import { BlockType, Position } from './types'

interface BlockProps {
  type: BlockType
  position: Position
}

const blockColors: Record<BlockType, string> = {
  grass: '#5D8B3A', // More authentic Minecraft grass green
  dirt: '#8B4513', // Rich brown dirt
  stone: '#696969', // Darker stone gray
  water: '#4A90E2', // Better water blue
  sand: '#DDD700', // More yellowish sand
  wood: '#8B4513' // Oak wood brown
}

export function Block({ type, position }: BlockProps) {
  // Add some variation for more organic look
  const isWater = type === 'water'
  
  return (
    <mesh position={[position.x, position.y, position.z]}>
      <boxGeometry args={[1, 1, 1]} />
      <meshLambertMaterial 
        color={blockColors[type]}
        transparent={isWater}
        opacity={isWater ? 0.8 : 1.0}
      />
    </mesh>
  )
}