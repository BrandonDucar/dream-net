import { useMemo } from 'react'

interface CloudProps {
  position: [number, number, number]
  scale?: number
}

function SingleCloud({ position, scale = 1 }: CloudProps) {
  return (
    <group position={position} scale={scale}>
      {/* Main cloud body made of multiple spheres */}
      <mesh position={[0, 0, 0]}>
        <sphereGeometry args={[1.5, 8, 6]} />
        <meshLambertMaterial color="#FFFFFF" />
      </mesh>
      
      <mesh position={[1.2, 0.3, 0.3]}>
        <sphereGeometry args={[1.2, 8, 6]} />
        <meshLambertMaterial color="#FFFFFF" />
      </mesh>
      
      <mesh position={[-1.1, 0.2, -0.2]}>
        <sphereGeometry args={[1.3, 8, 6]} />
        <meshLambertMaterial color="#FFFFFF" />
      </mesh>
      
      <mesh position={[0.5, 0.8, 0.1]}>
        <sphereGeometry args={[1.0, 8, 6]} />
        <meshLambertMaterial color="#FFFFFF" />
      </mesh>
      
      <mesh position={[-0.3, 0.5, 0.8]}>
        <sphereGeometry args={[0.8, 8, 6]} />
        <meshLambertMaterial color="#FFFFFF" />
      </mesh>
      
      <mesh position={[0.2, -0.3, -0.5]}>
        <sphereGeometry args={[0.9, 8, 6]} />
        <meshLambertMaterial color="#FFFFFF" />
      </mesh>
    </group>
  )
}

export function Clouds() {
  // Generate static cloud positions
  const cloudPositions = useMemo(() => [
    { position: [5, 25, 8], scale: 1.2 },
    { position: [18, 27, 15], scale: 0.8 },
    { position: [-3, 24, 22], scale: 1.0 },
    { position: [25, 26, 5], scale: 1.1 },
    { position: [12, 28, -5], scale: 0.9 },
    { position: [-8, 25, 12], scale: 1.3 },
    { position: [30, 29, 18], scale: 0.7 },
    { position: [8, 24, 28], scale: 1.0 },
    { position: [20, 27, -8], scale: 0.8 },
    { position: [-5, 26, 35], scale: 1.1 },
    { position: [35, 28, 10], scale: 0.9 },
    { position: [15, 25, 25], scale: 1.2 }
  ], [])

  return (
    <group>
      {cloudPositions.map((cloud, index) => (
        <SingleCloud
          key={index}
          position={cloud.position as [number, number, number]}
          scale={cloud.scale}
        />
      ))}
    </group>
  )
}