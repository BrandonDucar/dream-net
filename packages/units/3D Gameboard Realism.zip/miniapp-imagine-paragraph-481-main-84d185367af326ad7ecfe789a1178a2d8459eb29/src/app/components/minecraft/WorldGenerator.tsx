import { Block, BlockType, World } from './types'

export function generateWorld(size: number = 16): World {
  const blocks: Block[][][] = []
  
  // Initialize empty world
  for (let x = 0; x < size; x++) {
    blocks[x] = []
    for (let y = 0; y < 32; y++) { // Height limit
      blocks[x][y] = []
      for (let z = 0; z < size; z++) {
        blocks[x][y][z] = null as any
      }
    }
  }

  // Generate terrain
  for (let x = 0; x < size; x++) {
    for (let z = 0; z < size; z++) {
      // Simple height map using noise-like function
      const height = Math.floor(
        8 + 4 * Math.sin(x * 0.1) * Math.cos(z * 0.1) + 
        2 * Math.sin(x * 0.3) * Math.sin(z * 0.2) +
        Math.random() * 2
      )
      
      // Build terrain layers
      for (let y = 0; y <= height; y++) {
        let blockType: BlockType = 'stone'
        
        if (y === height) {
          // Top layer - grass or sand
          blockType = Math.random() > 0.8 ? 'sand' : 'grass'
        } else if (y === height - 1 && blockType !== 'sand') {
          // Just below surface - dirt
          blockType = 'dirt'
        } else if (y < height - 3) {
          // Deep underground - stone
          blockType = 'stone'
        } else {
          // Shallow underground - dirt
          blockType = 'dirt'
        }
        
        blocks[x][y][z] = {
          type: blockType,
          position: { x, y, z }
        }
      }
      
      // Add some water bodies
      if (height < 6 && Math.random() > 0.7) {
        for (let y = height + 1; y <= 6; y++) {
          blocks[x][y][z] = {
            type: 'water',
            position: { x, y, z }
        }
      }
      
      // Add some trees
      if (height > 8 && Math.random() > 0.95) {
        const treeHeight = 3 + Math.floor(Math.random() * 3)
        for (let y = height + 1; y <= height + treeHeight; y++) {
          blocks[x][y][z] = {
            type: 'wood',
            position: { x, y, z }
          }
        }
      }
    }
  }

  return { blocks, size }
}

export function getVisibleBlocks(world: World): Block[] {
  const visibleBlocks: Block[] = []
  
  for (let x = 0; x < world.size; x++) {
    for (let y = 0; y < 32; y++) {
      for (let z = 0; z < world.size; z++) {
        const block = world.blocks[x][y][z]
        if (!block) continue
        
        // Simple occlusion culling - only render blocks that have at least one exposed face
        const hasExposedFace = (
          !world.blocks[x + 1]?.[y]?.[z] ||
          !world.blocks[x - 1]?.[y]?.[z] ||
          !world.blocks[x]?.[y + 1]?.[z] ||
          !world.blocks[x]?.[y - 1]?.[z] ||
          !world.blocks[x]?.[y]?.[z + 1] ||
          !world.blocks[x]?.[y]?.[z - 1]
        )
        
        if (hasExposedFace) {
          visibleBlocks.push(block)
        }
      }
    }
  }
  
  return visibleBlocks
}