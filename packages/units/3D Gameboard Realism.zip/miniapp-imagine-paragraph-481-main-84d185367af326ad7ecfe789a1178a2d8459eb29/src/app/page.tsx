'use client'
import { useState, useEffect } from 'react';
import type { GameState, Move, Theme } from '@/lib/backgammon/types';
import { BackgammonBoard } from '@/components/BackgammonBoard';
import { GameControls } from '@/components/GameControls';
import { createInitialGameState, rollDice, switchPlayer, hasWon, cloneGameState } from '@/lib/backgammon/gameState';
import { parseMove, isMoveLegal, applyMove, getLegalMoves } from '@/lib/backgammon/moveValidator';
import { selectAIMove, getAIMoveDescription } from '@/lib/backgammon/ai';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function BackgammonPage() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [gameState, setGameState] = useState<GameState>(
    createInitialGameState('ai', 'biomech')
  );
  const [message, setMessage] = useState<string>('');
  const [isAITurn, setIsAITurn] = useState(false);
  
  // AI turn handler
  useEffect(() => {
    if (
      gameState.gameStarted &&
      gameState.gameMode === 'ai' &&
      gameState.currentPlayer === 'black' &&
      !gameState.winner &&
      gameState.dice.length > 0 &&
      !isAITurn
    ) {
      setIsAITurn(true);
      
      // Delay AI moves slightly for better UX
      const timer = setTimeout(() => {
        executeAITurn();
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [gameState, isAITurn]);
  
  const executeAITurn = () => {
    let currentState = cloneGameState(gameState);
    const moves: string[] = [];
    
    while (currentState.availableMoves.length > 0) {
      const aiMove = selectAIMove(currentState);
      
      if (!aiMove) {
        break;
      }
      
      const description = getAIMoveDescription(aiMove, 'black');
      moves.push(description);
      
      currentState = applyMove(currentState, aiMove);
      
      if (hasWon(currentState, 'black')) {
        currentState.winner = 'black';
        currentState.matchScore.black++;
        break;
      }
    }
    
    if (moves.length > 0) {
      setMessage(`AI ${moves.join(', then ')}`);
    } else {
      setMessage('AI has no legal moves and passes');
    }
    
    currentState.dice = [];
    currentState.availableMoves = [];
    currentState.currentPlayer = switchPlayer(currentState.currentPlayer);
    
    setGameState(currentState);
    setIsAITurn(false);
  };
  
  const handleStartGame = (mode: 'ai' | 'local', theme: Theme) => {
    const newState = createInitialGameState(mode, theme);
    newState.gameStarted = true;
    setGameState(newState);
    setMessage(`Game started! ${mode === 'ai' ? 'You are WHITE (○), AI is BLACK (●)' : 'WHITE (○) vs BLACK (●)'}`);
  };
  
  const handleRollDice = () => {
    if (gameState.winner) {
      setMessage('Game is over! Start a new game.');
      return;
    }
    
    if (gameState.dice.length > 0) {
      setMessage('You already rolled! Make your moves or end turn.');
      return;
    }
    
    const dice = rollDice();
    const newState = cloneGameState(gameState);
    newState.dice = dice;
    newState.availableMoves = [...dice];
    
    setGameState(newState);
    
    const legalMoves = getLegalMoves(newState, newState.currentPlayer);
    
    if (legalMoves.length === 0) {
      setMessage(`${newState.currentPlayer.toUpperCase()} rolled ${dice.join(', ')} but has no legal moves!`);
    } else {
      setMessage(`${newState.currentPlayer.toUpperCase()} rolled ${dice.join(', ')}! Choose your moves.`);
    }
  };
  
  const handleMakeMove = (moveStr: string) => {
    if (gameState.dice.length === 0) {
      setMessage('Roll the dice first!');
      return;
    }
    
    if (gameState.availableMoves.length === 0) {
      setMessage('No moves left! End your turn.');
      return;
    }
    
    const move = parseMove(moveStr, gameState.currentPlayer);
    
    if (!move) {
      setMessage('Invalid move format! Use: "13-8", "bar-3", or "6-off"');
      return;
    }
    
    if (!isMoveLegal(gameState, move)) {
      setMessage('Illegal move! Check the legal moves list.');
      return;
    }
    
    const newState = applyMove(gameState, move);
    
    // Check for win
    if (hasWon(newState, gameState.currentPlayer)) {
      newState.winner = gameState.currentPlayer;
      newState.matchScore[gameState.currentPlayer]++;
      setMessage(`${gameState.currentPlayer.toUpperCase()} WINS!`);
      setGameState(newState);
      return;
    }
    
    setGameState(newState);
    
    if (newState.availableMoves.length === 0) {
      setMessage('All moves used! End your turn.');
    } else {
      const legalMoves = getLegalMoves(newState, newState.currentPlayer);
      if (legalMoves.length === 0) {
        setMessage('No more legal moves! End your turn.');
      } else {
        setMessage(`Move made! ${newState.availableMoves.length} moves remaining.`);
      }
    }
  };
  
  const handleEndTurn = () => {
    if (gameState.dice.length === 0) {
      setMessage('Roll the dice first!');
      return;
    }
    
    const newState = cloneGameState(gameState);
    newState.dice = [];
    newState.availableMoves = [];
    newState.currentPlayer = switchPlayer(gameState.currentPlayer);
    
    setGameState(newState);
    
    if (newState.gameMode === 'ai' && newState.currentPlayer === 'black') {
      setMessage('AI is thinking...');
    } else {
      setMessage(`${newState.currentPlayer.toUpperCase()}'s turn!`);
    }
  };
  
  const handleNewGame = () => {
    const newState = createInitialGameState(gameState.gameMode, gameState.theme);
    newState.gameStarted = true;
    newState.matchScore = { ...gameState.matchScore };
    setGameState(newState);
    setMessage('New game started!');
    setIsAITurn(false);
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white p-4 pt-16">
      <div className="container mx-auto space-y-6">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-600">
            DreamNet Backgammon Arena
          </h1>
          <p className="text-gray-400">
            Full rules. Real strategy. Badass themes.
          </p>
          {gameState.gameStarted && (
            <div className="mt-4 text-sm text-gray-500">
              Match Score - White: {gameState.matchScore.white} | Black: {gameState.matchScore.black}
            </div>
          )}
        </div>
        
        {gameState.gameStarted && (
          <BackgammonBoard gameState={gameState} />
        )}
        
        <GameControls
          gameState={gameState}
          onStartGame={handleStartGame}
          onRollDice={handleRollDice}
          onMakeMove={handleMakeMove}
          onEndTurn={handleEndTurn}
          onNewGame={handleNewGame}
          message={message}
        />
      </div>
    </div>
  );
}
