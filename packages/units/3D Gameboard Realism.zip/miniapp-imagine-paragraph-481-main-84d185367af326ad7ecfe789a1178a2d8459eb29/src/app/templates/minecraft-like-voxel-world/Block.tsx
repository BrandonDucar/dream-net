import { useRef } from 'react'
import { Mesh } from 'three'
import { ThreeEvent } from '@react-three/fiber'

export interface BlockProps {
  position: [number, number, number]
  blockType: 'grass' | 'dirt' | 'stone' | 'wood' | 'water'
  onClick?: (event: ThreeEvent<MouseEvent>) => void
}

const BLOCK_COLORS = {
  grass: '#4CAF50',
  dirt: '#8D6E63',
  stone: '#9E9E9E',
  wood: '#795548',
  water: '#2196F3'
}

export function Block({ position, blockType, onClick }: BlockProps) {
  const meshRef = useRef<Mesh>(null)

  return (
    <mesh
      ref={meshRef}
      position={position}
      onClick={onClick}
      onPointerEnter={() => {
        if (meshRef.current) {
          meshRef.current.scale.setScalar(1.05)
        }
      }}
      onPointerLeave={() => {
        if (meshRef.current) {
          meshRef.current.scale.setScalar(1)
        }
      }}
    >
      <boxGeometry args={[1, 1, 1]} />
      <meshLambertMaterial 
        color={BLOCK_COLORS[blockType]} 
        transparent={blockType === 'water'} 
        opacity={blockType === 'water' ? 0.7 : 1}
      />
    </mesh>
  )
}