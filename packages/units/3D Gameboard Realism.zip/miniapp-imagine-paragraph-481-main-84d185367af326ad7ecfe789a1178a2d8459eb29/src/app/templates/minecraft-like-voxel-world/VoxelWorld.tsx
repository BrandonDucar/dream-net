'use client'

import { Canvas, ThreeEvent } from '@react-three/fiber'
import { OrbitControls, Sky, Environment } from '@react-three/drei'
import { useState, useMemo, useEffect } from 'react'
import { Block, BlockProps } from './Block'
import { generateTerrain } from './terrainUtils'

export interface VoxelWorldProps {
  width?: number
  depth?: number
  height?: number
  activeBlockType: BlockProps['blockType']
  onBlockCountChange?: (count: number) => void
}

export function VoxelWorld({ width = 20, depth = 20, height = 8, activeBlockType, onBlockCountChange }: VoxelWorldProps) {
  const initialBlocks = useMemo(() => generateTerrain(width, depth, height), [width, depth, height])
  const [blocks, setBlocks] = useState(initialBlocks)

  // Notify parent of block count changes using useEffect
  useEffect(() => {
    if (onBlockCountChange) {
      onBlockCountChange(blocks.length)
    }
  }, [blocks.length, onBlockCountChange])

  const handleBlockClick = (event: ThreeEvent<MouseEvent>, blockKey: string, currentPosition: [number, number, number]) => {
    event.stopPropagation()
    
    if (event.button === 2) { // Right-click to remove
        setBlocks(prevBlocks => prevBlocks.filter(b => b.key !== blockKey))
    } else if (event.button === 0) { // Left-click to add
        if (!event.face || !event.face.normal) return;

        const normal = event.face.normal;
        const newPosition: [number, number, number] = [
            currentPosition[0] + normal.x,
            currentPosition[1] + normal.y,
            currentPosition[2] + normal.z,
        ]

        const newBlock = {
            key: newPosition.join('-'),
            position: newPosition,
            blockType: activeBlockType
        }

        setBlocks(prevBlocks => [...prevBlocks, newBlock])
    }
  }

  return (
    <div className="w-full h-screen bg-sky-200" onContextMenu={(e) => e.preventDefault()}>
      <Canvas
        camera={{ 
          position: [15, 12, 15], 
          fov: 60,
          near: 0.1,
          far: 1000
        }}
        shadows
      >
        <ambientLight intensity={0.6} />
        <directionalLight
          position={[50, 50, 25]}
          intensity={1}
          castShadow
          shadow-mapSize={[2048, 2048]}
          shadow-camera-left={-50}
          shadow-camera-right={50}
          shadow-camera-top={50}
          shadow-camera-bottom={-50}
        />
        <Sky
          distance={450000}
          sunPosition={[1, 1, 0]}
          inclination={0}
          azimuth={0.25}
        />
        <Environment preset="sunset" />

        {/* Render blocks */}
        {blocks.map((block) => (
          <Block
            key={block.key}
            position={block.position}
            blockType={block.blockType}
            onClick={(e) => handleBlockClick(e, block.key, block.position)}
          />
        ))}

        <OrbitControls
          enablePan={true}
          enableZoom={true}
          enableRotate={true}
          maxPolarAngle={Math.PI / 2}
          minDistance={5}
          maxDistance={50}
        />
      </Canvas>
      <div className="absolute bottom-4 right-4 bg-black bg-opacity-50 text-white p-4 rounded-lg">
        <h3 className="font-bold mb-2">Controls:</h3>
        <ul className="text-sm list-disc list-inside">
            <li>LMB on block: Add new block</li>
            <li>RMB on block: Remove block</li>
            <li>Mouse Drag: Orbit</li>
            <li>Mouse Wheel: Zoom</li>
        </ul>
      </div>
    </div>
  )
}