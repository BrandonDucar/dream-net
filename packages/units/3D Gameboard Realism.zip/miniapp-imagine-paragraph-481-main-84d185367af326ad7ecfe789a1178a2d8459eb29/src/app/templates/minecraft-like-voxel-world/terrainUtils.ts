import { BlockProps } from './Block';

// Simple noise function for terrain generation
function noise(x: number, z: number): number {
  return Math.sin(x * 0.3) * Math.cos(z * 0.3) * 0.5 + 
         Math.sin(x * 0.1) * Math.cos(z * 0.1) * 2 +
         Math.random() * 0.5
}

function getBlockType(x: number, y: number, z: number, surfaceY: number): BlockProps['blockType'] {
  if (y === surfaceY) {
    return 'grass'
  } else if (y === surfaceY - 1 || y === surfaceY - 2) {
    return 'dirt'
  } else if (y < surfaceY - 2) {
    return 'stone'
  }
  return 'dirt'
}

export function generateTerrain(width: number, depth: number, height: number) {
    const blocks: Array<{
        position: [number, number, number]
        blockType: BlockProps['blockType']
        key: string
    }> = []

    for (let x = 0; x < width; x++) {
        for (let z = 0; z < depth; z++) {
            const surfaceHeight = Math.floor(Math.max(1, Math.min(height - 1, 3 + noise(x, z))));

            for (let y = 0; y <= surfaceHeight; y++) {
                const blockType = getBlockType(x, y, z, surfaceHeight);
                blocks.push({
                    position: [x - width / 2, y, z - depth / 2],
                    blockType,
                    key: `${x}-${y}-${z}`
                });
            }

            if (surfaceHeight < 2 && Math.random() > 0.7) {
                blocks.push({
                    position: [x - width / 2, surfaceHeight + 1, z - depth / 2],
                    blockType: 'water',
                    key: `${x}-${surfaceHeight + 1}-${z}-water`
                });
            }

            if (surfaceHeight > 2 && Math.random() > 0.95) {
                const treeHeight = Math.floor(Math.random() * 3) + 2;
                for (let treeY = 1; treeY <= treeHeight; treeY++) {
                    blocks.push({
                        position: [x - width / 2, surfaceHeight + treeY, z - depth / 2],
                        blockType: 'wood',
                        key: `${x}-${surfaceHeight + treeY}-${z}-tree`
                    });
                }
            }
        }
    }
    return blocks;
}