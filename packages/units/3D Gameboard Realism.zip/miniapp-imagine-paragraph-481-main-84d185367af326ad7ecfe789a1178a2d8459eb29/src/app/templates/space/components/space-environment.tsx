"use client"

import { useRef, useMemo } from "react"
import { Canvas, useFrame, useThree } from "@react-three/fiber"
import { Stars, OrbitControls, Float, KeyboardControls, useKeyboardControls } from "@react-three/drei"
import * as THREE from "three"

export default function SpaceEnvironment() {
  return (
    <div className="w-full h-screen bg-black">
      <KeyboardControls
        map={[
          { name: "forward", keys: ["ArrowUp", "w", "W"] },
          { name: "backward", keys: ["ArrowDown", "s", "S"] },
          { name: "left", keys: ["ArrowLeft", "a", "A"] },
          { name: "right", keys: ["ArrowRight", "d", "D"] },
          { name: "up", keys: ["Space"] },
          { name: "down", keys: ["ShiftLeft", "ShiftRight"] },
          { name: "boost", keys: ["KeyF"] },
        ]}
      >
        <Canvas camera={{ position: [0, 0, 30], fov: 60 }}>
          <fog attach="fog" args={["black", 30, 100]} />
          <ambientLight intensity={0.2} />
          <pointLight position={[10, 10, 10]} intensity={0.8} />
          <Asteroids count={50} />
          <Stars radius={100} depth={50} count={7000} factor={6} saturation={1} fade speed={0.5} />
          <FlyControls />
        </Canvas>
      </KeyboardControls>
      <div className="absolute bottom-4 left-4 text-white text-sm opacity-70">
        <p>WASD/Arrow Keys: Move | Space: Move Up | Shift: Move Down | F: Speed Boost</p>
        <p>Mouse: Look Around | Mouse Wheel: Zoom</p>
      </div>
    </div>
  )
}

function FlyControls() {
  const { camera } = useThree()
  const [subscribeKeys, getKeys] = useKeyboardControls()
  const orbitControlsRef = useRef()

  useFrame((state, delta) => {
    const { forward, backward, left, right, up, down, boost } = getKeys()

    // Calculate movement speed
    const speedMultiplier = boost ? 5 : 1
    const moveSpeed = delta * 10 * speedMultiplier

    // Get camera direction vectors
    const direction = new THREE.Vector3()
    const frontVector = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion)
    const sideVector = new THREE.Vector3(1, 0, 0).applyQuaternion(camera.quaternion)
    const upVector = new THREE.Vector3(0, 1, 0)

    // Calculate movement direction
    direction.set(0, 0, 0)
    if (forward) direction.add(frontVector)
    if (backward) direction.sub(frontVector)
    if (right) direction.add(sideVector)
    if (left) direction.sub(sideVector)
    if (up) direction.add(upVector)
    if (down) direction.sub(upVector)
    direction.normalize().multiplyScalar(moveSpeed)

    // Move camera
    if (direction.length() > 0) {
      camera.position.add(direction)

      // Update orbit controls target to be in front of the camera
      if (orbitControlsRef.current) {
        const targetDistance = 10
        const target = new THREE.Vector3()
        target.copy(camera.position).add(frontVector.multiplyScalar(targetDistance))
        orbitControlsRef.current.target.copy(target)
      }
    }
  })

  return (
    <OrbitControls
      ref={orbitControlsRef}
      enableZoom={true}
      enablePan={false}
      enableRotate={true}
      zoomSpeed={0.8}
      rotateSpeed={0.8}
      minDistance={1}
      maxDistance={200}
    />
  )
}

function Asteroids({ count = 50 }) {
  const asteroids = useMemo(() => {
    return Array.from({ length: count }).map((_, i) => ({
      position: [Math.random() * 200 - 100, Math.random() * 200 - 100, Math.random() * 200 - 100],
      rotation: [Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI],
      scale: Math.random() * 2 + 0.5,
      speed: Math.random() * 0.02 + 0.005,
    }))
  }, [count])

  return (
    <>
      {asteroids.map((data, i) => (
        <Asteroid key={i} {...data} />
      ))}
    </>
  )
}

function Asteroid({ position, rotation, scale, speed }) {
  const meshRef = useRef()

  useFrame(() => {
    if (meshRef.current) {
      meshRef.current.rotation.x += speed * 0.5
      meshRef.current.rotation.y += speed
    }
  })

  return (
    <Float speed={1} rotationIntensity={0.2} floatIntensity={0.2}>
      <mesh ref={meshRef} position={position} rotation={rotation} scale={scale}>
        <icosahedronGeometry args={[1, 1]} />
        <meshStandardMaterial color="#888888" roughness={0.9} metalness={0.2} flatShading={true} />
      </mesh>
    </Float>
  )
}