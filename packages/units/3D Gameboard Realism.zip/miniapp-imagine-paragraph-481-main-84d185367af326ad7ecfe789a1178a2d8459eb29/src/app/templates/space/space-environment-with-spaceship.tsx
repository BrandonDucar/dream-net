"use client"

import { useRef, useMemo } from "react"
import { Canvas, useFrame, useThree } from "@react-three/fiber"
import { Stars, OrbitControls, Float, KeyboardControls, useKeyboardControls } from "@react-three/drei"
import * as THREE from "three"
import Spaceship from "./spaceship"

export default function SpaceEnvironmentWithSpaceship() {
  return (
    <div className="w-full h-screen bg-black">
      <KeyboardControls
        map={[
          { name: "forward", keys: ["ArrowUp", "w", "W"] },
          { name: "backward", keys: ["ArrowDown", "s", "S"] },
          { name: "left", keys: ["ArrowLeft", "a", "A"] },
          { name: "right", keys: ["ArrowRight", "d", "D"] },
          { name: "up", keys: ["Space"] },
          { name: "down", keys: ["ShiftLeft", "ShiftRight"] },
          { name: "boost", keys: ["KeyF"] },
        ]}
      >
        <Canvas camera={{ position: [0, 5, 12], fov: 60 }}>
          <fog attach="fog" args={["black", 30, 150]} />
          <ambientLight intensity={0.5} />
          <pointLight position={[100, 100, 100]} intensity={1.5} />
          
          <Player />
          
          {/* Static spaceships in the distance for scenery */}
          <Float>
            <group position={[-20, 5, -30]} rotation={[0, Math.PI / 4, 0]} scale={1.2}>
              <Spaceship />
            </group>
          </Float>
          <Float>
            <group position={[25, -8, -45]} rotation={[0, -Math.PI / 3, 0]} scale={1.5}>
              <Spaceship />
            </group>
          </Float>
          
          <Asteroids count={50} />
          <Stars radius={100} depth={50} count={7000} factor={6} saturation={1} fade speed={0.5} />
        </Canvas>
      </KeyboardControls>
      <div className="absolute bottom-4 left-4 text-white text-sm opacity-70">
        <p>WASD/Arrow Keys: Move & Turn | Space/Shift: Move Up/Down</p>
        <p>F: Speed Boost | Mouse: Look Around Ship</p>
        <p className="mt-2 text-orange-400">🚀 Player-Controlled Spaceship</p>
      </div>
    </div>
  )
}

function Player() {
  const shipRef = useRef<THREE.Group>(null);
  const { camera } = useThree();
  const [, getKeys] = useKeyboardControls<any>();
  const orbitControlsRef = useRef<any>(null); // Ref for OrbitControls

  const speed = 15;
  const rotationSpeed = 1.5;

  useFrame((state, delta) => {
    if (!shipRef.current || !orbitControlsRef.current) return;

    const { forward, backward, left, right, up, down, boost } = getKeys();

    // --- Ship Movement ---
    const currentSpeed = (boost ? speed * 2.5 : speed) * delta;
    
    // Move forward/backward along the ship's local z-axis
    if (forward) {
        shipRef.current.translateZ(-currentSpeed);
    }
    if (backward) {
        shipRef.current.translateZ(currentSpeed);
    }
    
    // --- Ship Rotation (Yaw) ---
    if (left) {
        shipRef.current.rotateY(rotationSpeed * delta);
    }
    if (right) {
        shipRef.current.rotateY(-rotationSpeed * delta);
    }

    // --- Vertical Strafing ---
    if (up) {
      shipRef.current.position.y += currentSpeed;
    }
    if (down) {
      shipRef.current.position.y -= currentSpeed;
    }

    // --- Camera Follow Logic ---
    // The camera follows the ship from a fixed offset.
    const cameraOffset = new THREE.Vector3(0, 5, 12);
    // Apply the ship's rotation to the offset vector.
    const cameraOffsetRotated = cameraOffset.clone().applyQuaternion(shipRef.current.quaternion);
    const desiredCameraPosition = shipRef.current.position.clone().add(cameraOffsetRotated);

    // Smoothly interpolate the camera's position (lerp).
    camera.position.lerp(desiredCameraPosition, 0.1);
    
    // Always point the camera at the ship and update orbit controls.
    orbitControlsRef.current.target.copy(shipRef.current.position);
    orbitControlsRef.current.update();
  });

  return (
    <>
      <group ref={shipRef} scale={1.5}>
          <Spaceship />
      </group>
      {/* OrbitControls allows looking around the ship */}
      <OrbitControls ref={orbitControlsRef} enablePan={false} enableZoom={true} minDistance={5} maxDistance={50} />
    </>
  );
}

interface AsteroidData {
  position: [number, number, number]
  rotation: [number, number, number]
  scale: number
  speed: number
}

function Asteroids({ count = 30 }: { count?: number }) {
  const asteroids = useMemo(() => {
    return Array.from({ length: count }).map((_, i): AsteroidData => ({
      position: [
        Math.random() * 200 - 100, 
        Math.random() * 200 - 100, 
        Math.random() * 200 - 100
      ],
      rotation: [
        Math.random() * Math.PI, 
        Math.random() * Math.PI, 
        Math.random() * Math.PI
      ],
      scale: Math.random() * 2 + 0.5,
      speed: Math.random() * 0.02 + 0.005,
    }))
  }, [count])

  return (
    <>
      {asteroids.map((data, i) => (
        <Asteroid key={i} {...data} />
      ))}
    </>
  )
}

function Asteroid({ position, rotation, scale, speed }: AsteroidData) {
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame(() => {
    if (meshRef.current) {
      meshRef.current.rotation.x += speed * 0.5
      meshRef.current.rotation.y += speed
    }
  })

  return (
    <Float speed={1} rotationIntensity={0.2} floatIntensity={0.2}>
      <mesh ref={meshRef} position={position} rotation={rotation} scale={scale}>
        <icosahedronGeometry args={[1, 1]} />
        <meshStandardMaterial color="#888888" roughness={0.9} metalness={0.2} flatShading={true} />
      </mesh>
    </Float>
  )
}