'use client';

import { Canvas } from '@react-three/fiber';
import { OrbitControls, Environment, PerspectiveCamera } from '@react-three/drei';
import { Board3D } from './Board3D';
import { Checker3D } from './Checker3D';
import { Dice3D } from './Dice3D';
import type { GameState } from '@/lib/backgammon/types';
import { themes } from '@/lib/backgammon/themes';

interface Backgammon3DSceneProps {
  gameState: GameState;
  onPointClick?: (pointIndex: number) => void;
}

export function Backgammon3DScene({ gameState, onPointClick }: Backgammon3DSceneProps) {
  const theme = themes[gameState.theme];
  
  return (
    <div className="w-full h-[600px] rounded-lg overflow-hidden">
      <Canvas shadows>
        <PerspectiveCamera makeDefault position={[0, 8, 10]} fov={50} />
        
        {/* Lighting setup based on theme */}
        <Lighting theme={gameState.theme} />
        
        {/* Environment for reflections */}
        <Environment preset={gameState.theme === 'neon' ? 'night' : 'city'} />
        
        {/* The game board */}
        <Board3D theme={theme} onPointClick={onPointClick} />
        
        {/* Render checkers on points */}
        {gameState.points.map((point, pointIndex) => {
          if (!point.owner || point.checkers === 0) return null;
          
          return Array.from({ length: point.checkers }).map((_, stackIndex) => {
            const position = getCheckerPosition(pointIndex, stackIndex);
            return (
              <Checker3D
                key={`${pointIndex}-${stackIndex}`}
                player={point.owner!}
                position={position}
                stackHeight={stackIndex}
                theme={theme.name}
              />
            );
          });
        })}
        
        {/* Render checkers on bar */}
        {gameState.bar.white > 0 && Array.from({ length: gameState.bar.white }).map((_, i) => (
          <Checker3D
            key={`bar-white-${i}`}
            player="white"
            position={[-0.2, 0.15, 0.8 - i * 0.3]}
            stackHeight={i}
            theme={theme.name}
          />
        ))}
        
        {gameState.bar.black > 0 && Array.from({ length: gameState.bar.black }).map((_, i) => (
          <Checker3D
            key={`bar-black-${i}`}
            player="black"
            position={[0.2, 0.15, -0.8 + i * 0.3]}
            stackHeight={i}
            theme={theme.name}
          />
        ))}
        
        {/* Render borne off checkers */}
        {gameState.bornOff.white > 0 && Array.from({ length: Math.min(gameState.bornOff.white, 15) }).map((_, i) => (
          <Checker3D
            key={`off-white-${i}`}
            player="white"
            position={[7.5, 0.15, -2 + (i % 5) * 0.4]}
            stackHeight={Math.floor(i / 5)}
            theme={theme.name}
          />
        ))}
        
        {gameState.bornOff.black > 0 && Array.from({ length: Math.min(gameState.bornOff.black, 15) }).map((_, i) => (
          <Checker3D
            key={`off-black-${i}`}
            player="black"
            position={[-7.5, 0.15, 2 - (i % 5) * 0.4]}
            stackHeight={Math.floor(i / 5)}
            theme={theme.name}
          />
        ))}
        
        {/* Render dice */}
        {gameState.dice.length > 0 && gameState.dice.map((value, i) => (
          <Dice3D
            key={`dice-${i}`}
            value={value}
            position={[
              -2 + i * 1,
              1.5,
              gameState.currentPlayer === 'white' ? -4 : 4
            ]}
            theme={theme.name}
          />
        ))}
        
        {/* Camera controls */}
        <OrbitControls
          enablePan={false}
          enableZoom={true}
          enableRotate={true}
          minDistance={8}
          maxDistance={20}
          maxPolarAngle={Math.PI / 2.2}
          minPolarAngle={Math.PI / 6}
          target={[0, 0, 0]}
        />
      </Canvas>
    </div>
  );
}

function Lighting({ theme }: { theme: string }) {
  const isNeon = theme === 'neon';
  const isBiomech = theme === 'biomech';
  const isDNA = theme === 'dna';
  
  return (
    <>
      {/* Ambient light */}
      <ambientLight intensity={isNeon ? 0.3 : 0.5} />
      
      {/* Main directional light */}
      <directionalLight
        position={[5, 8, 5]}
        intensity={isNeon ? 0.8 : 1.2}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-left={-10}
        shadow-camera-right={10}
        shadow-camera-top={10}
        shadow-camera-bottom={-10}
      />
      
      {/* Theme-specific accent lights */}
      {isNeon && (
        <>
          <pointLight position={[-5, 2, 0]} color="#3b82f6" intensity={2} distance={10} />
          <pointLight position={[5, 2, 0]} color="#ec4899" intensity={2} distance={10} />
        </>
      )}
      
      {isBiomech && (
        <>
          <pointLight position={[0, 3, -4]} color="#dc2626" intensity={1.5} distance={8} />
          <spotLight position={[0, 5, 0]} color="#71717a" intensity={0.5} angle={0.6} />
        </>
      )}
      
      {isDNA && (
        <>
          <pointLight position={[-4, 3, 0]} color="#22c55e" intensity={1.2} distance={10} />
          <pointLight position={[4, 3, 0]} color="#8b5cf6" intensity={1.2} distance={10} />
        </>
      )}
      
      {/* Fill light */}
      <directionalLight position={[-5, 3, -5]} intensity={0.3} />
    </>
  );
}

function getCheckerPosition(pointIndex: number, stackHeight: number): [number, number, number] {
  // Calculate position based on point index
  const isTopRow = pointIndex >= 12;
  const sideIndex = pointIndex % 12;
  const isRightSide = sideIndex >= 6;
  
  const localIndex = isRightSide ? sideIndex - 6 : sideIndex;
  const spacing = 1.1;
  const xOffset = isRightSide ? 0.4 : -0.4;
  const xPos = (localIndex - 2.5) * spacing + xOffset;
  
  // Position checkers along the triangle
  const zBase = isTopRow ? 2.2 : -2.2;
  const zDirection = isTopRow ? -1 : 1;
  const zPos = zBase + (zDirection * stackHeight * 0.15);
  
  const yPos = 0.15 + stackHeight * 0.25;
  
  return [xPos, yPos, zPos];
}
