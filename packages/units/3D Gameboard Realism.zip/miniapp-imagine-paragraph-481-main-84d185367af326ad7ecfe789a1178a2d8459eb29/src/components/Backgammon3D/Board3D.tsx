'use client';

import { useRef, useMemo } from 'react';
import type * as THREE from 'three';
import type { ThemeConfig } from '@/lib/backgammon/types';

interface Board3DProps {
  theme: ThemeConfig;
  onPointClick?: (pointIndex: number) => void;
}

export function Board3D({ theme, onPointClick }: Board3DProps) {
  const boardRef = useRef<THREE.Mesh>(null);
  
  const boardMaterial = useMemo(() => {
    return {
      color: theme.colors.primary,
      metalness: theme.name.includes('Biomech') ? 0.8 : 0.3,
      roughness: theme.name.includes('Glass') ? 0.1 : 0.4,
    };
  }, [theme]);

  const accentMaterial = useMemo(() => {
    return {
      color: theme.colors.accent,
      metalness: 0.6,
      roughness: 0.3,
      emissive: theme.name.includes('Neon') ? theme.colors.accent : '#000000',
      emissiveIntensity: theme.name.includes('Neon') ? 0.5 : 0,
    };
  }, [theme]);

  return (
    <group>
      {/* Main board surface */}
      <mesh
        ref={boardRef}
        position={[0, -0.2, 0]}
        rotation={[-Math.PI / 2, 0, 0]}
        receiveShadow
      >
        <boxGeometry args={[14, 8, 0.4]} />
        <meshStandardMaterial
          color={boardMaterial.color}
          metalness={boardMaterial.metalness}
          roughness={boardMaterial.roughness}
        />
      </mesh>

      {/* Border frame */}
      <mesh position={[0, 0, 0]} receiveShadow>
        <boxGeometry args={[14.4, 0.3, 8.4]} />
        <meshStandardMaterial
          color={accentMaterial.color}
          metalness={accentMaterial.metalness}
          roughness={accentMaterial.roughness}
          emissive={accentMaterial.emissive}
          emissiveIntensity={accentMaterial.emissiveIntensity}
        />
      </mesh>

      {/* Center divider */}
      <mesh position={[0, 0.1, 0]} castShadow>
        <boxGeometry args={[0.3, 0.4, 8]} />
        <meshStandardMaterial
          color={theme.colors.secondary}
          metalness={0.7}
          roughness={0.2}
          emissive={theme.colors.secondary}
          emissiveIntensity={0.3}
        />
      </mesh>

      {/* Triangular points (24 total) */}
      {Array.from({ length: 24 }).map((_, i) => (
        <TriangularPoint
          key={i}
          index={i}
          theme={theme}
          onClick={() => onPointClick?.(i)}
        />
      ))}
    </group>
  );
}

interface TriangularPointProps {
  index: number;
  theme: ThemeConfig;
  onClick?: () => void;
}

function TriangularPoint({ index, theme, onClick }: TriangularPointProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  
  // Calculate position based on point index
  // Points 0-11 on bottom, 12-23 on top
  // Split by center bar: 0-5 and 6-11 on bottom, 12-17 and 18-23 on top
  const isTopRow = index >= 12;
  const sideIndex = index % 12;
  const isRightSide = sideIndex >= 6;
  
  const localIndex = isRightSide ? sideIndex - 6 : sideIndex;
  const spacing = 1.1;
  const xOffset = isRightSide ? 0.4 : -0.4;
  const xPos = (localIndex - 2.5) * spacing + xOffset;
  const zPos = isTopRow ? 2.8 : -2.8;
  const rotation = isTopRow ? 0 : Math.PI;
  
  // Alternate colors for visual clarity
  const isLightPoint = index % 2 === 0;
  const pointColor = isLightPoint ? theme.colors.secondary : theme.colors.accent;
  
  return (
    <mesh
      ref={meshRef}
      position={[xPos, 0.05, zPos]}
      rotation={[0, rotation, 0]}
      onClick={onClick}
      onPointerEnter={() => {
        if (meshRef.current) {
          meshRef.current.scale.setScalar(1.1);
        }
      }}
      onPointerLeave={() => {
        if (meshRef.current) {
          meshRef.current.scale.setScalar(1);
        }
      }}
      castShadow
    >
      <coneGeometry args={[0.45, 2, 3]} />
      <meshStandardMaterial
        color={pointColor}
        metalness={0.5}
        roughness={0.4}
        emissive={theme.name.includes('Neon') ? pointColor : '#000000'}
        emissiveIntensity={theme.name.includes('Neon') ? 0.2 : 0}
      />
    </mesh>
  );
}
