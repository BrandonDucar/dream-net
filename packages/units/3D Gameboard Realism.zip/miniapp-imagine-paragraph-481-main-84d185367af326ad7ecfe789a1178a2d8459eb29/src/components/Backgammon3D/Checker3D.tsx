'use client';

import { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import type * as THREE from 'three';
import type { Player } from '@/lib/backgammon/types';

interface Checker3DProps {
  player: Player;
  position: [number, number, number];
  stackHeight?: number;
  onClick?: () => void;
  theme: string;
}

export function Checker3D({ player, position, stackHeight = 0, onClick, theme }: Checker3DProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  
  useFrame((state) => {
    if (meshRef.current && hovered) {
      meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 3) * 0.05;
    }
  });

  // Adjust position based on stack height
  const adjustedPosition: [number, number, number] = [
    position[0],
    position[1] + stackHeight * 0.25,
    position[2]
  ];

  // Material properties based on player and theme
  const isBiomech = theme.includes('Biomech');
  const isNeon = theme.includes('Neon');
  const isDNA = theme.includes('DNA');

  const checkerMaterial = {
    white: {
      color: isNeon ? '#ffffff' : isBiomech ? '#e0e0e0' : '#f0f0f0',
      metalness: isBiomech ? 0.9 : isNeon ? 0.7 : 0.3,
      roughness: isBiomech ? 0.2 : isNeon ? 0.1 : 0.4,
      emissive: isNeon ? '#3b82f6' : isDNA ? '#22c55e' : '#000000',
      emissiveIntensity: isNeon ? 0.5 : isDNA ? 0.3 : 0,
    },
    black: {
      color: isBiomech ? '#2a2a2a' : isNeon ? '#1a1a2e' : '#1e1e1e',
      metalness: isBiomech ? 0.8 : isNeon ? 0.6 : 0.4,
      roughness: isBiomech ? 0.3 : isNeon ? 0.2 : 0.5,
      emissive: isNeon ? '#ec4899' : isDNA ? '#8b5cf6' : isBiomech ? '#dc2626' : '#000000',
      emissiveIntensity: isNeon ? 0.6 : isDNA ? 0.4 : isBiomech ? 0.2 : 0,
    },
  };

  const material = checkerMaterial[player];

  return (
    <mesh
      ref={meshRef}
      position={adjustedPosition}
      onClick={onClick}
      onPointerEnter={() => setHovered(true)}
      onPointerLeave={() => setHovered(false)}
      castShadow
      receiveShadow
    >
      <cylinderGeometry args={[0.35, 0.35, 0.2, 32]} />
      <meshStandardMaterial
        color={material.color}
        metalness={material.metalness}
        roughness={material.roughness}
        emissive={material.emissive}
        emissiveIntensity={material.emissiveIntensity}
      />
      
      {/* Top edge ring for detail */}
      <mesh position={[0, 0.1, 0]} castShadow>
        <torusGeometry args={[0.35, 0.02, 8, 32]} />
        <meshStandardMaterial
          color={player === 'white' ? '#c0c0c0' : '#0a0a0a'}
          metalness={0.9}
          roughness={0.1}
        />
      </mesh>
    </mesh>
  );
}
