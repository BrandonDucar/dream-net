'use client';

import { useRef, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import type * as THREE from 'three';

interface Dice3DProps {
  value: number;
  position: [number, number, number];
  theme: string;
}

export function Dice3D({ value, position, theme }: Dice3DProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const rotationSpeed = useRef({ x: 0, y: 0, z: 0 });

  useEffect(() => {
    // Initialize random rotation speeds for rolling animation
    rotationSpeed.current = {
      x: (Math.random() - 0.5) * 0.1,
      y: (Math.random() - 0.5) * 0.1,
      z: (Math.random() - 0.5) * 0.1,
    };

    // Settle into final orientation after a brief roll
    const timeout = setTimeout(() => {
      rotationSpeed.current = { x: 0, y: 0, z: 0 };
      
      // Align to show the correct face based on value
      if (meshRef.current) {
        meshRef.current.rotation.set(
          value === 6 ? Math.PI : value === 1 ? 0 : Math.PI / 2,
          0,
          value === 4 || value === 3 ? Math.PI / 2 : 0
        );
      }
    }, 1000);

    return () => clearTimeout(timeout);
  }, [value]);

  useFrame(() => {
    if (meshRef.current) {
      meshRef.current.rotation.x += rotationSpeed.current.x;
      meshRef.current.rotation.y += rotationSpeed.current.y;
      meshRef.current.rotation.z += rotationSpeed.current.z;
    }
  });

  const isNeon = theme.includes('Neon');
  const isDNA = theme.includes('DNA');

  return (
    <mesh ref={meshRef} position={position} castShadow>
      <boxGeometry args={[0.4, 0.4, 0.4]} />
      <meshStandardMaterial
        color={isNeon ? '#ffffff' : isDNA ? '#f0f0f0' : '#e0e0e0'}
        metalness={0.3}
        roughness={0.5}
        emissive={isNeon ? '#3b82f6' : isDNA ? '#22c55e' : '#000000'}
        emissiveIntensity={isNeon ? 0.3 : isDNA ? 0.2 : 0}
      />
      
      {/* Dots for die faces */}
      <DiceDots value={value} />
    </mesh>
  );
}

function DiceDots({ value }: { value: number }) {
  const dotPositions = getDotPositions(value);
  
  return (
    <>
      {dotPositions.map((pos, i) => (
        <mesh key={i} position={pos}>
          <sphereGeometry args={[0.05, 16, 16]} />
          <meshStandardMaterial color="#000000" />
        </mesh>
      ))}
    </>
  );
}

function getDotPositions(value: number): [number, number, number][] {
  const offset = 0.21; // Distance from center to face
  
  switch (value) {
    case 1:
      return [[0, offset, 0]];
    case 2:
      return [
        [-0.1, offset, -0.1],
        [0.1, offset, 0.1],
      ];
    case 3:
      return [
        [-0.1, offset, -0.1],
        [0, offset, 0],
        [0.1, offset, 0.1],
      ];
    case 4:
      return [
        [-0.1, offset, -0.1],
        [0.1, offset, -0.1],
        [-0.1, offset, 0.1],
        [0.1, offset, 0.1],
      ];
    case 5:
      return [
        [-0.1, offset, -0.1],
        [0.1, offset, -0.1],
        [0, offset, 0],
        [-0.1, offset, 0.1],
        [0.1, offset, 0.1],
      ];
    case 6:
      return [
        [-0.1, offset, -0.1],
        [0.1, offset, -0.1],
        [-0.1, offset, 0],
        [0.1, offset, 0],
        [-0.1, offset, 0.1],
        [0.1, offset, 0.1],
      ];
    default:
      return [];
  }
}
