'use client';

import { useEffect, useRef } from 'react';
import Stats from 'stats.js';

export function PerformanceStats() {
  const statsRef = useRef<Stats | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Create FPS monitor
    const stats = new Stats();
    stats.showPanel(0); // 0: fps, 1: ms, 2: mb
    stats.dom.style.position = 'relative';
    
    containerRef.current.appendChild(stats.dom);
    statsRef.current = stats;

    function animate() {
      if (statsRef.current) {
        statsRef.current.begin();
        statsRef.current.end();
      }
      requestAnimationFrame(animate);
    }

    animate();

    return () => {
      if (containerRef.current && stats.dom) {
        containerRef.current.removeChild(stats.dom);
      }
    };
  }, []);

  return (
    <div className="fixed top-20 right-4 bg-black bg-opacity-80 rounded-lg p-3 z-50 border border-gray-600">
      <div className="text-white text-sm font-bold mb-2 text-center">Performance</div>
      <div ref={containerRef} className="flex flex-col" />
      <div className="text-gray-400 text-xs mt-2 text-center">
        FPS Monitor
      </div>
    </div>
  );
}
