'use client';

import type { GameState } from '@/lib/backgammon/types';
import { formatGameStatus } from '@/lib/backgammon/boardRenderer';
import { themes } from '@/lib/backgammon/themes';
import { Backgammon3DScene, PerformanceStats } from './Backgammon3D';

interface BackgammonBoardProps {
  gameState: GameState;
}

export function BackgammonBoard({ gameState }: BackgammonBoardProps) {
  const theme = themes[gameState.theme];
  
  return (
    <>
      <div 
        className="w-full max-w-6xl mx-auto p-6 rounded-lg shadow-2xl"
        style={{ 
          backgroundColor: theme.colors.primary,
          borderColor: theme.colors.accent,
          borderWidth: '2px',
        }}
      >
        <div className="mb-4 text-center">
          <h2 
            className="text-2xl font-bold mb-2"
            style={{ color: theme.colors.secondary }}
          >
            {theme.name}
          </h2>
          <p 
            className="text-sm italic"
            style={{ color: theme.colors.accent }}
          >
            {theme.description}
          </p>
        </div>
        
        {/* 3D Board Visualization */}
        <Backgammon3DScene gameState={gameState} />
        
        {/* Game Status */}
        <div 
          className="mt-4 font-mono text-sm whitespace-pre"
          style={{ color: theme.colors.accent }}
        >
          {formatGameStatus(gameState)}
        </div>
        
        {gameState.winner && (
          <div 
            className="mt-4 p-4 rounded text-center text-xl font-bold animate-pulse"
            style={{ 
              backgroundColor: theme.colors.secondary,
              color: theme.colors.primary,
            }}
          >
            🎉 {gameState.winner.toUpperCase()} WINS! 🎉
          </div>
        )}
      </div>
      
      {/* Performance Stats */}
      <PerformanceStats />
    </>
  );
}
