'use client';

import { useState } from 'react';
import type { GameState, Move, Theme } from '@/lib/backgammon/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { themes } from '@/lib/backgammon/themes';
import { getLegalMoves } from '@/lib/backgammon/moveValidator';
import { formatDice } from '@/lib/backgammon/boardRenderer';

interface GameControlsProps {
  gameState: GameState;
  onStartGame: (mode: 'ai' | 'local', theme: Theme) => void;
  onRollDice: () => void;
  onMakeMove: (move: string) => void;
  onEndTurn: () => void;
  onNewGame: () => void;
  message: string;
}

export function GameControls({
  gameState,
  onStartGame,
  onRollDice,
  onMakeMove,
  onEndTurn,
  onNewGame,
  message,
}: GameControlsProps) {
  const [moveInput, setMoveInput] = useState('');
  const [selectedMode, setSelectedMode] = useState<'ai' | 'local'>('ai');
  const [selectedTheme, setSelectedTheme] = useState<Theme>('biomech');
  
  const theme = themes[gameState.theme];
  const legalMoves = gameState.dice.length > 0 && gameState.availableMoves.length > 0
    ? getLegalMoves(gameState, gameState.currentPlayer)
    : [];
  
  if (!gameState.gameStarted) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="text-3xl text-center">DreamNet Backgammon Arena</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center space-y-4">
            <p className="text-lg">
              Welcome to the arena! Choose your mode and theme to begin.
            </p>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Game Mode</label>
                <Select value={selectedMode} onValueChange={(v: 'ai' | 'local') => setSelectedMode(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ai">vs AI</SelectItem>
                    <SelectItem value="local">2-Player Local</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Board Theme</label>
                <Select value={selectedTheme} onValueChange={(v: Theme) => setSelectedTheme(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="biomech">Biomech Spine Board</SelectItem>
                    <SelectItem value="neon">Neon Glass Grid</SelectItem>
                    <SelectItem value="dna">DreamNet DNA Board</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-sm text-muted-foreground mt-2">
                  {themes[selectedTheme].description}
                </p>
              </div>
              
              <Button 
                onClick={() => onStartGame(selectedMode, selectedTheme)}
                size="lg"
                className="w-full"
              >
                Start Game
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card 
      className="w-full max-w-4xl mx-auto"
      style={{ borderColor: theme.colors.accent }}
    >
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>Game Controls</span>
          <Badge variant="outline">
            {gameState.gameMode === 'ai' ? 'vs AI' : '2-Player'}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {message && (
          <div 
            className="p-3 rounded text-sm"
            style={{ 
              backgroundColor: theme.colors.primary,
              color: theme.colors.secondary,
            }}
          >
            {message}
          </div>
        )}
        
        {gameState.dice.length > 0 && (
          <div className="text-center p-3 bg-muted rounded">
            <p className="font-bold">{formatDice(gameState.dice)}</p>
          </div>
        )}
        
        {!gameState.winner && (
          <>
            {gameState.dice.length === 0 ? (
              <Button 
                onClick={onRollDice}
                className="w-full"
                size="lg"
              >
                🎲 Roll Dice
              </Button>
            ) : (
              <>
                {legalMoves.length > 0 && (
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Legal Moves:</label>
                    <div className="max-h-40 overflow-y-auto space-y-1 p-2 bg-muted rounded">
                      {legalMoves.map((move, idx) => {
                        let moveStr = '';
                        if (move.from === -1) {
                          const pointNum = gameState.currentPlayer === 'white' 
                            ? move.to + 1 
                            : 24 - move.to;
                          moveStr = `bar → ${pointNum}`;
                        } else if (move.to === -2) {
                          const pointNum = gameState.currentPlayer === 'white' 
                            ? move.from + 1 
                            : 24 - move.from;
                          moveStr = `${pointNum} → off`;
                        } else {
                          const fromNum = gameState.currentPlayer === 'white' 
                            ? move.from + 1 
                            : 24 - move.from;
                          const toNum = gameState.currentPlayer === 'white' 
                            ? move.to + 1 
                            : 24 - move.to;
                          moveStr = `${fromNum} → ${toNum}`;
                        }
                        
                        if (move.isHit) moveStr += ' (HIT!)';
                        
                        return (
                          <div key={idx} className="text-xs font-mono">
                            {moveStr}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Make Move:</label>
                  <div className="flex gap-2">
                    <Input
                      value={moveInput}
                      onChange={(e) => setMoveInput(e.target.value)}
                      placeholder="e.g., 13-8 or bar-3 or 6-off"
                      className="flex-1"
                    />
                    <Button 
                      onClick={() => {
                        onMakeMove(moveInput);
                        setMoveInput('');
                      }}
                    >
                      Move
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Formats: "13-8", "bar-3", "6-off"
                  </p>
                </div>
                
                {gameState.availableMoves.length === 0 || legalMoves.length === 0 ? (
                  <Button 
                    onClick={onEndTurn}
                    variant="secondary"
                    className="w-full"
                  >
                    End Turn
                  </Button>
                ) : null}
              </>
            )}
          </>
        )}
        
        {gameState.winner && (
          <Button 
            onClick={onNewGame}
            className="w-full"
            size="lg"
          >
            New Game
          </Button>
        )}
        
        {gameState.gameStarted && !gameState.winner && (
          <Button 
            onClick={onNewGame}
            variant="outline"
            className="w-full"
          >
            Restart Game
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
