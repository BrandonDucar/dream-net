import type { GameState, Move, Player } from './types';
import { getLegalMoves, applyMove } from './moveValidator';
import { cloneGameState, hasWon, canBearOff } from './gameState';

export function selectAIMove(state: GameState): Move | null {
  const legalMoves = getLegalMoves(state, 'black');
  
  if (legalMoves.length === 0) {
    return null;
  }
  
  // Try to find the best sequence of moves for all available dice
  const bestSequence = findBestMoveSequence(state, state.availableMoves);
  
  if (bestSequence.length > 0) {
    return bestSequence[0];
  }
  
  return legalMoves[0];
}

function findBestMoveSequence(state: GameState, availableDice: number[]): Move[] {
  if (availableDice.length === 0) {
    return [];
  }
  
  const legalMoves = getLegalMoves(state, 'black');
  
  if (legalMoves.length === 0) {
    return [];
  }
  
  let bestSequence: Move[] = [];
  let bestScore = -Infinity;
  
  for (const move of legalMoves) {
    const newState = applyMove(state, move);
    const remainingMoves = findBestMoveSequence(newState, newState.availableMoves);
    const fullSequence = [move, ...remainingMoves];
    const score = evaluatePosition(newState) + fullSequence.length * 10;
    
    if (score > bestScore) {
      bestScore = score;
      bestSequence = fullSequence;
    }
  }
  
  return bestSequence;
}

function evaluatePosition(state: GameState): number {
  let score = 0;
  const player: Player = 'black';
  const opponent: Player = 'white';
  
  // Winning is best
  if (hasWon(state, player)) {
    return 10000;
  }
  
  // Progress toward bearing off
  score += state.bornOff[player] * 100;
  score -= state.bornOff[opponent] * 100;
  
  // Checkers on bar are bad
  score -= state.bar[player] * 50;
  score += state.bar[opponent] * 50;
  
  // Evaluate board position
  for (let i = 0; i < 24; i++) {
    const point = state.points[i];
    
    if (point.owner === player) {
      // Prefer moving checkers forward
      const progress = player === 'black' ? (24 - i) : (i + 1);
      score += progress * point.checkers;
      
      // Making points (2+ checkers) is good
      if (point.checkers >= 2) {
        score += 20;
      }
      
      // Blots (single checkers) are vulnerable
      if (point.checkers === 1) {
        score -= 10;
      }
    } else if (point.owner === opponent) {
      // Hitting opponent blots is good
      if (point.checkers === 1) {
        score += 15;
      }
    }
  }
  
  // Bonus for being able to bear off
  if (canBearOff(state, player)) {
    score += 50;
  }
  
  return score;
}

export function getAIMoveDescription(move: Move, player: Player): string {
  if (move.from === -1) {
    const pointNum = player === 'white' ? move.to + 1 : 24 - move.to;
    return `enters from bar to point ${pointNum}${move.isHit ? ' (hit!)' : ''}`;
  }
  
  if (move.to === -2) {
    const pointNum = player === 'white' ? move.from + 1 : 24 - move.from;
    return `bears off from point ${pointNum}`;
  }
  
  const fromNum = player === 'white' ? move.from + 1 : 24 - move.from;
  const toNum = player === 'white' ? move.to + 1 : 24 - move.to;
  
  return `moves ${fromNum} → ${toNum}${move.isHit ? ' (hit!)' : ''}`;
}
