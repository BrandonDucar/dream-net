import type { GameState, Player } from './types';

export function renderBoard(state: GameState): string {
  const { points, bar, bornOff } = state;
  
  let board = '\n';
  
  // DreamNet header
  board += '                    DREAMNET BACKGAMMON ARENA\n';
  board += '     ————————————————————————————————————————————————————————\n\n';
  
  // Top row point numbers (13-24)
  board += '     13   14   15   16   17   18     |     19   20   21   22   23   24\n';
  board += '     ·    ·    ·    ·    ·    ·      |      ·    ·    ·    ·    ·    ·\n';
  
  // Top points (5 rows)
  for (let row = 0; row < 5; row++) {
    board += '    ';
    
    // Points 12-7 (right to left)
    for (let p = 12; p >= 7; p--) {
      const point = points[p];
      const symbol = getCheckerSymbol(point.owner, point.checkers, row);
      board += `  ${symbol}  `;
    }
    
    // Bar (black checkers)
    board += '  |  ';
    const barSymbol = row < bar.black ? '●' : ' ';
    board += ` ${barSymbol}  `;
    board += '|  ';
    
    // Points 18-23 (left to right)
    for (let p = 18; p <= 23; p++) {
      const point = points[p];
      const symbol = getCheckerSymbol(point.owner, point.checkers, row);
      board += `  ${symbol}  `;
    }
    
    // Borne off (black) - right side annotation
    if (row === 0) {
      board += `    BLACK: ${bornOff.black.toString().padStart(2, ' ')}/15`;
    }
    
    board += '\n';
  }
  
  // Middle separator
  board += '\n';
  board += '     ————————————————————————————————————————————————————————\n';
  board += '\n';
  
  // Bottom points (5 rows, reversed)
  for (let row = 4; row >= 0; row--) {
    board += '    ';
    
    // Points 6-1 (right to left)
    for (let p = 6; p >= 1; p--) {
      const point = points[p - 1];
      const symbol = getCheckerSymbol(point.owner, point.checkers, row);
      board += `  ${symbol}  `;
    }
    
    // Bar (white checkers)
    board += '  |  ';
    const barSymbol = row < bar.white ? '○' : ' ';
    board += ` ${barSymbol}  `;
    board += '|  ';
    
    // Points 7-12 (left to right)
    for (let p = 7; p <= 12; p++) {
      const point = points[p - 1];
      const symbol = getCheckerSymbol(point.owner, point.checkers, row);
      board += `  ${symbol}  `;
    }
    
    // Borne off (white) - right side annotation
    if (row === 4) {
      board += `    WHITE: ${bornOff.white.toString().padStart(2, ' ')}/15`;
    }
    
    board += '\n';
  }
  
  // Bottom row point numbers (12-1)
  board += '     ·    ·    ·    ·    ·    ·      |      ·    ·    ·    ·    ·    ·\n';
  board += '     12   11   10    9    8    7     |      6    5    4    3    2    1\n';
  
  // Footer
  board += '\n';
  board += '     ————————————————————————————————————————————————————————\n';
  
  return board;
}

function getCheckerSymbol(owner: Player | null, count: number, row: number): string {
  if (owner === null || count === 0) {
    return ' ';
  }
  
  if (count > row) {
    // Show count if more than 5 checkers and on top row
    if (count > 5 && row === 4) {
      const countStr = count.toString();
      return owner === 'white' ? `○${countStr}` : `●${countStr}`;
    }
    return owner === 'white' ? '○' : '●';
  }
  
  return ' ';
}

export function formatDice(dice: number[]): string {
  if (dice.length === 0) {
    return 'No dice rolled';
  }
  
  const unique = Array.from(new Set(dice));
  
  if (unique.length === 1) {
    return `DOUBLES  :  ${unique[0]}—${unique[0]}  :  ${dice.length} moves available`;
  }
  
  return `ROLL  :  ${unique.join(' — ')}`;
}

export function formatGameStatus(state: GameState): string {
  const { currentPlayer, bar, bornOff, availableMoves } = state;
  
  let status = `\n`;
  status += `     ════════════════════════════════════════════════════════\n\n`;
  status += `     TURN  :  ${currentPlayer.toUpperCase()}\n`;
  
  if (bar.white > 0 || bar.black > 0) {
    status += `     BAR   :  White ${bar.white}  |  Black ${bar.black}\n`;
  }
  
  status += `     HOME  :  White ${bornOff.white}/15  |  Black ${bornOff.black}/15\n`;
  
  if (availableMoves.length > 0) {
    status += `\n     MOVES :  ${availableMoves.join(' · ')}`;
  }
  
  status += `\n\n     ════════════════════════════════════════════════════════\n`;
  
  return status;
}
