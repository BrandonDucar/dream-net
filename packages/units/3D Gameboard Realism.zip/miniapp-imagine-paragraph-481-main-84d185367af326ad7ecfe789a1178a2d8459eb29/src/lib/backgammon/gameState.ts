import type { GameState, Player, Point, Theme } from './types';

export function createInitialGameState(gameMode: 'ai' | 'local', theme: Theme): GameState {
  const points: Point[] = Array(24).fill(null).map(() => ({
    checkers: 0,
    owner: null,
  }));

  // Standard backgammon starting position
  // White moves from 1 to 24, Black moves from 24 to 1
  points[0] = { checkers: 2, owner: 'white' }; // Point 1
  points[11] = { checkers: 5, owner: 'white' }; // Point 12
  points[16] = { checkers: 3, owner: 'white' }; // Point 17
  points[18] = { checkers: 5, owner: 'white' }; // Point 19

  points[23] = { checkers: 2, owner: 'black' }; // Point 24
  points[12] = { checkers: 5, owner: 'black' }; // Point 13
  points[7] = { checkers: 3, owner: 'black' }; // Point 8
  points[5] = { checkers: 5, owner: 'black' }; // Point 6

  return {
    points,
    bar: { white: 0, black: 0 },
    bornOff: { white: 0, black: 0 },
    currentPlayer: 'white',
    dice: [],
    availableMoves: [],
    gameMode,
    theme,
    winner: null,
    matchScore: { white: 0, black: 0 },
    gameStarted: false,
  };
}

export function rollDice(): number[] {
  const die1 = Math.floor(Math.random() * 6) + 1;
  const die2 = Math.floor(Math.random() * 6) + 1;
  
  // If doubles, player gets 4 moves
  if (die1 === die2) {
    return [die1, die1, die1, die1];
  }
  
  return [die1, die2];
}

export function switchPlayer(player: Player): Player {
  return player === 'white' ? 'black' : 'white';
}

export function getPointNumber(player: Player, point: number): number {
  // White: 1-24 (left to right on bottom, right to left on top)
  // Black: 24-1 (opposite direction)
  if (player === 'white') {
    return point + 1;
  } else {
    return 24 - point;
  }
}

export function getPointIndex(player: Player, pointNum: number): number {
  if (player === 'white') {
    return pointNum - 1;
  } else {
    return 24 - pointNum;
  }
}

export function isInHomeBoard(player: Player, pointIndex: number): boolean {
  if (player === 'white') {
    return pointIndex >= 18; // Points 19-24
  } else {
    return pointIndex <= 5; // Points 6-1
  }
}

export function canBearOff(state: GameState, player: Player): boolean {
  const { points, bar } = state;
  
  // Must have no checkers on bar
  if (bar[player] > 0) {
    return false;
  }
  
  // All checkers must be in home board
  for (let i = 0; i < 24; i++) {
    const point = points[i];
    if (point.owner === player) {
      if (!isInHomeBoard(player, i)) {
        return false;
      }
    }
  }
  
  return true;
}

export function hasWon(state: GameState, player: Player): boolean {
  return state.bornOff[player] === 15;
}

export function cloneGameState(state: GameState): GameState {
  return {
    ...state,
    points: state.points.map(p => ({ ...p })),
    bar: { ...state.bar },
    bornOff: { ...state.bornOff },
    dice: [...state.dice],
    availableMoves: [...state.availableMoves],
    matchScore: { ...state.matchScore },
  };
}
