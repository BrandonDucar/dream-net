import type { GameState, Player, Move } from './types';
import { getPointIndex, isInHomeBoard, canBearOff } from './gameState';

export function getLegalMoves(state: GameState, player: Player): Move[] {
  const moves: Move[] = [];
  const { points, bar, dice, availableMoves } = state;
  
  if (availableMoves.length === 0) {
    return [];
  }
  
  // If player has checkers on bar, must enter first
  if (bar[player] > 0) {
    for (const die of availableMoves) {
      const entryPoint = player === 'white' ? die - 1 : 24 - die;
      const targetPoint = points[entryPoint];
      
      if (targetPoint.owner === null || targetPoint.owner === player || targetPoint.checkers === 1) {
        moves.push({
          from: -1, // -1 indicates bar
          to: entryPoint,
          isHit: targetPoint.owner !== null && targetPoint.owner !== player,
        });
      }
    }
    return moves;
  }
  
  const canBear = canBearOff(state, player);
  
  // Check all points for possible moves
  for (let fromIndex = 0; fromIndex < 24; fromIndex++) {
    const fromPoint = points[fromIndex];
    if (fromPoint.owner !== player) continue;
    
    for (const die of availableMoves) {
      const direction = player === 'white' ? 1 : -1;
      const toIndex = fromIndex + (die * direction);
      
      // Check bearing off
      if (canBear && isInHomeBoard(player, fromIndex)) {
        const homeStart = player === 'white' ? 18 : 0;
        const homeEnd = player === 'white' ? 23 : 5;
        
        // Exact bear off
        if ((player === 'white' && toIndex >= 24) || (player === 'black' && toIndex < 0)) {
          moves.push({
            from: fromIndex,
            to: -2, // -2 indicates bear off
            isBearOff: true,
          });
          continue;
        }
        
        // Bear off from lower point if exact die not available
        if ((player === 'white' && toIndex > 24) || (player === 'black' && toIndex < 0)) {
          let isFurthestBack = true;
          const range = player === 'white' ? [fromIndex + 1, homeEnd + 1] : [homeStart, fromIndex];
          
          for (let i = range[0]; i < range[1]; i++) {
            if (points[i].owner === player) {
              isFurthestBack = false;
              break;
            }
          }
          
          if (isFurthestBack) {
            moves.push({
              from: fromIndex,
              to: -2,
              isBearOff: true,
            });
          }
          continue;
        }
      }
      
      // Normal move
      if (toIndex >= 0 && toIndex < 24) {
        const toPoint = points[toIndex];
        
        // Can move to empty, own point, or blot (single opponent checker)
        if (toPoint.owner === null || toPoint.owner === player || toPoint.checkers === 1) {
          moves.push({
            from: fromIndex,
            to: toIndex,
            isHit: toPoint.owner !== null && toPoint.owner !== player,
          });
        }
      }
    }
  }
  
  return moves;
}

export function isMoveLegal(state: GameState, move: Move): boolean {
  const legalMoves = getLegalMoves(state, state.currentPlayer);
  return legalMoves.some(m => m.from === move.from && m.to === move.to);
}

export function applyMove(state: GameState, move: Move): GameState {
  const newState = { ...state };
  newState.points = state.points.map(p => ({ ...p }));
  newState.bar = { ...state.bar };
  newState.bornOff = { ...state.bornOff };
  newState.availableMoves = [...state.availableMoves];
  
  const player = state.currentPlayer;
  const opponent = player === 'white' ? 'black' : 'white';
  
  // Handle bar entry
  if (move.from === -1) {
    newState.bar[player]--;
    const toPoint = newState.points[move.to];
    
    if (move.isHit) {
      newState.bar[opponent]++;
      toPoint.checkers = 1;
      toPoint.owner = player;
    } else {
      if (toPoint.owner === null) {
        toPoint.owner = player;
        toPoint.checkers = 1;
      } else {
        toPoint.checkers++;
      }
    }
    
    // Remove used die
    const die = player === 'white' ? move.to + 1 : 24 - move.to;
    const dieIndex = newState.availableMoves.indexOf(die);
    if (dieIndex !== -1) {
      newState.availableMoves.splice(dieIndex, 1);
    }
    
    return newState;
  }
  
  // Handle bear off
  if (move.to === -2) {
    const fromPoint = newState.points[move.from];
    fromPoint.checkers--;
    if (fromPoint.checkers === 0) {
      fromPoint.owner = null;
    }
    newState.bornOff[player]++;
    
    // Remove used die
    const pointNum = player === 'white' ? move.from + 1 : 24 - move.from;
    const homeStart = player === 'white' ? 19 : 6;
    const die = pointNum - homeStart + 1;
    
    let dieIndex = newState.availableMoves.indexOf(die);
    if (dieIndex === -1) {
      // Use larger die if exact not available
      const largerDice = newState.availableMoves.filter(d => d > die);
      if (largerDice.length > 0) {
        dieIndex = newState.availableMoves.indexOf(Math.min(...largerDice));
      }
    }
    
    if (dieIndex !== -1) {
      newState.availableMoves.splice(dieIndex, 1);
    }
    
    return newState;
  }
  
  // Normal move
  const fromPoint = newState.points[move.from];
  const toPoint = newState.points[move.to];
  
  fromPoint.checkers--;
  if (fromPoint.checkers === 0) {
    fromPoint.owner = null;
  }
  
  if (move.isHit) {
    newState.bar[opponent]++;
    toPoint.checkers = 1;
    toPoint.owner = player;
  } else {
    if (toPoint.owner === null) {
      toPoint.owner = player;
      toPoint.checkers = 1;
    } else {
      toPoint.checkers++;
    }
  }
  
  // Remove used die
  const distance = Math.abs(move.to - move.from);
  const dieIndex = newState.availableMoves.indexOf(distance);
  if (dieIndex !== -1) {
    newState.availableMoves.splice(dieIndex, 1);
  }
  
  return newState;
}

export function parseMove(moveStr: string, player: Player): Move | null {
  // Support formats: "13-8", "13/8", "bar-3", "8-off"
  const normalized = moveStr.toLowerCase().trim();
  
  let from: number;
  let to: number;
  
  if (normalized.startsWith('bar')) {
    from = -1;
    const match = normalized.match(/bar[-\/]\s*(\d+)/);
    if (!match) return null;
    to = getPointIndex(player, parseInt(match[1]));
  } else {
    const match = normalized.match(/(\d+)[-\/]\s*(\d+|off)/);
    if (!match) return null;
    
    from = getPointIndex(player, parseInt(match[1]));
    
    if (match[2] === 'off') {
      to = -2;
    } else {
      to = getPointIndex(player, parseInt(match[2]));
    }
  }
  
  return { from, to };
}
