import type { Theme, ThemeConfig } from './types';

export const themes: Record<Theme, ThemeConfig> = {
  biomech: {
    name: 'Biomech Spine Board',
    description: 'Chrome vertebrae meet neural circuitry. Gritty metallic textures with pulsing red accents.',
    colors: {
      primary: '#1a1a1a',
      secondary: '#dc2626',
      accent: '#71717a',
    },
    boardStyle: 'Metallic biomechanical aesthetics with industrial edge',
  },
  neon: {
    name: 'Neon Glass Grid',
    description: 'Electric blue and magenta light trails on transparent glass. Cyberpunk vibes.',
    colors: {
      primary: '#0c0a1f',
      secondary: '#3b82f6',
      accent: '#ec4899',
    },
    boardStyle: 'Glowing neon grid with holographic transparency',
  },
  dna: {
    name: 'DreamNet DNA Board',
    description: 'Double helix spirals and genetic code patterns. Bioluminescent green on deep purple.',
    colors: {
      primary: '#1e1b4b',
      secondary: '#22c55e',
      accent: '#8b5cf6',
    },
    boardStyle: 'Organic DNA strands with bioluminescent glow',
  },
};
