export type Player = 'white' | 'black';

export type Theme = 'biomech' | 'neon' | 'dna';

export interface Point {
  checkers: number;
  owner: Player | null;
}

export interface GameState {
  points: Point[];
  bar: { white: number; black: number };
  bornOff: { white: number; black: number };
  currentPlayer: Player;
  dice: number[];
  availableMoves: number[];
  gameMode: 'ai' | 'local';
  theme: Theme;
  winner: Player | null;
  matchScore: { white: number; black: number };
  gameStarted: boolean;
}

export interface Move {
  from: number;
  to: number;
  isHit?: boolean;
  isBearOff?: boolean;
}

export interface ThemeConfig {
  name: string;
  description: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
  };
  boardStyle: string;
}
