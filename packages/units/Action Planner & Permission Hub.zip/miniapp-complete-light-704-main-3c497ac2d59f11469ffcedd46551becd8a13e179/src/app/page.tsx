'use client'
import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ActorsOverview } from "@/components/actors-overview";
import { ActionTypesOverview } from "@/components/action-types-overview";
import { ActionTemplatesOverview } from "@/components/action-templates-overview";
import { ActionQueue } from "@/components/action-queue";
import { Brain, Users, Workflow, FileText, ListChecks } from "lucide-react";
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DreamNetPage(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [activeTab, setActiveTab] = useState<string>("overview");

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-8 px-4 max-w-7xl">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Brain className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold">DreamNet Action Router & Permission Brain</h1>
          </div>
          <p className="text-muted-foreground">
            Define actors, action types, templates, and manage your action queue with approval workflows
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid grid-cols-5 w-full">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Brain className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="actors" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Actors
            </TabsTrigger>
            <TabsTrigger value="action-types" className="flex items-center gap-2">
              <Workflow className="h-4 w-4" />
              Action Types
            </TabsTrigger>
            <TabsTrigger value="templates" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Templates
            </TabsTrigger>
            <TabsTrigger value="queue" className="flex items-center gap-2">
              <ListChecks className="h-4 w-4" />
              Action Queue
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Welcome to DreamNet</CardTitle>
                <CardDescription>
                  Your control board for managing actors, action types, templates, and action planning
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <div className="flex items-center gap-2">
                        <Users className="h-5 w-5 text-blue-500" />
                        <CardTitle className="text-base">Actors</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">
                        Register and manage actors (humans, bots, mini-apps) with their risk profiles, roles, and permissions
                      </p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <div className="flex items-center gap-2">
                        <Workflow className="h-5 w-5 text-green-500" />
                        <CardTitle className="text-base">Action Types</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">
                        Define action types with risk levels, approval requirements, and default channels
                      </p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <div className="flex items-center gap-2">
                        <FileText className="h-5 w-5 text-purple-500" />
                        <CardTitle className="text-base">Templates</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">
                        Create reusable templates with SEO metadata and geo-targeting for consistent action planning
                      </p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <div className="flex items-center gap-2">
                        <ListChecks className="h-5 w-5 text-orange-500" />
                        <CardTitle className="text-base">Action Queue</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">
                        Plan, approve, and track actions with detailed status, risk management, and execution logs
                      </p>
                    </CardContent>
                  </Card>
                </div>

                <Card className="bg-muted/50">
                  <CardHeader>
                    <CardTitle className="text-base">How It Works</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div className="flex items-start gap-2">
                      <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-xs font-bold">
                        1
                      </div>
                      <p>
                        <strong>Register Actors</strong> - Define who/what can perform actions (humans, bots, mini-apps)
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-xs font-bold">
                        2
                      </div>
                      <p>
                        <strong>Create Action Types</strong> - Define what actions can be performed and their risk levels
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-xs font-bold">
                        3
                      </div>
                      <p>
                        <strong>Build Templates</strong> - Create reusable templates with SEO and geo-targeting (optional)
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-xs font-bold">
                        4
                      </div>
                      <p>
                        <strong>Plan Actions</strong> - Queue actions for approval and execution with full tracking
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-xs font-bold">
                        5
                      </div>
                      <p>
                        <strong>Export & Execute</strong> - Use the action queue as a source of truth for execution
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="actors">
            <div className="grid grid-cols-1 gap-6">
              <ActorsOverview />
              <ActionTypesOverview />
            </div>
          </TabsContent>

          <TabsContent value="action-types">
            <ActionTypesOverview />
          </TabsContent>

          <TabsContent value="templates">
            <ActionTemplatesOverview />
          </TabsContent>

          <TabsContent value="queue">
            <ActionQueue />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
