"use client";

import { useState, useEffect } from "react";
import type { PlannedAction } from "@/types/dreamnet";
import { getActionDetails, approveAction, rejectAction, markActionExecuted, markActionFailed } from "@/lib/dreamnet-core";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { format } from "date-fns";
import { getActors } from "@/lib/storage";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ActionDetailDialogProps {
  open: boolean;
  onClose: () => void;
  action: PlannedAction | null;
}

export function ActionDetailDialog({ open, onClose, action }: ActionDetailDialogProps): JSX.Element {
  const [details, setDetails] = useState<ReturnType<typeof getActionDetails> | null>(null);
  const [approvalNotes, setApprovalNotes] = useState<string>("");
  const [executionLog, setExecutionLog] = useState<string>("");
  const [selectedApproverId, setSelectedApproverId] = useState<string>("");

  useEffect(() => {
    if (action) {
      const actionDetails = getActionDetails(action.id);
      setDetails(actionDetails);
      setApprovalNotes("");
      setExecutionLog("");
      
      const actors = getActors();
      if (actors.length > 0) {
        setSelectedApproverId(actors[0].id);
      }
    }
  }, [action, open]);

  function handleApprove(): void {
    if (!action || !selectedApproverId) {
      return;
    }

    const result = approveAction(action.id, selectedApproverId, approvalNotes);
    if (result) {
      toast.success("Action approved");
      onClose();
    } else {
      toast.error("Failed to approve action");
    }
  }

  function handleReject(): void {
    if (!action || !selectedApproverId) {
      return;
    }

    const result = rejectAction(action.id, selectedApproverId, approvalNotes);
    if (result) {
      toast.success("Action rejected");
      onClose();
    } else {
      toast.error("Failed to reject action");
    }
  }

  function handleMarkExecuted(): void {
    if (!action) {
      return;
    }

    const result = markActionExecuted(action.id, executionLog);
    if (result) {
      toast.success("Action marked as executed");
      onClose();
    } else {
      toast.error("Failed to mark action as executed");
    }
  }

  function handleMarkFailed(): void {
    if (!action) {
      return;
    }

    const result = markActionFailed(action.id, executionLog);
    if (result) {
      toast.success("Action marked as failed");
      onClose();
    } else {
      toast.error("Failed to mark action as failed");
    }
  }

  function handleCopyPayload(): void {
    if (!action) {
      return;
    }
    
    const copyText = `Payload Summary:\n${action.payloadSummary}\n\nPayload Raw:\n${action.payloadRaw}\n\nExternal Refs:\n${JSON.stringify(action.externalRefs, null, 2)}`;
    navigator.clipboard.writeText(copyText);
    toast.success("Payload copied to clipboard");
  }

  if (!action || !details) {
    return <></>;
  }

  const actors = getActors();
  const canApprove = action.requiresManualApproval && action.approvalStatus === "pending";
  const canExecute = action.executionStatus === "not-started" || action.executionStatus === "in-progress";

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Action Details</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Basic Info */}
          <div className="space-y-3">
            <div>
              <Label className="text-muted-foreground">Action Type</Label>
              <p className="font-medium">{details.actionType?.name || "Unknown"}</p>
            </div>

            {details.template && (
              <div>
                <Label className="text-muted-foreground">Template</Label>
                <p className="font-medium">{details.template.name}</p>
              </div>
            )}

            <div>
              <Label className="text-muted-foreground">Summary</Label>
              <p className="font-medium">{action.payloadSummary || "No summary"}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-muted-foreground">Channel</Label>
                <p className="font-medium">{action.channel}</p>
              </div>

              <div>
                <Label className="text-muted-foreground">Risk Level</Label>
                <Badge variant={action.riskLevel === "high" ? "destructive" : "default"}>
                  {action.riskLevel}
                </Badge>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-muted-foreground">Requested By</Label>
                <p className="font-medium">{details.requestedBy?.name || "Unknown"}</p>
              </div>

              {details.targetActor && (
                <div>
                  <Label className="text-muted-foreground">Target Actor</Label>
                  <p className="font-medium">{details.targetActor.name}</p>
                </div>
              )}
            </div>
          </div>

          <Separator />

          {/* Payload */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-lg font-semibold">Payload</Label>
              <Button variant="outline" size="sm" onClick={handleCopyPayload}>
                Copy Payload
              </Button>
            </div>

            {action.payloadRaw && (
              <div>
                <Label className="text-muted-foreground">Raw Payload</Label>
                <pre className="mt-1 p-3 bg-muted rounded-md text-sm overflow-x-auto">
                  {action.payloadRaw}
                </pre>
              </div>
            )}

            {Object.keys(action.externalRefs).length > 0 && (
              <div>
                <Label className="text-muted-foreground">External References</Label>
                <pre className="mt-1 p-3 bg-muted rounded-md text-sm overflow-x-auto">
                  {JSON.stringify(action.externalRefs, null, 2)}
                </pre>
              </div>
            )}
          </div>

          <Separator />

          {/* Status */}
          <div className="space-y-3">
            <Label className="text-lg font-semibold">Status</Label>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-muted-foreground">Approval Status</Label>
                <div className="mt-1">
                  <Badge>{action.approvalStatus}</Badge>
                </div>
              </div>

              <div>
                <Label className="text-muted-foreground">Execution Status</Label>
                <div className="mt-1">
                  <Badge>{action.executionStatus}</Badge>
                </div>
              </div>
            </div>

            {action.approvalNotes && (
              <div>
                <Label className="text-muted-foreground">Approval Notes</Label>
                <p className="mt-1 text-sm">{action.approvalNotes}</p>
              </div>
            )}

            {action.executionLog && (
              <div>
                <Label className="text-muted-foreground">Execution Log</Label>
                <pre className="mt-1 p-3 bg-muted rounded-md text-sm overflow-x-auto">
                  {action.executionLog}
                </pre>
              </div>
            )}

            <div className="grid grid-cols-3 gap-4 text-sm">
              <div>
                <Label className="text-muted-foreground">Created</Label>
                <p>{format(new Date(action.createdAt), "MMM d, yyyy HH:mm")}</p>
              </div>

              {action.scheduledAt && (
                <div>
                  <Label className="text-muted-foreground">Scheduled</Label>
                  <p>{format(new Date(action.scheduledAt), "MMM d, yyyy HH:mm")}</p>
                </div>
              )}

              {action.executedAt && (
                <div>
                  <Label className="text-muted-foreground">Executed</Label>
                  <p>{format(new Date(action.executedAt), "MMM d, yyyy HH:mm")}</p>
                </div>
              )}
            </div>
          </div>

          <Separator />

          {/* Actions */}
          {canApprove && (
            <div className="space-y-3">
              <Label className="text-lg font-semibold">Approval</Label>
              
              <div className="space-y-2">
                <Label htmlFor="approver">Approver</Label>
                <Select value={selectedApproverId} onValueChange={setSelectedApproverId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select approver" />
                  </SelectTrigger>
                  <SelectContent>
                    {actors.map((actor) => (
                      <SelectItem key={actor.id} value={actor.id}>
                        {actor.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="approvalNotes">Notes</Label>
                <Textarea
                  id="approvalNotes"
                  value={approvalNotes}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                    setApprovalNotes(e.target.value)
                  }
                  placeholder="Optional approval/rejection notes"
                  rows={3}
                />
              </div>

              <div className="flex gap-2">
                <Button onClick={handleApprove} className="flex-1">
                  Approve
                </Button>
                <Button onClick={handleReject} variant="destructive" className="flex-1">
                  Reject
                </Button>
              </div>
            </div>
          )}

          {canExecute && (
            <div className="space-y-3">
              <Label className="text-lg font-semibold">Execution</Label>

              <div className="space-y-2">
                <Label htmlFor="executionLog">Execution Log</Label>
                <Textarea
                  id="executionLog"
                  value={executionLog}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                    setExecutionLog(e.target.value)
                  }
                  placeholder="e.g., Cast URL, transaction hash, error message"
                  rows={3}
                />
              </div>

              <div className="flex gap-2">
                <Button onClick={handleMarkExecuted} className="flex-1">
                  Mark as Executed
                </Button>
                <Button onClick={handleMarkFailed} variant="destructive" className="flex-1">
                  Mark as Failed
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
