"use client";

import { useState, useEffect } from "react";
import type {
  PlannedAction,
  PlannedActionFilters,
  ApprovalStatus,
  ExecutionStatus,
  RiskLevel,
} from "@/types/dreamnet";
import { listPlannedActions, exportActionQueueBrief } from "@/lib/dreamnet-core";
import { getActionTypeById, getActorById } from "@/lib/storage";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ActionDetailDialog } from "./action-detail-dialog";
import { PlanActionDialog } from "./plan-action-dialog";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { format } from "date-fns";

export function ActionQueue(): JSX.Element {
  const [actions, setActions] = useState<PlannedAction[]>([]);
  const [filters, setFilters] = useState<PlannedActionFilters>({});
  const [selectedAction, setSelectedAction] = useState<PlannedAction | null>(null);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState<boolean>(false);
  const [isPlanDialogOpen, setIsPlanDialogOpen] = useState<boolean>(false);
  const [isExportDialogOpen, setIsExportDialogOpen] = useState<boolean>(false);
  const [exportText, setExportText] = useState<string>("");

  useEffect(() => {
    loadActions();
  }, [filters]);

  function loadActions(): void {
    const filtered = listPlannedActions(filters);
    setActions(filtered.sort((a: PlannedAction, b: PlannedAction) => {
      const dateA = new Date(a.createdAt).getTime();
      const dateB = new Date(b.createdAt).getTime();
      return dateB - dateA;
    }));
  }

  function handleViewAction(action: PlannedAction): void {
    setSelectedAction(action);
    setIsDetailDialogOpen(true);
  }

  function handlePlanAction(): void {
    setIsPlanDialogOpen(true);
  }

  function handleDialogClose(): void {
    setIsDetailDialogOpen(false);
    setIsPlanDialogOpen(false);
    setSelectedAction(null);
    loadActions();
  }

  function handleExport(): void {
    const brief = exportActionQueueBrief();
    setExportText(brief);
    setIsExportDialogOpen(true);
  }

  function handleCopyExport(): void {
    navigator.clipboard.writeText(exportText);
    toast.success("Copied to clipboard");
  }

  function getRiskBadgeVariant(risk: RiskLevel): "default" | "secondary" | "destructive" {
    const variants: Record<RiskLevel, "default" | "secondary" | "destructive"> = {
      low: "default",
      medium: "secondary",
      high: "destructive",
    };
    return variants[risk];
  }

  function getApprovalBadgeVariant(status: ApprovalStatus): "default" | "secondary" | "destructive" | "outline" {
    const variants: Record<ApprovalStatus, "default" | "secondary" | "destructive" | "outline"> = {
      pending: "secondary",
      approved: "default",
      rejected: "destructive",
      skipped: "outline",
    };
    return variants[status];
  }

  function getExecutionBadgeVariant(status: ExecutionStatus): "default" | "secondary" | "destructive" | "outline" {
    const variants: Record<ExecutionStatus, "default" | "secondary" | "destructive" | "outline"> = {
      "not-started": "outline",
      "in-progress": "secondary",
      executed: "default",
      failed: "destructive",
      cancelled: "outline",
    };
    return variants[status];
  }

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Action Queue</CardTitle>
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleExport}>
                Export Brief
              </Button>
              <Button onClick={handlePlanAction}>Plan Action</Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex flex-wrap gap-2">
            <Select
              value={filters.approvalStatus || "all"}
              onValueChange={(value: string) =>
                setFilters({
                  ...filters,
                  approvalStatus: value === "all" ? undefined : (value as ApprovalStatus),
                })
              }
            >
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Approval status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Approval Statuses</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="skipped">Skipped</SelectItem>
              </SelectContent>
            </Select>

            <Select
              value={filters.executionStatus || "all"}
              onValueChange={(value: string) =>
                setFilters({
                  ...filters,
                  executionStatus: value === "all" ? undefined : (value as ExecutionStatus),
                })
              }
            >
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Execution status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Execution Statuses</SelectItem>
                <SelectItem value="not-started">Not Started</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
                <SelectItem value="executed">Executed</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>

            <Select
              value={filters.riskLevel || "all"}
              onValueChange={(value: string) =>
                setFilters({
                  ...filters,
                  riskLevel: value === "all" ? undefined : (value as RiskLevel),
                })
              }
            >
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Risk level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Risk Levels</SelectItem>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Summary</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Channel</TableHead>
                  <TableHead>Requested By</TableHead>
                  <TableHead>Risk</TableHead>
                  <TableHead>Approval</TableHead>
                  <TableHead>Execution</TableHead>
                  <TableHead>Scheduled</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {actions.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center text-muted-foreground">
                      No actions in queue
                    </TableCell>
                  </TableRow>
                ) : (
                  actions.map((action: PlannedAction) => {
                    const actionType = getActionTypeById(action.actionTypeId);
                    const requestedBy = getActorById(action.requestedByActorId);

                    return (
                      <TableRow key={action.id}>
                        <TableCell className="max-w-xs truncate font-medium">
                          {action.payloadSummary || "No summary"}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{actionType?.name || "Unknown"}</Badge>
                        </TableCell>
                        <TableCell>{action.channel}</TableCell>
                        <TableCell>{requestedBy?.name || "Unknown"}</TableCell>
                        <TableCell>
                          <Badge variant={getRiskBadgeVariant(action.riskLevel)}>
                            {action.riskLevel}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={getApprovalBadgeVariant(action.approvalStatus)}>
                            {action.approvalStatus}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={getExecutionBadgeVariant(action.executionStatus)}>
                            {action.executionStatus}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {action.scheduledAt
                            ? format(new Date(action.scheduledAt), "MMM d, yyyy")
                            : "-"}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewAction(action)}
                          >
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <ActionDetailDialog
        open={isDetailDialogOpen}
        onClose={handleDialogClose}
        action={selectedAction}
      />

      <PlanActionDialog open={isPlanDialogOpen} onClose={handleDialogClose} />

      <Dialog open={isExportDialogOpen} onOpenChange={setIsExportDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Action Queue Brief Export</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              value={exportText}
              readOnly
              className="font-mono text-sm h-[500px]"
            />
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsExportDialogOpen(false)}>
                Close
              </Button>
              <Button onClick={handleCopyExport}>Copy to Clipboard</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
