"use client";

import { useState, useEffect } from "react";
import type { ActionTemplate, GeoTarget, RiskLevel } from "@/types/dreamnet";
import {
  createActionTemplate,
  updateActionTemplate,
  assignGeoTargetsToTemplate,
  generateGeoVariantsForTemplate,
} from "@/lib/dreamnet-core";
import { getActionTypes } from "@/lib/storage";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";

interface ActionTemplateDialogProps {
  open: boolean;
  onClose: () => void;
  template: ActionTemplate | null;
  isCreating: boolean;
}

export function ActionTemplateDialog({
  open,
  onClose,
  template,
  isCreating,
}: ActionTemplateDialogProps): JSX.Element {
  const [formData, setFormData] = useState<{
    name: string;
    actionTypeId: string;
    description: string;
    parametersSchema: string;
    defaultPayloadExample: string;
    defaultChannel: string;
    defaultRiskOverride: string;
    notes: string;
    seoTitle: string;
    seoDescription: string;
    seoKeywords: string;
    seoHashtags: string;
    altText: string;
  }>({
    name: "",
    actionTypeId: "",
    description: "",
    parametersSchema: "",
    defaultPayloadExample: "",
    defaultChannel: "",
    defaultRiskOverride: "inherit",
    notes: "",
    seoTitle: "",
    seoDescription: "",
    seoKeywords: "",
    seoHashtags: "",
    altText: "",
  });

  const [geoTargets, setGeoTargets] = useState<GeoTarget[]>([]);
  const [newGeoTarget, setNewGeoTarget] = useState<GeoTarget>({
    id: "",
    region: "",
    country: "",
    cityOrMarket: "",
    language: "",
  });

  const actionTypes = getActionTypes();

  useEffect(() => {
    if (template) {
      setFormData({
        name: template.name,
        actionTypeId: template.actionTypeId,
        description: template.description,
        parametersSchema: template.parametersSchema,
        defaultPayloadExample: template.defaultPayloadExample,
        defaultChannel: template.defaultChannel || "",
        defaultRiskOverride: template.defaultRiskOverride,
        notes: template.notes,
        seoTitle: template.seoTitle,
        seoDescription: template.seoDescription,
        seoKeywords: template.seoKeywords.join(", "),
        seoHashtags: template.seoHashtags.join(", "),
        altText: template.altText,
      });
      setGeoTargets(template.primaryGeoTargets);
    } else {
      setFormData({
        name: "",
        actionTypeId: actionTypes.length > 0 ? actionTypes[0].id : "",
        description: "",
        parametersSchema: "",
        defaultPayloadExample: "",
        defaultChannel: "",
        defaultRiskOverride: "inherit",
        notes: "",
        seoTitle: "",
        seoDescription: "",
        seoKeywords: "",
        seoHashtags: "",
        altText: "",
      });
      setGeoTargets([]);
    }
  }, [template, open, actionTypes]);

  function handleSubmit(e: React.FormEvent<HTMLFormElement>): void {
    e.preventDefault();

    if (!formData.name || !formData.actionTypeId) {
      toast.error("Name and action type are required");
      return;
    }

    try {
      if (isCreating) {
        const newTemplate = createActionTemplate({
          name: formData.name,
          actionTypeId: formData.actionTypeId,
          description: formData.description,
          parametersSchema: formData.parametersSchema,
          defaultPayloadExample: formData.defaultPayloadExample,
          defaultChannel: formData.defaultChannel || null,
          defaultRiskOverride: formData.defaultRiskOverride as "inherit" | RiskLevel,
        });

        if (newTemplate && geoTargets.length > 0) {
          assignGeoTargetsToTemplate(newTemplate.id, geoTargets);
          generateGeoVariantsForTemplate(newTemplate.id);
        }

        toast.success("Template created successfully");
      } else if (template) {
        updateActionTemplate(template.id, {
          name: formData.name,
          actionTypeId: formData.actionTypeId,
          description: formData.description,
          parametersSchema: formData.parametersSchema,
          defaultPayloadExample: formData.defaultPayloadExample,
          defaultChannel: formData.defaultChannel || null,
          defaultRiskOverride: formData.defaultRiskOverride as "inherit" | RiskLevel,
          notes: formData.notes,
          seoTitle: formData.seoTitle,
          seoDescription: formData.seoDescription,
          seoKeywords: formData.seoKeywords
            .split(",")
            .map((s: string) => s.trim())
            .filter((s: string) => s !== ""),
          seoHashtags: formData.seoHashtags
            .split(",")
            .map((s: string) => s.trim())
            .filter((s: string) => s !== ""),
          altText: formData.altText,
        });

        assignGeoTargetsToTemplate(template.id, geoTargets);
        if (geoTargets.length > 0) {
          generateGeoVariantsForTemplate(template.id);
        }

        toast.success("Template updated successfully");
      }
      onClose();
    } catch (error) {
      toast.error("Failed to save template");
      console.error(error);
    }
  }

  function handleAddGeoTarget(): void {
    if (!newGeoTarget.id || !newGeoTarget.region || !newGeoTarget.language) {
      toast.error("Geo target ID, region, and language are required");
      return;
    }

    setGeoTargets([...geoTargets, { ...newGeoTarget }]);
    setNewGeoTarget({
      id: "",
      region: "",
      country: "",
      cityOrMarket: "",
      language: "",
    });
  }

  function handleRemoveGeoTarget(id: string): void {
    setGeoTargets(geoTargets.filter((gt: GeoTarget) => gt.id !== id));
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isCreating ? "Create Action Template" : "Edit Action Template"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                placeholder="e.g., Standard Drop Announcement"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="actionTypeId">Action Type *</Label>
              <Select
                value={formData.actionTypeId}
                onValueChange={(value: string) =>
                  setFormData({ ...formData, actionTypeId: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select action type" />
                </SelectTrigger>
                <SelectContent>
                  {actionTypes.map((type) => (
                    <SelectItem key={type.id} value={type.id}>
                      {type.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, description: e.target.value })
              }
              placeholder="Description of this template"
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="parametersSchema">Parameters Schema</Label>
            <Textarea
              id="parametersSchema"
              value={formData.parametersSchema}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, parametersSchema: e.target.value })
              }
              placeholder="e.g., {dropId, scriptId, accountId, scheduleTime}"
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="defaultPayloadExample">Default Payload Example</Label>
            <Textarea
              id="defaultPayloadExample"
              value={formData.defaultPayloadExample}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, defaultPayloadExample: e.target.value })
              }
              placeholder="Example JSON or pseudo-JSON"
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="defaultChannel">Default Channel</Label>
              <Input
                id="defaultChannel"
                value={formData.defaultChannel}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setFormData({ ...formData, defaultChannel: e.target.value })
                }
                placeholder="e.g., farcaster, x, zora"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="defaultRiskOverride">Risk Override</Label>
              <Select
                value={formData.defaultRiskOverride}
                onValueChange={(value: string) =>
                  setFormData({ ...formData, defaultRiskOverride: value })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="inherit">Inherit</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, notes: e.target.value })
              }
              placeholder="Additional notes"
              rows={2}
            />
          </div>

          {!isCreating && (
            <>
              <Separator className="my-4" />
              <h3 className="text-lg font-semibold">SEO Metadata</h3>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="seoTitle">SEO Title</Label>
                  <Input
                    id="seoTitle"
                    value={formData.seoTitle}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      setFormData({ ...formData, seoTitle: e.target.value })
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="altText">Alt Text</Label>
                  <Input
                    id="altText"
                    value={formData.altText}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      setFormData({ ...formData, altText: e.target.value })
                    }
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="seoDescription">SEO Description</Label>
                <Textarea
                  id="seoDescription"
                  value={formData.seoDescription}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                    setFormData({ ...formData, seoDescription: e.target.value })
                  }
                  rows={2}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="seoKeywords">SEO Keywords (comma-separated)</Label>
                  <Input
                    id="seoKeywords"
                    value={formData.seoKeywords}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      setFormData({ ...formData, seoKeywords: e.target.value })
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="seoHashtags">SEO Hashtags (comma-separated)</Label>
                  <Input
                    id="seoHashtags"
                    value={formData.seoHashtags}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      setFormData({ ...formData, seoHashtags: e.target.value })
                    }
                  />
                </div>
              </div>
            </>
          )}

          <Separator className="my-4" />
          <h3 className="text-lg font-semibold">Geo Targeting</h3>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Add Geo Target</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-5 gap-2">
                <Input
                  placeholder="ID (e.g., us-en)"
                  value={newGeoTarget.id}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setNewGeoTarget({ ...newGeoTarget, id: e.target.value })
                  }
                />
                <Input
                  placeholder="Region (e.g., US)"
                  value={newGeoTarget.region}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setNewGeoTarget({ ...newGeoTarget, region: e.target.value })
                  }
                />
                <Input
                  placeholder="Country"
                  value={newGeoTarget.country}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setNewGeoTarget({ ...newGeoTarget, country: e.target.value })
                  }
                />
                <Input
                  placeholder="City/Market"
                  value={newGeoTarget.cityOrMarket}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setNewGeoTarget({ ...newGeoTarget, cityOrMarket: e.target.value })
                  }
                />
                <Input
                  placeholder="Language (e.g., en)"
                  value={newGeoTarget.language}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setNewGeoTarget({ ...newGeoTarget, language: e.target.value })
                  }
                />
              </div>
              <Button type="button" onClick={handleAddGeoTarget} size="sm">
                Add Geo Target
              </Button>
            </CardContent>
          </Card>

          {geoTargets.length > 0 && (
            <div className="space-y-2">
              <Label>Current Geo Targets</Label>
              <div className="space-y-2">
                {geoTargets.map((gt: GeoTarget) => (
                  <Card key={gt.id}>
                    <CardContent className="p-3 flex items-center justify-between">
                      <div className="text-sm">
                        <strong>{gt.id}</strong> - {gt.region}, {gt.country}, {gt.cityOrMarket} ({gt.language})
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveGeoTarget(gt.id)}
                      >
                        Remove
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">{isCreating ? "Create" : "Save Changes"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
