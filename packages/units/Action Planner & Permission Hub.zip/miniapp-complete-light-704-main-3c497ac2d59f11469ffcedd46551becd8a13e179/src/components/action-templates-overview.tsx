"use client";

import { useState, useEffect } from "react";
import type { ActionTemplate } from "@/types/dreamnet";
import { getActionTemplates, getActionTypeById } from "@/lib/storage";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ActionTemplateDialog } from "./action-template-dialog";

export function ActionTemplatesOverview(): JSX.Element {
  const [templates, setTemplates] = useState<ActionTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<ActionTemplate | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);
  const [isCreating, setIsCreating] = useState<boolean>(false);

  useEffect(() => {
    loadTemplates();
  }, []);

  function loadTemplates(): void {
    const allTemplates = getActionTemplates();
    setTemplates(allTemplates);
  }

  function handleCreateTemplate(): void {
    setSelectedTemplate(null);
    setIsCreating(true);
    setIsDialogOpen(true);
  }

  function handleEditTemplate(template: ActionTemplate): void {
    setSelectedTemplate(template);
    setIsCreating(false);
    setIsDialogOpen(true);
  }

  function handleDialogClose(): void {
    setIsDialogOpen(false);
    setSelectedTemplate(null);
    setIsCreating(false);
    loadTemplates();
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Action Templates</CardTitle>
          <Button onClick={handleCreateTemplate}>Create Template</Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Action Type</TableHead>
                <TableHead>Default Channel</TableHead>
                <TableHead>Risk Override</TableHead>
                <TableHead>Geo Targets</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {templates.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground">
                    No templates found
                  </TableCell>
                </TableRow>
              ) : (
                templates.map((template: ActionTemplate) => {
                  const actionType = getActionTypeById(template.actionTypeId);

                  return (
                    <TableRow key={template.id}>
                      <TableCell className="font-medium">{template.name}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{actionType?.name || "Unknown"}</Badge>
                      </TableCell>
                      <TableCell>{template.defaultChannel || "-"}</TableCell>
                      <TableCell>
                        <Badge variant={template.defaultRiskOverride === "inherit" ? "outline" : "secondary"}>
                          {template.defaultRiskOverride}
                        </Badge>
                      </TableCell>
                      <TableCell>{template.primaryGeoTargets.length}</TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditTemplate(template)}
                        >
                          View/Edit
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>

      <ActionTemplateDialog
        open={isDialogOpen}
        onClose={handleDialogClose}
        template={selectedTemplate}
        isCreating={isCreating}
      />
    </Card>
  );
}
