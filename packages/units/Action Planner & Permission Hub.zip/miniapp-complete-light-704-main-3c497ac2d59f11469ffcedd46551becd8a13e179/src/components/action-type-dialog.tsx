"use client";

import { useState, useEffect } from "react";
import type { ActionType, RiskLevel, ActionTypeStatus } from "@/types/dreamnet";
import { createActionType, updateActionType } from "@/lib/dreamnet-core";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";

interface ActionTypeDialogProps {
  open: boolean;
  onClose: () => void;
  actionType: ActionType | null;
  isCreating: boolean;
}

export function ActionTypeDialog({
  open,
  onClose,
  actionType,
  isCreating,
}: ActionTypeDialogProps): JSX.Element {
  const [formData, setFormData] = useState<{
    name: string;
    code: string;
    description: string;
    defaultRiskLevel: RiskLevel;
    requiresManualApproval: boolean;
    defaultChannels: string;
    allowedActors: string;
    tags: string;
    status: ActionTypeStatus;
    seoTitle: string;
    seoDescription: string;
    seoKeywords: string;
    seoHashtags: string;
    altText: string;
  }>({
    name: "",
    code: "",
    description: "",
    defaultRiskLevel: "medium",
    requiresManualApproval: false,
    defaultChannels: "",
    allowedActors: "",
    tags: "",
    status: "active",
    seoTitle: "",
    seoDescription: "",
    seoKeywords: "",
    seoHashtags: "",
    altText: "",
  });

  useEffect(() => {
    if (actionType) {
      setFormData({
        name: actionType.name,
        code: actionType.code,
        description: actionType.description,
        defaultRiskLevel: actionType.defaultRiskLevel,
        requiresManualApproval: actionType.requiresManualApproval,
        defaultChannels: actionType.defaultChannels.join(", "),
        allowedActors: actionType.allowedActors.join(", "),
        tags: actionType.tags.join(", "),
        status: actionType.status,
        seoTitle: actionType.seoTitle,
        seoDescription: actionType.seoDescription,
        seoKeywords: actionType.seoKeywords.join(", "),
        seoHashtags: actionType.seoHashtags.join(", "),
        altText: actionType.altText,
      });
    } else {
      setFormData({
        name: "",
        code: "",
        description: "",
        defaultRiskLevel: "medium",
        requiresManualApproval: false,
        defaultChannels: "",
        allowedActors: "",
        tags: "",
        status: "active",
        seoTitle: "",
        seoDescription: "",
        seoKeywords: "",
        seoHashtags: "",
        altText: "",
      });
    }
  }, [actionType, open]);

  function handleSubmit(e: React.FormEvent<HTMLFormElement>): void {
    e.preventDefault();

    if (!formData.name || !formData.code) {
      toast.error("Name and code are required");
      return;
    }

    try {
      if (isCreating) {
        createActionType({
          name: formData.name,
          code: formData.code,
          description: formData.description,
          defaultRiskLevel: formData.defaultRiskLevel,
          requiresManualApproval: formData.requiresManualApproval,
          defaultChannels: formData.defaultChannels
            .split(",")
            .map((s: string) => s.trim())
            .filter((s: string) => s !== ""),
        });
        toast.success("Action type created successfully");
      } else if (actionType) {
        updateActionType(actionType.id, {
          name: formData.name,
          code: formData.code,
          description: formData.description,
          defaultRiskLevel: formData.defaultRiskLevel,
          requiresManualApproval: formData.requiresManualApproval,
          defaultChannels: formData.defaultChannels
            .split(",")
            .map((s: string) => s.trim())
            .filter((s: string) => s !== ""),
          allowedActors: formData.allowedActors
            .split(",")
            .map((s: string) => s.trim())
            .filter((s: string) => s !== ""),
          tags: formData.tags
            .split(",")
            .map((s: string) => s.trim())
            .filter((s: string) => s !== ""),
          status: formData.status,
          seoTitle: formData.seoTitle,
          seoDescription: formData.seoDescription,
          seoKeywords: formData.seoKeywords
            .split(",")
            .map((s: string) => s.trim())
            .filter((s: string) => s !== ""),
          seoHashtags: formData.seoHashtags
            .split(",")
            .map((s: string) => s.trim())
            .filter((s: string) => s !== ""),
          altText: formData.altText,
        });
        toast.success("Action type updated successfully");
      }
      onClose();
    } catch (error) {
      toast.error("Failed to save action type");
      console.error(error);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isCreating ? "Create Action Type" : "Edit Action Type"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                placeholder="e.g., Post Farcaster Cast"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="code">Code *</Label>
              <Input
                id="code"
                value={formData.code}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setFormData({ ...formData, code: e.target.value })
                }
                placeholder="e.g., POST_FC"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, description: e.target.value })
              }
              placeholder="Description of this action type"
              rows={2}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="defaultRiskLevel">Default Risk Level</Label>
              <Select
                value={formData.defaultRiskLevel}
                onValueChange={(value: string) =>
                  setFormData({ ...formData, defaultRiskLevel: value as RiskLevel })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: string) =>
                  setFormData({ ...formData, status: value as ActionTypeStatus })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="deprecated">Deprecated</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="requiresManualApproval"
              checked={formData.requiresManualApproval}
              onCheckedChange={(checked: boolean) =>
                setFormData({ ...formData, requiresManualApproval: checked })
              }
            />
            <Label htmlFor="requiresManualApproval">Requires manual approval</Label>
          </div>

          <div className="space-y-2">
            <Label htmlFor="defaultChannels">Default Channels (comma-separated)</Label>
            <Input
              id="defaultChannels"
              value={formData.defaultChannels}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setFormData({ ...formData, defaultChannels: e.target.value })
              }
              placeholder="e.g., farcaster, x, zora"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="allowedActors">Allowed Actors (comma-separated IDs or roles)</Label>
            <Input
              id="allowedActors"
              value={formData.allowedActors}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setFormData({ ...formData, allowedActors: e.target.value })
              }
              placeholder="e.g., founder, culture-engine"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="tags">Tags (comma-separated)</Label>
            <Input
              id="tags"
              value={formData.tags}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setFormData({ ...formData, tags: e.target.value })
              }
              placeholder="e.g., social, onchain, announcement"
            />
          </div>

          {!isCreating && (
            <>
              <Separator className="my-4" />
              <h3 className="text-lg font-semibold">SEO Metadata</h3>

              <div className="space-y-2">
                <Label htmlFor="seoTitle">SEO Title</Label>
                <Input
                  id="seoTitle"
                  value={formData.seoTitle}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setFormData({ ...formData, seoTitle: e.target.value })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="seoDescription">SEO Description</Label>
                <Textarea
                  id="seoDescription"
                  value={formData.seoDescription}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                    setFormData({ ...formData, seoDescription: e.target.value })
                  }
                  rows={2}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="seoKeywords">SEO Keywords (comma-separated)</Label>
                <Input
                  id="seoKeywords"
                  value={formData.seoKeywords}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setFormData({ ...formData, seoKeywords: e.target.value })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="seoHashtags">SEO Hashtags (comma-separated)</Label>
                <Input
                  id="seoHashtags"
                  value={formData.seoHashtags}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setFormData({ ...formData, seoHashtags: e.target.value })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="altText">Alt Text</Label>
                <Input
                  id="altText"
                  value={formData.altText}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setFormData({ ...formData, altText: e.target.value })
                  }
                />
              </div>
            </>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">{isCreating ? "Create" : "Save Changes"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
