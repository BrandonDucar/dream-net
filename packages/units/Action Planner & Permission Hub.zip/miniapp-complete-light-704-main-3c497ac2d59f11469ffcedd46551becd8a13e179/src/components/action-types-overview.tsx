"use client";

import { useState, useEffect } from "react";
import type { ActionType, ActionTypeFilters, RiskLevel, ActionTypeStatus } from "@/types/dreamnet";
import { listActionTypes } from "@/lib/dreamnet-core";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { ActionTypeDialog } from "./action-type-dialog";

export function ActionTypesOverview(): JSX.Element {
  const [actionTypes, setActionTypes] = useState<ActionType[]>([]);
  const [filters, setFilters] = useState<ActionTypeFilters>({});
  const [selectedActionType, setSelectedActionType] = useState<ActionType | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);
  const [isCreating, setIsCreating] = useState<boolean>(false);

  useEffect(() => {
    loadActionTypes();
  }, [filters]);

  function loadActionTypes(): void {
    const filtered = listActionTypes(filters);
    setActionTypes(filtered);
  }

  function handleCreateActionType(): void {
    setSelectedActionType(null);
    setIsCreating(true);
    setIsDialogOpen(true);
  }

  function handleEditActionType(actionType: ActionType): void {
    setSelectedActionType(actionType);
    setIsCreating(false);
    setIsDialogOpen(true);
  }

  function handleDialogClose(): void {
    setIsDialogOpen(false);
    setSelectedActionType(null);
    setIsCreating(false);
    loadActionTypes();
  }

  function getRiskBadgeVariant(risk: RiskLevel): "default" | "secondary" | "destructive" {
    const variants: Record<RiskLevel, "default" | "secondary" | "destructive"> = {
      low: "default",
      medium: "secondary",
      high: "destructive",
    };
    return variants[risk];
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Action Types</CardTitle>
          <Button onClick={handleCreateActionType}>Create Action Type</Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4 flex flex-wrap gap-2">
          <Select
            value={filters.defaultRiskLevel || "all"}
            onValueChange={(value: string) =>
              setFilters({
                ...filters,
                defaultRiskLevel: value === "all" ? undefined : (value as RiskLevel),
              })
            }
          >
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Filter by risk" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Risk Levels</SelectItem>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={
              filters.requiresManualApproval === undefined
                ? "all"
                : filters.requiresManualApproval
                ? "yes"
                : "no"
            }
            onValueChange={(value: string) =>
              setFilters({
                ...filters,
                requiresManualApproval:
                  value === "all" ? undefined : value === "yes",
              })
            }
          >
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Manual approval" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Approval Types</SelectItem>
              <SelectItem value="yes">Requires Approval</SelectItem>
              <SelectItem value="no">No Approval</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={filters.status || "all"}
            onValueChange={(value: string) =>
              setFilters({
                ...filters,
                status: value === "all" ? undefined : (value as ActionTypeStatus),
              })
            }
          >
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="deprecated">Deprecated</SelectItem>
            </SelectContent>
          </Select>

          <Input
            placeholder="Search tags..."
            value={filters.tagText || ""}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
              setFilters({ ...filters, tagText: e.target.value || undefined })
            }
            className="w-48"
          />
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Risk Level</TableHead>
                <TableHead>Manual Approval</TableHead>
                <TableHead>Tags</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {actionTypes.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground">
                    No action types found
                  </TableCell>
                </TableRow>
              ) : (
                actionTypes.map((actionType: ActionType) => (
                  <TableRow key={actionType.id}>
                    <TableCell className="font-medium">{actionType.name}</TableCell>
                    <TableCell>
                      <code className="text-sm">{actionType.code}</code>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getRiskBadgeVariant(actionType.defaultRiskLevel)}>
                        {actionType.defaultRiskLevel}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {actionType.requiresManualApproval ? (
                        <Badge variant="secondary">Required</Badge>
                      ) : (
                        <Badge variant="outline">Not Required</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {actionType.tags.slice(0, 2).map((tag: string) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {actionType.tags.length > 2 && (
                          <Badge variant="outline" className="text-xs">
                            +{actionType.tags.length - 2}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={actionType.status === "active" ? "default" : "outline"}>
                        {actionType.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditActionType(actionType)}
                      >
                        View/Edit
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>

      <ActionTypeDialog
        open={isDialogOpen}
        onClose={handleDialogClose}
        actionType={selectedActionType}
        isCreating={isCreating}
      />
    </Card>
  );
}
