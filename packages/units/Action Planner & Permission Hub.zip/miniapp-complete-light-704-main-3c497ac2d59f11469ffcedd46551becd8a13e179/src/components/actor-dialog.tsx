"use client";

import { useState, useEffect } from "react";
import type { Actor, ActorType, RiskProfile, ActorStatus } from "@/types/dreamnet";
import { registerActor, updateActor } from "@/lib/dreamnet-core";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

interface ActorDialogProps {
  open: boolean;
  onClose: () => void;
  actor: Actor | null;
  isCreating: boolean;
}

export function ActorDialog({ open, onClose, actor, isCreating }: ActorDialogProps): JSX.Element {
  const [formData, setFormData] = useState<{
    type: ActorType;
    name: string;
    role: string;
    refId: string;
    description: string;
    riskProfile: RiskProfile;
    status: ActorStatus;
    notes: string;
    allowedActionTypes: string;
    restrictedChannels: string;
  }>({
    type: "human",
    name: "",
    role: "",
    refId: "",
    description: "",
    riskProfile: "balanced",
    status: "active",
    notes: "",
    allowedActionTypes: "",
    restrictedChannels: "",
  });

  useEffect(() => {
    if (actor) {
      setFormData({
        type: actor.type,
        name: actor.name,
        role: actor.role,
        refId: actor.refId,
        description: actor.description,
        riskProfile: actor.riskProfile,
        status: actor.status,
        notes: actor.notes,
        allowedActionTypes: actor.allowedActionTypes.join(", "),
        restrictedChannels: actor.restrictedChannels.join(", "),
      });
    } else {
      setFormData({
        type: "human",
        name: "",
        role: "",
        refId: "",
        description: "",
        riskProfile: "balanced",
        status: "active",
        notes: "",
        allowedActionTypes: "",
        restrictedChannels: "",
      });
    }
  }, [actor, open]);

  function handleSubmit(e: React.FormEvent<HTMLFormElement>): void {
    e.preventDefault();

    if (!formData.name || !formData.role) {
      toast.error("Name and role are required");
      return;
    }

    try {
      if (isCreating) {
        registerActor({
          type: formData.type,
          name: formData.name,
          role: formData.role,
          refId: formData.refId,
          description: formData.description,
          riskProfile: formData.riskProfile,
        });
        toast.success("Actor registered successfully");
      } else if (actor) {
        updateActor(actor.id, {
          type: formData.type,
          name: formData.name,
          role: formData.role,
          refId: formData.refId,
          description: formData.description,
          riskProfile: formData.riskProfile,
          status: formData.status,
          notes: formData.notes,
          allowedActionTypes: formData.allowedActionTypes
            .split(",")
            .map((s: string) => s.trim())
            .filter((s: string) => s !== ""),
          restrictedChannels: formData.restrictedChannels
            .split(",")
            .map((s: string) => s.trim())
            .filter((s: string) => s !== ""),
        });
        toast.success("Actor updated successfully");
      }
      onClose();
    } catch (error) {
      toast.error("Failed to save actor");
      console.error(error);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isCreating ? "Register New Actor" : "Edit Actor"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                placeholder="e.g., Brandon, Threadsmith"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Type *</Label>
              <Select
                value={formData.type}
                onValueChange={(value: string) =>
                  setFormData({ ...formData, type: value as ActorType })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="human">Human</SelectItem>
                  <SelectItem value="mini-app">Mini-app</SelectItem>
                  <SelectItem value="bot">Bot</SelectItem>
                  <SelectItem value="external-service">External Service</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="role">Role *</Label>
              <Input
                id="role"
                value={formData.role}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setFormData({ ...formData, role: e.target.value })
                }
                placeholder="e.g., founder, culture-engine"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="refId">Reference ID</Label>
              <Input
                id="refId"
                value={formData.refId}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setFormData({ ...formData, refId: e.target.value })
                }
                placeholder="Handle or backend ID"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="riskProfile">Risk Profile</Label>
              <Select
                value={formData.riskProfile}
                onValueChange={(value: string) =>
                  setFormData({ ...formData, riskProfile: value as RiskProfile })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="conservative">Conservative</SelectItem>
                  <SelectItem value="balanced">Balanced</SelectItem>
                  <SelectItem value="aggressive">Aggressive</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: string) =>
                  setFormData({ ...formData, status: value as ActorStatus })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="paused">Paused</SelectItem>
                  <SelectItem value="retired">Retired</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, description: e.target.value })
              }
              placeholder="Brief description of this actor"
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="allowedActionTypes">Allowed Action Types (comma-separated)</Label>
            <Input
              id="allowedActionTypes"
              value={formData.allowedActionTypes}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setFormData({ ...formData, allowedActionTypes: e.target.value })
              }
              placeholder="e.g., post, announce-drop, mint"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="restrictedChannels">Restricted Channels (comma-separated)</Label>
            <Input
              id="restrictedChannels"
              value={formData.restrictedChannels}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setFormData({ ...formData, restrictedChannels: e.target.value })
              }
              placeholder="e.g., x-main, fc-founders-only"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, notes: e.target.value })
              }
              placeholder="Additional notes"
              rows={2}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">{isCreating ? "Register" : "Save Changes"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
