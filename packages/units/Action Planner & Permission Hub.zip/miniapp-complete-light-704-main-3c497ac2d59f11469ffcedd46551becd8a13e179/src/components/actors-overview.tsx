"use client";

import { useState, useEffect } from "react";
import type { Actor, ActorFilters, ActorType, RiskProfile, ActorStatus } from "@/types/dreamnet";
import { listActors } from "@/lib/dreamnet-core";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ActorDialog } from "./actor-dialog";

export function ActorsOverview(): JSX.Element {
  const [actors, setActors] = useState<Actor[]>([]);
  const [filters, setFilters] = useState<ActorFilters>({});
  const [selectedActor, setSelectedActor] = useState<Actor | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);
  const [isCreating, setIsCreating] = useState<boolean>(false);

  useEffect(() => {
    loadActors();
  }, [filters]);

  function loadActors(): void {
    const filtered = listActors(filters);
    setActors(filtered);
  }

  function handleCreateActor(): void {
    setSelectedActor(null);
    setIsCreating(true);
    setIsDialogOpen(true);
  }

  function handleEditActor(actor: Actor): void {
    setSelectedActor(actor);
    setIsCreating(false);
    setIsDialogOpen(true);
  }

  function handleDialogClose(): void {
    setIsDialogOpen(false);
    setSelectedActor(null);
    setIsCreating(false);
    loadActors();
  }

  function getRiskBadgeVariant(risk: RiskProfile): "default" | "secondary" | "destructive" {
    const variants: Record<RiskProfile, "default" | "secondary" | "destructive"> = {
      conservative: "default",
      balanced: "secondary",
      aggressive: "destructive",
    };
    return variants[risk];
  }

  function getStatusBadgeVariant(status: ActorStatus): "default" | "secondary" | "outline" {
    const variants: Record<ActorStatus, "default" | "secondary" | "outline"> = {
      active: "default",
      paused: "secondary",
      retired: "outline",
    };
    return variants[status];
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Actors</CardTitle>
          <Button onClick={handleCreateActor}>Register Actor</Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4 flex flex-wrap gap-2">
          <Select
            value={filters.type || "all"}
            onValueChange={(value: string) =>
              setFilters({ ...filters, type: value === "all" ? undefined : (value as ActorType) })
            }
          >
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="human">Human</SelectItem>
              <SelectItem value="mini-app">Mini-app</SelectItem>
              <SelectItem value="bot">Bot</SelectItem>
              <SelectItem value="external-service">External Service</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={filters.riskProfile || "all"}
            onValueChange={(value: string) =>
              setFilters({ ...filters, riskProfile: value === "all" ? undefined : (value as RiskProfile) })
            }
          >
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Filter by risk" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Risk Profiles</SelectItem>
              <SelectItem value="conservative">Conservative</SelectItem>
              <SelectItem value="balanced">Balanced</SelectItem>
              <SelectItem value="aggressive">Aggressive</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={filters.status || "all"}
            onValueChange={(value: string) =>
              setFilters({ ...filters, status: value === "all" ? undefined : (value as ActorStatus) })
            }
          >
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="paused">Paused</SelectItem>
              <SelectItem value="retired">Retired</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Risk Profile</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions Count</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {actors.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground">
                    No actors found
                  </TableCell>
                </TableRow>
              ) : (
                actors.map((actor: Actor) => (
                  <TableRow key={actor.id}>
                    <TableCell className="font-medium">{actor.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{actor.type}</Badge>
                    </TableCell>
                    <TableCell>{actor.role}</TableCell>
                    <TableCell>
                      <Badge variant={getRiskBadgeVariant(actor.riskProfile)}>
                        {actor.riskProfile}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getStatusBadgeVariant(actor.status)}>{actor.status}</Badge>
                    </TableCell>
                    <TableCell>{actor.allowedActionTypes.length}</TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm" onClick={() => handleEditActor(actor)}>
                        View/Edit
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>

      <ActorDialog
        open={isDialogOpen}
        onClose={handleDialogClose}
        actor={selectedActor}
        isCreating={isCreating}
      />
    </Card>
  );
}
