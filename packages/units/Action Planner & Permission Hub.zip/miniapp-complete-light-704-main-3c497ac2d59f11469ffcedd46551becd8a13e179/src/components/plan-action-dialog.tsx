"use client";

import { useState, useEffect } from "react";
import type { RiskLevel } from "@/types/dreamnet";
import { planAction } from "@/lib/dreamnet-core";
import { getActionTypes, getActors, getActionTemplates } from "@/lib/storage";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

interface PlanActionDialogProps {
  open: boolean;
  onClose: () => void;
}

export function PlanActionDialog({ open, onClose }: PlanActionDialogProps): JSX.Element {
  const [formData, setFormData] = useState<{
    actionTypeId: string;
    requestedByActorId: string;
    templateId: string;
    targetActorId: string;
    channel: string;
    payloadSummary: string;
    payloadRaw: string;
    scheduledAt: string;
    riskLevelOverride: string;
    externalRefs: string;
  }>({
    actionTypeId: "",
    requestedByActorId: "",
    templateId: "",
    targetActorId: "",
    channel: "",
    payloadSummary: "",
    payloadRaw: "",
    scheduledAt: "",
    riskLevelOverride: "",
    externalRefs: "",
  });

  const actionTypes = getActionTypes();
  const actors = getActors();
  const templates = getActionTemplates();

  useEffect(() => {
    if (open && actionTypes.length > 0) {
      setFormData((prev) => ({
        ...prev,
        actionTypeId: prev.actionTypeId || actionTypes[0].id,
      }));
    }
    if (open && actors.length > 0) {
      setFormData((prev) => ({
        ...prev,
        requestedByActorId: prev.requestedByActorId || actors[0].id,
      }));
    }
  }, [open, actionTypes, actors]);

  function handleSubmit(e: React.FormEvent<HTMLFormElement>): void {
    e.preventDefault();

    if (!formData.actionTypeId || !formData.requestedByActorId) {
      toast.error("Action type and requester are required");
      return;
    }

    try {
      let externalRefs = {};
      if (formData.externalRefs) {
        try {
          externalRefs = JSON.parse(formData.externalRefs);
        } catch {
          toast.error("Invalid JSON in external refs");
          return;
        }
      }

      const result = planAction({
        actionTypeId: formData.actionTypeId,
        requestedByActorId: formData.requestedByActorId,
        templateId: formData.templateId || null,
        targetActorId: formData.targetActorId || null,
        channel: formData.channel,
        payloadSummary: formData.payloadSummary,
        payloadRaw: formData.payloadRaw,
        scheduledAt: formData.scheduledAt || null,
        riskLevelOverride: formData.riskLevelOverride
          ? (formData.riskLevelOverride as RiskLevel)
          : undefined,
        externalRefs,
      });

      if (result) {
        toast.success("Action planned successfully");
        onClose();
        resetForm();
      } else {
        toast.error("Failed to plan action");
      }
    } catch (error) {
      toast.error("Failed to plan action");
      console.error(error);
    }
  }

  function resetForm(): void {
    setFormData({
      actionTypeId: actionTypes.length > 0 ? actionTypes[0].id : "",
      requestedByActorId: actors.length > 0 ? actors[0].id : "",
      templateId: "",
      targetActorId: "",
      channel: "",
      payloadSummary: "",
      payloadRaw: "",
      scheduledAt: "",
      riskLevelOverride: "",
      externalRefs: "",
    });
  }

  const relevantTemplates = templates.filter(
    (t) => t.actionTypeId === formData.actionTypeId
  );

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Plan New Action</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="actionTypeId">Action Type *</Label>
              <Select
                value={formData.actionTypeId}
                onValueChange={(value: string) =>
                  setFormData({ ...formData, actionTypeId: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select action type" />
                </SelectTrigger>
                <SelectContent>
                  {actionTypes.map((type) => (
                    <SelectItem key={type.id} value={type.id}>
                      {type.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="requestedByActorId">Requested By *</Label>
              <Select
                value={formData.requestedByActorId}
                onValueChange={(value: string) =>
                  setFormData({ ...formData, requestedByActorId: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select requester" />
                </SelectTrigger>
                <SelectContent>
                  {actors.map((actor) => (
                    <SelectItem key={actor.id} value={actor.id}>
                      {actor.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {relevantTemplates.length > 0 && (
              <div className="space-y-2">
                <Label htmlFor="templateId">Template (optional)</Label>
                <Select
                  value={formData.templateId}
                  onValueChange={(value: string) =>
                    setFormData({ ...formData, templateId: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="No template" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">No template</SelectItem>
                    {relevantTemplates.map((template) => (
                      <SelectItem key={template.id} value={template.id}>
                        {template.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="targetActorId">Target Actor (optional)</Label>
              <Select
                value={formData.targetActorId}
                onValueChange={(value: string) =>
                  setFormData({ ...formData, targetActorId: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="None" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">None</SelectItem>
                  {actors.map((actor) => (
                    <SelectItem key={actor.id} value={actor.id}>
                      {actor.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="channel">Channel</Label>
              <Input
                id="channel"
                value={formData.channel}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setFormData({ ...formData, channel: e.target.value })
                }
                placeholder="e.g., farcaster, x, zora"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="riskLevelOverride">Risk Level Override</Label>
              <Select
                value={formData.riskLevelOverride}
                onValueChange={(value: string) =>
                  setFormData({ ...formData, riskLevelOverride: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Use default" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Use default</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="payloadSummary">Payload Summary</Label>
            <Textarea
              id="payloadSummary"
              value={formData.payloadSummary}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, payloadSummary: e.target.value })
              }
              placeholder="Human-readable description of what will happen"
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="payloadRaw">Payload Raw (JSON or text)</Label>
            <Textarea
              id="payloadRaw"
              value={formData.payloadRaw}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, payloadRaw: e.target.value })
              }
              placeholder="Optional raw payload data"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="externalRefs">External References (JSON object)</Label>
            <Textarea
              id="externalRefs"
              value={formData.externalRefs}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, externalRefs: e.target.value })
              }
              placeholder='{"dropId": "123", "contentRefId": "456"}'
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="scheduledAt">Scheduled At (ISO format)</Label>
            <Input
              id="scheduledAt"
              type="datetime-local"
              value={formData.scheduledAt}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setFormData({ ...formData, scheduledAt: e.target.value })
              }
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">Plan Action</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
