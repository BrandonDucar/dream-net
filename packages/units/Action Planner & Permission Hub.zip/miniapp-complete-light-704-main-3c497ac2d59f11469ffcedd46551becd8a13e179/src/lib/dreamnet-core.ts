// Core functions for DreamNet Action Router & Permission Brain

import type {
  Actor,
  ActionType,
  ActionTemplate,
  PlannedAction,
  GeoTarget,
  ActorType,
  RiskProfile,
  RiskLevel,
  ActorFilters,
  ActionTypeFilters,
  PlannedActionFilters,
} from "@/types/dreamnet";

import {
  getActors,
  saveActors,
  getActorById,
  getActionTypes,
  saveActionTypes,
  getActionTypeById,
  getActionTemplates,
  saveActionTemplates,
  getActionTemplateById,
  getPlannedActions,
  savePlannedActions,
  getPlannedActionById,
} from "./storage";

// Utility: Generate unique ID
function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

// Utility: Generate SEO meta
function generateSEOMeta(name: string, description: string, tags: string[]): {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
} {
  return {
    seoTitle: name,
    seoDescription: description,
    seoKeywords: tags.slice(0, 10),
    seoHashtags: tags.map((tag: string) => `#${tag.replace(/\s+/g, "")}`),
    altText: `${name} - ${description}`,
  };
}

// 1) registerActor
export function registerActor(input: {
  type: ActorType;
  name: string;
  role: string;
  refId?: string;
  description?: string;
  riskProfile?: RiskProfile;
}): Actor {
  const actor: Actor = {
    id: generateId(),
    type: input.type,
    name: input.name,
    role: input.role,
    refId: input.refId || "",
    description: input.description || "",
    riskProfile: input.riskProfile || "balanced",
    allowedActionTypes: [],
    restrictedChannels: [],
    status: "active",
    notes: "",
  };

  const actors = getActors();
  actors.push(actor);
  saveActors(actors);

  return actor;
}

// 2) updateActor
export function updateActor(id: string, updates: Partial<Actor>): Actor | null {
  const actors = getActors();
  const index = actors.findIndex((a: Actor) => a.id === id);

  if (index === -1) {
    return null;
  }

  actors[index] = { ...actors[index], ...updates };
  saveActors(actors);

  return actors[index];
}

// 3) createActionType
export function createActionType(input: {
  name: string;
  code: string;
  description: string;
  defaultRiskLevel: RiskLevel;
  requiresManualApproval: boolean;
  defaultChannels: string[];
}): ActionType {
  const seoMeta = generateSEOMeta(input.name, input.description, []);

  const actionType: ActionType = {
    id: generateId(),
    name: input.name,
    code: input.code,
    description: input.description,
    defaultRiskLevel: input.defaultRiskLevel,
    requiresManualApproval: input.requiresManualApproval,
    allowedActors: [],
    defaultChannels: input.defaultChannels,
    tags: [],
    status: "active",
    ...seoMeta,
  };

  const actionTypes = getActionTypes();
  actionTypes.push(actionType);
  saveActionTypes(actionTypes);

  return actionType;
}

// 4) updateActionType
export function updateActionType(id: string, updates: Partial<ActionType>): ActionType | null {
  const actionTypes = getActionTypes();
  const index = actionTypes.findIndex((at: ActionType) => at.id === id);

  if (index === -1) {
    return null;
  }

  actionTypes[index] = { ...actionTypes[index], ...updates };
  saveActionTypes(actionTypes);

  return actionTypes[index];
}

// 5) createActionTemplate
export function createActionTemplate(input: {
  name: string;
  actionTypeId: string;
  description: string;
  parametersSchema: string;
  defaultPayloadExample: string;
  defaultChannel?: string | null;
  defaultRiskOverride?: "inherit" | RiskLevel;
}): ActionTemplate | null {
  const actionType = getActionTypeById(input.actionTypeId);
  if (!actionType) {
    return null;
  }

  const seoMeta = generateSEOMeta(input.name, input.description, []);

  const template: ActionTemplate = {
    id: generateId(),
    name: input.name,
    actionTypeId: input.actionTypeId,
    description: input.description,
    parametersSchema: input.parametersSchema,
    defaultPayloadExample: input.defaultPayloadExample,
    defaultChannel: input.defaultChannel || null,
    defaultRiskOverride: input.defaultRiskOverride || "inherit",
    notes: "",
    primaryGeoTargets: [],
    captionTemplateLocalized: {},
    tagsLocalized: {},
    ...seoMeta,
  };

  const templates = getActionTemplates();
  templates.push(template);
  saveActionTemplates(templates);

  return template;
}

// 6) updateActionTemplate
export function updateActionTemplate(
  id: string,
  updates: Partial<ActionTemplate>
): ActionTemplate | null {
  const templates = getActionTemplates();
  const index = templates.findIndex((t: ActionTemplate) => t.id === id);

  if (index === -1) {
    return null;
  }

  templates[index] = { ...templates[index], ...updates };
  saveActionTemplates(templates);

  return templates[index];
}

// 7) assignGeoTargetsToTemplate
export function assignGeoTargetsToTemplate(templateId: string, geoTargets: GeoTarget[]): boolean {
  const template = getActionTemplateById(templateId);
  if (!template) {
    return false;
  }

  return updateActionTemplate(templateId, { primaryGeoTargets: geoTargets }) !== null;
}

// 8) generateGeoVariantsForTemplate
export function generateGeoVariantsForTemplate(templateId: string): boolean {
  const template = getActionTemplateById(templateId);
  if (!template) {
    return false;
  }

  const actionType = getActionTypeById(template.actionTypeId);
  if (!actionType) {
    return false;
  }

  const captionTemplateLocalized: Record<string, string> = {};
  const tagsLocalized: Record<string, string[]> = {};

  template.primaryGeoTargets.forEach((geo: GeoTarget) => {
    const geoKey = geo.id;
    captionTemplateLocalized[geoKey] = `[${geo.language.toUpperCase()}] ${template.description} in ${geo.region}`;
    tagsLocalized[geoKey] = [
      ...actionType.tags,
      geo.region.toLowerCase(),
      geo.language,
      geo.cityOrMarket.toLowerCase(),
    ];
  });

  return (
    updateActionTemplate(templateId, {
      captionTemplateLocalized,
      tagsLocalized,
    }) !== null
  );
}

// 9) planAction
export function planAction(input: {
  actionTypeId: string;
  requestedByActorId: string;
  templateId?: string | null;
  targetActorId?: string | null;
  externalRefs?: Record<string, string>;
  channel?: string;
  payloadSummary?: string;
  payloadRaw?: string;
  scheduledAt?: string | null;
  riskLevelOverride?: RiskLevel;
}): PlannedAction | null {
  const actionType = getActionTypeById(input.actionTypeId);
  if (!actionType) {
    return null;
  }

  const requestedBy = getActorById(input.requestedByActorId);
  if (!requestedBy) {
    return null;
  }

  const riskLevel = input.riskLevelOverride || actionType.defaultRiskLevel;
  const requiresManualApproval = actionType.requiresManualApproval;

  const action: PlannedAction = {
    id: generateId(),
    templateId: input.templateId || null,
    actionTypeId: input.actionTypeId,
    requestedByActorId: input.requestedByActorId,
    targetActorId: input.targetActorId || null,
    externalRefs: input.externalRefs || {},
    channel: input.channel || actionType.defaultChannels[0] || "",
    payloadSummary: input.payloadSummary || "",
    payloadRaw: input.payloadRaw || "",
    riskLevel,
    requiresManualApproval,
    approvalStatus: requiresManualApproval ? "pending" : "skipped",
    approvalActorId: null,
    approvalNotes: "",
    executionStatus: "not-started",
    executionLog: "",
    createdAt: new Date().toISOString(),
    scheduledAt: input.scheduledAt || null,
    executedAt: null,
  };

  const actions = getPlannedActions();
  actions.push(action);
  savePlannedActions(actions);

  return action;
}

// 10) approveAction
export function approveAction(
  actionId: string,
  approverActorId: string,
  notes: string
): PlannedAction | null {
  const action = getPlannedActionById(actionId);
  if (!action) {
    return null;
  }

  if (!action.requiresManualApproval) {
    return action;
  }

  const actions = getPlannedActions();
  const index = actions.findIndex((a: PlannedAction) => a.id === actionId);

  if (index === -1) {
    return null;
  }

  actions[index] = {
    ...actions[index],
    approvalStatus: "approved",
    approvalActorId: approverActorId,
    approvalNotes: notes,
  };

  savePlannedActions(actions);
  return actions[index];
}

// 11) rejectAction
export function rejectAction(
  actionId: string,
  approverActorId: string,
  notes: string
): PlannedAction | null {
  const action = getPlannedActionById(actionId);
  if (!action) {
    return null;
  }

  const actions = getPlannedActions();
  const index = actions.findIndex((a: PlannedAction) => a.id === actionId);

  if (index === -1) {
    return null;
  }

  actions[index] = {
    ...actions[index],
    approvalStatus: "rejected",
    executionStatus: "cancelled",
    approvalActorId: approverActorId,
    approvalNotes: notes,
  };

  savePlannedActions(actions);
  return actions[index];
}

// 12) markActionExecuted
export function markActionExecuted(actionId: string, executionLog: string): PlannedAction | null {
  const actions = getPlannedActions();
  const index = actions.findIndex((a: PlannedAction) => a.id === actionId);

  if (index === -1) {
    return null;
  }

  actions[index] = {
    ...actions[index],
    executionStatus: "executed",
    executedAt: new Date().toISOString(),
    executionLog,
  };

  savePlannedActions(actions);
  return actions[index];
}

// 13) markActionFailed
export function markActionFailed(actionId: string, errorNotes: string): PlannedAction | null {
  const actions = getPlannedActions();
  const index = actions.findIndex((a: PlannedAction) => a.id === actionId);

  if (index === -1) {
    return null;
  }

  actions[index] = {
    ...actions[index],
    executionStatus: "failed",
    executionLog: errorNotes,
  };

  savePlannedActions(actions);
  return actions[index];
}

// 14) listActors
export function listActors(filters?: ActorFilters): Actor[] {
  let actors = getActors();

  if (filters) {
    if (filters.type) {
      actors = actors.filter((a: Actor) => a.type === filters.type);
    }
    if (filters.role) {
      actors = actors.filter((a: Actor) => a.role.toLowerCase().includes(filters.role!.toLowerCase()));
    }
    if (filters.riskProfile) {
      actors = actors.filter((a: Actor) => a.riskProfile === filters.riskProfile);
    }
    if (filters.status) {
      actors = actors.filter((a: Actor) => a.status === filters.status);
    }
  }

  return actors;
}

// 15) listActionTypes
export function listActionTypes(filters?: ActionTypeFilters): ActionType[] {
  let actionTypes = getActionTypes();

  if (filters) {
    if (filters.defaultRiskLevel) {
      actionTypes = actionTypes.filter((at: ActionType) => at.defaultRiskLevel === filters.defaultRiskLevel);
    }
    if (filters.requiresManualApproval !== undefined) {
      actionTypes = actionTypes.filter(
        (at: ActionType) => at.requiresManualApproval === filters.requiresManualApproval
      );
    }
    if (filters.status) {
      actionTypes = actionTypes.filter((at: ActionType) => at.status === filters.status);
    }
    if (filters.tagText) {
      const searchText = filters.tagText.toLowerCase();
      actionTypes = actionTypes.filter((at: ActionType) =>
        at.tags.some((tag: string) => tag.toLowerCase().includes(searchText))
      );
    }
  }

  return actionTypes;
}

// 16) listPlannedActions
export function listPlannedActions(filters?: PlannedActionFilters): PlannedAction[] {
  let actions = getPlannedActions();

  if (filters) {
    if (filters.approvalStatus) {
      actions = actions.filter((a: PlannedAction) => a.approvalStatus === filters.approvalStatus);
    }
    if (filters.executionStatus) {
      actions = actions.filter((a: PlannedAction) => a.executionStatus === filters.executionStatus);
    }
    if (filters.riskLevel) {
      actions = actions.filter((a: PlannedAction) => a.riskLevel === filters.riskLevel);
    }
    if (filters.channel) {
      actions = actions.filter((a: PlannedAction) => a.channel === filters.channel);
    }
    if (filters.requestedByActorId) {
      actions = actions.filter((a: PlannedAction) => a.requestedByActorId === filters.requestedByActorId);
    }
    if (filters.targetActorId) {
      actions = actions.filter((a: PlannedAction) => a.targetActorId === filters.targetActorId);
    }
  }

  return actions;
}

// 17) getActionDetails
export function getActionDetails(actionId: string): {
  action: PlannedAction;
  actionType: ActionType | null;
  template: ActionTemplate | null;
  requestedBy: Actor | null;
  targetActor: Actor | null;
} | null {
  const action = getPlannedActionById(actionId);
  if (!action) {
    return null;
  }

  return {
    action,
    actionType: getActionTypeById(action.actionTypeId) || null,
    template: action.templateId ? getActionTemplateById(action.templateId) || null : null,
    requestedBy: getActorById(action.requestedByActorId) || null,
    targetActor: action.targetActorId ? getActorById(action.targetActorId) || null : null,
  };
}

// 18) exportActionQueueBrief
export function exportActionQueueBrief(): string {
  const actions = getPlannedActions();

  const highRiskPending = actions.filter(
    (a: PlannedAction) => a.riskLevel === "high" && a.approvalStatus === "pending"
  );

  const approvedNotExecuted = actions.filter(
    (a: PlannedAction) => a.approvalStatus === "approved" && a.executionStatus === "not-started"
  );

  const recentlyExecuted = actions
    .filter((a: PlannedAction) => a.executionStatus === "executed")
    .sort((a: PlannedAction, b: PlannedAction) => {
      const dateA = a.executedAt ? new Date(a.executedAt).getTime() : 0;
      const dateB = b.executedAt ? new Date(b.executedAt).getTime() : 0;
      return dateB - dateA;
    })
    .slice(0, 10);

  let output = "=== DreamNet Action Queue Brief ===\n\n";

  output += `## HIGH-RISK ACTIONS PENDING APPROVAL (${highRiskPending.length})\n`;
  highRiskPending.forEach((action: PlannedAction) => {
    const actionType = getActionTypeById(action.actionTypeId);
    const requestedBy = getActorById(action.requestedByActorId);
    output += `- [${action.id}] ${action.payloadSummary || "No summary"}\n`;
    output += `  Type: ${actionType?.name || "Unknown"} | Channel: ${action.channel}\n`;
    output += `  Requested by: ${requestedBy?.name || "Unknown"} | Risk: ${action.riskLevel}\n`;
    output += `  Scheduled: ${action.scheduledAt || "Not scheduled"}\n\n`;
  });

  output += `\n## APPROVED BUT NOT EXECUTED (${approvedNotExecuted.length})\n`;
  approvedNotExecuted.forEach((action: PlannedAction) => {
    const actionType = getActionTypeById(action.actionTypeId);
    const requestedBy = getActorById(action.requestedByActorId);
    output += `- [${action.id}] ${action.payloadSummary || "No summary"}\n`;
    output += `  Type: ${actionType?.name || "Unknown"} | Channel: ${action.channel}\n`;
    output += `  Requested by: ${requestedBy?.name || "Unknown"} | Risk: ${action.riskLevel}\n`;
    output += `  Scheduled: ${action.scheduledAt || "Not scheduled"}\n\n`;
  });

  output += `\n## RECENTLY EXECUTED (${recentlyExecuted.length})\n`;
  recentlyExecuted.forEach((action: PlannedAction) => {
    const actionType = getActionTypeById(action.actionTypeId);
    output += `- [${action.id}] ${action.payloadSummary || "No summary"}\n`;
    output += `  Type: ${actionType?.name || "Unknown"} | Channel: ${action.channel}\n`;
    output += `  Executed: ${action.executedAt || "Unknown"}\n`;
    output += `  Log: ${action.executionLog || "No log"}\n\n`;
  });

  return output;
}
