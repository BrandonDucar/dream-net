// Local storage utilities for DreamNet

import type { Actor, ActionType, ActionTemplate, PlannedAction } from "@/types/dreamnet";

const STORAGE_KEYS = {
  ACTORS: "dreamnet_actors",
  ACTION_TYPES: "dreamnet_action_types",
  ACTION_TEMPLATES: "dreamnet_action_templates",
  PLANNED_ACTIONS: "dreamnet_planned_actions",
} as const;

// Generic storage functions
function getFromStorage<T>(key: string): T[] {
  if (typeof window === "undefined") {
    return [];
  }
  try {
    const data = localStorage.getItem(key);
    return data ? (JSON.parse(data) as T[]) : [];
  } catch (error) {
    console.error(`Error reading from storage: ${key}`, error);
    return [];
  }
}

function saveToStorage<T>(key: string, data: T[]): void {
  if (typeof window === "undefined") {
    return;
  }
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error saving to storage: ${key}`, error);
  }
}

// Actor storage
export function getActors(): Actor[] {
  return getFromStorage<Actor>(STORAGE_KEYS.ACTORS);
}

export function saveActors(actors: Actor[]): void {
  saveToStorage(STORAGE_KEYS.ACTORS, actors);
}

export function getActorById(id: string): Actor | undefined {
  return getActors().find((actor: Actor) => actor.id === id);
}

// ActionType storage
export function getActionTypes(): ActionType[] {
  return getFromStorage<ActionType>(STORAGE_KEYS.ACTION_TYPES);
}

export function saveActionTypes(actionTypes: ActionType[]): void {
  saveToStorage(STORAGE_KEYS.ACTION_TYPES, actionTypes);
}

export function getActionTypeById(id: string): ActionType | undefined {
  return getActionTypes().find((actionType: ActionType) => actionType.id === id);
}

// ActionTemplate storage
export function getActionTemplates(): ActionTemplate[] {
  return getFromStorage<ActionTemplate>(STORAGE_KEYS.ACTION_TEMPLATES);
}

export function saveActionTemplates(templates: ActionTemplate[]): void {
  saveToStorage(STORAGE_KEYS.ACTION_TEMPLATES, templates);
}

export function getActionTemplateById(id: string): ActionTemplate | undefined {
  return getActionTemplates().find((template: ActionTemplate) => template.id === id);
}

// PlannedAction storage
export function getPlannedActions(): PlannedAction[] {
  return getFromStorage<PlannedAction>(STORAGE_KEYS.PLANNED_ACTIONS);
}

export function savePlannedActions(actions: PlannedAction[]): void {
  saveToStorage(STORAGE_KEYS.PLANNED_ACTIONS, actions);
}

export function getPlannedActionById(id: string): PlannedAction | undefined {
  return getPlannedActions().find((action: PlannedAction) => action.id === id);
}
