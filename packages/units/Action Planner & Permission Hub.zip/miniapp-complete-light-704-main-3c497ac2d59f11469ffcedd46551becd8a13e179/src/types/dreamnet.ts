// Data Models for DreamNet Action Router & Permission Brain

export type ActorType = "human" | "mini-app" | "bot" | "external-service" | "other";
export type ActorStatus = "active" | "paused" | "retired";
export type RiskProfile = "conservative" | "balanced" | "aggressive";
export type RiskLevel = "low" | "medium" | "high";
export type ApprovalStatus = "pending" | "approved" | "rejected" | "skipped";
export type ExecutionStatus = "not-started" | "in-progress" | "executed" | "failed" | "cancelled";
export type ActionTypeStatus = "active" | "deprecated";

export interface Actor {
  id: string;
  type: ActorType;
  name: string;
  refId: string;
  role: string;
  description: string;
  riskProfile: RiskProfile;
  allowedActionTypes: string[];
  restrictedChannels: string[];
  status: ActorStatus;
  notes: string;
}

export interface SEOMeta {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export interface ActionType extends SEOMeta {
  id: string;
  name: string;
  code: string;
  description: string;
  defaultRiskLevel: RiskLevel;
  requiresManualApproval: boolean;
  allowedActors: string[];
  defaultChannels: string[];
  tags: string[];
  status: ActionTypeStatus;
}

export interface GeoTarget {
  id: string;
  region: string;
  country: string;
  cityOrMarket: string;
  language: string;
}

export interface ActionTemplate extends SEOMeta {
  id: string;
  name: string;
  actionTypeId: string;
  description: string;
  parametersSchema: string;
  defaultPayloadExample: string;
  defaultChannel: string | null;
  defaultRiskOverride: "inherit" | RiskLevel;
  notes: string;
  primaryGeoTargets: GeoTarget[];
  captionTemplateLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
}

export interface PlannedAction {
  id: string;
  templateId: string | null;
  actionTypeId: string;
  requestedByActorId: string;
  targetActorId: string | null;
  externalRefs: Record<string, string>;
  channel: string;
  payloadSummary: string;
  payloadRaw: string;
  riskLevel: RiskLevel;
  requiresManualApproval: boolean;
  approvalStatus: ApprovalStatus;
  approvalActorId: string | null;
  approvalNotes: string;
  executionStatus: ExecutionStatus;
  executionLog: string;
  createdAt: string;
  scheduledAt: string | null;
  executedAt: string | null;
}

// Filter types
export interface ActorFilters {
  type?: ActorType;
  role?: string;
  riskProfile?: RiskProfile;
  status?: ActorStatus;
}

export interface ActionTypeFilters {
  defaultRiskLevel?: RiskLevel;
  requiresManualApproval?: boolean;
  status?: ActionTypeStatus;
  tagText?: string;
}

export interface PlannedActionFilters {
  approvalStatus?: ApprovalStatus;
  executionStatus?: ExecutionStatus;
  riskLevel?: RiskLevel;
  channel?: string;
  requestedByActorId?: string;
  targetActorId?: string;
}
