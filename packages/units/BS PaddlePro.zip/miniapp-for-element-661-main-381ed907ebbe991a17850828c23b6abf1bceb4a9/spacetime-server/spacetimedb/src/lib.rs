use spacetimedb::{table, reducer, ReducerContext, Identity, Table, Timestamp, SpacetimeType};

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub struct ReviewPhoto {
    pub url: String,
    pub caption: String,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum ListingStatus {
    Draft,
    Active,
    Reserved,
    Sold,
    Cancelled,
}

#[table(name = player, public)]
#[derive(Clone)]
pub struct Player {
    #[primary_key]
    identity: Identity,
    name: String,
    rating: i32,
    wins: i32,
    losses: i32,
}

#[table(name = match_record, public)]
#[derive(Clone)]
pub struct MatchRecord {
    #[primary_key]
    #[auto_inc]
    id: u64,
    player_a_id: Identity,
    player_b_id: Identity,
    score_a: i32,
    score_b: i32,
    winner_id: Identity,
    date: Timestamp,
    rating_change_a: i32,
    rating_change_b: i32,
}

#[table(name = user_profile, public)]
#[derive(Clone)]
pub struct UserProfile {
    #[primary_key]
    identity: Identity,
    username: String,
    email: String,
    hashed_password: String,
    bio: String,
    skill_level: String,
    favorite_paddle: String,
    verified: bool,
    created_at: Timestamp,
    last_login_at: Timestamp,
}

#[table(
    name = paddle_review,
    public,
    index(name = paddle_review_author_idx, btree(columns = [author_id]))
)]
#[derive(Clone)]
pub struct PaddleReview {
    #[primary_key]
    #[auto_inc]
    review_id: u64,
    author_id: Identity,
    paddle_model: String,
    rating: u8,
    headline: String,
    content: String,
    photos: Vec<ReviewPhoto>,
    created_at: Timestamp,
    helpful_votes: u32,
    verified_purchase: bool,
}

#[table(
    name = review_helpful_vote,
    public,
    index(name = review_vote_idx, btree(columns = [review_id, voter_id]))
)]
#[derive(Clone)]
pub struct ReviewHelpfulVote {
    #[primary_key]
    #[auto_inc]
    vote_id: u64,
    review_id: u64,
    voter_id: Identity,
    voted_at: Timestamp,
}

#[table(
    name = marketplace_listing,
    public,
    index(name = listing_seller_idx, btree(columns = [seller_id]))
)]
#[derive(Clone)]
pub struct MarketplaceListing {
    #[primary_key]
    #[auto_inc]
    listing_id: u64,
    seller_id: Identity,
    paddle_model: String,
    title: String,
    description: String,
    price_cents: i64,
    condition: String,
    status: ListingStatus,
    photo_urls: Vec<String>,
    location: String,
    created_at: Timestamp,
    updated_at: Timestamp,
}

#[table(
    name = retail_price_point,
    public,
    index(name = retailer_model_idx, btree(columns = [retailer_name, paddle_model]))
)]
#[derive(Clone)]
pub struct RetailPricePoint {
    #[primary_key]
    #[auto_inc]
    price_point_id: u64,
    paddle_model: String,
    retailer_name: String,
    url: String,
    price_cents: i64,
    currency: String,
    recorded_at: Timestamp,
}

#[table(
    name = user_performance,
    public,
    index(name = performance_user_idx, btree(columns = [user_id]))
)]
#[derive(Clone)]
pub struct UserPerformance {
    #[primary_key]
    #[auto_inc]
    performance_id: u64,
    user_id: Identity,
    matches_played: u32,
    matches_won: u32,
    matches_lost: u32,
    win_rate: f32,
    avg_rally_length: f32,
    paddle_model: String,
    notes: String,
    power_score: f32,
    control_score: f32,
    recorded_at: Timestamp,
}

#[table(
    name = pro_tournament_result,
    public,
    index(name = pro_player_idx, btree(columns = [pro_player_name]))
)]
#[derive(Clone)]
pub struct ProTournamentResult {
    #[primary_key]
    #[auto_inc]
    result_id: u64,
    pro_player_name: String,
    tournament_name: String,
    placement: u32,
    paddle_model: String,
    earnings_cents: i64,
    matches_won: u32,
    matches_lost: u32,
    surface_type: String,
    event_date: Timestamp,
}

#[reducer]
pub fn create_player(ctx: &ReducerContext, name: String) -> Result<(), String> {
    let identity: Identity = ctx.sender;

    if ctx.db.player().identity().find(&identity).is_some() {
        return Err("Player already exists".to_string());
    }

    let new_player = Player {
        identity,
        name,
        rating: 1200,
        wins: 0,
        losses: 0,
    };

    match ctx.db.player().try_insert(new_player) {
        Ok(_row) => Ok(()),
        Err(e) => Err(format!("Failed to create player: {}", e)),
    }
}

#[reducer]
pub fn record_match(
    ctx: &ReducerContext,
    player_a_id: Identity,
    player_b_id: Identity,
    score_a: i32,
    score_b: i32,
) -> Result<(), String> {
    if player_a_id == player_b_id {
        return Err("A player cannot play against themselves".to_string());
    }
    if score_a < 0 || score_b < 0 {
        return Err("Scores must be non-negative".to_string());
       }
    if score_a == score_b {
        return Err("Match cannot end in a tie".to_string());
    }

    let mut player_a = match ctx.db.player().identity().find(&player_a_id) {
        Some(p) => p,
        None => return Err("Player A not found".to_string()),
    };

    let mut player_b = match ctx.db.player().identity().find(&player_b_id) {
        Some(p) => p,
        None => return Err("Player B not found".to_string()),
    };

    let winner_id = if score_a > score_b { player_a_id } else { player_b_id };

    let rating_a = player_a.rating as f64;
    let rating_b = player_b.rating as f64;

    let expected_a = 1.0 / (1.0 + 10f64.powf((rating_b - rating_a) / 400.0));
    let expected_b = 1.0 - expected_a;

    let actual_a = if score_a > score_b { 1.0 } else { 0.0 };
    let actual_b = 1.0 - actual_a;

    let k: f64 = 32.0;

    let delta_a = (k * (actual_a - expected_a)).round() as i32;
    let delta_b = (k * (actual_b - expected_b)).round() as i32;

    if score_a > score_b {
        player_a.wins += 1;
        player_b.losses += 1;
    } else {
        player_b.wins += 1;
        player_a.losses += 1;
    }

    player_a.rating += delta_a;
    player_b.rating += delta_b;

    let match_record = MatchRecord {
        id: 0,
        player_a_id,
        player_b_id,
        score_a,
        score_b,
        winner_id,
        date: ctx.timestamp,
        rating_change_a: delta_a,
        rating_change_b: delta_b,
    };

    ctx.db.match_record().insert(match_record);

    ctx.db.player().identity().update(player_a);
    ctx.db.player().identity().update(player_b);

    Ok(())
}

#[reducer]
pub fn register_user_profile(
    ctx: &ReducerContext,
    username: String,
    email: String,
    hashed_password: String,
    bio: String,
    skill_level: String,
    favorite_paddle: String,
) -> Result<(), String> {
    let identity = ctx.sender;

    if ctx.db.user_profile().identity().find(&identity).is_some() {
        return Err("Profile already exists for this identity".to_string());
    }

    let normalized_username = username.trim().to_string();
    if normalized_username.is_empty() {
        return Err("Username cannot be empty".to_string());
    }

    let normalized_email = email.trim().to_lowercase();
    if normalized_email.is_empty() {
        return Err("Email cannot be empty".to_string());
    }

    if hashed_password.trim().is_empty() {
        return Err("Hashed password cannot be empty".to_string());
    }

    let timestamp = ctx.timestamp;

    let profile = UserProfile {
        identity,
        username: normalized_username,
        email: normalized_email,
        hashed_password,
        bio: bio.trim().to_string(),
        skill_level: skill_level.trim().to_string(),
        favorite_paddle: favorite_paddle.trim().to_string(),
        verified: false,
        created_at: timestamp,
        last_login_at: timestamp,
    };

    ctx.db.user_profile().insert(profile);
    Ok(())
}

#[reducer]
pub fn login_user(ctx: &ReducerContext, hashed_password_attempt: String) -> Result<(), String> {
    let identity = ctx.sender;

    let mut profile = match ctx.db.user_profile().identity().find(&identity) {
        Some(profile) => profile,
        None => return Err("Profile not found".to_string()),
    };

    if profile.hashed_password != hashed_password_attempt {
        return Err("Invalid credentials".to_string());
    }

    profile.last_login_at = ctx.timestamp;
    ctx.db.user_profile().identity().update(profile);

    Ok(())
}

#[reducer]
pub fn update_user_profile(
    ctx: &ReducerContext,
    bio: String,
    skill_level: String,
    favorite_paddle: String,
    verified: bool,
) -> Result<(), String> {
    let identity = ctx.sender;

    let mut profile = match ctx.db.user_profile().identity().find(&identity) {
        Some(profile) => profile,
        None => return Err("Profile not found".to_string()),
    };

    profile.bio = bio.trim().to_string();
    profile.skill_level = skill_level.trim().to_string();
    profile.favorite_paddle = favorite_paddle.trim().to_string();
    profile.verified = verified;

    ctx.db.user_profile().identity().update(profile);
    Ok(())
}

#[reducer]
pub fn submit_paddle_review(
    ctx: &ReducerContext,
    paddle_model: String,
    rating: u8,
    headline: String,
    content: String,
    mut photos: Vec<ReviewPhoto>,
    verified_purchase: bool,
) -> Result<(), String> {
    if rating == 0 || rating > 5 {
        return Err("Rating must be between 1 and 5".to_string());
    }

    if ctx
        .db
        .user_profile()
        .identity()
        .find(&ctx.sender)
        .is_none()
    {
        return Err("Profile required to submit reviews".to_string());
    }

    let trimmed_headline = headline.trim().to_string();
    if trimmed_headline.is_empty() {
        return Err("Headline cannot be empty".to_string());
    }

    let trimmed_content = content.trim().to_string();
    if trimmed_content.is_empty() {
        return Err("Review content cannot be empty".to_string());
    }

    if photos.len() > 6 {
        photos.truncate(6);
    }

    let review = PaddleReview {
        review_id: 0,
        author_id: ctx.sender,
        paddle_model: paddle_model.trim().to_string(),
        rating,
        headline: trimmed_headline,
        content: trimmed_content,
        photos,
        created_at: ctx.timestamp,
        helpful_votes: 0,
        verified_purchase,
    };

    ctx.db.paddle_review().insert(review);
    Ok(())
}

#[reducer]
pub fn vote_review_helpful(ctx: &ReducerContext, review_id: u64) -> Result<(), String> {
    if ctx
        .db
        .user_profile()
        .identity()
        .find(&ctx.sender)
        .is_none()
    {
        return Err("Profile required to vote".to_string());
    }

    let mut review = match ctx.db.paddle_review().review_id().find(&review_id) {
        Some(review) => review,
        None => return Err("Review not found".to_string()),
    };

    for vote in ctx.db.review_helpful_vote().iter() {
        if vote.review_id == review_id && vote.voter_id == ctx.sender {
            return Err("You have already voted for this review".to_string());
        }
    }

    let new_vote = ReviewHelpfulVote {
        vote_id: 0,
        review_id,
        voter_id: ctx.sender,
        voted_at: ctx.timestamp,
    };

    ctx.db.review_helpful_vote().insert(new_vote);

    review.helpful_votes += 1;
    ctx.db.paddle_review().review_id().update(review);

    Ok(())
}

#[reducer]
pub fn create_listing(
    ctx: &ReducerContext,
    paddle_model: String,
    title: String,
    description: String,
    price_cents: i64,
    condition: String,
    location: String,
    mut photo_urls: Vec<String>,
) -> Result<(), String> {
    if price_cents <= 0 {
        return Err("Price must be greater than zero".to_string());
    }

    if ctx
        .db
        .user_profile()
        .identity()
        .find(&ctx.sender)
        .is_none()
    {
        return Err("Profile required to create listings".to_string());
    }

    let trimmed_title = title.trim().to_string();
    if trimmed_title.is_empty() {
        return Err("Title cannot be empty".to_string());
    }

    if photo_urls.len() > 6 {
        photo_urls.truncate(6);
    }

    let now = ctx.timestamp;

    let listing = MarketplaceListing {
        listing_id: 0,
        seller_id: ctx.sender,
        paddle_model: paddle_model.trim().to_string(),
        title: trimmed_title,
        description: description.trim().to_string(),
        price_cents,
        condition: condition.trim().to_string(),
        status: ListingStatus::Active,
        photo_urls,
        location: location.trim().to_string(),
        created_at: now,
        updated_at: now,
    };

    ctx.db.marketplace_listing().insert(listing);
    Ok(())
}

#[reducer]
pub fn update_listing_status(
    ctx: &ReducerContext,
    listing_id: u64,
    new_status: ListingStatus,
    new_price_cents: i64,
) -> Result<(), String> {
    let mut listing = match ctx
        .db
        .marketplace_listing()
        .listing_id()
        .find(&listing_id)
    {
        Some(listing) => listing,
        None => return Err("Listing not found".to_string()),
    };

    if listing.seller_id != ctx.sender {
        return Err("Only the seller can modify this listing".to_string());
    }

    if new_price_cents < 0 {
        return Err("Price cannot be negative".to_string());
    }

    if new_price_cents > 0 {
        listing.price_cents = new_price_cents;
    }

    listing.status = new_status;
    listing.updated_at = ctx.timestamp;

    ctx.db.marketplace_listing().listing_id().update(listing);
    Ok(())
}

#[reducer]
pub fn record_retail_price(
    ctx: &ReducerContext,
    paddle_model: String,
    retailer_name: String,
    url: String,
    price_cents: i64,
    currency: String,
) -> Result<(), String> {
    if price_cents <= 0 {
        return Err("Price must be positive".to_string());
    }

    let price_point = RetailPricePoint {
        price_point_id: 0,
        paddle_model: paddle_model.trim().to_string(),
        retailer_name: retailer_name.trim().to_string(),
        url: url.trim().to_string(),
        price_cents,
        currency: currency.trim().to_uppercase(),
        recorded_at: ctx.timestamp,
    };

    ctx.db.retail_price_point().insert(price_point);
    Ok(())
}

#[reducer]
pub fn record_user_performance(
    ctx: &ReducerContext,
    matches_played: u32,
    matches_won: u32,
    avg_rally_length: f32,
    paddle_model: String,
    notes: String,
    power_score: f32,
    control_score: f32,
) -> Result<(), String> {
    if ctx
        .db
        .user_profile()
        .identity()
        .find(&ctx.sender)
        .is_none()
    {
        return Err("Profile required to record performance".to_string());
    }

    if matches_won > matches_played {
        return Err("Wins cannot exceed matches played".to_string());
    }

    if !(0.0..=100.0).contains(&power_score) || !(0.0..=100.0).contains(&control_score) {
        return Err("Power and control scores must be between 0 and 100".to_string());
    }

    let matches_lost = matches_played.saturating_sub(matches_won);
    let win_rate = if matches_played == 0 {
        0.0
    } else {
        matches_won as f32 / matches_played as f32
    };

    let performance = UserPerformance {
        performance_id: 0,
        user_id: ctx.sender,
        matches_played,
        matches_won,
        matches_lost,
        win_rate,
        avg_rally_length,
        paddle_model: paddle_model.trim().to_string(),
        notes: notes.trim().to_string(),
        power_score,
        control_score,
        recorded_at: ctx.timestamp,
    };

    ctx.db.user_performance().insert(performance);
    Ok(())
}

#[reducer]
pub fn record_pro_tournament_result(
    ctx: &ReducerContext,
    pro_player_name: String,
    tournament_name: String,
    placement: u32,
    paddle_model: String,
    earnings_cents: i64,
    matches_won: u32,
    matches_lost: u32,
    surface_type: String,
    event_timestamp: Timestamp,
) -> Result<(), String> {
    if placement == 0 {
        return Err("Placement must be greater than zero".to_string());
    }

    if matches_won == 0 && matches_lost == 0 {
        return Err("At least one match must be recorded".to_string());
    }

    if earnings_cents < 0 {
        return Err("Earnings cannot be negative".to_string());
    }

    let result = ProTournamentResult {
        result_id: 0,
        pro_player_name: pro_player_name.trim().to_string(),
        tournament_name: tournament_name.trim().to_string(),
        placement,
        paddle_model: paddle_model.trim().to_string(),
        earnings_cents,
        matches_won,
        matches_lost,
        surface_type: surface_type.trim().to_string(),
        event_date: event_timestamp,
    };

    ctx.db.pro_tournament_result().insert(result);
    Ok(())
}