import { NextRequest, NextResponse } from 'next/server'
import { paddleDatabase } from '@/lib/paddleData'
import { compareAdvancedPaddles } from '@/lib/advancedPaddleData'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { paddleA, paddleB } = body

    if (!paddleA || !paddleB) {
      return NextResponse.json(
        { error: 'Both paddleA and paddleB IDs are required' },
        { status: 400 }
      )
    }

    if (paddleA === paddleB) {
      return NextResponse.json(
        { error: 'Cannot compare a paddle with itself' },
        { status: 400 }
      )
    }

    // Verify paddles exist
    const paddleDataA = paddleDatabase.find(p => p.id === paddleA)
    const paddleDataB = paddleDatabase.find(p => p.id === paddleB)

    if (!paddleDataA) {
      return NextResponse.json(
        { error: `Paddle with ID '${paddleA}' not found` },
        { status: 404 }
      )
    }

    if (!paddleDataB) {
      return NextResponse.json(
        { error: `Paddle with ID '${paddleB}' not found` },
        { status: 404 }
      )
    }

    // Perform comparison
    const comparison = compareAdvancedPaddles(paddleA, paddleB)

    if (!comparison) {
      return NextResponse.json(
        { error: 'Advanced specifications not available for one or both paddles' },
        { status: 400 }
      )
    }

    return NextResponse.json({
      comparison,
      paddleDataA,
      paddleDataB,
      success: true
    })
  } catch (error) {
    console.error('Error performing paddle comparison:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const paddleA = searchParams.get('paddleA')
    const paddleB = searchParams.get('paddleB')

    if (!paddleA || !paddleB) {
      return NextResponse.json(
        { 
          error: 'Both paddleA and paddleB query parameters are required',
          example: '/api/compare?paddleA=selkirk-vanguard-power-air&paddleB=joola-ben-johns-hyperion'
        },
        { status: 400 }
      )
    }

    if (paddleA === paddleB) {
      return NextResponse.json(
        { error: 'Cannot compare a paddle with itself' },
        { status: 400 }
      )
    }

    // Verify paddles exist
    const paddleDataA = paddleDatabase.find(p => p.id === paddleA)
    const paddleDataB = paddleDatabase.find(p => p.id === paddleB)

    if (!paddleDataA) {
      return NextResponse.json(
        { error: `Paddle with ID '${paddleA}' not found` },
        { status: 404 }
      )
    }

    if (!paddleDataB) {
      return NextResponse.json(
        { error: `Paddle with ID '${paddleB}' not found` },
        { status: 404 }
      )
    }

    // Perform comparison
    const comparison = compareAdvancedPaddles(paddleA, paddleB)

    if (!comparison) {
      return NextResponse.json(
        { error: 'Advanced specifications not available for one or both paddles' },
        { status: 400 }
      )
    }

    return NextResponse.json({
      comparison,
      paddleDataA,
      paddleDataB,
      success: true
    })
  } catch (error) {
    console.error('Error performing paddle comparison:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}