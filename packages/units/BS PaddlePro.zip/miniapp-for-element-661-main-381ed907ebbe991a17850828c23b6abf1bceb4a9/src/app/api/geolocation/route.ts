import { NextRequest, NextResponse } from 'next/server'
import { findNearbyRetailers, getWeatherData } from '@/lib/geolocation'
import { generateLocationSEO } from '@/lib/ai-seo'
import type { LocationData } from '@/types/advanced-paddle'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { latitude, longitude, city, state, zipCode, country }: LocationData = body

    if (!latitude || !longitude) {
      return NextResponse.json(
        { error: 'Latitude and longitude are required' },
        { status: 400 }
      )
    }

    // Find nearby retailers
    const retailers = await findNearbyRetailers({
      latitude,
      longitude,
      city: city || 'Unknown',
      state: state || 'Unknown',
      zipCode: zipCode || 'Unknown',
      country: country || 'Unknown'
    })

    // Get weather data
    const weather = await getWeatherData(latitude, longitude)

    // Generate location-specific SEO content
    const seoContent = generateLocationSEO(city || 'Your City', state || 'Your State')

    return NextResponse.json({
      retailers,
      weather,
      seoContent,
      location: { latitude, longitude, city, state, zipCode, country },
      success: true
    })
  } catch (error) {
    console.error('Error processing geolocation request:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const lat = searchParams.get('lat')
    const lng = searchParams.get('lng')

    if (!lat || !lng) {
      return NextResponse.json(
        { error: 'Latitude (lat) and longitude (lng) parameters are required' },
        { status: 400 }
      )
    }

    const latitude = parseFloat(lat)
    const longitude = parseFloat(lng)

    if (isNaN(latitude) || isNaN(longitude)) {
      return NextResponse.json(
        { error: 'Invalid latitude or longitude values' },
        { status: 400 }
      )
    }

    // Basic location info without detailed geocoding
    const location: LocationData = {
      latitude,
      longitude,
      city: 'Unknown',
      state: 'Unknown',
      zipCode: 'Unknown',
      country: 'Unknown'
    }

    const retailers = await findNearbyRetailers(location)
    const weather = await getWeatherData(latitude, longitude)

    return NextResponse.json({
      retailers,
      weather,
      location,
      success: true
    })
  } catch (error) {
    console.error('Error processing geolocation GET request:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}