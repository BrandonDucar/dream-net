import { NextRequest, NextResponse } from 'next/server'

// Mock marketplace data - In production this would connect to SpacetimeDB
const mockListings = [
  {
    id: '1',
    sellerId: 'user123',
    sellerName: 'PicklePro2024',
    sellerRating: 4.8,
    paddleId: 'selkirk-vanguard-power-air',
    paddleBrand: 'Selkirk',
    paddleModel: 'Vanguard Power Air',
    condition: 'excellent',
    price: 160,
    originalPrice: 210,
    description: "Selling my Vanguard after upgrading to Labs 002. Still in excellent condition.",
    monthsUsed: 6,
    location: 'Austin, TX',
    shipping: true,
    localPickup: true,
    datePosted: '2024-01-20',
    status: 'active',
    views: 45,
    watchers: 8
  },
  {
    id: '2',
    sellerId: 'user456',
    sellerName: 'CoachSarah',
    sellerRating: 5.0,
    paddleId: 'joola-ben-johns-hyperion',
    paddleBrand: 'JOOLA',
    paddleModel: 'Ben Johns Hyperion CFS',
    condition: 'like-new',
    price: 195,
    originalPrice: 240,
    description: "Barely used Hyperion. Bought for tournaments but went with a different paddle.",
    monthsUsed: 1,
    location: 'Phoenix, AZ',
    shipping: true,
    localPickup: false,
    datePosted: '2024-01-18',
    status: 'active',
    views: 73,
    watchers: 15
  }
]

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const condition = searchParams.get('condition')
  const priceRange = searchParams.get('priceRange')
  const sortBy = searchParams.get('sortBy') || 'newest'
  const search = searchParams.get('search')

  try {
    let filteredListings = mockListings.filter(listing => listing.status === 'active')

    // Filter by condition
    if (condition && condition !== 'all') {
      filteredListings = filteredListings.filter(listing => listing.condition === condition)
    }

    // Filter by price range
    if (priceRange && priceRange !== 'all') {
      filteredListings = filteredListings.filter(listing => {
        const price = listing.price
        switch (priceRange) {
          case 'under-100': return price < 100
          case '100-150': return price >= 100 && price <= 150
          case '150-200': return price >= 150 && price <= 200
          case 'over-200': return price > 200
          default: return true
        }
      })
    }

    // Search filter
    if (search) {
      const searchTerm = search.toLowerCase()
      filteredListings = filteredListings.filter(listing =>
        listing.paddleBrand.toLowerCase().includes(searchTerm) ||
        listing.paddleModel.toLowerCase().includes(searchTerm) ||
        listing.description.toLowerCase().includes(searchTerm)
      )
    }

    // Sort listings
    filteredListings.sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.datePosted).getTime() - new Date(a.datePosted).getTime()
        case 'oldest':
          return new Date(a.datePosted).getTime() - new Date(b.datePosted).getTime()
        case 'price-low':
          return a.price - b.price
        case 'price-high':
          return b.price - a.price
        case 'popular':
          return b.watchers - a.watchers
        default:
          return 0
      }
    })

    return NextResponse.json({
      success: true,
      listings: filteredListings,
      total: filteredListings.length
    })
  } catch (error) {
    console.error('Error fetching marketplace listings:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch listings' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const listingData = await request.json()
    
    // Validate required fields
    const required = ['paddleId', 'condition', 'price', 'description', 'location']
    for (const field of required) {
      if (!listingData[field]) {
        return NextResponse.json(
          { success: false, error: `Missing required field: ${field}` },
          { status: 400 }
        )
      }
    }

    // Create new listing
    const newListing = {
      id: Date.now().toString(),
      sellerId: 'current-user', // In production: get from auth
      sellerName: 'You',
      sellerRating: 5.0,
      ...listingData,
      datePosted: new Date().toISOString().split('T')[0],
      status: 'active',
      views: 0,
      watchers: 0
    }

    // In production: Save to SpacetimeDB
    mockListings.push(newListing)

    return NextResponse.json({
      success: true,
      listing: newListing,
      message: 'Listing created successfully'
    })
  } catch (error) {
    console.error('Error creating listing:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create listing' },
      { status: 500 }
    )
  }
}