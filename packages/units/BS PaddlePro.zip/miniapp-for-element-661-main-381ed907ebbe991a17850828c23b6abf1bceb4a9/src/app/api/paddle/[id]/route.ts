import { NextRequest, NextResponse } from 'next/server'
import { paddleDatabase } from '@/lib/paddleData'
import { generatePaddleSEO } from '@/lib/ai-seo'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const paddle = paddleDatabase.find(p => p.id === id)
    
    if (!paddle) {
      return NextResponse.json(
        { error: 'Paddle not found' },
        { status: 404 }
      )
    }

    const seoContent = generatePaddleSEO(paddle)
    
    return NextResponse.json({
      paddle,
      seoContent,
      success: true
    })
  } catch (error) {
    console.error('Error fetching paddle data:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    
    // This could be used for user feedback/ratings on paddles
    console.log('Paddle feedback received for:', id, body)
    
    return NextResponse.json({
      success: true,
      message: 'Feedback recorded'
    })
  } catch (error) {
    console.error('Error recording feedback:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}