import { NextRequest, NextResponse } from 'next/server'

// Mock price alert data - In production this would connect to SpacetimeDB
const mockAlerts = [
  {
    id: '1',
    paddleId: 'selkirk-vanguard-power-air',
    paddleName: 'Selkirk Vanguard Power Air',
    targetPrice: 180,
    currentPrice: 199.99,
    email: 'user@example.com',
    active: true,
    created: '2024-01-15',
    triggered: false
  },
  {
    id: '2',
    paddleId: 'joola-ben-johns-hyperion',
    paddleName: 'JOOLA Ben Johns Hyperion',
    targetPrice: 220,
    currentPrice: 234.95,
    email: 'user@example.com',
    active: true,
    created: '2024-01-10',
    triggered: false
  }
]

const mockPrices = [
  {
    id: '1',
    paddleId: 'selkirk-vanguard-power-air',
    retailer: 'Pickleball Central',
    price: 199.99,
    salePrice: 179.99,
    inStock: true,
    lastUpdated: '2024-01-20T10:00:00Z'
  },
  {
    id: '2',
    paddleId: 'joola-ben-johns-hyperion',
    retailer: 'Tennis Warehouse',
    price: 234.95,
    salePrice: 224.95,
    inStock: true,
    lastUpdated: '2024-01-20T11:00:00Z'
  }
]

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const action = searchParams.get('action')

  try {
    if (action === 'prices') {
      // Return current prices for all paddles
      return NextResponse.json({
        success: true,
        prices: mockPrices,
        total: mockPrices.length
      })
    }

    // Return user's price alerts
    return NextResponse.json({
      success: true,
      alerts: mockAlerts,
      total: mockAlerts.length
    })
  } catch (error) {
    console.error('Error fetching price data:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch price data' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const alertData = await request.json()
    
    // Validate required fields
    const required = ['paddleId', 'targetPrice', 'email']
    for (const field of required) {
      if (!alertData[field]) {
        return NextResponse.json(
          { success: false, error: `Missing required field: ${field}` },
          { status: 400 }
        )
      }
    }

    // Get current price for the paddle
    const currentPrice = mockPrices.find(p => p.paddleId === alertData.paddleId)?.price || 0
    
    // Create new alert
    const newAlert = {
      id: Date.now().toString(),
      paddleName: `Paddle ${alertData.paddleId}`, // In production: lookup paddle name
      currentPrice,
      ...alertData,
      active: true,
      created: new Date().toISOString().split('T')[0],
      triggered: false
    }

    // In production: Save to SpacetimeDB
    mockAlerts.push(newAlert)

    return NextResponse.json({
      success: true,
      alert: newAlert,
      message: 'Price alert created successfully'
    })
  } catch (error) {
    console.error('Error creating price alert:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create price alert' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const alertId = searchParams.get('id')
    
    if (!alertId) {
      return NextResponse.json(
        { success: false, error: 'Alert ID required' },
        { status: 400 }
      )
    }

    // In production: Remove from SpacetimeDB
    const alertIndex = mockAlerts.findIndex(alert => alert.id === alertId)
    if (alertIndex > -1) {
      mockAlerts.splice(alertIndex, 1)
    }

    return NextResponse.json({
      success: true,
      message: 'Price alert deleted successfully'
    })
  } catch (error) {
    console.error('Error deleting price alert:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to delete price alert' },
      { status: 500 }
    )
  }
}