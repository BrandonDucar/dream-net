import { NextRequest, NextResponse } from 'next/server'

// Mock pro player data - In production this would connect to tournament databases
const mockProPlayers = [
  {
    id: 'ben-johns',
    name: 'Ben Johns',
    ranking: 1,
    currentPaddle: 'joola-ben-johns-hyperion',
    paddleHistory: ['joola-ben-johns-hyperion', 'joola-vision-cgr'],
    totalTitles: 45,
    recentTitles: [
      { 
        tournament: 'PPA Masters', 
        year: 2024, 
        placement: '1st', 
        prize: 15000, 
        partner: 'Collin Johns', 
        paddleUsed: 'joola-ben-johns-hyperion' 
      },
      { 
        tournament: 'APP Championship', 
        year: 2024, 
        placement: '1st', 
        prize: 12000, 
        paddleUsed: 'joola-ben-johns-hyperion' 
      }
    ],
    endorsements: ['JOOLA', 'Franklin Sports'],
    playStyle: ['Power Baseline', 'Aggressive Nets', 'Counter-Attack'],
    signatureTechniques: ['Erne', 'ATP', 'Power Dinking']
  },
  {
    id: 'anna-leigh-waters',
    name: 'Anna Leigh Waters',
    ranking: 1,
    currentPaddle: 'paddletek-bantam-ts5-pro',
    paddleHistory: ['paddletek-bantam-ts5-pro', 'paddletek-tempest-wave-pro'],
    totalTitles: 38,
    recentTitles: [
      { 
        tournament: 'PPA Championships', 
        year: 2024, 
        placement: '1st', 
        prize: 18000, 
        partner: 'Leigh Waters', 
        paddleUsed: 'paddletek-bantam-ts5-pro' 
      }
    ],
    endorsements: ['Paddletek', 'HEAD'],
    playStyle: ['All-Court', 'Strategic Placement', 'Quick Hands'],
    signatureTechniques: ['Precision Dinking', 'Quick Exchanges', 'Court Positioning']
  }
]

const mockPaddleStats = [
  {
    paddleId: 'joola-ben-johns-hyperion',
    paddleName: 'JOOLA Ben Johns Hyperion',
    playersUsingCount: 15,
    topPlayers: ['Ben Johns', 'Riley Newman', 'JW Johnson'],
    winRate: 78,
    totalTournaments: 45,
    recentSwitches: 8
  },
  {
    paddleId: 'paddletek-bantam-ts5-pro',
    paddleName: 'Paddletek Bantam TS-5 Pro',
    playersUsingCount: 12,
    topPlayers: ['Anna Leigh Waters', 'Leigh Waters', 'Catherine Parenteau'],
    winRate: 74,
    totalTournaments: 38,
    recentSwitches: 5
  }
]

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const action = searchParams.get('action')
  const search = searchParams.get('search')
  const sortBy = searchParams.get('sortBy') || 'ranking'

  try {
    if (action === 'paddle-stats') {
      return NextResponse.json({
        success: true,
        paddleStats: mockPaddleStats,
        total: mockPaddleStats.length
      })
    }

    if (action === 'trends') {
      return NextResponse.json({
        success: true,
        trends: {
          risingPaddles: [
            { name: 'JOOLA Ben Johns Hyperion', change: '+8 pros' },
            { name: 'Selkirk Labs 002', change: '+5 pros' },
            { name: 'HEAD Extreme Tour', change: '+3 pros' }
          ],
          materialTrends: {
            'Raw Carbon': 68,
            'Carbon Fiber': 25,
            'Fiberglass': 7
          },
          recentChanges: [
            { player: 'Riley Newman', paddle: 'JOOLA Hyperion', date: '3 days ago' },
            { player: 'JW Johnson', paddle: 'Selkirk Labs 002', date: '1 week ago' }
          ]
        }
      })
    }

    // Filter and sort players
    let players = [...mockProPlayers]
    
    if (search) {
      const searchTerm = search.toLowerCase()
      players = players.filter(player =>
        player.name.toLowerCase().includes(searchTerm) ||
        player.currentPaddle.toLowerCase().includes(searchTerm)
      )
    }

    players.sort((a, b) => {
      switch (sortBy) {
        case 'ranking': return a.ranking - b.ranking
        case 'titles': return b.totalTitles - a.totalTitles
        case 'name': return a.name.localeCompare(b.name)
        default: return a.ranking - b.ranking
      }
    })

    return NextResponse.json({
      success: true,
      players: players,
      total: players.length
    })
  } catch (error) {
    console.error('Error fetching pro player data:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch pro player data' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const playerData = await request.json()
    
    // Validate required fields for tournament result submission
    const required = ['playerId', 'tournament', 'placement', 'paddleUsed']
    for (const field of required) {
      if (!playerData[field]) {
        return NextResponse.json(
          { success: false, error: `Missing required field: ${field}` },
          { status: 400 }
        )
      }
    }

    // In production: Save tournament result to SpacetimeDB
    // Update player stats, paddle usage statistics, etc.

    return NextResponse.json({
      success: true,
      message: 'Tournament result recorded successfully'
    })
  } catch (error) {
    console.error('Error recording tournament result:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to record tournament result' },
      { status: 500 }
    )
  }
}