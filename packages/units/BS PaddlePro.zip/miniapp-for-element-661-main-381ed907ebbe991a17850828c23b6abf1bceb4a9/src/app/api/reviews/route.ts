import { NextRequest, NextResponse } from 'next/server'

// Mock data - In production this would connect to SpacetimeDB
const mockReviews = [
  {
    id: '1',
    paddleId: 'selkirk-vanguard-power-air',
    userName: 'CoachMike47',
    rating: 5,
    reviewText: "Absolute game changer! The raw carbon surface gives incredible spin and the power is unmatched.",
    skillLevel: 'Advanced',
    playStyle: 'Singles',
    monthsUsed: 8,
    wouldRecommend: true,
    date: '2024-01-15',
    helpfulVotes: 23,
    verified: true
  },
  {
    id: '2',
    paddleId: 'joola-ben-johns-hyperion',
    userName: 'TournamentTom',
    rating: 5,
    reviewText: "This paddle is a beast! The spin generation is off the charts.",
    skillLevel: 'Tournament',
    playStyle: 'Both',
    monthsUsed: 6,
    wouldRecommend: true,
    date: '2024-01-08',
    helpfulVotes: 45,
    verified: true
  }
]

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const paddleId = searchParams.get('paddleId')
  const sortBy = searchParams.get('sortBy') || 'newest'
  const filterRating = searchParams.get('filterRating')

  try {
    let filteredReviews = [...mockReviews]

    // Filter by paddle
    if (paddleId && paddleId !== 'all') {
      filteredReviews = filteredReviews.filter(review => review.paddleId === paddleId)
    }

    // Filter by rating
    if (filterRating && filterRating !== 'all') {
      filteredReviews = filteredReviews.filter(review => review.rating.toString() === filterRating)
    }

    // Sort reviews
    filteredReviews.sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.date).getTime() - new Date(a.date).getTime()
        case 'oldest':
          return new Date(a.date).getTime() - new Date(b.date).getTime()
        case 'highest':
          return b.rating - a.rating
        case 'lowest':
          return a.rating - b.rating
        case 'helpful':
          return b.helpfulVotes - a.helpfulVotes
        default:
          return 0
      }
    })

    return NextResponse.json({
      success: true,
      reviews: filteredReviews,
      total: filteredReviews.length
    })
  } catch (error) {
    console.error('Error fetching reviews:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch reviews' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const reviewData = await request.json()
    
    // Validate required fields
    const required = ['paddleId', 'userName', 'rating', 'reviewText', 'skillLevel', 'playStyle']
    for (const field of required) {
      if (!reviewData[field]) {
        return NextResponse.json(
          { success: false, error: `Missing required field: ${field}` },
          { status: 400 }
        )
      }
    }

    // Create new review
    const newReview = {
      id: Date.now().toString(),
      ...reviewData,
      date: new Date().toISOString().split('T')[0],
      helpfulVotes: 0,
      verified: false
    }

    // In production: Save to SpacetimeDB
    mockReviews.push(newReview)

    return NextResponse.json({
      success: true,
      review: newReview,
      message: 'Review submitted successfully'
    })
  } catch (error) {
    console.error('Error submitting review:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to submit review' },
      { status: 500 }
    )
  }
}