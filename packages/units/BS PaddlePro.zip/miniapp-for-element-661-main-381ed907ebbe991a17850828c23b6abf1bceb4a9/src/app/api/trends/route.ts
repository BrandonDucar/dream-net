import { NextRequest, NextResponse } from 'next/server'
import { generateTrendAnalysis } from '@/lib/ai-seo'
import { paddleDatabase } from '@/lib/paddleData'
import { advancedPaddleSpecs } from '@/lib/advancedPaddleData'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const period = searchParams.get('period') as 'week' | 'month' | 'quarter' | 'year' || 'month'

    // Generate trend analysis
    const trends = generateTrendAnalysis()
    trends.period = period

    // Add additional analytics
    const analytics = {
      totalPaddles: paddleDatabase.length,
      paddlesWithAdvancedSpecs: Object.keys(advancedPaddleSpecs).length,
      averagePrice: Math.round(
        paddleDatabase.reduce((acc, p) => {
          const price = extractPrice(p.priceRange)
          return acc + price
        }, 0) / paddleDatabase.length
      ),
      surfaceDistribution: getSurfaceDistribution(),
      brandDistribution: getBrandDistribution(),
      priceRangeDistribution: getPriceRangeDistribution()
    }

    return NextResponse.json({
      trends,
      analytics,
      timestamp: new Date().toISOString(),
      success: true
    })
  } catch (error) {
    console.error('Error generating trend analysis:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

function extractPrice(priceRange: string): number {
  const numbers = priceRange.match(/\\d+/g)
  return numbers ? parseInt(numbers[0]) : 0
}

function getSurfaceDistribution() {
  const distribution: Record<string, number> = {}
  paddleDatabase.forEach(paddle => {
    distribution[paddle.surface] = (distribution[paddle.surface] || 0) + 1
  })
  return distribution
}

function getBrandDistribution() {
  const distribution: Record<string, number> = {}
  paddleDatabase.forEach(paddle => {
    distribution[paddle.brand] = (distribution[paddle.brand] || 0) + 1
  })
  return distribution
}

function getPriceRangeDistribution() {
  const distribution = {
    budget: 0,     // < $100
    midRange: 0,   // $100-200
    premium: 0     // > $200
  }
  
  paddleDatabase.forEach(paddle => {
    const price = extractPrice(paddle.priceRange)
    if (price < 100) distribution.budget++
    else if (price <= 200) distribution.midRange++
    else distribution.premium++
  })
  
  return distribution
}