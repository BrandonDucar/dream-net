import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { ResponseLogger } from "@/components/response-logger";
import { cookies } from "next/headers";
import { ReadyNotifier } from "@/components/ready-notifier";
import FarcasterWrapper from "@/components/FarcasterWrapper";

const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const requestId = cookies().get("x-request-id")?.value;

  return (
        <html lang="en">
          <head>
            {requestId && <meta name="x-request-id" content={requestId} />}
          </head>
          <body
            className={`${geistSans.variable} ${geistMono.variable} antialiased`}
          >
            {/* Do not remove this component, we use it to notify the parent that the mini-app is ready */}
            <ReadyNotifier />
            
      <FarcasterWrapper>
        {children}
      </FarcasterWrapper>
      
            <ResponseLogger />
          </body>
        </html>
      );
}

export const metadata: Metadata = {
        title: {
          default: 'PicklePaddle Intelligence - AI Paddle Recommendations & Expert Analysis',
          template: '%s | PicklePaddle Intelligence'
        },
        description: "Find your perfect pickleball paddle with AI-powered recommendations. Expert reviews, technical specs, geofencing store locator, and professional insights for 20+ top brands.",
        keywords: ['pickleball paddle', 'paddle recommendations', 'pickleball gear', 'AI paddle selection', 'USAP approved paddles', 'paddle comparison', 'professional pickleball equipment', 'paddle database', 'KEWCoR rating'],
        authors: [{ name: 'PicklePaddle Intelligence' }],
        creator: 'PicklePaddle Intelligence',
        publisher: 'PicklePaddle Intelligence',
        category: 'Sports Equipment',
        openGraph: {
          title: 'PicklePaddle Intelligence - AI Paddle Recommendations',
          description: 'Find your perfect pickleball paddle with AI-powered recommendations, expert reviews, and technical analysis.',
          type: 'website',
          locale: 'en_US',
          siteName: 'PicklePaddle Intelligence'
        },
        twitter: {
          card: 'summary_large_image',
          title: 'PicklePaddle Intelligence - AI Paddle Recommendations',
          description: 'Find your perfect pickleball paddle with AI-powered recommendations and expert analysis.',
          creator: '@picklepaddle'
        },
        robots: {
          index: true,
          follow: true,
          googleBot: {
            index: true,
            follow: true,
            'max-video-preview': -1,
            'max-image-preview': 'large',
            'max-snippet': -1
          }
        },
        other: { "fc:frame": JSON.stringify({"version":"next","imageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_f657913b-9eef-4276-a581-89a484364437-NTzAiyD1znsvBdo57DR2YKkNt5RXPa","button":{"title":"Open with Ohara","action":{"type":"launch_frame","name":"PicklePaddle Intelligence","url":"https://for-element-661.app.ohara.ai","splashImageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/farcaster/splash_images/splash_image1.svg","splashBackgroundColor":"#ffffff"}}}
        ) }
    };
