'use client'
import { useState, useEffect } from 'react'
import { PaddleDatabase } from '@/components/PaddleDatabase'
import { PaddleMatchmaker } from '@/components/PaddleMatchmaker'
import { CoachWelcome } from '@/components/CoachWelcome'
import { ReviewsHub } from '@/components/ReviewsHub'
import { MarketplaceHub } from '@/components/MarketplaceHub'
import { PriceTracker } from '@/components/PriceTracker'
import { PaddleScanner } from '@/components/PaddleScanner'
import { PerformanceDashboard } from '@/components/PerformanceDashboard'
import { ProPlayerIntelligence } from '@/components/ProPlayerIntelligence'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type View = 'welcome' | 'matchmaker' | 'database' | 'reviews' | 'marketplace' | 'prices' | 'scanner' | 'performance' | 'pro-intel'

export default function Page() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [currentView, setCurrentView] = useState<View>('welcome')

  const renderView = () => {
    switch (currentView) {
      case 'welcome':
        return <CoachWelcome onStartMatchmaker={() => setCurrentView('matchmaker')} />
      case 'matchmaker':
        return <PaddleMatchmaker onBackToWelcome={() => setCurrentView('welcome')} />
      case 'database':
        return <PaddleDatabase onBackToWelcome={() => setCurrentView('welcome')} />
      case 'reviews':
        return <ReviewsHub onBackToWelcome={() => setCurrentView('welcome')} />
      case 'marketplace':
        return <MarketplaceHub onBackToWelcome={() => setCurrentView('welcome')} />
      case 'prices':
        return <PriceTracker onBackToWelcome={() => setCurrentView('welcome')} />
      case 'scanner':
        return <PaddleScanner onBackToWelcome={() => setCurrentView('welcome')} />
      case 'performance':
        return <PerformanceDashboard onBackToWelcome={() => setCurrentView('welcome')} />
      case 'pro-intel':
        return <ProPlayerIntelligence onBackToWelcome={() => setCurrentView('welcome')} />
      default:
        return <CoachWelcome onStartMatchmaker={() => setCurrentView('matchmaker')} />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-blue-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8 pt-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="text-4xl">🏓</div>
            <h1 className="text-4xl font-bold text-gray-800">PicklePaddle</h1>
          </div>
          <p className="text-lg text-gray-600 mb-6">The Ultimate Pickleball Equipment Platform</p>
          
          {/* Navigation */}
          <div className="space-y-4">
            {/* Core Features */}
            <div className="flex flex-wrap justify-center gap-2">
              <Button
                variant={currentView === 'welcome' ? 'default' : 'outline'}
                onClick={() => setCurrentView('welcome')}
                className="flex items-center gap-1 text-xs px-3 py-2"
              >
                🎯 Coach Hub
              </Button>
              <Button
                variant={currentView === 'matchmaker' ? 'default' : 'outline'}
                onClick={() => setCurrentView('matchmaker')}
                className="flex items-center gap-1 text-xs px-3 py-2"
              >
                🚀 AI Matchmaker
              </Button>
              <Button
                variant={currentView === 'database' ? 'default' : 'outline'}
                onClick={() => setCurrentView('database')}
                className="flex items-center gap-1 text-xs px-3 py-2"
              >
                📚 Database
              </Button>
              <Button
                variant={currentView === 'scanner' ? 'default' : 'outline'}
                onClick={() => setCurrentView('scanner')}
                className="flex items-center gap-1 text-xs px-3 py-2"
              >
                📷 AI Scanner
              </Button>
            </div>

            {/* Community & Commerce */}
            <div className="flex flex-wrap justify-center gap-2">
              <Button
                variant={currentView === 'reviews' ? 'default' : 'outline'}
                onClick={() => setCurrentView('reviews')}
                className="flex items-center gap-1 text-xs px-3 py-2"
              >
                💬 Reviews
              </Button>
              <Button
                variant={currentView === 'marketplace' ? 'default' : 'outline'}
                onClick={() => setCurrentView('marketplace')}
                className="flex items-center gap-1 text-xs px-3 py-2"
              >
                🛒 Marketplace
              </Button>
              <Button
                variant={currentView === 'prices' ? 'default' : 'outline'}
                onClick={() => setCurrentView('prices')}
                className="flex items-center gap-1 text-xs px-3 py-2"
              >
                📊 Price Tracker
              </Button>
            </div>

            {/* Analytics & Pro Data */}
            <div className="flex flex-wrap justify-center gap-2">
              <Button
                variant={currentView === 'performance' ? 'default' : 'outline'}
                onClick={() => setCurrentView('performance')}
                className="flex items-center gap-1 text-xs px-3 py-2"
              >
                📈 Performance
              </Button>
              <Button
                variant={currentView === 'pro-intel' ? 'default' : 'outline'}
                onClick={() => setCurrentView('pro-intel')}
                className="flex items-center gap-1 text-xs px-3 py-2"
              >
                🏆 Pro Intel
              </Button>
            </div>
          </div>
        </div>

        {/* Current View */}
        {renderView()}
      </div>
    </div>
  )
}