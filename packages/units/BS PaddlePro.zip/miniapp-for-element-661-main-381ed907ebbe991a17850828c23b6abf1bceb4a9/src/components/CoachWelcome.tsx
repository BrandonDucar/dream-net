'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

interface CoachWelcomeProps {
  onStartMatchmaker: () => void
}

export function CoachWelcome({ onStartMatchmaker }: CoachWelcomeProps) {
  return (
    <div className="space-y-6">
      {/* Coach Introduction */}
      <Card className="bg-white border-l-4 border-l-emerald-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-2xl">
            <div className="text-3xl">👨‍🏫</div>
            Welcome to Your Paddle Coach
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-lg text-gray-700">
            I'm here to cut through the paddle hype and help you find gear that actually fits your game.
          </p>
          <p className="text-gray-600">
            With 200+ paddles in my database and years of coaching experience, I'll recommend paddles based on 
            <strong> how you actually play</strong> - not marketing promises.
          </p>
          
          <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-l-blue-400">
            <h4 className="font-semibold text-blue-900 mb-2">🎯 What Makes This Different</h4>
            <ul className="text-blue-800 space-y-1 text-sm">
              <li>• No sales pressure - just honest recommendations</li>
              <li>• Focus on play style fit over brand popularity</li>
              <li>• Consider your arm health and sensitivity</li>
              <li>• Real-world budget considerations</li>
            </ul>
          </div>

          <div className="pt-4">
            <Button 
              onClick={onStartMatchmaker}
              className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700 text-lg py-6 px-8"
            >
              🔍 Find My Perfect Paddle
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="text-center p-6">
            <div className="text-3xl font-bold text-emerald-600">200+</div>
            <div className="text-gray-600">Paddles Analyzed</div>
            <Badge className="mt-2" variant="outline">Updated 2024</Badge>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="text-center p-6">
            <div className="text-3xl font-bold text-blue-600">10+</div>
            <div className="text-gray-600">Major Brands</div>
            <Badge className="mt-2" variant="outline">USAP Approved</Badge>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="text-center p-6">
            <div className="text-3xl font-bold text-purple-600">5</div>
            <div className="text-gray-600">Minutes to Results</div>
            <Badge className="mt-2" variant="outline">Quick Quiz</Badge>
          </CardContent>
        </Card>
      </div>

      {/* Philosophy */}
      <Card className="bg-gray-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="text-2xl">💡</div>
            My Coaching Philosophy
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-gray-800 mb-2">✅ What I Focus On</h4>
              <ul className="text-gray-600 space-y-1 text-sm">
                <li>• Your actual skill level and goals</li>
                <li>• Play style: power vs control preference</li>
                <li>• Physical considerations (arm sensitivity)</li>
                <li>• Realistic budget constraints</li>
                <li>• Singles vs doubles focus</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-800 mb-2">❌ What I Ignore</h4>
              <ul className="text-gray-600 space-y-1 text-sm">
                <li>• Marketing hype and buzzwords</li>
                <li>• "Pro player endorsements"</li>
                <li>• Latest trends and gimmicks</li>
                <li>• One-size-fits-all recommendations</li>
                <li>• Pushing expensive gear unnecessarily</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}