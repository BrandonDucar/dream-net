'use client'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { paddleDatabase } from '@/lib/paddleData'
import type { Paddle } from '@/types/paddle'

interface MarketplaceListing {
  id: string
  sellerId: string
  sellerName: string
  sellerRating: number
  paddleId: string
  paddleBrand: string
  paddleModel: string
  condition: 'new' | 'like-new' | 'excellent' | 'good' | 'fair'
  price: number
  originalPrice: number
  description: string
  images: string[]
  monthsUsed: number
  location: string
  shipping: boolean
  localPickup: boolean
  datePosted: string
  status: 'active' | 'sold' | 'pending'
  views: number
  watchers: number
}

interface MarketplaceHubProps {
  onBackToWelcome: () => void
}

export function MarketplaceHub({ onBackToWelcome }: MarketplaceHubProps) {
  const [listings, setListings] = useState<MarketplaceListing[]>([])
  const [filterCondition, setFilterCondition] = useState<string>('all')
  const [filterPrice, setFilterPrice] = useState<string>('all')
  const [searchTerm, setSearchTerm] = useState('')
  const [sortBy, setSortBy] = useState('newest')
  const [activeTab, setActiveTab] = useState('buy')

  // Mock marketplace data - In production this would come from SpacetimeDB
  useEffect(() => {
    const mockListings: MarketplaceListing[] = [
      {
        id: '1',
        sellerId: 'user123',
        sellerName: 'PicklePro2024',
        sellerRating: 4.8,
        paddleId: 'selkirk-vanguard-power-air',
        paddleBrand: 'Selkirk',
        paddleModel: 'Vanguard Power Air',
        condition: 'excellent',
        price: 160,
        originalPrice: 210,
        description: "Selling my Vanguard after upgrading to Labs 002. Still in excellent condition with minimal wear on the sweet spot. Includes original grip and edge guard.",
        images: ['https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400&h=400&fit=crop'],
        monthsUsed: 6,
        location: 'Austin, TX',
        shipping: true,
        localPickup: true,
        datePosted: '2024-01-20',
        status: 'active',
        views: 45,
        watchers: 8
      },
      {
        id: '2',
        sellerId: 'user456',
        sellerName: 'CoachSarah',
        sellerRating: 5.0,
        paddleId: 'joola-ben-johns-hyperion',
        paddleBrand: 'JOOLA',
        paddleModel: 'Ben Johns Hyperion CFS',
        condition: 'like-new',
        price: 195,
        originalPrice: 240,
        description: "Barely used Hyperion. Bought for tournaments but went with a different paddle. Maybe 10 hours of play time. Like getting a new paddle at a discount!",
        images: ['https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400&h=400&fit=crop'],
        monthsUsed: 1,
        location: 'Phoenix, AZ',
        shipping: true,
        localPickup: false,
        datePosted: '2024-01-18',
        status: 'active',
        views: 73,
        watchers: 15
      },
      {
        id: '3',
        sellerId: 'user789',
        sellerName: 'WeekendPlayer',
        sellerRating: 4.6,
        paddleId: 'paddletek-bantam-ts5-pro',
        paddleBrand: 'Paddletek',
        paddleModel: 'Bantam TS-5 Pro',
        condition: 'good',
        price: 95,
        originalPrice: 170,
        description: "Great beginner to intermediate paddle. Some surface wear but still plays well. Perfect for someone getting into the sport without spending too much.",
        images: ['https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400&h=400&fit=crop'],
        monthsUsed: 18,
        location: 'San Diego, CA',
        shipping: true,
        localPickup: true,
        datePosted: '2024-01-15',
        status: 'active',
        views: 28,
        watchers: 3
      },
      {
        id: '4',
        sellerId: 'user101',
        sellerName: 'TournamentTom',
        sellerRating: 4.9,
        paddleId: 'engage-pursuit-mx',
        paddleBrand: 'Engage',
        paddleModel: 'Pursuit MX 6.0',
        condition: 'excellent',
        price: 175,
        originalPrice: 210,
        description: "Tournament-tested paddle with incredible power. Upgrading to the new Engage model. Maintained professionally, still has tons of life left.",
        images: ['https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400&h=400&fit=crop'],
        monthsUsed: 8,
        location: 'Orlando, FL',
        shipping: true,
        localPickup: true,
        datePosted: '2024-01-12',
        status: 'active',
        views: 52,
        watchers: 11
      }
    ]
    setListings(mockListings)
  }, [])

  const filteredListings = listings
    .filter(listing => listing.status === 'active')
    .filter(listing => filterCondition === 'all' || listing.condition === filterCondition)
    .filter(listing => {
      if (filterPrice === 'all') return true
      const price = listing.price
      switch (filterPrice) {
        case 'under-100': return price < 100
        case '100-150': return price >= 100 && price <= 150
        case '150-200': return price >= 150 && price <= 200
        case 'over-200': return price > 200
        default: return true
      }
    })
    .filter(listing => {
      if (!searchTerm) return true
      const term = searchTerm.toLowerCase()
      return listing.paddleBrand.toLowerCase().includes(term) ||
             listing.paddleModel.toLowerCase().includes(term) ||
             listing.description.toLowerCase().includes(term)
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'newest': return new Date(b.datePosted).getTime() - new Date(a.datePosted).getTime()
        case 'oldest': return new Date(a.datePosted).getTime() - new Date(b.datePosted).getTime()
        case 'price-low': return a.price - b.price
        case 'price-high': return b.price - a.price
        case 'popular': return b.watchers - a.watchers
        default: return 0
      }
    })

  const conditionColors = {
    'new': 'bg-green-100 text-green-800',
    'like-new': 'bg-blue-100 text-blue-800',
    'excellent': 'bg-purple-100 text-purple-800',
    'good': 'bg-yellow-100 text-yellow-800',
    'fair': 'bg-gray-100 text-gray-800'
  }

  const renderStars = (rating: number) => {
    return '★'.repeat(Math.floor(rating)) + (rating % 1 > 0 ? '☆' : '') + '☆'.repeat(5 - Math.ceil(rating))
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <Card className="border-2">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            🛒 Paddle Marketplace
          </CardTitle>
          <p className="text-gray-600">Buy, sell, and trade pickleball paddles with the community</p>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="buy">🛍️ Buy Paddles</TabsTrigger>
              <TabsTrigger value="sell">💰 Sell Your Paddle</TabsTrigger>
              <TabsTrigger value="trade">🔄 Trade Center</TabsTrigger>
            </TabsList>

            <TabsContent value="buy" className="space-y-6">
              {/* Search and Filters */}
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                <div>
                  <Label>Search</Label>
                  <Input
                    placeholder="Search paddles..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                
                <div>
                  <Label>Condition</Label>
                  <Select value={filterCondition} onValueChange={setFilterCondition}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Conditions</SelectItem>
                      <SelectItem value="new">New</SelectItem>
                      <SelectItem value="like-new">Like New</SelectItem>
                      <SelectItem value="excellent">Excellent</SelectItem>
                      <SelectItem value="good">Good</SelectItem>
                      <SelectItem value="fair">Fair</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Price Range</Label>
                  <Select value={filterPrice} onValueChange={setFilterPrice}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Prices</SelectItem>
                      <SelectItem value="under-100">Under $100</SelectItem>
                      <SelectItem value="100-150">$100 - $150</SelectItem>
                      <SelectItem value="150-200">$150 - $200</SelectItem>
                      <SelectItem value="over-200">Over $200</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Sort By</Label>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="newest">Newest First</SelectItem>
                      <SelectItem value="oldest">Oldest First</SelectItem>
                      <SelectItem value="price-low">Price: Low to High</SelectItem>
                      <SelectItem value="price-high">Price: High to Low</SelectItem>
                      <SelectItem value="popular">Most Popular</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-end">
                  <Button variant="outline" className="w-full">
                    🔔 Set Alert
                  </Button>
                </div>
              </div>

              {/* Listings Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredListings.map(listing => (
                  <MarketplaceCard key={listing.id} listing={listing} conditionColors={conditionColors} renderStars={renderStars} />
                ))}
              </div>

              {filteredListings.length === 0 && (
                <Card>
                  <CardContent className="pt-6 text-center text-gray-500">
                    No paddles found matching your criteria.
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="sell" className="space-y-6">
              <SellPaddleForm onSubmit={(listing) => {
                const newListing: MarketplaceListing = {
                  ...listing,
                  id: Date.now().toString(),
                  datePosted: new Date().toISOString().split('T')[0],
                  status: 'active',
                  views: 0,
                  watchers: 0,
                  sellerId: 'current-user',
                  sellerName: 'You',
                  sellerRating: 5.0
                }
                setListings(prev => [newListing, ...prev])
                setActiveTab('buy')
              }} />
            </TabsContent>

            <TabsContent value="trade" className="space-y-6">
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-6xl mb-4">🔄</div>
                  <h3 className="text-xl font-semibold mb-2">Trade Center Coming Soon!</h3>
                  <p className="text-gray-600 mb-4">
                    Direct paddle trading, trade-in programs, and upgrade paths.
                  </p>
                  <Button variant="outline">
                    Join Waitlist
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <div className="text-center">
        <Button variant="outline" onClick={onBackToWelcome}>
          ← Back to Coach Hub
        </Button>
      </div>
    </div>
  )
}

function MarketplaceCard({ listing, conditionColors, renderStars }: { 
  listing: MarketplaceListing,
  conditionColors: Record<string, string>,
  renderStars: (rating: number) => string
}) {
  const savings = listing.originalPrice - listing.price
  const savingsPercent = Math.round((savings / listing.originalPrice) * 100)

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <div className="aspect-square bg-gray-100 relative">
        <img 
          src={listing.images[0]} 
          alt={`${listing.paddleBrand} ${listing.paddleModel}`}
          className="w-full h-full object-cover rounded-t-lg"
        />
        <Badge className={`absolute top-2 left-2 ${conditionColors[listing.condition]}`}>
          {listing.condition.replace('-', ' ')}
        </Badge>
        <Badge className="absolute top-2 right-2 bg-red-500 text-white">
          {savingsPercent}% off
        </Badge>
      </div>
      
      <CardContent className="pt-4">
        <div className="space-y-3">
          <div>
            <h3 className="font-semibold text-lg">
              {listing.paddleBrand} {listing.paddleModel}
            </h3>
            <p className="text-gray-600 text-sm">{listing.monthsUsed} months used</p>
          </div>

          <div className="flex justify-between items-center">
            <div>
              <div className="text-2xl font-bold text-green-600">${listing.price}</div>
              <div className="text-sm text-gray-500 line-through">${listing.originalPrice}</div>
            </div>
            <div className="text-right text-sm">
              <div className="text-red-600 font-semibold">Save ${savings}</div>
            </div>
          </div>

          <p className="text-gray-600 text-sm line-clamp-2">{listing.description}</p>

          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-1">
              <span className="text-yellow-500">{renderStars(listing.sellerRating)}</span>
              <span className="text-gray-600">({listing.sellerRating})</span>
            </div>
            <span className="text-gray-600">{listing.location}</span>
          </div>

          <div className="flex gap-1 text-xs">
            {listing.shipping && <Badge variant="outline">📦 Ships</Badge>}
            {listing.localPickup && <Badge variant="outline">📍 Local</Badge>}
          </div>

          <div className="flex gap-2">
            <Button className="flex-1" size="sm">
              💬 Contact Seller
            </Button>
            <Button variant="outline" size="sm">
              ❤️ {listing.watchers}
            </Button>
          </div>

          <div className="text-xs text-gray-500 text-center">
            {listing.views} views • Posted {new Date(listing.datePosted).toLocaleDateString()}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function SellPaddleForm({ onSubmit }: { onSubmit: (listing: Partial<MarketplaceListing>) => void }) {
  const [formData, setFormData] = useState({
    paddleId: '',
    condition: '',
    price: '',
    originalPrice: '',
    description: '',
    monthsUsed: '1',
    location: '',
    shipping: true,
    localPickup: true
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const paddle = paddleDatabase.find(p => p.id === formData.paddleId)
    if (paddle) {
      onSubmit({
        paddleId: formData.paddleId,
        paddleBrand: paddle.brand,
        paddleModel: paddle.model,
        condition: formData.condition as any,
        price: parseInt(formData.price),
        originalPrice: parseInt(formData.originalPrice),
        description: formData.description,
        monthsUsed: parseInt(formData.monthsUsed),
        location: formData.location,
        shipping: formData.shipping,
        localPickup: formData.localPickup,
        images: ['https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400&h=400&fit=crop']
      })
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>List Your Paddle</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Paddle</Label>
              <Select value={formData.paddleId} onValueChange={(value) => setFormData(prev => ({ ...prev, paddleId: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select Your Paddle" />
                </SelectTrigger>
                <SelectContent>
                  {paddleDatabase.map(paddle => (
                    <SelectItem key={paddle.id} value={paddle.id}>
                      {paddle.brand} {paddle.model}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Condition</Label>
              <Select value={formData.condition} onValueChange={(value) => setFormData(prev => ({ ...prev, condition: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Condition" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="new">New (Never Used)</SelectItem>
                  <SelectItem value="like-new">Like New (1-2 uses)</SelectItem>
                  <SelectItem value="excellent">Excellent (Minor wear)</SelectItem>
                  <SelectItem value="good">Good (Moderate wear)</SelectItem>
                  <SelectItem value="fair">Fair (Heavy wear)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label>Selling Price ($)</Label>
              <Input
                type="number"
                value={formData.price}
                onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                placeholder="150"
                required
              />
            </div>

            <div>
              <Label>Original Price ($)</Label>
              <Input
                type="number"
                value={formData.originalPrice}
                onChange={(e) => setFormData(prev => ({ ...prev, originalPrice: e.target.value }))}
                placeholder="200"
                required
              />
            </div>

            <div>
              <Label>Months Used</Label>
              <Input
                type="number"
                min="0"
                max="60"
                value={formData.monthsUsed}
                onChange={(e) => setFormData(prev => ({ ...prev, monthsUsed: e.target.value }))}
                required
              />
            </div>
          </div>

          <div>
            <Label>Location (City, State)</Label>
            <Input
              value={formData.location}
              onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
              placeholder="Austin, TX"
              required
            />
          </div>

          <div>
            <Label>Description</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Describe the paddle condition, why you're selling, etc."
              rows={4}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="shipping"
                checked={formData.shipping}
                onChange={(e) => setFormData(prev => ({ ...prev, shipping: e.target.checked }))}
              />
              <Label htmlFor="shipping">📦 Willing to ship</Label>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="pickup"
                checked={formData.localPickup}
                onChange={(e) => setFormData(prev => ({ ...prev, localPickup: e.target.checked }))}
              />
              <Label htmlFor="pickup">📍 Local pickup available</Label>
            </div>
          </div>

          <Button type="submit" className="w-full">
            🚀 List My Paddle
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}