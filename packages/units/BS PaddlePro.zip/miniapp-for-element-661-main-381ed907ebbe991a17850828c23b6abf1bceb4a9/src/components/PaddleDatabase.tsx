'use client'

import { useState, useMemo } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { paddleDatabase } from '@/lib/paddleData'
import type { Paddle } from '@/types/paddle'

interface PaddleDatabaseProps {
  onBackToWelcome: () => void
}

export function PaddleDatabase({ onBackToWelcome }: PaddleDatabaseProps) {
  const [searchTerm, setSearchTerm] = useState<string>('')
  const [brandFilter, setBrandFilter] = useState<string>('all')
  const [surfaceFilter, setSurfaceFilter] = useState<string>('all')
  const [priceFilter, setPriceFilter] = useState<string>('all')
  const [sortBy, setSortBy] = useState<string>('name')

  const brands = useMemo(() => {
    const brandSet = new Set(paddleDatabase.map(p => p.brand))
    return Array.from(brandSet).sort()
  }, [])

  const filteredPaddles = useMemo(() => {
    let filtered = paddleDatabase.filter(paddle => {
      const matchesSearch = paddle.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          paddle.model.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesBrand = brandFilter === 'all' || paddle.brand === brandFilter
      const matchesSurface = surfaceFilter === 'all' || paddle.surface === surfaceFilter
      
      let matchesPrice = true
      if (priceFilter !== 'all') {
        const priceRange = paddle.priceRange.toLowerCase()
        switch (priceFilter) {
          case 'budget':
            matchesPrice = priceRange.includes('$50') || priceRange.includes('$60') || priceRange.includes('$70') || priceRange.includes('$80') || priceRange.includes('$90')
            break
          case 'mid':
            matchesPrice = priceRange.includes('$100') || priceRange.includes('$110') || priceRange.includes('$120') || priceRange.includes('$130') || priceRange.includes('$140') || priceRange.includes('$150') || priceRange.includes('$160') || priceRange.includes('$170') || priceRange.includes('$180') || priceRange.includes('$190')
            break
          case 'premium':
            matchesPrice = priceRange.includes('$200') || priceRange.includes('$250') || priceRange.includes('$300')
            break
        }
      }
      
      return matchesSearch && matchesBrand && matchesSurface && matchesPrice
    })

    // Sort results
    switch (sortBy) {
      case 'name':
        filtered.sort((a, b) => `${a.brand} ${a.model}`.localeCompare(`${b.brand} ${b.model}`))
        break
      case 'brand':
        filtered.sort((a, b) => a.brand.localeCompare(b.brand) || a.model.localeCompare(b.model))
        break
      case 'power':
        filtered.sort((a, b) => b.powerRating - a.powerRating)
        break
      case 'control':
        filtered.sort((a, b) => b.controlRating - a.controlRating)
        break
      case 'year':
        filtered.sort((a, b) => b.year - a.year)
        break
    }

    return filtered
  }, [searchTerm, brandFilter, surfaceFilter, priceFilter, sortBy])

  const clearFilters = () => {
    setSearchTerm('')
    setBrandFilter('all')
    setSurfaceFilter('all')
    setPriceFilter('all')
    setSortBy('name')
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" onClick={onBackToWelcome}>
          ← Back
        </Button>
        <div>
          <h2 className="text-2xl font-bold">Paddle Database</h2>
          <p className="text-gray-600">{paddleDatabase.length} paddles analyzed and categorized</p>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>🔍 Search & Filter</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search */}
          <div>
            <Input
              placeholder="Search by brand or model..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full"
            />
          </div>

          {/* Filters Row */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Select value={brandFilter} onValueChange={setBrandFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All Brands" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Brands</SelectItem>
                  {brands.map(brand => (
                    <SelectItem key={brand} value={brand}>{brand}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Select value={surfaceFilter} onValueChange={setSurfaceFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All Surfaces" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Surfaces</SelectItem>
                  <SelectItem value="Carbon Fiber">Carbon Fiber</SelectItem>
                  <SelectItem value="Raw Carbon">Raw Carbon</SelectItem>
                  <SelectItem value="Fiberglass">Fiberglass</SelectItem>
                  <SelectItem value="Kevlar">Kevlar</SelectItem>
                  <SelectItem value="Hybrid">Hybrid</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Select value={priceFilter} onValueChange={setPriceFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All Prices" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Prices</SelectItem>
                  <SelectItem value="budget">Under $100</SelectItem>
                  <SelectItem value="mid">$100 - $200</SelectItem>
                  <SelectItem value="premium">$200+</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger>
                  <SelectValue placeholder="Sort By" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Name A-Z</SelectItem>
                  <SelectItem value="brand">Brand</SelectItem>
                  <SelectItem value="power">Power Rating</SelectItem>
                  <SelectItem value="control">Control Rating</SelectItem>
                  <SelectItem value="year">Newest</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="text-sm text-gray-600">
              Showing {filteredPaddles.length} of {paddleDatabase.length} paddles
            </div>
            <Button variant="ghost" size="sm" onClick={clearFilters}>
              Clear Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {filteredPaddles.map((paddle, index) => (
          <Card key={`${paddle.brand}-${paddle.model}-${index}`} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg">
                    {paddle.brand} {paddle.model}
                  </CardTitle>
                  <p className="text-gray-600">{paddle.priceRange}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant="outline" className="text-xs">
                      {paddle.year}
                    </Badge>
                    {paddle.usapApproved && (
                      <Badge variant="default" className="text-xs">
                        USAP
                      </Badge>
                    )}
                    {paddle.armFriendly && (
                      <Badge variant="secondary" className="text-xs">
                        Arm-Friendly
                      </Badge>
                    )}
                  </div>
                </div>
                
                <div className="text-center">
                  <div className="text-2xl font-bold text-emerald-600">
                    {Math.round((paddle.powerRating + paddle.controlRating + paddle.spinRating) / 3 * 20)}
                  </div>
                  <div className="text-xs text-gray-500">Overall</div>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              {/* Ratings */}
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div className="text-center">
                  <div className="font-medium text-gray-800">Power</div>
                  <div className="flex justify-center">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className={i < paddle.powerRating ? 'text-red-500' : 'text-gray-300'}>⚡</span>
                    ))}
                  </div>
                </div>
                <div className="text-center">
                  <div className="font-medium text-gray-800">Control</div>
                  <div className="flex justify-center">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className={i < paddle.controlRating ? 'text-blue-500' : 'text-gray-300'}>🎯</span>
                    ))}
                  </div>
                </div>
                <div className="text-center">
                  <div className="font-medium text-gray-800">Spin</div>
                  <div className="flex justify-center">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className={i < paddle.spinRating ? 'text-green-500' : 'text-gray-300'}>🌪️</span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Specs */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs bg-gray-50 p-3 rounded-lg">
                <div>
                  <div className="font-medium text-gray-800">Surface</div>
                  <div className="text-gray-600">{paddle.surface}</div>
                </div>
                <div>
                  <div className="font-medium text-gray-800">Shape</div>
                  <div className="text-gray-600">{paddle.shape}</div>
                </div>
                <div>
                  <div className="font-medium text-gray-800">Core</div>
                  <div className="text-gray-600">{paddle.core}</div>
                </div>
                <div>
                  <div className="font-medium text-gray-800">Weight</div>
                  <div className="text-gray-600">{paddle.weight}</div>
                </div>
              </div>

              {/* Best For */}
              <div className="text-sm">
                <div className="font-medium text-gray-800 mb-1">Best For:</div>
                <div className="text-gray-600">{paddle.bestFor}</div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredPaddles.length === 0 && (
        <Card>
          <CardContent className="text-center p-12">
            <div className="text-4xl mb-4">🔍</div>
            <h3 className="text-xl font-semibold mb-2">No Paddles Found</h3>
            <p className="text-gray-600 mb-4">Try adjusting your search or filter criteria</p>
            <Button onClick={clearFilters}>Clear All Filters</Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}