'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Badge } from '@/components/ui/badge'
import { paddleDatabase, getRecommendations } from '@/lib/paddleData'
import type { UserPreferences, PaddleRecommendation } from '@/types/paddle'

interface PaddleMatchmakerProps {
  onBackToWelcome: () => void
}

export function PaddleMatchmaker({ onBackToWelcome }: PaddleMatchmakerProps) {
  const [step, setStep] = useState<number>(1)
  const [preferences, setPreferences] = useState<Partial<UserPreferences>>({})
  const [recommendations, setRecommendations] = useState<PaddleRecommendation[]>([])
  const [isLoading, setIsLoading] = useState<boolean>(false)

  const handlePreferenceChange = (key: keyof UserPreferences, value: string) => {
    setPreferences(prev => ({ ...prev, [key]: value }))
  }

  const nextStep = () => {
    setStep(prev => prev + 1)
  }

  const generateRecommendations = async () => {
    setIsLoading(true)
    // Simulate analysis time for better UX
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    const results = getRecommendations(preferences as UserPreferences)
    setRecommendations(results)
    setIsLoading(false)
    setStep(6)
  }

  const resetQuiz = () => {
    setStep(1)
    setPreferences({})
    setRecommendations([])
  }

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <Card>
            <CardHeader>
              <CardTitle>🎯 What's your skill level?</CardTitle>
              <p className="text-gray-600">Be honest - this affects everything from paddle weight to forgiveness.</p>
            </CardHeader>
            <CardContent>
              <RadioGroup 
                value={preferences.skillLevel || ''} 
                onValueChange={(value) => handlePreferenceChange('skillLevel', value)}
                className="space-y-4"
              >
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="beginner" id="beginner" />
                  <Label htmlFor="beginner" className="flex-1 cursor-pointer">
                    <div className="font-medium">Beginner (0-2 years)</div>
                    <div className="text-sm text-gray-500">Still learning basic strokes and positioning</div>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="intermediate" id="intermediate" />
                  <Label htmlFor="intermediate" className="flex-1 cursor-pointer">
                    <div className="font-medium">Intermediate (2-5 years)</div>
                    <div className="text-sm text-gray-500">Consistent strokes, understanding strategy</div>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="advanced" id="advanced" />
                  <Label htmlFor="advanced" className="flex-1 cursor-pointer">
                    <div className="font-medium">Advanced (5+ years)</div>
                    <div className="text-sm text-gray-500">Competitive play, advanced techniques</div>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="tournament" id="tournament" />
                  <Label htmlFor="tournament" className="flex-1 cursor-pointer">
                    <div className="font-medium">Tournament Player</div>
                    <div className="text-sm text-gray-500">Competitive tournaments, peak performance focus</div>
                  </Label>
                </div>
              </RadioGroup>
              
              <Button 
                onClick={nextStep} 
                disabled={!preferences.skillLevel}
                className="w-full mt-6"
              >
                Continue →
              </Button>
            </CardContent>
          </Card>
        )

      case 2:
        return (
          <Card>
            <CardHeader>
              <CardTitle>🏓 Singles or doubles focus?</CardTitle>
              <p className="text-gray-600">This affects paddle shape and weight recommendations.</p>
            </CardHeader>
            <CardContent>
              <RadioGroup 
                value={preferences.playStyle || ''} 
                onValueChange={(value) => handlePreferenceChange('playStyle', value)}
                className="space-y-4"
              >
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="singles" id="singles" />
                  <Label htmlFor="singles" className="flex-1 cursor-pointer">
                    <div className="font-medium">Primarily Singles</div>
                    <div className="text-sm text-gray-500">Need power and reach for court coverage</div>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="doubles" id="doubles" />
                  <Label htmlFor="doubles" className="flex-1 cursor-pointer">
                    <div className="font-medium">Primarily Doubles</div>
                    <div className="text-sm text-gray-500">Focus on quick hands and net play</div>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="both" id="both" />
                  <Label htmlFor="both" className="flex-1 cursor-pointer">
                    <div className="font-medium">Both Equally</div>
                    <div className="text-sm text-gray-500">Need versatility for different games</div>
                  </Label>
                </div>
              </RadioGroup>
              
              <Button 
                onClick={nextStep} 
                disabled={!preferences.playStyle}
                className="w-full mt-6"
              >
                Continue →
              </Button>
            </CardContent>
          </Card>
        )

      case 3:
        return (
          <Card>
            <CardHeader>
              <CardTitle>⚡ Power vs Control preference?</CardTitle>
              <p className="text-gray-600">This is the biggest factor in paddle selection.</p>
            </CardHeader>
            <CardContent>
              <RadioGroup 
                value={preferences.powerVsControl || ''} 
                onValueChange={(value) => handlePreferenceChange('powerVsControl', value)}
                className="space-y-4"
              >
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="power" id="power" />
                  <Label htmlFor="power" className="flex-1 cursor-pointer">
                    <div className="font-medium">Power First</div>
                    <div className="text-sm text-gray-500">I want to drive the ball and end points quickly</div>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="balanced" id="balanced" />
                  <Label htmlFor="balanced" className="flex-1 cursor-pointer">
                    <div className="font-medium">Balanced</div>
                    <div className="text-sm text-gray-500">I want good power but also precision</div>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="control" id="control" />
                  <Label htmlFor="control" className="flex-1 cursor-pointer">
                    <div className="font-medium">Control First</div>
                    <div className="text-sm text-gray-500">I prefer placement and consistency over power</div>
                  </Label>
                </div>
              </RadioGroup>
              
              <Button 
                onClick={nextStep} 
                disabled={!preferences.powerVsControl}
                className="w-full mt-6"
              >
                Continue →
              </Button>
            </CardContent>
          </Card>
        )

      case 4:
        return (
          <Card>
            <CardHeader>
              <CardTitle>🏥 Any arm or elbow sensitivity?</CardTitle>
              <p className="text-gray-600">Honesty here can save you from injury and frustration.</p>
            </CardHeader>
            <CardContent>
              <RadioGroup 
                value={preferences.armSensitivity || ''} 
                onValueChange={(value) => handlePreferenceChange('armSensitivity', value)}
                className="space-y-4"
              >
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="none" id="none" />
                  <Label htmlFor="none" className="flex-1 cursor-pointer">
                    <div className="font-medium">No Issues</div>
                    <div className="text-sm text-gray-500">No arm, elbow, or shoulder problems</div>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="mild" id="mild" />
                  <Label htmlFor="mild" className="flex-1 cursor-pointer">
                    <div className="font-medium">Mild Sensitivity</div>
                    <div className="text-sm text-gray-500">Occasional soreness after long sessions</div>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="moderate" id="moderate" />
                  <Label htmlFor="moderate" className="flex-1 cursor-pointer">
                    <div className="font-medium">Moderate Issues</div>
                    <div className="text-sm text-gray-500">History of tennis elbow or arm problems</div>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="high" id="high" />
                  <Label htmlFor="high" className="flex-1 cursor-pointer">
                    <div className="font-medium">High Sensitivity</div>
                    <div className="text-sm text-gray-500">Current arm problems, need maximum comfort</div>
                  </Label>
                </div>
              </RadioGroup>
              
              <Button 
                onClick={nextStep} 
                disabled={!preferences.armSensitivity}
                className="w-full mt-6"
              >
                Continue →
              </Button>
            </CardContent>
          </Card>
        )

      case 5:
        return (
          <Card>
            <CardHeader>
              <CardTitle>💰 What's your budget range?</CardTitle>
              <p className="text-gray-600">I'll find the best value in your price range - expensive doesn't always mean better.</p>
            </CardHeader>
            <CardContent>
              <RadioGroup 
                value={preferences.budget || ''} 
                onValueChange={(value) => handlePreferenceChange('budget', value)}
                className="space-y-4"
              >
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="budget" id="budget" />
                  <Label htmlFor="budget" className="flex-1 cursor-pointer">
                    <div className="font-medium">Under $100</div>
                    <div className="text-sm text-gray-500">Great starter paddles that won't break the bank</div>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="mid" id="mid" />
                  <Label htmlFor="mid" className="flex-1 cursor-pointer">
                    <div className="font-medium">$100 - $200</div>
                    <div className="text-sm text-gray-500">Sweet spot for performance and value</div>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="premium" id="premium" />
                  <Label htmlFor="premium" className="flex-1 cursor-pointer">
                    <div className="font-medium">$200+</div>
                    <div className="text-sm text-gray-500">Premium materials and latest technology</div>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="unlimited" id="unlimited" />
                  <Label htmlFor="unlimited" className="flex-1 cursor-pointer">
                    <div className="font-medium">Price No Object</div>
                    <div className="text-sm text-gray-500">Just find me the best paddle for my game</div>
                  </Label>
                </div>
              </RadioGroup>
              
              <Button 
                onClick={generateRecommendations} 
                disabled={!preferences.budget}
                className="w-full mt-6 bg-emerald-600 hover:bg-emerald-700"
              >
                Get My Recommendations 🎯
              </Button>
            </CardContent>
          </Card>
        )

      case 6:
        return (
          <div className="space-y-6">
            {isLoading ? (
              <Card>
                <CardContent className="text-center p-12">
                  <div className="animate-spin text-4xl mb-4">🏓</div>
                  <h3 className="text-xl font-semibold mb-2">Analyzing Your Game...</h3>
                  <p className="text-gray-600">Matching you with the perfect paddle based on your preferences</p>
                </CardContent>
              </Card>
            ) : (
              <>
                <Card className="bg-emerald-50 border-emerald-200">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-emerald-800">
                      <div className="text-2xl">🎯</div>
                      Your Perfect Paddle Matches
                    </CardTitle>
                    <p className="text-emerald-700">Based on your preferences, here are my top recommendations:</p>
                  </CardHeader>
                </Card>

                {recommendations.map((rec, index) => (
                  <Card key={index} className={index === 0 ? 'border-2 border-emerald-500' : ''}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant={index === 0 ? 'default' : 'secondary'}>
                              {index === 0 ? '🏆 Top Pick' : `#${index + 1}`}
                            </Badge>
                            {rec.category === 'safe' && <Badge variant="outline">Safe Choice</Badge>}
                            {rec.category === 'performance' && <Badge variant="outline">Performance</Badge>}
                          </div>
                          <CardTitle className="text-xl">
                            {rec.paddle.brand} {rec.paddle.model}
                          </CardTitle>
                          <p className="text-gray-600">{rec.paddle.priceRange}</p>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-emerald-600">{rec.matchScore}%</div>
                          <div className="text-sm text-gray-500">Match</div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-gray-700">{rec.reason}</p>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <div className="font-medium text-gray-800">Surface</div>
                          <div className="text-gray-600">{rec.paddle.surface}</div>
                        </div>
                        <div>
                          <div className="font-medium text-gray-800">Shape</div>
                          <div className="text-gray-600">{rec.paddle.shape}</div>
                        </div>
                        <div>
                          <div className="font-medium text-gray-800">Core</div>
                          <div className="text-gray-600">{rec.paddle.core}</div>
                        </div>
                        <div>
                          <div className="font-medium text-gray-800">Weight</div>
                          <div className="text-gray-600">{rec.paddle.weight}</div>
                        </div>
                      </div>

                      <div className="flex gap-4 text-sm">
                        <div className="flex items-center gap-1">
                          <div className="font-medium">Power:</div>
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <span key={i} className={i < rec.paddle.powerRating ? 'text-red-500' : 'text-gray-300'}>⚡</span>
                            ))}
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          <div className="font-medium">Control:</div>
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <span key={i} className={i < rec.paddle.controlRating ? 'text-blue-500' : 'text-gray-300'}>🎯</span>
                            ))}
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          <div className="font-medium">Spin:</div>
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <span key={i} className={i < rec.paddle.spinRating ? 'text-green-500' : 'text-gray-300'}>🌪️</span>
                            ))}
                          </div>
                        </div>
                      </div>

                      {rec.paddle.armFriendly && (
                        <div className="bg-blue-50 p-3 rounded-lg border-l-4 border-l-blue-400">
                          <div className="font-medium text-blue-900">🏥 Arm-Friendly Design</div>
                          <div className="text-blue-800 text-sm">Reduced vibration and shock for comfort</div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}

                <div className="flex flex-col sm:flex-row gap-4">
                  <Button onClick={resetQuiz} variant="outline" className="flex-1">
                    🔄 Take Quiz Again
                  </Button>
                  <Button onClick={onBackToWelcome} className="flex-1">
                    🏠 Back to Coach Hub
                  </Button>
                </div>
              </>
            )}
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="ghost" onClick={onBackToWelcome}>
          ← Back
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-bold">Paddle Matchmaker</h2>
            {step < 6 && (
              <Badge variant="outline">
                Step {step} of 5
              </Badge>
            )}
          </div>
          {step < 6 && (
            <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
              <div 
                className="bg-emerald-600 h-2 rounded-full transition-all duration-300" 
                style={{ width: `${(step / 5) * 100}%` }}
              />
            </div>
          )}
        </div>
      </div>

      {renderStep()}
    </div>
  )
}