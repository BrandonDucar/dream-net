'use client'
import { useState, useCallback, useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { paddleDatabase } from '@/lib/paddleData'
import type { Paddle } from '@/types/paddle'

interface ScanResult {
  confidence: number
  paddle: Paddle
  identified: string[]
  marketPrice: number
  recommendations: string[]
}

interface PaddleScannerProps {
  onBackToWelcome: () => void
}

export function PaddleScanner({ onBackToWelcome }: PaddleScannerProps) {
  const [scanResult, setScanResult] = useState<ScanResult | null>(null)
  const [isScanning, setIsScanning] = useState(false)
  const [uploadedImage, setUploadedImage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Mock AI identification - In production this would use computer vision API
  const identifyPaddle = useCallback(async (imageFile: File): Promise<ScanResult> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    // Mock identification results
    const mockResults: ScanResult[] = [
      {
        confidence: 0.92,
        paddle: paddleDatabase[0], // Selkirk Vanguard Power Air
        identified: ['Raw Carbon Surface', 'Elongated Shape', 'Black Handle'],
        marketPrice: 199.99,
        recommendations: [
          'Excellent choice for advanced players',
          'Consider grip size - this looks like 4 1/4"',
          'Surface looks well-maintained for used paddle'
        ]
      },
      {
        confidence: 0.87,
        paddle: paddleDatabase[5], // JOOLA Ben Johns Hyperion
        identified: ['Carbon Fiber Face', 'Signature Graphics', 'Tournament Paddle'],
        marketPrice: 239.99,
        recommendations: [
          'Pro-level paddle with maximum performance',
          'Check for USAP approval sticker',
          'High resale value due to Ben Johns endorsement'
        ]
      },
      {
        confidence: 0.83,
        paddle: paddleDatabase[10], // Paddletek Bantam TS-5
        identified: ['Carbon Surface', 'Paddletek Logo', 'Professional Series'],
        marketPrice: 169.99,
        recommendations: [
          'Great mid-range performance paddle',
          'Good balance of power and control',
          'Popular choice for intermediate players'
        ]
      }
    ]
    
    // Return random mock result
    return mockResults[Math.floor(Math.random() * mockResults.length)]
  }, [])

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    // Validate file type
    if (!file.type.startsWith('image/')) {
      setError('Please upload an image file')
      return
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      setError('Image must be less than 10MB')
      return
    }

    setError(null)
    setIsScanning(true)
    setScanResult(null)

    try {
      // Create preview URL
      const imageUrl = URL.createObjectURL(file)
      setUploadedImage(imageUrl)

      // Identify paddle
      const result = await identifyPaddle(file)
      setScanResult(result)
    } catch (err) {
      setError('Failed to identify paddle. Please try again with a clearer image.')
    } finally {
      setIsScanning(false)
    }
  }

  const handleCameraCapture = () => {
    // In a real app, this would open camera interface
    setError('Camera feature coming soon! Please upload a photo for now.')
  }

  const resetScanner = () => {
    setScanResult(null)
    setUploadedImage(null)
    setError(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.9) return 'bg-green-100 text-green-800'
    if (confidence >= 0.8) return 'bg-yellow-100 text-yellow-800'
    return 'bg-red-100 text-red-800'
  }

  const getConfidenceText = (confidence: number) => {
    if (confidence >= 0.9) return 'Very High Confidence'
    if (confidence >= 0.8) return 'High Confidence'
    if (confidence >= 0.7) return 'Medium Confidence'
    return 'Low Confidence'
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card className="border-2">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            📷 AI Paddle Scanner
          </CardTitle>
          <p className="text-gray-600">
            Upload a photo or take a picture to instantly identify any pickleball paddle
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {!scanResult && !isScanning && (
            <div className="space-y-6">
              {/* Upload Area */}
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <div className="space-y-4">
                  <div className="text-6xl">📸</div>
                  <h3 className="text-lg font-semibold">Identify Your Paddle</h3>
                  <p className="text-gray-600">
                    Take a clear photo showing the paddle face and any visible logos or text
                  </p>
                  
                  <div className="flex flex-col sm:flex-row gap-3 justify-center">
                    <Button onClick={() => fileInputRef.current?.click()}>
                      📁 Upload Photo
                    </Button>
                    <Button variant="outline" onClick={handleCameraCapture}>
                      📷 Use Camera
                    </Button>
                  </div>
                  
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </div>
              </div>

              {/* Tips for Best Results */}
              <Card className="bg-blue-50 border-blue-200">
                <CardHeader>
                  <CardTitle className="text-lg">📋 Tips for Best Results</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center gap-2">
                      <span className="text-green-600">✓</span>
                      Take photo in good lighting
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-600">✓</span>
                      Show the paddle face clearly
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-600">✓</span>
                      Include any visible brand logos
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-600">✓</span>
                      Keep paddle centered in frame
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-red-600">✗</span>
                      Avoid blurry or dark photos
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Error Display */}
          {error && (
            <Alert>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Scanning State */}
          {isScanning && (
            <div className="text-center py-12">
              <div className="space-y-4">
                <div className="text-6xl animate-pulse">🔍</div>
                <h3 className="text-xl font-semibold">Analyzing Paddle...</h3>
                <div className="space-y-2">
                  <div className="text-sm text-gray-600">🤖 Running AI identification</div>
                  <div className="text-sm text-gray-600">📊 Comparing with database</div>
                  <div className="text-sm text-gray-600">💰 Finding market prices</div>
                </div>
                <div className="w-64 mx-auto bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-600 h-2 rounded-full animate-pulse" style={{ width: '70%' }}></div>
                </div>
              </div>
            </div>
          )}

          {/* Upload Preview */}
          {uploadedImage && !isScanning && (
            <div className="text-center">
              <img 
                src={uploadedImage} 
                alt="Uploaded paddle" 
                className="max-w-sm max-h-64 mx-auto rounded-lg border-2 border-gray-200"
              />
            </div>
          )}

          {/* Scan Results */}
          {scanResult && (
            <div className="space-y-6">
              <div className="text-center">
                <Badge className={getConfidenceColor(scanResult.confidence)}>
                  {Math.round(scanResult.confidence * 100)}% Match - {getConfidenceText(scanResult.confidence)}
                </Badge>
              </div>

              <Card className="border-2 border-green-200 bg-green-50">
                <CardContent className="pt-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h2 className="text-2xl font-bold mb-2">
                        {scanResult.paddle.brand} {scanResult.paddle.model}
                      </h2>
                      <div className="space-y-2 text-sm">
                        <p><span className="font-semibold">Year:</span> {scanResult.paddle.year}</p>
                        <p><span className="font-semibold">Surface:</span> {scanResult.paddle.surface}</p>
                        <p><span className="font-semibold">Shape:</span> {scanResult.paddle.shape}</p>
                        <p><span className="font-semibold">Core:</span> {scanResult.paddle.core}</p>
                        <p><span className="font-semibold">Weight:</span> {scanResult.paddle.weight}</p>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-2">Current Market Price</h3>
                      <div className="text-3xl font-bold text-green-600 mb-2">
                        ${scanResult.marketPrice}
                      </div>
                      <p className="text-sm text-gray-600 mb-4">
                        Based on current retail pricing
                      </p>

                      <div className="space-y-2">
                        <h4 className="font-semibold">Ratings</h4>
                        <div className="grid grid-cols-3 gap-2 text-sm">
                          <div className="text-center">
                            <div className="font-semibold">{scanResult.paddle.powerRating}/5</div>
                            <div className="text-gray-600">Power</div>
                          </div>
                          <div className="text-center">
                            <div className="font-semibold">{scanResult.paddle.controlRating}/5</div>
                            <div className="text-gray-600">Control</div>
                          </div>
                          <div className="text-center">
                            <div className="font-semibold">{scanResult.paddle.spinRating}/5</div>
                            <div className="text-gray-600">Spin</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Identified Features */}
              <Card>
                <CardHeader>
                  <CardTitle>🔍 Identified Features</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {scanResult.identified.map((feature, index) => (
                      <Badge key={index} variant="outline">
                        ✓ {feature}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* AI Recommendations */}
              <Card>
                <CardHeader>
                  <CardTitle>💡 AI Coach Insights</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {scanResult.recommendations.map((rec, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">•</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline">📊 Full Specs</Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>{scanResult.paddle.brand} {scanResult.paddle.model} - Complete Specifications</DialogTitle>
                    </DialogHeader>
                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                      <div className="space-y-2">
                        <p><span className="font-semibold">Brand:</span> {scanResult.paddle.brand}</p>
                        <p><span className="font-semibold">Model:</span> {scanResult.paddle.model}</p>
                        <p><span className="font-semibold">Year:</span> {scanResult.paddle.year}</p>
                        <p><span className="font-semibold">Surface:</span> {scanResult.paddle.surface}</p>
                        <p><span className="font-semibold">Shape:</span> {scanResult.paddle.shape}</p>
                        <p><span className="font-semibold">Core:</span> {scanResult.paddle.core}</p>
                      </div>
                      <div className="space-y-2">
                        <p><span className="font-semibold">Weight:</span> {scanResult.paddle.weight}</p>
                        <p><span className="font-semibold">Grip Sizes:</span> {scanResult.paddle.gripSizes.join(', ')}</p>
                        <p><span className="font-semibold">USAP Approved:</span> {scanResult.paddle.usapApproved ? 'Yes' : 'No'}</p>
                        <p><span className="font-semibold">Price Range:</span> {scanResult.paddle.priceRange}</p>
                        <p><span className="font-semibold">Arm Friendly:</span> {scanResult.paddle.armFriendly ? 'Yes' : 'No'}</p>
                      </div>
                    </div>
                    <div className="mt-4">
                      <p className="font-semibold">Best For:</p>
                      <p className="text-gray-600">{scanResult.paddle.bestFor}</p>
                    </div>
                  </DialogContent>
                </Dialog>

                <Button variant="outline">💰 Find Prices</Button>
                <Button variant="outline">📝 See Reviews</Button>
                <Button variant="outline">🔄 Compare</Button>
              </div>

              <div className="text-center">
                <Button onClick={resetScanner}>
                  📷 Scan Another Paddle
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="text-center">
        <Button variant="outline" onClick={onBackToWelcome}>
          ← Back to Coach Hub
        </Button>
      </div>
    </div>
  )
}