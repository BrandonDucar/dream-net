'use client'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts'
import { paddleDatabase } from '@/lib/paddleData'

interface PerformanceMetrics {
  paddleId: string
  paddleName: string
  monthsUsed: number
  matchesPlayed: number
  winRate: number
  avgPointsPerGame: number
  improvementScore: number
  durabilityRating: number
  comfortRating: number
  overallSatisfaction: number
  wouldRecommend: boolean
  dateAdded: string
  lastUpdated: string
}

interface PerformanceComparison {
  metric: string
  paddle1: number
  paddle2: number
}

interface PerformanceDashboardProps {
  onBackToWelcome: () => void
}

export function PerformanceDashboard({ onBackToWelcome }: PerformanceDashboardProps) {
  const [userPaddles, setUserPaddles] = useState<PerformanceMetrics[]>([])
  const [selectedPaddle, setSelectedPaddle] = useState<string>('')
  const [comparisonData, setComparisonData] = useState<PerformanceComparison[]>([])
  const [activeTab, setActiveTab] = useState('overview')

  // Mock performance data - In production this would come from SpacetimeDB
  useEffect(() => {
    const mockPerformance: PerformanceMetrics[] = [
      {
        paddleId: 'selkirk-vanguard-power-air',
        paddleName: 'Selkirk Vanguard Power Air',
        monthsUsed: 8,
        matchesPlayed: 45,
        winRate: 68,
        avgPointsPerGame: 12.4,
        improvementScore: 85,
        durabilityRating: 4.5,
        comfortRating: 4.2,
        overallSatisfaction: 4.7,
        wouldRecommend: true,
        dateAdded: '2023-06-01',
        lastUpdated: '2024-01-20'
      },
      {
        paddleId: 'joola-ben-johns-hyperion',
        paddleName: 'JOOLA Ben Johns Hyperion',
        monthsUsed: 6,
        matchesPlayed: 32,
        winRate: 72,
        avgPointsPerGame: 13.8,
        improvementScore: 92,
        durabilityRating: 4.8,
        comfortRating: 3.9,
        overallSatisfaction: 4.6,
        wouldRecommend: true,
        dateAdded: '2023-08-01',
        lastUpdated: '2024-01-20'
      },
      {
        paddleId: 'paddletek-bantam-ts5-pro',
        paddleName: 'Paddletek Bantam TS-5 Pro',
        monthsUsed: 12,
        matchesPlayed: 78,
        winRate: 61,
        avgPointsPerGame: 11.2,
        improvementScore: 73,
        durabilityRating: 4.3,
        comfortRating: 4.8,
        overallSatisfaction: 4.2,
        wouldRecommend: true,
        dateAdded: '2023-02-01',
        lastUpdated: '2024-01-20'
      }
    ]
    setUserPaddles(mockPerformance)
    if (mockPerformance.length > 0) {
      setSelectedPaddle(mockPerformance[0].paddleId)
    }
  }, [])

  // Mock progression data for charts
  const progressionData = [
    { month: 'Month 1', winRate: 45, pointsPerGame: 9.2 },
    { month: 'Month 2', winRate: 52, pointsPerGame: 10.1 },
    { month: 'Month 3', winRate: 58, pointsPerGame: 10.8 },
    { month: 'Month 4', winRate: 63, pointsPerGame: 11.5 },
    { month: 'Month 5', winRate: 66, pointsPerGame: 12.1 },
    { month: 'Month 6', winRate: 68, pointsPerGame: 12.4 }
  ]

  const paddleComparisonData = [
    { metric: 'Win Rate', vanguard: 68, hyperion: 72, bantam: 61 },
    { metric: 'Points/Game', vanguard: 12.4, hyperion: 13.8, bantam: 11.2 },
    { metric: 'Comfort', vanguard: 4.2, hyperion: 3.9, bantam: 4.8 },
    { metric: 'Durability', vanguard: 4.5, hyperion: 4.8, bantam: 4.3 },
    { metric: 'Satisfaction', vanguard: 4.7, hyperion: 4.6, bantam: 4.2 }
  ]

  const pieData = [
    { name: 'Excellent Games', value: 35, color: '#22c55e' },
    { name: 'Good Games', value: 40, color: '#3b82f6' },
    { name: 'Average Games', value: 20, color: '#f59e0b' },
    { name: 'Poor Games', value: 5, color: '#ef4444' }
  ]

  const selectedPaddleData = userPaddles.find(p => p.paddleId === selectedPaddle)

  const getPerformanceGrade = (score: number) => {
    if (score >= 90) return { grade: 'A+', color: 'text-green-600' }
    if (score >= 80) return { grade: 'A', color: 'text-green-600' }
    if (score >= 70) return { grade: 'B', color: 'text-blue-600' }
    if (score >= 60) return { grade: 'C', color: 'text-yellow-600' }
    return { grade: 'D', color: 'text-red-600' }
  }

  const getImprovementTrend = (score: number) => {
    if (score >= 80) return { trend: '📈 Significant Improvement', color: 'text-green-600' }
    if (score >= 60) return { trend: '📊 Steady Progress', color: 'text-blue-600' }
    if (score >= 40) return { trend: '📉 Slow Progress', color: 'text-yellow-600' }
    return { trend: '⚠️ No Clear Improvement', color: 'text-red-600' }
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <Card className="border-2">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            📊 Performance Analytics Dashboard
          </CardTitle>
          <p className="text-gray-600">Track how your paddles actually perform in real games</p>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">🏠 Overview</TabsTrigger>
              <TabsTrigger value="individual">📈 Individual Stats</TabsTrigger>
              <TabsTrigger value="comparison">⚖️ Compare Paddles</TabsTrigger>
              <TabsTrigger value="insights">💡 AI Insights</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card className="bg-blue-50 border-blue-200">
                  <CardContent className="pt-6 text-center">
                    <div className="text-3xl font-bold text-blue-600">
                      {userPaddles.reduce((sum, p) => sum + p.matchesPlayed, 0)}
                    </div>
                    <div className="text-sm text-blue-700">Total Matches</div>
                  </CardContent>
                </Card>

                <Card className="bg-green-50 border-green-200">
                  <CardContent className="pt-6 text-center">
                    <div className="text-3xl font-bold text-green-600">
                      {Math.round(userPaddles.reduce((sum, p) => sum + p.winRate, 0) / userPaddles.length)}%
                    </div>
                    <div className="text-sm text-green-700">Avg Win Rate</div>
                  </CardContent>
                </Card>

                <Card className="bg-purple-50 border-purple-200">
                  <CardContent className="pt-6 text-center">
                    <div className="text-3xl font-bold text-purple-600">
                      {userPaddles.length}
                    </div>
                    <div className="text-sm text-purple-700">Paddles Tracked</div>
                  </CardContent>
                </Card>

                <Card className="bg-yellow-50 border-yellow-200">
                  <CardContent className="pt-6 text-center">
                    <div className="text-3xl font-bold text-yellow-600">
                      {Math.round(userPaddles.reduce((sum, p) => sum + p.overallSatisfaction, 0) / userPaddles.length * 20)}%
                    </div>
                    <div className="text-sm text-yellow-700">Satisfaction</div>
                  </CardContent>
                </Card>
              </div>

              {/* Current Paddles Performance */}
              <Card>
                <CardHeader>
                  <CardTitle>🎯 Your Paddle Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {userPaddles.map(paddle => {
                      const performance = getPerformanceGrade(paddle.improvementScore)
                      const trend = getImprovementTrend(paddle.improvementScore)
                      
                      return (
                        <div key={paddle.paddleId} className="flex items-center justify-between p-4 border rounded-lg">
                          <div>
                            <h4 className="font-semibold">{paddle.paddleName}</h4>
                            <div className="text-sm text-gray-600">
                              {paddle.matchesPlayed} matches • {paddle.monthsUsed} months
                            </div>
                            <div className={`text-sm ${trend.color}`}>{trend.trend}</div>
                          </div>
                          <div className="text-right space-y-1">
                            <div className={`text-2xl font-bold ${performance.color}`}>
                              {performance.grade}
                            </div>
                            <div className="text-sm text-gray-600">
                              {paddle.winRate}% Win Rate
                            </div>
                            <div className="text-sm">
                              ⭐ {paddle.overallSatisfaction.toFixed(1)}/5.0
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Performance Over Time */}
              <Card>
                <CardHeader>
                  <CardTitle>📈 Progress Over Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={progressionData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Line type="monotone" dataKey="winRate" stroke="#2563eb" strokeWidth={2} name="Win Rate %" />
                        <Line type="monotone" dataKey="pointsPerGame" stroke="#16a34a" strokeWidth={2} name="Points/Game" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Individual Stats Tab */}
            <TabsContent value="individual" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Select Paddle to Analyze</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {userPaddles.map(paddle => (
                      <Card 
                        key={paddle.paddleId}
                        className={`cursor-pointer transition-colors ${selectedPaddle === paddle.paddleId ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'}`}
                        onClick={() => setSelectedPaddle(paddle.paddleId)}
                      >
                        <CardContent className="pt-6 text-center">
                          <h3 className="font-semibold mb-2">{paddle.paddleName}</h3>
                          <div className="text-sm text-gray-600">
                            {paddle.matchesPlayed} matches • {paddle.winRate}% win rate
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {selectedPaddleData && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>📊 Performance Metrics</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span>Win Rate</span>
                          <span className="font-semibold">{selectedPaddleData.winRate}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${selectedPaddleData.winRate}%` }}></div>
                        </div>

                        <div className="flex justify-between">
                          <span>Avg Points/Game</span>
                          <span className="font-semibold">{selectedPaddleData.avgPointsPerGame}</span>
                        </div>

                        <div className="flex justify-between">
                          <span>Improvement Score</span>
                          <span className="font-semibold">{selectedPaddleData.improvementScore}/100</span>
                        </div>

                        <div className="flex justify-between">
                          <span>Durability Rating</span>
                          <span className="font-semibold">⭐ {selectedPaddleData.durabilityRating}/5.0</span>
                        </div>

                        <div className="flex justify-between">
                          <span>Comfort Rating</span>
                          <span className="font-semibold">⭐ {selectedPaddleData.comfortRating}/5.0</span>
                        </div>

                        <div className="flex justify-between">
                          <span>Overall Satisfaction</span>
                          <span className="font-semibold">⭐ {selectedPaddleData.overallSatisfaction}/5.0</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>🎯 Game Performance Distribution</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={pieData}
                              cx="50%"
                              cy="50%"
                              innerRadius={40}
                              outerRadius={80}
                              dataKey="value"
                              label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
                            >
                              {pieData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Pie>
                            <Tooltip />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </TabsContent>

            {/* Comparison Tab */}
            <TabsContent value="comparison" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>⚖️ Paddle Performance Comparison</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={paddleComparisonData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="metric" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="vanguard" fill="#2563eb" name="Vanguard" />
                        <Bar dataKey="hyperion" fill="#16a34a" name="Hyperion" />
                        <Bar dataKey="bantam" fill="#f59e0b" name="Bantam" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {userPaddles.map(paddle => (
                  <Card key={paddle.paddleId}>
                    <CardContent className="pt-6">
                      <h3 className="font-semibold mb-4">{paddle.paddleName}</h3>
                      <div className="space-y-3 text-sm">
                        <div className="flex justify-between">
                          <span>Win Rate:</span>
                          <span className="font-semibold">{paddle.winRate}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Points/Game:</span>
                          <span className="font-semibold">{paddle.avgPointsPerGame}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Comfort:</span>
                          <span className="font-semibold">{paddle.comfortRating}/5</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Durability:</span>
                          <span className="font-semibold">{paddle.durabilityRating}/5</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Satisfaction:</span>
                          <span className="font-semibold">{paddle.overallSatisfaction}/5</span>
                        </div>
                        <Badge className={paddle.wouldRecommend ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                          {paddle.wouldRecommend ? '✓ Recommend' : '✗ Don\'t Recommend'}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* AI Insights Tab */}
            <TabsContent value="insights" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>🤖 AI Performance Insights</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="bg-green-50 border-green-200">
                      <CardHeader>
                        <CardTitle className="text-lg text-green-800">💪 Strengths Identified</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="text-green-600">✓</span>
                          <span>Consistent improvement with power paddles</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-green-600">✓</span>
                          <span>Better performance with carbon fiber surfaces</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-green-600">✓</span>
                          <span>Win rate increases with paddle familiarity</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="bg-yellow-50 border-yellow-200">
                      <CardHeader>
                        <CardTitle className="text-lg text-yellow-800">⚠️ Areas for Improvement</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="text-yellow-600">!</span>
                          <span>Consider arm-friendly options for comfort</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-yellow-600">!</span>
                          <span>Control-focused paddles might help consistency</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-yellow-600">!</span>
                          <span>Track specific shot performance for deeper insights</span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <Card className="bg-blue-50 border-blue-200">
                    <CardHeader>
                      <CardTitle className="text-lg text-blue-800">🎯 Personalized Recommendations</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-3">
                        <div>
                          <h4 className="font-semibold">Next Paddle Suggestion:</h4>
                          <p className="text-sm">Based on your performance data, consider the <strong>Selkirk Labs Project 002</strong> for maximum spin control while maintaining power.</p>
                        </div>
                        <div>
                          <h4 className="font-semibold">Playing Style Analysis:</h4>
                          <p className="text-sm">Your data suggests you're a <strong>power-baseline player</strong> who benefits from aggressive paddles with good spin generation.</p>
                        </div>
                        <div>
                          <h4 className="font-semibold">Performance Goal:</h4>
                          <p className="text-sm">Focus on improving consistency with your current paddle to reach 75% win rate within 3 months.</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <div className="text-center">
                    <Button>
                      📊 Export Performance Report
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <div className="text-center">
        <Button variant="outline" onClick={onBackToWelcome}>
          ← Back to Coach Hub
        </Button>
      </div>
    </div>
  )
}