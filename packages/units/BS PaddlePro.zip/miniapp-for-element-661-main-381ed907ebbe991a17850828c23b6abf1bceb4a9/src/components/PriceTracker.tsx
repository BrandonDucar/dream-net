'use client'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { paddleDatabase } from '@/lib/paddleData'

interface PriceData {
  id: string
  paddleId: string
  retailer: string
  price: number
  originalPrice: number
  salePrice?: number
  inStock: boolean
  lastUpdated: string
  url: string
}

interface PriceAlert {
  id: string
  paddleId: string
  targetPrice: number
  email: string
  active: boolean
  created: string
}

interface PriceHistory {
  date: string
  price: number
  retailer: string
}

interface PriceTrackerProps {
  onBackToWelcome: () => void
}

export function PriceTracker({ onBackToWelcome }: PriceTrackerProps) {
  const [prices, setPrices] = useState<PriceData[]>([])
  const [alerts, setAlerts] = useState<PriceAlert[]>([])
  const [selectedPaddle, setSelectedPaddle] = useState<string>('')
  const [priceHistory, setPriceHistory] = useState<PriceHistory[]>([])
  const [showAlertDialog, setShowAlertDialog] = useState(false)
  const [sortBy, setSortBy] = useState('best-deal')

  // Mock price data - In production this would come from web scraping APIs
  useEffect(() => {
    const mockPrices: PriceData[] = [
      {
        id: '1',
        paddleId: 'selkirk-vanguard-power-air',
        retailer: 'Pickleball Central',
        price: 199.99,
        originalPrice: 219.99,
        salePrice: 179.99,
        inStock: true,
        lastUpdated: '2024-01-20T10:00:00Z',
        url: 'https://pickleballcentral.com'
      },
      {
        id: '2',
        paddleId: 'selkirk-vanguard-power-air',
        retailer: 'Amazon',
        price: 209.95,
        originalPrice: 219.99,
        inStock: true,
        lastUpdated: '2024-01-20T09:30:00Z',
        url: 'https://amazon.com'
      },
      {
        id: '3',
        paddleId: 'selkirk-vanguard-power-air',
        retailer: "Dick's Sporting Goods",
        price: 219.99,
        originalPrice: 219.99,
        inStock: false,
        lastUpdated: '2024-01-20T08:00:00Z',
        url: 'https://dickssportinggoods.com'
      },
      {
        id: '4',
        paddleId: 'joola-ben-johns-hyperion',
        retailer: 'Tennis Warehouse',
        price: 234.95,
        originalPrice: 249.99,
        salePrice: 224.95,
        inStock: true,
        lastUpdated: '2024-01-20T11:00:00Z',
        url: 'https://tenniswarehouse.com'
      },
      {
        id: '5',
        paddleId: 'joola-ben-johns-hyperion',
        retailer: 'Pickleball Central',
        price: 239.99,
        originalPrice: 249.99,
        inStock: true,
        lastUpdated: '2024-01-20T10:30:00Z',
        url: 'https://pickleballcentral.com'
      },
      {
        id: '6',
        paddleId: 'paddletek-bantam-ts5-pro',
        retailer: 'Amazon',
        price: 159.99,
        originalPrice: 179.99,
        salePrice: 149.99,
        inStock: true,
        lastUpdated: '2024-01-20T12:00:00Z',
        url: 'https://amazon.com'
      }
    ]
    setPrices(mockPrices)

    // Mock price history for charts
    const mockHistory: PriceHistory[] = [
      { date: '2024-01-01', price: 219.99, retailer: 'Average' },
      { date: '2024-01-05', price: 215.99, retailer: 'Average' },
      { date: '2024-01-10', price: 209.99, retailer: 'Average' },
      { date: '2024-01-15', price: 199.99, retailer: 'Average' },
      { date: '2024-01-20', price: 189.99, retailer: 'Average' }
    ]
    setPriceHistory(mockHistory)
  }, [])

  const paddlePrices = selectedPaddle ? 
    prices.filter(p => p.paddleId === selectedPaddle) : 
    prices

  const sortedPrices = [...paddlePrices].sort((a, b) => {
    switch (sortBy) {
      case 'best-deal':
        const aPrice = a.salePrice || a.price
        const bPrice = b.salePrice || b.price
        return aPrice - bPrice
      case 'highest-savings':
        const aSavings = a.originalPrice - (a.salePrice || a.price)
        const bSavings = b.originalPrice - (b.salePrice || b.price)
        return bSavings - aSavings
      case 'retailer':
        return a.retailer.localeCompare(b.retailer)
      case 'last-updated':
        return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime()
      default:
        return 0
    }
  })

  const getPaddleName = (paddleId: string) => {
    const paddle = paddleDatabase.find(p => p.id === paddleId)
    return paddle ? `${paddle.brand} ${paddle.model}` : 'Unknown Paddle'
  }

  const getBestDeal = (paddleId: string) => {
    const paddlePricesForId = prices.filter(p => p.paddleId === paddleId && p.inStock)
    if (paddlePricesForId.length === 0) return null
    
    return paddlePricesForId.reduce((best, current) => {
      const bestPrice = best.salePrice || best.price
      const currentPrice = current.salePrice || current.price
      return currentPrice < bestPrice ? current : best
    })
  }

  const formatLastUpdated = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))
    
    if (diffHours < 1) return 'Just updated'
    if (diffHours < 24) return `${diffHours}h ago`
    return `${Math.floor(diffHours / 24)}d ago`
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <Card className="border-2">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            📊 Price Tracker & Deal Finder
          </CardTitle>
          <p className="text-gray-600">Track prices across retailers and never miss a deal</p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Controls */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label>Track Specific Paddle</Label>
              <Select value={selectedPaddle} onValueChange={setSelectedPaddle}>
                <SelectTrigger>
                  <SelectValue placeholder="All Paddles" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Paddles</SelectItem>
                  {paddleDatabase.map(paddle => (
                    <SelectItem key={paddle.id} value={paddle.id}>
                      {paddle.brand} {paddle.model}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Sort By</Label>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="best-deal">Best Deal</SelectItem>
                  <SelectItem value="highest-savings">Highest Savings</SelectItem>
                  <SelectItem value="retailer">Retailer A-Z</SelectItem>
                  <SelectItem value="last-updated">Recently Updated</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Dialog open={showAlertDialog} onOpenChange={setShowAlertDialog}>
                <DialogTrigger asChild>
                  <Button className="w-full">🔔 Set Price Alert</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create Price Alert</DialogTitle>
                  </DialogHeader>
                  <PriceAlertForm onSubmit={(alert) => {
                    setAlerts(prev => [...prev, { ...alert, id: Date.now().toString() }])
                    setShowAlertDialog(false)
                  }} />
                </DialogContent>
              </Dialog>
            </div>

            <div className="flex items-end">
              <Button variant="outline" className="w-full">
                📈 Price History
              </Button>
            </div>
          </div>

          {/* Best Deals Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-green-50 border-green-200">
              <CardContent className="pt-6 text-center">
                <div className="text-2xl font-bold text-green-600 mb-2">
                  {prices.filter(p => p.salePrice && p.inStock).length}
                </div>
                <div className="text-sm text-green-700">Active Sales</div>
              </CardContent>
            </Card>

            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="pt-6 text-center">
                <div className="text-2xl font-bold text-blue-600 mb-2">
                  ${Math.max(...prices.filter(p => p.salePrice && p.inStock).map(p => p.originalPrice - (p.salePrice || 0))).toFixed(0)}
                </div>
                <div className="text-sm text-blue-700">Max Savings</div>
              </CardContent>
            </Card>

            <Card className="bg-purple-50 border-purple-200">
              <CardContent className="pt-6 text-center">
                <div className="text-2xl font-bold text-purple-600 mb-2">
                  {alerts.filter(a => a.active).length}
                </div>
                <div className="text-sm text-purple-700">Active Alerts</div>
              </CardContent>
            </Card>
          </div>

          {/* Price Chart */}
          {selectedPaddle && (
            <Card>
              <CardHeader>
                <CardTitle>Price History - {getPaddleName(selectedPaddle)}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={priceHistory}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="price" stroke="#2563eb" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Price Listings */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sortedPrices.map(priceData => (
              <PriceCard key={priceData.id} priceData={priceData} getPaddleName={getPaddleName} formatLastUpdated={formatLastUpdated} />
            ))}
          </div>

          {/* Featured Deals */}
          <Card>
            <CardHeader>
              <CardTitle>🔥 Today's Best Deals</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {paddleDatabase.slice(0, 5).map(paddle => {
                  const bestDeal = getBestDeal(paddle.id)
                  if (!bestDeal) return null
                  
                  const savings = bestDeal.originalPrice - (bestDeal.salePrice || bestDeal.price)
                  const savingsPercent = Math.round((savings / bestDeal.originalPrice) * 100)
                  
                  return (
                    <div key={paddle.id} className="flex justify-between items-center p-4 border rounded-lg">
                      <div>
                        <h4 className="font-semibold">{paddle.brand} {paddle.model}</h4>
                        <p className="text-sm text-gray-600">{bestDeal.retailer}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-bold text-green-600">
                          ${bestDeal.salePrice || bestDeal.price}
                        </div>
                        {savings > 0 && (
                          <div className="text-sm">
                            <span className="line-through text-gray-500">${bestDeal.originalPrice}</span>
                            <span className="text-red-600 ml-2">Save ${savings.toFixed(0)} ({savingsPercent}%)</span>
                          </div>
                        )}
                      </div>
                      <Button size="sm">
                        View Deal
                      </Button>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>

      <div className="text-center">
        <Button variant="outline" onClick={onBackToWelcome}>
          ← Back to Coach Hub
        </Button>
      </div>
    </div>
  )
}

function PriceCard({ priceData, getPaddleName, formatLastUpdated }: {
  priceData: PriceData,
  getPaddleName: (id: string) => string,
  formatLastUpdated: (date: string) => string
}) {
  const currentPrice = priceData.salePrice || priceData.price
  const savings = priceData.originalPrice - currentPrice
  const savingsPercent = Math.round((savings / priceData.originalPrice) * 100)

  return (
    <Card className={`${!priceData.inStock ? 'opacity-60' : ''} hover:shadow-lg transition-shadow`}>
      <CardContent className="pt-6">
        <div className="space-y-3">
          <div>
            <h3 className="font-semibold text-lg line-clamp-1">
              {getPaddleName(priceData.paddleId)}
            </h3>
            <p className="text-gray-600 font-medium">{priceData.retailer}</p>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <div className="text-2xl font-bold text-green-600">
                ${currentPrice.toFixed(2)}
              </div>
              {savings > 0 && (
                <Badge className="bg-red-500 text-white">
                  {savingsPercent}% OFF
                </Badge>
              )}
            </div>
            
            {savings > 0 && (
              <div className="text-sm">
                <span className="line-through text-gray-500">${priceData.originalPrice.toFixed(2)}</span>
                <span className="text-red-600 ml-2 font-semibold">Save ${savings.toFixed(2)}</span>
              </div>
            )}
          </div>

          <div className="flex justify-between items-center text-sm">
            <Badge variant={priceData.inStock ? "default" : "secondary"}>
              {priceData.inStock ? "✅ In Stock" : "❌ Out of Stock"}
            </Badge>
            <span className="text-gray-500">{formatLastUpdated(priceData.lastUpdated)}</span>
          </div>

          <Button className="w-full" disabled={!priceData.inStock}>
            {priceData.inStock ? "🛒 View at Retailer" : "📧 Notify When Available"}
          </Button>

          <Button variant="ghost" size="sm" className="w-full">
            🔔 Alert me at ${(currentPrice * 0.9).toFixed(0)}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

function PriceAlertForm({ onSubmit }: { onSubmit: (alert: Omit<PriceAlert, 'id'>) => void }) {
  const [formData, setFormData] = useState({
    paddleId: '',
    targetPrice: '',
    email: ''
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit({
      paddleId: formData.paddleId,
      targetPrice: parseFloat(formData.targetPrice),
      email: formData.email,
      active: true,
      created: new Date().toISOString()
    })
    setFormData({ paddleId: '', targetPrice: '', email: '' })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label>Paddle</Label>
        <Select value={formData.paddleId} onValueChange={(value) => setFormData(prev => ({ ...prev, paddleId: value }))}>
          <SelectTrigger>
            <SelectValue placeholder="Select Paddle" />
          </SelectTrigger>
          <SelectContent>
            {paddleDatabase.map(paddle => (
              <SelectItem key={paddle.id} value={paddle.id}>
                {paddle.brand} {paddle.model}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label>Target Price ($)</Label>
        <Input
          type="number"
          step="0.01"
          value={formData.targetPrice}
          onChange={(e) => setFormData(prev => ({ ...prev, targetPrice: e.target.value }))}
          placeholder="150.00"
          required
        />
      </div>

      <div>
        <Label>Email for Alerts</Label>
        <Input
          type="email"
          value={formData.email}
          onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
          placeholder="your@email.com"
          required
        />
      </div>

      <Button type="submit" className="w-full">
        🔔 Create Alert
      </Button>
    </form>
  )
}