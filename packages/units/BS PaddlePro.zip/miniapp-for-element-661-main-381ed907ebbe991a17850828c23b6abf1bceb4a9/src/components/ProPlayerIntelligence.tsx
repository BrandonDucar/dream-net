'use client'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { paddleDatabase } from '@/lib/paddleData'

interface ProPlayer {
  id: string
  name: string
  ranking: number
  currentPaddle: string
  paddleHistory: string[]
  totalTitles: number
  recentTitles: TournamentResult[]
  endorsements: string[]
  playStyle: string[]
  signatureTechniques: string[]
  profileImage: string
}

interface TournamentResult {
  tournament: string
  year: number
  placement: string
  prize: number
  partner?: string
  paddleUsed: string
}

interface PaddleUsageStats {
  paddleId: string
  paddleName: string
  playersUsingCount: number
  topPlayers: string[]
  winRate: number
  totalTournaments: number
  recentSwitches: number
}

interface ProPlayerIntelligenceProps {
  onBackToWelcome: () => void
}

export function ProPlayerIntelligence({ onBackToWelcome }: ProPlayerIntelligenceProps) {
  const [proPlayers, setProPlayers] = useState<ProPlayer[]>([])
  const [paddleStats, setPaddleStats] = useState<PaddleUsageStats[]>([])
  const [selectedPlayer, setSelectedPlayer] = useState<string>('')
  const [filterBy, setFilterBy] = useState<string>('ranking')
  const [searchTerm, setSearchTerm] = useState('')

  // Mock pro player data - In production this would come from tournament databases
  useEffect(() => {
    const mockProPlayers: ProPlayer[] = [
      {
        id: 'ben-johns',
        name: 'Ben Johns',
        ranking: 1,
        currentPaddle: 'joola-ben-johns-hyperion',
        paddleHistory: ['joola-ben-johns-hyperion', 'joola-vision-cgr'],
        totalTitles: 45,
        recentTitles: [
          { tournament: 'PPA Masters', year: 2024, placement: '1st', prize: 15000, partner: 'Collin Johns', paddleUsed: 'joola-ben-johns-hyperion' },
          { tournament: 'APP Championship', year: 2024, placement: '1st', prize: 12000, paddleUsed: 'joola-ben-johns-hyperion' },
          { tournament: 'MLP Season 3', year: 2024, placement: '1st', prize: 20000, paddleUsed: 'joola-ben-johns-hyperion' }
        ],
        endorsements: ['JOOLA', 'Franklin Sports'],
        playStyle: ['Power Baseline', 'Aggressive Nets', 'Counter-Attack'],
        signatureTechniques: ['Erne', 'ATP', 'Power Dinking'],
        profileImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face'
      },
      {
        id: 'anna-leigh-waters',
        name: 'Anna Leigh Waters',
        ranking: 1,
        currentPaddle: 'paddletek-bantam-ts5-pro',
        paddleHistory: ['paddletek-bantam-ts5-pro', 'paddletek-tempest-wave-pro'],
        totalTitles: 38,
        recentTitles: [
          { tournament: 'PPA Championships', year: 2024, placement: '1st', prize: 18000, partner: 'Leigh Waters', paddleUsed: 'paddletek-bantam-ts5-pro' },
          { tournament: 'US Open', year: 2024, placement: '1st', prize: 15000, partner: 'Leigh Waters', paddleUsed: 'paddletek-bantam-ts5-pro' }
        ],
        endorsements: ['Paddletek', 'HEAD'],
        playStyle: ['All-Court', 'Strategic Placement', 'Quick Hands'],
        signatureTechniques: ['Precision Dinking', 'Quick Exchanges', 'Court Positioning'],
        profileImage: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop&crop=face'
      },
      {
        id: 'tyson-mcguffin',
        name: 'Tyson McGuffin',
        ranking: 3,
        currentPaddle: 'selkirk-vanguard-power-air',
        paddleHistory: ['selkirk-vanguard-power-air', 'selkirk-amped-epic'],
        totalTitles: 32,
        recentTitles: [
          { tournament: 'Desert Ridge Open', year: 2024, placement: '2nd', prize: 8000, paddleUsed: 'selkirk-vanguard-power-air' },
          { tournament: 'Atlanta Open', year: 2024, placement: '1st', prize: 12000, paddleUsed: 'selkirk-vanguard-power-air' }
        ],
        endorsements: ['Selkirk', 'Vulcan'],
        playStyle: ['Power Game', 'Aggressive Serves', 'Net Domination'],
        signatureTechniques: ['Power Drives', 'Put-Away Volleys', 'Overhead Smashes'],
        profileImage: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=face'
      },
      {
        id: 'collin-johns',
        name: 'Collin Johns',
        ranking: 2,
        currentPaddle: 'joola-collin-johns-scorpeus',
        paddleHistory: ['joola-collin-johns-scorpeus', 'joola-vision-cgr'],
        totalTitles: 28,
        recentTitles: [
          { tournament: 'Newport Beach Open', year: 2024, placement: '1st', prize: 10000, partner: 'Ben Johns', paddleUsed: 'joola-collin-johns-scorpeus' },
          { tournament: 'Florida Open', year: 2024, placement: '2nd', prize: 6000, paddleUsed: 'joola-collin-johns-scorpeus' }
        ],
        endorsements: ['JOOLA'],
        playStyle: ['Balanced Attack', 'Strategic Play', 'Spin Control'],
        signatureTechniques: ['Spin Serves', 'Drop Shot Mastery', 'Defensive Lobs'],
        profileImage: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=face'
      }
    ]
    setProPlayers(mockProPlayers)

    const mockPaddleStats: PaddleUsageStats[] = [
      {
        paddleId: 'joola-ben-johns-hyperion',
        paddleName: 'JOOLA Ben Johns Hyperion',
        playersUsingCount: 15,
        topPlayers: ['Ben Johns', 'Riley Newman', 'JW Johnson'],
        winRate: 78,
        totalTournaments: 45,
        recentSwitches: 8
      },
      {
        paddleId: 'paddletek-bantam-ts5-pro',
        paddleName: 'Paddletek Bantam TS-5 Pro',
        playersUsingCount: 12,
        topPlayers: ['Anna Leigh Waters', 'Leigh Waters', 'Catherine Parenteau'],
        winRate: 74,
        totalTournaments: 38,
        recentSwitches: 5
      },
      {
        paddleId: 'selkirk-vanguard-power-air',
        paddleName: 'Selkirk Vanguard Power Air',
        playersUsingCount: 18,
        topPlayers: ['Tyson McGuffin', 'Zane Navratil', 'Jay Devilliers'],
        winRate: 71,
        totalTournaments: 52,
        recentSwitches: 12
      }
    ]
    setPaddleStats(mockPaddleStats)
  }, [])

  const filteredPlayers = proPlayers
    .filter(player => {
      if (!searchTerm) return true
      return player.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
             player.currentPaddle.toLowerCase().includes(searchTerm.toLowerCase())
    })
    .sort((a, b) => {
      switch (filterBy) {
        case 'ranking': return a.ranking - b.ranking
        case 'titles': return b.totalTitles - a.totalTitles
        case 'name': return a.name.localeCompare(b.name)
        default: return a.ranking - b.ranking
      }
    })

  const getPaddleName = (paddleId: string) => {
    const paddle = paddleDatabase.find(p => p.id === paddleId)
    return paddle ? `${paddle.brand} ${paddle.model}` : paddleId
  }

  const selectedPlayerData = proPlayers.find(p => p.id === selectedPlayer)

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <Card className="border-2">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            🏆 Pro Player Intelligence Hub
          </CardTitle>
          <p className="text-gray-600">Track pro equipment choices, performance data, and tournament insights</p>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="players" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="players">👥 Pro Players</TabsTrigger>
              <TabsTrigger value="equipment">🏓 Equipment Stats</TabsTrigger>
              <TabsTrigger value="trends">📈 Trends</TabsTrigger>
              <TabsTrigger value="insights">🎯 Insights</TabsTrigger>
            </TabsList>

            {/* Pro Players Tab */}
            <TabsContent value="players" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label>Search Players</Label>
                  <Input
                    placeholder="Search by name or paddle..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                
                <div>
                  <Label>Sort By</Label>
                  <Select value={filterBy} onValueChange={setFilterBy}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ranking">World Ranking</SelectItem>
                      <SelectItem value="titles">Total Titles</SelectItem>
                      <SelectItem value="name">Name A-Z</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-end">
                  <Button variant="outline" className="w-full">
                    📊 Export Data
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredPlayers.map(player => (
                  <ProPlayerCard 
                    key={player.id} 
                    player={player} 
                    getPaddleName={getPaddleName}
                    onViewDetails={() => setSelectedPlayer(player.id)}
                  />
                ))}
              </div>

              {/* Player Details Modal */}
              {selectedPlayerData && (
                <Dialog open={!!selectedPlayer} onOpenChange={() => setSelectedPlayer('')}>
                  <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-3">
                        <img 
                          src={selectedPlayerData.profileImage} 
                          alt={selectedPlayerData.name}
                          className="w-12 h-12 rounded-full"
                        />
                        {selectedPlayerData.name} - Detailed Profile
                      </DialogTitle>
                    </DialogHeader>
                    <ProPlayerDetails player={selectedPlayerData} getPaddleName={getPaddleName} />
                  </DialogContent>
                </Dialog>
              )}
            </TabsContent>

            {/* Equipment Stats Tab */}
            <TabsContent value="equipment" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-blue-50 border-blue-200">
                  <CardContent className="pt-6 text-center">
                    <div className="text-3xl font-bold text-blue-600">
                      {paddleStats.reduce((sum, p) => sum + p.playersUsingCount, 0)}
                    </div>
                    <div className="text-sm text-blue-700">Pro Endorsements</div>
                  </CardContent>
                </Card>

                <Card className="bg-green-50 border-green-200">
                  <CardContent className="pt-6 text-center">
                    <div className="text-3xl font-bold text-green-600">
                      {Math.round(paddleStats.reduce((sum, p) => sum + p.winRate, 0) / paddleStats.length)}%
                    </div>
                    <div className="text-sm text-green-700">Avg Win Rate</div>
                  </CardContent>
                </Card>

                <Card className="bg-purple-50 border-purple-200">
                  <CardContent className="pt-6 text-center">
                    <div className="text-3xl font-bold text-purple-600">
                      {paddleStats.reduce((sum, p) => sum + p.recentSwitches, 0)}
                    </div>
                    <div className="text-sm text-purple-700">Recent Switches</div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-4">
                {paddleStats.map(paddle => (
                  <Card key={paddle.paddleId}>
                    <CardContent className="pt-6">
                      <div className="grid md:grid-cols-4 gap-4">
                        <div>
                          <h3 className="font-semibold text-lg mb-2">{paddle.paddleName}</h3>
                          <div className="text-sm text-gray-600">
                            {paddle.playersUsingCount} pro players using
                          </div>
                        </div>

                        <div>
                          <div className="text-2xl font-bold text-green-600">{paddle.winRate}%</div>
                          <div className="text-sm text-gray-600">Tournament Win Rate</div>
                        </div>

                        <div>
                          <div className="text-2xl font-bold text-blue-600">{paddle.totalTournaments}</div>
                          <div className="text-sm text-gray-600">Total Tournaments</div>
                        </div>

                        <div>
                          <div className="text-sm font-semibold mb-1">Top Players:</div>
                          {paddle.topPlayers.map((player, idx) => (
                            <Badge key={idx} variant="outline" className="mr-1 mb-1 text-xs">
                              {player}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Trends Tab */}
            <TabsContent value="trends" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>🔥 Current Equipment Trends</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="bg-red-50 border-red-200">
                      <CardHeader>
                        <CardTitle className="text-lg text-red-800">📈 Rising Paddles</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          <li className="flex justify-between">
                            <span>JOOLA Ben Johns Hyperion</span>
                            <Badge className="bg-red-100 text-red-800">+8 pros</Badge>
                          </li>
                          <li className="flex justify-between">
                            <span>Selkirk Labs 002</span>
                            <Badge className="bg-red-100 text-red-800">+5 pros</Badge>
                          </li>
                          <li className="flex justify-between">
                            <span>HEAD Extreme Tour</span>
                            <Badge className="bg-red-100 text-red-800">+3 pros</Badge>
                          </li>
                        </ul>
                      </CardContent>
                    </Card>

                    <Card className="bg-blue-50 border-blue-200">
                      <CardHeader>
                        <CardTitle className="text-lg text-blue-800">📊 Material Trends</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span>Raw Carbon</span>
                            <span className="font-semibold">68% of pros</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-blue-600 h-2 rounded-full" style={{ width: '68%' }}></div>
                          </div>

                          <div className="flex justify-between">
                            <span>Carbon Fiber</span>
                            <span className="font-semibold">25% of pros</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-blue-600 h-2 rounded-full" style={{ width: '25%' }}></div>
                          </div>

                          <div className="flex justify-between">
                            <span>Fiberglass</span>
                            <span className="font-semibold">7% of pros</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-blue-600 h-2 rounded-full" style={{ width: '7%' }}></div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <Card>
                    <CardHeader>
                      <CardTitle>⏰ Recent Equipment Changes</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center p-3 border rounded">
                          <div>
                            <span className="font-semibold">Riley Newman</span>
                            <span className="text-gray-600 ml-2">switched to JOOLA Hyperion</span>
                          </div>
                          <Badge>3 days ago</Badge>
                        </div>
                        <div className="flex justify-between items-center p-3 border rounded">
                          <div>
                            <span className="font-semibold">JW Johnson</span>
                            <span className="text-gray-600 ml-2">switched to Selkirk Labs 002</span>
                          </div>
                          <Badge>1 week ago</Badge>
                        </div>
                        <div className="flex justify-between items-center p-3 border rounded">
                          <div>
                            <span className="font-semibold">Zane Navratil</span>
                            <span className="text-gray-600 ml-2">switched to Selkirk Vanguard</span>
                          </div>
                          <Badge>2 weeks ago</Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Insights Tab */}
            <TabsContent value="insights" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>🎯 Pro Player Insights & Analysis</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="bg-green-50 border-green-200">
                      <CardHeader>
                        <CardTitle className="text-lg text-green-800">🏆 Championship Patterns</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="text-sm">
                          <strong>Power Paddles Dominate:</strong> 73% of recent tournament wins used power-focused paddles (4+ power rating)
                        </div>
                        <div className="text-sm">
                          <strong>Raw Carbon Advantage:</strong> Raw carbon surface paddles have 15% higher win rate in finals
                        </div>
                        <div className="text-sm">
                          <strong>Signature Models:</strong> Pro signature paddles win 68% more often than generic models
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="bg-blue-50 border-blue-200">
                      <CardHeader>
                        <CardTitle className="text-lg text-blue-800">📊 Equipment Insights</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="text-sm">
                          <strong>Switch Timing:</strong> Most pros switch paddles during off-season (November-January)
                        </div>
                        <div className="text-sm">
                          <strong>Loyalty Factor:</strong> Top 10 players average 2.3 years with same paddle brand
                        </div>
                        <div className="text-sm">
                          <strong>Performance Impact:</strong> Paddle switches show 12% performance drop in first month
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <Card className="bg-purple-50 border-purple-200">
                    <CardHeader>
                      <CardTitle className="text-lg text-purple-800">🔮 Recommendations for Your Game</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <h4 className="font-semibold">Based on Pro Trends:</h4>
                        <ul className="list-disc list-inside text-sm space-y-1 mt-2">
                          <li>Consider raw carbon surface for better spin generation (used by 68% of pros)</li>
                          <li>Power-focused paddles show higher success rates in competitive play</li>
                          <li>Signature models often have refined specs based on actual pro feedback</li>
                          <li>Stick with a paddle for at least 3-6 months before making changes</li>
                        </ul>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold">Top Pro Choices by Play Style:</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-2">
                          <div className="text-sm p-2 border rounded">
                            <div className="font-semibold">Power Players:</div>
                            <div>JOOLA Hyperion, Selkirk Vanguard</div>
                          </div>
                          <div className="text-sm p-2 border rounded">
                            <div className="font-semibold">Control Players:</div>
                            <div>Paddletek Bantam, Engage Poach</div>
                          </div>
                          <div className="text-sm p-2 border rounded">
                            <div className="font-semibold">All-Court:</div>
                            <div>YONEX PERCEPT, HEAD Radical</div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <div className="text-center">
        <Button variant="outline" onClick={onBackToWelcome}>
          ← Back to Coach Hub
        </Button>
      </div>
    </div>
  )
}

function ProPlayerCard({ player, getPaddleName, onViewDetails }: {
  player: ProPlayer,
  getPaddleName: (id: string) => string,
  onViewDetails: () => void
}) {
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="pt-6">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <img 
              src={player.profileImage} 
              alt={player.name}
              className="w-16 h-16 rounded-full object-cover"
            />
            <div>
              <h3 className="font-bold text-lg">{player.name}</h3>
              <Badge className="bg-gold-100 text-gold-800">
                #{player.ranking} World Ranking
              </Badge>
            </div>
          </div>

          <div className="space-y-2 text-sm">
            <div>
              <span className="font-semibold">Current Paddle:</span>
              <div className="text-gray-600">{getPaddleName(player.currentPaddle)}</div>
            </div>
            <div>
              <span className="font-semibold">Career Titles:</span>
              <span className="ml-2 text-green-600 font-bold">{player.totalTitles}</span>
            </div>
            <div>
              <span className="font-semibold">Play Style:</span>
              <div className="flex flex-wrap gap-1 mt-1">
                {player.playStyle.slice(0, 2).map((style, idx) => (
                  <Badge key={idx} variant="outline" className="text-xs">
                    {style}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          <div>
            <span className="font-semibold text-sm">Recent Results:</span>
            <div className="space-y-1 mt-1">
              {player.recentTitles.slice(0, 2).map((title, idx) => (
                <div key={idx} className="text-xs text-gray-600 flex justify-between">
                  <span>{title.tournament}</span>
                  <Badge variant="outline" className={title.placement === '1st' ? 'bg-gold-50' : ''}>
                    {title.placement}
                  </Badge>
                </div>
              ))}
            </div>
          </div>

          <Button onClick={onViewDetails} className="w-full" size="sm">
            📊 View Full Profile
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

function ProPlayerDetails({ player, getPaddleName }: {
  player: ProPlayer,
  getPaddleName: (id: string) => string
}) {
  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <h3 className="font-semibold text-lg mb-2">Career Overview</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>World Ranking:</span>
                <Badge className="bg-gold-100 text-gold-800">#{player.ranking}</Badge>
              </div>
              <div className="flex justify-between">
                <span>Total Titles:</span>
                <span className="font-semibold">{player.totalTitles}</span>
              </div>
              <div className="flex justify-between">
                <span>Current Paddle:</span>
                <span className="font-semibold">{getPaddleName(player.currentPaddle)}</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-2">Play Style</h3>
            <div className="flex flex-wrap gap-1">
              {player.playStyle.map((style, idx) => (
                <Badge key={idx} variant="outline">
                  {style}
                </Badge>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-2">Signature Techniques</h3>
            <div className="flex flex-wrap gap-1">
              {player.signatureTechniques.map((tech, idx) => (
                <Badge key={idx} className="bg-blue-100 text-blue-800">
                  {tech}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <h3 className="font-semibold text-lg mb-2">Equipment History</h3>
            <div className="space-y-2">
              {player.paddleHistory.map((paddleId, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <Badge variant={idx === 0 ? "default" : "secondary"}>
                    {idx === 0 ? 'Current' : 'Previous'}
                  </Badge>
                  <span className="text-sm">{getPaddleName(paddleId)}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-2">Endorsements</h3>
            <div className="flex flex-wrap gap-1">
              {player.endorsements.map((brand, idx) => (
                <Badge key={idx} className="bg-purple-100 text-purple-800">
                  {brand}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div>
        <h3 className="font-semibold text-lg mb-4">Recent Tournament Results</h3>
        <div className="space-y-3">
          {player.recentTitles.map((result, idx) => (
            <div key={idx} className="flex justify-between items-center p-3 border rounded">
              <div>
                <div className="font-semibold">{result.tournament}</div>
                <div className="text-sm text-gray-600">
                  {result.year} • {result.partner ? `with ${result.partner}` : 'Singles'}
                </div>
                <div className="text-xs text-gray-500">
                  Paddle: {getPaddleName(result.paddleUsed)}
                </div>
              </div>
              <div className="text-right">
                <Badge className={result.placement === '1st' ? 'bg-gold-100 text-gold-800' : ''}>
                  {result.placement}
                </Badge>
                <div className="text-sm text-green-600 font-semibold">
                  ${result.prize.toLocaleString()}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}