'use client'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { paddleDatabase } from '@/lib/paddleData'
import type { Paddle } from '@/types/paddle'

interface Review {
  id: string
  paddleId: string
  userName: string
  rating: number
  reviewText: string
  skillLevel: string
  playStyle: string
  monthsUsed: number
  wouldRecommend: boolean
  date: string
  helpfulVotes: number
  verified: boolean
}

interface ReviewsHubProps {
  onBackToWelcome: () => void
}

export function ReviewsHub({ onBackToWelcome }: ReviewsHubProps) {
  const [reviews, setReviews] = useState<Review[]>([])
  const [selectedPaddle, setSelectedPaddle] = useState<string>('')
  const [sortBy, setSortBy] = useState<string>('newest')
  const [filterRating, setFilterRating] = useState<string>('all')
  const [isWritingReview, setIsWritingReview] = useState(false)

  // Mock reviews data - In production this would come from SpacetimeDB
  useEffect(() => {
    const mockReviews: Review[] = [
      {
        id: '1',
        paddleId: 'selkirk-vanguard-power-air',
        userName: 'CoachMike47',
        rating: 5,
        reviewText: "Absolute game changer! The raw carbon surface gives incredible spin and the power is unmatched. Took my baseline game to the next level. Worth every penny.",
        skillLevel: 'Advanced',
        playStyle: 'Singles',
        monthsUsed: 8,
        wouldRecommend: true,
        date: '2024-01-15',
        helpfulVotes: 23,
        verified: true
      },
      {
        id: '2',
        paddleId: 'selkirk-amped-epic',
        userName: 'PicklePro2024',
        rating: 4,
        reviewText: "Great control paddle for doubles. The sweet spot is huge and it's very forgiving. Perfect for improving your soft game.",
        skillLevel: 'Intermediate',
        playStyle: 'Doubles',
        monthsUsed: 12,
        wouldRecommend: true,
        date: '2024-01-10',
        helpfulVotes: 18,
        verified: true
      },
      {
        id: '3',
        paddleId: 'joola-ben-johns-hyperion',
        userName: 'TournamentTom',
        rating: 5,
        reviewText: "This paddle is a beast! Ben Johns knows what he's doing. The spin generation is off the charts and the power is incredible. Warning: not for beginners!",
        skillLevel: 'Tournament',
        playStyle: 'Both',
        monthsUsed: 6,
        wouldRecommend: true,
        date: '2024-01-08',
        helpfulVotes: 45,
        verified: true
      },
      {
        id: '4',
        paddleId: 'paddletek-bantam-ts5-pro',
        userName: 'WeekendWarrior',
        rating: 4,
        reviewText: "Solid paddle for the price. Good balance of power and control. My arm feels great after long sessions. Highly recommend for recreational players.",
        skillLevel: 'Intermediate',
        playStyle: 'Both',
        monthsUsed: 10,
        wouldRecommend: true,
        date: '2024-01-05',
        helpfulVotes: 12,
        verified: false
      }
    ]
    setReviews(mockReviews)
  }, [])

  const filteredReviews = reviews
    .filter(review => selectedPaddle === '' || review.paddleId === selectedPaddle)
    .filter(review => filterRating === 'all' || review.rating.toString() === filterRating)
    .sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.date).getTime() - new Date(a.date).getTime()
        case 'oldest':
          return new Date(a.date).getTime() - new Date(b.date).getTime()
        case 'highest':
          return b.rating - a.rating
        case 'lowest':
          return a.rating - b.rating
        case 'helpful':
          return b.helpfulVotes - a.helpfulVotes
        default:
          return 0
      }
    })

  const getPaddleName = (paddleId: string) => {
    const paddle = paddleDatabase.find(p => p.id === paddleId)
    return paddle ? `${paddle.brand} ${paddle.model}` : 'Unknown Paddle'
  }

  const renderStars = (rating: number) => {
    return '★'.repeat(rating) + '☆'.repeat(5 - rating)
  }

  const avgRating = selectedPaddle ? 
    reviews.filter(r => r.paddleId === selectedPaddle).reduce((sum, r) => sum + r.rating, 0) / 
    reviews.filter(r => r.paddleId === selectedPaddle).length : 0

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <Card className="border-2">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            💬 Community Reviews & Insights
          </CardTitle>
          <p className="text-gray-600">Real experiences from real players</p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Controls */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label>Filter by Paddle</Label>
              <Select value={selectedPaddle} onValueChange={setSelectedPaddle}>
                <SelectTrigger>
                  <SelectValue placeholder="All Paddles" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Paddles</SelectItem>
                  {paddleDatabase.map(paddle => (
                    <SelectItem key={paddle.id} value={paddle.id}>
                      {paddle.brand} {paddle.model}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Sort By</Label>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="oldest">Oldest First</SelectItem>
                  <SelectItem value="highest">Highest Rated</SelectItem>
                  <SelectItem value="lowest">Lowest Rated</SelectItem>
                  <SelectItem value="helpful">Most Helpful</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Filter Rating</Label>
              <Select value={filterRating} onValueChange={setFilterRating}>
                <SelectTrigger>
                  <SelectValue placeholder="All Ratings" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Ratings</SelectItem>
                  <SelectItem value="5">5 Stars</SelectItem>
                  <SelectItem value="4">4 Stars</SelectItem>
                  <SelectItem value="3">3 Stars</SelectItem>
                  <SelectItem value="2">2 Stars</SelectItem>
                  <SelectItem value="1">1 Star</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Dialog open={isWritingReview} onOpenChange={setIsWritingReview}>
                <DialogTrigger asChild>
                  <Button className="w-full">📝 Write Review</Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Write a Paddle Review</DialogTitle>
                  </DialogHeader>
                  <WriteReviewForm onSubmit={(review) => {
                    setReviews(prev => [...prev, { ...review, id: Date.now().toString() }])
                    setIsWritingReview(false)
                  }} />
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Paddle Summary */}
          {selectedPaddle && (
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600">
                      {avgRating.toFixed(1)}
                    </div>
                    <div className="text-yellow-500 text-xl">
                      {renderStars(Math.round(avgRating))}
                    </div>
                    <div className="text-sm text-gray-600">
                      Average Rating
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">
                      {reviews.filter(r => r.paddleId === selectedPaddle).length}
                    </div>
                    <div className="text-sm text-gray-600">
                      Total Reviews
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-600">
                      {Math.round(reviews.filter(r => r.paddleId === selectedPaddle && r.wouldRecommend).length / reviews.filter(r => r.paddleId === selectedPaddle).length * 100)}%
                    </div>
                    <div className="text-sm text-gray-600">
                      Would Recommend
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Reviews List */}
          <div className="space-y-4">
            {filteredReviews.length === 0 ? (
              <Card>
                <CardContent className="pt-6 text-center text-gray-500">
                  No reviews found matching your filters.
                </CardContent>
              </Card>
            ) : (
              filteredReviews.map(review => (
                <ReviewCard key={review.id} review={review} getPaddleName={getPaddleName} />
              ))
            )}
          </div>
        </CardContent>
      </Card>

      <div className="text-center">
        <Button variant="outline" onClick={onBackToWelcome}>
          ← Back to Coach Hub
        </Button>
      </div>
    </div>
  )
}

function ReviewCard({ review, getPaddleName }: { review: Review, getPaddleName: (id: string) => string }) {
  const renderStars = (rating: number) => '★'.repeat(rating) + '☆'.repeat(5 - rating)

  return (
    <Card className="border">
      <CardContent className="pt-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Badge variant={review.verified ? "default" : "secondary"}>
                {review.verified ? "✓ Verified Owner" : "Unverified"}
              </Badge>
              <span className="font-semibold">{review.userName}</span>
              <span className="text-sm text-gray-500">
                {review.skillLevel} • {review.playStyle} • {review.monthsUsed} months
              </span>
            </div>
            <h4 className="font-semibold text-lg">{getPaddleName(review.paddleId)}</h4>
          </div>
          <div className="text-right">
            <div className="text-yellow-500 text-lg">{renderStars(review.rating)}</div>
            <div className="text-sm text-gray-500">{review.date}</div>
          </div>
        </div>

        <p className="text-gray-700 mb-4 leading-relaxed">{review.reviewText}</p>

        <div className="flex justify-between items-center">
          <div className="flex gap-4 text-sm text-gray-600">
            <span className={review.wouldRecommend ? "text-green-600" : "text-red-600"}>
              {review.wouldRecommend ? "👍 Recommends" : "👎 Doesn't Recommend"}
            </span>
          </div>
          <Button variant="ghost" size="sm">
            👍 Helpful ({review.helpfulVotes})
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

function WriteReviewForm({ onSubmit }: { onSubmit: (review: Omit<Review, 'id'>) => void }) {
  const [formData, setFormData] = useState({
    paddleId: '',
    userName: '',
    rating: 5,
    reviewText: '',
    skillLevel: '',
    playStyle: '',
    monthsUsed: 1,
    wouldRecommend: true
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit({
      ...formData,
      date: new Date().toISOString().split('T')[0],
      helpfulVotes: 0,
      verified: false
    })
    setFormData({
      paddleId: '',
      userName: '',
      rating: 5,
      reviewText: '',
      skillLevel: '',
      playStyle: '',
      monthsUsed: 1,
      wouldRecommend: true
    })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Paddle</Label>
          <Select value={formData.paddleId} onValueChange={(value) => setFormData(prev => ({ ...prev, paddleId: value }))}>
            <SelectTrigger>
              <SelectValue placeholder="Select Paddle" />
            </SelectTrigger>
            <SelectContent>
              {paddleDatabase.map(paddle => (
                <SelectItem key={paddle.id} value={paddle.id}>
                  {paddle.brand} {paddle.model}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>Your Name</Label>
          <Input
            value={formData.userName}
            onChange={(e) => setFormData(prev => ({ ...prev, userName: e.target.value }))}
            placeholder="Your nickname"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div>
          <Label>Skill Level</Label>
          <Select value={formData.skillLevel} onValueChange={(value) => setFormData(prev => ({ ...prev, skillLevel: value }))}>
            <SelectTrigger>
              <SelectValue placeholder="Select Level" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Beginner">Beginner</SelectItem>
              <SelectItem value="Intermediate">Intermediate</SelectItem>
              <SelectItem value="Advanced">Advanced</SelectItem>
              <SelectItem value="Tournament">Tournament</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>Play Style</Label>
          <Select value={formData.playStyle} onValueChange={(value) => setFormData(prev => ({ ...prev, playStyle: value }))}>
            <SelectTrigger>
              <SelectValue placeholder="Select Style" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Singles">Singles</SelectItem>
              <SelectItem value="Doubles">Doubles</SelectItem>
              <SelectItem value="Both">Both</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>Months Used</Label>
          <Input
            type="number"
            min="1"
            max="60"
            value={formData.monthsUsed}
            onChange={(e) => setFormData(prev => ({ ...prev, monthsUsed: parseInt(e.target.value) }))}
          />
        </div>
      </div>

      <div>
        <Label>Rating</Label>
        <Select value={formData.rating.toString()} onValueChange={(value) => setFormData(prev => ({ ...prev, rating: parseInt(value) }))}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="5">5 Stars - Excellent</SelectItem>
            <SelectItem value="4">4 Stars - Very Good</SelectItem>
            <SelectItem value="3">3 Stars - Good</SelectItem>
            <SelectItem value="2">2 Stars - Fair</SelectItem>
            <SelectItem value="1">1 Star - Poor</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label>Your Review</Label>
        <Textarea
          value={formData.reviewText}
          onChange={(e) => setFormData(prev => ({ ...prev, reviewText: e.target.value }))}
          placeholder="Share your experience with this paddle..."
          rows={4}
          required
        />
      </div>

      <div className="flex items-center gap-2">
        <input
          type="checkbox"
          id="recommend"
          checked={formData.wouldRecommend}
          onChange={(e) => setFormData(prev => ({ ...prev, wouldRecommend: e.target.checked }))}
        />
        <Label htmlFor="recommend">I would recommend this paddle</Label>
      </div>

      <Button type="submit" className="w-full">
        Submit Review
      </Button>
    </form>
  )
}