'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { Identity } from 'spacetimedb';
import * as moduleBindings from '../spacetime_module_bindings';

type DbConnection = moduleBindings.DbConnection;
type EventContext = moduleBindings.EventContext;
type ErrorContext = moduleBindings.ErrorContext;
type Player = moduleBindings.Player;
type MatchRecord = moduleBindings.MatchRecord;

export interface SpacetimeDBState {
  connected: boolean;
  identity: Identity | null;
  statusMessage: string;
  players: ReadonlyMap<string, Player>;
  matches: ReadonlyMap<string, MatchRecord>;
  currentPlayer: Player | null;
  connection: DbConnection | null;
}

export interface SpacetimeDBActions {
  createPlayer: (name: string) => void;
  recordMatch: (playerAId: Identity, playerBId: Identity, scoreA: number, scoreB: number) => void;
}

export function useSpacetimeDB(): SpacetimeDBState & SpacetimeDBActions {
  const [connected, setConnected] = useState<boolean>(false);
  const [identity, setIdentity] = useState<Identity | null>(null);
  const [statusMessage, setStatusMessage] = useState<string>("Connecting...");
  const [players, setPlayers] = useState<ReadonlyMap<string, Player>>(new Map());
  const [matches, setMatches] = useState<ReadonlyMap<string, MatchRecord>>(new Map());
  const [currentPlayer, setCurrentPlayer] = useState<Player | null>(null);
  
  const connectionRef = useRef<DbConnection | null>(null);

  const subscribeToTables = useCallback(() => {
    if (!connectionRef.current) return;
    
    console.log("Subscribing to tables...");
    
    const queries: string[] = ["SELECT * FROM player", "SELECT * FROM match_record"];
    
    connectionRef.current
      .subscriptionBuilder()
      .onApplied(() => {
        console.log(`Subscription applied for: ${queries.join(", ")}`);
        processInitialCache();
      })
      .onError((error: Error) => {
        console.error(`Subscription error:`, error);
        setStatusMessage(`Subscription Error: ${error?.message || error}`);
      })
      .subscribe(queries);
  }, []);

  const processInitialCache = useCallback(() => {
    if (!connectionRef.current) return;
    console.log("Processing initial cache...");
    
    const currentPlayers = new Map<string, Player>();
    for (const player of connectionRef.current.db.player.iter()) {
      currentPlayers.set(player.identity.toHexString(), player);
    }
    setPlayers(currentPlayers);

    const currentMatches = new Map<string, MatchRecord>();
    for (const match of connectionRef.current.db.matchRecord.iter()) {
      currentMatches.set(match.id.toString(), match);
    }
    setMatches(currentMatches);
  }, []);

  const registerTableCallbacks = useCallback((currentIdentity: Identity) => {
    if (!connectionRef.current) return;
    
    console.log("Registering table callbacks...");

    // Player callbacks
    connectionRef.current.db.player.onInsert((_ctx: EventContext | undefined, player: Player) => {
      console.log("Player inserted:", player.identity.toHexString());
      setPlayers((prev: ReadonlyMap<string, Player>) =>
        new Map(prev).set(player.identity.toHexString(), player)
      );
      
      if (currentIdentity && player.identity.toHexString() === currentIdentity.toHexString()) {
        setCurrentPlayer(player);
        setStatusMessage(`Registered as ${player.name}`);
      }
    });

    connectionRef.current.db.player.onUpdate((_ctx: EventContext | undefined, _oldPlayer: Player, newPlayer: Player) => {
      setPlayers((prev: ReadonlyMap<string, Player>) => {
        const newMap = new Map(prev);
        newMap.set(newPlayer.identity.toHexString(), newPlayer);
        return newMap;
      });
      
      if (currentIdentity && newPlayer.identity.toHexString() === currentIdentity.toHexString()) {
        setCurrentPlayer(newPlayer);
      }
    });

    connectionRef.current.db.player.onDelete((_ctx: EventContext, player: Player) => {
      console.log("Player deleted:", player.identity.toHexString());
      setPlayers((prev: ReadonlyMap<string, Player>) => {
        const newMap = new Map(prev);
        newMap.delete(player.identity.toHexString());
        return newMap;
      });
    });

    // Match callbacks
    connectionRef.current.db.matchRecord.onInsert((_ctx: EventContext | undefined, match: MatchRecord) => {
      console.log("Match inserted:", match.id.toString());
      setMatches((prev: ReadonlyMap<string, MatchRecord>) =>
        new Map(prev).set(match.id.toString(), match)
      );
    });

    connectionRef.current.db.matchRecord.onUpdate((_ctx: EventContext | undefined, _oldMatch: MatchRecord, newMatch: MatchRecord) => {
      setMatches((prev: ReadonlyMap<string, MatchRecord>) => {
        const newMap = new Map(prev);
        newMap.set(newMatch.id.toString(), newMatch);
        return newMap;
      });
    });

    connectionRef.current.db.matchRecord.onDelete((_ctx: EventContext, match: MatchRecord) => {
      console.log("Match deleted:", match.id.toString());
      setMatches((prev: ReadonlyMap<string, MatchRecord>) => {
        const newMap = new Map(prev);
        newMap.delete(match.id.toString());
        return newMap;
      });
    });
  }, []);

  useEffect(() => {
    if (connectionRef.current) {
      console.log("Connection already established, skipping setup.");
      return;
    }

    const dbHost: string = "wss://maincloud.spacetimedb.com";
    const dbName: string = process.env.NEXT_PUBLIC_SPACETIME_MODULE_NAME || "default_module";

    const onConnect = (connection: DbConnection, id: Identity, _token: string) => {
      console.log("Connected!");
      connectionRef.current = connection;
      setIdentity(id);
      setConnected(true);
      setStatusMessage(`Connected as ${id.toHexString().substring(0, 8)}...`);
      
      subscribeToTables();
      registerTableCallbacks(id);
    };

    const onDisconnect = (_ctx: ErrorContext, reason?: Error | null) => {
      const reasonStr: string = reason ? reason.message : "No reason given";
      console.log("Disconnected:", reasonStr);
      setStatusMessage(`Disconnected: ${reasonStr}`);
      connectionRef.current = null;
      setIdentity(null);
      setConnected(false);
    };

    moduleBindings.DbConnection.builder()
      .withUri(dbHost)
      .withModuleName(dbName)
      .onConnect(onConnect)
      .onDisconnect(onDisconnect)
      .build();
  }, [subscribeToTables, registerTableCallbacks]);

  const createPlayer = useCallback((name: string) => {
    if (!connectionRef.current || !connected) {
      console.error("Not connected to database");
      return;
    }
    
    connectionRef.current.reducers.createPlayer(name);
  }, [connected]);

  const recordMatch = useCallback((playerAId: Identity, playerBId: Identity, scoreA: number, scoreB: number) => {
    if (!connectionRef.current || !connected) {
      console.error("Not connected to database");
      return;
    }
    
    connectionRef.current.reducers.recordMatch(playerAId, playerBId, scoreA, scoreB);
  }, [connected]);

  return {
    connected,
    identity,
    statusMessage,
    players,
    matches,
    currentPlayer,
    connection: connectionRef.current,
    createPlayer,
    recordMatch,
  };
}
