import type { AdvancedPaddleSpecs } from '@/types/advanced-paddle'

// Advanced technical specifications database
export const advancedPaddleSpecs: Record<string, AdvancedPaddleSpecs> = {
  'selkirk-vanguard-power-air': {
    swingWeight: 115,
    twistWeight: 6.8,
    balancePoint: 22.5,
    kewCor: 0.87,
    deflection: 2.3,
    staticWeight: 228,
    sweetSpotSize: 'Medium',
    vibrationDamping: 7,
    durabilityRating: 8,
    proPlayerUsage: ['Tyson McGuffin', 'Matt Wright'],
    tournamentWins: 15,
    releaseNotes: 'Revolutionary Air Core technology reduces weight while maintaining power',
    generationalUpdate: '15% lighter than original Vanguard with 8% more power',
    carbonLayerCount: 6,
    coreHoneycombDensity: 42,
    edgeGuardMaterial: 'Reinforced ABS',
    handleWrapType: 'Cushioned Grip',
    coatingType: 'Raw Carbon Texture'
  },
  'joola-ben-johns-hyperion': {
    swingWeight: 118,
    twistWeight: 7.2,
    balancePoint: 23.1,
    kewCor: 0.94,
    deflection: 1.8,
    staticWeight: 235,
    sweetSpotSize: 'Large',
    vibrationDamping: 6,
    durabilityRating: 9,
    proPlayerUsage: ['Ben Johns', 'Anna Leigh Waters'],
    tournamentWins: 28,
    releaseNotes: 'Ben Johns signature paddle - maximum spin and power',
    generationalUpdate: 'Complete redesign with ChargeFeel Surface for unprecedented spin',
    carbonLayerCount: 8,
    coreHoneycombDensity: 38,
    edgeGuardMaterial: 'Carbon Fiber Edge',
    handleWrapType: 'Ridged Performance',
    coatingType: 'ChargeFeel Surface (CFS)'
  },
  'paddletek-bantam-ts5-pro': {
    swingWeight: 110,
    twistWeight: 6.2,
    balancePoint: 21.8,
    kewCor: 0.79,
    deflection: 2.6,
    staticWeight: 221,
    sweetSpotSize: 'Medium',
    vibrationDamping: 8,
    durabilityRating: 8,
    proPlayerUsage: ['Thomas Wilson', 'Jessie Irvine'],
    tournamentWins: 12,
    releaseNotes: 'Smart Response Technology adapts to your swing speed',
    generationalUpdate: '12% better feel than TS-5 with improved arm comfort',
    carbonLayerCount: 5,
    coreHoneycombDensity: 45,
    edgeGuardMaterial: 'TPU Edge Guard',
    handleWrapType: 'Comfort Plus',
    coatingType: 'Smooth Carbon'
  },
  'engage-pursuit-mx': {
    swingWeight: 116,
    twistWeight: 7.0,
    balancePoint: 22.9,
    kewCor: 0.89,
    deflection: 2.1,
    staticWeight: 232,
    sweetSpotSize: 'Large',
    vibrationDamping: 6,
    durabilityRating: 9,
    proPlayerUsage: ['Morgan Evans', 'Federico Staksrud'],
    tournamentWins: 19,
    releaseNotes: 'Maximum power paddle with Engage\'s signature control',
    generationalUpdate: 'New MX surface adds 15% more spin than previous Pursuit',
    carbonLayerCount: 7,
    coreHoneycombDensity: 40,
    edgeGuardMaterial: 'Composite Edge',
    handleWrapType: 'Tour Grip',
    coatingType: 'MX Raw Carbon'
  },
  'head-extreme-tour': {
    swingWeight: 117,
    twistWeight: 7.3,
    balancePoint: 23.0,
    kewCor: 0.91,
    deflection: 1.9,
    staticWeight: 238,
    sweetSpotSize: 'Large',
    vibrationDamping: 7,
    durabilityRating: 9,
    proPlayerUsage: ['Andrei Daescu', 'Jackie Kawamoto'],
    tournamentWins: 22,
    releaseNotes: 'Tennis heritage meets pickleball innovation - maximum spin generation',
    generationalUpdate: 'Tennis-inspired design with 20% better spin than standard models',
    carbonLayerCount: 9,
    coreHoneycombDensity: 36,
    edgeGuardMaterial: 'HEAD TK Edge',
    handleWrapType: 'Hydrosorb Pro',
    coatingType: 'Auxetic Carbon Surface'
  },
  'gearbox-cx11e-power': {
    swingWeight: 119,
    twistWeight: 7.5,
    balancePoint: 23.4,
    kewCor: 0.96,
    deflection: 1.6,
    staticWeight: 241,
    sweetSpotSize: 'Medium',
    vibrationDamping: 5,
    durabilityRating: 9,
    proPlayerUsage: ['Kyle Yates', 'Lucy Kovalova'],
    tournamentWins: 25,
    releaseNotes: 'Thinnest legal core for maximum power and responsiveness',
    generationalUpdate: '11mm core provides 25% more power than 16mm equivalent',
    carbonLayerCount: 8,
    coreHoneycombDensity: 48,
    edgeGuardMaterial: 'Carbon Wrapped Edge',
    handleWrapType: 'Power Grip',
    coatingType: 'Raw Power Surface'
  }
}

// Professional player database for insights
export const professionalPlayers = {
  'Ben Johns': {
    preferredSpecs: { swingWeight: 115, twistWeight: 7.0, balancePoint: 23.0 },
    playStyle: 'All-court dominance with precision power',
    majorTitles: 15,
    currentPaddle: 'joola-ben-johns-hyperion'
  },
  'Anna Leigh Waters': {
    preferredSpecs: { swingWeight: 112, twistWeight: 6.5, balancePoint: 22.5 },
    playStyle: 'Aggressive net play with incredible hands',
    majorTitles: 12,
    currentPaddle: 'joola-ben-johns-hyperion'
  },
  'Tyson McGuffin': {
    preferredSpecs: { swingWeight: 116, twistWeight: 7.2, balancePoint: 22.8 },
    playStyle: 'Power baseline with strategic placement',
    majorTitles: 8,
    currentPaddle: 'selkirk-vanguard-power-air'
  }
}

// Regional paddle preferences based on climate and play style
export const regionalPreferences = {
  'Southwest USA': {
    topChoices: ['engage-pursuit-mx', 'selkirk-vanguard-power-air'],
    climate: 'Hot, dry, high altitude',
    adjustments: ['Lower string tension', 'Lighter weight preferred', 'Power focus'],
    uniqueFactors: ['Altitude affects ball bounce', 'Heat requires comfort grips']
  },
  'Southeast USA': {
    topChoices: ['paddletek-bantam-ts5-pro', 'babolat-air-veron'],
    climate: 'Hot, humid, sea level',
    adjustments: ['Moisture-wicking grips', 'Higher durability needed', 'Control emphasis'],
    uniqueFactors: ['Humidity affects paddle feel', 'Frequent play requires durability']
  },
  'Northeast USA': {
    topChoices: ['head-extreme-tour', 'yonex-ezone-100'],
    climate: 'Variable, cold winters, moderate summers',
    adjustments: ['All-weather performance', 'Versatile specs', 'Indoor/outdoor flexibility'],
    uniqueFactors: ['Temperature changes affect paddle', 'Indoor play prevalent in winter']
  },
  'Pacific Northwest': {
    topChoices: ['gearbox-pro-control', 'joola-vision-cgr'],
    climate: 'Cool, wet, overcast',
    adjustments: ['Weather-resistant materials', 'Better grip in wet conditions'],
    uniqueFactors: ['Frequent rain requires covered courts', 'Softer play style preferred']
  }
}

// Advanced paddle comparison algorithm
export function compareAdvancedPaddles(paddleA: string, paddleB: string) {
  const specA = advancedPaddleSpecs[paddleA]
  const specB = advancedPaddleSpecs[paddleB]
  
  if (!specA || !specB) {
    return null
  }

  const differences = [
    {
      category: 'Power Generation',
      paddleAValue: specA.kewCor,
      paddleBValue: specB.kewCor,
      impact: Math.abs(specA.kewCor - specB.kewCor) > 0.1 ? 'Major' as const : 
              Math.abs(specA.kewCor - specB.kewCor) > 0.05 ? 'Moderate' as const : 'Minor' as const,
      explanation: specA.kewCor > specB.kewCor ? 
        `Paddle A generates ${((specA.kewCor - specB.kewCor) * 100).toFixed(1)}% more power` :
        `Paddle B generates ${((specB.kewCor - specA.kewCor) * 100).toFixed(1)}% more power`
    },
    {
      category: 'Swing Feel',
      paddleAValue: specA.swingWeight,
      paddleBValue: specB.swingWeight,
      impact: Math.abs(specA.swingWeight - specB.swingWeight) > 8 ? 'Major' as const : 
              Math.abs(specA.swingWeight - specB.swingWeight) > 4 ? 'Moderate' as const : 'Minor' as const,
      explanation: specA.swingWeight > specB.swingWeight ?
        `Paddle A feels ${specA.swingWeight - specB.swingWeight} points heavier through the swing` :
        `Paddle B feels ${specB.swingWeight - specA.swingWeight} points heavier through the swing`
    },
    {
      category: 'Stability',
      paddleAValue: specA.twistWeight,
      paddleBValue: specB.twistWeight,
      impact: Math.abs(specA.twistWeight - specB.twistWeight) > 1.0 ? 'Major' as const :
              Math.abs(specA.twistWeight - specB.twistWeight) > 0.5 ? 'Moderate' as const : 'Minor' as const,
      explanation: specA.twistWeight > specB.twistWeight ?
        `Paddle A is ${((specA.twistWeight - specB.twistWeight) / specB.twistWeight * 100).toFixed(1)}% more stable on off-center hits` :
        `Paddle B is ${((specB.twistWeight - specA.twistWeight) / specA.twistWeight * 100).toFixed(1)}% more stable on off-center hits`
    },
    {
      category: 'Vibration Comfort',
      paddleAValue: specA.vibrationDamping,
      paddleBValue: specB.vibrationDamping,
      impact: Math.abs(specA.vibrationDamping - specB.vibrationDamping) > 2 ? 'Major' as const :
              Math.abs(specA.vibrationDamping - specB.vibrationDamping) > 1 ? 'Moderate' as const : 'Minor' as const,
      explanation: specA.vibrationDamping > specB.vibrationDamping ?
        `Paddle A provides ${specA.vibrationDamping - specB.vibrationDamping} points better vibration dampening` :
        `Paddle B provides ${specB.vibrationDamping - specA.vibrationDamping} points better vibration dampening`
    },
    {
      category: 'Professional Success',
      paddleAValue: specA.tournamentWins,
      paddleBValue: specB.tournamentWins,
      impact: Math.abs(specA.tournamentWins - specB.tournamentWins) > 10 ? 'Major' as const :
              Math.abs(specA.tournamentWins - specB.tournamentWins) > 5 ? 'Moderate' as const : 'Minor' as const,
      explanation: specA.tournamentWins > specB.tournamentWins ?
        `Paddle A has ${specA.tournamentWins - specB.tournamentWins} more major tournament wins` :
        `Paddle B has ${specB.tournamentWins - specA.tournamentWins} more major tournament wins`
    }
  ]

  // Determine overall recommendation
  let aScore = 0
  let bScore = 0
  
  differences.forEach(diff => {
    if (diff.paddleAValue > diff.paddleBValue) aScore++
    else if (diff.paddleBValue > diff.paddleAValue) bScore++
  })

  return {
    paddleA,
    paddleB,
    differences,
    recommendation: aScore > bScore ? 
      `Paddle A (${paddleA}) edges out Paddle B with superior ${differences.filter(d => d.paddleAValue > d.paddleBValue).map(d => d.category.toLowerCase()).slice(0, 2).join(' and ')}` :
      bScore > aScore ?
      `Paddle B (${paddleB}) edges out Paddle A with superior ${differences.filter(d => d.paddleBValue > d.paddleAValue).map(d => d.category.toLowerCase()).slice(0, 2).join(' and ')}` :
      'Both paddles are extremely close - personal preference will be the deciding factor',
    winnerCategory: aScore > bScore ? 'A' as const : bScore > aScore ? 'B' as const : 'Tie' as const
  }
}

// Weather-based recommendations
export function getWeatherRecommendations(temp: number, humidity: number, windSpeed: number) {
  let adjustments = {
    paddleAdjustment: '',
    gripRecommendation: '',
    playStyleTips: [] as string[]
  }

  // Temperature adjustments
  if (temp > 85) {
    adjustments.paddleAdjustment = 'Consider lighter weight paddle - heat makes everything feel heavier'
    adjustments.gripRecommendation = 'Use moisture-wicking overgrip or tacky grip'
    adjustments.playStyleTips.push('Take frequent water breaks', 'Focus on placement over power')
  } else if (temp < 50) {
    adjustments.paddleAdjustment = 'Paddle may feel stiffer - allow extra warm-up time'
    adjustments.gripRecommendation = 'Standard grip should be fine, hands stay drier'
    adjustments.playStyleTips.push('Extended warm-up crucial', 'Ball bounces lower in cold')
  }

  // Humidity adjustments  
  if (humidity > 70) {
    adjustments.gripRecommendation = 'Essential: moisture-wicking grip or frequent towel use'
    adjustments.playStyleTips.push('Ball feels heavier and slower', 'Clean paddle face frequently')
  }

  // Wind adjustments
  if (windSpeed > 10) {
    adjustments.paddleAdjustment = 'Heavier paddle provides more stability in wind'
    adjustments.playStyleTips.push('Adjust for wind drift on serves', 'Lower trajectory shots work better')
  }

  return {
    temperature: temp,
    humidity,
    windSpeed,
    recommendation: adjustments
  }
}