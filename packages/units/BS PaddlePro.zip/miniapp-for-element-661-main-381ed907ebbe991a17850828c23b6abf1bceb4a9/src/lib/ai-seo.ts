import type { Paddle } from '@/types/paddle'
import type { SEOContent, TrendAnalysis } from '@/types/advanced-paddle'
import { paddleDatabase } from './paddleData'
import { advancedPaddleSpecs, professionalPlayers } from './advancedPaddleData'

// Generate dynamic SEO content for paddle pages
export function generatePaddleSEO(paddle: Paddle): SEOContent {
  const advancedSpecs = advancedPaddleSpecs[paddle.id]
  
  // Generate AI-style review content
  const aiReview = generateAIReview(paddle, advancedSpecs)
  
  // Generate comparison content
  const comparisonContent = generateComparisonContent(paddle)
  
  // Generate FAQ sections
  const faqSections = generateFAQs(paddle)
  
  return {
    title: `${paddle.brand} ${paddle.model} Review 2024 - Expert Paddle Analysis | PicklePaddle`,
    description: `In-depth review of the ${paddle.brand} ${paddle.model}. Technical specs, pros vs performance, and expert recommendations. ${paddle.bestFor}`,
    keywords: [
      paddle.brand.toLowerCase(),
      paddle.model.toLowerCase(),
      'pickleball paddle',
      'paddle review',
      paddle.surface.toLowerCase(),
      paddle.shape.toLowerCase(),
      'USAP approved',
      '2024 paddle',
      'paddle comparison',
      'expert review'
    ],
    structuredData: generateStructuredData(paddle),
    aiGeneratedReview: aiReview,
    comparisonContent,
    faqSections
  }
}

function generateAIReview(paddle: Paddle, specs: any): string {
  const proUsers = specs?.proPlayerUsage?.join(', ') || 'various professionals'
  const standoutFeature = specs?.releaseNotes || paddle.bestFor
  
  return `After extensive testing and analysis, the ${paddle.brand} ${paddle.model} emerges as a ${
    paddle.powerRating >= 4 ? 'power-oriented' : paddle.controlRating >= 4 ? 'control-focused' : 'balanced'
  } paddle that delivers on its promises.

**Performance Summary:**
This ${paddle.year} release showcases ${paddle.surface} construction with a ${paddle.core} core, resulting in ${
    paddle.powerRating >= 4 ? 'impressive power generation' : 'excellent touch and feel'
  }. The ${paddle.shape} shape caters to ${
    paddle.shape === 'Elongated' ? 'players seeking reach and power' : 'players prioritizing quick hands and forgiveness'
  }.

**Professional Validation:**
Currently used by ${proUsers}, this paddle has proven itself in competitive play${
    specs?.tournamentWins ? ` with ${specs.tournamentWins} major tournament victories` : ''
  }.

**Technical Excellence:**
${standoutFeature}${specs?.kewCor ? ` Our lab testing confirms a KEWCoR rating of ${specs.kewCor}, placing it in the ${
    specs.kewCor > 0.9 ? 'elite power' : specs.kewCor > 0.8 ? 'high performance' : 'control-oriented'
  } category.` : ''}

**Bottom Line:**
${paddle.armFriendly ? 'Arm-friendly design makes this accessible for extended play sessions.' : 'Performance-focused design may require conditioning for sensitive players.'} ${
    paddle.bestFor
  } At ${paddle.priceRange}, it represents ${
    extractPrice(paddle.priceRange) > 200 ? 'premium value for serious players' : 
    extractPrice(paddle.priceRange) > 150 ? 'excellent mid-range performance' : 'outstanding budget-friendly quality'
  }.`
}

function generateComparisonContent(paddle: Paddle): string {
  const competitors = paddleDatabase.filter(p => 
    p.id !== paddle.id && 
    p.brand !== paddle.brand &&
    Math.abs(p.powerRating - paddle.powerRating) <= 1 &&
    Math.abs(p.controlRating - paddle.controlRating) <= 1
  ).slice(0, 3)

  if (competitors.length === 0) return ''

  return `**How it compares:**

${competitors.map(comp => 
  `vs ${comp.brand} ${comp.model}: ${
    paddle.powerRating > comp.powerRating ? 'More power-oriented' :
    paddle.powerRating < comp.powerRating ? 'More control-focused' : 'Similar power level'
  }, ${
    paddle.armFriendly && !comp.armFriendly ? 'better arm comfort' :
    !paddle.armFriendly && comp.armFriendly ? 'less forgiving on the arm' : 'comparable comfort'
  }.`
).join('\n')}`
}

function generateFAQs(paddle: Paddle): { question: string; answer: string }[] {
  const specs = advancedPaddleSpecs[paddle.id]
  
  return [
    {
      question: `Is the ${paddle.brand} ${paddle.model} USAP approved?`,
      answer: `Yes, the ${paddle.brand} ${paddle.model} is ${paddle.usapApproved ? 'fully USAP approved' : 'pending USAP approval'} for tournament play.`
    },
    {
      question: `What skill level is the ${paddle.brand} ${paddle.model} best for?`,
      answer: `${paddle.bestFor} ${
        paddle.armFriendly ? 'The arm-friendly design makes it suitable for players with elbow sensitivity.' : 'Best suited for players comfortable with higher performance paddles.'
      }`
    },
    {
      question: `How does the ${paddle.surface} surface affect play?`,
      answer: `${paddle.surface} surfaces provide ${
        paddle.surface === 'Raw Carbon' ? 'maximum spin generation and power, ideal for aggressive players' :
        paddle.surface === 'Carbon Fiber' ? 'excellent balance of power and control with good durability' :
        'predictable feel and excellent control, perfect for learning proper technique'
      }. Spin rating: ${paddle.spinRating}/5, Power rating: ${paddle.powerRating}/5.`
    },
    {
      question: `What's the price range for the ${paddle.brand} ${paddle.model}?`,
      answer: `The ${paddle.brand} ${paddle.model} typically retails for ${paddle.priceRange}${
        specs?.generationalUpdate ? `. ${specs.generationalUpdate}` : ''
      }`
    }
  ]
}

function generateStructuredData(paddle: Paddle) {
  return {
    "@context": "https://schema.org",
    "@type": "Product",
    "name": `${paddle.brand} ${paddle.model}`,
    "image": `/api/paddle-image/${paddle.id}`,
    "description": paddle.bestFor,
    "brand": {
      "@type": "Brand",
      "name": paddle.brand
    },
    "offers": {
      "@type": "Offer",
      "priceCurrency": "USD",
      "price": extractPrice(paddle.priceRange),
      "availability": "https://schema.org/InStock"
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": Math.round((paddle.powerRating + paddle.controlRating + paddle.spinRating) / 3 * 2) / 2,
      "reviewCount": Math.floor(Math.random() * 100) + 20
    },
    "review": {
      "@type": "Review",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": Math.round((paddle.powerRating + paddle.controlRating + paddle.spinRating) / 3 * 2) / 2
      },
      "author": {
        "@type": "Organization",
        "name": "PicklePaddle Intelligence"
      }
    }
  }
}

function extractPrice(priceRange: string): number {
  const numbers = priceRange.match(/\d+/g)
  return numbers ? parseInt(numbers[0]) : 0
}

// Generate trend analysis for SEO and insights
export function generateTrendAnalysis(): TrendAnalysis {
  // Mock trend data - in production would analyze real search/sales data
  const topPaddles = [
    { paddleId: 'joola-ben-johns-hyperion', searchVolume: 15400, trendDirection: 'up' as const, percentChange: 23 },
    { paddleId: 'selkirk-vanguard-power-air', searchVolume: 12200, trendDirection: 'up' as const, percentChange: 18 },
    { paddleId: 'engage-pursuit-mx', searchVolume: 9800, trendDirection: 'stable' as const, percentChange: 2 },
    { paddleId: 'head-extreme-tour', searchVolume: 8600, trendDirection: 'up' as const, percentChange: 31 },
    { paddleId: 'gearbox-cx11e-power', searchVolume: 7200, trendDirection: 'down' as const, percentChange: -8 }
  ]

  return {
    period: 'month',
    topPaddles,
    emergingBrands: ['YONEX', 'Babolat', 'HEAD'],
    decliningSurfaces: ['Basic Fiberglass', 'Polymer'],
    regionalPreferences: [
      {
        region: 'Southwest USA',
        topChoices: ['engage-pursuit-mx', 'selkirk-vanguard-power-air'],
        uniqueFactors: ['High altitude play', 'Hot weather considerations', 'Power-focused game']
      },
      {
        region: 'Northeast USA', 
        topChoices: ['head-extreme-tour', 'paddletek-bantam-ts5-pro'],
        uniqueFactors: ['Indoor/outdoor versatility', 'Weather resistance', 'Tennis crossover appeal']
      }
    ]
  }
}

// Generate location-specific SEO content
export function generateLocationSEO(city: string, state: string): SEOContent {
  return {
    title: `Best Pickleball Paddles in ${city}, ${state} - Local Store Guide | PicklePaddle`,
    description: `Find the perfect pickleball paddle in ${city}, ${state}. Local store recommendations, climate-specific advice, and regional preferences.`,
    keywords: [
      `pickleball ${city}`,
      `paddle stores ${state}`,
      'local pickleball gear',
      'paddle recommendations',
      `${city} sporting goods`
    ],
    structuredData: {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "PicklePaddle Intelligence",
      "description": `Pickleball paddle recommendations for ${city}, ${state}`,
      "areaServed": {
        "@type": "City",
        "name": city,
        "containedInPlace": state
      }
    },
    aiGeneratedReview: `Playing pickleball in ${city}, ${state} presents unique considerations for paddle selection...`,
    comparisonContent: '',
    faqSections: [
      {
        question: `What are the best paddle stores in ${city}?`,
        answer: 'Our location finder shows nearby retailers with paddle selection, demo availability, and expert fitting services.'
      },
      {
        question: `How does ${state} climate affect paddle choice?`,
        answer: 'Regional weather patterns influence grip selection, material preferences, and seasonal considerations for optimal performance.'
      }
    ]
  }
}