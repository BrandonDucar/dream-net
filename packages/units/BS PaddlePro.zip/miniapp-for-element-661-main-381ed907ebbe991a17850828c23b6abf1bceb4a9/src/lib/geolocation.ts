import type { LocationData, RetailerLocation } from '@/types/advanced-paddle'

// Get user's current location
export async function getUserLocation(): Promise<LocationData | null> {
  return new Promise((resolve) => {
    if (!navigator.geolocation) {
      console.log('Geolocation not supported')
      resolve(null)
      return
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords
        
        try {
          // Reverse geocode to get address details
          const response = await fetch(
            `https://api.openweathermap.org/geo/1.0/reverse?lat=${latitude}&lon=${longitude}&limit=1&appid=demo` // Using demo key for now
          )
          
          if (!response.ok) {
            throw new Error('Geocoding failed')
          }
          
          const data = await response.json()
          const location = data[0]
          
          resolve({
            latitude,
            longitude,
            city: location?.name || 'Unknown',
            state: location?.state || 'Unknown', 
            zipCode: 'Unknown',
            country: location?.country || 'Unknown'
          })
        } catch (error) {
          console.error('Geocoding error:', error)
          // Return basic coords if geocoding fails
          resolve({
            latitude,
            longitude,
            city: 'Unknown',
            state: 'Unknown',
            zipCode: 'Unknown',
            country: 'Unknown'
          })
        }
      },
      (error) => {
        console.log('Geolocation permission denied or failed:', error)
        resolve(null)
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000 // 5 minutes
      }
    )
  })
}

// Mock retailer database - in production would integrate with Google Places API
export const retailerDatabase: RetailerLocation[] = [
  {
    name: 'Dick\'s Sporting Goods',
    address: '123 Sports Ave',
    phone: '(555) 123-4567',
    website: 'dickssportinggoods.com',
    distance: 0,
    paddleBrands: ['Wilson', 'HEAD', 'Franklin'],
    hasDemo: false,
    hasStringing: false,
    rating: 4.2,
    reviews: 156
  },
  {
    name: 'Game-Set-Match Pro Shop',
    address: '456 Tennis Court Rd',
    phone: '(555) 234-5678', 
    website: 'gamesetmatch.com',
    distance: 0,
    paddleBrands: ['Selkirk', 'JOOLA', 'Paddletek', 'Engage'],
    hasDemo: true,
    hasStringing: true,
    rating: 4.8,
    reviews: 89
  },
  {
    name: 'Big 5 Sporting Goods',
    address: '789 Athletic Blvd',
    phone: '(555) 345-6789',
    website: 'big5sportinggoods.com', 
    distance: 0,
    paddleBrands: ['Franklin', 'Wilson', 'NIUPIPO'],
    hasDemo: false,
    hasStringing: false,
    rating: 3.9,
    reviews: 203
  },
  {
    name: 'Specialty Pickleball Pro Shop',
    address: '321 Pickleball Lane',
    phone: '(555) 456-7890',
    website: 'pickleballpro.com',
    distance: 0,
    paddleBrands: ['Selkirk', 'JOOLA', 'Engage', 'HEAD', 'Gearbox', 'YONEX'],
    hasDemo: true,
    hasStringing: true,
    rating: 4.9,
    reviews: 67
  },
  {
    name: 'Academy Sports + Outdoors',
    address: '654 Outdoor Way',
    phone: '(555) 567-8901',
    website: 'academy.com',
    distance: 0,
    paddleBrands: ['Franklin', 'Wilson', 'Babolat'],
    hasDemo: false,
    hasStringing: false,
    rating: 4.1,
    reviews: 178
  }
]

// Calculate distance between two coordinates (Haversine formula)
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3959 // Earth's radius in miles
  const dLat = (lat2 - lat1) * Math.PI / 180
  const dLon = (lon2 - lon1) * Math.PI / 180
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon/2) * Math.sin(dLon/2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
  return R * c
}

// Find nearby retailers based on user location
export async function findNearbyRetailers(userLocation: LocationData, maxDistance: number = 25): Promise<RetailerLocation[]> {
  // Generate random coordinates near user location for demo
  const retailers = retailerDatabase.map(retailer => {
    // Add some random variance to create realistic distances
    const latOffset = (Math.random() - 0.5) * 0.5 // ~25 mile radius
    const lonOffset = (Math.random() - 0.5) * 0.5
    
    const retailerLat = userLocation.latitude + latOffset
    const retailerLon = userLocation.longitude + lonOffset
    
    const distance = calculateDistance(
      userLocation.latitude,
      userLocation.longitude,
      retailerLat,
      retailerLon
    )
    
    return {
      ...retailer,
      distance: Math.round(distance * 10) / 10 // Round to 1 decimal
    }
  })
  
  return retailers
    .filter(retailer => retailer.distance <= maxDistance)
    .sort((a, b) => a.distance - b.distance)
}

// Get weather data for location-based recommendations
export async function getWeatherData(latitude: number, longitude: number) {
  try {
    // Using demo weather data - in production would use real weather API
    return {
      temperature: Math.round(65 + Math.random() * 30), // 65-95°F
      humidity: Math.round(30 + Math.random() * 50), // 30-80%
      windSpeed: Math.round(Math.random() * 15), // 0-15 mph
      description: ['Sunny', 'Partly Cloudy', 'Overcast', 'Light Wind'][Math.floor(Math.random() * 4)]
    }
  } catch (error) {
    console.error('Weather fetch failed:', error)
    return {
      temperature: 75,
      humidity: 50,
      windSpeed: 5,
      description: 'Mild'
    }
  }
}