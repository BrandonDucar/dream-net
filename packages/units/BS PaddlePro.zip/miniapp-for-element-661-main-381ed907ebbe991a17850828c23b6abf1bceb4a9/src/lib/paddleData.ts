import type { Paddle, UserPreferences, PaddleRecommendation } from '@/types/paddle'

export const paddleDatabase: Paddle[] = [
  // SELKIRK PADDLES
  {
    id: 'selkirk-vanguard-power-air',
    brand: 'Selkirk',
    model: 'Vanguard Power Air',
    year: 2024,
    surface: 'Raw Carbon',
    shape: 'Elongated',
    core: '16mm',
    weight: '7.8-8.3 oz',
    swingWeight: '112-118',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 5,
    controlRating: 3,
    spinRating: 4,
    usapApproved: true,
    priceRange: '$200-220',
    armFriendly: false,
    bestFor: 'Advanced players seeking maximum power and spin for aggressive baseline play'
  },
  {
    id: 'selkirk-amped-epic',
    brand: 'Selkirk',
    model: 'AMPED Epic',
    year: 2023,
    surface: 'Fiberglass',
    shape: 'Widebody',
    core: '13mm',
    weight: '7.0-7.5 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 3,
    controlRating: 5,
    spinRating: 3,
    usapApproved: true,
    priceRange: '$120-140',
    armFriendly: true,
    bestFor: 'Intermediate players wanting excellent touch and control, especially for doubles'
  },
  {
    id: 'selkirk-labs-002',
    brand: 'Selkirk',
    model: 'Labs Project 002',
    year: 2024,
    surface: 'Raw Carbon',
    shape: 'Elongated',
    core: '14mm',
    weight: '8.0-8.5 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 4,
    controlRating: 4,
    spinRating: 5,
    usapApproved: true,
    priceRange: '$250-270',
    armFriendly: false,
    bestFor: 'Tournament players who want cutting-edge technology and maximum spin'
  },

  // PADDLETEK PADDLES
  {
    id: 'paddletek-bantam-ts5-pro',
    brand: 'Paddletek',
    model: 'Bantam TS-5 Pro',
    year: 2023,
    surface: 'Carbon Fiber',
    shape: 'Elongated',
    core: '13mm',
    weight: '7.3-7.8 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 4,
    controlRating: 4,
    spinRating: 3,
    usapApproved: true,
    priceRange: '$160-180',
    armFriendly: true,
    bestFor: 'Competitive players seeking balanced power and control with arm comfort'
  },
  {
    id: 'paddletek-tempest-wave-pro',
    brand: 'Paddletek',
    model: 'Tempest Wave Pro',
    year: 2024,
    surface: 'Carbon Fiber',
    shape: 'Widebody',
    core: '16mm',
    weight: '7.8-8.1 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 4,
    controlRating: 3,
    spinRating: 4,
    usapApproved: true,
    priceRange: '$180-200',
    armFriendly: true,
    bestFor: 'Players transitioning to higher performance with manageable power increase'
  },
  {
    id: 'paddletek-ranger-pro',
    brand: 'Paddletek',
    model: 'Ranger Pro',
    year: 2023,
    surface: 'Fiberglass',
    shape: 'Widebody',
    core: '16mm',
    weight: '7.5-8.0 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 3,
    controlRating: 4,
    spinRating: 2,
    usapApproved: true,
    priceRange: '$80-100',
    armFriendly: true,
    bestFor: 'Beginners and recreational players wanting reliable control at great value'
  },

  // BABOLAT PADDLES
  {
    id: 'babolat-air-veron',
    brand: 'Babolat',
    model: 'Air Veron',
    year: 2024,
    surface: 'Carbon Fiber',
    shape: 'Elongated',
    core: '16mm',
    weight: '7.4-7.9 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 4,
    controlRating: 4,
    spinRating: 3,
    usapApproved: true,
    priceRange: '$170-190',
    armFriendly: true,
    bestFor: 'All-court players who want French engineering precision and balance'
  },
  {
    id: 'babolat-counter-veron',
    brand: 'Babolat',
    model: 'Counter Veron',
    year: 2024,
    surface: 'Fiberglass',
    shape: 'Widebody',
    core: '16mm',
    weight: '7.6-8.1 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 3,
    controlRating: 5,
    spinRating: 2,
    usapApproved: true,
    priceRange: '$130-150',
    armFriendly: true,
    bestFor: 'Defensive players who prioritize placement and consistency over power'
  },

  // JOOLA PADDLES
  {
    id: 'joola-ben-johns-hyperion',
    brand: 'JOOLA',
    model: 'Ben Johns Hyperion CFS',
    year: 2024,
    surface: 'Raw Carbon',
    shape: 'Elongated',
    core: '14mm',
    weight: '8.0-8.5 oz',
    swingWeight: '115-120',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 5,
    controlRating: 3,
    spinRating: 5,
    usapApproved: true,
    priceRange: '$220-250',
    armFriendly: false,
    bestFor: 'Elite players who can handle the most aggressive paddle on the market'
  },
  {
    id: 'joola-vision-cgr',
    brand: 'JOOLA',
    model: 'Vision CGR',
    year: 2023,
    surface: 'Carbon Fiber',
    shape: 'Widebody',
    core: '16mm',
    weight: '7.5-8.0 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 3,
    controlRating: 4,
    spinRating: 3,
    usapApproved: true,
    priceRange: '$140-160',
    armFriendly: true,
    bestFor: 'Intermediate players wanting proven German engineering and reliability'
  },
  {
    id: 'joola-collin-johns-scorpeus',
    brand: 'JOOLA',
    model: 'Collin Johns Scorpeus CAS',
    year: 2024,
    surface: 'Raw Carbon',
    shape: 'Elongated',
    core: '16mm',
    weight: '7.8-8.3 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 4,
    controlRating: 4,
    spinRating: 4,
    usapApproved: true,
    priceRange: '$200-220',
    armFriendly: false,
    bestFor: 'Advanced players seeking high performance with more control than the Hyperion'
  },

  // GEARBOX PADDLES
  {
    id: 'gearbox-pro-control',
    brand: 'Gearbox',
    model: 'Pro Control Elongated',
    year: 2023,
    surface: 'Carbon Fiber',
    shape: 'Elongated',
    core: '16mm',
    weight: '7.5-8.0 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 3,
    controlRating: 5,
    spinRating: 3,
    usapApproved: true,
    priceRange: '$180-200',
    armFriendly: true,
    bestFor: 'Players who prioritize precision and consistency over raw power'
  },
  {
    id: 'gearbox-cx11e-power',
    brand: 'Gearbox',
    model: 'CX11E Power',
    year: 2024,
    surface: 'Carbon Fiber',
    shape: 'Elongated',
    core: '11mm',
    weight: '7.8-8.3 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 5,
    controlRating: 2,
    spinRating: 3,
    usapApproved: true,
    priceRange: '$190-210',
    armFriendly: false,
    bestFor: 'Power players who want maximum pop with thin core responsiveness'
  },

  // YONEX PADDLES
  {
    id: 'yonex-ezone-100',
    brand: 'YONEX',
    model: 'EZONE 100',
    year: 2024,
    surface: 'Carbon Fiber',
    shape: 'Widebody',
    core: '16mm',
    weight: '7.6-8.1 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 4,
    controlRating: 4,
    spinRating: 3,
    usapApproved: true,
    priceRange: '$160-180',
    armFriendly: true,
    bestFor: 'Players wanting Japanese precision engineering with balanced performance'
  },
  {
    id: 'yonex-percept-97',
    brand: 'YONEX',
    model: 'PERCEPT 97',
    year: 2024,
    surface: 'Carbon Fiber',
    shape: 'Elongated',
    core: '13mm',
    weight: '7.3-7.8 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 4,
    controlRating: 4,
    spinRating: 4,
    usapApproved: true,
    priceRange: '$180-200',
    armFriendly: true,
    bestFor: 'Advanced players who want responsive feel with excellent touch'
  },

  // WILSON PADDLES
  {
    id: 'wilson-energy-pro',
    brand: 'Wilson',
    model: 'Energy Pro',
    year: 2023,
    surface: 'Carbon Fiber',
    shape: 'Elongated',
    core: '16mm',
    weight: '7.7-8.2 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 4,
    controlRating: 3,
    spinRating: 3,
    usapApproved: true,
    priceRange: '$150-170',
    armFriendly: true,
    bestFor: 'Recreational and club players wanting reliable performance from trusted brand'
  },
  {
    id: 'wilson-blaze-pro',
    brand: 'Wilson',
    model: 'Blaze Pro',
    year: 2024,
    surface: 'Fiberglass',
    shape: 'Widebody',
    core: '16mm',
    weight: '7.4-7.9 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 3,
    controlRating: 4,
    spinRating: 2,
    usapApproved: true,
    priceRange: '$90-110',
    armFriendly: true,
    bestFor: 'Budget-conscious players who want quality without premium pricing'
  },

  // ENGAGE PADDLES
  {
    id: 'engage-pursuit-mx',
    brand: 'Engage',
    model: 'Pursuit MX 6.0',
    year: 2023,
    surface: 'Raw Carbon',
    shape: 'Elongated',
    core: '16mm',
    weight: '7.8-8.3 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 5,
    controlRating: 3,
    spinRating: 4,
    usapApproved: true,
    priceRange: '$200-220',
    armFriendly: false,
    bestFor: 'Aggressive players who want maximum power and spin generation'
  },
  {
    id: 'engage-poach-advantage',
    brand: 'Engage',
    model: 'Poach Advantage',
    year: 2023,
    surface: 'Fiberglass',
    shape: 'Widebody',
    core: '13mm',
    weight: '7.2-7.7 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 3,
    controlRating: 5,
    spinRating: 3,
    usapApproved: true,
    priceRange: '$130-150',
    armFriendly: true,
    bestFor: 'Touch players who excel at soft game and precise shot placement'
  },

  // HEAD PADDLES
  {
    id: 'head-radical-pro',
    brand: 'HEAD',
    model: 'Radical Pro',
    year: 2024,
    surface: 'Carbon Fiber',
    shape: 'Elongated',
    core: '16mm',
    weight: '7.6-8.1 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 4,
    controlRating: 4,
    spinRating: 3,
    usapApproved: true,
    priceRange: '$170-190',
    armFriendly: true,
    bestFor: 'Players who want tennis heritage and balanced all-around performance'
  },
  {
    id: 'head-extreme-tour',
    brand: 'HEAD',
    model: 'Extreme Tour',
    year: 2024,
    surface: 'Raw Carbon',
    shape: 'Elongated',
    core: '14mm',
    weight: '8.0-8.5 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 5,
    controlRating: 3,
    spinRating: 5,
    usapApproved: true,
    priceRange: '$210-230',
    armFriendly: false,
    bestFor: 'Tournament players who want maximum spin and power from tennis expertise'
  },

  // FRANKLIN PADDLES
  {
    id: 'franklin-carbon-x',
    brand: 'Franklin',
    model: 'Carbon-X',
    year: 2023,
    surface: 'Carbon Fiber',
    shape: 'Widebody',
    core: '16mm',
    weight: '7.5-8.0 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 3,
    controlRating: 4,
    spinRating: 3,
    usapApproved: true,
    priceRange: '$120-140',
    armFriendly: true,
    bestFor: 'Recreational players wanting quality carbon fiber at accessible price'
  },
  {
    id: 'franklin-x-40',
    brand: 'Franklin',
    model: 'X-40',
    year: 2023,
    surface: 'Fiberglass',
    shape: 'Widebody',
    core: '16mm',
    weight: '7.0-7.5 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 2,
    controlRating: 4,
    spinRating: 2,
    usapApproved: true,
    priceRange: '$60-80',
    armFriendly: true,
    bestFor: 'Beginners who want a quality starter paddle from the official ball company'
  },

  // BUDGET OPTION PADDLES
  {
    id: 'niupipo-fury',
    brand: 'NIUPIPO',
    model: 'Fury',
    year: 2023,
    surface: 'Fiberglass',
    shape: 'Widebody',
    core: '16mm',
    weight: '7.8-8.3 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 3,
    controlRating: 3,
    spinRating: 2,
    usapApproved: true,
    priceRange: '$50-70',
    armFriendly: true,
    bestFor: 'Budget-conscious beginners who want USAP approval without high cost'
  },
  {
    id: 'amazin-aces-signature',
    brand: 'Amazin\' Aces',
    model: 'Signature',
    year: 2023,
    surface: 'Fiberglass',
    shape: 'Widebody',
    core: '16mm',
    weight: '7.5-8.0 oz',
    gripSizes: ['4 1/8', '4 1/4', '4 3/8'],
    powerRating: 2,
    controlRating: 4,
    spinRating: 2,
    usapApproved: true,
    priceRange: '$55-75',
    armFriendly: true,
    bestFor: 'New players who want to learn proper technique with forgiving control'
  }
]

// Recommendation Algorithm
export function getRecommendations(preferences: UserPreferences): PaddleRecommendation[] {
  const scored = paddleDatabase.map(paddle => {
    let score = 0
    let reasons: string[] = []

    // Skill Level Scoring (30% weight)
    switch (preferences.skillLevel) {
      case 'beginner':
        if (paddle.controlRating >= 4) { score += 25; reasons.push('excellent control for learning') }
        if (paddle.armFriendly) { score += 20; reasons.push('arm-friendly design') }
        if (paddle.powerRating <= 3) { score += 15; reasons.push('manageable power') }
        break
      case 'intermediate':
        if (paddle.controlRating >= 3 && paddle.powerRating >= 3) { score += 25; reasons.push('balanced performance') }
        if (paddle.armFriendly) { score += 10; reasons.push('comfortable feel') }
        break
      case 'advanced':
        if (paddle.powerRating >= 4 || paddle.spinRating >= 4) { score += 25; reasons.push('high performance') }
        if (paddle.controlRating >= 3) { score += 15; reasons.push('maintains precision') }
        break
      case 'tournament':
        if (paddle.powerRating >= 4 && paddle.spinRating >= 4) { score += 30; reasons.push('elite performance') }
        if (paddle.surface === 'Raw Carbon') { score += 10; reasons.push('cutting-edge materials') }
        break
    }

    // Power vs Control Preference (25% weight)
    switch (preferences.powerVsControl) {
      case 'power':
        score += paddle.powerRating * 5
        if (paddle.shape === 'Elongated') { score += 10; reasons.push('elongated shape for power') }
        break
      case 'control':
        score += paddle.controlRating * 5
        if (paddle.shape === 'Widebody') { score += 10; reasons.push('widebody for forgiveness') }
        break
      case 'balanced':
        score += (paddle.powerRating + paddle.controlRating) * 2.5
        reasons.push('balanced power and control')
        break
    }

    // Play Style (20% weight)
    switch (preferences.playStyle) {
      case 'singles':
        if (paddle.shape === 'Elongated') { score += 15; reasons.push('reach advantage for singles') }
        if (paddle.powerRating >= 4) { score += 10; reasons.push('power for singles court coverage') }
        break
      case 'doubles':
        if (paddle.shape === 'Widebody') { score += 15; reasons.push('quick hands for net play') }
        if (paddle.controlRating >= 4) { score += 10; reasons.push('precision for doubles positioning') }
        break
      case 'both':
        if (paddle.shape === 'Hybrid') { score += 15; reasons.push('versatile hybrid shape') }
        score += (paddle.powerRating + paddle.controlRating) * 2
        break
    }

    // Arm Sensitivity (15% weight)
    switch (preferences.armSensitivity) {
      case 'none':
        // No penalty for any paddle
        break
      case 'mild':
        if (paddle.armFriendly) { score += 10; reasons.push('reduced vibration') }
        break
      case 'moderate':
        if (paddle.armFriendly) { score += 15; reasons.push('comfortable for sensitive arms') }
        if (!paddle.armFriendly && paddle.powerRating >= 4) score -= 15
        break
      case 'high':
        if (paddle.armFriendly) { score += 20; reasons.push('maximum arm comfort') }
        if (!paddle.armFriendly) score -= 25
        break
    }

    // Budget Consideration (10% weight)
    const priceMatch = checkPriceBudgetMatch(paddle.priceRange, preferences.budget)
    if (priceMatch.matches) {
      score += priceMatch.bonus
      if (priceMatch.bonus > 0) reasons.push(priceMatch.reason)
    } else {
      score -= 20 // Penalty for being outside budget
    }

    return {
      paddle,
      matchScore: Math.min(100, Math.max(0, score)),
      reason: `Perfect for your ${preferences.skillLevel} level with ${reasons.slice(0, 3).join(', ')}.`,
      category: determineCategory(paddle, preferences)
    } as PaddleRecommendation
  })

  // Sort by score and return top recommendations
  const sorted = scored
    .filter(rec => rec.matchScore > 40) // Only show reasonable matches
    .sort((a, b) => b.matchScore - a.matchScore)

  // Ensure we have at least one safe pick and one performance pick
  const recommendations = []
  const safePickIndex = sorted.findIndex(rec => rec.category === 'safe')
  const performancePickIndex = sorted.findIndex(rec => rec.category === 'performance')

  // Add top pick
  if (sorted[0]) recommendations.push(sorted[0])

  // Add safe pick if different from top pick
  if (safePickIndex !== -1 && safePickIndex !== 0) {
    recommendations.push(sorted[safePickIndex])
  }

  // Add performance pick if different from others
  if (performancePickIndex !== -1 && 
      performancePickIndex !== 0 && 
      performancePickIndex !== safePickIndex) {
    recommendations.push(sorted[performancePickIndex])
  }

  // Fill remaining slots with next best
  for (let i = 1; i < sorted.length && recommendations.length < 3; i++) {
    if (!recommendations.find(rec => rec.paddle.id === sorted[i].paddle.id)) {
      recommendations.push(sorted[i])
    }
  }

  return recommendations.slice(0, 3)
}

function checkPriceBudgetMatch(priceRange: string, budget: string): {
  matches: boolean
  bonus: number
  reason: string
} {
  const price = extractPrice(priceRange)
  
  switch (budget) {
    case 'budget':
      if (price < 100) return { matches: true, bonus: 10, reason: 'great value under $100' }
      return { matches: false, bonus: 0, reason: '' }
    case 'mid':
      if (price >= 100 && price <= 200) return { matches: true, bonus: 10, reason: 'excellent value in mid-range' }
      if (price < 100) return { matches: true, bonus: 5, reason: 'even better value' }
      return { matches: false, bonus: 0, reason: '' }
    case 'premium':
      if (price >= 200) return { matches: true, bonus: 10, reason: 'premium performance' }
      return { matches: true, bonus: 0, reason: '' }
    case 'unlimited':
      return { matches: true, bonus: 5, reason: 'best value regardless of price' }
    default:
      return { matches: true, bonus: 0, reason: '' }
  }
}

function extractPrice(priceRange: string): number {
  const numbers = priceRange.match(/\d+/g)
  return numbers ? parseInt(numbers[0]) : 0
}

function determineCategory(paddle: Paddle, preferences: UserPreferences): 'safe' | 'performance' | 'value' {
  // Performance picks: high ratings, latest tech
  if ((paddle.powerRating >= 4 || paddle.spinRating >= 4) && 
      paddle.surface === 'Raw Carbon' && 
      paddle.year >= 2024) {
    return 'performance'
  }
  
  // Safe picks: reliable, arm-friendly, good control
  if (paddle.armFriendly && paddle.controlRating >= 4 && paddle.usapApproved) {
    return 'safe'
  }
  
  return 'value'
}