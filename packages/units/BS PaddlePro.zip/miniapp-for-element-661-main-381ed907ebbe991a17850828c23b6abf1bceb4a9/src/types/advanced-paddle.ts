export interface AdvancedPaddleSpecs {
  // Advanced technical specifications
  swingWeight: number // in kg⋅cm²
  twistWeight: number // in kg⋅cm² 
  balancePoint: number // cm from handle
  kewCor: number // KEWCoR rating (JohnKew standard)
  deflection: number // mm under load
  staticWeight: number // grams
  sweetSpotSize: 'Small' | 'Medium' | 'Large' | 'Extra Large'
  vibrationDamping: number // 1-10 scale
  durabilityRating: number // 1-10 scale
  
  // Professional insights
  proPlayerUsage: string[] // List of pros who use it
  tournamentWins: number // Major tournament wins with this paddle
  releaseNotes: string // What makes this paddle unique
  generationalUpdate: string // How it compares to previous versions
  
  // Advanced materials science
  carbonLayerCount: number
  coreHoneycombDensity: number // cells per inch
  edgeGuardMaterial: string
  handleWrapType: string
  coatingType: string
}

export interface PaddleComparison {
  paddleA: string // paddle ID
  paddleB: string // paddle ID
  differences: {
    category: string
    paddleAValue: string | number
    paddleBValue: string | number
    impact: 'Major' | 'Moderate' | 'Minor'
    explanation: string
  }[]
  recommendation: string
  winnerCategory: 'A' | 'B' | 'Tie'
}

export interface LocationData {
  latitude: number
  longitude: number
  city: string
  state: string
  zipCode: string
  country: string
}

export interface RetailerLocation {
  name: string
  address: string
  phone: string
  website: string
  distance: number // miles from user
  paddleBrands: string[]
  hasDemo: boolean
  hasStringing: boolean
  rating: number
  reviews: number
}

export interface WeatherRecommendation {
  temperature: number
  humidity: number
  windSpeed: number
  recommendation: {
    paddleAdjustment: string
    gripRecommendation: string
    playStyleTips: string[]
  }
}

export interface SEOContent {
  title: string
  description: string
  keywords: string[]
  structuredData: any
  aiGeneratedReview: string
  comparisonContent: string
  faqSections: {
    question: string
    answer: string
  }[]
}

export interface TrendAnalysis {
  period: 'week' | 'month' | 'quarter' | 'year'
  topPaddles: {
    paddleId: string
    searchVolume: number
    trendDirection: 'up' | 'down' | 'stable'
    percentChange: number
  }[]
  emergingBrands: string[]
  decliningSurfaces: string[]
  regionalPreferences: {
    region: string
    topChoices: string[]
    uniqueFactors: string[]
  }[]
}