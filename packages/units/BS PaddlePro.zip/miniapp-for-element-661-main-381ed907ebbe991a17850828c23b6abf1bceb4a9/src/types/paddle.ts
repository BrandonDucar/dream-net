export interface Paddle {
  id: string
  brand: string
  model: string
  year: number
  surface: 'Carbon Fiber' | 'Raw Carbon' | 'Fiberglass' | 'Kevlar' | 'Hybrid'
  shape: 'Elongated' | 'Widebody' | 'Hybrid'
  core: '13mm' | '16mm' | '14mm' | '15mm' | '11mm' | '20mm'
  weight: string // e.g., "7.5-8.2 oz"
  swingWeight?: string // if available
  gripSizes: string[] // e.g., ["4 1/8", "4 1/4", "4 3/8"]
  powerRating: number // 1-5 scale
  controlRating: number // 1-5 scale  
  spinRating: number // 1-5 scale
  usapApproved: boolean
  priceRange: string // e.g., "$150-180"
  armFriendly: boolean
  bestFor: string // description of ideal player type
}

export interface UserPreferences {
  skillLevel: 'beginner' | 'intermediate' | 'advanced' | 'tournament'
  playStyle: 'singles' | 'doubles' | 'both'
  powerVsControl: 'power' | 'balanced' | 'control'
  armSensitivity: 'none' | 'mild' | 'moderate' | 'high'
  budget: 'budget' | 'mid' | 'premium' | 'unlimited'
}

export interface PaddleRecommendation {
  paddle: Paddle
  matchScore: number // 1-100%
  reason: string
  category: 'safe' | 'performance' | 'value'
}