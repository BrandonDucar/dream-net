export const ONCHAINKIT_PROJECT_ID = 'a45f2a23-e8f9-4abe-a33e-c6513ce6db30';
export const ONCHAINKIT_API_KEY = 'IvwYCUHpYrPx8hP_lLRE09QJP3LDxiIl';
