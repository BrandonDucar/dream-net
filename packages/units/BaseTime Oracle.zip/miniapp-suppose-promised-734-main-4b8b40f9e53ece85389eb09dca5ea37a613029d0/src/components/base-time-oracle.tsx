'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, TrendingDown, TrendingUp, Users, Sparkles } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { getPredictedTimes, type TimePrediction } from '@/lib/oracle-utils';

export function BaseTimeOracle() {
  const [predictions, setPredictions] = useState<TimePrediction[]>([]);
  const [currentCongestion, setCurrentCongestion] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    // Simulate loading predictions
    const loadPredictions = () => {
      const newPredictions = getPredictedTimes();
      setPredictions(newPredictions);
      
      // Simulate current congestion (0-100)
      const congestion = Math.floor(Math.random() * 40) + 30;
      setCurrentCongestion(congestion);
      
      setLoading(false);
    };

    loadPredictions();
    
    // Refresh predictions every 5 minutes
    const interval = setInterval(loadPredictions, 300000);
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Current Network Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            Current Network Status
          </CardTitle>
          <CardDescription>Live Base chain congestion and activity</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">Congestion Level</span>
                <span className="text-sm text-gray-600">{currentCongestion}%</span>
              </div>
              <Progress value={currentCongestion} className="h-2" />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-green-50 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-1">
                  <TrendingDown className="w-4 h-4 text-green-600" />
                  <span className="text-xs font-medium text-green-900">Gas Trend</span>
                </div>
                <p className="text-lg font-bold text-green-700">Decreasing</p>
              </div>
              
              <div className="bg-blue-50 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-1">
                  <Users className="w-4 h-4 text-blue-600" />
                  <span className="text-xs font-medium text-blue-900">Activity</span>
                </div>
                <p className="text-lg font-bold text-blue-700">Moderate</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Time Predictions */}
      {predictions.map((prediction) => (
        <Card key={prediction.type}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-indigo-600" />
              {prediction.title}
            </CardTitle>
            <CardDescription>{prediction.description}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Primary Time Window */}
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4 border-2 border-blue-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Optimal Window</span>
                  <Badge variant="default" className="bg-blue-600">
                    <Sparkles className="w-3 h-3 mr-1" />
                    Best Time
                  </Badge>
                </div>
                <p className="text-2xl font-bold text-blue-900">{prediction.timeWindow}</p>
                <p className="text-xs text-gray-600 mt-1">{prediction.reason}</p>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-3">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-600 mb-1">Gas Savings</p>
                  <p className="text-lg font-bold text-green-600">{prediction.gasSavings}%</p>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-600 mb-1">Success Rate</p>
                  <p className="text-lg font-bold text-blue-600">{prediction.successRate}%</p>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-600 mb-1">Confidence</p>
                  <p className="text-lg font-bold text-indigo-600">{prediction.confidence}%</p>
                </div>
              </div>

              {/* Alternative Times */}
              {prediction.alternativeTimes && prediction.alternativeTimes.length > 0 && (
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-2">Alternative Times</p>
                  <div className="flex flex-wrap gap-2">
                    {prediction.alternativeTimes.map((time, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {time}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
