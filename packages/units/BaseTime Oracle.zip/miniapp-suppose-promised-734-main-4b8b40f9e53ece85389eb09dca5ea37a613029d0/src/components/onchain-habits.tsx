'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useAccount } from 'wagmi';
import { parseEther } from 'viem';
import { Plus, Flame, Trophy, Target, Coins } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import type { Habit } from '@/lib/habits-utils';
import { loadHabits, saveHabits, logHabit, calculateVaultBalance } from '@/lib/habits-utils';

export function OnchainHabits() {
  const { address, status } = useAccount();
  const [habits, setHabits] = useState<Habit[]>([]);
  const [vaultBalance, setVaultBalance] = useState<string>('0');
  const [newHabitName, setNewHabitName] = useState<string>('');
  const [newHabitAmount, setNewHabitAmount] = useState<string>('0.0001');
  const [isOpen, setIsOpen] = useState<boolean>(false);

  useEffect(() => {
    if (address) {
      const userHabits = loadHabits(address);
      setHabits(userHabits);
      
      const balance = calculateVaultBalance(userHabits);
      setVaultBalance(balance);
    }
  }, [address]);

  const handleAddHabit = () => {
    if (!address) {
      toast.error('Please connect your wallet first');
      return;
    }

    if (!newHabitName.trim()) {
      toast.error('Please enter a habit name');
      return;
    }

    const amount = parseFloat(newHabitAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    const newHabit: Habit = {
      id: Date.now().toString(),
      name: newHabitName.trim(),
      amount: newHabitAmount,
      streak: 0,
      totalLogs: 0,
      lastLogDate: null,
      createdAt: new Date().toISOString(),
    };

    const updatedHabits = [...habits, newHabit];
    setHabits(updatedHabits);
    saveHabits(address, updatedHabits);

    setNewHabitName('');
    setNewHabitAmount('0.0001');
    setIsOpen(false);

    toast.success('Habit created! Start your onchain journey 🎯');
  };

  const handleLogHabit = async (habitId: string) => {
    if (!address) {
      toast.error('Please connect your wallet first');
      return;
    }

    if (status !== 'connected') {
      toast.error('Wallet not connected. Please open in Warpcast.');
      return;
    }

    const habit = habits.find((h) => h.id === habitId);
    if (!habit) return;

    // In a real app, this would send the transaction
    // For now, we'll simulate it
    toast.loading('Logging habit and sending micro-transaction...');

    // Simulate transaction delay
    setTimeout(() => {
      const updatedHabits = logHabit(habits, habitId);
      setHabits(updatedHabits);
      saveHabits(address, updatedHabits);

      const balance = calculateVaultBalance(updatedHabits);
      setVaultBalance(balance);

      const updatedHabit = updatedHabits.find((h) => h.id === habitId);
      if (updatedHabit) {
        toast.success(`✅ Habit logged! Streak: ${updatedHabit.streak} days`);
        
        // Check for milestones
        if (updatedHabit.totalLogs === 7) {
          toast.success('🎉 7-day milestone! Keep going!', { duration: 5000 });
        } else if (updatedHabit.totalLogs === 30) {
          toast.success('🏆 30-day badge unlocked! You\'re a legend!', { duration: 5000 });
        } else if (updatedHabit.totalLogs === 60) {
          toast.success('💎 60-day vault state unlocked! Diamond hands!', { duration: 5000 });
        }
      }
    }, 2000);
  };

  const getBadge = (totalLogs: number): string | null => {
    if (totalLogs >= 60) return '💎 Diamond';
    if (totalLogs >= 30) return '🏆 Gold';
    if (totalLogs >= 7) return '🥉 Bronze';
    return null;
  };

  if (status === 'connecting' || status === 'reconnecting') {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!address) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="text-center py-8">
            <p className="text-gray-600 mb-4">Connect your wallet to start tracking habits onchain</p>
            <p className="text-sm text-gray-500">Open this app in Warpcast for the full experience</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Vault Balance */}
      <Card className="bg-gradient-to-br from-amber-50 to-yellow-50 border-amber-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Coins className="w-5 h-5 text-amber-600" />
            Habit Vault
          </CardTitle>
          <CardDescription>Your onchain commitment grows with every habit</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center">
            <p className="text-4xl font-bold text-amber-900 mb-2">{vaultBalance} ETH</p>
            <p className="text-sm text-gray-600">
              Total value locked • {habits.reduce((sum, h) => sum + h.totalLogs, 0)} total logs
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Add Habit Button */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button className="w-full" size="lg">
            <Plus className="w-4 h-4 mr-2" />
            Create New Habit
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Onchain Habit</DialogTitle>
            <DialogDescription>
              Set up a new habit with a micro-transaction amount. Every time you complete this habit, you'll send that amount to your vault.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="habitName">Habit Name</Label>
              <Input
                id="habitName"
                placeholder="e.g., Daily meditation, Exercise, Read 30 min"
                value={newHabitName}
                onChange={(e) => setNewHabitName(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="amount">Micro-Transaction Amount (ETH)</Label>
              <Input
                id="amount"
                type="number"
                step="0.0001"
                placeholder="0.0001"
                value={newHabitAmount}
                onChange={(e) => setNewHabitAmount(e.target.value)}
              />
              <p className="text-xs text-gray-500 mt-1">This amount will be sent to your vault each time you log this habit</p>
            </div>
          </div>
          <Button onClick={handleAddHabit} className="w-full">
            Create Habit
          </Button>
        </DialogContent>
      </Dialog>

      {/* Habits List */}
      {habits.length === 0 ? (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-8">
              <Target className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600 mb-2">No habits yet</p>
              <p className="text-sm text-gray-500">Create your first onchain habit to get started</p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {habits.map((habit) => {
            const badge = getBadge(habit.totalLogs);
            const progressToNext = habit.totalLogs < 7 ? (habit.totalLogs / 7) * 100 : 
                                  habit.totalLogs < 30 ? ((habit.totalLogs - 7) / 23) * 100 :
                                  habit.totalLogs < 60 ? ((habit.totalLogs - 30) / 30) * 100 : 100;

            return (
              <Card key={habit.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{habit.name}</CardTitle>
                      <CardDescription className="flex items-center gap-2 mt-1">
                        <span>{habit.amount} ETH per log</span>
                        {badge && <Badge variant="secondary" className="text-xs">{badge}</Badge>}
                      </CardDescription>
                    </div>
                    <Button 
                      onClick={() => handleLogHabit(habit.id)}
                      size="sm"
                      className="ml-4"
                    >
                      Log Habit
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Streak */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Flame className="w-5 h-5 text-orange-500" />
                        <span className="font-semibold text-orange-600">{habit.streak} day streak</span>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-600">Total: {habit.totalLogs} logs</p>
                      </div>
                    </div>

                    {/* Progress to next badge */}
                    {habit.totalLogs < 60 && (
                      <div>
                        <div className="flex justify-between text-xs text-gray-600 mb-1">
                          <span>Progress to next milestone</span>
                          <span>
                            {habit.totalLogs < 7 ? `${7 - habit.totalLogs} more` :
                             habit.totalLogs < 30 ? `${30 - habit.totalLogs} more` :
                             `${60 - habit.totalLogs} more`}
                          </span>
                        </div>
                        <Progress value={progressToNext} className="h-2" />
                      </div>
                    )}

                    {/* Stats */}
                    <div className="grid grid-cols-2 gap-2 pt-2">
                      <div className="bg-gray-50 rounded-lg p-2 text-center">
                        <p className="text-xs text-gray-600">Vault Contribution</p>
                        <p className="text-sm font-bold text-blue-600">
                          {(parseFloat(habit.amount) * habit.totalLogs).toFixed(4)} ETH
                        </p>
                      </div>
                      <div className="bg-gray-50 rounded-lg p-2 text-center">
                        <p className="text-xs text-gray-600">Last Logged</p>
                        <p className="text-sm font-bold text-gray-700">
                          {habit.lastLogDate ? new Date(habit.lastLogDate).toLocaleDateString() : 'Never'}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
