import type { Address } from 'viem';

export type Habit = {
  id: string;
  name: string;
  amount: string;
  streak: number;
  totalLogs: number;
  lastLogDate: string | null;
  createdAt: string;
};

const STORAGE_KEY_PREFIX = 'onchain_habits_';

/**
 * Load habits from localStorage for a specific wallet address
 */
export function loadHabits(address: Address): Habit[] {
  if (typeof window === 'undefined') return [];
  
  try {
    const key = `${STORAGE_KEY_PREFIX}${address.toLowerCase()}`;
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading habits:', error);
    return [];
  }
}

/**
 * Save habits to localStorage for a specific wallet address
 */
export function saveHabits(address: Address, habits: Habit[]): void {
  if (typeof window === 'undefined') return;
  
  try {
    const key = `${STORAGE_KEY_PREFIX}${address.toLowerCase()}`;
    localStorage.setItem(key, JSON.stringify(habits));
  } catch (error) {
    console.error('Error saving habits:', error);
  }
}

/**
 * Log a habit completion and update streak
 */
export function logHabit(habits: Habit[], habitId: string): Habit[] {
  return habits.map((habit) => {
    if (habit.id !== habitId) return habit;
    
    const now = new Date();
    const lastLog = habit.lastLogDate ? new Date(habit.lastLogDate) : null;
    
    // Check if already logged today
    if (lastLog && isSameDay(lastLog, now)) {
      return habit;
    }
    
    // Check if streak should continue (logged yesterday) or reset
    let newStreak = habit.streak;
    if (lastLog) {
      const yesterday = new Date(now);
      yesterday.setDate(yesterday.getDate() - 1);
      
      if (isSameDay(lastLog, yesterday)) {
        // Logged yesterday, continue streak
        newStreak = habit.streak + 1;
      } else {
        // Missed a day, reset streak
        newStreak = 1;
      }
    } else {
      // First log
      newStreak = 1;
    }
    
    return {
      ...habit,
      streak: newStreak,
      totalLogs: habit.totalLogs + 1,
      lastLogDate: now.toISOString(),
    };
  });
}

/**
 * Calculate total vault balance from all habits
 */
export function calculateVaultBalance(habits: Habit[]): string {
  const total = habits.reduce((sum, habit) => {
    const habitTotal = parseFloat(habit.amount) * habit.totalLogs;
    return sum + habitTotal;
  }, 0);
  
  return total.toFixed(4);
}

/**
 * Check if two dates are the same day
 */
function isSameDay(date1: Date, date2: Date): boolean {
  return (
    date1.getFullYear() === date2.getFullYear() &&
    date1.getMonth() === date2.getMonth() &&
    date1.getDate() === date2.getDate()
  );
}
