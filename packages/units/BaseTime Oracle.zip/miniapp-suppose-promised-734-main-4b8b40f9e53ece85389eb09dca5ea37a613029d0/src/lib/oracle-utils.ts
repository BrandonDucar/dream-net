export type TimePrediction = {
  type: 'mint' | 'post' | 'send';
  title: string;
  description: string;
  timeWindow: string;
  reason: string;
  gasSavings: number;
  successRate: number;
  confidence: number;
  alternativeTimes: string[];
};

/**
 * Generates predicted optimal times for different blockchain activities
 * In a production app, this would use real-time data from:
 * - Base chain analytics
 * - Gas price history
 * - Creator activity patterns
 * - Social posting patterns
 * - Volume and liquidity data
 */
export function getPredictedTimes(): TimePrediction[] {
  const now = new Date();
  const currentHour = now.getHours();
  
  // Simulate different optimal times based on current time
  const mintTime = calculateOptimalMintTime(currentHour);
  const postTime = calculateOptimalPostTime(currentHour);
  const sendTime = calculateOptimalSendTime(currentHour);
  
  return [
    {
      type: 'mint',
      title: 'Best Time to Mint',
      description: 'Optimal window for minting NFTs based on gas and creator activity',
      timeWindow: mintTime.window,
      reason: mintTime.reason,
      gasSavings: mintTime.savings,
      successRate: 94,
      confidence: 87,
      alternativeTimes: mintTime.alternatives,
    },
    {
      type: 'post',
      title: 'Best Time to Post',
      description: 'Peak engagement window for social posting on Base',
      timeWindow: postTime.window,
      reason: postTime.reason,
      gasSavings: postTime.savings,
      successRate: 91,
      confidence: 92,
      alternativeTimes: postTime.alternatives,
    },
    {
      type: 'send',
      title: 'Cheapest Time to Send',
      description: 'Lowest gas fees for transfers and transactions',
      timeWindow: sendTime.window,
      reason: sendTime.reason,
      gasSavings: sendTime.savings,
      successRate: 98,
      confidence: 95,
      alternativeTimes: sendTime.alternatives,
    },
  ];
}

function calculateOptimalMintTime(currentHour: number): {
  window: string;
  reason: string;
  savings: number;
  alternatives: string[];
} {
  // Morning mints tend to have higher success rates
  if (currentHour >= 6 && currentHour < 12) {
    return {
      window: '2:17 PM–3:04 PM',
      reason: 'High creator activity, moderate gas fees',
      savings: 23,
      alternatives: ['5:30 PM–6:15 PM', '8:00 PM–8:45 PM'],
    };
  }
  
  // Afternoon - prime time
  if (currentHour >= 12 && currentHour < 18) {
    return {
      window: '8:45 PM–9:30 PM',
      reason: 'Peak creator output, optimal liquidity',
      savings: 18,
      alternatives: ['11:00 AM–11:45 AM', '2:15 PM–3:00 PM'],
    };
  }
  
  // Evening
  return {
    window: '10:30 AM–11:20 AM',
    reason: 'Early adopter window, lower congestion',
    savings: 31,
    alternatives: ['1:45 PM–2:30 PM', '4:00 PM–4:45 PM'],
  };
}

function calculateOptimalPostTime(currentHour: number): {
  window: string;
  reason: string;
  savings: number;
  alternatives: string[];
} {
  // Early morning
  if (currentHour >= 0 && currentHour < 6) {
    return {
      window: '11:50 AM',
      reason: 'Peak social engagement window',
      savings: 15,
      alternatives: ['6:30 PM', '8:15 PM'],
    };
  }
  
  // Morning
  if (currentHour >= 6 && currentHour < 12) {
    return {
      window: '6:45 PM',
      reason: 'Evening engagement surge',
      savings: 12,
      alternatives: ['12:30 PM', '3:15 PM'],
    };
  }
  
  // Afternoon
  if (currentHour >= 12 && currentHour < 18) {
    return {
      window: '8:20 PM',
      reason: 'Prime social activity hours',
      savings: 10,
      alternatives: ['11:00 AM', '2:45 PM'],
    };
  }
  
  // Evening
  return {
    window: '9:30 AM',
    reason: 'Morning engagement boost',
    savings: 14,
    alternatives: ['1:00 PM', '5:30 PM'],
  };
}

function calculateOptimalSendTime(currentHour: number): {
  window: string;
  reason: string;
  savings: number;
  alternatives: string[];
} {
  // Late night always cheapest
  if (currentHour >= 0 && currentHour < 6) {
    return {
      window: 'Now–6:00 AM',
      reason: 'Lowest network activity, minimal congestion',
      savings: 45,
      alternatives: ['2:00 AM–3:30 AM', '4:00 AM–5:30 AM'],
    };
  }
  
  // During day, point to night
  return {
    window: '2:00 AM–3:30 AM',
    reason: 'Lowest daily gas fees, minimal congestion',
    savings: 42,
    alternatives: ['3:30 AM–5:00 AM', '12:30 AM–1:45 AM'],
  };
}
