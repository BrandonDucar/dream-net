import { NextRequest, NextResponse } from 'next/server';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY || 'sk-proj-abcd1234567890abcd1234567890abcd1234567890abcd1234567890';

interface PickRequest {
  gameData: {
    sport: string;
    homeTeam: string;
    awayTeam: string;
    odds: {
      h2h?: Array<{ name: string; price: number }>;
      spreads?: Array<{ name: string; price: number; point: number }>;
      totals?: Array<{ name: string; price: number; point: number }>;
    };
    commence: string;
  };
  analysisType: 'moneyline' | 'spread' | 'total' | 'all';
  userBankroll?: number;
}

export async function POST(request: NextRequest) {
  try {
    const body: PickRequest = await request.json();
    const { gameData, analysisType, userBankroll = 1000 } = body;

    const prompt = `You are a professional sports betting analyst with 15+ years of experience. Analyze this ${gameData.sport} game and provide detailed betting recommendations.

GAME: ${gameData.awayTeam} @ ${gameData.homeTeam}
COMMENCE: ${gameData.commence}

AVAILABLE ODDS:
${JSON.stringify(gameData.odds, null, 2)}

ANALYSIS TYPE: ${analysisType}

Provide a comprehensive analysis with:
1. Win probabilities for each outcome (based on odds analysis, team strength, recent form)
2. Expected value calculations (precise EV calculations using true probability estimates)
3. Recommended bets with confidence levels (Very High, High, Medium, Low)
4. Risk assessment and variance considerations
5. Kelly Criterion stake recommendations (bankroll: $${userBankroll})
6. Key factors influencing your picks (injuries, trends, matchups, line movement)
7. Market inefficiencies and value spots

Return JSON format:
{
  "recommendations": [
    {
      "betType": "moneyline|spread|total",
      "selection": "team name or over/under with line",
      "odds": number,
      "winProbability": number (0-1),
      "expectedValue": number (as decimal, e.g. 0.025 for 2.5%),
      "confidence": "Very High|High|Medium|Low",
      "kellyStake": number (dollar amount),
      "reasoning": "detailed explanation with specific factors"
    }
  ],
  "keyFactors": ["factor1", "factor2", "factor3"],
  "riskLevel": "Low|Medium|High",
  "overallConfidence": "Very High|High|Medium|Low",
  "marketInsights": "analysis of line movement and market sentiment"
}`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: 'You are an elite sports betting analyst who provides data-driven recommendations with precise probability calculations, Kelly Criterion stake sizing, and deep market analysis. Always provide actionable insights with specific reasoning.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        response_format: { type: 'json_object' },
        temperature: 0.2,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`OpenAI API error: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    
    if (!result.choices?.[0]?.message?.content) {
      throw new Error('Invalid response from OpenAI API');
    }

    const analysis = JSON.parse(result.choices[0].message.content);

    return NextResponse.json({
      success: true,
      analysis,
      timestamp: new Date().toISOString(),
      game: {
        matchup: `${gameData.awayTeam} @ ${gameData.homeTeam}`,
        sport: gameData.sport,
        commence: gameData.commence
      },
      model: 'gpt-4o'
    });

  } catch (error) {
    console.error('AI Picks Error:', error);
    
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to generate AI analysis',
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}