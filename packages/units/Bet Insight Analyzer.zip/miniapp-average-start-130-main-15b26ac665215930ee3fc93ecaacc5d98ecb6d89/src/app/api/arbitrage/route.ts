import { NextRequest, NextResponse } from 'next/server';

interface ArbitrageOpportunity {
  id: string;
  sport: string;
  matchup: string;
  betType: string;
  opportunities: Array<{
    outcome1: {
      name: string;
      odds: number;
      bookmaker: string;
      stake: number;
    };
    outcome2: {
      name: string;
      odds: number;
      bookmaker: string;
      stake: number;
    };
    totalStake: number;
    profit: number;
    profitPercent: number;
  }>;
  commence: string;
  lastUpdate: string;
}

export async function POST(request: NextRequest) {
  try {
    const { gamesData, totalStake = 100 } = await request.json();

    if (!gamesData || !Array.isArray(gamesData)) {
      return NextResponse.json({ error: 'Invalid games data - must provide array of games' }, { status: 400 });
    }

    const arbitrageOpportunities: ArbitrageOpportunity[] = [];

    for (const game of gamesData) {
      if (!game.bookmakers || game.bookmakers.length < 2) continue;

      // Check each market type for arbitrage opportunities
      const markets = ['h2h', 'spreads', 'totals'];
      
      for (const marketType of markets) {
        const opportunities = findArbitrageInMarket(
          game,
          marketType,
          totalStake
        );
        
        if (opportunities.length > 0) {
          arbitrageOpportunities.push({
            id: `${game.id}-${marketType}`,
            sport: game.sportTitle || game.sport,
            matchup: `${game.awayTeam} @ ${game.homeTeam}`,
            betType: marketType,
            opportunities,
            commence: game.commence,
            lastUpdate: new Date().toISOString()
          });
        }
      }
    }

    // Sort by profit percentage (best opportunities first)
    arbitrageOpportunities.sort((a, b) => 
      Math.max(...b.opportunities.map(o => o.profitPercent)) - 
      Math.max(...a.opportunities.map(o => o.profitPercent))
    );

    return NextResponse.json({
      success: true,
      opportunities: arbitrageOpportunities,
      count: arbitrageOpportunities.length,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Arbitrage Detection Error:', error);
    
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to detect arbitrage opportunities',
      opportunities: [],
      count: 0,
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}

function findArbitrageInMarket(game: any, marketType: string, totalStake: number) {
  const opportunities: any[] = [];
  
  // Get all bookmakers that have this market
  const bookmarksWithMarket = game.bookmakers.filter((book: any) =>
    book.markets.some((market: any) => market.key === marketType)
  );

  if (bookmarksWithMarket.length < 2) return opportunities;

  // For each market, find the best odds for each outcome
  const outcomeOdds: { [outcome: string]: Array<{ odds: number; bookmaker: string; point?: number }> } = {};

  for (const bookmaker of bookmarksWithMarket) {
    const market = bookmaker.markets.find((m: any) => m.key === marketType);
    if (!market) continue;

    for (const outcome of market.outcomes) {
      const key = outcome.point ? `${outcome.name}_${outcome.point}` : outcome.name;
      
      if (!outcomeOdds[key]) {
        outcomeOdds[key] = [];
      }
      
      outcomeOdds[key].push({
        odds: outcome.price,
        bookmaker: bookmaker.title,
        point: outcome.point
      });
    }
  }

  // Check for arbitrage opportunities
  const outcomes = Object.keys(outcomeOdds);
  
  if (outcomes.length === 2) {
    // Two-way arbitrage (moneyline, spread, total)
    const [outcome1Key, outcome2Key] = outcomes;
    const outcome1Best = outcomeOdds[outcome1Key].reduce((best, current) =>
      current.odds > best.odds ? current : best
    );
    const outcome2Best = outcomeOdds[outcome2Key].reduce((best, current) =>
      current.odds > best.odds ? current : best
    );

    const arb = calculateTwoWayArbitrage(
      outcome1Key,
      outcome1Best,
      outcome2Key,
      outcome2Best,
      totalStake
    );

    if (arb && arb.profitPercent > 0.1) { // Only return profitable arbitrages (>0.1%)
      opportunities.push(arb);
    }
  }

  return opportunities;
}

function calculateTwoWayArbitrage(
  outcome1Name: string,
  outcome1: any,
  outcome2Name: string,
  outcome2: any,
  totalStake: number
) {
  // Convert American odds to decimal
  const dec1 = americanToDecimal(outcome1.odds);
  const dec2 = americanToDecimal(outcome2.odds);

  // Calculate implied probability
  const impliedProb1 = 1 / dec1;
  const impliedProb2 = 1 / dec2;
  
  // Check if arbitrage exists
  const totalImpliedProb = impliedProb1 + impliedProb2;
  
  if (totalImpliedProb >= 1) return null; // No arbitrage

  // Calculate optimal stakes
  const stake1 = (totalStake * impliedProb1) / totalImpliedProb;
  const stake2 = (totalStake * impliedProb2) / totalImpliedProb;

  // Calculate profit
  const payout1 = stake1 * dec1;
  const payout2 = stake2 * dec2;
  const profit = Math.min(payout1, payout2) - totalStake;
  const profitPercent = (profit / totalStake) * 100;

  return {
    outcome1: {
      name: outcome1Name.split('_')[0],
      odds: outcome1.odds,
      bookmaker: outcome1.bookmaker,
      stake: Math.round(stake1 * 100) / 100
    },
    outcome2: {
      name: outcome2Name.split('_')[0],
      odds: outcome2.odds,
      bookmaker: outcome2.bookmaker,
      stake: Math.round(stake2 * 100) / 100
    },
    totalStake,
    profit: Math.round(profit * 100) / 100,
    profitPercent: Math.round(profitPercent * 100) / 100
  };
}

function americanToDecimal(americanOdds: number): number {
  if (americanOdds > 0) {
    return (americanOdds / 100) + 1;
  } else {
    return (100 / Math.abs(americanOdds)) + 1;
  }
}