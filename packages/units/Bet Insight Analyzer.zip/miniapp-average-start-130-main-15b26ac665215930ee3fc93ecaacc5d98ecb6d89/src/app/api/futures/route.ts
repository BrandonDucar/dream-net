import { NextRequest, NextResponse } from 'next/server';

// The Odds API for real-time futures odds
const ODDS_API_KEY = process.env.ODDS_API_KEY || 'b8d1f0a1c2e3f4g5h6i7j8k9';
const BASE_URL = 'https://api.the-odds-api.com/v4';

interface FuturesBet {
  id: string;
  sport: string;
  market: string;
  selection: string;
  currentOdds: number;
  placementOdds?: number;
  placementDate?: string;
  trend: 'improving' | 'worsening' | 'stable';
  hedgeOpportunity?: {
    available: boolean;
    guaranteedProfit: number;
    hedgeOdds: number;
    hedgeStake: number;
  };
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const sport = searchParams.get('sport') || 'americanfootball_nfl';

    // Get futures odds from The Odds API
    const response = await fetch(
      `${BASE_URL}/sports/${sport}/odds?` +
      `apiKey=${ODDS_API_KEY}&` +
      `regions=us&` +
      `markets=outrights&` +
      `oddsFormat=american`,
      {
        headers: { 'Accept': 'application/json' },
      }
    );

    if (!response.ok) {
      throw new Error(`Futures API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    const futures: FuturesBet[] = [];

    for (const market of data) {
      if (!market.bookmakers || market.bookmakers.length === 0) continue;

      const bookmaker = market.bookmakers[0]; // Use first bookmaker
      const outrightsMarket = bookmaker.markets.find((m: any) => m.key === 'outrights');
      
      if (!outrightsMarket) continue;

      for (const outcome of outrightsMarket.outcomes) {
        futures.push({
          id: `${market.sport_key}-${outcome.name.replace(/\s+/g, '-').toLowerCase()}`,
          sport: market.sport_title,
          market: 'Championship',
          selection: outcome.name,
          currentOdds: outcome.price,
          trend: 'stable', // Would need historical data to determine trend
          hedgeOpportunity: calculateHedgeOpportunity(outcome.price, null)
        });
      }
    }

    return NextResponse.json({
      success: true,
      futures,
      count: futures.length,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Futures API Error:', error);
    
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to fetch futures odds',
      futures: [],
      count: 0,
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const { action, futuresBets } = await request.json();

    if (action === 'calculateHedge' && futuresBets) {
      const hedgeCalculations = futuresBets.map((bet: any) => ({
        ...bet,
        hedgeOpportunity: calculateHedgeOpportunity(
          bet.currentOdds, 
          bet.placementOdds,
          bet.stake
        )
      }));

      return NextResponse.json({
        success: true,
        calculations: hedgeCalculations,
        timestamp: new Date().toISOString()
      });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });

  } catch (error) {
    console.error('Futures Calculation Error:', error);
    
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to calculate hedge opportunities',
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}

function calculateHedgeOpportunity(
  currentOdds: number, 
  placementOdds?: number | null,
  originalStake?: number
) {
  if (!placementOdds || !originalStake) {
    return {
      available: false,
      guaranteedProfit: 0,
      hedgeOdds: 0,
      hedgeStake: 0
    };
  }

  // Convert American odds to decimal
  const currentDecimal = americanToDecimal(currentOdds);
  const placementDecimal = americanToDecimal(placementOdds);

  // Calculate potential payout from original bet
  const originalPayout = originalStake * placementDecimal;

  // Calculate hedge stake to guarantee profit
  const hedgeStake = originalPayout / currentDecimal;
  const guaranteedProfit = Math.min(
    originalPayout - originalStake - hedgeStake,
    hedgeStake - originalStake
  );

  return {
    available: guaranteedProfit > 0,
    guaranteedProfit: Math.round(guaranteedProfit * 100) / 100,
    hedgeOdds: currentOdds,
    hedgeStake: Math.round(hedgeStake * 100) / 100
  };
}

function americanToDecimal(americanOdds: number): number {
  if (americanOdds > 0) {
    return (americanOdds / 100) + 1;
  } else {
    return (100 / Math.abs(americanOdds)) + 1;
  }
}