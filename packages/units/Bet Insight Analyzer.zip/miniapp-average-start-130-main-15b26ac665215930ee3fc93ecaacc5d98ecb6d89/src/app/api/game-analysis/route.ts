import { NextRequest, NextResponse } from 'next/server';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY || 'sk-proj-abcd1234567890abcd1234567890abcd1234567890abcd1234567890';

export interface GameAnalysis {
  aiPrediction: {
    winner: string;
    winProbability: number;
    confidence: 'very_high' | 'high' | 'medium' | 'low';
    reasoning: string[];
  };
  bettingRecommendations: Array<{
    bestBet: string;
    expectedValue: number;
    confidence: 'very_high' | 'high' | 'medium' | 'low';
    reasoning: string;
    kellySuggestion: number;
  }>;
  publicBetting: Array<{
    side: string;
    percentage: number;
    action: 'follow' | 'fade';
  }>;
  sharpMoney: Array<{
    side: string;
    movement: string;
  }>;
}

export async function POST(request: NextRequest) {
  try {
    const { gameId, homeTeam, awayTeam, sport } = await request.json();

    if (!gameId || !homeTeam || !awayTeam || !sport) {
      return NextResponse.json({ 
        error: 'Missing required fields: gameId, homeTeam, awayTeam, sport' 
      }, { status: 400 });
    }

    const prompt = `You are a professional sports betting analyst with 15+ years of experience. Provide a comprehensive analysis for this ${sport} game: ${awayTeam} @ ${homeTeam}.

Analyze the following aspects:
1. Team strengths, weaknesses, and recent form
2. Head-to-head matchup history
3. Key player situations (injuries, suspensions, form)
4. Home/away advantages
5. Situational factors (scheduling, motivation, weather)
6. Line movement and market sentiment
7. Public vs sharp money indicators

Return a detailed JSON analysis:
{
  "aiPrediction": {
    "winner": "team name",
    "winProbability": number (0-100),
    "confidence": "very_high|high|medium|low",
    "reasoning": ["reason1", "reason2", "reason3"]
  },
  "bettingRecommendations": [
    {
      "bestBet": "specific bet recommendation with line",
      "expectedValue": number (as percentage),
      "confidence": "very_high|high|medium|low", 
      "reasoning": "detailed explanation",
      "kellySuggestion": number (percentage of bankroll)
    }
  ],
  "publicBetting": [
    {
      "side": "team or bet side",
      "percentage": number (0-100),
      "action": "follow|fade"
    }
  ],
  "sharpMoney": [
    {
      "side": "team or bet side", 
      "movement": "description of line movement"
    }
  ]
}`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: 'You are an elite sports betting analyst who provides comprehensive game analysis with precise predictions, value betting opportunities, and market insights. Always provide specific, actionable recommendations.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        response_format: { type: 'json_object' },
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`OpenAI API error: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    
    if (!result.choices?.[0]?.message?.content) {
      throw new Error('Invalid response from OpenAI API');
    }

    const analysis: GameAnalysis = JSON.parse(result.choices[0].message.content);

    return NextResponse.json({
      success: true,
      analysis,
      timestamp: new Date().toISOString(),
      gameId,
      matchup: `${awayTeam} @ ${homeTeam}`,
      sport
    });

  } catch (error) {
    console.error('Game Analysis Error:', error);
    
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to generate game analysis',
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}