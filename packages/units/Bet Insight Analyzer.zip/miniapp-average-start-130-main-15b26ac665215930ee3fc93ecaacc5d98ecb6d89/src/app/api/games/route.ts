import { NextResponse } from 'next/server';

// The Odds API - Real-time games and sports data
const ODDS_API_KEY = process.env.ODDS_API_KEY || 'b8d1f0a1c2e3f4g5h6i7j8k9';
const BASE_URL = 'https://api.the-odds-api.com/v4';

export interface GameMatchup {
  id: string;
  sport: string;
  league: string;
  homeTeam: string;
  awayTeam: string;
  gameTime: string;
  gameDate: string;
  venue: string;
  weather?: {
    condition: string;
    temp: string;
    wind: string;
  };
  status: 'scheduled' | 'in_progress' | 'completed';
  homeRecord?: string;
  awayRecord?: string;
  lastMeeting?: string;
  injuries: {
    team: string;
    player: string;
    status: string;
    impact: 'high' | 'medium' | 'low';
  }[];
  trends: {
    team: string;
    trend: string;
    stat: string;
  }[];
  keynotes: string[];
}

// Sport mapping from API keys to display names
const SPORT_MAPPING: Record<string, { apiKey: string; displayName: string; league: string }> = {
  'nfl': { apiKey: 'americanfootball_nfl', displayName: 'NFL', league: 'NFL' },
  'nba': { apiKey: 'basketball_nba', displayName: 'NBA', league: 'NBA' },
  'ncaab': { apiKey: 'basketball_ncaab', displayName: 'NCAAB', league: 'NCAA' },
  'nhl': { apiKey: 'icehockey_nhl', displayName: 'NHL', league: 'NHL' },
  'mlb': { apiKey: 'baseball_mlb', displayName: 'MLB', league: 'MLB' },
};

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const sport = searchParams.get('sport') || 'all';
    const date = searchParams.get('date') || new Date().toISOString().split('T')[0];

    const games: GameMatchup[] = [];

    // Determine which sports to fetch
    const sportsToFetch = sport === 'all' 
      ? Object.keys(SPORT_MAPPING)
      : [sport.toLowerCase()];

    // Fetch games from The Odds API for each sport
    for (const sportKey of sportsToFetch) {
      const sportConfig = SPORT_MAPPING[sportKey];
      if (!sportConfig) continue;

      try {
        const response = await fetch(
          `${BASE_URL}/sports/${sportConfig.apiKey}/odds?` +
          `apiKey=${ODDS_API_KEY}&` +
          `regions=us&` +
          `markets=h2h&` +
          `oddsFormat=american&` +
          `dateFormat=iso`,
          {
            headers: {
              'Accept': 'application/json',
            },
          }
        );

        if (response.ok) {
          const oddsData = await response.json();
          
          for (const game of oddsData) {
            const gameDate = new Date(game.commence_time);
            const requestDate = new Date(date);
            
            // Check if game is on requested date
            if (gameDate.toDateString() === requestDate.toDateString()) {
              const transformedGame: GameMatchup = {
                id: `${game.sport_key}_${game.id}`,
                sport: sportConfig.displayName,
                league: sportConfig.league,
                homeTeam: game.home_team,
                awayTeam: game.away_team,
                gameTime: gameDate.toLocaleTimeString('en-US', {
                  hour: 'numeric',
                  minute: '2-digit',
                  timeZoneName: 'short'
                }),
                gameDate: date,
                venue: `${game.home_team} Stadium`,
                status: new Date() > gameDate ? 'completed' : 'scheduled',
                injuries: generateInjuryData(game.home_team, game.away_team),
                trends: generateTrendData(game.home_team, game.away_team),
                keynotes: generateKeyNotes(game.home_team, game.away_team, sportConfig.displayName)
              };

              games.push(transformedGame);
            }
          }
        }
      } catch (apiError) {
        console.error(`Error fetching ${sportKey} games:`, apiError);
        // Continue with other sports even if one fails
      }
    }

    // Sort games by time
    games.sort((a, b) => {
      const timeA = new Date(`${a.gameDate} ${a.gameTime}`).getTime();
      const timeB = new Date(`${b.gameDate} ${b.gameTime}`).getTime();
      return timeA - timeB;
    });

    return NextResponse.json({
      success: true,
      date: date,
      games: games,
      total: games.length
    });

  } catch (error) {
    console.error('Games API Error:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch real-time games data',
      games: [],
      total: 0
    }, { status: 500 });
  }
}

// Helper functions to generate enhanced data for games
function generateInjuryData(homeTeam: string, awayTeam: string) {
  // In production, this would come from injury APIs like ESPN or similar
  const injuries = [
    { team: homeTeam, player: 'Key Player 1', status: 'Questionable', impact: 'medium' as const },
    { team: awayTeam, player: 'Star Player', status: 'Probable', impact: 'low' as const }
  ];
  return Math.random() > 0.5 ? injuries : [];
}

function generateTrendData(homeTeam: string, awayTeam: string) {
  // In production, this would come from sports data APIs
  const trends = [
    { team: homeTeam, trend: '7-3 ATS L10', stat: 'Strong home performance' },
    { team: awayTeam, trend: '5-5 ATS L10', stat: 'Average road record' }
  ];
  return trends;
}

function generateKeyNotes(homeTeam: string, awayTeam: string, sport: string) {
  // In production, this would come from sports news APIs or analysis
  const notes = [
    `${homeTeam} looking to extend winning streak`,
    `${awayTeam} has won 3 of last 5 meetings`,
    `Important ${sport} matchup with playoff implications`,
    'Weather conditions favorable for scoring'
  ];
  return notes.slice(0, Math.floor(Math.random() * 3) + 2);
}