import { NextResponse } from 'next/server';

export interface LineMovementPoint {
  timestamp: string;
  spread: number;
  total: number;
  moneylineHome: number;
  moneylineAway: number;
  volume: 'low' | 'medium' | 'high';
  source: string;
}

export interface LineMovementHistory {
  gameId: string;
  sport: string;
  homeTeam: string;
  awayTeam: string;
  currentSpread: number;
  currentTotal: number;
  openingSpread: number;
  openingTotal: number;
  spreadMovement: number;
  totalMovement: number;
  movements: LineMovementPoint[];
  keyMoves: {
    timestamp: string;
    type: 'spread' | 'total' | 'moneyline';
    from: number;
    to: number;
    magnitude: 'small' | 'medium' | 'large' | 'steam';
    likelyReason: string;
  }[];
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const gameId = searchParams.get('gameId') || 'nfl-buf-det';

    // Generate realistic line movement data
    const now = Date.now();
    const movements: LineMovementPoint[] = [];
    
    // Create 48 hours of movement data (every 2 hours)
    for (let i = 48; i >= 0; i -= 2) {
      const timestamp = new Date(now - (i * 60 * 60 * 1000)).toISOString();
      movements.push({
        timestamp,
        spread: -3.5 + (Math.random() - 0.5) * 1.0, // Line moves around -3.5
        total: 48.5 + (Math.random() - 0.5) * 2.0, // Total moves around 48.5
        moneylineHome: -180 + (Math.random() - 0.5) * 40,
        moneylineAway: 155 + (Math.random() - 0.5) * 30,
        volume: Math.random() > 0.7 ? 'high' : Math.random() > 0.4 ? 'medium' : 'low',
        source: ['FanDuel', 'DraftKings', 'BetMGM', 'Caesars'][Math.floor(Math.random() * 4)]
      });
    }

    const lineHistory: LineMovementHistory = {
      gameId,
      sport: 'NFL',
      homeTeam: 'Detroit Lions',
      awayTeam: 'Buffalo Bills',
      currentSpread: -3.5,
      currentTotal: 48.5,
      openingSpread: -2.5,
      openingTotal: 50.0,
      spreadMovement: -1.0,
      totalMovement: -1.5,
      movements,
      keyMoves: [
        {
          timestamp: new Date(now - (36 * 60 * 60 * 1000)).toISOString(),
          type: 'spread',
          from: -2.5,
          to: -3.0,
          magnitude: 'medium',
          likelyReason: 'Sharp money on Lions after injury news'
        },
        {
          timestamp: new Date(now - (18 * 60 * 60 * 1000)).toISOString(),
          type: 'total',
          from: 50.0,
          to: 49.0,
          magnitude: 'medium',
          likelyReason: 'Weather forecast showing wind'
        },
        {
          timestamp: new Date(now - (6 * 60 * 60 * 1000)).toISOString(),
          type: 'spread',
          from: -3.0,
          to: -3.5,
          magnitude: 'steam',
          likelyReason: 'Large bet on Lions spread'
        }
      ]
    };

    return NextResponse.json({
      success: true,
      data: lineHistory,
      lastUpdate: new Date().toISOString()
    });

  } catch (error) {
    console.error('Line movement history API error:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch line movement history',
      data: null
    }, { status: 500 });
  }
}