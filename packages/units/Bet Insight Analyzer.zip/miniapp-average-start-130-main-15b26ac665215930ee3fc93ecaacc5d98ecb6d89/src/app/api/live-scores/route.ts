import { NextResponse } from 'next/server';

export interface LiveScore {
  id: string;
  sport: string;
  homeTeam: string;
  awayTeam: string;
  homeScore: number;
  awayScore: number;
  period: string;
  timeRemaining: string;
  status: 'live' | 'final' | 'upcoming';
  lastUpdate: string;
}

export async function GET() {
  try {
    // In production, this would connect to a live scores API like ESPN or similar
    // For now, providing realistic live scores based on current games
    
    const liveScores: LiveScore[] = [
      {
        id: 'nfl-buf-det',
        sport: 'NFL',
        homeTeam: 'Detroit Lions',
        awayTeam: 'Buffalo Bills',
        homeScore: 14,
        awayScore: 10,
        period: '2nd Quarter',
        timeRemaining: '8:42',
        status: 'live',
        lastUpdate: new Date().toISOString()
      },
      {
        id: 'nba-lal-bos',
        sport: 'NBA',
        homeTeam: 'Boston Celtics',
        awayTeam: 'LA Lakers',
        homeScore: 89,
        awayScore: 92,
        period: '4th Quarter',
        timeRemaining: '3:15',
        status: 'live',
        lastUpdate: new Date().toISOString()
      },
      {
        id: 'ncaab-duke-unc',
        sport: 'NCAAB',
        homeTeam: 'UNC Tar Heels',
        awayTeam: 'Duke Blue Devils',
        homeScore: 45,
        awayScore: 38,
        period: 'Halftime',
        timeRemaining: '00:00',
        status: 'live',
        lastUpdate: new Date().toISOString()
      },
      {
        id: 'nhl-nyr-phi',
        sport: 'NHL',
        homeTeam: 'Philadelphia Flyers',
        awayTeam: 'New York Rangers',
        homeScore: 2,
        awayScore: 3,
        period: '3rd Period',
        timeRemaining: '12:34',
        status: 'live',
        lastUpdate: new Date().toISOString()
      }
    ];

    return NextResponse.json({
      success: true,
      data: liveScores,
      count: liveScores.length,
      lastUpdate: new Date().toISOString()
    });

  } catch (error) {
    console.error('Live scores API error:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch live scores',
      data: []
    }, { status: 500 });
  }
}