import { NextRequest, NextResponse } from 'next/server';

// The Odds API - Real-time odds from 40+ sportsbooks
// Free tier: 500 requests/month, paid plans available
const ODDS_API_KEY = process.env.ODDS_API_KEY || 'b8d1f0a1c2e3f4g5h6i7j8k9';
const BASE_URL = 'https://api.the-odds-api.com/v4';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const sport = searchParams.get('sport') || 'upcoming';
    const regions = searchParams.get('regions') || 'us,us2';
    const markets = searchParams.get('markets') || 'h2h,spreads,totals';
    const oddsFormat = searchParams.get('oddsFormat') || 'american';
    const dateFormat = searchParams.get('dateFormat') || 'iso';

    // Get live odds from The Odds API
    const response = await fetch(
      `${BASE_URL}/sports/${sport}/odds?` +
      `apiKey=${ODDS_API_KEY}&` +
      `regions=${regions}&` +
      `markets=${markets}&` +
      `oddsFormat=${oddsFormat}&` +
      `dateFormat=${dateFormat}`,
      {
        headers: {
          'Accept': 'application/json',
        },
      }
    );

    if (!response.ok) {
      throw new Error(`Odds API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    
    // Transform data for better frontend consumption
    const transformedData = {
      success: true,
      odds: data.map((game: any) => ({
        id: game.id,
        sport: game.sport_key,
        sportTitle: game.sport_title,
        commence: game.commence_time,
        homeTeam: game.home_team,
        awayTeam: game.away_team,
        bookmakers: game.bookmakers.map((book: any) => ({
          key: book.key,
          title: book.title,
          lastUpdate: book.last_update,
          markets: book.markets.map((market: any) => ({
            key: market.key,
            lastUpdate: market.last_update,
            outcomes: market.outcomes.map((outcome: any) => ({
              name: outcome.name,
              price: outcome.price,
              point: outcome.point || null,
            }))
          }))
        }))
      })),
      remainingRequests: response.headers.get('x-requests-remaining'),
      usedRequests: response.headers.get('x-requests-used'),
      timestamp: new Date().toISOString()
    };

    return NextResponse.json(transformedData);

  } catch (error) {
    console.error('Odds API Error:', error);
    
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to fetch live odds',
      odds: [],
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;

    if (action === 'getSports') {
      // Get available sports from The Odds API
      const response = await fetch(
        `${BASE_URL}/sports?apiKey=${ODDS_API_KEY}`,
        {
          headers: {
            'Accept': 'application/json',
          },
        }
      );

      if (!response.ok) {
        throw new Error(`Sports API error: ${response.status} ${response.statusText}`);
      }

      const sports = await response.json();
      
      return NextResponse.json({
        success: true,
        sports: sports.filter((sport: any) => sport.active),
        timestamp: new Date().toISOString()
      });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });

  } catch (error) {
    console.error('Sports API Error:', error);
    
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to fetch sports data',
      sports: [],
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}