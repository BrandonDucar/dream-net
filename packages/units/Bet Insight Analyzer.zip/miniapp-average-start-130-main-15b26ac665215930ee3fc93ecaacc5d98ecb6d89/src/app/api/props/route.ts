import { NextRequest, NextResponse } from 'next/server';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY || 'sk-proj-abcd1234567890abcd1234567890abcd1234567890abcd1234567890';

export async function POST(request: NextRequest) {
  try {
    const { 
      player, 
      propType, 
      line, 
      odds, 
      sport, 
      matchup 
    } = await request.json();

    if (!player || !propType || !line || !odds || !sport) {
      return NextResponse.json({ 
        error: 'Missing required fields: player, propType, line, odds, sport' 
      }, { status: 400 });
    }

    const prompt = `You are a professional sports betting analyst specializing in player props. Analyze this ${sport} prop bet:

PLAYER: ${player}
PROP TYPE: ${propType}
LINE: ${line}
ODDS: ${odds}
MATCHUP: ${matchup}

Provide a comprehensive analysis including:
1. Player's recent form and averages for this stat
2. Historical performance against this opponent
3. Matchup advantages/disadvantages
4. Usage rate and opportunity factors
5. External factors (injury, rest, motivation, etc.)
6. Expected value calculation
7. Confidence level in the recommendation

Return JSON format:
{
  "recommendation": "over|under",
  "confidence": "very_high|high|medium|low",
  "expectedValue": number (as percentage),
  "reasoning": "detailed explanation",
  "keyFactors": [
    {
      "factor": "factor name",
      "impact": "positive|negative|neutral",
      "weight": number (1-10)
    }
  ],
  "historicalAverage": number,
  "recentForm": "description of recent performance",
  "matchupAdvantage": number (1-10 scale),
  "projectedStat": number,
  "valueRating": "excellent|good|fair|poor"
}`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: 'You are an expert sports betting analyst who specializes in player prop bets. You provide data-driven analysis with specific reasoning and accurate projections based on player form, matchups, and situational factors.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        response_format: { type: 'json_object' },
        temperature: 0.2,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`OpenAI API error: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    
    if (!result.choices?.[0]?.message?.content) {
      throw new Error('Invalid response from OpenAI API');
    }

    const analysis = JSON.parse(result.choices[0].message.content);

    return NextResponse.json({
      success: true,
      analysis,
      input: {
        player,
        propType,
        line,
        odds,
        sport,
        matchup
      },
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Props Analysis Error:', error);
    
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to analyze prop bet',
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}