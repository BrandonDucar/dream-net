import { NextResponse } from 'next/server';

export interface PublicBettingData {
  gameId: string;
  sport: string;
  homeTeam: string;
  awayTeam: string;
  moneyline: {
    publicHome: number;
    publicAway: number;
    sharpHome: number;
    sharpAway: number;
  };
  spread: {
    publicHome: number;
    publicAway: number;
    sharpHome: number;
    sharpAway: number;
    line: number;
  };
  total: {
    publicOver: number;
    publicUnder: number;
    sharpOver: number;
    sharpUnder: number;
    line: number;
  };
  consensus: 'public' | 'sharp' | 'split';
  confidence: 'high' | 'medium' | 'low';
}

export async function GET() {
  try {
    // In production, this would connect to Action Network's public betting API or similar
    const publicBettingData: PublicBettingData[] = [
      {
        gameId: 'nfl-buf-det',
        sport: 'NFL',
        homeTeam: 'Detroit Lions',
        awayTeam: 'Buffalo Bills',
        moneyline: {
          publicHome: 72,
          publicAway: 28,
          sharpHome: 45,
          sharpAway: 55
        },
        spread: {
          publicHome: 68,
          publicAway: 32,
          sharpHome: 42,
          sharpAway: 58,
          line: -3.5
        },
        total: {
          publicOver: 61,
          publicUnder: 39,
          sharpOver: 35,
          sharpUnder: 65,
          line: 48.5
        },
        consensus: 'sharp',
        confidence: 'high'
      },
      {
        gameId: 'nba-lal-bos',
        sport: 'NBA',
        homeTeam: 'Boston Celtics',
        awayTeam: 'LA Lakers',
        moneyline: {
          publicHome: 78,
          publicAway: 22,
          sharpHome: 83,
          sharpAway: 17
        },
        spread: {
          publicHome: 71,
          publicAway: 29,
          sharpHome: 76,
          sharpAway: 24,
          line: -6.5
        },
        total: {
          publicOver: 58,
          publicUnder: 42,
          sharpOver: 52,
          sharpUnder: 48,
          line: 218.5
        },
        consensus: 'public',
        confidence: 'medium'
      },
      {
        gameId: 'ncaab-duke-unc',
        sport: 'NCAAB',
        homeTeam: 'UNC Tar Heels',
        awayTeam: 'Duke Blue Devils',
        moneyline: {
          publicHome: 53,
          publicAway: 47,
          sharpHome: 48,
          sharpAway: 52
        },
        spread: {
          publicHome: 55,
          publicAway: 45,
          sharpHome: 43,
          sharpAway: 57,
          line: -2.5
        },
        total: {
          publicOver: 67,
          publicUnder: 33,
          sharpOver: 38,
          sharpUnder: 62,
          line: 142.5
        },
        consensus: 'split',
        confidence: 'low'
      }
    ];

    return NextResponse.json({
      success: true,
      data: publicBettingData,
      lastUpdate: new Date().toISOString()
    });

  } catch (error) {
    console.error('Public betting API error:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch public betting data',
      data: []
    }, { status: 500 });
  }
}