import { NextRequest, NextResponse } from 'next/server';

// The Odds API for real-time line movement tracking
const ODDS_API_KEY = process.env.ODDS_API_KEY || 'b8d1f0a1c2e3f4g5h6i7j8k9';
const BASE_URL = 'https://api.the-odds-api.com/v4';

interface SteamMove {
  id: string;
  sport: string;
  matchup: string;
  betType: string;
  movement: string;
  magnitude: number;
  confidence: 'high' | 'medium' | 'low';
  timestamp: string;
  books: string[];
}

export async function POST(request: NextRequest) {
  try {
    const { sport = 'americanfootball_nfl', timeframe = '1h' } = await request.json();

    // Get current odds
    const currentResponse = await fetch(
      `${BASE_URL}/sports/${sport}/odds?` +
      `apiKey=${ODDS_API_KEY}&` +
      `regions=us&` +
      `markets=h2h,spreads,totals&` +
      `oddsFormat=american`,
      {
        headers: { 'Accept': 'application/json' },
      }
    );

    if (!currentResponse.ok) {
      throw new Error(`Odds API error: ${currentResponse.status}`);
    }

    const currentOdds = await currentResponse.json();
    const steamMoves: SteamMove[] = [];

    // Analyze odds movements (in production, would compare with historical data)
    for (const game of currentOdds) {
      if (!game.bookmakers || game.bookmakers.length < 2) continue;

      // Check for consensus line movements across multiple books
      const movements = analyzeLineMovement(game);
      steamMoves.push(...movements);
    }

    // Sort by confidence and magnitude
    steamMoves.sort((a, b) => {
      const confidenceOrder = { high: 3, medium: 2, low: 1 };
      return (confidenceOrder[b.confidence] * b.magnitude) - 
             (confidenceOrder[a.confidence] * a.magnitude);
    });

    return NextResponse.json({
      success: true,
      moves: steamMoves.slice(0, 10), // Top 10 moves
      count: steamMoves.length,
      timeframe,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Steam Moves Error:', error);
    
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to detect line movements',
      moves: [],
      count: 0,
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}

function analyzeLineMovement(game: any): SteamMove[] {
  const moves: SteamMove[] = [];
  
  try {
    // Analyze each market for movements
    const markets = ['h2h', 'spreads', 'totals'];
    
    for (const marketType of markets) {
      const bookmarkets = game.bookmakers
        .filter((book: any) => book.markets.some((m: any) => m.key === marketType))
        .map((book: any) => ({
          bookmaker: book.title,
          market: book.markets.find((m: any) => m.key === marketType)
        }));

      if (bookmarkets.length < 2) continue;

      // Detect consensus movements (simplified - in production would use historical data)
      const movement = detectConsensusMovement(bookmarkets, marketType);
      
      if (movement) {
        moves.push({
          id: `${game.id}-${marketType}-${Date.now()}`,
          sport: game.sport_title,
          matchup: `${game.away_team} @ ${game.home_team}`,
          betType: marketType,
          movement: movement.description,
          magnitude: movement.magnitude,
          confidence: movement.confidence,
          timestamp: new Date().toISOString(),
          books: bookmarkets.map(b => b.bookmaker)
        });
      }
    }
  } catch (error) {
    console.error('Error analyzing movement for game:', game.id, error);
  }
  
  return moves;
}

function detectConsensusMovement(bookmarkets: any[], marketType: string) {
  try {
    // Simplified movement detection - in production would compare with historical odds
    const outcomes = {};
    
    for (const { bookmaker, market } of bookmarkets) {
      if (!market?.outcomes) continue;
      
      for (const outcome of market.outcomes) {
        const key = outcome.point ? `${outcome.name}_${outcome.point}` : outcome.name;
        
        if (!outcomes[key]) {
          outcomes[key] = [];
        }
        
        outcomes[key].push({
          bookmaker,
          price: outcome.price,
          point: outcome.point
        });
      }
    }

    // Look for significant price differences that might indicate movement
    for (const [outcomeName, books] of Object.entries(outcomes)) {
      const prices = books.map(b => b.price);
      const maxPrice = Math.max(...prices);
      const minPrice = Math.min(...prices);
      
      // If there's significant variance, consider it movement
      if (marketType === 'h2h' && Math.abs(maxPrice - minPrice) >= 20) {
        return {
          description: `${outcomeName.split('_')[0]} line moving ${maxPrice > 0 ? 'out' : 'in'}`,
          magnitude: Math.abs(maxPrice - minPrice) / 10,
          confidence: Math.abs(maxPrice - minPrice) >= 30 ? 'high' : 'medium'
        };
      }
    }
    
    return null;
  } catch (error) {
    console.error('Error detecting consensus movement:', error);
    return null;
  }
}