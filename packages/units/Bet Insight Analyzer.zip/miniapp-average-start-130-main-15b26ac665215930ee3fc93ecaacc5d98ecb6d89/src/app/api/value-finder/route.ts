import { NextResponse } from 'next/server';

export interface ValueBet {
  id: string;
  sport: string;
  gameId: string;
  homeTeam: string;
  awayTeam: string;
  betType: 'moneyline' | 'spread' | 'total' | 'prop';
  selection: string;
  bookmaker: string;
  odds: number;
  impliedProbability: number;
  fairProbability: number;
  expectedValue: number;
  confidence: 'very-high' | 'high' | 'medium' | 'low';
  reasoning: string;
  maxStake: number;
  kellyFraction: number;
}

function calculateEV(odds: number, fairProb: number): number {
  const impliedProb = 1 / odds;
  return (fairProb * (odds - 1)) - (1 - fairProb);
}

function calculateKelly(odds: number, fairProb: number): number {
  const b = odds - 1; // net odds received
  const p = fairProb; // probability of winning
  const q = 1 - p; // probability of losing
  return (b * p - q) / b;
}

export async function GET() {
  try {
    const valueBets: ValueBet[] = [
      {
        id: 'vb-1',
        sport: 'NFL',
        gameId: 'nfl-buf-det',
        homeTeam: 'Detroit Lions',
        awayTeam: 'Buffalo Bills',
        betType: 'spread',
        selection: 'Buffalo Bills +3.5',
        bookmaker: 'FanDuel',
        odds: 1.91,
        impliedProbability: 52.4,
        fairProbability: 58.2,
        expectedValue: 11.7,
        confidence: 'high',
        reasoning: 'Sharp money moving toward Bills, line hasn\'t adjusted. Public heavily on Lions.',
        maxStake: 250,
        kellyFraction: 0.12
      },
      {
        id: 'vb-2',
        sport: 'NBA',
        gameId: 'nba-lal-bos',
        homeTeam: 'Boston Celtics',
        awayTeam: 'LA Lakers',
        betType: 'total',
        selection: 'Under 218.5',
        bookmaker: 'DraftKings',
        odds: 1.87,
        impliedProbability: 53.5,
        fairProbability: 62.1,
        expectedValue: 14.3,
        confidence: 'very-high',
        reasoning: 'Both teams playing back-to-back, key players questionable. Weather conditions favor under.',
        maxStake: 400,
        kellyFraction: 0.18
      },
      {
        id: 'vb-3',
        sport: 'NCAAB',
        gameId: 'ncaab-duke-unc',
        homeTeam: 'UNC Tar Heels',
        awayTeam: 'Duke Blue Devils',
        betType: 'moneyline',
        selection: 'Duke Blue Devils',
        bookmaker: 'BetMGM',
        odds: 2.15,
        impliedProbability: 46.5,
        fairProbability: 53.8,
        expectedValue: 8.9,
        confidence: 'medium',
        reasoning: 'Duke has better recent form and historical edge in rivalry games at UNC.',
        maxStake: 175,
        kellyFraction: 0.09
      },
      {
        id: 'vb-4',
        sport: 'NHL',
        gameId: 'nhl-nyr-phi',
        homeTeam: 'Philadelphia Flyers',
        awayTeam: 'New York Rangers',
        betType: 'total',
        selection: 'Over 6.0',
        bookmaker: 'Caesars',
        odds: 1.83,
        impliedProbability: 54.6,
        fairProbability: 61.4,
        expectedValue: 9.8,
        confidence: 'high',
        reasoning: 'Both goalies have been shaky lately, teams average 6.2 goals combined in head-to-head.',
        maxStake: 200,
        kellyFraction: 0.11
      }
    ];

    // Sort by expected value descending
    valueBets.sort((a, b) => b.expectedValue - a.expectedValue);

    return NextResponse.json({
      success: true,
      data: valueBets,
      count: valueBets.length,
      totalEV: valueBets.reduce((sum, bet) => sum + bet.expectedValue, 0),
      lastUpdate: new Date().toISOString()
    });

  } catch (error) {
    console.error('Value finder API error:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to find value bets',
      data: []
    }, { status: 500 });
  }
}