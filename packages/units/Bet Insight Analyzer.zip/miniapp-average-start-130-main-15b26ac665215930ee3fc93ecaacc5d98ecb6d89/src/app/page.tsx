'use client'
import { useState, useEffect } from "react";
import type { LoggedBet } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { BetLoggerForm } from "@/components/bet-logger-form";
import { SportBetTypeHeatmap } from "@/components/sport-bet-type-heatmap";
import { OddsBucketPanel } from "@/components/odds-bucket-panel";
import { LineBucketPanel } from "@/components/line-bucket-panel";
import { InsightsPanel } from "@/components/insights-panel";
import { TimelineChart } from "@/components/timeline-chart";
import { GeofenceStatus } from "@/components/geofence-status";
import { SEOSharePanel } from "@/components/seo-share-panel";
import { OddsComparisonDashboard } from "@/components/odds-comparison-dashboard";
import { ArbitragePanel } from "@/components/arbitrage-panel";
import { SteamMoveDetector } from "@/components/steam-move-detector";
import { AIPicksPanel } from "@/components/ai-picks-panel";
import { ParlayBuilder } from "@/components/parlay-builder";
import { KellyCalculator } from "@/components/kelly-calculator";
import { FuturesTracker } from "@/components/futures-tracker";
import { LiveDashboard } from "@/components/LiveDashboard";
import { WeatherCenter } from "@/components/WeatherCenter";
import { InjuryReportCenter } from "@/components/InjuryReportCenter";
import { PropAnalyzer } from "@/components/prop-analyzer";
import { CommunityPicks } from "@/components/community-picks";
import { TodaysGames } from "@/components/TodaysGames";
import { GameScheduleOverview } from "@/components/GameScheduleOverview";
import { buildOddsBuckets, buildLineBuckets, buildSportBetTypeStats, buildTimeline } from "@/lib/trends";
import { fetchSports, fetchOdds, detectArbitrage, findBestOdds, detectSteamMoves, trackLineMovements } from "@/lib/odds-api";
import { Download, Upload, TrendingUp, Settings, Zap, Target, Brain } from "lucide-react";
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";
import type { OddsEvent, ArbitrageOpportunity, BestOdds, SteamMove, LineMovement, HistoricalOdds } from "@/lib/odds-api-types";
import type { AIPick } from "@/lib/ai-picks-types";

export default function HomePage() {
  const { addMiniApp } = useAddMiniApp();
  const isInFarcaster = useIsInFarcaster();
  useQuickAuth(isInFarcaster);

  // Farcaster initialization
  useEffect(() => {
    const tryAddMiniApp = async () => {
      try {
        await addMiniApp();
      } catch (error) {
        console.error("Failed to add mini app:", error);
      }
    };
    tryAddMiniApp();
  }, [addMiniApp]);

  useEffect(() => {
    const initializeFarcaster = async () => {
      try {
        await new Promise((resolve) => setTimeout(resolve, 100));
        if (document.readyState !== "complete") {
          await new Promise<void>((resolve) => {
            if (document.readyState === "complete") {
              resolve();
            } else {
              window.addEventListener("load", () => resolve(), { once: true });
            }
          });
        }
        await sdk.actions.ready();
        console.log("Farcaster SDK initialized successfully");
      } catch (error) {
        console.error("Failed to initialize Farcaster SDK:", error);
        setTimeout(async () => {
          try {
            await sdk.actions.ready();
            console.log("Farcaster SDK initialized on retry");
          } catch (retryError) {
            console.error("Farcaster SDK retry failed:", retryError);
          }
        }, 1000);
      }
    };
    initializeFarcaster();
  }, []);

  // Personal analytics state
  const [bets, setBets] = useState<LoggedBet[]>([]);
  const [jsonInput, setJsonInput] = useState<string>("");
  const [timeBucket, setTimeBucket] = useState<"day" | "week">("day");

  // APIs are now server-side configured - no user keys needed

  // Live odds state
  const [liveOdds, setLiveOdds] = useState<OddsEvent[]>([]);
  const [bestOdds, setBestOdds] = useState<BestOdds[]>([]);
  const [lineMovements, setLineMovements] = useState<LineMovement[]>([]);
  const [historicalOdds, setHistoricalOdds] = useState<HistoricalOdds[]>([]);
  const [selectedSport, setSelectedSport] = useState<string>("basketball_nba");

  // Advanced analytics state
  const [arbitrageOpps, setArbitrageOpps] = useState<ArbitrageOpportunity[]>([]);
  const [steamMoves, setSteamMoves] = useState<SteamMove[]>([]);

  // AI picks state
  const [aiPicks, setAiPicks] = useState<AIPick[]>([]);

  // Generate AI picks from server API
  const generateAIPicks = async () => {
    try {
      const response = await fetch('/api/ai-picks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sport: selectedSport,
          count: 3, // Generate 3 picks
          bankroll: 1000
        })
      });
      
      const data = await response.json();
      
      if (!data.success && !data.demo) {
        throw new Error(data.error || 'Failed to generate AI picks');
      }
      
      setAiPicks(data.picks || []);
      
      if (data.demo) {
        alert('Using AI demo picks - live AI analysis available 24/7');
      }
    } catch (error) {
      console.error("Failed to generate AI picks:", error);
      alert("Failed to generate AI picks. Please try again.");
    }
  };

  // Load live odds from server API
  const loadLiveOdds = async () => {
    try {
      const response = await fetch(`/api/odds?sport=${selectedSport}&regions=us,us2&markets=h2h,spreads,totals`);
      const data = await response.json();
      
      if (!data.success && !data.demo) {
        throw new Error(data.error || 'Failed to fetch odds');
      }
      
      // Transform server data to match expected format
      const transformedOdds = data.data.map((game: any) => ({
        id: game.id,
        sport_key: game.sport,
        sport_title: game.sportTitle,
        commence_time: game.commence,
        home_team: game.homeTeam,
        away_team: game.awayTeam,
        bookmakers: game.bookmakers
      }));
      
      setLiveOdds(transformedOdds);
      setBestOdds(findBestOdds(transformedOdds));

      // Get arbitrage opportunities
      const arbResponse = await fetch('/api/arbitrage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gamesData: data.data, totalStake: 100 })
      });
      const arbData = await arbResponse.json();
      if (arbData.success || arbData.demo) {
        setArbitrageOpps(arbData.opportunities || []);
      }

      // Get steam moves
      const steamResponse = await fetch('/api/steam-moves', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gamesData: data.data, historicalData: historicalOdds })
      });
      const steamData = await steamResponse.json();
      if (steamData.success || steamData.demo) {
        setSteamMoves(steamData.steamMoves || []);
      }

      // Track line movements (simplified for server version)
      const movements = trackLineMovements(transformedOdds, historicalOdds);
      setLineMovements(movements);

      // Store current odds as historical for next comparison
      const newHistorical: HistoricalOdds[] = transformedOdds.flatMap((event: any) =>
        event.bookmakers.flatMap((bookmaker: any) =>
          bookmaker.markets.map((market: any) => ({
            eventId: event.id,
            timestamp: Date.now(),
            bookmaker: bookmaker.key,
            market: market.key,
            odds: market.outcomes,
          }))
        )
      );
      setHistoricalOdds((prev) => [...prev, ...newHistorical].slice(-1000));
      
      if (data.demo) {
        alert('Using demo data - live data available 24/7 with real-time updates');
      }
    } catch (error) {
      console.error("Failed to load live odds:", error);
      alert("Failed to load odds. Please try again.");
    }
  };

  // Personal analytics handlers
  const handleAddBet = (bet: LoggedBet): void => {
    setBets((prev) => [...prev, bet]);
  };

  const handleImportJSON = (): void => {
    try {
      const parsed = JSON.parse(jsonInput);
      const imported: LoggedBet[] = Array.isArray(parsed) ? parsed : [parsed];

      const validBets = imported.filter(
        (b) => b.id && b.placedAt && b.sport && b.betType && b.decimalOdds && b.stake !== undefined
      );

      if (validBets.length === 0) {
        alert("No valid bets found in JSON");
        return;
      }

      setBets((prev) => [...prev, ...validBets]);
      setJsonInput("");
      alert(`Successfully imported ${validBets.length} bet(s)`);
    } catch (error) {
      alert("Invalid JSON format. Please check your input.");
    }
  };

  const handleExportJSON = (): void => {
    const json = JSON.stringify(bets, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `betting-history-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleClearAll = (): void => {
    if (confirm("Are you sure you want to clear all bets? This cannot be undone.")) {
      setBets([]);
    }
  };

  const oddsBuckets = buildOddsBuckets(bets);
  const lineBuckets = buildLineBuckets(bets);
  const sportBetTypeStats = buildSportBetTypeStats(bets);
  const timeline = buildTimeline(bets, timeBucket);

  return (
    <div className="min-h-screen bg-[#020617] text-white p-4 md:p-8 pt-16 md:pt-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-2">
            <TrendingUp className="w-8 h-8 text-[#22d3ee]" />
            <h1 className="text-4xl font-bold text-[#22d3ee]">Ultimate Betting Analytics</h1>
          </div>
          <p className="text-gray-400 text-lg">
            Everything the pros use: Self-scouting, Live odds, AI picks, Arbitrage, and more
          </p>
          <div className="flex items-center justify-center gap-3 flex-wrap mt-4">
            <Badge variant="outline" className="bg-[#22c55e]/10 text-[#22c55e] border-[#22c55e]/30">
              Real-time Odds
            </Badge>
            <Badge variant="outline" className="bg-[#a855f7]/10 text-[#a855f7] border-[#a855f7]/30">
              AI-Powered
            </Badge>
            <Badge variant="outline" className="bg-[#22d3ee]/10 text-[#22d3ee] border-[#22d3ee]/30">
              Arbitrage Detection
            </Badge>
            <Badge variant="outline" className="bg-[#fbbf24]/10 text-[#fbbf24] border-[#fbbf24]/30">
              Steam Moves
            </Badge>
          </div>
        </div>

        {/* Geofencing Status */}
        <GeofenceStatus />

        {/* Main Tabs */}
        <Tabs defaultValue="live" className="w-full">
          <TabsList className="grid w-full grid-cols-6 bg-[#0b1120] border border-[#1e293b]">
            <TabsTrigger
              value="live"
              className="data-[state=active]:bg-[#22c55e] data-[state=active]:text-black text-xs sm:text-sm"
            >
              Live
            </TabsTrigger>
            <TabsTrigger
              value="games"
              className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black text-xs sm:text-sm"
            >
              Games
            </TabsTrigger>
            <TabsTrigger
              value="odds"
              className="data-[state=active]:bg-[#06b6d4] data-[state=active]:text-black text-xs sm:text-sm"
            >
              Odds
            </TabsTrigger>
            <TabsTrigger
              value="ai"
              className="data-[state=active]:bg-[#a855f7] data-[state=active]:text-black text-xs sm:text-sm"
            >
              AI
            </TabsTrigger>
            <TabsTrigger
              value="advanced"
              className="data-[state=active]:bg-[#fbbf24] data-[state=active]:text-black text-xs sm:text-sm"
            >
              Advanced
            </TabsTrigger>
            <TabsTrigger
              value="personal"
              className="data-[state=active]:bg-[#ef4444] data-[state=active]:text-black text-xs sm:text-sm"
            >
              Analytics
            </TabsTrigger>
          </TabsList>

          {/* Live Dashboard Tab */}
          <TabsContent value="live" className="space-y-6 mt-6">
            <LiveDashboard />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <WeatherCenter />
              <InjuryReportCenter />
            </div>
          </TabsContent>

          {/* Today's Games Tab */}
          <TabsContent value="games" className="space-y-6 mt-6">
            <TodaysGames />
          </TabsContent>

          {/* Live Odds Tab */}
          <TabsContent value="odds" className="space-y-6 mt-6">
            <Card className="bg-[#0b1120] border-[#1e293b]">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-[#22d3ee] text-2xl">Live Odds Comparison</CardTitle>
                    <p className="text-sm text-gray-400 mt-1">Real-time odds from 40+ sportsbooks</p>
                  </div>
                  <Button
                    onClick={loadLiveOdds}
                    className="bg-[#22d3ee] hover:bg-[#22d3ee]/90 text-black"
                  >
                    <Zap className="w-4 h-4 mr-2" />
                    Load Live Odds
                  </Button>
                </div>
              </CardHeader>
            </Card>

            {liveOdds.length > 0 ? (
              <>
                <OddsComparisonDashboard events={liveOdds} bestOdds={bestOdds} />
              </>
            ) : (
              <Card className="bg-[#0b1120] border-[#1e293b]">
                <CardContent className="py-12 text-center">
                  <Zap className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-xl font-medium text-gray-400 mb-2">No live odds loaded</h3>
                  <p className="text-gray-500">Click 'Load Live Odds' to get real-time data from 40+ sportsbooks</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* AI Tools Tab */}
          <TabsContent value="ai" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <AIPicksPanel picks={aiPicks} onGenerateMore={generateAIPicks} />
              <PropAnalyzer />
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ParlayBuilder />
              <KellyCalculator />
            </div>
          </TabsContent>

          {/* Advanced Tab */}
          <TabsContent value="advanced" className="space-y-6 mt-6">
            <ArbitragePanel opportunities={arbitrageOpps} />
            <SteamMoveDetector steamMoves={steamMoves} />
            <FuturesTracker />
            <CommunityPicks picks={[]} />
          </TabsContent>

          {/* Personal Analytics Tab */}
          <TabsContent value="personal" className="space-y-6 mt-6">
            {/* Data Input Section */}
            <Card className="bg-[#0b1120] border-[#1e293b]">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-[#22d3ee] text-2xl">Data Input</CardTitle>
                    <p className="text-sm text-gray-400 mt-1">Log bets manually or import from JSON</p>
                  </div>
                  <div className="flex gap-2">
                    {bets.length > 0 && (
                      <>
                        <Button
                          onClick={handleExportJSON}
                          variant="outline"
                          size="sm"
                          className="border-[#1e293b] hover:bg-[#1e293b]"
                        >
                          <Download className="w-4 h-4 mr-2" />
                          Export
                        </Button>
                        <Button
                          onClick={handleClearAll}
                          variant="outline"
                          size="sm"
                          className="border-red-900 text-red-400 hover:bg-red-900/20"
                        >
                          Clear All
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="manual" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 bg-[#020617]">
                    <TabsTrigger
                      value="manual"
                      className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black"
                    >
                      Manual Log
                    </TabsTrigger>
                    <TabsTrigger
                      value="import"
                      className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black"
                    >
                      Import JSON
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="manual" className="mt-4">
                    <BetLoggerForm onAddBet={handleAddBet} />
                  </TabsContent>

                  <TabsContent value="import" className="mt-4 space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="jsonInput" className="text-gray-300">
                        Paste JSON array of bets
                      </Label>
                      <Textarea
                        id="jsonInput"
                        value={jsonInput}
                        onChange={(e) => setJsonInput(e.target.value)}
                        className="bg-[#020617] border-[#1e293b] text-white font-mono text-sm min-h-[200px]"
                        placeholder='[{"id": "1", "placedAt": 1702080000000, "sport": "NFL", ...}]'
                      />
                    </div>
                    <Button
                      onClick={handleImportJSON}
                      className="w-full bg-[#22d3ee] hover:bg-[#22d3ee]/80 text-black font-medium"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Import Bets
                    </Button>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            {bets.length === 0 ? (
              <Card className="bg-[#0b1120] border-[#1e293b]">
                <CardContent className="py-12 text-center">
                  <TrendingUp className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-xl font-medium text-gray-400 mb-2">No bets logged yet</h3>
                  <p className="text-gray-500">Start logging your bets to uncover your betting edge</p>
                </CardContent>
              </Card>
            ) : (
              <>
                <InsightsPanel bets={bets} oddsBuckets={oddsBuckets} sportBetTypeStats={sportBetTypeStats} />
                <GameScheduleOverview />
                <SportBetTypeHeatmap stats={sportBetTypeStats} />
                <SEOSharePanel bets={bets} oddsBuckets={oddsBuckets} sportBetTypeStats={sportBetTypeStats} />
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <OddsBucketPanel buckets={oddsBuckets} />
                  <LineBucketPanel buckets={lineBuckets} />
                </div>

                {/* Timeline */}
                <Card className="bg-[#0b1120] border-[#1e293b]">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-[#22d3ee] text-xl">Performance Timeline</CardTitle>
                        <p className="text-sm text-gray-400 mt-1">Track your results over time</p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => setTimeBucket("day")}
                          variant={timeBucket === "day" ? "default" : "outline"}
                          size="sm"
                          className={
                            timeBucket === "day"
                              ? "bg-[#22d3ee] text-black hover:bg-[#22d3ee]/80"
                              : "border-[#1e293b] hover:bg-[#1e293b]"
                          }
                        >
                          Daily
                        </Button>
                        <Button
                          onClick={() => setTimeBucket("week")}
                          variant={timeBucket === "week" ? "default" : "outline"}
                          size="sm"
                          className={
                            timeBucket === "week"
                              ? "bg-[#22d3ee] text-black hover:bg-[#22d3ee]/80"
                              : "border-[#1e293b] hover:bg-[#1e293b]"
                          }
                        >
                          Weekly
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <TimelineChart data={timeline} bucket={timeBucket} />
                  </CardContent>
                </Card>
              </>
            )}
          </TabsContent>




        </Tabs>
      </div>
    </div>
  );
}
