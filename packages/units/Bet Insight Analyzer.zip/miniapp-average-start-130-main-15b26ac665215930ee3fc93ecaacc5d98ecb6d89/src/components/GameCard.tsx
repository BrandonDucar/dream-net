'use client';

import type React from 'react';
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { 
  Clock, 
  MapPin, 
  Activity, 
  TrendingUp, 
  AlertTriangle,
  Zap,
  Target,
  Users,
  Brain,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import type { GameMatchup } from '@/app/api/games/route';
import type { GameAnalysis } from '@/app/api/game-analysis/route';

interface GameCardProps {
  game: GameMatchup;
  oddsData?: any;
}

export const GameCard: React.FC<GameCardProps> = ({ game, oddsData }) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [analysis, setAnalysis] = useState<GameAnalysis | null>(null);
  const [isLoadingAnalysis, setIsLoadingAnalysis] = useState<boolean>(false);

  const loadAnalysis = async (): Promise<void> => {
    if (analysis) {
      setIsExpanded(!isExpanded);
      return;
    }

    setIsLoadingAnalysis(true);
    try {
      const response = await fetch('/api/game-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gameId: game.id,
          homeTeam: game.homeTeam,
          awayTeam: game.awayTeam,
          sport: game.sport
        })
      });

      const data = await response.json();
      if (data.success) {
        setAnalysis(data.analysis);
        setIsExpanded(true);
      }
    } catch (error) {
      console.error('Failed to load analysis:', error);
    }
    setIsLoadingAnalysis(false);
  };

  const getInjuryBadgeColor = (impact: string): string => {
    switch (impact) {
      case 'high': return 'destructive';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
      default: return 'outline';
    }
  };

  const getConfidenceBadgeColor = (confidence: string): string => {
    switch (confidence) {
      case 'very_high': return 'bg-green-600 text-white';
      case 'high': return 'bg-green-500 text-white';
      case 'medium': return 'bg-yellow-500 text-black';
      case 'low': return 'bg-red-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  return (
    <Card className="bg-[#0b1120] border-[#1e293b] hover:border-[#22d3ee]/30 transition-all duration-200">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-[#22d3ee] border-[#22d3ee]/30">
              {game.sport}
            </Badge>
            {game.league !== game.sport && (
              <Badge variant="outline" className="text-[#6b7280]">
                {game.league}
              </Badge>
            )}
            <Badge 
              variant={game.status === 'scheduled' ? 'outline' : 'secondary'}
              className={game.status === 'in_progress' ? 'text-green-400 border-green-400' : ''}
            >
              {game.status === 'scheduled' ? 'Upcoming' : 
               game.status === 'in_progress' ? 'Live' : 'Final'}
            </Badge>
          </div>
          <div className="flex items-center gap-2 text-sm text-[#6b7280]">
            <Clock className="w-4 h-4" />
            {game.gameTime}
          </div>
        </div>
        
        <CardTitle className="text-[#e5e7eb] text-xl">
          <div className="flex items-center justify-between">
            <div className="flex flex-col gap-1">
              <div className="flex items-center gap-2">
                <span>{game.awayTeam}</span>
                {game.awayRecord && (
                  <span className="text-sm text-[#6b7280]">({game.awayRecord})</span>
                )}
              </div>
              <div className="text-[#6b7280] text-sm">@</div>
              <div className="flex items-center gap-2">
                <span>{game.homeTeam}</span>
                {game.homeRecord && (
                  <span className="text-sm text-[#6b7280]">({game.homeRecord})</span>
                )}
              </div>
            </div>
            
            {oddsData && (
              <div className="text-right text-sm">
                <div className="flex gap-3">
                  <div className="text-[#22d3ee]">
                    <div className="font-medium">{oddsData.homeSpread || 'N/A'}</div>
                    <div className="text-xs text-[#6b7280]">Spread</div>
                  </div>
                  <div className="text-[#22d3ee]">
                    <div className="font-medium">{oddsData.total || 'N/A'}</div>
                    <div className="text-xs text-[#6b7280]">Total</div>
                  </div>
                  <div className="text-[#22d3ee]">
                    <div className="font-medium">{oddsData.homeML || 'N/A'}</div>
                    <div className="text-xs text-[#6b7280]">ML</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Basic Info */}
        <div className="flex items-center gap-4 text-sm text-[#6b7280]">
          <div className="flex items-center gap-1">
            <MapPin className="w-4 h-4" />
            {game.venue}
          </div>
          {game.weather && (
            <div className="flex items-center gap-1">
              <Activity className="w-4 h-4" />
              {game.weather.condition} • {game.weather.temp}
            </div>
          )}
        </div>

        {/* Key Notes */}
        {game.keynotes.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-[#22d3ee] flex items-center gap-1">
              <Target className="w-4 h-4" />
              Key Notes
            </h4>
            <div className="space-y-1">
              {game.keynotes.slice(0, 2).map((note, index) => (
                <div key={index} className="text-sm text-[#e5e7eb] flex items-start gap-2">
                  <div className="w-1 h-1 bg-[#22d3ee] rounded-full mt-2 flex-shrink-0" />
                  {note}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Injuries */}
        {game.injuries.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-[#ef4444] flex items-center gap-1">
              <AlertTriangle className="w-4 h-4" />
              Injury Report
            </h4>
            <div className="space-y-1">
              {game.injuries.slice(0, 3).map((injury, index) => (
                <div key={index} className="flex items-center justify-between text-sm">
                  <span className="text-[#e5e7eb]">
                    {injury.player} ({injury.team})
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-[#6b7280]">{injury.status}</span>
                    <Badge size="sm" variant={getInjuryBadgeColor(injury.impact) as any}>
                      {injury.impact}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Trends */}
        {game.trends.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-[#22d3ee] flex items-center gap-1">
              <TrendingUp className="w-4 h-4" />
              Recent Trends
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {game.trends.map((trend, index) => (
                <div key={index} className="text-sm">
                  <div className="text-[#e5e7eb] font-medium">{trend.team}</div>
                  <div className="text-[#6b7280]">{trend.trend}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        <Separator className="bg-[#1e293b]" />

        {/* Analysis Button */}
        <Button 
          onClick={loadAnalysis}
          disabled={isLoadingAnalysis}
          className="w-full bg-[#22d3ee] hover:bg-[#0891b2] text-black font-medium"
        >
          {isLoadingAnalysis ? (
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
              Analyzing Game...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4" />
              {analysis ? 'View Analysis' : 'Get AI Analysis'}
              {analysis && (isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />)}
            </div>
          )}
        </Button>

        {/* Expanded Analysis */}
        {analysis && isExpanded && (
          <div className="space-y-4 border-t border-[#1e293b] pt-4">
            {/* AI Prediction */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-[#22d3ee] flex items-center gap-1">
                <Brain className="w-4 h-4" />
                AI Prediction
              </h4>
              <div className="bg-[#020617] p-3 rounded-lg border border-[#1e293b]">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[#e5e7eb] font-medium">{analysis.aiPrediction.winner}</span>
                    <Badge className={getConfidenceBadgeColor(analysis.aiPrediction.confidence)}>
                      {analysis.aiPrediction.confidence.replace('_', ' ')}
                    </Badge>
                  </div>
                  <div className="text-[#22d3ee] font-medium">
                    {analysis.aiPrediction.winProbability}%
                  </div>
                </div>
                <Progress 
                  value={analysis.aiPrediction.winProbability} 
                  className="mb-3" 
                />
                <div className="space-y-1">
                  {analysis.aiPrediction.reasoning.slice(0, 2).map((reason, index) => (
                    <div key={index} className="text-sm text-[#6b7280] flex items-start gap-2">
                      <div className="w-1 h-1 bg-[#22d3ee] rounded-full mt-2 flex-shrink-0" />
                      {reason}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Betting Recommendations */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-[#22c55e] flex items-center gap-1">
                <Target className="w-4 h-4" />
                Best Bets
              </h4>
              <div className="space-y-2">
                {analysis.bettingRecommendations.slice(0, 2).map((bet, index) => (
                  <div key={index} className="bg-[#020617] p-3 rounded-lg border border-[#1e293b]">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[#e5e7eb] font-medium">{bet.bestBet}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-[#22c55e] text-sm">+{bet.expectedValue.toFixed(1)}% EV</span>
                        <Badge size="sm" className={getConfidenceBadgeColor(bet.confidence)}>
                          {bet.confidence.replace('_', ' ')}
                        </Badge>
                      </div>
                    </div>
                    <div className="text-sm text-[#6b7280]">{bet.reasoning}</div>
                    <div className="text-xs text-[#22d3ee] mt-1">
                      Kelly: {bet.kellySuggestion.toFixed(1)}% of bankroll
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Public vs Sharp */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-[#6b7280] flex items-center gap-1">
                  <Users className="w-4 h-4" />
                  Public Betting
                </h4>
                <div className="space-y-1">
                  {analysis.publicBetting.slice(0, 2).map((pub, index) => (
                    <div key={index} className="flex items-center justify-between text-sm">
                      <span className="text-[#e5e7eb]">{pub.side}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-[#6b7280]">{pub.percentage}%</span>
                        <Badge size="sm" variant={pub.action === 'fade' ? 'destructive' : 'outline'}>
                          {pub.action}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-sm font-medium text-[#f59e0b] flex items-center gap-1">
                  <Zap className="w-4 h-4" />
                  Sharp Money
                </h4>
                <div className="space-y-1">
                  {analysis.sharpMoney.map((sharp, index) => (
                    <div key={index} className="text-sm">
                      <div className="text-[#e5e7eb] font-medium">{sharp.side}</div>
                      <div className="text-[#6b7280]">{sharp.movement}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};