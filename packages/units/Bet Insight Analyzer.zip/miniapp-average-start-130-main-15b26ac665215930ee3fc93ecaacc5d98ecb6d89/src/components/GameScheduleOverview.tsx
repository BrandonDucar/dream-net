'use client';

import type React from 'react';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  Calendar,
  Clock,
  Trophy,
  TrendingUp,
  Star,
  ArrowRight
} from 'lucide-react';
import type { GameMatchup } from '@/app/api/games/route';
import { format } from 'date-fns';

interface GameScheduleOverviewProps {}

export const GameScheduleOverview: React.FC<GameScheduleOverviewProps> = () => {
  const [todaysGames, setTodaysGames] = useState<GameMatchup[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    const loadTodaysGames = async (): Promise<void> => {
      try {
        const today = format(new Date(), 'yyyy-MM-dd');
        const response = await fetch(`/api/games?sport=all&date=${today}`);
        const data = await response.json();
        
        if (data.success) {
          setTodaysGames(data.games.slice(0, 6)); // Show first 6 games
        }
      } catch (error) {
        console.error('Failed to load today\'s games:', error);
      }
      setIsLoading(false);
    };

    loadTodaysGames();
  }, []);

  const getStats = () => {
    const totalGames = todaysGames.length;
    const sportsCount = new Set(todaysGames.map(g => g.sport)).size;
    const liveGames = todaysGames.filter(g => g.status === 'in_progress').length;
    const upcomingGames = todaysGames.filter(g => g.status === 'scheduled').length;
    
    return { totalGames, sportsCount, liveGames, upcomingGames };
  };

  const stats = getStats();

  if (isLoading) {
    return (
      <Card className="bg-[#0b1120] border-[#1e293b]">
        <CardHeader>
          <Skeleton className="h-6 w-32 bg-[#1e293b]" />
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            {[1,2,3,4].map(i => (
              <Skeleton key={i} className="h-12 bg-[#1e293b]" />
            ))}
          </div>
          <div className="space-y-2">
            {[1,2,3].map(i => (
              <Skeleton key={i} className="h-16 bg-[#1e293b]" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-[#e5e7eb] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-[#22d3ee]" />
            Today's Games Overview
          </div>
          <Button 
            size="sm" 
            variant="outline"
            className="border-[#22d3ee]/30 text-[#22d3ee] hover:bg-[#22d3ee]/10"
          >
            View All
            <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </CardTitle>
        <div className="text-sm text-[#6b7280]">
          {format(new Date(), 'EEEE, MMMM d, yyyy')}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-[#020617] p-3 rounded-lg border border-[#1e293b]">
            <div className="text-[#22d3ee] text-lg font-bold">{stats.totalGames}</div>
            <div className="text-[#6b7280] text-sm">Total Games</div>
          </div>
          <div className="bg-[#020617] p-3 rounded-lg border border-[#1e293b]">
            <div className="text-[#22d3ee] text-lg font-bold">{stats.sportsCount}</div>
            <div className="text-[#6b7280] text-sm">Sports</div>
          </div>
          <div className="bg-[#020617] p-3 rounded-lg border border-[#1e293b]">
            <div className="text-[#22c55e] text-lg font-bold">{stats.liveGames}</div>
            <div className="text-[#6b7280] text-sm">Live Now</div>
          </div>
          <div className="bg-[#020617] p-3 rounded-lg border border-[#1e293b]">
            <div className="text-[#f59e0b] text-lg font-bold">{stats.upcomingGames}</div>
            <div className="text-[#6b7280] text-sm">Upcoming</div>
          </div>
        </div>

        {/* Featured Games */}
        {todaysGames.length === 0 ? (
          <div className="text-center py-8">
            <Trophy className="w-12 h-12 text-[#6b7280] mx-auto mb-4" />
            <h3 className="text-[#e5e7eb] text-lg font-medium mb-2">
              No games scheduled today
            </h3>
            <p className="text-[#6b7280]">
              Check back later for upcoming games
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-[#22d3ee] flex items-center gap-1">
              <Star className="w-4 h-4" />
              Featured Matchups
            </h4>
            
            <div className="space-y-2">
              {todaysGames.slice(0, 4).map(game => (
                <div 
                  key={game.id} 
                  className="bg-[#020617] p-3 rounded-lg border border-[#1e293b] hover:border-[#22d3ee]/30 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className="text-[#22d3ee] border-[#22d3ee]/30">
                        {game.sport}
                      </Badge>
                      <div className="flex flex-col">
                        <div className="text-[#e5e7eb] font-medium text-sm">
                          {game.awayTeam} @ {game.homeTeam}
                        </div>
                        <div className="text-[#6b7280] text-xs">
                          {game.venue} • {game.gameTime}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Badge 
                        variant={game.status === 'in_progress' ? 'secondary' : 'outline'}
                        className={game.status === 'in_progress' ? 'text-green-400 border-green-400' : ''}
                      >
                        {game.status === 'scheduled' ? 'Upcoming' : 
                         game.status === 'in_progress' ? 'Live' : 'Final'}
                      </Badge>
                      <Clock className="w-4 h-4 text-[#6b7280]" />
                    </div>
                  </div>
                  
                  {/* Key Notes Preview */}
                  {game.keynotes.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-[#1e293b]">
                      <div className="text-xs text-[#6b7280] flex items-start gap-2">
                        <TrendingUp className="w-3 h-3 mt-0.5 flex-shrink-0" />
                        {game.keynotes[0]}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
            
            {todaysGames.length > 4 && (
              <div className="text-center pt-2">
                <span className="text-sm text-[#6b7280]">
                  +{todaysGames.length - 4} more games today
                </span>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};