'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RefreshCw, Activity, AlertCircle, Clock, TrendingDown, TrendingUp } from 'lucide-react';

interface InjuryReport {
  gameId: string;
  sport: string;
  homeTeam: string;
  awayTeam: string;
  injuries: {
    player: string;
    position: string;
    team: 'home' | 'away';
    status: 'out' | 'doubtful' | 'questionable' | 'probable';
    injury: string;
    impactRating: number; // 1-10 scale
    lineImpact: string;
    notes: string;
  }[];
}

interface InjuryCenterProps {
  className?: string;
}

export function InjuryReportCenter({ className = '' }: InjuryCenterProps) {
  const [injuryReports, setInjuryReports] = useState<InjuryReport[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchInjuryReports = async () => {
    try {
      setLoading(true);
      // In production, this would connect to an injury report API
      const mockInjuryData: InjuryReport[] = [
        {
          gameId: 'nfl-buf-det',
          sport: 'NFL',
          homeTeam: 'Detroit Lions',
          awayTeam: 'Buffalo Bills',
          injuries: [
            {
              player: 'Aidan Hutchinson',
              position: 'DE',
              team: 'home',
              status: 'out',
              injury: 'Broken leg',
              impactRating: 9,
              lineImpact: 'Lions spread moved from -2.5 to -3.5',
              notes: 'Key pass rusher, major impact on Lions defense'
            },
            {
              player: 'Josh Allen',
              position: 'QB',
              team: 'away',
              status: 'questionable',
              injury: 'Shoulder',
              impactRating: 8,
              lineImpact: 'Total moved down 1.5 points',
              notes: 'Limited in practice, may affect passing accuracy'
            }
          ]
        },
        {
          gameId: 'nba-lal-bos',
          sport: 'NBA',
          homeTeam: 'Boston Celtics',
          awayTeam: 'LA Lakers',
          injuries: [
            {
              player: 'Jayson Tatum',
              position: 'F',
              team: 'home',
              status: 'probable',
              injury: 'Ankle',
              impactRating: 6,
              lineImpact: 'Spread moved 1 point toward Lakers',
              notes: 'Day-to-day, expected to play but may be limited'
            },
            {
              player: 'Anthony Davis',
              position: 'F/C',
              team: 'away',
              status: 'doubtful',
              injury: 'Back spasms',
              impactRating: 8,
              lineImpact: 'Total moved down 3 points',
              notes: 'Key defensive anchor, major rebounding impact'
            }
          ]
        },
        {
          gameId: 'nhl-nyr-phi',
          sport: 'NHL',
          homeTeam: 'Philadelphia Flyers',
          awayTeam: 'New York Rangers',
          injuries: [
            {
              player: 'Igor Shesterkin',
              position: 'G',
              team: 'away',
              status: 'out',
              injury: 'Lower body',
              impactRating: 9,
              lineImpact: 'Total moved up 0.5, Flyers ML improved',
              notes: 'Elite goaltender out, backup starting'
            }
          ]
        }
      ];

      setInjuryReports(mockInjuryData);
    } catch (error) {
      console.error('Error fetching injury reports:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInjuryReports();
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'out': return 'bg-red-600 text-white';
      case 'doubtful': return 'bg-orange-600 text-white';
      case 'questionable': return 'bg-yellow-600 text-white';
      case 'probable': return 'bg-green-600 text-white';
      default: return 'bg-gray-600 text-white';
    }
  };

  const getImpactIcon = (rating: number) => {
    if (rating >= 8) return <TrendingDown className="w-4 h-4 text-red-400" />;
    if (rating >= 6) return <AlertCircle className="w-4 h-4 text-yellow-400" />;
    return <Activity className="w-4 h-4 text-green-400" />;
  };

  const getImpactColor = (rating: number) => {
    if (rating >= 8) return 'text-red-400';
    if (rating >= 6) return 'text-yellow-400';
    return 'text-green-400';
  };

  if (loading) {
    return (
      <Card className={`border-slate-800 bg-slate-950 ${className}`}>
        <CardHeader>
          <CardTitle className="text-cyan-400">Injury Report Center</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse bg-slate-800 rounded-lg h-24"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`border-slate-800 bg-slate-950 ${className}`}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-cyan-400">Injury Report Center</CardTitle>
          <Button
            size="sm"
            variant="outline"
            onClick={fetchInjuryReports}
            disabled={loading}
            className="border-slate-600 bg-slate-800 text-slate-300 hover:bg-slate-700"
          >
            <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800 mb-4">
            <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
            <TabsTrigger value="high-impact" className="text-xs">High Impact</TabsTrigger>
            <TabsTrigger value="questionable" className="text-xs">Questionable</TabsTrigger>
            <TabsTrigger value="out" className="text-xs">Out</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            {injuryReports.map((report) => (
              <div key={report.gameId} className="bg-slate-900 rounded-lg p-4 border border-slate-700">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-slate-200">
                      {report.awayTeam} @ {report.homeTeam}
                    </h3>
                    <Badge variant="secondary" className="text-xs mt-1">
                      {report.sport}
                    </Badge>
                  </div>
                  <div className="text-xs text-slate-400">
                    {report.injuries.length} injury report{report.injuries.length !== 1 ? 's' : ''}
                  </div>
                </div>

                <div className="space-y-3">
                  {report.injuries.map((injury, index) => (
                    <div key={index} className="bg-slate-800 rounded-lg p-3">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <div>
                            <div className="font-medium text-slate-200">
                              {injury.player} ({injury.position})
                            </div>
                            <div className="text-xs text-slate-400">
                              {injury.team === 'home' ? report.homeTeam : report.awayTeam}
                            </div>
                          </div>
                          <Badge className={`text-xs ${getStatusColor(injury.status)}`}>
                            {injury.status.toUpperCase()}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2">
                          {getImpactIcon(injury.impactRating)}
                          <span className={`text-sm font-bold ${getImpactColor(injury.impactRating)}`}>
                            {injury.impactRating}/10
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div>
                          <div className="text-xs text-slate-400 mb-1">Injury</div>
                          <div className="text-sm text-slate-300">{injury.injury}</div>
                        </div>
                        <div>
                          <div className="text-xs text-slate-400 mb-1">Line Impact</div>
                          <div className="text-sm text-slate-300">{injury.lineImpact}</div>
                        </div>
                      </div>

                      <div className="mt-2">
                        <div className="text-xs text-slate-400 mb-1">Notes</div>
                        <div className="text-xs text-slate-300">{injury.notes}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </TabsContent>

          <TabsContent value="high-impact">
            <div className="space-y-4">
              {injuryReports.map((report) => 
                report.injuries.filter(injury => injury.impactRating >= 8).length > 0 && (
                  <div key={report.gameId} className="bg-slate-900 rounded-lg p-4 border border-slate-700">
                    <h3 className="font-semibold text-slate-200 mb-3">
                      {report.awayTeam} @ {report.homeTeam}
                    </h3>
                    {report.injuries.filter(injury => injury.impactRating >= 8).map((injury, index) => (
                      <div key={index} className="bg-red-900/20 border border-red-800 rounded-lg p-3">
                        <div className="flex items-center gap-2 mb-2">
                          <TrendingDown className="w-4 h-4 text-red-400" />
                          <span className="font-medium text-red-300">{injury.player}</span>
                          <Badge className="bg-red-600 text-white text-xs">
                            {injury.status.toUpperCase()}
                          </Badge>
                        </div>
                        <p className="text-xs text-slate-300">{injury.notes}</p>
                      </div>
                    ))}
                  </div>
                )
              )}
            </div>
          </TabsContent>

          <TabsContent value="questionable">
            <div className="space-y-4">
              {injuryReports.map((report) => 
                report.injuries.filter(injury => injury.status === 'questionable').length > 0 && (
                  <div key={report.gameId} className="bg-slate-900 rounded-lg p-4 border border-slate-700">
                    <h3 className="font-semibold text-slate-200 mb-3">
                      {report.awayTeam} @ {report.homeTeam}
                    </h3>
                    {report.injuries.filter(injury => injury.status === 'questionable').map((injury, index) => (
                      <div key={index} className="bg-yellow-900/20 border border-yellow-800 rounded-lg p-3">
                        <div className="flex items-center gap-2 mb-2">
                          <Clock className="w-4 h-4 text-yellow-400" />
                          <span className="font-medium text-yellow-300">{injury.player}</span>
                        </div>
                        <p className="text-xs text-slate-300">{injury.notes}</p>
                      </div>
                    ))}
                  </div>
                )
              )}
            </div>
          </TabsContent>

          <TabsContent value="out">
            <div className="space-y-4">
              {injuryReports.map((report) => 
                report.injuries.filter(injury => injury.status === 'out').length > 0 && (
                  <div key={report.gameId} className="bg-slate-900 rounded-lg p-4 border border-slate-700">
                    <h3 className="font-semibold text-slate-200 mb-3">
                      {report.awayTeam} @ {report.homeTeam}
                    </h3>
                    {report.injuries.filter(injury => injury.status === 'out').map((injury, index) => (
                      <div key={index} className="bg-red-900/20 border border-red-800 rounded-lg p-3">
                        <div className="flex items-center gap-2 mb-2">
                          <AlertCircle className="w-4 h-4 text-red-400" />
                          <span className="font-medium text-red-300">{injury.player}</span>
                          <span className="text-xs text-red-400">CONFIRMED OUT</span>
                        </div>
                        <p className="text-xs text-slate-300">{injury.lineImpact}</p>
                      </div>
                    ))}
                  </div>
                )
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}