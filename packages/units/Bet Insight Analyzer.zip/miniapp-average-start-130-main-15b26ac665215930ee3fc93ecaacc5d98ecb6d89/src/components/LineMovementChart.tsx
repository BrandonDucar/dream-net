'use client';

import React, { useState, useEffect } from 'react';
import type { LineMovementHistory } from '@/app/api/line-movement-history/route';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RefreshCw, TrendingUp, TrendingDown, Activity } from 'lucide-react';

interface LineMovementChartProps {
  className?: string;
}

export function LineMovementChart({ className = '' }: LineMovementChartProps) {
  const [data, setData] = useState<LineMovementHistory | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedGameId, setSelectedGameId] = useState('nfl-buf-det');

  const fetchData = async (gameId: string) => {
    try {
      setLoading(true);
      const response = await fetch(`/api/line-movement-history?gameId=${gameId}`);
      const result = await response.json();
      
      if (result.success) {
        setData(result.data);
      }
    } catch (error) {
      console.error('Error fetching line movement data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData(selectedGameId);
  }, [selectedGameId]);

  const getMagnitudeColor = (magnitude: string) => {
    switch (magnitude) {
      case 'steam': return 'bg-red-600 text-white';
      case 'large': return 'bg-orange-600 text-white';
      case 'medium': return 'bg-yellow-600 text-white';
      case 'small': return 'bg-green-600 text-white';
      default: return 'bg-gray-600 text-white';
    }
  };

  const getMovementIcon = (from: number, to: number) => {
    if (to > from) {
      return <TrendingUp className="w-3 h-3 text-green-400" />;
    } else if (to < from) {
      return <TrendingDown className="w-3 h-3 text-red-400" />;
    } else {
      return <Activity className="w-3 h-3 text-gray-400" />;
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const gameOptions = [
    { id: 'nfl-buf-det', label: 'Bills @ Lions' },
    { id: 'nba-lal-bos', label: 'Lakers @ Celtics' },
    { id: 'ncaab-duke-unc', label: 'Duke @ UNC' },
    { id: 'nhl-nyr-phi', label: 'Rangers @ Flyers' }
  ];

  if (loading) {
    return (
      <Card className={`border-slate-800 bg-slate-950 ${className}`}>
        <CardHeader>
          <CardTitle className="text-cyan-400">Line Movement</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse bg-slate-800 rounded-lg h-64"></div>
        </CardContent>
      </Card>
    );
  }

  if (!data) {
    return (
      <Card className={`border-slate-800 bg-slate-950 ${className}`}>
        <CardHeader>
          <CardTitle className="text-cyan-400">Line Movement</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-slate-400">
            No line movement data available
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`border-slate-800 bg-slate-950 ${className}`}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-cyan-400">Line Movement</CardTitle>
          <div className="flex items-center gap-2">
            <Select value={selectedGameId} onValueChange={setSelectedGameId}>
              <SelectTrigger className="w-40 bg-slate-800 border-slate-600 text-slate-300">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-600">
                {gameOptions.map((option) => (
                  <SelectItem key={option.id} value={option.id} className="text-slate-300">
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              size="sm"
              variant="outline"
              onClick={() => fetchData(selectedGameId)}
              disabled={loading}
              className="border-slate-600 bg-slate-800 text-slate-300 hover:bg-slate-700"
            >
              <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-6">
          <h3 className="font-semibold text-slate-200 mb-2">
            {data.awayTeam} @ {data.homeTeam}
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-900 rounded-lg p-3">
              <div className="text-xs text-slate-400 mb-1">Spread Movement</div>
              <div className="flex items-center gap-2">
                <span className="text-slate-300">
                  {data.openingSpread > 0 ? '+' : ''}{data.openingSpread}
                </span>
                <span className="text-slate-500">→</span>
                <span className="text-cyan-400 font-semibold">
                  {data.currentSpread > 0 ? '+' : ''}{data.currentSpread}
                </span>
                <Badge variant="outline" className={`text-xs ml-2 ${
                  data.spreadMovement > 0 ? 'border-green-500 text-green-400' : 
                  data.spreadMovement < 0 ? 'border-red-500 text-red-400' : 'border-gray-500 text-gray-400'
                }`}>
                  {data.spreadMovement > 0 ? '+' : ''}{data.spreadMovement}
                </Badge>
              </div>
            </div>
            <div className="bg-slate-900 rounded-lg p-3">
              <div className="text-xs text-slate-400 mb-1">Total Movement</div>
              <div className="flex items-center gap-2">
                <span className="text-slate-300">{data.openingTotal}</span>
                <span className="text-slate-500">→</span>
                <span className="text-cyan-400 font-semibold">{data.currentTotal}</span>
                <Badge variant="outline" className={`text-xs ml-2 ${
                  data.totalMovement > 0 ? 'border-green-500 text-green-400' : 
                  data.totalMovement < 0 ? 'border-red-500 text-red-400' : 'border-gray-500 text-gray-400'
                }`}>
                  {data.totalMovement > 0 ? '+' : ''}{data.totalMovement}
                </Badge>
              </div>
            </div>
          </div>
        </div>

        <Tabs defaultValue="key-moves" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-slate-800">
            <TabsTrigger value="key-moves">Key Moves</TabsTrigger>
            <TabsTrigger value="timeline">Timeline</TabsTrigger>
          </TabsList>

          <TabsContent value="key-moves" className="space-y-3 mt-4">
            {data.keyMoves.length === 0 ? (
              <div className="text-center py-4 text-slate-400">
                No significant line movements detected
              </div>
            ) : (
              data.keyMoves.map((move, index) => (
                <div key={index} className="bg-slate-900 rounded-lg p-3 border border-slate-700">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {getMovementIcon(move.from, move.to)}
                      <Badge variant="secondary" className="text-xs">
                        {move.type.toUpperCase()}
                      </Badge>
                      <Badge className={`text-xs ${getMagnitudeColor(move.magnitude)}`}>
                        {move.magnitude.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="text-xs text-slate-400">
                      {formatTime(move.timestamp)}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-slate-300">{move.from}</span>
                    <span className="text-slate-500">→</span>
                    <span className="text-cyan-400 font-semibold">{move.to}</span>
                  </div>
                  <p className="text-xs text-slate-400">{move.likelyReason}</p>
                </div>
              ))
            )}
          </TabsContent>

          <TabsContent value="timeline" className="mt-4">
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {data.movements.slice(-10).reverse().map((movement, index) => (
                <div key={index} className="flex items-center justify-between py-2 px-3 bg-slate-900 rounded border border-slate-700">
                  <div className="text-xs text-slate-400">
                    {formatTime(movement.timestamp)}
                  </div>
                  <div className="flex items-center gap-3 text-xs">
                    <span className="text-slate-300">
                      Spread: {movement.spread > 0 ? '+' : ''}{movement.spread.toFixed(1)}
                    </span>
                    <span className="text-slate-300">
                      Total: {movement.total.toFixed(1)}
                    </span>
                    <Badge variant={movement.volume === 'high' ? 'default' : 'secondary'} className="text-xs">
                      {movement.volume}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}