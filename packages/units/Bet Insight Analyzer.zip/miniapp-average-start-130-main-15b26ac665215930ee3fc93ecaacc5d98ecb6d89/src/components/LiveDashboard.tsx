'use client';

import React from 'react';
import { LiveScores } from '@/components/LiveScores';
import { PublicVsSharp } from '@/components/PublicVsSharp';
import { ValueFinder } from '@/components/ValueFinder';
import { LineMovementChart } from '@/components/LineMovementChart';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Activity, Target, TrendingUp, Zap } from 'lucide-react';

interface LiveDashboardProps {
  className?: string;
}

export function LiveDashboard({ className = '' }: LiveDashboardProps) {
  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header */}
      <Card className="bg-[#0b1120] border-[#1e293b]">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Activity className="w-8 h-8 text-cyan-400" />
            <div>
              <CardTitle className="text-2xl text-cyan-400">Live Dashboard</CardTitle>
              <p className="text-gray-400">
                Real-time scores, odds, public sentiment, and value opportunities
              </p>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-slate-900 rounded-lg p-3 text-center">
              <Zap className="w-5 h-5 text-green-400 mx-auto mb-1" />
              <div className="text-sm text-slate-300 mb-1">Live Games</div>
              <div className="text-lg font-bold text-green-400">4</div>
            </div>
            <div className="bg-slate-900 rounded-lg p-3 text-center">
              <Target className="w-5 h-5 text-blue-400 mx-auto mb-1" />
              <div className="text-sm text-slate-300 mb-1">Value Bets</div>
              <div className="text-lg font-bold text-blue-400">12</div>
            </div>
            <div className="bg-slate-900 rounded-lg p-3 text-center">
              <TrendingUp className="w-5 h-5 text-purple-400 mx-auto mb-1" />
              <div className="text-sm text-slate-300 mb-1">Sharp Moves</div>
              <div className="text-lg font-bold text-purple-400">3</div>
            </div>
            <div className="bg-slate-900 rounded-lg p-3 text-center">
              <Activity className="w-5 h-5 text-orange-400 mx-auto mb-1" />
              <div className="text-sm text-slate-300 mb-1">Line Changes</div>
              <div className="text-lg font-bold text-orange-400">18</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Top Row - Scores and Public vs Sharp */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <LiveScores />
        <PublicVsSharp />
      </div>

      {/* Second Row - Value Finder and Line Movement */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ValueFinder />
        <LineMovementChart />
      </div>
    </div>
  );
}