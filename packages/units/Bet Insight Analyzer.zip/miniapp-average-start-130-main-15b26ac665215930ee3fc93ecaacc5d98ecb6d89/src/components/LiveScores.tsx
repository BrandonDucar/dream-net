'use client';

import React, { useState, useEffect } from 'react';
import type { LiveScore } from '@/app/api/live-scores/route';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { RefreshCw, Play, Square } from 'lucide-react';

interface LiveScoresProps {
  className?: string;
}

export function LiveScores({ className = '' }: LiveScoresProps) {
  const [scores, setScores] = useState<LiveScore[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState<string>('');
  const [autoRefresh, setAutoRefresh] = useState(true);

  const fetchScores = async () => {
    try {
      const response = await fetch('/api/live-scores');
      const result = await response.json();
      
      if (result.success) {
        setScores(result.data);
        setLastUpdate(result.lastUpdate);
      }
    } catch (error) {
      console.error('Error fetching live scores:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchScores();
  }, []);

  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      fetchScores();
    }, 30000); // Refresh every 30 seconds

    return () => clearInterval(interval);
  }, [autoRefresh]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live': return 'bg-red-500 text-white';
      case 'final': return 'bg-green-500 text-white';
      case 'upcoming': return 'bg-blue-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const formatLastUpdate = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit'
    });
  };

  if (loading) {
    return (
      <Card className={`border-slate-800 bg-slate-950 ${className}`}>
        <CardHeader>
          <CardTitle className="text-cyan-400">Live Scores</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse bg-slate-800 rounded-lg h-16"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`border-slate-800 bg-slate-950 ${className}`}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-cyan-400">Live Scores</CardTitle>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => setAutoRefresh(!autoRefresh)}
              className={`border-slate-600 ${autoRefresh ? 'bg-green-600 text-white' : 'bg-slate-800 text-slate-300'}`}
            >
              {autoRefresh ? <Play className="w-3 h-3" /> : <Square className="w-3 h-3" />}
              {autoRefresh ? 'Live' : 'Paused'}
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={fetchScores}
              disabled={loading}
              className="border-slate-600 bg-slate-800 text-slate-300 hover:bg-slate-700"
            >
              <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </div>
        {lastUpdate && (
          <p className="text-xs text-slate-400">
            Last updated: {formatLastUpdate(lastUpdate)}
          </p>
        )}
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {scores.length === 0 ? (
            <div className="text-center py-8 text-slate-400">
              No live games at the moment
            </div>
          ) : (
            scores.map((score) => (
              <div key={score.id} className="bg-slate-900 rounded-lg p-3 border border-slate-700">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="secondary" className="text-xs font-medium">
                    {score.sport}
                  </Badge>
                  <Badge className={`text-xs font-medium ${getStatusColor(score.status)}`}>
                    {score.status.toUpperCase()}
                  </Badge>
                </div>
                
                <div className="grid grid-cols-3 items-center gap-3">
                  <div className="text-right">
                    <div className="font-medium text-slate-200 text-sm">
                      {score.awayTeam}
                    </div>
                    <div className="text-2xl font-bold text-cyan-400">
                      {score.awayScore}
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-xs text-slate-400 mb-1">VS</div>
                    {score.status === 'live' && (
                      <div className="text-xs text-slate-300">
                        <div>{score.period}</div>
                        <div className="font-mono text-cyan-400">
                          {score.timeRemaining}
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div className="text-left">
                    <div className="font-medium text-slate-200 text-sm">
                      {score.homeTeam}
                    </div>
                    <div className="text-2xl font-bold text-cyan-400">
                      {score.homeScore}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}