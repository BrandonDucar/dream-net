'use client';

import React, { useState, useEffect } from 'react';
import type { PublicBettingData } from '@/app/api/public-betting/route';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { RefreshCw, TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface PublicVsSharpProps {
  className?: string;
}

export function PublicVsSharp({ className = '' }: PublicVsSharpProps) {
  const [data, setData] = useState<PublicBettingData[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/public-betting');
      const result = await response.json();
      
      if (result.success) {
        setData(result.data);
      }
    } catch (error) {
      console.error('Error fetching public betting data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const getConsensusIcon = (consensus: string) => {
    switch (consensus) {
      case 'public': return <TrendingUp className="w-4 h-4 text-blue-400" />;
      case 'sharp': return <TrendingDown className="w-4 h-4 text-green-400" />;
      case 'split': return <Minus className="w-4 h-4 text-yellow-400" />;
      default: return null;
    }
  };

  const getConsensusColor = (consensus: string) => {
    switch (consensus) {
      case 'public': return 'bg-blue-600 text-white';
      case 'sharp': return 'bg-green-600 text-white';
      case 'split': return 'bg-yellow-600 text-white';
      default: return 'bg-gray-600 text-white';
    }
  };

  const getConfidenceColor = (confidence: string) => {
    switch (confidence) {
      case 'high': return 'bg-red-600 text-white';
      case 'medium': return 'bg-orange-600 text-white';
      case 'low': return 'bg-gray-600 text-white';
      default: return 'bg-gray-600 text-white';
    }
  };

  if (loading) {
    return (
      <Card className={`border-slate-800 bg-slate-950 ${className}`}>
        <CardHeader>
          <CardTitle className="text-cyan-400">Public vs Sharp Money</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse bg-slate-800 rounded-lg h-32"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`border-slate-800 bg-slate-950 ${className}`}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-cyan-400">Public vs Sharp Money</CardTitle>
          <Button
            size="sm"
            variant="outline"
            onClick={fetchData}
            disabled={loading}
            className="border-slate-600 bg-slate-800 text-slate-300 hover:bg-slate-700"
          >
            <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {data.map((game) => (
            <div key={game.gameId} className="bg-slate-900 rounded-lg p-4 border border-slate-700">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-semibold text-slate-200">
                    {game.awayTeam} @ {game.homeTeam}
                  </h3>
                  <p className="text-xs text-slate-400">{game.sport}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={`text-xs ${getConsensusColor(game.consensus)}`}>
                    {getConsensusIcon(game.consensus)}
                    {game.consensus.toUpperCase()}
                  </Badge>
                  <Badge className={`text-xs ${getConfidenceColor(game.confidence)}`}>
                    {game.confidence.toUpperCase()}
                  </Badge>
                </div>
              </div>

              <Tabs defaultValue="spread" className="w-full">
                <TabsList className="grid w-full grid-cols-3 bg-slate-800">
                  <TabsTrigger value="spread" className="text-xs">Spread</TabsTrigger>
                  <TabsTrigger value="moneyline" className="text-xs">ML</TabsTrigger>
                  <TabsTrigger value="total" className="text-xs">Total</TabsTrigger>
                </TabsList>

                <TabsContent value="spread" className="space-y-3 mt-4">
                  <div className="text-center text-sm text-slate-300 mb-2">
                    {game.homeTeam} {game.spread.line > 0 ? '+' : ''}{game.spread.line}
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs">
                      <span className="text-blue-400">Public: {game.spread.publicHome}%</span>
                      <span className="text-green-400">Sharp: {game.spread.sharpHome}%</span>
                    </div>
                    <Progress value={game.spread.publicHome} className="h-2 bg-slate-800">
                      <div 
                        className="h-full bg-gradient-to-r from-blue-600 to-green-600 rounded-full transition-all"
                        style={{ 
                          width: `${game.spread.publicHome}%`,
                          background: `linear-gradient(to right, 
                            rgb(59 130 246) 0%, 
                            rgb(59 130 246) ${game.spread.publicHome}%, 
                            rgb(34 197 94) ${game.spread.publicHome}%, 
                            rgb(34 197 94) 100%)`
                        }}
                      />
                    </Progress>
                  </div>
                </TabsContent>

                <TabsContent value="moneyline" className="space-y-3 mt-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs">
                      <span className="text-blue-400">Public Home: {game.moneyline.publicHome}%</span>
                      <span className="text-green-400">Sharp Home: {game.moneyline.sharpHome}%</span>
                    </div>
                    <Progress value={game.moneyline.publicHome} className="h-2 bg-slate-800">
                      <div 
                        className="h-full bg-gradient-to-r from-blue-600 to-green-600 rounded-full transition-all"
                        style={{ width: `${game.moneyline.publicHome}%` }}
                      />
                    </Progress>
                  </div>
                </TabsContent>

                <TabsContent value="total" className="space-y-3 mt-4">
                  <div className="text-center text-sm text-slate-300 mb-2">
                    O/U {game.total.line}
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs">
                      <span className="text-blue-400">Public Over: {game.total.publicOver}%</span>
                      <span className="text-green-400">Sharp Over: {game.total.sharpOver}%</span>
                    </div>
                    <Progress value={game.total.publicOver} className="h-2 bg-slate-800">
                      <div 
                        className="h-full bg-gradient-to-r from-blue-600 to-green-600 rounded-full transition-all"
                        style={{ width: `${game.total.publicOver}%` }}
                      />
                    </Progress>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}