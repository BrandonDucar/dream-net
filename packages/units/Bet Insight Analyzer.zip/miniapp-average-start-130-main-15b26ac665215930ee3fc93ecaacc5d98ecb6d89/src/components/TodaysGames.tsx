'use client';

import type React from 'react';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  Calendar, 
  RefreshCw, 
  Filter,
  Trophy,
  Clock,
  TrendingUp,
  Target
} from 'lucide-react';
import { GameCard } from './GameCard';
import type { GameMatchup } from '@/app/api/games/route';
import { format } from 'date-fns';

interface TodaysGamesProps {}

export const TodaysGames: React.FC<TodaysGamesProps> = () => {
  const [games, setGames] = useState<GameMatchup[]>([]);
  const [oddsData, setOddsData] = useState<Record<string, any>>({});
  const [selectedSport, setSelectedSport] = useState<string>('all');
  const [selectedDate, setSelectedDate] = useState<string>(
    format(new Date(), 'yyyy-MM-dd')
  );
  const [isLoadingGames, setIsLoadingGames] = useState<boolean>(true);
  const [isLoadingOdds, setIsLoadingOdds] = useState<boolean>(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  const sports = ['all', 'NFL', 'NBA', 'NCAAB', 'NHL', 'MLB'];

  const loadGames = async (sport: string = selectedSport, date: string = selectedDate): Promise<void> => {
    setIsLoadingGames(true);
    try {
      const response = await fetch(`/api/games?sport=${sport}&date=${date}`);
      const data = await response.json();
      
      if (data.success) {
        setGames(data.games);
      }
    } catch (error) {
      console.error('Failed to load games:', error);
    }
    setIsLoadingGames(false);
  };

  const loadOddsForGames = async (): Promise<void> => {
    if (games.length === 0) return;
    
    setIsLoadingOdds(true);
    try {
      // Get the sport from the first game to load appropriate odds
      const sportMap: Record<string, string> = {
        'NFL': 'americanfootball_nfl',
        'NBA': 'basketball_nba', 
        'NCAAB': 'basketball_ncaab',
        'NHL': 'icehockey_nhl',
        'MLB': 'baseball_mlb'
      };

      const uniqueSports = [...new Set(games.map(g => g.sport))];
      const oddsMap: Record<string, any> = {};

      // Load odds for each sport
      for (const sport of uniqueSports) {
        const sportKey = sportMap[sport] || 'americanfootball_nfl';
        
        try {
          const response = await fetch(`/api/odds?sport=${sportKey}`);
          const data = await response.json();
          
          if (data.success && data.odds) {
            // Map odds data to games by team matchup
            data.odds.forEach((oddsGame: any) => {
              if (oddsGame.bookmakers && oddsGame.bookmakers.length > 0) {
                const bestBook = oddsGame.bookmakers[0];
                const spreads = bestBook.markets?.find((m: any) => m.key === 'spreads')?.outcomes || [];
                const totals = bestBook.markets?.find((m: any) => m.key === 'totals')?.outcomes || [];
                const h2h = bestBook.markets?.find((m: any) => m.key === 'h2h')?.outcomes || [];
                
                const homeTeam = oddsGame.homeTeam;
                const awayTeam = oddsGame.awayTeam;
                
                // Create a key that matches our games
                const matchupKey = `${awayTeam}_${homeTeam}`.toLowerCase().replace(/\s+/g, '');
                
                oddsMap[matchupKey] = {
                  homeSpread: spreads.find((o: any) => o.name === homeTeam)?.point || 'N/A',
                  awaySpread: spreads.find((o: any) => o.name === awayTeam)?.point || 'N/A',
                  total: totals[0]?.point || 'N/A',
                  homeML: h2h.find((o: any) => o.name === homeTeam)?.price || 'N/A',
                  awayML: h2h.find((o: any) => o.name === awayTeam)?.price || 'N/A'
                };
              }
            });
          }
        } catch (sportError) {
          console.error(`Failed to load odds for ${sport}:`, sportError);
        }
      }
      
      setOddsData(oddsMap);
      setLastUpdated(new Date());
    } catch (error) {
      console.error('Failed to load odds:', error);
    }
    setIsLoadingOdds(false);
  };

  useEffect(() => {
    loadGames();
  }, [selectedSport, selectedDate]);

  useEffect(() => {
    if (games.length > 0) {
      loadOddsForGames();
    }
  }, [games]);

  const refreshData = async (): Promise<void> => {
    await Promise.all([
      loadGames(),
      loadOddsForGames()
    ]);
  };

  const getGameStats = () => {
    const totalGames = games.length;
    const sportsCount = new Set(games.map(g => g.sport)).size;
    const upcomingGames = games.filter(g => g.status === 'scheduled').length;
    const liveGames = games.filter(g => g.status === 'in_progress').length;
    
    return { totalGames, sportsCount, upcomingGames, liveGames };
  };

  const stats = getGameStats();

  if (isLoadingGames) {
    return (
      <div className="space-y-6">
        <Card className="bg-[#0b1120] border-[#1e293b]">
          <CardHeader>
            <Skeleton className="h-6 w-48 bg-[#1e293b]" />
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-4 gap-4 mb-6">
              {[1,2,3,4].map(i => (
                <Skeleton key={i} className="h-16 bg-[#1e293b]" />
              ))}
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {[1,2,3,4].map(i => (
                <Skeleton key={i} className="h-64 bg-[#1e293b]" />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <Card className="bg-[#0b1120] border-[#1e293b]">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-[#e5e7eb] flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#22d3ee]" />
              Today's Games
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button
                onClick={refreshData}
                disabled={isLoadingOdds}
                size="sm"
                variant="outline"
                className="border-[#22d3ee]/30 text-[#22d3ee] hover:bg-[#22d3ee]/10"
              >
                <RefreshCw className={`w-4 h-4 ${isLoadingOdds ? 'animate-spin' : ''}`} />
                {isLoadingOdds ? 'Updating...' : 'Refresh'}
              </Button>
            </div>
          </div>
          
          <div className="text-sm text-[#6b7280]">
            {format(new Date(selectedDate), 'EEEE, MMMM d, yyyy')}
            {lastUpdated && (
              <span className="ml-2">
                • Last updated: {format(lastUpdated, 'h:mm a')}
              </span>
            )}
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Stats Overview */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-[#020617] p-3 rounded-lg border border-[#1e293b]">
              <div className="text-[#22d3ee] text-lg font-bold">{stats.totalGames}</div>
              <div className="text-[#6b7280] text-sm">Total Games</div>
            </div>
            <div className="bg-[#020617] p-3 rounded-lg border border-[#1e293b]">
              <div className="text-[#22d3ee] text-lg font-bold">{stats.sportsCount}</div>
              <div className="text-[#6b7280] text-sm">Sports</div>
            </div>
            <div className="bg-[#020617] p-3 rounded-lg border border-[#1e293b]">
              <div className="text-[#22c55e] text-lg font-bold">{stats.liveGames}</div>
              <div className="text-[#6b7280] text-sm">Live Now</div>
            </div>
            <div className="bg-[#020617] p-3 rounded-lg border border-[#1e293b]">
              <div className="text-[#f59e0b] text-lg font-bold">{stats.upcomingGames}</div>
              <div className="text-[#6b7280] text-sm">Upcoming</div>
            </div>
          </div>

          {/* Sport Filter */}
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-[#6b7280]" />
            <div className="flex flex-wrap gap-2">
              {sports.map(sport => (
                <Button
                  key={sport}
                  onClick={() => setSelectedSport(sport)}
                  size="sm"
                  variant={selectedSport === sport ? "default" : "outline"}
                  className={selectedSport === sport 
                    ? "bg-[#22d3ee] text-black hover:bg-[#0891b2]" 
                    : "border-[#1e293b] text-[#6b7280] hover:text-[#e5e7eb] hover:border-[#22d3ee]/30"
                  }
                >
                  {sport.toUpperCase()}
                  {sport !== 'all' && (
                    <Badge variant="secondary" className="ml-1 text-xs">
                      {games.filter(g => g.sport === sport).length}
                    </Badge>
                  )}
                </Button>
              ))}
            </div>
          </div>

          {/* Date Selector */}
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#6b7280]" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-[#020617] border border-[#1e293b] rounded-lg px-3 py-1 text-[#e5e7eb] text-sm"
            />
          </div>
        </CardContent>
      </Card>

      {/* Games Grid */}
      {games.length === 0 ? (
        <Card className="bg-[#0b1120] border-[#1e293b]">
          <CardContent className="py-12 text-center">
            <Trophy className="w-12 h-12 text-[#6b7280] mx-auto mb-4" />
            <h3 className="text-[#e5e7eb] text-lg font-medium mb-2">
              No games scheduled
            </h3>
            <p className="text-[#6b7280] mb-4">
              {selectedSport === 'all' 
                ? 'No games found for this date across all sports.'
                : `No ${selectedSport} games found for this date.`
              }
            </p>
            <div className="flex justify-center gap-2">
              <Button
                onClick={() => setSelectedDate(format(new Date(), 'yyyy-MM-dd'))}
                size="sm"
                variant="outline"
                className="border-[#22d3ee]/30 text-[#22d3ee] hover:bg-[#22d3ee]/10"
              >
                Today's Games
              </Button>
              <Button
                onClick={() => setSelectedSport('all')}
                size="sm"
                variant="outline"
                className="border-[#22d3ee]/30 text-[#22d3ee] hover:bg-[#22d3ee]/10"
              >
                All Sports
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {games.map(game => {
            // Create matchup key to find odds data
            const matchupKey = `${game.awayTeam}_${game.homeTeam}`.toLowerCase().replace(/\s+/g, '');
            
            return (
              <GameCard 
                key={game.id} 
                game={game} 
                oddsData={oddsData[matchupKey]}
              />
            );
          })}
        </div>
      )}
    </div>
  );
};