'use client';

import React, { useState, useEffect } from 'react';
import type { ValueBet } from '@/app/api/value-finder/route';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { RefreshCw, TrendingUp, DollarSign, Target, AlertTriangle } from 'lucide-react';

interface ValueFinderProps {
  className?: string;
}

export function ValueFinder({ className = '' }: ValueFinderProps) {
  const [valueBets, setValueBets] = useState<ValueBet[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalEV, setTotalEV] = useState<number>(0);

  const fetchValueBets = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/value-finder');
      const result = await response.json();
      
      if (result.success) {
        setValueBets(result.data);
        setTotalEV(result.totalEV);
      }
    } catch (error) {
      console.error('Error fetching value bets:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchValueBets();
  }, []);

  const getConfidenceColor = (confidence: string) => {
    switch (confidence) {
      case 'very-high': return 'bg-green-600 text-white border-green-500';
      case 'high': return 'bg-blue-600 text-white border-blue-500';
      case 'medium': return 'bg-yellow-600 text-white border-yellow-500';
      case 'low': return 'bg-gray-600 text-white border-gray-500';
      default: return 'bg-gray-600 text-white border-gray-500';
    }
  };

  const getEVColor = (ev: number) => {
    if (ev >= 15) return 'text-green-400';
    if (ev >= 10) return 'text-blue-400';
    if (ev >= 5) return 'text-yellow-400';
    return 'text-red-400';
  };

  const formatOdds = (odds: number) => {
    if (odds >= 2) {
      return `+${Math.round((odds - 1) * 100)}`;
    } else {
      return `-${Math.round(100 / (odds - 1))}`;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  if (loading) {
    return (
      <Card className={`border-slate-800 bg-slate-950 ${className}`}>
        <CardHeader>
          <CardTitle className="text-cyan-400">Value Finder</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse bg-slate-800 rounded-lg h-24"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`border-slate-800 bg-slate-950 ${className}`}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CardTitle className="text-cyan-400">Value Finder</CardTitle>
            <Badge variant="secondary" className="bg-green-900 text-green-300">
              <TrendingUp className="w-3 h-3 mr-1" />
              Total EV: +{totalEV.toFixed(1)}%
            </Badge>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={fetchValueBets}
            disabled={loading}
            className="border-slate-600 bg-slate-800 text-slate-300 hover:bg-slate-700"
          >
            <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {valueBets.length === 0 ? (
            <div className="text-center py-8">
              <AlertTriangle className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-slate-400">No value bets found at this time</p>
              <p className="text-xs text-slate-500 mt-1">Check back soon for new opportunities</p>
            </div>
          ) : (
            valueBets.map((bet) => (
              <div key={bet.id} className="bg-slate-900 rounded-lg p-4 border border-slate-700 hover:border-slate-600 transition-colors">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="secondary" className="text-xs">
                        {bet.sport}
                      </Badge>
                      <Badge className={`text-xs ${getConfidenceColor(bet.confidence)}`}>
                        {bet.confidence.toUpperCase().replace('-', ' ')}
                      </Badge>
                      <Badge variant="outline" className="text-xs border-slate-600 text-slate-300">
                        {bet.betType.toUpperCase()}
                      </Badge>
                    </div>
                    <h3 className="font-semibold text-slate-200 text-sm mb-1">
                      {bet.awayTeam} @ {bet.homeTeam}
                    </h3>
                    <p className="text-slate-300 font-medium text-sm">
                      {bet.selection}
                    </p>
                  </div>
                  <div className="text-right ml-4">
                    <div className={`font-bold text-lg ${getEVColor(bet.expectedValue)}`}>
                      +{bet.expectedValue.toFixed(1)}% EV
                    </div>
                    <div className="text-slate-400 text-xs">
                      {formatOdds(bet.odds)} @ {bet.bookmaker}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-3">
                  <div className="bg-slate-800 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-1">
                      <Target className="w-4 h-4 text-cyan-400" />
                      <span className="text-xs text-slate-400">Probabilities</span>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-300">Implied:</span>
                        <span className="text-slate-200">{bet.impliedProbability.toFixed(1)}%</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-300">Fair:</span>
                        <span className="text-green-400">{bet.fairProbability.toFixed(1)}%</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-slate-800 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-1">
                      <DollarSign className="w-4 h-4 text-green-400" />
                      <span className="text-xs text-slate-400">Kelly Sizing</span>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-300">Kelly %:</span>
                        <span className="text-green-400">{(bet.kellyFraction * 100).toFixed(1)}%</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-300">Max Stake:</span>
                        <span className="text-slate-200">{formatCurrency(bet.maxStake)}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-800 rounded-lg p-3">
                  <div className="text-xs text-slate-400 mb-2">Analysis</div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {bet.reasoning}
                  </p>
                </div>

                <div className="mt-3">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-400">Expected Value</span>
                    <span className={`font-medium ${getEVColor(bet.expectedValue)}`}>
                      +{bet.expectedValue.toFixed(1)}%
                    </span>
                  </div>
                  <Progress 
                    value={Math.min(bet.expectedValue * 4, 100)} 
                    className="h-1 bg-slate-700"
                  />
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}