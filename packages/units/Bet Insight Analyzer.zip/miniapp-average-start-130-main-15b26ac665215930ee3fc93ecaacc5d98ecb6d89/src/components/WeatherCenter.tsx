'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { RefreshCw, Cloud, Wind, Thermometer, Eye, AlertTriangle } from 'lucide-react';

interface WeatherData {
  gameId: string;
  sport: string;
  homeTeam: string;
  awayTeam: string;
  venue: string;
  temperature: number;
  windSpeed: number;
  windDirection: string;
  precipitation: number;
  visibility: number;
  conditions: string;
  bettingImpact: 'high' | 'medium' | 'low';
  insights: string[];
}

interface WeatherCenterProps {
  className?: string;
}

export function WeatherCenter({ className = '' }: WeatherCenterProps) {
  const [weatherData, setWeatherData] = useState<WeatherData[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchWeatherData = async () => {
    try {
      setLoading(true);
      // In production, this would connect to a weather API like OpenWeatherMap
      const mockWeatherData: WeatherData[] = [
        {
          gameId: 'nfl-buf-det',
          sport: 'NFL',
          homeTeam: 'Detroit Lions',
          awayTeam: 'Buffalo Bills',
          venue: 'Ford Field',
          temperature: 72,
          windSpeed: 0,
          windDirection: 'N/A',
          precipitation: 0,
          visibility: 10,
          conditions: 'Indoor Dome',
          bettingImpact: 'low',
          insights: ['Indoor game - weather not a factor', 'Passing game should be unaffected']
        },
        {
          gameId: 'nfl-sea-gb',
          sport: 'NFL',
          homeTeam: 'Green Bay Packers',
          awayTeam: 'Seattle Seahawks',
          venue: 'Lambeau Field',
          temperature: 28,
          windSpeed: 18,
          windDirection: 'NW',
          precipitation: 5,
          visibility: 6,
          conditions: 'Snow, Windy',
          bettingImpact: 'high',
          insights: [
            'Strong winds favor under bets',
            'Snow affects passing accuracy',
            'Field goal accuracy reduced significantly',
            'Running game becomes more important'
          ]
        },
        {
          gameId: 'nfl-mia-den',
          sport: 'NFL',
          homeTeam: 'Denver Broncos',
          awayTeam: 'Miami Dolphins',
          venue: 'Empower Field',
          temperature: 22,
          windSpeed: 12,
          windDirection: 'W',
          precipitation: 0,
          visibility: 10,
          conditions: 'Cold, Breezy',
          bettingImpact: 'medium',
          insights: [
            'Cold weather affects Miami more than Denver',
            'Moderate wind may impact long passes',
            'Home team advantage in cold conditions'
          ]
        }
      ];

      setWeatherData(mockWeatherData);
    } catch (error) {
      console.error('Error fetching weather data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWeatherData();
  }, []);

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'bg-red-600 text-white';
      case 'medium': return 'bg-yellow-600 text-white';
      case 'low': return 'bg-green-600 text-white';
      default: return 'bg-gray-600 text-white';
    }
  };

  const getWeatherIcon = (conditions: string) => {
    if (conditions.includes('Snow') || conditions.includes('Rain')) {
      return <Cloud className="w-4 h-4 text-blue-400" />;
    } else if (conditions.includes('Wind')) {
      return <Wind className="w-4 h-4 text-gray-400" />;
    } else if (conditions.includes('Indoor')) {
      return <Thermometer className="w-4 h-4 text-green-400" />;
    }
    return <Cloud className="w-4 h-4 text-slate-400" />;
  };

  if (loading) {
    return (
      <Card className={`border-slate-800 bg-slate-950 ${className}`}>
        <CardHeader>
          <CardTitle className="text-cyan-400">Weather Center</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse bg-slate-800 rounded-lg h-20"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`border-slate-800 bg-slate-950 ${className}`}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-cyan-400">Weather Center</CardTitle>
          <Button
            size="sm"
            variant="outline"
            onClick={fetchWeatherData}
            disabled={loading}
            className="border-slate-600 bg-slate-800 text-slate-300 hover:bg-slate-700"
          >
            <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {weatherData.map((weather) => (
            <div key={weather.gameId} className="bg-slate-900 rounded-lg p-4 border border-slate-700">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-slate-200">
                    {weather.awayTeam} @ {weather.homeTeam}
                  </h3>
                  <p className="text-xs text-slate-400">{weather.venue}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="text-xs">
                    {weather.sport}
                  </Badge>
                  <Badge className={`text-xs ${getImpactColor(weather.bettingImpact)}`}>
                    {weather.bettingImpact.toUpperCase()} IMPACT
                  </Badge>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
                <div className="bg-slate-800 rounded-lg p-2 text-center">
                  <Thermometer className="w-4 h-4 text-orange-400 mx-auto mb-1" />
                  <div className="text-xs text-slate-400">Temp</div>
                  <div className="text-sm font-bold text-slate-200">{weather.temperature}°F</div>
                </div>
                
                <div className="bg-slate-800 rounded-lg p-2 text-center">
                  <Wind className="w-4 h-4 text-blue-400 mx-auto mb-1" />
                  <div className="text-xs text-slate-400">Wind</div>
                  <div className="text-sm font-bold text-slate-200">
                    {weather.windSpeed} mph {weather.windDirection !== 'N/A' ? weather.windDirection : ''}
                  </div>
                </div>
                
                <div className="bg-slate-800 rounded-lg p-2 text-center">
                  <Cloud className="w-4 h-4 text-gray-400 mx-auto mb-1" />
                  <div className="text-xs text-slate-400">Precip</div>
                  <div className="text-sm font-bold text-slate-200">{weather.precipitation}%</div>
                </div>
                
                <div className="bg-slate-800 rounded-lg p-2 text-center">
                  <Eye className="w-4 h-4 text-purple-400 mx-auto mb-1" />
                  <div className="text-xs text-slate-400">Visibility</div>
                  <div className="text-sm font-bold text-slate-200">{weather.visibility} mi</div>
                </div>
              </div>

              <div className="flex items-center gap-2 mb-3">
                {getWeatherIcon(weather.conditions)}
                <span className="text-sm text-slate-300">{weather.conditions}</span>
                {weather.bettingImpact === 'high' && (
                  <AlertTriangle className="w-4 h-4 text-red-400 ml-2" />
                )}
              </div>

              <div className="bg-slate-800 rounded-lg p-3">
                <div className="text-xs text-slate-400 mb-2">Betting Insights</div>
                <ul className="space-y-1">
                  {weather.insights.map((insight, index) => (
                    <li key={index} className="text-xs text-slate-300 flex items-start gap-2">
                      <span className="text-cyan-400 text-lg leading-3">•</span>
                      <span>{insight}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}