"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Sparkles, TrendingUp, Brain, Target } from "lucide-react";
import type { AIPick } from "@/lib/ai-picks-types";

interface AIPicksPanelProps {
  picks: AIPick[];
  onGenerateMore?: () => void;
}

export function AIPicksPanel({ picks, onGenerateMore }: AIPicksPanelProps) {
  const getConfidenceColor = (confidence: string): string => {
    switch (confidence) {
      case "very_high":
        return "bg-[#22c55e]/10 text-[#22c55e] border-[#22c55e]/30";
      case "high":
        return "bg-[#3b82f6]/10 text-[#3b82f6] border-[#3b82f6]/30";
      case "medium":
        return "bg-[#fbbf24]/10 text-[#fbbf24] border-[#fbbf24]/30";
      case "low":
        return "bg-[#9ca3af]/10 text-[#9ca3af] border-[#9ca3af]/30";
      default:
        return "bg-[#9ca3af]/10 text-[#9ca3af] border-[#9ca3af]/30";
    }
  };

  const sortedPicks = [...picks].sort((a, b) => {
    const confidenceOrder = { very_high: 4, high: 3, medium: 2, low: 1 };
    return (
      confidenceOrder[b.confidence as keyof typeof confidenceOrder] -
      confidenceOrder[a.confidence as keyof typeof confidenceOrder]
    );
  });

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-[#e5e7eb] flex items-center gap-2">
              <Brain className="w-5 h-5 text-[#a855f7]" />
              AI Expert Picks
            </CardTitle>
            <CardDescription className="text-[#9ca3af]">
              Powered by GPT-4o and Perplexity AI
            </CardDescription>
          </div>
          {onGenerateMore && (
            <Button onClick={onGenerateMore} size="sm" className="bg-[#a855f7] hover:bg-[#9333ea]">
              <Sparkles className="w-4 h-4 mr-2" />
              Generate More
            </Button>
          )}
        </div>
      </CardHeader>

      <CardContent>
        {picks.length === 0 ? (
          <div className="text-center py-8">
            <Brain className="w-12 h-12 text-[#9ca3af] mx-auto mb-3" />
            <p className="text-[#9ca3af]">No AI picks generated yet</p>
            <p className="text-sm text-[#6b7280] mt-2">
              Click "Generate More" to get AI-powered betting recommendations
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {sortedPicks.map((pick) => (
              <Card key={pick.id} className="bg-[#020617] border-[#1e293b]">
                <CardContent className="pt-4">
                  <div className="space-y-3">
                    {/* Header */}
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="font-medium text-[#e5e7eb]">
                          {pick.awayTeam} @ {pick.homeTeam}
                        </div>
                        <div className="text-sm text-[#9ca3af]">
                          {pick.sport} • {new Date(pick.commenceTime).toLocaleString()}
                        </div>
                      </div>
                      <Badge variant="outline" className={getConfidenceColor(pick.confidence)}>
                        {pick.confidence.replace("_", " ").toUpperCase()}
                      </Badge>
                    </div>

                    {/* Pick Details */}
                    <div className="p-3 bg-[#0b1120] rounded-lg border border-[#1e293b]">
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-lg font-bold text-[#a855f7]">{pick.prediction}</div>
                        <div className="text-right">
                          <div className="text-sm text-[#9ca3af]">Recommended Odds</div>
                          <div className="text-xl font-bold text-[#22d3ee]">
                            {pick.recommendedOdds > 0 ? "+" : ""}
                            {pick.recommendedOdds}
                          </div>
                        </div>
                      </div>
                      <div className="text-sm text-[#9ca3af] capitalize">{pick.pickType}</div>
                    </div>

                    {/* Metrics */}
                    <div className="grid grid-cols-3 gap-2">
                      <div className="p-2 bg-[#0b1120] rounded border border-[#1e293b]">
                        <div className="text-xs text-[#9ca3af] mb-1">Win Prob.</div>
                        <div className="text-lg font-bold text-[#22c55e]">{pick.winProbability}%</div>
                      </div>
                      <div className="p-2 bg-[#0b1120] rounded border border-[#1e293b]">
                        <div className="text-xs text-[#9ca3af] mb-1">Expected Value</div>
                        <div
                          className={`text-lg font-bold ${
                            pick.expectedValue > 0 ? "text-[#22c55e]" : "text-[#ef4444]"
                          }`}
                        >
                          {pick.expectedValue > 0 ? "+" : ""}
                          {pick.expectedValue.toFixed(1)}%
                        </div>
                      </div>
                      <div className="p-2 bg-[#0b1120] rounded border border-[#1e293b]">
                        <div className="text-xs text-[#9ca3af] mb-1">Kelly Stake</div>
                        <div className="text-lg font-bold text-[#22d3ee]">${pick.kellyStake.toFixed(2)}</div>
                      </div>
                    </div>

                    {/* Reasoning */}
                    <details className="group">
                      <summary className="text-sm text-[#22d3ee] cursor-pointer hover:text-[#67e8f9] flex items-center gap-2">
                        <span>View AI reasoning</span>
                        <Target className="w-4 h-4 group-open:rotate-90 transition-transform" />
                      </summary>
                      <div className="mt-2 p-3 bg-[#0b1120] rounded border border-[#1e293b] text-sm text-[#e5e7eb]">
                        {pick.reasoning}
                      </div>
                    </details>

                    {/* Factors */}
                    <details className="group">
                      <summary className="text-sm text-[#22d3ee] cursor-pointer hover:text-[#67e8f9] flex items-center gap-2">
                        <span>View analysis factors</span>
                        <TrendingUp className="w-4 h-4 group-open:rotate-90 transition-transform" />
                      </summary>
                      <div className="mt-2 space-y-2">
                        {Object.entries(pick.factors).map(([key, value]) => (
                          <div key={key} className="flex items-center gap-2">
                            <div className="text-sm text-[#9ca3af] capitalize w-32">
                              {key.replace(/([A-Z])/g, " $1").trim()}
                            </div>
                            <div className="flex-1 h-2 bg-[#1e293b] rounded-full overflow-hidden">
                              <div
                                className="h-full bg-[#a855f7] rounded-full"
                                style={{ width: `${(value / 10) * 100}%` }}
                              />
                            </div>
                            <div className="text-sm font-medium text-[#e5e7eb] w-8 text-right">
                              {value}/10
                            </div>
                          </div>
                        ))}
                      </div>
                    </details>

                    {/* Model info */}
                    <div className="flex items-center justify-between text-xs text-[#6b7280]">
                      <span>Model: {pick.model}</span>
                      <span>{new Date(pick.generatedAt).toLocaleString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
