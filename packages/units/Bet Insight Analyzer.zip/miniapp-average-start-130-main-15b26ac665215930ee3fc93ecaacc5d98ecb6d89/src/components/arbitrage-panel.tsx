"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertCircle, TrendingUp, DollarSign } from "lucide-react";
import type { ArbitrageOpportunity } from "@/lib/odds-api-types";

interface ArbitragePanelProps {
  opportunities: ArbitrageOpportunity[];
}

export function ArbitragePanel({ opportunities }: ArbitragePanelProps) {
  const sortedOpps = [...opportunities].sort((a, b) => b.profitPct - a.profitPct);

  if (opportunities.length === 0) {
    return (
      <Card className="bg-[#0b1120] border-[#1e293b]">
        <CardHeader>
          <CardTitle className="text-[#e5e7eb] flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-[#22d3ee]" />
            Arbitrage Opportunities
          </CardTitle>
          <CardDescription className="text-[#9ca3af]">
            Find guaranteed profit opportunities across bookmakers
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <AlertCircle className="w-12 h-12 text-[#9ca3af] mx-auto mb-3" />
            <p className="text-[#9ca3af]">No arbitrage opportunities detected at this time</p>
            <p className="text-sm text-[#6b7280] mt-2">
              Arbitrage opportunities are rare and disappear quickly. Check back frequently.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-[#e5e7eb] flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-[#22c55e]" />
              Arbitrage Opportunities
            </CardTitle>
            <CardDescription className="text-[#9ca3af]">
              Guaranteed profit opportunities found
            </CardDescription>
          </div>
          <Badge variant="outline" className="bg-[#22c55e]/10 text-[#22c55e] border-[#22c55e]/30">
            {opportunities.length} Found
          </Badge>
        </div>
      </CardHeader>

      <CardContent>
        <div className="space-y-3">
          {sortedOpps.map((opp) => (
            <Card key={opp.id} className="bg-[#020617] border-[#1e293b]">
              <CardContent className="pt-4">
                <div className="space-y-3">
                  {/* Header */}
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-medium text-[#e5e7eb]">
                        {opp.awayTeam} @ {opp.homeTeam}
                      </div>
                      <div className="text-sm text-[#9ca3af]">
                        {opp.sport} • {new Date(opp.commenceTime).toLocaleString()}
                      </div>
                    </div>
                    <Badge className="bg-[#22c55e] text-[#020617] hover:bg-[#22c55e]/90">
                      +{opp.profitPct.toFixed(2)}% Profit
                    </Badge>
                  </div>

                  {/* Stakes & Profit */}
                  <div className="grid grid-cols-3 gap-2 p-3 bg-[#0b1120] rounded-lg border border-[#1e293b]">
                    <div>
                      <div className="text-xs text-[#9ca3af] mb-1">Total Stake</div>
                      <div className="text-lg font-bold text-[#e5e7eb]">
                        $100.00
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-[#9ca3af] mb-1">Guaranteed Profit</div>
                      <div className="text-lg font-bold text-[#22c55e]">
                        ${opp.profit.toFixed(2)}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-[#9ca3af] mb-1">Return</div>
                      <div className="text-lg font-bold text-[#22d3ee]">
                        ${(100 + opp.profit).toFixed(2)}
                      </div>
                    </div>
                  </div>

                  {/* Bets to place */}
                  <div>
                    <div className="text-sm font-medium text-[#9ca3af] mb-2">Bets to Place:</div>
                    <div className="space-y-2">
                      {opp.books.map((book, idx) => {
                        const stake = opp.stakes[book.outcome] || 0;
                        return (
                          <div
                            key={idx}
                            className="flex justify-between items-center p-3 bg-[#0b1120] rounded border border-[#1e293b]"
                          >
                            <div>
                              <div className="font-medium text-[#e5e7eb]">{book.outcome}</div>
                              <div className="text-sm text-[#22d3ee]">{book.bookmaker}</div>
                            </div>
                            <div className="text-right">
                              <div className="text-sm text-[#9ca3af]">
                                Stake: <span className="text-[#e5e7eb] font-medium">${stake.toFixed(2)}</span>
                              </div>
                              <div className="text-sm text-[#22d3ee]">
                                @ {book.odds > 0 ? "+" : ""}{book.odds}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Warning */}
                  <div className="flex items-start gap-2 p-3 bg-[#fbbf24]/10 border border-[#fbbf24]/30 rounded">
                    <AlertCircle className="w-4 h-4 text-[#fbbf24] mt-0.5 flex-shrink-0" />
                    <p className="text-xs text-[#fbbf24]">
                      Place bets quickly - arbitrage opportunities disappear fast! Odds may change before you complete all bets.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
