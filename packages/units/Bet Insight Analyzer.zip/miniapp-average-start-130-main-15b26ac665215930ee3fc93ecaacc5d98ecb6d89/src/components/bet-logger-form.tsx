"use client";

import { useState } from "react";
import type { BetType, OddsFormat, BetOutcome, LoggedBet } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { americanToDecimal, calculateProfitLoss } from "@/lib/trends";

interface BetLoggerFormProps {
  onAddBet: (bet: LoggedBet) => void;
}

export function BetLoggerForm({ onAddBet }: BetLoggerFormProps) {
  const [sport, setSport] = useState<string>("NFL");
  const [league, setLeague] = useState<string>("AFC");
  const [betType, setBetType] = useState<BetType>("spread");
  const [description, setDescription] = useState<string>("");
  const [oddsFormat, setOddsFormat] = useState<OddsFormat>("american");
  const [inputOdds, setInputOdds] = useState<string>("-110");
  const [lineNumber, setLineNumber] = useState<string>("");
  const [stake, setStake] = useState<string>("100");
  const [outcome, setOutcome] = useState<BetOutcome>("win");

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();

    const oddsValue = parseFloat(inputOdds);
    if (isNaN(oddsValue)) {
      alert("Please enter valid odds");
      return;
    }

    const stakeValue = parseFloat(stake);
    if (isNaN(stakeValue) || stakeValue <= 0) {
      alert("Please enter valid stake amount");
      return;
    }

    const decimalOdds = oddsFormat === "american"
      ? americanToDecimal(oddsValue)
      : oddsValue;

    const lineValue = lineNumber.trim() ? parseFloat(lineNumber) : null;

    const profitLoss = calculateProfitLoss(stakeValue, decimalOdds, outcome);

    const bet: LoggedBet = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      placedAt: Date.now(),
      sport,
      league,
      betType,
      description,
      oddsFormat,
      inputOdds: oddsValue,
      decimalOdds,
      lineNumber: lineValue,
      stake: stakeValue,
      outcome,
      profitLoss
    };

    onAddBet(bet);

    setDescription("");
    setLineNumber("");
  };

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardContent className="pt-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="sport" className="text-gray-300">Sport</Label>
              <Select value={sport} onValueChange={setSport}>
                <SelectTrigger id="sport" className="bg-[#020617] border-[#1e293b] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#0b1120] border-[#1e293b]">
                  <SelectItem value="NFL">NFL</SelectItem>
                  <SelectItem value="NBA">NBA</SelectItem>
                  <SelectItem value="NCAAB">NCAAB</SelectItem>
                  <SelectItem value="NCAAF">NCAAF</SelectItem>
                  <SelectItem value="MLB">MLB</SelectItem>
                  <SelectItem value="NHL">NHL</SelectItem>
                  <SelectItem value="Soccer">Soccer</SelectItem>
                  <SelectItem value="UFC">UFC</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="league" className="text-gray-300">League</Label>
              <Input
                id="league"
                value={league}
                onChange={(e) => setLeague(e.target.value)}
                className="bg-[#020617] border-[#1e293b] text-white"
                placeholder="e.g., AFC, Big Ten"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="betType" className="text-gray-300">Bet Type</Label>
              <Select value={betType} onValueChange={(value) => setBetType(value as BetType)}>
                <SelectTrigger id="betType" className="bg-[#020617] border-[#1e293b] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#0b1120] border-[#1e293b]">
                  <SelectItem value="moneyline">Moneyline</SelectItem>
                  <SelectItem value="spread">Spread</SelectItem>
                  <SelectItem value="total">Total</SelectItem>
                  <SelectItem value="prop">Prop</SelectItem>
                  <SelectItem value="parlay">Parlay</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="outcome" className="text-gray-300">Outcome</Label>
              <Select value={outcome} onValueChange={(value) => setOutcome(value as BetOutcome)}>
                <SelectTrigger id="outcome" className="bg-[#020617] border-[#1e293b] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#0b1120] border-[#1e293b]">
                  <SelectItem value="win">Win</SelectItem>
                  <SelectItem value="loss">Loss</SelectItem>
                  <SelectItem value="push">Push</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-gray-300">Description</Label>
            <Input
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="bg-[#020617] border-[#1e293b] text-white"
              placeholder="e.g., Lakers -3.5 vs Suns"
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="oddsFormat" className="text-gray-300">Odds Format</Label>
              <Select value={oddsFormat} onValueChange={(value) => setOddsFormat(value as OddsFormat)}>
                <SelectTrigger id="oddsFormat" className="bg-[#020617] border-[#1e293b] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#0b1120] border-[#1e293b]">
                  <SelectItem value="american">American</SelectItem>
                  <SelectItem value="decimal">Decimal</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="inputOdds" className="text-gray-300">Odds</Label>
              <Input
                id="inputOdds"
                value={inputOdds}
                onChange={(e) => setInputOdds(e.target.value)}
                className="bg-[#020617] border-[#1e293b] text-white"
                placeholder={oddsFormat === "american" ? "-110" : "1.91"}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="lineNumber" className="text-gray-300">Line (optional)</Label>
              <Input
                id="lineNumber"
                value={lineNumber}
                onChange={(e) => setLineNumber(e.target.value)}
                className="bg-[#020617] border-[#1e293b] text-white"
                placeholder="e.g., -3.5, 221.5"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="stake" className="text-gray-300">Stake Amount</Label>
            <Input
              id="stake"
              type="number"
              step="0.01"
              value={stake}
              onChange={(e) => setStake(e.target.value)}
              className="bg-[#020617] border-[#1e293b] text-white"
              placeholder="100"
              required
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-[#22d3ee] hover:bg-[#22d3ee]/80 text-black font-medium"
          >
            Log Bet
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
