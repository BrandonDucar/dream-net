"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Users, ThumbsUp, MessageCircle, TrendingUp, Award } from "lucide-react";
import type { CommunityPick } from "@/lib/ai-picks-types";

interface CommunityPicksProps {
  picks: CommunityPick[];
}

// Mock data for demonstration
const mockPicks: CommunityPick[] = [
  {
    id: "1",
    userId: "user1",
    username: "SharpBettor47",
    verifiedRecord: {
      totalPicks: 284,
      wins: 165,
      losses: 119,
      pushes: 0,
      roi: 8.3,
      streak: 5,
      streakType: "win",
    },
    eventId: "event1",
    sport: "NFL",
    homeTeam: "Kansas City Chiefs",
    awayTeam: "Buffalo Bills",
    pickType: "spread",
    selection: "Bills +2.5",
    odds: -110,
    confidence: "high",
    reasoning:
      "Buffalo's defense has been elite, allowing only 17 PPG over last 5 games. Chiefs struggling without key offensive weapons. Line moved from +3 to +2.5, sharp money on Bills.",
    postedAt: Date.now() - 3600000,
    likes: 47,
    comments: 12,
  },
  {
    id: "2",
    userId: "user2",
    username: "NBAProFade",
    verifiedRecord: {
      totalPicks: 189,
      wins: 112,
      losses: 77,
      pushes: 0,
      roi: 12.1,
      streak: 3,
      streakType: "win",
    },
    eventId: "event2",
    sport: "NBA",
    homeTeam: "Los Angeles Lakers",
    awayTeam: "Boston Celtics",
    pickType: "total",
    selection: "Under 225.5",
    odds: -105,
    confidence: "very_high",
    reasoning:
      "Both teams playing 4th game in 6 nights. Lakers ranked 5th in defensive efficiency. Celtics without key bench scorer. Pace will be slow.",
    postedAt: Date.now() - 7200000,
    likes: 89,
    comments: 24,
  },
  {
    id: "3",
    userId: "user3",
    username: "MLBAnalyzer",
    verifiedRecord: {
      totalPicks: 412,
      wins: 224,
      losses: 188,
      pushes: 0,
      roi: 5.7,
      streak: 2,
      streakType: "loss",
    },
    eventId: "event3",
    sport: "MLB",
    homeTeam: "New York Yankees",
    awayTeam: "Tampa Bay Rays",
    pickType: "moneyline",
    selection: "Yankees ML",
    odds: -145,
    confidence: "medium",
    reasoning:
      "Cole on the mound vs struggling Rays offense. Yankees 12-3 at home. Rays bullpen exhausted from extra inning game yesterday.",
    postedAt: Date.now() - 10800000,
    likes: 32,
    comments: 8,
  },
];

export function CommunityPicks({ picks = mockPicks }: CommunityPicksProps) {
  const getConfidenceColor = (confidence: string): string => {
    switch (confidence) {
      case "very_high":
        return "bg-[#22c55e]/10 text-[#22c55e] border-[#22c55e]/30";
      case "high":
        return "bg-[#3b82f6]/10 text-[#3b82f6] border-[#3b82f6]/30";
      case "medium":
        return "bg-[#fbbf24]/10 text-[#fbbf24] border-[#fbbf24]/30";
      case "low":
        return "bg-[#9ca3af]/10 text-[#9ca3af] border-[#9ca3af]/30";
      default:
        return "bg-[#9ca3af]/10 text-[#9ca3af] border-[#9ca3af]/30";
    }
  };

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-[#e5e7eb] flex items-center gap-2">
          <Users className="w-5 h-5 text-[#22d3ee]" />
          Community Picks
        </CardTitle>
        <CardDescription className="text-[#9ca3af]">
          Verified picks from top-performing bettors
        </CardDescription>
      </CardHeader>

      <CardContent>
        <div className="space-y-3">
          {picks.map((pick) => {
            const winRate = ((pick.verifiedRecord.wins / pick.verifiedRecord.totalPicks) * 100).toFixed(1);

            return (
              <Card key={pick.id} className="bg-[#020617] border-[#1e293b]">
                <CardContent className="pt-4">
                  <div className="space-y-3">
                    {/* User info */}
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <div className="font-medium text-[#e5e7eb]">{pick.username}</div>
                          {pick.verifiedRecord.roi > 10 && (
                            <Award className="w-4 h-4 text-[#fbbf24]" />
                          )}
                        </div>
                        <div className="text-xs text-[#9ca3af] mt-1">
                          {pick.verifiedRecord.totalPicks} picks •{" "}
                          <span className="text-[#22c55e]">{winRate}% win rate</span> •{" "}
                          <span className="text-[#22d3ee]">
                            {pick.verifiedRecord.roi > 0 ? "+" : ""}
                            {pick.verifiedRecord.roi}% ROI
                          </span>
                        </div>
                        {pick.verifiedRecord.streak >= 3 && (
                          <div className="flex items-center gap-1 mt-1">
                            <TrendingUp className="w-3 h-3 text-[#22c55e]" />
                            <span className="text-xs text-[#22c55e]">
                              {pick.verifiedRecord.streak} {pick.verifiedRecord.streakType} streak
                            </span>
                          </div>
                        )}
                      </div>
                      <Badge variant="outline" className={getConfidenceColor(pick.confidence)}>
                        {pick.confidence.replace("_", " ").toUpperCase()}
                      </Badge>
                    </div>

                    {/* Pick details */}
                    <div className="p-3 bg-[#0b1120] rounded-lg border border-[#1e293b]">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <div className="font-medium text-[#e5e7eb]">
                            {pick.awayTeam} @ {pick.homeTeam}
                          </div>
                          <div className="text-sm text-[#9ca3af]">{pick.sport}</div>
                        </div>
                        <div className="text-xs text-[#6b7280]">
                          {new Date(pick.postedAt).toLocaleTimeString()}
                        </div>
                      </div>
                      <div className="flex items-baseline gap-2">
                        <div className="text-lg font-bold text-[#22d3ee]">{pick.selection}</div>
                        <div className="text-sm text-[#9ca3af]">
                          @ {pick.odds > 0 ? "+" : ""}
                          {pick.odds}
                        </div>
                        <Badge
                          variant="outline"
                          className="bg-[#1e293b] text-[#9ca3af] border-[#1e293b] text-xs"
                        >
                          {pick.pickType}
                        </Badge>
                      </div>
                    </div>

                    {/* Reasoning */}
                    <div className="p-3 bg-[#0b1120] rounded border border-[#1e293b]">
                      <div className="text-xs font-medium text-[#9ca3af] mb-1">Analysis:</div>
                      <p className="text-sm text-[#e5e7eb] leading-relaxed">{pick.reasoning}</p>
                    </div>

                    {/* Engagement */}
                    <div className="flex items-center gap-4 text-sm">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-[#9ca3af] hover:text-[#22d3ee] hover:bg-[#22d3ee]/10 gap-2"
                      >
                        <ThumbsUp className="w-4 h-4" />
                        {pick.likes}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-[#9ca3af] hover:text-[#22d3ee] hover:bg-[#22d3ee]/10 gap-2"
                      >
                        <MessageCircle className="w-4 h-4" />
                        {pick.comments}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-4 text-center">
          <Button variant="outline" className="border-[#1e293b] text-[#22d3ee] hover:bg-[#22d3ee]/10">
            Load More Picks
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
