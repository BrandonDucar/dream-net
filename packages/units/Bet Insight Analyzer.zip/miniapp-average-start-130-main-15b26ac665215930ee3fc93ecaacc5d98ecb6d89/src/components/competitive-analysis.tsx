'use client'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, XCircle, TrendingUp, MapPin, Share2, BarChart3 } from "lucide-react";

export function CompetitiveAnalysis() {
  const competitors = [
    {
      name: "Action Network",
      features: {
        oddsComparison: true,
        expertPicks: true,
        liveOdds: true,
        performanceTracking: true,
        selfScoutingTrends: false,
        oddsRangeHeatmaps: false,
        lineRangeAnalysis: false,
        aiSEO: false,
        geofencing: false,
        roiByOddsRange: false
      }
    },
    {
      name: "VegasInsider",
      features: {
        oddsComparison: true,
        expertPicks: true,
        liveOdds: true,
        performanceTracking: true,
        selfScoutingTrends: false,
        oddsRangeHeatmaps: false,
        lineRangeAnalysis: false,
        aiSEO: false,
        geofencing: false,
        roiByOddsRange: false
      }
    },
    {
      name: "BetQL",
      features: {
        oddsComparison: true,
        expertPicks: true,
        liveOdds: true,
        performanceTracking: true,
        selfScoutingTrends: false,
        oddsRangeHeatmaps: false,
        lineRangeAnalysis: false,
        aiSEO: false,
        geofencing: false,
        roiByOddsRange: false
      }
    },
    {
      name: "BettingPros",
      features: {
        oddsComparison: true,
        expertPicks: true,
        liveOdds: true,
        performanceTracking: true,
        selfScoutingTrends: false,
        oddsRangeHeatmaps: false,
        lineRangeAnalysis: false,
        aiSEO: false,
        geofencing: false,
        roiByOddsRange: false
      }
    },
    {
      name: "Trend & Heatmap Explorer",
      features: {
        oddsComparison: false,
        expertPicks: false,
        liveOdds: false,
        performanceTracking: true,
        selfScoutingTrends: true,
        oddsRangeHeatmaps: true,
        lineRangeAnalysis: true,
        aiSEO: true,
        geofencing: true,
        roiByOddsRange: true
      },
      isOurs: true
    }
  ];

  const featureLabels: Record<string, { label: string; icon: JSX.Element }> = {
    oddsComparison: { label: "Odds Comparison", icon: <BarChart3 className="w-4 h-4" /> },
    expertPicks: { label: "Expert Picks", icon: <TrendingUp className="w-4 h-4" /> },
    liveOdds: { label: "Live Odds", icon: <TrendingUp className="w-4 h-4" /> },
    performanceTracking: { label: "Performance Tracking", icon: <BarChart3 className="w-4 h-4" /> },
    selfScoutingTrends: { label: "Self-Scouting Trends", icon: <TrendingUp className="w-4 h-4" /> },
    oddsRangeHeatmaps: { label: "Odds Range Heatmaps", icon: <BarChart3 className="w-4 h-4" /> },
    lineRangeAnalysis: { label: "Line Range Analysis", icon: <BarChart3 className="w-4 h-4" /> },
    aiSEO: { label: "AI-Powered SEO", icon: <Share2 className="w-4 h-4" /> },
    geofencing: { label: "Legal Geofencing", icon: <MapPin className="w-4 h-4" /> },
    roiByOddsRange: { label: "ROI by Odds Range", icon: <TrendingUp className="w-4 h-4" /> }
  };

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-[#22d3ee] text-xl flex items-center gap-2">
          <BarChart3 className="w-5 h-5" />
          Competitive Analysis
        </CardTitle>
        <p className="text-sm text-gray-400 mt-1">
          How we compare to leading betting analytics platforms
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Summary */}
          <div className="bg-gradient-to-r from-green-900/20 to-cyan-900/20 border border-green-700/30 rounded-lg p-4">
            <h3 className="font-medium text-green-100 mb-2">What Makes Us Unique</h3>
            <ul className="text-sm text-green-200/80 space-y-2">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                <span>
                  <strong>Self-scouting focus:</strong> Find YOUR edge, not generic picks from experts
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                <span>
                  <strong>Odds range analysis:</strong> Discover which odds ranges you actually win at
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                <span>
                  <strong>Line range heatmaps:</strong> See performance by spread/total ranges
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                <span>
                  <strong>AI-powered SEO:</strong> Share insights with optimized meta tags & social previews
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                <span>
                  <strong>Legal geofencing:</strong> Verify jurisdiction with VPN/proxy detection
                </span>
              </li>
            </ul>
          </div>

          {/* Comparison Table */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#1e293b]">
                  <th className="text-left p-3 text-sm font-medium text-gray-400">Feature</th>
                  {competitors.map((comp, i) => (
                    <th
                      key={i}
                      className={`text-center p-3 text-sm font-medium ${
                        comp.isOurs ? "text-[#22d3ee]" : "text-gray-400"
                      }`}
                    >
                      <div className="flex flex-col items-center gap-1">
                        <span className={comp.isOurs ? "font-bold" : ""}>{comp.name}</span>
                        {comp.isOurs && (
                          <span className="text-xs bg-[#22d3ee] text-black px-2 py-0.5 rounded">
                            This App
                          </span>
                        )}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {Object.keys(featureLabels).map((featureKey, idx) => {
                  const feature = featureLabels[featureKey as keyof typeof featureLabels];
                  return (
                    <tr key={idx} className="border-b border-[#1e293b]/50 hover:bg-[#1e293b]/20">
                      <td className="p-3 text-sm text-gray-300">
                        <div className="flex items-center gap-2">
                          {feature.icon}
                          <span>{feature.label}</span>
                        </div>
                      </td>
                      {competitors.map((comp, i) => {
                        const hasFeature = comp.features[featureKey as keyof typeof comp.features];
                        return (
                          <td key={i} className="p-3 text-center">
                            {hasFeature ? (
                              <CheckCircle
                                className={`w-5 h-5 mx-auto ${
                                  comp.isOurs ? "text-green-400" : "text-gray-500"
                                }`}
                              />
                            ) : (
                              <XCircle className="w-5 h-5 mx-auto text-gray-700" />
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Key Differentiators */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-[#020617] border border-[#1e293b] rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-5 h-5 text-[#22d3ee]" />
                <h4 className="font-medium text-white">Self-Scouting Focus</h4>
              </div>
              <p className="text-xs text-gray-400">
                While competitors focus on expert picks and odds comparison, we help you discover YOUR profitable patterns through historical analysis.
              </p>
            </div>

            <div className="bg-[#020617] border border-[#1e293b] rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Share2 className="w-5 h-5 text-[#22d3ee]" />
                <h4 className="font-medium text-white">AI SEO Integration</h4>
              </div>
              <p className="text-xs text-gray-400">
                First betting analytics tool with AI-powered SEO, dynamic meta tags, and shareable insights optimized for social media.
              </p>
            </div>

            <div className="bg-[#020617] border border-[#1e293b] rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <MapPin className="w-5 h-5 text-[#22d3ee]" />
                <h4 className="font-medium text-white">Legal Compliance</h4>
              </div>
              <p className="text-xs text-gray-400">
                Built-in geofencing with legal jurisdiction verification and VPN detection - ensuring compliance with local regulations.
              </p>
            </div>
          </div>

          {/* Bottom Line */}
          <div className="bg-[#020617] border border-amber-700/50 rounded-lg p-4">
            <h4 className="font-medium text-amber-100 mb-2">The Bottom Line</h4>
            <p className="text-sm text-amber-200/80">
              <strong>Action Network, VegasInsider, BetQL, and BettingPros</strong> are excellent for finding bets and comparing odds. But <strong>none of them help you understand which bets YOU should actually be making</strong> based on your historical performance.
            </p>
            <p className="text-sm text-amber-200/80 mt-2">
              We're the <strong>only tool</strong> that combines self-scouting trend analysis, odds range heatmaps, line range performance tracking, AI-powered SEO, and legal geofencing in one platform.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
