"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, TrendingUp, TrendingDown, Target, AlertTriangle } from "lucide-react";
import type { FuturesBet } from "@/lib/ai-picks-types";

export function FuturesTracker() {
  const [futures, setFutures] = useState<FuturesBet[]>([]);
  const [showForm, setShowForm] = useState<boolean>(false);
  const [newFuture, setNewFuture] = useState({
    sport: "",
    league: "",
    betType: "championship" as const,
    description: "",
    selection: "",
    oddsAtPlacement: 0,
    currentOdds: 0,
    stake: 0,
  });

  const addFuture = (): void => {
    if (!newFuture.selection || !newFuture.stake) return;

    const future: FuturesBet = {
      id: `future-${Date.now()}`,
      betId: `bet-${Date.now()}`,
      sport: newFuture.sport,
      league: newFuture.league,
      betType: newFuture.betType,
      description: newFuture.description,
      selection: newFuture.selection,
      placedAt: Date.now(),
      oddsAtPlacement: newFuture.oddsAtPlacement,
      currentOdds: newFuture.currentOdds,
      stake: newFuture.stake,
      potentialPayout:
        newFuture.oddsAtPlacement > 0
          ? newFuture.stake * (newFuture.oddsAtPlacement / 100 + 1)
          : newFuture.stake * (100 / Math.abs(newFuture.oddsAtPlacement) + 1),
      status: "active",
    };

    setFutures([...futures, future]);
    setNewFuture({
      sport: "",
      league: "",
      betType: "championship",
      description: "",
      selection: "",
      oddsAtPlacement: 0,
      currentOdds: 0,
      stake: 0,
    });
    setShowForm(false);
  };

  const activeFutures = futures.filter((f) => f.status === "active");
  const totalStaked = activeFutures.reduce((sum, f) => sum + f.stake, 0);
  const totalPotentialPayout = activeFutures.reduce((sum, f) => sum + f.potentialPayout, 0);

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-[#e5e7eb] flex items-center gap-2">
              <Target className="w-5 h-5 text-[#22d3ee]" />
              Futures Tracker
            </CardTitle>
            <CardDescription className="text-[#9ca3af]">Track long-term bets</CardDescription>
          </div>
          <Button
            onClick={() => setShowForm(!showForm)}
            size="sm"
            className="bg-[#22d3ee] hover:bg-[#22d3ee]/90 text-[#020617]"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Future
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Add form */}
        {showForm && (
          <div className="p-4 bg-[#020617] rounded-lg border border-[#1e293b] space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-[#e5e7eb]">Sport</Label>
                <Input
                  placeholder="NFL"
                  value={newFuture.sport}
                  onChange={(e) => setNewFuture({ ...newFuture, sport: e.target.value })}
                  className="bg-[#0b1120] border-[#1e293b] text-[#e5e7eb] mt-1"
                />
              </div>
              <div>
                <Label className="text-[#e5e7eb]">League</Label>
                <Input
                  placeholder="AFC"
                  value={newFuture.league}
                  onChange={(e) => setNewFuture({ ...newFuture, league: e.target.value })}
                  className="bg-[#0b1120] border-[#1e293b] text-[#e5e7eb] mt-1"
                />
              </div>
            </div>

            <div>
              <Label className="text-[#e5e7eb]">Bet Type</Label>
              <Select
                value={newFuture.betType}
                onValueChange={(value) =>
                  setNewFuture({
                    ...newFuture,
                    betType: value as FuturesBet["betType"],
                  })
                }
              >
                <SelectTrigger className="bg-[#0b1120] border-[#1e293b] text-[#e5e7eb] mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="championship">Championship</SelectItem>
                  <SelectItem value="playoff">Playoff</SelectItem>
                  <SelectItem value="award">Award</SelectItem>
                  <SelectItem value="season_wins">Season Wins</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-[#e5e7eb]">Description</Label>
              <Input
                placeholder="2025 Super Bowl Winner"
                value={newFuture.description}
                onChange={(e) => setNewFuture({ ...newFuture, description: e.target.value })}
                className="bg-[#0b1120] border-[#1e293b] text-[#e5e7eb] mt-1"
              />
            </div>

            <div>
              <Label className="text-[#e5e7eb]">Selection</Label>
              <Input
                placeholder="Kansas City Chiefs"
                value={newFuture.selection}
                onChange={(e) => setNewFuture({ ...newFuture, selection: e.target.value })}
                className="bg-[#0b1120] border-[#1e293b] text-[#e5e7eb] mt-1"
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label className="text-[#e5e7eb]">Odds at Placement</Label>
                <Input
                  type="number"
                  placeholder="+500"
                  value={newFuture.oddsAtPlacement}
                  onChange={(e) =>
                    setNewFuture({
                      ...newFuture,
                      oddsAtPlacement: parseFloat(e.target.value) || 0,
                    })
                  }
                  className="bg-[#0b1120] border-[#1e293b] text-[#e5e7eb] mt-1"
                />
              </div>
              <div>
                <Label className="text-[#e5e7eb]">Current Odds</Label>
                <Input
                  type="number"
                  placeholder="+300"
                  value={newFuture.currentOdds}
                  onChange={(e) =>
                    setNewFuture({ ...newFuture, currentOdds: parseFloat(e.target.value) || 0 })
                  }
                  className="bg-[#0b1120] border-[#1e293b] text-[#e5e7eb] mt-1"
                />
              </div>
              <div>
                <Label className="text-[#e5e7eb]">Stake ($)</Label>
                <Input
                  type="number"
                  placeholder="100"
                  value={newFuture.stake}
                  onChange={(e) =>
                    setNewFuture({ ...newFuture, stake: parseFloat(e.target.value) || 0 })
                  }
                  className="bg-[#0b1120] border-[#1e293b] text-[#e5e7eb] mt-1"
                />
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={addFuture}
                className="flex-1 bg-[#22d3ee] hover:bg-[#22d3ee]/90 text-[#020617]"
              >
                Add Future Bet
              </Button>
              <Button
                onClick={() => setShowForm(false)}
                variant="outline"
                className="border-[#1e293b]"
              >
                Cancel
              </Button>
            </div>
          </div>
        )}

        {/* Summary */}
        {activeFutures.length > 0 && (
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 bg-[#020617] rounded-lg border border-[#1e293b]">
              <div className="text-xs text-[#9ca3af] mb-1">Active Futures</div>
              <div className="text-2xl font-bold text-[#e5e7eb]">{activeFutures.length}</div>
            </div>
            <div className="p-3 bg-[#020617] rounded-lg border border-[#1e293b]">
              <div className="text-xs text-[#9ca3af] mb-1">Total Staked</div>
              <div className="text-2xl font-bold text-[#e5e7eb]">${totalStaked.toFixed(2)}</div>
            </div>
            <div className="p-3 bg-[#020617] rounded-lg border border-[#1e293b]">
              <div className="text-xs text-[#9ca3af] mb-1">Potential Payout</div>
              <div className="text-2xl font-bold text-[#22d3ee]">
                ${totalPotentialPayout.toFixed(2)}
              </div>
            </div>
          </div>
        )}

        {/* Futures list */}
        {futures.length > 0 ? (
          <div className="space-y-2">
            {futures.map((future) => {
              const oddsChange = future.currentOdds - future.oddsAtPlacement;
              const trending = oddsChange < 0 ? "improving" : oddsChange > 0 ? "worsening" : "stable";

              return (
                <div key={future.id} className="p-4 bg-[#020617] rounded-lg border border-[#1e293b]">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <div className="font-medium text-[#e5e7eb]">{future.description}</div>
                      <div className="text-sm text-[#9ca3af]">
                        {future.sport} • {future.league}
                      </div>
                      <div className="text-lg font-bold text-[#22d3ee] mt-1">{future.selection}</div>
                    </div>
                    <Badge
                      variant="outline"
                      className={
                        future.status === "active"
                          ? "bg-[#22d3ee]/10 text-[#22d3ee] border-[#22d3ee]/30"
                          : "bg-[#9ca3af]/10 text-[#9ca3af] border-[#9ca3af]/30"
                      }
                    >
                      {future.status.toUpperCase()}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-4 gap-3">
                    <div className="p-2 bg-[#0b1120] rounded border border-[#1e293b]">
                      <div className="text-xs text-[#9ca3af]">Placed @</div>
                      <div className="text-sm font-medium text-[#e5e7eb]">
                        {future.oddsAtPlacement > 0 ? "+" : ""}
                        {future.oddsAtPlacement}
                      </div>
                    </div>
                    <div className="p-2 bg-[#0b1120] rounded border border-[#1e293b]">
                      <div className="text-xs text-[#9ca3af]">Current</div>
                      <div className="text-sm font-medium text-[#22d3ee] flex items-center gap-1">
                        {future.currentOdds > 0 ? "+" : ""}
                        {future.currentOdds}
                        {trending === "improving" && <TrendingDown className="w-3 h-3 text-[#22c55e]" />}
                        {trending === "worsening" && <TrendingUp className="w-3 h-3 text-[#ef4444]" />}
                      </div>
                    </div>
                    <div className="p-2 bg-[#0b1120] rounded border border-[#1e293b]">
                      <div className="text-xs text-[#9ca3af]">Stake</div>
                      <div className="text-sm font-medium text-[#e5e7eb]">${future.stake}</div>
                    </div>
                    <div className="p-2 bg-[#0b1120] rounded border border-[#1e293b]">
                      <div className="text-xs text-[#9ca3af]">To Win</div>
                      <div className="text-sm font-medium text-[#22c55e]">
                        ${future.potentialPayout.toFixed(2)}
                      </div>
                    </div>
                  </div>

                  {trending === "improving" && (
                    <div className="mt-2 flex items-start gap-2 p-2 bg-[#22c55e]/10 border border-[#22c55e]/30 rounded">
                      <TrendingUp className="w-3 h-3 text-[#22c55e] mt-0.5" />
                      <p className="text-xs text-[#22c55e]">
                        Odds improved by {Math.abs(oddsChange)} - your position is strengthening
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-8 text-[#9ca3af]">
            <Target className="w-12 h-12 mx-auto mb-3 text-[#6b7280]" />
            <p>No futures bets tracked yet</p>
            <p className="text-sm text-[#6b7280] mt-1">Add your first future bet to get started</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
