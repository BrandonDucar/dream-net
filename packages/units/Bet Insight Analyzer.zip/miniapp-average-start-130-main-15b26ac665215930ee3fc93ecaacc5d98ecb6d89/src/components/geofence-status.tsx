'use client'
import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, AlertTriangle, Shield, RefreshCw, Info } from "lucide-react";
import {
  getUserLocation,
  formatLocation,
  getJurisdictionWarning,
  detectVPN,
  storeLocation,
  getStoredLocation,
  isLocationStale,
  getLegalStates,
  type LocationData,
  type GeofenceStatus
} from "@/lib/geofencing";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export function GeofenceStatus() {
  const [status, setStatus] = useState<GeofenceStatus>({
    isEnabled: false,
    location: null,
    error: null,
    isLoading: false
  });
  const [vpnWarning, setVpnWarning] = useState<string | null>(null);

  // Check for stored location on mount
  useEffect(() => {
    const stored = getStoredLocation();
    if (stored) {
      setStatus({
        isEnabled: true,
        location: stored,
        error: null,
        isLoading: false
      });
      
      const vpnCheck = detectVPN(stored);
      if (vpnCheck.suspected) {
        setVpnWarning(vpnCheck.reason);
      }
    }
  }, []);

  const handleEnableLocation = async (): Promise<void> => {
    setStatus(prev => ({ ...prev, isLoading: true, error: null }));
    setVpnWarning(null);

    try {
      const location = await getUserLocation();
      
      // Check for VPN/proxy
      const vpnCheck = detectVPN(location);
      if (vpnCheck.suspected) {
        setVpnWarning(vpnCheck.reason);
      }
      
      // Store location
      storeLocation(location);
      
      setStatus({
        isEnabled: true,
        location,
        error: null,
        isLoading: false
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      setStatus({
        isEnabled: false,
        location: null,
        error: errorMessage,
        isLoading: false
      });
    }
  };

  const handleRefreshLocation = async (): Promise<void> => {
    await handleEnableLocation();
  };

  const jurisdictionWarning = getJurisdictionWarning(status.location);
  const needsRefresh = status.location && isLocationStale(status.location);

  if (!status.isEnabled && !status.error) {
    return (
      <Card className="bg-gradient-to-r from-amber-900/20 to-orange-900/20 border-amber-700/50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <MapPin className="w-5 h-5 text-amber-400 mt-0.5 flex-shrink-0" />
            <div className="flex-1 space-y-2">
              <div>
                <h3 className="font-medium text-amber-100">Location Verification</h3>
                <p className="text-sm text-amber-200/80 mt-1">
                  Enable location services to verify you're in a legal sports betting jurisdiction.
                </p>
              </div>
              <Button
                onClick={handleEnableLocation}
                disabled={status.isLoading}
                size="sm"
                className="bg-amber-600 hover:bg-amber-700 text-white"
              >
                {status.isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Detecting Location...
                  </>
                ) : (
                  <>
                    <MapPin className="w-4 h-4 mr-2" />
                    Enable Location
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (status.error) {
    return (
      <Card className="bg-red-900/20 border-red-700/50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
            <div className="flex-1 space-y-2">
              <div>
                <h3 className="font-medium text-red-100">Location Error</h3>
                <p className="text-sm text-red-200/80 mt-1">{status.error}</p>
              </div>
              <Button
                onClick={handleEnableLocation}
                disabled={status.isLoading}
                size="sm"
                variant="outline"
                className="border-red-700 text-red-100 hover:bg-red-900/40"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Retry
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const location = status.location;
  if (!location) return null;

  return (
    <div className="space-y-3">
      {/* Main location status */}
      <Card className={`${
        location.isLegalJurisdiction 
          ? "bg-green-900/20 border-green-700/50" 
          : "bg-red-900/20 border-red-700/50"
      }`}>
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            {location.isLegalJurisdiction ? (
              <Shield className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
            )}
            <div className="flex-1">
              <div className="flex items-center justify-between gap-2">
                <h3 className={`font-medium ${
                  location.isLegalJurisdiction ? "text-green-100" : "text-red-100"
                }`}>
                  {location.isLegalJurisdiction ? "Verified Location" : "Location Restricted"}
                </h3>
                <div className="flex items-center gap-2">
                  {needsRefresh && (
                    <span className="text-xs text-amber-400">Refresh recommended</span>
                  )}
                  <Button
                    onClick={handleRefreshLocation}
                    disabled={status.isLoading}
                    size="sm"
                    variant="ghost"
                    className="h-7 px-2"
                  >
                    <RefreshCw className={`w-3 h-3 ${status.isLoading ? 'animate-spin' : ''}`} />
                  </Button>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 px-2"
                      >
                        <Info className="w-3 h-3" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-[#0b1120] border-[#1e293b] text-white max-w-2xl">
                      <DialogHeader>
                        <DialogTitle className="text-[#22d3ee]">Legal Betting Jurisdictions</DialogTitle>
                        <DialogDescription className="text-gray-400">
                          Sports betting is legal in the following US states and territories:
                        </DialogDescription>
                      </DialogHeader>
                      <div className="max-h-96 overflow-y-auto">
                        <div className="grid grid-cols-2 gap-2 text-sm text-gray-300">
                          {getLegalStates().map(state => (
                            <div key={state} className="flex items-center gap-2">
                              <Shield className="w-3 h-3 text-green-400 flex-shrink-0" />
                              <span>{state}</span>
                            </div>
                          ))}
                        </div>
                        <p className="text-xs text-gray-400 mt-4">
                          Note: This list is current as of 2024. Laws change frequently. Always check your local regulations.
                        </p>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
              <p className={`text-sm mt-1 ${
                location.isLegalJurisdiction ? "text-green-200/80" : "text-red-200/80"
              }`}>
                {location.isLegalJurisdiction ? (
                  <>
                    You are in <strong>{formatLocation(location)}</strong>, where sports betting is legal.
                  </>
                ) : (
                  jurisdictionWarning
                )}
              </p>
              {location.isLegalJurisdiction && (
                <p className="text-xs text-green-300/60 mt-2">
                  This app is compliant with your jurisdiction's sports betting regulations.
                </p>
              )}
              {!location.isLegalJurisdiction && (
                <p className="text-xs text-red-300/60 mt-2">
                  For educational and entertainment purposes only. No real money wagering.
                </p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* VPN warning */}
      {vpnWarning && (
        <Card className="bg-yellow-900/20 border-yellow-700/50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-yellow-400 mt-0.5 flex-shrink-0" />
              <div className="flex-1">
                <h3 className="font-medium text-yellow-100">VPN/Proxy Detected</h3>
                <p className="text-sm text-yellow-200/80 mt-1">{vpnWarning}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
