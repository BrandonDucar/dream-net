"use client";

import type { LoggedBet, OddsBucketStats, SportBetTypeStats } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, AlertCircle } from "lucide-react";

interface InsightsPanelProps {
  bets: LoggedBet[];
  oddsBuckets: OddsBucketStats[];
  sportBetTypeStats: SportBetTypeStats[];
}

export function InsightsPanel({ bets, oddsBuckets, sportBetTypeStats }: InsightsPanelProps) {
  if (bets.length === 0) {
    return null;
  }

  const totalStake = bets.reduce((acc, b) => acc + b.stake, 0);
  const totalProfitLoss = bets.reduce((acc, b) => acc + b.profitLoss, 0);
  const overallROI = totalStake > 0 ? (totalProfitLoss / totalStake) * 100 : 0;

  const bestSportBetType = [...sportBetTypeStats]
    .filter(s => s.bets >= 10)
    .sort((a, b) => b.roiPct - a.roiPct)[0];

  const worstSportBetType = [...sportBetTypeStats]
    .filter(s => s.bets >= 10)
    .sort((a, b) => a.roiPct - b.roiPct)[0];

  const bestOddsBucket = [...oddsBuckets]
    .filter(b => b.bets >= 10)
    .sort((a, b) => b.roiPct - a.roiPct)[0];

  const worstOddsBucket = [...oddsBuckets]
    .filter(b => b.bets >= 10)
    .sort((a, b) => a.roiPct - b.roiPct)[0];

  const insights: Array<{
    type: "strength" | "weakness" | "neutral";
    message: string;
  }> = [];

  if (bestSportBetType && bestSportBetType.roiPct > 5) {
    insights.push({
      type: "strength",
      message: `You're strongest on ${bestSportBetType.sport} ${bestSportBetType.betType}s with a ${bestSportBetType.roiPct >= 0 ? '+' : ''}${bestSportBetType.roiPct.toFixed(1)}% ROI over ${bestSportBetType.bets} bets.`
    });
  }

  if (worstSportBetType && worstSportBetType.roiPct < -5) {
    insights.push({
      type: "weakness",
      message: `You're leaking on ${worstSportBetType.sport} ${worstSportBetType.betType}s with a ${worstSportBetType.roiPct.toFixed(1)}% ROI. Consider avoiding this combination.`
    });
  }

  if (bestOddsBucket && bestOddsBucket.roiPct > 5) {
    insights.push({
      type: "strength",
      message: `Your best odds zone is ${bestOddsBucket.label.toLowerCase()} (${bestOddsBucket.roiPct >= 0 ? '+' : ''}${bestOddsBucket.roiPct.toFixed(1)}% ROI); consider focusing there.`
    });
  }

  if (worstOddsBucket && worstOddsBucket.roiPct < -5) {
    insights.push({
      type: "weakness",
      message: `You're struggling with ${worstOddsBucket.label.toLowerCase()} (${worstOddsBucket.roiPct.toFixed(1)}% ROI). This might be a leak in your strategy.`
    });
  }

  if (overallROI > 5) {
    insights.push({
      type: "strength",
      message: `Strong overall performance with ${overallROI >= 0 ? '+' : ''}${overallROI.toFixed(1)}% ROI across ${bets.length} bets.`
    });
  } else if (overallROI < -5) {
    insights.push({
      type: "weakness",
      message: `Currently down ${overallROI.toFixed(1)}% ROI. Review your weakest categories to plug leaks.`
    });
  }

  if (insights.length === 0) {
    insights.push({
      type: "neutral",
      message: "Not enough data yet for meaningful insights. Keep logging bets to identify your edge."
    });
  }

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-[#22d3ee] text-xl">Key Insights</CardTitle>
        <p className="text-sm text-gray-400">AI-powered analysis of your betting performance</p>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {insights.map((insight, index) => (
            <div
              key={index}
              className="flex items-start gap-3 p-3 rounded-lg bg-gray-900/30"
            >
              {insight.type === "strength" && (
                <TrendingUp className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
              )}
              {insight.type === "weakness" && (
                <TrendingDown className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              )}
              {insight.type === "neutral" && (
                <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
              )}
              <p className="text-sm text-gray-200 leading-relaxed">{insight.message}</p>
            </div>
          ))}
        </div>

        <div className="mt-6 pt-6 border-t border-[#1e293b]">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-white">{bets.length}</div>
              <div className="text-xs text-gray-400 mt-1">Total Bets</div>
            </div>
            <div>
              <div className={`text-2xl font-bold ${totalProfitLoss >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {totalProfitLoss >= 0 ? '+' : ''}{totalProfitLoss.toFixed(2)}
              </div>
              <div className="text-xs text-gray-400 mt-1">Total P&L</div>
            </div>
            <div>
              <div className={`text-2xl font-bold ${overallROI >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {overallROI >= 0 ? '+' : ''}{overallROI.toFixed(1)}%
              </div>
              <div className="text-xs text-gray-400 mt-1">Overall ROI</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
