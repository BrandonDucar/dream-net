"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Calculator, TrendingUp, AlertTriangle } from "lucide-react";
import { calculateKelly } from "@/lib/ai-picks";

export function KellyCalculator() {
  const [winProbability, setWinProbability] = useState<number>(55);
  const [odds, setOdds] = useState<number>(-110);
  const [bankroll, setBankroll] = useState<number>(1000);

  const kelly = calculateKelly(winProbability, odds, bankroll, true);

  const getRiskColor = (risk: string): string => {
    switch (risk) {
      case "conservative":
        return "bg-[#22c55e]/10 text-[#22c55e] border-[#22c55e]/30";
      case "moderate":
        return "bg-[#fbbf24]/10 text-[#fbbf24] border-[#fbbf24]/30";
      case "aggressive":
        return "bg-[#ef4444]/10 text-[#ef4444] border-[#ef4444]/30";
      default:
        return "bg-[#9ca3af]/10 text-[#9ca3af] border-[#9ca3af]/30";
    }
  };

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-[#e5e7eb] flex items-center gap-2">
          <Calculator className="w-5 h-5 text-[#22d3ee]" />
          Kelly Criterion Calculator
        </CardTitle>
        <CardDescription className="text-[#9ca3af]">
          Optimal bet sizing for long-term growth
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Inputs */}
        <div className="space-y-3">
          <div>
            <Label className="text-[#e5e7eb]">Your Win Probability (%)</Label>
            <Input
              type="number"
              min="0"
              max="100"
              value={winProbability}
              onChange={(e) => setWinProbability(parseFloat(e.target.value) || 0)}
              className="bg-[#020617] border-[#1e293b] text-[#e5e7eb] mt-1"
            />
            <p className="text-xs text-[#6b7280] mt-1">
              Your estimated probability that this bet wins
            </p>
          </div>

          <div>
            <Label className="text-[#e5e7eb]">Bookmaker Odds (American)</Label>
            <Input
              type="number"
              value={odds}
              onChange={(e) => setOdds(parseFloat(e.target.value) || 0)}
              className="bg-[#020617] border-[#1e293b] text-[#e5e7eb] mt-1"
            />
            <p className="text-xs text-[#6b7280] mt-1">
              The odds offered by the bookmaker
            </p>
          </div>

          <div>
            <Label className="text-[#e5e7eb]">Total Bankroll ($)</Label>
            <Input
              type="number"
              min="0"
              value={bankroll}
              onChange={(e) => setBankroll(parseFloat(e.target.value) || 0)}
              className="bg-[#020617] border-[#1e293b] text-[#e5e7eb] mt-1"
            />
            <p className="text-xs text-[#6b7280] mt-1">
              Your total betting bankroll
            </p>
          </div>
        </div>

        {/* Results */}
        <div className="p-4 bg-[#020617] rounded-lg border border-[#1e293b] space-y-3">
          <div className="flex items-center justify-between">
            <div className="font-medium text-[#e5e7eb]">Kelly Analysis</div>
            <Badge variant="outline" className={getRiskColor(kelly.riskLevel)}>
              {kelly.riskLevel.toUpperCase()}
            </Badge>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-[#0b1120] rounded border border-[#1e293b]">
              <div className="text-xs text-[#9ca3af] mb-1">Fractional Kelly (¼)</div>
              <div className="text-2xl font-bold text-[#22d3ee]">
                ${kelly.fractionalKellyStake.toFixed(2)}
              </div>
              <div className="text-xs text-[#22c55e] mt-1">Recommended</div>
            </div>
            <div className="p-3 bg-[#0b1120] rounded border border-[#1e293b]">
              <div className="text-xs text-[#9ca3af] mb-1">Full Kelly</div>
              <div className="text-2xl font-bold text-[#fbbf24]">
                ${kelly.fullKellyStake.toFixed(2)}
              </div>
              <div className="text-xs text-[#ef4444] mt-1">Higher variance</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-[#0b1120] rounded border border-[#1e293b]">
              <div className="text-xs text-[#9ca3af] mb-1">Kelly %</div>
              <div className="text-xl font-bold text-[#e5e7eb]">
                {(kelly.kellyFraction * 100).toFixed(2)}%
              </div>
            </div>
            <div className="p-3 bg-[#0b1120] rounded border border-[#1e293b]">
              <div className="text-xs text-[#9ca3af] mb-1">Expected Value</div>
              <div
                className={`text-xl font-bold ${
                  kelly.expectedValue > 0 ? "text-[#22c55e]" : "text-[#ef4444]"
                }`}
              >
                {kelly.expectedValue > 0 ? "+" : ""}
                {kelly.expectedValue.toFixed(2)}%
              </div>
            </div>
          </div>

          {/* Recommendations */}
          {kelly.expectedValue <= 0 && (
            <div className="flex items-start gap-2 p-3 bg-[#ef4444]/10 border border-[#ef4444]/30 rounded">
              <AlertTriangle className="w-4 h-4 text-[#ef4444] mt-0.5 flex-shrink-0" />
              <div className="text-xs text-[#ef4444]">
                <div className="font-medium mb-1">No Kelly bet recommended</div>
                <div>
                  Your win probability ({winProbability}%) doesn't exceed the break-even point for
                  these odds. This bet has negative expected value.
                </div>
              </div>
            </div>
          )}

          {kelly.expectedValue > 0 && kelly.kellyFraction > 0.15 && (
            <div className="flex items-start gap-2 p-3 bg-[#fbbf24]/10 border border-[#fbbf24]/30 rounded">
              <AlertTriangle className="w-4 h-4 text-[#fbbf24] mt-0.5 flex-shrink-0" />
              <div className="text-xs text-[#fbbf24]">
                <div className="font-medium mb-1">High variance warning</div>
                <div>
                  Kelly suggests betting {(kelly.kellyFraction * 100).toFixed(1)}% of bankroll.
                  Using fractional Kelly (¼) reduces variance while maintaining good growth.
                </div>
              </div>
            </div>
          )}

          {kelly.expectedValue > 0 && kelly.expectedValue < 5 && (
            <div className="flex items-start gap-2 p-3 bg-[#22d3ee]/10 border border-[#22d3ee]/30 rounded">
              <TrendingUp className="w-4 h-4 text-[#22d3ee] mt-0.5 flex-shrink-0" />
              <div className="text-xs text-[#22d3ee]">
                <div className="font-medium mb-1">Small edge detected</div>
                <div>
                  This bet has a small positive edge ({kelly.expectedValue.toFixed(2)}%). Consider
                  if the effort is worth it compared to other opportunities.
                </div>
              </div>
            </div>
          )}

          {kelly.expectedValue >= 5 && (
            <div className="flex items-start gap-2 p-3 bg-[#22c55e]/10 border border-[#22c55e]/30 rounded">
              <TrendingUp className="w-4 h-4 text-[#22c55e] mt-0.5 flex-shrink-0" />
              <div className="text-xs text-[#22c55e]">
                <div className="font-medium mb-1">Strong edge!</div>
                <div>
                  This bet has solid positive expected value ({kelly.expectedValue.toFixed(2)}%).
                  The fractional Kelly stake of ${kelly.fractionalKellyStake.toFixed(2)} balances
                  growth with risk management.
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="text-xs text-[#6b7280] p-3 bg-[#020617] rounded border border-[#1e293b]">
          <div className="font-medium text-[#9ca3af] mb-2">About Kelly Criterion:</div>
          <ul className="space-y-1 list-disc list-inside">
            <li>Maximizes long-term bankroll growth</li>
            <li>Fractional Kelly (¼) reduces variance</li>
            <li>Only bet when you have an edge (positive EV)</li>
            <li>Adjust stake as bankroll changes</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
