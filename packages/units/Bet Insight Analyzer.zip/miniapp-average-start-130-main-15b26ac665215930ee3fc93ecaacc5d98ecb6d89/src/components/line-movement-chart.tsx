"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Activity } from "lucide-react";
import type { LineMovement } from "@/lib/odds-api-types";

interface LineMovementChartProps {
  movements: LineMovement[];
}

export function LineMovementChart({ movements }: LineMovementChartProps) {
  if (movements.length === 0) {
    return (
      <Card className="bg-[#0b1120] border-[#1e293b]">
        <CardHeader>
          <CardTitle className="text-[#e5e7eb] flex items-center gap-2">
            <Activity className="w-5 h-5 text-[#22d3ee]" />
            Line Movement Tracker
          </CardTitle>
          <CardDescription className="text-[#9ca3af]">
            Historical odds changes across bookmakers
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Activity className="w-12 h-12 text-[#9ca3af] mx-auto mb-3" />
            <p className="text-[#9ca3af]">No line movements to display</p>
            <p className="text-sm text-[#6b7280] mt-2">
              Line movements will appear here as odds change
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-[#e5e7eb] flex items-center gap-2">
              <Activity className="w-5 h-5 text-[#22d3ee]" />
              Line Movement Tracker
            </CardTitle>
            <CardDescription className="text-[#9ca3af]">
              {movements.length} game{movements.length !== 1 ? "s" : ""} with line movements
            </CardDescription>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <div className="space-y-3">
          {movements.map((movement) => {
            const totalMovements = movement.movements.length;
            const recentMovements = movement.movements.slice(0, 5);
            const upMovements = movement.movements.filter((m) => m.direction === "up").length;
            const downMovements = movement.movements.filter((m) => m.direction === "down").length;

            return (
              <Card key={`${movement.eventId}-${movement.market}`} className="bg-[#020617] border-[#1e293b]">
                <CardContent className="pt-4">
                  <div className="space-y-3">
                    {/* Header */}
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="font-medium text-[#e5e7eb]">
                          {movement.awayTeam} @ {movement.homeTeam}
                        </div>
                        <div className="text-sm text-[#9ca3af]">
                          {movement.sport} • {movement.market === "h2h" ? "Moneyline" : movement.market === "spreads" ? "Spread" : "Total"}
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant="outline" className="bg-[#22d3ee]/10 text-[#22d3ee] border-[#22d3ee]/30">
                          {totalMovements} Movement{totalMovements !== 1 ? "s" : ""}
                        </Badge>
                        <div className="text-xs text-[#9ca3af] mt-1">
                          <span className="text-[#22c55e]">{upMovements}↑</span> /{" "}
                          <span className="text-[#ef4444]">{downMovements}↓</span>
                        </div>
                      </div>
                    </div>

                    {/* Recent movements */}
                    <div className="space-y-2">
                      <div className="text-xs font-medium text-[#9ca3af]">
                        Recent Movements (Last 5):
                      </div>
                      {recentMovements.map((move, idx) => {
                        const DirectionIcon = move.direction === "up" ? TrendingUp : TrendingDown;
                        const directionColor =
                          move.direction === "up" ? "text-[#22c55e]" : "text-[#ef4444]";

                        return (
                          <div
                            key={idx}
                            className="flex items-center justify-between p-2 bg-[#0b1120] rounded border border-[#1e293b]"
                          >
                            <div className="flex items-center gap-2">
                              <DirectionIcon className={`w-4 h-4 ${directionColor}`} />
                              <div>
                                <div className="text-sm text-[#e5e7eb]">{move.bookmaker}</div>
                                <div className="text-xs text-[#6b7280]">
                                  {new Date(move.timestamp).toLocaleString()}
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className={`text-sm font-medium ${directionColor}`}>
                                {move.oldValue > 0 ? "+" : ""}
                                {move.oldValue} → {move.newValue > 0 ? "+" : ""}
                                {move.newValue}
                              </div>
                              <div className="text-xs text-[#9ca3af]">
                                {Math.abs(move.newValue - move.oldValue).toFixed(1)} pts
                              </div>
                            </div>
                          </div>
                        );
                      })}

                      {totalMovements > 5 && (
                        <div className="text-xs text-center text-[#6b7280] pt-1">
                          +{totalMovements - 5} more movement{totalMovements - 5 !== 1 ? "s" : ""}
                        </div>
                      )}
                    </div>

                    {/* Trend indicator */}
                    {upMovements > downMovements * 2 && (
                      <div className="flex items-start gap-2 p-2 bg-[#22c55e]/10 border border-[#22c55e]/30 rounded">
                        <TrendingUp className="w-3 h-3 text-[#22c55e] mt-0.5" />
                        <p className="text-xs text-[#22c55e]">
                          Strong upward trend - line moving consistently higher
                        </p>
                      </div>
                    )}

                    {downMovements > upMovements * 2 && (
                      <div className="flex items-start gap-2 p-2 bg-[#ef4444]/10 border border-[#ef4444]/30 rounded">
                        <TrendingDown className="w-3 h-3 text-[#ef4444] mt-0.5" />
                        <p className="text-xs text-[#ef4444]">
                          Strong downward trend - line moving consistently lower
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
