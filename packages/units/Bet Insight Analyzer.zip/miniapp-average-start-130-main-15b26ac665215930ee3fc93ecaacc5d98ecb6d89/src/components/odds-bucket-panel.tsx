"use client";

import type { OddsBucketStats } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface OddsBucketPanelProps {
  buckets: OddsBucketStats[];
}

export function OddsBucketPanel({ buckets }: OddsBucketPanelProps) {
  if (buckets.length === 0) {
    return null;
  }

  const getColorClass = (roiPct: number): string => {
    if (roiPct > 10) return "text-green-400";
    if (roiPct > 3) return "text-green-500";
    if (roiPct > -3) return "text-yellow-400";
    if (roiPct > -10) return "text-red-400";
    return "text-red-500";
  };

  const getBarColor = (roiPct: number): string => {
    if (roiPct > 3) return "bg-green-500";
    if (roiPct > -3) return "bg-yellow-500";
    return "bg-red-500";
  };

  const sortedBuckets = [...buckets].sort((a, b) => {
    const order = ["short_fave", "med_fave", "coinflip", "small_dog", "longshot"];
    return order.indexOf(a.id) - order.indexOf(b.id);
  });

  const best = [...buckets].filter(b => b.bets >= 10).sort((a, b) => b.roiPct - a.roiPct)[0];
  const worst = [...buckets].filter(b => b.bets >= 10).sort((a, b) => a.roiPct - b.roiPct)[0];

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-[#22d3ee] text-xl">Odds Range Performance</CardTitle>
        <p className="text-sm text-gray-400">Your edge across different odds ranges</p>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {sortedBuckets.map(bucket => {
            const isBest = best && bucket.id === best.id;
            const isWorst = worst && bucket.id === worst.id;

            return (
              <div key={bucket.id} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-white">{bucket.label}</span>
                    {isBest && bucket.bets >= 10 && (
                      <Badge className="bg-green-500/20 text-green-400 text-xs">Best</Badge>
                    )}
                    {isWorst && bucket.bets >= 10 && (
                      <Badge className="bg-red-500/20 text-red-400 text-xs">Worst</Badge>
                    )}
                  </div>
                  <div className="text-sm text-gray-400">
                    {bucket.bets} bets
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-4 text-sm">
                  <div>
                    <div className="text-gray-400 text-xs">P&L</div>
                    <div className={bucket.profitLoss >= 0 ? "text-green-400" : "text-red-400"}>
                      {bucket.profitLoss >= 0 ? '+' : ''}{bucket.profitLoss.toFixed(2)}
                    </div>
                  </div>
                  <div>
                    <div className="text-gray-400 text-xs">ROI</div>
                    <div className={`font-bold ${getColorClass(bucket.roiPct)}`}>
                      {bucket.roiPct >= 0 ? '+' : ''}{bucket.roiPct.toFixed(1)}%
                    </div>
                  </div>
                  <div>
                    <div className="text-gray-400 text-xs">W-L-P</div>
                    <div className="text-white">
                      {bucket.wins}-{bucket.losses}-{bucket.pushes}
                    </div>
                  </div>
                  <div>
                    <div className="text-gray-400 text-xs">Win Rate</div>
                    <div className="text-white">
                      {bucket.wins + bucket.losses > 0
                        ? ((bucket.wins / (bucket.wins + bucket.losses)) * 100).toFixed(1)
                        : '0.0'}%
                    </div>
                  </div>
                </div>

                <div className="relative h-2 bg-gray-800 rounded overflow-hidden">
                  <div
                    className={`absolute left-0 top-0 h-full ${getBarColor(bucket.roiPct)} transition-all`}
                    style={{
                      width: `${Math.min(Math.max(Math.abs(bucket.roiPct), 0), 100)}%`
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
