"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, TrendingDown, AlertTriangle } from "lucide-react";
import type { OddsEvent, BestOdds } from "@/lib/odds-api-types";

interface OddsComparisonDashboardProps {
  events?: OddsEvent[];
  bestOdds?: BestOdds[];
}

export function OddsComparisonDashboard({ events, bestOdds }: OddsComparisonDashboardProps) {
  const [selectedSport, setSelectedSport] = useState<string>("all");

  const sports = Array.from(new Set(events.map((e) => e.sport_title)));
  const filteredEvents = selectedSport === "all" ? events : events.filter((e) => e.sport_title === selectedSport);

  return (
    <div className="space-y-4">
      <div className="flex gap-2 flex-wrap">
        <Button
          variant={selectedSport === "all" ? "default" : "outline"}
          onClick={() => setSelectedSport("all")}
          size="sm"
        >
          All Sports
        </Button>
        {sports.map((sport) => (
          <Button
            key={sport}
            variant={selectedSport === sport ? "default" : "outline"}
            onClick={() => setSelectedSport(sport)}
            size="sm"
          >
            {sport}
          </Button>
        ))}
      </div>

      <div className="space-y-3">
        {filteredEvents.map((event) => {
          const eventBestOdds = bestOdds.filter((bo) => bo.eventId === event.id);
          const h2hOdds = eventBestOdds.filter((bo) => bo.market === "h2h");

          return (
            <Card key={event.id} className="bg-[#0b1120] border-[#1e293b]">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg text-[#e5e7eb]">
                      {event.away_team} @ {event.home_team}
                    </CardTitle>
                    <CardDescription className="text-[#9ca3af]">
                      {event.sport_title} • {new Date(event.commence_time).toLocaleString()}
                    </CardDescription>
                  </div>
                  <Badge variant="outline" className="bg-[#22d3ee]/10 text-[#22d3ee] border-[#22d3ee]/30">
                    {event.bookmakers.length} Books
                  </Badge>
                </div>
              </CardHeader>

              <CardContent>
                <div className="space-y-3">
                  {/* Moneyline Odds */}
                  {h2hOdds.length > 0 && (
                    <div>
                      <div className="text-sm font-medium text-[#9ca3af] mb-2">Moneyline - Best Odds</div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {h2hOdds.map((odds) => (
                          <div
                            key={`${odds.outcome}-${odds.market}`}
                            className="flex justify-between items-center p-3 bg-[#020617] rounded-lg border border-[#1e293b]"
                          >
                            <div>
                              <div className="text-[#e5e7eb] font-medium">{odds.outcome}</div>
                              <div className="text-xs text-[#22d3ee]">{odds.bestBookmaker}</div>
                            </div>
                            <div className="text-right">
                              <div className="text-xl font-bold text-[#22d3ee]">
                                {odds.bestOdds > 0 ? "+" : ""}
                                {odds.bestOdds}
                              </div>
                              <div className="text-xs text-[#9ca3af]">
                                {odds.allBooks.length} books
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* All Bookmakers Comparison */}
                  <details className="group">
                    <summary className="text-sm text-[#22d3ee] cursor-pointer hover:text-[#67e8f9] flex items-center gap-2">
                      <span>View all bookmakers</span>
                      <TrendingDown className="w-4 h-4 group-open:rotate-180 transition-transform" />
                    </summary>
                    <div className="mt-3 space-y-2">
                      {event.bookmakers.map((bookmaker) => {
                        const h2h = bookmaker.markets.find((m) => m.key === "h2h");
                        const spreads = bookmaker.markets.find((m) => m.key === "spreads");
                        const totals = bookmaker.markets.find((m) => m.key === "totals");

                        return (
                          <div
                            key={bookmaker.key}
                            className="p-3 bg-[#020617] rounded border border-[#1e293b]"
                          >
                            <div className="font-medium text-[#e5e7eb] mb-2">{bookmaker.title}</div>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
                              {h2h && (
                                <div>
                                  <div className="text-[#9ca3af] mb-1">Moneyline</div>
                                  {h2h.outcomes.map((outcome) => (
                                    <div key={outcome.name} className="flex justify-between">
                                      <span className="text-[#e5e7eb]">{outcome.name}</span>
                                      <span className="text-[#22d3ee]">
                                        {outcome.price > 0 ? "+" : ""}
                                        {outcome.price}
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              )}
                              {spreads && (
                                <div>
                                  <div className="text-[#9ca3af] mb-1">Spread</div>
                                  {spreads.outcomes.map((outcome) => (
                                    <div key={outcome.name} className="flex justify-between">
                                      <span className="text-[#e5e7eb]">
                                        {outcome.name} {outcome.point != null ? `(${outcome.point > 0 ? "+" : ""}${outcome.point})` : ""}
                                      </span>
                                      <span className="text-[#22d3ee]">
                                        {outcome.price > 0 ? "+" : ""}
                                        {outcome.price}
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              )}
                              {totals && (
                                <div>
                                  <div className="text-[#9ca3af] mb-1">Total</div>
                                  {totals.outcomes.map((outcome) => (
                                    <div key={outcome.name} className="flex justify-between">
                                      <span className="text-[#e5e7eb]">
                                        {outcome.name} {outcome.point != null ? `(${outcome.point})` : ""}
                                      </span>
                                      <span className="text-[#22d3ee]">
                                        {outcome.price > 0 ? "+" : ""}
                                        {outcome.price}
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </details>
                </div>
              </CardContent>
            </Card>
          );
        })}

        {filteredEvents.length === 0 && (
          <Card className="bg-[#0b1120] border-[#1e293b]">
            <CardContent className="py-12 text-center">
              <AlertTriangle className="w-12 h-12 text-[#9ca3af] mx-auto mb-3" />
              <p className="text-[#9ca3af]">No events available for this sport</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
