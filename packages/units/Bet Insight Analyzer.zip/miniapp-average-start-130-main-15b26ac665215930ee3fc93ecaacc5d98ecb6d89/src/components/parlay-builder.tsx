"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, TrendingUp, AlertTriangle } from "lucide-react";
import { calculateParlayEV } from "@/lib/ai-picks";

interface ParlayLeg {
  id: string;
  selection: string;
  odds: number;
  winProbability: number;
}

export function ParlayBuilder() {
  const [legs, setLegs] = useState<ParlayLeg[]>([]);
  const [newLeg, setNewLeg] = useState({ selection: "", odds: -110, winProbability: 50 });

  const addLeg = (): void => {
    if (newLeg.selection.trim() === "") return;
    setLegs([
      ...legs,
      {
        id: `leg-${Date.now()}`,
        ...newLeg,
      },
    ]);
    setNewLeg({ selection: "", odds: -110, winProbability: 50 });
  };

  const removeLeg = (id: string): void => {
    setLegs(legs.filter((leg) => leg.id !== id));
  };

  const parlayCalc =
    legs.length >= 2
      ? calculateParlayEV(
          legs.map((leg) => ({ winProbability: leg.winProbability, odds: leg.odds }))
        )
      : null;

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-[#e5e7eb] flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-[#22d3ee]" />
          Parlay Builder
        </CardTitle>
        <CardDescription className="text-[#9ca3af]">
          Build parlays with EV calculations
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Add new leg */}
        <div className="p-4 bg-[#020617] rounded-lg border border-[#1e293b] space-y-3">
          <Label className="text-[#e5e7eb]">Add Leg</Label>
          <div className="space-y-2">
            <Input
              placeholder="Selection (e.g., Lakers ML)"
              value={newLeg.selection}
              onChange={(e) => setNewLeg({ ...newLeg, selection: e.target.value })}
              className="bg-[#0b1120] border-[#1e293b] text-[#e5e7eb]"
            />
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label className="text-xs text-[#9ca3af]">Odds (American)</Label>
                <Input
                  type="number"
                  placeholder="-110"
                  value={newLeg.odds}
                  onChange={(e) => setNewLeg({ ...newLeg, odds: parseFloat(e.target.value) || 0 })}
                  className="bg-[#0b1120] border-[#1e293b] text-[#e5e7eb]"
                />
              </div>
              <div>
                <Label className="text-xs text-[#9ca3af]">Your Win Prob. (%)</Label>
                <Input
                  type="number"
                  placeholder="50"
                  min="0"
                  max="100"
                  value={newLeg.winProbability}
                  onChange={(e) =>
                    setNewLeg({ ...newLeg, winProbability: parseFloat(e.target.value) || 0 })
                  }
                  className="bg-[#0b1120] border-[#1e293b] text-[#e5e7eb]"
                />
              </div>
            </div>
            <Button onClick={addLeg} className="w-full bg-[#22d3ee] hover:bg-[#22d3ee]/90 text-[#020617]">
              <Plus className="w-4 h-4 mr-2" />
              Add Leg
            </Button>
          </div>
        </div>

        {/* Current legs */}
        {legs.length > 0 && (
          <div className="space-y-2">
            <Label className="text-[#e5e7eb]">Parlay Legs ({legs.length})</Label>
            {legs.map((leg) => (
              <div
                key={leg.id}
                className="flex items-center justify-between p-3 bg-[#020617] rounded border border-[#1e293b]"
              >
                <div>
                  <div className="font-medium text-[#e5e7eb]">{leg.selection}</div>
                  <div className="text-sm text-[#9ca3af]">
                    {leg.odds > 0 ? "+" : ""}
                    {leg.odds} • {leg.winProbability}% win prob.
                  </div>
                </div>
                <Button
                  onClick={() => removeLeg(leg.id)}
                  variant="ghost"
                  size="sm"
                  className="text-[#ef4444] hover:text-[#ef4444] hover:bg-[#ef4444]/10"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        )}

        {/* Parlay calculation */}
        {parlayCalc && (
          <div className="p-4 bg-[#020617] rounded-lg border border-[#1e293b] space-y-3">
            <div className="font-medium text-[#e5e7eb]">Parlay Analysis</div>
            
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-[#0b1120] rounded border border-[#1e293b]">
                <div className="text-xs text-[#9ca3af] mb-1">Parlay Odds</div>
                <div className="text-2xl font-bold text-[#22d3ee]">
                  {parlayCalc.parlayOdds > 0 ? "+" : ""}
                  {parlayCalc.parlayOdds}
                </div>
              </div>
              <div className="p-3 bg-[#0b1120] rounded border border-[#1e293b]">
                <div className="text-xs text-[#9ca3af] mb-1">Combined Win Prob.</div>
                <div className="text-2xl font-bold text-[#e5e7eb]">
                  {parlayCalc.combinedProbability.toFixed(2)}%
                </div>
              </div>
              <div className="p-3 bg-[#0b1120] rounded border border-[#1e293b]">
                <div className="text-xs text-[#9ca3af] mb-1">Break-Even Prob.</div>
                <div className="text-2xl font-bold text-[#fbbf24]">
                  {parlayCalc.breakEvenProbability.toFixed(2)}%
                </div>
              </div>
              <div className="p-3 bg-[#0b1120] rounded border border-[#1e293b]">
                <div className="text-xs text-[#9ca3af] mb-1">Expected Value</div>
                <div
                  className={`text-2xl font-bold ${
                    parlayCalc.expectedValue > 0 ? "text-[#22c55e]" : "text-[#ef4444]"
                  }`}
                >
                  {parlayCalc.expectedValue > 0 ? "+" : ""}
                  {parlayCalc.expectedValue.toFixed(2)}%
                </div>
              </div>
            </div>

            {/* Recommendation */}
            {parlayCalc.expectedValue < 0 && (
              <div className="flex items-start gap-2 p-3 bg-[#ef4444]/10 border border-[#ef4444]/30 rounded">
                <AlertTriangle className="w-4 h-4 text-[#ef4444] mt-0.5 flex-shrink-0" />
                <p className="text-xs text-[#ef4444]">
                  Negative EV: This parlay is not profitable long-term based on your win probabilities.
                  Consider placing single bets instead.
                </p>
              </div>
            )}

            {parlayCalc.expectedValue > 0 && (
              <div className="flex items-start gap-2 p-3 bg-[#22c55e]/10 border border-[#22c55e]/30 rounded">
                <TrendingUp className="w-4 h-4 text-[#22c55e] mt-0.5 flex-shrink-0" />
                <p className="text-xs text-[#22c55e]">
                  Positive EV: This parlay has positive expected value based on your analysis!
                </p>
              </div>
            )}
          </div>
        )}

        {legs.length > 0 && legs.length < 2 && (
          <div className="text-center text-sm text-[#9ca3af]">
            Add at least 2 legs to calculate parlay odds
          </div>
        )}
      </CardContent>
    </Card>
  );
}
