"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Target, Brain, TrendingUp, AlertCircle } from "lucide-react";
import type { PropAnalysis } from "@/lib/ai-picks-types";

export function PropAnalyzer() {
  const [analyses, setAnalyses] = useState<PropAnalysis[]>([]);
  const [showForm, setShowForm] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [newPlayer, setNewPlayer] = useState<string>("");
  const [newPropType, setNewPropType] = useState<string>("");
  const [newLine, setNewLine] = useState<number>(25.5);
  const [newOverOdds, setNewOverOdds] = useState<number>(-110);
  const [newUnderOdds, setNewUnderOdds] = useState<number>(-110);

  const analyzeWithAI = async (): void => {
    setLoading(true);
    try {
      const response = await fetch('/api/props', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          player: newPlayer,
          propType: newPropType,
          line: newLine,
          overOdds: newOverOdds,
          underOdds: newUnderOdds,
          sport: 'NBA' // Default to NBA
        })
      });
      
      const data = await response.json();
      
      if (!data.success && !data.demo) {
        throw new Error(data.error || 'Failed to analyze prop');
      }
      
      const analysis: PropAnalysis = data.analysis;
      setAnalyses([analysis, ...analyses]);
      setShowForm(false);
      
      if (data.demo) {
        alert('Using AI demo analysis - live AI analysis available 24/7');
      }
    } catch (error) {
      console.error("Failed to analyze prop:", error);
      alert("Failed to analyze prop. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const getConfidenceColor = (confidence: string): string => {
    switch (confidence) {
      case "very_high":
        return "bg-[#22c55e]/10 text-[#22c55e] border-[#22c55e]/30";
      case "high":
        return "bg-[#3b82f6]/10 text-[#3b82f6] border-[#3b82f6]/30";
      case "medium":
        return "bg-[#fbbf24]/10 text-[#fbbf24] border-[#fbbf24]/30";
      case "low":
        return "bg-[#9ca3af]/10 text-[#9ca3af] border-[#9ca3af]/30";
      default:
        return "bg-[#9ca3af]/10 text-[#9ca3af] border-[#9ca3af]/30";
    }
  };

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-[#e5e7eb] flex items-center gap-2">
              <Target className="w-5 h-5 text-[#a855f7]" />
              Prop Analyzer
            </CardTitle>
            <CardDescription className="text-[#9ca3af]">
              AI-powered player prop analysis
            </CardDescription>
          </div>
          <Button
            onClick={() => setShowForm(!showForm)}
            size="sm"
            className="bg-[#a855f7] hover:bg-[#9333ea]"
          >
            <Brain className="w-4 h-4 mr-2" />
            Analyze Prop
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Analysis form */}
        {showForm && (
          <div className="p-4 bg-[#020617] rounded-lg border border-[#1e293b] space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-[#e5e7eb]">Player Name</Label>
                <Input
                  placeholder="LeBron James"
                  value={newPlayer}
                  onChange={(e) => setNewPlayer(e.target.value)}
                  className="bg-[#0b1120] border-[#1e293b] text-[#e5e7eb] mt-1"
                />
              </div>
              <div>
                <Label className="text-[#e5e7eb]">Prop Type</Label>
                <Input
                  placeholder="Points"
                  value={newPropType}
                  onChange={(e) => setNewPropType(e.target.value)}
                  className="bg-[#0b1120] border-[#1e293b] text-[#e5e7eb] mt-1"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label className="text-[#e5e7eb]">Line</Label>
                <Input
                  type="number"
                  placeholder="25.5"
                  value={newLine}
                  onChange={(e) => setNewLine(parseFloat(e.target.value) || 0)}
                  className="bg-[#0b1120] border-[#1e293b] text-[#e5e7eb] mt-1"
                />
              </div>
              <div>
                <Label className="text-[#e5e7eb]">Over Odds</Label>
                <Input
                  type="number"
                  placeholder="-110"
                  value={newOverOdds}
                  onChange={(e) => setNewOverOdds(parseFloat(e.target.value) || 0)}
                  className="bg-[#0b1120] border-[#1e293b] text-[#e5e7eb] mt-1"
                />
              </div>
              <div>
                <Label className="text-[#e5e7eb]">Under Odds</Label>
                <Input
                  type="number"
                  placeholder="-110"
                  value={newUnderOdds}
                  onChange={(e) => setNewUnderOdds(parseFloat(e.target.value) || 0)}
                  className="bg-[#0b1120] border-[#1e293b] text-[#e5e7eb] mt-1"
                />
              </div>
            </div>

            <Button
              onClick={analyzeWithAI}
              disabled={loading || !newPlayer.trim() || !newPropType.trim()}
              className="w-full bg-[#a855f7] hover:bg-[#9333ea]"
            >
              {loading ? "Analyzing with AI..." : "Analyze Prop"}
            </Button>
          </div>
        )}

        {/* Analyses list */}
        {analyses.length > 0 ? (
          <div className="space-y-3">
            {analyses.map((analysis) => (
              <Card key={analysis.id} className="bg-[#020617] border-[#1e293b]">
                <CardContent className="pt-4">
                  <div className="space-y-3">
                    {/* Header */}
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="font-bold text-lg text-[#e5e7eb]">{analysis.player}</div>
                        <div className="text-sm text-[#9ca3af]">
                          {analysis.sport} • {analysis.propType}
                        </div>
                      </div>
                      <Badge variant="outline" className={getConfidenceColor(analysis.confidence)}>
                        {analysis.confidence.replace("_", " ").toUpperCase()}
                      </Badge>
                    </div>

                    {/* Recommendation */}
                    <div className="p-3 bg-[#0b1120] rounded-lg border border-[#1e293b]">
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <div className="text-xs text-[#9ca3af] mb-1">Recommendation</div>
                          <div className="text-2xl font-bold text-[#a855f7] uppercase">
                            {analysis.recommendation}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-xs text-[#9ca3af]">Line</div>
                          <div className="text-2xl font-bold text-[#22d3ee]">{analysis.line}</div>
                        </div>
                      </div>
                      <div className="text-xs text-[#9ca3af]">
                        {analysis.recommendation === "over" ? "Over" : "Under"} {analysis.line}{" "}
                        {analysis.propType} @{" "}
                        {analysis.recommendation === "over"
                          ? analysis.overOdds > 0
                            ? "+"
                            : ""
                          : analysis.underOdds > 0
                          ? "+"
                          : ""}
                        {analysis.recommendation === "over" ? analysis.overOdds : analysis.underOdds}
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="grid grid-cols-3 gap-2">
                      <div className="p-2 bg-[#0b1120] rounded border border-[#1e293b]">
                        <div className="text-xs text-[#9ca3af] mb-1">Season Avg</div>
                        <div className="text-lg font-bold text-[#e5e7eb]">
                          {analysis.historicalAverage.toFixed(1)}
                        </div>
                      </div>
                      <div className="p-2 bg-[#0b1120] rounded border border-[#1e293b]">
                        <div className="text-xs text-[#9ca3af] mb-1">Recent Form</div>
                        <div className="text-lg font-bold text-[#22c55e]">
                          {analysis.recentForm.toFixed(1)}
                        </div>
                      </div>
                      <div className="p-2 bg-[#0b1120] rounded border border-[#1e293b]">
                        <div className="text-xs text-[#9ca3af] mb-1">Expected Value</div>
                        <div
                          className={`text-lg font-bold ${
                            analysis.expectedValue > 0 ? "text-[#22c55e]" : "text-[#ef4444]"
                          }`}
                        >
                          {analysis.expectedValue > 0 ? "+" : ""}
                          {analysis.expectedValue.toFixed(1)}%
                        </div>
                      </div>
                    </div>

                    {/* Reasoning */}
                    <div className="p-3 bg-[#0b1120] rounded border border-[#1e293b]">
                      <div className="text-xs font-medium text-[#9ca3af] mb-2">AI Analysis:</div>
                      <p className="text-sm text-[#e5e7eb] leading-relaxed">{analysis.reasoning}</p>
                    </div>

                    {/* Matchup advantage bar */}
                    <div>
                      <div className="text-xs text-[#9ca3af] mb-2">Matchup Advantage</div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-2 bg-[#1e293b] rounded-full overflow-hidden">
                          <div
                            className="h-full bg-[#a855f7] rounded-full"
                            style={{ width: `${(analysis.matchupAdvantage / 10) * 100}%` }}
                          />
                        </div>
                        <div className="text-sm font-medium text-[#e5e7eb] w-12 text-right">
                          {analysis.matchupAdvantage}/10
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <Target className="w-12 h-12 text-[#9ca3af] mx-auto mb-3" />
            <p className="text-[#9ca3af]">No prop analyses yet</p>
            <p className="text-sm text-[#6b7280] mt-2">
              Click "Analyze Prop" to get AI-powered prop bet recommendations
            </p>
          </div>
        )}

        <div className="flex items-start gap-2 p-3 bg-[#22c55e]/10 border border-[#22c55e]/30 rounded">
          <TrendingUp className="w-4 h-4 text-[#22c55e] mt-0.5 flex-shrink-0" />
          <p className="text-xs text-[#22c55e]">
            <span className="font-medium">AI-Powered:</span> Real-time prop analysis using OpenAI GPT-4o with 
            live player stats, recent form analysis, and matchup data. No setup required!
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
