'use client'
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Share2, Copy, CheckCircle, Code, MessageSquare } from "lucide-react";
import type { LoggedBet, OddsBucketStats, SportBetTypeStats } from "@/lib/types";
import {
  generateSEOMetadata,
  generateShareableInsight,
  generateMetaTagsHTML,
  generateShareableText,
  copyToClipboard
} from "@/lib/ai-seo";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface SEOSharePanelProps {
  bets: LoggedBet[];
  oddsBuckets: OddsBucketStats[];
  sportBetTypeStats: SportBetTypeStats[];
}

export function SEOSharePanel({ bets, oddsBuckets, sportBetTypeStats }: SEOSharePanelProps) {
  const [copied, setCopied] = useState<string | null>(null);

  if (bets.length === 0) return null;

  const seoMetadata = generateSEOMetadata(bets, oddsBuckets, sportBetTypeStats);
  const shareableInsight = generateShareableInsight(bets, oddsBuckets, sportBetTypeStats);
  const metaTagsHTML = generateMetaTagsHTML(seoMetadata);
  const shareableText = generateShareableText(shareableInsight);

  const handleCopy = async (content: string, type: string): Promise<void> => {
    const success = await copyToClipboard(content);
    if (success) {
      setCopied(type);
      setTimeout(() => setCopied(null), 2000);
    }
  };

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-[#22d3ee] text-xl flex items-center gap-2">
              <Share2 className="w-5 h-5" />
              Share Your Edge
            </CardTitle>
            <p className="text-sm text-gray-400 mt-1">
              AI-powered insights ready to share on social media
            </p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Shareable Insight Card */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-gray-300 flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              Social Media Post
            </h3>
            <div className="bg-[#020617] border border-[#1e293b] rounded-lg p-4 space-y-3">
              <div>
                <h4 className="font-bold text-white text-lg">{shareableInsight.title}</h4>
                <p className="text-sm text-gray-400 mt-1">{shareableInsight.description}</p>
              </div>
              <div className="space-y-1.5">
                {shareableInsight.stats.map((stat, i) => (
                  <div key={i} className="text-sm text-white font-mono bg-[#0b1120] px-3 py-1.5 rounded">
                    {stat}
                  </div>
                ))}
              </div>
              <p className="text-xs text-gray-500">
                Track your betting edge: Trend & Heatmap Explorer
              </p>
            </div>
            <Button
              onClick={() => handleCopy(shareableText, "social")}
              size="sm"
              className="w-full bg-[#22d3ee] hover:bg-[#22d3ee]/80 text-black"
            >
              {copied === "social" ? (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy Post Text
                </>
              )}
            </Button>
          </div>

          {/* SEO Metadata Preview */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-gray-300 flex items-center gap-2">
              <Code className="w-4 h-4" />
              SEO Metadata
            </h3>
            <div className="bg-[#020617] border border-[#1e293b] rounded-lg p-4 space-y-3">
              <div>
                <h4 className="text-xs font-medium text-gray-500 mb-1">Page Title</h4>
                <p className="text-sm text-white font-medium">{seoMetadata.title}</p>
              </div>
              <div>
                <h4 className="text-xs font-medium text-gray-500 mb-1">Description</h4>
                <p className="text-xs text-gray-300 leading-relaxed">{seoMetadata.description}</p>
              </div>
              <div>
                <h4 className="text-xs font-medium text-gray-500 mb-1">Keywords</h4>
                <div className="flex flex-wrap gap-1">
                  {seoMetadata.keywords.slice(0, 6).map((keyword, i) => (
                    <span
                      key={i}
                      className="text-xs bg-[#1e293b] text-gray-300 px-2 py-0.5 rounded"
                    >
                      {keyword}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            <Dialog>
              <DialogTrigger asChild>
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full border-[#1e293b] hover:bg-[#1e293b]"
                >
                  <Code className="w-4 h-4 mr-2" />
                  View Full Meta Tags
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-[#0b1120] border-[#1e293b] text-white max-w-3xl">
                <DialogHeader>
                  <DialogTitle className="text-[#22d3ee]">SEO Meta Tags & Structured Data</DialogTitle>
                  <DialogDescription className="text-gray-400">
                    Copy and paste these tags into your website's &lt;head&gt; section
                  </DialogDescription>
                </DialogHeader>
                <Tabs defaultValue="meta" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 bg-[#020617]">
                    <TabsTrigger 
                      value="meta"
                      className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black"
                    >
                      Meta Tags
                    </TabsTrigger>
                    <TabsTrigger 
                      value="schema"
                      className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black"
                    >
                      Schema.org
                    </TabsTrigger>
                    <TabsTrigger 
                      value="preview"
                      className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black"
                    >
                      Preview
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="meta" className="space-y-3">
                    <Textarea
                      value={metaTagsHTML}
                      readOnly
                      className="bg-[#020617] border-[#1e293b] text-white font-mono text-xs min-h-[400px]"
                    />
                    <Button
                      onClick={() => handleCopy(metaTagsHTML, "meta")}
                      size="sm"
                      className="w-full bg-[#22d3ee] hover:bg-[#22d3ee]/80 text-black"
                    >
                      {copied === "meta" ? (
                        <>
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" />
                          Copy Meta Tags
                        </>
                      )}
                    </Button>
                  </TabsContent>

                  <TabsContent value="schema" className="space-y-3">
                    <Textarea
                      value={JSON.stringify(seoMetadata.schema, null, 2)}
                      readOnly
                      className="bg-[#020617] border-[#1e293b] text-white font-mono text-xs min-h-[400px]"
                    />
                    <Button
                      onClick={() => handleCopy(JSON.stringify(seoMetadata.schema, null, 2), "schema")}
                      size="sm"
                      className="w-full bg-[#22d3ee] hover:bg-[#22d3ee]/80 text-black"
                    >
                      {copied === "schema" ? (
                        <>
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" />
                          Copy Schema
                        </>
                      )}
                    </Button>
                  </TabsContent>

                  <TabsContent value="preview" className="space-y-4">
                    <div className="bg-[#020617] border border-[#1e293b] rounded-lg p-4 space-y-4">
                      {/* Google Preview */}
                      <div>
                        <h4 className="text-xs font-medium text-gray-500 mb-2">Google Search Preview</h4>
                        <div className="space-y-1">
                          <div className="text-[#8ab4f8] text-lg hover:underline cursor-pointer">
                            {seoMetadata.title}
                          </div>
                          <div className="text-[#9aa0a6] text-xs">
                            https://yourapp.com/analytics
                          </div>
                          <div className="text-[#bdc1c6] text-sm">
                            {seoMetadata.description}
                          </div>
                        </div>
                      </div>

                      {/* Social Media Preview */}
                      <div>
                        <h4 className="text-xs font-medium text-gray-500 mb-2">Social Media Preview</h4>
                        <div className="border border-[#1e293b] rounded overflow-hidden">
                          <div className="bg-gray-800 h-48 flex items-center justify-center">
                            <Share2 className="w-12 h-12 text-gray-600" />
                          </div>
                          <div className="p-3 bg-[#0b1120]">
                            <div className="font-medium text-white text-sm">{seoMetadata.ogTitle}</div>
                            <div className="text-xs text-gray-400 mt-1">{seoMetadata.ogDescription}</div>
                            <div className="text-xs text-gray-500 mt-1">yourapp.com</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="bg-[#020617] border border-[#1e293b] rounded-lg p-4">
          <h4 className="text-sm font-medium text-gray-300 mb-2">Why AI SEO Matters</h4>
          <ul className="text-xs text-gray-400 space-y-1.5">
            <li className="flex items-start gap-2">
              <span className="text-[#22d3ee] mt-0.5">•</span>
              <span><strong>Optimized for AI search engines</strong> (ChatGPT, Perplexity, Google AI)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-[#22d3ee] mt-0.5">•</span>
              <span><strong>Rich social previews</strong> increase click-through rates by 40%</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-[#22d3ee] mt-0.5">•</span>
              <span><strong>Structured data</strong> helps search engines understand your betting insights</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-[#22d3ee] mt-0.5">•</span>
              <span><strong>Dynamic content</strong> updates automatically based on your performance</span>
            </li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
