"use client";

import type { SportBetTypeStats, BetType } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface SportBetTypeHeatmapProps {
  stats: SportBetTypeStats[];
}

export function SportBetTypeHeatmap({ stats }: SportBetTypeHeatmapProps) {
  if (stats.length === 0) {
    return null;
  }

  const sports = Array.from(new Set(stats.map(s => s.sport))).sort();
  const betTypes: BetType[] = ["moneyline", "spread", "total", "prop", "parlay"];

  const getStats = (sport: string, betType: BetType): SportBetTypeStats | undefined => {
    return stats.find(s => s.sport === sport && s.betType === betType);
  };

  const getColorClass = (roiPct: number, bets: number): string => {
    if (bets < 5) return "bg-gray-800 text-gray-400";
    if (roiPct > 10) return "bg-green-900/60 text-green-300";
    if (roiPct > 3) return "bg-green-900/40 text-green-400";
    if (roiPct > -3) return "bg-yellow-900/30 text-yellow-300";
    if (roiPct > -10) return "bg-red-900/40 text-red-400";
    return "bg-red-900/60 text-red-300";
  };

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-[#22d3ee] text-xl">Sport × Bet Type Heatmap</CardTitle>
        <p className="text-sm text-gray-400">ROI % by sport and bet type combination</p>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <th className="text-left p-3 text-sm font-medium text-gray-400 border-b border-[#1e293b]">
                  Sport
                </th>
                {betTypes.map(betType => (
                  <th
                    key={betType}
                    className="text-center p-3 text-sm font-medium text-gray-400 border-b border-[#1e293b] capitalize"
                  >
                    {betType}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sports.map(sport => (
                <tr key={sport} className="border-b border-[#1e293b]/50">
                  <td className="p-3 text-sm font-medium text-white">{sport}</td>
                  {betTypes.map(betType => {
                    const cellStats = getStats(sport, betType);
                    if (!cellStats) {
                      return (
                        <td key={betType} className="p-2">
                          <div className="h-16 flex items-center justify-center bg-gray-900/30 rounded text-gray-600 text-xs">
                            —
                          </div>
                        </td>
                      );
                    }

                    const colorClass = getColorClass(cellStats.roiPct, cellStats.bets);

                    return (
                      <td key={betType} className="p-2">
                        <div
                          className={`h-16 flex flex-col items-center justify-center rounded ${colorClass} cursor-pointer hover:opacity-80 transition-opacity`}
                          title={`${cellStats.bets} bets | ${cellStats.profitLoss >= 0 ? '+' : ''}${cellStats.profitLoss.toFixed(2)} | ${(cellStats.winRate * 100).toFixed(1)}% win rate`}
                        >
                          <div className="text-lg font-bold">
                            {cellStats.roiPct >= 0 ? '+' : ''}{cellStats.roiPct.toFixed(1)}%
                          </div>
                          <div className="text-xs opacity-75">
                            {cellStats.bets} bets
                          </div>
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-4 flex items-center gap-4 text-xs text-gray-400">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-900/60 rounded"></div>
            <span>Strong edge</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-yellow-900/30 rounded"></div>
            <span>Break-even</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-red-900/60 rounded"></div>
            <span>Losing</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-gray-800 rounded"></div>
            <span>&lt;5 bets</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
