"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, TrendingUp, TrendingDown, Zap } from "lucide-react";
import type { SteamMove } from "@/lib/odds-api-types";

interface SteamMoveDetectorProps {
  steamMoves: SteamMove[];
}

export function SteamMoveDetector({ steamMoves }: SteamMoveDetectorProps) {
  const recentMoves = [...steamMoves]
    .sort((a, b) => b.detectedAt - a.detectedAt)
    .slice(0, 20);

  const getConfidenceColor = (confidence: string): string => {
    switch (confidence) {
      case "high":
        return "bg-[#22c55e]/10 text-[#22c55e] border-[#22c55e]/30";
      case "medium":
        return "bg-[#fbbf24]/10 text-[#fbbf24] border-[#fbbf24]/30";
      case "low":
        return "bg-[#9ca3af]/10 text-[#9ca3af] border-[#9ca3af]/30";
      default:
        return "bg-[#9ca3af]/10 text-[#9ca3af] border-[#9ca3af]/30";
    }
  };

  if (steamMoves.length === 0) {
    return (
      <Card className="bg-[#0b1120] border-[#1e293b]">
        <CardHeader>
          <CardTitle className="text-[#e5e7eb] flex items-center gap-2">
            <Zap className="w-5 h-5 text-[#22d3ee]" />
            Steam Move Detector
          </CardTitle>
          <CardDescription className="text-[#9ca3af]">
            Track sharp money movements across bookmakers
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Zap className="w-12 h-12 text-[#9ca3af] mx-auto mb-3" />
            <p className="text-[#9ca3af]">No steam moves detected recently</p>
            <p className="text-sm text-[#6b7280] mt-2">
              Steam moves indicate sharp money action. They'll appear here when detected.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-[#e5e7eb] flex items-center gap-2">
              <Zap className="w-5 h-5 text-[#fbbf24]" />
              Steam Move Detector
            </CardTitle>
            <CardDescription className="text-[#9ca3af]">
              Sharp money movements detected
            </CardDescription>
          </div>
          <Badge variant="outline" className="bg-[#fbbf24]/10 text-[#fbbf24] border-[#fbbf24]/30">
            {steamMoves.length} Moves
          </Badge>
        </div>
      </CardHeader>

      <CardContent>
        <div className="space-y-2">
          {recentMoves.map((move) => {
            const direction = move.newLine > move.originalLine ? "up" : "down";
            const DirectionIcon = direction === "up" ? TrendingUp : TrendingDown;
            const directionColor = direction === "up" ? "text-[#22c55e]" : "text-[#ef4444]";

            return (
              <div
                key={move.id}
                className="p-3 bg-[#020617] rounded-lg border border-[#1e293b] hover:border-[#22d3ee]/30 transition-colors"
              >
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="font-medium text-[#e5e7eb]">
                      {move.awayTeam} @ {move.homeTeam}
                    </div>
                    <div className="text-sm text-[#9ca3af]">
                      {move.sport} • {move.market === "spreads" ? "Spread" : "Total"}
                    </div>
                  </div>
                  <Badge variant="outline" className={getConfidenceColor(move.confidence)}>
                    {move.confidence.toUpperCase()}
                  </Badge>
                </div>

                <div className="grid grid-cols-3 gap-3 mb-2">
                  <div className="p-2 bg-[#0b1120] rounded border border-[#1e293b]">
                    <div className="text-xs text-[#9ca3af] mb-1">Original Line</div>
                    <div className="text-lg font-bold text-[#e5e7eb]">
                      {move.originalLine > 0 ? "+" : ""}
                      {move.originalLine}
                    </div>
                  </div>
                  <div className="p-2 bg-[#0b1120] rounded border border-[#1e293b]">
                    <div className="text-xs text-[#9ca3af] mb-1">New Line</div>
                    <div className={`text-lg font-bold ${directionColor}`}>
                      {move.newLine > 0 ? "+" : ""}
                      {move.newLine}
                    </div>
                  </div>
                  <div className="p-2 bg-[#0b1120] rounded border border-[#1e293b]">
                    <div className="text-xs text-[#9ca3af] mb-1">Movement</div>
                    <div className={`text-lg font-bold ${directionColor} flex items-center gap-1`}>
                      <DirectionIcon className="w-4 h-4" />
                      {move.movement.toFixed(1)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#9ca3af]">
                    {move.bookmakers.length} bookmaker{move.bookmakers.length !== 1 ? "s" : ""} moved
                  </span>
                  <span className="text-[#6b7280]">
                    {new Date(move.detectedAt).toLocaleTimeString()}
                  </span>
                </div>

                {move.confidence === "high" && (
                  <div className="mt-2 flex items-start gap-2 p-2 bg-[#22c55e]/10 border border-[#22c55e]/30 rounded">
                    <Zap className="w-3 h-3 text-[#22c55e] mt-0.5 flex-shrink-0" />
                    <p className="text-xs text-[#22c55e]">
                      High confidence: Multiple books moved simultaneously - likely sharp action
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {steamMoves.length > 20 && (
          <div className="mt-3 text-center text-sm text-[#9ca3af]">
            Showing 20 most recent moves out of {steamMoves.length} total
          </div>
        )}
      </CardContent>
    </Card>
  );
}
