"use client";

import type { TimelinePoint } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

interface TimelineChartProps {
  data: TimelinePoint[];
  bucket: "day" | "week";
}

export function TimelineChart({ data, bucket }: TimelineChartProps) {
  if (data.length === 0) {
    return null;
  }

  const customTooltip = ({ active, payload }: { active?: boolean; payload?: Array<{ value: number; payload: TimelinePoint }> }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-[#0b1120] border border-[#1e293b] rounded-lg p-3 shadow-lg">
          <p className="text-white font-medium text-sm">{data.label}</p>
          <p className={`text-sm mt-1 ${data.net >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            P&L: {data.net >= 0 ? '+' : ''}{data.net.toFixed(2)}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-[#22d3ee] text-xl">
          P&L Timeline ({bucket === "day" ? "Daily" : "Weekly"})
        </CardTitle>
        <p className="text-sm text-gray-400">Track your profit and loss over time</p>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
            <XAxis
              dataKey="label"
              stroke="#6b7280"
              tick={{ fill: "#9ca3af", fontSize: 12 }}
              angle={-45}
              textAnchor="end"
              height={80}
            />
            <YAxis
              stroke="#6b7280"
              tick={{ fill: "#9ca3af", fontSize: 12 }}
            />
            <Tooltip content={customTooltip} />
            <Bar dataKey="net" radius={[4, 4, 0, 0]}>
              {data.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={entry.net >= 0 ? "#22c55e" : "#ef4444"}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
