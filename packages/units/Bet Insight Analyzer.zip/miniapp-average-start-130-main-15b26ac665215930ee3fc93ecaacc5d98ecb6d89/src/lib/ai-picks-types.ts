// AI-powered expert picks and predictive analytics types

export type PickConfidence = "very_high" | "high" | "medium" | "low";
export type PickType = "moneyline" | "spread" | "total" | "prop";

export interface AIPickFactors {
  teamForm: number;
  headToHead: number;
  injuries: number;
  homeAdvantage: number;
  weather: number;
  motivation: number;
  rest: number;
  publicBetting: number;
}

export interface AIPick {
  id: string;
  eventId: string;
  sport: string;
  homeTeam: string;
  awayTeam: string;
  commenceTime: string;
  pickType: PickType;
  prediction: string;
  recommendedOdds: number;
  winProbability: number;
  confidence: PickConfidence;
  reasoning: string;
  factors: AIPickFactors;
  expectedValue: number;
  kellyStake: number;
  generatedAt: number;
  model: "gpt-4o" | "perplexity";
}

export interface PropAnalysis {
  id: string;
  eventId: string;
  sport: string;
  player: string;
  propType: string;
  line: number;
  overOdds: number;
  underOdds: number;
  recommendation: "over" | "under" | "skip";
  confidence: PickConfidence;
  reasoning: string;
  historicalAverage: number;
  recentForm: number;
  matchupAdvantage: number;
  expectedValue: number;
}

export interface FuturesBet {
  id: string;
  betId: string;
  sport: string;
  league: string;
  betType: "championship" | "playoff" | "award" | "season_wins" | "custom";
  description: string;
  selection: string;
  placedAt: number;
  oddsAtPlacement: number;
  currentOdds: number;
  stake: number;
  potentialPayout: number;
  settlementDate?: number;
  status: "active" | "won" | "lost" | "void";
  hedgeOpportunities?: {
    bookmaker: string;
    selection: string;
    odds: number;
    stake: number;
    guaranteedProfit: number;
  }[];
}

export interface KellyCalculation {
  eventId: string;
  selection: string;
  yourWinProbability: number;
  bookmakerOdds: number;
  bankroll: number;
  kellyFraction: number;
  recommendedStake: number;
  fullKellyStake: number;
  fractionalKellyStake: number;
  expectedValue: number;
  riskLevel: "conservative" | "moderate" | "aggressive";
}

export interface CommunityPick {
  id: string;
  userId: string;
  username: string;
  verifiedRecord: {
    totalPicks: number;
    wins: number;
    losses: number;
    pushes: number;
    roi: number;
    streak: number;
    streakType: "win" | "loss";
  };
  eventId: string;
  sport: string;
  homeTeam: string;
  awayTeam: string;
  pickType: PickType;
  selection: string;
  odds: number;
  confidence: PickConfidence;
  reasoning: string;
  postedAt: number;
  likes: number;
  comments: number;
}
