// AI-powered expert picks and predictive analytics
import type { AIPick, PropAnalysis, KellyCalculation, PickConfidence, AIPickFactors } from "./ai-picks-types";
import type { OddsEvent } from "./odds-api-types";

export async function generateAIPick(
  event: OddsEvent,
  apiKey: string,
  model: "openai" | "perplexity" = "openai"
): Promise<AIPick> {
  const prompt = `Analyze this ${event.sport_title} game and provide a betting recommendation:

${event.away_team} @ ${event.home_team}
Commence Time: ${new Date(event.commence_time).toLocaleString()}

Current Odds (American format):
${event.bookmakers
  .slice(0, 3)
  .map((b) => {
    const h2h = b.markets.find((m) => m.key === "h2h");
    if (!h2h) return "";
    return `${b.title}: ${h2h.outcomes.map((o) => `${o.name} ${o.price > 0 ? "+" : ""}${o.price}`).join(", ")}`;
  })
  .filter(Boolean)
  .join("\n")}

Analyze:
1. Team form and recent performance
2. Head-to-head history
3. Injuries and roster changes
4. Home/away advantage
5. Motivation factors
6. Public betting trends

Provide:
- Your pick (which team and bet type)
- Win probability (0-100)
- Confidence level (very_high, high, medium, low)
- Recommended odds to take
- Detailed reasoning
- Factor scores (0-10 for each: teamForm, headToHead, injuries, homeAdvantage, weather, motivation, rest, publicBetting)

Format as JSON.`;

  const endpoint = model === "openai" 
    ? "/api/proxy" 
    : "/api/proxy";

  const body = model === "openai"
    ? JSON.stringify({
        protocol: "https",
        origin: "api.openai.com",
        path: "/v1/chat/completions",
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: {
          model: "gpt-4o",
          messages: [
            { role: "system", content: "You are an expert sports betting analyst with deep knowledge of all major sports." },
            { role: "user", content: prompt },
          ],
          response_format: { type: "json_object" },
        },
      })
    : JSON.stringify({
        protocol: "https",
        origin: "api.perplexity.ai",
        path: "/chat/completions",
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: {
          model: "llama-3.1-sonar-large-128k-online",
          messages: [
            { role: "system", content: "You are an expert sports betting analyst with access to real-time sports data." },
            { role: "user", content: prompt },
          ],
        },
      });

  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body,
  });

  if (!response.ok) {
    throw new Error(`AI pick generation failed: ${response.statusText}`);
  }

  const data = await response.json();
  const content = data.choices[0].message.content;
  const parsed = JSON.parse(content);

  // Calculate expected value
  const impliedProb = parsed.recommendedOdds > 0 
    ? 100 / (parsed.recommendedOdds + 100) 
    : Math.abs(parsed.recommendedOdds) / (Math.abs(parsed.recommendedOdds) + 100);
  const expectedValue = (parsed.winProbability / 100 - impliedProb) * 100;

  // Calculate Kelly stake (fractional Kelly at 25% of full Kelly)
  const kellyFraction = (parsed.winProbability / 100 - (1 - parsed.winProbability / 100) * impliedProb) / impliedProb;
  const kellyStake = Math.max(0, kellyFraction * 0.25 * 100); // Assume $100 bankroll, 25% Kelly

  return {
    id: `ai-pick-${event.id}-${Date.now()}`,
    eventId: event.id,
    sport: event.sport_title,
    homeTeam: event.home_team,
    awayTeam: event.away_team,
    commenceTime: event.commence_time,
    pickType: parsed.betType || "moneyline",
    prediction: parsed.pick,
    recommendedOdds: parsed.recommendedOdds,
    winProbability: parsed.winProbability,
    confidence: parsed.confidence as PickConfidence,
    reasoning: parsed.reasoning,
    factors: parsed.factors as AIPickFactors,
    expectedValue,
    kellyStake,
    generatedAt: Date.now(),
    model: model === "openai" ? "gpt-4o" : "perplexity",
  };
}

export async function analyzeProp(
  event: OddsEvent,
  player: string,
  propType: string,
  line: number,
  overOdds: number,
  underOdds: number,
  apiKey: string
): Promise<PropAnalysis> {
  const prompt = `Analyze this player prop bet:

Game: ${event.away_team} @ ${event.home_team}
Player: ${player}
Prop: ${propType}
Line: ${line}
Odds: Over ${overOdds > 0 ? "+" : ""}${overOdds} / Under ${underOdds > 0 ? "+" : ""}${underOdds}

Analyze:
1. Player's historical average for this stat
2. Recent form (last 5-10 games)
3. Matchup advantage/disadvantage
4. Team pace and style
5. Injury concerns
6. Motivation and playing time

Recommend: "over", "under", or "skip"
Confidence: very_high, high, medium, low
Provide detailed reasoning and expected value estimate.

Format as JSON.`;

  const response = await fetch("/api/proxy", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      protocol: "https",
      origin: "api.openai.com",
      path: "/v1/chat/completions",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: {
        model: "gpt-4o",
        messages: [
          { role: "system", content: "You are an expert at analyzing player prop bets with deep statistical knowledge." },
          { role: "user", content: prompt },
        ],
        response_format: { type: "json_object" },
      },
    }),
  });

  if (!response.ok) {
    throw new Error(`Prop analysis failed: ${response.statusText}`);
  }

  const data = await response.json();
  const content = data.choices[0].message.content;
  const parsed = JSON.parse(content);

  return {
    id: `prop-${event.id}-${player}-${Date.now()}`,
    eventId: event.id,
    sport: event.sport_title,
    player,
    propType,
    line,
    overOdds,
    underOdds,
    recommendation: parsed.recommendation,
    confidence: parsed.confidence,
    reasoning: parsed.reasoning,
    historicalAverage: parsed.historicalAverage || line,
    recentForm: parsed.recentForm || line,
    matchupAdvantage: parsed.matchupAdvantage || 0,
    expectedValue: parsed.expectedValue || 0,
  };
}

export function calculateKelly(
  yourWinProbability: number,
  bookmakerOdds: number,
  bankroll: number,
  fractional: boolean = true
): KellyCalculation {
  // Convert American odds to decimal
  const decimalOdds = bookmakerOdds > 0 
    ? (bookmakerOdds / 100) + 1 
    : (100 / Math.abs(bookmakerOdds)) + 1;

  const p = yourWinProbability / 100; // Win probability
  const q = 1 - p; // Loss probability
  const b = decimalOdds - 1; // Net odds

  // Kelly formula: f = (bp - q) / b
  const kellyFraction = (b * p - q) / b;

  const fullKellyStake = Math.max(0, kellyFraction * bankroll);
  const fractionalKellyStake = fullKellyStake * 0.25; // Quarter Kelly

  // Calculate expected value
  const impliedProb = 1 / decimalOdds;
  const expectedValue = (p - impliedProb) * 100;

  const riskLevel: "conservative" | "moderate" | "aggressive" = 
    kellyFraction < 0.02 ? "conservative" : kellyFraction < 0.05 ? "moderate" : "aggressive";

  return {
    eventId: "",
    selection: "",
    yourWinProbability,
    bookmakerOdds,
    bankroll,
    kellyFraction,
    recommendedStake: fractional ? fractionalKellyStake : fullKellyStake,
    fullKellyStake,
    fractionalKellyStake,
    expectedValue,
    riskLevel,
  };
}

export function calculateParlayEV(
  legs: { winProbability: number; odds: number }[]
): { combinedProbability: number; parlayOdds: number; expectedValue: number; breakEvenProbability: number } {
  // Combined probability = product of all leg probabilities
  const combinedProbability = legs.reduce((acc, leg) => acc * (leg.winProbability / 100), 1);

  // Calculate parlay odds (American)
  let parlayDecimal = 1;
  for (const leg of legs) {
    const legDecimal = leg.odds > 0 ? (leg.odds / 100) + 1 : (100 / Math.abs(leg.odds)) + 1;
    parlayDecimal *= legDecimal;
  }

  const parlayOdds = parlayDecimal >= 2 
    ? Math.round((parlayDecimal - 1) * 100) 
    : Math.round(-100 / (parlayDecimal - 1));

  // Break-even probability
  const breakEvenProbability = 1 / parlayDecimal;

  // Expected value
  const expectedValue = (combinedProbability - breakEvenProbability) * 100;

  return {
    combinedProbability: combinedProbability * 100,
    parlayOdds,
    expectedValue,
    breakEvenProbability: breakEvenProbability * 100,
  };
}
