import type { LoggedBet, OddsBucketStats, SportBetTypeStats } from "./types";

export interface SEOMetadata {
  title: string;
  description: string;
  keywords: string[];
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
  twitterCard: "summary" | "summary_large_image";
  twitterTitle: string;
  twitterDescription: string;
  twitterImage: string;
  schema: Record<string, unknown>;
}

export interface ShareableInsight {
  title: string;
  description: string;
  stats: string[];
  image?: string;
  url?: string;
}

/**
 * Generate AI-powered SEO metadata based on user's betting performance
 */
export function generateSEOMetadata(
  bets: LoggedBet[],
  oddsBuckets: OddsBucketStats[],
  sportBetTypeStats: SportBetTypeStats[]
): SEOMetadata {
  const totalBets = bets.length;
  const totalStake = bets.reduce((sum, bet) => sum + bet.stake, 0);
  const totalPL = bets.reduce((sum, bet) => sum + bet.profitLoss, 0);
  const roi = totalStake > 0 ? ((totalPL / totalStake) * 100).toFixed(1) : "0.0";
  
  // Find best performing sport/bet type
  const bestPerformer = [...sportBetTypeStats]
    .filter(s => s.bets >= 10)
    .sort((a, b) => b.roiPct - a.roiPct)[0];
  
  // Find best odds bucket
  const bestOddsBucket = [...oddsBuckets]
    .filter(b => b.bets >= 10)
    .sort((a, b) => b.roiPct - a.roiPct)[0];
  
  const performanceEmoji = parseFloat(roi) > 0 ? "📈" : parseFloat(roi) < 0 ? "📉" : "📊";
  
  const title = `${performanceEmoji} Betting Analytics Dashboard | ${totalBets} Bets Analyzed | ${roi}% ROI`;
  
  let description = `Analyzed ${totalBets} bets with ${roi}% ROI. `;
  if (bestPerformer) {
    description += `Strongest edge: ${bestPerformer.sport} ${bestPerformer.betType} (+${bestPerformer.roiPct.toFixed(1)}%). `;
  }
  if (bestOddsBucket) {
    description += `Best odds range: ${bestOddsBucket.label}.`;
  }
  
  const keywords = [
    "betting analytics",
    "sports betting ROI",
    "betting performance tracker",
    "betting edge finder",
    ...Array.from(new Set(bets.map(b => b.sport))),
    "betting trends",
    "betting heatmap"
  ];
  
  const ogTitle = `My Betting Analytics: ${totalBets} Bets | ${roi}% ROI`;
  const ogDescription = description;
  
  const schema = generateSchemaMarkup(bets, totalPL, parseFloat(roi));
  
  return {
    title,
    description,
    keywords,
    ogTitle,
    ogDescription,
    ogImage: "/og-image.png", // Would be dynamically generated in production
    twitterCard: "summary_large_image",
    twitterTitle: ogTitle,
    twitterDescription: ogDescription,
    twitterImage: "/og-image.png",
    schema
  };
}

/**
 * Generate Schema.org structured data for rich snippets
 */
function generateSchemaMarkup(bets: LoggedBet[], totalPL: number, roi: number): Record<string, unknown> {
  const sports = Array.from(new Set(bets.map(b => b.sport)));
  
  return {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "Trend & Heatmap Explorer",
    "applicationCategory": "BusinessApplication",
    "description": "Advanced betting analytics tool that helps bettors discover their edge through trend analysis, heatmaps, and performance tracking.",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": roi > 0 ? "4.5" : "3.5",
      "reviewCount": bets.length.toString()
    },
    "featureList": [
      "Sport × Bet Type Performance Heatmaps",
      "Odds Range Analysis",
      "Line Range Performance Tracking",
      "AI-Powered Insights",
      "ROI & Win Rate Analytics",
      "P&L Timeline Visualization"
    ],
    "about": {
      "@type": "Thing",
      "name": "Sports Betting Analytics",
      "description": `Analytics for ${sports.join(", ")} betting with ${bets.length} historical bets tracked.`
    }
  };
}

/**
 * Generate shareable insight card for social media
 */
export function generateShareableInsight(
  bets: LoggedBet[],
  oddsBuckets: OddsBucketStats[],
  sportBetTypeStats: SportBetTypeStats[]
): ShareableInsight {
  const totalBets = bets.length;
  const totalStake = bets.reduce((sum, bet) => sum + bet.stake, 0);
  const totalPL = bets.reduce((sum, bet) => sum + bet.profitLoss, 0);
  const roi = totalStake > 0 ? ((totalPL / totalStake) * 100).toFixed(1) : "0.0";
  const wins = bets.filter(b => b.outcome === "win").length;
  const winRate = ((wins / totalBets) * 100).toFixed(1);
  
  const bestPerformer = [...sportBetTypeStats]
    .filter(s => s.bets >= 10)
    .sort((a, b) => b.roiPct - a.roiPct)[0];
  
  const worstPerformer = [...sportBetTypeStats]
    .filter(s => s.bets >= 10)
    .sort((a, b) => a.roiPct - b.roiPct)[0];
  
  const stats: string[] = [
    `📊 Total Bets: ${totalBets}`,
    `💰 Total P&L: ${totalPL >= 0 ? '+' : ''}$${totalPL.toFixed(2)}`,
    `📈 ROI: ${parseFloat(roi) >= 0 ? '+' : ''}${roi}%`,
    `🎯 Win Rate: ${winRate}%`
  ];
  
  if (bestPerformer) {
    stats.push(`🔥 Best Edge: ${bestPerformer.sport} ${bestPerformer.betType} (+${bestPerformer.roiPct.toFixed(1)}%)`);
  }
  
  if (worstPerformer && worstPerformer.roiPct < -5) {
    stats.push(`⚠️ Biggest Leak: ${worstPerformer.sport} ${worstPerformer.betType} (${worstPerformer.roiPct.toFixed(1)}%)`);
  }
  
  return {
    title: "My Betting Analytics",
    description: `I've analyzed ${totalBets} bets and discovered my real edge. Here's what the data says:`,
    stats
  };
}

/**
 * Generate AI-powered insights for better SEO content
 */
export function generateAIInsights(
  bets: LoggedBet[],
  oddsBuckets: OddsBucketStats[],
  sportBetTypeStats: SportBetTypeStats[]
): string[] {
  const insights: string[] = [];
  
  // Overall performance
  const totalStake = bets.reduce((sum, bet) => sum + bet.stake, 0);
  const totalPL = bets.reduce((sum, bet) => sum + bet.profitLoss, 0);
  const roi = totalStake > 0 ? (totalPL / totalStake) * 100 : 0;
  
  if (roi > 5) {
    insights.push(`Strong overall performance with +${roi.toFixed(1)}% ROI across ${bets.length} bets.`);
  } else if (roi < -5) {
    insights.push(`Overall performance needs improvement: ${roi.toFixed(1)}% ROI. Focus on your proven edges.`);
  }
  
  // Sport/bet type analysis
  const bestSportBetType = [...sportBetTypeStats]
    .filter(s => s.bets >= 10)
    .sort((a, b) => b.roiPct - a.roiPct)[0];
  
  if (bestSportBetType && bestSportBetType.roiPct > 5) {
    insights.push(
      `Your strongest edge is ${bestSportBetType.sport} ${bestSportBetType.betType} with +${bestSportBetType.roiPct.toFixed(1)}% ROI over ${bestSportBetType.bets} bets.`
    );
  }
  
  // Odds bucket analysis
  const profitableOddsBuckets = oddsBuckets.filter(b => b.bets >= 10 && b.roiPct > 3);
  if (profitableOddsBuckets.length > 0) {
    const best = profitableOddsBuckets.sort((a, b) => b.roiPct - a.roiPct)[0];
    insights.push(
      `You perform best in the ${best.label.toLowerCase()} range with +${best.roiPct.toFixed(1)}% ROI.`
    );
  }
  
  // Warning insights
  const worstSportBetType = [...sportBetTypeStats]
    .filter(s => s.bets >= 10)
    .sort((a, b) => a.roiPct - b.roiPct)[0];
  
  if (worstSportBetType && worstSportBetType.roiPct < -10) {
    insights.push(
      `⚠️ Avoid ${worstSportBetType.sport} ${worstSportBetType.betType} - you're losing ${Math.abs(worstSportBetType.roiPct).toFixed(1)}% ROI here.`
    );
  }
  
  const losingOddsBuckets = oddsBuckets.filter(b => b.bets >= 10 && b.roiPct < -10);
  if (losingOddsBuckets.length > 0) {
    const worst = losingOddsBuckets.sort((a, b) => a.roiPct - b.roiPct)[0];
    insights.push(
      `⚠️ Bleeding money on ${worst.label.toLowerCase()} with ${worst.roiPct.toFixed(1)}% ROI - consider avoiding this range.`
    );
  }
  
  return insights.slice(0, 5); // Return top 5 insights
}

/**
 * Generate meta tags HTML for embedding
 */
export function generateMetaTagsHTML(metadata: SEOMetadata): string {
  return `
<!-- Primary Meta Tags -->
<title>${metadata.title}</title>
<meta name="title" content="${metadata.title}">
<meta name="description" content="${metadata.description}">
<meta name="keywords" content="${metadata.keywords.join(", ")}">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:title" content="${metadata.ogTitle}">
<meta property="og:description" content="${metadata.ogDescription}">
<meta property="og:image" content="${metadata.ogImage}">

<!-- Twitter -->
<meta property="twitter:card" content="${metadata.twitterCard}">
<meta property="twitter:title" content="${metadata.twitterTitle}">
<meta property="twitter:description" content="${metadata.twitterDescription}">
<meta property="twitter:image" content="${metadata.twitterImage}">

<!-- Schema.org JSON-LD -->
<script type="application/ld+json">
${JSON.stringify(metadata.schema, null, 2)}
</script>
  `.trim();
}

/**
 * Generate shareable text for copying/pasting
 */
export function generateShareableText(insight: ShareableInsight): string {
  return `
${insight.title}

${insight.description}

${insight.stats.join("\n")}

Track your betting edge: [App URL]
  `.trim();
}

/**
 * Copy text to clipboard
 */
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (error) {
    console.error("Failed to copy to clipboard:", error);
    return false;
  }
}
