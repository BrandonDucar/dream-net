import type { LoggedBet } from "./types";

export interface LocationData {
  latitude: number;
  longitude: number;
  state: string | null;
  country: string;
  isLegalJurisdiction: boolean;
  timestamp: number;
}

export interface GeofenceStatus {
  isEnabled: boolean;
  location: LocationData | null;
  error: string | null;
  isLoading: boolean;
}

// US states where sports betting is legal (as of 2024)
const LEGAL_US_STATES = new Set([
  "Arizona", "Arkansas", "Colorado", "Connecticut", "Delaware", "Illinois",
  "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland",
  "Massachusetts", "Michigan", "Mississippi", "Montana", "Nebraska", "Nevada",
  "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina",
  "North Dakota", "Ohio", "Oregon", "Pennsylvania", "Rhode Island",
  "South Dakota", "Tennessee", "Vermont", "Virginia", "Washington",
  "West Virginia", "Wisconsin", "Wyoming", "District of Columbia"
]);

// Legal countries for sports betting
const LEGAL_COUNTRIES = new Set([
  "United States", "United Kingdom", "Canada", "Australia", "Ireland",
  "Germany", "Spain", "Italy", "France", "Portugal", "Netherlands",
  "Belgium", "Austria", "Denmark", "Sweden", "Norway", "Finland"
]);

/**
 * Get user's location using browser Geolocation API
 */
export async function getUserLocation(): Promise<LocationData> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocation is not supported by your browser"));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        
        try {
          // Reverse geocode to get state/country
          const locationInfo = await reverseGeocode(latitude, longitude);
          
          resolve({
            latitude,
            longitude,
            state: locationInfo.state,
            country: locationInfo.country,
            isLegalJurisdiction: checkLegalJurisdiction(locationInfo.country, locationInfo.state),
            timestamp: Date.now()
          });
        } catch (error) {
          // If geocoding fails, still return coordinates
          resolve({
            latitude,
            longitude,
            state: null,
            country: "Unknown",
            isLegalJurisdiction: false,
            timestamp: Date.now()
          });
        }
      },
      (error) => {
        let errorMessage = "Unable to retrieve your location";
        
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "Location permission denied. Please enable location access to verify your jurisdiction.";
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = "Location information is unavailable.";
            break;
          case error.TIMEOUT:
            errorMessage = "Location request timed out.";
            break;
        }
        
        reject(new Error(errorMessage));
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000 // 5 minutes
      }
    );
  });
}

/**
 * Reverse geocode coordinates to get state/country
 * Uses OpenStreetMap Nominatim API (free, no API key required)
 */
async function reverseGeocode(lat: number, lon: number): Promise<{ state: string | null; country: string }> {
  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=10&addressdetails=1`,
      {
        headers: {
          'User-Agent': 'BettingAnalyticsApp/1.0'
        }
      }
    );
    
    if (!response.ok) {
      throw new Error("Geocoding failed");
    }
    
    const data = await response.json();
    const address = data.address || {};
    
    return {
      state: address.state || null,
      country: address.country || "Unknown"
    };
  } catch (error) {
    console.error("Reverse geocoding error:", error);
    return { state: null, country: "Unknown" };
  }
}

/**
 * Check if location is in a legal betting jurisdiction
 */
export function checkLegalJurisdiction(country: string, state: string | null): boolean {
  // Check if country is legal
  if (!LEGAL_COUNTRIES.has(country)) {
    return false;
  }
  
  // For US, check state-level legality
  if (country === "United States") {
    return state ? LEGAL_US_STATES.has(state) : false;
  }
  
  // Other legal countries are OK
  return true;
}

/**
 * Get jurisdiction warning message
 */
export function getJurisdictionWarning(location: LocationData | null): string | null {
  if (!location) {
    return "Location unknown. Sports betting may not be legal in your area.";
  }
  
  if (location.isLegalJurisdiction) {
    return null;
  }
  
  if (location.country === "United States") {
    return `Sports betting is not currently legal in ${location.state || "your state"}. This app is for entertainment and educational purposes only.`;
  }
  
  return `Sports betting may not be legal in ${location.country}. This app is for entertainment and educational purposes only.`;
}

/**
 * Check if location data is stale (older than 30 minutes)
 */
export function isLocationStale(location: LocationData | null): boolean {
  if (!location) return true;
  
  const thirtyMinutes = 30 * 60 * 1000;
  return Date.now() - location.timestamp > thirtyMinutes;
}

/**
 * Format location for display
 */
export function formatLocation(location: LocationData | null): string {
  if (!location) return "Unknown";
  
  if (location.country === "United States" && location.state) {
    return `${location.state}, USA`;
  }
  
  return location.country;
}

/**
 * Get legal betting states list
 */
export function getLegalStates(): string[] {
  return Array.from(LEGAL_US_STATES).sort();
}

/**
 * Detect if user is using VPN or proxy (basic check)
 */
export function detectVPN(location: LocationData): { suspected: boolean; reason: string | null } {
  // This is a basic client-side check. Real VPN detection requires server-side analysis
  // of IP reputation, time zone mismatches, etc.
  
  // Check for sudden location changes (client-side storage based)
  const lastLocation = getStoredLocation();
  
  if (lastLocation) {
    const distance = calculateDistance(
      lastLocation.latitude,
      lastLocation.longitude,
      location.latitude,
      location.longitude
    );
    
    const timeDiff = location.timestamp - lastLocation.timestamp;
    const minutesDiff = timeDiff / (1000 * 60);
    
    // If moved more than 100 miles in less than 5 minutes, might be VPN
    if (distance > 100 && minutesDiff < 5) {
      return {
        suspected: true,
        reason: "Rapid location change detected. Please ensure you're not using a VPN or proxy."
      };
    }
  }
  
  return { suspected: false, reason: null };
}

/**
 * Calculate distance between two coordinates in miles
 */
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3959; // Earth's radius in miles
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function toRad(degrees: number): number {
  return degrees * (Math.PI / 180);
}

/**
 * Store location in localStorage
 */
export function storeLocation(location: LocationData): void {
  try {
    localStorage.setItem("userLocation", JSON.stringify(location));
  } catch (error) {
    console.error("Failed to store location:", error);
  }
}

/**
 * Get stored location from localStorage
 */
export function getStoredLocation(): LocationData | null {
  try {
    const stored = localStorage.getItem("userLocation");
    if (!stored) return null;
    
    const location = JSON.parse(stored) as LocationData;
    
    // Don't use stale data
    if (isLocationStale(location)) {
      return null;
    }
    
    return location;
  } catch (error) {
    console.error("Failed to retrieve stored location:", error);
    return null;
  }
}

/**
 * Analyze bets by location (for future multi-location tracking)
 */
export function analyzeBetsByLocation(bets: LoggedBet[]): Record<string, { bets: number; profitLoss: number }> {
  // This would require location data stored with each bet
  // For now, return empty object as placeholder for future enhancement
  return {};
}
