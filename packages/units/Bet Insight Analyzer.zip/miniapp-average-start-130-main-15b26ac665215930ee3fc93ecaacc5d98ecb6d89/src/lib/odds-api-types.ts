// The Odds API integration types

export type OddsFormat = "american" | "decimal";
export type MarketKey = "h2h" | "spreads" | "totals" | "outrights";
export type Region = "us" | "uk" | "eu" | "au";

export interface Sport {
  key: string;
  group: string;
  title: string;
  description: string;
  active: boolean;
  has_outrights: boolean;
}

export interface Bookmaker {
  key: string;
  title: string;
  last_update: string;
  markets: Market[];
}

export interface Market {
  key: MarketKey;
  last_update: string;
  outcomes: Outcome[];
}

export interface Outcome {
  name: string;
  price: number;
  point?: number;
}

export interface OddsEvent {
  id: string;
  sport_key: string;
  sport_title: string;
  commence_time: string;
  home_team: string;
  away_team: string;
  bookmakers: Bookmaker[];
}

export interface HistoricalOdds {
  eventId: string;
  timestamp: number;
  bookmaker: string;
  market: MarketKey;
  odds: Outcome[];
}

export interface LineMovement {
  eventId: string;
  sport: string;
  homeTeam: string;
  awayTeam: string;
  market: MarketKey;
  movements: {
    timestamp: number;
    bookmaker: string;
    oldValue: number;
    newValue: number;
    direction: "up" | "down";
  }[];
}

export interface ArbitrageOpportunity {
  id: string;
  eventId: string;
  sport: string;
  homeTeam: string;
  awayTeam: string;
  commenceTime: string;
  market: MarketKey;
  books: {
    bookmaker: string;
    outcome: string;
    odds: number;
  }[];
  impliedProbability: number;
  profit: number;
  profitPct: number;
  stakes: Record<string, number>;
}

export interface BestOdds {
  eventId: string;
  market: MarketKey;
  outcome: string;
  bestBookmaker: string;
  bestOdds: number;
  allBooks: {
    bookmaker: string;
    odds: number;
  }[];
}

export interface SteamMove {
  id: string;
  eventId: string;
  sport: string;
  homeTeam: string;
  awayTeam: string;
  market: MarketKey;
  detectedAt: number;
  bookmakers: string[];
  originalLine: number;
  newLine: number;
  movement: number;
  confidence: "high" | "medium" | "low";
}
