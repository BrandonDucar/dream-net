// The Odds API integration service
import type { OddsEvent, Sport, ArbitrageOpportunity, BestOdds, LineMovement, SteamMove, HistoricalOdds } from "./odds-api-types";

const ODDS_API_BASE = "https://api.the-odds-api.com/v4";

export async function fetchSports(apiKey: string): Promise<Sport[]> {
  const response = await fetch(`${ODDS_API_BASE}/sports?apiKey=${apiKey}`);
  if (!response.ok) {
    throw new Error(`Failed to fetch sports: ${response.statusText}`);
  }
  return response.json();
}

export async function fetchOdds(
  apiKey: string,
  sport: string,
  regions: string = "us",
  markets: string = "h2h,spreads,totals",
  oddsFormat: string = "american"
): Promise<OddsEvent[]> {
  const url = `${ODDS_API_BASE}/sports/${sport}/odds?apiKey=${apiKey}&regions=${regions}&markets=${markets}&oddsFormat=${oddsFormat}`;
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to fetch odds: ${response.statusText}`);
  }
  return response.json();
}

export async function fetchEventOdds(
  apiKey: string,
  sport: string,
  eventId: string,
  regions: string = "us",
  markets: string = "h2h,spreads,totals",
  oddsFormat: string = "american"
): Promise<OddsEvent> {
  const url = `${ODDS_API_BASE}/sports/${sport}/odds?apiKey=${apiKey}&regions=${regions}&markets=${markets}&oddsFormat=${oddsFormat}&eventIds=${eventId}`;
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to fetch event odds: ${response.statusText}`);
  }
  const events: OddsEvent[] = await response.json();
  if (events.length === 0) {
    throw new Error("Event not found");
  }
  return events[0];
}

// Find arbitrage opportunities across bookmakers
export function detectArbitrage(events: OddsEvent[]): ArbitrageOpportunity[] {
  const opportunities: ArbitrageOpportunity[] = [];

  for (const event of events) {
    for (const marketKey of ["h2h", "spreads", "totals"] as const) {
      const bookmakersByMarket = event.bookmakers
        .map((b) => ({
          bookmaker: b.key,
          market: b.markets.find((m) => m.key === marketKey),
        }))
        .filter((b) => b.market != null);

      if (bookmakersByMarket.length < 2) continue;

      // For h2h: find best odds for each outcome
      if (marketKey === "h2h") {
        const outcomes = bookmakersByMarket[0].market!.outcomes.map((o) => o.name);
        const bestOddsPerOutcome: Record<string, { bookmaker: string; odds: number }> = {};

        for (const outcome of outcomes) {
          let best = { bookmaker: "", odds: -Infinity };
          for (const { bookmaker, market } of bookmakersByMarket) {
            const outcomeData = market!.outcomes.find((o) => o.name === outcome);
            if (outcomeData && outcomeData.price > best.odds) {
              best = { bookmaker, odds: outcomeData.price };
            }
          }
          bestOddsPerOutcome[outcome] = best;
        }

        // Calculate implied probability
        const impliedProb = Object.values(bestOddsPerOutcome).reduce((sum, { odds }) => {
          return sum + (odds > 0 ? 100 / (odds + 100) : Math.abs(odds) / (Math.abs(odds) + 100));
        }, 0);

        if (impliedProb < 1) {
          // Arbitrage opportunity!
          const profit = (1 - impliedProb) * 100;
          const books = Object.entries(bestOddsPerOutcome).map(([outcome, { bookmaker, odds }]) => ({
            bookmaker,
            outcome,
            odds,
          }));

          opportunities.push({
            id: `arb-${event.id}-${marketKey}`,
            eventId: event.id,
            sport: event.sport_title,
            homeTeam: event.home_team,
            awayTeam: event.away_team,
            commenceTime: event.commence_time,
            market: marketKey,
            books,
            impliedProbability: impliedProb,
            profit: profit * 100, // assume $100 total stake
            profitPct: profit * 100,
            stakes: calculateArbitrageStakes(bestOddsPerOutcome, 100),
          });
        }
      }
    }
  }

  return opportunities;
}

function calculateArbitrageStakes(
  bestOdds: Record<string, { bookmaker: string; odds: number }>,
  totalStake: number
): Record<string, number> {
  const stakes: Record<string, number> = {};
  const impliedProbs: Record<string, number> = {};
  let totalImplied = 0;

  for (const [outcome, { odds }] of Object.entries(bestOdds)) {
    const implied = odds > 0 ? 100 / (odds + 100) : Math.abs(odds) / (Math.abs(odds) + 100);
    impliedProbs[outcome] = implied;
    totalImplied += implied;
  }

  for (const [outcome, implied] of Object.entries(impliedProbs)) {
    stakes[outcome] = (implied / totalImplied) * totalStake;
  }

  return stakes;
}

// Find best odds for each outcome across all bookmakers
export function findBestOdds(events: OddsEvent[]): BestOdds[] {
  const bestOdds: BestOdds[] = [];

  for (const event of events) {
    for (const marketKey of ["h2h", "spreads", "totals"] as const) {
      const bookmakersByMarket = event.bookmakers
        .map((b) => ({
          bookmaker: b.title,
          market: b.markets.find((m) => m.key === marketKey),
        }))
        .filter((b) => b.market != null);

      if (bookmakersByMarket.length === 0) continue;

      const outcomes = bookmakersByMarket[0].market!.outcomes.map((o) => o.name);

      for (const outcome of outcomes) {
        const allBooks: { bookmaker: string; odds: number }[] = [];
        let bestBookmaker = "";
        let bestOddsValue = -Infinity;

        for (const { bookmaker, market } of bookmakersByMarket) {
          const outcomeData = market!.outcomes.find((o) => o.name === outcome);
          if (outcomeData) {
            allBooks.push({ bookmaker, odds: outcomeData.price });
            if (outcomeData.price > bestOddsValue) {
              bestOddsValue = outcomeData.price;
              bestBookmaker = bookmaker;
            }
          }
        }

        if (allBooks.length > 0) {
          bestOdds.push({
            eventId: event.id,
            market: marketKey,
            outcome,
            bestBookmaker,
            bestOdds: bestOddsValue,
            allBooks: allBooks.sort((a, b) => b.odds - a.odds),
          });
        }
      }
    }
  }

  return bestOdds;
}

// Detect steam moves (sharp money) by tracking rapid line movements
export function detectSteamMoves(
  currentOdds: OddsEvent[],
  historicalOdds: HistoricalOdds[]
): SteamMove[] {
  const steamMoves: SteamMove[] = [];
  const STEAM_THRESHOLD = 1.5; // Point movement threshold
  const TIME_WINDOW = 3600000; // 1 hour in ms

  for (const event of currentOdds) {
    const eventHistory = historicalOdds.filter((h) => h.eventId === event.id);
    if (eventHistory.length < 2) continue;

    for (const marketKey of ["spreads", "totals"] as const) {
      const currentMarkets = event.bookmakers
        .map((b) => ({
          bookmaker: b.key,
          market: b.markets.find((m) => m.key === marketKey),
        }))
        .filter((b) => b.market != null);

      for (const { bookmaker } of currentMarkets) {
        const recentHistory = eventHistory
          .filter((h) => h.bookmaker === bookmaker && h.market === marketKey)
          .sort((a, b) => b.timestamp - a.timestamp)
          .slice(0, 10);

        if (recentHistory.length < 2) continue;

        const latest = recentHistory[0];
        const previous = recentHistory.find((h) => h.timestamp < Date.now() - TIME_WINDOW);

        if (previous && latest.odds[0].point != null && previous.odds[0].point != null) {
          const movement = Math.abs(latest.odds[0].point - previous.odds[0].point);

          if (movement >= STEAM_THRESHOLD) {
            // Check if multiple books moved simultaneously
            const simultaneousBooks = currentMarkets.filter((cm) => {
              const cmHistory = eventHistory
                .filter((h) => h.bookmaker === cm.bookmaker && h.market === marketKey)
                .sort((a, b) => b.timestamp - a.timestamp);

              if (cmHistory.length < 2) return false;

              const cmLatest = cmHistory[0];
              const cmPrevious = cmHistory.find((h) => h.timestamp < Date.now() - TIME_WINDOW);

              if (cmPrevious && cmLatest.odds[0].point != null && cmPrevious.odds[0].point != null) {
                const cmMovement = Math.abs(cmLatest.odds[0].point - cmPrevious.odds[0].point);
                return cmMovement >= STEAM_THRESHOLD;
              }
              return false;
            }).map((cm) => cm.bookmaker);

            const confidence: "high" | "medium" | "low" =
              simultaneousBooks.length >= 5 ? "high" : simultaneousBooks.length >= 3 ? "medium" : "low";

            steamMoves.push({
              id: `steam-${event.id}-${marketKey}-${bookmaker}-${Date.now()}`,
              eventId: event.id,
              sport: event.sport_title,
              homeTeam: event.home_team,
              awayTeam: event.away_team,
              market: marketKey,
              detectedAt: Date.now(),
              bookmakers: simultaneousBooks,
              originalLine: previous.odds[0].point,
              newLine: latest.odds[0].point,
              movement,
              confidence,
            });
          }
        }
      }
    }
  }

  return steamMoves;
}

// Track line movements over time
export function trackLineMovements(currentOdds: OddsEvent[], historicalOdds: HistoricalOdds[]): LineMovement[] {
  const movements: LineMovement[] = [];

  for (const event of currentOdds) {
    const eventHistory = historicalOdds.filter((h) => h.eventId === event.id);

    for (const marketKey of ["h2h", "spreads", "totals"] as const) {
      const movementData: LineMovement = {
        eventId: event.id,
        sport: event.sport_title,
        homeTeam: event.home_team,
        awayTeam: event.away_team,
        market: marketKey,
        movements: [],
      };

      const bookmakers = event.bookmakers.map((b) => b.key);

      for (const bookmaker of bookmakers) {
        const bookHistory = eventHistory
          .filter((h) => h.bookmaker === bookmaker && h.market === marketKey)
          .sort((a, b) => a.timestamp - b.timestamp);

        for (let i = 1; i < bookHistory.length; i++) {
          const prev = bookHistory[i - 1];
          const curr = bookHistory[i];

          // For spreads/totals, track point changes
          if ((marketKey === "spreads" || marketKey === "totals") && prev.odds[0].point != null && curr.odds[0].point != null) {
            if (prev.odds[0].point !== curr.odds[0].point) {
              movementData.movements.push({
                timestamp: curr.timestamp,
                bookmaker,
                oldValue: prev.odds[0].point,
                newValue: curr.odds[0].point,
                direction: curr.odds[0].point > prev.odds[0].point ? "up" : "down",
              });
            }
          }

          // For moneyline, track price changes
          if (marketKey === "h2h" && prev.odds[0].price !== curr.odds[0].price) {
            movementData.movements.push({
              timestamp: curr.timestamp,
              bookmaker,
              oldValue: prev.odds[0].price,
              newValue: curr.odds[0].price,
              direction: curr.odds[0].price > prev.odds[0].price ? "up" : "down",
            });
          }
        }
      }

      if (movementData.movements.length > 0) {
        movements.push(movementData);
      }
    }
  }

  return movements;
}
