import type {
  LoggedBet,
  OddsBucketId,
  OddsBucketStats,
  LineBucketId,
  LineBucketStats,
  SportBetTypeStats,
  TimeBucket,
  TimelinePoint
} from "./types";

export function bucketOdds(decimalOdds: number): OddsBucketId {
  if (decimalOdds <= 1.5) return "short_fave";
  if (decimalOdds <= 1.8) return "med_fave";
  if (decimalOdds <= 2.2) return "coinflip";
  if (decimalOdds <= 3.5) return "small_dog";
  return "longshot";
}

export function oddsBucketLabel(id: OddsBucketId): string {
  const labels: Record<OddsBucketId, string> = {
    short_fave: "Short favorites",
    med_fave: "Medium favorites",
    coinflip: "Coinflip range",
    small_dog: "Small underdogs",
    longshot: "Longshots"
  };
  return labels[id];
}

export function bucketLine(lineNumber: number | null | undefined): LineBucketId {
  if (lineNumber == null) return "medium";

  const absLine = Math.abs(lineNumber);
  if (absLine <= 3) return "low";
  if (absLine <= 7) return "medium";
  if (absLine <= 14) return "high";
  return "extreme";
}

export function lineBucketLabel(id: LineBucketId): string {
  const labels: Record<LineBucketId, string> = {
    low: "Low lines (≤3)",
    medium: "Medium (3.5–7)",
    high: "High (7.5–14)",
    extreme: "Extreme (14+)"
  };
  return labels[id];
}

export function buildOddsBuckets(bets: LoggedBet[]): OddsBucketStats[] {
  const map = new Map<OddsBucketId, OddsBucketStats>();

  for (const bet of bets) {
    const bucketId = bucketOdds(bet.decimalOdds);
    const existing = map.get(bucketId) || {
      id: bucketId,
      label: oddsBucketLabel(bucketId),
      bets: 0,
      profitLoss: 0,
      roiPct: 0,
      wins: 0,
      losses: 0,
      pushes: 0
    };

    existing.bets++;
    existing.profitLoss += bet.profitLoss;

    if (bet.outcome === "win") existing.wins++;
    if (bet.outcome === "loss") existing.losses++;
    if (bet.outcome === "push") existing.pushes++;

    map.set(bucketId, existing);
  }

  for (const [id, row] of map.entries()) {
    const totalStake = bets
      .filter(b => bucketOdds(b.decimalOdds) === id)
      .reduce((acc, b) => acc + b.stake, 0);
    row.roiPct = totalStake > 0 ? (row.profitLoss / totalStake) * 100 : 0;
    map.set(id, row);
  }

  return Array.from(map.values());
}

export function buildLineBuckets(bets: LoggedBet[]): LineBucketStats[] {
  const map = new Map<LineBucketId, LineBucketStats>();

  for (const bet of bets.filter(b => b.betType === "spread" || b.betType === "total")) {
    const bucketId = bucketLine(bet.lineNumber);
    const existing = map.get(bucketId) || {
      id: bucketId,
      label: lineBucketLabel(bucketId),
      bets: 0,
      profitLoss: 0,
      roiPct: 0
    };

    existing.bets++;
    existing.profitLoss += bet.profitLoss;

    map.set(bucketId, existing);
  }

  for (const [id, row] of map.entries()) {
    const totalStake = bets
      .filter(b => (b.betType === "spread" || b.betType === "total") && bucketLine(b.lineNumber) === id)
      .reduce((acc, b) => acc + b.stake, 0);
    row.roiPct = totalStake > 0 ? (row.profitLoss / totalStake) * 100 : 0;
    map.set(id, row);
  }

  return Array.from(map.values());
}

export function buildSportBetTypeStats(bets: LoggedBet[]): SportBetTypeStats[] {
  const map = new Map<string, SportBetTypeStats>();

  for (const bet of bets) {
    const key = `${bet.sport}|${bet.betType}`;
    const existing = map.get(key) || {
      sport: bet.sport,
      betType: bet.betType,
      bets: 0,
      profitLoss: 0,
      roiPct: 0,
      winRate: 0
    };

    existing.bets++;
    existing.profitLoss += bet.profitLoss;

    map.set(key, existing);
  }

  for (const [key, row] of map.entries()) {
    const [sport, betType] = key.split("|");
    const subset = bets.filter(b => b.sport === sport && b.betType === betType);

    const totalStake = subset.reduce((acc, b) => acc + b.stake, 0);
    const wins = subset.filter(b => b.outcome === "win").length;
    const losses = subset.filter(b => b.outcome === "loss").length;

    row.roiPct = totalStake > 0 ? (row.profitLoss / totalStake) * 100 : 0;
    row.winRate = (wins + losses) > 0 ? wins / (wins + losses) : 0;

    map.set(key, row);
  }

  return Array.from(map.values());
}

export function buildTimeline(bets: LoggedBet[], bucket: TimeBucket): TimelinePoint[] {
  const map = new Map<string, number>();

  for (const bet of bets) {
    const d = new Date(bet.placedAt);
    let key: string;
    if (bucket === "day") {
      key = d.toISOString().slice(0, 10); // YYYY-MM-DD
    } else {
      const year = d.getUTCFullYear();
      const firstDay = new Date(Date.UTC(year, 0, 1));
      const week = Math.ceil((((d.getTime() - firstDay.getTime()) / 86400000) + firstDay.getUTCDay() + 1) / 7);
      key = `${year}-W${week}`;
    }
    const prev = map.get(key) || 0;
    map.set(key, prev + bet.profitLoss);
  }

  return Array.from(map.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([label, net]) => ({ label, net }));
}

export function americanToDecimal(american: number): number {
  if (american > 0) {
    return (american / 100) + 1;
  } else {
    return (100 / Math.abs(american)) + 1;
  }
}

export function decimalToAmerican(decimal: number): number {
  if (decimal >= 2) {
    return Math.round((decimal - 1) * 100);
  } else {
    return Math.round(-100 / (decimal - 1));
  }
}

export function calculateProfitLoss(
  stake: number,
  decimalOdds: number,
  outcome: string
): number {
  if (outcome === "win") {
    return stake * (decimalOdds - 1);
  } else if (outcome === "loss") {
    return -stake;
  } else {
    return 0; // push
  }
}
