export type OddsFormat = "american" | "decimal";
export type BetOutcome = "win" | "loss" | "push";
export type BetType = "moneyline" | "spread" | "total" | "prop" | "parlay";

export interface LoggedBet {
  id: string;
  placedAt: number;          // timestamp
  sport: string;             // "NFL", "NBA", "NCAAB", etc.
  league: string;            // "AFC", "La Liga", "Big Ten", etc.
  betType: BetType;          // ML / spread / total / prop / parlay
  description: string;       // "Lakers -3.5 vs Suns"

  oddsFormat: OddsFormat;
  inputOdds: number;         // -110 or 1.91
  decimalOdds: number;

  lineNumber: number | null;   // e.g. -3.5 spread, 221.5 total, etc.
  stake: number;
  outcome: BetOutcome;
  profitLoss: number;        // + for win, - for loss, 0 for push
}

export type OddsBucketId =
  | "short_fave"
  | "med_fave"
  | "coinflip"
  | "small_dog"
  | "longshot";

export interface OddsBucketStats {
  id: OddsBucketId;
  label: string;       // "Short faves", "Coinflips", etc.
  bets: number;
  profitLoss: number;
  roiPct: number;      // profitLoss / total_staked_in_bucket * 100
  wins: number;
  losses: number;
  pushes: number;
}

export type LineBucketId = "low" | "medium" | "high" | "extreme";

export interface LineBucketStats {
  id: LineBucketId;
  label: string;
  bets: number;
  profitLoss: number;
  roiPct: number;
}

export interface SportBetTypeStats {
  sport: string;
  betType: BetType;
  bets: number;
  profitLoss: number;
  roiPct: number;
  winRate: number;
}

export type TimeBucket = "day" | "week";

export interface TimelinePoint {
  label: string;       // e.g. "2025-12-09" or "2025-W50"
  net: number;
}
