use spacetimedb::{table, reducer, ReducerContext, Identity, Table, Timestamp, SpacetimeType};
use spacetimedb::log;

#[derive(SpacetimeType, Clone, Debug, PartialEq, Eq)]
pub enum SourceType {
    Exa,
    Perplexity,
    Firecrawl,
    Other(String),
}

#[derive(SpacetimeType, Clone, Debug, PartialEq, Eq)]
pub enum NoteCategory {
    Insight,
    Finding,
    Annotation,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq, Eq)]
pub enum CollaborationRole {
    Owner,
    Editor,
    Viewer,
}

#[table(name = research_project, public)]
#[derive(Clone)]
pub struct ResearchProject {
    #[primary_key]
    #[auto_inc]
    project_id: u64,
    title: String,
    description: String,
    created_by: Identity,
    created_at: Timestamp,
}

#[table(name = research_query, public)]
#[derive(Clone)]
pub struct ResearchQuery {
    #[primary_key]
    #[auto_inc]
    query_id: u64,
    #[index(btree)]
    project_id: u64,
    search_terms: String,
    source_type: SourceType,
    results_summary: String,
    submitted_by: Identity,
    created_at: Timestamp,
}

#[table(name = research_note, public)]
#[derive(Clone)]
pub struct ResearchNote {
    #[primary_key]
    #[auto_inc]
    note_id: u64,
    #[index(btree)]
    project_id: u64,
    headline: String,
    body: String,
    category: NoteCategory,
    author: Identity,
    created_at: Timestamp,
}

#[table(
    name = collaboration_member,
    public,
    index(name = project_member_idx, btree(columns = [project_id, member_identity]))
)]
#[derive(Clone)]
pub struct CollaborationMember {
    #[primary_key]
    #[auto_inc]
    membership_id: u64,
    project_id: u64,
    member_identity: Identity,
    role: CollaborationRole,
    joined_at: Timestamp,
}

#[reducer(init)]
pub fn init(ctx: &ReducerContext) -> Result<(), String> {
    let micros = ctx.timestamp.to_micros_since_unix_epoch();
    log::info!("Collaborative research module initialized at {}", micros);
    Ok(())
}

#[reducer(client_connected)]
pub fn identity_connected(ctx: &ReducerContext) {
    log::info!("Research collaborator {} connected.", ctx.sender);
}

#[reducer(client_disconnected)]
pub fn identity_disconnected(ctx: &ReducerContext) {
    log::info!("Research collaborator {} disconnected.", ctx.sender);
}

#[reducer]
pub fn create_research_project(
    ctx: &ReducerContext,
    title: String,
    description: String,
) -> Result<(), String> {
    let normalized_title = title.trim().to_string();
    if normalized_title.is_empty() {
        return Err("Project title cannot be empty.".to_string());
    }

    let normalized_description = description.trim().to_string();
    if normalized_description.is_empty() {
        return Err("Project description cannot be empty.".to_string());
    }

    let new_project = ResearchProject {
        project_id: 0,
        title: normalized_title.clone(),
        description: normalized_description.clone(),
        created_by: ctx.sender,
        created_at: ctx.timestamp,
    };

    match ctx.db.research_project().try_insert(new_project) {
        Ok(inserted_project) => {
            let project_id = inserted_project.project_id;
            let owner_membership = CollaborationMember {
                membership_id: 0,
                project_id,
                member_identity: ctx.sender,
                role: CollaborationRole::Owner,
                joined_at: ctx.timestamp,
            };

            match ctx.db.collaboration_member().try_insert(owner_membership) {
                Ok(_) => {
                    log::info!(
                        "Project '{}' ({}) created by {}.",
                        normalized_title,
                        project_id,
                        ctx.sender
                    );
                    Ok(())
                }
                Err(e) => {
                    let err_msg = format!(
                        "Project {} created but failed to add owner membership: {}",
                        project_id, e
                    );
                    log::error!("{}", err_msg);
                    Err(err_msg)
                }
            }
        }
        Err(e) => {
            let err_msg = format!("Failed to create research project: {}", e);
            log::error!("{}", err_msg);
            Err(err_msg)
        }
    }
}

#[reducer]
pub fn join_research_project(ctx: &ReducerContext, project_id: u64) -> Result<(), String> {
    let project = ensure_project_exists(ctx, project_id)?;
    let project_title = project.title.clone();

    if find_membership(ctx, project_id, ctx.sender).is_some() {
        return Err(format!(
            "Identity {} is already a member of project {}.",
            ctx.sender, project_id
        ));
    }

    let membership = CollaborationMember {
        membership_id: 0,
        project_id,
        member_identity: ctx.sender,
        role: CollaborationRole::Editor,
        joined_at: ctx.timestamp,
    };

    match ctx.db.collaboration_member().try_insert(membership) {
        Ok(_) => {
            log::info!(
                "{} joined project '{}' ({}) as Editor.",
                ctx.sender,
                project_title,
                project_id
            );
            Ok(())
        }
        Err(e) => {
            let err_msg = format!("Failed to join project {}: {}", project_id, e);
            log::error!("{}", err_msg);
            Err(err_msg)
        }
    }
}

#[reducer]
pub fn leave_research_project(ctx: &ReducerContext, project_id: u64) -> Result<(), String> {
    let membership = match find_membership(ctx, project_id, ctx.sender) {
        Some(m) => m,
        None => {
            return Err(format!(
                "Identity {} is not a collaborator on project {}.",
                ctx.sender, project_id
            ))
        }
    };

    let membership_id = membership.membership_id;
    let role_label = format!("{:?}", membership.role);

    ctx.db
        .collaboration_member()
        .membership_id()
        .delete(membership_id);

    log::info!(
        "{} left project {} (previous role: {}).",
        ctx.sender,
        project_id,
        role_label
    );
    Ok(())
}

#[reducer]
pub fn add_research_query(
    ctx: &ReducerContext,
    project_id: u64,
    search_terms: String,
    source_type: SourceType,
    results_summary: String,
) -> Result<(), String> {
    let project = ensure_project_exists(ctx, project_id)?;
    ensure_collaborator(ctx, project_id, ctx.sender)?;

    let sanitized_terms = search_terms.trim().to_string();
    if sanitized_terms.is_empty() {
        return Err("Search terms cannot be empty.".to_string());
    }

    let sanitized_summary = results_summary.trim().to_string();
    if sanitized_summary.is_empty() {
        return Err("Results summary cannot be empty.".to_string());
    }

    let source_label = format!("{:?}", source_type);

    let query = ResearchQuery {
        query_id: 0,
        project_id,
        search_terms: sanitized_terms.clone(),
        source_type,
        results_summary: sanitized_summary.clone(),
        submitted_by: ctx.sender,
        created_at: ctx.timestamp,
    };

    match ctx.db.research_query().try_insert(query) {
        Ok(inserted_query) => {
            log::info!(
                "{} recorded query {} for project '{}' ({}) via {}.",
                ctx.sender,
                inserted_query.query_id,
                project.title,
                project.project_id,
                source_label
            );
            Ok(())
        }
        Err(e) => {
            let err_msg = format!("Failed to insert research query: {}", e);
            log::error!("{}", err_msg);
            Err(err_msg)
        }
    }
}

#[reducer]
pub fn add_research_note(
    ctx: &ReducerContext,
    project_id: u64,
    headline: String,
    body: String,
    category: NoteCategory,
) -> Result<(), String> {
    let project = ensure_project_exists(ctx, project_id)?;
    ensure_collaborator(ctx, project_id, ctx.sender)?;

    let trimmed_headline = headline.trim().to_string();
    if trimmed_headline.is_empty() {
        return Err("Note headline cannot be empty.".to_string());
    }

    let trimmed_body = body.trim().to_string();
    if trimmed_body.is_empty() {
        return Err("Note body cannot be empty.".to_string());
    }

    let category_label = format!("{:?}", category);

    let note = ResearchNote {
        note_id: 0,
        project_id,
        headline: trimmed_headline.clone(),
        body: trimmed_body.clone(),
        category,
        author: ctx.sender,
        created_at: ctx.timestamp,
    };

    match ctx.db.research_note().try_insert(note) {
        Ok(inserted_note) => {
            log::info!(
                "{} added note {} ({}) to project '{}' ({}).",
                ctx.sender,
                inserted_note.note_id,
                category_label,
                project.title,
                project.project_id
            );
            Ok(())
        }
        Err(e) => {
            let err_msg = format!("Failed to insert research note: {}", e);
            log::error!("{}", err_msg);
            Err(err_msg)
        }
    }
}

fn ensure_project_exists(ctx: &ReducerContext, project_id: u64) -> Result<ResearchProject, String> {
    ctx.db
        .research_project()
        .project_id()
        .find(project_id)
        .ok_or_else(|| format!("Research project {} does not exist.", project_id))
}

fn find_membership(
    ctx: &ReducerContext,
    project_id: u64,
    identity: Identity,
) -> Option<CollaborationMember> {
    ctx.db
        .collaboration_member()
        .iter()
        .find(|membership| membership.project_id == project_id && membership.member_identity == identity)
}

fn ensure_collaborator(
    ctx: &ReducerContext,
    project_id: u64,
    identity: Identity,
) -> Result<(), String> {
    if find_membership(ctx, project_id, identity).is_some() {
        Ok(())
    } else {
        Err(format!(
            "Identity {} is not authorized for project {}.",
            identity, project_id
        ))
    }
}