'use client'
import { useState, useEffect } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Search, Brain, Globe, Cloud, Users, Lightbulb, Plus } from 'lucide-react'

import { ProjectOverview } from '@/components/research/ProjectOverview'
import { AISearchPanel } from '@/components/research/AISearchPanel'  
import { AIAnalysisPanel } from '@/components/research/AIAnalysisPanel'
import { WebScraperPanel } from '@/components/research/WebScraperPanel'
import { WeatherPanel } from '@/components/research/WeatherPanel'
import { CollaborationPanel } from '@/components/research/CollaborationPanel'
import { ConnectionStatus } from '@/components/research/ConnectionStatus'
import { useSpacetimeDB } from '@/hooks/useSpacetimeDB'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

interface TabInfo {
  id: string
  label: string
  icon: React.ElementType
  description: string
  color: string
}

const researchTabs: TabInfo[] = [
  {
    id: 'overview',
    label: 'Projects',
    icon: Lightbulb,
    description: 'Manage research projects and track progress',
    color: 'bg-blue-500'
  },
  {
    id: 'search',
    label: 'AI Search',
    icon: Search,
    description: 'Discover relevant content across the web',
    color: 'bg-green-500'
  },
  {
    id: 'analysis',
    label: 'AI Analysis',
    icon: Brain,
    description: 'Get intelligent insights with citations',
    color: 'bg-purple-500'
  },
  {
    id: 'scraper',
    label: 'Web Scraper',
    icon: Globe,
    description: 'Deep analysis of specific websites',
    color: 'bg-orange-500'
  },
  {
    id: 'weather',
    label: 'Weather Context',
    icon: Cloud,
    description: 'Location-based environmental data',
    color: 'bg-cyan-500'
  },
  {
    id: 'collaborate',
    label: 'Collaborate',
    icon: Users,
    description: 'Real-time team research sessions',
    color: 'bg-pink-500'
  }
]

export default function ResearchHub(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [activeTab, setActiveTab] = useState<string>('overview')
  const [selectedProject, setSelectedProject] = useState<number | null>(null)
  const { connected, identity, statusMessage } = useSpacetimeDB()

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-black/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                  <Search className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold">Research Intelligence Hub</h1>
                  <p className="text-sm text-gray-400">Function drives creativity</p>
                </div>
              </div>
              <Badge variant="outline" className="border-blue-500/20 bg-blue-500/10 text-blue-400">
                Builder Mode
              </Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <ConnectionStatus connected={connected} statusMessage={statusMessage} />
              {identity && (
                <Badge variant="outline" className="border-green-500/20 bg-green-500/10 text-green-400">
                  {identity.toHexString().slice(0, 8)}...
                </Badge>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Research Any Problem, Build Better Solutions</h2>
          <p className="text-gray-400 text-lg">
            Combine AI-powered search, intelligent analysis, web scraping, and real-time collaboration to research topics comprehensively.
          </p>
        </div>

        {/* Research Tools */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          {/* Tab Navigation */}
          <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6 gap-2 bg-gray-900/50 p-2">
            {researchTabs.map((tab) => (
              <TabsTrigger
                key={tab.id}
                value={tab.id}
                className="flex flex-col items-center space-y-1 p-3 rounded-lg data-[state=active]:bg-white/10 data-[state=active]:text-white"
              >
                <div className={`w-8 h-8 rounded-md ${tab.color}/20 flex items-center justify-center`}>
                  <tab.icon className={`w-4 h-4 text-white`} />
                </div>
                <span className="text-xs font-medium">{tab.label}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {/* Tab Content */}
          <div className="mt-6">
            <TabsContent value="overview" className="mt-0">
              <Card className="bg-gray-900/50 border-gray-800">
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Lightbulb className="w-5 h-5 text-blue-400" />
                    <CardTitle className="text-white">Research Projects</CardTitle>
                  </div>
                  <CardDescription className="text-gray-400">
                    Create, organize, and manage your research initiatives
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ProjectOverview 
                    connected={connected}
                    selectedProject={selectedProject}
                    onSelectProject={setSelectedProject}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="search" className="mt-0">
              <Card className="bg-gray-900/50 border-gray-800">
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Search className="w-5 h-5 text-green-400" />
                    <CardTitle className="text-white">AI-Powered Web Search</CardTitle>
                  </div>
                  <CardDescription className="text-gray-400">
                    Discover relevant content across the web using Exa's semantic search
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <AISearchPanel selectedProject={selectedProject} connected={connected} />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analysis" className="mt-0">
              <Card className="bg-gray-900/50 border-gray-800">
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Brain className="w-5 h-5 text-purple-400" />
                    <CardTitle className="text-white">AI Analysis & Insights</CardTitle>
                  </div>
                  <CardDescription className="text-gray-400">
                    Get intelligent answers and analysis with source citations using Perplexity AI
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <AIAnalysisPanel selectedProject={selectedProject} connected={connected} />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="scraper" className="mt-0">
              <Card className="bg-gray-900/50 border-gray-800">
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Globe className="w-5 h-5 text-orange-400" />
                    <CardTitle className="text-white">Website Analysis</CardTitle>
                  </div>
                  <CardDescription className="text-gray-400">
                    Deep scraping and analysis of specific websites using Firecrawl
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <WebScraperPanel selectedProject={selectedProject} connected={connected} />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="weather" className="mt-0">
              <Card className="bg-gray-900/50 border-gray-800">
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Cloud className="w-5 h-5 text-cyan-400" />
                    <CardTitle className="text-white">Weather Context</CardTitle>
                  </div>
                  <CardDescription className="text-gray-400">
                    Get current weather data to inform location-based research
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <WeatherPanel selectedProject={selectedProject} connected={connected} />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="collaborate" className="mt-0">
              <Card className="bg-gray-900/50 border-gray-800">
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Users className="w-5 h-5 text-pink-400" />
                    <CardTitle className="text-white">Team Collaboration</CardTitle>
                  </div>
                  <CardDescription className="text-gray-400">
                    Real-time collaborative research with your team
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <CollaborationPanel selectedProject={selectedProject} connected={connected} />
                </CardContent>
              </Card>
            </TabsContent>
          </div>
        </Tabs>

        {/* Quick Actions */}
        {!selectedProject && (
          <div className="mt-12 text-center">
            <Card className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 border-blue-500/20">
              <CardContent className="p-8">
                <div className="mb-4">
                  <Plus className="w-12 h-12 text-blue-400 mx-auto mb-2" />
                  <h3 className="text-xl font-semibold text-white mb-2">Get Started</h3>
                  <p className="text-gray-400">
                    Create your first research project to start using the intelligence tools
                  </p>
                </div>
                <Button
                  onClick={() => setActiveTab('overview')}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  Create Research Project
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  )
}