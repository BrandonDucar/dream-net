'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Brain, ExternalLink, CheckCircle, AlertCircle, Loader2, BookOpen } from 'lucide-react'
import { 
  perplexityResearch, 
  perplexityFactCheck, 
  perplexityChat,
  perplexityExtractCitations,
  perplexityGetAnswer 
} from '@/perplexity-api'
import type { PerplexityResearchResponse } from '@/perplexity-api'
import { useSpacetimeDB } from '@/hooks/useSpacetimeDB'
import { reducers, SourceType } from '@/spacetime_module_bindings'

interface AIAnalysisPanelProps {
  selectedProject: number | null
  connected: boolean
}

export function AIAnalysisPanel({ selectedProject, connected }: AIAnalysisPanelProps): JSX.Element {
  const [researchQuery, setResearchQuery] = useState<string>('')
  const [factCheckClaim, setFactCheckClaim] = useState<string>('')
  const [chatQuery, setChatQuery] = useState<string>('')
  
  const [researchResult, setResearchResult] = useState<PerplexityResearchResponse | null>(null)
  const [factCheckResult, setFactCheckResult] = useState<PerplexityResearchResponse | null>(null)
  const [chatResult, setChatResult] = useState<PerplexityResearchResponse | null>(null)
  
  const [loading, setLoading] = useState<{ [key: string]: boolean }>({
    research: false,
    factCheck: false,
    chat: false
  })

  const { connection } = useSpacetimeDB()

  const handleResearch = async (): Promise<void> => {
    if (!researchQuery.trim() || loading.research) return

    setLoading(prev => ({ ...prev, research: true }))
    try {
      const response = await perplexityResearch(researchQuery, {
        temperature: 0.2,
        max_tokens: 4000
      })

      setResearchResult(response)

      // Save to project if one is selected
      if (selectedProject && connection) {
        const citationCount = response.citations?.length || 0
        const resultsSummary = `Research analysis completed with ${citationCount} citations. ${
          response.answer.length > 100 
            ? response.answer.substring(0, 100) + '...' 
            : response.answer
        }`

        await connection.reducers.addResearchQuery({
          projectId: selectedProject,
          searchTerms: researchQuery,
          sourceType: { Perplexity: null },
          resultsSummary
        })
      }
    } catch (error) {
      console.error('Research failed:', error)
      setResearchResult(null)
    }
    setLoading(prev => ({ ...prev, research: false }))
  }

  const handleFactCheck = async (): Promise<void> => {
    if (!factCheckClaim.trim() || loading.factCheck) return

    setLoading(prev => ({ ...prev, factCheck: true }))
    try {
      const response = await perplexityFactCheck(factCheckClaim, {
        temperature: 0.1,
        max_tokens: 2000
      })

      setFactCheckResult(response)

      // Save to project if one is selected
      if (selectedProject && connection) {
        const citationCount = response.citations?.length || 0
        const resultsSummary = `Fact-check completed with ${citationCount} verification sources. ${
          response.answer.length > 100 
            ? response.answer.substring(0, 100) + '...' 
            : response.answer
        }`

        await connection.reducers.addResearchQuery({
          projectId: selectedProject,
          searchTerms: `Fact-check: ${factCheckClaim}`,
          sourceType: { Perplexity: null },
          resultsSummary
        })
      }
    } catch (error) {
      console.error('Fact check failed:', error)
      setFactCheckResult(null)
    }
    setLoading(prev => ({ ...prev, factCheck: false }))
  }

  const handleChat = async (): Promise<void> => {
    if (!chatQuery.trim() || loading.chat) return

    setLoading(prev => ({ ...prev, chat: true }))
    try {
      const response = await perplexityChat({
        model: 'sonar',
        messages: [
          {
            role: 'system',
            content: 'You are a helpful research assistant. Provide accurate, well-sourced answers with proper citations.'
          },
          {
            role: 'user',
            content: chatQuery
          }
        ],
        temperature: 0.3,
        max_tokens: 3000
      })

      const answer = perplexityGetAnswer(response)
      const citations = perplexityExtractCitations(response)

      setChatResult({
        answer,
        citations,
        usage: response.usage,
        model: response.model
      })

      // Save to project if one is selected
      if (selectedProject && connection) {
        const citationCount = citations?.length || 0
        const resultsSummary = `AI chat response with ${citationCount} citations. ${
          answer.length > 100 
            ? answer.substring(0, 100) + '...' 
            : answer
        }`

        await connection.reducers.addResearchQuery({
          projectId: selectedProject,
          searchTerms: `Chat: ${chatQuery}`,
          sourceType: { Perplexity: null },
          resultsSummary
        })
      }
    } catch (error) {
      console.error('Chat failed:', error)
      setChatResult(null)
    }
    setLoading(prev => ({ ...prev, chat: false }))
  }

  const renderResult = (
    result: PerplexityResearchResponse | null, 
    type: 'research' | 'factCheck' | 'chat'
  ) => {
    if (!result) return null

    const isFactCheck = type === 'factCheck'
    const iconColor = isFactCheck ? 'text-green-500' : 'text-purple-500'
    const Icon = isFactCheck ? CheckCircle : Brain

    return (
      <Card className="bg-gray-800/30 border-gray-700 mt-4">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Icon className={`w-4 h-4 ${iconColor}`} />
              <CardTitle className="text-white text-sm">
                {isFactCheck ? 'Fact Check Result' : type === 'chat' ? 'AI Response' : 'Research Analysis'}
              </CardTitle>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="border-purple-500/20 bg-purple-500/10 text-purple-400 text-xs">
                {result.model}
              </Badge>
              {result.citations && (
                <Badge variant="outline" className="border-blue-500/20 bg-blue-500/10 text-blue-400 text-xs">
                  {result.citations.length} sources
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Answer */}
          <div className="prose prose-sm max-w-none">
            <div className="text-gray-300 leading-relaxed whitespace-pre-wrap">
              {result.answer}
            </div>
          </div>

          {/* Citations */}
          {result.citations && result.citations.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <BookOpen className="w-4 h-4 text-blue-400" />
                <h4 className="text-sm font-medium text-blue-400">Sources & Citations</h4>
              </div>
              <div className="space-y-2">
                {result.citations.map((citation, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-blue-900/10 border border-blue-500/20 rounded-lg"
                  >
                    <div className="flex-1">
                      <p className="text-blue-300 text-sm font-medium truncate">
                        Source {index + 1}
                      </p>
                      <p className="text-gray-400 text-xs truncate">
                        {citation}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      asChild
                      className="ml-2 h-8 w-8 p-0 hover:bg-blue-800/20"
                    >
                      <a href={citation} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Usage Stats */}
          {result.usage && (
            <div className="flex justify-between items-center text-xs text-gray-500 pt-2 border-t border-gray-700">
              <span>Tokens: {result.usage.total_tokens}</span>
              <span>Model: {result.model}</span>
            </div>
          )}
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Project Status */}
      {selectedProject ? (
        <div className="bg-green-900/20 border border-green-500/20 rounded-lg p-3">
          <p className="text-green-400 text-sm">
            ✅ Analysis results will be automatically saved to Project {selectedProject}
          </p>
        </div>
      ) : (
        <div className="bg-yellow-900/20 border border-yellow-500/20 rounded-lg p-3">
          <p className="text-yellow-400 text-sm">
            ⚠️ Select a project from the Projects tab to save analysis results
          </p>
        </div>
      )}

      {/* Analysis Tools */}
      <Tabs defaultValue="research" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3 bg-gray-800/50">
          <TabsTrigger value="research" className="data-[state=active]:bg-purple-600/20">
            Research Analysis
          </TabsTrigger>
          <TabsTrigger value="factcheck" className="data-[state=active]:bg-green-600/20">
            Fact Checking
          </TabsTrigger>
          <TabsTrigger value="chat" className="data-[state=active]:bg-blue-600/20">
            AI Chat
          </TabsTrigger>
        </TabsList>

        <TabsContent value="research" className="space-y-4">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center space-x-2">
                <Brain className="w-4 h-4 text-purple-400" />
                <span>Deep Research Analysis</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={researchQuery}
                onChange={(e) => setResearchQuery(e.target.value)}
                placeholder="Analyze the impact of large language models on software development productivity and code quality..."
                rows={3}
                className="bg-gray-900 border-gray-600 text-white"
              />
              <Button
                onClick={handleResearch}
                disabled={!researchQuery.trim() || loading.research}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white"
              >
                {loading.research ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    Researching...
                  </>
                ) : (
                  <>
                    <Brain className="w-4 h-4 mr-2" />
                    Research & Analyze
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
          {renderResult(researchResult, 'research')}
        </TabsContent>

        <TabsContent value="factcheck" className="space-y-4">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span>Fact Verification</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                value={factCheckClaim}
                onChange={(e) => setFactCheckClaim(e.target.value)}
                placeholder="AI has reduced software development time by 50% industry-wide"
                className="bg-gray-900 border-gray-600 text-white"
                onKeyPress={(e) => e.key === 'Enter' && handleFactCheck()}
              />
              <Button
                onClick={handleFactCheck}
                disabled={!factCheckClaim.trim() || loading.factCheck}
                className="w-full bg-green-600 hover:bg-green-700 text-white"
              >
                {loading.factCheck ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    Checking...
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Verify Claim
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
          {renderResult(factCheckResult, 'factCheck')}
        </TabsContent>

        <TabsContent value="chat" className="space-y-4">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center space-x-2">
                <Brain className="w-4 h-4 text-blue-400" />
                <span>AI Assistant Chat</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                value={chatQuery}
                onChange={(e) => setChatQuery(e.target.value)}
                placeholder="What are the latest trends in TypeScript development?"
                className="bg-gray-900 border-gray-600 text-white"
                onKeyPress={(e) => e.key === 'Enter' && handleChat()}
              />
              <Button
                onClick={handleChat}
                disabled={!chatQuery.trim() || loading.chat}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              >
                {loading.chat ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    Thinking...
                  </>
                ) : (
                  <>
                    <Brain className="w-4 h-4 mr-2" />
                    Ask AI
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
          {renderResult(chatResult, 'chat')}
        </TabsContent>
      </Tabs>

      {/* Empty State */}
      {!researchResult && !factCheckResult && !chatResult && (
        <div className="text-center py-12">
          <Brain className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-300 mb-2">AI-Powered Analysis</h3>
          <p className="text-gray-500">
            Get intelligent insights, verify facts, and chat with AI using Perplexity's advanced models
          </p>
        </div>
      )}
    </div>
  )
}