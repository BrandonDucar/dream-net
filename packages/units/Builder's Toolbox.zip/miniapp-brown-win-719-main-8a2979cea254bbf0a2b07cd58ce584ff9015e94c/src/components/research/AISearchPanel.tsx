'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Search, ExternalLink, Calendar, Star, Globe, Loader2 } from 'lucide-react'
import { exaSearch, exaFindSimilar, exaContents } from '@/exa-api'
import type { ExaSearchResponse, ExaResult } from '@/exa-api'
import { useSpacetimeDB } from '@/hooks/useSpacetimeDB'
import { reducers, SourceType } from '@/spacetime_module_bindings'

interface AISearchPanelProps {
  selectedProject: number | null
  connected: boolean
}

export function AISearchPanel({ selectedProject, connected }: AISearchPanelProps): JSX.Element {
  const [searchQuery, setSearchQuery] = useState<string>('')
  const [searchResults, setSearchResults] = useState<ExaResult[]>([])
  const [loading, setLoading] = useState<boolean>(false)
  const [similarUrl, setSimilarUrl] = useState<string>('')
  const [contentUrls, setContentUrls] = useState<string>('')

  const { connection } = useSpacetimeDB()

  const handleWebSearch = async (): Promise<void> => {
    if (!searchQuery.trim() || loading) return

    setLoading(true)
    try {
      const response: ExaSearchResponse = await exaSearch({
        query: searchQuery,
        text: true
      })

      setSearchResults(response.results || [])

      // Save to project if one is selected
      if (selectedProject && connection) {
        const resultsSummary = `Found ${response.results?.length || 0} results for "${searchQuery}". ${
          response.results?.length ? `Top result: "${response.results[0].title}"` : 'No results found.'
        }`

        await connection.reducers.addResearchQuery({
          projectId: selectedProject,
          searchTerms: searchQuery,
          sourceType: { Exa: null },
          resultsSummary
        })
      }
    } catch (error) {
      console.error('Search failed:', error)
      setSearchResults([])
    }
    setLoading(false)
  }

  const handleFindSimilar = async (): Promise<void> => {
    if (!similarUrl.trim() || loading) return

    setLoading(true)
    try {
      const response = await exaFindSimilar({
        url: similarUrl,
        text: true
      })

      setSearchResults(response.results || [])

      // Save to project if one is selected
      if (selectedProject && connection) {
        const resultsSummary = `Found ${response.results?.length || 0} similar pages to "${similarUrl}"`

        await connection.reducers.addResearchQuery({
          projectId: selectedProject,
          searchTerms: `Similar to: ${similarUrl}`,
          sourceType: { Exa: null },
          resultsSummary
        })
      }
    } catch (error) {
      console.error('Similar search failed:', error)
      setSearchResults([])
    }
    setLoading(false)
  }

  const handleExtractContent = async (): Promise<void> => {
    if (!contentUrls.trim() || loading) return

    setLoading(true)
    try {
      const urls = contentUrls.split('\n').map(url => url.trim()).filter(Boolean)
      const response = await exaContents({
        urls,
        text: true
      })

      setSearchResults(response.results || [])

      // Save to project if one is selected
      if (selectedProject && connection) {
        const resultsSummary = `Extracted content from ${urls.length} URLs. ${
          response.results?.length ? `Successfully processed ${response.results.length} pages.` : 'No content extracted.'
        }`

        await connection.reducers.addResearchQuery({
          projectId: selectedProject,
          searchTerms: `Content extraction from ${urls.length} URLs`,
          sourceType: { Exa: null },
          resultsSummary
        })
      }
    } catch (error) {
      console.error('Content extraction failed:', error)
      setSearchResults([])
    }
    setLoading(false)
  }

  const formatDate = (dateStr: string): string => {
    if (!dateStr) return 'Unknown date'
    try {
      return new Date(dateStr).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
    } catch {
      return dateStr
    }
  }

  const truncateText = (text: string, maxLength: number): string => {
    if (text.length <= maxLength) return text
    return text.substring(0, maxLength) + '...'
  }

  return (
    <div className="space-y-6">
      {/* Search Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Web Search */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-white text-sm flex items-center space-x-2">
              <Search className="w-4 h-4" />
              <span>Web Search</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="quantum computing breakthroughs 2024"
              className="bg-gray-900 border-gray-600 text-white text-sm"
              onKeyPress={(e) => e.key === 'Enter' && handleWebSearch()}
            />
            <Button
              onClick={handleWebSearch}
              disabled={!searchQuery.trim() || loading}
              className="w-full bg-green-600 hover:bg-green-700 text-white text-sm"
              size="sm"
            >
              {loading ? <Loader2 className="w-3 h-3 animate-spin mr-2" /> : <Search className="w-3 h-3 mr-2" />}
              Search Web
            </Button>
          </CardContent>
        </Card>

        {/* Find Similar */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-white text-sm flex items-center space-x-2">
              <Globe className="w-4 h-4" />
              <span>Find Similar</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Input
              value={similarUrl}
              onChange={(e) => setSimilarUrl(e.target.value)}
              placeholder="https://arxiv.org/abs/2307.06435"
              className="bg-gray-900 border-gray-600 text-white text-sm"
              onKeyPress={(e) => e.key === 'Enter' && handleFindSimilar()}
            />
            <Button
              onClick={handleFindSimilar}
              disabled={!similarUrl.trim() || loading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white text-sm"
              size="sm"
            >
              {loading ? <Loader2 className="w-3 h-3 animate-spin mr-2" /> : <Globe className="w-3 h-3 mr-2" />}
              Find Similar
            </Button>
          </CardContent>
        </Card>

        {/* Extract Content */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-white text-sm flex items-center space-x-2">
              <ExternalLink className="w-4 h-4" />
              <span>Extract Content</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Textarea
              value={contentUrls}
              onChange={(e) => setContentUrls(e.target.value)}
              placeholder="https://example.com/page1&#10;https://example.com/page2"
              rows={2}
              className="bg-gray-900 border-gray-600 text-white text-sm"
            />
            <Button
              onClick={handleExtractContent}
              disabled={!contentUrls.trim() || loading}
              className="w-full bg-orange-600 hover:bg-orange-700 text-white text-sm"
              size="sm"
            >
              {loading ? <Loader2 className="w-3 h-3 animate-spin mr-2" /> : <ExternalLink className="w-3 h-3 mr-2" />}
              Extract
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Project Status */}
      {selectedProject ? (
        <div className="bg-green-900/20 border border-green-500/20 rounded-lg p-3">
          <p className="text-green-400 text-sm">
            ✅ Results will be automatically saved to Project {selectedProject}
          </p>
        </div>
      ) : (
        <div className="bg-yellow-900/20 border border-yellow-500/20 rounded-lg p-3">
          <p className="text-yellow-400 text-sm">
            ⚠️ Select a project from the Projects tab to save search results
          </p>
        </div>
      )}

      {/* Search Results */}
      {searchResults.length > 0 && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-white">Search Results</h3>
            <Badge variant="outline" className="border-green-500/20 bg-green-500/10 text-green-400">
              {searchResults.length} results
            </Badge>
          </div>

          <div className="space-y-3">
            {searchResults.map((result, index) => (
              <Card key={index} className="bg-gray-800/30 border-gray-700 hover:border-green-500/50 transition-colors">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="text-white font-medium text-sm line-clamp-2 flex-1">
                      {result.title || 'Untitled'}
                    </h4>
                    <div className="flex items-center space-x-2 ml-4">
                      {result.score && (
                        <div className="flex items-center space-x-1">
                          <Star className="w-3 h-3 text-yellow-500" />
                          <span className="text-xs text-gray-400">
                            {(result.score * 100).toFixed(1)}%
                          </span>
                        </div>
                      )}
                      {result.url && (
                        <Button
                          variant="ghost"
                          size="sm"
                          asChild
                          className="h-6 w-6 p-0 hover:bg-gray-700"
                        >
                          <a href={result.url} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </Button>
                      )}
                    </div>
                  </div>

                  {(result.author || result.publishedDate) && (
                    <div className="flex items-center space-x-4 mb-2 text-xs text-gray-500">
                      {result.author && (
                        <span>By {result.author}</span>
                      )}
                      {result.publishedDate && (
                        <div className="flex items-center space-x-1">
                          <Calendar className="w-3 h-3" />
                          <span>{formatDate(result.publishedDate)}</span>
                        </div>
                      )}
                    </div>
                  )}

                  {result.text && (
                    <p className="text-gray-300 text-xs leading-relaxed">
                      {truncateText(result.text, 300)}
                    </p>
                  )}

                  {result.highlights && result.highlights.length > 0 && (
                    <div className="mt-2 space-y-1">
                      <p className="text-xs font-medium text-gray-400">Key highlights:</p>
                      <div className="space-y-1">
                        {result.highlights.slice(0, 2).map((highlight, idx) => (
                          <p key={idx} className="text-xs text-blue-300 bg-blue-900/20 rounded px-2 py-1">
                            &quot;{truncateText(highlight, 150)}&quot;
                          </p>
                        ))}
                      </div>
                    </div>
                  )}

                  {result.url && (
                    <div className="mt-2">
                      <p className="text-xs text-gray-500 truncate">
                        {result.url}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Empty State */}
      {!loading && searchResults.length === 0 && (
        <div className="text-center py-12">
          <Search className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-300 mb-2">Start Your Research</h3>
          <p className="text-gray-500">
            Search the web, find similar content, or extract specific page information using Exa's semantic search
          </p>
        </div>
      )}
    </div>
  )
}