'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { 
  Users, 
  MessageSquare, 
  FileText, 
  Search, 
  Calendar, 
  User, 
  Plus, 
  Star,
  Brain,
  Globe,
  Cloud
} from 'lucide-react'
import { useSpacetimeDB } from '@/hooks/useSpacetimeDB'
import { reducers, NoteCategory } from '@/spacetime_module_bindings'
import type { Infer } from 'spacetimedb'
import type { ResearchQuery, ResearchNote, CollaborationMember } from '@/spacetime_module_bindings'

type ResearchQueryType = Infer<typeof ResearchQuery>
type ResearchNoteType = Infer<typeof ResearchNote>
type CollaborationMemberType = Infer<typeof CollaborationMember>

interface CollaborationPanelProps {
  selectedProject: number | null
  connected: boolean
}

export function CollaborationPanel({ 
  selectedProject, 
  connected 
}: CollaborationPanelProps): JSX.Element {
  const [queries, setQueries] = useState<ResearchQueryType[]>([])
  const [notes, setNotes] = useState<ResearchNoteType[]>([])
  const [members, setMembers] = useState<CollaborationMemberType[]>([])
  
  const [newNoteHeadline, setNewNoteHeadline] = useState<string>('')
  const [newNoteBody, setNewNoteBody] = useState<string>('')
  const [newNoteCategory, setNewNoteCategory] = useState<'Insight' | 'Finding' | 'Annotation'>('Insight')
  const [isAddingNote, setIsAddingNote] = useState<boolean>(false)
  const [loading, setLoading] = useState<boolean>(false)

  const { connection, identity } = useSpacetimeDB()

  // Load collaboration data for selected project
  useEffect(() => {
    if (!connection || !selectedProject) {
      setQueries([])
      setNotes([])
      setMembers([])
      return
    }

    const loadProjectData = () => {
      // Load queries for this project
      const projectQueries = Array.from(connection.db.researchQuery.iter())
        .filter(query => query.projectId === selectedProject)
        .sort((a, b) => b.createdAt.toDate().getTime() - a.createdAt.toDate().getTime())
      
      // Load notes for this project
      const projectNotes = Array.from(connection.db.researchNote.iter())
        .filter(note => note.projectId === selectedProject)
        .sort((a, b) => b.createdAt.toDate().getTime() - a.createdAt.toDate().getTime())
      
      // Load members for this project
      const projectMembers = Array.from(connection.db.collaborationMember.iter())
        .filter(member => member.projectId === selectedProject)
        .sort((a, b) => a.joinedAt.toDate().getTime() - b.joinedAt.toDate().getTime())
      
      setQueries(projectQueries)
      setNotes(projectNotes)
      setMembers(projectMembers)
    }

    // Initial load
    loadProjectData()

    // Set up real-time updates
    connection.db.researchQuery.onInsert(loadProjectData)
    connection.db.researchQuery.onUpdate(loadProjectData)
    connection.db.researchQuery.onDelete(loadProjectData)

    connection.db.researchNote.onInsert(loadProjectData)
    connection.db.researchNote.onUpdate(loadProjectData)
    connection.db.researchNote.onDelete(loadProjectData)

    connection.db.collaborationMember.onInsert(loadProjectData)
    connection.db.collaborationMember.onUpdate(loadProjectData)
    connection.db.collaborationMember.onDelete(loadProjectData)

  }, [connection, selectedProject])

  const handleAddNote = async (): Promise<void> => {
    if (!connection || !selectedProject || !newNoteHeadline.trim() || !newNoteBody.trim()) return

    setLoading(true)
    try {
      await connection.reducers.addResearchNote({
        projectId: selectedProject,
        headline: newNoteHeadline.trim(),
        body: newNoteBody.trim(),
        category: { [newNoteCategory]: null }
      })

      setNewNoteHeadline('')
      setNewNoteBody('')
      setIsAddingNote(false)
    } catch (error) {
      console.error('Failed to add note:', error)
    }
    setLoading(false)
  }

  const formatDate = (timestamp: any): string => {
    return timestamp.toDate().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const getSourceTypeIcon = (sourceType: any) => {
    if ('Exa' in sourceType) return <Search className="w-3 h-3 text-green-500" />
    if ('Perplexity' in sourceType) return <Brain className="w-3 h-3 text-purple-500" />
    if ('Firecrawl' in sourceType) return <Globe className="w-3 h-3 text-orange-500" />
    return <Cloud className="w-3 h-3 text-cyan-500" />
  }

  const getSourceTypeLabel = (sourceType: any): string => {
    if ('Exa' in sourceType) return 'Exa Search'
    if ('Perplexity' in sourceType) return 'Perplexity AI'
    if ('Firecrawl' in sourceType) return 'Firecrawl'
    if ('Other' in sourceType) return sourceType.Other
    return 'Unknown'
  }

  const getCategoryIcon = (category: any) => {
    if ('Insight' in category) return <Star className="w-3 h-3 text-yellow-500" />
    if ('Finding' in category) return <Search className="w-3 h-3 text-blue-500" />
    if ('Annotation' in category) return <MessageSquare className="w-3 h-3 text-green-500" />
    return <FileText className="w-3 h-3 text-gray-500" />
  }

  const getCategoryLabel = (category: any): string => {
    if ('Insight' in category) return 'Insight'
    if ('Finding' in category) return 'Finding'
    if ('Annotation' in category) return 'Annotation'
    return 'Note'
  }

  const getCategoryColor = (category: any): string => {
    if ('Insight' in category) return 'border-yellow-500/20 bg-yellow-500/10 text-yellow-400'
    if ('Finding' in category) return 'border-blue-500/20 bg-blue-500/10 text-blue-400'
    if ('Annotation' in category) return 'border-green-500/20 bg-green-500/10 text-green-400'
    return 'border-gray-500/20 bg-gray-500/10 text-gray-400'
  }

  const isCurrentUser = (userIdentity: any): boolean => {
    if (!identity) return false
    return userIdentity.toHexString() === identity.toHexString()
  }

  if (!selectedProject) {
    return (
      <div className="text-center py-12">
        <Users className="w-12 h-12 text-gray-600 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-300 mb-2">Select a Project</h3>
        <p className="text-gray-500">
          Choose a research project to collaborate with your team in real-time
        </p>
      </div>
    )
  }

  if (!connected) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-400">Connect to SpacetimeDB to enable collaboration...</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Project Header */}
      <Card className="bg-gradient-to-r from-pink-900/20 to-purple-900/20 border-pink-500/20">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-lg bg-pink-500/20 flex items-center justify-center">
                <Users className="w-5 h-5 text-pink-400" />
              </div>
              <div>
                <h3 className="text-white font-medium">Collaborative Research</h3>
                <p className="text-pink-300 text-sm">Project {selectedProject} • Real-time sync</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="border-pink-500/20 bg-pink-500/10 text-pink-400">
                {members.length} {members.length === 1 ? 'member' : 'members'}
              </Badge>
              <Badge variant="outline" className="border-purple-500/20 bg-purple-500/10 text-purple-400">
                {queries.length} queries
              </Badge>
              <Badge variant="outline" className="border-blue-500/20 bg-blue-500/10 text-blue-400">
                {notes.length} notes
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Collaboration Tabs */}
      <Tabs defaultValue="activity" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800/50">
          <TabsTrigger value="activity">Activity Feed</TabsTrigger>
          <TabsTrigger value="notes">Team Notes</TabsTrigger>
          <TabsTrigger value="queries">Research Queries</TabsTrigger>
          <TabsTrigger value="members">Team Members</TabsTrigger>
        </TabsList>

        <TabsContent value="activity" className="space-y-4">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white text-sm">Recent Activity</CardTitle>
                <Badge variant="outline" className="border-pink-500/20 bg-pink-500/10 text-pink-400">
                  Live
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Combine and sort all activity */}
              {[...queries, ...notes]
                .sort((a, b) => b.createdAt.toDate().getTime() - a.createdAt.toDate().getTime())
                .slice(0, 10)
                .map((item, index) => {
                  const isQuery = 'searchTerms' in item
                  const user = isQuery 
                    ? (item as ResearchQueryType).submittedBy 
                    : (item as ResearchNoteType).author

                  return (
                    <div
                      key={`${isQuery ? 'query' : 'note'}-${isQuery ? (item as ResearchQueryType).queryId : (item as ResearchNoteType).noteId}`}
                      className="flex items-start space-x-3 p-3 bg-gray-900/30 rounded-lg"
                    >
                      <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center flex-shrink-0">
                        {isQuery ? (
                          getSourceTypeIcon((item as ResearchQueryType).sourceType)
                        ) : (
                          getCategoryIcon((item as ResearchNoteType).category)
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className="text-white text-sm font-medium">
                            {isCurrentUser(user) ? 'You' : user.toHexString().slice(0, 8)}
                            <span className="text-gray-400 font-normal ml-1">
                              {isQuery ? 'ran a query' : 'added a note'}
                            </span>
                          </p>
                          <p className="text-gray-500 text-xs">
                            {formatDate(item.createdAt)}
                          </p>
                        </div>
                        <p className="text-gray-300 text-sm mt-1">
                          {isQuery 
                            ? `"${(item as ResearchQueryType).searchTerms}"`
                            : `"${(item as ResearchNoteType).headline}"`
                          }
                        </p>
                        {isQuery && (
                          <div className="flex items-center space-x-2 mt-2">
                            <Badge 
                              variant="outline" 
                              className="border-gray-600 text-xs"
                            >
                              {getSourceTypeLabel((item as ResearchQueryType).sourceType)}
                            </Badge>
                          </div>
                        )}
                        {!isQuery && (
                          <div className="flex items-center space-x-2 mt-2">
                            <Badge 
                              variant="outline" 
                              className={`text-xs ${getCategoryColor((item as ResearchNoteType).category)}`}
                            >
                              {getCategoryLabel((item as ResearchNoteType).category)}
                            </Badge>
                          </div>
                        )}
                      </div>
                    </div>
                  )
                })}

              {queries.length === 0 && notes.length === 0 && (
                <div className="text-center py-8">
                  <MessageSquare className="w-8 h-8 text-gray-600 mx-auto mb-2" />
                  <p className="text-gray-500 text-sm">No activity yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notes" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-white">Team Notes</h3>
            <Dialog open={isAddingNote} onOpenChange={setIsAddingNote}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Note
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-gray-900 border-gray-800">
                <DialogHeader>
                  <DialogTitle className="text-white">Add Research Note</DialogTitle>
                  <DialogDescription className="text-gray-400">
                    Share insights, findings, or annotations with your team
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-300 mb-2 block">
                      Category
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['Insight', 'Finding', 'Annotation'] as const).map((category) => (
                        <Button
                          key={category}
                          variant={newNoteCategory === category ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => setNewNoteCategory(category)}
                          className={`${
                            newNoteCategory === category 
                              ? 'bg-blue-600 text-white' 
                              : 'border-gray-700 text-gray-300 hover:bg-gray-800'
                          }`}
                        >
                          {getCategoryIcon({ [category]: null })}
                          <span className="ml-1">{category}</span>
                        </Button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-300 mb-2 block">
                      Headline
                    </label>
                    <Input
                      value={newNoteHeadline}
                      onChange={(e) => setNewNoteHeadline(e.target.value)}
                      placeholder="Key insight about user behavior patterns"
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-300 mb-2 block">
                      Details
                    </label>
                    <Textarea
                      value={newNoteBody}
                      onChange={(e) => setNewNoteBody(e.target.value)}
                      placeholder="Detailed explanation of your findings..."
                      rows={4}
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button 
                      variant="outline" 
                      onClick={() => setIsAddingNote(false)}
                      className="border-gray-700 text-gray-300 hover:bg-gray-800"
                    >
                      Cancel
                    </Button>
                    <Button
                      onClick={handleAddNote}
                      disabled={!newNoteHeadline.trim() || !newNoteBody.trim() || loading}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      {loading ? 'Adding...' : 'Add Note'}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-3">
            {notes.map((note) => (
              <Card 
                key={note.noteId}
                className="bg-gray-800/30 border-gray-700"
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Badge 
                        variant="outline" 
                        className={`text-xs ${getCategoryColor(note.category)}`}
                      >
                        {getCategoryIcon(note.category)}
                        <span className="ml-1">{getCategoryLabel(note.category)}</span>
                      </Badge>
                      <p className="text-gray-400 text-xs">
                        by {isCurrentUser(note.author) ? 'You' : note.author.toHexString().slice(0, 8)}
                      </p>
                    </div>
                    <p className="text-gray-500 text-xs">
                      {formatDate(note.createdAt)}
                    </p>
                  </div>
                  <h4 className="text-white font-medium mb-2">{note.headline}</h4>
                  <p className="text-gray-300 text-sm leading-relaxed whitespace-pre-wrap">
                    {note.body}
                  </p>
                </CardContent>
              </Card>
            ))}

            {notes.length === 0 && (
              <div className="text-center py-8">
                <FileText className="w-8 h-8 text-gray-600 mx-auto mb-2" />
                <p className="text-gray-500 text-sm">No notes yet</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="queries" className="space-y-4">
          <div className="space-y-3">
            {queries.map((query) => (
              <Card 
                key={query.queryId}
                className="bg-gray-800/30 border-gray-700"
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Badge 
                        variant="outline" 
                        className="border-gray-600 text-xs"
                      >
                        {getSourceTypeIcon(query.sourceType)}
                        <span className="ml-1">{getSourceTypeLabel(query.sourceType)}</span>
                      </Badge>
                      <p className="text-gray-400 text-xs">
                        by {isCurrentUser(query.submittedBy) ? 'You' : query.submittedBy.toHexString().slice(0, 8)}
                      </p>
                    </div>
                    <p className="text-gray-500 text-xs">
                      {formatDate(query.createdAt)}
                    </p>
                  </div>
                  <h4 className="text-white font-medium mb-2">{query.searchTerms}</h4>
                  <p className="text-gray-300 text-sm">
                    {query.resultsSummary}
                  </p>
                </CardContent>
              </Card>
            ))}

            {queries.length === 0 && (
              <div className="text-center py-8">
                <Search className="w-8 h-8 text-gray-600 mx-auto mb-2" />
                <p className="text-gray-500 text-sm">No research queries yet</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="members" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {members.map((member) => (
              <Card 
                key={member.membershipId}
                className="bg-gray-800/30 border-gray-700"
              >
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                      <User className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <p className="text-white font-medium text-sm">
                        {isCurrentUser(member.memberIdentity) 
                          ? 'You' 
                          : member.memberIdentity.toHexString().slice(0, 8) + '...'
                        }
                      </p>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge 
                          variant="outline" 
                          className={`text-xs ${
                            'Owner' in member.role 
                              ? 'border-yellow-500/20 bg-yellow-500/10 text-yellow-400'
                              : 'border-blue-500/20 bg-blue-500/10 text-blue-400'
                          }`}
                        >
                          {'Owner' in member.role ? 'Owner' : 'Editor'}
                        </Badge>
                      </div>
                      <p className="text-gray-500 text-xs mt-1">
                        Joined {formatDate(member.joinedAt)}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {members.length === 0 && (
            <div className="text-center py-8">
              <Users className="w-8 h-8 text-gray-600 mx-auto mb-2" />
              <p className="text-gray-500 text-sm">No team members</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}