'use client'

import { Badge } from '@/components/ui/badge'
import { Wifi, WifiOff } from 'lucide-react'

interface ConnectionStatusProps {
  connected: boolean
  statusMessage: string
}

export function ConnectionStatus({ connected, statusMessage }: ConnectionStatusProps): JSX.Element {
  return (
    <div className="flex items-center space-x-2">
      <div className="flex items-center space-x-1">
        {connected ? (
          <Wifi className="w-4 h-4 text-green-500" />
        ) : (
          <WifiOff className="w-4 h-4 text-red-500" />
        )}
      </div>
      <Badge
        variant="outline"
        className={`${
          connected
            ? 'border-green-500/20 bg-green-500/10 text-green-400'
            : 'border-red-500/20 bg-red-500/10 text-red-400'
        }`}
      >
        {statusMessage}
      </Badge>
    </div>
  )
}