'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { Plus, Calendar, User, Users, FileText } from 'lucide-react'
import { useSpacetimeDB } from '@/hooks/useSpacetimeDB'
import { reducers } from '@/spacetime_module_bindings'
import type { Infer } from 'spacetimedb'
import type { ResearchProject } from '@/spacetime_module_bindings'

type ResearchProjectType = Infer<typeof ResearchProject>

interface ProjectOverviewProps {
  connected: boolean
  selectedProject: number | null
  onSelectProject: (projectId: number | null) => void
}

export function ProjectOverview({ 
  connected, 
  selectedProject, 
  onSelectProject 
}: ProjectOverviewProps): JSX.Element {
  const [projects, setProjects] = useState<ResearchProjectType[]>([])
  const [isCreating, setIsCreating] = useState<boolean>(false)
  const [newProjectTitle, setNewProjectTitle] = useState<string>('')
  const [newProjectDescription, setNewProjectDescription] = useState<string>('')
  const [loading, setLoading] = useState<boolean>(false)
  
  const { connection, identity } = useSpacetimeDB()

  // Load projects from SpacetimeDB
  useEffect(() => {
    if (!connection) return

    const loadProjects = () => {
      const allProjects = Array.from(connection.db.researchProject.iter())
        .sort((a, b) => b.createdAt.toDate().getTime() - a.createdAt.toDate().getTime())
      
      setProjects(allProjects)
    }

    // Initial load
    loadProjects()

    // Set up real-time updates
    connection.db.researchProject.onInsert(loadProjects)
    connection.db.researchProject.onUpdate(loadProjects)
    connection.db.researchProject.onDelete(loadProjects)

  }, [connection])

  const handleCreateProject = async (): Promise<void> => {
    if (!connection || !newProjectTitle.trim() || !newProjectDescription.trim()) return

    setLoading(true)
    try {
      await connection.reducers.createResearchProject({ 
        title: newProjectTitle.trim(),
        description: newProjectDescription.trim()
      })
      
      setNewProjectTitle('')
      setNewProjectDescription('')
      setIsCreating(false)
    } catch (error) {
      console.error('Failed to create project:', error)
    }
    setLoading(false)
  }

  const handleJoinProject = async (projectId: number): Promise<void> => {
    if (!connection) return

    try {
      await connection.reducers.joinResearchProject({ projectId })
    } catch (error) {
      console.error('Failed to join project:', error)
    }
  }

  const formatDate = (timestamp: any): string => {
    return timestamp.toDate().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  const getProjectMemberCount = (projectId: number): number => {
    if (!connection) return 0
    
    return Array.from(connection.db.collaborationMember.iter())
      .filter(member => member.projectId === projectId).length
  }

  const isProjectMember = (projectId: number): boolean => {
    if (!connection || !identity) return false
    
    return Array.from(connection.db.collaborationMember.iter())
      .some(member => 
        member.projectId === projectId && 
        member.memberIdentity.toHexString() === identity.toHexString()
      )
  }

  if (!connected) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-400">Connect to SpacetimeDB to access projects...</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Create New Project */}
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold text-white">Research Projects</h3>
          <p className="text-sm text-gray-400">Organize your research into collaborative projects</p>
        </div>
        
        <Dialog open={isCreating} onOpenChange={setIsCreating}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">
              <Plus className="w-4 h-4 mr-2" />
              New Project
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-gray-900 border-gray-800">
            <DialogHeader>
              <DialogTitle className="text-white">Create Research Project</DialogTitle>
              <DialogDescription className="text-gray-400">
                Start a new collaborative research initiative
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-300 mb-2 block">
                  Project Title
                </label>
                <Input
                  value={newProjectTitle}
                  onChange={(e) => setNewProjectTitle(e.target.value)}
                  placeholder="AI Impact on Software Development"
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-300 mb-2 block">
                  Description
                </label>
                <Textarea
                  value={newProjectDescription}
                  onChange={(e) => setNewProjectDescription(e.target.value)}
                  placeholder="Research the impact of AI tools on developer productivity and software quality..."
                  rows={4}
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button 
                  variant="outline" 
                  onClick={() => setIsCreating(false)}
                  className="border-gray-700 text-gray-300 hover:bg-gray-800"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleCreateProject}
                  disabled={!newProjectTitle.trim() || !newProjectDescription.trim() || loading}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  {loading ? 'Creating...' : 'Create Project'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Projects List */}
      {projects.length === 0 ? (
        <div className="text-center py-12">
          <FileText className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-300 mb-2">No Research Projects</h3>
          <p className="text-gray-500 mb-4">Create your first project to get started with collaborative research</p>
          <Button
            onClick={() => setIsCreating(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create First Project
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects.map((project) => {
            const memberCount = getProjectMemberCount(project.projectId)
            const isMember = isProjectMember(project.projectId)
            const isSelected = selectedProject === project.projectId

            return (
              <Card 
                key={project.projectId}
                className={`cursor-pointer transition-all hover:border-blue-500/50 ${
                  isSelected 
                    ? 'bg-blue-900/20 border-blue-500/50 ring-2 ring-blue-500/20' 
                    : 'bg-gray-800/50 border-gray-700'
                }`}
                onClick={() => onSelectProject(isSelected ? null : project.projectId)}
              >
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-white text-sm line-clamp-2">
                      {project.title}
                    </CardTitle>
                    <div className="flex space-x-1 ml-2">
                      {isMember && (
                        <Badge variant="outline" className="border-green-500/20 bg-green-500/10 text-green-400 text-xs">
                          Member
                        </Badge>
                      )}
                      {isSelected && (
                        <Badge variant="outline" className="border-blue-500/20 bg-blue-500/10 text-blue-400 text-xs">
                          Active
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-gray-400 text-xs mb-3 line-clamp-2">
                    {project.description}
                  </p>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center space-x-1 text-gray-500">
                        <Calendar className="w-3 h-3" />
                        <span>{formatDate(project.createdAt)}</span>
                      </div>
                      <div className="flex items-center space-x-1 text-gray-500">
                        <Users className="w-3 h-3" />
                        <span>{memberCount} {memberCount === 1 ? 'member' : 'members'}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-1 text-xs text-gray-500">
                      <User className="w-3 h-3" />
                      <span>Created by {project.createdBy.toHexString().slice(0, 8)}...</span>
                    </div>
                  </div>

                  {!isMember && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={(e) => {
                        e.stopPropagation()
                        handleJoinProject(project.projectId)
                      }}
                      className="mt-3 w-full border-blue-500/20 text-blue-400 hover:bg-blue-500/10"
                    >
                      Join Project
                    </Button>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}

      {/* Selected Project Info */}
      {selectedProject && (
        <Card className="bg-blue-900/10 border-blue-500/20">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <p className="text-blue-400 font-medium">
                Project {selectedProject} is now active for research tools
              </p>
            </div>
            <p className="text-gray-400 text-sm mt-1">
              All research queries and notes will be automatically associated with this project
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}