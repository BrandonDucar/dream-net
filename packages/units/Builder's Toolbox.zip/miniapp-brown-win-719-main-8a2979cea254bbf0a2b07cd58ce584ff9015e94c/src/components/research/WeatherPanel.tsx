'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Cloud, MapPin, Thermometer, Wind, Eye, Droplets, Sunrise, Sunset, Loader2 } from 'lucide-react'
import { getWeatherByCity, getWeatherIconUrl, formatTemperature, formatWindSpeed, formatPressure, formatVisibility, formatTime, isWeatherError } from '@/lib/weatherApi'
import type { WeatherData } from '@/lib/weatherApi'
import { useSpacetimeDB } from '@/hooks/useSpacetimeDB'
import { reducers, SourceType } from '@/spacetime_module_bindings'

interface WeatherPanelProps {
  selectedProject: number | null
  connected: boolean
}

export function WeatherPanel({ selectedProject, connected }: WeatherPanelProps): JSX.Element {
  const [cityName, setCityName] = useState<string>('')
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null)
  const [loading, setLoading] = useState<boolean>(false)
  const [error, setError] = useState<string>('')

  const { connection } = useSpacetimeDB()

  const handleGetWeather = async (): Promise<void> => {
    if (!cityName.trim() || loading) return

    setLoading(true)
    setError('')
    try {
      const response = await getWeatherByCity(cityName.trim())
      
      if (isWeatherError(response)) {
        setError(`Weather API Error: ${response.message}`)
        setWeatherData(null)
      } else {
        setWeatherData(response)
        setError('')

        // Save to project if one is selected
        if (selectedProject && connection) {
          const temp = formatTemperature(response.main.temp)
          const condition = response.weather[0]?.main || 'Unknown'
          const resultsSummary = `Weather data for ${response.name}, ${response.sys.country}. Temperature: ${temp}, Condition: ${condition}, Humidity: ${response.main.humidity}%`

          await connection.reducers.addResearchQuery({
            projectId: selectedProject,
            searchTerms: `Weather: ${cityName.trim()}`,
            sourceType: { Other: 'OpenWeatherMap' },
            resultsSummary
          })
        }
      }
    } catch (error) {
      console.error('Weather fetch failed:', error)
      setError('Failed to fetch weather data. Please try again.')
      setWeatherData(null)
    }
    setLoading(false)
  }

  const getCurrentTime = (): string => {
    return new Date().toLocaleString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      timeZoneName: 'short'
    })
  }

  return (
    <div className="space-y-6">
      {/* Project Status */}
      {selectedProject ? (
        <div className="bg-green-900/20 border border-green-500/20 rounded-lg p-3">
          <p className="text-green-400 text-sm">
            ✅ Weather data will be automatically saved to Project {selectedProject}
          </p>
        </div>
      ) : (
        <div className="bg-yellow-900/20 border border-yellow-500/20 rounded-lg p-3">
          <p className="text-yellow-400 text-sm">
            ⚠️ Select a project from the Projects tab to save weather data
          </p>
        </div>
      )}

      {/* Weather Search */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center space-x-2">
            <Cloud className="w-4 h-4 text-cyan-400" />
            <span>Get Weather Data</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex space-x-2">
            <Input
              value={cityName}
              onChange={(e) => setCityName(e.target.value)}
              placeholder="San Francisco, CA"
              className="bg-gray-900 border-gray-600 text-white"
              onKeyPress={(e) => e.key === 'Enter' && handleGetWeather()}
            />
            <Button
              onClick={handleGetWeather}
              disabled={!cityName.trim() || loading}
              className="bg-cyan-600 hover:bg-cyan-700 text-white px-6"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Cloud className="w-4 h-4" />
              )}
            </Button>
          </div>
          
          <p className="text-xs text-gray-500">
            Enter a city name or "City, Country" format for accurate results
          </p>

          {error && (
            <div className="bg-red-900/20 border border-red-500/20 rounded-lg p-3">
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Weather Results */}
      {weatherData && (
        <div className="space-y-6">
          {/* Main Weather Info */}
          <Card className="bg-gradient-to-br from-cyan-900/20 to-blue-900/20 border-cyan-500/20">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <MapPin className="w-5 h-5 text-cyan-400" />
                  <div>
                    <CardTitle className="text-white text-lg">
                      {weatherData.name}, {weatherData.sys.country}
                    </CardTitle>
                    <p className="text-cyan-300 text-sm">
                      Current Weather • {getCurrentTime()}
                    </p>
                  </div>
                </div>
                {weatherData.weather[0]?.icon && (
                  <img
                    src={getWeatherIconUrl(weatherData.weather[0].icon)}
                    alt={weatherData.weather[0]?.description || 'Weather icon'}
                    className="w-12 h-12"
                  />
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Temperature and Condition */}
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <div className="flex items-center space-x-3">
                    <Thermometer className="w-5 h-5 text-orange-400" />
                    <span className="text-3xl font-bold text-white">
                      {formatTemperature(weatherData.main.temp)}
                    </span>
                  </div>
                  <p className="text-gray-300 text-sm capitalize">
                    {weatherData.weather[0]?.description || 'Unknown condition'}
                  </p>
                </div>
                <div className="text-right space-y-1">
                  <p className="text-gray-400 text-xs">Feels like</p>
                  <p className="text-white text-lg">
                    {formatTemperature(weatherData.main.feels_like)}
                  </p>
                </div>
              </div>

              {/* Temperature Range */}
              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-700">
                <div className="text-center">
                  <p className="text-gray-400 text-xs">High</p>
                  <p className="text-white font-medium">
                    {formatTemperature(weatherData.main.temp_max)}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-gray-400 text-xs">Low</p>
                  <p className="text-white font-medium">
                    {formatTemperature(weatherData.main.temp_min)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Detailed Weather Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Wind */}
            <Card className="bg-gray-800/30 border-gray-700">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                    <Wind className="w-5 h-5 text-blue-400" />
                  </div>
                  <div>
                    <p className="text-white font-medium">
                      {formatWindSpeed(weatherData.wind.speed)}
                    </p>
                    <p className="text-gray-400 text-xs">
                      Wind Speed
                      {weatherData.wind.deg && ` • ${weatherData.wind.deg}°`}
                    </p>
                    {weatherData.wind.gust && (
                      <p className="text-gray-500 text-xs">
                        Gusts: {formatWindSpeed(weatherData.wind.gust)}
                      </p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Humidity */}
            <Card className="bg-gray-800/30 border-gray-700">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                    <Droplets className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <p className="text-white font-medium">
                      {weatherData.main.humidity}%
                    </p>
                    <p className="text-gray-400 text-xs">Humidity</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Pressure */}
            <Card className="bg-gray-800/30 border-gray-700">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
                    <Cloud className="w-5 h-5 text-purple-400" />
                  </div>
                  <div>
                    <p className="text-white font-medium">
                      {formatPressure(weatherData.main.pressure)}
                    </p>
                    <p className="text-gray-400 text-xs">Pressure</p>
                    {weatherData.main.sea_level && (
                      <p className="text-gray-500 text-xs">
                        Sea Level: {formatPressure(weatherData.main.sea_level)}
                      </p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Visibility */}
            <Card className="bg-gray-800/30 border-gray-700">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                    <Eye className="w-5 h-5 text-green-400" />
                  </div>
                  <div>
                    <p className="text-white font-medium">
                      {formatVisibility(weatherData.visibility)}
                    </p>
                    <p className="text-gray-400 text-xs">Visibility</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Cloudiness */}
            <Card className="bg-gray-800/30 border-gray-700">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-lg bg-gray-500/10 flex items-center justify-center">
                    <Cloud className="w-5 h-5 text-gray-400" />
                  </div>
                  <div>
                    <p className="text-white font-medium">
                      {weatherData.clouds.all}%
                    </p>
                    <p className="text-gray-400 text-xs">Cloudiness</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Sunrise/Sunset */}
            <Card className="bg-gray-800/30 border-gray-700">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-lg bg-yellow-500/10 flex items-center justify-center">
                    <Sunrise className="w-5 h-5 text-yellow-400" />
                  </div>
                  <div>
                    <p className="text-white font-medium">
                      {formatTime(weatherData.sys.sunrise, weatherData.timezone)}
                    </p>
                    <p className="text-gray-400 text-xs">Sunrise</p>
                    <div className="flex items-center space-x-1 mt-1">
                      <Sunset className="w-3 h-3 text-orange-400" />
                      <p className="text-gray-500 text-xs">
                        {formatTime(weatherData.sys.sunset, weatherData.timezone)}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Additional Information */}
          {(weatherData.rain || weatherData.snow) && (
            <Card className="bg-blue-900/20 border-blue-500/20">
              <CardContent className="p-4">
                <h4 className="text-white font-medium mb-3 flex items-center space-x-2">
                  <Droplets className="w-4 h-4 text-blue-400" />
                  <span>Precipitation</span>
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {weatherData.rain?.['1h'] && (
                    <div>
                      <p className="text-blue-300 text-sm font-medium">
                        Rain (1h): {weatherData.rain['1h']} mm
                      </p>
                    </div>
                  )}
                  {weatherData.snow?.['1h'] && (
                    <div>
                      <p className="text-blue-300 text-sm font-medium">
                        Snow (1h): {weatherData.snow['1h']} mm
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Data Source */}
          <div className="text-center">
            <Badge variant="outline" className="border-cyan-500/20 bg-cyan-500/10 text-cyan-400">
              Data from OpenWeatherMap
            </Badge>
          </div>
        </div>
      )}

      {/* Empty State */}
      {!weatherData && !loading && !error && (
        <div className="text-center py-12">
          <Cloud className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-300 mb-2">Weather Context</h3>
          <p className="text-gray-500">
            Get current weather data for any location to inform your research with environmental context
          </p>
        </div>
      )}
    </div>
  )
}