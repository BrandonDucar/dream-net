'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Globe, ExternalLink, Download, Search, Loader2, FileText, AlertCircle } from 'lucide-react'
import { scrapeUrl, crawlUrl, mapUrl, searchUrl } from '@/firecrawl'
import type { ScrapeResponse, CrawlResponse, MapResponse, SearchResponse } from '@/firecrawl'
import { useSpacetimeDB } from '@/hooks/useSpacetimeDB'
import { reducers, SourceType } from '@/spacetime_module_bindings'

interface WebScraperPanelProps {
  selectedProject: number | null
  connected: boolean
}

interface ScrapedData {
  type: 'scrape' | 'crawl' | 'map' | 'search'
  data: ScrapeResponse | CrawlResponse | MapResponse | SearchResponse | null
  timestamp: Date
  url?: string
  query?: string
}

export function WebScraperPanel({ selectedProject, connected }: WebScraperPanelProps): JSX.Element {
  const [scrapeUrl, setScrapeUrl] = useState<string>('')
  const [crawlUrl, setCrawlUrl] = useState<string>('')
  const [mapUrl, setMapUrl] = useState<string>('')
  const [searchQuery, setSearchQuery] = useState<string>('')
  
  const [onlyMainContent, setOnlyMainContent] = useState<boolean>(true)
  const [includeMarkdown, setIncludeMarkdown] = useState<boolean>(true)
  
  const [results, setResults] = useState<ScrapedData[]>([])
  const [loading, setLoading] = useState<{ [key: string]: boolean }>({
    scrape: false,
    crawl: false,
    map: false,
    search: false
  })

  const { connection } = useSpacetimeDB()

  const handleScrape = async (): Promise<void> => {
    if (!scrapeUrl.trim() || loading.scrape) return

    setLoading(prev => ({ ...prev, scrape: true }))
    try {
      const response = await scrapeUrl({
        url: scrapeUrl,
        onlyMainContent,
        formats: includeMarkdown ? ['markdown', 'html'] : ['html'],
        timeout: 60000
      })

      const scrapedData: ScrapedData = {
        type: 'scrape',
        data: response,
        timestamp: new Date(),
        url: scrapeUrl
      }
      
      setResults(prev => [scrapedData, ...prev])

      // Save to project if one is selected
      if (selectedProject && connection) {
        const success = response.success ? 'successful' : 'failed'
        const title = response.data?.metadata?.title || 'Unknown'
        const resultsSummary = `Website scraping ${success}. ${
          response.success 
            ? `Page title: "${title}". Content extracted successfully.` 
            : 'Failed to extract content.'
        }`

        await connection.reducers.addResearchQuery({
          projectId: selectedProject,
          searchTerms: `Scrape: ${scrapeUrl}`,
          sourceType: { Firecrawl: null },
          resultsSummary
        })
      }
    } catch (error) {
      console.error('Scraping failed:', error)
    }
    setLoading(prev => ({ ...prev, scrape: false }))
  }

  const handleCrawl = async (): Promise<void> => {
    if (!crawlUrl.trim() || loading.crawl) return

    setLoading(prev => ({ ...prev, crawl: true }))
    try {
      const response = await crawlUrl({
        url: crawlUrl,
        limit: 10,
        timeout: 120000,
        scrapeOptions: {
          onlyMainContent,
          formats: includeMarkdown ? ['markdown'] : ['html']
        }
      })

      const scrapedData: ScrapedData = {
        type: 'crawl',
        data: response,
        timestamp: new Date(),
        url: crawlUrl
      }
      
      setResults(prev => [scrapedData, ...prev])

      // Save to project if one is selected
      if (selectedProject && connection) {
        const success = response.success ? 'initiated' : 'failed'
        const crawlId = response.id || 'unknown'
        const resultsSummary = `Website crawling ${success}. ${
          response.success 
            ? `Crawl ID: ${crawlId}. Processing multiple pages from ${crawlUrl}` 
            : 'Failed to start crawling process.'
        }`

        await connection.reducers.addResearchQuery({
          projectId: selectedProject,
          searchTerms: `Crawl: ${crawlUrl}`,
          sourceType: { Firecrawl: null },
          resultsSummary
        })
      }
    } catch (error) {
      console.error('Crawling failed:', error)
    }
    setLoading(prev => ({ ...prev, crawl: false }))
  }

  const handleMap = async (): Promise<void> => {
    if (!mapUrl.trim() || loading.map) return

    setLoading(prev => ({ ...prev, map: true }))
    try {
      const response = await mapUrl({
        url: mapUrl,
        limit: 50,
        timeout: 60000
      })

      const scrapedData: ScrapedData = {
        type: 'map',
        data: response,
        timestamp: new Date(),
        url: mapUrl
      }
      
      setResults(prev => [scrapedData, ...prev])

      // Save to project if one is selected
      if (selectedProject && connection) {
        const success = response.success ? 'successful' : 'failed'
        const linkCount = response.links?.length || 0
        const resultsSummary = `Sitemap generation ${success}. ${
          response.success 
            ? `Found ${linkCount} pages on ${mapUrl}` 
            : 'Failed to generate sitemap.'
        }`

        await connection.reducers.addResearchQuery({
          projectId: selectedProject,
          searchTerms: `Map: ${mapUrl}`,
          sourceType: { Firecrawl: null },
          resultsSummary
        })
      }
    } catch (error) {
      console.error('Mapping failed:', error)
    }
    setLoading(prev => ({ ...prev, map: false }))
  }

  const handleSearch = async (): Promise<void> => {
    if (!searchQuery.trim() || loading.search) return

    setLoading(prev => ({ ...prev, search: true }))
    try {
      const response = await searchUrl({
        query: searchQuery,
        limit: 10,
        timeout: 60000,
        scrapeOptions: {
          onlyMainContent,
          formats: includeMarkdown ? ['markdown'] : ['html']
        }
      })

      const scrapedData: ScrapedData = {
        type: 'search',
        data: response,
        timestamp: new Date(),
        query: searchQuery
      }
      
      setResults(prev => [scrapedData, ...prev])

      // Save to project if one is selected
      if (selectedProject && connection) {
        const success = response.success ? 'successful' : 'failed'
        const resultCount = Array.isArray(response.data) ? response.data.length : 0
        const resultsSummary = `Web search ${success}. ${
          response.success 
            ? `Found ${resultCount} results for "${searchQuery}"` 
            : 'Failed to complete search.'
        }`

        await connection.reducers.addResearchQuery({
          projectId: selectedProject,
          searchTerms: `Search: ${searchQuery}`,
          sourceType: { Firecrawl: null },
          resultsSummary
        })
      }
    } catch (error) {
      console.error('Search failed:', error)
    }
    setLoading(prev => ({ ...prev, search: false }))
  }

  const truncateText = (text: string, maxLength: number): string => {
    if (text.length <= maxLength) return text
    return text.substring(0, maxLength) + '...'
  }

  const renderResult = (result: ScrapedData) => {
    const { type, data, timestamp, url, query } = result

    if (!data || !data.success) {
      return (
        <Card key={timestamp.getTime()} className="bg-red-900/20 border-red-500/20">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-red-500" />
              <p className="text-red-400 text-sm">
                {type.charAt(0).toUpperCase() + type.slice(1)} operation failed
              </p>
            </div>
            <p className="text-gray-400 text-xs mt-1">
              {url || query} - {timestamp.toLocaleString()}
            </p>
          </CardContent>
        </Card>
      )
    }

    return (
      <Card key={timestamp.getTime()} className="bg-gray-800/30 border-gray-700">
        <CardHeader className="pb-3">
          <div className="flex justify-between items-start">
            <div className="flex items-center space-x-2">
              <Globe className="w-4 h-4 text-orange-400" />
              <CardTitle className="text-white text-sm capitalize">
                {type} Result
              </CardTitle>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="border-orange-500/20 bg-orange-500/10 text-orange-400 text-xs">
                {timestamp.toLocaleTimeString()}
              </Badge>
              {url && (
                <Button
                  variant="ghost"
                  size="sm"
                  asChild
                  className="h-6 w-6 p-0 hover:bg-gray-700"
                >
                  <a href={url} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* URL or Query */}
          <div className="text-xs text-gray-400">
            <span className="font-medium">
              {type === 'search' ? 'Query:' : 'URL:'} 
            </span>
            <span className="ml-2">{url || query}</span>
          </div>

          {/* Type-specific content */}
          {type === 'scrape' && data.data && (
            <div className="space-y-2">
              {data.data.metadata?.title && (
                <h4 className="text-white font-medium text-sm">
                  {data.data.metadata.title}
                </h4>
              )}
              {data.data.metadata?.description && (
                <p className="text-gray-300 text-xs">
                  {truncateText(data.data.metadata.description, 200)}
                </p>
              )}
              {data.data.markdown && (
                <div className="bg-gray-900/50 rounded p-3">
                  <p className="text-gray-300 text-xs font-mono leading-relaxed">
                    {truncateText(data.data.markdown, 300)}
                  </p>
                </div>
              )}
            </div>
          )}

          {type === 'crawl' && (
            <div className="space-y-2">
              {data.id && (
                <div className="bg-blue-900/20 rounded p-3">
                  <p className="text-blue-300 text-xs">
                    <span className="font-medium">Crawl ID:</span> {data.id}
                  </p>
                  {data.url && (
                    <p className="text-blue-300 text-xs mt-1">
                      <span className="font-medium">Status URL:</span> {data.url}
                    </p>
                  )}
                </div>
              )}
            </div>
          )}

          {type === 'map' && data.links && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-400">Pages discovered:</span>
                <Badge variant="outline" className="border-orange-500/20 bg-orange-500/10 text-orange-400 text-xs">
                  {data.links.length} pages
                </Badge>
              </div>
              <div className="max-h-40 overflow-y-auto space-y-1">
                {data.links.slice(0, 10).map((link, index) => (
                  <div key={index} className="flex items-center justify-between text-xs">
                    <span className="text-gray-400 truncate flex-1 mr-2">
                      {link}
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      asChild
                      className="h-5 w-5 p-0 hover:bg-gray-700"
                    >
                      <a href={link} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-2 h-2" />
                      </a>
                    </Button>
                  </div>
                ))}
                {data.links.length > 10 && (
                  <p className="text-xs text-gray-500 text-center pt-2">
                    ... and {data.links.length - 10} more pages
                  </p>
                )}
              </div>
            </div>
          )}

          {type === 'search' && Array.isArray(data.data) && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-400">Search results:</span>
                <Badge variant="outline" className="border-orange-500/20 bg-orange-500/10 text-orange-400 text-xs">
                  {data.data.length} results
                </Badge>
              </div>
              <div className="space-y-2">
                {data.data.slice(0, 3).map((item, index) => (
                  <div key={index} className="bg-gray-900/30 rounded p-2">
                    {item.title && (
                      <h5 className="text-white text-xs font-medium mb-1">
                        {truncateText(item.title, 80)}
                      </h5>
                    )}
                    {item.description && (
                      <p className="text-gray-400 text-xs mb-1">
                        {truncateText(item.description, 120)}
                      </p>
                    )}
                    {item.url && (
                      <div className="flex items-center justify-between">
                        <p className="text-gray-500 text-xs truncate flex-1">
                          {item.url}
                        </p>
                        <Button
                          variant="ghost"
                          size="sm"
                          asChild
                          className="h-5 w-5 p-0 hover:bg-gray-700 ml-1"
                        >
                          <a href={item.url} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="w-2 h-2" />
                          </a>
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
                {data.data.length > 3 && (
                  <p className="text-xs text-gray-500 text-center">
                    ... and {data.data.length - 3} more results
                  </p>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Project Status */}
      {selectedProject ? (
        <div className="bg-green-900/20 border border-green-500/20 rounded-lg p-3">
          <p className="text-green-400 text-sm">
            ✅ Scraping results will be automatically saved to Project {selectedProject}
          </p>
        </div>
      ) : (
        <div className="bg-yellow-900/20 border border-yellow-500/20 rounded-lg p-3">
          <p className="text-yellow-400 text-sm">
            ⚠️ Select a project from the Projects tab to save scraping results
          </p>
        </div>
      )}

      {/* Scraping Options */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white text-sm">Scraping Options</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center space-x-2">
              <Switch
                id="main-content"
                checked={onlyMainContent}
                onCheckedChange={setOnlyMainContent}
              />
              <Label htmlFor="main-content" className="text-sm text-gray-300">
                Extract only main content
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="markdown"
                checked={includeMarkdown}
                onCheckedChange={setIncludeMarkdown}
              />
              <Label htmlFor="markdown" className="text-sm text-gray-300">
                Include markdown format
              </Label>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Scraping Tools */}
      <Tabs defaultValue="scrape" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800/50">
          <TabsTrigger value="scrape">Single Page</TabsTrigger>
          <TabsTrigger value="crawl">Crawl Site</TabsTrigger>
          <TabsTrigger value="map">Site Map</TabsTrigger>
          <TabsTrigger value="search">Web Search</TabsTrigger>
        </TabsList>

        <TabsContent value="scrape">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center space-x-2">
                <FileText className="w-4 h-4 text-orange-400" />
                <span>Scrape Single Page</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                value={scrapeUrl}
                onChange={(e) => setScrapeUrl(e.target.value)}
                placeholder="https://example.com/page"
                className="bg-gray-900 border-gray-600 text-white"
                onKeyPress={(e) => e.key === 'Enter' && handleScrape()}
              />
              <Button
                onClick={handleScrape}
                disabled={!scrapeUrl.trim() || loading.scrape}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white"
              >
                {loading.scrape ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    Scraping...
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 mr-2" />
                    Scrape Page
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="crawl">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center space-x-2">
                <Globe className="w-4 h-4 text-orange-400" />
                <span>Crawl Website</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                value={crawlUrl}
                onChange={(e) => setCrawlUrl(e.target.value)}
                placeholder="https://example.com"
                className="bg-gray-900 border-gray-600 text-white"
                onKeyPress={(e) => e.key === 'Enter' && handleCrawl()}
              />
              <Button
                onClick={handleCrawl}
                disabled={!crawlUrl.trim() || loading.crawl}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white"
              >
                {loading.crawl ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    Crawling...
                  </>
                ) : (
                  <>
                    <Globe className="w-4 h-4 mr-2" />
                    Start Crawl
                  </>
                )}
              </Button>
              <p className="text-xs text-gray-500">
                Crawls up to 10 pages from the target website
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="map">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center space-x-2">
                <Search className="w-4 h-4 text-orange-400" />
                <span>Generate Sitemap</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                value={mapUrl}
                onChange={(e) => setMapUrl(e.target.value)}
                placeholder="https://example.com"
                className="bg-gray-900 border-gray-600 text-white"
                onKeyPress={(e) => e.key === 'Enter' && handleMap()}
              />
              <Button
                onClick={handleMap}
                disabled={!mapUrl.trim() || loading.map}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white"
              >
                {loading.map ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    Mapping...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 mr-2" />
                    Generate Map
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="search">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center space-x-2">
                <Search className="w-4 h-4 text-orange-400" />
                <span>Search & Scrape</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="AI research papers"
                className="bg-gray-900 border-gray-600 text-white"
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
              <Button
                onClick={handleSearch}
                disabled={!searchQuery.trim() || loading.search}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white"
              >
                {loading.search ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    Searching...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 mr-2" />
                    Search & Scrape
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Results */}
      {results.length > 0 && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-white">Scraping Results</h3>
            <Badge variant="outline" className="border-orange-500/20 bg-orange-500/10 text-orange-400">
              {results.length} operations
            </Badge>
          </div>

          <div className="space-y-3">
            {results.map(renderResult)}
          </div>
        </div>
      )}

      {/* Empty State */}
      {results.length === 0 && (
        <div className="text-center py-12">
          <Globe className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-300 mb-2">Website Analysis Tools</h3>
          <p className="text-gray-500">
            Extract content from web pages, crawl entire sites, or search and scrape multiple pages using Firecrawl
          </p>
        </div>
      )}
    </div>
  )
}