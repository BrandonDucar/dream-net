'use client'

import { useEffect, useState, useRef, useCallback } from 'react'
import { Identity } from 'spacetimedb'
import { DbConnection } from '@/spacetime_module_bindings'
import type { Infer } from 'spacetimedb'

type DbConnectionType = Infer<typeof DbConnection>

export interface SpacetimeDBState {
  connected: boolean
  identity: Identity | null
  statusMessage: string
  connection: DbConnectionType | null
}

export function useSpacetimeDB(): SpacetimeDBState {
  const [connected, setConnected] = useState<boolean>(false)
  const [identity, setIdentity] = useState<Identity | null>(null)
  const [statusMessage, setStatusMessage] = useState<string>('Connecting...')
  
  const connectionRef = useRef<DbConnectionType | null>(null)

  const subscribeToTables = useCallback(() => {
    if (!connectionRef.current) return
    
    console.log('Subscribing to research tables...')
    
    const queries = [
      'SELECT * FROM research_project',
      'SELECT * FROM research_query',
      'SELECT * FROM research_note',
      'SELECT * FROM collaboration_member'
    ]
    
    connectionRef.current
      .subscriptionBuilder()
      .onApplied(() => {
        console.log('Research data subscriptions applied successfully')
        setStatusMessage(connected ? 'Connected & Synced' : 'Synced')
      })
      .onError((error: Error) => {
        console.error('Subscription error:', error)
        setStatusMessage(`Subscription Error: ${error.message}`)
      })
      .subscribe(queries)
  }, [connected])

  const registerTableCallbacks = useCallback((currentIdentity: Identity) => {
    if (!connectionRef.current) return
    
    console.log('Registering research table callbacks...')

    // Research Project callbacks
    connectionRef.current.db.researchProject.onInsert((ctx, project) => {
      if (ctx) {
        console.log('New research project created:', project.title)
      } else {
        console.log('Initial project loaded:', project.title)
      }
    })

    connectionRef.current.db.researchProject.onUpdate((ctx, oldProject, newProject) => {
      if (ctx) {
        console.log('Research project updated:', newProject.title)
      }
    })

    connectionRef.current.db.researchProject.onDelete((ctx, project) => {
      console.log('Research project deleted:', project.title)
    })

    // Research Query callbacks
    connectionRef.current.db.researchQuery.onInsert((ctx, query) => {
      if (ctx) {
        console.log('New research query:', query.searchTerms)
      } else {
        console.log('Initial query loaded:', query.searchTerms)
      }
    })

    // Research Note callbacks
    connectionRef.current.db.researchNote.onInsert((ctx, note) => {
      if (ctx) {
        console.log('New research note:', note.headline)
      } else {
        console.log('Initial note loaded:', note.headline)
      }
    })

    // Collaboration Member callbacks
    connectionRef.current.db.collaborationMember.onInsert((ctx, member) => {
      if (ctx) {
        console.log('New collaborator joined project', member.projectId)
      } else {
        console.log('Initial member loaded for project', member.projectId)
      }
    })

    connectionRef.current.db.collaborationMember.onDelete((ctx, member) => {
      console.log('Collaborator left project', member.projectId)
    })
  }, [])

  useEffect(() => {
    if (connectionRef.current) {
      console.log('SpacetimeDB connection already established, skipping setup')
      return
    }

    const dbHost = 'wss://maincloud.spacetimedb.com'
    const dbName = process.env.NEXT_PUBLIC_SPACETIME_MODULE_NAME || 'research_intelligence_hub'

    const onConnect = (connection: DbConnectionType, id: Identity, _token: string) => {
      console.log('SpacetimeDB connected successfully!')
      connectionRef.current = connection
      setIdentity(id)
      setConnected(true)
      setStatusMessage(`Connected as ${id.toHexString().substring(0, 8)}...`)
      
      // Set up subscriptions and callbacks with identity parameter
      subscribeToTables()
      registerTableCallbacks(id)
    }

    const onDisconnect = (_ctx: any, reason?: Error | null) => {
      const reasonStr = reason ? reason.message : 'No reason given'
      console.log('SpacetimeDB disconnected:', reasonStr)
      setStatusMessage(`Disconnected: ${reasonStr}`)
      connectionRef.current = null
      setIdentity(null)
      setConnected(false)
    }

    try {
      DbConnection.builder()
        .withUri(dbHost)
        .withModuleName(dbName)
        .onConnect(onConnect)
        .onDisconnect(onDisconnect)
        .build()
    } catch (error) {
      console.error('Failed to establish SpacetimeDB connection:', error)
      setStatusMessage(`Connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`)
    }
  }, [subscribeToTables, registerTableCallbacks])

  return {
    connected,
    identity,
    statusMessage,
    connection: connectionRef.current
  }
}