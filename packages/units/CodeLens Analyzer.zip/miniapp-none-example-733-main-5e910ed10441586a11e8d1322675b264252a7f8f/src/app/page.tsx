'use client'
import { useState, useEffect } from 'react';
import { CodeInput } from '@/components/code-input';
import { AnalysisResults } from '@/components/analysis-results';
import { FixPlanComponent } from '@/components/fix-plan';
import { CodeAnalyzer } from '@/lib/code-analyzer';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import type { AnalysisResult } from '@/types/analysis';
import { Code2, FileSearch, Wrench } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Page(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [originalCode, setOriginalCode] = useState<string>('');

  const handleAnalyze = (code: string, fileName?: string): void => {
    setIsAnalyzing(true);
    setOriginalCode(code);
    
    // Simulate analysis delay for better UX
    setTimeout(() => {
      const analyzer = new CodeAnalyzer(code);
      const result = analyzer.analyze();
      setAnalysisResult(result);
      setIsAnalyzing(false);
    }, 500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8 pt-16">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Code2 className="h-12 w-12 text-primary" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
              Dream CodeLens Inspector
            </h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive code analysis tool that detects code smells, security issues, 
            performance bottlenecks, and provides one-click fixes
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="text-center">
            <CardContent className="pt-6">
              <FileSearch className="h-8 w-8 mx-auto mb-2 text-blue-500" />
              <p className="text-sm font-medium">Code Smells</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <svg className="h-8 w-8 mx-auto mb-2 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
              <p className="text-sm font-medium">Security</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <svg className="h-8 w-8 mx-auto mb-2 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
              <p className="text-sm font-medium">Performance</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <Wrench className="h-8 w-8 mx-auto mb-2 text-green-500" />
              <p className="text-sm font-medium">Auto-Fix</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="space-y-6">
          <CodeInput onAnalyze={handleAnalyze} isAnalyzing={isAnalyzing} />
          
          {analysisResult && (
            <Tabs defaultValue="results" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="results">Analysis Results</TabsTrigger>
                <TabsTrigger value="fixes">Fix Plans</TabsTrigger>
              </TabsList>
              
              <TabsContent value="results" className="mt-6">
                <AnalysisResults results={analysisResult} />
              </TabsContent>
              
              <TabsContent value="fixes" className="mt-6">
                <FixPlanComponent fixPlans={analysisResult.fixPlans} originalCode={originalCode} />
              </TabsContent>
            </Tabs>
          )}
          
          {!analysisResult && !isAnalyzing && (
            <Card className="border-dashed">
              <CardHeader>
                <CardTitle>Ready to Analyze</CardTitle>
                <CardDescription>
                  Paste your code, upload a file, or load sample code to get started
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <h3 className="font-semibold mb-2">🔍 What we detect:</h3>
                    <ul className="space-y-1 text-muted-foreground">
                      <li>• Code smells & anti-patterns</li>
                      <li>• Security vulnerabilities</li>
                      <li>• Unused imports & dead code</li>
                      <li>• Complexity hotspots</li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">⚡ Performance:</h3>
                    <ul className="space-y-1 text-muted-foreground">
                      <li>• Nested loop detection</li>
                      <li>• Memory leak warnings</li>
                      <li>• Inefficient operations</li>
                      <li>• Optimization tips</li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">🔧 Auto-Fix:</h3>
                    <ul className="space-y-1 text-muted-foreground">
                      <li>• Remove console logs</li>
                      <li>• Fix var declarations</li>
                      <li>• Download fixed code</li>
                      <li>• Batch fixes available</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Footer */}
        <div className="mt-12 text-center text-sm text-muted-foreground">
          <p>Built with ❤️ for developers • Supports JS, TS, JSX, TSX and more</p>
        </div>
      </div>
    </div>
  );
}
