'use client';

import type { AnalysisResult } from '@/types/analysis';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { 
  AlertTriangle, 
  Shield, 
  Trash2, 
  GitBranch, 
  Gauge, 
  Zap,
  Building2,
  Wrench,
  Network,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Info
} from 'lucide-react';

interface AnalysisResultsProps {
  results: AnalysisResult;
}

export function AnalysisResults({ results }: AnalysisResultsProps): JSX.Element {
  const getSeverityColor = (severity: string): string => {
    const colors: Record<string, string> = {
      critical: 'bg-red-500',
      high: 'bg-orange-500',
      medium: 'bg-yellow-500',
      low: 'bg-blue-500',
    };
    return colors[severity] || 'bg-gray-500';
  };

  const getSeverityIcon = (severity: string): JSX.Element => {
    const icons: Record<string, JSX.Element> = {
      critical: <XCircle className="h-4 w-4" />,
      high: <AlertCircle className="h-4 w-4" />,
      medium: <AlertTriangle className="h-4 w-4" />,
      low: <Info className="h-4 w-4" />,
    };
    return icons[severity] || <Info className="h-4 w-4" />;
  };

  const totalIssues = 
    results.codeSmells.length +
    results.securityIssues.length +
    results.unusedImports.length +
    results.deadBranches.length +
    results.performanceWarnings.length;

  const criticalIssues = [
    ...results.codeSmells.filter((s) => s.severity === 'critical'),
    ...results.securityIssues.filter((s) => s.severity === 'critical'),
  ].length;

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Total Issues</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{totalIssues}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {criticalIssues} critical
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Maintainability</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{results.metrics.maintainabilityIndex}</div>
            <Progress value={results.metrics.maintainabilityIndex} className="mt-2" />
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Avg Complexity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{results.metrics.averageComplexity}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Cyclomatic complexity
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Lines of Code</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{results.metrics.codeLines}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {results.metrics.commentLines} comments
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Results */}
      <Card>
        <CardHeader>
          <CardTitle>Detailed Analysis</CardTitle>
          <CardDescription>Comprehensive code quality report</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="smells" className="w-full">
            <TabsList className="grid w-full grid-cols-4 lg:grid-cols-9">
              <TabsTrigger value="smells" className="flex items-center gap-1">
                <AlertTriangle className="h-3 w-3" />
                <span className="hidden sm:inline">Smells</span>
                <Badge variant="secondary" className="ml-1">{results.codeSmells.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="security" className="flex items-center gap-1">
                <Shield className="h-3 w-3" />
                <span className="hidden sm:inline">Security</span>
                <Badge variant="secondary" className="ml-1">{results.securityIssues.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="unused" className="flex items-center gap-1">
                <Trash2 className="h-3 w-3" />
                <span className="hidden sm:inline">Unused</span>
                <Badge variant="secondary" className="ml-1">{results.unusedImports.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="dead" className="flex items-center gap-1">
                <GitBranch className="h-3 w-3" />
                <span className="hidden sm:inline">Dead</span>
                <Badge variant="secondary" className="ml-1">{results.deadBranches.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="complexity" className="flex items-center gap-1">
                <Gauge className="h-3 w-3" />
                <span className="hidden sm:inline">Complex</span>
                <Badge variant="secondary" className="ml-1">{results.complexityHotspots.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="performance" className="flex items-center gap-1">
                <Zap className="h-3 w-3" />
                <span className="hidden sm:inline">Perf</span>
                <Badge variant="secondary" className="ml-1">{results.performanceWarnings.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="architecture" className="flex items-center gap-1">
                <Building2 className="h-3 w-3" />
                <span className="hidden sm:inline">Arch</span>
                <Badge variant="secondary" className="ml-1">{results.architecturalRisks.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="refactor" className="flex items-center gap-1">
                <Wrench className="h-3 w-3" />
                <span className="hidden sm:inline">Refactor</span>
                <Badge variant="secondary" className="ml-1">{results.refactorSuggestions.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="graph" className="flex items-center gap-1">
                <Network className="h-3 w-3" />
                <span className="hidden sm:inline">Graph</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="smells" className="space-y-4 mt-4">
              {results.codeSmells.length === 0 ? (
                <Alert>
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertTitle>No code smells detected!</AlertTitle>
                  <AlertDescription>Your code follows best practices.</AlertDescription>
                </Alert>
              ) : (
                results.codeSmells.map((smell, index) => (
                  <Alert key={index}>
                    <div className="flex items-start gap-3">
                      {getSeverityIcon(smell.severity)}
                      <div className="flex-1">
                        <AlertTitle className="flex items-center gap-2">
                          {smell.type}
                          <Badge className={getSeverityColor(smell.severity)}>
                            {smell.severity}
                          </Badge>
                        </AlertTitle>
                        <AlertDescription className="mt-2 space-y-1">
                          <p><strong>Line {smell.line}:</strong> {smell.message}</p>
                          <p className="text-green-600"><strong>Suggestion:</strong> {smell.suggestion}</p>
                        </AlertDescription>
                      </div>
                    </div>
                  </Alert>
                ))
              )}
            </TabsContent>

            <TabsContent value="security" className="space-y-4 mt-4">
              {results.securityIssues.length === 0 ? (
                <Alert>
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertTitle>No security issues found!</AlertTitle>
                  <AlertDescription>Your code appears secure.</AlertDescription>
                </Alert>
              ) : (
                results.securityIssues.map((issue, index) => (
                  <Alert key={index} variant="destructive">
                    <div className="flex items-start gap-3">
                      <Shield className="h-4 w-4" />
                      <div className="flex-1">
                        <AlertTitle className="flex items-center gap-2">
                          {issue.type}
                          <Badge className={getSeverityColor(issue.severity)}>
                            {issue.severity}
                          </Badge>
                          {issue.cwe && <Badge variant="outline">{issue.cwe}</Badge>}
                        </AlertTitle>
                        <AlertDescription className="mt-2 space-y-1">
                          <p><strong>Line {issue.line}:</strong> {issue.description}</p>
                          <p className="text-green-600"><strong>Fix:</strong> {issue.fix}</p>
                        </AlertDescription>
                      </div>
                    </div>
                  </Alert>
                ))
              )}
            </TabsContent>

            <TabsContent value="unused" className="space-y-4 mt-4">
              {results.unusedImports.length === 0 ? (
                <Alert>
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertTitle>No unused imports!</AlertTitle>
                  <AlertDescription>All imports are being used.</AlertDescription>
                </Alert>
              ) : (
                <Alert>
                  <Trash2 className="h-4 w-4" />
                  <AlertTitle>Unused Imports ({results.unusedImports.length})</AlertTitle>
                  <AlertDescription className="mt-2">
                    <ul className="space-y-1">
                      {results.unusedImports.map((imp, index) => (
                        <li key={index}>
                          <strong>Line {imp.line}:</strong> {imp.importName} from "{imp.module}"
                        </li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              )}
            </TabsContent>

            <TabsContent value="dead" className="space-y-4 mt-4">
              {results.deadBranches.length === 0 ? (
                <Alert>
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertTitle>No dead code!</AlertTitle>
                  <AlertDescription>All code paths are reachable.</AlertDescription>
                </Alert>
              ) : (
                results.deadBranches.map((branch, index) => (
                  <Alert key={index}>
                    <GitBranch className="h-4 w-4" />
                    <AlertTitle>Dead {branch.type} at line {branch.line}</AlertTitle>
                    <AlertDescription>{branch.reason}</AlertDescription>
                  </Alert>
                ))
              )}
            </TabsContent>

            <TabsContent value="complexity" className="space-y-4 mt-4">
              {results.complexityHotspots.length === 0 ? (
                <Alert>
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertTitle>Good complexity!</AlertTitle>
                  <AlertDescription>Functions are well-structured.</AlertDescription>
                </Alert>
              ) : (
                results.complexityHotspots.map((hotspot, index) => (
                  <Alert key={index}>
                    <Gauge className="h-4 w-4" />
                    <AlertTitle>
                      {hotspot.functionName} (Line {hotspot.line})
                    </AlertTitle>
                    <AlertDescription className="mt-2 space-y-1">
                      <p><strong>Cyclomatic:</strong> {hotspot.cyclomaticComplexity}</p>
                      <p><strong>Cognitive:</strong> {hotspot.cognitiveComplexity}</p>
                      <p className="text-orange-600"><strong>Action:</strong> {hotspot.recommendation}</p>
                    </AlertDescription>
                  </Alert>
                ))
              )}
            </TabsContent>

            <TabsContent value="performance" className="space-y-4 mt-4">
              {results.performanceWarnings.length === 0 ? (
                <Alert>
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertTitle>No performance issues!</AlertTitle>
                  <AlertDescription>Code is optimized.</AlertDescription>
                </Alert>
              ) : (
                results.performanceWarnings.map((warning, index) => (
                  <Alert key={index}>
                    <div className="flex items-start gap-3">
                      <Zap className="h-4 w-4" />
                      <div className="flex-1">
                        <AlertTitle className="flex items-center gap-2">
                          {warning.type}
                          <Badge className={getSeverityColor(warning.severity)}>
                            {warning.severity}
                          </Badge>
                        </AlertTitle>
                        <AlertDescription className="mt-2 space-y-1">
                          <p><strong>Line {warning.line}:</strong> {warning.issue}</p>
                          <p><strong>Impact:</strong> {warning.impact}</p>
                          <p className="text-green-600"><strong>Solution:</strong> {warning.solution}</p>
                        </AlertDescription>
                      </div>
                    </div>
                  </Alert>
                ))
              )}
            </TabsContent>

            <TabsContent value="architecture" className="space-y-4 mt-4">
              {results.architecturalRisks.length === 0 ? (
                <Alert>
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertTitle>Solid architecture!</AlertTitle>
                  <AlertDescription>No architectural concerns detected.</AlertDescription>
                </Alert>
              ) : (
                results.architecturalRisks.map((risk, index) => (
                  <Alert key={index}>
                    <div className="flex items-start gap-3">
                      <Building2 className="h-4 w-4" />
                      <div className="flex-1">
                        <AlertTitle className="flex items-center gap-2">
                          {risk.type}
                          <Badge className={getSeverityColor(risk.severity)}>
                            {risk.severity}
                          </Badge>
                        </AlertTitle>
                        <AlertDescription className="mt-2 space-y-1">
                          <p>{risk.description}</p>
                          <p className="text-green-600"><strong>Recommendation:</strong> {risk.recommendation}</p>
                        </AlertDescription>
                      </div>
                    </div>
                  </Alert>
                ))
              )}
            </TabsContent>

            <TabsContent value="refactor" className="space-y-4 mt-4">
              {results.refactorSuggestions.length === 0 ? (
                <Alert>
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertTitle>Code is clean!</AlertTitle>
                  <AlertDescription>No refactoring needed.</AlertDescription>
                </Alert>
              ) : (
                results.refactorSuggestions.map((suggestion, index) => (
                  <Alert key={index}>
                    <div className="flex items-start gap-3">
                      <Wrench className="h-4 w-4" />
                      <div className="flex-1">
                        <AlertTitle className="flex items-center gap-2">
                          {suggestion.title}
                          <Badge variant={
                            suggestion.priority === 'high' ? 'destructive' :
                            suggestion.priority === 'medium' ? 'default' : 'secondary'
                          }>
                            {suggestion.priority}
                          </Badge>
                        </AlertTitle>
                        <AlertDescription className="mt-2 space-y-2">
                          <p>{suggestion.description}</p>
                          <p><strong>Effort:</strong> {suggestion.effort}</p>
                          <div>
                            <strong>Benefits:</strong>
                            <ul className="list-disc list-inside ml-4">
                              {suggestion.benefits.map((benefit, i) => (
                                <li key={i}>{benefit}</li>
                              ))}
                            </ul>
                          </div>
                        </AlertDescription>
                      </div>
                    </div>
                  </Alert>
                ))
              )}
            </TabsContent>

            <TabsContent value="graph" className="mt-4">
              <Alert>
                <Network className="h-4 w-4" />
                <AlertTitle>Dependency Graph</AlertTitle>
                <AlertDescription className="mt-2">
                  <div className="space-y-2">
                    {results.dependencyGraph.map((node) => (
                      <div key={node.id} className="border rounded p-3">
                        <p className="font-semibold">{node.name}</p>
                        <p className="text-sm text-muted-foreground">Type: {node.type}</p>
                        {node.dependencies.length > 0 && (
                          <div className="mt-2">
                            <p className="text-sm font-medium">Dependencies:</p>
                            <ul className="text-sm list-disc list-inside ml-2">
                              {node.dependencies.map((dep) => (
                                <li key={dep}>{dep}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </AlertDescription>
              </Alert>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
