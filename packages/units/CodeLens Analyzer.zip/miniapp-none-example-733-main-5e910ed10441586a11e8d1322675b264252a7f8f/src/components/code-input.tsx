'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Upload, Code2, FileCode } from 'lucide-react';

interface CodeInputProps {
  onAnalyze: (code: string, fileName?: string) => void;
  isAnalyzing: boolean;
}

export function CodeInput({ onAnalyze, isAnalyzing }: CodeInputProps): JSX.Element {
  const [code, setCode] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>): void => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e: ProgressEvent<FileReader>): void => {
        const content = e.target?.result as string;
        setCode(content);
        setFileName(file.name);
      };
      reader.readAsText(file);
    }
  };

  const handleAnalyze = (): void => {
    if (code.trim()) {
      onAnalyze(code, fileName);
    }
  };

  const loadSampleCode = (): void => {
    const sample = `import React, { useState } from 'react';
import { Button } from './components/ui/button';

// TODO: Add proper error handling
function UserProfile({ userId }) {
  var userData = null;
  const [loading, setLoading] = useState(false);
  
  const fetchUser = async () => {
    setLoading(true);
    const response = await fetch('https://api.example.com/users/' + userId);
    userData = await response.json();
    console.log('User data:', userData);
    setLoading(false);
  };
  
  if (true) {
    console.log('This always runs');
  }
  
  const password = "hardcoded123";
  
  return (
    <div>
      <div dangerouslySetInnerHTML={{ __html: userData.bio }} />
      {[1,2,3,4,5].map(item => {
        return [1,2,3].filter(x => x > 1).map(y => y * 2);
      })}
    </div>
  );
}

export default UserProfile;`;
    setCode(sample);
    setFileName('sample.tsx');
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Code2 className="h-6 w-6" />
          Code Input
        </CardTitle>
        <CardDescription>Paste code, upload a file, or use sample code</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="paste" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="paste">Paste Code</TabsTrigger>
            <TabsTrigger value="upload">Upload File</TabsTrigger>
            <TabsTrigger value="sample">Sample</TabsTrigger>
          </TabsList>
          
          <TabsContent value="paste" className="space-y-4">
            <Textarea
              placeholder="Paste your code here..."
              value={code}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>): void => setCode(e.target.value)}
              className="min-h-[400px] font-mono text-sm"
            />
          </TabsContent>
          
          <TabsContent value="upload" className="space-y-4">
            <div className="flex flex-col items-center justify-center border-2 border-dashed rounded-lg p-12 hover:border-primary transition-colors">
              <Upload className="h-12 w-12 text-muted-foreground mb-4" />
              <label htmlFor="file-upload" className="cursor-pointer">
                <Button type="button" variant="secondary" asChild>
                  <span>
                    <FileCode className="mr-2 h-4 w-4" />
                    Choose File
                  </span>
                </Button>
                <input
                  id="file-upload"
                  type="file"
                  accept=".js,.jsx,.ts,.tsx,.py,.java,.cpp,.c,.go,.rs"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
              {fileName && (
                <p className="mt-4 text-sm text-muted-foreground">
                  Selected: {fileName}
                </p>
              )}
            </div>
            {code && (
              <Textarea
                value={code}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>): void => setCode(e.target.value)}
                className="min-h-[300px] font-mono text-sm"
              />
            )}
          </TabsContent>
          
          <TabsContent value="sample" className="space-y-4">
            <div className="flex items-center justify-center p-8 border rounded-lg">
              <Button onClick={loadSampleCode} size="lg">
                Load Sample Code with Issues
              </Button>
            </div>
            {code && (
              <Textarea
                value={code}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>): void => setCode(e.target.value)}
                className="min-h-[300px] font-mono text-sm"
              />
            )}
          </TabsContent>
        </Tabs>
        
        <div className="mt-6 flex justify-end">
          <Button 
            onClick={handleAnalyze} 
            disabled={!code.trim() || isAnalyzing}
            size="lg"
          >
            {isAnalyzing ? 'Analyzing...' : 'Analyze Code'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
