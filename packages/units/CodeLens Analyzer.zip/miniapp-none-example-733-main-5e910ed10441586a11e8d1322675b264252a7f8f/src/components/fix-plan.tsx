'use client';

import type { FixPlan } from '@/types/analysis';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Download, CheckCircle, Clock, Wand2 } from 'lucide-react';

interface FixPlanProps {
  fixPlans: FixPlan[];
  originalCode: string;
}

export function FixPlanComponent({ fixPlans, originalCode }: FixPlanProps): JSX.Element {
  const applyFix = (plan: FixPlan): string => {
    let fixedCode = originalCode;
    const lines = fixedCode.split('\n');
    
    // Sort changes in reverse order to maintain line numbers
    const sortedChanges = [...plan.changes].sort((a, b) => b.line - a.line);
    
    sortedChanges.forEach((change) => {
      const lineIndex = change.line - 1;
      if (lineIndex >= 0 && lineIndex < lines.length) {
        if (change.fixed === '') {
          // Remove line
          lines.splice(lineIndex, 1);
        } else {
          // Replace line
          lines[lineIndex] = change.fixed;
        }
      }
    });
    
    return lines.join('\n');
  };

  const downloadFixedCode = (plan: FixPlan): void => {
    const fixedCode = applyFix(plan);
    const blob = new Blob([fixedCode], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fixed-${plan.id}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const applyAllFixes = (): void => {
    let fixedCode = originalCode;
    const allLines = fixedCode.split('\n');
    
    // Collect all changes from all plans
    const allChanges = fixPlans.flatMap((plan) => plan.changes);
    
    // Sort in reverse to maintain line numbers
    const sortedChanges = [...allChanges].sort((a, b) => b.line - a.line);
    
    sortedChanges.forEach((change) => {
      const lineIndex = change.line - 1;
      if (lineIndex >= 0 && lineIndex < allLines.length) {
        if (change.fixed === '') {
          allLines.splice(lineIndex, 1);
        } else {
          allLines[lineIndex] = change.fixed;
        }
      }
    });
    
    fixedCode = allLines.join('\n');
    
    const blob = new Blob([fixedCode], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'fully-fixed-code.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (fixPlans.length === 0) {
    return (
      <Alert>
        <CheckCircle className="h-4 w-4" />
        <AlertTitle>No auto-fixable issues!</AlertTitle>
        <AlertDescription>
          Your code doesn't have any issues that can be automatically fixed.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Wand2 className="h-5 w-5" />
              One-Click Fix Plans
            </CardTitle>
            <CardDescription>
              Automatically fix common issues
            </CardDescription>
          </div>
          {fixPlans.length > 1 && (
            <Button onClick={applyAllFixes} size="lg">
              <Download className="mr-2 h-4 w-4" />
              Apply All Fixes
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible className="w-full">
          {fixPlans.map((plan) => (
            <AccordionItem key={plan.id} value={plan.id}>
              <AccordionTrigger>
                <div className="flex items-center gap-3 text-left">
                  <span>{plan.title}</span>
                  <Badge variant={plan.autoFixable ? 'default' : 'secondary'}>
                    {plan.autoFixable ? 'Auto-fixable' : 'Manual'}
                  </Badge>
                  <Badge variant="outline" className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {plan.estimatedTime}
                  </Badge>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-4 pt-2">
                  <p className="text-sm text-muted-foreground">{plan.description}</p>
                  
                  <div className="space-y-2">
                    <h4 className="text-sm font-semibold">Changes ({plan.changes.length}):</h4>
                    <div className="space-y-2">
                      {plan.changes.slice(0, 5).map((change, index) => (
                        <div key={index} className="border rounded p-3 text-sm">
                          <p className="font-medium mb-2">Line {change.line}:</p>
                          {change.original && (
                            <div className="bg-red-50 dark:bg-red-950 border-l-2 border-red-500 p-2 mb-1">
                              <code className="text-xs">- {change.original}</code>
                            </div>
                          )}
                          {change.fixed && (
                            <div className="bg-green-50 dark:bg-green-950 border-l-2 border-green-500 p-2">
                              <code className="text-xs">+ {change.fixed}</code>
                            </div>
                          )}
                          {change.fixed === '' && (
                            <div className="bg-gray-50 dark:bg-gray-950 border-l-2 border-gray-500 p-2">
                              <code className="text-xs italic">(line removed)</code>
                            </div>
                          )}
                        </div>
                      ))}
                      {plan.changes.length > 5 && (
                        <p className="text-xs text-muted-foreground">
                          ...and {plan.changes.length - 5} more changes
                        </p>
                      )}
                    </div>
                  </div>
                  
                  <Button onClick={(): void => downloadFixedCode(plan)} className="w-full">
                    <Download className="mr-2 h-4 w-4" />
                    Download Fixed Code
                  </Button>
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </CardContent>
    </Card>
  );
}
