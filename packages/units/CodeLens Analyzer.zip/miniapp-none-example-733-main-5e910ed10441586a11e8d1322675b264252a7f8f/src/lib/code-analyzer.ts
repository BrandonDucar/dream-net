import type {
  AnalysisResult,
  CodeSmell,
  SecurityIssue,
  UnusedImport,
  DeadBranch,
  ComplexityHotspot,
  PerformanceWarning,
  DependencyNode,
  ArchitecturalRisk,
  RefactorSuggestion,
  FixPlan,
} from '@/types/analysis';

export class CodeAnalyzer {
  private code: string;
  private lines: string[];

  constructor(code: string) {
    this.code = code;
    this.lines = code.split('\n');
  }

  public analyze(): AnalysisResult {
    return {
      codeSmells: this.detectCodeSmells(),
      securityIssues: this.detectSecurityIssues(),
      unusedImports: this.detectUnusedImports(),
      deadBranches: this.detectDeadBranches(),
      complexityHotspots: this.detectComplexityHotspots(),
      performanceWarnings: this.detectPerformanceWarnings(),
      architecturalRisks: this.detectArchitecturalRisks(),
      refactorSuggestions: this.generateRefactorSuggestions(),
      fixPlans: this.generateFixPlans(),
      dependencyGraph: this.buildDependencyGraph(),
      metrics: this.calculateMetrics(),
    };
  }

  private detectCodeSmells(): CodeSmell[] {
    const smells: CodeSmell[] = [];

    this.lines.forEach((line, index) => {
      const lineNum = index + 1;
      const trimmed = line.trim();

      // Long lines
      if (line.length > 120) {
        smells.push({
          type: 'Long Line',
          severity: 'low',
          line: lineNum,
          column: 120,
          message: `Line exceeds 120 characters (${line.length} chars)`,
          suggestion: 'Break into multiple lines or extract to variable',
        });
      }

      // Magic numbers
      const magicNumberMatch = trimmed.match(/[^a-zA-Z_]\d{2,}/);
      if (magicNumberMatch && !trimmed.includes('//') && !trimmed.includes('const')) {
        smells.push({
          type: 'Magic Number',
          severity: 'medium',
          line: lineNum,
          column: line.indexOf(magicNumberMatch[0]),
          message: 'Magic number detected',
          suggestion: 'Extract to named constant',
        });
      }

      // Deep nesting
      const indentLevel = (line.match(/^  /g) || []).length;
      if (indentLevel > 4) {
        smells.push({
          type: 'Deep Nesting',
          severity: 'high',
          line: lineNum,
          column: 0,
          message: `Deep nesting level: ${indentLevel}`,
          suggestion: 'Extract nested logic into separate functions',
        });
      }

      // TODO comments
      if (trimmed.includes('TODO') || trimmed.includes('FIXME')) {
        smells.push({
          type: 'TODO Comment',
          severity: 'low',
          line: lineNum,
          column: line.indexOf('TODO') !== -1 ? line.indexOf('TODO') : line.indexOf('FIXME'),
          message: 'Unresolved TODO/FIXME comment',
          suggestion: 'Resolve or create a ticket',
        });
      }

      // Console.log in production
      if (trimmed.includes('console.log') || trimmed.includes('console.error')) {
        smells.push({
          type: 'Console Statement',
          severity: 'medium',
          line: lineNum,
          column: line.indexOf('console'),
          message: 'Console statement in code',
          suggestion: 'Remove or replace with proper logging',
        });
      }

      // var usage
      if (trimmed.match(/\bvar\s+/)) {
        smells.push({
          type: 'Var Declaration',
          severity: 'medium',
          line: lineNum,
          column: line.indexOf('var'),
          message: 'Using var instead of let/const',
          suggestion: 'Replace with let or const',
        });
      }

      // Large functions
      if (trimmed.match(/^(function|const.*=.*=>|async function)/)) {
        let braceCount = 0;
        let functionLines = 0;
        for (let i = index; i < this.lines.length; i++) {
          braceCount += (this.lines[i].match(/{/g) || []).length;
          braceCount -= (this.lines[i].match(/}/g) || []).length;
          functionLines++;
          if (braceCount === 0 && functionLines > 50) {
            smells.push({
              type: 'Large Function',
              severity: 'high',
              line: lineNum,
              column: 0,
              message: `Function exceeds 50 lines (${functionLines} lines)`,
              suggestion: 'Split into smaller, focused functions',
            });
            break;
          }
          if (braceCount === 0) break;
        }
      }
    });

    return smells;
  }

  private detectSecurityIssues(): SecurityIssue[] {
    const issues: SecurityIssue[] = [];

    this.lines.forEach((line, index) => {
      const lineNum = index + 1;
      const trimmed = line.trim();

      // SQL Injection
      if (trimmed.match(/['"`]\s*\+\s*\w+.*SELECT|INSERT|UPDATE|DELETE/i)) {
        issues.push({
          type: 'SQL Injection',
          severity: 'critical',
          line: lineNum,
          description: 'Potential SQL injection vulnerability',
          cwe: 'CWE-89',
          fix: 'Use parameterized queries or ORM',
        });
      }

      // XSS
      if (trimmed.match(/innerHTML|dangerouslySetInnerHTML/)) {
        issues.push({
          type: 'XSS Vulnerability',
          severity: 'high',
          line: lineNum,
          description: 'Potential XSS vulnerability through innerHTML',
          cwe: 'CWE-79',
          fix: 'Sanitize input or use textContent/innerText',
        });
      }

      // Hardcoded credentials
      if (trimmed.match(/(password|apiKey|secret|token)\s*=\s*['"][^'"]+['"]/i)) {
        issues.push({
          type: 'Hardcoded Credentials',
          severity: 'critical',
          line: lineNum,
          description: 'Hardcoded sensitive credentials detected',
          cwe: 'CWE-798',
          fix: 'Use environment variables',
        });
      }

      // eval usage
      if (trimmed.match(/\beval\s*\(/)) {
        issues.push({
          type: 'Eval Usage',
          severity: 'high',
          line: lineNum,
          description: 'Dangerous eval() usage',
          cwe: 'CWE-95',
          fix: 'Avoid eval() or use safer alternatives',
        });
      }

      // Weak crypto
      if (trimmed.match(/Math\.random\(\)/) && trimmed.match(/password|token|key/i)) {
        issues.push({
          type: 'Weak Randomness',
          severity: 'high',
          line: lineNum,
          description: 'Math.random() used for security-sensitive operation',
          cwe: 'CWE-330',
          fix: 'Use crypto.getRandomValues() or similar',
        });
      }
    });

    return issues;
  }

  private detectUnusedImports(): UnusedImport[] {
    const unused: UnusedImport[] = [];
    const imports: Map<string, { line: number; module: string }> = new Map();
    const usage: Set<string> = new Set();

    // Collect imports
    this.lines.forEach((line, index) => {
      const importMatch = line.match(/import\s+(?:{([^}]+)}|(\w+))\s+from\s+['"]([^'"]+)['"]/);
      if (importMatch) {
        const module = importMatch[3];
        if (importMatch[1]) {
          // Named imports
          importMatch[1].split(',').forEach((name) => {
            const cleanName = name.trim().split(' as ')[0].trim();
            imports.set(cleanName, { line: index + 1, module });
          });
        } else if (importMatch[2]) {
          // Default import
          imports.set(importMatch[2], { line: index + 1, module });
        }
      }
    });

    // Check usage
    const codeWithoutImports = this.lines.slice(0).join('\n');
    imports.forEach((data, name) => {
      const regex = new RegExp(`\\b${name}\\b`, 'g');
      const matches = codeWithoutImports.match(regex) || [];
      if (matches.length <= 1) {
        // Only the import itself
        unused.push({
          importName: name,
          line: data.line,
          module: data.module,
        });
      }
    });

    return unused;
  }

  private detectDeadBranches(): DeadBranch[] {
    const dead: DeadBranch[] = [];

    this.lines.forEach((line, index) => {
      const lineNum = index + 1;
      const trimmed = line.trim();

      // if (true) or if (false)
      if (trimmed.match(/if\s*\(\s*(true|false)\s*\)/)) {
        dead.push({
          type: 'if',
          line: lineNum,
          reason: 'Condition always evaluates to constant',
        });
      }

      // Unreachable code after return
      if (trimmed.startsWith('return') && index < this.lines.length - 1) {
        const nextLine = this.lines[index + 1].trim();
        if (nextLine && !nextLine.startsWith('}') && !nextLine.startsWith('//')) {
          dead.push({
            type: 'function',
            line: lineNum + 1,
            reason: 'Unreachable code after return statement',
          });
        }
      }
    });

    return dead;
  }

  private detectComplexityHotspots(): ComplexityHotspot[] {
    const hotspots: ComplexityHotspot[] = [];
    const functionRegex = /(?:function\s+(\w+)|const\s+(\w+)\s*=)|(?:(\w+)\s*:\s*function)/;

    let currentFunction: string | null = null;
    let currentFunctionLine = 0;
    let complexity = 1;

    this.lines.forEach((line, index) => {
      const lineNum = index + 1;
      const trimmed = line.trim();

      // Start of function
      const match = line.match(functionRegex);
      if (match) {
        currentFunction = match[1] || match[2] || match[3] || 'anonymous';
        currentFunctionLine = lineNum;
        complexity = 1;
      }

      // Count complexity
      if (currentFunction) {
        // Conditional statements
        if (trimmed.match(/\b(if|else if|case|catch)\b/)) complexity++;
        if (trimmed.match(/\b(for|while|do)\b/)) complexity++;
        if (trimmed.match(/\?\s*.*:/)) complexity++; // ternary
        if (trimmed.match(/&&|\|\|/)) complexity++;

        // End of function
        if (trimmed === '}' && currentFunction) {
          if (complexity > 10) {
            hotspots.push({
              functionName: currentFunction,
              line: currentFunctionLine,
              cyclomaticComplexity: complexity,
              cognitiveComplexity: Math.floor(complexity * 1.2),
              recommendation: complexity > 15 ? 'Critical: Refactor immediately' : 'Consider breaking into smaller functions',
            });
          }
          currentFunction = null;
        }
      }
    });

    return hotspots;
  }

  private detectPerformanceWarnings(): PerformanceWarning[] {
    const warnings: PerformanceWarning[] = [];

    this.lines.forEach((line, index) => {
      const lineNum = index + 1;
      const trimmed = line.trim();

      // Nested loops
      if (trimmed.match(/for.*for/)) {
        warnings.push({
          type: 'Nested Loops',
          severity: 'high',
          line: lineNum,
          issue: 'Nested loops detected',
          impact: 'O(n²) or worse time complexity',
          solution: 'Consider using hash maps or optimize algorithm',
        });
      }

      // Synchronous operations in loops
      if (trimmed.includes('forEach') && trimmed.includes('await')) {
        warnings.push({
          type: 'Async in Loop',
          severity: 'medium',
          line: lineNum,
          issue: 'Await inside forEach',
          impact: 'Sequential execution, not parallel',
          solution: 'Use Promise.all() with map()',
        });
      }

      // Large array operations
      if (trimmed.match(/\.map\(.*\.filter\(/)) {
        warnings.push({
          type: 'Chained Array Operations',
          severity: 'low',
          line: lineNum,
          issue: 'Multiple array iterations',
          impact: 'Unnecessary iterations over data',
          solution: 'Combine operations or use single reduce()',
        });
      }

      // Memory leaks
      if (trimmed.match(/addEventListener/) && !this.code.includes('removeEventListener')) {
        warnings.push({
          type: 'Memory Leak',
          severity: 'medium',
          line: lineNum,
          issue: 'Event listener without cleanup',
          impact: 'Potential memory leak',
          solution: 'Add removeEventListener in cleanup',
        });
      }
    });

    return warnings;
  }

  private detectArchitecturalRisks(): ArchitecturalRisk[] {
    const risks: ArchitecturalRisk[] = [];

    // Tight coupling
    const importCount = this.lines.filter((line) => line.trim().startsWith('import')).length;
    if (importCount > 20) {
      risks.push({
        type: 'Tight Coupling',
        severity: 'high',
        description: `Excessive imports (${importCount}) indicate tight coupling`,
        files: ['current file'],
        recommendation: 'Refactor to reduce dependencies, use dependency injection',
      });
    }

    // God object
    const classMatch = this.code.match(/class\s+\w+/);
    if (classMatch && this.lines.length > 500) {
      risks.push({
        type: 'God Object',
        severity: 'high',
        description: 'Large class/file exceeds 500 lines',
        files: ['current file'],
        recommendation: 'Split into smaller, focused modules',
      });
    }

    // Missing error handling
    const hasAsync = this.code.includes('async');
    const hasTryCatch = this.code.includes('try') && this.code.includes('catch');
    if (hasAsync && !hasTryCatch) {
      risks.push({
        type: 'Missing Error Handling',
        severity: 'medium',
        description: 'Async code without try-catch blocks',
        files: ['current file'],
        recommendation: 'Add proper error handling and recovery',
      });
    }

    return risks;
  }

  private generateRefactorSuggestions(): RefactorSuggestion[] {
    const suggestions: RefactorSuggestion[] = [];

    // Extract repeated code
    const codeBlocks: Map<string, number[]> = new Map();
    for (let i = 0; i < this.lines.length - 3; i++) {
      const block = this.lines.slice(i, i + 3).join('\n').trim();
      if (block.length > 20) {
        if (!codeBlocks.has(block)) {
          codeBlocks.set(block, []);
        }
        codeBlocks.get(block)!.push(i + 1);
      }
    }

    codeBlocks.forEach((lines, block) => {
      if (lines.length > 1) {
        suggestions.push({
          priority: 'high',
          title: 'Extract Duplicate Code',
          description: 'Code block appears multiple times',
          affectedLines: lines,
          effort: '30 minutes',
          benefits: ['Improved maintainability', 'Reduced code size', 'Single source of truth'],
        });
      }
    });

    // Extract constants
    const literalCount = (this.code.match(/['"][^'"]{10,}['"]/g) || []).length;
    if (literalCount > 5) {
      suggestions.push({
        priority: 'medium',
        title: 'Extract String Literals',
        description: `Found ${literalCount} string literals that could be constants`,
        affectedLines: [],
        effort: '15 minutes',
        benefits: ['Easier to maintain', 'Reusable values', 'Better i18n support'],
      });
    }

    return suggestions;
  }

  private generateFixPlans(): FixPlan[] {
    const plans: FixPlan[] = [];

    // Remove console logs
    const consoleLogs: number[] = [];
    this.lines.forEach((line, index) => {
      if (line.includes('console.log') || line.includes('console.error')) {
        consoleLogs.push(index);
      }
    });

    if (consoleLogs.length > 0) {
      plans.push({
        id: 'remove-console',
        title: 'Remove Console Statements',
        description: `Remove ${consoleLogs.length} console statements`,
        changes: consoleLogs.map((lineIndex) => ({
          file: 'current',
          line: lineIndex + 1,
          original: this.lines[lineIndex],
          fixed: '',
        })),
        estimatedTime: '2 minutes',
        autoFixable: true,
      });
    }

    // Fix var declarations
    const varDeclarations: number[] = [];
    this.lines.forEach((line, index) => {
      if (line.trim().match(/\bvar\s+/)) {
        varDeclarations.push(index);
      }
    });

    if (varDeclarations.length > 0) {
      plans.push({
        id: 'fix-var',
        title: 'Replace var with const/let',
        description: `Convert ${varDeclarations.length} var declarations`,
        changes: varDeclarations.map((lineIndex) => ({
          file: 'current',
          line: lineIndex + 1,
          original: this.lines[lineIndex],
          fixed: this.lines[lineIndex].replace(/\bvar\b/, 'const'),
        })),
        estimatedTime: '1 minute',
        autoFixable: true,
      });
    }

    return plans;
  }

  private buildDependencyGraph(): DependencyNode[] {
    const nodes: DependencyNode[] = [];
    const imports: Map<string, string[]> = new Map();

    this.lines.forEach((line) => {
      const importMatch = line.match(/import\s+.*from\s+['"]([^'"]+)['"]/);
      if (importMatch) {
        const module = importMatch[1];
        if (!imports.has('current')) {
          imports.set('current', []);
        }
        imports.get('current')!.push(module);
      }
    });

    // Current file node
    nodes.push({
      id: 'current',
      name: 'Current File',
      type: 'file',
      dependencies: imports.get('current') || [],
      dependents: [],
    });

    // Module nodes
    (imports.get('current') || []).forEach((module) => {
      nodes.push({
        id: module,
        name: module,
        type: 'module',
        dependencies: [],
        dependents: ['current'],
      });
    });

    return nodes;
  }

  private calculateMetrics(): AnalysisResult['metrics'] {
    const totalLines = this.lines.length;
    const commentLines = this.lines.filter((line) => line.trim().startsWith('//')).length;
    const blankLines = this.lines.filter((line) => line.trim() === '').length;
    const codeLines = totalLines - commentLines - blankLines;

    // Simple complexity average
    const complexitySum = this.detectComplexityHotspots().reduce((sum, h) => sum + h.cyclomaticComplexity, 0);
    const functionCount = Math.max(1, this.detectComplexityHotspots().length);
    const averageComplexity = complexitySum / functionCount;

    // Maintainability index (simplified)
    const maintainabilityIndex = Math.max(0, Math.min(100, 171 - 5.2 * Math.log(codeLines) - 0.23 * averageComplexity));

    return {
      totalLines,
      codeLines,
      commentLines,
      blankLines,
      averageComplexity: Math.round(averageComplexity * 10) / 10,
      maintainabilityIndex: Math.round(maintainabilityIndex),
    };
  }
}
