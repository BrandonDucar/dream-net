export interface CodeSmell {
  type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  line: number;
  column: number;
  message: string;
  suggestion: string;
}

export interface SecurityIssue {
  type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  line: number;
  description: string;
  cwe?: string;
  fix: string;
}

export interface UnusedImport {
  importName: string;
  line: number;
  module: string;
}

export interface DeadBranch {
  type: 'if' | 'else' | 'switch' | 'case' | 'function';
  line: number;
  reason: string;
}

export interface ComplexityHotspot {
  functionName: string;
  line: number;
  cyclomaticComplexity: number;
  cognitiveComplexity: number;
  recommendation: string;
}

export interface PerformanceWarning {
  type: string;
  severity: 'low' | 'medium' | 'high';
  line: number;
  issue: string;
  impact: string;
  solution: string;
}

export interface DependencyNode {
  id: string;
  name: string;
  type: 'file' | 'module' | 'function';
  dependencies: string[];
  dependents: string[];
}

export interface ArchitecturalRisk {
  type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  files: string[];
  recommendation: string;
}

export interface RefactorSuggestion {
  priority: 'low' | 'medium' | 'high';
  title: string;
  description: string;
  affectedLines: number[];
  effort: string;
  benefits: string[];
}

export interface FixPlan {
  id: string;
  title: string;
  description: string;
  changes: Array<{
    file: string;
    line: number;
    original: string;
    fixed: string;
  }>;
  estimatedTime: string;
  autoFixable: boolean;
}

export interface AnalysisResult {
  codeSmells: CodeSmell[];
  securityIssues: SecurityIssue[];
  unusedImports: UnusedImport[];
  deadBranches: DeadBranch[];
  complexityHotspots: ComplexityHotspot[];
  performanceWarnings: PerformanceWarning[];
  architecturalRisks: ArchitecturalRisk[];
  refactorSuggestions: RefactorSuggestion[];
  fixPlans: FixPlan[];
  dependencyGraph: DependencyNode[];
  metrics: {
    totalLines: number;
    codeLines: number;
    commentLines: number;
    blankLines: number;
    averageComplexity: number;
    maintainabilityIndex: number;
  };
}
