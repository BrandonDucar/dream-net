export const ONCHAINKIT_PROJECT_ID = 'aeda8b48-68f5-4e30-b42e-2f59b3dcbf7b';
export const ONCHAINKIT_API_KEY = '8TXI1MjRPz_J7PQyvPnT8bJe9Z3Rcp1Y';
