import type { Metadata } from 'next';
import '@coinbase/onchainkit/styles.css';
import './globals.css';
import { Providers } from './providers';
import FarcasterWrapper from "@/components/FarcasterWrapper";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
        <html lang="en">
          <body>
            <Providers>
      <FarcasterWrapper>
        {children}
      </FarcasterWrapper>
      </Providers>
          </body>
        </html>
      );
}

export const metadata: Metadata = {
        title: "CryptoGuardian",
        description: "CryptoGuardian is your wallet's bodyguard. It monitors contracts, flags risks, tracks approvals, and warns of threats. Ensure secure transactions with automated safety checks and spending limits.",
        other: { "fc:frame": JSON.stringify({"version":"next","imageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_0c8a0f01-cbfa-492e-ac97-1da584c61ba4-uvs1fV1bPbAYAdzz4wnvNdFnuUZ5Gh","button":{"title":"Open with Ohara","action":{"type":"launch_frame","name":"CryptoGuardian","url":"https://ocean-location-819.app.ohara.ai","splashImageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/farcaster/splash_images/splash_image1.svg","splashBackgroundColor":"#ffffff"}}}
        ) }
    };
