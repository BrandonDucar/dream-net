'use client'
import { useEffect, useState } from 'react';
import { useAccount } from 'wagmi';
import { sdk } from '@farcaster/miniapp-sdk';
import { Shield, AlertTriangle, CheckCircle, Activity, FileSearch, Lock, TrendingDown } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ContractScanner } from '@/components/contract-scanner';
import { ApprovalMonitor } from '@/components/approval-monitor';
import { RiskHeatmap } from '@/components/risk-heatmap';
import { AlertSystem } from '@/components/alert-system';
import { SpendingLimits } from '@/components/spending-limits';
import { SecurityScore } from '@/components/security-score';
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function XKeeperPage() {
  const { address, status } = useAccount();
  const [username, setUsername] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])

  useEffect(() => {
    let cancelled = false;

    async function loadFarcasterContext() {
      try {
        await sdk.actions.ready();
        const context = await sdk.context;
        if (!cancelled) {
          setUsername(context?.user?.username ?? null);
        }
      } catch (error) {
        if (!cancelled) {
          setUsername(null);
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    loadFarcasterContext();
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading || status === 'connecting' || status === 'reconnecting') {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center space-y-4">
          <Shield className="w-16 h-16 text-blue-600 mx-auto animate-pulse" />
          <p className="text-lg font-medium text-gray-900">Initializing XKEEPER...</p>
          <p className="text-sm text-gray-600">Preparing your crypto bodyguard</p>
        </div>
      </div>
    );
  }

  if (!address) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <Shield className="w-16 h-16 text-blue-600 mx-auto mb-4" />
            <CardTitle className="text-2xl">XKEEPER</CardTitle>
            <CardDescription>Your Personal Crypto Bodyguard</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 text-center">
            <p className="text-gray-700">
              Please open XKEEPER inside Warpcast to connect your Base smart wallet and start monitoring your security.
            </p>
            <div className="bg-blue-50 p-4 rounded-lg text-left space-y-2">
              <p className="text-sm font-semibold text-blue-900">What XKEEPER does:</p>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>✓ Monitors all contract interactions</li>
                <li>✓ Detects social engineering attempts</li>
                <li>✓ Tracks token approvals</li>
                <li>✓ Shows risk heatmaps</li>
                <li>✓ Warns about compromised wallets</li>
                <li>✓ Auto-limits spending</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-200 bg-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8 text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">XKEEPER</h1>
                <p className="text-xs text-gray-600">Your Crypto Bodyguard</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs text-gray-600">Connected Wallet</div>
              <div className="text-sm font-mono text-gray-900">
                {address.slice(0, 6)}...{address.slice(-4)}
              </div>
              {username && (
                <div className="text-xs text-blue-600">@{username}</div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Security Score Overview */}
        <SecurityScore address={address} />

        {/* Quick Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-600">Active Approvals</p>
                  <p className="text-2xl font-bold text-gray-900">12</p>
                </div>
                <FileSearch className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-600">High Risk</p>
                  <p className="text-2xl font-bold text-red-600">3</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-red-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-600">Protected</p>
                  <p className="text-2xl font-bold text-green-600">9</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-600">Monitoring</p>
                  <p className="text-2xl font-bold text-blue-600">24/7</p>
                </div>
                <Activity className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Features Tabs */}
        <Tabs defaultValue="scanner" className="w-full">
          <TabsList className="grid w-full grid-cols-3 lg:grid-cols-5">
            <TabsTrigger value="scanner">Scanner</TabsTrigger>
            <TabsTrigger value="approvals">Approvals</TabsTrigger>
            <TabsTrigger value="heatmap">Heatmap</TabsTrigger>
            <TabsTrigger value="alerts">Alerts</TabsTrigger>
            <TabsTrigger value="limits">Limits</TabsTrigger>
          </TabsList>

          <TabsContent value="scanner" className="space-y-4">
            <ContractScanner address={address} />
          </TabsContent>

          <TabsContent value="approvals" className="space-y-4">
            <ApprovalMonitor address={address} />
          </TabsContent>

          <TabsContent value="heatmap" className="space-y-4">
            <RiskHeatmap address={address} />
          </TabsContent>

          <TabsContent value="alerts" className="space-y-4">
            <AlertSystem address={address} />
          </TabsContent>

          <TabsContent value="limits" className="space-y-4">
            <SpendingLimits address={address} />
          </TabsContent>
        </Tabs>

        {/* Base Network Badge */}
        <div className="flex justify-center pt-4 pb-8">
          <Badge variant="outline" className="text-xs">
            <span className="w-2 h-2 bg-blue-600 rounded-full mr-2"></span>
            Protected by Base Network
          </Badge>
        </div>
      </main>
    </div>
  );
}
