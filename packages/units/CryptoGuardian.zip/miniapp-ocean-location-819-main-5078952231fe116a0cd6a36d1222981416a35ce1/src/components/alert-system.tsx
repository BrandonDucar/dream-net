'use client';

import { useState, useEffect } from 'react';
import type { Address } from 'viem';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, Bell, CheckCircle, XCircle, Clock, Shield } from 'lucide-react';

interface AlertSystemProps {
  address: Address;
}

interface SecurityAlert {
  id: string;
  type: 'critical' | 'high' | 'medium' | 'info';
  title: string;
  message: string;
  timestamp: string;
  dismissed: boolean;
  actionable: boolean;
}

export function AlertSystem({ address }: AlertSystemProps) {
  const [alerts, setAlerts] = useState<SecurityAlert[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAlerts();
  }, [address]);

  const loadAlerts = async () => {
    setLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));

    // Mock alert data
    const mockAlerts: SecurityAlert[] = [
      {
        id: '1',
        type: 'critical',
        title: 'Suspicious Contract Interaction Detected',
        message:
          'A contract you recently interacted with (0x3456...9012) shows signs of being a honeypot. We recommend revoking any approvals immediately.',
        timestamp: '5 minutes ago',
        dismissed: false,
        actionable: true,
      },
      {
        id: '2',
        type: 'high',
        title: 'Unusual Spending Pattern',
        message:
          'Your wallet has made 15 transactions in the last hour, which is significantly higher than your average. This could indicate compromised access.',
        timestamp: '1 hour ago',
        dismissed: false,
        actionable: true,
      },
      {
        id: '3',
        type: 'medium',
        title: 'New Contract Approval Request',
        message:
          'A new contract is requesting unlimited USDC approval. Always verify the contract before approving.',
        timestamp: '3 hours ago',
        dismissed: false,
        actionable: false,
      },
      {
        id: '4',
        type: 'info',
        title: 'Security Score Improved',
        message:
          'Great job! You revoked 2 high-risk approvals. Your security score increased from 72 to 85.',
        timestamp: '1 day ago',
        dismissed: false,
        actionable: false,
      },
      {
        id: '5',
        type: 'high',
        title: 'Spending Limit Nearly Reached',
        message:
          'You have spent $950 of your $1000 daily limit. Auto-limit will trigger at $1000.',
        timestamp: '2 days ago',
        dismissed: false,
        actionable: true,
      },
    ];

    setAlerts(mockAlerts);
    setLoading(false);
  };

  const dismissAlert = (alertId: string) => {
    setAlerts((prev) =>
      prev.map((alert) => (alert.id === alertId ? { ...alert, dismissed: true } : alert))
    );
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'critical':
        return <XCircle className="w-5 h-5 text-red-600" />;
      case 'high':
        return <AlertTriangle className="w-5 h-5 text-orange-600" />;
      case 'medium':
        return <Bell className="w-5 h-5 text-yellow-600" />;
      case 'info':
        return <CheckCircle className="w-5 h-5 text-blue-600" />;
      default:
        return <Bell className="w-5 h-5 text-gray-600" />;
    }
  };

  const getAlertBadge = (type: string) => {
    switch (type) {
      case 'critical':
        return <Badge variant="destructive" className="bg-red-700">CRITICAL</Badge>;
      case 'high':
        return <Badge variant="destructive">HIGH</Badge>;
      case 'medium':
        return <Badge className="bg-yellow-600">MEDIUM</Badge>;
      case 'info':
        return <Badge className="bg-blue-600">INFO</Badge>;
      default:
        return <Badge variant="outline">UNKNOWN</Badge>;
    }
  };

  const getAlertBorderColor = (type: string): string => {
    switch (type) {
      case 'critical':
        return 'border-red-300 bg-red-50';
      case 'high':
        return 'border-orange-300 bg-orange-50';
      case 'medium':
        return 'border-yellow-300 bg-yellow-50';
      case 'info':
        return 'border-blue-300 bg-blue-50';
      default:
        return 'border-gray-300 bg-gray-50';
    }
  };

  const activeAlerts = alerts.filter((a) => !a.dismissed);
  const criticalCount = activeAlerts.filter((a) => a.type === 'critical').length;
  const highCount = activeAlerts.filter((a) => a.type === 'high').length;

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Alert System</CardTitle>
          <CardDescription>Loading security alerts...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-3">
            <div className="h-24 bg-gray-200 rounded"></div>
            <div className="h-24 bg-gray-200 rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" />
              Alert System
            </CardTitle>
            <CardDescription>
              Real-time security notifications • {activeAlerts.length} active
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            {criticalCount > 0 && (
              <Badge variant="destructive" className="bg-red-700">
                {criticalCount} Critical
              </Badge>
            )}
            {highCount > 0 && (
              <Badge variant="destructive">{highCount} High</Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Alert List */}
        <div className="space-y-3">
          {activeAlerts.map((alert) => (
            <div
              key={alert.id}
              className={`p-4 rounded-lg border-2 ${getAlertBorderColor(alert.type)}`}
            >
              <div className="flex items-start gap-3">
                <div className="mt-1">{getAlertIcon(alert.type)}</div>
                <div className="flex-1 space-y-2">
                  {/* Header */}
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-semibold text-gray-900">{alert.title}</h4>
                      {getAlertBadge(alert.type)}
                    </div>
                  </div>

                  {/* Message */}
                  <p className="text-sm text-gray-700">{alert.message}</p>

                  {/* Timestamp */}
                  <div className="flex items-center gap-1 text-xs text-gray-600">
                    <Clock className="w-3 h-3" />
                    <span>{alert.timestamp}</span>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 pt-2">
                    {alert.actionable && (
                      <Button size="sm" variant="outline">
                        Take Action
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => dismissAlert(alert.id)}
                    >
                      Dismiss
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {activeAlerts.length === 0 && (
          <div className="text-center py-12 space-y-3">
            <Shield className="w-16 h-16 text-green-600 mx-auto" />
            <h3 className="text-lg font-semibold text-gray-900">All Clear!</h3>
            <p className="text-sm text-gray-600">
              No active security alerts. XKEEPER is monitoring your wallet 24/7.
            </p>
          </div>
        )}

        {/* Alert Settings */}
        <div className="bg-blue-50 p-4 rounded-lg">
          <p className="text-sm font-semibold text-blue-900 mb-2">Alert Types:</p>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• <strong>Critical:</strong> Immediate action required (honeypots, compromised wallets)</li>
            <li>• <strong>High:</strong> Urgent attention needed (unusual activity, high-risk approvals)</li>
            <li>• <strong>Medium:</strong> Review recommended (new contracts, spending patterns)</li>
            <li>• <strong>Info:</strong> General updates (score improvements, tips)</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
