'use client';

import { useState, useEffect } from 'react';
import type { Address } from 'viem';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileSearch, Trash2, AlertTriangle, CheckCircle, Loader2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface ApprovalMonitorProps {
  address: Address;
}

interface TokenApproval {
  id: string;
  tokenName: string;
  tokenSymbol: string;
  tokenAddress: string;
  spenderAddress: string;
  spenderName: string;
  amount: string;
  riskLevel: 'low' | 'medium' | 'high';
  lastUpdated: string;
}

export function ApprovalMonitor({ address }: ApprovalMonitorProps) {
  const [approvals, setApprovals] = useState<TokenApproval[]>([]);
  const [loading, setLoading] = useState(true);
  const [revoking, setRevoking] = useState<string | null>(null);

  useEffect(() => {
    loadApprovals();
  }, [address]);

  const loadApprovals = async () => {
    setLoading(true);
    // Simulate loading approvals
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // Mock approval data
    const mockApprovals: TokenApproval[] = [
      {
        id: '1',
        tokenName: 'USD Coin',
        tokenSymbol: 'USDC',
        tokenAddress: '0x833589fcd6edb6e08f4c7c32d4f71b54bda02913',
        spenderAddress: '0x1234567890123456789012345678901234567890',
        spenderName: 'Uniswap V3 Router',
        amount: 'Unlimited',
        riskLevel: 'low',
        lastUpdated: '2 days ago',
      },
      {
        id: '2',
        tokenName: 'Wrapped Ether',
        tokenSymbol: 'WETH',
        tokenAddress: '0x4200000000000000000000000000000000000006',
        spenderAddress: '0x2345678901234567890123456789012345678901',
        spenderName: 'SushiSwap Router',
        amount: '10.5 WETH',
        riskLevel: 'medium',
        lastUpdated: '5 days ago',
      },
      {
        id: '3',
        tokenName: 'Unknown Token',
        tokenSymbol: 'SCAM',
        tokenAddress: '0x3456789012345678901234567890123456789012',
        spenderAddress: '0x4567890123456789012345678901234567890123',
        spenderName: 'Suspicious Contract',
        amount: 'Unlimited',
        riskLevel: 'high',
        lastUpdated: '1 hour ago',
      },
      {
        id: '4',
        tokenName: 'Dai Stablecoin',
        tokenSymbol: 'DAI',
        tokenAddress: '0x50c5725949a6f0c72e6c4a641f24049a917db0cb',
        tokenAddress: '0x5678901234567890123456789012345678901234',
        spenderAddress: '0x6789012345678901234567890123456789012345',
        spenderName: 'Curve Finance',
        amount: '1000 DAI',
        riskLevel: 'low',
        lastUpdated: '1 week ago',
      },
    ];

    setApprovals(mockApprovals);
    setLoading(false);
  };

  const handleRevoke = async (approvalId: string) => {
    setRevoking(approvalId);
    // Simulate revoke transaction
    await new Promise((resolve) => setTimeout(resolve, 2000));
    setApprovals((prev) => prev.filter((a) => a.id !== approvalId));
    setRevoking(null);
  };

  const getRiskBadge = (level: string) => {
    switch (level) {
      case 'high':
        return <Badge variant="destructive">HIGH RISK</Badge>;
      case 'medium':
        return <Badge className="bg-yellow-600">MEDIUM</Badge>;
      case 'low':
        return <Badge className="bg-green-600">LOW</Badge>;
      default:
        return <Badge variant="outline">UNKNOWN</Badge>;
    }
  };

  const highRiskCount = approvals.filter((a) => a.riskLevel === 'high').length;

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Approval Monitor</CardTitle>
          <CardDescription>Loading your token approvals...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <FileSearch className="w-5 h-5" />
              Approval Monitor
            </CardTitle>
            <CardDescription>
              Manage and revoke token approvals • {approvals.length} active
            </CardDescription>
          </div>
          {highRiskCount > 0 && (
            <Badge variant="destructive" className="flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" />
              {highRiskCount} High Risk
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* High Risk Warning */}
        {highRiskCount > 0 && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>High Risk Approvals Detected!</AlertTitle>
            <AlertDescription>
              You have {highRiskCount} high-risk token approval(s). We recommend revoking them immediately
              to protect your assets.
            </AlertDescription>
          </Alert>
        )}

        {/* Approvals List */}
        <div className="space-y-3">
          {approvals.map((approval) => (
            <div
              key={approval.id}
              className={`p-4 rounded-lg border-2 ${
                approval.riskLevel === 'high'
                  ? 'border-red-200 bg-red-50'
                  : approval.riskLevel === 'medium'
                  ? 'border-yellow-200 bg-yellow-50'
                  : 'border-gray-200 bg-white'
              }`}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 space-y-2">
                  {/* Token Info */}
                  <div className="flex items-center gap-2">
                    <div>
                      <h4 className="font-semibold text-gray-900">
                        {approval.tokenName} ({approval.tokenSymbol})
                      </h4>
                      <p className="text-xs text-gray-600 font-mono">
                        {approval.tokenAddress.slice(0, 10)}...{approval.tokenAddress.slice(-8)}
                      </p>
                    </div>
                  </div>

                  {/* Spender Info */}
                  <div className="space-y-1">
                    <p className="text-sm text-gray-700">
                      <span className="font-medium">Spender:</span> {approval.spenderName}
                    </p>
                    <p className="text-xs text-gray-600 font-mono">
                      {approval.spenderAddress.slice(0, 10)}...{approval.spenderAddress.slice(-8)}
                    </p>
                  </div>

                  {/* Amount & Risk */}
                  <div className="flex items-center gap-3 flex-wrap">
                    <div>
                      <p className="text-xs text-gray-600">Approved Amount</p>
                      <p className="text-sm font-semibold text-gray-900">{approval.amount}</p>
                    </div>
                    <div>{getRiskBadge(approval.riskLevel)}</div>
                  </div>

                  {/* Last Updated */}
                  <p className="text-xs text-gray-500">Last updated: {approval.lastUpdated}</p>
                </div>

                {/* Revoke Button */}
                <Button
                  variant={approval.riskLevel === 'high' ? 'destructive' : 'outline'}
                  size="sm"
                  onClick={() => handleRevoke(approval.id)}
                  disabled={revoking === approval.id}
                >
                  {revoking === approval.id ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Revoking...
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-4 h-4 mr-2" />
                      Revoke
                    </>
                  )}
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {approvals.length === 0 && (
          <div className="text-center py-12 space-y-3">
            <CheckCircle className="w-16 h-16 text-green-600 mx-auto" />
            <h3 className="text-lg font-semibold text-gray-900">No Active Approvals</h3>
            <p className="text-sm text-gray-600">Your wallet is clean! No token approvals found.</p>
          </div>
        )}

        {/* Info Box */}
        <div className="bg-blue-50 p-4 rounded-lg">
          <p className="text-sm font-semibold text-blue-900 mb-2">About Token Approvals:</p>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Approvals allow contracts to spend your tokens</li>
            <li>• Unlimited approvals pose security risks</li>
            <li>• Revoke approvals you no longer use</li>
            <li>• Regular monitoring prevents unauthorized access</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
