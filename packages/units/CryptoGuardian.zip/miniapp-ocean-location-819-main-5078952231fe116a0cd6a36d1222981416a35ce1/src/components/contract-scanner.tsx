'use client';

import { useState } from 'react';
import type { Address } from 'viem';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Search, AlertTriangle, CheckCircle, XCircle, Loader2, Shield } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface ContractScannerProps {
  address: Address;
}

interface ScanResult {
  contractAddress: string;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  verified: boolean;
  honeypot: boolean;
  socialEngineeringFlags: string[];
  issues: string[];
}

export function ContractScanner({ address }: ContractScannerProps) {
  const [contractToScan, setContractToScan] = useState('');
  const [scanning, setScanning] = useState(false);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);

  const handleScan = async () => {
    if (!contractToScan.trim()) return;

    setScanning(true);
    setScanResult(null);

    // Simulate contract scanning (in production, this would call actual security APIs)
    await new Promise((resolve) => setTimeout(resolve, 2000));

    // Mock scan result
    const mockResult: ScanResult = {
      contractAddress: contractToScan,
      riskLevel: Math.random() > 0.7 ? 'high' : Math.random() > 0.4 ? 'medium' : 'low',
      verified: Math.random() > 0.3,
      honeypot: Math.random() > 0.85,
      socialEngineeringFlags: Math.random() > 0.6 ? ['Suspicious naming pattern', 'Recent deployment'] : [],
      issues: [],
    };

    if (mockResult.riskLevel === 'high') {
      mockResult.issues.push('High concentration of ownership');
      mockResult.issues.push('Unusual transfer restrictions');
    }
    if (mockResult.riskLevel === 'medium') {
      mockResult.issues.push('Limited liquidity');
    }
    if (!mockResult.verified) {
      mockResult.issues.push('Unverified contract code');
    }
    if (mockResult.honeypot) {
      mockResult.issues.push('⚠️ HONEYPOT DETECTED - Cannot sell tokens');
      mockResult.riskLevel = 'critical';
    }

    setScanResult(mockResult);
    setScanning(false);
  };

  const getRiskBadge = (level: string) => {
    switch (level) {
      case 'critical':
        return <Badge variant="destructive" className="bg-red-700">CRITICAL</Badge>;
      case 'high':
        return <Badge variant="destructive">HIGH RISK</Badge>;
      case 'medium':
        return <Badge className="bg-yellow-600">MEDIUM RISK</Badge>;
      case 'low':
        return <Badge className="bg-green-600">LOW RISK</Badge>;
      default:
        return <Badge variant="outline">UNKNOWN</Badge>;
    }
  };

  const getRiskIcon = (level: string) => {
    switch (level) {
      case 'critical':
      case 'high':
        return <XCircle className="w-12 h-12 text-red-600" />;
      case 'medium':
        return <AlertTriangle className="w-12 h-12 text-yellow-600" />;
      case 'low':
        return <CheckCircle className="w-12 h-12 text-green-600" />;
      default:
        return <Shield className="w-12 h-12 text-gray-400" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="w-5 h-5" />
          Contract Scanner
        </CardTitle>
        <CardDescription>
          Check any contract address for security risks, honeypots, and social engineering flags
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Search Input */}
        <div className="flex gap-2">
          <Input
            type="text"
            placeholder="Enter contract address (0x...)"
            value={contractToScan}
            onChange={(e) => setContractToScan(e.target.value)}
            className="flex-1"
          />
          <Button onClick={handleScan} disabled={scanning || !contractToScan.trim()}>
            {scanning ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Scanning...
              </>
            ) : (
              <>
                <Search className="w-4 h-4 mr-2" />
                Scan
              </>
            )}
          </Button>
        </div>

        {/* Scan Result */}
        {scanResult && (
          <div className="space-y-4">
            {/* Risk Level Banner */}
            <div className={`p-6 rounded-lg text-center space-y-3 ${
              scanResult.riskLevel === 'critical' || scanResult.riskLevel === 'high' 
                ? 'bg-red-50 border-2 border-red-200' 
                : scanResult.riskLevel === 'medium' 
                ? 'bg-yellow-50 border-2 border-yellow-200' 
                : 'bg-green-50 border-2 border-green-200'
            }`}>
              <div className="flex justify-center">
                {getRiskIcon(scanResult.riskLevel)}
              </div>
              <div>
                {getRiskBadge(scanResult.riskLevel)}
              </div>
              <p className="text-xs text-gray-600 font-mono break-all">
                {scanResult.contractAddress}
              </p>
            </div>

            {/* Contract Details */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <p className="text-xs text-gray-600">Verification Status</p>
                <div className="flex items-center gap-2">
                  {scanResult.verified ? (
                    <>
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium text-green-600">Verified</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-4 h-4 text-red-600" />
                      <span className="text-sm font-medium text-red-600">Unverified</span>
                    </>
                  )}
                </div>
              </div>

              <div className="space-y-1">
                <p className="text-xs text-gray-600">Honeypot Check</p>
                <div className="flex items-center gap-2">
                  {scanResult.honeypot ? (
                    <>
                      <AlertTriangle className="w-4 h-4 text-red-600" />
                      <span className="text-sm font-medium text-red-600">Detected!</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium text-green-600">Safe</span>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Issues Found */}
            {scanResult.issues.length > 0 && (
              <Alert variant={scanResult.riskLevel === 'critical' || scanResult.riskLevel === 'high' ? 'destructive' : 'default'}>
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Security Issues Detected</AlertTitle>
                <AlertDescription>
                  <ul className="mt-2 space-y-1">
                    {scanResult.issues.map((issue, index) => (
                      <li key={index} className="text-sm">• {issue}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            )}

            {/* Social Engineering Flags */}
            {scanResult.socialEngineeringFlags.length > 0 && (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Social Engineering Flags</AlertTitle>
                <AlertDescription>
                  <ul className="mt-2 space-y-1">
                    {scanResult.socialEngineeringFlags.map((flag, index) => (
                      <li key={index} className="text-sm">• {flag}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            )}

            {/* Recommendations */}
            {(scanResult.riskLevel === 'high' || scanResult.riskLevel === 'critical') && (
              <div className="bg-red-50 p-4 rounded-lg">
                <p className="text-sm font-semibold text-red-900 mb-2">⚠️ Recommendations:</p>
                <ul className="text-sm text-red-800 space-y-1">
                  <li>• DO NOT interact with this contract</li>
                  <li>• Revoke any existing approvals immediately</li>
                  <li>• Report this contract if you suspect fraud</li>
                </ul>
              </div>
            )}
          </div>
        )}

        {/* Quick Scan Tips */}
        {!scanResult && !scanning && (
          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-sm font-semibold text-blue-900 mb-2">Quick Scan Tips:</p>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Always scan contracts before interaction</li>
              <li>• Check for verification status</li>
              <li>• Watch for honeypot warnings</li>
              <li>• Review ownership concentration</li>
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
