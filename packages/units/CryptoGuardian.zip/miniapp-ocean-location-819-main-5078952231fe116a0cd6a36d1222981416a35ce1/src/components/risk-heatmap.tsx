'use client';

import { useState, useEffect } from 'react';
import type { Address } from 'viem';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Activity, TrendingUp, TrendingDown } from 'lucide-react';

interface RiskHeatmapProps {
  address: Address;
}

interface DayActivity {
  day: string;
  risk: number;
  transactions: number;
}

export function RiskHeatmap({ address }: RiskHeatmapProps) {
  const [heatmapData, setHeatmapData] = useState<DayActivity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadHeatmapData();
  }, [address]);

  const loadHeatmapData = async () => {
    setLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));

    // Generate mock heatmap data for the last 30 days
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const data: DayActivity[] = [];

    for (let week = 0; week < 4; week++) {
      for (let day = 0; day < 7; day++) {
        data.push({
          day: days[day],
          risk: Math.floor(Math.random() * 100),
          transactions: Math.floor(Math.random() * 15),
        });
      }
    }

    setHeatmapData(data);
    setLoading(false);
  };

  const getRiskColor = (risk: number): string => {
    if (risk >= 75) return 'bg-red-600';
    if (risk >= 50) return 'bg-orange-500';
    if (risk >= 25) return 'bg-yellow-400';
    return 'bg-green-500';
  };

  const getOpacity = (transactions: number): string => {
    if (transactions === 0) return 'opacity-10';
    if (transactions <= 3) return 'opacity-30';
    if (transactions <= 7) return 'opacity-60';
    return 'opacity-100';
  };

  const avgRisk = heatmapData.reduce((sum, day) => sum + day.risk, 0) / heatmapData.length;
  const totalTransactions = heatmapData.reduce((sum, day) => sum + day.transactions, 0);
  const highRiskDays = heatmapData.filter((day) => day.risk >= 75).length;

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Risk Heatmap</CardTitle>
          <CardDescription>Loading activity data...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-3">
            <div className="h-48 bg-gray-200 rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="w-5 h-5" />
          Risk Heatmap
        </CardTitle>
        <CardDescription>
          30-day activity and risk visualization
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Summary Stats */}
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center p-3 bg-blue-50 rounded-lg">
            <p className="text-xs text-blue-600 mb-1">Avg Risk Score</p>
            <p className="text-2xl font-bold text-blue-900">{avgRisk.toFixed(0)}</p>
          </div>
          <div className="text-center p-3 bg-green-50 rounded-lg">
            <p className="text-xs text-green-600 mb-1">Total Transactions</p>
            <p className="text-2xl font-bold text-green-900">{totalTransactions}</p>
          </div>
          <div className="text-center p-3 bg-red-50 rounded-lg">
            <p className="text-xs text-red-600 mb-1">High Risk Days</p>
            <p className="text-2xl font-bold text-red-900">{highRiskDays}</p>
          </div>
        </div>

        {/* Heatmap Grid */}
        <div className="space-y-2">
          <div className="flex justify-between items-center mb-2">
            <p className="text-sm font-semibold text-gray-900">Last 4 Weeks</p>
            <div className="flex items-center gap-4 text-xs text-gray-600">
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 bg-green-500 rounded"></div>
                <span>Low</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 bg-yellow-400 rounded"></div>
                <span>Medium</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 bg-red-600 rounded"></div>
                <span>High</span>
              </div>
            </div>
          </div>

          {/* Week Labels */}
          <div className="flex gap-1 mb-1">
            <div className="w-12"></div>
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div key={day} className="flex-1 text-center">
                <span className="text-xs text-gray-600">{day}</span>
              </div>
            ))}
          </div>

          {/* Heatmap Rows */}
          {[0, 1, 2, 3].map((week) => (
            <div key={week} className="flex gap-1">
              <div className="w-12 flex items-center">
                <span className="text-xs text-gray-600">Week {week + 1}</span>
              </div>
              {heatmapData.slice(week * 7, (week + 1) * 7).map((dayData, index) => (
                <div
                  key={`${week}-${index}`}
                  className="flex-1 aspect-square relative group"
                  title={`${dayData.day}: ${dayData.transactions} transactions, Risk: ${dayData.risk}`}
                >
                  <div
                    className={`w-full h-full rounded ${getRiskColor(dayData.risk)} ${getOpacity(
                      dayData.transactions
                    )} hover:ring-2 hover:ring-blue-600 transition-all cursor-pointer`}
                  ></div>
                  {/* Tooltip */}
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 hidden group-hover:block z-10">
                    <div className="bg-gray-900 text-white text-xs rounded px-2 py-1 whitespace-nowrap">
                      <p>{dayData.day}</p>
                      <p>{dayData.transactions} txs</p>
                      <p>Risk: {dayData.risk}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* Activity Trends */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-green-50 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <TrendingDown className="w-4 h-4 text-green-600" />
              <p className="text-sm font-semibold text-green-900">Improving</p>
            </div>
            <ul className="text-xs text-green-800 space-y-1">
              <li>• Risk score decreased 15% this week</li>
              <li>• Fewer high-risk contract interactions</li>
              <li>• Spending within safe limits</li>
            </ul>
          </div>

          <div className="bg-yellow-50 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-yellow-600" />
              <p className="text-sm font-semibold text-yellow-900">Monitor</p>
            </div>
            <ul className="text-xs text-yellow-800 space-y-1">
              <li>• Increased activity on weekends</li>
              <li>• New contract interactions detected</li>
              <li>• Consider reviewing recent approvals</li>
            </ul>
          </div>
        </div>

        {/* Legend */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <p className="text-xs font-semibold text-gray-900 mb-2">How to Read the Heatmap:</p>
          <ul className="text-xs text-gray-700 space-y-1">
            <li>• Color intensity indicates risk level (green = low, red = high)</li>
            <li>• Opacity shows transaction volume (darker = more transactions)</li>
            <li>• Hover over cells for detailed information</li>
            <li>• Empty cells indicate no wallet activity</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
