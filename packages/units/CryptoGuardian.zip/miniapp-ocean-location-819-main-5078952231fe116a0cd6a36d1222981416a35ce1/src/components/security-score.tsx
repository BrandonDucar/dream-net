'use client';

import { useEffect, useState } from 'react';
import type { Address } from 'viem';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Shield, TrendingUp, TrendingDown } from 'lucide-react';

interface SecurityScoreProps {
  address: Address;
}

export function SecurityScore({ address }: SecurityScoreProps) {
  const [score, setScore] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate calculating security score
    const calculateScore = async () => {
      setLoading(true);
      await new Promise((resolve) => setTimeout(resolve, 1000));
      
      // Mock score calculation (in production, this would analyze actual wallet data)
      const mockScore = Math.floor(Math.random() * 30) + 70; // 70-100
      setScore(mockScore);
      setLoading(false);
    };

    calculateScore();
  }, [address]);

  const getScoreColor = (score: number): string => {
    if (score >= 90) return 'text-green-600';
    if (score >= 75) return 'text-blue-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreLabel = (score: number): string => {
    if (score >= 90) return 'Excellent';
    if (score >= 75) return 'Good';
    if (score >= 60) return 'Fair';
    return 'Poor';
  };

  const getScoreBadgeVariant = (score: number): 'default' | 'secondary' | 'destructive' | 'outline' => {
    if (score >= 90) return 'default';
    if (score >= 75) return 'secondary';
    return 'destructive';
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Security Score</CardTitle>
          <CardDescription>Analyzing your wallet security...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="animate-pulse space-y-3">
              <div className="h-24 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-2 border-blue-100">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-blue-600" />
              Security Score
            </CardTitle>
            <CardDescription>Real-time wallet security assessment</CardDescription>
          </div>
          <Badge variant={getScoreBadgeVariant(score)}>
            {getScoreLabel(score)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Score Display */}
        <div className="text-center space-y-2">
          <div className={`text-6xl font-bold ${getScoreColor(score)}`}>
            {score}
          </div>
          <p className="text-sm text-gray-600">out of 100</p>
        </div>

        {/* Score Progress Bar */}
        <div className="space-y-2">
          <Progress value={score} className="h-3" />
          <div className="flex justify-between text-xs text-gray-600">
            <span>0</span>
            <span>50</span>
            <span>100</span>
          </div>
        </div>

        {/* Score Factors */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-green-50 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <p className="text-xs font-semibold text-green-900">Strengths</p>
            </div>
            <ul className="text-xs text-green-800 space-y-1">
              <li>• No suspicious contracts</li>
              <li>• Low approval count</li>
              <li>• Recent activity normal</li>
            </ul>
          </div>

          <div className="bg-yellow-50 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <TrendingDown className="w-4 h-4 text-yellow-600" />
              <p className="text-xs font-semibold text-yellow-900">Watch</p>
            </div>
            <ul className="text-xs text-yellow-800 space-y-1">
              <li>• 3 high-risk approvals</li>
              <li>• New contract interactions</li>
              <li>• Spending limit near max</li>
            </ul>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <Shield className="w-4 h-4 text-blue-600" />
              <p className="text-xs font-semibold text-blue-900">Protected</p>
            </div>
            <ul className="text-xs text-blue-800 space-y-1">
              <li>• Auto-limits active</li>
              <li>• 24/7 monitoring on</li>
              <li>• Alert system enabled</li>
            </ul>
          </div>
        </div>

        {/* Recommendations */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <p className="text-xs font-semibold text-gray-900 mb-2">Recommendations:</p>
          <ul className="text-xs text-gray-700 space-y-1">
            <li>• Review and revoke 3 high-risk token approvals</li>
            <li>• Enable stricter spending limits for new contracts</li>
            <li>• Monitor recent contract interactions closely</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
