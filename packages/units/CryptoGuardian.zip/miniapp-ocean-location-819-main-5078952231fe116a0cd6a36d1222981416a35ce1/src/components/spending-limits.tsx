'use client';

import { useState } from 'react';
import type { Address } from 'viem';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Lock, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface SpendingLimitsProps {
  address: Address;
}

interface Limit {
  id: string;
  name: string;
  current: number;
  max: number;
  enabled: boolean;
  period: string;
}

export function SpendingLimits({ address }: SpendingLimitsProps) {
  const [limits, setLimits] = useState<Limit[]>([
    {
      id: 'daily',
      name: 'Daily Limit',
      current: 950,
      max: 1000,
      enabled: true,
      period: 'per day',
    },
    {
      id: 'weekly',
      name: 'Weekly Limit',
      current: 2800,
      max: 5000,
      enabled: true,
      period: 'per week',
    },
    {
      id: 'tx',
      name: 'Transaction Limit',
      current: 45,
      max: 100,
      enabled: true,
      period: 'per day',
    },
    {
      id: 'newContract',
      name: 'New Contract Limit',
      current: 250,
      max: 500,
      enabled: true,
      period: 'per interaction',
    },
  ]);

  const [autoLimitEnabled, setAutoLimitEnabled] = useState(true);
  const [emergencyStop, setEmergencyStop] = useState(false);

  const updateLimit = (id: string, newMax: number) => {
    setLimits((prev) =>
      prev.map((limit) => (limit.id === id ? { ...limit, max: newMax } : limit))
    );
  };

  const toggleLimit = (id: string) => {
    setLimits((prev) =>
      prev.map((limit) => (limit.id === id ? { ...limit, enabled: !limit.enabled } : limit))
    );
  };

  const getProgressColor = (percentage: number): string => {
    if (percentage >= 90) return 'bg-red-600';
    if (percentage >= 75) return 'bg-yellow-600';
    return 'bg-green-600';
  };

  const getUsagePercentage = (current: number, max: number): number => {
    return (current / max) * 100;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Lock className="w-5 h-5" />
          Spending Limits
        </CardTitle>
        <CardDescription>
          Set automatic spending limits to protect your wallet from unauthorized access
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Emergency Stop */}
        {emergencyStop && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Emergency Stop Activated!</AlertTitle>
            <AlertDescription>
              All transactions are currently blocked. Disable emergency stop to resume normal
              activity.
            </AlertDescription>
          </Alert>
        )}

        {/* Main Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Auto-Limit Toggle */}
          <div className="flex items-center justify-between p-4 rounded-lg border-2 border-blue-200 bg-blue-50">
            <div className="space-y-1">
              <Label htmlFor="auto-limit" className="text-sm font-semibold text-blue-900">
                Auto-Limit Protection
              </Label>
              <p className="text-xs text-blue-700">
                Automatically block transactions exceeding limits
              </p>
            </div>
            <Switch
              id="auto-limit"
              checked={autoLimitEnabled}
              onCheckedChange={setAutoLimitEnabled}
            />
          </div>

          {/* Emergency Stop */}
          <div className="flex items-center justify-between p-4 rounded-lg border-2 border-red-200 bg-red-50">
            <div className="space-y-1">
              <Label htmlFor="emergency" className="text-sm font-semibold text-red-900">
                Emergency Stop
              </Label>
              <p className="text-xs text-red-700">Block all transactions immediately</p>
            </div>
            <Switch
              id="emergency"
              checked={emergencyStop}
              onCheckedChange={setEmergencyStop}
            />
          </div>
        </div>

        {/* Limits List */}
        <div className="space-y-4">
          <h3 className="text-sm font-semibold text-gray-900">Active Limits</h3>

          {limits.map((limit) => {
            const percentage = getUsagePercentage(limit.current, limit.max);
            const isNearLimit = percentage >= 75;

            return (
              <div
                key={limit.id}
                className={`p-4 rounded-lg border-2 ${
                  isNearLimit ? 'border-yellow-200 bg-yellow-50' : 'border-gray-200 bg-white'
                }`}
              >
                <div className="space-y-3">
                  {/* Header */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Switch
                        checked={limit.enabled}
                        onCheckedChange={() => toggleLimit(limit.id)}
                      />
                      <div>
                        <h4 className="font-semibold text-gray-900">{limit.name}</h4>
                        <p className="text-xs text-gray-600">{limit.period}</p>
                      </div>
                    </div>
                    {isNearLimit && limit.enabled && (
                      <Badge variant="destructive" className="flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        Near Limit
                      </Badge>
                    )}
                  </div>

                  {/* Progress */}
                  {limit.enabled && (
                    <>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-700">
                            ${limit.current.toLocaleString()} used
                          </span>
                          <span className="font-semibold text-gray-900">
                            ${limit.max.toLocaleString()} max
                          </span>
                        </div>
                        <div className="relative">
                          <Progress value={percentage} className="h-2" />
                        </div>
                        <p className="text-xs text-gray-600 text-right">
                          {percentage.toFixed(1)}% used
                        </p>
                      </div>

                      {/* Update Limit */}
                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          placeholder="New limit"
                          className="flex-1"
                          defaultValue={limit.max}
                          onChange={(e) => {
                            const value = parseInt(e.target.value);
                            if (!isNaN(value)) {
                              updateLimit(limit.id, value);
                            }
                          }}
                        />
                        <Button size="sm" variant="outline">
                          Update
                        </Button>
                      </div>
                    </>
                  )}

                  {!limit.enabled && (
                    <p className="text-sm text-gray-500 italic">Limit disabled</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Auto-Trigger Info */}
        {autoLimitEnabled && (
          <div className="bg-green-50 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <p className="text-sm font-semibold text-green-900">Auto-Limit Active</p>
            </div>
            <ul className="text-sm text-green-800 space-y-1">
              <li>• Transactions exceeding limits will be automatically blocked</li>
              <li>• You'll receive an alert when limits are reached</li>
              <li>• Limits reset based on their time period</li>
            </ul>
          </div>
        )}

        {/* Usage Stats */}
        <div className="bg-blue-50 p-4 rounded-lg">
          <p className="text-sm font-semibold text-blue-900 mb-3">Today's Activity</p>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <TrendingUp className="w-6 h-6 text-blue-600 mx-auto mb-1" />
              <p className="text-xl font-bold text-blue-900">12</p>
              <p className="text-xs text-blue-700">Transactions</p>
            </div>
            <div className="text-center">
              <Lock className="w-6 h-6 text-blue-600 mx-auto mb-1" />
              <p className="text-xl font-bold text-blue-900">2</p>
              <p className="text-xs text-blue-700">Blocked</p>
            </div>
            <div className="text-center">
              <CheckCircle className="w-6 h-6 text-blue-600 mx-auto mb-1" />
              <p className="text-xl font-bold text-blue-900">$950</p>
              <p className="text-xs text-blue-700">Spent</p>
            </div>
          </div>
        </div>

        {/* Tips */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <p className="text-xs font-semibold text-gray-900 mb-2">Best Practices:</p>
          <ul className="text-xs text-gray-700 space-y-1">
            <li>• Set daily limits based on your typical spending</li>
            <li>• Enable lower limits for new/unverified contracts</li>
            <li>• Use emergency stop if you suspect unauthorized access</li>
            <li>• Review and adjust limits regularly</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
