use spacetimedb::{table, reducer, ReducerContext, Table, Timestamp, SpacetimeType};

#[table(name = culture_coin, public)]
#[derive(Clone)]
pub struct CultureCoin {
    #[primary_key]
    #[auto_inc]
    id: u64,
    name: String,
    ticker: String,
    short_tagline: String,
    theme: String,
    #[index(btree)]
    archetype: String,
    primary_emoji: String,
    #[index(btree)]
    chain: String,
    contract_address: Option<String>,
    #[index(btree)]
    status: String,
    origin_story: String,
    core_myth: String,
    personality_traits: Vec<String>,
    allied_symbols: Vec<String>,
    enemies_or_antagonists: Option<String>,
    visual_motifs: Vec<String>,
    meme_angles: Vec<String>,
    formats_recommended: Vec<String>,
    key_phrases: Vec<String>,
    talking_points: Vec<String>,
    launch_hooks: Vec<String>,
    drop_ideas: Vec<String>,
    risk_notes: Vec<String>,
    seo_title: String,
    seo_description: String,
    seo_keywords: Vec<String>,
    seo_hashtags: Vec<String>,
    alt_text: String,
    related_meme_ids: String,
    related_campaign_ids: String,

    // New optional fields for deployment, analytics, and social features
    mascot_image_url: Option<String>,
    mascot_ipfs_url: Option<String>,
    deployment_status: Option<String>,       // "not_deployed", "deploying", "deployed", "failed"
    deployment_tx_hash: Option<String>,
    deployment_error: Option<String>,
    revenue_manager_address: Option<String>,
    protocol_fee: Option<u64>,
    creator_wallet_address: Option<String>,
    launched_at: Option<u64>,
    total_minted: Option<u64>,
    holder_count: Option<u64>,
    market_cap_usd: Option<String>,
    price_usd: Option<String>,
    volume_24h: Option<String>,
    research_notes: Option<String>,
    trend_score: Option<u64>,                 // 0-100
    competitor_analysis: Option<String>,
    social_metrics: Option<String>,           // JSON blob
    attached_meme_urls: Option<String>,       // comma-separated URLs

    created_at: Timestamp,
    updated_at: Timestamp,
}

#[table(name = geo_target, public)]
#[derive(Clone)]
pub struct GeoTarget {
    #[primary_key]
    #[auto_inc]
    id: u64,
    #[index(btree)]
    culture_coin_id: u64,
    region: String,
    country: Option<String>,
    city_or_market: String,
    language: String,
    #[index(btree)]
    geo_key: String,
    localized_caption: String,
    localized_tags: String,
}

#[derive(SpacetimeType, Clone, Debug)]
pub struct CreateCultureCoinArgs {
    pub name: String,
    pub ticker: String,
    pub short_tagline: String,
    pub theme: String,
    pub archetype: String,
    pub primary_emoji: String,
    pub chain: Option<String>,
    pub contract_address: Option<String>,
    pub status: String,
    pub origin_story: String,
    pub core_myth: String,
    pub personality_traits: Vec<String>,
    pub allied_symbols: Vec<String>,
    pub enemies_or_antagonists: Option<String>,
    pub visual_motifs: Vec<String>,
    pub meme_angles: Vec<String>,
    pub formats_recommended: Vec<String>,
    pub key_phrases: Vec<String>,
    pub talking_points: Vec<String>,
    pub launch_hooks: Vec<String>,
    pub drop_ideas: Vec<String>,
    pub risk_notes: Vec<String>,
    pub seo_title: String,
    pub seo_description: String,
    pub seo_keywords: Vec<String>,
    pub seo_hashtags: Vec<String>,
    pub alt_text: String,
    pub related_meme_ids: String,
    pub related_campaign_ids: String,

    // New optional fields
    pub mascot_image_url: Option<String>,
    pub mascot_ipfs_url: Option<String>,
    pub deployment_status: Option<String>,
    pub deployment_tx_hash: Option<String>,
    pub deployment_error: Option<String>,
    pub revenue_manager_address: Option<String>,
    pub protocol_fee: Option<u64>,
    pub creator_wallet_address: Option<String>,
    pub launched_at: Option<u64>,
    pub total_minted: Option<u64>,
    pub holder_count: Option<u64>,
    pub market_cap_usd: Option<String>,
    pub price_usd: Option<String>,
    pub volume_24h: Option<String>,
    pub research_notes: Option<String>,
    pub trend_score: Option<u64>,
    pub competitor_analysis: Option<String>,
    pub social_metrics: Option<String>,
    pub attached_meme_urls: Option<String>,
}

#[derive(SpacetimeType, Clone, Debug)]
pub struct UpdateCultureCoinArgs {
    pub name: Option<String>,
    pub ticker: Option<String>,
    pub short_tagline: Option<String>,
    pub theme: Option<String>,
    pub archetype: Option<String>,
    pub primary_emoji: Option<String>,
    pub chain: Option<String>,
    pub contract_address: Option<String>,
    pub status: Option<String>,
    pub origin_story: Option<String>,
    pub core_myth: Option<String>,
    pub personality_traits: Option<Vec<String>>,
    pub allied_symbols: Option<Vec<String>>,
    pub enemies_or_antagonists: Option<String>,
    pub visual_motifs: Option<Vec<String>>,
    pub meme_angles: Option<Vec<String>>,
    pub formats_recommended: Option<Vec<String>>,
    pub key_phrases: Option<Vec<String>>,
    pub talking_points: Option<Vec<String>>,
    pub launch_hooks: Option<Vec<String>>,
    pub drop_ideas: Option<Vec<String>>,
    pub risk_notes: Option<Vec<String>>,
    pub seo_title: Option<String>,
    pub seo_description: Option<String>,
    pub seo_keywords: Option<Vec<String>>,
    pub seo_hashtags: Option<Vec<String>>,
    pub alt_text: Option<String>,
    pub related_meme_ids: Option<String>,
    pub related_campaign_ids: Option<String>,

    // New optional fields
    pub mascot_image_url: Option<String>,
    pub mascot_ipfs_url: Option<String>,
    pub deployment_status: Option<String>,
    pub deployment_tx_hash: Option<String>,
    pub deployment_error: Option<String>,
    pub revenue_manager_address: Option<String>,
    pub protocol_fee: Option<u64>,
    pub creator_wallet_address: Option<String>,
    pub launched_at: Option<u64>,
    pub total_minted: Option<u64>,
    pub holder_count: Option<u64>,
    pub market_cap_usd: Option<String>,
    pub price_usd: Option<String>,
    pub volume_24h: Option<String>,
    pub research_notes: Option<String>,
    pub trend_score: Option<u64>,
    pub competitor_analysis: Option<String>,
    pub social_metrics: Option<String>,
    pub attached_meme_urls: Option<String>,
}

#[derive(SpacetimeType, Clone, Debug)]
pub struct CreateGeoTargetArgs {
    pub culture_coin_id: u64,
    pub region: String,
    pub country: Option<String>,
    pub city_or_market: String,
    pub language: String,
    pub geo_key: String,
    pub localized_caption: String,
    pub localized_tags: String,
}

#[derive(SpacetimeType, Clone, Debug)]
pub struct UpdateGeoTargetArgs {
    pub culture_coin_id: Option<u64>,
    pub region: Option<String>,
    pub country: Option<String>,
    pub city_or_market: Option<String>,
    pub language: Option<String>,
    pub geo_key: Option<String>,
    pub localized_caption: Option<String>,
    pub localized_tags: Option<String>,
}

#[reducer]
pub fn create_culture_coin(ctx: &ReducerContext, args: CreateCultureCoinArgs) -> Result<(), String> {
    let now = ctx.timestamp;
    let chain_value = args.chain.unwrap_or_else(|| "Base".to_string());

    let new_row = CultureCoin {
        id: 0,
        name: args.name,
        ticker: args.ticker,
        short_tagline: args.short_tagline,
        theme: args.theme,
        archetype: args.archetype,
        primary_emoji: args.primary_emoji,
        chain: chain_value,
        contract_address: args.contract_address,
        status: args.status,
        origin_story: args.origin_story,
        core_myth: args.core_myth,
        personality_traits: args.personality_traits,
        allied_symbols: args.allied_symbols,
        enemies_or_antagonists: args.enemies_or_antagonists,
        visual_motifs: args.visual_motifs,
        meme_angles: args.meme_angles,
        formats_recommended: args.formats_recommended,
        key_phrases: args.key_phrases,
        talking_points: args.talking_points,
        launch_hooks: args.launch_hooks,
        drop_ideas: args.drop_ideas,
        risk_notes: args.risk_notes,
        seo_title: args.seo_title,
        seo_description: args.seo_description,
        seo_keywords: args.seo_keywords,
        seo_hashtags: args.seo_hashtags,
        alt_text: args.alt_text,
        related_meme_ids: args.related_meme_ids,
        related_campaign_ids: args.related_campaign_ids,

        // New optional fields
        mascot_image_url: args.mascot_image_url,
        mascot_ipfs_url: args.mascot_ipfs_url,
        deployment_status: args.deployment_status,
        deployment_tx_hash: args.deployment_tx_hash,
        deployment_error: args.deployment_error,
        revenue_manager_address: args.revenue_manager_address,
        protocol_fee: args.protocol_fee,
        creator_wallet_address: args.creator_wallet_address,
        launched_at: args.launched_at,
        total_minted: args.total_minted,
        holder_count: args.holder_count,
        market_cap_usd: args.market_cap_usd,
        price_usd: args.price_usd,
        volume_24h: args.volume_24h,
        research_notes: args.research_notes,
        trend_score: args.trend_score,
        competitor_analysis: args.competitor_analysis,
        social_metrics: args.social_metrics,
        attached_meme_urls: args.attached_meme_urls,

        created_at: now,
        updated_at: now,
    };

    match ctx.db.culture_coin().try_insert(new_row) {
        Ok(inserted) => {
            spacetimedb::log::info!("Created CultureCoin id={}", inserted.id);
            Ok(())
        }
        Err(e) => {
            let msg = format!("Failed to create CultureCoin: {}", e);
            spacetimedb::log::error!("{}", msg);
            Err(msg)
        }
    }
}

#[reducer]
pub fn update_culture_coin(ctx: &ReducerContext, id: u64, changes: UpdateCultureCoinArgs) -> Result<(), String> {
    if let Some(mut coin) = ctx.db.culture_coin().id().find(id) {
        if let Some(v) = changes.name { coin.name = v; }
        if let Some(v) = changes.ticker { coin.ticker = v; }
        if let Some(v) = changes.short_tagline { coin.short_tagline = v; }
        if let Some(v) = changes.theme { coin.theme = v; }
        if let Some(v) = changes.archetype { coin.archetype = v; }
        if let Some(v) = changes.primary_emoji { coin.primary_emoji = v; }
        if let Some(v) = changes.chain { coin.chain = v; }
        if let Some(v) = changes.contract_address { coin.contract_address = Some(v); }
        if let Some(v) = changes.status { coin.status = v; }
        if let Some(v) = changes.origin_story { coin.origin_story = v; }
        if let Some(v) = changes.core_myth { coin.core_myth = v; }
        if let Some(v) = changes.personality_traits { coin.personality_traits = v; }
        if let Some(v) = changes.allied_symbols { coin.allied_symbols = v; }
        if let Some(v) = changes.enemies_or_antagonists { coin.enemies_or_antagonists = Some(v); }
        if let Some(v) = changes.visual_motifs { coin.visual_motifs = v; }
        if let Some(v) = changes.meme_angles { coin.meme_angles = v; }
        if let Some(v) = changes.formats_recommended { coin.formats_recommended = v; }
        if let Some(v) = changes.key_phrases { coin.key_phrases = v; }
        if let Some(v) = changes.talking_points { coin.talking_points = v; }
        if let Some(v) = changes.launch_hooks { coin.launch_hooks = v; }
        if let Some(v) = changes.drop_ideas { coin.drop_ideas = v; }
        if let Some(v) = changes.risk_notes { coin.risk_notes = v; }
        if let Some(v) = changes.seo_title { coin.seo_title = v; }
        if let Some(v) = changes.seo_description { coin.seo_description = v; }
        if let Some(v) = changes.seo_keywords { coin.seo_keywords = v; }
        if let Some(v) = changes.seo_hashtags { coin.seo_hashtags = v; }
        if let Some(v) = changes.alt_text { coin.alt_text = v; }
        if let Some(v) = changes.related_meme_ids { coin.related_meme_ids = v; }
        if let Some(v) = changes.related_campaign_ids { coin.related_campaign_ids = v; }

        // New optional fields updates
        if let Some(v) = changes.mascot_image_url { coin.mascot_image_url = Some(v); }
        if let Some(v) = changes.mascot_ipfs_url { coin.mascot_ipfs_url = Some(v); }
        if let Some(v) = changes.deployment_status { coin.deployment_status = Some(v); }
        if let Some(v) = changes.deployment_tx_hash { coin.deployment_tx_hash = Some(v); }
        if let Some(v) = changes.deployment_error { coin.deployment_error = Some(v); }
        if let Some(v) = changes.revenue_manager_address { coin.revenue_manager_address = Some(v); }
        if let Some(v) = changes.protocol_fee { coin.protocol_fee = Some(v); }
        if let Some(v) = changes.creator_wallet_address { coin.creator_wallet_address = Some(v); }
        if let Some(v) = changes.launched_at { coin.launched_at = Some(v); }
        if let Some(v) = changes.total_minted { coin.total_minted = Some(v); }
        if let Some(v) = changes.holder_count { coin.holder_count = Some(v); }
        if let Some(v) = changes.market_cap_usd { coin.market_cap_usd = Some(v); }
        if let Some(v) = changes.price_usd { coin.price_usd = Some(v); }
        if let Some(v) = changes.volume_24h { coin.volume_24h = Some(v); }
        if let Some(v) = changes.research_notes { coin.research_notes = Some(v); }
        if let Some(v) = changes.trend_score { coin.trend_score = Some(v); }
        if let Some(v) = changes.competitor_analysis { coin.competitor_analysis = Some(v); }
        if let Some(v) = changes.social_metrics { coin.social_metrics = Some(v); }
        if let Some(v) = changes.attached_meme_urls { coin.attached_meme_urls = Some(v); }

        coin.updated_at = ctx.timestamp;

        ctx.db.culture_coin().id().update(coin);
        Ok(())
    } else {
        let msg = format!("CultureCoin id={} not found", id);
        spacetimedb::log::warn!("{}", msg);
        Err(msg)
    }
}

#[reducer]
pub fn delete_culture_coin(ctx: &ReducerContext, id: u64) -> Result<(), String> {
    // Delete children GeoTargets first to avoid orphans
    let mut to_delete: Vec<u64> = Vec::new();
    for gt in ctx.db.geo_target().iter() {
        if gt.culture_coin_id == id {
            to_delete.push(gt.id);
        }
    }
    for gid in to_delete {
        ctx.db.geo_target().id().delete(gid);
    }

    if ctx.db.culture_coin().id().find(id).is_some() {
        ctx.db.culture_coin().id().delete(id);
        Ok(())
    } else {
        let msg = format!("CultureCoin id={} not found", id);
        spacetimedb::log::warn!("{}", msg);
        Err(msg)
    }
}

#[reducer]
pub fn create_geo_target(ctx: &ReducerContext, args: CreateGeoTargetArgs) -> Result<(), String> {
    // Ensure parent CultureCoin exists
    if ctx.db.culture_coin().id().find(args.culture_coin_id).is_none() {
        let msg = format!("Cannot create GeoTarget: CultureCoin id={} not found", args.culture_coin_id);
        spacetimedb::log::warn!("{}", msg);
        return Err(msg);
    }

    // Enforce unique geo_key
    for existing in ctx.db.geo_target().iter() {
        if existing.geo_key == args.geo_key {
            let msg = format!("GeoTarget with geo_key '{}' already exists", args.geo_key);
            spacetimedb::log::warn!("{}", msg);
            return Err(msg);
        }
    }

    let row = GeoTarget {
        id: 0,
        culture_coin_id: args.culture_coin_id,
        region: args.region,
        country: args.country,
        city_or_market: args.city_or_market,
        language: args.language,
        geo_key: args.geo_key,
        localized_caption: args.localized_caption,
        localized_tags: args.localized_tags,
    };

    match ctx.db.geo_target().try_insert(row) {
        Ok(inserted) => {
            spacetimedb::log::info!("Created GeoTarget id={} for CultureCoin id={}", inserted.id, inserted.culture_coin_id);
            Ok(())
        }
        Err(e) => {
            let msg = format!("Failed to create GeoTarget: {}", e);
            spacetimedb::log::error!("{}", msg);
            Err(msg)
        }
    }
}

#[reducer]
pub fn update_geo_target(ctx: &ReducerContext, id: u64, changes: UpdateGeoTargetArgs) -> Result<(), String> {
    if let Some(mut gt) = ctx.db.geo_target().id().find(id) {
        if let Some(new_ccid) = changes.culture_coin_id {
            if ctx.db.culture_coin().id().find(new_ccid).is_none() {
                let msg = format!("Cannot set culture_coin_id to {}: CultureCoin not found", new_ccid);
                spacetimedb::log::warn!("{}", msg);
                return Err(msg);
            }
            gt.culture_coin_id = new_ccid;
        }

        if let Some(v) = changes.region { gt.region = v; }
        if let Some(v) = changes.country { gt.country = Some(v); }
        if let Some(v) = changes.city_or_market { gt.city_or_market = v; }
        if let Some(v) = changes.language { gt.language = v; }
        if let Some(new_key) = changes.geo_key {
            // Ensure new geo_key is unique
            for other in ctx.db.geo_target().iter() {
                if other.id != gt.id && other.geo_key == new_key {
                    let msg = format!("GeoTarget with geo_key '{}' already exists", new_key);
                    spacetimedb::log::warn!("{}", msg);
                    return Err(msg);
                }
            }
            gt.geo_key = new_key;
        }
        if let Some(v) = changes.localized_caption { gt.localized_caption = v; }
        if let Some(v) = changes.localized_tags { gt.localized_tags = v; }

        ctx.db.geo_target().id().update(gt);
        Ok(())
    } else {
        let msg = format!("GeoTarget id={} not found", id);
        spacetimedb::log::warn!("{}", msg);
        Err(msg)
    }
}

#[reducer]
pub fn delete_geo_target(ctx: &ReducerContext, id: u64) -> Result<(), String> {
    if ctx.db.geo_target().id().find(id).is_some() {
        ctx.db.geo_target().id().delete(id);
        Ok(())
    } else {
        let msg = format!("GeoTarget id={} not found", id);
        spacetimedb::log::warn!("{}", msg);
        Err(msg)
    }
}