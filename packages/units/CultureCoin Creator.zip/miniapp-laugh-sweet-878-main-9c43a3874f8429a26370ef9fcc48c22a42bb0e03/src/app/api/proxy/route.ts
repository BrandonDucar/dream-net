import { NextResponse } from 'next/server'

export const runtime = 'edge'

const customSecretMappings: Record<string, string> = {
  "secret_cm9157zvu00003b6rg40werxy": "35a0b148-5091-445e-bf2e-0b980fac136a:c7ca5934547912218e7f0dd206ab0402",
  "secret_cmcb7gbz30000356n3sxdmhrd": "AIzaSyD8n3njg4bm1-JD-3Q7PJST7DRfa_UMEVk",
  "secret_cmhxx5g380000356ov8qk1tw7": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySW5mb3JtYXRpb24iOnsiaWQiOiI1NDBjYjllYi1kN2EwLTQ2ODgtYmRmOS0wNTUzN2YxYTNmNGYiLCJlbWFpbCI6ImNvbm5lY3Rpb25zQG9oYXJhLmFpIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsInBpbl9wb2xpY3kiOnsicmVnaW9ucyI6W3siZGVzaXJlZFJlcGxpY2F0aW9uQ291bnQiOjEsImlkIjoiRlJBMSJ9LHsiZGVzaXJlZFJlcGxpY2F0aW9uQ291bnQiOjEsImlkIjoiTllDMSJ9XSwidmVyc2lvbiI6MX0sIm1mYV9lbmFibGVkIjpmYWxzZSwic3RhdHVzIjoiQUNUSVZFIn0sImF1dGhlbnRpY2F0aW9uVHlwZSI6InNjb3BlZEtleSIsInNjb3BlZEtleUtleSI6ImRiMDA5MDI4MGUyODI1MTZkZGIyIiwic2NvcGVkS2V5U2VjcmV0IjoiODQ3ZmMxMDBhMDVmNzEyMzA4ZmZmMDdjNWZlOTc2ZjJmOTc0NjNjMzlmNGE3NWY0NjJmNzFhOGUyMzU5MGE1OCIsImV4cCI6MTc5NDUxNDA1N30.EIi3c3H7yOWNwyoPFt49yaCTrGh0xVCuXT5ShrZSUHs",
  "secret_cmbtluy3a0000356ntmpbqbbz": "xai-fIAd5LKvruY6VNwMQkkNrTlLSIVuCDTnxlXvDNUdi3oYnTayHGVhECXoRkm0TRYIgfKlBcPg4YpsVCnB"
}

function createSecretMap(): Map<string, string> {
  const secretMap = new Map<string, string>()

  for (const [key, value] of Object.entries(customSecretMappings)) {
    secretMap.set(key, value)
  }

  return secretMap
}

export async function GET(request: Request) {
  return handleRequest(request)
}

export async function POST(request: Request) {
  return handleRequest(request)
}

export async function PUT(request: Request) {
  return handleRequest(request)
}

export async function PATCH(request: Request) {
  return handleRequest(request)
}

export async function DELETE(request: Request) {
  return handleRequest(request)
}

async function handleRequest(request: Request) {
  let parsed
  const wordMap = createSecretMap()

  const contentType = request.headers.get('content-type')

  if (!contentType) {
    return NextResponse.json(
      { error: 'Missing content-type header in the request' },
      { status: 400 },
    )
  }

  if (contentType.includes('multipart/form-data')) {
    const proxyRequest = await request.formData()
    parsed = {
      protocol: '',
      origin: '',
      path: '',
      method: '',
      headers: {},
      body: new FormData(),
    }

    for (const [key, value] of proxyRequest.entries()) {
      if (key.startsWith('body[') && key.endsWith(']')) {
        const fieldName = key.slice(5, -1)
        parsed.body.append(
          fieldName,
          replaceMaskedWordsWithSecrets(value, wordMap),
        )
      } else if (key === 'headers') {
        try {
          parsed.headers = replaceMaskedWordsWithSecrets(
            JSON.parse(String(value)),
            wordMap,
          )
        } catch {
          return NextResponse.json(
            {
              error: 'Invalid headers in the body - must be a JSON object',
            },
            { status: 400 },
          )
        }
      } else {
        parsed[key] = replaceMaskedWordsWithSecrets(value, wordMap)
      }
    }
  } else if (contentType.includes('application/json')) {
    try {
      parsed = await request.json()
    } catch (error) {
      return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 })
    }

    if (wordMap.size > 0) {
      parsed = replaceMaskedWordsWithSecrets(parsed, wordMap)
    }
  } else {
    return NextResponse.json(
      { error: 'Unsupported content-type header' },
      { status: 400 },
    )
  }

  const { protocol, origin, path, method, headers, body } = parsed

  if (!protocol || !origin || !path || !method || !headers) {
    return NextResponse.json(
      { error: 'Missing required fields in request body' },
      { status: 400 },
    )
  }

  const fetchHeaders = new Headers(headers)
  if (contentType.includes('multipart/form-data')) {
    fetchHeaders.delete('content-type') // fetch sets the header automatically
  }

  try {
    const response = await fetch(
      `${protocol}://${origin}/${path.startsWith('/') ? path.slice(1) : path}`,
      {
        method,
        body:
          typeof body === 'string' || body instanceof FormData
            ? body
            : JSON.stringify(body),
        headers: fetchHeaders,
      },
    )

    const json = await response.json()
    return NextResponse.json(json)
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch external API', details: error.message },
      { status: 500 },
    )
  }
}

function replaceMaskedWordsWithSecrets(
  obj: any,
  wordMap: Map<string, string>,
): any {
  if (typeof obj === 'string') {
    return replaceInString(obj, wordMap)
  } else if (typeof obj === 'object' && obj.constructor.name === 'File') {
    return obj
  } else if (Array.isArray(obj)) {
    return obj.map((item) => replaceMaskedWordsWithSecrets(item, wordMap))
  } else if (typeof obj === 'object' && obj !== null) {
    const newObj: any = {}
    for (const key in obj) {
      newObj[key] = replaceMaskedWordsWithSecrets(obj[key], wordMap)
    }
    return newObj
  }
  return obj
}

function replaceInString(str: string, wordMap: Map<string, string>): string {
  for (const [word, replacement] of Array.from(wordMap.entries())) {
    const regex = new RegExp(`\\b${word}\\b`, 'gi')
    str = str.replace(regex, replacement)
  }
  return str
}
