'use client'
import { useState, useCallback, useEffect } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import type { CultureCoin, GeoTarget } from '../hooks/useLocalStorage';
import type { GeneratedCultureCoin } from '../lib/generator';
import { Sparkles, Wallet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import dynamic from 'next/dynamic';

// Dynamically import components to avoid SSR issues
const CultureCoinDashboard = dynamic(() => import('../components/CultureCoinDashboard').then(mod => ({ default: mod.CultureCoinDashboard })), { ssr: false });
const CreateCultureCoin = dynamic(() => import('../components/CreateCultureCoin').then(mod => ({ default: mod.CreateCultureCoin })), { ssr: false });
const CultureCoinDetail = dynamic(() => import('../components/CultureCoinDetail').then(mod => ({ default: mod.CultureCoinDetail })), { ssr: false });
const LaunchBriefExport = dynamic(() => import('../components/LaunchBriefExport').then(mod => ({ default: mod.LaunchBriefExport })), { ssr: false });
const HeroLanding = dynamic(() => import('../components/HeroLanding').then(mod => ({ default: mod.HeroLanding })), { ssr: false });
const OnboardingTutorial = dynamic(() => import('../components/OnboardingTutorial').then(mod => ({ default: mod.OnboardingTutorial })), { ssr: false });
const KeyboardShortcuts = dynamic(() => import('../components/KeyboardShortcuts').then(mod => ({ default: mod.KeyboardShortcuts })), { ssr: false });
const SuccessNotification = dynamic(() => import('../components/SuccessNotification').then(mod => ({ default: mod.SuccessNotification })), { ssr: false });

// Privy
import { usePrivy, useWallets } from '@privy-io/react-auth';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type View = 'dashboard' | 'create' | 'detail' | 'export';

export default function Home() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [mounted, setMounted] = useState(false);
  const [successMessage, setSuccessMessage] = useState<{message: string; submessage?: string; showConfetti?: boolean} | null>(null);
  const {
    cultureCoins,
    geoTargets,
    isLoading,
    createCultureCoin,
    updateCultureCoin,
    deleteCultureCoin,
    createGeoTarget,
    deleteGeoTarget,
  } = useLocalStorage();

  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [selectedCoinId, setSelectedCoinId] = useState<string | null>(null);

  // Privy wallet
  const { ready, authenticated, login, logout, user } = usePrivy();
  const { wallets } = useWallets();

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleCreateCultureCoin = useCallback((generatedCoin: GeneratedCultureCoin) => {
    const newCoin = createCultureCoin({
      name: generatedCoin.name,
      ticker: generatedCoin.ticker,
      shortTagline: generatedCoin.shortTagline,
      theme: generatedCoin.theme,
      archetype: generatedCoin.archetype,
      primaryEmoji: generatedCoin.primaryEmoji,
      chain: 'Base',
      contractAddress: undefined,
      status: 'idea',
      originStory: generatedCoin.originStory,
      coreMyth: generatedCoin.coreMyth,
      personalityTraits: generatedCoin.personalityTraits,
      alliedSymbols: generatedCoin.alliedSymbols,
      enemiesOrAntagonists: generatedCoin.enemiesOrAntagonists,
      visualMotifs: generatedCoin.visualMotifs,
      memeAngles: generatedCoin.memeAngles,
      formatsRecommended: generatedCoin.formatsRecommended,
      keyPhrases: generatedCoin.keyPhrases,
      talkingPoints: generatedCoin.talkingPoints,
      launchHooks: generatedCoin.launchHooks,
      dropIdeas: generatedCoin.dropIdeas,
      riskNotes: [],
      seoTitle: generatedCoin.seoTitle,
      seoDescription: generatedCoin.seoDescription,
      seoKeywords: generatedCoin.seoKeywords,
      seoHashtags: generatedCoin.seoHashtags,
      altText: generatedCoin.altText,
      relatedMemeIds: '',
      relatedCampaignIds: '',
      mascotImageUrl: generatedCoin.mascotImageUrl,
      mascotIpfsUrl: generatedCoin.mascotIpfsUrl,
      deploymentStatus: undefined,
      deploymentTxHash: undefined,
      deploymentError: undefined,
      revenueManagerAddress: undefined,
      protocolFee: undefined,
      creatorWalletAddress: undefined,
      launchedAt: undefined,
      totalMinted: undefined,
      holderCount: undefined,
      marketCapUsd: undefined,
      priceUsd: undefined,
      volume24H: undefined,
      researchNotes: undefined,
      trendScore: undefined,
      competitorAnalysis: undefined,
      socialMetrics: undefined,
      attachedMemeUrls: undefined,
    });

    setSuccessMessage({
      message: 'Culture Coin Created!',
      submessage: `${generatedCoin.name} is ready to launch`,
      showConfetti: true
    });
    setCurrentView('dashboard');
  }, [createCultureCoin]);

  const handleUpdateCultureCoin = useCallback((id: string, updates: Partial<CultureCoin>) => {
    updateCultureCoin(id, updates);
  }, [updateCultureCoin]);

  const handleDeleteCultureCoin = useCallback((id: string) => {
    deleteCultureCoin(id);
    setCurrentView('dashboard');
  }, [deleteCultureCoin]);

  const handleCreateGeoTarget = useCallback((cultureCoinId: string, target: Omit<GeoTarget, 'id' | 'cultureCoinId'>) => {
    createGeoTarget({
      cultureCoinId,
      region: target.region,
      country: target.country,
      cityOrMarket: target.cityOrMarket,
      language: target.language,
      geoKey: target.geoKey,
      localizedCaption: target.localizedCaption,
      localizedTags: target.localizedTags,
    });
  }, [createGeoTarget]);

  const handleDeleteGeoTarget = useCallback((id: string) => {
    deleteGeoTarget(id);
  }, [deleteGeoTarget]);

  const handleSelectCoin = useCallback((coin: CultureCoin) => {
    setSelectedCoinId(coin.id);
    setCurrentView('detail');
  }, []);

  const selectedCoin = selectedCoinId ? cultureCoins.get(selectedCoinId) : null;
  const selectedGeoTargets = selectedCoinId 
    ? Array.from(geoTargets.values()).filter((t: GeoTarget) => t.cultureCoinId === selectedCoinId)
    : [];

  const handleKeyboardAction = useCallback((action: string) => {
    if (action === 'create') {
      setCurrentView('create');
    } else if (action === 'search') {
      const searchInput = document.querySelector('input[type="text"]') as HTMLInputElement;
      if (searchInput) searchInput.focus();
    } else if (action === 'close') {
      if (currentView !== 'dashboard') {
        setCurrentView('dashboard');
      }
    }
  }, [currentView]);

  // Show loading only during initial mount
  if (!mounted || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-black via-gray-900 to-black text-white flex items-center justify-center">
        <div className="text-center">
          <Sparkles className="w-16 h-16 text-blue-500 mx-auto mb-4 animate-pulse" />
          <h1 className="text-2xl font-bold mb-2">CultureCoin Foundry</h1>
          <p className="text-gray-400">Loading your culture coins...</p>
        </div>
      </div>
    );
  }

  // Wallet button component
  const WalletButton = () => (
    <div className="fixed top-4 right-4 z-50">
      {!ready ? (
        <Button disabled className="bg-gray-800 text-gray-400">
          <Wallet className="w-4 h-4 mr-2" />
          Loading...
        </Button>
      ) : !authenticated ? (
        <Button 
          onClick={login}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
        >
          <Wallet className="w-4 h-4 mr-2" />
          Connect Wallet
        </Button>
      ) : (
        <div className="flex items-center gap-2">
          <div className="bg-gray-900 px-4 py-2 rounded-lg border border-gray-800">
            <div className="text-xs text-gray-400">Connected</div>
            <div className="text-sm font-mono">
              {wallets[0]?.address ? `${wallets[0].address.slice(0, 6)}...${wallets[0].address.slice(-4)}` : user?.email?.address || 'Wallet'}
            </div>
          </div>
          <Button 
            onClick={logout}
            variant="outline"
            size="sm"
            className="border-gray-800 hover:bg-gray-900"
          >
            Disconnect
          </Button>
        </div>
      )}
    </div>
  );

  // Route to different views
  if (currentView === 'create') {
    return (
      <>
        <WalletButton />
        <CreateCultureCoin
          onCancel={() => setCurrentView('dashboard')}
          onCreate={handleCreateCultureCoin}
        />
      </>
    );
  }

  if (currentView === 'detail' && selectedCoin) {
    return (
      <>
        <WalletButton />
        <CultureCoinDetail
          coin={selectedCoin}
          geoTargets={selectedGeoTargets}
          onBack={() => setCurrentView('dashboard')}
          onUpdate={handleUpdateCultureCoin}
          onDelete={handleDeleteCultureCoin}
          onCreateGeoTarget={handleCreateGeoTarget}
          onDeleteGeoTarget={handleDeleteGeoTarget}
          onExportBrief={() => setCurrentView('export')}
        />
      </>
    );
  }

  if (currentView === 'export' && selectedCoin) {
    return (
      <>
        <WalletButton />
        <LaunchBriefExport
          coin={selectedCoin}
          geoTargets={selectedGeoTargets}
          onBack={() => setCurrentView('detail')}
        />
      </>
    );
  }

  const coins = Array.from(cultureCoins.values());
  const showHero = coins.length === 0;

  if (showHero) {
    return (
      <>
        <WalletButton />
        <HeroLanding
          onGetStarted={() => setCurrentView('create')}
          totalCoins={coins.length}
        />
      </>
    );
  }

  return (
    <>
      <WalletButton />
      <OnboardingTutorial />
      <KeyboardShortcuts onAction={handleKeyboardAction} />
      {successMessage && (
        <SuccessNotification
          message={successMessage.message}
          submessage={successMessage.submessage}
          showConfetti={successMessage.showConfetti}
          onClose={() => setSuccessMessage(null)}
        />
      )}
      <CultureCoinDashboard
        cultureCoins={cultureCoins}
        onCreateNew={() => setCurrentView('create')}
        onSelectCoin={handleSelectCoin}
      />
    </>
  );
}
