'use client'

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Gift, Users, Shield, Download, Upload } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface AirdropBuilderProps {
  coinTicker: string;
}

export function AirdropBuilder({ coinTicker }: AirdropBuilderProps) {
  const [criteriaType, setCriteriaType] = useState<string>('holder');
  const [totalAmount, setTotalAmount] = useState<string>('');
  const [addresses, setAddresses] = useState<string>('');
  const [antiSybilEnabled, setAntiSybilEnabled] = useState<boolean>(true);

  const handleGenerateMerkle = (): void => {
    console.log('Generating Merkle tree...');
  };

  const handleExportCSV = (): void => {
    console.log('Exporting CSV...');
  };

  return (
    <Card className="bg-gray-900 border-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Gift className="w-5 h-5" />
          Airdrop Builder
        </CardTitle>
        <CardDescription>Create criteria-based token distributions</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div>
            <Label>Distribution Criteria</Label>
            <Select value={criteriaType} onValueChange={setCriteriaType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="holder">NFT Holders</SelectItem>
                <SelectItem value="activity">On-chain Activity</SelectItem>
                <SelectItem value="lp">LP Providers</SelectItem>
                <SelectItem value="whitelist">Whitelist</SelectItem>
                <SelectItem value="snapshot">Snapshot Voters</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-gray-500 mt-1">
              Select how recipients will be determined
            </p>
          </div>

          <div>
            <Label>Total Airdrop Amount</Label>
            <Input
              type="number"
              placeholder="1000000"
              value={totalAmount}
              onChange={(e) => setTotalAmount(e.target.value)}
            />
            <p className="text-xs text-gray-500 mt-1">
              Total {coinTicker} tokens to distribute
            </p>
          </div>

          <div>
            <Label className="flex items-center justify-between">
              Recipient Addresses
              <Button size="sm" variant="ghost" onClick={handleExportCSV}>
                <Upload className="w-4 h-4 mr-2" />
                Import CSV
              </Button>
            </Label>
            <Textarea
              placeholder="0x1234...&#10;0x5678...&#10;0x9abc..."
              value={addresses}
              onChange={(e) => setAddresses(e.target.value)}
              rows={6}
              className="font-mono text-xs"
            />
            <p className="text-xs text-gray-500 mt-1">
              One address per line, or import from CSV
            </p>
          </div>

          <div className="flex items-center justify-between p-3 rounded-lg bg-gray-800">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-green-500" />
              <div>
                <p className="text-sm font-medium">Anti-Sybil Detection</p>
                <p className="text-xs text-gray-400">Filter wallet clustering & bots</p>
              </div>
            </div>
            <Button
              size="sm"
              variant={antiSybilEnabled ? 'default' : 'outline'}
              onClick={() => setAntiSybilEnabled(!antiSybilEnabled)}
            >
              {antiSybilEnabled ? 'Enabled' : 'Disabled'}
            </Button>
          </div>
        </div>

        <div className="pt-4 border-t border-gray-800">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm font-medium">Distribution Summary</p>
              <p className="text-xs text-gray-400">Merkle claim contract</p>
            </div>
            <Badge variant="outline">
              <Users className="w-3 h-3 mr-1" />
              {addresses.split('\n').filter(a => a.trim()).length} recipients
            </Badge>
          </div>

          <div className="flex gap-2">
            <Button onClick={handleGenerateMerkle} className="flex-1">
              Generate Merkle Tree
            </Button>
            <Button variant="outline" onClick={handleExportCSV}>
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
