'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { TrendingUp, Users, Activity, AlertTriangle, DollarSign, BarChart3 } from 'lucide-react';
import type { CultureCoin } from '../spacetime_module_bindings/culture_coin_type';

interface AnalyticsDashboardProps {
  coin: CultureCoin;
}

export function AnalyticsDashboard({ coin }: AnalyticsDashboardProps) {
  const mockData = {
    holders: coin.holderCount || 1234,
    volume24h: coin.volume24H || 45678,
    marketCap: coin.marketCapUsd || 123456,
    price: coin.priceUsd || 0.00123,
    trendScore: coin.trendScore || 75,
    botActivity: 12,
    whaleCount: 8,
    sentiment: 'Positive',
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Holders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <p className="text-2xl font-bold">{mockData.holders.toLocaleString()}</p>
              <Users className="w-4 h-4 text-blue-500" />
            </div>
            <Badge variant="outline" className="mt-2">
              <TrendingUp className="w-3 h-3 mr-1" />
              +12.3%
            </Badge>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">24h Volume</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <p className="text-2xl font-bold">${(mockData.volume24h / 1000).toFixed(1)}K</p>
              <Activity className="w-4 h-4 text-green-500" />
            </div>
            <Badge variant="outline" className="mt-2">
              <TrendingUp className="w-3 h-3 mr-1" />
              +8.7%
            </Badge>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Market Cap</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <p className="text-2xl font-bold">${(mockData.marketCap / 1000).toFixed(0)}K</p>
              <DollarSign className="w-4 h-4 text-yellow-500" />
            </div>
            <p className="text-xs text-gray-500 mt-2">${mockData.price.toFixed(6)}/token</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Trend Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <p className="text-2xl font-bold">{mockData.trendScore}/100</p>
              <BarChart3 className="w-4 h-4 text-purple-500" />
            </div>
            <Badge variant="default" className="mt-2">
              {mockData.sentiment}
            </Badge>
          </CardContent>
        </Card>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle>Holder Analysis</CardTitle>
            <CardDescription>Distribution and concentration metrics</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Top 10 holders</span>
              <span className="font-medium">34.2%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Whale wallets (>1%)</span>
              <span className="font-medium">{mockData.whaleCount}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">New holders (24h)</span>
              <Badge variant="outline">+89</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Average hold time</span>
              <span className="font-medium">12.4 days</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-yellow-500" />
              Security Alerts
            </CardTitle>
            <CardDescription>Bot detection and suspicious activity</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between p-2 rounded bg-yellow-500/10 border border-yellow-500/20">
              <span className="text-sm">Bot activity detected</span>
              <Badge variant="outline" className="text-yellow-500">{mockData.botActivity} wallets</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Suspicious trades (24h)</span>
              <span className="font-medium">3</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Wallet clustering</span>
              <Badge variant="outline" className="text-green-500">Low risk</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Contract security</span>
              <Badge variant="outline" className="text-green-500">Verified</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle>Social Sentiment Analysis</CardTitle>
          <CardDescription>Real-time monitoring from X, Farcaster, Discord</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-4 rounded-lg bg-gray-800">
              <p className="text-3xl font-bold text-green-500">78%</p>
              <p className="text-sm text-gray-400 mt-1">Positive</p>
            </div>
            <div className="text-center p-4 rounded-lg bg-gray-800">
              <p className="text-3xl font-bold text-gray-400">16%</p>
              <p className="text-sm text-gray-400 mt-1">Neutral</p>
            </div>
            <div className="text-center p-4 rounded-lg bg-gray-800">
              <p className="text-3xl font-bold text-red-500">6%</p>
              <p className="text-sm text-gray-400 mt-1">Negative</p>
            </div>
          </div>
          <div className="mt-4 space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Mentions (24h)</span>
              <span className="font-medium">1,234</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Trending rank</span>
              <Badge variant="outline">#42 on Base</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
