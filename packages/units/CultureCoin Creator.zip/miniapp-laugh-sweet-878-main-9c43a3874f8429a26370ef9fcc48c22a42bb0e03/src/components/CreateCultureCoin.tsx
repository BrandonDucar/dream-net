'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Sparkles, Wand2, ArrowLeft } from 'lucide-react';
import { generateCultureCoin } from '../lib/generator';
import type { GeneratedCultureCoin } from '../lib/generator';
import { ImageGenerationPanel } from './ImageGenerationPanel';

interface CreateCultureCoinProps {
  onCancel: () => void;
  onCreate: (coin: GeneratedCultureCoin) => void;
}

export function CreateCultureCoin({ onCancel, onCreate }: CreateCultureCoinProps) {
  const [name, setName] = useState<string>('');
  const [ticker, setTicker] = useState<string>('');
  const [vibe, setVibe] = useState<string>('');
  const [generated, setGenerated] = useState<GeneratedCultureCoin | null>(null);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [mascotImage, setMascotImage] = useState<string | null>(null);
  const [mascotIpfs, setMascotIpfs] = useState<string | null>(null);

  const handleGenerate = () => {
    if (!name || !ticker || !vibe) return;
    
    setIsGenerating(true);
    setTimeout(() => {
      const coin = generateCultureCoin(name, ticker.toUpperCase(), vibe);
      setGenerated(coin);
      setIsGenerating(false);
    }, 500);
  };

  const handleSave = () => {
    if (generated) {
      onCreate({ ...generated, mascotImageUrl: mascotImage || undefined, mascotIpfsUrl: mascotIpfs || undefined });
    }
  };

  const handleRegenerate = () => {
    handleGenerate();
  };

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <div className="max-w-4xl mx-auto">
        <Button
          variant="ghost"
          onClick={onCancel}
          className="mb-6 text-gray-400 hover:text-white"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-3xl flex items-center gap-2">
              <Wand2 className="w-8 h-8 text-blue-500" />
              Create CultureCoin
            </CardTitle>
            <p className="text-gray-400">Generate a complete culture coin with lore, memes, and messaging</p>
          </CardHeader>
          <CardContent className="space-y-6">
            {!generated ? (
              <>
                <div className="space-y-2">
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    placeholder="e.g., DreamSnail, Jaggy Signal"
                    value={name}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="ticker">Ticker</Label>
                  <Input
                    id="ticker"
                    placeholder="e.g., SNAIL, JAGGY"
                    value={ticker}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTicker(e.target.value.toUpperCase())}
                    className="bg-gray-800 border-gray-700 text-white font-mono"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="vibe">Vibe / Theme / Prompt</Label>
                  <Textarea
                    id="vibe"
                    placeholder="Describe the vibe... e.g., cozy chaos, guardian of Base, mystical tech oracle"
                    value={vibe}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setVibe(e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white min-h-[100px]"
                  />
                </div>

                <Button
                  onClick={handleGenerate}
                  disabled={!name || !ticker || !vibe || isGenerating}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  size="lg"
                >
                  {isGenerating ? (
                    <>
                      <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate CultureCoin
                    </>
                  )}
                </Button>
              </>
            ) : (
              <>
                <div className="bg-gray-800 p-6 rounded-lg space-y-4">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-5xl">{generated.primaryEmoji}</span>
                    <div>
                      <h3 className="text-2xl font-bold">{generated.name}</h3>
                      <p className="text-blue-400 font-mono">${generated.ticker}</p>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold text-gray-400 mb-1">TAGLINE</h4>
                    <p className="text-white">{generated.shortTagline}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="text-sm font-semibold text-gray-400 mb-1">THEME</h4>
                      <p className="text-white text-sm">{generated.theme}</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-gray-400 mb-1">ARCHETYPE</h4>
                      <p className="text-white text-sm">{generated.archetype}</p>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold text-gray-400 mb-1">ORIGIN STORY</h4>
                    <p className="text-gray-300 text-sm">{generated.originStory}</p>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold text-gray-400 mb-1">MEME ANGLES</h4>
                    <ul className="list-disc list-inside text-gray-300 text-sm space-y-1">
                      {generated.memeAngles.slice(0, 3).map((angle: string, idx: number) => (
                        <li key={idx}>{angle}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                <ImageGenerationPanel
                  coinName={generated.name}
                  ticker={generated.ticker}
                  theme={generated.theme}
                  onImageGenerated={(imageUrl: string, ipfsUrl?: string) => {
                    setMascotImage(imageUrl);
                    if (ipfsUrl) setMascotIpfs(ipfsUrl);
                  }}
                />

                <div className="flex gap-3">
                  <Button
                    onClick={handleSave}
                    className="flex-1 bg-green-600 hover:bg-green-700"
                    size="lg"
                  >
                    Save CultureCoin
                  </Button>
                  <Button
                    onClick={handleRegenerate}
                    variant="outline"
                    className="flex-1 border-gray-700 hover:bg-gray-800"
                    size="lg"
                  >
                    <Sparkles className="w-4 h-4 mr-2" />
                    Regenerate
                  </Button>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
