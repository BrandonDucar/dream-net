'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Input } from './ui/input';
import type { CultureCoin } from '../hooks/useLocalStorage';
import { Sparkles, Filter, Search } from 'lucide-react';
import { WalletButton } from './WalletButton';

interface CultureCoinDashboardProps {
  cultureCoins: ReadonlyMap<string, CultureCoin>;
  onCreateNew: () => void;
  onSelectCoin: (coin: CultureCoin) => void;
}

export function CultureCoinDashboard({ cultureCoins, onCreateNew, onSelectCoin }: CultureCoinDashboardProps) {
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [archetypeFilter, setArchetypeFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const coins = Array.from(cultureCoins.values());
  
  const filteredCoins = coins.filter((coin: CultureCoin) => {
    if (statusFilter !== 'all' && coin.status !== statusFilter) return false;
    if (archetypeFilter !== 'all' && coin.archetype !== archetypeFilter) return false;
    if (searchQuery && !coin.name.toLowerCase().includes(searchQuery.toLowerCase()) && 
        !coin.ticker.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const statuses = Array.from(new Set(coins.map((c: CultureCoin) => c.status)));
  const archetypes = Array.from(new Set(coins.map((c: CultureCoin) => c.archetype)));

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold mb-2 flex items-center gap-2">
              <Sparkles className="w-8 h-8 text-blue-500 animate-pulse" />
              CultureCoin Foundry
            </h1>
            <p className="text-gray-400">You have {coins.length} culture coin{coins.length !== 1 ? 's' : ''} in your foundry</p>
          </div>
          <div className="flex items-center gap-3">
            <WalletButton />
            <Button onClick={onCreateNew} size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
              <Sparkles className="w-4 h-4 mr-2" />
              Create New Coin
            </Button>
          </div>
        </div>

        <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search by name or ticker..."
                  value={searchQuery}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-gray-800 border-gray-700 text-white"
                />
              </div>
              <div className="flex gap-2">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[150px] bg-gray-800 border-gray-700 text-white">
                    <Filter className="w-4 h-4 mr-2" />
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-700 text-white">
                    <SelectItem value="all">All Status</SelectItem>
                    {statuses.map((status: string) => (
                      <SelectItem key={status} value={status}>{status}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={archetypeFilter} onValueChange={setArchetypeFilter}>
                  <SelectTrigger className="w-[150px] bg-gray-800 border-gray-700 text-white">
                    <SelectValue placeholder="Archetype" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-700 text-white">
                    <SelectItem value="all">All Archetypes</SelectItem>
                    {archetypes.map((archetype: string) => (
                      <SelectItem key={archetype} value={archetype}>{archetype}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {filteredCoins.length === 0 ? (
          <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm">
            <CardContent className="py-16 text-center">
              <Sparkles className="w-16 h-16 text-blue-500 mx-auto mb-4 animate-pulse" />
              <h3 className="text-2xl font-bold mb-2 text-white">No matches found</h3>
              <p className="text-gray-400 mb-6">Try adjusting your filters or search query</p>
              <Button 
                onClick={() => {
                  setStatusFilter('all');
                  setArchetypeFilter('all');
                  setSearchQuery('');
                }}
                variant="outline"
                className="border-gray-600 hover:border-blue-500"
              >
                Clear Filters
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCoins.map((coin: CultureCoin) => (
              <Card 
                key={coin.id.toString()} 
                className="bg-gradient-to-br from-gray-900 to-gray-800 border-gray-700 hover:border-blue-500 hover:shadow-lg hover:shadow-blue-500/20 transition-all cursor-pointer group"
                onClick={() => onSelectCoin(coin)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-2xl flex items-center gap-2">
                        <span className="text-3xl group-hover:scale-110 transition-transform">{coin.primaryEmoji}</span>
                        <span>{coin.name}</span>
                      </CardTitle>
                      <p className="text-blue-400 font-mono text-sm mt-1">${coin.ticker}</p>
                    </div>
                    <Badge 
                      variant="outline" 
                      className={`text-xs ${
                        coin.status === 'launched' ? 'border-green-500 text-green-500' :
                        coin.status === 'ready' ? 'border-blue-500 text-blue-500' :
                        coin.status === 'draft' ? 'border-yellow-500 text-yellow-500' :
                        'border-gray-500 text-gray-500'
                      }`}
                    >
                      {coin.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400 text-sm mb-3 line-clamp-2">{coin.shortTagline}</p>
                  <div className="flex flex-wrap gap-2 mb-3">
                    <Badge variant="secondary" className="text-xs bg-gray-800">
                      {coin.archetype}
                    </Badge>
                    <Badge variant="secondary" className="text-xs bg-gray-800">
                      {coin.chain}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-500">{coin.theme}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
