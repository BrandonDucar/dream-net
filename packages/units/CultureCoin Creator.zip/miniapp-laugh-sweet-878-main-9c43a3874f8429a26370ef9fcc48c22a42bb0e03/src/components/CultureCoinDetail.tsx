'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { ArrowLeft, Save, Sparkles, Trash2, Plus, FileText } from 'lucide-react';
import type { CultureCoin, GeoTarget } from '../hooks/useLocalStorage';
import { 
  regenerateNarrative, 
  regenerateMemeDirections, 
  regenerateMessagingAndSEO,
  generateGeoVariants 
} from '../lib/generator';
import { ImageGenerationPanel } from './ImageGenerationPanel';
import { TokenDeployment } from './TokenDeployment';
import { MemeDiscovery } from './MemeDiscovery';
import { MarketResearch } from './MarketResearch';
import { VersionHistory } from './VersionHistory';
import { AirdropBuilder } from './AirdropBuilder';
import { AnalyticsDashboard } from './AnalyticsDashboard';
import { LaunchScheduler } from './LaunchScheduler';
import { TokenomicsCalculator } from './TokenomicsCalculator';
import { QuestSystem } from './QuestSystem';
import { VideoGeneration } from './VideoGeneration';
import { ExportTemplates } from './ExportTemplates';

interface CultureCoinDetailProps {
  coin: CultureCoin;
  geoTargets: GeoTarget[];
  onBack: () => void;
  onUpdate: (id: string, updates: Partial<CultureCoin>) => void;
  onDelete: (id: string) => void;
  onCreateGeoTarget: (cultureCoinId: string, target: Omit<GeoTarget, 'id' | 'cultureCoinId'>) => void;
  onDeleteGeoTarget: (id: string) => void;
  onExportBrief: () => void;
}

export function CultureCoinDetail({ 
  coin, 
  geoTargets,
  onBack, 
  onUpdate, 
  onDelete,
  onCreateGeoTarget,
  onDeleteGeoTarget,
  onExportBrief 
}: CultureCoinDetailProps) {
  const [editedCoin, setEditedCoin] = useState<CultureCoin>(coin);
  const [hasChanges, setHasChanges] = useState<boolean>(false);

  const updateField = <K extends keyof CultureCoin>(field: K, value: CultureCoin[K]) => {
    setEditedCoin({ ...editedCoin, [field]: value });
    setHasChanges(true);
  };

  const handleSave = () => {
    onUpdate(coin.id, editedCoin);
    setHasChanges(false);
  };

  const handleRegenerateNarrative = () => {
    const updates = regenerateNarrative(editedCoin as unknown as { name: string; ticker: string; shortTagline: string; theme: string; archetype: string; primaryEmoji: string; originStory: string; coreMyth: string; personalityTraits: string[]; alliedSymbols: string[]; enemiesOrAntagonists?: string; visualMotifs: string[]; memeAngles: string[]; formatsRecommended: string[]; keyPhrases: string[]; talkingPoints: string[]; launchHooks: string[]; dropIdeas: string[]; seoTitle: string; seoDescription: string; seoKeywords: string[]; seoHashtags: string[]; altText: string; });
    setEditedCoin({ ...editedCoin, ...updates });
    setHasChanges(true);
  };

  const handleRegenerateMemeDirections = () => {
    const updates = regenerateMemeDirections(editedCoin as unknown as { name: string; ticker: string; shortTagline: string; theme: string; archetype: string; primaryEmoji: string; originStory: string; coreMyth: string; personalityTraits: string[]; alliedSymbols: string[]; enemiesOrAntagonists?: string; visualMotifs: string[]; memeAngles: string[]; formatsRecommended: string[]; keyPhrases: string[]; talkingPoints: string[]; launchHooks: string[]; dropIdeas: string[]; seoTitle: string; seoDescription: string; seoKeywords: string[]; seoHashtags: string[]; altText: string; });
    setEditedCoin({ ...editedCoin, ...updates });
    setHasChanges(true);
  };

  const handleRegenerateMessaging = () => {
    const updates = regenerateMessagingAndSEO(editedCoin as unknown as { name: string; ticker: string; shortTagline: string; theme: string; archetype: string; primaryEmoji: string; originStory: string; coreMyth: string; personalityTraits: string[]; alliedSymbols: string[]; enemiesOrAntagonists?: string; visualMotifs: string[]; memeAngles: string[]; formatsRecommended: string[]; keyPhrases: string[]; talkingPoints: string[]; launchHooks: string[]; dropIdeas: string[]; seoTitle: string; seoDescription: string; seoKeywords: string[]; seoHashtags: string[]; altText: string; });
    setEditedCoin({ ...editedCoin, ...updates });
    setHasChanges(true);
  };

  const handleGenerateGeoVariants = () => {
    const variants = generateGeoVariants(coin.name, coin.ticker, coin.shortTagline);
    variants.forEach((variant: { geoKey: string; region: string; language: string; localizedCaption: string; localizedTags: string[] }) => {
      onCreateGeoTarget(coin.id, {
        region: variant.region,
        country: undefined,
        cityOrMarket: variant.region,
        language: variant.language,
        geoKey: variant.geoKey,
        localizedCaption: variant.localizedCaption,
        localizedTags: variant.localizedTags.join(', '),
      });
    });
  };

  const ArrayField = ({ label, value, onChange }: { label: string; value: string[]; onChange: (val: string[]) => void }) => (
    <div className="space-y-2">
      <Label>{label}</Label>
      <Textarea
        value={value.join('\n')}
        onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => onChange(e.target.value.split('\n').filter((s: string) => s.trim()))}
        className="bg-gray-800 border-gray-700 text-white min-h-[100px] font-mono text-sm"
        placeholder="One per line"
      />
    </div>
  );

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <Button variant="ghost" onClick={onBack} className="text-gray-400 hover:text-white">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              onClick={onExportBrief}
              className="border-gray-700 hover:bg-gray-800"
            >
              <FileText className="w-4 h-4 mr-2" />
              Export Launch Brief
            </Button>
            <Button 
              variant="outline" 
              onClick={() => onDelete(coin.id)}
              className="border-red-900 text-red-400 hover:bg-red-950"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete
            </Button>
            <Button 
              onClick={handleSave} 
              disabled={!hasChanges}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </div>

        <Card className="bg-gray-900 border-gray-800 mb-6">
          <CardHeader>
            <div className="flex items-center gap-4">
              <span className="text-6xl">{editedCoin.primaryEmoji}</span>
              <div>
                <CardTitle className="text-3xl">{editedCoin.name}</CardTitle>
                <p className="text-blue-400 font-mono text-xl">${editedCoin.ticker}</p>
              </div>
            </div>
          </CardHeader>
        </Card>

        <Tabs defaultValue="identity" className="space-y-6">
          <ScrollArea className="w-full">
            <TabsList className="bg-gray-900 border border-gray-800 p-1 w-max">
              <TabsTrigger value="identity">Identity</TabsTrigger>
              <TabsTrigger value="lore">Lore</TabsTrigger>
              <TabsTrigger value="meme">Meme</TabsTrigger>
              <TabsTrigger value="messaging">Messaging</TabsTrigger>
              <TabsTrigger value="seo">SEO</TabsTrigger>
              <TabsTrigger value="geo">Geo</TabsTrigger>
              <TabsTrigger value="visual">Visual</TabsTrigger>
              <TabsTrigger value="video">Video</TabsTrigger>
              <TabsTrigger value="deploy">Deploy</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="airdrop">Airdrop</TabsTrigger>
              <TabsTrigger value="launch">Launch</TabsTrigger>
              <TabsTrigger value="tokenomics">Tokenomics</TabsTrigger>
              <TabsTrigger value="quests">Quests</TabsTrigger>
              <TabsTrigger value="memes">Memes</TabsTrigger>
              <TabsTrigger value="research">Research</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
              <TabsTrigger value="related">Related</TabsTrigger>
              <TabsTrigger value="export">Export</TabsTrigger>
            </TabsList>
          </ScrollArea>

          <TabsContent value="identity">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>Identity & Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input
                      id="name"
                      value={editedCoin.name}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('name', e.target.value)}
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="ticker">Ticker</Label>
                    <Input
                      id="ticker"
                      value={editedCoin.ticker}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('ticker', e.target.value.toUpperCase())}
                      className="bg-gray-800 border-gray-700 text-white font-mono"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tagline">Short Tagline</Label>
                  <Input
                    id="tagline"
                    value={editedCoin.shortTagline}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('shortTagline', e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="theme">Theme</Label>
                    <Input
                      id="theme"
                      value={editedCoin.theme}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('theme', e.target.value)}
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="archetype">Archetype</Label>
                    <Input
                      id="archetype"
                      value={editedCoin.archetype}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('archetype', e.target.value)}
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="emoji">Primary Emoji</Label>
                    <Input
                      id="emoji"
                      value={editedCoin.primaryEmoji}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('primaryEmoji', e.target.value)}
                      className="bg-gray-800 border-gray-700 text-white text-2xl text-center"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="chain">Chain</Label>
                    <Input
                      id="chain"
                      value={editedCoin.chain}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('chain', e.target.value)}
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="contract">Contract Address (optional)</Label>
                    <Input
                      id="contract"
                      value={editedCoin.contractAddress || ''}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('contractAddress', e.target.value || undefined)}
                      className="bg-gray-800 border-gray-700 text-white font-mono"
                      placeholder="0x..."
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select value={editedCoin.status} onValueChange={(val: string) => updateField('status', val)}>
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-700 text-white">
                      <SelectItem value="idea">Idea</SelectItem>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="ready">Ready</SelectItem>
                      <SelectItem value="launched">Launched</SelectItem>
                      <SelectItem value="retired">Retired</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="lore">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Lore & Narrative</CardTitle>
                <Button 
                  onClick={handleRegenerateNarrative}
                  variant="outline"
                  size="sm"
                  className="border-gray-700 hover:bg-gray-800"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Regenerate
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="origin">Origin Story</Label>
                  <Textarea
                    id="origin"
                    value={editedCoin.originStory}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => updateField('originStory', e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white min-h-[120px]"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="myth">Core Myth</Label>
                  <Textarea
                    id="myth"
                    value={editedCoin.coreMyth}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => updateField('coreMyth', e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white min-h-[100px]"
                  />
                </div>
                <ArrayField
                  label="Personality Traits"
                  value={editedCoin.personalityTraits}
                  onChange={(val: string[]) => updateField('personalityTraits', val)}
                />
                <ArrayField
                  label="Allied Symbols"
                  value={editedCoin.alliedSymbols}
                  onChange={(val: string[]) => updateField('alliedSymbols', val)}
                />
                <div className="space-y-2">
                  <Label htmlFor="enemies">Enemies/Antagonists (optional)</Label>
                  <Textarea
                    id="enemies"
                    value={editedCoin.enemiesOrAntagonists || ''}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => updateField('enemiesOrAntagonists', e.target.value || undefined)}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="meme">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Meme & Visual Direction</CardTitle>
                <Button 
                  onClick={handleRegenerateMemeDirections}
                  variant="outline"
                  size="sm"
                  className="border-gray-700 hover:bg-gray-800"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Regenerate
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                <ArrayField
                  label="Visual Motifs"
                  value={editedCoin.visualMotifs}
                  onChange={(val: string[]) => updateField('visualMotifs', val)}
                />
                <ArrayField
                  label="Meme Angles"
                  value={editedCoin.memeAngles}
                  onChange={(val: string[]) => updateField('memeAngles', val)}
                />
                <ArrayField
                  label="Formats Recommended"
                  value={editedCoin.formatsRecommended}
                  onChange={(val: string[]) => updateField('formatsRecommended', val)}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="messaging">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Messaging & Launch</CardTitle>
                <Button 
                  onClick={handleRegenerateMessaging}
                  variant="outline"
                  size="sm"
                  className="border-gray-700 hover:bg-gray-800"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Regenerate
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                <ArrayField
                  label="Key Phrases"
                  value={editedCoin.keyPhrases}
                  onChange={(val: string[]) => updateField('keyPhrases', val)}
                />
                <ArrayField
                  label="Talking Points"
                  value={editedCoin.talkingPoints}
                  onChange={(val: string[]) => updateField('talkingPoints', val)}
                />
                <ArrayField
                  label="Launch Hooks"
                  value={editedCoin.launchHooks}
                  onChange={(val: string[]) => updateField('launchHooks', val)}
                />
                <ArrayField
                  label="Drop Ideas"
                  value={editedCoin.dropIdeas}
                  onChange={(val: string[]) => updateField('dropIdeas', val)}
                />
                <ArrayField
                  label="Risk Notes"
                  value={editedCoin.riskNotes}
                  onChange={(val: string[]) => updateField('riskNotes', val)}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="seo">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>SEO & Meta</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="seoTitle">SEO Title</Label>
                  <Input
                    id="seoTitle"
                    value={editedCoin.seoTitle}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('seoTitle', e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="seoDesc">SEO Description</Label>
                  <Textarea
                    id="seoDesc"
                    value={editedCoin.seoDescription}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => updateField('seoDescription', e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <ArrayField
                  label="SEO Keywords"
                  value={editedCoin.seoKeywords}
                  onChange={(val: string[]) => updateField('seoKeywords', val)}
                />
                <ArrayField
                  label="SEO Hashtags"
                  value={editedCoin.seoHashtags}
                  onChange={(val: string[]) => updateField('seoHashtags', val)}
                />
                <div className="space-y-2">
                  <Label htmlFor="altText">Alt Text</Label>
                  <Textarea
                    id="altText"
                    value={editedCoin.altText}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => updateField('altText', e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="geo">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Geo Targeting</CardTitle>
                <Button 
                  onClick={handleGenerateGeoVariants}
                  variant="outline"
                  size="sm"
                  className="border-gray-700 hover:bg-gray-800"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Generate Geo Variants
                </Button>
              </CardHeader>
              <CardContent>
                {geoTargets.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">
                    <p>No geo targets yet. Generate variants to start.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {geoTargets.map((target: GeoTarget) => (
                      <Card key={target.id.toString()} className="bg-gray-800 border-gray-700">
                        <CardContent className="pt-4 space-y-2">
                          <div className="flex justify-between items-start">
                            <div className="flex gap-2">
                              <Badge>{target.region}</Badge>
                              <Badge variant="outline">{target.language}</Badge>
                              <Badge variant="outline" className="font-mono">{target.geoKey}</Badge>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onDeleteGeoTarget(target.id)}
                              className="text-red-400 hover:text-red-300"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                          <p className="text-sm text-gray-300">{target.localizedCaption}</p>
                          <p className="text-xs text-gray-500">{target.localizedTags}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="visual">
            <div className="space-y-6">
              <ImageGenerationPanel
                coinName={editedCoin.name}
                ticker={editedCoin.ticker}
                theme={editedCoin.theme}
                onImageGenerated={(imageUrl: string, ipfsUrl?: string) => {
                  updateField('mascotImageUrl', imageUrl);
                  if (ipfsUrl) updateField('mascotIpfsUrl', ipfsUrl);
                }}
              />
              {editedCoin.mascotImageUrl && (
                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <CardTitle>Current Mascot</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <img
                      src={editedCoin.mascotImageUrl}
                      alt={`${editedCoin.name} mascot`}
                      className="w-full max-w-md mx-auto rounded-lg"
                    />
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="deploy">
            <TokenDeployment
              coinName={editedCoin.name}
              ticker={editedCoin.ticker}
              description={editedCoin.shortTagline}
              mascotImageUrl={editedCoin.mascotImageUrl}
              onDeploymentComplete={(contractAddress: string, revenueManager?: string) => {
                updateField('contractAddress', contractAddress);
                updateField('deploymentStatus', 'deployed');
                updateField('status', 'launched');
                if (revenueManager) updateField('revenueManagerAddress', revenueManager);
                setHasChanges(true);
              }}
            />
          </TabsContent>

          <TabsContent value="memes">
            <MemeDiscovery
              onMemeSelected={(memeUrl: string) => {
                const currentUrls = editedCoin.attachedMemeUrls || '';
                const urlsArray = currentUrls.split(',').filter((u: string) => u.trim());
                if (!urlsArray.includes(memeUrl)) {
                  urlsArray.push(memeUrl);
                  updateField('attachedMemeUrls', urlsArray.join(','));
                }
              }}
            />
            {editedCoin.attachedMemeUrls && (
              <Card className="bg-gray-900 border-gray-800 mt-4">
                <CardHeader>
                  <CardTitle>Attached Memes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-2">
                    {editedCoin.attachedMemeUrls.split(',').filter((u: string) => u.trim()).map((url: string, idx: number) => (
                      <img key={idx} src={url.trim()} alt={`Meme ${idx + 1}`} className="w-full h-auto rounded" />
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="research">
            <MarketResearch
              coinName={editedCoin.name}
              ticker={editedCoin.ticker}
              theme={editedCoin.theme}
              onResearchComplete={(insights: string, trendScore?: number) => {
                updateField('researchNotes', insights);
                if (trendScore) updateField('trendScore', BigInt(trendScore));
                setHasChanges(true);
              }}
            />
            {editedCoin.researchNotes && (
              <Card className="bg-gray-900 border-gray-800 mt-4">
                <CardHeader>
                  <CardTitle>Saved Research</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-300 whitespace-pre-wrap">{editedCoin.researchNotes}</p>
                  {editedCoin.trendScore && (
                    <Badge className="mt-2">Trend Score: {Number(editedCoin.trendScore)}/100</Badge>
                  )}
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="video">
            <VideoGeneration coinName={editedCoin.name} mascotImageUrl={editedCoin.mascotImageUrl} />
          </TabsContent>

          <TabsContent value="analytics">
            <AnalyticsDashboard coin={editedCoin} />
          </TabsContent>

          <TabsContent value="airdrop">
            <AirdropBuilder coinTicker={editedCoin.ticker} />
          </TabsContent>

          <TabsContent value="launch">
            <LaunchScheduler coinName={editedCoin.name} />
          </TabsContent>

          <TabsContent value="tokenomics">
            <TokenomicsCalculator />
          </TabsContent>

          <TabsContent value="quests">
            <QuestSystem />
          </TabsContent>

          <TabsContent value="history">
            <VersionHistory 
              coinId={coin.id}
              currentCoin={editedCoin}
              onRestore={(version) => {
                setEditedCoin({ ...editedCoin, ...version.coin });
                setHasChanges(true);
              }}
            />
          </TabsContent>

          <TabsContent value="related">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>Related References</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="memeIds">Related Meme IDs (comma-separated)</Label>
                  <Input
                    id="memeIds"
                    value={editedCoin.relatedMemeIds}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('relatedMemeIds', e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white font-mono"
                    placeholder="meme1, meme2, meme3"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="campaignIds">Related Campaign IDs (comma-separated)</Label>
                  <Input
                    id="campaignIds"
                    value={editedCoin.relatedCampaignIds}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('relatedCampaignIds', e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white font-mono"
                    placeholder="campaign1, campaign2, campaign3"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="export">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>Export Templates</CardTitle>
              </CardHeader>
              <CardContent>
                <ExportTemplates coin={editedCoin} />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
