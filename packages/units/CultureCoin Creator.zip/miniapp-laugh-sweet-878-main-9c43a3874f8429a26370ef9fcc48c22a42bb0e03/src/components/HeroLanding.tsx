'use client';

import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Sparkles, 
  Zap, 
  Globe, 
  Image, 
  Rocket, 
  TrendingUp,
  Users,
  Target,
  Brain,
  BarChart3
} from 'lucide-react';

interface HeroLandingProps {
  onGetStarted: () => void;
  totalCoins: number;
}

export function HeroLanding({ onGetStarted, totalCoins }: HeroLandingProps) {
  const features = [
    {
      icon: Brain,
      title: 'AI-Powered Generation',
      description: 'Auto-generate lore, memes, messaging & SEO in seconds',
      color: 'text-purple-500'
    },
    {
      icon: Image,
      title: 'Visual Creation',
      description: 'Create mascots with Flux Pro & upload to IPFS',
      color: 'text-pink-500'
    },
    {
      icon: Rocket,
      title: 'One-Click Deploy',
      description: 'Launch tokens on Base with revenue manager support',
      color: 'text-blue-500'
    },
    {
      icon: Globe,
      title: 'Geo Targeting',
      description: 'Auto-localize for US, LATAM, EU & Asia markets',
      color: 'text-green-500'
    },
    {
      icon: TrendingUp,
      title: 'Market Research',
      description: 'Real-time insights & competitor analysis with xAI',
      color: 'text-orange-500'
    },
    {
      icon: Users,
      title: 'Community Tools',
      description: 'Airdrops, quests, analytics & launch scheduling',
      color: 'text-cyan-500'
    }
  ];

  const templates = [
    { emoji: '🐌', name: 'DreamSnail', ticker: 'SNAIL', theme: 'Cozy chaos explorer', archetype: 'trickster' },
    { emoji: '⚡', name: 'Jaggy Signal', ticker: 'JAGGY', theme: 'Guardian of Base', archetype: 'guardian' },
    { emoji: '🌊', name: 'WaveRider', ticker: 'WAVE', theme: 'Flow state oracle', archetype: 'oracle' },
    { emoji: '🔥', name: 'FlamePunk', ticker: 'PUNK', theme: 'Rebel energy', archetype: 'rebel' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white">
      <div className="max-w-7xl mx-auto px-8 py-12">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-3 mb-6">
            <Sparkles className="w-12 h-12 text-blue-500 animate-pulse" />
            <h1 className="text-6xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500">
              CultureCoin Foundry
            </h1>
          </div>
          <p className="text-2xl text-gray-400 mb-4">
            The Ultimate Culture Coin Launchpad
          </p>
          <p className="text-lg text-gray-500 max-w-2xl mx-auto mb-8">
            Design, generate, and launch iconic culture coins on Base. 
            From narrative to deployment—all in one platform.
          </p>
          
          {/* CTA Buttons */}
          <div className="flex items-center justify-center gap-4 mb-8">
            <Button 
              onClick={onGetStarted} 
              size="lg" 
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-lg px-8 py-6"
            >
              <Zap className="w-5 h-5 mr-2" />
              Create Your First Coin
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="border-gray-600 hover:border-blue-500 text-lg px-8 py-6"
            >
              <BarChart3 className="w-5 h-5 mr-2" />
              View Examples
            </Button>
          </div>

          {/* Stats */}
          {totalCoins > 0 && (
            <div className="flex items-center justify-center gap-8 text-sm text-gray-500">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span>{totalCoins} Culture Coins Created</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
                <span>Base Network</span>
              </div>
            </div>
          )}
        </div>

        {/* Features Grid */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8 flex items-center justify-center gap-2">
            <Target className="w-8 h-8 text-blue-500" />
            Everything You Need to Launch
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card 
                key={index}
                className="bg-gray-900/50 border-gray-800 hover:border-blue-500/50 transition-all backdrop-blur-sm"
              >
                <CardContent className="pt-6">
                  <feature.icon className={`w-10 h-10 ${feature.color} mb-4`} />
                  <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
                  <p className="text-gray-400 text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Template Examples */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8 flex items-center justify-center gap-2">
            <Sparkles className="w-8 h-8 text-purple-500" />
            Get Inspired
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {templates.map((template, index) => (
              <Card 
                key={index}
                className="bg-gradient-to-br from-gray-900 to-gray-800 border-gray-700 hover:border-blue-500 transition-all cursor-pointer group"
              >
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-5xl mb-3 group-hover:scale-110 transition-transform">
                      {template.emoji}
                    </div>
                    <h3 className="text-xl font-bold mb-1">{template.name}</h3>
                    <p className="text-blue-400 font-mono text-sm mb-3">${template.ticker}</p>
                    <Badge variant="secondary" className="text-xs mb-2">
                      {template.archetype}
                    </Badge>
                    <p className="text-xs text-gray-500">{template.theme}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-6">
            <Button 
              onClick={onGetStarted}
              variant="ghost" 
              className="text-blue-400 hover:text-blue-300"
            >
              Create your own unique culture coin →
            </Button>
          </div>
        </div>

        {/* How It Works */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">
            Launch in 3 Steps
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                1
              </div>
              <h3 className="text-xl font-bold mb-2">Design</h3>
              <p className="text-gray-400 text-sm">
                Enter name, ticker & vibe. AI generates lore, memes, messaging & SEO.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                2
              </div>
              <h3 className="text-xl font-bold mb-2">Generate</h3>
              <p className="text-gray-400 text-sm">
                Create mascot with AI, upload to IPFS, research market & discover memes.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-pink-600 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                3
              </div>
              <h3 className="text-xl font-bold mb-2">Launch</h3>
              <p className="text-gray-400 text-sm">
                Deploy on Base, set up airdrops, schedule posts & track analytics.
              </p>
            </div>
          </div>
        </div>

        {/* Final CTA */}
        <Card className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 border-blue-500/50">
          <CardContent className="py-12 text-center">
            <h2 className="text-3xl font-bold mb-4">
              Ready to Build the Next Iconic Culture Coin?
            </h2>
            <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
              Join the movement of creators building culture on Base. 
              No coding required. Just vibes, creativity, and one click.
            </p>
            <Button 
              onClick={onGetStarted}
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-lg px-12 py-6"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Start Building Now
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
