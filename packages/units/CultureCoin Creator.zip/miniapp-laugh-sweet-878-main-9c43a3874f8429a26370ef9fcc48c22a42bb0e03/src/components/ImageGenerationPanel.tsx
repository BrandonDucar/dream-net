'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Sparkles, Image as ImageIcon, Upload, ExternalLink } from 'lucide-react';
import { fluxproSubmit, fluxproPollStatus, fluxproFetchImages, type FluxProImageFile } from '../fluxpro-api';
import { pinataUploadImageWithMetadata, type PinataImageWithMetadataResult } from '../pinata-media-api';

interface ImageGenerationPanelProps {
  coinName: string;
  ticker: string;
  theme: string;
  onImageGenerated: (imageUrl: string, ipfsUrl?: string) => void;
}

export function ImageGenerationPanel({ coinName, ticker, theme, onImageGenerated }: ImageGenerationPanelProps) {
  const [customPrompt, setCustomPrompt] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generatedImages, setGeneratedImages] = useState<FluxProImageFile[]>([]);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [ipfsResult, setIpfsResult] = useState<PinataImageWithMetadataResult | null>(null);

  const defaultPrompt = `Create a vibrant, memorable mascot character for ${coinName} ($${ticker}), a culture coin on Base blockchain. Theme: ${theme}. Style: modern crypto art, bold colors, friendly and approachable, suitable for social media and NFTs. High quality, 4k, digital art.`;

  const handleGenerate = async () => {
    setIsGenerating(true);
    setGeneratedImages([]);
    setSelectedImage(null);
    setIpfsResult(null);

    try {
      const prompt = customPrompt.trim() || defaultPrompt;
      const requestId = await fluxproSubmit({
        prompt,
        num_images: 2,
        aspect_ratio: '1:1',
        output_format: 'png',
        safety_tolerance: '3',
      });

      await fluxproPollStatus(requestId);
      const images = await fluxproFetchImages(requestId);
      setGeneratedImages(images);
      if (images.length > 0) {
        setSelectedImage(images[0].url);
      }
    } catch (error) {
      console.error('Image generation failed:', error);
      alert('Failed to generate image. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleUploadToIPFS = async () => {
    if (!selectedImage) return;

    setIsUploading(true);
    try {
      const result = await pinataUploadImageWithMetadata({
        image: selectedImage,
        filename: `${ticker.toLowerCase()}-mascot.png`,
        metadata: {
          name: `${coinName} Mascot`,
          description: `Official mascot image for ${coinName} ($${ticker}) culture coin`,
          attributes: [
            { trait_type: 'Type', value: 'Mascot' },
            { trait_type: 'Ticker', value: ticker },
            { trait_type: 'Theme', value: theme },
            { trait_type: 'Chain', value: 'Base' },
          ],
        },
      });

      setIpfsResult(result);
      onImageGenerated(selectedImage, result.metadata.pin.ipfsUri);
    } catch (error) {
      console.error('IPFS upload failed:', error);
      alert('Failed to upload to IPFS. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-blue-500" />
            AI Mascot Generation
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="prompt">Custom Prompt (optional)</Label>
            <Textarea
              id="prompt"
              placeholder={defaultPrompt}
              value={customPrompt}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setCustomPrompt(e.target.value)}
              className="bg-gray-800 border-gray-700 text-white min-h-[100px]"
            />
            <p className="text-xs text-gray-500">
              Leave empty to use auto-generated prompt based on coin details
            </p>
          </div>

          <Button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="w-full bg-blue-600 hover:bg-blue-700"
            size="lg"
          >
            {isGenerating ? (
              <>
                <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <ImageIcon className="w-4 h-4 mr-2" />
                Generate Mascot Images
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {generatedImages.length > 0 && (
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle>Generated Images</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              {generatedImages.map((img: FluxProImageFile, idx: number) => (
                <div
                  key={idx}
                  className={`relative cursor-pointer rounded-lg overflow-hidden border-2 transition-all ${
                    selectedImage === img.url ? 'border-blue-500' : 'border-gray-700 hover:border-gray-600'
                  }`}
                  onClick={() => setSelectedImage(img.url)}
                >
                  <img src={img.url} alt={`Generated ${idx + 1}`} className="w-full h-auto" />
                  {selectedImage === img.url && (
                    <div className="absolute top-2 right-2">
                      <Badge className="bg-blue-600">Selected</Badge>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {selectedImage && !ipfsResult && (
              <Button
                onClick={handleUploadToIPFS}
                disabled={isUploading}
                className="w-full bg-purple-600 hover:bg-purple-700"
                size="lg"
              >
                {isUploading ? (
                  <>
                    <Upload className="w-4 h-4 mr-2 animate-spin" />
                    Uploading to IPFS...
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4 mr-2" />
                    Upload to IPFS & Use This Image
                  </>
                )}
              </Button>
            )}

            {ipfsResult && (
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="pt-4 space-y-2">
                  <p className="text-sm font-semibold text-green-400">✓ Uploaded to IPFS Successfully!</p>
                  <div className="space-y-1 text-xs">
                    <div>
                      <span className="text-gray-400">Gateway URL:</span>
                      <a
                        href={ipfsResult.image.pin.gatewayUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="ml-2 text-blue-400 hover:underline inline-flex items-center gap-1"
                      >
                        View Image <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                    <div>
                      <span className="text-gray-400">IPFS URI:</span>
                      <code className="ml-2 text-purple-400">{ipfsResult.metadata.pin.ipfsUri}</code>
                    </div>
                    <div>
                      <span className="text-gray-400">Metadata:</span>
                      <a
                        href={ipfsResult.metadata.pin.gatewayUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="ml-2 text-blue-400 hover:underline inline-flex items-center gap-1"
                      >
                        View JSON <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
