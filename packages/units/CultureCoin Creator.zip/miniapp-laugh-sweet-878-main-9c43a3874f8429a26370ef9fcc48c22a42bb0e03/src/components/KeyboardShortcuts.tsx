'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { X, Command, Search, Plus, Keyboard } from 'lucide-react'

interface Shortcut {
  keys: string[]
  description: string
  action: string
}

const shortcuts: Shortcut[] = [
  { keys: ['⌘', 'K'], description: 'Quick search', action: 'search' },
  { keys: ['⌘', 'N'], description: 'Create new coin', action: 'create' },
  { keys: ['⌘', 'S'], description: 'Save current coin', action: 'save' },
  { keys: ['⌘', '/'], description: 'Show shortcuts', action: 'shortcuts' },
  { keys: ['ESC'], description: 'Close dialog', action: 'close' },
  { keys: ['⌘', '1-9'], description: 'Switch tabs', action: 'tab' },
  { keys: ['⌘', 'E'], description: 'Export launch brief', action: 'export' },
  { keys: ['⌘', 'G'], description: 'Generate content', action: 'generate' },
]

interface KeyboardShortcutsProps {
  onAction: (action: string) => void
}

export function KeyboardShortcuts({ onAction }: KeyboardShortcutsProps) {
  const [isOpen, setIsOpen] = useState(false)

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isMac = typeof window !== 'undefined' && navigator.platform.toUpperCase().indexOf('MAC') >= 0
      const modKey = isMac ? e.metaKey : e.ctrlKey

      // Command/Ctrl + K - Search
      if (modKey && e.key === 'k') {
        e.preventDefault()
        onAction('search')
      }

      // Command/Ctrl + N - New coin
      if (modKey && e.key === 'n') {
        e.preventDefault()
        onAction('create')
      }

      // Command/Ctrl + S - Save
      if (modKey && e.key === 's') {
        e.preventDefault()
        onAction('save')
      }

      // Command/Ctrl + / - Show shortcuts
      if (modKey && e.key === '/') {
        e.preventDefault()
        setIsOpen(!isOpen)
      }

      // Command/Ctrl + E - Export
      if (modKey && e.key === 'e') {
        e.preventDefault()
        onAction('export')
      }

      // Command/Ctrl + G - Generate
      if (modKey && e.key === 'g') {
        e.preventDefault()
        onAction('generate')
      }

      // Command/Ctrl + 1-9 - Switch tabs
      if (modKey && e.key >= '1' && e.key <= '9') {
        e.preventDefault()
        onAction(`tab-${e.key}`)
      }

      // ESC - Close
      if (e.key === 'Escape') {
        onAction('close')
        setIsOpen(false)
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [onAction, isOpen])

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 bg-gradient-to-r from-blue-500 to-purple-500 text-white p-3 rounded-full shadow-lg hover:shadow-xl transition-all z-40 group"
        title="Keyboard shortcuts (⌘/)"
      >
        <Keyboard className="w-5 h-5 group-hover:scale-110 transition-transform" />
      </button>
    )
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <Card className="w-full max-w-2xl bg-gradient-to-br from-gray-900 to-black border-purple-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl flex items-center gap-2">
              <Command className="w-6 h-6 text-purple-400" />
              Keyboard Shortcuts
            </CardTitle>
            <button
              onClick={() => setIsOpen(false)}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {shortcuts.map((shortcut, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg hover:bg-gray-800 transition-colors"
              >
                <span className="text-gray-300">{shortcut.description}</span>
                <div className="flex gap-1">
                  {shortcut.keys.map((key, keyIndex) => (
                    <kbd
                      key={keyIndex}
                      className="px-3 py-1 bg-gray-900 border border-gray-700 rounded text-sm font-mono text-purple-400"
                    >
                      {key}
                    </kbd>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 p-4 bg-blue-950/30 border border-blue-500/20 rounded-lg">
            <p className="text-sm text-gray-400 text-center">
              Press <kbd className="px-2 py-1 bg-gray-800 rounded text-purple-400">⌘ /</kbd> anytime to toggle this menu
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
