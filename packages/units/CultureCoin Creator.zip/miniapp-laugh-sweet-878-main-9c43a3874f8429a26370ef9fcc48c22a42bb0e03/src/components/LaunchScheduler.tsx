'use client'

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Calendar, Clock, Send, CheckCircle2, Circle } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface LaunchSchedulerProps {
  coinName: string;
}

interface Task {
  id: string;
  title: string;
  status: 'pending' | 'inprogress' | 'completed';
  platform?: string;
}

export function LaunchScheduler({ coinName }: LaunchSchedulerProps) {
  const [launchDate, setLaunchDate] = useState<string>('');
  const [launchTime, setLaunchTime] = useState<string>('');
  const [countdown, setCountdown] = useState<string>('');

  const [tasks] = useState<Task[]>([
    { id: '1', title: 'Generate mascot image', status: 'completed' },
    { id: '2', title: 'Upload to IPFS', status: 'completed' },
    { id: '3', title: 'Deploy token contract', status: 'inprogress', platform: 'Base' },
    { id: '4', title: 'Post announcement on X', status: 'pending', platform: 'X' },
    { id: '5', title: 'Share on Farcaster', status: 'pending', platform: 'Farcaster' },
    { id: '6', title: 'Create Zora mint', status: 'pending', platform: 'Zora' },
  ]);

  const handleSchedule = (): void => {
    console.log('Scheduling launch for', launchDate, launchTime);
  };

  return (
    <div className="space-y-4">
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Launch Calendar
          </CardTitle>
          <CardDescription>Schedule your culture coin launch</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label>Launch Date</Label>
              <Input
                type="date"
                value={launchDate}
                onChange={(e) => setLaunchDate(e.target.value)}
              />
            </div>
            <div>
              <Label>Launch Time (UTC)</Label>
              <Input
                type="time"
                value={launchTime}
                onChange={(e) => setLaunchTime(e.target.value)}
              />
            </div>
          </div>

          {countdown && (
            <div className="p-4 rounded-lg bg-blue-500/10 border border-blue-500/20 text-center">
              <p className="text-sm text-gray-400 mb-1">Launching in</p>
              <p className="text-3xl font-bold text-blue-500">{countdown}</p>
            </div>
          )}

          <Button onClick={handleSchedule} className="w-full">
            <Clock className="w-4 h-4 mr-2" />
            Schedule Launch
          </Button>
        </CardContent>
      </Card>

      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle>Launch Checklist</CardTitle>
          <CardDescription>Track your pre-launch tasks</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {tasks.map((task) => (
            <div
              key={task.id}
              className="flex items-center justify-between p-3 rounded-lg bg-gray-800"
            >
              <div className="flex items-center gap-3">
                {task.status === 'completed' ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                ) : task.status === 'inprogress' ? (
                  <Clock className="w-5 h-5 text-yellow-500 animate-pulse" />
                ) : (
                  <Circle className="w-5 h-5 text-gray-600" />
                )}
                <div>
                  <p className="text-sm font-medium">{task.title}</p>
                  {task.platform && (
                    <p className="text-xs text-gray-400">{task.platform}</p>
                  )}
                </div>
              </div>
              <Badge
                variant={
                  task.status === 'completed'
                    ? 'default'
                    : task.status === 'inprogress'
                    ? 'outline'
                    : 'secondary'
                }
              >
                {task.status === 'completed' ? 'Done' : task.status === 'inprogress' ? 'In Progress' : 'Pending'}
              </Badge>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Send className="w-5 h-5" />
            Multi-Platform Posting
          </CardTitle>
          <CardDescription>Schedule posts across all platforms</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-2">
            <Label>Platform</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Select platform" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="x">X (Twitter)</SelectItem>
                <SelectItem value="farcaster">Farcaster</SelectItem>
                <SelectItem value="discord">Discord</SelectItem>
                <SelectItem value="telegram">Telegram</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button variant="outline" className="w-full">
            Schedule Post
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
