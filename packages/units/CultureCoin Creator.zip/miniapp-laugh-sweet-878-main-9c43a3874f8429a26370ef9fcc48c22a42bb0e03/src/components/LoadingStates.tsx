'use client'

import { Loader2, Sparkles, Zap, Rocket } from 'lucide-react'

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg'
  className?: string
}

export function LoadingSpinner({ size = 'md', className = '' }: LoadingSpinnerProps) {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8'
  }

  return (
    <Loader2 className={`animate-spin ${sizeClasses[size]} ${className}`} />
  )
}

interface LoadingCardProps {
  message?: string
  submessage?: string
}

export function LoadingCard({ message = 'Loading...', submessage }: LoadingCardProps) {
  return (
    <div className="flex flex-col items-center justify-center p-12 space-y-4">
      <div className="relative">
        <Sparkles className="w-12 h-12 text-purple-400 animate-pulse" />
        <Zap className="w-6 h-6 text-blue-400 absolute -top-2 -right-2 animate-bounce" />
      </div>
      <div className="text-center">
        <p className="text-xl font-semibold text-white">{message}</p>
        {submessage && (
          <p className="text-sm text-gray-400 mt-2">{submessage}</p>
        )}
      </div>
      <div className="flex gap-2">
        <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
        <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
        <div className="w-2 h-2 bg-pink-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
      </div>
    </div>
  )
}

interface GeneratingOverlayProps {
  message: string
  stage?: string
}

export function GeneratingOverlay({ message, stage }: GeneratingOverlayProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md">
      <div className="bg-gradient-to-br from-gray-900 to-black border border-purple-500/20 rounded-2xl p-12 max-w-md mx-4 text-center">
        <div className="relative mb-6">
          <Sparkles className="w-16 h-16 text-purple-400 animate-spin mx-auto" />
          <Rocket className="w-8 h-8 text-blue-400 absolute top-0 right-1/4 animate-bounce" />
        </div>
        <h3 className="text-2xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
          {message}
        </h3>
        {stage && (
          <p className="text-gray-400 text-sm mb-6">{stage}</p>
        )}
        <div className="flex justify-center gap-2">
          <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse" style={{ animationDelay: '0ms' }} />
          <div className="w-3 h-3 bg-purple-500 rounded-full animate-pulse" style={{ animationDelay: '200ms' }} />
          <div className="w-3 h-3 bg-pink-500 rounded-full animate-pulse" style={{ animationDelay: '400ms' }} />
        </div>
      </div>
    </div>
  )
}

interface SkeletonProps {
  className?: string
}

export function Skeleton({ className = '' }: SkeletonProps) {
  return (
    <div className={`bg-gray-800 animate-pulse rounded ${className}`} />
  )
}

export function CoinCardSkeleton() {
  return (
    <div className="bg-gradient-to-br from-gray-900 to-black border border-gray-800 rounded-xl p-6 space-y-4">
      <div className="flex items-start justify-between">
        <div className="space-y-2 flex-1">
          <Skeleton className="h-6 w-3/4" />
          <Skeleton className="h-4 w-1/2" />
        </div>
        <Skeleton className="h-12 w-12 rounded-full" />
      </div>
      <Skeleton className="h-4 w-full" />
      <div className="flex justify-between items-center">
        <Skeleton className="h-6 w-20" />
        <Skeleton className="h-8 w-24 rounded-full" />
      </div>
    </div>
  )
}
