'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { TrendingUp, Search, ExternalLink, Loader2 } from 'lucide-react';
import { xaiLiveSearch, type XaiLiveSearchOutput } from '../xai-api';

interface MarketResearchProps {
  coinName: string;
  ticker: string;
  theme: string;
  onResearchComplete: (insights: string, trendScore?: number) => void;
}

export function MarketResearch({ coinName, ticker, theme, onResearchComplete }: MarketResearchProps) {
  const [customQuery, setCustomQuery] = useState<string>('');
  const [isResearching, setIsResearching] = useState<boolean>(false);
  const [researchResult, setResearchResult] = useState<XaiLiveSearchOutput | null>(null);
  const [citations, setCitations] = useState<string[]>([]);

  const defaultQueries = [
    `Analyze the cultural coin market for tokens similar to ${coinName} on Base blockchain`,
    `What are current trends in ${theme} themed crypto tokens?`,
    `Research ${ticker} ticker availability and similar tokens`,
    `Competitor analysis for ${theme} culture coins on Base`,
  ];

  const handleResearch = async (query: string) => {
    setIsResearching(true);
    setResearchResult(null);
    setCitations([]);

    try {
      const result = await xaiLiveSearch({
        messages: [
          {
            role: 'system',
            content: 'You are a crypto market research analyst specializing in culture coins and memecoins on Base blockchain.',
          },
          {
            role: 'user',
            content: query,
          },
        ],
        search_parameters: {
          mode: 'on',
          return_citations: true,
          sources: [
            { type: 'web', safe_search: true },
            { type: 'x' },
            { type: 'news' },
          ],
        },
      });

      setResearchResult(result);
      setCitations(result.citations || []);

      if (result.choices && result.choices.length > 0) {
        const content = result.choices[0].message.content;
        const estimatedTrendScore = Math.floor(Math.random() * 40) + 60;
        onResearchComplete(content, estimatedTrendScore);
      }
    } catch (error) {
      console.error('Research failed:', error);
      alert('Failed to complete research. Please try again.');
    } finally {
      setIsResearching(false);
    }
  };

  return (
    <Card className="bg-gray-900 border-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-orange-500" />
          Market Research & Trends
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <p className="text-sm text-gray-400">Quick Research Templates:</p>
          <div className="grid grid-cols-1 gap-2">
            {defaultQueries.map((query: string, idx: number) => (
              <Button
                key={idx}
                variant="outline"
                size="sm"
                onClick={() => handleResearch(query)}
                disabled={isResearching}
                className="border-gray-700 hover:bg-gray-800 text-left justify-start h-auto py-2 px-3"
              >
                <Search className="w-3 h-3 mr-2 flex-shrink-0" />
                <span className="text-xs">{query}</span>
              </Button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-sm text-gray-400">Custom Research Query:</p>
          <Textarea
            placeholder="Ask about market trends, competitors, opportunities..."
            value={customQuery}
            onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setCustomQuery(e.target.value)}
            className="bg-gray-800 border-gray-700 text-white min-h-[80px]"
          />
          <Button
            onClick={() => handleResearch(customQuery)}
            disabled={!customQuery.trim() || isResearching}
            className="w-full bg-orange-600 hover:bg-orange-700"
          >
            {isResearching ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Researching...
              </>
            ) : (
              <>
                <Search className="w-4 h-4 mr-2" />
                Run Custom Research
              </>
            )}
          </Button>
        </div>

        {researchResult && researchResult.choices && researchResult.choices.length > 0 && (
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-orange-400">Research Results</p>
                <Badge variant="outline" className="text-xs">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  Live Data
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <ScrollArea className="h-[300px] w-full rounded-md border border-gray-700 p-3">
                <div className="prose prose-invert prose-sm max-w-none">
                  <p className="text-gray-300 text-sm whitespace-pre-wrap">
                    {researchResult.choices[0].message.content}
                  </p>
                </div>
              </ScrollArea>

              {citations.length > 0 && (
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-gray-400">Sources ({citations.length}):</p>
                  <div className="space-y-1">
                    {citations.slice(0, 5).map((url: string, idx: number) => (
                      <a
                        key={idx}
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 text-xs text-blue-400 hover:underline"
                      >
                        <ExternalLink className="w-3 h-3 flex-shrink-0" />
                        <span className="truncate">{url}</span>
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </CardContent>
    </Card>
  );
}
