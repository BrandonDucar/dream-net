'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Search, Film, Plus, Sparkles } from 'lucide-react';
import { tenorSearchMemes, tenorFeaturedMemes, tenorMemeCategories, type TenorMeme, type TenorMemeCategory } from '../tenor-api';

interface MemeDiscoveryProps {
  onMemeSelected: (memeUrl: string) => void;
}

export function MemeDiscovery({ onMemeSelected }: MemeDiscoveryProps) {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [memes, setMemes] = useState<TenorMeme[]>([]);
  const [categories, setCategories] = useState<TenorMemeCategory[]>([]);
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [selectedMemes, setSelectedMemes] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'search' | 'trending' | 'categories'>('trending');

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    try {
      const result = await tenorSearchMemes({
        q: searchQuery,
        limit: 20,
        contentfilter: 'medium',
      });
      setMemes(result.results || []);
      setActiveTab('search');
    } catch (error) {
      console.error('Meme search failed:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const loadTrending = async () => {
    setIsSearching(true);
    try {
      const result = await tenorFeaturedMemes({ limit: 20 });
      setMemes(result.results || []);
      setActiveTab('trending');
    } catch (error) {
      console.error('Failed to load trending memes:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const loadCategories = async () => {
    setIsSearching(true);
    try {
      const result = await tenorMemeCategories({ type: 'featured' });
      setCategories(result.tags || []);
      setActiveTab('categories');
    } catch (error) {
      console.error('Failed to load categories:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const toggleMemeSelection = (url: string) => {
    setSelectedMemes((prev: string[]) => {
      if (prev.includes(url)) {
        return prev.filter((u: string) => u !== url);
      } else {
        return [...prev, url];
      }
    });
  };

  const handleSaveSelection = () => {
    selectedMemes.forEach((url: string) => onMemeSelected(url));
    setSelectedMemes([]);
  };

  const getMemePreviewUrl = (meme: TenorMeme): string => {
    return meme.media_formats?.nanogif?.url || meme.media_formats?.tinygif?.url || meme.media_formats?.gif?.url || '';
  };

  return (
    <Card className="bg-gray-900 border-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Film className="w-5 h-5 text-purple-500" />
          Meme Discovery & Library
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search memes... (e.g., 'success kid', 'distracted boyfriend')"
              value={searchQuery}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
              onKeyPress={(e: React.KeyboardEvent) => e.key === 'Enter' && handleSearch()}
              className="pl-10 bg-gray-800 border-gray-700 text-white"
            />
          </div>
          <Button onClick={handleSearch} disabled={isSearching} className="bg-purple-600 hover:bg-purple-700">
            Search
          </Button>
        </div>

        <div className="flex gap-2">
          <Button
            variant={activeTab === 'trending' ? 'default' : 'outline'}
            onClick={loadTrending}
            size="sm"
            className={activeTab === 'trending' ? 'bg-purple-600' : 'border-gray-700'}
          >
            <Sparkles className="w-4 h-4 mr-1" />
            Trending
          </Button>
          <Button
            variant={activeTab === 'categories' ? 'default' : 'outline'}
            onClick={loadCategories}
            size="sm"
            className={activeTab === 'categories' ? 'bg-purple-600' : 'border-gray-700'}
          >
            Categories
          </Button>
        </div>

        {activeTab === 'categories' && categories.length > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {categories.map((cat: TenorMemeCategory) => (
              <Button
                key={cat.searchterm}
                variant="outline"
                size="sm"
                onClick={() => {
                  setSearchQuery(cat.searchterm);
                  handleSearch();
                }}
                className="border-gray-700 hover:bg-gray-800"
              >
                {cat.name}
              </Button>
            ))}
          </div>
        )}

        {memes.length > 0 && activeTab !== 'categories' && (
          <>
            <ScrollArea className="h-[400px] w-full rounded-md border border-gray-800">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 p-2">
                {memes.map((meme: TenorMeme) => {
                  const previewUrl = getMemePreviewUrl(meme);
                  if (!previewUrl) return null;

                  const isSelected = selectedMemes.includes(previewUrl);

                  return (
                    <div
                      key={meme.id}
                      className={`relative cursor-pointer rounded overflow-hidden border-2 transition-all ${
                        isSelected ? 'border-purple-500' : 'border-gray-700 hover:border-gray-600'
                      }`}
                      onClick={() => toggleMemeSelection(previewUrl)}
                    >
                      <img src={previewUrl} alt={meme.content_description} className="w-full h-auto" />
                      {isSelected && (
                        <div className="absolute top-1 right-1">
                          <Badge className="bg-purple-600">
                            <Plus className="w-3 h-3" />
                          </Badge>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </ScrollArea>

            {selectedMemes.length > 0 && (
              <div className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                <span className="text-sm text-gray-300">{selectedMemes.length} meme(s) selected</span>
                <Button onClick={handleSaveSelection} size="sm" className="bg-green-600 hover:bg-green-700">
                  Add to CultureCoin
                </Button>
              </div>
            )}
          </>
        )}

        {memes.length === 0 && activeTab !== 'categories' && !isSearching && (
          <div className="text-center py-8 text-gray-500">
            <Film className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>Search or browse trending memes</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
