'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { X, ArrowRight, ArrowLeft, Sparkles, Rocket, Zap } from 'lucide-react'

interface OnboardingStep {
  title: string
  description: string
  icon: React.ReactNode
  highlight?: string
}

const steps: OnboardingStep[] = [
  {
    title: "Welcome to CultureCoin Foundry! 🎨",
    description: "The ultimate platform for designing, deploying, and launching culture coins on Base. Let's take a quick tour!",
    icon: <Sparkles className="w-12 h-12 text-purple-400" />,
    highlight: "Welcome"
  },
  {
    title: "Create Your Culture Coin",
    description: "Enter a name, ticker, and vibe. Our AI generates complete lore, messaging, memes, and SEO - everything you need for launch.",
    icon: <Zap className="w-12 h-12 text-blue-400" />,
    highlight: "Create"
  },
  {
    title: "Generate AI Visuals",
    description: "Use Flux Pro to create professional mascot images. Upload to IPFS for NFT-ready metadata. Generate launch videos.",
    icon: <Sparkles className="w-12 h-12 text-pink-400" />,
    highlight: "Generate"
  },
  {
    title: "Deploy & Launch",
    description: "Deploy tokens on Base with Flaunch. Set up airdrops. Schedule launches. Track analytics. Build quests for your community.",
    icon: <Rocket className="w-12 h-12 text-green-400" />,
    highlight: "Launch"
  },
  {
    title: "Export & Share",
    description: "Export comprehensive launch briefs ready for X, Farcaster, Zora, and more. Everything in one place.",
    icon: <Zap className="w-12 h-12 text-yellow-400" />,
    highlight: "Share"
  }
]

export function OnboardingTutorial() {
  const [isOpen, setIsOpen] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)

  useEffect(() => {
    // Check if user has seen onboarding
    const hasSeenOnboarding = localStorage.getItem('hasSeenOnboarding')
    if (!hasSeenOnboarding) {
      setIsOpen(true)
    }
  }, [])

  const handleClose = () => {
    localStorage.setItem('hasSeenOnboarding', 'true')
    setIsOpen(false)
  }

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      handleClose()
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleSkip = () => {
    handleClose()
  }

  if (!isOpen) return null

  const step = steps[currentStep]

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <Card className="w-full max-w-2xl bg-gradient-to-br from-gray-900 to-black border-purple-500/20">
        <CardContent className="p-8 relative">
          {/* Close button */}
          <button
            onClick={handleSkip}
            className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Progress dots */}
          <div className="flex justify-center gap-2 mb-8">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`h-2 rounded-full transition-all ${
                  index === currentStep
                    ? 'w-8 bg-gradient-to-r from-blue-500 to-purple-500'
                    : 'w-2 bg-gray-600'
                }`}
              />
            ))}
          </div>

          {/* Icon */}
          <div className="flex justify-center mb-6 animate-bounce">
            {step.icon}
          </div>

          {/* Content */}
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-4 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              {step.title}
            </h2>
            <p className="text-gray-300 text-lg leading-relaxed">
              {step.description}
            </p>
          </div>

          {/* Step counter */}
          <div className="text-center mb-6">
            <span className="text-sm text-gray-500">
              Step {currentStep + 1} of {steps.length}
            </span>
          </div>

          {/* Navigation buttons */}
          <div className="flex justify-between items-center">
            <Button
              onClick={handlePrevious}
              disabled={currentStep === 0}
              variant="outline"
              className="border-gray-700 hover:bg-gray-800"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Previous
            </Button>

            <Button
              onClick={handleSkip}
              variant="ghost"
              className="text-gray-400 hover:text-white"
            >
              Skip Tutorial
            </Button>

            <Button
              onClick={handleNext}
              className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
            >
              {currentStep === steps.length - 1 ? (
                <>
                  Get Started
                  <Rocket className="w-4 h-4 ml-2" />
                </>
              ) : (
                <>
                  Next
                  <ArrowRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
