'use client'

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Trophy, Star, Target, Gift, CheckCircle2, Lock } from 'lucide-react';

interface Quest {
  id: string;
  title: string;
  description: string;
  reward: string;
  progress: number;
  maxProgress: number;
  completed: boolean;
  locked: boolean;
}

export function QuestSystem() {
  const [quests] = useState<Quest[]>([
    {
      id: '1',
      title: 'Share on X',
      description: 'Post about the culture coin on X',
      reward: '100 tokens',
      progress: 1,
      maxProgress: 1,
      completed: true,
      locked: false,
    },
    {
      id: '2',
      title: 'Join Discord',
      description: 'Join the community Discord server',
      reward: '50 tokens',
      progress: 0,
      maxProgress: 1,
      completed: false,
      locked: false,
    },
    {
      id: '3',
      title: 'Refer 3 Friends',
      description: 'Invite friends to join the community',
      reward: '300 tokens + NFT',
      progress: 1,
      maxProgress: 3,
      completed: false,
      locked: false,
    },
    {
      id: '4',
      title: 'Hold for 7 Days',
      description: 'Hold tokens for at least 7 days',
      reward: '500 tokens',
      progress: 2,
      maxProgress: 7,
      completed: false,
      locked: false,
    },
    {
      id: '5',
      title: 'Provide Liquidity',
      description: 'Add liquidity to the pool',
      reward: '1000 tokens + LP rewards',
      progress: 0,
      maxProgress: 1,
      completed: false,
      locked: true,
    },
  ]);

  const [achievements] = useState([
    { id: '1', name: 'Early Adopter', icon: '🌱', earned: true },
    { id: '2', name: 'Community Builder', icon: '🏗️', earned: true },
    { id: '3', name: 'Whale Hunter', icon: '🐋', earned: false },
    { id: '4', name: 'Diamond Hands', icon: '💎', earned: false },
  ]);

  const totalPoints = 650;
  const level = Math.floor(totalPoints / 100) + 1;

  return (
    <div className="space-y-4">
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-500" />
            Your Progress
          </CardTitle>
          <CardDescription>Complete quests to earn rewards</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Level {level}</p>
              <p className="text-2xl font-bold">{totalPoints} Points</p>
            </div>
            <div className="text-right">
              <Badge variant="outline" className="mb-2">
                <Star className="w-3 h-3 mr-1" />
                Rank #42
              </Badge>
              <p className="text-xs text-gray-500">{100 - (totalPoints % 100)} to next level</p>
            </div>
          </div>
          <Progress value={(totalPoints % 100)} className="h-2" />
        </CardContent>
      </Card>

      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5" />
            Active Quests
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {quests.map((quest) => (
            <div
              key={quest.id}
              className={`p-4 rounded-lg border transition-all ${
                quest.completed
                  ? 'bg-green-500/10 border-green-500/20'
                  : quest.locked
                  ? 'bg-gray-800/50 border-gray-700 opacity-50'
                  : 'bg-gray-800 border-gray-700 hover:border-gray-600'
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    {quest.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-green-500" />
                    ) : quest.locked ? (
                      <Lock className="w-5 h-5 text-gray-600" />
                    ) : (
                      <Circle className="w-5 h-5 text-gray-600" />
                    )}
                    <h4 className="font-medium">{quest.title}</h4>
                  </div>
                  <p className="text-sm text-gray-400 ml-7">{quest.description}</p>
                </div>
                <Badge variant={quest.completed ? 'default' : 'outline'}>
                  <Gift className="w-3 h-3 mr-1" />
                  {quest.reward}
                </Badge>
              </div>
              {!quest.locked && !quest.completed && (
                <div className="ml-7 mt-3">
                  <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                    <span>Progress</span>
                    <span>{quest.progress}/{quest.maxProgress}</span>
                  </div>
                  <Progress value={(quest.progress / quest.maxProgress) * 100} className="h-1.5" />
                </div>
              )}
              {quest.completed && (
                <Button size="sm" variant="ghost" className="ml-7 mt-2" disabled>
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Claimed
                </Button>
              )}
              {!quest.completed && !quest.locked && (
                <Button size="sm" className="ml-7 mt-2">
                  Start Quest
                </Button>
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-500" />
            Achievements
          </CardTitle>
          <CardDescription>Unlock badges and special rewards</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {achievements.map((achievement) => (
              <div
                key={achievement.id}
                className={`p-4 rounded-lg border text-center ${
                  achievement.earned
                    ? 'bg-yellow-500/10 border-yellow-500/20'
                    : 'bg-gray-800 border-gray-700 opacity-50'
                }`}
              >
                <div className="text-3xl mb-2">{achievement.icon}</div>
                <p className="text-xs font-medium">{achievement.name}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function Circle(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <circle cx="12" cy="12" r="10" />
    </svg>
  );
}
