'use client'

import { useEffect, useState } from 'react'
import { CheckCircle, X, Sparkles, Rocket, Zap } from 'lucide-react'
import Confetti from 'react-confetti'

interface SuccessNotificationProps {
  message: string
  submessage?: string
  onClose: () => void
  showConfetti?: boolean
  duration?: number
}

export function SuccessNotification({
  message,
  submessage,
  onClose,
  showConfetti = false,
  duration = 5000
}: SuccessNotificationProps) {
  const [isVisible, setIsVisible] = useState(true)
  const [windowSize, setWindowSize] = useState({ width: 0, height: 0 })

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setWindowSize({ width: window.innerWidth, height: window.innerHeight })
    }

    const timer = setTimeout(() => {
      setIsVisible(false)
      setTimeout(onClose, 300)
    }, duration)

    return () => clearTimeout(timer)
  }, [duration, onClose])

  return (
    <>
      {showConfetti && (
        <Confetti
          width={windowSize.width}
          height={windowSize.height}
          recycle={false}
          numberOfPieces={500}
          gravity={0.3}
        />
      )}
      
      <div
        className={`fixed top-4 right-4 z-50 transition-all duration-300 ${
          isVisible ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'
        }`}
      >
        <div className="bg-gradient-to-br from-green-900/90 to-emerald-900/90 backdrop-blur-lg border border-green-500/30 rounded-xl shadow-2xl p-6 max-w-md">
          <div className="flex items-start gap-4">
            {/* Animated success icon */}
            <div className="relative flex-shrink-0">
              <CheckCircle className="w-8 h-8 text-green-400 animate-bounce" />
              <Sparkles className="w-4 h-4 text-yellow-400 absolute -top-1 -right-1 animate-pulse" />
            </div>

            {/* Content */}
            <div className="flex-1">
              <h3 className="text-lg font-bold text-white mb-1 flex items-center gap-2">
                {message}
                {showConfetti && <Rocket className="w-4 h-4 text-yellow-400 animate-bounce" />}
              </h3>
              {submessage && (
                <p className="text-sm text-green-200">{submessage}</p>
              )}
            </div>

            {/* Close button */}
            <button
              onClick={() => {
                setIsVisible(false)
                setTimeout(onClose, 300)
              }}
              className="text-green-300 hover:text-white transition-colors flex-shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Animated progress bar */}
          <div className="mt-4 h-1 bg-green-950 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-green-400 to-emerald-400 animate-progress"
              style={{
                animation: `progress ${duration}ms linear forwards`
              }}
            />
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes progress {
          from {
            width: 100%;
          }
          to {
            width: 0%;
          }
        }
        .animate-progress {
          animation: progress ${duration}ms linear forwards;
        }
      `}</style>
    </>
  )
}

interface ErrorNotificationProps {
  message: string
  submessage?: string
  onClose: () => void
  duration?: number
}

export function ErrorNotification({
  message,
  submessage,
  onClose,
  duration = 5000
}: ErrorNotificationProps) {
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false)
      setTimeout(onClose, 300)
    }, duration)

    return () => clearTimeout(timer)
  }, [duration, onClose])

  return (
    <div
      className={`fixed top-4 right-4 z-50 transition-all duration-300 ${
        isVisible ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'
      }`}
    >
      <div className="bg-gradient-to-br from-red-900/90 to-rose-900/90 backdrop-blur-lg border border-red-500/30 rounded-xl shadow-2xl p-6 max-w-md">
        <div className="flex items-start gap-4">
          {/* Error icon */}
          <div className="relative flex-shrink-0">
            <Zap className="w-8 h-8 text-red-400 animate-pulse" />
          </div>

          {/* Content */}
          <div className="flex-1">
            <h3 className="text-lg font-bold text-white mb-1">
              {message}
            </h3>
            {submessage && (
              <p className="text-sm text-red-200">{submessage}</p>
            )}
          </div>

          {/* Close button */}
          <button
            onClick={() => {
              setIsVisible(false)
              setTimeout(onClose, 300)
            }}
            className="text-red-300 hover:text-white transition-colors flex-shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  )
}
