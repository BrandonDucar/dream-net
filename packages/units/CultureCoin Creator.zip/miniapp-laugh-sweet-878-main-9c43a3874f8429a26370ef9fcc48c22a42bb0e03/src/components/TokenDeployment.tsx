'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Rocket, Wallet, DollarSign, CheckCircle2, XCircle, Loader2, ExternalLink } from 'lucide-react';
import { launchMemecoinSimple, launchMemecoinWithManager, type LaunchResponse } from '../flaunch-api';

interface TokenDeploymentProps {
  coinName: string;
  ticker: string;
  description: string;
  mascotImageUrl?: string;
  onDeploymentComplete: (contractAddress: string, revenueManager?: string) => void;
}

export function TokenDeployment({
  coinName,
  ticker,
  description,
  mascotImageUrl,
  onDeploymentComplete,
}: TokenDeploymentProps) {
  const [deploymentMode, setDeploymentMode] = useState<'simple' | 'revenue'>('simple');
  const [walletAddress, setWalletAddress] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [protocolFee, setProtocolFee] = useState<string>('250');
  const [isDeploying, setIsDeploying] = useState<boolean>(false);
  const [deploymentResult, setDeploymentResult] = useState<LaunchResponse | null>(null);

  const handleDeploy = async () => {
    if (!mascotImageUrl) {
      alert('Please generate and upload a mascot image first!');
      return;
    }

    if (deploymentMode === 'simple' && !walletAddress && !email) {
      alert('Please provide either a wallet address or email!');
      return;
    }

    if (deploymentMode === 'revenue' && !walletAddress) {
      alert('Please provide a wallet address for revenue manager deployment!');
      return;
    }

    setIsDeploying(true);
    setDeploymentResult(null);

    try {
      let result: LaunchResponse;

      if (deploymentMode === 'simple') {
        result = await launchMemecoinSimple({
          name: coinName,
          symbol: ticker,
          description,
          base64Image: mascotImageUrl,
          creator: {
            address: walletAddress || undefined,
            email: email || undefined,
          },
        });
      } else {
        const fee = parseInt(protocolFee, 10);
        if (isNaN(fee) || fee < 0 || fee > 10000) {
          alert('Protocol fee must be between 0 and 10000 (basis points)');
          return;
        }

        result = await launchMemecoinWithManager({
          name: coinName,
          symbol: ticker,
          description,
          base64Image: mascotImageUrl,
          creatorAddress: walletAddress,
          protocolFee: fee,
        });
      }

      setDeploymentResult(result);

      if (result.success && result.tokenAddress) {
        onDeploymentComplete(result.tokenAddress, result.managerAddress);
      }
    } catch (error) {
      console.error('Deployment failed:', error);
      setDeploymentResult({
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
      });
    } finally {
      setIsDeploying(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Rocket className="w-5 h-5 text-green-500" />
            Deploy Token on Base
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!mascotImageUrl && (
            <div className="bg-yellow-900/20 border border-yellow-700 rounded-lg p-4 text-yellow-300 text-sm">
              ⚠️ Generate and upload a mascot image before deploying
            </div>
          )}

          <Tabs value={deploymentMode} onValueChange={(v: string) => setDeploymentMode(v as 'simple' | 'revenue')}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="simple">Simple Launch</TabsTrigger>
              <TabsTrigger value="revenue">With Revenue Manager</TabsTrigger>
            </TabsList>

            <TabsContent value="simple" className="space-y-4 mt-4">
              <p className="text-sm text-gray-400">
                Quick token launch without fee collection. Perfect for pure community tokens.
              </p>

              <div className="space-y-2">
                <Label htmlFor="wallet">Wallet Address (optional)</Label>
                <Input
                  id="wallet"
                  placeholder="0x..."
                  value={walletAddress}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setWalletAddress(e.target.value)}
                  className="bg-gray-800 border-gray-700 text-white font-mono"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email (optional, if no wallet)</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="creator@example.com"
                  value={email}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEmail(e.target.value)}
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>

              <p className="text-xs text-gray-500">
                Provide either wallet address or email. Wallet recommended for full control.
              </p>
            </TabsContent>

            <TabsContent value="revenue" className="space-y-4 mt-4">
              <p className="text-sm text-gray-400">
                Deploy with a revenue manager to collect protocol fees on transactions. Perfect for monetized launches.
              </p>

              <div className="space-y-2">
                <Label htmlFor="revenue-wallet">Wallet Address (required)</Label>
                <Input
                  id="revenue-wallet"
                  placeholder="0x..."
                  value={walletAddress}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setWalletAddress(e.target.value)}
                  className="bg-gray-800 border-gray-700 text-white font-mono"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="protocol-fee">Protocol Fee (basis points, 0-10000)</Label>
                <Input
                  id="protocol-fee"
                  type="number"
                  min="0"
                  max="10000"
                  placeholder="250 = 2.5%"
                  value={protocolFee}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setProtocolFee(e.target.value)}
                  className="bg-gray-800 border-gray-700 text-white"
                />
                <p className="text-xs text-gray-500">
                  250 basis points = 2.5% fee. 10000 = 100%
                </p>
              </div>
            </TabsContent>
          </Tabs>

          <Button
            onClick={handleDeploy}
            disabled={isDeploying || !mascotImageUrl}
            className="w-full bg-green-600 hover:bg-green-700"
            size="lg"
          >
            {isDeploying ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Deploying...
              </>
            ) : (
              <>
                <Rocket className="w-4 h-4 mr-2" />
                Deploy Token on Base
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {deploymentResult && (
        <Card className={`border-2 ${deploymentResult.success ? 'bg-green-900/10 border-green-700' : 'bg-red-900/10 border-red-700'}`}>
          <CardContent className="pt-6 space-y-3">
            <div className="flex items-center gap-2">
              {deploymentResult.success ? (
                <CheckCircle2 className="w-6 h-6 text-green-400" />
              ) : (
                <XCircle className="w-6 h-6 text-red-400" />
              )}
              <h3 className="text-lg font-bold">
                {deploymentResult.success ? 'Deployment Successful!' : 'Deployment Failed'}
              </h3>
            </div>

            {deploymentResult.success && deploymentResult.tokenAddress && (
              <div className="space-y-2 text-sm">
                <div>
                  <span className="text-gray-400">Token Address:</span>
                  <a
                    href={`https://basescan.org/address/${deploymentResult.tokenAddress}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="ml-2 text-blue-400 hover:underline font-mono inline-flex items-center gap-1"
                  >
                    {deploymentResult.tokenAddress} <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                {deploymentResult.managerAddress && (
                  <div>
                    <span className="text-gray-400">Revenue Manager:</span>
                    <a
                      href={`https://basescan.org/address/${deploymentResult.managerAddress}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="ml-2 text-blue-400 hover:underline font-mono inline-flex items-center gap-1"
                    >
                      {deploymentResult.managerAddress} <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                )}
              </div>
            )}

            {!deploymentResult.success && deploymentResult.error && (
              <p className="text-red-300 text-sm">{deploymentResult.error}</p>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
