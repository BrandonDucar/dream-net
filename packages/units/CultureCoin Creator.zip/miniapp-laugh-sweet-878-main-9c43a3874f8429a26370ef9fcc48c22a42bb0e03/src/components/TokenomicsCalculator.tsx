'use client'

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Slider } from './ui/slider';
import { Calculator, PieChart, TrendingUp } from 'lucide-react';

export function TokenomicsCalculator() {
  const [totalSupply, setTotalSupply] = useState<string>('1000000000');
  const [communityAllocation, setCommunityAllocation] = useState<number>(60);
  const [teamAllocation, setTeamAllocation] = useState<number>(20);
  const [treasuryAllocation, setTreasuryAllocation] = useState<number>(15);
  const [lpAllocation, setLpAllocation] = useState<number>(5);
  
  const [initialPrice, setInitialPrice] = useState<string>('0.001');
  const [targetMarketCap, setTargetMarketCap] = useState<string>('1000000');

  const calculateAllocation = (percentage: number): string => {
    const supply = parseFloat(totalSupply);
    if (isNaN(supply)) return '0';
    return ((supply * percentage) / 100).toLocaleString();
  };

  const calculatePotentialPrice = (): string => {
    const supply = parseFloat(totalSupply);
    const marketCap = parseFloat(targetMarketCap);
    if (isNaN(supply) || isNaN(marketCap) || supply === 0) return '0';
    return (marketCap / supply).toFixed(6);
  };

  return (
    <div className="space-y-4">
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="w-5 h-5" />
            Tokenomics Calculator
          </CardTitle>
          <CardDescription>Design your token distribution and economics</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label>Total Supply</Label>
            <Input
              type="number"
              placeholder="1000000000"
              value={totalSupply}
              onChange={(e) => setTotalSupply(e.target.value)}
            />
            <p className="text-xs text-gray-500 mt-1">
              Total number of tokens to be created
            </p>
          </div>

          <div>
            <Label>Initial Price (USD)</Label>
            <Input
              type="number"
              step="0.000001"
              placeholder="0.001"
              value={initialPrice}
              onChange={(e) => setInitialPrice(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PieChart className="w-5 h-5" />
            Token Distribution
          </CardTitle>
          <CardDescription>Allocate tokens across categories</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Community ({communityAllocation}%)</Label>
              <span className="text-sm font-medium">{calculateAllocation(communityAllocation)} tokens</span>
            </div>
            <Slider
              value={[communityAllocation]}
              onValueChange={(val) => setCommunityAllocation(val[0])}
              max={100}
              step={1}
              className="w-full"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Team ({teamAllocation}%)</Label>
              <span className="text-sm font-medium">{calculateAllocation(teamAllocation)} tokens</span>
            </div>
            <Slider
              value={[teamAllocation]}
              onValueChange={(val) => setTeamAllocation(val[0])}
              max={100}
              step={1}
              className="w-full"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Treasury ({treasuryAllocation}%)</Label>
              <span className="text-sm font-medium">{calculateAllocation(treasuryAllocation)} tokens</span>
            </div>
            <Slider
              value={[treasuryAllocation]}
              onValueChange={(val) => setTreasuryAllocation(val[0])}
              max={100}
              step={1}
              className="w-full"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Liquidity Pool ({lpAllocation}%)</Label>
              <span className="text-sm font-medium">{calculateAllocation(lpAllocation)} tokens</span>
            </div>
            <Slider
              value={[lpAllocation]}
              onValueChange={(val) => setLpAllocation(val[0])}
              max={100}
              step={1}
              className="w-full"
            />
          </div>

          <div className="pt-4 border-t border-gray-800">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Total Allocated</span>
              <span className={`font-medium ${communityAllocation + teamAllocation + treasuryAllocation + lpAllocation === 100 ? 'text-green-500' : 'text-red-500'}`}>
                {communityAllocation + teamAllocation + treasuryAllocation + lpAllocation}%
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Price Projections
          </CardTitle>
          <CardDescription>Estimate future valuations</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Target Market Cap (USD)</Label>
            <Input
              type="number"
              placeholder="1000000"
              value={targetMarketCap}
              onChange={(e) => setTargetMarketCap(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-4 pt-4">
            <div className="p-4 rounded-lg bg-gray-800">
              <p className="text-sm text-gray-400 mb-1">Current FDV</p>
              <p className="text-xl font-bold">
                ${(parseFloat(totalSupply) * parseFloat(initialPrice)).toLocaleString()}
              </p>
            </div>
            <div className="p-4 rounded-lg bg-gray-800">
              <p className="text-sm text-gray-400 mb-1">Price at Target MC</p>
              <p className="text-xl font-bold">${calculatePotentialPrice()}</p>
            </div>
          </div>

          <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
            <p className="text-sm text-gray-400 mb-1">Potential ROI</p>
            <p className="text-2xl font-bold text-blue-500">
              {((parseFloat(calculatePotentialPrice()) / parseFloat(initialPrice) - 1) * 100).toFixed(0)}x
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
