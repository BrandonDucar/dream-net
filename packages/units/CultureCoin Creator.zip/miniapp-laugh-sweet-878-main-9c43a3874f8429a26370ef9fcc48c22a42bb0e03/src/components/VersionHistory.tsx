'use client'

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Clock, RotateCcw, GitCompare, ChevronRight } from 'lucide-react';
import type { CultureCoin } from '../spacetime_module_bindings/culture_coin_type';

interface Version {
  id: string;
  timestamp: Date;
  changes: string[];
  coin: Partial<CultureCoin>;
}

interface VersionHistoryProps {
  coinId: bigint;
  currentCoin: CultureCoin;
  onRestore: (version: Version) => void;
}

export function VersionHistory({ coinId, currentCoin, onRestore }: VersionHistoryProps) {
  const [versions] = useState<Version[]>([
    {
      id: '1',
      timestamp: new Date(Date.now() - 86400000),
      changes: ['Created coin', 'Generated initial narrative', 'Added SEO metadata'],
      coin: { name: currentCoin.name, ticker: currentCoin.ticker },
    },
    {
      id: '2',
      timestamp: new Date(Date.now() - 43200000),
      changes: ['Regenerated meme directions', 'Updated visual motifs'],
      coin: { name: currentCoin.name, ticker: currentCoin.ticker },
    },
    {
      id: '3',
      timestamp: new Date(Date.now() - 3600000),
      changes: ['Updated messaging', 'Added geo targeting'],
      coin: { name: currentCoin.name, ticker: currentCoin.ticker },
    },
  ]);

  const [selectedVersion, setSelectedVersion] = useState<string | null>(null);

  return (
    <div className="space-y-4">
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Version History
          </CardTitle>
          <CardDescription>Track and restore previous versions</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {versions.map((version, index) => (
            <div
              key={version.id}
              className={`p-4 rounded-lg border transition-all cursor-pointer ${
                selectedVersion === version.id
                  ? 'border-blue-500 bg-blue-500/10'
                  : 'border-gray-700 hover:border-gray-600'
              }`}
              onClick={() => setSelectedVersion(version.id)}
            >
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="flex items-center gap-2">
                    <Badge variant={index === 0 ? 'default' : 'outline'}>
                      {index === 0 ? 'Current' : `v${versions.length - index}`}
                    </Badge>
                    <span className="text-sm text-gray-400">
                      {version.timestamp.toLocaleDateString()} {version.timestamp.toLocaleTimeString()}
                    </span>
                  </div>
                </div>
                {index > 0 && (
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={(e) => {
                      e.stopPropagation();
                      onRestore(version);
                    }}
                  >
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Restore
                  </Button>
                )}
              </div>
              <div className="space-y-1">
                {version.changes.map((change, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-sm text-gray-300">
                    <ChevronRight className="w-3 h-3" />
                    {change}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {selectedVersion && selectedVersion !== '1' && (
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <GitCompare className="w-5 h-5" />
              Compare Versions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold mb-2 text-green-500">Current</h4>
                <div className="space-y-1 text-sm">
                  <p><span className="text-gray-400">Name:</span> {currentCoin.name}</p>
                  <p><span className="text-gray-400">Ticker:</span> {currentCoin.ticker}</p>
                  <p><span className="text-gray-400">Status:</span> {currentCoin.status}</p>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-2 text-blue-500">Selected Version</h4>
                <div className="space-y-1 text-sm">
                  <p><span className="text-gray-400">Changes:</span> {versions.find(v => v.id === selectedVersion)?.changes.length || 0}</p>
                  <p className="text-xs text-gray-500">Previous state snapshot</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
