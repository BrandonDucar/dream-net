'use client'

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Video, Wand2, Download, Play, Loader2 } from 'lucide-react';

interface VideoGenerationProps {
  coinName: string;
  mascotImageUrl?: string;
}

export function VideoGeneration({ coinName, mascotImageUrl }: VideoGenerationProps) {
  const [videoPrompt, setVideoPrompt] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string>('');

  const handleGenerateVideo = async (): Promise<void> => {
    setIsGenerating(true);
    // Simulate video generation
    setTimeout(() => {
      setGeneratedVideoUrl('https://example.com/video.mp4');
      setIsGenerating(false);
    }, 3000);
  };

  const generateLaunchVideoPrompt = (): string => {
    return `Create an exciting launch video for ${coinName}, featuring the culture coin mascot with dynamic motion, vibrant colors, and energetic music. Show the mascot emerging from cosmic particles, followed by the coin ticker and tagline. End with "Now Live on Base" text.`;
  };

  const generateAnimatedMascotPrompt = (): string => {
    return `Animated ${coinName} mascot character dancing and celebrating in a colorful crypto-themed environment with floating coins, blockchain patterns, and neon lights. Playful, energetic, and fun vibes perfect for social media.`;
  };

  return (
    <Card className="bg-gray-900 border-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Video className="w-5 h-5" />
          Video Generation
        </CardTitle>
        <CardDescription>Create launch videos and animated content</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid md:grid-cols-2 gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setVideoPrompt(generateLaunchVideoPrompt())}
          >
            <Wand2 className="w-4 h-4 mr-2" />
            Launch Video
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setVideoPrompt(generateAnimatedMascotPrompt())}
          >
            <Wand2 className="w-4 h-4 mr-2" />
            Animated Mascot
          </Button>
        </div>

        <div>
          <Label>Video Prompt</Label>
          <Textarea
            placeholder="Describe the video you want to generate..."
            value={videoPrompt}
            onChange={(e) => setVideoPrompt(e.target.value)}
            rows={5}
            className="resize-none"
          />
          <p className="text-xs text-gray-500 mt-1">
            Describe motion, style, colors, and mood for best results
          </p>
        </div>

        <Button
          onClick={handleGenerateVideo}
          disabled={!videoPrompt || isGenerating}
          className="w-full"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Generating Video...
            </>
          ) : (
            <>
              <Video className="w-4 h-4 mr-2" />
              Generate Video
            </>
          )}
        </Button>

        {generatedVideoUrl && (
          <div className="space-y-3 pt-4 border-t border-gray-800">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium">Generated Video</p>
              <Badge variant="default">Ready</Badge>
            </div>
            
            <div className="aspect-video bg-gray-800 rounded-lg flex items-center justify-center">
              <Play className="w-12 h-12 text-gray-600" />
            </div>

            <div className="flex gap-2">
              <Button variant="outline" className="flex-1">
                <Play className="w-4 h-4 mr-2" />
                Preview
              </Button>
              <Button variant="outline" className="flex-1">
                <Download className="w-4 h-4 mr-2" />
                Download
              </Button>
            </div>

            <div className="text-xs text-gray-500">
              <p>• Use for X posts, Farcaster frames, TikTok, Instagram Reels</p>
              <p>• Optimized for 16:9 aspect ratio</p>
              <p>• MP4 format, ready for social media</p>
            </div>
          </div>
        )}

        <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
          <p className="text-sm font-medium mb-1">Pro Tip</p>
          <p className="text-xs text-gray-400">
            Combine with your mascot image for character consistency. Videos typically take 1-2 minutes to generate.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
