'use client'

import { useState, useEffect } from 'react';

export interface CultureCoin {
  id: string;
  name: string;
  ticker: string;
  shortTagline: string;
  theme: string;
  archetype: string;
  primaryEmoji: string;
  chain: string;
  contractAddress?: string;
  status: 'idea' | 'draft' | 'ready' | 'launched' | 'retired';
  originStory: string;
  coreMyth: string;
  personalityTraits: string[];
  alliedSymbols: string[];
  enemiesOrAntagonists: string[];
  visualMotifs: string[];
  memeAngles: string[];
  formatsRecommended: string[];
  keyPhrases: string[];
  talkingPoints: string[];
  launchHooks: string[];
  dropIdeas: string[];
  riskNotes: string[];
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
  relatedMemeIds: string;
  relatedCampaignIds: string;
  mascotImageUrl?: string;
  mascotIpfsUrl?: string;
  deploymentStatus?: string;
  deploymentTxHash?: string;
  deploymentError?: string;
  revenueManagerAddress?: string;
  protocolFee?: number;
  creatorWalletAddress?: string;
  launchedAt?: string;
  totalMinted?: number;
  holderCount?: number;
  marketCapUsd?: number;
  priceUsd?: number;
  volume24H?: number;
  researchNotes?: string;
  trendScore?: number;
  competitorAnalysis?: string;
  socialMetrics?: string;
  attachedMemeUrls?: string;
  createdAt: string;
  updatedAt: string;
}

export interface GeoTarget {
  id: string;
  cultureCoinId: string;
  region: string;
  country?: string;
  cityOrMarket?: string;
  language: string;
  geoKey: string;
  localizedCaption: string;
  localizedTags: string[];
}

const STORAGE_KEY = 'culturecoin-foundry-data';

interface StorageData {
  cultureCoins: CultureCoin[];
  geoTargets: GeoTarget[];
}

export function useLocalStorage() {
  const [cultureCoins, setCultureCoins] = useState<Map<string, CultureCoin>>(new Map());
  const [geoTargets, setGeoTargets] = useState<Map<string, GeoTarget>>(new Map());
  const [isLoading, setIsLoading] = useState(true);

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const data: StorageData = JSON.parse(stored);
        const coinsMap = new Map(data.cultureCoins.map(c => [c.id, c]));
        const targetsMap = new Map(data.geoTargets.map(t => [t.id, t]));
        setCultureCoins(coinsMap);
        setGeoTargets(targetsMap);
      }
    } catch (error) {
      console.error('Failed to load from localStorage:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Save to localStorage whenever data changes
  const saveToStorage = (coins: Map<string, CultureCoin>, targets: Map<string, GeoTarget>) => {
    try {
      const data: StorageData = {
        cultureCoins: Array.from(coins.values()),
        geoTargets: Array.from(targets.values()),
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error('Failed to save to localStorage:', error);
    }
  };

  const createCultureCoin = (coin: Omit<CultureCoin, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newCoin: CultureCoin = {
      ...coin,
      id: `coin-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const newCoins = new Map(cultureCoins);
    newCoins.set(newCoin.id, newCoin);
    setCultureCoins(newCoins);
    saveToStorage(newCoins, geoTargets);
    return newCoin;
  };

  const updateCultureCoin = (id: string, updates: Partial<CultureCoin>) => {
    const coin = cultureCoins.get(id);
    if (!coin) return;
    const updatedCoin: CultureCoin = {
      ...coin,
      ...updates,
      id,
      updatedAt: new Date().toISOString(),
    };
    const newCoins = new Map(cultureCoins);
    newCoins.set(id, updatedCoin);
    setCultureCoins(newCoins);
    saveToStorage(newCoins, geoTargets);
    return updatedCoin;
  };

  const deleteCultureCoin = (id: string) => {
    const newCoins = new Map(cultureCoins);
    newCoins.delete(id);
    // Also delete related geo targets
    const newTargets = new Map(geoTargets);
    Array.from(newTargets.values())
      .filter(t => t.cultureCoinId === id)
      .forEach(t => newTargets.delete(t.id));
    setCultureCoins(newCoins);
    setGeoTargets(newTargets);
    saveToStorage(newCoins, newTargets);
  };

  const createGeoTarget = (target: Omit<GeoTarget, 'id'>) => {
    const newTarget: GeoTarget = {
      ...target,
      id: `geo-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };
    const newTargets = new Map(geoTargets);
    newTargets.set(newTarget.id, newTarget);
    setGeoTargets(newTargets);
    saveToStorage(cultureCoins, newTargets);
    return newTarget;
  };

  const deleteGeoTarget = (id: string) => {
    const newTargets = new Map(geoTargets);
    newTargets.delete(id);
    setGeoTargets(newTargets);
    saveToStorage(cultureCoins, newTargets);
  };

  return {
    cultureCoins,
    geoTargets,
    isLoading,
    createCultureCoin,
    updateCultureCoin,
    deleteCultureCoin,
    createGeoTarget,
    deleteGeoTarget,
  };
}
