'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import type { Identity } from 'spacetimedb';
import * as moduleBindings from '../spacetime_module_bindings';

type DbConnection = moduleBindings.DbConnection;
type CultureCoin = moduleBindings.CultureCoin;
type GeoTarget = moduleBindings.GeoTarget;

export function useSpacetimeDB() {
  const [connected, setConnected] = useState<boolean>(false);
  const [identity, setIdentity] = useState<Identity | null>(null);
  const [statusMessage, setStatusMessage] = useState<string>('Connecting...');
  const [cultureCoins, setCultureCoins] = useState<ReadonlyMap<bigint, CultureCoin>>(new Map());
  const [geoTargets, setGeoTargets] = useState<ReadonlyMap<bigint, GeoTarget>>(new Map());
  
  const connectionRef = useRef<DbConnection | null>(null);

  const subscribeToTables = useCallback(() => {
    if (!connectionRef.current) return;
    
    console.log('Subscribing to tables...');
    
    const queries = ['SELECT * FROM culture_coin', 'SELECT * FROM geo_target'];
    
    connectionRef.current
      .subscriptionBuilder()
      .onApplied(() => {
        console.log('Subscription applied for:', queries);
        processInitialCache();
      })
      .onError((error: Error) => {
        console.error('Subscription error:', error);
        setStatusMessage(`Subscription Error: ${error.message}`);
      })
      .subscribe(queries);
  }, []);

  const processInitialCache = useCallback(() => {
    if (!connectionRef.current) return;
    console.log('Processing initial cache...');
    
    const coins = new Map<bigint, CultureCoin>();
    for (const coin of connectionRef.current.db.cultureCoin.iter()) {
      coins.set(coin.id, coin);
    }
    setCultureCoins(coins);
    
    const targets = new Map<bigint, GeoTarget>();
    for (const target of connectionRef.current.db.geoTarget.iter()) {
      targets.set(target.id, target);
    }
    setGeoTargets(targets);
  }, []);

  const registerTableCallbacks = useCallback((currentIdentity: Identity) => {
    if (!connectionRef.current) return;
    
    console.log('Registering table callbacks...');

    connectionRef.current.db.cultureCoin.onInsert((_ctx, coin) => {
      console.log('CultureCoin inserted:', coin.id);
      setCultureCoins((prev: ReadonlyMap<bigint, CultureCoin>) =>
        new Map(prev).set(coin.id, coin)
      );
    });

    connectionRef.current.db.cultureCoin.onUpdate((_ctx, _oldCoin, newCoin) => {
      setCultureCoins((prev: ReadonlyMap<bigint, CultureCoin>) => {
        const newMap = new Map(prev);
        newMap.set(newCoin.id, newCoin);
        return newMap;
      });
    });

    connectionRef.current.db.cultureCoin.onDelete((_ctx, coin) => {
      console.log('CultureCoin deleted:', coin.id);
      setCultureCoins((prev: ReadonlyMap<bigint, CultureCoin>) => {
        const newMap = new Map(prev);
        newMap.delete(coin.id);
        return newMap;
      });
    });

    connectionRef.current.db.geoTarget.onInsert((_ctx, target) => {
      console.log('GeoTarget inserted:', target.id);
      setGeoTargets((prev: ReadonlyMap<bigint, GeoTarget>) =>
        new Map(prev).set(target.id, target)
      );
    });

    connectionRef.current.db.geoTarget.onUpdate((_ctx, _oldTarget, newTarget) => {
      setGeoTargets((prev: ReadonlyMap<bigint, GeoTarget>) => {
        const newMap = new Map(prev);
        newMap.set(newTarget.id, newTarget);
        return newMap;
      });
    });

    connectionRef.current.db.geoTarget.onDelete((_ctx, target) => {
      console.log('GeoTarget deleted:', target.id);
      setGeoTargets((prev: ReadonlyMap<bigint, GeoTarget>) => {
        const newMap = new Map(prev);
        newMap.delete(target.id);
        return newMap;
      });
    });
  }, []);

  useEffect(() => {
    if (connectionRef.current) {
      console.log('Connection already established, skipping setup.');
      return;
    }

    const dbHost = 'wss://maincloud.spacetimedb.com';
    const dbName = process.env.NEXT_PUBLIC_SPACETIME_MODULE_NAME || 'culturecoin_foundry';

    const onConnect = (connection: DbConnection, id: Identity, _token: string) => {
      console.log('Connected to SpacetimeDB!');
      connectionRef.current = connection;
      setIdentity(id);
      setConnected(true);
      setStatusMessage('Connected');
      
      subscribeToTables();
      registerTableCallbacks(id);
    };

    const onDisconnect = (_ctx: moduleBindings.ErrorContext, reason?: Error | null) => {
      const reasonStr = reason ? reason.message : 'Connection interrupted';
      console.log('Disconnected:', reasonStr);
      setStatusMessage('Reconnecting...');
      connectionRef.current = null;
      setIdentity(null);
      setConnected(false);
      
      setTimeout(() => {
        console.log('Attempting to reconnect...');
        moduleBindings.DbConnection.builder()
          .withUri(dbHost)
          .withModuleName(dbName)
          .onConnect(onConnect)
          .onDisconnect(onDisconnect)
          .build();
      }, 2000);
    };

    moduleBindings.DbConnection.builder()
      .withUri(dbHost)
      .withModuleName(dbName)
      .onConnect(onConnect)
      .onDisconnect(onDisconnect)
      .build();
  }, [subscribeToTables, registerTableCallbacks]);

  return {
    connected,
    identity,
    statusMessage,
    cultureCoins,
    geoTargets,
    connection: connectionRef.current,
  };
}
