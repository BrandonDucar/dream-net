// Generation logic for CultureCoin content

export interface GeneratedCultureCoin {
  name: string;
  ticker: string;
  shortTagline: string;
  theme: string;
  archetype: string;
  primaryEmoji: string;
  originStory: string;
  coreMyth: string;
  personalityTraits: string[];
  alliedSymbols: string[];
  enemiesOrAntagonists?: string;
  visualMotifs: string[];
  memeAngles: string[];
  formatsRecommended: string[];
  keyPhrases: string[];
  talkingPoints: string[];
  launchHooks: string[];
  dropIdeas: string[];
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
  mascotImageUrl?: string;
  mascotIpfsUrl?: string;
}

const archetypes = ['trickster', 'guardian', 'oracle', 'rebel', 'sage', 'explorer', 'creator', 'catalyst'];
const emojis = ['🐌', '🐱', '🌲', '🔮', '⚡', '🌊', '🔥', '🌙', '⭐', '🦋', '🌺', '🎭', '🎨', '🎪'];

export function generateCultureCoin(name: string, ticker: string, vibe: string): GeneratedCultureCoin {
  const archetype = archetypes[Math.floor(Math.random() * archetypes.length)];
  const emoji = emojis[Math.floor(Math.random() * emojis.length)];
  
  const theme = `${vibe} meets ${archetype} energy`;
  const shortTagline = `${name} ${emoji} – where ${vibe} becomes currency`;
  
  const originStory = `In the depths of the blockchain forest, ${name} emerged from the collective dreams of builders who believed ${vibe} could reshape value itself. Born on Base, this ${archetype} energy crystallized into a token that represents not just wealth, but a way of being. ${name} doesn't just exist—it vibrates at the frequency of ${vibe}, turning every transaction into a ritual of cultural alchemy.`;
  
  const coreMyth = `${name} is the ${archetype} who guards the sacred intersection of ${vibe} and onchain culture. Legend says that holders of ${ticker} gain the ability to manifest ${vibe} in all their endeavors. The token itself is said to be woven from the digital threads of Base's most creative minds, each transaction spreading the ${archetype}'s wisdom further into the ecosystem.`;
  
  const personalityTraits = [
    `${archetype}-like wisdom`,
    `deeply ${vibe}`,
    'Base-native energy',
    'meme-fluent',
    'community-first',
  ];
  
  const alliedSymbols = [
    emoji,
    '🔵 Base',
    '⚡ speed',
    `${vibe} vibes`,
    'onchain culture',
  ];
  
  const visualMotifs = [
    `${emoji} glowing softly`,
    `${vibe} color palette`,
    'Base blue accents',
    'ethereal gradients',
    'digital nature fusion',
  ];
  
  const memeAngles = [
    `"${name} holders be like..." reaction format`,
    `${ticker} vs other tokens comparison`,
    `POV: you just bought ${ticker}`,
    `${name} ${emoji} morning routine`,
    `${vibe} energy alignment chart with ${ticker}`,
  ];
  
  const formatsRecommended = [
    '4-panel comic',
    'reaction image',
    'quote card',
    'before/after split',
    'alignment chart',
  ];
  
  const keyPhrases = [
    `${ticker} is the vibe`,
    `${vibe} on chain`,
    `${name} ${emoji} season`,
    `Based and ${vibe}-pilled`,
    `${ticker} holders know`,
  ];
  
  const talkingPoints = [
    `${name} represents ${vibe} culture materialized on Base`,
    `${ticker} isn't just a token—it's a cultural signal`,
    `Built by and for the ${vibe} community`,
    `Every ${ticker} transaction spreads ${archetype} energy`,
    `${name} ${emoji} = the intersection of art, memes, and value`,
  ];
  
  const launchHooks = [
    `${emoji} ${name} is live on Base. ${ticker} is the ${vibe} you've been waiting for.`,
    `Introducing ${ticker}: where ${vibe} becomes unstoppable. Join the ${archetype}.`,
  ];
  
  const dropIdeas = [
    `Zora mint: "${name} Genesis ${emoji}" NFT collection`,
    `Farcaster Frame: ${ticker} vibe check`,
    `Airdrop to ${vibe} community leaders`,
    `Launch party in Based channels`,
    `${name} sticker pack for holders`,
  ];
  
  const seoTitle = `${name} (${ticker}) - ${vibe} Culture Coin on Base`;
  const seoDescription = `${name} is a Base-native culture coin embodying ${vibe} energy. Built as a ${archetype}, ${ticker} represents onchain ${vibe} culture and community.`;
  const seoKeywords = [name, ticker, vibe, archetype, 'Base', 'culture coin', 'memecoin', 'onchain culture'];
  const seoHashtags = [`#${ticker}`, `#${name}`, '#Base', '#CultureCoin', `#${vibe.replace(/\s+/g, '')}`];
  const altText = `${name} ${emoji} logo representing ${vibe} energy and ${archetype} archetype on Base blockchain`;
  
  return {
    name,
    ticker,
    shortTagline,
    theme,
    archetype,
    primaryEmoji: emoji,
    originStory,
    coreMyth,
    personalityTraits,
    alliedSymbols,
    visualMotifs,
    memeAngles,
    formatsRecommended,
    keyPhrases,
    talkingPoints,
    launchHooks,
    dropIdeas,
    seoTitle,
    seoDescription,
    seoKeywords,
    seoHashtags,
    altText,
  };
}

export function regenerateNarrative(currentCoin: GeneratedCultureCoin, boost?: string): Partial<GeneratedCultureCoin> {
  const extraContext = boost ? ` ${boost}` : '';
  
  return {
    originStory: `${currentCoin.originStory}${extraContext} This deeper layer reveals how ${currentCoin.name} transcends ordinary tokens, becoming a living sigil of ${currentCoin.theme}.`,
    coreMyth: `${currentCoin.coreMyth} The myth evolves: ${currentCoin.name} holders report synchronicities, unexpected collaborations, and a heightened sense of ${currentCoin.theme}.`,
    personalityTraits: [...currentCoin.personalityTraits, 'evolving consciousness', 'synchronicity magnet'],
  };
}

export function regenerateMemeDirections(currentCoin: GeneratedCultureCoin): Partial<GeneratedCultureCoin> {
  return {
    visualMotifs: [
      ...currentCoin.visualMotifs,
      'holographic textures',
      'animated ${currentCoin.primaryEmoji}',
      'glitch art aesthetics',
    ],
    memeAngles: [
      ...currentCoin.memeAngles,
      `${currentCoin.ticker} holder meetup be like`,
      `explaining ${currentCoin.name} to nocoiners`,
      `${currentCoin.ticker} energy levels throughout the day`,
    ],
    formatsRecommended: [...currentCoin.formatsRecommended, 'video meme', 'GIF reaction'],
  };
}

export function regenerateMessagingAndSEO(currentCoin: GeneratedCultureCoin): Partial<GeneratedCultureCoin> {
  return {
    keyPhrases: [
      ...currentCoin.keyPhrases,
      `${currentCoin.ticker} forever`,
      `${currentCoin.name} family`,
    ],
    talkingPoints: [
      ...currentCoin.talkingPoints,
      `${currentCoin.name} community is building the future of ${currentCoin.theme}`,
      `${currentCoin.ticker} represents a new paradigm in cultural tokens`,
    ],
    launchHooks: [
      ...currentCoin.launchHooks,
      `The ${currentCoin.primaryEmoji} awakens. ${currentCoin.ticker} is here.`,
    ],
    seoKeywords: [...currentCoin.seoKeywords, 'crypto culture', 'meme economy', 'Base ecosystem'],
    seoHashtags: [...currentCoin.seoHashtags, '#OnchainCulture', '#BuildOnBase'],
  };
}

export interface GeoVariant {
  geoKey: string;
  region: string;
  language: string;
  localizedCaption: string;
  localizedTags: string[];
}

export function generateGeoVariants(coinName: string, ticker: string, baseCaption: string): GeoVariant[] {
  return [
    {
      geoKey: 'us-en',
      region: 'US',
      language: 'en',
      localizedCaption: baseCaption,
      localizedTags: [`#${ticker}`, '#crypto', '#Base', '#memecoin'],
    },
    {
      geoKey: 'latam-es',
      region: 'LATAM',
      language: 'es',
      localizedCaption: `${coinName} llega a Base. ${ticker} es la nueva energía cultural.`,
      localizedTags: [`#${ticker}`, '#cripto', '#Base', '#meme'],
    },
    {
      geoKey: 'latam-pt',
      region: 'LATAM',
      language: 'pt-BR',
      localizedCaption: `${coinName} chegou na Base. ${ticker} é a nova energia cultural.`,
      localizedTags: [`#${ticker}`, '#cripto', '#Base', '#meme'],
    },
    {
      geoKey: 'eu-en',
      region: 'EU',
      language: 'en',
      localizedCaption: `${coinName} has landed on Base. ${ticker} is the cultural shift you've been waiting for.`,
      localizedTags: [`#${ticker}`, '#crypto', '#Base', '#culture'],
    },
    {
      geoKey: 'asia-en',
      region: 'ASIA',
      language: 'en',
      localizedCaption: `${coinName} is live on Base. Join the ${ticker} movement.`,
      localizedTags: [`#${ticker}`, '#crypto', '#Base', '#web3'],
    },
  ];
}
