// tenor-api.ts

/**
 * ================================================================================
 * DO NOT MODIFY THIS FILE. This file is READ ONLY and is DETERMINISTIC.
 * Tenor Meme Search API — Find, browse, and suggest memes (GIFs/stickers) via proxy.
 * Secure. Typed. Supports semantic/keyword search, content filtering, and pagination.
 * ================================================================================
 */

const BASE_URL = 'tenor.googleapis.com';
const TENOR_API_KEY = 'secret_cmcb7gbz30000356n3sxdmhrd';

export type TenorMediaFormat =
  | 'gif' | 'mediumgif' | 'tinygif' | 'nanogif'
  | 'mp4' | 'loopedmp4' | 'tinymp4' | 'nanomp4'
  | 'webm' | 'tinywebm' | 'nanowebm'
  | 'webp_transparent' | 'tinywebp_transparent' | 'nanowebp_transparent'
  | 'gif_transparent' | 'tinygif_transparent' | 'nanogif_transparent';

export type TenorContentFilter = 'off' | 'low' | 'medium' | 'high';

export type TenorMemeSearchParams = {
  q: string; // Search phrase, meme keyword, or emoji
  limit?: number;
  pos?: string;
  random?: boolean;
  client_key?: string;
  country?: string;
  locale?: string;
  contentfilter?: TenorContentFilter;
  media_filter?: string;
  ar_range?: 'all' | 'wide' | 'standard';
};

export type TenorMemeCategoriesParams = {
  type?: 'featured' | 'trending';
  client_key?: string;
  country?: string;
  locale?: string;
};

export type TenorMemeSuggestionsParams = {
  q: string;
  limit?: number;
  client_key?: string;
  country?: string;
  locale?: string;
};

export type TenorMeme = {
  id: string;
  title: string;
  content_description: string;
  itemurl: string;
  url: string;
  hasaudio: boolean;
  hascaption: boolean;
  tags: string[];
  media_formats: Record<string, {
    url: string;
    dims: number[];
    duration?: number;
    size?: number;
  }>;
  flags: string;
  created?: number;
  bg_color?: string;
};

export type TenorMemeCategory = {
  name: string;
  searchterm: string;
  path: string;
  image: string;
};

export type TenorMemeSearchResponse = {
  next?: string;
  results: TenorMeme[];
};

export type TenorMemeCategoriesResponse = {
  tags: TenorMemeCategory[];
};

export type TenorMemeSuggestionsResponse = {
  results: string[];
};

/**
 * Internal proxy utility for all Tenor meme API requests.
 */
async function tenorMemeProxy({
  path,
  method = 'GET',
  query = {},
}: {
  path: string;
  method?: 'GET' | 'POST';
  query?: Record<string, any>;
}): Promise<any> {
  const params = new URLSearchParams({ ...query, key: TENOR_API_KEY });
  const urlPath = `${path}?${params.toString()}`;
  const res = await fetch('/api/proxy', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      protocol: 'https',
      origin: BASE_URL,
      path: urlPath,
      method,
      headers: { 'accept': 'application/json' },
    }),
  });
  return res.json();
}

/**
 * Search for memes (GIFs, meme phrases, catchphrases, emoji).
 */
export async function tenorSearchMemes(params: TenorMemeSearchParams): Promise<TenorMemeSearchResponse> {
  return tenorMemeProxy({ path: '/v2/search', query: { ...params } });
}

/**
 * Search for meme stickers (animated, transparent memes).
 */
export async function tenorSearchMemeStickers(params: TenorMemeSearchParams): Promise<TenorMemeSearchResponse> {
  return tenorMemeProxy({ path: '/v2/search', query: { ...params, searchfilter: 'sticker' } });
}

/**
 * Get globally trending/featured meme GIFs.
 */
export async function tenorFeaturedMemes(params: Partial<TenorMemeSearchParams> = {}): Promise<TenorMemeSearchResponse> {
  return tenorMemeProxy({ path: '/v2/featured', query: { ...params } });
}

/**
 * Get featured or trending meme categories.
 */
export async function tenorMemeCategories(params: TenorMemeCategoriesParams = {}): Promise<TenorMemeCategoriesResponse> {
  return tenorMemeProxy({ path: '/v2/categories', query: { ...params } });
}

/**
 * Get semantic/related meme search suggestions (autocomplete).
 */
export async function tenorMemeSuggestions(params: TenorMemeSuggestionsParams): Promise<TenorMemeSuggestionsResponse> {
  return tenorMemeProxy({ path: '/v2/search_suggestions', query: { ...params } });
}
