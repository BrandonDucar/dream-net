import { NextRequest, NextResponse } from 'next/server';
import { openaiChatCompletion } from '@/openai-api';
import type { AnalysisRequest, AnalysisResult } from '@/types/culture-score';

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body: AnalysisRequest = await request.json();
    
    if (!body.text || body.text.trim().length === 0) {
      return NextResponse.json(
        { error: 'Text is required' },
        { status: 400 }
      );
    }

    const platform = body.platform || 'Generic';
    const region = body.audience_region || 'Global';
    const intent = body.intent || 'meme';

    // Construct the analysis prompt
    const systemPrompt = `You are CultureScore — DreamNet's cultural signal index for memes and posts.

Your job:
- Analyze the user's text.
- Score it across 5 categories (0-100 scale).
- Explain what's strong, what's weak.
- Quietly improve it using semantic optimization and regional style tuning.
- Output a clean scorecard and improved versions in JSON.

Scoring dimensions (0–100):

1) originality
   - How fresh/unique the idea/phrasing is.
   - High: unusual phrasing, clever angle, non-generic.
   - Low: generic platitudes, overused jokes.

2) virality_potential
   - How likely it is to get engagement (given typical platform behavior).
   - Consider hook strength, emotional punch, shareability.

3) cultural_resonance
   - How well it plugs into current culture, memes, or narrative.
   - Avoid relying on niche references unless clearly intended.

4) remix_potential
   - How easy it is for others to riff on, quote, or meme it further.

5) platform_fit
   - How well it matches norms for the selected platform.

Platform context: ${platform}
Audience region: ${region}
Intent: ${intent}

Semantic optimization (AI-SEO style, internal only):
- Make the improved_version clearer, more engaging, and more discoverable.
- Use language patterns that match the platform and topic.
- DO NOT mention SEO, algorithms, or optimization.

Geo-style tuning (audience_region):
- ${getRegionGuidance(region)}

Improved + alt versions:
- improved_version: same idea, better execution.
- alt_versions:
  - spicy: more provocative but still within safe limits.
  - safe: PG, brand-safe.
  - lore: optional DreamNet-style flavor (roots, signals, DreamNet tree, culture engines, etc.) if it fits.
  - minimal: short, stripped-down, punchy.

Strengths/weaknesses:
- Provide 2-3 bullet-level strengths and weaknesses each, as short phrases.

Safety:
- If the original text is harmful or disallowed, produce a safe humorous alternative and score based on the safe version.

Return ONLY valid JSON matching this exact schema:
{
  "scores": {
    "originality": number,
    "virality_potential": number,
    "cultural_resonance": number,
    "remix_potential": number,
    "platform_fit": number
  },
  "summary": "string",
  "strengths": ["string", "string"],
  "weaknesses": ["string", "string"],
  "improved_version": "string",
  "alt_versions": {
    "spicy": "string",
    "safe": "string",
    "lore": "string",
    "minimal": "string"
  }
}`;

    const userPrompt = `Analyze this text:\n\n"${body.text}"\n\nProvide your analysis as valid JSON only.`;

    const response = await openaiChatCompletion({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error('No content returned from AI');
    }

    // Extract JSON from potential markdown code blocks
    let jsonText = content.trim();
    if (jsonText.startsWith('```json')) {
      jsonText = jsonText.replace(/^```json\s*/i, '').replace(/\s*```$/, '');
    } else if (jsonText.startsWith('```')) {
      jsonText = jsonText.replace(/^```\s*/, '').replace(/\s*```$/, '');
    }

    const result: AnalysisResult = JSON.parse(jsonText);

    // Validate the structure
    if (!result.scores || !result.summary || !result.improved_version || !result.alt_versions) {
      throw new Error('Invalid response structure from AI');
    }

    return NextResponse.json(result);
  } catch (error: unknown) {
    console.error('Analysis error:', error);
    const message = error instanceof Error ? error.message : 'Failed to analyze text';
    return NextResponse.json(
      { error: message },
      { status: 500 }
    );
  }
}

function getRegionGuidance(region: string): string {
  const guidance: Record<string, string> = {
    US: 'Casual internet tone, meme slang is okay.',
    EU: 'Slightly cleaner, more neutral.',
    LATAM: 'A bit warmer and expressive (still in English unless requested).',
    Asia: 'Avoid heavy niche Western references.',
    Global: 'Broadly understandable internet tone.',
  };
  return guidance[region] || guidance.Global;
}
