'use client';

import type { AnalysisResult } from '@/types/culture-score';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScoreCard } from './score-card';
import { CheckCircle2, XCircle, Sparkles } from 'lucide-react';

interface AnalysisResultsProps {
  result: AnalysisResult;
  originalText: string;
}

export function AnalysisResults({ result, originalText }: AnalysisResultsProps): JSX.Element {
  return (
    <div className="space-y-6 w-full max-w-4xl">
      {/* Score Card */}
      <ScoreCard scores={result.scores} />

      {/* Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-black leading-relaxed">{result.summary}</p>
        </CardContent>
      </Card>

      {/* Strengths & Weaknesses */}
      <div className="grid md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-600">
              <CheckCircle2 className="w-5 h-5" />
              Strengths
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {result.strengths.map((strength, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="text-green-500 mt-1">•</span>
                  <span className="text-black">{strength}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-600">
              <XCircle className="w-5 h-5" />
              Weaknesses
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {result.weaknesses.map((weakness, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="text-red-500 mt-1">•</span>
                  <span className="text-black">{weakness}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Original vs Improved */}
      <Card>
        <CardHeader>
          <CardTitle>Original vs Improved</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Badge variant="outline" className="mb-2">Original</Badge>
            <p className="text-black bg-gray-50 p-4 rounded-lg border">{originalText}</p>
          </div>
          <div>
            <Badge className="mb-2 bg-green-600">Improved</Badge>
            <p className="text-black bg-green-50 p-4 rounded-lg border border-green-200">
              {result.improved_version}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Alternative Versions */}
      <Card>
        <CardHeader>
          <CardTitle>Alternative Versions</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="spicy" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="spicy">🌶️ Spicy</TabsTrigger>
              <TabsTrigger value="safe">✅ Safe</TabsTrigger>
              <TabsTrigger value="lore">🌳 Lore</TabsTrigger>
              <TabsTrigger value="minimal">⚡ Minimal</TabsTrigger>
            </TabsList>
            <TabsContent value="spicy" className="mt-4">
              <p className="text-black bg-orange-50 p-4 rounded-lg border border-orange-200">
                {result.alt_versions.spicy}
              </p>
            </TabsContent>
            <TabsContent value="safe" className="mt-4">
              <p className="text-black bg-blue-50 p-4 rounded-lg border border-blue-200">
                {result.alt_versions.safe}
              </p>
            </TabsContent>
            <TabsContent value="lore" className="mt-4">
              <p className="text-black bg-purple-50 p-4 rounded-lg border border-purple-200">
                {result.alt_versions.lore}
              </p>
            </TabsContent>
            <TabsContent value="minimal" className="mt-4">
              <p className="text-black bg-gray-50 p-4 rounded-lg border border-gray-200">
                {result.alt_versions.minimal}
              </p>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
