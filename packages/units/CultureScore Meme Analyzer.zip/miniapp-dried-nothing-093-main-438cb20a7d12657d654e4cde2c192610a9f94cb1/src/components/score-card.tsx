'use client';

import type { ScoreBreakdown } from '@/types/culture-score';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';

interface ScoreCardProps {
  scores: ScoreBreakdown;
}

const scoreLabels: Record<keyof ScoreBreakdown, string> = {
  originality: 'Originality',
  virality_potential: 'Virality Potential',
  cultural_resonance: 'Cultural Resonance',
  remix_potential: 'Remix Potential',
  platform_fit: 'Platform Fit',
};

const getScoreColor = (score: number): string => {
  if (score >= 80) return 'bg-green-500';
  if (score >= 60) return 'bg-blue-500';
  if (score >= 40) return 'bg-yellow-500';
  if (score >= 20) return 'bg-orange-500';
  return 'bg-red-500';
};

const getScoreLabel = (score: number): string => {
  if (score >= 80) return 'Excellent';
  if (score >= 60) return 'Good';
  if (score >= 40) return 'Fair';
  if (score >= 20) return 'Weak';
  return 'Poor';
};

export function ScoreCard({ scores }: ScoreCardProps): JSX.Element {
  const avgScore = Math.round(
    Object.values(scores).reduce((a, b) => a + b, 0) / Object.values(scores).length
  );

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Cultural Signal Scorecard</span>
          <span className="text-2xl font-bold text-black">{avgScore}/100</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {(Object.keys(scores) as Array<keyof ScoreBreakdown>).map((key) => {
          const score = scores[key];
          return (
            <div key={key} className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="font-medium text-black">{scoreLabels[key]}</span>
                <span className={`font-semibold ${score >= 60 ? 'text-green-600' : score >= 40 ? 'text-yellow-600' : 'text-red-600'}`}>
                  {score}/100 · {getScoreLabel(score)}
                </span>
              </div>
              <div className="relative">
                <Progress value={score} className="h-3" />
                <div
                  className={`absolute top-0 left-0 h-3 rounded-full transition-all ${getScoreColor(score)}`}
                  style={{ width: `${score}%` }}
                />
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
