export type Platform = 'X' | 'Farcaster' | 'Instagram' | 'TikTok' | 'Base' | 'Generic';
export type AudienceRegion = 'US' | 'EU' | 'LATAM' | 'Asia' | 'Global';
export type Intent = 'meme' | 'announcement' | 'shitpost' | 'lore_drop' | 'call_to_action';

export interface AnalysisRequest {
  text: string;
  platform?: Platform;
  audience_region?: AudienceRegion;
  intent?: Intent;
}

export interface ScoreBreakdown {
  originality: number;
  virality_potential: number;
  cultural_resonance: number;
  remix_potential: number;
  platform_fit: number;
}

export interface AltVersions {
  spicy: string;
  safe: string;
  lore: string;
  minimal: string;
}

export interface AnalysisResult {
  scores: ScoreBreakdown;
  summary: string;
  strengths: string[];
  weaknesses: string[];
  improved_version: string;
  alt_versions: AltVersions;
}
