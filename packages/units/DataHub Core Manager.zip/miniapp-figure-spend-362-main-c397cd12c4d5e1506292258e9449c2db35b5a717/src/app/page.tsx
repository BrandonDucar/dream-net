'use client'
import { useState, useEffect } from 'react';
import type { DataHubSnapshot } from '@/types/datahub';
import { InitializationForm } from '@/components/datahub/initialization-form';
import { SnapshotDisplay } from '@/components/datahub/snapshot-display';
import { SnapshotImporter } from '@/components/datahub/snapshot-importer';
import { AdminPanel } from '@/components/datahub/admin-panel';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DataHubPage(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [snapshot, setSnapshot] = useState<DataHubSnapshot | null>(null);
  const [activeTab, setActiveTab] = useState<string>('init');

  const handleSnapshotCreated = (newSnapshot: DataHubSnapshot): void => {
    setSnapshot(newSnapshot);
    setActiveTab('view');
  };

  const handleSnapshotImported = (importedSnapshot: DataHubSnapshot): void => {
    setSnapshot(importedSnapshot);
    setActiveTab('view');
  };

  const handleSnapshotUpdated = (updatedSnapshot: DataHubSnapshot): void => {
    setSnapshot(updatedSnapshot);
  };

  const handleReset = (): void => {
    setSnapshot(null);
    setActiveTab('init');
  };

  return (
    <main className="min-h-screen bg-white text-black p-4 md:p-8 pt-16">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold mb-2">DataHub Node</h1>
          <p className="text-gray-700">
            Shared data hub for all mini apps. Maintains a unified snapshot of wallets, assets, metals, payments, automations, campaigns, and metrics.
          </p>
        </header>

        {!snapshot ? (
          <Card className="p-6">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="init">Create New</TabsTrigger>
                <TabsTrigger value="import">Load Existing</TabsTrigger>
              </TabsList>
              
              <TabsContent value="init">
                <InitializationForm onSnapshotCreated={handleSnapshotCreated} />
              </TabsContent>
              
              <TabsContent value="import">
                <SnapshotImporter onSnapshotImported={handleSnapshotImported} />
              </TabsContent>
            </Tabs>
          </Card>
        ) : (
          <div className="space-y-6">
            <div className="flex justify-end">
              <Button onClick={handleReset} variant="outline">
                Reset / New Snapshot
              </Button>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3 mb-6">
                <TabsTrigger value="view">View Snapshot</TabsTrigger>
                <TabsTrigger value="admin">Admin Panel</TabsTrigger>
                <TabsTrigger value="import">Import/Merge</TabsTrigger>
              </TabsList>
              
              <TabsContent value="view">
                <SnapshotDisplay snapshot={snapshot} />
              </TabsContent>
              
              <TabsContent value="admin">
                <AdminPanel 
                  snapshot={snapshot} 
                  onSnapshotUpdated={handleSnapshotUpdated} 
                />
              </TabsContent>
              
              <TabsContent value="import">
                <SnapshotImporter 
                  onSnapshotImported={handleSnapshotImported}
                  existingSnapshot={snapshot}
                />
              </TabsContent>
            </Tabs>
          </div>
        )}
      </div>
    </main>
  );
}
