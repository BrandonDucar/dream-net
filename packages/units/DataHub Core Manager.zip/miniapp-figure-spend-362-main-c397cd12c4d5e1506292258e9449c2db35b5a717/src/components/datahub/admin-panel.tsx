'use client';

import { useState } from 'react';
import type { DataHubSnapshot } from '@/types/datahub';
import { generateId } from '@/lib/datahub-utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DomainManager } from './domain-manager';
import { TenantEditor } from './tenant-editor';

interface AdminPanelProps {
  snapshot: DataHubSnapshot;
  onSnapshotUpdated: (snapshot: DataHubSnapshot) => void;
}

export function AdminPanel({ snapshot, onSnapshotUpdated }: AdminPanelProps): JSX.Element {
  const [activeTab, setActiveTab] = useState<string>('overview');

  const handleTenantUpdate = (updatedTenant: DataHubSnapshot['tenant']): void => {
    const updated = { ...snapshot };
    updated.tenant = updatedTenant;
    updated.last_updated = new Date().toISOString();
    onSnapshotUpdated(updated);
  };

  const handleProfileUpdate = (userName: string, notes: string): void => {
    const updated = { ...snapshot };
    updated.profile.user_name = userName;
    updated.profile.notes = notes;
    updated.last_updated = new Date().toISOString();
    onSnapshotUpdated(updated);
  };

  const handleDomainUpdate = (domain: keyof DataHubSnapshot, data: unknown[]): void => {
    const updated = { ...snapshot };
    updated[domain] = data as never;
    updated.last_updated = new Date().toISOString();
    onSnapshotUpdated(updated);
  };

  const handleCreateBackup = (): void => {
    const updated = { ...snapshot };
    if (!updated.custom.backups) {
      updated.custom.backups = [];
    }
    const backups = updated.custom.backups as Array<{ id: string; timestamp: string; snapshot: DataHubSnapshot }>;
    backups.push({
      id: generateId(),
      timestamp: new Date().toISOString(),
      snapshot: JSON.parse(JSON.stringify(snapshot)) as DataHubSnapshot,
    });
    updated.last_updated = new Date().toISOString();
    onSnapshotUpdated(updated);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Admin Panel</CardTitle>
          <CardDescription>
            Manage your DataHub Snapshot: inspect, edit, and maintain data integrity
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="tenant">Tenant & Profile</TabsTrigger>
              <TabsTrigger value="domains">Manage Domains</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Tenant Info</CardTitle>
                  </CardHeader>
                  <CardContent className="text-sm space-y-1">
                    <p>ID: {snapshot.tenant.id}</p>
                    <p>Name: {snapshot.tenant.display_name}</p>
                    <p>Wallet: {snapshot.tenant.primary_wallet}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Snapshot Info</CardTitle>
                  </CardHeader>
                  <CardContent className="text-sm space-y-1">
                    <p>Version: {snapshot.version}</p>
                    <p>Last Updated: {new Date(snapshot.last_updated).toLocaleString()}</p>
                    <p>
                      Backups:{' '}
                      {snapshot.custom.backups
                        ? (snapshot.custom.backups as unknown[]).length
                        : 0}
                    </p>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Domain Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="flex justify-between p-2 border rounded">
                      <span>Wallets</span>
                      <span className="font-semibold">{snapshot.wallets.length}</span>
                    </div>
                    <div className="flex justify-between p-2 border rounded">
                      <span>Assets</span>
                      <span className="font-semibold">{snapshot.assets.length}</span>
                    </div>
                    <div className="flex justify-between p-2 border rounded">
                      <span>Metals</span>
                      <span className="font-semibold">{snapshot.metals.length}</span>
                    </div>
                    <div className="flex justify-between p-2 border rounded">
                      <span>Payments</span>
                      <span className="font-semibold">{snapshot.payments.length}</span>
                    </div>
                    <div className="flex justify-between p-2 border rounded">
                      <span>Automations</span>
                      <span className="font-semibold">{snapshot.automations.length}</span>
                    </div>
                    <div className="flex justify-between p-2 border rounded">
                      <span>Apps</span>
                      <span className="font-semibold">{snapshot.apps.length}</span>
                    </div>
                    <div className="flex justify-between p-2 border rounded">
                      <span>Campaigns</span>
                      <span className="font-semibold">{snapshot.campaigns.length}</span>
                    </div>
                    <div className="flex justify-between p-2 border rounded">
                      <span>Metrics</span>
                      <span className="font-semibold">{snapshot.metrics.length}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button onClick={handleCreateBackup} variant="outline" className="w-full">
                Create Backup
              </Button>
            </TabsContent>

            <TabsContent value="tenant">
              <TenantEditor
                tenant={snapshot.tenant}
                profile={snapshot.profile}
                onTenantUpdate={handleTenantUpdate}
                onProfileUpdate={handleProfileUpdate}
              />
            </TabsContent>

            <TabsContent value="domains">
              <DomainManager snapshot={snapshot} onDomainUpdate={handleDomainUpdate} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
