'use client';

import { useState } from 'react';
import type { DataHubSnapshot } from '@/types/datahub';
import { generateId } from '@/lib/datahub-utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';

interface DomainManagerProps {
  snapshot: DataHubSnapshot;
  onDomainUpdate: (domain: keyof DataHubSnapshot, data: unknown[]) => void;
}

const DOMAINS = [
  { key: 'wallets', label: 'Wallets' },
  { key: 'assets', label: 'Assets' },
  { key: 'metals', label: 'Metals' },
  { key: 'payments', label: 'Payments' },
  { key: 'automations', label: 'Automations' },
  { key: 'apps', label: 'Apps' },
  { key: 'campaigns', label: 'Campaigns' },
  { key: 'metrics', label: 'Metrics' },
] as const;

type DomainKey = typeof DOMAINS[number]['key'];

export function DomainManager({ snapshot, onDomainUpdate }: DomainManagerProps): JSX.Element {
  const [selectedDomain, setSelectedDomain] = useState<DomainKey>('wallets');
  const [jsonInput, setJsonInput] = useState<string>('');
  const [editingId, setEditingId] = useState<string | null>(null);

  const currentData = snapshot[selectedDomain] as Array<{ id: string; [key: string]: unknown }>;

  const handleAddItem = (): void => {
    try {
      const parsed = JSON.parse(jsonInput) as Record<string, unknown>;
      const newItem = {
        id: generateId(),
        ...parsed,
      };
      const updated = [...currentData, newItem];
      onDomainUpdate(selectedDomain, updated);
      setJsonInput('');
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      alert(`Invalid JSON: ${errorMessage}`);
    }
  };

  const handleUpdateItem = (): void => {
    try {
      const parsed = JSON.parse(jsonInput) as Record<string, unknown>;
      const updated = currentData.map((item: { id: string; [key: string]: unknown }) =>
        item.id === editingId ? { ...item, ...parsed } : item
      );
      onDomainUpdate(selectedDomain, updated);
      setJsonInput('');
      setEditingId(null);
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      alert(`Invalid JSON: ${errorMessage}`);
    }
  };

  const handleArchiveItem = (id: string): void => {
    const updated = currentData.map((item: { id: string; [key: string]: unknown }) =>
      item.id === id ? { ...item, status: 'archived' } : item
    );
    onDomainUpdate(selectedDomain, updated);
  };

  const handleDeleteItem = (id: string): void => {
    if (!confirm('Are you sure you want to permanently delete this item?')) return;
    const updated = currentData.filter((item: { id: string }) => item.id !== id);
    onDomainUpdate(selectedDomain, updated);
  };

  const handleEditItem = (item: { id: string; [key: string]: unknown }): void => {
    setEditingId(item.id);
    const { id, ...rest } = item;
    setJsonInput(JSON.stringify(rest, null, 2));
  };

  const handleCancelEdit = (): void => {
    setEditingId(null);
    setJsonInput('');
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Domain Manager</CardTitle>
          <CardDescription>Add, edit, or archive entries in each domain</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="domainSelect">Select Domain</Label>
            <Select
              value={selectedDomain}
              onValueChange={(value: string) => {
                setSelectedDomain(value as DomainKey);
                setEditingId(null);
                setJsonInput('');
              }}
            >
              <SelectTrigger id="domainSelect">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {DOMAINS.map(({ key, label }: { key: DomainKey; label: string }) => (
                  <SelectItem key={key} value={key}>
                    {label} ({(snapshot[key] as unknown[]).length})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="jsonInput">
              {editingId ? 'Edit Entry (JSON)' : 'Add New Entry (JSON)'}
            </Label>
            <Textarea
              id="jsonInput"
              value={jsonInput}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setJsonInput(e.target.value)}
              placeholder='{"key": "value", ...}'
              className="font-mono text-xs"
              rows={6}
            />
            <p className="text-xs text-gray-600 mt-1">
              Enter JSON without the id field (it will be auto-generated)
            </p>
          </div>

          <div className="flex gap-2">
            {editingId ? (
              <>
                <Button onClick={handleUpdateItem} className="flex-1">
                  Update Entry
                </Button>
                <Button onClick={handleCancelEdit} variant="outline" className="flex-1">
                  Cancel
                </Button>
              </>
            ) : (
              <Button onClick={handleAddItem} className="w-full">
                Add Entry
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Current Entries</CardTitle>
          <CardDescription>
            {currentData.length} {currentData.length === 1 ? 'entry' : 'entries'} in {selectedDomain}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-96 w-full">
            {currentData.length === 0 ? (
              <p className="text-sm text-gray-600 text-center py-8">No entries yet</p>
            ) : (
              <div className="space-y-3">
                {currentData.map((item: { id: string; [key: string]: unknown }) => (
                  <Card key={item.id} className="p-3">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <code className="text-xs bg-gray-100 px-2 py-1 rounded">{item.id}</code>
                        {item.status === 'archived' && (
                          <Badge variant="secondary">Archived</Badge>
                        )}
                      </div>
                      <div className="flex gap-1">
                        <Button
                          onClick={() => handleEditItem(item)}
                          size="sm"
                          variant="outline"
                        >
                          Edit
                        </Button>
                        <Button
                          onClick={() => handleArchiveItem(item.id)}
                          size="sm"
                          variant="outline"
                          disabled={item.status === 'archived'}
                        >
                          Archive
                        </Button>
                        <Button
                          onClick={() => handleDeleteItem(item.id)}
                          size="sm"
                          variant="destructive"
                        >
                          Delete
                        </Button>
                      </div>
                    </div>
                    <pre className="text-xs bg-gray-50 p-2 rounded overflow-x-auto">
                      {JSON.stringify(item, null, 2)}
                    </pre>
                  </Card>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
