'use client';

import { useState } from 'react';
import type { DataHubSnapshot } from '@/types/datahub';
import { createEmptySnapshot } from '@/lib/datahub-utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface InitializationFormProps {
  onSnapshotCreated: (snapshot: DataHubSnapshot) => void;
}

const DOMAIN_OPTIONS = [
  { id: 'wallets', label: 'Wallets / tokens / onchain activity' },
  { id: 'metals', label: 'Metals / pricing / dealers' },
  { id: 'payments', label: 'Payments / streams / automations' },
  { id: 'campaigns', label: 'Content / campaigns / funnels' },
  { id: 'metrics', label: 'Metrics / experiments' },
  { id: 'business', label: 'Business ops / data' },
];

export function InitializationForm({ onSnapshotCreated }: InitializationFormProps): JSX.Element {
  const [tenantId, setTenantId] = useState<string>('');
  const [displayName, setDisplayName] = useState<string>('');
  const [primaryWallet, setPrimaryWallet] = useState<string>('');
  const [selectedDomains, setSelectedDomains] = useState<string[]>([]);
  const [customDomain, setCustomDomain] = useState<string>('');

  const handleDomainToggle = (domainId: string): void => {
    setSelectedDomains((prev: string[]) =>
      prev.includes(domainId)
        ? prev.filter((id: string) => id !== domainId)
        : [...prev, domainId]
    );
  };

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    
    if (!tenantId || !displayName || !primaryWallet) {
      alert('Please fill in all required fields');
      return;
    }
    
    const snapshot = createEmptySnapshot(tenantId, displayName, primaryWallet);
    
    // Add selected domains to notes
    const domains = [...selectedDomains];
    if (customDomain) {
      domains.push(customDomain);
    }
    
    if (domains.length > 0) {
      snapshot.profile.notes = `Tracking domains: ${domains.join(', ')}`;
    }
    
    onSnapshotCreated(snapshot);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Initialize New DataHub Snapshot</CardTitle>
        <CardDescription>
          Create a new unified data snapshot for your mini app ecosystem
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="tenantId">Tenant ID *</Label>
              <Input
                id="tenantId"
                value={tenantId}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTenantId(e.target.value)}
                placeholder="your-unique-id"
                required
              />
            </div>

            <div>
              <Label htmlFor="displayName">Display Name *</Label>
              <Input
                id="displayName"
                value={displayName}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setDisplayName(e.target.value)}
                placeholder="Your Name"
                required
              />
            </div>

            <div>
              <Label htmlFor="primaryWallet">Primary Wallet *</Label>
              <Input
                id="primaryWallet"
                value={primaryWallet}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPrimaryWallet(e.target.value)}
                placeholder="0x..."
                required
              />
            </div>
          </div>

          <div className="space-y-3">
            <Label>Domains to Track</Label>
            {DOMAIN_OPTIONS.map((domain: { id: string; label: string }) => (
              <div key={domain.id} className="flex items-center space-x-2">
                <Checkbox
                  id={domain.id}
                  checked={selectedDomains.includes(domain.id)}
                  onCheckedChange={() => handleDomainToggle(domain.id)}
                />
                <Label htmlFor={domain.id} className="font-normal cursor-pointer">
                  {domain.label}
                </Label>
              </div>
            ))}
            
            <div>
              <Label htmlFor="customDomain">Other (custom)</Label>
              <Input
                id="customDomain"
                value={customDomain}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCustomDomain(e.target.value)}
                placeholder="Custom domain..."
              />
            </div>
          </div>

          <Button type="submit" className="w-full">
            Create DataHub Snapshot
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
