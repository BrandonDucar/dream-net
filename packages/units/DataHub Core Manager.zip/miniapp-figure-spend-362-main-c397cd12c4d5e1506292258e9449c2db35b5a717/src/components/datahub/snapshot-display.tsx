'use client';

import { useState } from 'react';
import type { DataHubSnapshot } from '@/types/datahub';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';

interface SnapshotDisplayProps {
  snapshot: DataHubSnapshot;
}

export function SnapshotDisplay({ snapshot }: SnapshotDisplayProps): JSX.Element {
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopySnapshot = (): void => {
    const formattedSnapshot = JSON.stringify(snapshot, null, 2);
    navigator.clipboard.writeText(formattedSnapshot);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSnapshot = (): void => {
    const formattedSnapshot = JSON.stringify(snapshot, null, 2);
    const blob = new Blob([formattedSnapshot], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `datahub-snapshot-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>SUMMARY</CardTitle>
              <CardDescription>Current DataHub Snapshot Overview</CardDescription>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleCopySnapshot} variant="outline" size="sm">
                {copied ? 'Copied!' : 'Copy JSON'}
              </Button>
              <Button onClick={handleDownloadSnapshot} variant="outline" size="sm">
                Download
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ul className="list-disc list-inside space-y-2 text-sm">
            <li>Snapshot version: {snapshot.version}</li>
            <li>Tenant: {snapshot.tenant.display_name} ({snapshot.tenant.id})</li>
            <li>Primary wallet: {snapshot.tenant.primary_wallet}</li>
            <li>Last updated: {new Date(snapshot.last_updated).toLocaleString()}</li>
            <li>Wallets: {snapshot.wallets.length} entries</li>
            <li>Assets: {snapshot.assets.length} entries</li>
            <li>Metals: {snapshot.metals.length} entries</li>
            <li>Payments: {snapshot.payments.length} entries</li>
            <li>Automations: {snapshot.automations.length} entries</li>
            <li>Apps: {snapshot.apps.length} entries</li>
            <li>Campaigns: {snapshot.campaigns.length} entries</li>
            <li>Metrics: {snapshot.metrics.length} entries</li>
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>QUESTIONS</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600">None</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>DATAHUB_SNAPSHOT</CardTitle>
          <CardDescription>Complete canonical snapshot structure</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="overview">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="domains">Domains</TabsTrigger>
              <TabsTrigger value="json">Full JSON</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Tenant</h4>
                  <div className="text-sm space-y-1">
                    <p>ID: {snapshot.tenant.id}</p>
                    <p>Name: {snapshot.tenant.display_name}</p>
                    <p>Wallet: {snapshot.tenant.primary_wallet}</p>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">Profile</h4>
                  <div className="text-sm space-y-1">
                    <p>User: {snapshot.profile.user_name || 'Not set'}</p>
                    <p>Notes: {snapshot.profile.notes || 'None'}</p>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="domains" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                {[
                  { key: 'wallets', label: 'Wallets', count: snapshot.wallets.length },
                  { key: 'assets', label: 'Assets', count: snapshot.assets.length },
                  { key: 'metals', label: 'Metals', count: snapshot.metals.length },
                  { key: 'payments', label: 'Payments', count: snapshot.payments.length },
                  { key: 'automations', label: 'Automations', count: snapshot.automations.length },
                  { key: 'apps', label: 'Apps', count: snapshot.apps.length },
                  { key: 'campaigns', label: 'Campaigns', count: snapshot.campaigns.length },
                  { key: 'metrics', label: 'Metrics', count: snapshot.metrics.length },
                ].map(({ key, label, count }: { key: string; label: string; count: number }) => (
                  <div key={key} className="flex items-center justify-between p-3 border rounded">
                    <span className="font-medium">{label}</span>
                    <Badge variant="secondary">{count}</Badge>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="json">
              <ScrollArea className="h-96 w-full rounded border">
                <pre className="p-4 text-xs">
                  {JSON.stringify(snapshot, null, 2)}
                </pre>
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>UPDATE_NOTES</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600">Snapshot loaded and displayed successfully.</p>
        </CardContent>
      </Card>
    </div>
  );
}
