'use client';

import { useState } from 'react';
import type { DataHubSnapshot } from '@/types/datahub';
import { normalizeSnapshot, mergeSnapshots, validateSnapshot } from '@/lib/datahub-utils';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';

interface SnapshotImporterProps {
  onSnapshotImported: (snapshot: DataHubSnapshot) => void;
  existingSnapshot?: DataHubSnapshot | null;
}

export function SnapshotImporter({ onSnapshotImported, existingSnapshot }: SnapshotImporterProps): JSX.Element {
  const [inputText, setInputText] = useState<string>('');
  const [validationStatus, setValidationStatus] = useState<{
    isValid: boolean;
    message: string;
    notes: string[];
  } | null>(null);

  const handleImport = (): void => {
    try {
      const parsed = JSON.parse(inputText) as unknown;
      
      // Validate and normalize
      const isValid = validateSnapshot(parsed);
      const normalized = normalizeSnapshot(parsed);
      
      const notes: string[] = [];
      
      if (!isValid) {
        notes.push('Snapshot structure did not match canonical schema');
        notes.push('Applied automatic normalization to fix schema issues');
      }
      
      // If there's an existing snapshot, merge
      if (existingSnapshot) {
        const { merged, notes: mergeNotes } = mergeSnapshots(existingSnapshot, normalized);
        notes.push(...mergeNotes);
        
        setValidationStatus({
          isValid: true,
          message: 'Snapshot merged successfully',
          notes,
        });
        
        onSnapshotImported(merged);
      } else {
        setValidationStatus({
          isValid: true,
          message: 'Snapshot imported successfully',
          notes,
        });
        
        onSnapshotImported(normalized);
      }
      
      setInputText('');
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      setValidationStatus({
        isValid: false,
        message: `Failed to parse JSON: ${errorMessage}`,
        notes: ['Please ensure you are pasting valid JSON'],
      });
    }
  };

  const handleValidate = (): void => {
    try {
      const parsed = JSON.parse(inputText) as unknown;
      const isValid = validateSnapshot(parsed);
      
      if (isValid) {
        setValidationStatus({
          isValid: true,
          message: 'Snapshot structure is valid',
          notes: ['Schema matches canonical structure', 'Ready to import'],
        });
      } else {
        const normalized = normalizeSnapshot(parsed);
        const notes: string[] = [
          'Schema does not match canonical structure',
          'Normalization will be applied on import',
        ];
        
        // Check what normalizations would be applied
        if (!parsed || typeof parsed !== 'object') {
          notes.push('Input is not a valid object');
        } else {
          const obj = parsed as Record<string, unknown>;
          if (!obj.tenant) notes.push('Missing tenant field');
          if (!obj.wallets) notes.push('Missing or invalid wallets array');
          if (!obj.metals) notes.push('Missing or invalid metals array');
          if (!obj.payments) notes.push('Missing or invalid payments array');
        }
        
        setValidationStatus({
          isValid: false,
          message: 'Snapshot structure needs normalization',
          notes,
        });
      }
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      setValidationStatus({
        isValid: false,
        message: `Invalid JSON: ${errorMessage}`,
        notes: ['Please check your JSON syntax'],
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          {existingSnapshot ? 'Import and Merge Snapshot' : 'Load Existing Snapshot'}
        </CardTitle>
        <CardDescription>
          {existingSnapshot
            ? 'Paste a DataHub Snapshot to merge with the current snapshot'
            : 'Paste your existing DataHub Snapshot JSON here'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="snapshotInput">DataHub Snapshot JSON</Label>
          <Textarea
            id="snapshotInput"
            value={inputText}
            onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setInputText(e.target.value)}
            placeholder='{"version": "1.0", "tenant": {...}, ...}'
            className="font-mono text-xs min-h-48"
          />
        </div>

        <div className="flex gap-2">
          <Button onClick={handleValidate} variant="outline" disabled={!inputText}>
            Validate
          </Button>
          <Button onClick={handleImport} disabled={!inputText}>
            {existingSnapshot ? 'Import and Merge' : 'Import'}
          </Button>
        </div>

        {validationStatus && (
          <Alert variant={validationStatus.isValid ? 'default' : 'destructive'}>
            <AlertDescription>
              <div className="space-y-2">
                <p className="font-semibold">{validationStatus.message}</p>
                {validationStatus.notes.length > 0 && (
                  <ScrollArea className="h-32 w-full rounded border p-2 bg-white">
                    <ul className="list-disc list-inside space-y-1 text-sm">
                      {validationStatus.notes.map((note: string, index: number) => (
                        <li key={index}>{note}</li>
                      ))}
                    </ul>
                  </ScrollArea>
                )}
              </div>
            </AlertDescription>
          </Alert>
        )}

        <div className="mt-6 p-4 bg-gray-50 rounded border">
          <h4 className="font-semibold mb-2 text-sm">Integration Guide</h4>
          <p className="text-xs text-gray-700 mb-2">
            Other mini apps should follow this pattern when integrating with DataHub Node:
          </p>
          <ul className="list-disc list-inside space-y-1 text-xs text-gray-700">
            <li>Accept a DATAHUB_SNAPSHOT object as input</li>
            <li>Read only the sections relevant to your domain (e.g., metals, payments, campaigns)</li>
            <li>Modify only those sections as needed</li>
            <li>Output your normal result plus a full updated DATAHUB_SNAPSHOT using the same schema</li>
            <li>Never remove or rename top-level keys</li>
            <li>Never overwrite unrelated sections</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
