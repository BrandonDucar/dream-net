'use client';

import { useState } from 'react';
import type { DataHubSnapshot } from '@/types/datahub';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface TenantEditorProps {
  tenant: DataHubSnapshot['tenant'];
  profile: DataHubSnapshot['profile'];
  onTenantUpdate: (tenant: DataHubSnapshot['tenant']) => void;
  onProfileUpdate: (userName: string, notes: string) => void;
}

export function TenantEditor({
  tenant,
  profile,
  onTenantUpdate,
  onProfileUpdate,
}: TenantEditorProps): JSX.Element {
  const [tenantId, setTenantId] = useState<string>(tenant.id);
  const [displayName, setDisplayName] = useState<string>(tenant.display_name);
  const [primaryWallet, setPrimaryWallet] = useState<string>(tenant.primary_wallet);
  const [userName, setUserName] = useState<string>(profile.user_name);
  const [notes, setNotes] = useState<string>(profile.notes);

  const handleTenantSave = (): void => {
    onTenantUpdate({
      id: tenantId,
      display_name: displayName,
      primary_wallet: primaryWallet,
    });
  };

  const handleProfileSave = (): void => {
    onProfileUpdate(userName, notes);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Tenant Information</CardTitle>
          <CardDescription>Update tenant identification and primary wallet</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="tenantId">Tenant ID</Label>
            <Input
              id="tenantId"
              value={tenantId}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTenantId(e.target.value)}
            />
          </div>

          <div>
            <Label htmlFor="displayName">Display Name</Label>
            <Input
              id="displayName"
              value={displayName}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setDisplayName(e.target.value)}
            />
          </div>

          <div>
            <Label htmlFor="primaryWallet">Primary Wallet</Label>
            <Input
              id="primaryWallet"
              value={primaryWallet}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPrimaryWallet(e.target.value)}
            />
          </div>

          <Button onClick={handleTenantSave} className="w-full">
            Save Tenant Info
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Profile Information</CardTitle>
          <CardDescription>Update user profile and notes</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="userName">User Name</Label>
            <Input
              id="userName"
              value={userName}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setUserName(e.target.value)}
            />
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNotes(e.target.value)}
              rows={4}
            />
          </div>

          <Button onClick={handleProfileSave} className="w-full">
            Save Profile Info
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
