import type { DataHubSnapshot } from '@/types/datahub';

export function createEmptySnapshot(
  tenantId: string,
  displayName: string,
  primaryWallet: string
): DataHubSnapshot {
  return {
    version: '1.0',
    tenant: {
      id: tenantId,
      display_name: displayName,
      primary_wallet: primaryWallet,
    },
    last_updated: new Date().toISOString(),
    profile: {
      user_name: displayName,
      notes: '',
    },
    wallets: [],
    assets: [],
    metals: [],
    payments: [],
    automations: [],
    apps: [],
    campaigns: [],
    metrics: [],
    custom: {},
  };
}

export function validateSnapshot(data: unknown): data is DataHubSnapshot {
  if (typeof data !== 'object' || data === null) return false;
  
  const snapshot = data as Record<string, unknown>;
  
  // Check required top-level keys
  const requiredKeys = [
    'version',
    'tenant',
    'last_updated',
    'profile',
    'wallets',
    'assets',
    'metals',
    'payments',
    'automations',
    'apps',
    'campaigns',
    'metrics',
    'custom',
  ];
  
  for (const key of requiredKeys) {
    if (!(key in snapshot)) return false;
  }
  
  // Check tenant structure
  if (typeof snapshot.tenant !== 'object' || snapshot.tenant === null) return false;
  const tenant = snapshot.tenant as Record<string, unknown>;
  if (!tenant.id || !tenant.display_name || !tenant.primary_wallet) return false;
  
  // Check arrays
  const arrayKeys = ['wallets', 'assets', 'metals', 'payments', 'automations', 'apps', 'campaigns', 'metrics'];
  for (const key of arrayKeys) {
    if (!Array.isArray(snapshot[key])) return false;
  }
  
  return true;
}

export function normalizeSnapshot(data: unknown): DataHubSnapshot {
  if (validateSnapshot(data)) {
    const snapshot = data as DataHubSnapshot;
    snapshot.last_updated = new Date().toISOString();
    return snapshot;
  }
  
  // Attempt to normalize partial or misnamed data
  const normalized: DataHubSnapshot = {
    version: '1.0',
    tenant: {
      id: '',
      display_name: '',
      primary_wallet: '',
    },
    last_updated: new Date().toISOString(),
    profile: {
      user_name: '',
      notes: '',
    },
    wallets: [],
    assets: [],
    metals: [],
    payments: [],
    automations: [],
    apps: [],
    campaigns: [],
    metrics: [],
    custom: {},
  };
  
  if (typeof data !== 'object' || data === null) {
    return normalized;
  }
  
  const input = data as Record<string, unknown>;
  
  // Normalize version
  if (typeof input.version === 'string') {
    normalized.version = input.version;
  }
  
  // Normalize tenant
  if (typeof input.tenant === 'object' && input.tenant !== null) {
    const tenant = input.tenant as Record<string, unknown>;
    normalized.tenant = {
      id: String(tenant.id || ''),
      display_name: String(tenant.display_name || tenant.displayName || ''),
      primary_wallet: String(tenant.primary_wallet || tenant.primaryWallet || ''),
    };
  }
  
  // Normalize profile
  if (typeof input.profile === 'object' && input.profile !== null) {
    const profile = input.profile as Record<string, unknown>;
    normalized.profile = {
      user_name: String(profile.user_name || profile.userName || ''),
      notes: String(profile.notes || ''),
    };
  }
  
  // Normalize arrays with common naming variations
  const arrayMappings: Record<string, string[]> = {
    wallets: ['wallets', 'wallet_list'],
    assets: ['assets', 'asset_list'],
    metals: ['metals', 'metal_portfolio', 'metal_holdings'],
    payments: ['payments', 'payment_list', 'transactions'],
    automations: ['automations', 'automation_list', 'workflows'],
    apps: ['apps', 'app_list', 'applications'],
    campaigns: ['campaigns', 'campaign_list'],
    metrics: ['metrics', 'metric_list', 'kpis'],
  };
  
  for (const [canonicalKey, variations] of Object.entries(arrayMappings)) {
    for (const variation of variations) {
      if (Array.isArray(input[variation])) {
        normalized[canonicalKey as keyof DataHubSnapshot] = input[variation] as never;
        break;
      }
    }
  }
  
  // Normalize custom
  if (typeof input.custom === 'object' && input.custom !== null) {
    normalized.custom = input.custom as Record<string, unknown>;
  }
  
  return normalized;
}

export function mergeSnapshots(
  existing: DataHubSnapshot,
  incoming: DataHubSnapshot
): { merged: DataHubSnapshot; notes: string[] } {
  const notes: string[] = [];
  const merged: DataHubSnapshot = JSON.parse(JSON.stringify(existing)) as DataHubSnapshot;
  
  // Update timestamp
  merged.last_updated = new Date().toISOString();
  
  // Merge tenant (incoming takes precedence if fields are not empty)
  if (incoming.tenant.id && incoming.tenant.id !== existing.tenant.id) {
    merged.tenant.id = incoming.tenant.id;
    notes.push(`Updated tenant.id to: ${incoming.tenant.id}`);
  }
  if (incoming.tenant.display_name && incoming.tenant.display_name !== existing.tenant.display_name) {
    merged.tenant.display_name = incoming.tenant.display_name;
    notes.push(`Updated tenant.display_name to: ${incoming.tenant.display_name}`);
  }
  if (incoming.tenant.primary_wallet && incoming.tenant.primary_wallet !== existing.tenant.primary_wallet) {
    merged.tenant.primary_wallet = incoming.tenant.primary_wallet;
    notes.push(`Updated tenant.primary_wallet to: ${incoming.tenant.primary_wallet}`);
  }
  
  // Merge profile
  if (incoming.profile.user_name) {
    merged.profile.user_name = incoming.profile.user_name;
  }
  if (incoming.profile.notes) {
    merged.profile.notes = incoming.profile.notes;
  }
  
  // Merge arrays (add new items, update existing by id)
  const arrayKeys: Array<keyof DataHubSnapshot> = [
    'wallets',
    'assets',
    'metals',
    'payments',
    'automations',
    'apps',
    'campaigns',
    'metrics',
  ];
  
  for (const key of arrayKeys) {
    const existingArray = merged[key] as Array<{ id: string; [key: string]: unknown }>;
    const incomingArray = incoming[key] as Array<{ id: string; [key: string]: unknown }>;
    
    for (const incomingItem of incomingArray) {
      const existingIndex = existingArray.findIndex((item: { id: string }) => item.id === incomingItem.id);
      
      if (existingIndex >= 0) {
        // Update existing item
        existingArray[existingIndex] = { ...existingArray[existingIndex], ...incomingItem };
        notes.push(`Updated ${key} item: ${incomingItem.id}`);
      } else {
        // Add new item
        existingArray.push(incomingItem);
        notes.push(`Added new ${key} item: ${incomingItem.id}`);
      }
    }
  }
  
  // Merge custom (deep merge)
  merged.custom = { ...existing.custom, ...incoming.custom };
  if (Object.keys(incoming.custom).length > 0) {
    notes.push('Merged custom fields');
  }
  
  return { merged, notes };
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}
