export interface DataHubSnapshot {
  version: string;
  tenant: {
    id: string;
    display_name: string;
    primary_wallet: string;
  };
  last_updated: string;
  profile: {
    user_name: string;
    notes: string;
  };
  wallets: WalletEntry[];
  assets: AssetEntry[];
  metals: MetalEntry[];
  payments: PaymentEntry[];
  automations: AutomationEntry[];
  apps: AppEntry[];
  campaigns: CampaignEntry[];
  metrics: MetricEntry[];
  custom: Record<string, unknown>;
}

export interface WalletEntry {
  id: string;
  address: string;
  label?: string;
  chain?: string;
  balance?: string;
  notes?: string;
  [key: string]: unknown;
}

export interface AssetEntry {
  id: string;
  symbol: string;
  name?: string;
  amount?: string;
  value_usd?: string;
  wallet_id?: string;
  notes?: string;
  [key: string]: unknown;
}

export interface MetalEntry {
  id: string;
  metal_type: string;
  amount?: string;
  unit?: string;
  spot_price?: string;
  dealer?: string;
  notes?: string;
  [key: string]: unknown;
}

export interface PaymentEntry {
  id: string;
  type: string;
  amount?: string;
  currency?: string;
  from?: string;
  to?: string;
  status?: string;
  timestamp?: string;
  notes?: string;
  [key: string]: unknown;
}

export interface AutomationEntry {
  id: string;
  name: string;
  type?: string;
  trigger?: string;
  action?: string;
  status?: string;
  notes?: string;
  [key: string]: unknown;
}

export interface AppEntry {
  id: string;
  name: string;
  type?: string;
  status?: string;
  last_sync?: string;
  notes?: string;
  [key: string]: unknown;
}

export interface CampaignEntry {
  id: string;
  name: string;
  type?: string;
  status?: string;
  start_date?: string;
  end_date?: string;
  notes?: string;
  [key: string]: unknown;
}

export interface MetricEntry {
  id: string;
  name: string;
  value?: string;
  unit?: string;
  timestamp?: string;
  notes?: string;
  [key: string]: unknown;
}

export interface InitializationData {
  tenantId: string;
  displayName: string;
  primaryWallet: string;
  domains: string[];
}

export interface OutputStructure {
  summary: string[];
  questions: string[];
  snapshot: DataHubSnapshot;
  updateNotes: string[];
}
