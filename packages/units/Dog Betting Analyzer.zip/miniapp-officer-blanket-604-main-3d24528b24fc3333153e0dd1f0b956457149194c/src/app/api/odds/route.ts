import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'edge'

// Free tier API key placeholder - users can add their own from https://the-odds-api.com/
const ODDS_API_KEY = process.env.ODDS_API_KEY || 'demo_key'
const ODDS_API_BASE = 'https://api.the-odds-api.com/v4'

// Sport key mapping
const SPORT_KEY_MAP: Record<string, string> = {
  NFL: 'americanfootball_nfl',
  NCAAF: 'americanfootball_ncaaf',
  NBA: 'basketball_nba',
  NCAAB: 'basketball_ncaab',
  MLB: 'baseball_mlb',
  NHL: 'icehockey_nhl',
  SOCCER: 'soccer_epl', // Premier League as default
  UFC: 'mma_mixed_martial_arts',
}

export interface OddsAPIGame {
  id: string
  sport_key: string
  sport_title: string
  commence_time: string
  home_team: string
  away_team: string
  bookmakers: Array<{
    key: string
    title: string
    markets: Array<{
      key: string
      outcomes: Array<{
        name: string
        price: number
        point?: number
      }>
    }>
  }>
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const sport = searchParams.get('sport') || 'NFL'
    
    const sportKey = SPORT_KEY_MAP[sport as keyof typeof SPORT_KEY_MAP] || SPORT_KEY_MAP.NFL

    // Fetch odds from The Odds API
    const url = `${ODDS_API_BASE}/sports/${sportKey}/odds?apiKey=${ODDS_API_KEY}&regions=us&markets=h2h,spreads,totals&oddsFormat=american`

    const response = await fetch(url, {
      headers: {
        'Accept': 'application/json',
      },
    })

    if (!response.ok) {
      throw new Error(`Odds API error: ${response.status}`)
    }

    const data: OddsAPIGame[] = await response.json()

    // Transform to simpler format
    const games = data.map((game) => {
      const firstBookmaker = game.bookmakers[0]
      
      let spread = null
      let total = null
      let homeML = null
      let awayML = null

      if (firstBookmaker) {
        // Get H2H (moneyline)
        const h2h = firstBookmaker.markets.find((m) => m.key === 'h2h')
        if (h2h) {
          const homeOutcome = h2h.outcomes.find((o) => o.name === game.home_team)
          const awayOutcome = h2h.outcomes.find((o) => o.name === game.away_team)
          homeML = homeOutcome?.price || null
          awayML = awayOutcome?.price || null
        }

        // Get spreads
        const spreads = firstBookmaker.markets.find((m) => m.key === 'spreads')
        if (spreads) {
          const homeSpread = spreads.outcomes.find((o) => o.name === game.home_team)
          spread = homeSpread?.point || null
        }

        // Get totals
        const totals = firstBookmaker.markets.find((m) => m.key === 'totals')
        if (totals && totals.outcomes.length > 0) {
          total = totals.outcomes[0].point || null
        }
      }

      return {
        id: game.id,
        sport: sport,
        homeTeam: game.home_team,
        awayTeam: game.away_team,
        commenceTime: game.commence_time,
        homeML,
        awayML,
        spread,
        total,
        bookmaker: firstBookmaker?.title || 'N/A',
      }
    })

    return NextResponse.json({ games, count: games.length })
  } catch (error) {
    console.error('Odds API error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch odds', message: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
