import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { ResponseLogger } from "@/components/response-logger";
import { cookies } from "next/headers";
import { ReadyNotifier } from "@/components/ready-notifier";
import FarcasterWrapper from "@/components/FarcasterWrapper";

const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const requestId = cookies().get("x-request-id")?.value;

  return (
        <html lang="en">
          <head>
            {requestId && <meta name="x-request-id" content={requestId} />}
            <script
              type="application/ld+json"
              dangerouslySetInnerHTML={{
                __html: JSON.stringify({
                  "@context": "https://schema.org",
                  "@type": "WebApplication",
                  "name": "Live Dog Finder",
                  "description": "Sports betting analytics tool for calculating upset probabilities and finding value in underdogs",
                  "applicationCategory": "FinanceApplication",
                  "offers": {
                    "@type": "Offer",
                    "price": "0",
                    "priceCurrency": "USD"
                  },
                  "featureList": [
                    "Upset probability calculation",
                    "Fair price modeling",
                    "Live Dog Index scoring",
                    "Multi-sport support",
                    "Geofencing for responsible gambling"
                  ]
                })
              }}
            />
          </head>
          <body
            className={`${geistSans.variable} ${geistMono.variable} antialiased bg-slate-950 text-gray-100`}
          >
            <ReadyNotifier />
            
      <FarcasterWrapper>
        {children}
      </FarcasterWrapper>
      
            <ResponseLogger />
          </body>
        </html>
      );
}

export const metadata: Metadata = {
        title: "Dog Betting Analyzer",
        description: "Instantly analyze betting lines to find potential upsets. Calculate win probabilities, fair prices, and receive betting recommendations. Perfect for bettors seeking the edge.",
        other: { "fc:frame": JSON.stringify({"version":"next","imageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_99f52b20-87be-4479-ace1-a7da3b91bdd6-b2YGQtHnErEFkQfNkoy1mZM3yt2JSH","button":{"title":"Open with Ohara","action":{"type":"launch_frame","name":"Dog Betting Analyzer","url":"https://officer-blanket-604.app.ohara.ai","splashImageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/farcaster/splash_images/splash_image1.svg","splashBackgroundColor":"#ffffff"}}}
        ) }
    };
