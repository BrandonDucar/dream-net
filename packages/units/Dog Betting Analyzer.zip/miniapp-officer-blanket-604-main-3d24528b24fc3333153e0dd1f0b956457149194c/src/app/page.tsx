'use client'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Slider } from '@/components/ui/slider'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { GeofenceWarning } from '@/components/geofence-warning'
import { KellyCalculator } from '@/components/KellyCalculator'
import { ExportButtons } from '@/components/ExportButtons'
import { LineShoppingAssistant } from '@/components/LineShoppingAssistant'
import { ComparisonMode } from '@/components/ComparisonMode'
import { HistoryPanel } from '@/components/HistoryPanel'
import { ThemeToggle } from '@/components/ThemeToggle'
import { LiveOddsPanel } from '@/components/LiveOddsPanel'
import { PerformanceDashboard } from '@/components/PerformanceDashboard'
import { saveAnalysis } from '@/lib/localStorage'
import { 
  runUpsetEngine, 
  type GameInput, 
  type UpsetEngineResult, 
  type SportCode, 
  type OddsFormat 
} from '@/lib/upset'
import { TrendingUp, AlertCircle, Target, Zap } from 'lucide-react'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function LiveDogFinder() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [gameInput, setGameInput] = useState<GameInput>({
    sport: 'NFL',
    homeTeam: '',
    awayTeam: '',
    favoriteSide: 'home',
    spread: null,
    total: null,
    favMoneylineFormat: 'american',
    favMoneylineOdds: null,
    dogMoneylineFormat: 'american',
    dogMoneylineOdds: null,
    dogForm: 50,
    favForm: 50,
    variance: 50,
  })

  const [result, setResult] = useState<UpsetEngineResult | null>(null)
  const [comparisonGames, setComparisonGames] = useState<UpsetEngineResult[]>([])
  const [activeTab, setActiveTab] = useState('analysis')

  const handleRunEngine = () => {
    if (!gameInput.homeTeam || !gameInput.awayTeam) {
      alert('Please enter both team names')
      return
    }
    
    const engineResult = runUpsetEngine(gameInput)
    setResult(engineResult)
    saveAnalysis(engineResult)

    // Show notification for high-value dogs
    if (engineResult.liveDogIndex > 70 && 'Notification' in window && Notification.permission === 'granted') {
      new Notification('🔥 High-Value Dog Alert!', {
        body: `${engineResult.dogLabel} has a Live Dog Index of ${engineResult.liveDogIndex.toFixed(1)} (${engineResult.valueGrade}-tier)`,
        icon: '/icon.png'
      })
    }
  }

  const handleAddToComparison = () => {
    if (result && !comparisonGames.find(g => g.dogLabel === result.dogLabel && g.favLabel === result.favLabel)) {
      setComparisonGames([...comparisonGames, result])
      setActiveTab('compare')
    }
  }

  const handleRemoveFromComparison = (index: number) => {
    setComparisonGames(comparisonGames.filter((_, i) => i !== index))
  }

  const handleClearComparison = () => {
    setComparisonGames([])
  }

  // Request notification permission on mount
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission()
    }
  }, [])

  const getAngleBadgeColor = (angle: string) => {
    const colors: Record<string, string> = {
      DOG_ML: 'bg-green-600/20 text-green-300 border-green-600/50',
      DOG_SPREAD: 'bg-blue-600/20 text-blue-300 border-blue-600/50',
      FAVE: 'bg-gray-600/20 text-gray-300 border-gray-600/50',
      PASS: 'bg-amber-600/20 text-amber-300 border-amber-600/50',
    }
    return colors[angle] || colors.PASS
  }

  const getAngleLabel = (angle: string) => {
    const labels: Record<string, string> = {
      DOG_ML: 'Moneyline dog shot',
      DOG_SPREAD: 'Points > ML',
      FAVE: 'Favorite has real edge',
      PASS: 'Pass / Sharp price',
    }
    return labels[angle] || 'Unknown'
  }

  const getGradeColor = (grade: string) => {
    const colors: Record<string, string> = {
      S: 'text-purple-400',
      A: 'text-green-400',
      B: 'text-blue-400',
      C: 'text-yellow-400',
      F: 'text-red-400',
    }
    return colors[grade] || colors.F
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2 py-8">
          <div className="flex items-center justify-center gap-4">
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Live Dog Finder
            </h1>
            <ThemeToggle />
          </div>
          <p className="text-slate-400 text-lg">
            Is this dog actually live or just a corpse? Let the engine decide.
          </p>
        </div>

        {/* Geofence Warning */}
        <GeofenceWarning />

        {/* Tabs Navigation */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 bg-slate-800/50 border border-slate-700">
            <TabsTrigger value="analysis" className="text-slate-300 data-[state=active]:text-white">
              Analysis
            </TabsTrigger>
            <TabsTrigger value="compare" className="text-slate-300 data-[state=active]:text-white">
              Compare {comparisonGames.length > 0 && `(${comparisonGames.length})`}
            </TabsTrigger>
            <TabsTrigger value="shopping" className="text-slate-300 data-[state=active]:text-white">
              Line Shopping
            </TabsTrigger>
            <TabsTrigger value="performance" className="text-slate-300 data-[state=active]:text-white">
              Performance
            </TabsTrigger>
            <TabsTrigger value="history" className="text-slate-300 data-[state=active]:text-white">
              History
            </TabsTrigger>
          </TabsList>

          {/* Analysis Tab */}
          <TabsContent value="analysis" className="mt-6">
            {/* Live Odds Panel */}
            <div className="mb-6">
              <LiveOddsPanel 
                sport={gameInput.sport}
                onSelectGame={(game) => setGameInput({ ...gameInput, ...game })}
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* INPUT PANEL */}
          <div className="space-y-6">
            {/* Game Info */}
            <Card className="bg-slate-900/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-cyan-400" />
                  Game Info
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Basic matchup details
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="sport" className="text-slate-300">Sport</Label>
                  <Select
                    value={gameInput.sport}
                    onValueChange={(value: SportCode) => setGameInput({ ...gameInput, sport: value })}
                  >
                    <SelectTrigger id="sport" className="bg-slate-800 border-slate-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-600">
                      <SelectItem value="NFL">NFL</SelectItem>
                      <SelectItem value="NCAAF">NCAAF</SelectItem>
                      <SelectItem value="NBA">NBA</SelectItem>
                      <SelectItem value="NCAAB">NCAAB</SelectItem>
                      <SelectItem value="MLB">MLB</SelectItem>
                      <SelectItem value="NHL">NHL</SelectItem>
                      <SelectItem value="SOCCER">Soccer</SelectItem>
                      <SelectItem value="UFC">UFC</SelectItem>
                      <SelectItem value="OTHER">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="homeTeam" className="text-slate-300">Home Team</Label>
                    <Input
                      id="homeTeam"
                      value={gameInput.homeTeam}
                      onChange={(e) => setGameInput({ ...gameInput, homeTeam: e.target.value })}
                      placeholder="e.g. Patriots"
                      className="bg-slate-800 border-slate-600 text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="awayTeam" className="text-slate-300">Away Team</Label>
                    <Input
                      id="awayTeam"
                      value={gameInput.awayTeam}
                      onChange={(e) => setGameInput({ ...gameInput, awayTeam: e.target.value })}
                      placeholder="e.g. Bills"
                      className="bg-slate-800 border-slate-600 text-white"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="favSide" className="text-slate-300">Favorite Side</Label>
                  <Select
                    value={gameInput.favoriteSide}
                    onValueChange={(value: 'home' | 'away') => setGameInput({ ...gameInput, favoriteSide: value })}
                  >
                    <SelectTrigger id="favSide" className="bg-slate-800 border-slate-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-600">
                      <SelectItem value="home">Home</SelectItem>
                      <SelectItem value="away">Away</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Market Lines */}
            <Card className="bg-slate-900/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-green-400" />
                  Market Lines
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Spread and total from favorite&apos;s perspective
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="spread" className="text-slate-300">Spread (Fav POV)</Label>
                    <Input
                      id="spread"
                      type="number"
                      step="0.5"
                      value={gameInput.spread ?? ''}
                      onChange={(e) => setGameInput({ ...gameInput, spread: e.target.value ? parseFloat(e.target.value) : null })}
                      placeholder="e.g. -6.5"
                      className="bg-slate-800 border-slate-600 text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="total" className="text-slate-300">Total (optional)</Label>
                    <Input
                      id="total"
                      type="number"
                      step="0.5"
                      value={gameInput.total ?? ''}
                      onChange={(e) => setGameInput({ ...gameInput, total: e.target.value ? parseFloat(e.target.value) : null })}
                      placeholder="e.g. 47.5"
                      className="bg-slate-800 border-slate-600 text-white"
                    />
                  </div>
                </div>

                {/* Favorite Moneyline */}
                <div className="space-y-2">
                  <Label className="text-slate-300">Favorite Moneyline</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <Select
                      value={gameInput.favMoneylineFormat}
                      onValueChange={(value: OddsFormat) => setGameInput({ ...gameInput, favMoneylineFormat: value })}
                    >
                      <SelectTrigger className="bg-slate-800 border-slate-600">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-600">
                        <SelectItem value="american">American</SelectItem>
                        <SelectItem value="decimal">Decimal</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      type="number"
                      step="1"
                      value={gameInput.favMoneylineOdds ?? ''}
                      onChange={(e) => setGameInput({ ...gameInput, favMoneylineOdds: e.target.value ? parseFloat(e.target.value) : null })}
                      placeholder={gameInput.favMoneylineFormat === 'american' ? '-220' : '1.45'}
                      className="bg-slate-800 border-slate-600 text-white"
                    />
                  </div>
                </div>

                {/* Dog Moneyline */}
                <div className="space-y-2">
                  <Label className="text-slate-300">Dog Moneyline</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <Select
                      value={gameInput.dogMoneylineFormat}
                      onValueChange={(value: OddsFormat) => setGameInput({ ...gameInput, dogMoneylineFormat: value })}
                    >
                      <SelectTrigger className="bg-slate-800 border-slate-600">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-600">
                        <SelectItem value="american">American</SelectItem>
                        <SelectItem value="decimal">Decimal</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      type="number"
                      step="1"
                      value={gameInput.dogMoneylineOdds ?? ''}
                      onChange={(e) => setGameInput({ ...gameInput, dogMoneylineOdds: e.target.value ? parseFloat(e.target.value) : null })}
                      placeholder={gameInput.dogMoneylineFormat === 'american' ? '+180' : '2.80'}
                      className="bg-slate-800 border-slate-600 text-white"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Narrative Sliders */}
            <Card className="bg-slate-900/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-purple-400" />
                  Narrative & Volatility
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Adjust form and variance expectations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label className="text-slate-300">Dog Form</Label>
                    <span className="text-slate-400 text-sm">{gameInput.dogForm}</span>
                  </div>
                  <Slider
                    value={[gameInput.dogForm]}
                    onValueChange={(value) => setGameInput({ ...gameInput, dogForm: value[0] })}
                    min={0}
                    max={100}
                    step={1}
                    className="py-2"
                  />
                  <div className="flex justify-between text-xs text-slate-500">
                    <span>Ice cold</span>
                    <span>Red hot</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label className="text-slate-300">Favorite Form</Label>
                    <span className="text-slate-400 text-sm">{gameInput.favForm}</span>
                  </div>
                  <Slider
                    value={[gameInput.favForm]}
                    onValueChange={(value) => setGameInput({ ...gameInput, favForm: value[0] })}
                    min={0}
                    max={100}
                    step={1}
                    className="py-2"
                  />
                  <div className="flex justify-between text-xs text-slate-500">
                    <span>Ice cold</span>
                    <span>Red hot</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label className="text-slate-300">Game Volatility</Label>
                    <span className="text-slate-400 text-sm">{gameInput.variance}</span>
                  </div>
                  <Slider
                    value={[gameInput.variance]}
                    onValueChange={(value) => setGameInput({ ...gameInput, variance: value[0] })}
                    min={0}
                    max={100}
                    step={1}
                    className="py-2"
                  />
                  <div className="flex justify-between text-xs text-slate-500">
                    <span>Low blowouts</span>
                    <span>High chaos</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Button 
              onClick={handleRunEngine}
              className="w-full bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white font-semibold py-6 text-lg"
            >
              Run Upset Engine
            </Button>
          </div>

          {/* OUTPUT PANEL */}
          <div className="space-y-6">
            {result ? (
              <>
                {/* Hero Card */}
                <Card className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 border-slate-700">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-2xl">Upset Analysis</CardTitle>
                      <Badge className={`text-2xl font-bold px-4 py-2 ${getGradeColor(result.valueGrade)}`}>
                        {result.valueGrade}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <p className="text-slate-400 text-sm">Favorite</p>
                        <p className="text-xl font-bold text-white">{result.favLabel}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Dog</p>
                        <p className="text-xl font-bold text-white">{result.dogLabel}</p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="text-slate-300">Upset Probability</span>
                          <span className="text-green-400 font-bold text-lg">
                            {(result.modelDogProb * 100).toFixed(1)}%
                          </span>
                        </div>
                        <Progress 
                          value={result.modelDogProb * 100} 
                          className="h-3 bg-slate-700"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="text-slate-300">Live Dog Index</span>
                          <span className="text-cyan-400 font-bold text-lg">
                            {result.liveDogIndex.toFixed(1)} / 100
                          </span>
                        </div>
                        <Progress 
                          value={result.liveDogIndex} 
                          className="h-3 bg-slate-700"
                        />
                      </div>
                    </div>

                    <div className="pt-4 border-t border-slate-700">
                      <p className="text-slate-400 text-sm mb-2">Suggested Angle</p>
                      <Badge className={`${getAngleBadgeColor(result.suggestedAngle)} text-base px-4 py-2 border`}>
                        {getAngleLabel(result.suggestedAngle)}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                {/* Kelly Calculator */}
                <KellyCalculator 
                  fairDecimalOdds={result.fairDogDecimal}
                  bookDecimalOdds={gameInput.dogMoneylineOdds && gameInput.dogMoneylineFormat === 'decimal' 
                    ? gameInput.dogMoneylineOdds 
                    : gameInput.dogMoneylineOdds && gameInput.dogMoneylineFormat === 'american'
                    ? (gameInput.dogMoneylineOdds > 0 ? 1 + gameInput.dogMoneylineOdds / 100 : 1 + 100 / Math.abs(gameInput.dogMoneylineOdds))
                    : result.fairDogDecimal}
                />

                {/* Export Buttons & Add to Comparison */}
                <Card className="bg-slate-900/50 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-lg">Export & Share</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <ExportButtons result={result} />
                    <Button
                      onClick={handleAddToComparison}
                      variant="outline"
                      className="w-full border-cyan-600 text-cyan-400 hover:bg-cyan-900/20"
                      disabled={comparisonGames.some(g => g.dogLabel === result.dogLabel && g.favLabel === result.favLabel)}
                    >
                      {comparisonGames.some(g => g.dogLabel === result.dogLabel && g.favLabel === result.favLabel)
                        ? '✓ Added to Comparison'
                        : '+ Add to Comparison'}
                    </Button>
                  </CardContent>
                </Card>

                {/* Model vs Market */}
                <Card className="bg-slate-900/50 border-slate-700">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <AlertCircle className="h-5 w-5 text-yellow-400" />
                      Model vs Market
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <p className="text-slate-400 text-sm">Model Fair Price</p>
                        <p className="text-white font-mono text-lg">
                          {result.fairDogAmerican > 0 ? '+' : ''}{result.fairDogAmerican}
                        </p>
                        <p className="text-slate-500 text-xs">
                          ({result.fairDogDecimal.toFixed(2)} decimal)
                        </p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-slate-400 text-sm">Book Dog Price</p>
                        <p className="text-white font-mono text-lg">
                          {gameInput.dogMoneylineOdds !== null 
                            ? (gameInput.dogMoneylineFormat === 'american' 
                              ? (gameInput.dogMoneylineOdds > 0 ? '+' : '') + gameInput.dogMoneylineOdds
                              : gameInput.dogMoneylineOdds.toFixed(2))
                            : 'N/A'}
                        </p>
                        <p className="text-slate-500 text-xs">
                          {result.dogProbFromMoneyline 
                            ? `(${(result.dogProbFromMoneyline * 100).toFixed(1)}% implied)`
                            : ''}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Spread / ML Relationship */}
                {result.baseFavProbFromSpread && result.favProbFromMoneyline && (
                  <Card className="bg-slate-900/50 border-slate-700">
                    <CardHeader>
                      <CardTitle>Spread / ML Relationship</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Spread-based fav win prob:</span>
                        <span className="text-white font-mono">
                          {(result.baseFavProbFromSpread * 100).toFixed(1)}%
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">ML-based fav win prob:</span>
                        <span className="text-white font-mono">
                          {(result.favProbFromMoneyline * 100).toFixed(1)}%
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Blended model fav prob:</span>
                        <span className="text-white font-mono font-bold">
                          {(result.modelFavProb * 100).toFixed(1)}%
                        </span>
                      </div>
                      <p className="text-slate-500 text-xs pt-2 border-t border-slate-700">
                        Bigger gap → more suspicious line / mispricing
                      </p>
                    </CardContent>
                  </Card>
                )}

                {/* Narrative Notes */}
                <Card className="bg-slate-900/50 border-slate-700">
                  <CardHeader>
                    <CardTitle>Narrative & Analysis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm text-slate-300">
                      {result.notes.map((note, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="text-cyan-400 mt-1">•</span>
                          <span>{note}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                {/* Disclaimer */}
                <Card className="bg-amber-950/20 border-amber-800/50">
                  <CardContent className="pt-6">
                    <p className="text-amber-200/80 text-xs leading-relaxed">
                      <strong>Disclaimer:</strong> This tool is for educational and entertainment purposes only. 
                      No model or algorithm can predict sports outcomes with certainty. 
                      Always gamble responsibly and within your means. If you or someone you know has a gambling problem, 
                      call 1-800-GAMBLER.
                    </p>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card className="bg-slate-900/50 border-slate-700">
                <CardContent className="py-24 text-center">
                  <AlertCircle className="h-16 w-16 text-slate-600 mx-auto mb-4" />
                  <p className="text-slate-400 text-lg">
                    Enter game details and run the engine to see analysis
                  </p>
                </CardContent>
              </Card>
            )}
            </div>
          </div>
          </TabsContent>

          {/* Compare Tab */}
          <TabsContent value="compare" className="mt-6">
            <ComparisonMode 
              games={comparisonGames}
              onRemove={handleRemoveFromComparison}
              onClear={handleClearComparison}
            />
          </TabsContent>

          {/* Line Shopping Tab */}
          <TabsContent value="shopping" className="mt-6">
            <LineShoppingAssistant />
          </TabsContent>

          {/* Performance Tab */}
          <TabsContent value="performance" className="mt-6">
            <PerformanceDashboard />
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history" className="mt-6">
            <HistoryPanel />
          </TabsContent>
        </Tabs>

        {/* Footer */}
        <div className="text-center py-8 text-slate-500 text-sm">
          <p>Live Dog Finder • Analytics Only • No Betting Functionality</p>
          <p className="mt-2">For entertainment and educational purposes only</p>
        </div>
      </div>
    </div>
  )
}
