'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Button } from '@/components/ui/button'
import type { UpsetEngineResult } from '@/lib/upset'

type ComparisonModeProps = {
  games: UpsetEngineResult[]
  onRemove: (index: number) => void
  onClear: () => void
}

export function ComparisonMode({
  games,
  onRemove,
  onClear,
}: ComparisonModeProps) {
  if (games.length === 0) {
    return (
      <Card className="bg-slate-900/50 border-slate-700">
        <CardContent className="p-8 text-center">
          <p className="text-slate-300">
            No games added to comparison yet. Run an analysis and click "Add to
            Comparison" to get started.
          </p>
        </CardContent>
      </Card>
    )
  }

  const checkCorrelation = (game1: UpsetEngineResult, game2: UpsetEngineResult): string => {
    if (
      game1.favLabel === game2.favLabel ||
      game1.favLabel === game2.dogLabel ||
      game1.dogLabel === game2.favLabel ||
      game1.dogLabel === game2.dogLabel
    ) {
      return 'HIGH'
    }
    if (game1.sport === game2.sport) {
      return 'MEDIUM'
    }
    return 'LOW'
  }

  const hasHighCorrelation = games.length > 1 && games.some((g1, i) =>
    games.slice(i + 1).some((g2) => checkCorrelation(g1, g2) === 'HIGH')
  )

  return (
    <Card className="bg-slate-900/50 border-slate-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white">
            Comparison Mode ({games.length} games)
          </CardTitle>
          <Button
            onClick={onClear}
            variant="outline"
            size="sm"
            className="border-slate-600 text-white hover:bg-slate-800"
          >
            Clear All
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {hasHighCorrelation && (
          <div className="p-3 bg-amber-900/20 rounded border border-amber-700">
            <div className="text-sm text-amber-300 font-semibold">
              ⚠️ High Correlation Detected
            </div>
            <div className="text-sm text-slate-300 mt-1">
              Parlaying these games reduces true odds due to correlation. Consider betting them separately or diversifying.
            </div>
          </div>
        )}

        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-slate-700">
                <TableHead className="text-slate-200">Game</TableHead>
                <TableHead className="text-slate-200">Dog</TableHead>
                <TableHead className="text-slate-200">Upset %</TableHead>
                <TableHead className="text-slate-200">LDI</TableHead>
                <TableHead className="text-slate-200">Grade</TableHead>
                <TableHead className="text-slate-200">Fair Price</TableHead>
                <TableHead className="text-slate-200">Angle</TableHead>
                <TableHead className="text-slate-200"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {games.map((game, idx) => (
                <TableRow key={idx} className="border-slate-700">
                  <TableCell className="text-slate-100">
                    <div className="font-medium">{game.sport}</div>
                    <div className="text-xs text-slate-300">
                      {game.favLabel} vs {game.dogLabel}
                    </div>
                  </TableCell>
                  <TableCell className="text-slate-100 font-semibold">
                    {game.dogLabel}
                  </TableCell>
                  <TableCell className="text-slate-100">
                    <span className="text-green-400 font-bold">
                      {(game.modelDogProb * 100).toFixed(1)}%
                    </span>
                  </TableCell>
                  <TableCell className="text-slate-100">
                    <span className="text-cyan-400 font-bold">
                      {game.liveDogIndex.toFixed(1)}
                    </span>
                  </TableCell>
                  <TableCell>
                    <span
                      className={`px-2 py-1 rounded text-xs font-bold ${
                        game.valueGrade === 'S'
                          ? 'bg-purple-900/50 text-purple-300'
                          : game.valueGrade === 'A'
                          ? 'bg-green-900/50 text-green-300'
                          : game.valueGrade === 'B'
                          ? 'bg-blue-900/50 text-blue-300'
                          : game.valueGrade === 'C'
                          ? 'bg-yellow-900/50 text-yellow-300'
                          : 'bg-red-900/50 text-red-300'
                      }`}
                    >
                      {game.valueGrade}
                    </span>
                  </TableCell>
                  <TableCell className="text-slate-100">
                    <div className="text-sm">
                      {game.fairDogAmerican > 0 ? '+' : ''}
                      {game.fairDogAmerican}
                    </div>
                    <div className="text-xs text-slate-300">
                      {game.fairDogDecimal.toFixed(2)}
                    </div>
                  </TableCell>
                  <TableCell>
                    <span
                      className={`px-2 py-1 rounded text-xs font-semibold ${
                        game.suggestedAngle === 'DOG_ML'
                          ? 'bg-green-900/50 text-green-300'
                          : game.suggestedAngle === 'DOG_SPREAD'
                          ? 'bg-blue-900/50 text-blue-300'
                          : game.suggestedAngle === 'FAVE'
                          ? 'bg-slate-700 text-slate-300'
                          : 'bg-amber-900/50 text-amber-300'
                      }`}
                    >
                      {game.suggestedAngle.replace('_', ' ')}
                    </span>
                  </TableCell>
                  <TableCell>
                    <Button
                      onClick={() => onRemove(idx)}
                      variant="ghost"
                      size="sm"
                      className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                    >
                      Remove
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {games.length > 1 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            <div className="p-3 bg-slate-800/50 rounded border border-slate-700">
              <div className="text-xs text-slate-300 uppercase">
                Avg Upset %
              </div>
              <div className="text-2xl font-bold text-green-400 mt-1">
                {(
                  games.reduce((sum, g) => sum + g.modelDogProb * 100, 0) /
                  games.length
                ).toFixed(1)}
                %
              </div>
            </div>

            <div className="p-3 bg-slate-800/50 rounded border border-slate-700">
              <div className="text-xs text-slate-300 uppercase">Avg LDI</div>
              <div className="text-2xl font-bold text-cyan-400 mt-1">
                {(
                  games.reduce((sum, g) => sum + g.liveDogIndex, 0) /
                  games.length
                ).toFixed(1)}
              </div>
            </div>

            <div className="p-3 bg-slate-800/50 rounded border border-slate-700">
              <div className="text-xs text-slate-300 uppercase">
                Grade Distribution
              </div>
              <div className="text-sm text-slate-300 mt-1">
                {['S', 'A', 'B', 'C', 'F'].map((grade) => {
                  const count = games.filter((g) => g.valueGrade === grade).length
                  return count > 0 ? `${grade}: ${count}  ` : ''
                })}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
