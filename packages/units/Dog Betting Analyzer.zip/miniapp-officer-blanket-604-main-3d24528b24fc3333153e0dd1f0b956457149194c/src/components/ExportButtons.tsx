'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import type { UpsetEngineResult } from '@/lib/upset';
import { exportAsJSON, exportAsCSV, shareAnalysis, copyToClipboard } from '@/lib/export';

interface ExportButtonsProps {
  result: UpsetEngineResult;
}

export function ExportButtons({ result }: ExportButtonsProps) {
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopy = async () => {
    const success = await copyToClipboard(result);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleShare = async () => {
    await shareAnalysis(result);
  };

  return (
    <div className="flex flex-wrap gap-2">
      <Button
        onClick={() => exportAsJSON(result)}
        variant="outline"
        size="sm"
        className="bg-slate-800 border-slate-600 text-white hover:bg-slate-700"
      >
        📄 Export JSON
      </Button>
      
      <Button
        onClick={() => exportAsCSV(result)}
        variant="outline"
        size="sm"
        className="bg-slate-800 border-slate-600 text-white hover:bg-slate-700"
      >
        📊 Export CSV
      </Button>

      <Button
        onClick={handleCopy}
        variant="outline"
        size="sm"
        className="bg-slate-800 border-slate-600 text-white hover:bg-slate-700"
      >
        {copied ? '✓ Copied!' : '📋 Copy Summary'}
      </Button>

      {typeof navigator !== 'undefined' && navigator.share && (
        <Button
          onClick={handleShare}
          variant="outline"
          size="sm"
          className="bg-slate-800 border-slate-600 text-white hover:bg-slate-700"
        >
          🔗 Share
        </Button>
      )}
    </div>
  );
}
