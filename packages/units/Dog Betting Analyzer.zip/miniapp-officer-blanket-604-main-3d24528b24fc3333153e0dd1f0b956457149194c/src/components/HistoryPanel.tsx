'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import type { SavedAnalysis } from '@/lib/localStorage'
import { getHistory, clearHistory, deleteAnalysis } from '@/lib/localStorage'

export function HistoryPanel() {
  const [history, setHistory] = useState<SavedAnalysis[]>([])

  const loadHistory = (): void => {
    setHistory(getHistory())
  }

  useEffect(() => {
    loadHistory()
  }, [])

  const handleClear = (): void => {
    if (confirm('Clear all saved analyses?')) {
      clearHistory()
      loadHistory()
    }
  }

  const handleDelete = (id: string): void => {
    deleteAnalysis(id)
    loadHistory()
  }

  if (history.length === 0) {
    return (
      <Card className="bg-slate-900/50 border-slate-700">
        <CardContent className="p-8 text-center">
          <p className="text-slate-300">
            No saved analyses yet. Your analysis history will appear here.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-slate-900/50 border-slate-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white">
            Analysis History ({history.length})
          </CardTitle>
          <Button
            onClick={handleClear}
            variant="outline"
            size="sm"
            className="border-slate-600 text-white hover:bg-slate-800"
          >
            Clear All
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-slate-700">
                <TableHead className="text-slate-200">Date</TableHead>
                <TableHead className="text-slate-200">Game</TableHead>
                <TableHead className="text-slate-200">Dog</TableHead>
                <TableHead className="text-slate-200">Upset %</TableHead>
                <TableHead className="text-slate-200">LDI</TableHead>
                <TableHead className="text-slate-200">Grade</TableHead>
                <TableHead className="text-slate-200">Angle</TableHead>
                <TableHead className="text-slate-200"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {history.map((entry) => {
                const date = new Date(entry.timestamp)
                const { result } = entry
                
                return (
                  <TableRow key={entry.id} className="border-slate-700">
                    <TableCell className="text-slate-100">
                      <div className="text-sm">
                        {date.toLocaleDateString()}
                      </div>
                      <div className="text-xs text-slate-300">
                        {date.toLocaleTimeString()}
                      </div>
                    </TableCell>
                    <TableCell className="text-slate-100">
                      <div className="font-medium">{result.sport}</div>
                      <div className="text-xs text-slate-300">
                        {result.favLabel} vs {result.dogLabel}
                      </div>
                    </TableCell>
                    <TableCell className="text-slate-100 font-semibold">
                      {result.dogLabel}
                    </TableCell>
                    <TableCell className="text-slate-100">
                      <span className="text-green-400 font-bold">
                        {(result.modelDogProb * 100).toFixed(1)}%
                      </span>
                    </TableCell>
                    <TableCell className="text-slate-100">
                      <span className="text-cyan-400 font-bold">
                        {result.liveDogIndex.toFixed(1)}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span
                        className={`px-2 py-1 rounded text-xs font-bold ${
                          result.valueGrade === 'S'
                            ? 'bg-purple-900/50 text-purple-300'
                            : result.valueGrade === 'A'
                            ? 'bg-green-900/50 text-green-300'
                            : result.valueGrade === 'B'
                            ? 'bg-blue-900/50 text-blue-300'
                            : result.valueGrade === 'C'
                            ? 'bg-yellow-900/50 text-yellow-300'
                            : 'bg-red-900/50 text-red-300'
                        }`}
                      >
                        {result.valueGrade}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span
                        className={`px-2 py-1 rounded text-xs font-semibold ${
                          result.suggestedAngle === 'DOG_ML'
                            ? 'bg-green-900/50 text-green-300'
                            : result.suggestedAngle === 'DOG_SPREAD'
                            ? 'bg-blue-900/50 text-blue-300'
                            : result.suggestedAngle === 'FAVE'
                            ? 'bg-slate-700 text-slate-300'
                            : 'bg-amber-900/50 text-amber-300'
                        }`}
                      >
                        {result.suggestedAngle.replace('_', ' ')}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Button
                        onClick={() => handleDelete(entry.id)}
                        variant="ghost"
                        size="sm"
                        className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                      >
                        Delete
                      </Button>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-6">
          <div className="p-3 bg-slate-800/50 rounded border border-slate-700">
            <div className="text-xs text-slate-300 uppercase">
              Total Analyses
            </div>
            <div className="text-2xl font-bold text-white mt-1">
              {history.length}
            </div>
          </div>

          <div className="p-3 bg-slate-800/50 rounded border border-slate-700">
            <div className="text-xs text-slate-300 uppercase">
              Avg Upset %
            </div>
            <div className="text-2xl font-bold text-green-400 mt-1">
              {(
                history.reduce(
                  (sum, h) => sum + h.result.modelDogProb * 100,
                  0
                ) / history.length
              ).toFixed(1)}
              %
            </div>
          </div>

          <div className="p-3 bg-slate-800/50 rounded border border-slate-700">
            <div className="text-xs text-slate-300 uppercase">Avg LDI</div>
            <div className="text-2xl font-bold text-cyan-400 mt-1">
              {(
                history.reduce((sum, h) => sum + h.result.liveDogIndex, 0) /
                history.length
              ).toFixed(1)}
            </div>
          </div>

          <div className="p-3 bg-slate-800/50 rounded border border-slate-700">
            <div className="text-xs text-slate-300 uppercase">
              S/A Tier Count
            </div>
            <div className="text-2xl font-bold text-purple-400 mt-1">
              {
                history.filter(
                  (h) =>
                    h.result.valueGrade === 'S' ||
                    h.result.valueGrade === 'A'
                ).length
              }
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
