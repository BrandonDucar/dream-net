'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { calculateKelly, type KellyResult } from '@/lib/kelly';

interface KellyCalculatorProps {
  fairDecimalOdds: number;
  bookDecimalOdds: number;
}

export function KellyCalculator({ fairDecimalOdds, bookDecimalOdds }: KellyCalculatorProps) {
  const [bankroll, setBankroll] = useState<number>(1000);
  const [kelly, setKelly] = useState<KellyResult | null>(null);

  const handleCalculate = () => {
    const result = calculateKelly(bankroll, fairDecimalOdds, bookDecimalOdds);
    setKelly(result);
  };

  // Auto-calculate when inputs change
  const handleBankrollChange = (value: string) => {
    const num = parseFloat(value) || 0;
    setBankroll(num);
    if (num > 0) {
      const result = calculateKelly(num, fairDecimalOdds, bookDecimalOdds);
      setKelly(result);
    }
  };

  // Calculate on mount
  if (!kelly && bankroll > 0) {
    handleCalculate();
  }

  return (
    <Card className="bg-slate-900 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white text-lg">💰 Kelly Criterion Bet Sizer</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="bankroll" className="text-slate-300">
            Bankroll ($)
          </Label>
          <Input
            id="bankroll"
            type="number"
            value={bankroll}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleBankrollChange(e.target.value)}
            className="bg-slate-800 border-slate-600 text-white"
            min="0"
            step="100"
          />
        </div>

        {kelly && (
          <>
            {kelly.isPositiveEV ? (
              <div className="space-y-3">
                {kelly.warning && (
                  <div className="bg-amber-900/20 border border-amber-700 rounded-lg p-3 text-amber-200 text-sm">
                    {kelly.warning}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-slate-800 rounded-lg p-3 border border-slate-700">
                    <div className="text-slate-400 text-xs mb-1">Quarter Kelly (0.25x)</div>
                    <div className="text-white font-bold text-lg">${kelly.quarterKelly.toFixed(2)}</div>
                    <div className="text-slate-500 text-xs">{(kelly.kellyPercentage * 0.25).toFixed(2)}% of roll</div>
                  </div>

                  <div className="bg-slate-800 rounded-lg p-3 border border-green-700">
                    <div className="text-slate-400 text-xs mb-1">Half Kelly (0.5x) ✓</div>
                    <div className="text-green-400 font-bold text-lg">${kelly.halfKelly.toFixed(2)}</div>
                    <div className="text-slate-500 text-xs">{(kelly.kellyPercentage * 0.5).toFixed(2)}% of roll</div>
                  </div>

                  <div className="bg-slate-800 rounded-lg p-3 border border-slate-700">
                    <div className="text-slate-400 text-xs mb-1">3/4 Kelly (0.75x)</div>
                    <div className="text-white font-bold text-lg">${kelly.threeQuarterKelly.toFixed(2)}</div>
                    <div className="text-slate-500 text-xs">{(kelly.kellyPercentage * 0.75).toFixed(2)}% of roll</div>
                  </div>

                  <div className="bg-slate-800 rounded-lg p-3 border border-slate-700">
                    <div className="text-slate-400 text-xs mb-1">Full Kelly (1.0x)</div>
                    <div className="text-white font-bold text-lg">${kelly.fullKelly.toFixed(2)}</div>
                    <div className="text-slate-500 text-xs">{kelly.kellyPercentage.toFixed(2)}% of roll</div>
                  </div>
                </div>

                <div className="text-xs text-slate-400 mt-2">
                  ℹ️ Half Kelly is recommended for optimal risk-adjusted growth with lower variance.
                </div>
              </div>
            ) : (
              <div className="bg-red-900/20 border border-red-700 rounded-lg p-4 text-center">
                <div className="text-red-400 font-bold mb-1">No Positive Expected Value</div>
                <div className="text-slate-400 text-sm">Model shows no edge on this bet</div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
