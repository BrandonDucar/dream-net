'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import type { OddsFormat } from '@/lib/upset'
import { americanToDecimal, impliedProbFromDecimal } from '@/lib/upset'

type BookOdds = {
  book: string
  format: OddsFormat
  odds: number | null
}

type LineShoppingResult = {
  bestBook: string
  bestOdds: number
  bestDecimal: number
  bestImplied: number
  worstBook: string
  worstOdds: number
  worstDecimal: number
  centsSaved: number
  evBoost: number
}

const POPULAR_BOOKS = [
  'DraftKings',
  'FanDuel',
  'BetMGM',
  'Caesars',
  'PointsBet',
  'BetRivers',
  'Barstool',
  'WynnBet',
]

export function LineShoppingAssistant() {
  const [books, setBooks] = useState<BookOdds[]>([
    { book: 'DraftKings', format: 'american', odds: null },
  ])

  const [result, setResult] = useState<LineShoppingResult | null>(null)

  const addBook = (): void => {
    setBooks([...books, { book: 'FanDuel', format: 'american', odds: null }])
  }

  const removeBook = (index: number): void => {
    setBooks(books.filter((_, i) => i !== index))
  }

  const updateBook = (
    index: number,
    field: keyof BookOdds,
    value: string | number | null
  ): void => {
    const updated = [...books]
    updated[index] = { ...updated[index], [field]: value }
    setBooks(updated)
  }

  const compareLines = (): void => {
    const validBooks = books.filter((b) => b.odds != null) as Array<
      BookOdds & { odds: number }
    >

    if (validBooks.length < 2) {
      alert('Add at least 2 books with odds to compare')
      return
    }

    const decimals = validBooks.map((b) => ({
      book: b.book,
      odds: b.odds,
      decimal:
        b.format === 'american' ? americanToDecimal(b.odds) : b.odds,
    }))

    const sorted = decimals.sort((a, b) => b.decimal - a.decimal)
    const best = sorted[0]
    const worst = sorted[sorted.length - 1]

    const bestImplied = impliedProbFromDecimal(best.decimal)
    const centsSaved = best.decimal - worst.decimal
    const evBoost = ((best.decimal - worst.decimal) / worst.decimal) * 100

    setResult({
      bestBook: best.book,
      bestOdds: best.odds,
      bestDecimal: best.decimal,
      bestImplied,
      worstBook: worst.book,
      worstOdds: worst.odds,
      worstDecimal: worst.decimal,
      centsSaved,
      evBoost,
    })
  }

  return (
    <Card className="bg-slate-900/50 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white">Line Shopping Assistant</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          {books.map((book, idx) => (
            <div
              key={idx}
              className="grid grid-cols-1 md:grid-cols-4 gap-2 p-3 bg-slate-800/50 rounded-lg border border-slate-700"
            >
              <div>
                <Label className="text-slate-300">Sportsbook</Label>
                <Select
                  value={book.book}
                  onValueChange={(val) => updateBook(idx, 'book', val)}
                >
                  <SelectTrigger className="bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-600 text-white">
                    {POPULAR_BOOKS.map((b) => (
                      <SelectItem
                        key={b}
                        value={b}
                        className="text-white focus:bg-slate-700 focus:text-white"
                      >
                        {b}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-slate-300">Format</Label>
                <Select
                  value={book.format}
                  onValueChange={(val) =>
                    updateBook(idx, 'format', val as OddsFormat)
                  }
                >
                  <SelectTrigger className="bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-600 text-white">
                    <SelectItem
                      value="american"
                      className="text-white focus:bg-slate-700 focus:text-white"
                    >
                      American
                    </SelectItem>
                    <SelectItem
                      value="decimal"
                      className="text-white focus:bg-slate-700 focus:text-white"
                    >
                      Decimal
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-slate-300">Odds</Label>
                <Input
                  type="number"
                  step="any"
                  placeholder="e.g. +180"
                  value={book.odds ?? ''}
                  onChange={(e) =>
                    updateBook(
                      idx,
                      'odds',
                      e.target.value ? parseFloat(e.target.value) : null
                    )
                  }
                  className="bg-slate-800 border-slate-600 text-white placeholder:text-slate-500"
                />
              </div>

              <div className="flex items-end">
                {books.length > 1 && (
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => removeBook(idx)}
                    className="w-full"
                  >
                    Remove
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="flex gap-2">
          <Button
            onClick={addBook}
            variant="outline"
            className="border-slate-600 text-white hover:bg-slate-800"
          >
            + Add Sportsbook
          </Button>
          <Button
            onClick={compareLines}
            className="bg-cyan-600 hover:bg-cyan-700 text-white"
          >
            Compare Lines
          </Button>
        </div>

        {result && (
          <div className="mt-6 p-4 bg-slate-800/50 rounded-lg border border-slate-700 space-y-3">
            <h3 className="text-lg font-semibold text-white">
              Shopping Results
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3 bg-green-900/20 rounded border border-green-700">
                <div className="text-xs text-green-400 uppercase mb-1">
                  Best Price
                </div>
                <div className="text-xl font-bold text-green-300">
                  {result.bestBook}
                </div>
                <div className="text-2xl font-bold text-white mt-1">
                  {result.bestOdds > 0 ? '+' : ''}
                  {result.bestOdds}
                </div>
                <div className="text-sm text-slate-300 mt-1">
                  Decimal: {result.bestDecimal.toFixed(2)} • Implied:{' '}
                  {(result.bestImplied * 100).toFixed(1)}%
                </div>
              </div>

              <div className="p-3 bg-red-900/20 rounded border border-red-700">
                <div className="text-xs text-red-400 uppercase mb-1">
                  Worst Price
                </div>
                <div className="text-xl font-bold text-red-300">
                  {result.worstBook}
                </div>
                <div className="text-2xl font-bold text-white mt-1">
                  {result.worstOdds > 0 ? '+' : ''}
                  {result.worstOdds}
                </div>
                <div className="text-sm text-slate-300 mt-1">
                  Decimal: {result.worstDecimal.toFixed(2)}
                </div>
              </div>
            </div>

            <div className="p-3 bg-cyan-900/20 rounded border border-cyan-700">
              <div className="text-sm text-cyan-300 font-semibold">
                💰 Shopping saved you {result.centsSaved.toFixed(2)} cents of
                decimal value
              </div>
              <div className="text-sm text-slate-300 mt-1">
                That's a <span className="text-cyan-300 font-bold">
                  +{result.evBoost.toFixed(2)}%
                </span>{' '}
                EV boost just from line shopping!
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
