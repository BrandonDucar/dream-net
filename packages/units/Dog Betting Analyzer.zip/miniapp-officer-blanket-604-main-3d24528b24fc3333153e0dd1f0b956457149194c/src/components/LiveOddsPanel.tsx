'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { RefreshCw, TrendingUp, Clock } from 'lucide-react'
import type { GameInput, SportCode } from '@/lib/upset'

interface LiveGame {
  id: string
  sport: string
  homeTeam: string
  awayTeam: string
  commenceTime: string
  homeML: number | null
  awayML: number | null
  spread: number | null
  total: number | null
  bookmaker: string
}

interface LiveOddsPanelProps {
  sport: SportCode
  onSelectGame: (game: Partial<GameInput>) => void
}

export function LiveOddsPanel({ sport, onSelectGame }: LiveOddsPanelProps) {
  const [games, setGames] = useState<LiveGame[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)

  const fetchLiveOdds = async () => {
    setLoading(true)
    setError(null)

    try {
      const response = await fetch(`/api/odds?sport=${sport}`)
      
      if (!response.ok) {
        throw new Error('Failed to fetch odds')
      }

      const data = await response.json()
      setGames(data.games || [])
      setLastUpdate(new Date())
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error')
      console.error('Live odds error:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleSelectGame = (game: LiveGame) => {
    // Determine favorite based on moneylines
    let favoriteSide: 'home' | 'away' = 'home'
    let spread = game.spread
    let favML = game.homeML
    let dogML = game.awayML

    if (game.homeML && game.awayML) {
      if (game.homeML < game.awayML) {
        favoriteSide = 'home'
      } else {
        favoriteSide = 'away'
        // Flip spread for away favorite
        spread = spread ? -spread : null
        favML = game.awayML
        dogML = game.homeML
      }
    }

    onSelectGame({
      sport: sport,
      homeTeam: game.homeTeam,
      awayTeam: game.awayTeam,
      favoriteSide,
      spread,
      total: game.total,
      favMoneylineFormat: 'american',
      favMoneylineOdds: favML,
      dogMoneylineFormat: 'american',
      dogMoneylineOdds: dogML,
    })
  }

  const formatTime = (isoString: string) => {
    const date = new Date(isoString)
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    })
  }

  return (
    <Card className="bg-slate-900/50 border-slate-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-400" />
              Live Odds Feed
            </CardTitle>
            <CardDescription className="text-slate-400">
              Auto-populate from The Odds API ({sport})
            </CardDescription>
          </div>
          <Button
            onClick={fetchLiveOdds}
            disabled={loading}
            size="sm"
            className="bg-green-600 hover:bg-green-500 text-white"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            {loading ? 'Loading...' : 'Refresh'}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {error && (
          <div className="bg-red-950/30 border border-red-800/50 rounded-lg p-4 mb-4">
            <p className="text-red-300 text-sm">
              <strong>Error:</strong> {error}
            </p>
            <p className="text-red-300/70 text-xs mt-1">
              Note: Free API key has limited requests. Add your own key as ODDS_API_KEY env variable.
            </p>
          </div>
        )}

        {lastUpdate && (
          <div className="flex items-center gap-2 text-slate-400 text-sm mb-4">
            <Clock className="h-4 w-4" />
            Last updated: {lastUpdate.toLocaleTimeString()}
          </div>
        )}

        {games.length > 0 ? (
          <div className="rounded-lg border border-slate-700 overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent border-slate-700">
                  <TableHead className="text-slate-200">Game</TableHead>
                  <TableHead className="text-slate-200">Time</TableHead>
                  <TableHead className="text-slate-200">Spread</TableHead>
                  <TableHead className="text-slate-200">Total</TableHead>
                  <TableHead className="text-slate-200">ML</TableHead>
                  <TableHead className="text-slate-200"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {games.map((game) => (
                  <TableRow key={game.id} className="border-slate-700 hover:bg-slate-800/50">
                    <TableCell className="text-slate-100">
                      <div className="space-y-1">
                        <div className="font-medium">{game.awayTeam}</div>
                        <div className="text-slate-400 text-sm">@ {game.homeTeam}</div>
                      </div>
                    </TableCell>
                    <TableCell className="text-slate-300 text-sm">
                      {formatTime(game.commenceTime)}
                    </TableCell>
                    <TableCell className="text-slate-100">
                      {game.spread ? (
                        <Badge variant="outline" className="bg-slate-800 border-slate-600 text-white">
                          {game.spread > 0 ? '+' : ''}{game.spread}
                        </Badge>
                      ) : (
                        <span className="text-slate-500">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-slate-100">
                      {game.total ? (
                        <Badge variant="outline" className="bg-slate-800 border-slate-600 text-white">
                          {game.total}
                        </Badge>
                      ) : (
                        <span className="text-slate-500">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-slate-100">
                      <div className="space-y-1 text-sm">
                        {game.awayML && (
                          <div className="font-mono">{game.awayML > 0 ? '+' : ''}{game.awayML}</div>
                        )}
                        {game.homeML && (
                          <div className="font-mono text-slate-400">{game.homeML > 0 ? '+' : ''}{game.homeML}</div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Button
                        size="sm"
                        onClick={() => handleSelectGame(game)}
                        className="bg-cyan-600 hover:bg-cyan-500 text-white"
                      >
                        Load
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="text-center py-12 text-slate-400">
            <TrendingUp className="h-12 w-12 mx-auto mb-3 text-slate-600" />
            <p>Click Refresh to load live odds for {sport}</p>
            <p className="text-xs mt-2 text-slate-500">
              Powered by The Odds API
            </p>
          </div>
        )}

        {games.length > 0 && (
          <div className="mt-4 text-xs text-slate-500">
            Showing {games.length} games from {games[0]?.bookmaker || 'multiple books'}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
