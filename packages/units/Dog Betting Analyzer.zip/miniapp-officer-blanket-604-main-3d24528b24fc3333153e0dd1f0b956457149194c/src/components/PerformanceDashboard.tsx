'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import { TrendingUp, DollarSign, Target, Award, Trash2 } from 'lucide-react'

interface TrackedBet {
  id: string
  game: string
  side: string
  stake: number
  oddsTaken: number
  closingOdds: number | null
  result: 'pending' | 'win' | 'loss' | 'push'
  profitLoss: number
  clv: number | null
  timestamp: number
}

export function PerformanceDashboard() {
  const [bets, setBets] = useState<TrackedBet[]>([])
  const [newBet, setNewBet] = useState({
    game: '',
    side: '',
    stake: 0,
    oddsTaken: 0,
    closingOdds: 0,
    result: 'pending' as 'pending' | 'win' | 'loss' | 'push',
  })

  // Load bets from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('tracked_bets')
    if (saved) {
      setBets(JSON.parse(saved))
    }
  }, [])

  // Save to localStorage
  const saveBets = (updatedBets: TrackedBet[]) => {
    localStorage.setItem('tracked_bets', JSON.stringify(updatedBets))
    setBets(updatedBets)
  }

  const addBet = () => {
    if (!newBet.game || !newBet.side || newBet.stake <= 0 || newBet.oddsTaken <= 0) {
      alert('Please fill in all fields')
      return
    }

    const clv = newBet.closingOdds > 0 && newBet.oddsTaken > 0
      ? ((newBet.oddsTaken - newBet.closingOdds) / 100) * 100
      : null

    let profitLoss = 0
    if (newBet.result === 'win') {
      profitLoss = newBet.stake * (newBet.oddsTaken - 1)
    } else if (newBet.result === 'loss') {
      profitLoss = -newBet.stake
    }

    const bet: TrackedBet = {
      id: Date.now().toString(),
      game: newBet.game,
      side: newBet.side,
      stake: newBet.stake,
      oddsTaken: newBet.oddsTaken,
      closingOdds: newBet.closingOdds || null,
      result: newBet.result,
      profitLoss,
      clv,
      timestamp: Date.now(),
    }

    saveBets([...bets, bet])
    
    // Reset form
    setNewBet({
      game: '',
      side: '',
      stake: 0,
      oddsTaken: 0,
      closingOdds: 0,
      result: 'pending',
    })
  }

  const deleteBet = (id: string) => {
    saveBets(bets.filter((b) => b.id !== id))
  }

  const clearAll = () => {
    if (confirm('Clear all tracked bets?')) {
      saveBets([])
    }
  }

  // Stats calculations
  const completedBets = bets.filter((b) => b.result !== 'pending')
  const wins = completedBets.filter((b) => b.result === 'win').length
  const losses = completedBets.filter((b) => b.result === 'loss').length
  const winRate = completedBets.length > 0 ? (wins / completedBets.length) * 100 : 0
  const totalProfitLoss = bets.reduce((sum, b) => sum + b.profitLoss, 0)
  const totalStaked = completedBets.reduce((sum, b) => sum + b.stake, 0)
  const roi = totalStaked > 0 ? (totalProfitLoss / totalStaked) * 100 : 0
  const avgClv = bets.filter((b) => b.clv !== null).reduce((sum, b, _, arr) => sum + (b.clv || 0) / arr.length, 0)
  const bestClv = Math.max(...bets.map((b) => b.clv || 0), 0)

  // Chart data: cumulative P/L
  const cumulativePL = bets
    .filter((b) => b.result !== 'pending')
    .reduce((acc, bet, index) => {
      const prev = acc[index - 1]?.total || 0
      acc.push({
        bet: index + 1,
        total: prev + bet.profitLoss,
      })
      return acc
    }, [] as Array<{ bet: number; total: number }>)

  const getClvGrade = (clv: number | null) => {
    if (clv === null) return 'N/A'
    if (clv >= 20) return 'Excellent'
    if (clv >= 10) return 'Good'
    if (clv >= 0) return 'Fair'
    return 'Poor'
  }

  const getResultColor = (result: string) => {
    const colors: Record<string, string> = {
      win: 'bg-green-600/20 text-green-300 border-green-600/50',
      loss: 'bg-red-600/20 text-red-300 border-red-600/50',
      push: 'bg-gray-600/20 text-gray-300 border-gray-600/50',
      pending: 'bg-yellow-600/20 text-yellow-300 border-yellow-600/50',
    }
    return colors[result] || colors.pending
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-green-950/50 to-slate-900/50 border-green-800/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
              <Target className="h-4 w-4 text-green-400" />
              Win Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{winRate.toFixed(1)}%</div>
            <p className="text-xs text-slate-400 mt-1">
              {wins}W - {losses}L ({completedBets.length} bets)
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-950/50 to-slate-900/50 border-purple-800/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-purple-400" />
              Total P/L
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${totalProfitLoss >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {totalProfitLoss >= 0 ? '+' : ''}${totalProfitLoss.toFixed(2)}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              ROI: {roi >= 0 ? '+' : ''}{roi.toFixed(1)}%
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-cyan-950/50 to-slate-900/50 border-cyan-800/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-cyan-400" />
              Avg CLV
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">
              {avgClv >= 0 ? '+' : ''}{avgClv.toFixed(1)} cents
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {getClvGrade(avgClv)}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-950/50 to-slate-900/50 border-amber-800/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
              <Award className="h-4 w-4 text-amber-400" />
              Best CLV
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">
              +{bestClv.toFixed(1)} cents
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Single bet record
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      {cumulativePL.length > 0 && (
        <Card className="bg-slate-900/50 border-slate-700">
          <CardHeader>
            <CardTitle>Cumulative Profit/Loss</CardTitle>
            <CardDescription className="text-slate-400">Track your bankroll growth over time</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={cumulativePL}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="bet" stroke="#94a3b8" label={{ value: 'Bet #', position: 'insideBottom', offset: -5, fill: '#94a3b8' }} />
                <YAxis stroke="#94a3b8" label={{ value: 'P/L ($)', angle: -90, position: 'insideLeft', fill: '#94a3b8' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
                  labelStyle={{ color: '#e2e8f0' }}
                />
                <Line type="monotone" dataKey="total" stroke="#22d3ee" strokeWidth={2} dot={{ fill: '#22d3ee', r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Add New Bet */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle>Track New Bet</CardTitle>
          <CardDescription className="text-slate-400">Log bets with CLV tracking</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="game" className="text-slate-300">Game</Label>
              <Input
                id="game"
                value={newBet.game}
                onChange={(e) => setNewBet({ ...newBet, game: e.target.value })}
                placeholder="e.g. Patriots vs Bills"
                className="bg-slate-800 border-slate-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="side" className="text-slate-300">Side & Odds Taken</Label>
              <Input
                id="side"
                value={newBet.side}
                onChange={(e) => setNewBet({ ...newBet, side: e.target.value })}
                placeholder="e.g. Patriots +180"
                className="bg-slate-800 border-slate-600 text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="stake" className="text-slate-300">Stake ($)</Label>
              <Input
                id="stake"
                type="number"
                step="0.01"
                value={newBet.stake || ''}
                onChange={(e) => setNewBet({ ...newBet, stake: parseFloat(e.target.value) || 0 })}
                placeholder="100"
                className="bg-slate-800 border-slate-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="oddsTaken" className="text-slate-300">Odds Taken (decimal)</Label>
              <Input
                id="oddsTaken"
                type="number"
                step="0.01"
                value={newBet.oddsTaken || ''}
                onChange={(e) => setNewBet({ ...newBet, oddsTaken: parseFloat(e.target.value) || 0 })}
                placeholder="2.80"
                className="bg-slate-800 border-slate-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="closingOdds" className="text-slate-300">Closing Odds (decimal)</Label>
              <Input
                id="closingOdds"
                type="number"
                step="0.01"
                value={newBet.closingOdds || ''}
                onChange={(e) => setNewBet({ ...newBet, closingOdds: parseFloat(e.target.value) || 0 })}
                placeholder="2.65"
                className="bg-slate-800 border-slate-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="result" className="text-slate-300">Result</Label>
              <Select
                value={newBet.result}
                onValueChange={(value: 'pending' | 'win' | 'loss' | 'push') => setNewBet({ ...newBet, result: value })}
              >
                <SelectTrigger id="result" className="bg-slate-800 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-600">
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="win">Win</SelectItem>
                  <SelectItem value="loss">Loss</SelectItem>
                  <SelectItem value="push">Push</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button
            onClick={addBet}
            className="w-full bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white"
          >
            Add Bet
          </Button>
        </CardContent>
      </Card>

      {/* Bets Table */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Tracked Bets</CardTitle>
              <CardDescription className="text-slate-400">{bets.length} total bets</CardDescription>
            </div>
            {bets.length > 0 && (
              <Button
                onClick={clearAll}
                variant="outline"
                size="sm"
                className="border-red-600 text-red-400 hover:bg-red-900/20"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Clear All
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {bets.length > 0 ? (
            <div className="rounded-lg border border-slate-700 overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent border-slate-700">
                    <TableHead className="text-slate-200">Game</TableHead>
                    <TableHead className="text-slate-200">Side</TableHead>
                    <TableHead className="text-slate-200">Stake</TableHead>
                    <TableHead className="text-slate-200">Odds</TableHead>
                    <TableHead className="text-slate-200">Closing</TableHead>
                    <TableHead className="text-slate-200">CLV</TableHead>
                    <TableHead className="text-slate-200">Result</TableHead>
                    <TableHead className="text-slate-200">P/L</TableHead>
                    <TableHead className="text-slate-200"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {bets.map((bet) => (
                    <TableRow key={bet.id} className="border-slate-700 hover:bg-slate-800/50">
                      <TableCell className="text-slate-100">{bet.game}</TableCell>
                      <TableCell className="text-slate-100">{bet.side}</TableCell>
                      <TableCell className="text-slate-100">${bet.stake.toFixed(2)}</TableCell>
                      <TableCell className="text-slate-100 font-mono">{bet.oddsTaken.toFixed(2)}</TableCell>
                      <TableCell className="text-slate-100 font-mono">
                        {bet.closingOdds ? bet.closingOdds.toFixed(2) : '-'}
                      </TableCell>
                      <TableCell>
                        {bet.clv !== null ? (
                          <Badge variant="outline" className={`${bet.clv >= 0 ? 'bg-green-600/20 text-green-300 border-green-600/50' : 'bg-red-600/20 text-red-300 border-red-600/50'}`}>
                            {bet.clv >= 0 ? '+' : ''}{bet.clv.toFixed(1)}¢
                          </Badge>
                        ) : (
                          <span className="text-slate-500">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge className={getResultColor(bet.result)}>
                          {bet.result}
                        </Badge>
                      </TableCell>
                      <TableCell className={`font-mono ${bet.profitLoss >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {bet.profitLoss >= 0 ? '+' : ''}${bet.profitLoss.toFixed(2)}
                      </TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => deleteBet(bet.id)}
                          className="text-red-400 hover:bg-red-900/20"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-400">
              <Target className="h-12 w-12 mx-auto mb-3 text-slate-600" />
              <p>No tracked bets yet</p>
              <p className="text-xs mt-2 text-slate-500">
                Add your first bet above to start tracking CLV and performance
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
