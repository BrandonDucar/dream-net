'use client'

import { useEffect, useState } from 'react'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { AlertTriangle, Info, MapPin } from 'lucide-react'
import { detectLocation, checkGeofence, type GeofenceStatus } from '@/lib/geofence'

export function GeofenceWarning() {
  const [status, setStatus] = useState<GeofenceStatus | null>(null)
  const [loading, setLoading] = useState<boolean>(true)

  useEffect(() => {
    async function checkLocation() {
      try {
        const location = await detectLocation()
        const geofenceStatus = checkGeofence(location)
        setStatus(geofenceStatus)
      } catch (error) {
        setStatus({
          allowed: true,
          location: null,
          message: "Unable to detect location. Tool available for educational purposes only.",
          severity: "info",
        })
      } finally {
        setLoading(false)
      }
    }

    checkLocation()
  }, [])

  if (loading) {
    return (
      <Alert className="bg-slate-900/50 border-slate-700">
        <MapPin className="h-4 w-4" />
        <AlertDescription className="text-slate-400">
          Detecting location...
        </AlertDescription>
      </Alert>
    )
  }

  if (!status) return null

  const Icon = status.severity === "error" || status.severity === "warning" ? AlertTriangle : Info

  const severityStyles = {
    info: "bg-blue-950/30 border-blue-800/50 text-blue-200",
    warning: "bg-amber-950/30 border-amber-800/50 text-amber-200",
    error: "bg-red-950/30 border-red-800/50 text-red-200",
  }

  return (
    <Alert className={`${severityStyles[status.severity]}`}>
      <Icon className="h-4 w-4" />
      <AlertDescription>
        {status.message}
        {!status.allowed && (
          <span className="block mt-2 text-xs opacity-80">
            This is an analytics tool only. No betting functionality is provided.
          </span>
        )}
      </AlertDescription>
    </Alert>
  )
}
