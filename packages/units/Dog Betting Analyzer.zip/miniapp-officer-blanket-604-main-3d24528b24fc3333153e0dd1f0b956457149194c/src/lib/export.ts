import type { UpsetEngineResult } from './upset';

/**
 * Export analysis result as JSON
 */
export function exportAsJSON(result: UpsetEngineResult): void {
  const dataStr = JSON.stringify(result, null, 2);
  const blob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `live-dog-analysis-${Date.now()}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Export analysis result as CSV
 */
export function exportAsCSV(result: UpsetEngineResult): void {
  const rows = [
    ['Metric', 'Value'],
    ['Sport', result.sport],
    ['Favorite', result.favLabel],
    ['Dog', result.dogLabel],
    ['Spread', result.spread?.toString() || 'N/A'],
    ['Total', result.total?.toString() || 'N/A'],
    ['Model Dog Win %', (result.modelDogProb * 100).toFixed(2) + '%'],
    ['Model Fav Win %', (result.modelFavProb * 100).toFixed(2) + '%'],
    ['Fair Dog Decimal', result.fairDogDecimal.toFixed(2)],
    ['Fair Dog American', result.fairDogAmerican.toString()],
    ['Live Dog Index', result.liveDogIndex.toFixed(1)],
    ['Value Grade', result.valueGrade],
    ['Suggested Angle', result.suggestedAngle],
    ['', ''],
    ['Notes', ''],
    ...result.notes.map((note: string) => ['', note])
  ];

  const csvContent = rows.map((row: string[]) => row.join(',')).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `live-dog-analysis-${Date.now()}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Share analysis via Web Share API (if available)
 */
export async function shareAnalysis(result: UpsetEngineResult): Promise<boolean> {
  if (!navigator.share) {
    return false;
  }

  try {
    await navigator.share({
      title: `Live Dog Analysis: ${result.dogLabel}`,
      text: `${result.dogLabel} upset probability: ${(result.modelDogProb * 100).toFixed(1)}% | Live Dog Index: ${result.liveDogIndex.toFixed(1)} (${result.valueGrade}-tier) | Angle: ${result.suggestedAngle}`,
      url: window.location.href
    });
    return true;
  } catch (err) {
    if ((err as Error).name !== 'AbortError') {
      console.error('Share failed:', err);
    }
    return false;
  }
}

/**
 * Copy analysis summary to clipboard
 */
export async function copyToClipboard(result: UpsetEngineResult): Promise<boolean> {
  const summary = `
🐶 Live Dog Analysis: ${result.dogLabel}

Sport: ${result.sport}
Matchup: ${result.dogLabel} @ ${result.favLabel}
${result.spread ? `Spread: ${result.spread > 0 ? '+' : ''}${result.spread}` : ''}

📊 Model Probabilities:
• Dog win: ${(result.modelDogProb * 100).toFixed(1)}%
• Fav win: ${(result.modelFavProb * 100).toFixed(1)}%

💰 Fair Price:
• Decimal: ${result.fairDogDecimal.toFixed(2)}
• American: ${result.fairDogAmerican > 0 ? '+' : ''}${result.fairDogAmerican}

⚡ Live Dog Index: ${result.liveDogIndex.toFixed(1)}/100
🏆 Grade: ${result.valueGrade}-tier
🎯 Angle: ${result.suggestedAngle}

Notes:
${result.notes.join('\n')}
`.trim();

  try {
    await navigator.clipboard.writeText(summary);
    return true;
  } catch (err) {
    console.error('Copy failed:', err);
    return false;
  }
}
