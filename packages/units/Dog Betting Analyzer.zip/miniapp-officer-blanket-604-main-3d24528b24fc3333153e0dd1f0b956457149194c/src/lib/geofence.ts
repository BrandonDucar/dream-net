export type GeoLocation = {
  latitude: number;
  longitude: number;
  country: string | null;
  region: string | null;
  city: string | null;
};

export type GeofenceStatus = {
  allowed: boolean;
  location: GeoLocation | null;
  message: string;
  severity: "info" | "warning" | "error";
};

// US states where sports betting is restricted or illegal
const RESTRICTED_US_STATES = [
  "AL", "AK", "CA", "GA", "HI", "ID", "MN", "MO", "SC", "TX", "UT", "VT"
];

// Countries where online gambling is heavily restricted
const RESTRICTED_COUNTRIES = [
  "CN", // China
  "KP", // North Korea
  "SY", // Syria
  "IR", // Iran
];

/**
 * Detects user's location using browser geolocation API
 */
export async function detectLocation(): Promise<GeoLocation | null> {
  return new Promise((resolve) => {
    if (!navigator.geolocation) {
      resolve(null);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        
        // Use reverse geocoding to get location details
        try {
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`
          );
          const data = await response.json();
          
          resolve({
            latitude,
            longitude,
            country: data.address?.country_code?.toUpperCase() || null,
            region: data.address?.state_code?.toUpperCase() || data.address?.state || null,
            city: data.address?.city || data.address?.town || data.address?.village || null,
          });
        } catch (error) {
          // If reverse geocoding fails, still return coords
          resolve({
            latitude,
            longitude,
            country: null,
            region: null,
            city: null,
          });
        }
      },
      () => {
        resolve(null);
      },
      {
        timeout: 10000,
        enableHighAccuracy: false,
      }
    );
  });
}

/**
 * Checks if betting is allowed in the user's location
 */
export function checkGeofence(location: GeoLocation | null): GeofenceStatus {
  if (!location) {
    return {
      allowed: true,
      location: null,
      message: "Location detection disabled. This tool is for educational and analytical purposes only.",
      severity: "info",
    };
  }

  // Check country restrictions
  if (location.country && RESTRICTED_COUNTRIES.includes(location.country)) {
    return {
      allowed: false,
      location,
      message: `Sports betting analytics may be restricted in your country (${location.country}). This tool is for educational purposes only.`,
      severity: "error",
    };
  }

  // Check US state restrictions
  if (location.country === "US" && location.region) {
    if (RESTRICTED_US_STATES.includes(location.region)) {
      return {
        allowed: false,
        location,
        message: `Sports betting is restricted in ${location.region}. This tool is for educational and entertainment purposes only.`,
        severity: "warning",
      };
    }
  }

  return {
    allowed: true,
    location,
    message: `Location: ${location.city || "Unknown"}, ${location.region || location.country || "Unknown"}. Remember to bet responsibly.`,
    severity: "info",
  };
}

/**
 * Gets timezone from coordinates
 */
export function getTimezone(latitude: number, longitude: number): string {
  // Simple timezone estimation based on longitude
  const offset = Math.round(longitude / 15);
  return `UTC${offset >= 0 ? '+' : ''}${offset}`;
}
