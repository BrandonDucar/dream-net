/**
 * Kelly Criterion bet sizing calculations
 */

export interface KellyResult {
  fullKelly: number;
  halfKelly: number;
  quarterKelly: number;
  threeQuarterKelly: number;
  kellyPercentage: number;
  isPositiveEV: boolean;
  warning: string | null;
}

/**
 * Calculate Kelly Criterion stake
 * @param bankroll - Total bankroll
 * @param fairDecimalOdds - Your model's fair decimal odds
 * @param bookDecimalOdds - Bookmaker's decimal odds
 * @returns Kelly stake calculations
 */
export function calculateKelly(
  bankroll: number,
  fairDecimalOdds: number,
  bookDecimalOdds: number
): KellyResult {
  // Edge case checks
  if (bankroll <= 0 || fairDecimalOdds <= 1 || bookDecimalOdds <= 1) {
    return {
      fullKelly: 0,
      halfKelly: 0,
      quarterKelly: 0,
      threeQuarterKelly: 0,
      kellyPercentage: 0,
      isPositiveEV: false,
      warning: "Invalid inputs - check odds and bankroll"
    };
  }

  const p = 1 / fairDecimalOdds; // win probability
  const b = bookDecimalOdds - 1; // net odds (decimal - 1)
  const q = 1 - p; // lose probability

  // Kelly formula: (bp - q) / b
  const kellyFraction = (b * p - q) / b;

  // No positive edge
  if (kellyFraction <= 0) {
    return {
      fullKelly: 0,
      halfKelly: 0,
      quarterKelly: 0,
      threeQuarterKelly: 0,
      kellyPercentage: 0,
      isPositiveEV: false,
      warning: "No positive expected value - do not bet"
    };
  }

  const kellyPercentage = kellyFraction * 100;
  const fullKelly = bankroll * kellyFraction;
  const halfKelly = fullKelly * 0.5;
  const quarterKelly = fullKelly * 0.25;
  const threeQuarterKelly = fullKelly * 0.75;

  // Warning for aggressive sizing
  let warning: string | null = null;
  if (kellyPercentage > 10) {
    warning = "⚠️ Very aggressive sizing (>10%) - consider fractional Kelly";
  } else if (kellyPercentage > 5) {
    warning = "⚠️ Aggressive sizing (>5%) - high variance risk";
  }

  return {
    fullKelly,
    halfKelly,
    quarterKelly,
    threeQuarterKelly,
    kellyPercentage,
    isPositiveEV: true,
    warning
  };
}
