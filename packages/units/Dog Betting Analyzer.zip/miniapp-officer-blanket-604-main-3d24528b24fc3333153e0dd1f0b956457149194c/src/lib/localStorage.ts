import type { UpsetEngineResult } from './upset'

export type SavedAnalysis = {
  id: string
  timestamp: number
  result: UpsetEngineResult
}

const STORAGE_KEY = 'upset_engine_history'
const MAX_SAVED = 50

export function saveAnalysis(result: UpsetEngineResult): void {
  try {
    const history = getHistory()
    const newEntry: SavedAnalysis = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: Date.now(),
      result,
    }
    
    history.unshift(newEntry)
    
    // Keep only most recent MAX_SAVED entries
    const trimmed = history.slice(0, MAX_SAVED)
    
    localStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed))
  } catch (error) {
    console.warn('Failed to save analysis to localStorage:', error)
  }
}

export function getHistory(): SavedAnalysis[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (!stored) return []
    
    const parsed = JSON.parse(stored)
    return Array.isArray(parsed) ? parsed : []
  } catch (error) {
    console.warn('Failed to read history from localStorage:', error)
    return []
  }
}

export function clearHistory(): void {
  try {
    localStorage.removeItem(STORAGE_KEY)
  } catch (error) {
    console.warn('Failed to clear history:', error)
  }
}

export function deleteAnalysis(id: string): void {
  try {
    const history = getHistory()
    const filtered = history.filter(entry => entry.id !== id)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered))
  } catch (error) {
    console.warn('Failed to delete analysis:', error)
  }
}
