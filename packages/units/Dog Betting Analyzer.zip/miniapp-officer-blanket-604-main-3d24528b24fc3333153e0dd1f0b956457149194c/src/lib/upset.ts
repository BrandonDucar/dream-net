export type SportCode =
  | "NFL"
  | "NCAAF"
  | "NBA"
  | "NCAAB"
  | "MLB"
  | "NHL"
  | "SOCCER"
  | "UFC"
  | "OTHER";

export type OddsFormat = "american" | "decimal";

export type GameInput = {
  sport: SportCode;
  homeTeam: string;
  awayTeam: string;
  favoriteSide: "home" | "away";
  spread: number | null;
  total: number | null;
  favMoneylineFormat: OddsFormat;
  favMoneylineOdds: number | null;
  dogMoneylineFormat: OddsFormat;
  dogMoneylineOdds: number | null;
  dogForm: number;
  favForm: number;
  variance: number;
};

export type UpsetEngineResult = {
  sport: SportCode;
  favLabel: string;
  dogLabel: string;
  spread: number | null;
  total: number | null;
  baseFavProbFromSpread: number | null;
  baseDogProbFromSpread: number | null;
  favProbFromMoneyline: number | null;
  dogProbFromMoneyline: number | null;
  modelFavProb: number;
  modelDogProb: number;
  fairDogDecimal: number;
  fairDogAmerican: number;
  liveDogIndex: number;
  valueGrade: "F" | "C" | "B" | "A" | "S";
  suggestedAngle: "DOG_ML" | "DOG_SPREAD" | "FAVE" | "PASS";
  notes: string[];
};

// ---------- ODDS HELPERS ----------

export function americanToDecimal(american: number): number {
  if (american > 0) return 1 + american / 100;
  return 1 + 100 / Math.abs(american);
}

export function impliedProbFromDecimal(decimal: number): number {
  if (decimal <= 1) return 0;
  return 1 / decimal;
}

export function impliedProbFromAmerican(american: number): number {
  return impliedProbFromDecimal(americanToDecimal(american));
}

export function decimalToAmerican(decimal: number): number {
  if (decimal <= 1) return 0;
  const p = 1 / decimal;
  if (p > 0.5) {
    const odds = - (p / (1 - p)) * 100;
    return Math.round(odds);
  } else {
    const odds = ((1 - p) / p) * 100;
    return Math.round(odds);
  }
}

export function normalizeDecimal(format: OddsFormat, odds: number | null): number | null {
  if (odds == null) return null;
  return format === "american" ? americanToDecimal(odds) : odds;
}

// ---------- SPREAD → WIN PROB (SIMPLE HEURISTICS) ----------

function spreadToWinProbNFL(spread: number): number {
  const k = 0.23;
  return 1 / (1 + Math.exp(-k * spread));
}

function spreadToWinProbNBA(spread: number): number {
  const k = 0.19;
  return 1 / (1 + Math.exp(-k * spread));
}

function spreadToWinProbNCAAB(spread: number): number {
  const k = 0.16;
  return 1 / (1 + Math.exp(-k * spread));
}

function spreadToWinProbMLB(spread: number): number {
  const k = 0.14;
  return 1 / (1 + Math.exp(-k * spread));
}

function spreadToWinProbNHL(spread: number): number {
  const k = 0.14;
  return 1 / (1 + Math.exp(-k * spread));
}

function spreadToWinProbSOCCER(spread: number): number {
  const k = 0.12;
  return 1 / (1 + Math.exp(-k * spread));
}

function spreadToWinProbGeneric(spread: number): number {
  const k = 0.18;
  return 1 / (1 + Math.exp(-k * spread));
}

function spreadToFavProb(sport: SportCode, spread: number): number {
  const abs = Math.abs(spread);
  let base: number;
  switch (sport) {
    case "NFL": base = spreadToWinProbNFL(abs); break;
    case "NBA": base = spreadToWinProbNBA(abs); break;
    case "NCAAB": base = spreadToWinProbNCAAB(abs); break;
    case "MLB": base = spreadToWinProbMLB(abs); break;
    case "NHL": base = spreadToWinProbNHL(abs); break;
    case "SOCCER": base = spreadToWinProbSOCCER(abs); break;
    default: base = spreadToWinProbGeneric(abs); break;
  }
  return base;
}

// ---------- MAIN ENGINE ----------

export function runUpsetEngine(input: GameInput): UpsetEngineResult {
  const favLabel = input.favoriteSide === "home" ? input.homeTeam : input.awayTeam;
  const dogLabel = input.favoriteSide === "home" ? input.awayTeam : input.homeTeam;

  let baseFavProbFromSpread: number | null = null;
  let baseDogProbFromSpread: number | null = null;

  if (input.spread != null) {
    const favSpread = Math.abs(input.spread);
    const pFav = spreadToFavProb(input.sport, favSpread);
    baseFavProbFromSpread = pFav;
    baseDogProbFromSpread = 1 - pFav;
  }

  let favProbFromMoneyline: number | null = null;
  let dogProbFromMoneyline: number | null = null;

  const favDec = normalizeDecimal(input.favMoneylineFormat, input.favMoneylineOdds);
  const dogDec = normalizeDecimal(input.dogMoneylineFormat, input.dogMoneylineOdds);

  if (favDec != null) {
    favProbFromMoneyline = impliedProbFromDecimal(favDec);
  }
  if (dogDec != null) {
    dogProbFromMoneyline = impliedProbFromDecimal(dogDec);
  }

  if (favProbFromMoneyline != null && dogProbFromMoneyline != null) {
    const sum = favProbFromMoneyline + dogProbFromMoneyline;
    if (sum > 0) {
      favProbFromMoneyline = favProbFromMoneyline / sum;
      dogProbFromMoneyline = dogProbFromMoneyline / sum;
    }
  }

  let spreadWeight = input.spread != null ? 0.6 : 0;
  let mlWeight = favProbFromMoneyline != null ? 0.4 : 0;

  if (spreadWeight === 0 && mlWeight === 0) {
    spreadWeight = 0.0;
    mlWeight = 1.0;
  }

  const totalWeight = spreadWeight + mlWeight;
  const wSpread = totalWeight > 0 ? spreadWeight / totalWeight : 0;
  const wML = totalWeight > 0 ? mlWeight / totalWeight : 0;

  let favProbBase = 0.5;

  if (baseFavProbFromSpread != null && favProbFromMoneyline != null) {
    favProbBase = baseFavProbFromSpread * wSpread + favProbFromMoneyline * wML;
  } else if (baseFavProbFromSpread != null) {
    favProbBase = baseFavProbFromSpread;
  } else if (favProbFromMoneyline != null) {
    favProbBase = favProbFromMoneyline;
  }

  const favFormNorm = clamp01(input.favForm / 100);
  const dogFormNorm = clamp01(input.dogForm / 100);
  const varianceNorm = clamp01(input.variance / 100);

  const formDiff = dogFormNorm - favFormNorm;

  const maxShift = 0.05 + 0.05 * varianceNorm;
  const shift = formDiff * maxShift;

  let modelFavProb = clamp01(favProbBase - shift);
  let modelDogProb = 1 - modelFavProb;

  const fairDogDecimal = modelDogProb > 0 ? 1 / modelDogProb : 0;
  const fairDogAmerican = fairDogDecimal > 0 ? decimalToAmerican(fairDogDecimal) : 0;

  let priceEdge = 0;
  if (dogDec != null && fairDogDecimal > 0) {
    const impliedBook = impliedProbFromDecimal(dogDec);
    priceEdge = (modelDogProb - impliedBook) * 100;
  }

  const upsetPct = modelDogProb * 100;
  const varianceFactor = varianceNorm;

  let score = 0;
  score += (upsetPct / 100) * 60;
  score += clamp(priceEdge, -10, 10) * 1;
  score += varianceFactor * 20;

  const liveDogIndex = clamp(score, 0, 100);

  let valueGrade: "F" | "C" | "B" | "A" | "S" = "F";
  if (liveDogIndex >= 80) valueGrade = "S";
  else if (liveDogIndex >= 65) valueGrade = "A";
  else if (liveDogIndex >= 50) valueGrade = "B";
  else if (liveDogIndex >= 35) valueGrade = "C";
  else valueGrade = "F";

  let suggestedAngle: "DOG_ML" | "DOG_SPREAD" | "FAVE" | "PASS" = "PASS";

  if (modelDogProb > 0.45 && priceEdge > 0 && liveDogIndex >= 50) {
    suggestedAngle = "DOG_ML";
  } else if (modelDogProb > 0.35 && liveDogIndex >= 40) {
    suggestedAngle = "DOG_SPREAD";
  } else if (modelFavProb > 0.65 && priceEdge < -3) {
    suggestedAngle = "FAVE";
  } else {
    suggestedAngle = "PASS";
  }

  const notes: string[] = [];

  notes.push(`Model upset probability for ${dogLabel}: ${upsetPct.toFixed(1)}%.`);

  if (dogDec != null) {
    const dogBookImplied = impliedProbFromDecimal(dogDec) * 100;
    notes.push(`Book implies ~${dogBookImplied.toFixed(1)}% for the dog at current price.`);
    const edgeDiff = upsetPct - dogBookImplied;
    if (edgeDiff > 3) {
      notes.push(`Model sees roughly +${edgeDiff.toFixed(1)} pts of edge on the dog.`);
    } else if (edgeDiff < -3) {
      notes.push(`Model is more pessimistic on the dog than the book (−${Math.abs(edgeDiff).toFixed(1)} pts).`);
    } else {
      notes.push("Model and book are roughly aligned on dog odds.");
    }
  }

  if (varianceNorm > 0.7) {
    notes.push("High volatility matchup – ceiling and floor both elevated.");
  } else if (varianceNorm < 0.3) {
    notes.push("Lower volatility matchup – favorites tend to hold serve more often here.");
  }

  if (formDiff > 0.15) {
    notes.push("Dog form meaningfully stronger than favorite based on sliders.");
  } else if (formDiff < -0.15) {
    notes.push("Favorite form meaningfully stronger than dog based on sliders.");
  }

  notes.push(`Live Dog Index: ${liveDogIndex.toFixed(1)} (${valueGrade}-tier).`);

  return {
    sport: input.sport,
    favLabel,
    dogLabel,
    spread: input.spread,
    total: input.total,
    baseFavProbFromSpread,
    baseDogProbFromSpread,
    favProbFromMoneyline,
    dogProbFromMoneyline,
    modelFavProb,
    modelDogProb,
    fairDogDecimal,
    fairDogAmerican,
    liveDogIndex,
    valueGrade,
    suggestedAngle,
    notes
  };
}

// ---------- UTILS ----------

function clamp01(x: number): number {
  return Math.max(0, Math.min(1, x));
}

function clamp(x: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, x));
}
