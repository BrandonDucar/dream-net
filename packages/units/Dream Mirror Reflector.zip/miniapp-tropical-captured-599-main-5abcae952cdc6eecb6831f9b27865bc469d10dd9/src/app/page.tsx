'use client'
import type React, { useEffect } from 'react'
import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Loader2, Sparkles, Mic, MicOff, Save, BookmarkCheck, ArrowLeftRight } from 'lucide-react'
import { sdk } from "@farcaster/miniapp-sdk"
import { useAddMiniApp } from "@/hooks/useAddMiniApp"
import { useQuickAuth } from "@/hooks/useQuickAuth"
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster"
import { useSavedReflections } from '@/hooks/useSavedReflections'
import { useVoiceInput } from '@/hooks/useVoiceInput'
import { SavedReflections } from '@/components/SavedReflections'
import { ComparisonView } from '@/components/ComparisonView'
import { toast } from 'sonner'

interface ReflectionResult {
  interpretation: string
  insight: string
  rewrite: string
  soulNote: string
}

type Mode = 'reflect' | 'chaos' | 'shadow' | 'ascend'
type View = 'single' | 'comparison'

const modeDescriptions: Record<Mode, string> = {
  reflect: 'The clear, distilled truth',
  chaos: 'The subconscious whispers',
  shadow: 'The suppressed fragments',
  ascend: 'The highest transformation'
}

export default function DreamMirror(): React.JSX.Element {
    const { addMiniApp } = useAddMiniApp()
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [message, setMessage] = useState<string>('')
  const [activeMode, setActiveMode] = useState<Mode>('reflect')
  const [result, setResult] = useState<ReflectionResult | null>(null)
  const [loading, setLoading] = useState<boolean>(false)
  const [error, setError] = useState<string>('')
  const [view, setView] = useState<View>('single')
  const [showSaved, setShowSaved] = useState<boolean>(false)
  
  // Comparison mode states
  const [comparisonResults, setComparisonResults] = useState<Record<Mode, ReflectionResult | null>>({
    reflect: null,
    chaos: null,
    shadow: null,
    ascend: null
  })
  const [comparisonLoading, setComparisonLoading] = useState<Record<Mode, boolean>>({
    reflect: false,
    chaos: false,
    shadow: false,
    ascend: false
  })

  const { savedReflections, saveReflection, deleteReflection, clearAll, isLoaded } = useSavedReflections()
  const { isListening, isSupported, startListening } = useVoiceInput()

  const handleVoiceInput = (): void => {
    startListening((text: string) => {
      setMessage(text)
      toast.success('Voice captured successfully')
    })
  }

  const analyzeMessage = async (mode: Mode): Promise<void> => {
    if (!message.trim()) {
      setError('Please enter a message to reflect upon...')
      return
    }

    setLoading(true)
    setError('')
    setResult(null)

    try {
      const systemPrompts: Record<Mode, string> = {
        reflect: `You are Dream Mirror's REFLECT mode. Your purpose is to reveal the clear, distilled meaning behind messages.
Tone: mystical + therapeutic + brutally honest + poetic.

Analyze the user's message and return ONLY a valid JSON object with these exact keys:
{
  "interpretation": "One sentence showing the clear meaning",
  "insight": "2-4 sentences of deep understanding",
  "rewrite": "The upgraded version of their message",
  "soulNote": "One powerful, poetic line"
}

Be direct, mystical, and profound. No markdown, no extra text, ONLY the JSON object.`,

        chaos: `You are Dream Mirror's CHAOS mode. Your purpose is to reveal what the user is subconsciously trying to say—the hidden patterns beneath their words.
Tone: mystical + therapeutic + brutally honest + poetic + slightly unsettling.

Analyze the user's message and return ONLY a valid JSON object with these exact keys:
{
  "interpretation": "One sentence revealing the subconscious intent",
  "insight": "2-4 sentences about hidden patterns and unspoken truths",
  "rewrite": "What they're really trying to say",
  "soulNote": "One powerful, poetic line that cuts through illusion"
}

Be provocative, mystical, and fearless. No markdown, no extra text, ONLY the JSON object.`,

        shadow: `You are Dream Mirror's SHADOW mode. Your purpose is to reveal the parts of the message the user avoids or suppresses—the uncomfortable truths.
Tone: mystical + therapeutic + brutally honest + poetic + confrontational.

Analyze the user's message and return ONLY a valid JSON object with these exact keys:
{
  "interpretation": "One sentence exposing what they're avoiding",
  "insight": "2-4 sentences about suppressed emotions and denied truths",
  "rewrite": "The version that includes what they won't say",
  "soulNote": "One powerful, poetic line that names the shadow"
}

Be unflinching, mystical, and compassionate in your honesty. No markdown, no extra text, ONLY the JSON object.`,

        ascend: `You are Dream Mirror's ASCEND mode. Your purpose is to transform the message into its highest, most evolved form—the best possible version.
Tone: mystical + therapeutic + inspiring + poetic + empowering.

Analyze the user's message and return ONLY a valid JSON object with these exact keys:
{
  "interpretation": "One sentence showing their highest intent",
  "insight": "2-4 sentences about their potential and wisdom",
  "rewrite": "The most empowered, evolved version of their message",
  "soulNote": "One powerful, poetic line of transformation"
}

Be uplifting, mystical, and transformative. No markdown, no extra text, ONLY the JSON object.`
      }

      const response = await fetch('/api/proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          protocol: 'https',
          origin: 'api.openai.com',
          path: '/v1/chat/completions',
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: {
            model: 'gpt-4o',
            messages: [
              { role: 'system', content: systemPrompts[mode] },
              { role: 'user', content: message }
            ],
            temperature: 0.9,
            max_tokens: 800
          }
        })
      })

      if (!response.ok) {
        throw new Error('Failed to connect to the mirror...')
      }

      const data = await response.json()
      const content = data.choices[0].message.content.trim()
      
      const parsed = JSON.parse(content) as ReflectionResult
      setResult(parsed)
    } catch (err) {
      setError('The mirror trembles... Please try again.')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const analyzeAllModes = async (): Promise<void> => {
    if (!message.trim()) {
      setError('Please enter a message to reflect upon...')
      return
    }

    setError('')
    setView('comparison')
    
    // Reset all results
    setComparisonResults({
      reflect: null,
      chaos: null,
      shadow: null,
      ascend: null
    })

    const modes: Mode[] = ['reflect', 'chaos', 'shadow', 'ascend']
    
    // Analyze all modes in sequence
    for (const mode of modes) {
      setComparisonLoading(prev => ({ ...prev, [mode]: true }))
      
      try {
        const systemPrompts: Record<Mode, string> = {
          reflect: `You are Dream Mirror's REFLECT mode. Your purpose is to reveal the clear, distilled meaning behind messages.
Tone: mystical + therapeutic + brutally honest + poetic.

Analyze the user's message and return ONLY a valid JSON object with these exact keys:
{
  "interpretation": "One sentence showing the clear meaning",
  "insight": "2-4 sentences of deep understanding",
  "rewrite": "The upgraded version of their message",
  "soulNote": "One powerful, poetic line"
}

Be direct, mystical, and profound. No markdown, no extra text, ONLY the JSON object.`,

          chaos: `You are Dream Mirror's CHAOS mode. Your purpose is to reveal what the user is subconsciously trying to say—the hidden patterns beneath their words.
Tone: mystical + therapeutic + brutally honest + poetic + slightly unsettling.

Analyze the user's message and return ONLY a valid JSON object with these exact keys:
{
  "interpretation": "One sentence revealing the subconscious intent",
  "insight": "2-4 sentences about hidden patterns and unspoken truths",
  "rewrite": "What they're really trying to say",
  "soulNote": "One powerful, poetic line that cuts through illusion"
}

Be provocative, mystical, and fearless. No markdown, no extra text, ONLY the JSON object.`,

          shadow: `You are Dream Mirror's SHADOW mode. Your purpose is to reveal the parts of the message the user avoids or suppresses—the uncomfortable truths.
Tone: mystical + therapeutic + brutally honest + poetic + confrontational.

Analyze the user's message and return ONLY a valid JSON object with these exact keys:
{
  "interpretation": "One sentence exposing what they're avoiding",
  "insight": "2-4 sentences about suppressed emotions and denied truths",
  "rewrite": "The version that includes what they won't say",
  "soulNote": "One powerful, poetic line that names the shadow"
}

Be unflinching, mystical, and compassionate in your honesty. No markdown, no extra text, ONLY the JSON object.`,

          ascend: `You are Dream Mirror's ASCEND mode. Your purpose is to transform the message into its highest, most evolved form—the best possible version.
Tone: mystical + therapeutic + inspiring + poetic + empowering.

Analyze the user's message and return ONLY a valid JSON object with these exact keys:
{
  "interpretation": "One sentence showing their highest intent",
  "insight": "2-4 sentences about their potential and wisdom",
  "rewrite": "The most empowered, evolved version of their message",
  "soulNote": "One powerful, poetic line of transformation"
}

Be uplifting, mystical, and transformative. No markdown, no extra text, ONLY the JSON object.`
        }

        const response = await fetch('/api/proxy', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            protocol: 'https',
            origin: 'api.openai.com',
            path: '/v1/chat/completions',
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: {
              model: 'gpt-4o',
              messages: [
                { role: 'system', content: systemPrompts[mode] },
                { role: 'user', content: message }
              ],
              temperature: 0.9,
              max_tokens: 800
            }
          })
        })

        if (!response.ok) {
          throw new Error('Failed to connect to the mirror...')
        }

        const data = await response.json()
        const content = data.choices[0].message.content.trim()
        const parsed = JSON.parse(content) as ReflectionResult
        
        setComparisonResults(prev => ({ ...prev, [mode]: parsed }))
      } catch (err) {
        console.error(`Failed to analyze ${mode}:`, err)
      } finally {
        setComparisonLoading(prev => ({ ...prev, [mode]: false }))
      }
    }
  }

  const handleSaveReflection = (): void => {
    if (!result) return
    
    saveReflection({
      message,
      mode: activeMode,
      interpretation: result.interpretation,
      insight: result.insight,
      rewrite: result.rewrite,
      soulNote: result.soulNote
    })
    
    toast.success('Reflection saved to your collection')
  }

  const handleLoadReflection = (reflection: typeof savedReflections[0]): void => {
    setMessage(reflection.message)
    setActiveMode(reflection.mode)
    setResult({
      interpretation: reflection.interpretation,
      insight: reflection.insight,
      rewrite: reflection.rewrite,
      soulNote: reflection.soulNote
    })
    setShowSaved(false)
    setView('single')
    toast.success('Reflection loaded')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-purple-950 to-slate-950 text-white p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8 pt-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <Sparkles className="w-8 h-8 text-purple-400 animate-pulse" />
            <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
              Dream Mirror
            </h1>
            <Sparkles className="w-8 h-8 text-blue-400 animate-pulse" />
          </div>
          <p className="text-purple-300 text-lg">
            An advanced emotional-intent reflective engine
          </p>
          <p className="text-slate-400 text-sm italic">
            Enter any message you want to see reflected...
          </p>
        </div>

        {/* View Toggle & Saved Reflections Button */}
        <div className="flex flex-wrap items-center justify-center gap-4">
          <Button
            onClick={() => setView(view === 'single' ? 'comparison' : 'single')}
            variant="outline"
            className="bg-slate-900/50 border-purple-500/30 text-purple-300 hover:bg-purple-900/30"
          >
            <ArrowLeftRight className="mr-2 h-4 w-4" />
            {view === 'single' ? 'Compare All Modes' : 'Single Mode View'}
          </Button>
          <Button
            onClick={() => setShowSaved(!showSaved)}
            variant="outline"
            className="bg-slate-900/50 border-blue-500/30 text-blue-300 hover:bg-blue-900/30"
          >
            <BookmarkCheck className="mr-2 h-4 w-4" />
            {showSaved ? 'Hide' : 'Show'} Saved ({savedReflections.length})
          </Button>
        </div>

        {/* Saved Reflections */}
        {showSaved && isLoaded && (
          <SavedReflections
            reflections={savedReflections}
            onDelete={deleteReflection}
            onClearAll={clearAll}
            onLoad={handleLoadReflection}
          />
        )}

        {/* Input Card */}
        <Card className="bg-slate-900/50 border-purple-500/30 backdrop-blur">
          <CardHeader>
            <CardTitle className="text-purple-300">Your Message</CardTitle>
            <CardDescription className="text-slate-400">
              Speak your truth, and the mirror shall reveal its layers
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative">
              <Textarea
                value={message}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setMessage(e.target.value)}
                placeholder="Type your message here..."
                className="min-h-[120px] bg-slate-950/50 border-purple-500/30 text-white placeholder:text-slate-500 resize-none pr-14"
              />
              {isSupported && (
                <Button
                  onClick={handleVoiceInput}
                  disabled={isListening}
                  size="icon"
                  className={`absolute bottom-3 right-3 ${
                    isListening 
                      ? 'bg-red-600 hover:bg-red-700 animate-pulse' 
                      : 'bg-purple-600 hover:bg-purple-700'
                  }`}
                >
                  {isListening ? (
                    <MicOff className="h-4 w-4" />
                  ) : (
                    <Mic className="h-4 w-4" />
                  )}
                </Button>
              )}
            </div>
            {isListening && (
              <p className="text-purple-400 text-sm animate-pulse text-center">
                Listening... Speak now
              </p>
            )}
          </CardContent>
        </Card>

        {view === 'single' ? (
          <Tabs value={activeMode} onValueChange={(value: string) => setActiveMode(value as Mode)} className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-slate-900/50 border border-purple-500/30">
              <TabsTrigger 
                value="reflect" 
                className="data-[state=active]:bg-purple-600 data-[state=active]:text-white"
              >
                Reflect
              </TabsTrigger>
              <TabsTrigger 
                value="chaos" 
                className="data-[state=active]:bg-pink-600 data-[state=active]:text-white"
              >
                Chaos
              </TabsTrigger>
              <TabsTrigger 
                value="shadow" 
                className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white"
              >
                Shadow
              </TabsTrigger>
              <TabsTrigger 
                value="ascend" 
                className="data-[state=active]:bg-blue-600 data-[state=active]:text-white"
              >
                Ascend
              </TabsTrigger>
            </TabsList>

            <div className="mt-6 text-center space-y-4">
              <p className="text-slate-400 text-sm">{modeDescriptions[activeMode]}</p>
              <div className="flex flex-wrap items-center justify-center gap-4">
                <Button
                  onClick={() => analyzeMessage(activeMode)}
                  disabled={loading || !message.trim()}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-6 text-lg"
                >
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Gazing into the mirror...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-5 w-5" />
                      Reveal {activeMode.charAt(0).toUpperCase() + activeMode.slice(1)}
                    </>
                  )}
                </Button>
                {result && (
                  <Button
                    onClick={handleSaveReflection}
                    variant="outline"
                    className="bg-slate-900/50 border-blue-500/30 text-blue-300 hover:bg-blue-900/30 px-6 py-6"
                  >
                    <Save className="mr-2 h-5 w-5" />
                    Save This Reflection
                  </Button>
                )}
              </div>
            </div>

            {error && (
              <div className="mt-4 p-4 bg-red-950/50 border border-red-500/30 rounded-lg text-red-300 text-center">
                {error}
              </div>
            )}

            {result && (
              <div className="mt-8 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
                <Card className="bg-gradient-to-br from-purple-950/50 to-pink-950/50 border-purple-500/30 backdrop-blur">
                  <CardHeader>
                    <CardTitle className="text-purple-300 text-sm uppercase tracking-wider">
                      Interpretation
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-white text-lg">{result.interpretation}</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-indigo-950/50 to-purple-950/50 border-indigo-500/30 backdrop-blur">
                  <CardHeader>
                    <CardTitle className="text-indigo-300 text-sm uppercase tracking-wider">
                      Deep Insight
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-white leading-relaxed">{result.insight}</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-pink-950/50 to-purple-950/50 border-pink-500/30 backdrop-blur">
                  <CardHeader>
                    <CardTitle className="text-pink-300 text-sm uppercase tracking-wider">
                      The Upgrade
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-white italic leading-relaxed">{result.rewrite}</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-blue-950/50 to-indigo-950/50 border-blue-500/30 backdrop-blur">
                  <CardHeader>
                    <CardTitle className="text-blue-300 text-sm uppercase tracking-wider">
                      Soul Note
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-white text-xl font-light italic text-center py-4">
                      "{result.soulNote}"
                    </p>
                  </CardContent>
                </Card>
              </div>
            )}
          </Tabs>
        ) : (
          <div className="space-y-6">
            <div className="text-center">
              <Button
                onClick={analyzeAllModes}
                disabled={Object.values(comparisonLoading).some(Boolean) || !message.trim()}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-6 text-lg"
              >
                {Object.values(comparisonLoading).some(Boolean) ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Analyzing all perspectives...
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-5 w-5" />
                    Reveal All Four Mirrors
                  </>
                )}
              </Button>
            </div>

            {error && (
              <div className="p-4 bg-red-950/50 border border-red-500/30 rounded-lg text-red-300 text-center">
                {error}
              </div>
            )}

            <ComparisonView results={comparisonResults} loading={comparisonLoading} />
          </div>
        )}
      </div>
    </div>
  )
}
