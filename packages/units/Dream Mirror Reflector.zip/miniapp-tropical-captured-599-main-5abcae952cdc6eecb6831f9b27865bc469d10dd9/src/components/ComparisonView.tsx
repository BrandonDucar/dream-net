'use client'
import type React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Loader2 } from 'lucide-react'

interface ReflectionResult {
  interpretation: string
  insight: string
  rewrite: string
  soulNote: string
}

interface ComparisonViewProps {
  results: Record<string, ReflectionResult | null>
  loading: Record<string, boolean>
}

const modeInfo: Record<string, { title: string; color: string; gradientFrom: string; gradientTo: string; borderColor: string }> = {
  reflect: {
    title: 'Reflect',
    color: 'text-purple-300',
    gradientFrom: 'from-purple-950/50',
    gradientTo: 'to-pink-950/50',
    borderColor: 'border-purple-500/30'
  },
  chaos: {
    title: 'Chaos',
    color: 'text-pink-300',
    gradientFrom: 'from-pink-950/50',
    gradientTo: 'to-rose-950/50',
    borderColor: 'border-pink-500/30'
  },
  shadow: {
    title: 'Shadow',
    color: 'text-indigo-300',
    gradientFrom: 'from-indigo-950/50',
    gradientTo: 'to-purple-950/50',
    borderColor: 'border-indigo-500/30'
  },
  ascend: {
    title: 'Ascend',
    color: 'text-blue-300',
    gradientFrom: 'from-blue-950/50',
    gradientTo: 'to-indigo-950/50',
    borderColor: 'border-blue-500/30'
  }
}

export function ComparisonView({ results, loading }: ComparisonViewProps): React.JSX.Element {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {Object.entries(modeInfo).map(([mode, info]) => {
        const result = results[mode]
        const isLoading = loading[mode]

        return (
          <Card
            key={mode}
            className={`bg-gradient-to-br ${info.gradientFrom} ${info.gradientTo} ${info.borderColor} backdrop-blur`}
          >
            <CardHeader>
              <CardTitle className={`${info.color} text-xl uppercase tracking-wider text-center`}>
                {info.title}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {isLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
                </div>
              ) : result ? (
                <>
                  <div>
                    <p className="text-slate-400 text-xs uppercase tracking-wider mb-2">Interpretation</p>
                    <p className="text-white text-sm">{result.interpretation}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-xs uppercase tracking-wider mb-2">Insight</p>
                    <p className="text-white text-xs leading-relaxed">{result.insight}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-xs uppercase tracking-wider mb-2">Upgrade</p>
                    <p className="text-white text-xs italic leading-relaxed">{result.rewrite}</p>
                  </div>
                  <div className="pt-2 border-t border-slate-700/30">
                    <p className="text-white text-sm font-light italic text-center">
                      "{result.soulNote}"
                    </p>
                  </div>
                </>
              ) : (
                <p className="text-slate-500 text-center py-12 italic text-sm">
                  Awaiting reflection...
                </p>
              )}
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
