'use client'
import type React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Trash2, Clock } from 'lucide-react'
import type { SavedReflection } from '@/hooks/useSavedReflections'

interface SavedReflectionsProps {
  reflections: SavedReflection[]
  onDelete: (id: string) => void
  onClearAll: () => void
  onLoad: (reflection: SavedReflection) => void
}

const modeColors: Record<string, string> = {
  reflect: 'bg-purple-600',
  chaos: 'bg-pink-600',
  shadow: 'bg-indigo-600',
  ascend: 'bg-blue-600'
}

export function SavedReflections({ reflections, onDelete, onClearAll, onLoad }: SavedReflectionsProps): React.JSX.Element {
  const formatDate = (timestamp: number): string => {
    const date = new Date(timestamp)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / 60000)
    const diffHours = Math.floor(diffMs / 3600000)
    const diffDays = Math.floor(diffMs / 86400000)

    if (diffMins < 1) return 'Just now'
    if (diffMins < 60) return `${diffMins}m ago`
    if (diffHours < 24) return `${diffHours}h ago`
    if (diffDays < 7) return `${diffDays}d ago`
    
    return date.toLocaleDateString()
  }

  return (
    <Card className="bg-slate-900/50 border-purple-500/30 backdrop-blur">
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle className="text-purple-300">Saved Reflections</CardTitle>
        {reflections.length > 0 && (
          <Button
            onClick={onClearAll}
            variant="ghost"
            size="sm"
            className="text-red-400 hover:text-red-300 hover:bg-red-950/30"
          >
            Clear All
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {reflections.length === 0 ? (
          <p className="text-slate-400 text-center py-8 italic">
            No saved reflections yet. Your insights will appear here...
          </p>
        ) : (
          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-4">
              {reflections.map((reflection: SavedReflection) => (
                <Card
                  key={reflection.id}
                  className="bg-slate-950/50 border-slate-700/30 hover:border-purple-500/50 transition-all cursor-pointer"
                  onClick={() => onLoad(reflection)}
                >
                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className={`${modeColors[reflection.mode]} text-white text-xs px-2 py-1 rounded-full uppercase tracking-wider`}>
                        {reflection.mode}
                      </span>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1 text-slate-500 text-xs">
                          <Clock className="w-3 h-3" />
                          {formatDate(reflection.timestamp)}
                        </div>
                        <Button
                          onClick={(e: React.MouseEvent) => {
                            e.stopPropagation()
                            onDelete(reflection.id)
                          }}
                          variant="ghost"
                          size="sm"
                          className="h-7 w-7 p-0 text-slate-500 hover:text-red-400 hover:bg-red-950/30"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-slate-300 text-sm line-clamp-2">
                      {reflection.message}
                    </p>
                    <p className="text-purple-300 text-xs italic line-clamp-1">
                      "{reflection.soulNote}"
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  )
}
