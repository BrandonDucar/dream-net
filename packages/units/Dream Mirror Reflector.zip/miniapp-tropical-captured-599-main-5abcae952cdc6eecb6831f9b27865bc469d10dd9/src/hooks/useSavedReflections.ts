'use client'
import { useState, useEffect } from 'react'

export interface SavedReflection {
  id: string
  message: string
  mode: 'reflect' | 'chaos' | 'shadow' | 'ascend'
  interpretation: string
  insight: string
  rewrite: string
  soulNote: string
  timestamp: number
}

export function useSavedReflections() {
  const [savedReflections, setSavedReflections] = useState<SavedReflection[]>([])
  const [isLoaded, setIsLoaded] = useState<boolean>(false)

  useEffect(() => {
    const stored = localStorage.getItem('dream-mirror-reflections')
    if (stored) {
      try {
        const parsed = JSON.parse(stored) as SavedReflection[]
        setSavedReflections(parsed)
      } catch (error) {
        console.error('Failed to parse saved reflections', error)
      }
    }
    setIsLoaded(true)
  }, [])

  const saveReflection = (reflection: Omit<SavedReflection, 'id' | 'timestamp'>): void => {
    const newReflection: SavedReflection = {
      ...reflection,
      id: Math.random().toString(36).substring(7),
      timestamp: Date.now()
    }
    const updated = [newReflection, ...savedReflections]
    setSavedReflections(updated)
    localStorage.setItem('dream-mirror-reflections', JSON.stringify(updated))
  }

  const deleteReflection = (id: string): void => {
    const updated = savedReflections.filter((r: SavedReflection) => r.id !== id)
    setSavedReflections(updated)
    localStorage.setItem('dream-mirror-reflections', JSON.stringify(updated))
  }

  const clearAll = (): void => {
    setSavedReflections([])
    localStorage.removeItem('dream-mirror-reflections')
  }

  return {
    savedReflections,
    saveReflection,
    deleteReflection,
    clearAll,
    isLoaded
  }
}
