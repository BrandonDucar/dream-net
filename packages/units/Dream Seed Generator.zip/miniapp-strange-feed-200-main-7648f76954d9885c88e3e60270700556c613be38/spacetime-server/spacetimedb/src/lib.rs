use spacetimedb::{
    table, reducer, ReducerContext, Identity, Table, Timestamp, ScheduleAt, SpacetimeType,
};
use spacetimedb::log;
use std::time::Duration;

const SESSION_TIMEOUT_SECONDS: u64 = 30;
const CLEANER_INTERVAL_SECONDS: u64 = 10;

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum StartupRole {
    Owner,
    Admin,
    Contributor,
    Viewer,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum MemberStatus {
    Active,
    Pending,
    Removed,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum InviteStatus {
    Pending,
    Accepted,
    Declined,
    Revoked,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum ActivityType {
    KitCreated,
    SectionAdded,
    SectionUpdated,
    CommentAdded,
    InviteSent,
    InviteResponded,
    SessionStarted,
    SessionEnded,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum LiveEditStatus {
    Active,
    Ended,
}

#[table(name = startup_kit, public)]
#[derive(Clone)]
pub struct StartupKit {
    #[primary_key]
    #[auto_inc]
    kit_id: u64,
    owner: Identity,
    name: String,
    summary: String,
    problem: String,
    solution: String,
    target_market: String,
    created_at: Timestamp,
    updated_at: Timestamp,
    is_archived: bool,
    last_editor: Identity,
}

#[table(
    name = team_member,
    public,
    index(name = team_member_kit_idx, btree(columns = [kit_id])),
    index(name = team_member_identity_idx, btree(columns = [member]))
)]
#[derive(Clone)]
pub struct TeamMember {
    #[primary_key]
    #[auto_inc]
    membership_id: u64,
    kit_id: u64,
    member: Identity,
    role: StartupRole,
    status: MemberStatus,
    can_edit: bool,
    joined_at: Timestamp,
}

#[table(
    name = team_invite,
    public,
    index(name = team_invite_kit_idx, btree(columns = [kit_id])),
    index(name = team_invite_invitee_idx, btree(columns = [invitee]))
)]
#[derive(Clone)]
pub struct TeamInvite {
    #[primary_key]
    #[auto_inc]
    invite_id: u64,
    kit_id: u64,
    inviter: Identity,
    invitee: Identity,
    role: StartupRole,
    status: InviteStatus,
    message: String,
    created_at: Timestamp,
}

#[table(
    name = kit_section,
    public,
    index(name = kit_section_kit_idx, btree(columns = [kit_id]))
)]
#[derive(Clone)]
pub struct KitSection {
    #[primary_key]
    #[auto_inc]
    section_id: u64,
    kit_id: u64,
    title: String,
    content: String,
    last_updated: Timestamp,
    last_editor: Identity,
}

#[table(
    name = section_comment,
    public,
    index(name = comment_section_idx, btree(columns = [section_id])),
    index(name = comment_kit_idx, btree(columns = [kit_id]))
)]
#[derive(Clone)]
pub struct SectionComment {
    #[primary_key]
    #[auto_inc]
    comment_id: u64,
    kit_id: u64,
    section_id: u64,
    parent_comment_id: u64,
    author: Identity,
    body: String,
    created_at: Timestamp,
}

#[table(
    name = activity_log,
    public,
    index(name = activity_kit_idx, btree(columns = [kit_id]))
)]
#[derive(Clone)]
pub struct ActivityLog {
    #[primary_key]
    #[auto_inc]
    log_id: u64,
    kit_id: u64,
    actor: Identity,
    activity_type: ActivityType,
    summary: String,
    reference_id: u64,
    created_at: Timestamp,
}

#[table(
    name = live_editing_session,
    public,
    index(name = live_session_kit_idx, btree(columns = [kit_id])),
    index(name = live_session_section_idx, btree(columns = [section_id]))
)]
#[derive(Clone)]
pub struct LiveEditingSession {
    #[primary_key]
    #[auto_inc]
    session_id: u64,
    kit_id: u64,
    section_id: u64,
    editor: Identity,
    cursor_offset: u32,
    started_at: Timestamp,
    last_heartbeat: Timestamp,
    status: LiveEditStatus,
}

#[table(name = session_cleaner_schedule, scheduled(clean_expired_sessions))]
#[derive(Clone)]
pub struct SessionCleanerSchedule {
    #[primary_key]
    #[auto_inc]
    schedule_id: u64,
    scheduled_at: ScheduleAt,
}

fn role_can_edit(role: &StartupRole) -> bool {
    matches!(role, StartupRole::Owner | StartupRole::Admin | StartupRole::Contributor)
}

fn member_can_manage_team(role: &StartupRole) -> bool {
    matches!(role, StartupRole::Owner | StartupRole::Admin)
}

fn find_active_member(ctx: &ReducerContext, kit_id: u64, identity: Identity) -> Option<TeamMember> {
    ctx.db
        .team_member()
        .iter()
        .find(|member| member.kit_id == kit_id && member.member == identity && member.status == MemberStatus::Active)
}

fn ensure_active_member(ctx: &ReducerContext, kit_id: u64, identity: Identity) -> Result<TeamMember, String> {
    find_active_member(ctx, kit_id, identity).ok_or_else(|| "You are not an active member of this startup kit".to_string())
}

fn ensure_edit_permission(ctx: &ReducerContext, kit_id: u64, identity: Identity) -> Result<TeamMember, String> {
    let member = ensure_active_member(ctx, kit_id, identity)?;
    if !member.can_edit {
        return Err("You do not have edit permissions for this kit".into());
    }
    Ok(member)
}

fn record_activity(
    ctx: &ReducerContext,
    kit_id: u64,
    activity_type: ActivityType,
    summary: String,
    reference_id: u64,
    actor: Identity,
) {
    let entry = ActivityLog {
        log_id: 0,
        kit_id,
        actor,
        activity_type,
        summary,
        reference_id,
        created_at: ctx.timestamp,
    };
    if let Err(e) = ctx.db.activity_log().try_insert(entry) {
        log::error!("Failed to record activity for kit {}: {}", kit_id, e);
    }
}

fn touch_kit(ctx: &ReducerContext, kit_id: u64, editor: Identity) -> Result<(), String> {
    if let Some(mut kit) = ctx.db.startup_kit().kit_id().find(&kit_id) {
        kit.updated_at = ctx.timestamp;
        kit.last_editor = editor;
        ctx.db.startup_kit().kit_id().update(kit);
        Ok(())
    } else {
        Err("Startup kit not found".into())
    }
}

fn get_section_for_kit(ctx: &ReducerContext, kit_id: u64, section_id: u64) -> Result<KitSection, String> {
    if let Some(section) = ctx.db.kit_section().section_id().find(&section_id) {
        if section.kit_id == kit_id {
            Ok(section)
        } else {
            Err("Section does not belong to the provided kit".into())
        }
    } else {
        Err("Section not found".into())
    }
}

fn find_active_session_id(ctx: &ReducerContext, kit_id: u64, section_id: u64, editor: Identity) -> Option<u64> {
    ctx.db
        .live_editing_session()
        .iter()
        .find(|session| {
            session.kit_id == kit_id
                && session.section_id == section_id
                && session.editor == editor
                && session.status == LiveEditStatus::Active
        })
        .map(|session| session.session_id)
}

#[reducer(init)]
pub fn init(ctx: &ReducerContext) -> Result<(), String> {
    log::info!("Collaborative startup platform initializing");
    if ctx.db.session_cleaner_schedule().count() == 0 {
        let schedule = SessionCleanerSchedule {
            schedule_id: 0,
            scheduled_at: ScheduleAt::Interval(Duration::from_secs(CLEANER_INTERVAL_SECONDS).into()),
        };
        if let Err(e) = ctx.db.session_cleaner_schedule().try_insert(schedule) {
            log::error!("Failed to schedule session cleaner: {}", e);
        }
    }
    Ok(())
}

#[reducer(client_connected)]
pub fn client_connected(ctx: &ReducerContext) {
    log::info!("Client connected: {}", ctx.sender);
}

#[reducer(client_disconnected)]
pub fn client_disconnected(ctx: &ReducerContext) {
    let mut affected_sessions = Vec::new();
    for session in ctx.db.live_editing_session().iter() {
        if session.editor == ctx.sender && session.status == LiveEditStatus::Active {
            affected_sessions.push((session.session_id, session.kit_id, session.section_id, session.editor));
        }
    }
    for (session_id, kit_id, section_id, editor) in affected_sessions {
        if let Some(mut session) = ctx.db.live_editing_session().session_id().find(&session_id) {
            session.status = LiveEditStatus::Ended;
            session.last_heartbeat = ctx.timestamp;
            ctx.db.live_editing_session().session_id().update(session);
            let summary = format!("Session {} closed after disconnection", session_id);
            record_activity(ctx, kit_id, ActivityType::SessionEnded, summary, section_id, editor);
        }
    }
    log::info!("Client disconnected: {}", ctx.sender);
}

#[reducer]
pub fn create_startup_kit(
    ctx: &ReducerContext,
    name: String,
    summary: String,
    problem: String,
    solution: String,
    target_market: String,
) -> Result<(), String> {
    let normalized_name = name.trim().to_string();
    if normalized_name.is_empty() {
        return Err("Startup kit name cannot be empty".into());
    }
    let normalized_summary = summary.trim().to_string();
    if normalized_summary.is_empty() {
        return Err("Summary cannot be empty".into());
    }
    let now = ctx.timestamp;
    let new_kit = StartupKit {
        kit_id: 0,
        owner: ctx.sender,
        name: normalized_name.clone(),
        summary: normalized_summary,
        problem,
        solution,
        target_market,
        created_at: now,
        updated_at: now,
        is_archived: false,
        last_editor: ctx.sender,
    };
    let inserted_kit = match ctx.db.startup_kit().try_insert(new_kit) {
        Ok(kit) => kit,
        Err(e) => {
            let msg = format!("Unable to create startup kit: {}", e);
            log::error!("{}", msg);
            return Err(msg);
        }
    };

    let owner_member = TeamMember {
        membership_id: 0,
        kit_id: inserted_kit.kit_id,
        member: ctx.sender,
        role: StartupRole::Owner,
        status: MemberStatus::Active,
        can_edit: true,
        joined_at: now,
    };
    if let Err(e) = ctx.db.team_member().try_insert(owner_member) {
        log::error!("Failed to register owner membership: {}", e);
    }

    let summary_text = format!("{} created startup kit '{}'", ctx.sender, inserted_kit.name.clone());
    record_activity(
        ctx,
        inserted_kit.kit_id,
        ActivityType::KitCreated,
        summary_text,
        inserted_kit.kit_id,
        ctx.sender,
    );

    log::info!("Startup kit {} created by {}", inserted_kit.kit_id, ctx.sender);
    Ok(())
}

#[reducer]
pub fn add_section(ctx: &ReducerContext, kit_id: u64, title: String, content: String) -> Result<(), String> {
    let member = ensure_edit_permission(ctx, kit_id, ctx.sender)?;
    let kit = ctx
        .db
        .startup_kit()
        .kit_id()
        .find(&kit_id)
        .ok_or_else(|| "Startup kit not found".to_string())?;
    let kit_name = kit.name.clone();

    let section_title = title.trim().to_string();
    if section_title.is_empty() {
        return Err("Section title cannot be empty".into());
    }
    let section_content = content.trim().to_string();
    if section_content.is_empty() {
        return Err("Section content cannot be empty".into());
    }

    let new_section = KitSection {
        section_id: 0,
        kit_id,
        title: section_title.clone(),
        content: section_content.clone(),
        last_updated: ctx.timestamp,
        last_editor: ctx.sender,
    };

    let inserted_section = match ctx.db.kit_section().try_insert(new_section) {
        Ok(section) => section,
        Err(e) => {
            let msg = format!("Unable to add section: {}", e);
            log::error!("{}", msg);
            return Err(msg);
        }
    };

    touch_kit(ctx, kit_id, ctx.sender)?;

    let summary_text = format!("{} added section '{}' to {}", member.member, section_title, kit_name);
    record_activity(
        ctx,
        kit_id,
        ActivityType::SectionAdded,
        summary_text,
        inserted_section.section_id,
        ctx.sender,
    );

    Ok(())
}

#[reducer]
pub fn update_section_content(
    ctx: &ReducerContext,
    kit_id: u64,
    section_id: u64,
    content: String,
    cursor_offset: u32,
) -> Result<(), String> {
    let _member = ensure_edit_permission(ctx, kit_id, ctx.sender)?;
    let mut section = get_section_for_kit(ctx, kit_id, section_id)?;
    let section_title = section.title.clone();
    let previous_length = section.content.len();

    let sanitized_content = content.trim().to_string();
    if sanitized_content.is_empty() {
        return Err("Updated section content cannot be empty".into());
    }
    let new_length = sanitized_content.len();

    section.content = sanitized_content;
    section.last_updated = ctx.timestamp;
    section.last_editor = ctx.sender;
    ctx.db.kit_section().section_id().update(section);

    touch_kit(ctx, kit_id, ctx.sender)?;

    if let Some(existing_session_id) = find_active_session_id(ctx, kit_id, section_id, ctx.sender) {
        if let Some(mut session) = ctx.db.live_editing_session().session_id().find(&existing_session_id) {
            session.cursor_offset = cursor_offset;
            session.last_heartbeat = ctx.timestamp;
            let refreshed_session_id = session.session_id;
            ctx.db.live_editing_session().session_id().update(session);
            log::debug!("Refreshed live session {} during section update", refreshed_session_id);
        }
    }

    let summary_text = format!(
        "{} updated section '{}' ({} → {} chars)",
        ctx.sender, section_title, previous_length, new_length
    );
    record_activity(
        ctx,
        kit_id,
        ActivityType::SectionUpdated,
        summary_text,
        section_id,
        ctx.sender,
    );

    Ok(())
}

#[reducer]
pub fn add_comment(
    ctx: &ReducerContext,
    kit_id: u64,
    section_id: u64,
    parent_comment_id: u64,
    body: String,
) -> Result<(), String> {
    let member = ensure_active_member(ctx, kit_id, ctx.sender)?;
    let section = get_section_for_kit(ctx, kit_id, section_id)?;
    let section_title = section.title.clone();

    if parent_comment_id != 0 {
        if let Some(parent) = ctx.db.section_comment().comment_id().find(&parent_comment_id) {
            if parent.section_id != section_id {
                return Err("Parent comment belongs to another section".into());
            }
        } else {
            return Err("Parent comment not found".into());
        }
    }

    let trimmed_body = body.trim().to_string();
    if trimmed_body.is_empty() {
        return Err("Comment body cannot be empty".into());
    }

    let comment = SectionComment {
        comment_id: 0,
        kit_id,
        section_id,
        parent_comment_id,
        author: ctx.sender,
        body: trimmed_body.clone(),
        created_at: ctx.timestamp,
    };

    let inserted_comment = match ctx.db.section_comment().try_insert(comment) {
        Ok(row) => row,
        Err(e) => {
            let msg = format!("Unable to add comment: {}", e);
            log::error!("{}", msg);
            return Err(msg);
        }
    };

    touch_kit(ctx, kit_id, ctx.sender)?;

    let summary_text = format!(
        "{} commented on section '{}': {}",
        member.member,
        section_title,
        trimmed_body
    );
    record_activity(
        ctx,
        kit_id,
        ActivityType::CommentAdded,
        summary_text,
        inserted_comment.comment_id,
        ctx.sender,
    );

    Ok(())
}

#[reducer]
pub fn invite_member(
    ctx: &ReducerContext,
    kit_id: u64,
    invitee: Identity,
    role: StartupRole,
    message: String,
) -> Result<(), String> {
    let inviter_member = ensure_active_member(ctx, kit_id, ctx.sender)?;
    if !member_can_manage_team(&inviter_member.role) {
        return Err("Only owners or admins can send invites".into());
    }

    if find_active_member(ctx, kit_id, invitee).is_some() {
        return Err("Invitee is already part of this startup kit".into());
    }

    let has_pending = ctx
        .db
        .team_invite()
        .iter()
        .any(|invite| invite.kit_id == kit_id && invite.invitee == invitee && invite.status == InviteStatus::Pending);
    if has_pending {
        return Err("An invitation for this member is already pending".into());
    }

    let invite_message = message.trim().to_string();
    let new_invite = TeamInvite {
        invite_id: 0,
        kit_id,
        inviter: ctx.sender,
        invitee,
        role: role.clone(),
        status: InviteStatus::Pending,
        message: invite_message,
        created_at: ctx.timestamp,
    };

    let inserted_invite = match ctx.db.team_invite().try_insert(new_invite) {
        Ok(invite) => invite,
        Err(e) => {
            let msg = format!("Unable to send invite: {}", e);
            log::error!("{}", msg);
            return Err(msg);
        }
    };

    let summary_text = format!("{} invited {} as {:?}", ctx.sender, invitee, role);
    record_activity(
        ctx,
        kit_id,
        ActivityType::InviteSent,
        summary_text,
        inserted_invite.invite_id,
        ctx.sender,
    );

    Ok(())
}

#[reducer]
pub fn respond_to_invite(ctx: &ReducerContext, invite_id: u64, accept: bool) -> Result<(), String> {
    let mut invite = ctx
        .db
        .team_invite()
        .invite_id()
        .find(&invite_id)
        .ok_or_else(|| "Invite not found".to_string())?;

    if invite.invitee != ctx.sender {
        return Err("You are not authorized to respond to this invite".into());
    }

    if invite.status != InviteStatus::Pending {
        return Err("This invite has already been processed".into());
    }

    let kit_id = invite.kit_id;
    let invitee = invite.invitee;
    let role_for_member = invite.role.clone();

    if accept {
        let can_edit = role_can_edit(&role_for_member);
        let mut existing_membership_id = None;
        for member in ctx.db.team_member().iter() {
            if member.kit_id == kit_id && member.member == invitee {
                existing_membership_id = Some(member.membership_id);
                break;
            }
        }

        if let Some(membership_id) = existing_membership_id {
            if let Some(mut member) = ctx.db.team_member().membership_id().find(&membership_id) {
                member.status = MemberStatus::Active;
                member.role = role_for_member.clone();
                member.can_edit = can_edit;
                member.joined_at = ctx.timestamp;
                ctx.db.team_member().membership_id().update(member);
            }
        } else {
            let new_member = TeamMember {
                membership_id: 0,
                kit_id,
                member: invitee,
                role: role_for_member.clone(),
                status: MemberStatus::Active,
                can_edit,
                joined_at: ctx.timestamp,
            };
            if let Err(e) = ctx.db.team_member().try_insert(new_member) {
                let msg = format!("Unable to add new member: {}", e);
                log::error!("{}", msg);
                return Err(msg);
            }
        }
    }

    invite.status = if accept {
        InviteStatus::Accepted
    } else {
        InviteStatus::Declined
    };
    let updated_status = invite.status.clone();
    ctx.db.team_invite().invite_id().update(invite);

    let summary_text = if accept {
        format!("{} accepted invite to join kit {} as {:?}", invitee, kit_id, role_for_member)
    } else {
        format!("{} declined invite to kit {}", invitee, kit_id)
    };
    record_activity(
        ctx,
        kit_id,
        ActivityType::InviteResponded,
        summary_text,
        invite_id,
        ctx.sender,
    );

    if accept {
        touch_kit(ctx, kit_id, ctx.sender)?;
    }

    log::info!("Invite {} responded with {:?}", invite_id, updated_status);
    Ok(())
}

#[reducer]
pub fn join_live_session(ctx: &ReducerContext, kit_id: u64, section_id: u64, cursor_offset: u32) -> Result<(), String> {
    ensure_edit_permission(ctx, kit_id, ctx.sender)?;
    let section = get_section_for_kit(ctx, kit_id, section_id)?;
    let section_title = section.title.clone();

    if let Some(existing_id) = find_active_session_id(ctx, kit_id, section_id, ctx.sender) {
        if let Some(mut session) = ctx.db.live_editing_session().session_id().find(&existing_id) {
            session.cursor_offset = cursor_offset;
            session.last_heartbeat = ctx.timestamp;
            let session_id_copy = session.session_id;
            ctx.db.live_editing_session().session_id().update(session);
            log::info!("Refreshed existing live session {}", session_id_copy);
        }
    } else {
        let new_session = LiveEditingSession {
            session_id: 0,
            kit_id,
            section_id,
            editor: ctx.sender,
            cursor_offset,
            started_at: ctx.timestamp,
            last_heartbeat: ctx.timestamp,
            status: LiveEditStatus::Active,
        };
        let inserted_session = match ctx.db.live_editing_session().try_insert(new_session) {
            Ok(session) => session,
            Err(e) => {
                let msg = format!("Unable to start live session: {}", e);
                log::error!("{}", msg);
                return Err(msg);
            }
        };
        let summary_text = format!("{} started live editing '{}'", ctx.sender, section_title);
        record_activity(
            ctx,
            kit_id,
            ActivityType::SessionStarted,
            summary_text,
            inserted_session.session_id,
            ctx.sender,
        );
        log::info!(
            "Live session {} started for section {}",
            inserted_session.session_id,
            section_id
        );
    }

    Ok(())
}

#[reducer]
pub fn leave_live_session(ctx: &ReducerContext, session_id: u64) -> Result<(), String> {
    let mut session = ctx
        .db
        .live_editing_session()
        .session_id()
        .find(&session_id)
        .ok_or_else(|| "Live editing session not found".to_string())?;

    if session.editor != ctx.sender {
        return Err("You are not the editor of this session".into());
    }

    session.status = LiveEditStatus::Ended;
    session.last_heartbeat = ctx.timestamp;
    let kit_id = session.kit_id;
    let section_id = session.section_id;
    let editor = session.editor;
    ctx.db.live_editing_session().session_id().update(session);

    let summary_text = format!("{} ended live editing session {}", editor, session_id);
    record_activity(
        ctx,
        kit_id,
        ActivityType::SessionEnded,
        summary_text,
        section_id,
        ctx.sender,
    );

    Ok(())
}

#[reducer]
pub fn heartbeat_live_session(ctx: &ReducerContext, session_id: u64, cursor_offset: u32) -> Result<(), String> {
    let mut session = ctx
        .db
        .live_editing_session()
        .session_id()
        .find(&session_id)
        .ok_or_else(|| "Live editing session not found".to_string())?;

    if session.editor != ctx.sender {
        return Err("You are not the editor of this session".into());
    }

    if session.status != LiveEditStatus::Active {
        return Err("This session is no longer active".into());
    }

    session.cursor_offset = cursor_offset;
    session.last_heartbeat = ctx.timestamp;
    ctx.db.live_editing_session().session_id().update(session);

    Ok(())
}

#[reducer]
pub fn clean_expired_sessions(ctx: &ReducerContext, _schedule: SessionCleanerSchedule) -> Result<(), String> {
    if ctx.sender != ctx.identity() {
        return Err("Reducer 'clean_expired_sessions' may only be invoked by the scheduler".into());
    }

    let timeout_micros = (SESSION_TIMEOUT_SECONDS as i64) * 1_000_000;
    let now_micros = ctx.timestamp.to_micros_since_unix_epoch();

    let mut expired_sessions = Vec::new();
    for session in ctx.db.live_editing_session().iter() {
        if session.status == LiveEditStatus::Active {
            let last_micros = session.last_heartbeat.to_micros_since_unix_epoch();
            let elapsed = now_micros.saturating_sub(last_micros);
            if elapsed > timeout_micros {
                expired_sessions.push((session.session_id, session.kit_id, session.section_id, session.editor));
            }
        }
    }

    for (session_id, kit_id, section_id, editor) in expired_sessions {
        if let Some(mut session) = ctx.db.live_editing_session().session_id().find(&session_id) {
            session.status = LiveEditStatus::Ended;
            session.last_heartbeat = ctx.timestamp;
            ctx.db.live_editing_session().session_id().update(session);
            let summary = format!("Session {} automatically closed for inactivity", session_id);
            record_activity(
                ctx,
                kit_id,
                ActivityType::SessionEnded,
                summary,
                section_id,
                editor,
            );
        }
    }

    log::debug!("Expired live editing sessions cleanup completed");
    Ok(())
}