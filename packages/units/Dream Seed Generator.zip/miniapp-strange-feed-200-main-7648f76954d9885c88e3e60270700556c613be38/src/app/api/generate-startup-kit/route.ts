import { NextRequest, NextResponse } from 'next/server'
import { openaiChatCompletion } from '@/openai-api'
import { perplexityResearch } from '@/perplexity-api'
import { exaSearch } from '@/exa-api'
import { xaiLiveSearch } from '@/xai-api'

interface MarketData {
  marketSize: string
  trends: string[]
  competitors: string[]
  opportunities: string[]
}

interface LocationData {
  country: string
  city: string
  timeZone: string
}

export async function POST(request: NextRequest) {
  try {
    const { businessIdea, location } = await request.json()

    if (!businessIdea?.trim()) {
      return NextResponse.json(
        { error: 'Business idea is required' },
        { status: 400 }
      )
    }

    // Step 1: Conduct comprehensive market research
    const marketData = await conductMarketResearch(businessIdea)

    // Step 2: Generate enhanced content using OpenAI
    const kit = await generateEnhancedContent(businessIdea, marketData, location)

    return NextResponse.json(kit)
  } catch (error) {
    console.error('Startup kit generation error:', error)
    return NextResponse.json(
      { error: 'Failed to generate startup kit' },
      { status: 500 }
    )
  }
}

async function conductMarketResearch(businessIdea: string): Promise<MarketData> {
  try {
    // Use multiple AI sources for comprehensive research
    const [perplexityResult, exaResult, xaiResult] = await Promise.allSettled([
      perplexityResearch(`Market size, trends, and opportunities for ${businessIdea} industry in 2024`, { temperature: 0.1 }),
      exaSearch({ query: `${businessIdea} market size competitors trends 2024`, text: true }),
      xaiLiveSearch({ 
        messages: [{ role: 'user', content: `What are the latest market trends, size, and key competitors in the ${businessIdea} industry?` }],
        search_parameters: { mode: 'on', return_citations: true }
      })
    ])

    let marketSize = 'Growing market with significant opportunity'
    let trends: string[] = []
    let competitors: string[] = []
    let opportunities: string[] = []

    // Process Perplexity research
    if (perplexityResult.status === 'fulfilled') {
      const research = perplexityResult.value
      const lines = research.answer.split('\n').filter(line => line.trim())
      
      lines.forEach(line => {
        if (line.toLowerCase().includes('market size') || line.toLowerCase().includes('billion') || line.toLowerCase().includes('million')) {
          marketSize = line.trim()
        }
        if (line.toLowerCase().includes('trend') && !line.toLowerCase().includes('market size')) {
          trends.push(line.trim())
        }
        if (line.toLowerCase().includes('competitor') || line.toLowerCase().includes('company')) {
          competitors.push(line.trim())
        }
        if (line.toLowerCase().includes('opportunity') || line.toLowerCase().includes('potential')) {
          opportunities.push(line.trim())
        }
      })
    }

    // Process Exa results
    if (exaResult.status === 'fulfilled' && exaResult.value.results) {
      exaResult.value.results.slice(0, 3).forEach(result => {
        if (result.title) {
          trends.push(`Industry insight: ${result.title}`)
        }
      })
    }

    // Process xAI results
    if (xaiResult.status === 'fulfilled' && xaiResult.value.choices?.[0]) {
      const xaiContent = xaiResult.value.choices[0].message.content
      if (xaiContent) {
        const xaiLines = xaiContent.split('\n').filter(line => line.trim())
        xaiLines.slice(0, 2).forEach(line => {
          if (line.toLowerCase().includes('opportunity') || line.toLowerCase().includes('trend')) {
            opportunities.push(line.trim())
          }
        })
      }
    }

    return {
      marketSize: marketSize || `The ${businessIdea} market shows strong growth potential`,
      trends: trends.length > 0 ? trends.slice(0, 5) : [
        'Digital transformation accelerating adoption',
        'Increased demand for automation',
        'Growing focus on user experience',
        'Mobile-first approach trending',
        'AI integration becoming standard'
      ],
      competitors: competitors.length > 0 ? competitors.slice(0, 5) : [
        'Established industry leaders',
        'Emerging tech startups', 
        'Traditional companies digitalizing',
        'Niche specialized providers',
        'International market players'
      ],
      opportunities: opportunities.length > 0 ? opportunities.slice(0, 5) : [
        'Underserved market segments',
        'Technology gaps in current solutions',
        'Changing customer preferences',
        'Regulatory shifts creating openings',
        'Geographic expansion potential'
      ]
    }
  } catch (error) {
    console.error('Market research error:', error)
    return {
      marketSize: `The ${businessIdea} market shows strong growth potential`,
      trends: ['Digital transformation accelerating', 'User experience focus increasing'],
      competitors: ['Established players', 'Emerging startups'],
      opportunities: ['Market gaps exist', 'Innovation opportunities available']
    }
  }
}

async function generateEnhancedContent(businessIdea: string, marketData: MarketData, location?: LocationData) {
  try {
    const prompt = `You are an expert startup advisor and business strategist. Generate comprehensive startup content for: "${businessIdea}"

Market Intelligence Context:
- Market Size: ${marketData.marketSize}
- Location: ${location ? `${location.city}, ${location.country}` : 'Global'}
- Key Trends: ${marketData.trends.join(', ')}
- Competitors: ${marketData.competitors.join(', ')}
- Opportunities: ${marketData.opportunities.join(', ')}

Create a JSON response with EXACTLY this structure. Be creative, specific, and professional:

{
  "names": [3 creative, memorable business names that reflect the idea],
  "slogan": "A powerful, memorable slogan that captures the essence",
  "logoPrompt": "Detailed prompt for AI logo generation including style, colors, symbols, and feeling",
  "pitchDeck": {
    "problem": "Clear problem statement with market pain points",
    "solution": "How your solution addresses the problem uniquely", 
    "market": "Market size and opportunity analysis",
    "product": "Detailed product/service description",
    "businessModel": "Clear revenue generation strategy",
    "competition": "Competitive landscape and differentiation",
    "team": "Ideal team composition and expertise needed",
    "traction": "Initial traction strategy and metrics",
    "financials": "Revenue projections and key financial metrics",
    "ask": "Funding requirements and use of funds"
  },
  "landingPage": {
    "headline": "Compelling main headline",
    "subheadline": "Supporting value proposition",
    "benefits": [4 key customer benefits],
    "cta": "Strong call-to-action text",
    "features": [
      {"title": "Feature 1", "description": "Detailed description"},
      {"title": "Feature 2", "description": "Detailed description"},
      {"title": "Feature 3", "description": "Detailed description"}
    ]
  },
  "marketingPlan": [
    {"day": 1, "activity": "Specific marketing activity", "goal": "Clear measurable goal"},
    {"day": 2, "activity": "Specific marketing activity", "goal": "Clear measurable goal"},
    {"day": 3, "activity": "Specific marketing activity", "goal": "Clear measurable goal"},
    {"day": 4, "activity": "Specific marketing activity", "goal": "Clear measurable goal"},
    {"day": 5, "activity": "Specific marketing activity", "goal": "Clear measurable goal"},
    {"day": 6, "activity": "Specific marketing activity", "goal": "Clear measurable goal"},
    {"day": 7, "activity": "Specific marketing activity", "goal": "Clear measurable goal"}
  ],
  "pricing": [
    {"tier": "Starter", "price": "$X/month", "features": ["feature1", "feature2", "feature3", "feature4"]},
    {"tier": "Professional", "price": "$Y/month", "features": ["feature1", "feature2", "feature3", "feature4", "feature5"]},
    {"tier": "Enterprise", "price": "Custom", "features": ["feature1", "feature2", "feature3", "feature4", "feature5", "feature6"]}
  ]
}

Make everything specific to the business idea, avoiding generic responses. Use the market intelligence to inform realistic pricing, competitive positioning, and growth strategies.`

    const response = await openaiChatCompletion({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: 'You are a startup expert. Always respond with valid JSON only, no additional text.' },
        { role: 'user', content: prompt }
      ]
    })

    const content = response.choices[0]?.message?.content
    if (!content) throw new Error('No content generated')

    let parsedContent: any
    try {
      parsedContent = JSON.parse(content)
    } catch (error) {
      console.error('JSON parse error, using fallback content')
      throw new Error('Invalid JSON response')
    }

    // Generate 30-day content calendar
    const contentCalendar = Array.from({ length: 30 }, (_, i) => {
      const topics = [
        `Industry trend analysis: ${marketData.trends[i % marketData.trends.length] || 'Digital transformation insights'}`,
        `Customer success story for ${businessIdea}`,
        `Product feature spotlight: Innovation showcase`,
        `Expert tips: Best practices in ${businessIdea}`,
        `Behind-the-scenes: Building our ${businessIdea} solution`,
        `User-generated content: Community highlights`,
        `Educational content: ${businessIdea} fundamentals`,
        `Market research: Latest ${businessIdea} findings`,
        `Team spotlight: Meet our experts`,
        `Community engagement: Join the conversation`,
        `Case study: ${businessIdea} transformation`,
        `Industry news: What's happening in ${businessIdea}`,
        `Product update: Latest features and improvements`,
        `Webinar: Advanced ${businessIdea} strategies`,
        `Infographic: ${businessIdea} statistics and trends`
      ]
      return {
        day: i + 1,
        content: topics[i % topics.length],
        platform: i % 4 === 0 ? 'LinkedIn' : i % 4 === 1 ? 'Twitter' : i % 4 === 2 ? 'Blog' : 'Instagram'
      }
    })

    return {
      businessIdea,
      names: parsedContent.names || [`${businessIdea}Pro`, `Smart${businessIdea.split(' ')[0]}`, `${businessIdea.split(' ')[0]}Flow`],
      slogan: parsedContent.slogan || `Revolutionizing ${businessIdea.toLowerCase()} for the modern world`,
      logoPrompt: parsedContent.logoPrompt || `Modern, minimalist logo for ${businessIdea.toLowerCase()}. Clean design, professional, trustworthy. Tech-forward aesthetic.`,
      pitchDeck: {
        problem: parsedContent.pitchDeck?.problem || `Current ${businessIdea.toLowerCase()} solutions are outdated and inefficient.`,
        solution: parsedContent.pitchDeck?.solution || `Our platform provides an intuitive, scalable approach to ${businessIdea.toLowerCase()}.`,
        market: parsedContent.pitchDeck?.market || marketData.marketSize,
        product: parsedContent.pitchDeck?.product || `Comprehensive ${businessIdea.toLowerCase()} platform with cutting-edge technology.`,
        businessModel: parsedContent.pitchDeck?.businessModel || 'SaaS subscription with tiered pricing for individuals, teams, and enterprises.',
        competition: parsedContent.pitchDeck?.competition || 'We differentiate through superior UX, competitive pricing, and innovative features.',
        team: parsedContent.pitchDeck?.team || 'Experienced team with deep industry expertise and technical backgrounds.',
        traction: parsedContent.pitchDeck?.traction || 'Strong early traction with growing user base and positive feedback.',
        financials: parsedContent.pitchDeck?.financials || 'Targeting $1M ARR within 18 months with clear path to profitability.',
        ask: parsedContent.pitchDeck?.ask || 'Seeking seed funding to accelerate product development and market expansion.'
      },
      landingPage: {
        headline: parsedContent.landingPage?.headline || `Transform Your ${businessIdea}`,
        subheadline: parsedContent.landingPage?.subheadline || `The next-generation solution for ${businessIdea.toLowerCase()} that delivers real results`,
        benefits: parsedContent.landingPage?.benefits || [
          'Streamlined workflow automation',
          'Advanced analytics and insights', 
          'Enterprise-grade security',
          'Seamless team collaboration'
        ],
        cta: parsedContent.landingPage?.cta || 'Start Your Free Trial Today',
        features: parsedContent.landingPage?.features || [
          { title: 'Smart Dashboard', description: 'Comprehensive overview of all your operations' },
          { title: 'Real-time Analytics', description: 'Data-driven insights for better decisions' },
          { title: 'Seamless Integration', description: 'Connect with your favorite tools effortlessly' }
        ]
      },
      marketingPlan: parsedContent.marketingPlan || [
        { day: 1, activity: `Launch ${businessIdea} landing page and social presence`, goal: 'Establish market presence' },
        { day: 2, activity: 'Create product demo video showcasing key features', goal: 'Generate interest and engagement' },
        { day: 3, activity: 'Outreach to industry influencers and thought leaders', goal: 'Build credibility and partnerships' },
        { day: 4, activity: 'Launch targeted advertising campaign', goal: 'Drive qualified traffic and leads' },
        { day: 5, activity: 'Publish expert content and industry insights', goal: 'Establish thought leadership' },
        { day: 6, activity: 'Host product demonstration webinar', goal: 'Convert prospects to trial users' },
        { day: 7, activity: 'Implement email nurture campaign', goal: 'Increase trial-to-paid conversions' }
      ],
      pricing: parsedContent.pricing || [
        { tier: 'Starter', price: '$49/month', features: ['Core features', 'Up to 10 users', 'Email support', 'Basic analytics'] },
        { tier: 'Professional', price: '$149/month', features: ['Advanced features', 'Up to 50 users', 'Priority support', 'Advanced analytics', 'API access'] },
        { tier: 'Enterprise', price: 'Custom', features: ['All features', 'Unlimited users', 'Dedicated support', 'Custom integrations', 'SLA guarantee', 'White-label options'] }
      ],
      contentCalendar
    }
  } catch (error) {
    console.error('Content generation error:', error)
    throw error
  }
}