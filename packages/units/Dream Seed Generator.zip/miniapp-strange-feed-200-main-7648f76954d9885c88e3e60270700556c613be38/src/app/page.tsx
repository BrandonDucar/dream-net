'use client'
import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Sparkles, Download, Loader2, Zap, Video, Palette, Volume2, Building, Users, Calculator, Scale, TrendingUp, Star, Rocket, Brain, Globe, Shield, Target, Award } from 'lucide-react'
import { AIEnhancedGenerator } from '@/components/ai-enhanced-generator'
import { EnhancedStartupKitGenerator } from '@/components/enhanced-startup-kit-generator'
import type { StartupKit } from '@/types/startup-kit'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Page(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [businessIdea, setBusinessIdea] = useState<string>('')
  const [startupKit, setStartupKit] = useState<StartupKit | null>(null)
  const [isGenerating, setIsGenerating] = useState<boolean>(false)

  const handleGenerate = async (): Promise<void> => {
    if (!businessIdea.trim()) return

    setIsGenerating(true)
    
    // Simulate generation time for better UX
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Generate startup kit based on business idea
    const kit: StartupKit = {
      businessIdea: businessIdea,
      names: [
        `${businessIdea.split(' ')[0]}Hub`,
        `Smart${businessIdea.split(' ')[0]}`,
        `${businessIdea.split(' ')[0]}Flow`,
      ],
      slogan: `Revolutionizing ${businessIdea.toLowerCase()} for the modern world`,
      logoPrompt: `Modern, minimalist logo for a ${businessIdea.toLowerCase()} company. Clean lines, professional, trustworthy. Color palette: blues and greens. Vector style, suitable for digital and print.`,
      pitchDeck: {
        problem: `Current solutions in ${businessIdea.toLowerCase()} are outdated, expensive, and difficult to use.`,
        solution: `Our platform provides an intuitive, affordable, and scalable approach to ${businessIdea.toLowerCase()}.`,
        market: `The ${businessIdea.toLowerCase()} market is valued at billions and growing 20% annually.`,
        product: `A comprehensive platform that streamlines ${businessIdea.toLowerCase()} with cutting-edge technology.`,
        businessModel: 'SaaS subscription model with tiered pricing for individuals, teams, and enterprises.',
        competition: 'We differentiate through superior UX, lower pricing, and innovative features.',
        team: 'Experienced founders with backgrounds in technology, business, and the industry.',
        traction: 'Currently in beta with 100+ early adopters providing positive feedback.',
        financials: 'Targeting $1M ARR within 18 months with a clear path to profitability.',
        ask: 'Seeking $500K seed funding to scale product development and customer acquisition.',
      },
      landingPage: {
        headline: `Transform Your ${businessIdea}`,
        subheadline: `The modern solution for ${businessIdea.toLowerCase()} that saves time and delivers results`,
        benefits: [
          'Easy to use interface',
          'Save hours of manual work',
          'Affordable pricing for everyone',
          'Trusted by growing businesses',
        ],
        cta: 'Start Your Free Trial',
        features: [
          { title: 'Intuitive Dashboard', description: 'Manage everything from one central hub' },
          { title: 'Real-time Analytics', description: 'Track performance and make data-driven decisions' },
          { title: 'Seamless Integration', description: 'Connect with your existing tools effortlessly' },
        ],
      },
      marketingPlan: [
        { day: 1, activity: 'Launch landing page and social media profiles', goal: 'Establish online presence' },
        { day: 2, activity: 'Create and share launch announcement video', goal: 'Generate initial buzz' },
        { day: 3, activity: 'Reach out to industry influencers for partnerships', goal: 'Build credibility' },
        { day: 4, activity: 'Run targeted Facebook and LinkedIn ads', goal: 'Drive traffic to landing page' },
        { day: 5, activity: 'Publish blog post about industry problem', goal: 'Demonstrate expertise' },
        { day: 6, activity: 'Host live demo webinar', goal: 'Convert leads to trial users' },
        { day: 7, activity: 'Send follow-up emails to trial signups', goal: 'Increase engagement and conversions' },
      ],
      pricing: [
        { tier: 'Starter', price: '$29/month', features: ['Up to 5 users', 'Basic features', 'Email support', '1 GB storage'] },
        { tier: 'Professional', price: '$99/month', features: ['Up to 25 users', 'Advanced features', 'Priority support', '10 GB storage', 'API access'] },
        { tier: 'Enterprise', price: 'Custom', features: ['Unlimited users', 'All features', 'Dedicated support', 'Unlimited storage', 'Custom integrations', 'SLA guarantee'] },
      ],
      contentCalendar: Array.from({ length: 30 }, (_, i) => {
        const topics = [
          'Industry trends and insights',
          'Customer success story',
          'Product feature highlight',
          'Tips and best practices',
          'Behind-the-scenes content',
          'User-generated content',
          'Educational tutorial',
          'Market research findings',
          'Team member spotlight',
          'Community engagement post',
        ]
        return {
          day: i + 1,
          content: topics[i % topics.length],
          platform: i % 3 === 0 ? 'LinkedIn' : i % 3 === 1 ? 'Twitter' : 'Blog',
        }
      }),
    }

    setStartupKit(kit)
    setIsGenerating(false)
  }

  const handleExport = (): void => {
    if (!startupKit) return

    const exportData = JSON.stringify(startupKit, null, 2)
    const blob = new Blob([exportData], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `startup-kit-${Date.now()}.json`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  const premiumFeatures = [
    { icon: Zap, label: 'AI Market Research', description: 'Real-time competitive intelligence', color: 'from-yellow-500 to-orange-500' },
    { icon: Video, label: 'Video Generation', description: 'Pitch decks & marketing videos', color: 'from-red-500 to-pink-500' },
    { icon: Palette, label: 'Logo Creation', description: 'Professional AI-generated logos', color: 'from-purple-500 to-indigo-500' },
    { icon: Volume2, label: 'Voice Synthesis', description: 'Professional presentation audio', color: 'from-blue-500 to-cyan-500' },
    { icon: Building, label: '3D Visualization', description: 'Product demos & prototypes', color: 'from-green-500 to-teal-500' },
    { icon: Users, label: 'Team Matching', description: 'Find verified talent & investors', color: 'from-indigo-500 to-purple-500' },
    { icon: Calculator, label: 'Financial Modeling', description: '36-month projections & analysis', color: 'from-emerald-500 to-green-500' },
    { icon: Scale, label: 'Legal Documents', description: 'Automated contracts & compliance', color: 'from-gray-500 to-slate-500' },
    { icon: TrendingUp, label: 'SEO Optimization', description: 'Keyword research & content strategy', color: 'from-cyan-500 to-blue-500' }
  ]

  const stats = [
    { icon: Star, value: '10K+', label: 'Startups Created', color: 'text-yellow-400' },
    { icon: Award, value: '98%', label: 'Success Rate', color: 'text-green-400' },
    { icon: Target, value: '$2.5B+', label: 'Funding Raised', color: 'text-blue-400' },
    { icon: Globe, value: '50+', label: 'Countries', color: 'text-purple-400' }
  ]

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-pink-600/20 via-transparent to-cyan-600/20"></div>
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-cyan-500/20 rounded-full blur-3xl animate-pulse delay-2000"></div>
      </div>

      <div className="relative z-10 min-h-screen py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-12 pt-8">
            {/* Main Title */}
            <div className="flex items-center justify-center gap-4 mb-8">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-cyan-400 rounded-full blur-xl opacity-75 animate-pulse"></div>
                <Rocket className="relative h-16 w-16 text-white animate-bounce" />
              </div>
              <h1 className="text-6xl sm:text-8xl font-black bg-gradient-to-r from-purple-400 via-pink-400 via-blue-400 to-cyan-400 bg-clip-text text-transparent leading-tight">
                Dream Seed Forge
              </h1>
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-purple-400 rounded-full blur-xl opacity-75 animate-pulse delay-1000"></div>
                <Brain className="relative h-16 w-16 text-white animate-bounce delay-500" />
              </div>
            </div>

            {/* Subtitle */}
            <p className="text-2xl sm:text-3xl font-bold text-white mb-4 max-w-4xl mx-auto leading-relaxed">
              The World's Most Advanced AI-Powered
              <span className="bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent"> Startup Ecosystem</span>
            </p>
            
            <p className="text-lg text-gray-200 max-w-3xl mx-auto mb-8 leading-relaxed">
              Transform any business idea into a complete enterprise-ready startup kit with AI market intelligence, 
              professional media creation, geofencing capabilities, and collaborative tools that rival Fortune 500 resources.
            </p>

            {/* Feature Badges */}
            <div className="flex items-center justify-center gap-3 flex-wrap mb-8">
              <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-4 py-2 text-sm font-semibold hover:scale-105 transition-transform">
                <Zap className="w-4 h-4 mr-2" />
                AI-Powered Intelligence
              </Badge>
              <Badge className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-4 py-2 text-sm font-semibold hover:scale-105 transition-transform">
                <Globe className="w-4 h-4 mr-2" />
                Geofencing & Location Intel
              </Badge>
              <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-2 text-sm font-semibold hover:scale-105 transition-transform">
                <Video className="w-4 h-4 mr-2" />
                Professional Video AI
              </Badge>
              <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-4 py-2 text-sm font-semibold hover:scale-105 transition-transform">
                <Users className="w-4 h-4 mr-2" />
                Team Collaboration
              </Badge>
              <Badge className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white px-4 py-2 text-sm font-semibold hover:scale-105 transition-transform">
                <Shield className="w-4 h-4 mr-2" />
                Enterprise Security
              </Badge>
            </div>

            {/* Stats Section */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto mb-12">
              {stats.map((stat, index) => {
                const Icon = stat.icon
                return (
                  <Card key={index} className="bg-white/10 backdrop-blur-lg border-white/20 hover:bg-white/20 transition-all duration-300 hover:scale-105">
                    <CardContent className="p-6 text-center">
                      <Icon className={`h-8 w-8 mx-auto mb-3 ${stat.color}`} />
                      <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
                      <div className="text-sm text-gray-300">{stat.label}</div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </div>

          {/* Premium Features Showcase */}
          {!startupKit && (
            <Card className="max-w-6xl mx-auto mb-12 bg-white/5 backdrop-blur-xl border-white/10 shadow-2xl hover:bg-white/10 transition-all duration-500">
              <CardHeader className="text-center pb-6">
                <div className="flex items-center justify-center gap-3 mb-4">
                  <Sparkles className="h-8 w-8 text-yellow-400 animate-spin" />
                  <CardTitle className="text-4xl font-bold bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
                    Enterprise-Grade Features
                  </CardTitle>
                  <Sparkles className="h-8 w-8 text-yellow-400 animate-spin" />
                </div>
                <CardDescription className="text-xl text-gray-200 max-w-3xl mx-auto">
                  Everything your startup needs to compete with industry leaders and scale globally
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {premiumFeatures.map((feature, index) => {
                    const Icon = feature.icon
                    return (
                      <div key={index} className="group relative overflow-hidden">
                        <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl" 
                             style={{background: `linear-gradient(135deg, ${feature.color.split(' ')[1]}, ${feature.color.split(' ')[3]})`}}></div>
                        <div className="relative flex items-start gap-4 p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 hover:border-white/30 transition-all duration-300 hover:scale-105 hover:bg-white/10">
                          <div className={`p-3 rounded-full bg-gradient-to-br ${feature.color} shadow-lg`}>
                            <Icon className="h-6 w-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-bold text-white text-lg mb-2 group-hover:text-yellow-300 transition-colors">
                              {feature.label}
                            </h4>
                            <p className="text-gray-300 text-sm leading-relaxed group-hover:text-white transition-colors">
                              {feature.description}
                            </p>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Enhanced Input Section */}
          {!startupKit && (
            <div className="space-y-8">
              <Card className="max-w-4xl mx-auto shadow-2xl bg-white/10 backdrop-blur-xl border-white/20 hover:bg-white/15 transition-all duration-500">
                <CardHeader>
                  <div className="text-center space-y-4">
                    <div className="flex items-center justify-center gap-3">
                      <div className="p-3 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 animate-pulse">
                        <Target className="h-8 w-8 text-white" />
                      </div>
                      <CardTitle className="text-4xl font-bold text-white">
                        What's Your
                        <span className="bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent"> Million-Dollar</span> Idea?
                      </CardTitle>
                    </div>
                    <CardDescription className="text-xl text-gray-200 max-w-3xl mx-auto leading-relaxed">
                      Describe your business concept and our advanced AI will generate a complete enterprise startup kit with 
                      real-time market research, financial projections, professional media, legal documentation, and geofencing strategies.
                    </CardDescription>
                  </div>
                </CardHeader>
                <CardContent className="space-y-8 p-8">
                  <div className="space-y-4">
                    <Label htmlFor="business-idea" className="text-2xl font-semibold text-white flex items-center gap-3">
                      <Brain className="h-6 w-6 text-purple-400" />
                      Describe Your Vision
                    </Label>
                    <div className="relative">
                      <Input
                        id="business-idea"
                        placeholder="e.g., AI-powered sustainable energy management platform for smart cities with predictive analytics and real-time optimization"
                        value={businessIdea}
                        onChange={(e) => setBusinessIdea(e.target.value)}
                        disabled={isGenerating}
                        className="text-xl p-6 bg-white/5 backdrop-blur-sm border-2 border-white/20 text-white placeholder-gray-300 focus:border-purple-400 focus:bg-white/10 transition-all duration-300 rounded-2xl"
                      />
                      <div className="absolute inset-0 bg-gradient-to-r from-purple-400/20 to-cyan-400/20 rounded-2xl blur-sm opacity-0 focus-within:opacity-100 transition-opacity duration-300 -z-10"></div>
                    </div>
                  </div>

                  {/* Feature Highlights */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-xl border border-green-400/30 backdrop-blur-sm hover:scale-105 transition-transform">
                      <Globe className="h-6 w-6 text-green-400" />
                      <span className="text-green-300 font-semibold">Geofencing Intel</span>
                    </div>
                    <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 rounded-xl border border-blue-400/30 backdrop-blur-sm hover:scale-105 transition-transform">
                      <TrendingUp className="h-6 w-6 text-blue-400" />
                      <span className="text-blue-300 font-semibold">Market Research</span>
                    </div>
                    <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-xl border border-purple-400/30 backdrop-blur-sm hover:scale-105 transition-transform">
                      <Video className="h-6 w-6 text-purple-400" />
                      <span className="text-purple-300 font-semibold">Video AI</span>
                    </div>
                    <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-orange-500/20 to-red-500/20 rounded-xl border border-orange-400/30 backdrop-blur-sm hover:scale-105 transition-transform">
                      <Users className="h-6 w-6 text-orange-400" />
                      <span className="text-orange-300 font-semibold">Team Tools</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <AIEnhancedGenerator
                businessIdea={businessIdea}
                onGenerate={setStartupKit}
                isGenerating={isGenerating}
                setIsGenerating={setIsGenerating}
              />
            </div>
          )}

          {/* Generated Content */}
          {startupKit && (
            <div className="space-y-8">
              <Card className="bg-white/10 backdrop-blur-xl border-white/20 shadow-2xl hover:bg-white/15 transition-all duration-500">
                <CardContent className="p-8">
                  <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
                    <div className="flex-1">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="p-3 rounded-full bg-gradient-to-r from-green-500 to-emerald-500 animate-pulse">
                          <Rocket className="h-8 w-8 text-white" />
                        </div>
                        <h2 className="text-4xl font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
                          Your Enterprise Startup Kit
                        </h2>
                      </div>
                      <p className="text-xl text-gray-200 mb-4 leading-relaxed">
                        <span className="font-semibold text-yellow-400">Business Idea:</span> {startupKit.businessIdea}
                      </p>
                      <div className="flex items-center gap-3 flex-wrap">
                        <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-4 py-2 text-sm font-semibold">
                          ✅ Market Research Complete
                        </Badge>
                        <Badge className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-4 py-2 text-sm font-semibold">
                          ✅ SEO Optimized
                        </Badge>
                        <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-2 text-sm font-semibold">
                          ✅ Media Ready
                        </Badge>
                        <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-4 py-2 text-sm font-semibold">
                          ✅ Legal Compliant
                        </Badge>
                      </div>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-4">
                      <Button 
                        onClick={handleExport} 
                        variant="outline" 
                        className="bg-white/10 backdrop-blur-sm border-white/30 text-white hover:bg-white/20 hover:scale-105 transition-all duration-300 px-6 py-3 text-lg"
                      >
                        <Download className="mr-2 h-5 w-5" />
                        Export Complete Kit
                      </Button>
                      <Button
                        onClick={() => {
                          setStartupKit(null)
                          setBusinessIdea('')
                        }}
                        className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white hover:scale-105 transition-all duration-300 px-6 py-3 text-lg font-semibold"
                      >
                        <Sparkles className="mr-2 h-5 w-5" />
                        Generate New Kit
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <EnhancedStartupKitGenerator
                startupKit={startupKit}
                onUpdate={setStartupKit}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  )
}