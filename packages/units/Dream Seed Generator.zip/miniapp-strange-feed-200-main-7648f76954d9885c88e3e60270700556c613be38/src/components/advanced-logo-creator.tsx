'use client'
import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Palette, Sparkles, Loader2 } from 'lucide-react'

interface AdvancedLogoCreatorProps {
  businessName: string
  businessIdea: string
  logoPrompt: string
  onLogoGenerated: (logoUrl: string, prompt: string) => void
}

export function AdvancedLogoCreator({ 
  businessName, 
  businessIdea, 
  logoPrompt, 
  onLogoGenerated 
}: AdvancedLogoCreatorProps): JSX.Element {
  const [isGenerating, setIsGenerating] = useState<boolean>(false)

  const generateLogos = async (): Promise<void> => {
    setIsGenerating(true)
    // Mock generation
    await new Promise(resolve => setTimeout(resolve, 2000))
    onLogoGenerated('https://example.com/logo.png', logoPrompt)
    setIsGenerating(false)
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Palette className="h-6 w-6 text-purple-600" />
            AI Logo Creator
            <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
              Pro Feature
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-gray-600 mb-4">
            Generate professional logos for {businessName} using AI.
          </div>
          
          <Button
            onClick={generateLogos}
            disabled={isGenerating}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600"
          >
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Logos...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Generate AI Logos
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    </>
  )
}