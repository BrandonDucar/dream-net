'use client'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Sparkles, Loader2, Brain, Target, TrendingUp } from 'lucide-react'
import type { StartupKit } from '@/types/startup-kit'

interface AIEnhancedGeneratorProps {
  businessIdea: string
  onGenerate: (kit: StartupKit) => void
  isGenerating: boolean
  setIsGenerating: (loading: boolean) => void
}

interface LocationData {
  country: string
  city: string
  timeZone: string
}

export function AIEnhancedGenerator({ businessIdea, onGenerate, isGenerating, setIsGenerating }: AIEnhancedGeneratorProps): JSX.Element {
  const [generationStage, setGenerationStage] = useState<string>('')
  const [userLocation, setUserLocation] = useState<LocationData | null>(null)

  const handleGenerate = async (): Promise<void> => {
    if (!businessIdea.trim()) return

    setIsGenerating(true)

    try {
      // Step 1: Detect user location for geofencing
      setGenerationStage('Detecting your location...')
      const location = { country: 'Global', city: 'Unknown', timeZone: 'UTC' }
      setUserLocation(location)

      // Step 2: Call API to generate startup kit
      setGenerationStage('Conducting AI-powered market research...')
      
      const response = await fetch('/api/generate-startup-kit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          businessIdea,
          location
        })
      })

      if (!response.ok) {
        throw new Error(`Generation failed: ${response.status}`)
      }

      setGenerationStage('Generating enhanced business content...')
      
      const kit = await response.json()
      
      if (kit.error) {
        throw new Error(kit.error)
      }

      onGenerate(kit)
    } catch (error) {
      console.error('Generation error:', error)
      setGenerationStage('Error generating content. Please try again.')
      
      // Fallback generation
      setTimeout(() => {
        setIsGenerating(false)
        setGenerationStage('')
      }, 2000)
    } finally {
      setIsGenerating(false)
      setGenerationStage('')
    }
  }

  return (
    <>
      <Card className="max-w-4xl mx-auto shadow-2xl bg-white/10 backdrop-blur-xl border-white/20 hover:bg-white/15 transition-all duration-500">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 animate-pulse">
              <Brain className="h-8 w-8 text-white" />
            </div>
            <CardTitle className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              AI-Powered Startup Kit Generator
            </CardTitle>
          </div>
          <CardDescription className="text-xl text-gray-200 max-w-3xl mx-auto leading-relaxed">
            Advanced AI analysis with real-time market research, competitor intelligence, and location-based insights
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 p-8">
          {userLocation && (
            <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 rounded-xl border border-blue-400/30 backdrop-blur-sm">
              <Target className="h-5 w-5 text-blue-400" />
              <span className="text-blue-300 font-semibold">
                Location detected: {userLocation.city}, {userLocation.country}
              </span>
              <Badge className="ml-auto bg-blue-500/20 text-blue-300 border-blue-400/30">
                Geofencing Active
              </Badge>
            </div>
          )}

          {generationStage && (
            <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-purple-500/20 to-blue-500/20 rounded-xl border border-purple-400/30 backdrop-blur-sm">
              <Loader2 className="h-5 w-5 animate-spin text-purple-400" />
              <span className="text-lg font-medium text-white">{generationStage}</span>
              <TrendingUp className="h-5 w-5 text-blue-400 ml-auto" />
            </div>
          )}

          <Button
            onClick={handleGenerate}
            disabled={!businessIdea.trim() || isGenerating}
            className="w-full text-xl py-8 bg-gradient-to-r from-purple-600 via-blue-600 to-cyan-600 hover:from-purple-700 hover:via-blue-700 hover:to-cyan-700 shadow-2xl hover:shadow-purple-500/25 hover:scale-105 transition-all duration-300"
            size="lg"
          >
            {isGenerating ? (
              <>
                <Loader2 className="mr-3 h-6 w-6 animate-spin" />
                Generating Enhanced Startup Kit...
              </>
            ) : (
              <>
                <Sparkles className="mr-3 h-6 w-6" />
                Generate AI-Enhanced Startup Kit
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    </>
  )
}