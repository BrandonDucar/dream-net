'use client'
import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Users } from 'lucide-react'
import type { StartupKit } from '@/types/startup-kit'

interface CollaborationHubProps {
  startupKit: StartupKit
  onUpdate: (kit: StartupKit) => void
}

export function CollaborationHub({ startupKit, onUpdate }: CollaborationHubProps): JSX.Element {
  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Users className="h-6 w-6 text-blue-600" />
            Real-time Collaboration
            <Badge className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
              Live Editing
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-gray-600 mb-4">
            Collaborate with your team in real-time on your startup kit. All changes are automatically synchronized across all team members.
          </div>
          <div className="text-sm text-gray-500">
            Feature coming soon - real-time team collaboration with SpacetimeDB integration.
          </div>
        </CardContent>
      </Card>
    </>
  )
}