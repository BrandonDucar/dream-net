'use client'
import { useState } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Download, Sparkles, Users, TrendingUp, Calculator, Scale, Search, Palette, Building } from 'lucide-react'

// Enhanced components
import { LogoGenerator } from './logo-generator'
import { AdvancedLogoCreator } from './advanced-logo-creator'
import { PremiumVideoGenerator } from './premium-video-generator'
import { MarketResearchPanel } from './market-research-panel'
import { CollaborationHub } from './collaboration-hub'
import { FinancialProjections } from './financial-projections'
import { LegalDocuments } from './legal-documents'
import { SEOAnalyzer } from './seo-analyzer'
import { TeamBuilder } from './team-builder'

// Original sections
import { NamesSection } from './sections/names-section'
import { SloganSection } from './sections/slogan-section'
import { PitchDeckSection } from './sections/pitch-deck-section'
import { LandingPageSection } from './sections/landing-page-section'
import { MarketingPlanSection } from './sections/marketing-plan-section'
import { PricingSection } from './sections/pricing-section'
import { ContentCalendarSection } from './sections/content-calendar-section'

import type { StartupKit } from '@/types/startup-kit'

interface EnhancedStartupKitGeneratorProps {
  startupKit: StartupKit
  onUpdate: (kit: StartupKit) => void
}

export function EnhancedStartupKitGenerator({ startupKit, onUpdate }: EnhancedStartupKitGeneratorProps): JSX.Element {
  const [activeTab, setActiveTab] = useState<string>('overview')
  const [seoData, setSeoData] = useState<any>(null)

  const handleSectionUpdate = <T extends keyof StartupKit>(section: T, data: StartupKit[T]): void => {
    onUpdate({
      ...startupKit,
      [section]: data
    })
  }

  const handleExport = (): void => {
    const exportData = {
      ...startupKit,
      seoData,
      exportedAt: new Date().toISOString(),
      version: '2.0-enhanced'
    }
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `${startupKit.businessIdea.replace(/[^a-zA-Z0-9]/g, '-')}-enhanced-startup-kit.json`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Sparkles },
    { id: 'names', label: 'Names', icon: Building },
    { id: 'slogan', label: 'Slogan', icon: Sparkles },
    { id: 'logo', label: 'Logo', icon: Palette },
    { id: 'video', label: 'Videos', icon: TrendingUp },
    { id: 'pitch', label: 'Pitch Deck', icon: TrendingUp },
    { id: 'landing', label: 'Landing Page', icon: Search },
    { id: 'marketing', label: 'Marketing', icon: TrendingUp },
    { id: 'pricing', label: 'Pricing', icon: Calculator },
    { id: 'content', label: 'Content', icon: Search },
    { id: 'research', label: 'Market Research', icon: Search },
    { id: 'financials', label: 'Financials', icon: Calculator },
    { id: 'legal', label: 'Legal', icon: Scale },
    { id: 'seo', label: 'SEO', icon: Search },
    { id: 'team', label: 'Team', icon: Users },
    { id: 'collaboration', label: 'Collaboration', icon: Users }
  ]

  return (
    <div className="space-y-6">
      {/* Enhanced Header */}
      <Card className="bg-gradient-to-r from-purple-50 to-blue-50">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Enhanced Startup Kit</h2>
              <p className="text-gray-600 flex items-center gap-2">
                <span>AI-Powered • Real-time Collaboration • Market Intelligence</span>
                <Badge variant="secondary" className="text-xs">Pro Features</Badge>
              </p>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleExport} variant="outline" className="flex items-center gap-2">
                <Download className="h-4 w-4" />
                Export Enhanced Kit
              </Button>
              <Badge variant="default" className="px-3 py-1">
                {tabs.length} Modules
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Enhanced Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="border-b">
          <TabsList className="grid grid-cols-5 lg:grid-cols-10 xl:grid-cols-15 w-full h-auto p-1 bg-gray-50">
            {tabs.map((tab) => {
              const Icon = tab.icon
              return (
                <TabsTrigger 
                  key={tab.id} 
                  value={tab.id} 
                  className="flex flex-col items-center gap-1 p-2 text-xs min-h-16"
                >
                  <Icon className="h-4 w-4" />
                  <span className="hidden sm:block">{tab.label}</span>
                </TabsTrigger>
              )
            })}
          </TabsList>
        </div>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('research')}>
              <CardContent className="p-4 text-center">
                <Search className="h-8 w-8 mx-auto text-blue-600 mb-2" />
                <h3 className="font-semibold text-sm">Market Research</h3>
                <p className="text-xs text-gray-600">AI-powered competitive intelligence</p>
              </CardContent>
            </Card>
            
            <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('logo')}>
              <CardContent className="p-4 text-center">
                <Palette className="h-8 w-8 mx-auto text-purple-600 mb-2" />
                <h3 className="font-semibold text-sm">Logo Generation</h3>
                <p className="text-xs text-gray-600">AI-generated professional logos</p>
              </CardContent>
            </Card>
            
            <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('financials')}>
              <CardContent className="p-4 text-center">
                <Calculator className="h-8 w-8 mx-auto text-green-600 mb-2" />
                <h3 className="font-semibold text-sm">Financial Projections</h3>
                <p className="text-xs text-gray-600">36-month business forecasting</p>
              </CardContent>
            </Card>
            
            <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('team')}>
              <CardContent className="p-4 text-center">
                <Users className="h-8 w-8 mx-auto text-orange-600 mb-2" />
                <h3 className="font-semibold text-sm">Team Builder</h3>
                <p className="text-xs text-gray-600">Find verified talent on Talent Protocol</p>
              </CardContent>
            </Card>
            
            <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('legal')}>
              <CardContent className="p-4 text-center">
                <Scale className="h-8 w-8 mx-auto text-red-600 mb-2" />
                <h3 className="font-semibold text-sm">Legal Documents</h3>
                <p className="text-xs text-gray-600">AI-generated legal templates</p>
              </CardContent>
            </Card>
            
            <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('collaboration')}>
              <CardContent className="p-4 text-center">
                <Users className="h-8 w-8 mx-auto text-indigo-600 mb-2" />
                <h3 className="font-semibold text-sm">Real-time Collaboration</h3>
                <p className="text-xs text-gray-600">Team editing with SpacetimeDB</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Original Sections */}
        <TabsContent value="names" className="mt-6">
          <NamesSection
            names={startupKit.names}
            onUpdate={(names) => handleSectionUpdate('names', names)}
          />
        </TabsContent>

        <TabsContent value="slogan" className="mt-6">
          <SloganSection
            slogan={startupKit.slogan}
            onUpdate={(slogan) => handleSectionUpdate('slogan', slogan)}
          />
        </TabsContent>

        <TabsContent value="pitch" className="mt-6">
          <PitchDeckSection
            pitchDeck={startupKit.pitchDeck}
            onUpdate={(pitchDeck) => handleSectionUpdate('pitchDeck', pitchDeck)}
          />
        </TabsContent>

        <TabsContent value="landing" className="mt-6">
          <LandingPageSection
            landingPage={startupKit.landingPage}
            onUpdate={(landingPage) => handleSectionUpdate('landingPage', landingPage)}
          />
        </TabsContent>

        <TabsContent value="marketing" className="mt-6">
          <MarketingPlanSection
            marketingPlan={startupKit.marketingPlan}
            onUpdate={(marketingPlan) => handleSectionUpdate('marketingPlan', marketingPlan)}
          />
        </TabsContent>

        <TabsContent value="pricing" className="mt-6">
          <PricingSection
            pricing={startupKit.pricing}
            onUpdate={(pricing) => handleSectionUpdate('pricing', pricing)}
          />
        </TabsContent>

        <TabsContent value="content" className="mt-6">
          <ContentCalendarSection
            contentCalendar={startupKit.contentCalendar}
            onUpdate={(contentCalendar) => handleSectionUpdate('contentCalendar', contentCalendar)}
          />
        </TabsContent>

        {/* Enhanced Premium Sections */}
        <TabsContent value="logo" className="mt-6">
          <AdvancedLogoCreator
            businessName={startupKit.names[0] || startupKit.businessIdea}
            businessIdea={startupKit.businessIdea}
            logoPrompt={startupKit.logoPrompt}
            onLogoGenerated={(logoUrl, prompt) => handleSectionUpdate('logoPrompt', prompt)}
          />
        </TabsContent>

        <TabsContent value="video" className="mt-6">
          <PremiumVideoGenerator
            businessIdea={startupKit.businessIdea}
            pitchDeckContent={startupKit.pitchDeck}
            onVideoGenerated={(videoUrl) => console.log('Video generated:', videoUrl)}
          />
        </TabsContent>

        <TabsContent value="research" className="mt-6">
          <MarketResearchPanel businessIdea={startupKit.businessIdea} />
        </TabsContent>

        <TabsContent value="financials" className="mt-6">
          <FinancialProjections
            businessIdea={startupKit.businessIdea}
            pricing={startupKit.pricing}
          />
        </TabsContent>

        <TabsContent value="legal" className="mt-6">
          <LegalDocuments
            businessIdea={startupKit.businessIdea}
            companyName={startupKit.names[0] || ''}
          />
        </TabsContent>

        <TabsContent value="seo" className="mt-6">
          <SEOAnalyzer
            businessIdea={startupKit.businessIdea}
            landingPageContent={startupKit.landingPage}
            onUpdate={setSeoData}
          />
        </TabsContent>

        <TabsContent value="team" className="mt-6">
          <TeamBuilder
            businessIdea={startupKit.businessIdea}
            requiredRoles={['Developer', 'Designer', 'Marketer']}
          />
        </TabsContent>

        <TabsContent value="collaboration" className="mt-6">
          <CollaborationHub
            startupKit={startupKit}
            onUpdate={onUpdate}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}