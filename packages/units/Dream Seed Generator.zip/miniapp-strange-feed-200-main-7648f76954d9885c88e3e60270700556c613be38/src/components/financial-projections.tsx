'use client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Calculator } from 'lucide-react'
import type { PricingTier } from '@/types/startup-kit'

interface FinancialProjectionsProps {
  businessIdea: string
  pricing: PricingTier[]
}

export function FinancialProjections({ businessIdea, pricing }: FinancialProjectionsProps): JSX.Element {
  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Calculator className="h-6 w-6 text-green-600" />
            Financial Projections
            <Badge className="bg-gradient-to-r from-green-500 to-blue-500 text-white">
              Pro Analytics
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 mb-4">
            Advanced financial modeling and 36-month projections for {businessIdea} based on your pricing strategy.
          </p>
          <div className="text-sm text-gray-500">
            Feature coming soon - comprehensive financial projections with revenue forecasting, 
            burn rate analysis, and investor-ready financial models.
          </div>
        </CardContent>
      </Card>
    </>
  )
}