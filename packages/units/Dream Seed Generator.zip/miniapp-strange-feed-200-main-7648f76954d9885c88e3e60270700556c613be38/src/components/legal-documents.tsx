'use client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Scale } from 'lucide-react'

interface LegalDocumentsProps {
  businessIdea: string
  companyName: string
}

export function LegalDocuments({ businessIdea, companyName }: LegalDocumentsProps): JSX.Element {
  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Scale className="h-6 w-6 text-gray-600" />
            Legal Documents
            <Badge className="bg-gradient-to-r from-gray-500 to-slate-500 text-white">
              Legal Pro
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 mb-4">
            AI-generated legal documents and compliance templates for {companyName}.
          </p>
          <div className="text-sm text-gray-500">
            Feature coming soon - automated legal document generation including terms of service, 
            privacy policies, employment agreements, and compliance frameworks.
          </div>
        </CardContent>
      </Card>
    </>
  )
}