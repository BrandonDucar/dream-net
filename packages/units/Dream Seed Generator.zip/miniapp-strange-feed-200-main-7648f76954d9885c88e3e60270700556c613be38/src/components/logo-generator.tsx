'use client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Palette } from 'lucide-react'

export function LogoGenerator(): JSX.Element {
  return (
    <Card>
      <CardHeader>
        <CardTitle className=\"flex items-center gap-3\">
          <Palette className=\"h-6 w-6 text-purple-600\" />
          Logo Generator
          <Badge className=\"bg-gradient-to-r from-purple-500 to-pink-500 text-white\">
            Pro
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className=\"text-gray-600\">Advanced logo generation features available in the Logo Creator tab.</p>
      </CardContent>
    </Card>
  )
}