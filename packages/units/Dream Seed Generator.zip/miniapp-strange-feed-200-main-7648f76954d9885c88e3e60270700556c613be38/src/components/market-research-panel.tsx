'use client'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Search, RefreshCw, Loader2 } from 'lucide-react'

interface MarketResearchPanelProps {
  businessIdea: string
}

export function MarketResearchPanel({ businessIdea }: MarketResearchPanelProps): JSX.Element {
  const [isLoading, setIsLoading] = useState<boolean>(false)

  useEffect(() => {
    if (businessIdea) {
      setIsLoading(true)
      // Mock loading
      setTimeout(() => setIsLoading(false), 2000)
    }
  }, [businessIdea])

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Search className="h-6 w-6 text-blue-600" />
            AI Market Research
            <Badge className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
              Live Data
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-gray-600 mb-4">
            Comprehensive market analysis for {businessIdea} using multiple AI sources.
          </div>
          
          {isLoading && (
            <div className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin text-blue-600" />
              <span className="text-sm font-medium">Conducting market research...</span>
            </div>
          )}
          
          <div className="text-sm text-gray-500">
            Feature includes competitor analysis, market trends, opportunities, and target demographics.
          </div>
        </CardContent>
      </Card>
    </>
  )
}