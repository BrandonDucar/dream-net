'use client'
import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Video, Sparkles, Loader2 } from 'lucide-react'
import type { PitchDeck } from '@/types/startup-kit'

interface PremiumVideoGeneratorProps {
  businessIdea: string
  pitchDeckContent: PitchDeck
  onVideoGenerated: (videoUrl: string) => void
}

export function PremiumVideoGenerator({ 
  businessIdea, 
  pitchDeckContent, 
  onVideoGenerated 
}: PremiumVideoGeneratorProps): JSX.Element {
  const [isGenerating, setIsGenerating] = useState<boolean>(false)

  const generateVideo = async (): Promise<void> => {
    setIsGenerating(true)
    // Mock generation
    await new Promise(resolve => setTimeout(resolve, 3000))
    onVideoGenerated('https://example.com/video.mp4')
    setIsGenerating(false)
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Video className="h-6 w-6 text-red-600" />
            AI Video Generator
            <Badge className="bg-gradient-to-r from-red-500 to-pink-500 text-white">
              Premium Pro
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-gray-600 mb-4">
            Generate professional videos for {businessIdea} including pitch decks, product demos, and marketing content.
          </div>

          <Button
            onClick={generateVideo}
            disabled={isGenerating}
            className="w-full bg-gradient-to-r from-red-600 to-pink-600"
          >
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Video...
              </>
            ) : (
              <>
                <Video className="mr-2 h-4 w-4" />
                Generate AI Video
              </>
            )}
          </Button>

          <div className="text-sm text-gray-500">
            Feature includes multiple templates, custom scripts, and professional video rendering.
          </div>
        </CardContent>
      </Card>
    </>
  )
}