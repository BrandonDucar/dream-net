'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Plus, X } from 'lucide-react'
import type { ContentDay } from '@/types/startup-kit'

interface ContentCalendarSectionProps {
  contentCalendar: ContentDay[]
  onUpdate: (contentCalendar: ContentDay[]) => void
}

export function ContentCalendarSection({ contentCalendar, onUpdate }: ContentCalendarSectionProps): JSX.Element {
  const handleUpdate = (index: number, field: keyof ContentDay, value: string): void => {
    const updated = [...contentCalendar]
    updated[index] = { ...updated[index], [field]: value }
    onUpdate(updated)
  }

  const handleRemove = (index: number): void => {
    onUpdate(contentCalendar.filter((_, i) => i !== index))
  }

  const handleAdd = (): void => {
    const newDay: ContentDay = {
      day: contentCalendar.length + 1,
      content: '',
      platform: 'LinkedIn',
    }
    onUpdate([...contentCalendar, newDay])
  }

  const platforms = ['LinkedIn', 'Twitter', 'Blog', 'Instagram', 'Facebook', 'TikTok', 'YouTube']

  return (
    <Card>
      <CardHeader>
        <CardTitle>30-Day Content Calendar</CardTitle>
        <CardDescription>
          A full month of content ideas to keep your audience engaged and build your brand.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {contentCalendar.map((day, index) => (
            <Card key={index} className="p-3 bg-gray-50">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-semibold">Day {day.day}</Label>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleRemove(index)}
                    className="h-7 w-7 text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
                <div className="space-y-1">
                  <Label htmlFor={`content-${index}`} className="text-xs">Content</Label>
                  <Input
                    id={`content-${index}`}
                    value={day.content}
                    onChange={(e) => handleUpdate(index, 'content', e.target.value)}
                    placeholder="Content idea..."
                    className="text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor={`platform-${index}`} className="text-xs">Platform</Label>
                  <Select
                    value={day.platform}
                    onValueChange={(value) => handleUpdate(index, 'platform', value)}
                  >
                    <SelectTrigger id={`platform-${index}`} className="text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {platforms.map((platform) => (
                        <SelectItem key={platform} value={platform}>
                          {platform}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </Card>
          ))}
        </div>
        <Button onClick={handleAdd} variant="outline" className="w-full">
          <Plus className="h-4 w-4 mr-2" />
          Add Day
        </Button>
      </CardContent>
    </Card>
  )
}
