'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Plus, X } from 'lucide-react'
import type { LandingPage, Feature } from '@/types/startup-kit'

interface LandingPageSectionProps {
  landingPage: LandingPage
  onUpdate: (landingPage: LandingPage) => void
}

export function LandingPageSection({ landingPage, onUpdate }: LandingPageSectionProps): JSX.Element {
  const [newBenefit, setNewBenefit] = useState<string>('')
  const [newFeatureTitle, setNewFeatureTitle] = useState<string>('')
  const [newFeatureDesc, setNewFeatureDesc] = useState<string>('')

  const handleAddBenefit = (): void => {
    if (newBenefit.trim()) {
      onUpdate({
        ...landingPage,
        benefits: [...landingPage.benefits, newBenefit.trim()],
      })
      setNewBenefit('')
    }
  }

  const handleRemoveBenefit = (index: number): void => {
    onUpdate({
      ...landingPage,
      benefits: landingPage.benefits.filter((_, i) => i !== index),
    })
  }

  const handleUpdateBenefit = (index: number, value: string): void => {
    const updated = [...landingPage.benefits]
    updated[index] = value
    onUpdate({ ...landingPage, benefits: updated })
  }

  const handleAddFeature = (): void => {
    if (newFeatureTitle.trim() && newFeatureDesc.trim()) {
      onUpdate({
        ...landingPage,
        features: [...landingPage.features, { title: newFeatureTitle.trim(), description: newFeatureDesc.trim() }],
      })
      setNewFeatureTitle('')
      setNewFeatureDesc('')
    }
  }

  const handleRemoveFeature = (index: number): void => {
    onUpdate({
      ...landingPage,
      features: landingPage.features.filter((_, i) => i !== index),
    })
  }

  const handleUpdateFeature = (index: number, field: keyof Feature, value: string): void => {
    const updated = [...landingPage.features]
    updated[index] = { ...updated[index], [field]: value }
    onUpdate({ ...landingPage, features: updated })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Landing Page Copy</CardTitle>
        <CardDescription>
          All the copy you need for your landing page, including headlines, benefits, and features.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="headline">Headline</Label>
          <Input
            id="headline"
            value={landingPage.headline}
            onChange={(e) => onUpdate({ ...landingPage, headline: e.target.value })}
            className="text-lg font-semibold"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="subheadline">Subheadline</Label>
          <Textarea
            id="subheadline"
            value={landingPage.subheadline}
            onChange={(e) => onUpdate({ ...landingPage, subheadline: e.target.value })}
            rows={2}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="cta">Call-to-Action Button</Label>
          <Input
            id="cta"
            value={landingPage.cta}
            onChange={(e) => onUpdate({ ...landingPage, cta: e.target.value })}
          />
        </div>

        <div className="space-y-3 pt-4 border-t">
          <Label className="text-base font-semibold">Benefits</Label>
          {landingPage.benefits.map((benefit, index) => (
            <div key={index} className="flex gap-2">
              <Input
                value={benefit}
                onChange={(e) => handleUpdateBenefit(index, e.target.value)}
                className="flex-1"
              />
              <Button
                variant="ghost"
                size="icon"
                onClick={() => handleRemoveBenefit(index)}
                className="text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <div className="flex gap-2">
            <Input
              placeholder="Add benefit..."
              value={newBenefit}
              onChange={(e) => setNewBenefit(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleAddBenefit()
                }
              }}
            />
            <Button onClick={handleAddBenefit} disabled={!newBenefit.trim()}>
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="space-y-3 pt-4 border-t">
          <Label className="text-base font-semibold">Features</Label>
          {landingPage.features.map((feature, index) => (
            <Card key={index} className="p-4">
              <div className="space-y-3">
                <div className="flex gap-2">
                  <Input
                    placeholder="Feature title"
                    value={feature.title}
                    onChange={(e) => handleUpdateFeature(index, 'title', e.target.value)}
                    className="flex-1 font-medium"
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleRemoveFeature(index)}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <Textarea
                  placeholder="Feature description"
                  value={feature.description}
                  onChange={(e) => handleUpdateFeature(index, 'description', e.target.value)}
                  rows={2}
                />
              </div>
            </Card>
          ))}
          <Card className="p-4 bg-gray-50">
            <div className="space-y-3">
              <Input
                placeholder="New feature title..."
                value={newFeatureTitle}
                onChange={(e) => setNewFeatureTitle(e.target.value)}
              />
              <Textarea
                placeholder="Feature description..."
                value={newFeatureDesc}
                onChange={(e) => setNewFeatureDesc(e.target.value)}
                rows={2}
              />
              <Button
                onClick={handleAddFeature}
                disabled={!newFeatureTitle.trim() || !newFeatureDesc.trim()}
                className="w-full"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Feature
              </Button>
            </div>
          </Card>
        </div>
      </CardContent>
    </Card>
  )
}
