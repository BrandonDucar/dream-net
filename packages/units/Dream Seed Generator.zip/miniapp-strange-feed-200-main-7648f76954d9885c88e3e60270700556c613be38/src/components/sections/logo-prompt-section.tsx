'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'

interface LogoPromptSectionProps {
  logoPrompt: string
  onUpdate: (logoPrompt: string) => void
}

export function LogoPromptSection({ logoPrompt, onUpdate }: LogoPromptSectionProps): JSX.Element {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Logo Design Prompt</CardTitle>
        <CardDescription>
          Detailed description for creating your logo. Use this with design tools or share with your designer.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Textarea
          value={logoPrompt}
          onChange={(e) => onUpdate(e.target.value)}
          rows={6}
          placeholder="Describe your logo design..."
        />
      </CardContent>
    </Card>
  )
}
