'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Plus, X } from 'lucide-react'
import type { MarketingDay } from '@/types/startup-kit'

interface MarketingPlanSectionProps {
  marketingPlan: MarketingDay[]
  onUpdate: (marketingPlan: MarketingDay[]) => void
}

export function MarketingPlanSection({ marketingPlan, onUpdate }: MarketingPlanSectionProps): JSX.Element {
  const handleUpdate = (index: number, field: keyof MarketingDay, value: string): void => {
    const updated = [...marketingPlan]
    updated[index] = { ...updated[index], [field]: value }
    onUpdate(updated)
  }

  const handleRemove = (index: number): void => {
    onUpdate(marketingPlan.filter((_, i) => i !== index))
  }

  const handleAdd = (): void => {
    const newDay: MarketingDay = {
      day: marketingPlan.length + 1,
      activity: '',
      goal: '',
    }
    onUpdate([...marketingPlan, newDay])
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>7-Day Marketing Plan</CardTitle>
        <CardDescription>
          Your first week of marketing activities to launch and grow your startup.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {marketingPlan.map((day, index) => (
          <Card key={index} className="p-4 bg-gray-50">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-base font-semibold">Day {day.day}</Label>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleRemove(index)}
                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-2">
                <Label htmlFor={`activity-${index}`} className="text-sm">Activity</Label>
                <Input
                  id={`activity-${index}`}
                  value={day.activity}
                  onChange={(e) => handleUpdate(index, 'activity', e.target.value)}
                  placeholder="What marketing activity will you do?"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor={`goal-${index}`} className="text-sm">Goal</Label>
                <Input
                  id={`goal-${index}`}
                  value={day.goal}
                  onChange={(e) => handleUpdate(index, 'goal', e.target.value)}
                  placeholder="What do you hope to achieve?"
                />
              </div>
            </div>
          </Card>
        ))}
        <Button onClick={handleAdd} variant="outline" className="w-full">
          <Plus className="h-4 w-4 mr-2" />
          Add Day
        </Button>
      </CardContent>
    </Card>
  )
}
