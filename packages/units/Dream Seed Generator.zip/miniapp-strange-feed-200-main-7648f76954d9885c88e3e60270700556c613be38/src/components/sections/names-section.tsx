'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Plus, X } from 'lucide-react'

interface NamesSectionProps {
  names: string[]
  onUpdate: (names: string[]) => void
}

export function NamesSection({ names, onUpdate }: NamesSectionProps): JSX.Element {
  const [newName, setNewName] = useState<string>('')

  const handleAdd = (): void => {
    if (newName.trim()) {
      onUpdate([...names, newName.trim()])
      setNewName('')
    }
  }

  const handleRemove = (index: number): void => {
    onUpdate(names.filter((_, i) => i !== index))
  }

  const handleUpdate = (index: number, value: string): void => {
    const updated = [...names]
    updated[index] = value
    onUpdate(updated)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Business Name Ideas</CardTitle>
        <CardDescription>
          Edit existing names or add new ones to find the perfect name for your startup.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-3">
          {names.map((name, index) => (
            <div key={index} className="flex gap-2">
              <Input
                value={name}
                onChange={(e) => handleUpdate(index, e.target.value)}
                className="flex-1"
              />
              <Button
                variant="ghost"
                size="icon"
                onClick={() => handleRemove(index)}
                className="text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>

        <div className="flex gap-2 pt-4 border-t">
          <Input
            placeholder="Add another name..."
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleAdd()
              }
            }}
          />
          <Button onClick={handleAdd} disabled={!newName.trim()}>
            <Plus className="h-4 w-4 mr-2" />
            Add
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
