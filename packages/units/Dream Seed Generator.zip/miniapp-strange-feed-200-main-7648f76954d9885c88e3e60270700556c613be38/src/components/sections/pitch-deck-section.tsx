'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import type { PitchDeck } from '@/types/startup-kit'

interface PitchDeckSectionProps {
  pitchDeck: PitchDeck
  onUpdate: (pitchDeck: PitchDeck) => void
}

export function PitchDeckSection({ pitchDeck, onUpdate }: PitchDeckSectionProps): JSX.Element {
  const handleUpdate = (field: keyof PitchDeck, value: string): void => {
    onUpdate({ ...pitchDeck, [field]: value })
  }

  const slides = [
    { key: 'problem' as keyof PitchDeck, label: 'Problem', description: 'What problem are you solving?' },
    { key: 'solution' as keyof PitchDeck, label: 'Solution', description: 'How does your product solve it?' },
    { key: 'market' as keyof PitchDeck, label: 'Market Opportunity', description: 'How big is the market?' },
    { key: 'product' as keyof PitchDeck, label: 'Product', description: 'What are you building?' },
    { key: 'businessModel' as keyof PitchDeck, label: 'Business Model', description: 'How will you make money?' },
    { key: 'competition' as keyof PitchDeck, label: 'Competition', description: 'Who are your competitors?' },
    { key: 'team' as keyof PitchDeck, label: 'Team', description: 'Who is building this?' },
    { key: 'traction' as keyof PitchDeck, label: 'Traction', description: 'What progress have you made?' },
    { key: 'financials' as keyof PitchDeck, label: 'Financials', description: 'What are your projections?' },
    { key: 'ask' as keyof PitchDeck, label: 'The Ask', description: 'What are you raising?' },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Pitch Deck Outline</CardTitle>
        <CardDescription>
          A complete pitch deck structure with all essential slides. Edit each section to match your business.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {slides.map(({ key, label, description }) => (
          <div key={key} className="space-y-2">
            <Label htmlFor={key} className="text-base font-semibold">
              {label}
            </Label>
            <p className="text-sm text-gray-600">{description}</p>
            <Textarea
              id={key}
              value={pitchDeck[key]}
              onChange={(e) => handleUpdate(key, e.target.value)}
              rows={3}
            />
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
