'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Plus, X } from 'lucide-react'
import type { PricingTier } from '@/types/startup-kit'

interface PricingSectionProps {
  pricing: PricingTier[]
  onUpdate: (pricing: PricingTier[]) => void
}

export function PricingSection({ pricing, onUpdate }: PricingSectionProps): JSX.Element {
  const [newFeature, setNewFeature] = useState<Record<number, string>>({})

  const handleUpdate = (index: number, field: keyof PricingTier, value: string): void => {
    const updated = [...pricing]
    updated[index] = { ...updated[index], [field]: value }
    onUpdate(updated)
  }

  const handleRemoveTier = (index: number): void => {
    onUpdate(pricing.filter((_, i) => i !== index))
  }

  const handleAddTier = (): void => {
    const newTier: PricingTier = {
      tier: 'New Tier',
      price: '$0/month',
      features: [],
    }
    onUpdate([...pricing, newTier])
  }

  const handleAddFeature = (tierIndex: number): void => {
    const feature = newFeature[tierIndex]?.trim()
    if (feature) {
      const updated = [...pricing]
      updated[tierIndex] = {
        ...updated[tierIndex],
        features: [...updated[tierIndex].features, feature],
      }
      onUpdate(updated)
      setNewFeature({ ...newFeature, [tierIndex]: '' })
    }
  }

  const handleRemoveFeature = (tierIndex: number, featureIndex: number): void => {
    const updated = [...pricing]
    updated[tierIndex] = {
      ...updated[tierIndex],
      features: updated[tierIndex].features.filter((_, i) => i !== featureIndex),
    }
    onUpdate(updated)
  }

  const handleUpdateFeature = (tierIndex: number, featureIndex: number, value: string): void => {
    const updated = [...pricing]
    const features = [...updated[tierIndex].features]
    features[featureIndex] = value
    updated[tierIndex] = { ...updated[tierIndex], features }
    onUpdate(updated)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Pricing Strategy</CardTitle>
        <CardDescription>
          Different pricing tiers to meet the needs of various customer segments.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {pricing.map((tier, tierIndex) => (
          <Card key={tierIndex} className="p-4 bg-gradient-to-br from-blue-50 to-purple-50">
            <div className="space-y-4">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 space-y-3">
                  <div className="space-y-2">
                    <Label htmlFor={`tier-name-${tierIndex}`}>Tier Name</Label>
                    <Input
                      id={`tier-name-${tierIndex}`}
                      value={tier.tier}
                      onChange={(e) => handleUpdate(tierIndex, 'tier', e.target.value)}
                      className="font-semibold"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor={`tier-price-${tierIndex}`}>Price</Label>
                    <Input
                      id={`tier-price-${tierIndex}`}
                      value={tier.price}
                      onChange={(e) => handleUpdate(tierIndex, 'price', e.target.value)}
                    />
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleRemoveTier(tierIndex)}
                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-semibold">Features</Label>
                <div className="space-y-2">
                  {tier.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex gap-2">
                      <Input
                        value={feature}
                        onChange={(e) => handleUpdateFeature(tierIndex, featureIndex, e.target.value)}
                        className="flex-1 text-sm"
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveFeature(tierIndex, featureIndex)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  <div className="flex gap-2">
                    <Input
                      placeholder="Add feature..."
                      value={newFeature[tierIndex] || ''}
                      onChange={(e) => setNewFeature({ ...newFeature, [tierIndex]: e.target.value })}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          handleAddFeature(tierIndex)
                        }
                      }}
                      className="text-sm"
                    />
                    <Button
                      onClick={() => handleAddFeature(tierIndex)}
                      disabled={!newFeature[tierIndex]?.trim()}
                      size="sm"
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        ))}

        <Button onClick={handleAddTier} variant="outline" className="w-full">
          <Plus className="h-4 w-4 mr-2" />
          Add Pricing Tier
        </Button>
      </CardContent>
    </Card>
  )
}
