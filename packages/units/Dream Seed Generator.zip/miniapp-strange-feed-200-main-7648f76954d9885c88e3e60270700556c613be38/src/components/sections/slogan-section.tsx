'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'

interface SloganSectionProps {
  slogan: string
  onUpdate: (slogan: string) => void
}

export function SloganSection({ slogan, onUpdate }: SloganSectionProps): JSX.Element {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Slogan</CardTitle>
        <CardDescription>
          A catchy slogan that captures the essence of your business.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Textarea
          value={slogan}
          onChange={(e) => onUpdate(e.target.value)}
          rows={3}
          className="text-lg font-medium"
          placeholder="Enter your slogan..."
        />
      </CardContent>
    </Card>
  )
}
