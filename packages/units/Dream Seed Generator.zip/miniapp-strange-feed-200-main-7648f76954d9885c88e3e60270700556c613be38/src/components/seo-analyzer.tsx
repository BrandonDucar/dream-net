'use client'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Search, Loader2 } from 'lucide-react'
import type { LandingPage } from '@/types/startup-kit'

interface SEOAnalyzerProps {
  businessIdea: string
  landingPageContent: LandingPage
  onUpdate: (seoData: any) => void
}

export function SEOAnalyzer({ businessIdea, landingPageContent, onUpdate }: SEOAnalyzerProps): JSX.Element {
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false)

  useEffect(() => {
    if (businessIdea && landingPageContent) {
      setIsAnalyzing(true)
      // Mock analysis
      setTimeout(() => {
        setIsAnalyzing(false)
        onUpdate({ seoScore: 85 })
      }, 2000)
    }
  }, [businessIdea, landingPageContent, onUpdate])

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Search className="h-6 w-6 text-green-600" />
            SEO Analyzer
            <Badge className="bg-gradient-to-r from-green-500 to-blue-500 text-white">
              AI-Powered
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-gray-600 mb-4">
            Comprehensive SEO analysis for {businessIdea} with keyword research and optimization recommendations.
          </div>
          
          {isAnalyzing && (
            <div className="flex items-center gap-2 mb-4">
              <Loader2 className="h-4 w-4 animate-spin text-green-600" />
              <span className="text-sm font-medium">Analyzing SEO opportunities...</span>
            </div>
          )}

          <Button 
            onClick={() => setIsAnalyzing(true)} 
            disabled={isAnalyzing}
            className="w-full bg-gradient-to-r from-green-600 to-blue-600"
          >
            <Search className="mr-2 h-4 w-4" />
            {isAnalyzing ? 'Analyzing...' : 'Run SEO Analysis'}
          </Button>

          <div className="text-sm text-gray-500 mt-4">
            Feature includes keyword research, content suggestions, competitor analysis, and optimization tips.
          </div>
        </CardContent>
      </Card>
    </>
  )
}