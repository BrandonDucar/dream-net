'use client'

import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { NamesSection } from '@/components/sections/names-section'
import { SloganSection } from '@/components/sections/slogan-section'
import { LogoPromptSection } from '@/components/sections/logo-prompt-section'
import { PitchDeckSection } from '@/components/sections/pitch-deck-section'
import { LandingPageSection } from '@/components/sections/landing-page-section'
import { MarketingPlanSection } from '@/components/sections/marketing-plan-section'
import { PricingSection } from '@/components/sections/pricing-section'
import { ContentCalendarSection } from '@/components/sections/content-calendar-section'
import type { StartupKit } from '@/types/startup-kit'

interface StartupKitGeneratorProps {
  startupKit: StartupKit
  onUpdate: (kit: StartupKit) => void
}

export function StartupKitGenerator({ startupKit, onUpdate }: StartupKitGeneratorProps): JSX.Element {
  return (
    <Tabs defaultValue="names" className="w-full">
      <TabsList className="grid grid-cols-4 lg:grid-cols-8 w-full h-auto gap-1 bg-white p-2 rounded-lg shadow">
        <TabsTrigger value="names" className="text-xs sm:text-sm">Names</TabsTrigger>
        <TabsTrigger value="slogan" className="text-xs sm:text-sm">Slogan</TabsTrigger>
        <TabsTrigger value="logo" className="text-xs sm:text-sm">Logo</TabsTrigger>
        <TabsTrigger value="pitch" className="text-xs sm:text-sm">Pitch Deck</TabsTrigger>
        <TabsTrigger value="landing" className="text-xs sm:text-sm">Landing Page</TabsTrigger>
        <TabsTrigger value="marketing" className="text-xs sm:text-sm">Marketing</TabsTrigger>
        <TabsTrigger value="pricing" className="text-xs sm:text-sm">Pricing</TabsTrigger>
        <TabsTrigger value="content" className="text-xs sm:text-sm">Content</TabsTrigger>
      </TabsList>

      <TabsContent value="names">
        <NamesSection
          names={startupKit.names}
          onUpdate={(names) => onUpdate({ ...startupKit, names })}
        />
      </TabsContent>

      <TabsContent value="slogan">
        <SloganSection
          slogan={startupKit.slogan}
          onUpdate={(slogan) => onUpdate({ ...startupKit, slogan })}
        />
      </TabsContent>

      <TabsContent value="logo">
        <LogoPromptSection
          logoPrompt={startupKit.logoPrompt}
          onUpdate={(logoPrompt) => onUpdate({ ...startupKit, logoPrompt })}
        />
      </TabsContent>

      <TabsContent value="pitch">
        <PitchDeckSection
          pitchDeck={startupKit.pitchDeck}
          onUpdate={(pitchDeck) => onUpdate({ ...startupKit, pitchDeck })}
        />
      </TabsContent>

      <TabsContent value="landing">
        <LandingPageSection
          landingPage={startupKit.landingPage}
          onUpdate={(landingPage) => onUpdate({ ...startupKit, landingPage })}
        />
      </TabsContent>

      <TabsContent value="marketing">
        <MarketingPlanSection
          marketingPlan={startupKit.marketingPlan}
          onUpdate={(marketingPlan) => onUpdate({ ...startupKit, marketingPlan })}
        />
      </TabsContent>

      <TabsContent value="pricing">
        <PricingSection
          pricing={startupKit.pricing}
          onUpdate={(pricing) => onUpdate({ ...startupKit, pricing })}
        />
      </TabsContent>

      <TabsContent value="content">
        <ContentCalendarSection
          contentCalendar={startupKit.contentCalendar}
          onUpdate={(contentCalendar) => onUpdate({ ...startupKit, contentCalendar })}
        />
      </TabsContent>
    </Tabs>
  )
}
