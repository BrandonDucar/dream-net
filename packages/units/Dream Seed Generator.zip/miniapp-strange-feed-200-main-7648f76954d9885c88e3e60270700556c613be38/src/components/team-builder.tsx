'use client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Users } from 'lucide-react'

interface TeamBuilderProps {
  businessIdea: string
  requiredRoles: string[]
}

export function TeamBuilder({ businessIdea, requiredRoles }: TeamBuilderProps): JSX.Element {
  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Users className="h-6 w-6 text-orange-600" />
            Team Builder
            <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white">
              Talent Network
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 mb-4">
            Find verified talent for your {businessIdea} startup using Talent Protocol integration.
          </p>
          <div className="space-y-2 mb-4">
            <p className="text-sm font-medium">Recommended roles:</p>
            <div className="flex flex-wrap gap-2">
              {requiredRoles.map((role, index) => (
                <Badge key={index} variant="outline">{role}</Badge>
              ))}
            </div>
          </div>
          <div className="text-sm text-gray-500">
            Feature coming soon - connect with verified developers, designers, and marketers 
            through Talent Protocol's professional network.
          </div>
        </CardContent>
      </Card>
    </>
  )
}