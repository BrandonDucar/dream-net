/**
 * ================================================================================
 * DO NOT MODIFY THIS FILE. This file is READ ONLY and is DETERMINISTIC.
 *
 * FAL FluxPro 1.1 Image Generation API — Strict, Explicit, and Typed Agent Contract
 *
 * ALL USAGE MUST:
 * - Use only the exported PUBLIC methods below.
 * - Never change input/output schemas or flow.
 * - Always poll for status before fetching results.
 * - Throw/halt on any missing/null required field.
 * ================================================================================
 */

export type FluxProPrompt = {
  /** Text prompt describing the desired image (required, non-empty) */
  prompt: string;
  /** Random seed for reproducible output (optional) */
  seed?: number;
  /** Generate multiple images at once (default: 1) */
  num_images?: number;
  /** Output format: 'jpeg' or 'png' (default: 'jpeg') */
  output_format?: 'jpeg' | 'png';
  /** Enable/disable safety checker (default: true) */
  enable_safety_checker?: boolean;
  /** Safety tolerance: 1-6, higher is less strict (default: '2') */
  safety_tolerance?: '1' | '2' | '3' | '4' | '5' | '6';
  /** Aspect ratio for output image (default: '16:9') */
  aspect_ratio?: '21:9' | '16:9' | '4:3' | '3:2' | '1:1' | '2:3' | '3:4' | '9:16' | '9:21';
  /** Generate less processed/raw images (optional) */
  raw?: boolean;
};

export type FluxProSubmitResponse = {
  request_id: string;
};

export type FluxProStatusResponse =
  | { status: 'IN_QUEUE'; request_id: string; queue_position?: number }
  | { status: 'IN_PROGRESS'; request_id: string }
  | { status: 'COMPLETED'; request_id: string }
  | { status: string; request_id: string; [k: string]: any };

export type FluxProImageFile = {
  url: string; // Always check for valid, non-empty URL
  content_type: string;
  width?: number;
  height?: number;
  file_name?: string;
  file_size?: number;
};

export type FluxProImageResult = {
  images: FluxProImageFile[];
  seed?: number;
  prompt?: string;
};

function _throwIfInvalid(res: any, keys: string[]) {
  for (const k of keys) {
    if (res == null || res[k] == null || (typeof res[k] === 'string' && !res[k].trim()))
      throw new Error(`FluxPro: Required property "${k}" missing in response.`);
  }
}

/** Internal: All FAL API calls go through this proxy utility. */
async function _proxyFluxPro(options: {
  path: string;
  method?: 'GET' | 'POST';
  body?: any;
}): Promise<any> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Authorization: `Key secret_cm9157zvu00003b6rg40werxy`,
  };
  const payload: any = {
    protocol: 'https',
    origin: 'queue.fal.run',
    path: options.path,
    method: options.method || 'POST',
    headers,
  };
  if (options.body) payload.body = JSON.stringify(options.body);
  const res = await fetch('/api/proxy', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return res.json();
}

/**
 * Submit a FluxPro image generation job.
 * @param input FluxProPrompt
 * @returns request_id (string)
 * @throws if prompt is missing/empty, or request_id missing in response
 */
export async function fluxproSubmit(input: FluxProPrompt): Promise<string> {
  if (!input?.prompt || typeof input.prompt !== 'string' || !input.prompt.trim())
    throw new Error('Prompt is required and must be a non-empty string.');
  const body: any = { prompt: input.prompt };
  if (input.seed != null) body.seed = input.seed;
  if (input.num_images != null) body.num_images = input.num_images;
  if (input.output_format) body.output_format = input.output_format;
  if (typeof input.enable_safety_checker === 'boolean') body.enable_safety_checker = input.enable_safety_checker;
  if (input.safety_tolerance) body.safety_tolerance = input.safety_tolerance;
  if (input.aspect_ratio) body.aspect_ratio = input.aspect_ratio;
  if (input.raw != null) body.raw = input.raw;
  const res = await _proxyFluxPro({ path: '/fal-ai/flux-pro/v1.1-ultra', method: 'POST', body });
  _throwIfInvalid(res, ['request_id']);
  return res.request_id;
}

/**
 * Poll for FluxPro job status. Halts on error or unexpected status.
 * Cycles every 5 seconds until status is "COMPLETED" (max 20 min).
 * @param request_id (string)
 * @throws if request_id is missing, or API returns error/missing fields
 */
export async function fluxproPollStatus(
  request_id: string,
  maxAttempts = 240, // 20 min (5s x 240)
  intervalMs = 5000
): Promise<void> {
  if (!request_id || typeof request_id !== 'string')
    throw new Error('Missing request_id');
  let attempts = 0;
  while (true) {
    const res: FluxProStatusResponse = await _proxyFluxPro({
      path: `/fal-ai/flux-pro/requests/${request_id}/status`,
      method: 'GET',
    });
    _throwIfInvalid(res, ['status', 'request_id']);
    if (res.status === 'COMPLETED') return;
    if (res.status === 'IN_QUEUE' || res.status === 'IN_PROGRESS') {
      await new Promise((r) => setTimeout(r, intervalMs));
      attempts++;
      if (attempts > maxAttempts)
        throw new Error('FluxPro: Timeout waiting for image generation');
    } else {
      throw new Error(`FluxPro: Unexpected status "${res.status}" in polling`);
    }
  }
}

/**
 * Fetch FluxPro result (image URLs array). Always checks presence of valid images[].url.
 * Polls every 5s until present or throws on error/missing data.
 * @param request_id (string)
 * @returns images: FluxProImageFile[]
 * @throws if missing/invalid.
 */
export async function fluxproFetchImages(
  request_id: string,
  maxAttempts = 240,
  intervalMs = 5000
): Promise<FluxProImageFile[]> {
  if (!request_id || typeof request_id !== 'string')
    throw new Error('Missing request_id');
  let attempts = 0;
  while (true) {
    const res: FluxProImageResult = await _proxyFluxPro({
      path: `/fal-ai/flux-pro/requests/${request_id}`,
      method: 'GET',
    });
    if (Array.isArray(res?.images) && res.images.length > 0 && res.images.every(img => img.url))
      return res.images;
    await new Promise((r) => setTimeout(r, intervalMs));
    attempts++;
    if (attempts > maxAttempts)
      throw new Error('FluxPro: Timeout waiting for image result');
  }
}