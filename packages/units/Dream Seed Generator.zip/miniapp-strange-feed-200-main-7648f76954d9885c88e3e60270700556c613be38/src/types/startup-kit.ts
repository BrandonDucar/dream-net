export interface StartupKit {
  businessIdea: string
  names: string[]
  slogan: string
  logoPrompt: string
  pitchDeck: PitchDeck
  landingPage: LandingPage
  marketingPlan: MarketingDay[]
  pricing: PricingTier[]
  contentCalendar: ContentDay[]
}

export interface PitchDeck {
  problem: string
  solution: string
  market: string
  product: string
  businessModel: string
  competition: string
  team: string
  traction: string
  financials: string
  ask: string
}

export interface LandingPage {
  headline: string
  subheadline: string
  benefits: string[]
  cta: string
  features: Feature[]
}

export interface Feature {
  title: string
  description: string
}

export interface MarketingDay {
  day: number
  activity: string
  goal: string
}

export interface PricingTier {
  tier: string
  price: string
  features: string[]
}

export interface ContentDay {
  day: number
  content: string
  platform: string
}
