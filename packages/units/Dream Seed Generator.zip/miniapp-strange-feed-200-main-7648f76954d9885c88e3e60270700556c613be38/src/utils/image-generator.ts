import { openaiImageFromPromptUrl } from '@/openai-api'

/**
 * Generate an image using OpenAI DALL-E
 * @param prompt - The text prompt for image generation
 * @returns Promise<string> - URL of the generated image
 */
export async function generate_image(prompt: string): Promise<string> {
  try {
    const response = await openaiImageFromPromptUrl({
      model: 'dall-e-3',
      prompt: prompt,
      size: '1024x1024',
      n: 1
    })

    if (response.data && response.data.length > 0 && response.data[0].url) {
      return response.data[0].url
    } else {
      throw new Error('No image URL returned from OpenAI')
    }
  } catch (error) {
    console.error('Image generation error:', error)
    throw new Error('Failed to generate image')
  }
}

/**
 * Generate multiple images with variations
 * @param prompt - The base prompt for image generation
 * @param variations - Number of variations to generate (max 4)
 * @returns Promise<string[]> - Array of image URLs
 */
export async function generate_image_variations(prompt: string, variations: number = 4): Promise<string[]> {
  try {
    const promises = Array.from({ length: Math.min(variations, 4) }, (_, index) => {
      const variationPrompt = `${prompt} - variation ${index + 1}`
      return generate_image(variationPrompt)
    })

    const results = await Promise.allSettled(promises)
    
    return results
      .filter((result): result is PromiseFulfilledResult<string> => result.status === 'fulfilled')
      .map(result => result.value)
  } catch (error) {
    console.error('Image variations generation error:', error)
    return []
  }
}

/**
 * Generate a logo with specific styling
 * @param businessName - Name of the business
 * @param style - Style descriptor (modern, vintage, etc.)
 * @param colors - Color scheme descriptor
 * @returns Promise<string> - URL of the generated logo
 */
export async function generate_logo(
  businessName: string, 
  style: string = 'modern', 
  colors: string = 'blue and white'
): Promise<string> {
  const logoPrompt = `Professional ${style} logo for "${businessName}". ${colors} color scheme. Clean, minimalist design. Transparent background. Vector style. High quality branding logo suitable for business use.`
  
  return generate_image(logoPrompt)
}

/**
 * Generate a product mockup image
 * @param productDescription - Description of the product
 * @param style - Visual style (realistic, 3d, etc.)
 * @returns Promise<string> - URL of the generated mockup
 */
export async function generate_product_mockup(
  productDescription: string,
  style: string = 'realistic 3D'
): Promise<string> {
  const mockupPrompt = `${style} product mockup of ${productDescription}. Professional product photography style. Clean white background. High quality commercial image.`
  
  return generate_image(mockupPrompt)
}

/**
 * Generate a hero image for marketing
 * @param concept - The marketing concept or message
 * @param style - Visual style descriptor
 * @returns Promise<string> - URL of the generated hero image
 */
export async function generate_hero_image(
  concept: string,
  style: string = 'modern digital art'
): Promise<string> {
  const heroPrompt = `${style} hero image representing ${concept}. Professional marketing visual. Vibrant colors. High impact composition perfect for website headers.`
  
  return generate_image(heroPrompt)
}