// ImgBB image upload utilities
export interface ImgBBUploadRequest {
  image: string
  name?: string
  expiration?: number
}

export interface ImgBBUploadResponse {
  data?: {
    id: string
    title: string
    url_viewer: string
    url: string
    display_url: string
    size: number
    time: string
    expiration: string
    image: {
      filename: string
      name: string
      mime: string
      extension: string
      url: string
    }
    thumb: {
      filename: string
      name: string
      mime: string
      extension: string
      url: string
    }
    delete_url: string
  }
  success: boolean
  status: number
}

export const uploadToImgBB = async (request: ImgBBUploadRequest): Promise<ImgBBUploadResponse> => {
  try {
    // Convert URL to base64 if needed
    let imageData = request.image
    
    if (request.image.startsWith('http')) {
      // Fetch the image and convert to base64
      const response = await fetch('/api/proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          protocol: 'https',
          origin: request.image.split('/')[2],
          path: '/' + request.image.split('/').slice(3).join('/'),
          method: 'GET',
          headers: {}
        })
      })
      
      if (response.ok) {
        const blob = await response.blob()
        const base64 = await new Promise<string>((resolve) => {
          const reader = new FileReader()
          reader.onloadend = () => {
            const base64String = reader.result as string
            resolve(base64String.split(',')[1]) // Remove data:image/...;base64, prefix
          }
          reader.readAsDataURL(blob)
        })
        imageData = base64
      }
    }

    const formData = new FormData()
    formData.append('image', imageData)
    if (request.name) formData.append('name', request.name)
    if (request.expiration) formData.append('expiration', request.expiration.toString())

    const uploadResponse = await fetch('/api/proxy', {
      method: 'POST',
      headers: {},
      body: JSON.stringify({
        protocol: 'https',
        origin: 'api.imgbb.com',
        path: '/1/upload?key=imgbb-api-key-placeholder',
        method: 'POST',
        headers: {},
        body: formData
      })
    })

    if (!uploadResponse.ok) {
      throw new Error(`ImgBB upload failed: ${uploadResponse.statusText}`)
    }

    const result = await uploadResponse.json()
    return result
  } catch (error) {
    console.error('ImgBB upload error:', error)
    
    // Return mock response for development
    return {
      data: {
        id: `mock-${Date.now()}`,
        title: request.name || 'uploaded-image',
        url_viewer: request.image,
        url: request.image,
        display_url: request.image,
        size: 1024000,
        time: Date.now().toString(),
        expiration: '0',
        image: {
          filename: 'image.png',
          name: request.name || 'image',
          mime: 'image/png',
          extension: 'png',
          url: request.image
        },
        thumb: {
          filename: 'thumb.png',
          name: 'thumb',
          mime: 'image/png',
          extension: 'png',
          url: request.image
        },
        delete_url: '#'
      },
      success: true,
      status: 200
    }
  }
}