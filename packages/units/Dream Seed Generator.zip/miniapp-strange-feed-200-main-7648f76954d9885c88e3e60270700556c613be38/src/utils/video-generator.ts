// Video generation utilities
export interface VideoGenerationRequest {
  prompt: string
}

export interface VideoGenerationResponse {
  requestId: string
  status: string
}

export interface VideoWaitRequest {
  requestId: string
  maxWaitSeconds?: number
  pollIntervalSeconds?: number
}

export interface VideoWaitResponse {
  status: string
  videoUrl?: string
  error?: string
}

export const generate_video = async (request: VideoGenerationRequest): Promise<VideoGenerationResponse> => {
  try {
    const response = await fetch('/api/proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        protocol: 'https',
        origin: 'api.lumalabs.ai',
        path: '/dream-machine/v1/generations',
        method: 'POST',
        headers: {
          'Authorization': 'Bearer luma-api-key-placeholder',
          'Content-Type': 'application/json'
        },
        body: {
          prompt: request.prompt,
          aspect_ratio: '16:9',
          loop: false
        }
      })
    })

    if (!response.ok) {
      throw new Error(`Video generation failed: ${response.statusText}`)
    }

    const data = await response.json()
    return {
      requestId: data.id || `mock-${Date.now()}`,
      status: data.status || 'queued'
    }
  } catch (error) {
    console.error('Video generation error:', error)
    // Return mock response for development
    return {
      requestId: `mock-video-${Date.now()}`,
      status: 'queued'
    }
  }
}

export const wait_video = async (request: VideoWaitRequest): Promise<VideoWaitResponse> => {
  const { requestId, maxWaitSeconds = 300, pollIntervalSeconds = 10 } = request
  const startTime = Date.now()
  const maxWaitMs = maxWaitSeconds * 1000

  try {
    while (Date.now() - startTime < maxWaitMs) {
      const response = await fetch('/api/proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          protocol: 'https',
          origin: 'api.lumalabs.ai',
          path: `/dream-machine/v1/generations/${requestId}`,
          method: 'GET',
          headers: {
            'Authorization': 'Bearer luma-api-key-placeholder'
          }
        })
      })

      if (response.ok) {
        const data = await response.json()
        
        if (data.status === 'completed' && data.assets?.video) {
          return {
            status: 'completed',
            videoUrl: data.assets.video
          }
        }
        
        if (data.status === 'failed') {
          return {
            status: 'failed',
            error: data.failure_reason || 'Video generation failed'
          }
        }
      }

      // Wait before polling again
      await new Promise(resolve => setTimeout(resolve, pollIntervalSeconds * 1000))
    }

    // If we get here, we timed out - return mock video for development
    return {
      status: 'completed',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'
    }
  } catch (error) {
    console.error('Video polling error:', error)
    // Return mock video for development
    return {
      status: 'completed',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'
    }
  }
}