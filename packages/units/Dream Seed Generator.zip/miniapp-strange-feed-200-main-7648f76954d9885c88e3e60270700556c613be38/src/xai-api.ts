/**
 * ================================================================================
 * DO NOT MODIFY THIS FILE. This file is READ ONLY and is DETERMINISTIC.
 * xAI Live Search API Integration — Real-time chat completions with citations.
 * All requests are securely relayed via /api/proxy; no API key ever exposed client-side.
 * ================================================================================
 */

export type XaiMessage = { role: 'user' | 'assistant' | 'system'; content: string };

export type XaiSource =
  | { type: 'web'; country?: string; excluded_websites?: string[]; safe_search?: boolean }
  | { type: 'x'; x_handles?: string[] }
  | { type: 'news'; country?: string; excluded_websites?: string[]; safe_search?: boolean }
  | { type: 'rss'; links?: string[] };

export type XaiSearchParameters = {
  mode?: 'auto' | 'on' | 'off';
  sources?: XaiSource[];
  return_citations?: boolean;
  from_date?: string; // YYYY-MM-DD
  to_date?: string;   // YYYY-MM-DD
  max_search_results?: number;
};

export type XaiLiveSearchInput = {
  messages: XaiMessage[];
  search_parameters?: XaiSearchParameters;
  model?: string; // default: "grok-3-latest"
};

export type XaiChatChoice = {
  message: { role: string; content: string };
};

export type XaiLiveSearchOutput = {
  choices: XaiChatChoice[];
  citations?: string[];
};

const BASE_URL = 'api.x.ai';

/**
 * Proxy call to xAI Live Search for real-time chat completion with web search and citations.
 * All parameters and return values are fully typed. All errors use safe fallbacks.
 *
 * @param input XaiLiveSearchInput (messages, search_parameters, model)
 * @returns XaiLiveSearchOutput ({ choices: [...], citations: [...] })
 */
export async function xaiLiveSearch(input: XaiLiveSearchInput): Promise<XaiLiveSearchOutput> {
  try {
    if (!input.messages || !Array.isArray(input.messages) || !input.messages.length) {
      return { choices: [], citations: [] };
    }
    const res = await fetch('/api/proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        protocol: 'https',
        origin: BASE_URL,
        path: '/v1/chat/completions',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer secret_cmbtluy3a0000356ntmpbqbbz`,
        },
        body: JSON.stringify({
          messages: input.messages,
          search_parameters: input.search_parameters || {},
          model: input.model || 'grok-3-latest',
        }),
      }),
    });
    const data = await res.json();
    if (!data || !Array.isArray(data.choices)) {
      return { choices: [], citations: [] };
    }
    // Safe fallback for citations
    return {
      choices: data.choices || [],
      citations: Array.isArray(data.citations) ? data.citations : [],
    };
  } catch {
    // On any error, return safe fallbacks.
    return { choices: [], citations: [] };
  }
}