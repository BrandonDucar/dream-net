import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const { apiKey, heroLevel, region, difficulty, heroClass } = await request.json();

    if (!apiKey) {
      return NextResponse.json({ error: 'API key required' }, { status: 400 });
    }

    const prompt = `Create an epic fantasy RPG quest for a level ${heroLevel} ${heroClass} in the ${region} region with ${difficulty} difficulty.

Generate a JSON response with this exact structure:
{
  "title": "Quest title (exciting and thematic)",
  "story": ["Opening line establishing the threat", "Second line building tension", "Third line calling hero to action"],
  "enemyName": "Name of the enemy/boss",
  "enemyDescription": "Brief description of the enemy",
  "questHook": "One sentence why this quest matters",
  "battleDialogue": ["Enemy opening taunt", "Mid-battle threat", "Defeat quote"]
}

Make it dramatic, engaging, and appropriate for the difficulty level. The story should be 3 compelling sentences.`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: 'You are a creative fantasy game writer. Generate exciting quest content in valid JSON format only. Do not include any markdown formatting or code blocks.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.9,
        max_tokens: 500
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return NextResponse.json({ error: 'OpenAI API error', details: errorData }, { status: response.status });
    }

    const data = await response.json();
    const content = data.choices[0]?.message?.content;

    if (!content) {
      return NextResponse.json({ error: 'No content generated' }, { status: 500 });
    }

    let questData;
    try {
      questData = JSON.parse(content);
    } catch (parseError) {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        questData = JSON.parse(jsonMatch[0]);
      } else {
        return NextResponse.json({ error: 'Failed to parse AI response', content }, { status: 500 });
      }
    }

    return NextResponse.json({ success: true, quest: questData });
  } catch (error) {
    console.error('AI Quest Generation Error:', error);
    return NextResponse.json({ error: 'Failed to generate quest', details: String(error) }, { status: 500 });
  }
}
