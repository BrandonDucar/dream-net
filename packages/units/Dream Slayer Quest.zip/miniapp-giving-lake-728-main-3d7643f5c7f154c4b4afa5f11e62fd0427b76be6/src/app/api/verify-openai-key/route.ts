import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const { apiKey } = await request.json();

    if (!apiKey || !apiKey.startsWith('sk-')) {
      return NextResponse.json({ valid: false, error: 'Invalid API key format' }, { status: 400 });
    }

    const response = await fetch('https://api.openai.com/v1/models', {
      headers: {
        'Authorization': `Bearer ${apiKey}`
      }
    });

    if (response.ok) {
      return NextResponse.json({ valid: true });
    } else {
      return NextResponse.json({ valid: false, error: 'API key verification failed' }, { status: 401 });
    }
  } catch (error) {
    return NextResponse.json({ valid: false, error: 'Verification error' }, { status: 500 });
  }
}
