import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { ResponseLogger } from "@/components/response-logger";
import { cookies } from "next/headers";
import { ReadyNotifier } from "@/components/ready-notifier";
import FarcasterWrapper from "@/components/FarcasterWrapper";

const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const requestId = cookies().get("x-request-id")?.value;

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "VideoGame",
    "name": "Dream Hero: Dragon Slayer Quest",
    "description": "Epic AI-powered fantasy RPG with dynamic quests, turn-based battles, and legendary loot",
    "genre": ["Role-Playing Game", "Fantasy", "Adventure"],
    "gamePlatform": "Web Browser",
    "playMode": "SinglePlayer",
    "author": {
      "@type": "Organization",
      "name": "Dream Hero Team"
    },
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD",
      "availability": "https://schema.org/InStock"
    },
    "applicationCategory": "Game",
    "operatingSystem": "Any",
    "keywords": "fantasy game, rpg, dragon slayer, turn-based combat, AI game, fantasy adventure"
  };

  return (
        <html lang="en">
          <head>
            {requestId && <meta name="x-request-id" content={requestId} />}
            <script
              type="application/ld+json"
              dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
            />
          </head>
          <body
            className={`${geistSans.variable} ${geistMono.variable} antialiased`}
          >
            {/* Do not remove this component, we use it to notify the parent that the mini-app is ready */}
            <ReadyNotifier />
            
      <FarcasterWrapper>
        {children}
      </FarcasterWrapper>
      
            <ResponseLogger />
          </body>
        </html>
      );
}

export const metadata: Metadata = {
        title: "Dream Hero Adventure",
        description: "Embark on an epic fantasy journey as a hero. Experience AI-generated storylines, turn-based battles, regional unlocks, and more. Customize your hero, collect loot, and conquer dragons.",
        other: { "fc:frame": JSON.stringify({"version":"next","imageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_b9d57e29-12c0-419b-b9bb-dff238ea586d-CCjX5m80qYGfqxtMEOex0oPoJEobE6","button":{"title":"Open with Ohara","action":{"type":"launch_frame","name":"Dream Hero Adventure","url":"https://giving-lake-728.app.ohara.ai","splashImageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/farcaster/splash_images/splash_image1.svg","splashBackgroundColor":"#ffffff"}}}
        ) }
    };
