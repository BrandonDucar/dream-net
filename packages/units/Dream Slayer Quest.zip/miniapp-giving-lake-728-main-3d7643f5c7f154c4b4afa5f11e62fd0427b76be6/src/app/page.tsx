'use client'
import { useState, useEffect } from 'react';
import type { Hero, GameState, Quest, Battle, Region } from '@/types/game';
import { HeroSelection } from '@/components/game/HeroSelection';
import { GameBoard } from '@/components/game/GameBoard';
import { BattleScreen } from '@/components/game/BattleScreen';
import { HeroProfile } from '@/components/game/HeroProfile';
import { QuestLog } from '@/components/game/QuestLog';
import { Inventory } from '@/components/game/Inventory';
import { SkillTree } from '@/components/game/SkillTree';
import { RegionMap } from '@/components/game/RegionMap';
import { GameIntro } from '@/components/game/GameIntro';
import { SettingsPanel } from '@/components/game/SettingsPanel';
import { useGameLogic } from '@/hooks/useGameLogic';
import { useSoundEffects } from '@/hooks/useSoundEffects';
import { useGeolocation } from '@/hooks/useGeolocation';
import { AnimatePresence, motion } from 'framer-motion';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DreamHeroGame(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [gameStarted, setGameStarted] = useState<boolean>(false);
  const [showIntro, setShowIntro] = useState<boolean>(true);
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const { location, region } = useGeolocation();
  
  const {
    gameState,
    currentQuest,
    currentBattle,
    activeScreen,
    setActiveScreen,
    selectHero,
    startQuest,
    performBattleAction,
    levelUp,
    equipItem,
    upgradeSkill,
    unlockRegion,
    completeQuest,
    isBattleProcessing
  } = useGameLogic();

  const { playSound } = useSoundEffects();

  useEffect(() => {
    if (gameStarted && gameState.hero) {
      playSound('ambient');
    }
  }, [gameStarted, gameState.hero, playSound]);

  const handleHeroSelect = (heroClass: Hero['class'], skinId?: string): void => {
    selectHero(heroClass, region, skinId);
    setGameStarted(true);
    setShowIntro(false);
    playSound('select');
  };

  const handleStartGame = (): void => {
    setShowIntro(false);
  };

  if (showIntro) {
    return <GameIntro onStart={handleStartGame} />;
  }

  if (!gameStarted || !gameState.hero) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-purple-900 via-indigo-900 to-black">
        <HeroSelection onSelectHero={handleHeroSelect} region={region} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-indigo-900 to-black text-white">
      <AnimatePresence mode="wait">
        {currentBattle && activeScreen === 'battle' ? (
          <motion.div
            key="battle"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.3 }}
          >
            <BattleScreen
              battle={currentBattle}
              hero={gameState.hero}
              onAction={performBattleAction}
              onVictory={completeQuest}
              onDefeat={() => setActiveScreen('main')}
              isProcessing={isBattleProcessing}
            />
          </motion.div>
        ) : activeScreen === 'profile' ? (
          <motion.div
            key="profile"
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ duration: 0.3 }}
          >
            <HeroProfile
              hero={gameState.hero}
              achievements={gameState.achievements}
              onClose={() => setActiveScreen('main')}
            />
          </motion.div>
        ) : activeScreen === 'quests' ? (
          <motion.div
            key="quests"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            transition={{ duration: 0.3 }}
          >
            <QuestLog
              quests={gameState.quests}
              currentQuest={currentQuest}
              onStartQuest={startQuest}
              onClose={() => setActiveScreen('main')}
            />
          </motion.div>
        ) : activeScreen === 'inventory' ? (
          <motion.div
            key="inventory"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.3 }}
          >
            <Inventory
              hero={gameState.hero}
              onEquipItem={equipItem}
              onClose={() => setActiveScreen('main')}
            />
          </motion.div>
        ) : activeScreen === 'skills' ? (
          <motion.div
            key="skills"
            initial={{ opacity: 0, rotate: -5 }}
            animate={{ opacity: 1, rotate: 0 }}
            exit={{ opacity: 0, rotate: 5 }}
            transition={{ duration: 0.3 }}
          >
            <SkillTree
              hero={gameState.hero}
              onUpgradeSkill={upgradeSkill}
              onClose={() => setActiveScreen('main')}
            />
          </motion.div>
        ) : activeScreen === 'map' ? (
          <motion.div
            key="map"
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.3 }}
          >
            <RegionMap
              regions={gameState.regions}
              currentRegion={gameState.currentRegion}
              onSelectRegion={unlockRegion}
              onClose={() => setActiveScreen('main')}
            />
          </motion.div>
        ) : (
          <motion.div
            key="main"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <>
              <GameBoard
                gameState={gameState}
                currentQuest={currentQuest}
                onNavigate={setActiveScreen}
                onOpenSettings={(): void => setShowSettings(true)}
              />
              {showSettings && (
                <SettingsPanel onClose={(): void => setShowSettings(false)} />
              )}
            </>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
