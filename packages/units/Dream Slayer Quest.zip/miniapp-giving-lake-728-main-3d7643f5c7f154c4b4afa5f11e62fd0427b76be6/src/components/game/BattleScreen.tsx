'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import type { Battle, Hero, Quest } from '@/types/game';
import { Sword, Shield, Sparkles, Heart, Skull, Zap, Loader2 } from 'lucide-react';

interface BattleScreenProps {
  battle: Battle;
  hero: Hero;
  onAction: (action: 'attack' | 'skill' | 'defend' | 'item', skillId?: string) => void;
  onVictory: (quest: Quest) => void;
  onDefeat: () => void;
  isProcessing?: boolean;
}

export function BattleScreen({ battle, hero, onAction, onVictory, onDefeat, isProcessing = false }: BattleScreenProps): JSX.Element {
  const [selectedSkill, setSelectedSkill] = useState<string | null>(null);
  const [showSkills, setShowSkills] = useState<boolean>(false);

  const heroHpPercentage = (hero.hp / hero.maxHp) * 100;
  const enemyHpPercentage = (battle.enemy.hp / battle.enemy.maxHp) * 100;

  const isVictory = battle.enemy.hp <= 0;
  const isDefeat = hero.hp <= 0;

  const handleAttack = (): void => {
    if (!isProcessing) {
      onAction('attack');
    }
  };

  const handleSkill = (skillId: string): void => {
    if (!isProcessing) {
      setSelectedSkill(skillId);
      onAction('skill', skillId);
      setShowSkills(false);
    }
  };

  const handleDefend = (): void => {
    if (!isProcessing) {
      onAction('defend');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-900 via-purple-900 to-black p-4 pt-16">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-2">BATTLE!</h1>
          <Badge variant={battle.enemy.isBoss ? 'destructive' : 'default'} className="text-lg">
            {battle.enemy.isBoss ? '👑 BOSS BATTLE 👑' : `Turn ${battle.turnCount}`}
          </Badge>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <motion.div
            initial={{ x: -100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-gradient-to-br from-blue-900/90 to-purple-900/90 border-2 border-blue-500">
              <CardHeader>
                <CardTitle className="text-2xl text-white flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Shield className="w-8 h-8" />
                    {hero.name}
                  </span>
                  <span className="text-sm">Level {hero.level}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-gray-300 flex items-center gap-2">
                        <Heart className="w-4 h-4 text-red-500" />
                        HP: {hero.hp}/{hero.maxHp}
                      </span>
                    </div>
                    <Progress value={heroHpPercentage} className="h-4" />
                  </div>
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-gray-300 flex items-center gap-2">
                        <Zap className="w-4 h-4 text-blue-500" />
                        MP: {hero.mp}/{hero.maxMp}
                      </span>
                    </div>
                    <Progress value={(hero.mp / hero.maxMp) * 100} className="h-4" />
                  </div>
                  <div className="grid grid-cols-3 gap-2 pt-2">
                    <div className="bg-black/30 rounded p-2 text-center">
                      <div className="text-xs text-gray-400">ATK</div>
                      <div className="text-lg text-red-400 font-bold">{hero.attack}</div>
                    </div>
                    <div className="bg-black/30 rounded p-2 text-center">
                      <div className="text-xs text-gray-400">DEF</div>
                      <div className="text-lg text-blue-400 font-bold">{hero.defense}</div>
                    </div>
                    <div className="bg-black/30 rounded p-2 text-center">
                      <div className="text-xs text-gray-400">MAG</div>
                      <div className="text-lg text-purple-400 font-bold">{hero.magic}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ x: 100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-gradient-to-br from-red-900/90 to-orange-900/90 border-2 border-red-500">
              <CardHeader>
                <CardTitle className="text-2xl text-white flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Skull className="w-8 h-8" />
                    {battle.enemy.name}
                  </span>
                  <span className="text-sm">Level {battle.enemy.level}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-gray-300 flex items-center gap-2">
                        <Heart className="w-4 h-4 text-red-500" />
                        HP: {battle.enemy.hp}/{battle.enemy.maxHp}
                      </span>
                    </div>
                    <Progress value={enemyHpPercentage} className="h-4" />
                  </div>
                  <div className="grid grid-cols-3 gap-2 pt-2">
                    <div className="bg-black/30 rounded p-2 text-center">
                      <div className="text-xs text-gray-400">ATK</div>
                      <div className="text-lg text-red-400 font-bold">{battle.enemy.attack}</div>
                    </div>
                    <div className="bg-black/30 rounded p-2 text-center">
                      <div className="text-xs text-gray-400">DEF</div>
                      <div className="text-lg text-blue-400 font-bold">{battle.enemy.defense}</div>
                    </div>
                    <div className="bg-black/30 rounded p-2 text-center">
                      <div className="text-xs text-gray-400">MAG</div>
                      <div className="text-lg text-purple-400 font-bold">{battle.enemy.magic}</div>
                    </div>
                  </div>
                  {battle.enemy.isBoss && (
                    <Badge variant="destructive" className="w-full justify-center">
                      LEGENDARY BOSS
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <AnimatePresence mode="wait">
          {isVictory ? (
            <motion.div
              key="victory"
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="text-center"
            >
              <Card className="bg-gradient-to-br from-green-900/90 to-emerald-900/90 border-2 border-green-500 max-w-2xl mx-auto">
                <CardHeader>
                  <CardTitle className="text-4xl text-white">⚔️ VICTORY! ⚔️</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-xl text-gray-200 mb-6">
                    You have defeated {battle.enemy.name}!
                  </p>
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-black/30 rounded p-4">
                      <div className="text-sm text-gray-400">XP Gained</div>
                      <div className="text-2xl text-yellow-400 font-bold">
                        +{battle.enemy.xpReward}
                      </div>
                    </div>
                    <div className="bg-black/30 rounded p-4">
                      <div className="text-sm text-gray-400">Gold Gained</div>
                      <div className="text-2xl text-yellow-400 font-bold">
                        +{battle.enemy.goldReward} 💰
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-gray-400">
                    Returning to town...
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ) : isDefeat ? (
            <motion.div
              key="defeat"
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="text-center"
            >
              <Card className="bg-gradient-to-br from-gray-900/90 to-black/90 border-2 border-gray-500 max-w-2xl mx-auto">
                <CardHeader>
                  <CardTitle className="text-4xl text-white">💀 DEFEAT 💀</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-xl text-gray-200 mb-6">
                    You have been defeated by {battle.enemy.name}...
                  </p>
                  <p className="text-sm text-gray-400 mb-4">
                    You lost 10% of your gold and returned to town with 50% HP
                  </p>
                  <Button onClick={onDefeat} size="lg" variant="outline">
                    Return to Town
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ) : (
            <motion.div
              key="actions"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Card className="bg-gray-900/90 border-2 border-purple-500 max-w-3xl mx-auto">
                <CardHeader>
                  <CardTitle className="text-white text-center flex items-center justify-center gap-2">
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Processing Turn...
                      </>
                    ) : (
                      'Your Turn - Choose Action'
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {showSkills ? (
                    <div className="space-y-3">
                      <h3 className="text-white font-bold mb-3">Select a Skill</h3>
                      {hero.skills.filter(s => s.unlocked).map((skill) => (
                        <Button
                          key={skill.id}
                          onClick={() => handleSkill(skill.id)}
                          disabled={hero.mp < skill.mpCost || isProcessing}
                          className="w-full justify-between"
                          variant="outline"
                        >
                          <span className="flex items-center gap-2">
                            <Sparkles className="w-4 h-4" />
                            {skill.name}
                          </span>
                          <Badge variant="secondary">{skill.mpCost} MP</Badge>
                        </Button>
                      ))}
                      <Button
                        onClick={() => setShowSkills(false)}
                        variant="ghost"
                        className="w-full"
                        disabled={isProcessing}
                      >
                        Back
                      </Button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <Button
                        onClick={handleAttack}
                        disabled={isProcessing}
                        size="lg"
                        className="bg-red-600 hover:bg-red-700 disabled:opacity-50"
                      >
                        <Sword className="w-5 h-5 mr-2" />
                        Attack
                      </Button>
                      <Button
                        onClick={() => setShowSkills(true)}
                        disabled={isProcessing}
                        size="lg"
                        className="bg-purple-600 hover:bg-purple-700 disabled:opacity-50"
                      >
                        <Sparkles className="w-5 h-5 mr-2" />
                        Skills
                      </Button>
                      <Button
                        onClick={handleDefend}
                        disabled={isProcessing}
                        size="lg"
                        className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
                      >
                        <Shield className="w-5 h-5 mr-2" />
                        Defend
                      </Button>
                      <Button
                        disabled
                        size="lg"
                        variant="outline"
                      >
                        Items
                      </Button>
                    </div>
                  )}

                  <div className="mt-6 bg-black/40 rounded p-4 max-h-48 overflow-y-auto">
                    <h3 className="text-white font-bold mb-2">Battle Log</h3>
                    <div className="space-y-1">
                      {battle.battleLog.slice(-8).reverse().map((log, index) => (
                        <motion.div 
                          key={`${log.timestamp}-${index}`}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="text-sm text-gray-300"
                        >
                          <span className={log.attacker === 'hero' ? 'text-blue-400 font-semibold' : 'text-red-400 font-semibold'}>
                            {log.attacker === 'hero' ? hero.name : battle.enemy.name}
                          </span>
                          {' '}uses{' '}
                          <span className="text-yellow-400">{log.action}</span>
                          {log.damage > 0 && (
                            <>
                              {' '}for{' '}
                              <span className={log.critical ? 'text-orange-400 font-bold' : 'text-white font-semibold'}>
                                {log.damage} {log.critical && '⚡CRITICAL!⚡'}
                              </span>
                              {' '}damage
                            </>
                          )}
                        </motion.div>
                      ))}
                    </div>
                  </div>

                  {!isProcessing && (
                    <div className="mt-4 text-center">
                      <p className="text-sm text-gray-400">
                        💡 Each action triggers the enemy&apos;s turn automatically
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
