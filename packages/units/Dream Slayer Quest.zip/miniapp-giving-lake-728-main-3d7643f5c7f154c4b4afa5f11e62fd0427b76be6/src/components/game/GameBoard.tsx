'use client';

import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import type { GameState, Quest, ActiveScreen } from '@/types/game';
import { User, Scroll, Package, Sparkles, Map, Crown, Heart, Zap, Settings } from 'lucide-react';

interface GameBoardProps {
  gameState: GameState;
  currentQuest: Quest | null;
  onNavigate: (screen: ActiveScreen) => void;
  onOpenSettings: () => void;
}

export function GameBoard({ gameState, currentQuest, onNavigate, onOpenSettings }: GameBoardProps): JSX.Element {
  if (!gameState.hero) return <div>Loading...</div>;

  const hero = gameState.hero;
  const hpPercentage = (hero.hp / hero.maxHp) * 100;
  const mpPercentage = (hero.mp / hero.maxMp) * 100;
  const xpPercentage = (hero.xp / hero.xpToNextLevel) * 100;

  const availableQuests = gameState.quests.filter(q => !q.completed && !q.active);

  return (
    <div className="min-h-screen p-4 pt-16 pb-24">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Card className="bg-gradient-to-r from-purple-900/90 to-indigo-900/90 border-2 border-purple-500">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-3xl text-white flex items-center gap-3">
                    <Crown className="w-8 h-8 text-yellow-400" />
                    {hero.name}
                  </CardTitle>
                  <CardDescription className="text-gray-300 text-lg">
                    Level {hero.level} {hero.class.charAt(0).toUpperCase() + hero.class.slice(1)} • {hero.titles[hero.titles.length - 1]}
                  </CardDescription>
                </div>
                <div className="flex items-start gap-4">
                  <div className="text-right">
                    <div className="text-2xl text-yellow-400 font-bold">{hero.gold} 💰</div>
                    <div className="text-sm text-gray-400">Gold</div>
                  </div>
                  <Button
                    onClick={onOpenSettings}
                    variant="outline"
                    size="icon"
                    className="bg-purple-500/20 border-purple-500 hover:bg-purple-500/40"
                  >
                    <Settings className="w-5 h-5 text-purple-300" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-300 flex items-center gap-2">
                      <Heart className="w-4 h-4 text-red-500" />
                      HP: {hero.hp}/{hero.maxHp}
                    </span>
                  </div>
                  <Progress value={hpPercentage} className="h-3" />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-300 flex items-center gap-2">
                      <Zap className="w-4 h-4 text-blue-500" />
                      MP: {hero.mp}/{hero.maxMp}
                    </span>
                  </div>
                  <Progress value={mpPercentage} className="h-3" />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-300">XP: {hero.xp}/{hero.xpToNextLevel}</span>
                  </div>
                  <Progress value={xpPercentage} className="h-3" />
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2">
                <div className="bg-black/30 rounded p-3">
                  <div className="text-xs text-gray-400">Attack</div>
                  <div className="text-xl text-red-400 font-bold">{hero.attack}</div>
                </div>
                <div className="bg-black/30 rounded p-3">
                  <div className="text-xs text-gray-400">Defense</div>
                  <div className="text-xl text-blue-400 font-bold">{hero.defense}</div>
                </div>
                <div className="bg-black/30 rounded p-3">
                  <div className="text-xs text-gray-400">Magic</div>
                  <div className="text-xl text-purple-400 font-bold">{hero.magic}</div>
                </div>
                <div className="bg-black/30 rounded p-3">
                  <div className="text-xs text-gray-400">Speed</div>
                  <div className="text-xl text-green-400 font-bold">{hero.speed}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="bg-gray-900/80 border-2 border-gray-700 hover:border-blue-500 transition-all cursor-pointer h-full" onClick={() => onNavigate('quests')}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Scroll className="w-6 h-6 text-blue-400" />
                  Quest Log
                </CardTitle>
                <CardDescription>
                  {availableQuests.length} available quests
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline">
                  View Quests
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-gray-900/80 border-2 border-gray-700 hover:border-purple-500 transition-all cursor-pointer h-full" onClick={() => onNavigate('inventory')}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Package className="w-6 h-6 text-purple-400" />
                  Inventory
                </CardTitle>
                <CardDescription>
                  {hero.inventory.length} items
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline">
                  View Items
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-gray-900/80 border-2 border-gray-700 hover:border-green-500 transition-all cursor-pointer h-full" onClick={() => onNavigate('skills')}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Sparkles className="w-6 h-6 text-green-400" />
                  Skills
                </CardTitle>
                <CardDescription>
                  {hero.skills.filter(s => s.unlocked).length} skills unlocked
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline">
                  View Skills
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="bg-gray-900/80 border-2 border-gray-700 hover:border-yellow-500 transition-all cursor-pointer h-full" onClick={() => onNavigate('map')}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Map className="w-6 h-6 text-yellow-400" />
                  World Map
                </CardTitle>
                <CardDescription>
                  {gameState.regions.filter(r => r.unlocked).length} regions unlocked
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline">
                  View Map
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="bg-gray-900/80 border-2 border-gray-700 hover:border-orange-500 transition-all cursor-pointer h-full" onClick={() => onNavigate('profile')}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <User className="w-6 h-6 text-orange-400" />
                  Hero Profile
                </CardTitle>
                <CardDescription>
                  View stats & achievements
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline">
                  View Profile
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {currentQuest && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="bg-gradient-to-r from-red-900/80 to-orange-900/80 border-2 border-orange-500">
              <CardHeader>
                <CardTitle className="text-white">Active Quest</CardTitle>
                <CardDescription className="text-gray-200">{currentQuest.title}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-white mb-4">{currentQuest.story[0]}</p>
                <Badge variant="destructive" className="mr-2">
                  {currentQuest.difficulty.toUpperCase()}
                </Badge>
                <Badge variant="outline">
                  Level {currentQuest.enemy.level}
                </Badge>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}
