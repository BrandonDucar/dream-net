'use client';

import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Sparkles, Swords, Shield, Flame } from 'lucide-react';

interface GameIntroProps {
  onStart: () => void;
}

export function GameIntro({ onStart }: GameIntroProps): JSX.Element {
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-indigo-900 to-black flex items-center justify-center p-4 pt-16">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="max-w-4xl text-center"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.3, type: 'spring' }}
          className="mb-8"
        >
          <div className="flex justify-center items-center gap-4 mb-4">
            <Sparkles className="w-12 h-12 text-yellow-400" />
            <h1 className="text-6xl md:text-8xl font-bold bg-gradient-to-r from-yellow-400 via-pink-500 to-purple-500 bg-clip-text text-transparent">
              Dream Hero
            </h1>
            <Flame className="w-12 h-12 text-orange-500" />
          </div>
          <h2 className="text-3xl md:text-4xl font-semibold text-white mb-2">
            Dragon Slayer Quest
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="space-y-6 mb-12"
        >
          <p className="text-xl md:text-2xl text-gray-300 leading-relaxed">
            Embark on an epic adventure through mystical lands. Face fearsome dragons,
            battle legendary monsters, and forge your destiny as the ultimate hero.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-purple-900/50 p-6 rounded-lg border-2 border-purple-500/50"
            >
              <Swords className="w-10 h-10 text-red-400 mx-auto mb-3" />
              <h3 className="text-lg font-bold text-white mb-2">Dynamic Quests</h3>
              <p className="text-sm text-gray-400">
                AI-generated storylines that adapt to your choices
              </p>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-purple-900/50 p-6 rounded-lg border-2 border-blue-500/50"
            >
              <Shield className="w-10 h-10 text-blue-400 mx-auto mb-3" />
              <h3 className="text-lg font-bold text-white mb-2">Turn-Based Combat</h3>
              <p className="text-sm text-gray-400">
                Strategic battles with skills, magic, and legendary loot
              </p>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-purple-900/50 p-6 rounded-lg border-2 border-green-500/50"
            >
              <Sparkles className="w-10 h-10 text-green-400 mx-auto mb-3" />
              <h3 className="text-lg font-bold text-white mb-2">Epic Progression</h3>
              <p className="text-sm text-gray-400">
                Level up, unlock regions, earn titles and achievements
              </p>
            </motion.div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1 }}
        >
          <Button
            onClick={onStart}
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white text-xl px-12 py-6 rounded-full shadow-2xl"
          >
            Begin Your Quest
          </Button>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="text-gray-500 text-sm mt-8"
        >
          Your adventure begins now, brave hero...
        </motion.p>
      </motion.div>
    </div>
  );
}
