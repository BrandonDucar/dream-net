'use client';

import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import type { Hero, Achievement } from '@/types/game';
import { X, Crown, Award, Sword, Shield, Sparkles, Zap } from 'lucide-react';

interface HeroProfileProps {
  hero: Hero;
  achievements: Achievement[];
  onClose: () => void;
}

export function HeroProfile({ hero, achievements, onClose }: HeroProfileProps): JSX.Element {
  const unlockedAchievements = achievements.filter(a => a.unlocked);

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-indigo-900 to-black p-4 pt-16">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-between items-center mb-6"
        >
          <h1 className="text-4xl font-bold text-white flex items-center gap-3">
            <Crown className="w-10 h-10 text-yellow-400" />
            Hero Profile
          </h1>
          <Button onClick={onClose} variant="ghost" size="icon">
            <X className="w-6 h-6" />
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="bg-gradient-to-br from-purple-900/90 to-blue-900/90 border-2 border-purple-500 mb-6">
            <CardHeader>
              <CardTitle className="text-3xl text-white">{hero.name}</CardTitle>
              <div className="flex gap-2 flex-wrap mt-2">
                <Badge className="bg-gradient-to-r from-yellow-600 to-orange-600">
                  Level {hero.level}
                </Badge>
                <Badge className="bg-gradient-to-r from-blue-600 to-purple-600">
                  {hero.class.charAt(0).toUpperCase() + hero.class.slice(1)}
                </Badge>
                {hero.titles.map((title, i) => (
                  <Badge key={i} variant="outline">
                    {title}
                  </Badge>
                ))}
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    <Sword className="w-5 h-5" />
                    Combat Stats
                  </h3>
                  <div className="space-y-3">
                    <div className="bg-black/30 rounded p-3">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-gray-300">Health Points</span>
                        <span className="text-white font-bold">{hero.hp}/{hero.maxHp}</span>
                      </div>
                      <Progress value={(hero.hp / hero.maxHp) * 100} className="h-2" />
                    </div>
                    <div className="bg-black/30 rounded p-3">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-gray-300">Mana Points</span>
                        <span className="text-white font-bold">{hero.mp}/{hero.maxMp}</span>
                      </div>
                      <Progress value={(hero.mp / hero.maxMp) * 100} className="h-2" />
                    </div>
                    <div className="bg-black/30 rounded p-3">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-gray-300">Experience</span>
                        <span className="text-white font-bold">{hero.xp}/{hero.xpToNextLevel}</span>
                      </div>
                      <Progress value={(hero.xp / hero.xpToNextLevel) * 100} className="h-2" />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    <Shield className="w-5 h-5" />
                    Attributes
                  </h3>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-red-900/40 rounded p-3 border border-red-500/30">
                      <div className="text-xs text-gray-400 mb-1">Attack</div>
                      <div className="text-2xl text-red-400 font-bold">{hero.attack}</div>
                    </div>
                    <div className="bg-blue-900/40 rounded p-3 border border-blue-500/30">
                      <div className="text-xs text-gray-400 mb-1">Defense</div>
                      <div className="text-2xl text-blue-400 font-bold">{hero.defense}</div>
                    </div>
                    <div className="bg-purple-900/40 rounded p-3 border border-purple-500/30">
                      <div className="text-xs text-gray-400 mb-1">Magic</div>
                      <div className="text-2xl text-purple-400 font-bold">{hero.magic}</div>
                    </div>
                    <div className="bg-green-900/40 rounded p-3 border border-green-500/30">
                      <div className="text-xs text-gray-400 mb-1">Speed</div>
                      <div className="text-2xl text-green-400 font-bold">{hero.speed}</div>
                    </div>
                  </div>
                  <div className="bg-yellow-900/40 rounded p-4 border border-yellow-500/30">
                    <div className="text-sm text-gray-300 mb-1">Gold</div>
                    <div className="text-3xl text-yellow-400 font-bold">{hero.gold} 💰</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="bg-gray-900/90 border-2 border-gray-700 mb-6">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-yellow-400" />
                Equipment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-black/30 rounded p-4 border border-gray-600">
                  <div className="text-sm text-gray-400 mb-2">Weapon</div>
                  {hero.equippedItems.weapon ? (
                    <div>
                      <div className="text-white font-bold">{hero.equippedItems.weapon.name}</div>
                      <Badge variant="secondary" className="mt-2">
                        {hero.equippedItems.weapon.rarity}
                      </Badge>
                    </div>
                  ) : (
                    <div className="text-gray-500">None equipped</div>
                  )}
                </div>
                <div className="bg-black/30 rounded p-4 border border-gray-600">
                  <div className="text-sm text-gray-400 mb-2">Armor</div>
                  {hero.equippedItems.armor ? (
                    <div>
                      <div className="text-white font-bold">{hero.equippedItems.armor.name}</div>
                      <Badge variant="secondary" className="mt-2">
                        {hero.equippedItems.armor.rarity}
                      </Badge>
                    </div>
                  ) : (
                    <div className="text-gray-500">None equipped</div>
                  )}
                </div>
                <div className="bg-black/30 rounded p-4 border border-gray-600">
                  <div className="text-sm text-gray-400 mb-2">Accessory</div>
                  {hero.equippedItems.accessory ? (
                    <div>
                      <div className="text-white font-bold">{hero.equippedItems.accessory.name}</div>
                      <Badge variant="secondary" className="mt-2">
                        {hero.equippedItems.accessory.rarity}
                      </Badge>
                    </div>
                  ) : (
                    <div className="text-gray-500">None equipped</div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="bg-gray-900/90 border-2 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Award className="w-6 h-6 text-yellow-400" />
                Achievements
                <Badge variant="secondary" className="ml-2">
                  {unlockedAchievements.length}/{achievements.length}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {achievements.map((achievement) => (
                  <motion.div
                    key={achievement.id}
                    whileHover={{ scale: achievement.unlocked ? 1.05 : 1 }}
                    className={`bg-black/30 rounded p-4 border ${
                      achievement.unlocked
                        ? 'border-yellow-500/50'
                        : 'border-gray-600 opacity-50'
                    }`}
                  >
                    <div className="text-3xl mb-2 text-center">
                      {achievement.unlocked ? achievement.icon : '🔒'}
                    </div>
                    <div className="text-sm text-white font-bold text-center mb-1">
                      {achievement.name}
                    </div>
                    <div className="text-xs text-gray-400 text-center">
                      {achievement.description}
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
