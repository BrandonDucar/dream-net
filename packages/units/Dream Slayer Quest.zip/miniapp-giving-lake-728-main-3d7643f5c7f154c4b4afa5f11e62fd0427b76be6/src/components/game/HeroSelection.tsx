'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { HeroClass } from '@/types/game';
import { Sword, Wand2, Eye, Shield } from 'lucide-react';
import { SkinSelector } from './SkinSelector';

interface HeroSelectionProps {
  onSelectHero: (heroClass: HeroClass, skinId?: string) => void;
  region: string;
}

const heroClasses: Array<{
  class: HeroClass;
  name: string;
  description: string;
  icon: typeof Sword;
  stats: string[];
  color: string;
}> = [
  {
    class: 'warrior',
    name: 'Warrior',
    description: 'Master of melee combat with unmatched strength and endurance.',
    icon: Sword,
    stats: ['High HP', 'High Attack', 'Moderate Defense'],
    color: 'from-red-600 to-orange-600'
  },
  {
    class: 'mage',
    name: 'Mage',
    description: 'Wielder of arcane magic, devastating foes from afar.',
    icon: Wand2,
    stats: ['High Magic', 'High MP', 'Low Defense'],
    color: 'from-blue-600 to-purple-600'
  },
  {
    class: 'rogue',
    name: 'Rogue',
    description: 'Swift assassin with deadly precision and stealth.',
    icon: Eye,
    stats: ['High Speed', 'Critical Hits', 'Moderate Attack'],
    color: 'from-gray-700 to-slate-600'
  },
  {
    class: 'paladin',
    name: 'Paladin',
    description: 'Holy warrior with balanced abilities and healing powers.',
    icon: Shield,
    stats: ['Balanced Stats', 'Healing', 'Holy Magic'],
    color: 'from-yellow-500 to-amber-600'
  }
];

export function HeroSelection({ onSelectHero, region }: HeroSelectionProps): JSX.Element {
  const [selectedClass, setSelectedClass] = useState<HeroClass | null>(null);
  const [selectedSkin, setSelectedSkin] = useState<string>('');

  const handleClassSelect = (heroClass: HeroClass): void => {
    setSelectedClass(heroClass);
    setSelectedSkin(`${heroClass}_default`);
  };

  const handleConfirm = (): void => {
    if (selectedClass) {
      onSelectHero(selectedClass, selectedSkin);
    }
  };

  if (selectedClass) {
    return (
      <div className="min-h-screen p-4 pt-16 pb-24">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-3xl font-bold text-white">
                Customize Your {selectedClass.charAt(0).toUpperCase() + selectedClass.slice(1)}
              </h2>
              <Button
                onClick={(): void => setSelectedClass(null)}
                variant="outline"
              >
                Back to Classes
              </Button>
            </div>
            
            <SkinSelector
              heroClass={selectedClass}
              selectedSkinId={selectedSkin}
              onSelectSkin={setSelectedSkin}
            />

            <div className="mt-8 text-center">
              <Button
                onClick={handleConfirm}
                size="lg"
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-12 py-6 text-xl"
              >
                Begin Adventure
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 pt-16">
      <div className="max-w-6xl w-full">
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold text-white mb-4">Choose Your Hero</h1>
          <p className="text-xl text-gray-300">
            Select your class and begin your legendary journey
          </p>
          {region !== 'unknown' && (
            <Badge variant="outline" className="mt-4 text-lg px-4 py-2">
              Starting Region: {region.replace(/_/g, ' ').toUpperCase()}
            </Badge>
          )}
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {heroClasses.map((hero, index) => {
            const Icon = hero.icon;
            return (
              <motion.div
                key={hero.class}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1, duration: 0.3 }}
                whileHover={{ scale: 1.05 }}
              >
                <Card className="bg-gray-900/80 border-2 border-gray-700 hover:border-purple-500 transition-all h-full">
                  <CardHeader>
                    <div className={`w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br ${hero.color} flex items-center justify-center`}>
                      <Icon className="w-10 h-10 text-white" />
                    </div>
                    <CardTitle className="text-2xl text-white text-center">
                      {hero.name}
                    </CardTitle>
                    <CardDescription className="text-gray-400 text-center">
                      {hero.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 mb-4">
                      {hero.stats.map((stat, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-purple-500 rounded-full" />
                          <span className="text-sm text-gray-300">{stat}</span>
                        </div>
                      ))}
                    </div>
                    <Button
                      onClick={(): void => handleClassSelect(hero.class)}
                      className={`w-full bg-gradient-to-r ${hero.color} hover:opacity-90 text-white`}
                    >
                      Choose {hero.name}
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
