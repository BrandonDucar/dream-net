'use client';

import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { Hero, Item } from '@/types/game';
import { X, Package, Sparkles } from 'lucide-react';

interface InventoryProps {
  hero: Hero;
  onEquipItem: (item: Item) => void;
  onClose: () => void;
}

export function Inventory({ hero, onEquipItem, onClose }: InventoryProps): JSX.Element {
  const getRarityColor = (rarity: string): string => {
    switch (rarity) {
      case 'common': return 'bg-gray-600';
      case 'uncommon': return 'bg-green-600';
      case 'rare': return 'bg-blue-600';
      case 'epic': return 'bg-purple-600';
      case 'legendary': return 'bg-orange-600';
      default: return 'bg-gray-600';
    }
  };

  const getRarityBorder = (rarity: string): string => {
    switch (rarity) {
      case 'common': return 'border-gray-500';
      case 'uncommon': return 'border-green-500';
      case 'rare': return 'border-blue-500';
      case 'epic': return 'border-purple-500';
      case 'legendary': return 'border-orange-500';
      default: return 'border-gray-500';
    }
  };

  const groupedItems: Record<string, Item[]> = {
    weapon: hero.inventory.filter(i => i.type === 'weapon'),
    armor: hero.inventory.filter(i => i.type === 'armor'),
    accessory: hero.inventory.filter(i => i.type === 'accessory'),
    consumable: hero.inventory.filter(i => i.type === 'consumable'),
    rune: hero.inventory.filter(i => i.type === 'rune')
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-indigo-900 to-black p-4 pt-16">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-between items-center mb-6"
        >
          <h1 className="text-4xl font-bold text-white flex items-center gap-3">
            <Package className="w-10 h-10 text-purple-400" />
            Inventory
          </h1>
          <Button onClick={onClose} variant="ghost" size="icon">
            <X className="w-6 h-6" />
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mb-6"
        >
          <Card className="bg-gradient-to-br from-gray-900/90 to-black/90 border-2 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">
                Total Items: {hero.inventory.length}
              </CardTitle>
            </CardHeader>
          </Card>
        </motion.div>

        {Object.entries(groupedItems).map(([type, items], categoryIndex) => (
          items.length > 0 && (
            <motion.div
              key={type}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: categoryIndex * 0.1 }}
              className="mb-8"
            >
              <h2 className="text-2xl font-bold text-white mb-4 capitalize flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-yellow-400" />
                {type}s
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {items.map((item, itemIndex) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: itemIndex * 0.05 }}
                    whileHover={{ scale: 1.02 }}
                  >
                    <Card className={`bg-gray-900/80 border-2 ${getRarityBorder(item.rarity)} h-full`}>
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg text-white">{item.name}</CardTitle>
                          <Badge className={getRarityColor(item.rarity)}>
                            {item.rarity}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-400 mb-4">{item.description}</p>
                        <div className="space-y-2 mb-4">
                          {item.stats.attack && item.stats.attack > 0 && (
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-400">Attack:</span>
                              <span className="text-red-400 font-bold">+{item.stats.attack}</span>
                            </div>
                          )}
                          {item.stats.defense && item.stats.defense > 0 && (
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-400">Defense:</span>
                              <span className="text-blue-400 font-bold">+{item.stats.defense}</span>
                            </div>
                          )}
                          {item.stats.magic && item.stats.magic > 0 && (
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-400">Magic:</span>
                              <span className="text-purple-400 font-bold">+{item.stats.magic}</span>
                            </div>
                          )}
                          {item.stats.hp && item.stats.hp > 0 && (
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-400">HP:</span>
                              <span className="text-green-400 font-bold">+{item.stats.hp}</span>
                            </div>
                          )}
                          {item.stats.mp && item.stats.mp > 0 && (
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-400">MP:</span>
                              <span className="text-cyan-400 font-bold">+{item.stats.mp}</span>
                            </div>
                          )}
                        </div>
                        <div className="flex gap-2">
                          {(item.type === 'weapon' || item.type === 'armor' || item.type === 'accessory') && (
                            <Button
                              onClick={() => onEquipItem(item)}
                              className="flex-1"
                              variant={item.equipped ? 'secondary' : 'default'}
                              disabled={item.equipped}
                            >
                              {item.equipped ? 'Equipped' : 'Equip'}
                            </Button>
                          )}
                          <div className="text-xs text-gray-500 flex items-center">
                            {item.value} 💰
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )
        ))}

        {hero.inventory.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <Card className="bg-gray-900/80 border-2 border-gray-700">
              <CardContent className="p-12 text-center">
                <Package className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <p className="text-xl text-gray-400">Your inventory is empty</p>
                <p className="text-sm text-gray-500 mt-2">Complete quests to earn loot!</p>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}
