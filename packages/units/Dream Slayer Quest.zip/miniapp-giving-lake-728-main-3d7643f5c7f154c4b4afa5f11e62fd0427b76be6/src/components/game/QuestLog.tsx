'use client';

import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import type { Quest } from '@/types/game';
import { X, Scroll, Swords, Crown, Coins, Star } from 'lucide-react';

interface QuestLogProps {
  quests: Quest[];
  currentQuest: Quest | null;
  onStartQuest: (quest: Quest) => void;
  onClose: () => void;
}

export function QuestLog({ quests, currentQuest, onStartQuest, onClose }: QuestLogProps): JSX.Element {
  const availableQuests = quests.filter(q => !q.completed && !q.active);
  const completedQuests = quests.filter(q => q.completed);

  const getDifficultyColor = (difficulty: string): string => {
    switch (difficulty) {
      case 'easy': return 'bg-green-600';
      case 'medium': return 'bg-yellow-600';
      case 'hard': return 'bg-orange-600';
      case 'boss': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-indigo-900 to-black p-4 pt-16">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-between items-center mb-6"
        >
          <h1 className="text-4xl font-bold text-white flex items-center gap-3">
            <Scroll className="w-10 h-10 text-yellow-400" />
            Quest Log
          </h1>
          <Button onClick={onClose} variant="ghost" size="icon">
            <X className="w-6 h-6" />
          </Button>
        </motion.div>

        {currentQuest && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mb-8"
          >
            <Card className="bg-gradient-to-br from-orange-900/90 to-red-900/90 border-2 border-orange-500">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-2xl text-white flex items-center gap-2">
                      <Swords className="w-6 h-6" />
                      {currentQuest.title}
                    </CardTitle>
                    <CardDescription className="text-gray-200">
                      Active Quest
                    </CardDescription>
                  </div>
                  <Badge className={getDifficultyColor(currentQuest.difficulty)}>
                    {currentQuest.difficulty.toUpperCase()}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {currentQuest.story.map((line, i) => (
                    <p key={i} className="text-gray-200 italic">
                      {line}
                    </p>
                  ))}
                  <Separator className="bg-gray-700" />
                  <div className="flex items-center gap-6 text-sm">
                    <div className="flex items-center gap-2">
                      <Star className="w-4 h-4 text-yellow-400" />
                      <span className="text-gray-300">+{currentQuest.rewards.xp} XP</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Coins className="w-4 h-4 text-yellow-400" />
                      <span className="text-gray-300">+{currentQuest.rewards.gold} Gold</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <h2 className="text-2xl font-bold text-white mb-4">Available Quests</h2>
          {availableQuests.length === 0 ? (
            <Card className="bg-gray-900/80 border-2 border-gray-700">
              <CardContent className="p-8 text-center">
                <p className="text-gray-400">No available quests at the moment. Complete your current quest or explore new regions!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {availableQuests.map((quest, index) => (
                <motion.div
                  key={quest.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="bg-gray-900/80 border-2 border-gray-700 hover:border-purple-500 transition-all h-full">
                    <CardHeader>
                      <div className="flex justify-between items-start mb-2">
                        <CardTitle className="text-xl text-white">{quest.title}</CardTitle>
                        <Badge className={getDifficultyColor(quest.difficulty)}>
                          {quest.difficulty}
                        </Badge>
                      </div>
                      {quest.difficulty === 'boss' && (
                        <Badge variant="destructive" className="w-fit">
                          <Crown className="w-3 h-3 mr-1" />
                          BOSS QUEST
                        </Badge>
                      )}
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <p className="text-gray-300 text-sm line-clamp-2">
                          {quest.story[0]}
                        </p>
                        <div className="flex items-center gap-2 text-sm">
                          <Badge variant="outline">Level {quest.enemy.level}</Badge>
                          <Badge variant="outline">{quest.region}</Badge>
                        </div>
                        <Separator className="bg-gray-700" />
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-4">
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4 text-yellow-400" />
                              <span className="text-gray-300">+{quest.rewards.xp}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Coins className="w-4 h-4 text-yellow-400" />
                              <span className="text-gray-300">+{quest.rewards.gold}</span>
                            </div>
                          </div>
                        </div>
                        <Button
                          onClick={() => onStartQuest(quest)}
                          className="w-full"
                          variant={quest.difficulty === 'boss' ? 'destructive' : 'default'}
                        >
                          Start Quest
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>

        {completedQuests.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <h2 className="text-2xl font-bold text-white mb-4">Completed Quests</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {completedQuests.map((quest, index) => (
                <motion.div
                  key={quest.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Card className="bg-gray-900/60 border border-gray-700 opacity-75">
                    <CardHeader>
                      <CardTitle className="text-lg text-white flex items-center gap-2">
                        {quest.title}
                        <Badge variant="secondary" className="ml-auto">✓</Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center gap-2 text-sm">
                        <Badge className={getDifficultyColor(quest.difficulty)} variant="secondary">
                          {quest.difficulty}
                        </Badge>
                        <span className="text-gray-400">Level {quest.enemy.level}</span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
