'use client';

import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { Region } from '@/types/game';
import { X, Map, Lock, Check, Crown } from 'lucide-react';

interface RegionMapProps {
  regions: Region[];
  currentRegion: string;
  onSelectRegion: (regionId: string) => void;
  onClose: () => void;
}

export function RegionMap({ regions, currentRegion, onSelectRegion, onClose }: RegionMapProps): JSX.Element {
  const unlockedRegions = regions.filter(r => r.unlocked);
  const lockedRegions = regions.filter(r => !r.unlocked);

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-indigo-900 to-black p-4 pt-16">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-between items-center mb-6"
        >
          <h1 className="text-4xl font-bold text-white flex items-center gap-3">
            <Map className="w-10 h-10 text-yellow-400" />
            World Map
          </h1>
          <Button onClick={onClose} variant="ghost" size="icon">
            <X className="w-6 h-6" />
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mb-8"
        >
          <Card className="bg-gradient-to-br from-gray-900/90 to-black/90 border-2 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">
                Regions Unlocked: {unlockedRegions.length}/{regions.length}
              </CardTitle>
              <CardDescription className="text-gray-400">
                Explore new regions to discover powerful enemies and legendary loot
              </CardDescription>
            </CardHeader>
          </Card>
        </motion.div>

        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-4">Available Regions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {unlockedRegions.map((region, index) => {
              const isCurrent = region.id === currentRegion;
              
              return (
                <motion.div
                  key={region.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                >
                  <Card
                    className={`${region.isPremium ? 'bg-gradient-to-br from-purple-900/80 to-pink-900/80' : 'bg-gradient-to-br from-green-900/80 to-emerald-900/80'} border-2 ${
                      isCurrent ? 'border-yellow-500 shadow-lg shadow-yellow-500/50' : region.isPremium ? 'border-purple-500' : 'border-green-500'
                    } cursor-pointer h-full`}
                    onClick={() => onSelectRegion(region.id)}
                  >
                    <CardHeader>
                      <div className="flex justify-between items-start flex-wrap gap-2">
                        <CardTitle className="text-xl text-white flex items-center gap-2">
                          {region.name}
                          {region.isPremium && <Crown className="w-5 h-5 text-yellow-400" />}
                        </CardTitle>
                        {isCurrent && (
                          <Badge className="bg-yellow-600">Current</Badge>
                        )}
                        {region.completed && (
                          <Badge className="bg-green-600">
                            <Check className="w-3 h-3 mr-1" />
                            Complete
                          </Badge>
                        )}
                        {region.isPremium && (
                          <Badge className="bg-purple-600">
                            <Crown className="w-3 h-3 mr-1" />
                            Premium
                          </Badge>
                        )}
                      </div>
                      <CardDescription className="text-gray-200">
                        {region.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-300">Recommended Level:</span>
                          <Badge variant="outline">{region.level}+</Badge>
                        </div>
                        <div className="flex items-center gap-2">
                          <Crown className="w-4 h-4 text-yellow-400" />
                          <span className="text-sm text-gray-300">Boss: {region.boss}</span>
                        </div>
                        <Button
                          onClick={() => onSelectRegion(region.id)}
                          className="w-full"
                          variant={isCurrent ? 'secondary' : 'default'}
                        >
                          {isCurrent ? 'Current Region' : 'Travel Here'}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>

        {lockedRegions.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <h2 className="text-2xl font-bold text-white mb-4">Locked Regions</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {lockedRegions.map((region, index) => (
                <motion.div
                  key={region.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="bg-gray-900/60 border-2 border-gray-700 opacity-75 h-full">
                    <CardHeader>
                      <CardTitle className="text-xl text-white flex items-center gap-2">
                        <Lock className="w-5 h-5 text-gray-500" />
                        {region.name}
                      </CardTitle>
                      <CardDescription className="text-gray-400">
                        {region.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-400">Required Level:</span>
                          <Badge variant="outline" className="border-gray-600">
                            {region.level}+
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2">
                          <Crown className="w-4 h-4 text-gray-500" />
                          <span className="text-sm text-gray-400">Boss: ???</span>
                        </div>
                        <Button disabled className="w-full" variant="outline">
                          <Lock className="w-4 h-4 mr-2" />
                          Locked
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-8"
        >
          <Card className="bg-gradient-to-r from-purple-900/50 to-blue-900/50 border border-purple-500/50">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <Map className="w-12 h-12 text-yellow-400" />
                <div>
                  <h3 className="text-lg font-bold text-white mb-1">Exploration Tips</h3>
                  <p className="text-sm text-gray-300">
                    Each region contains unique enemies, quests, and legendary loot. Higher level regions offer greater rewards
                    but pose significant challenges. Level up and gather powerful equipment before venturing into dangerous territories!
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
