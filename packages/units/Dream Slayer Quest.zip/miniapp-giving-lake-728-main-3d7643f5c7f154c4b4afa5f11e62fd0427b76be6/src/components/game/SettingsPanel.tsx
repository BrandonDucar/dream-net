'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { motion } from 'framer-motion';
import { Sparkles, Lock, Unlock, Info, Crown } from 'lucide-react';

interface SettingsPanelProps {
  onClose: () => void;
}

export function SettingsPanel({ onClose }: SettingsPanelProps): JSX.Element {
  const [apiKey, setApiKey] = useState<string>('');
  const [savedKey, setSavedKey] = useState<string>('');
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [verificationStatus, setVerificationStatus] = useState<'idle' | 'success' | 'error'>('idle');

  useEffect(() => {
    const stored = localStorage.getItem('dreamHeroApiKey');
    if (stored) {
      setSavedKey(stored);
      setApiKey('••••••••' + stored.slice(-4));
    }
  }, []);

  const handleSave = async (): Promise<void> => {
    if (!apiKey || apiKey.includes('•')) return;
    
    setIsVerifying(true);
    setVerificationStatus('idle');

    try {
      const response = await fetch('/api/verify-openai-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey })
      });

      const data = await response.json();

      if (data.valid) {
        localStorage.setItem('dreamHeroApiKey', apiKey);
        setSavedKey(apiKey);
        setApiKey('••••••••' + apiKey.slice(-4));
        setVerificationStatus('success');
      } else {
        setVerificationStatus('error');
      }
    } catch (error) {
      setVerificationStatus('error');
    } finally {
      setIsVerifying(false);
    }
  };

  const handleRemove = (): void => {
    localStorage.removeItem('dreamHeroApiKey');
    setSavedKey('');
    setApiKey('');
    setVerificationStatus('idle');
  };

  const handleInputChange = (value: string): void => {
    setApiKey(value);
    setVerificationStatus('idle');
  };

  const premiumFeatures = [
    { name: 'AI-Generated Epic Storylines', description: 'Unique narrative adventures created by GPT-4' },
    { name: 'Exclusive Hero Skins', description: '10+ premium character appearances' },
    { name: 'Bonus Regions', description: 'Crystal Caverns & Shadow Realm' },
    { name: 'Legendary Items', description: 'Ultra-rare gear with unique abilities' },
    { name: 'Enhanced Quest Dialogue', description: 'Dynamic NPC conversations' },
    { name: 'Boss Lore Generation', description: 'Rich backstories for every boss' }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        onClick={(e: React.MouseEvent<HTMLDivElement>): void => e.stopPropagation()}
        className="w-full max-w-2xl max-h-[90vh] overflow-y-auto"
      >
        <Card className="border-2 border-purple-500/50 bg-gradient-to-br from-slate-900 to-purple-900/20">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 flex items-center gap-2">
                  <Crown className="w-8 h-8 text-yellow-400" />
                  Premium Features
                </CardTitle>
                <CardDescription className="text-slate-300 mt-2">
                  Unlock enhanced gameplay with your OpenAI API key
                </CardDescription>
              </div>
              <Button onClick={onClose} variant="ghost" className="text-white">
                Close
              </Button>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* API Key Input */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Label htmlFor="apiKey" className="text-white text-lg">OpenAI API Key</Label>
                {savedKey && (
                  <Badge variant="outline" className="bg-green-500/20 text-green-400 border-green-500">
                    <Unlock className="w-3 h-3 mr-1" />
                    Active
                  </Badge>
                )}
              </div>
              
              <Input
                id="apiKey"
                type="text"
                value={apiKey}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void => handleInputChange(e.target.value)}
                placeholder="sk-..."
                className="bg-slate-800/50 border-purple-500/30 text-white"
              />

              <div className="flex gap-2">
                <Button 
                  onClick={handleSave}
                  disabled={isVerifying || !apiKey || apiKey.includes('•')}
                  className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                >
                  {isVerifying ? 'Verifying...' : savedKey ? 'Update Key' : 'Save Key'}
                </Button>
                
                {savedKey && (
                  <Button 
                    onClick={handleRemove}
                    variant="outline"
                    className="border-red-500/50 text-red-400 hover:bg-red-500/10"
                  >
                    Remove Key
                  </Button>
                )}
              </div>

              {verificationStatus === 'success' && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-green-500/20 border border-green-500 rounded-lg p-3 text-green-400"
                >
                  ✓ API key verified successfully! Premium features unlocked.
                </motion.div>
              )}

              {verificationStatus === 'error' && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-red-500/20 border border-red-500 rounded-lg p-3 text-red-400"
                >
                  ✗ Invalid API key. Please check and try again.
                </motion.div>
              )}

              <div className="flex items-start gap-2 bg-blue-500/10 border border-blue-500/30 rounded-lg p-3">
                <Info className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-blue-300">
                  Your API key is stored locally in your browser and never sent to our servers. 
                  It's only used for direct requests to OpenAI's API.
                </p>
              </div>
            </div>

            <Separator className="bg-purple-500/30" />

            {/* Premium Features List */}
            <div>
              <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-yellow-400" />
                What You'll Unlock
              </h3>
              
              <div className="grid gap-3">
                {premiumFeatures.map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-lg p-4"
                  >
                    <div className="flex items-start gap-3">
                      {savedKey ? (
                        <Unlock className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                      ) : (
                        <Lock className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                      )}
                      <div>
                        <h4 className="font-bold text-white">{feature.name}</h4>
                        <p className="text-sm text-slate-400">{feature.description}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            <Separator className="bg-purple-500/30" />

            {/* How to Get API Key */}
            <div className="bg-slate-800/50 rounded-lg p-4 space-y-3">
              <h3 className="text-lg font-bold text-white">How to Get Your API Key</h3>
              <ol className="list-decimal list-inside space-y-2 text-slate-300 text-sm">
                <li>Visit <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:underline">platform.openai.com/api-keys</a></li>
                <li>Sign in or create an OpenAI account</li>
                <li>Click "Create new secret key"</li>
                <li>Copy the key and paste it above</li>
                <li>Start enjoying premium AI-powered features!</li>
              </ol>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
