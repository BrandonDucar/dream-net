'use client';

import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import type { Hero } from '@/types/game';
import { X, Sparkles, Lock, ArrowUp } from 'lucide-react';

interface SkillTreeProps {
  hero: Hero;
  onUpgradeSkill: (skillId: string) => void;
  onClose: () => void;
}

export function SkillTree({ hero, onUpgradeSkill, onClose }: SkillTreeProps): JSX.Element {
  const getSkillTypeColor = (type: string): string => {
    switch (type) {
      case 'attack': return 'bg-red-600';
      case 'defense': return 'bg-blue-600';
      case 'magic': return 'bg-purple-600';
      case 'passive': return 'bg-green-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-indigo-900 to-black p-4 pt-16">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-between items-center mb-6"
        >
          <h1 className="text-4xl font-bold text-white flex items-center gap-3">
            <Sparkles className="w-10 h-10 text-green-400" />
            Skill Tree
          </h1>
          <Button onClick={onClose} variant="ghost" size="icon">
            <X className="w-6 h-6" />
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mb-6"
        >
          <Card className="bg-gradient-to-br from-gray-900/90 to-black/90 border-2 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">
                Available Skills: {hero.skills.filter(s => s.unlocked).length}/{hero.skills.length}
              </CardTitle>
              <CardDescription className="text-gray-400">
                Upgrade your skills to increase their power
              </CardDescription>
            </CardHeader>
          </Card>
        </motion.div>

        <div className="space-y-4">
          {hero.skills.map((skill, index) => {
            const levelProgress = (skill.level / skill.maxLevel) * 100;
            const canUpgrade = skill.unlocked && skill.level < skill.maxLevel && hero.gold >= 100;

            return (
              <motion.div
                key={skill.id}
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card
                  className={`bg-gray-900/80 border-2 ${
                    skill.unlocked ? 'border-green-500/50' : 'border-gray-700'
                  } ${!skill.unlocked && 'opacity-60'}`}
                >
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <CardTitle className="text-xl text-white flex items-center gap-3">
                          {skill.unlocked ? (
                            <Sparkles className="w-6 h-6 text-yellow-400" />
                          ) : (
                            <Lock className="w-6 h-6 text-gray-500" />
                          )}
                          {skill.name}
                        </CardTitle>
                        <CardDescription className="mt-2 text-gray-300">
                          {skill.description}
                        </CardDescription>
                      </div>
                      <Badge className={getSkillTypeColor(skill.type)}>
                        {skill.type}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        <div className="bg-black/30 rounded p-3">
                          <div className="text-xs text-gray-400 mb-1">Level</div>
                          <div className="text-lg text-white font-bold">
                            {skill.level}/{skill.maxLevel}
                          </div>
                        </div>
                        {skill.damage && (
                          <div className="bg-black/30 rounded p-3">
                            <div className="text-xs text-gray-400 mb-1">Damage</div>
                            <div className="text-lg text-red-400 font-bold">{skill.damage}</div>
                          </div>
                        )}
                        <div className="bg-black/30 rounded p-3">
                          <div className="text-xs text-gray-400 mb-1">MP Cost</div>
                          <div className="text-lg text-blue-400 font-bold">{skill.mpCost}</div>
                        </div>
                        <div className="bg-black/30 rounded p-3">
                          <div className="text-xs text-gray-400 mb-1">Upgrade Cost</div>
                          <div className="text-lg text-yellow-400 font-bold">100 💰</div>
                        </div>
                      </div>

                      {skill.unlocked && (
                        <div>
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-sm text-gray-400">Skill Progress</span>
                            <span className="text-sm text-white">{skill.level}/{skill.maxLevel}</span>
                          </div>
                          <Progress value={levelProgress} className="h-3" />
                        </div>
                      )}

                      <div className="flex gap-2">
                        {skill.unlocked ? (
                          <>
                            <Button
                              onClick={() => onUpgradeSkill(skill.id)}
                              disabled={!canUpgrade}
                              className="flex-1"
                              variant={canUpgrade ? 'default' : 'secondary'}
                            >
                              {skill.level >= skill.maxLevel ? (
                                'Max Level'
                              ) : canUpgrade ? (
                                <>
                                  <ArrowUp className="w-4 h-4 mr-2" />
                                  Upgrade
                                </>
                              ) : (
                                'Not Enough Gold'
                              )}
                            </Button>
                          </>
                        ) : (
                          <Button disabled className="flex-1" variant="outline">
                            <Lock className="w-4 h-4 mr-2" />
                            Locked - Level {(index + 1) * 5} Required
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-8"
        >
          <Card className="bg-gradient-to-r from-purple-900/50 to-blue-900/50 border border-purple-500/50">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <Sparkles className="w-12 h-12 text-yellow-400" />
                <div>
                  <h3 className="text-lg font-bold text-white mb-1">Skill Tips</h3>
                  <p className="text-sm text-gray-300">
                    Upgrade skills to increase their effectiveness. Higher level skills deal more damage and have additional effects.
                    Unlock new skills by leveling up your hero!
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
