'use client';

import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import type { HeroClass } from '@/types/game';
import { getPremiumSkinsForClass, type HeroSkin } from '@/lib/game/premiumContent';
import { Crown, Lock } from 'lucide-react';

interface SkinSelectorProps {
  heroClass: HeroClass;
  selectedSkinId: string;
  onSelectSkin: (skinId: string) => void;
}

export function SkinSelector({ heroClass, selectedSkinId, onSelectSkin }: SkinSelectorProps): JSX.Element {
  const skins = getPremiumSkinsForClass(heroClass);

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-bold text-white flex items-center gap-2">
        <Crown className="w-5 h-5 text-yellow-400" />
        Choose Your Appearance
      </h3>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {skins.map((skin) => (
          <motion.div
            key={skin.id}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Card
              className={`cursor-pointer transition-all ${
                selectedSkinId === skin.id
                  ? 'border-2 border-purple-500 shadow-lg shadow-purple-500/50'
                  : 'border border-slate-600 hover:border-purple-400'
              } ${skin.isPremium ? 'bg-gradient-to-br from-purple-900/30 to-pink-900/30' : 'bg-slate-800/50'}`}
              onClick={(): void => onSelectSkin(skin.id)}
            >
              <div className="p-4 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold text-white flex items-center gap-2">
                      {skin.name}
                      {skin.isPremium && (
                        <Crown className="w-4 h-4 text-yellow-400" />
                      )}
                    </h4>
                    <p className="text-sm text-slate-400">{skin.description}</p>
                  </div>
                </div>

                <div className="flex gap-2 flex-wrap">
                  <div
                    className="w-8 h-8 rounded-full border-2 border-white/30"
                    style={{ background: skin.colorScheme.primary }}
                  />
                  <div
                    className="w-8 h-8 rounded-full border-2 border-white/30"
                    style={{ background: skin.colorScheme.secondary }}
                  />
                  <div
                    className="w-8 h-8 rounded-full border-2 border-white/30"
                    style={{ background: skin.colorScheme.accent }}
                  />
                </div>

                {skin.isPremium && (
                  <Badge variant="outline" className="bg-purple-500/20 text-purple-300 border-purple-500">
                    Premium
                  </Badge>
                )}

                {selectedSkinId === skin.id && (
                  <Badge variant="outline" className="bg-green-500/20 text-green-300 border-green-500">
                    Selected
                  </Badge>
                )}
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      {skins.some(s => s.isPremium) && skins.length > 1 && (
        <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3 text-sm text-blue-300">
          💎 Premium skins are available! Add your OpenAI API key in settings to unlock exclusive appearances.
        </div>
      )}
    </div>
  );
}
