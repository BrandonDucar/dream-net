import { useState, useCallback, useEffect } from 'react';
import type { Hero, GameState, Quest, Battle, Item, Region, ActiveScreen, HeroClass } from '@/types/game';
import { generateHero } from '@/lib/game/heroGenerator';
import { generateQuest } from '@/lib/game/questGenerator';
import { createBattle, processBattleTurn } from '@/lib/game/battleSystem';
import { initializeRegions } from '@/lib/game/regionData';
import { unlockAchievement } from '@/lib/game/achievementSystem';
import { calculateLevelUp } from '@/lib/game/levelSystem';

export function useGameLogic() {
  const [gameState, setGameState] = useState<GameState>({
    hero: null,
    quests: [],
    completedQuests: [],
    currentRegion: 'forest',
    regions: initializeRegions(),
    achievements: [],
    gameStartTime: Date.now(),
    totalPlayTime: 0
  });

  const [currentQuest, setCurrentQuest] = useState<Quest | null>(null);
  const [currentBattle, setCurrentBattle] = useState<Battle | null>(null);
  const [activeScreen, setActiveScreen] = useState<ActiveScreen>('main');
  const [isBattleProcessing, setIsBattleProcessing] = useState<boolean>(false);

  useEffect(() => {
    const savedGame = localStorage.getItem('dreamHeroSaveGame');
    if (savedGame) {
      try {
        const parsed = JSON.parse(savedGame);
        setGameState(parsed);
      } catch (error) {
        console.error('Failed to load saved game:', error);
      }
    }
  }, []);

  useEffect(() => {
    if (gameState.hero) {
      localStorage.setItem('dreamHeroSaveGame', JSON.stringify(gameState));
    }
  }, [gameState]);

  const selectHero = useCallback((heroClass: HeroClass, region: string, skinId?: string): void => {
    const hero = generateHero(heroClass, region);
    if (skinId) {
      hero.skinId = skinId;
    }
    const initialQuests = [
      generateQuest(hero.level, 'forest', 'easy'),
      generateQuest(hero.level, 'forest', 'medium')
    ];

    setGameState(prev => ({
      ...prev,
      hero,
      quests: initialQuests,
      achievements: unlockAchievement(prev.achievements, 'first_hero')
    }));
  }, []);

  const startQuest = useCallback((quest: Quest): void => {
    setCurrentQuest(quest);
    const battle = createBattle(quest.enemy);
    setCurrentBattle(battle);
    setActiveScreen('battle');

    setGameState(prev => ({
      ...prev,
      quests: prev.quests.map(q => 
        q.id === quest.id ? { ...q, active: true } : q
      )
    }));
  }, []);

  const performBattleAction = useCallback((action: 'attack' | 'skill' | 'defend' | 'item', skillId?: string): void => {
    if (!currentBattle || !gameState.hero || isBattleProcessing) return;

    setIsBattleProcessing(true);

    // Small delay to show player action animation
    setTimeout(() => {
      const result = processBattleTurn(currentBattle, gameState.hero!, action, skillId);
      
      // Update battle state with both player and enemy actions
      setCurrentBattle(result.updatedBattle);
      
      // Update hero HP and MP
      setGameState(prev => ({
        ...prev,
        hero: prev.hero ? { 
          ...prev.hero, 
          hp: result.updatedHeroHp,
          mp: result.updatedHeroMp
        } : null
      }));

      // Check for victory
      if (result.victory) {
        setTimeout(() => {
          completeQuest(currentQuest!);
          setIsBattleProcessing(false);
        }, 1500);
        return;
      }

      // Check for defeat
      if (result.defeat) {
        setTimeout(() => {
          handleDefeat();
          setIsBattleProcessing(false);
        }, 1500);
        return;
      }

      // Battle continues - enable player actions again
      setIsBattleProcessing(false);
    }, 300);
  }, [currentBattle, gameState.hero, currentQuest, isBattleProcessing]);

  const handleDefeat = useCallback((): void => {
    setGameState(prev => ({
      ...prev,
      hero: prev.hero ? { 
        ...prev.hero, 
        hp: Math.floor(prev.hero.maxHp * 0.5), // Restore 50% HP on defeat
        gold: Math.max(0, prev.hero.gold - Math.floor(prev.hero.gold * 0.1)) // Lose 10% gold
      } : null
    }));
    
    setActiveScreen('main');
    setCurrentBattle(null);
    setCurrentQuest(null);
  }, []);

  const completeQuest = useCallback((quest: Quest): void => {
    if (!gameState.hero) return;

    const xpGained = quest.rewards.xp;
    const goldGained = quest.rewards.gold;
    const newXp = gameState.hero.xp + xpGained;
    
    const levelUpResult = calculateLevelUp(gameState.hero, newXp);

    setGameState(prev => {
      const updatedHero: Hero = {
        ...prev.hero!,
        xp: levelUpResult.xp,
        level: levelUpResult.level,
        gold: prev.hero!.gold + goldGained,
        inventory: [...prev.hero!.inventory, ...quest.rewards.items],
        maxHp: levelUpResult.maxHp,
        maxMp: levelUpResult.maxMp,
        hp: levelUpResult.maxHp, // Restore HP on quest completion
        mp: levelUpResult.maxMp, // Restore MP on quest completion
        attack: levelUpResult.attack,
        defense: levelUpResult.defense,
        magic: levelUpResult.magic
      };

      const updatedQuests = prev.quests.map(q =>
        q.id === quest.id ? { ...q, completed: true, active: false } : q
      );

      const newQuest = generateQuest(updatedHero.level, prev.currentRegion, 'medium');
      
      return {
        ...prev,
        hero: updatedHero,
        quests: [...updatedQuests, newQuest],
        completedQuests: [...prev.completedQuests, quest.id],
        achievements: unlockAchievement(
          prev.achievements,
          quest.difficulty === 'boss' ? 'boss_slayer' : 'quest_complete'
        )
      };
    });

    setCurrentBattle(null);
    setCurrentQuest(null);
    setActiveScreen('main');
  }, [gameState.hero]);

  const levelUp = useCallback((): void => {
    setGameState(prev => {
      if (!prev.hero) return prev;
      
      const result = calculateLevelUp(prev.hero, prev.hero.xpToNextLevel);
      
      return {
        ...prev,
        hero: {
          ...prev.hero,
          level: result.level,
          maxHp: result.maxHp,
          maxMp: result.maxMp,
          attack: result.attack,
          defense: result.defense,
          magic: result.magic,
          xp: result.xp,
          xpToNextLevel: result.xpToNextLevel
        }
      };
    });
  }, []);

  const equipItem = useCallback((item: Item): void => {
    setGameState(prev => {
      if (!prev.hero) return prev;

      const updatedEquipped = { ...prev.hero.equippedItems };
      
      if (item.type === 'weapon') {
        updatedEquipped.weapon = item;
      } else if (item.type === 'armor') {
        updatedEquipped.armor = item;
      } else if (item.type === 'accessory') {
        updatedEquipped.accessory = item;
      }

      return {
        ...prev,
        hero: {
          ...prev.hero,
          equippedItems: updatedEquipped,
          attack: prev.hero.attack + (item.stats.attack || 0),
          defense: prev.hero.defense + (item.stats.defense || 0),
          magic: prev.hero.magic + (item.stats.magic || 0)
        }
      };
    });
  }, []);

  const upgradeSkill = useCallback((skillId: string): void => {
    setGameState(prev => {
      if (!prev.hero) return prev;

      const updatedSkills = prev.hero.skills.map(skill =>
        skill.id === skillId && skill.level < skill.maxLevel
          ? { ...skill, level: skill.level + 1, damage: (skill.damage || 0) + 10 }
          : skill
      );

      return {
        ...prev,
        hero: {
          ...prev.hero,
          skills: updatedSkills
        }
      };
    });
  }, []);

  const unlockRegion = useCallback((regionId: string): void => {
    setGameState(prev => {
      const updatedRegions = prev.regions.map(region =>
        region.id === regionId ? { ...region, unlocked: true } : region
      );

      return {
        ...prev,
        currentRegion: regionId,
        regions: updatedRegions
      };
    });
  }, []);

  return {
    gameState,
    currentQuest,
    currentBattle,
    activeScreen,
    setActiveScreen,
    selectHero,
    startQuest,
    performBattleAction,
    levelUp,
    equipItem,
    upgradeSkill,
    unlockRegion,
    completeQuest,
    isBattleProcessing
  };
}
