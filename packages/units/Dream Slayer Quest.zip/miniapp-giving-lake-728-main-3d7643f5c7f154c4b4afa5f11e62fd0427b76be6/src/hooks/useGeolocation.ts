import { useState, useEffect } from 'react';

interface GeolocationData {
  latitude: number | null;
  longitude: number | null;
  country: string | null;
  region: string | null;
  city: string | null;
}

export function useGeolocation() {
  const [location, setLocation] = useState<GeolocationData>({
    latitude: null,
    longitude: null,
    country: null,
    region: null,
    city: null
  });

  const [region, setRegion] = useState<string>('unknown');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position: GeolocationPosition) => {
          const { latitude, longitude } = position.coords;
          
          setLocation({
            latitude,
            longitude,
            country: null,
            region: null,
            city: null
          });

          const detectedRegion = determineFantasyRegion(latitude, longitude);
          setRegion(detectedRegion);
        },
        (err: GeolocationPositionError) => {
          setError(err.message);
          setRegion('unknown');
        },
        {
          enableHighAccuracy: false,
          timeout: 5000,
          maximumAge: 0
        }
      );
    } else {
      setError('Geolocation not supported');
      setRegion('unknown');
    }
  }, []);

  return {
    location,
    region,
    error
  };
}

function determineFantasyRegion(lat: number, lon: number): string {
  if (lat > 60) return 'northern_wastes';
  if (lat > 40) return 'mountain_peaks';
  if (lat > 20) return 'forest';
  if (lat > 0) return 'desert';
  if (lat > -20) return 'jungle';
  if (lat > -40) return 'swamp';
  return 'volcanic_islands';
}
