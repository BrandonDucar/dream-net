import { useCallback, useRef, useEffect } from 'react';

type SoundType = 'select' | 'attack' | 'hit' | 'victory' | 'defeat' | 'levelup' | 'ambient' | 'boss' | 'loot';

export function useSoundEffects() {
  const audioContextRef = useRef<AudioContext | null>(null);
  const soundsEnabledRef = useRef<boolean>(true);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      audioContextRef.current = new (window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext!)();
    }
    
    return () => {
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  const createOscillator = useCallback((frequency: number, duration: number, type: OscillatorType = 'sine'): void => {
    if (!audioContextRef.current || !soundsEnabledRef.current) return;

    const ctx = audioContextRef.current;
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);

    oscillator.type = type;
    oscillator.frequency.value = frequency;

    gainNode.gain.setValueAtTime(0.3, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration);

    oscillator.start(ctx.currentTime);
    oscillator.stop(ctx.currentTime + duration);
  }, []);

  const playSound = useCallback((sound: SoundType): void => {
    if (!soundsEnabledRef.current) return;

    switch (sound) {
      case 'select':
        createOscillator(523.25, 0.1, 'sine');
        break;
      case 'attack':
        createOscillator(200, 0.15, 'sawtooth');
        setTimeout(() => createOscillator(150, 0.1, 'sawtooth'), 50);
        break;
      case 'hit':
        createOscillator(100, 0.2, 'square');
        break;
      case 'victory':
        createOscillator(523.25, 0.2, 'sine');
        setTimeout(() => createOscillator(659.25, 0.2, 'sine'), 150);
        setTimeout(() => createOscillator(783.99, 0.3, 'sine'), 300);
        break;
      case 'defeat':
        createOscillator(200, 0.3, 'sawtooth');
        setTimeout(() => createOscillator(150, 0.3, 'sawtooth'), 200);
        setTimeout(() => createOscillator(100, 0.5, 'sawtooth'), 400);
        break;
      case 'levelup':
        createOscillator(523.25, 0.15, 'sine');
        setTimeout(() => createOscillator(659.25, 0.15, 'sine'), 100);
        setTimeout(() => createOscillator(783.99, 0.15, 'sine'), 200);
        setTimeout(() => createOscillator(1046.50, 0.3, 'sine'), 300);
        break;
      case 'loot':
        createOscillator(880, 0.1, 'sine');
        setTimeout(() => createOscillator(1046.50, 0.2, 'sine'), 100);
        break;
      case 'boss':
        createOscillator(55, 0.5, 'sawtooth');
        setTimeout(() => createOscillator(82.41, 0.5, 'sawtooth'), 250);
        break;
      case 'ambient':
        break;
    }
  }, [createOscillator]);

  const toggleSound = useCallback((): void => {
    soundsEnabledRef.current = !soundsEnabledRef.current;
  }, []);

  return {
    playSound,
    toggleSound,
    soundsEnabled: soundsEnabledRef.current
  };
}
