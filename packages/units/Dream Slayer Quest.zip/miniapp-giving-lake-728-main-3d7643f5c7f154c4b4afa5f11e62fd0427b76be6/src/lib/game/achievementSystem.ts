import type { Achievement } from '@/types/game';

const achievements: Record<string, Omit<Achievement, 'unlocked' | 'unlockedAt'>> = {
  first_hero: {
    id: 'first_hero',
    name: 'The Beginning',
    description: 'Created your first hero',
    icon: '⚔️'
  },
  quest_complete: {
    id: 'quest_complete',
    name: 'Quest Complete',
    description: 'Completed your first quest',
    icon: '✅'
  },
  boss_slayer: {
    id: 'boss_slayer',
    name: 'Boss Slayer',
    description: 'Defeated your first boss',
    icon: '👑'
  },
  legendary_item: {
    id: 'legendary_item',
    name: 'Legendary Find',
    description: 'Obtained a legendary item',
    icon: '💎'
  },
  level_10: {
    id: 'level_10',
    name: 'Rising Hero',
    description: 'Reached level 10',
    icon: '⭐'
  },
  level_25: {
    id: 'level_25',
    name: 'Master Adventurer',
    description: 'Reached level 25',
    icon: '🌟'
  },
  all_regions: {
    id: 'all_regions',
    name: 'World Explorer',
    description: 'Unlocked all regions',
    icon: '🗺️'
  },
  dragon_slayer: {
    id: 'dragon_slayer',
    name: 'Dragon Slayer',
    description: 'Defeated 5 dragons',
    icon: '🐉'
  },
  rich_hero: {
    id: 'rich_hero',
    name: 'Wealthy Adventurer',
    description: 'Accumulated 10,000 gold',
    icon: '💰'
  },
  skill_master: {
    id: 'skill_master',
    name: 'Skill Master',
    description: 'Maxed out all skills',
    icon: '📜'
  }
};

export function unlockAchievement(
  currentAchievements: Achievement[],
  achievementId: string
): Achievement[] {
  const existing = currentAchievements.find(a => a.id === achievementId);
  if (existing && existing.unlocked) {
    return currentAchievements;
  }

  const achievement = achievements[achievementId];
  if (!achievement) {
    return currentAchievements;
  }

  const newAchievement: Achievement = {
    ...achievement,
    unlocked: true,
    unlockedAt: Date.now()
  };

  if (existing) {
    return currentAchievements.map(a =>
      a.id === achievementId ? newAchievement : a
    );
  }

  return [...currentAchievements, newAchievement];
}

export function initializeAchievements(): Achievement[] {
  return Object.values(achievements).map(a => ({
    ...a,
    unlocked: false
  }));
}
