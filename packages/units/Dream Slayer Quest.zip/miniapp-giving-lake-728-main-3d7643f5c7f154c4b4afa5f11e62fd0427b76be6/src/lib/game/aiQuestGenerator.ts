import type { Quest, Enemy } from '@/types/game';
import { generateEnemy } from './enemyGenerator';
import { generateLoot } from './lootGenerator';
import { generateQuest } from './questGenerator';

interface AiQuestData {
  title: string;
  story: string[];
  enemyName: string;
  enemyDescription: string;
  questHook: string;
  battleDialogue: string[];
}

export async function generateAiQuest(
  heroLevel: number,
  heroClass: string,
  region: string,
  difficulty: 'easy' | 'medium' | 'hard' | 'boss'
): Promise<Quest> {
  const apiKey = typeof window !== 'undefined' ? localStorage.getItem('dreamHeroApiKey') : null;

  if (!apiKey) {
    return generateQuest(heroLevel, region as keyof typeof import('./questGenerator'), difficulty);
  }

  try {
    const response = await fetch('/api/generate-ai-quest', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        apiKey,
        heroLevel,
        heroClass,
        region,
        difficulty
      })
    });

    if (!response.ok) {
      throw new Error('AI quest generation failed');
    }

    const data = await response.json();
    
    if (!data.success || !data.quest) {
      throw new Error('Invalid AI response');
    }

    const aiQuest: AiQuestData = data.quest;
    
    const enemy: Enemy = {
      ...generateEnemy(heroLevel, difficulty, region),
      name: aiQuest.enemyName || generateEnemy(heroLevel, difficulty, region).name
    };

    const baseXp = difficulty === 'easy' ? 50 : difficulty === 'medium' ? 150 : difficulty === 'hard' ? 300 : 500;
    const baseGold = difficulty === 'easy' ? 25 : difficulty === 'medium' ? 75 : difficulty === 'hard' ? 150 : 300;

    const loot = generateLoot(difficulty, heroLevel);

    const quest: Quest = {
      id: `ai_quest_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      title: aiQuest.title,
      description: aiQuest.questHook || `Level ${heroLevel} AI-generated ${difficulty} quest`,
      story: aiQuest.story,
      region,
      difficulty,
      rewards: {
        xp: baseXp * heroLevel * 1.5,
        gold: Math.floor((baseGold + Math.random() * 50) * 1.3),
        items: loot
      },
      completed: false,
      active: false,
      enemy,
      isAiGenerated: true,
      questHook: aiQuest.questHook
    };

    return quest;
  } catch (error) {
    console.error('AI Quest generation failed, falling back to templates:', error);
    return generateQuest(heroLevel, region as keyof typeof import('./questGenerator'), difficulty);
  }
}
