import type { Battle, Enemy, Hero, BattleLogEntry } from '@/types/game';

export function createBattle(enemy: Enemy): Battle {
  return {
    id: `battle_${Date.now()}`,
    enemy: { ...enemy },
    turnCount: 0,
    playerTurn: true,
    battleLog: []
  };
}

export interface BattleTurnResult {
  updatedBattle: Battle;
  updatedHeroHp: number;
  updatedHeroMp: number;
  victory: boolean;
  defeat: boolean;
  playerAction: BattleLogEntry;
  enemyAction?: BattleLogEntry;
}

export function processBattleTurn(
  battle: Battle,
  hero: Hero,
  action: 'attack' | 'skill' | 'defend' | 'item',
  skillId?: string
): BattleTurnResult {
  const updatedBattle = { ...battle };
  let heroHp = hero.hp;
  let heroMp = hero.mp;
  let victory = false;
  let defeat = false;

  // Phase 1: Player Action
  let playerDamage = 0;
  let critical = false;
  let actionText = '';
  let defending = false;

  if (action === 'attack') {
    const criticalChance = Math.random();
    critical = criticalChance > 0.85;
    playerDamage = Math.max(1, hero.attack - Math.floor(battle.enemy.defense / 3));
    if (critical) {
      playerDamage = Math.floor(playerDamage * 2);
    }
    actionText = critical ? 'Critical Hit!' : 'Attack';
  } else if (action === 'skill' && skillId) {
    const skill = hero.skills.find(s => s.id === skillId && s.unlocked);
    if (skill && hero.mp >= skill.mpCost) {
      playerDamage = Math.max(1, (skill.damage || 0) + hero.magic - Math.floor(battle.enemy.defense / 2));
      heroMp = Math.max(0, heroMp - skill.mpCost);
      actionText = skill.name;
    } else {
      actionText = 'Not enough MP';
      playerDamage = 0;
    }
  } else if (action === 'defend') {
    actionText = 'Defend';
    playerDamage = 0;
    defending = true;
  }

  // Apply player damage to enemy
  updatedBattle.enemy.hp = Math.max(0, updatedBattle.enemy.hp - playerDamage);

  const playerLogEntry: BattleLogEntry = {
    turn: updatedBattle.turnCount,
    attacker: 'hero',
    action: actionText,
    damage: playerDamage,
    critical,
    timestamp: Date.now()
  };
  updatedBattle.battleLog = [...updatedBattle.battleLog, playerLogEntry];

  // Check for victory after player action
  if (updatedBattle.enemy.hp <= 0) {
    victory = true;
    updatedBattle.playerTurn = false;
    return {
      updatedBattle,
      updatedHeroHp: heroHp,
      updatedHeroMp: heroMp,
      victory,
      defeat: false,
      playerAction: playerLogEntry
    };
  }

  // Phase 2: Enemy Action (immediate, not setTimeout)
  const enemyActions = ['attack', 'attack', 'attack', 'special', 'defend'];
  const enemyActionType = enemyActions[Math.floor(Math.random() * enemyActions.length)];
  
  let enemyDamage = 0;
  let enemyActionText = '';

  if (enemyActionType === 'attack' || enemyActionType === 'special') {
    const baseEnemyDamage = Math.max(1, battle.enemy.attack - Math.floor(hero.defense / 2));
    
    if (enemyActionType === 'special' && battle.enemy.isBoss) {
      enemyDamage = Math.floor(baseEnemyDamage * 1.5);
      enemyActionText = 'Special Attack';
    } else {
      enemyDamage = baseEnemyDamage;
      enemyActionText = 'Attack';
    }

    // Reduce damage if player is defending
    if (defending) {
      enemyDamage = Math.floor(enemyDamage / 2);
    }

    heroHp = Math.max(0, heroHp - enemyDamage);
  } else {
    enemyActionText = 'Defend';
    enemyDamage = 0;
  }

  const enemyLogEntry: BattleLogEntry = {
    turn: updatedBattle.turnCount,
    attacker: 'enemy',
    action: enemyActionText,
    damage: enemyDamage,
    critical: false,
    timestamp: Date.now()
  };
  updatedBattle.battleLog = [...updatedBattle.battleLog, enemyLogEntry];

  // Check for defeat after enemy action
  if (heroHp <= 0) {
    defeat = true;
    updatedBattle.playerTurn = false;
  } else {
    // Battle continues - return control to player
    updatedBattle.playerTurn = true;
    updatedBattle.turnCount += 1;
  }

  return {
    updatedBattle,
    updatedHeroHp: heroHp,
    updatedHeroMp: heroMp,
    victory: false,
    defeat,
    playerAction: playerLogEntry,
    enemyAction: enemyLogEntry
  };
}
