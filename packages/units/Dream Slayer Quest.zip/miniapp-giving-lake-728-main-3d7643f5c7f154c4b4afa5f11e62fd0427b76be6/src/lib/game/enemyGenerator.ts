import type { Enemy, MonsterType } from '@/types/game';
import { generateLoot } from './lootGenerator';

const enemyTypes: Record<MonsterType, { names: string[]; isBoss: boolean }> = {
  goblin: { names: ['Goblin Raider', 'Goblin Shaman', 'Goblin Warlord'], isBoss: false },
  orc: { names: ['Orc Berserker', 'Orc Chieftain', 'Orc Warlord'], isBoss: false },
  dragon: { names: ['Young Dragon', 'Ancient Dragon', 'Elder Dragon'], isBoss: true },
  demon: { names: ['Lesser Demon', 'Demon Lord', 'Archfiend'], isBoss: true },
  undead: { names: ['Skeleton Warrior', 'Lich', 'Death Knight'], isBoss: false },
  beast: { names: ['Dire Wolf', 'Frost Bear', 'Chimera'], isBoss: false }
};

export function generateEnemy(
  heroLevel: number,
  difficulty: 'easy' | 'medium' | 'hard' | 'boss',
  region: string
): Enemy {
  const type = selectEnemyType(difficulty, region);
  const enemyData = enemyTypes[type];
  const name = enemyData.names[Math.floor(Math.random() * enemyData.names.length)];
  
  const isBoss = difficulty === 'boss';
  const level = heroLevel + (difficulty === 'easy' ? 0 : difficulty === 'medium' ? 2 : difficulty === 'hard' ? 4 : 6);
  
  const baseHp = isBoss ? 200 : difficulty === 'easy' ? 60 : difficulty === 'medium' ? 100 : 150;
  const maxHp = baseHp + (level * 15);
  
  const baseAttack = isBoss ? 30 : difficulty === 'easy' ? 15 : difficulty === 'medium' ? 20 : 25;
  const attack = baseAttack + (level * 2);
  
  const defense = 10 + (level * 1.5);
  const magic = 5 + (level * 1);
  
  const lootTable = generateLoot(difficulty, level);
  
  return {
    id: `enemy_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    name,
    type,
    level,
    hp: maxHp,
    maxHp,
    attack,
    defense,
    magic,
    isBoss,
    lootTable,
    xpReward: (difficulty === 'easy' ? 50 : difficulty === 'medium' ? 150 : difficulty === 'hard' ? 300 : 500) * level,
    goldReward: (difficulty === 'easy' ? 20 : difficulty === 'medium' ? 60 : difficulty === 'hard' ? 120 : 250) + Math.floor(Math.random() * 50)
  };
}

function selectEnemyType(difficulty: string, region: string): MonsterType {
  if (difficulty === 'boss') {
    return Math.random() > 0.5 ? 'dragon' : 'demon';
  }
  
  const regionTypes: Record<string, MonsterType[]> = {
    forest: ['goblin', 'beast', 'undead'],
    mountain_peaks: ['orc', 'dragon', 'beast'],
    desert: ['undead', 'demon', 'beast'],
    default: ['goblin', 'orc', 'beast']
  };
  
  const types = regionTypes[region] || regionTypes.default;
  return types[Math.floor(Math.random() * types.length)];
}
