import type { Hero, HeroClass, Skill } from '@/types/game';

const heroNames: Record<HeroClass, string[]> = {
  warrior: ['Thorin', 'Ragnar', 'Grom', 'Valkyr', 'Draven'],
  mage: ['Gandor', 'Merlyn', 'Azura', 'Theron', 'Celestia'],
  rogue: ['Shadow', 'Raven', 'Nyx', 'Vex', 'Whisper'],
  paladin: ['Arthur', 'Galahad', 'Seraphina', 'Lightbringer', 'Divine']
};

const heroSkills: Record<HeroClass, Omit<Skill, 'id'>[]> = {
  warrior: [
    { name: 'Power Strike', type: 'attack', level: 1, maxLevel: 5, description: 'A powerful melee attack', damage: 30, mpCost: 10, unlocked: true },
    { name: 'Shield Bash', type: 'attack', level: 1, maxLevel: 5, description: 'Stun enemy with shield', damage: 20, mpCost: 15, unlocked: true },
    { name: 'Berserker Rage', type: 'passive', level: 1, maxLevel: 5, description: 'Increase attack when low HP', mpCost: 0, unlocked: false }
  ],
  mage: [
    { name: 'Fireball', type: 'magic', level: 1, maxLevel: 5, description: 'Launch a ball of fire', damage: 40, mpCost: 20, unlocked: true },
    { name: 'Ice Shard', type: 'magic', level: 1, maxLevel: 5, description: 'Freeze and damage enemy', damage: 35, mpCost: 18, unlocked: true },
    { name: 'Arcane Shield', type: 'defense', level: 1, maxLevel: 5, description: 'Magical barrier', mpCost: 25, unlocked: false }
  ],
  rogue: [
    { name: 'Backstab', type: 'attack', level: 1, maxLevel: 5, description: 'Critical strike from shadows', damage: 50, mpCost: 15, unlocked: true },
    { name: 'Poison Blade', type: 'attack', level: 1, maxLevel: 5, description: 'Poison damage over time', damage: 25, mpCost: 12, unlocked: true },
    { name: 'Shadow Step', type: 'passive', level: 1, maxLevel: 5, description: 'Increase evasion', mpCost: 0, unlocked: false }
  ],
  paladin: [
    { name: 'Holy Strike', type: 'attack', level: 1, maxLevel: 5, description: 'Strike with holy power', damage: 35, mpCost: 18, unlocked: true },
    { name: 'Divine Heal', type: 'magic', level: 1, maxLevel: 5, description: 'Restore HP', damage: -30, mpCost: 20, unlocked: true },
    { name: 'Blessing', type: 'defense', level: 1, maxLevel: 5, description: 'Increase all stats', mpCost: 30, unlocked: false }
  ]
};

export function generateHero(heroClass: HeroClass, region: string): Hero {
  const names = heroNames[heroClass];
  const name = names[Math.floor(Math.random() * names.length)];
  
  const baseStats = getBaseStats(heroClass);
  const skills = heroSkills[heroClass].map((skill, index) => ({
    ...skill,
    id: `${heroClass}_skill_${index}`
  }));

  return {
    class: heroClass,
    name,
    level: 1,
    hp: baseStats.maxHp,
    maxHp: baseStats.maxHp,
    mp: baseStats.maxMp,
    maxMp: baseStats.maxMp,
    xp: 0,
    xpToNextLevel: 100,
    attack: baseStats.attack,
    defense: baseStats.defense,
    magic: baseStats.magic,
    speed: baseStats.speed,
    gold: 50,
    inventory: [],
    equippedItems: {},
    skills,
    runes: [],
    titles: ['Novice'],
    region
  };
}

function getBaseStats(heroClass: HeroClass): {
  maxHp: number;
  maxMp: number;
  attack: number;
  defense: number;
  magic: number;
  speed: number;
} {
  switch (heroClass) {
    case 'warrior':
      return { maxHp: 150, maxMp: 50, attack: 25, defense: 20, magic: 5, speed: 10 };
    case 'mage':
      return { maxHp: 80, maxMp: 120, attack: 10, defense: 8, magic: 35, speed: 12 };
    case 'rogue':
      return { maxHp: 100, maxMp: 70, attack: 20, defense: 12, magic: 10, speed: 25 };
    case 'paladin':
      return { maxHp: 130, maxMp: 80, attack: 18, defense: 18, magic: 20, speed: 8 };
  }
}
