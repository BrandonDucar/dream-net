import type { Hero } from '@/types/game';

export function calculateLevelUp(hero: Hero, newXp: number): {
  level: number;
  xp: number;
  xpToNextLevel: number;
  maxHp: number;
  maxMp: number;
  attack: number;
  defense: number;
  magic: number;
} {
  let level = hero.level;
  let xp = newXp;
  let xpToNextLevel = hero.xpToNextLevel;

  while (xp >= xpToNextLevel) {
    xp -= xpToNextLevel;
    level += 1;
    xpToNextLevel = calculateXpForNextLevel(level);
  }

  const stats = calculateStatsForLevel(hero, level);

  return {
    level,
    xp,
    xpToNextLevel,
    ...stats
  };
}

function calculateXpForNextLevel(level: number): number {
  return Math.floor(100 * Math.pow(1.5, level - 1));
}

function calculateStatsForLevel(hero: Hero, level: number): {
  maxHp: number;
  maxMp: number;
  attack: number;
  defense: number;
  magic: number;
} {
  const baseStats = getBaseStats(hero.class);
  
  const hpGrowth = hero.class === 'warrior' ? 15 : hero.class === 'paladin' ? 12 : hero.class === 'rogue' ? 10 : 8;
  const mpGrowth = hero.class === 'mage' ? 12 : hero.class === 'paladin' ? 8 : hero.class === 'rogue' ? 6 : 4;
  const attackGrowth = hero.class === 'warrior' ? 3 : hero.class === 'rogue' ? 2.5 : hero.class === 'paladin' ? 2 : 1;
  const defenseGrowth = hero.class === 'warrior' ? 2.5 : hero.class === 'paladin' ? 2 : hero.class === 'rogue' ? 1.5 : 1;
  const magicGrowth = hero.class === 'mage' ? 4 : hero.class === 'paladin' ? 2.5 : hero.class === 'rogue' ? 1 : 0.5;

  return {
    maxHp: baseStats.maxHp + Math.floor(hpGrowth * (level - 1)),
    maxMp: baseStats.maxMp + Math.floor(mpGrowth * (level - 1)),
    attack: baseStats.attack + Math.floor(attackGrowth * (level - 1)),
    defense: baseStats.defense + Math.floor(defenseGrowth * (level - 1)),
    magic: baseStats.magic + Math.floor(magicGrowth * (level - 1))
  };
}

function getBaseStats(heroClass: string): {
  maxHp: number;
  maxMp: number;
  attack: number;
  defense: number;
  magic: number;
} {
  switch (heroClass) {
    case 'warrior':
      return { maxHp: 150, maxMp: 50, attack: 25, defense: 20, magic: 5 };
    case 'mage':
      return { maxHp: 80, maxMp: 120, attack: 10, defense: 8, magic: 35 };
    case 'rogue':
      return { maxHp: 100, maxMp: 70, attack: 20, defense: 12, magic: 10 };
    case 'paladin':
      return { maxHp: 130, maxMp: 80, attack: 18, defense: 18, magic: 20 };
    default:
      return { maxHp: 100, maxMp: 50, attack: 15, defense: 10, magic: 10 };
  }
}
