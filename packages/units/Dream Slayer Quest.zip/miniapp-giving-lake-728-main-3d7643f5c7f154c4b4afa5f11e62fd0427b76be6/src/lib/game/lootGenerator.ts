import type { Item, ItemRarity, ItemType } from '@/types/game';

const rarityChances: Record<string, Record<ItemRarity, number>> = {
  easy: { common: 0.7, uncommon: 0.25, rare: 0.05, epic: 0, legendary: 0 },
  medium: { common: 0.4, uncommon: 0.35, rare: 0.2, epic: 0.05, legendary: 0 },
  hard: { common: 0.2, uncommon: 0.3, rare: 0.35, epic: 0.13, legendary: 0.02 },
  boss: { common: 0.1, uncommon: 0.2, rare: 0.4, epic: 0.25, legendary: 0.05 }
};

const itemNames: Record<ItemType, Record<ItemRarity, string[]>> = {
  weapon: {
    common: ['Rusty Sword', 'Wooden Staff', 'Dull Dagger', 'Old Bow'],
    uncommon: ['Iron Sword', 'Oak Staff', 'Steel Dagger', 'Hunter Bow'],
    rare: ['Silver Blade', 'Crystal Staff', 'Venom Dagger', 'Elven Bow'],
    epic: ['Flaming Sword', 'Arcane Staff', 'Shadow Dagger', 'Sunfire Bow'],
    legendary: ['Excalibur', 'Staff of Eternity', 'Nightbringer', 'Starfall Bow']
  },
  armor: {
    common: ['Leather Vest', 'Cloth Robe', 'Worn Shield'],
    uncommon: ['Chainmail', 'Silk Robe', 'Iron Shield'],
    rare: ['Plate Armor', 'Enchanted Robe', 'Tower Shield'],
    epic: ['Dragon Scale', 'Archmage Robe', 'Defender Shield'],
    legendary: ['Adamantine Plate', 'Celestial Robe', 'Aegis']
  },
  accessory: {
    common: ['Leather Belt', 'Simple Ring', 'Bronze Amulet'],
    uncommon: ['Sturdy Belt', 'Silver Ring', 'Gold Amulet'],
    rare: ['Magic Belt', 'Ruby Ring', 'Mystic Amulet'],
    epic: ['Champions Belt', 'Diamond Ring', 'Sacred Amulet'],
    legendary: ['Belt of Giants', 'Ring of Power', 'Amulet of Immortality']
  },
  consumable: {
    common: ['Health Potion', 'Mana Potion', 'Bread'],
    uncommon: ['Greater Health Potion', 'Greater Mana Potion', 'Roasted Meat'],
    rare: ['Superior Health Potion', 'Superior Mana Potion', 'Elven Bread'],
    epic: ['Elixir of Life', 'Elixir of Mana', 'Ambrosia'],
    legendary: ['Phoenix Tear', 'Dragon Blood', 'Nectar of Gods']
  },
  rune: {
    common: ['Fire Rune', 'Ice Rune', 'Earth Rune'],
    uncommon: ['Greater Fire Rune', 'Greater Ice Rune', 'Greater Earth Rune'],
    rare: ['Ancient Fire Rune', 'Ancient Ice Rune', 'Ancient Earth Rune'],
    epic: ['Master Fire Rune', 'Master Ice Rune', 'Master Earth Rune'],
    legendary: ['Primordial Fire', 'Primordial Ice', 'Primordial Earth']
  }
};

export function generateLoot(difficulty: string, level: number): Item[] {
  const loot: Item[] = [];
  const dropCount = difficulty === 'easy' ? 1 : difficulty === 'medium' ? 2 : difficulty === 'hard' ? 3 : 4;
  
  for (let i = 0; i < dropCount; i++) {
    const rarity = rollRarity(difficulty);
    const itemType = rollItemType();
    const item = createItem(itemType, rarity, level);
    loot.push(item);
  }
  
  return loot;
}

function rollRarity(difficulty: string): ItemRarity {
  const chances = rarityChances[difficulty];
  const roll = Math.random();
  
  let cumulative = 0;
  for (const [rarity, chance] of Object.entries(chances)) {
    cumulative += chance;
    if (roll <= cumulative) {
      return rarity as ItemRarity;
    }
  }
  
  return 'common';
}

function rollItemType(): ItemType {
  const types: ItemType[] = ['weapon', 'armor', 'accessory', 'consumable', 'rune'];
  return types[Math.floor(Math.random() * types.length)];
}

function createItem(type: ItemType, rarity: ItemRarity, level: number): Item {
  const names = itemNames[type][rarity];
  const name = names[Math.floor(Math.random() * names.length)];
  
  const rarityMultiplier = {
    common: 1,
    uncommon: 1.5,
    rare: 2,
    epic: 3,
    legendary: 5
  }[rarity];
  
  const baseStats = {
    attack: type === 'weapon' ? Math.floor(5 * rarityMultiplier * (level / 5 + 1)) : 0,
    defense: type === 'armor' ? Math.floor(4 * rarityMultiplier * (level / 5 + 1)) : 0,
    magic: type === 'rune' ? Math.floor(6 * rarityMultiplier * (level / 5 + 1)) : 0,
    hp: type === 'armor' ? Math.floor(10 * rarityMultiplier) : 0,
    mp: type === 'accessory' ? Math.floor(8 * rarityMultiplier) : 0
  };
  
  return {
    id: `item_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    name,
    type,
    rarity,
    description: `A ${rarity} ${type} of great power`,
    stats: baseStats,
    value: Math.floor(10 * rarityMultiplier * level),
    equipped: false
  };
}
