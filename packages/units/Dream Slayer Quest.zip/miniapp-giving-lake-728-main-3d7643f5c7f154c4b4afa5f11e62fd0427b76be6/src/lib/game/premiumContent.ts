import type { Item, Region, HeroClass } from '@/types/game';

export interface HeroSkin {
  id: string;
  name: string;
  class: HeroClass;
  description: string;
  isPremium: boolean;
  colorScheme: {
    primary: string;
    secondary: string;
    accent: string;
  };
}

export const premiumSkins: Record<HeroClass, HeroSkin[]> = {
  warrior: [
    {
      id: 'warrior_default',
      name: 'Battle Scarred',
      class: 'warrior',
      description: 'Classic warrior appearance',
      isPremium: false,
      colorScheme: { primary: '#8B0000', secondary: '#4A4A4A', accent: '#C0C0C0' }
    },
    {
      id: 'warrior_dragon_knight',
      name: 'Dragon Knight',
      class: 'warrior',
      description: 'Armor forged from dragon scales',
      isPremium: true,
      colorScheme: { primary: '#DC143C', secondary: '#FFD700', accent: '#FF4500' }
    },
    {
      id: 'warrior_shadow_berserker',
      name: 'Shadow Berserker',
      class: 'warrior',
      description: 'Infused with dark energy',
      isPremium: true,
      colorScheme: { primary: '#000000', secondary: '#4B0082', accent: '#8B008B' }
    }
  ],
  mage: [
    {
      id: 'mage_default',
      name: 'Apprentice Robes',
      class: 'mage',
      description: 'Standard mage attire',
      isPremium: false,
      colorScheme: { primary: '#4169E1', secondary: '#00008B', accent: '#87CEEB' }
    },
    {
      id: 'mage_archmage',
      name: 'Archmage Supreme',
      class: 'mage',
      description: 'Robes of ultimate magical power',
      isPremium: true,
      colorScheme: { primary: '#9400D3', secondary: '#FFD700', accent: '#00FFFF' }
    },
    {
      id: 'mage_frost_sage',
      name: 'Frost Sage',
      class: 'mage',
      description: 'Master of ice magic',
      isPremium: true,
      colorScheme: { primary: '#00CED1', secondary: '#E0FFFF', accent: '#4682B4' }
    }
  ],
  rogue: [
    {
      id: 'rogue_default',
      name: 'Street Thief',
      class: 'rogue',
      description: 'Basic rogue gear',
      isPremium: false,
      colorScheme: { primary: '#2F4F4F', secondary: '#000000', accent: '#696969' }
    },
    {
      id: 'rogue_shadow_assassin',
      name: 'Shadow Assassin',
      class: 'rogue',
      description: 'One with the shadows',
      isPremium: true,
      colorScheme: { primary: '#1C1C1C', secondary: '#8B0000', accent: '#4B0082' }
    },
    {
      id: 'rogue_phantom_blade',
      name: 'Phantom Blade',
      class: 'rogue',
      description: 'Ethereal and deadly',
      isPremium: true,
      colorScheme: { primary: '#483D8B', secondary: '#9370DB', accent: '#00FFFF' }
    }
  ],
  paladin: [
    {
      id: 'paladin_default',
      name: 'Holy Warrior',
      class: 'paladin',
      description: 'Blessed armor of light',
      isPremium: false,
      colorScheme: { primary: '#FFD700', secondary: '#FFFFFF', accent: '#87CEEB' }
    },
    {
      id: 'paladin_divine_champion',
      name: 'Divine Champion',
      class: 'paladin',
      description: 'Chosen by the gods',
      isPremium: true,
      colorScheme: { primary: '#FFD700', secondary: '#FF69B4', accent: '#00FFFF' }
    },
    {
      id: 'paladin_dark_crusader',
      name: 'Dark Crusader',
      class: 'paladin',
      description: 'Holy power with dark edge',
      isPremium: true,
      colorScheme: { primary: '#2F4F4F', secondary: '#FFD700', accent: '#8B0000' }
    }
  ]
};

export const bonusRegions: Region[] = [
  {
    id: 'crystal_caverns',
    name: 'Crystal Caverns',
    description: 'Ancient caves filled with magical crystals and subterranean horrors',
    unlocked: false,
    level: 15,
    isPremium: true,
    enemyTypes: ['Crystal Golem', 'Cave Wyrm', 'Dark Dweller'],
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
  },
  {
    id: 'shadow_realm',
    name: 'Shadow Realm',
    description: 'A dimension between worlds where nightmares take form',
    unlocked: false,
    level: 20,
    isPremium: true,
    enemyTypes: ['Shadow Demon', 'Void Walker', 'Nightmare King'],
    background: 'linear-gradient(135deg, #000000 0%, #434343 100%)'
  }
];

export const legendaryItems: Item[] = [
  {
    id: 'legendary_sword_infinity',
    name: 'Infinity Blade',
    type: 'weapon',
    rarity: 'legendary',
    description: 'A sword that cuts through reality itself',
    stats: { attack: 100, defense: 0, magic: 50, speed: 30 },
    value: 10000,
    isPremium: true,
    specialAbility: 'Void Strike: Ignores 50% of enemy defense'
  },
  {
    id: 'legendary_staff_cosmos',
    name: 'Staff of the Cosmos',
    type: 'weapon',
    rarity: 'legendary',
    description: 'Harness the power of stars',
    stats: { attack: 30, defense: 0, magic: 120, speed: 20 },
    value: 10000,
    isPremium: true,
    specialAbility: 'Cosmic Ray: Deals pure magic damage'
  },
  {
    id: 'legendary_armor_titan',
    name: 'Titan Plate Armor',
    type: 'armor',
    rarity: 'legendary',
    description: 'Forged by ancient titans',
    stats: { attack: 0, defense: 100, magic: 0, speed: -10 },
    value: 10000,
    isPremium: true,
    specialAbility: 'Titan Shield: Reflects 25% damage'
  },
  {
    id: 'legendary_cloak_shadows',
    name: 'Cloak of Eternal Shadows',
    type: 'armor',
    rarity: 'legendary',
    description: 'Become one with darkness',
    stats: { attack: 40, defense: 40, magic: 40, speed: 60 },
    value: 10000,
    isPremium: true,
    specialAbility: 'Shadow Form: 30% dodge chance'
  },
  {
    id: 'legendary_amulet_phoenix',
    name: 'Phoenix Heart Amulet',
    type: 'accessory',
    rarity: 'legendary',
    description: 'Rise from defeat like a phoenix',
    stats: { attack: 30, defense: 30, magic: 60, speed: 30 },
    value: 10000,
    isPremium: true,
    specialAbility: 'Rebirth: Once per battle, revive with 50% HP'
  },
  {
    id: 'legendary_ring_time',
    name: 'Ring of Temporal Flux',
    type: 'accessory',
    rarity: 'legendary',
    description: 'Manipulate the flow of time',
    stats: { attack: 20, defense: 20, magic: 80, speed: 100 },
    value: 10000,
    isPremium: true,
    specialAbility: 'Time Warp: Act twice in battle'
  }
];

export function isPremiumUnlocked(): boolean {
  if (typeof window === 'undefined') return false;
  const apiKey = localStorage.getItem('dreamHeroApiKey');
  return !!apiKey;
}

export function getPremiumSkinsForClass(heroClass: HeroClass): HeroSkin[] {
  const isPremium = isPremiumUnlocked();
  return premiumSkins[heroClass].filter(skin => !skin.isPremium || isPremium);
}

export function getPremiumItems(): Item[] {
  const isPremium = isPremiumUnlocked();
  return isPremium ? legendaryItems : [];
}

export function getPremiumRegions(): Region[] {
  const isPremium = isPremiumUnlocked();
  return isPremium ? bonusRegions : [];
}
