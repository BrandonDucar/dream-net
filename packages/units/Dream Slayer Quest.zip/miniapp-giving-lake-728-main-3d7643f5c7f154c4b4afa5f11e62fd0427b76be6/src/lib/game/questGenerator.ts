import type { Quest, Enemy, Item, MonsterType } from '@/types/game';
import { generateEnemy } from './enemyGenerator';
import { generateLoot } from './lootGenerator';

const questTemplates = {
  forest: {
    easy: [
      {
        title: 'The Lost Merchant',
        story: [
          'A merchant has been ambushed by goblins in the forest.',
          'The local guild needs a hero to rescue him.',
          'Prepare for battle and venture into the dark woods.'
        ]
      },
      {
        title: 'Wolf Pack Threat',
        story: [
          'A pack of dire wolves has been terrorizing nearby villages.',
          'The elders request your aid in eliminating the threat.',
          'Track the wolves to their den and face the alpha.'
        ]
      }
    ],
    medium: [
      {
        title: 'The Cursed Grove',
        story: [
          'An ancient grove has been corrupted by dark magic.',
          'The forest spirits cry out for a champion.',
          'Enter the cursed grove and face the corrupted guardian.'
        ]
      },
      {
        title: 'Bandit King',
        story: [
          'A notorious bandit king has claimed the forest roads.',
          'Travelers dare not pass without paying tribute.',
          'Hunt down the bandit king and restore peace.'
        ]
      }
    ],
    hard: [
      {
        title: 'Dragon of the Deep Woods',
        story: [
          'An ancient dragon has awakened in the heart of the forest.',
          'Its fury threatens to consume all life.',
          'Steel yourself, hero. This will be your greatest challenge yet.'
        ]
      }
    ],
    boss: [
      {
        title: 'The Forest Lord',
        story: [
          'The corrupted Forest Lord, once a protector, now a destroyer.',
          'Legend speaks of a hero who will face this ancient evil.',
          'Your destiny awaits in the deepest part of the forest.'
        ]
      }
    ]
  },
  mountain_peaks: {
    easy: [
      {
        title: 'Mountain Bandits',
        story: [
          'Bandits have set up camp in the mountain passes.',
          'They prey on travelers and merchants.',
          'Clear them out and claim their treasure.'
        ]
      }
    ],
    medium: [
      {
        title: 'The Ice Wyrm',
        story: [
          'A fearsome ice wyrm guards an ancient treasure.',
          'Many have tried to claim it. All have failed.',
          'Will you be the one to succeed?'
        ]
      }
    ],
    hard: [
      {
        title: 'Storm Dragon',
        story: [
          'A dragon that commands the storms dwells at the peak.',
          'Its rage brings endless blizzards.',
          'Only a true hero can calm this tempest.'
        ]
      }
    ],
    boss: [
      {
        title: 'The Mountain King',
        story: [
          'The ancient Mountain King rises from his slumber.',
          'His awakening shakes the very foundations of the world.',
          'Face him, or watch the mountains crumble.'
        ]
      }
    ]
  },
  desert: {
    easy: [
      {
        title: 'Scorpion Nest',
        story: [
          'Giant scorpions have made a nest near an oasis.',
          'The water supply is threatened.',
          'Eliminate the nest and protect the oasis.'
        ]
      }
    ],
    medium: [
      {
        title: 'Tomb Raiders',
        story: [
          'Undead guardians have awakened in an ancient tomb.',
          'Dark magic stirs within the sand-worn halls.',
          'Venture into the tomb and put the dead to rest.'
        ]
      }
    ],
    hard: [
      {
        title: 'Sand Drake',
        story: [
          'A massive drake burrows through the desert.',
          'It swallows caravans whole.',
          'Track it down and end its reign of terror.'
        ]
      }
    ],
    boss: [
      {
        title: 'The Desert Pharaoh',
        story: [
          'An ancient pharaoh, cursed to walk eternally.',
          'His power grows with each passing moon.',
          'Break the curse, or join his undead army.'
        ]
      }
    ]
  }
};

export function generateQuest(
  heroLevel: number,
  region: keyof typeof questTemplates,
  difficulty: 'easy' | 'medium' | 'hard' | 'boss'
): Quest {
  const templates = questTemplates[region]?.[difficulty] || questTemplates.forest[difficulty];
  const template = templates[Math.floor(Math.random() * templates.length)];
  
  const enemy = generateEnemy(heroLevel, difficulty, region);
  const loot = generateLoot(difficulty, heroLevel);
  
  const baseXp = difficulty === 'easy' ? 50 : difficulty === 'medium' ? 150 : difficulty === 'hard' ? 300 : 500;
  const baseGold = difficulty === 'easy' ? 25 : difficulty === 'medium' ? 75 : difficulty === 'hard' ? 150 : 300;

  return {
    id: `quest_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    title: template.title,
    description: `Level ${heroLevel} ${difficulty} quest`,
    story: template.story,
    region,
    difficulty,
    rewards: {
      xp: baseXp * heroLevel,
      gold: baseGold + Math.floor(Math.random() * 50),
      items: loot
    },
    completed: false,
    active: false,
    enemy
  };
}
