import type { Region } from '@/types/game';
import { getPremiumRegions } from './premiumContent';

export function initializeRegions(): Region[] {
  const baseRegions: Region[] = [
    {
      id: 'forest',
      name: 'Whisperwood Forest',
      description: 'An ancient forest filled with mysterious creatures and hidden secrets.',
      level: 1,
      unlocked: true,
      completed: false,
      quests: [],
      boss: 'The Forest Lord'
    },
    {
      id: 'mountain_peaks',
      name: 'Frostpeak Mountains',
      description: 'Treacherous peaks where dragons nest and storms rage eternally.',
      level: 5,
      unlocked: false,
      completed: false,
      quests: [],
      boss: 'The Mountain King'
    },
    {
      id: 'desert',
      name: 'Sunscorch Desert',
      description: 'Vast dunes hide ancient tombs and forgotten treasures.',
      level: 10,
      unlocked: false,
      completed: false,
      quests: [],
      boss: 'The Desert Pharaoh'
    },
    {
      id: 'swamp',
      name: 'Shadowmire Swamp',
      description: 'A cursed swamp where dark magic festers.',
      level: 15,
      unlocked: false,
      completed: false,
      quests: [],
      boss: 'The Swamp Witch'
    },
    {
      id: 'volcanic_islands',
      name: 'Emberfall Isles',
      description: 'Islands of fire and brimstone, home to the most fearsome beasts.',
      level: 20,
      unlocked: false,
      completed: false,
      quests: [],
      boss: 'The Inferno Dragon'
    },
    {
      id: 'northern_wastes',
      name: 'Eternal Frost',
      description: 'The frozen lands at the edge of the world.',
      level: 25,
      unlocked: false,
      completed: false,
      quests: [],
      boss: 'The Ice Titan'
    }
  ];

  const premiumRegions = getPremiumRegions();
  return [...baseRegions, ...premiumRegions];
}
