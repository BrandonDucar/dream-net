export type HeroClass = 'warrior' | 'mage' | 'rogue' | 'paladin';

export type ItemRarity = 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';

export type ItemType = 'weapon' | 'armor' | 'accessory' | 'consumable' | 'rune';

export type SkillType = 'attack' | 'defense' | 'magic' | 'passive';

export type MonsterType = 'goblin' | 'orc' | 'dragon' | 'demon' | 'undead' | 'beast';

export interface Hero {
  class: HeroClass;
  name: string;
  level: number;
  hp: number;
  maxHp: number;
  mp: number;
  maxMp: number;
  xp: number;
  xpToNextLevel: number;
  attack: number;
  defense: number;
  magic: number;
  speed: number;
  gold: number;
  inventory: Item[];
  equippedItems: {
    weapon?: Item;
    armor?: Item;
    accessory?: Item;
  };
  skills: Skill[];
  runes: Rune[];
  titles: string[];
  region: string;
  skinId?: string;
}

export interface Item {
  id: string;
  name: string;
  type: ItemType;
  rarity: ItemRarity;
  description: string;
  stats: {
    attack?: number;
    defense?: number;
    magic?: number;
    hp?: number;
    mp?: number;
    speed?: number;
  };
  value: number;
  equipped?: boolean;
  isPremium?: boolean;
  specialAbility?: string;
}

export interface Skill {
  id: string;
  name: string;
  type: SkillType;
  level: number;
  maxLevel: number;
  description: string;
  damage?: number;
  mpCost: number;
  unlocked: boolean;
}

export interface Rune {
  id: string;
  name: string;
  type: 'fire' | 'ice' | 'lightning' | 'earth' | 'wind' | 'dark' | 'light';
  power: number;
  description: string;
  equipped: boolean;
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  story: string[];
  region: string;
  difficulty: 'easy' | 'medium' | 'hard' | 'boss';
  rewards: {
    xp: number;
    gold: number;
    items: Item[];
  };
  completed: boolean;
  active: boolean;
  enemy: Enemy;
  isAiGenerated?: boolean;
  questHook?: string;
}

export interface Enemy {
  id: string;
  name: string;
  type: MonsterType;
  level: number;
  hp: number;
  maxHp: number;
  attack: number;
  defense: number;
  magic: number;
  isBoss: boolean;
  lootTable: Item[];
  xpReward: number;
  goldReward: number;
}

export interface Battle {
  id: string;
  enemy: Enemy;
  turnCount: number;
  playerTurn: boolean;
  battleLog: BattleLogEntry[];
}

export interface BattleLogEntry {
  turn: number;
  attacker: 'hero' | 'enemy';
  action: string;
  damage: number;
  critical: boolean;
  timestamp: number;
}

export interface Region {
  id: string;
  name: string;
  description: string;
  level: number;
  unlocked: boolean;
  completed?: boolean;
  quests?: string[];
  boss?: string;
  isPremium?: boolean;
  enemyTypes?: string[];
  background?: string;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  unlocked: boolean;
  unlockedAt?: number;
  icon: string;
}

export interface GameState {
  hero: Hero | null;
  quests: Quest[];
  completedQuests: string[];
  currentRegion: string;
  regions: Region[];
  achievements: Achievement[];
  gameStartTime: number;
  totalPlayTime: number;
}

export type ActiveScreen = 'main' | 'battle' | 'profile' | 'quests' | 'inventory' | 'skills' | 'map';
