import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.json();
    const { latitude, longitude } = body as { latitude: number; longitude: number };

    if (!latitude || !longitude) {
      return NextResponse.json(
        { error: 'Latitude and longitude are required' },
        { status: 400 }
      );
    }

    // Determine region based on coordinates
    let region = 'Unknown';
    let timezone = 'UTC';
    let localBonus = 0;

    // North America
    if (latitude >= 15 && latitude <= 72 && longitude >= -168 && longitude <= -52) {
      region = 'North America';
      timezone = 'America/New_York';
      localBonus = 50;
    }
    // Europe
    else if (latitude >= 36 && latitude <= 71 && longitude >= -10 && longitude <= 40) {
      region = 'Europe';
      timezone = 'Europe/London';
      localBonus = 75;
    }
    // Asia
    else if (latitude >= -10 && latitude <= 55 && longitude >= 60 && longitude <= 150) {
      region = 'Asia';
      timezone = 'Asia/Tokyo';
      localBonus = 100;
    }
    // South America
    else if (latitude >= -56 && latitude <= 13 && longitude >= -82 && longitude <= -35) {
      region = 'South America';
      timezone = 'America/Sao_Paulo';
      localBonus = 60;
    }
    // Africa
    else if (latitude >= -35 && latitude <= 37 && longitude >= -18 && longitude <= 52) {
      region = 'Africa';
      timezone = 'Africa/Cairo';
      localBonus = 80;
    }
    // Oceania
    else if (latitude >= -47 && latitude <= -10 && longitude >= 110 && longitude <= 180) {
      region = 'Oceania';
      timezone = 'Australia/Sydney';
      localBonus = 90;
    }

    return NextResponse.json({
      region,
      timezone,
      localBonus,
      coordinates: {
        latitude,
        longitude,
      },
      message: `Welcome, ninja from ${region}! You've earned a ${localBonus} point regional bonus!`,
    });
  } catch (error) {
    console.error('Geofence error:', error);
    return NextResponse.json(
      { error: 'Failed to process location' },
      { status: 500 }
    );
  }
}
