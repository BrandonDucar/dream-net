import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';
import { Toaster } from '@/components/ui/sonner';
import type { ReactElement, ReactNode } from 'react';
import FarcasterWrapper from "@/components/FarcasterWrapper";

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export default function RootLayout({
  children,
}: Readonly<{
  children: ReactNode;
}>): ReactElement {
  return (
        <html lang="en">
          <head>
            <script
              type="application/ld+json"
              dangerouslySetInnerHTML={{
                __html: JSON.stringify({
                  '@context': 'https://schema.org',
                  '@type': 'VideoGame',
                  name: 'DreamBlade Trials',
                  description: 'Fast-paced ninja reflex game with progression and unlockables',
                  genre: ['Action', 'Arcade', 'Skill'],
                  gamePlatform: 'Web Browser',
                  playMode: 'SinglePlayer',
                  url: typeof window !== 'undefined' ? window.location.href : '',
                }),
              }}
            />
          </head>
          <body
            className={`${geistSans.variable} ${geistMono.variable} antialiased`}
          >
            
      <FarcasterWrapper>
        {children}
      </FarcasterWrapper>
      
            <Toaster />
          </body>
        </html>
      );
}

export const metadata: Metadata = {
        title: "DreamBlade Trials",
        description: "Slice through targets in this fast-paced ninja reflex game. Test your skills, level up, and rise through the ranks. Compete globally with AI leaderboards. Neon graphics for a futuristic flair.",
        other: { "fc:frame": JSON.stringify({"version":"next","imageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_e6127e57-2258-4a59-9fd7-46c54e707535-EkWheUhDKLKx1lSWGvxNNqLP0qPMwC","button":{"title":"Open with Ohara","action":{"type":"launch_frame","name":"DreamBlade Trials","url":"https://have-supply-343.app.ohara.ai","splashImageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/farcaster/splash_images/splash_image1.svg","splashBackgroundColor":"#ffffff"}}}
        ) }
    };
