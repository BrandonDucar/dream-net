'use client'
import { useState, useEffect } from 'react';
import type { ReactElement } from 'react';
import { MainMenu } from '@/components/game/MainMenu';
import { GameCanvas } from '@/components/game/GameCanvas';
import { BladeGallery } from '@/components/game/BladeGallery';
import { Leaderboard } from '@/components/game/Leaderboard';
import type { GameMode, PlayerProfile } from '@/types/game';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DreamBladeTrials(): ReactElement {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [view, setView] = useState<'menu' | 'game' | 'gallery' | 'leaderboard'>('menu');
  const [gameMode, setGameMode] = useState<GameMode>('trial');
  const [playerProfile, setPlayerProfile] = useState<PlayerProfile>({
    totalScore: 0,
    level: 1,
    rank: 'Initiate',
    unlockedBlades: ['default'],
    selectedBlade: 'default',
    glowColor: '#00d9ff',
  });

  const handleStartGame = (mode: GameMode): void => {
    setGameMode(mode);
    setView('game');
  };

  const handleGameEnd = (score: number, accuracy: number, combo: number): void => {
    setPlayerProfile((prev: PlayerProfile) => {
      const newTotalScore = prev.totalScore + score;
      const newLevel = Math.floor(newTotalScore / 1000) + 1;
      let newRank: 'Initiate' | 'Striker' | 'Shadow Runner' | 'DreamBlade' = 'Initiate';
      
      if (newLevel >= 15) newRank = 'DreamBlade';
      else if (newLevel >= 10) newRank = 'Shadow Runner';
      else if (newLevel >= 5) newRank = 'Striker';

      const unlockedBlades = [...prev.unlockedBlades];
      if (newLevel >= 3 && !unlockedBlades.includes('striker')) unlockedBlades.push('striker');
      if (newLevel >= 7 && !unlockedBlades.includes('shadow')) unlockedBlades.push('shadow');
      if (newLevel >= 12 && !unlockedBlades.includes('dream')) unlockedBlades.push('dream');

      return {
        ...prev,
        totalScore: newTotalScore,
        level: newLevel,
        rank: newRank,
        unlockedBlades,
      };
    });
    setView('menu');
  };

  return (
    <div className="fixed inset-0 bg-black overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-950 via-black to-purple-950 opacity-70" />
      
      <div className="relative z-10 h-full w-full">
        {view === 'menu' && (
          <MainMenu
            playerProfile={playerProfile}
            onStartGame={handleStartGame}
            onShowGallery={(): void => setView('gallery')}
            onShowLeaderboard={(): void => setView('leaderboard')}
          />
        )}
        
        {view === 'game' && (
          <GameCanvas
            mode={gameMode}
            playerProfile={playerProfile}
            onGameEnd={handleGameEnd}
          />
        )}
        
        {view === 'gallery' && (
          <BladeGallery
            playerProfile={playerProfile}
            onSelectBlade={(blade: string): void => {
              setPlayerProfile((prev: PlayerProfile) => ({ ...prev, selectedBlade: blade }));
            }}
            onBack={(): void => setView('menu')}
          />
        )}
        
        {view === 'leaderboard' && (
          <Leaderboard
            playerScore={playerProfile.totalScore}
            onBack={(): void => setView('menu')}
          />
        )}
      </div>
      
      {/* Neon glow overlay */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-500 opacity-20 blur-[100px] rounded-full" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500 opacity-20 blur-[100px] rounded-full" />
      </div>
    </div>
  );
}
