'use client';

import type { ReactElement } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { PlayerProfile } from '@/types/game';

interface BladeGalleryProps {
  playerProfile: PlayerProfile;
  onSelectBlade: (blade: string) => void;
  onBack: () => void;
}

interface BladeStyle {
  id: string;
  name: string;
  color: string;
  unlockLevel: number;
  description: string;
}

const bladeStyles: BladeStyle[] = [
  {
    id: 'default',
    name: 'Initiate Blade',
    color: '#00d9ff',
    unlockLevel: 1,
    description: 'The standard blade for all ninjas beginning their journey.',
  },
  {
    id: 'striker',
    name: 'Striker Edge',
    color: '#00ff88',
    unlockLevel: 3,
    description: 'A vibrant green blade for those who strike with precision.',
  },
  {
    id: 'shadow',
    name: 'Shadow Fang',
    color: '#8800ff',
    unlockLevel: 7,
    description: 'A mysterious purple blade wielded by shadow runners.',
  },
  {
    id: 'dream',
    name: 'DreamBlade',
    color: '#ff00ff',
    unlockLevel: 12,
    description: 'The ultimate blade that bends reality itself.',
  },
];

export function BladeGallery({ playerProfile, onSelectBlade, onBack }: BladeGalleryProps): ReactElement {
  return (
    <div className="flex flex-col items-center justify-center h-full w-full px-4 pt-20 pb-8 overflow-y-auto">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-white mb-2" style={{
            textShadow: '0 0 20px rgba(0, 217, 255, 0.8)'
          }}>
            Blade Gallery
          </h2>
          <p className="text-gray-400">Unlock blade styles as you level up</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {bladeStyles.map((blade: BladeStyle) => {
            const isUnlocked = playerProfile.unlockedBlades.includes(blade.id);
            const isSelected = playerProfile.selectedBlade === blade.id;

            return (
              <Card
                key={blade.id}
                className={`transition-all ${
                  isUnlocked
                    ? 'bg-black/80 border-2 cursor-pointer hover:scale-105'
                    : 'bg-gray-900/50 border-2 border-gray-700'
                } ${isSelected ? 'border-yellow-400' : 'border-blue-500'}`}
                style={isUnlocked ? {
                  boxShadow: `0 0 20px ${blade.color}40`
                } : {}}
                onClick={(): void => {
                  if (isUnlocked) {
                    onSelectBlade(blade.id);
                  }
                }}
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-bold text-white">{blade.name}</h3>
                    {isSelected && (
                      <Badge className="bg-yellow-500 text-black">EQUIPPED</Badge>
                    )}
                    {!isUnlocked && (
                      <Badge className="bg-gray-600 text-gray-300">LOCKED</Badge>
                    )}
                  </div>

                  {/* Blade preview */}
                  <div className="h-32 flex items-center justify-center mb-4 relative overflow-hidden rounded-lg bg-black/50">
                    {isUnlocked ? (
                      <div
                        className="w-full h-2 transform rotate-45"
                        style={{
                          background: `linear-gradient(90deg, transparent, ${blade.color}, transparent)`,
                          boxShadow: `0 0 20px ${blade.color}`
                        }}
                      />
                    ) : (
                      <div className="text-6xl text-gray-600">🔒</div>
                    )}
                  </div>

                  <p className="text-gray-400 text-sm mb-4">{blade.description}</p>

                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Unlock Level:</span>
                    <span className={playerProfile.level >= blade.unlockLevel ? 'text-green-400' : 'text-gray-400'}>
                      Level {blade.unlockLevel}
                    </span>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="text-center">
          <Button
            onClick={onBack}
            variant="outline"
            className="bg-black/50 border-blue-400 text-blue-300 hover:bg-blue-950/50"
          >
            Back to Menu
          </Button>
        </div>
      </div>
    </div>
  );
}
