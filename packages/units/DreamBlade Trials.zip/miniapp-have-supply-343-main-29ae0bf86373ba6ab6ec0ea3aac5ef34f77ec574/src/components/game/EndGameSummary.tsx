'use client';

import type { ReactElement } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import type { GameState } from '@/types/game';

interface EndGameSummaryProps {
  gameState: GameState;
  onRetry: () => void;
  onQuit: () => void;
}

export function EndGameSummary({ gameState, onRetry, onQuit }: EndGameSummaryProps): ReactElement {
  const accuracy = gameState.targetsHit + gameState.targetsMissed > 0
    ? ((gameState.targetsHit / (gameState.targetsHit + gameState.targetsMissed)) * 100).toFixed(1)
    : '0.0';

  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/80 backdrop-blur-sm">
      <Card className="bg-black/90 border-2 border-blue-500 w-full max-w-md mx-4" style={{
        boxShadow: '0 0 40px rgba(0, 217, 255, 0.5)'
      }}>
        <CardHeader>
          <CardTitle className="text-3xl text-center text-white">Trial Complete</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Stats */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-300 text-lg">Score:</span>
              <span className="text-blue-300 font-bold text-2xl">{gameState.score.toLocaleString()}</span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-300 text-lg">Accuracy:</span>
              <span className="text-blue-300 font-bold text-2xl">{accuracy}%</span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-300 text-lg">Longest Combo:</span>
              <span className="text-purple-300 font-bold text-2xl">{gameState.maxCombo}x</span>
            </div>

            <div className="pt-4 border-t border-gray-700">
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-400">Targets Hit:</span>
                <span className="text-green-400">{gameState.targetsHit}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-400">Targets Missed:</span>
                <span className="text-red-400">{gameState.targetsMissed}</span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="space-y-3">
            <Button
              onClick={onRetry}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold"
              style={{
                boxShadow: '0 0 20px rgba(0, 217, 255, 0.4)'
              }}
            >
              Try Again
            </Button>
            
            <Button
              onClick={onQuit}
              variant="outline"
              className="w-full bg-black/50 border-blue-400 text-blue-300 hover:bg-blue-950/50"
            >
              Back to Menu
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
