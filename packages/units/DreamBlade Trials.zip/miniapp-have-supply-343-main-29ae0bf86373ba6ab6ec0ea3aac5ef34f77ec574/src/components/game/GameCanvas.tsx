'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import type { ReactElement } from 'react';
import type { GameMode, PlayerProfile, Target, PowerUp, GameState, Particle, SlashEffect } from '@/types/game';
import { GameHUD } from './GameHUD';
import { EndGameSummary } from './EndGameSummary';
import { playSound } from '@/lib/soundManager';
import { createParticleBurst } from '@/lib/particleSystem';

interface GameCanvasProps {
  mode: GameMode;
  playerProfile: PlayerProfile;
  onGameEnd: (score: number, accuracy: number, combo: number) => void;
}

export function GameCanvas({ mode, playerProfile, onGameEnd }: GameCanvasProps): ReactElement {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<GameState>({
    score: 0,
    combo: 0,
    maxCombo: 0,
    targetsHit: 0,
    targetsMissed: 0,
    timeRemaining: 60,
    isPlaying: true,
    isPaused: false,
    activePowerUp: null,
    powerUpEndTime: 0,
  });
  
  const [targets, setTargets] = useState<Target[]>([]);
  const [powerUps, setPowerUps] = useState<PowerUp[]>([]);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [slashEffects, setSlashEffects] = useState<SlashEffect[]>([]);
  const [showSummary, setShowSummary] = useState(false);
  
  const gameLoopRef = useRef<number>();
  const lastSpawnRef = useRef<number>(0);
  const lastPowerUpRef = useRef<number>(0);
  const speedMultiplierRef = useRef<number>(1);
  const touchStartRef = useRef<{ x: number; y: number } | null>(null);

  // Spawn targets
  const spawnTarget = useCallback((now: number): void => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const minDistance = 100;
    const maxAttempts = 10;
    let attempts = 0;
    let validPosition = false;
    let x = 0;
    let y = 0;

    while (!validPosition && attempts < maxAttempts) {
      x = Math.random() * (canvas.width - 100) + 50;
      y = Math.random() * (canvas.height - 100) + 50;
      
      validPosition = targets.every((t: Target) => {
        const dx = t.x - x;
        const dy = t.y - y;
        return Math.sqrt(dx * dx + dy * dy) > minDistance;
      });
      
      attempts++;
    }

    if (!validPosition) return;

    const isHazard = mode === 'trial' && Math.random() < 0.2;
    
    const newTarget: Target = {
      id: `target-${now}-${Math.random()}`,
      x,
      y,
      type: isHazard ? 'hazard' : 'normal',
      points: isHazard ? -50 : 10,
      radius: 40,
      spawnTime: now,
    };

    setTargets((prev: Target[]) => [...prev, newTarget]);
  }, [mode, targets]);

  // Spawn power-up
  const spawnPowerUp = useCallback((now: number): void => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const types: Array<'double' | 'slowmo' | 'freeze'> = ['double', 'slowmo', 'freeze'];
    const type = types[Math.floor(Math.random() * types.length)];

    const newPowerUp: PowerUp = {
      id: `powerup-${now}`,
      x: Math.random() * (canvas.width - 100) + 50,
      y: Math.random() * (canvas.height - 100) + 50,
      type,
      radius: 30,
      spawnTime: now,
    };

    setPowerUps((prev: PowerUp[]) => [...prev, newPowerUp]);
  }, []);

  // Check collision
  const checkCollision = useCallback((x: number, y: number): void => {
    const now = Date.now();
    
    // Check power-ups first
    const hitPowerUp = powerUps.find((p: PowerUp) => {
      const dx = p.x - x;
      const dy = p.y - y;
      return Math.sqrt(dx * dx + dy * dy) < p.radius;
    });

    if (hitPowerUp) {
      playSound('powerup');
      setPowerUps((prev: PowerUp[]) => prev.filter((p: PowerUp) => p.id !== hitPowerUp.id));
      
      setGameState((prev: GameState) => ({
        ...prev,
        activePowerUp: hitPowerUp.type,
        powerUpEndTime: now + 5000,
      }));

      if (hitPowerUp.type === 'freeze') {
        speedMultiplierRef.current = 0;
        setTimeout(() => {
          speedMultiplierRef.current = 1;
        }, 5000);
      } else if (hitPowerUp.type === 'slowmo') {
        speedMultiplierRef.current = 0.5;
        setTimeout(() => {
          speedMultiplierRef.current = 1;
        }, 5000);
      }
      
      setParticles((prev: Particle[]) => [
        ...prev,
        ...createParticleBurst(hitPowerUp.x, hitPowerUp.y, '#ffd700', 15)
      ]);
      
      return;
    }

    // Check targets
    const hitTarget = targets.find((t: Target) => {
      const dx = t.x - x;
      const dy = t.y - y;
      return Math.sqrt(dx * dx + dy * dy) < t.radius;
    });

    if (hitTarget) {
      setTargets((prev: Target[]) => prev.filter((t: Target) => t.id !== hitTarget.id));

      if (hitTarget.type === 'hazard') {
        playSound('hazard');
        setGameState((prev: GameState) => ({
          ...prev,
          score: Math.max(0, prev.score + hitTarget.points),
          combo: 0,
          targetsHit: prev.targetsHit + 1,
        }));
        setParticles((prev: Particle[]) => [
          ...prev,
          ...createParticleBurst(hitTarget.x, hitTarget.y, '#ff0000', 20)
        ]);
      } else {
        playSound('slash');
        setGameState((prev: GameState) => {
          const multiplier = prev.activePowerUp === 'double' ? 2 : 1;
          const comboMultiplier = Math.min(Math.floor(prev.combo / 5) + 1, 5);
          const points = hitTarget.points * multiplier * comboMultiplier;
          const newCombo = prev.combo + 1;
          
          return {
            ...prev,
            score: prev.score + points,
            combo: newCombo,
            maxCombo: Math.max(prev.maxCombo, newCombo),
            targetsHit: prev.targetsHit + 1,
          };
        });
        setParticles((prev: Particle[]) => [
          ...prev,
          ...createParticleBurst(hitTarget.x, hitTarget.y, playerProfile.glowColor, 25)
        ]);
      }
    }
  }, [targets, powerUps, playerProfile.glowColor]);

  // Handle touch/mouse input
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>): void => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) * (canvas.width / rect.width);
    const y = (e.clientY - rect.top) * (canvas.height / rect.height);

    touchStartRef.current = { x, y };
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>): void => {
    if (!touchStartRef.current) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) * (canvas.width / rect.width);
    const y = (e.clientY - rect.top) * (canvas.height / rect.height);

    const slash: SlashEffect = {
      id: `slash-${Date.now()}`,
      startX: touchStartRef.current.x,
      startY: touchStartRef.current.y,
      endX: x,
      endY: y,
      timestamp: Date.now(),
      color: playerProfile.glowColor,
    };

    setSlashEffects((prev: SlashEffect[]) => [...prev, slash]);
    checkCollision(x, y);
    
    touchStartRef.current = { x, y };
  };

  const handlePointerUp = (): void => {
    touchStartRef.current = null;
  };

  // Game loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    let lastTime = Date.now();

    const gameLoop = (): void => {
      const now = Date.now();
      const deltaTime = (now - lastTime) / 1000;
      lastTime = now;

      if (!gameState.isPlaying || gameState.isPaused) {
        gameLoopRef.current = requestAnimationFrame(gameLoop);
        return;
      }

      // Update timer
      setGameState((prev: GameState) => {
        const newTime = Math.max(0, prev.timeRemaining - deltaTime);
        if (newTime === 0 && prev.isPlaying) {
          setShowSummary(true);
          return { ...prev, timeRemaining: 0, isPlaying: false };
        }
        return { ...prev, timeRemaining: newTime };
      });

      // Increase spawn rate over time
      const elapsedTime = 60 - gameState.timeRemaining;
      const baseSpawnInterval = Math.max(800, 1500 - elapsedTime * 15);
      const spawnInterval = baseSpawnInterval / speedMultiplierRef.current;

      // Spawn targets
      if (now - lastSpawnRef.current > spawnInterval) {
        spawnTarget(now);
        lastSpawnRef.current = now;
      }

      // Spawn power-ups
      if (mode === 'trial' && now - lastPowerUpRef.current > 10000) {
        spawnPowerUp(now);
        lastPowerUpRef.current = now;
      }

      // Remove expired targets
      setTargets((prev: Target[]) => {
        const expired = prev.filter((t: Target) => now - t.spawnTime > 3000);
        if (expired.length > 0) {
          setGameState((state: GameState) => ({
            ...state,
            combo: 0,
            targetsMissed: state.targetsMissed + expired.length,
          }));
        }
        return prev.filter((t: Target) => now - t.spawnTime <= 3000);
      });

      // Remove expired power-ups
      setPowerUps((prev: PowerUp[]) => prev.filter((p: PowerUp) => now - p.spawnTime <= 5000));

      // Update particles
      setParticles((prev: Particle[]) => 
        prev
          .map((p: Particle) => ({
            ...p,
            x: p.x + p.vx,
            y: p.y + p.vy,
            vy: p.vy + 0.5,
            life: p.life - deltaTime,
          }))
          .filter((p: Particle) => p.life > 0)
      );

      // Remove old slash effects
      setSlashEffects((prev: SlashEffect[]) => 
        prev.filter((s: SlashEffect) => now - s.timestamp < 200)
      );

      // Clear power-up if expired
      if (gameState.activePowerUp && now > gameState.powerUpEndTime) {
        setGameState((prev: GameState) => ({
          ...prev,
          activePowerUp: null,
        }));
      }

      // Clear canvas
      ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw slash effects
      slashEffects.forEach((slash: SlashEffect) => {
        const age = (now - slash.timestamp) / 200;
        ctx.strokeStyle = slash.color;
        ctx.lineWidth = 10 * (1 - age);
        ctx.globalAlpha = 1 - age;
        ctx.beginPath();
        ctx.moveTo(slash.startX, slash.startY);
        ctx.lineTo(slash.endX, slash.endY);
        ctx.stroke();
      });

      ctx.globalAlpha = 1;

      // Draw targets
      targets.forEach((target: Target) => {
        const age = (now - target.spawnTime) / 3000;
        const scale = Math.min(1, age * 3);
        const opacity = 1 - age;

        ctx.save();
        ctx.translate(target.x, target.y);
        
        if (target.type === 'hazard') {
          // Red hazard
          ctx.fillStyle = `rgba(255, 0, 0, ${opacity})`;
          ctx.shadowBlur = 20;
          ctx.shadowColor = '#ff0000';
        } else {
          // Blue target
          ctx.fillStyle = `rgba(0, 217, 255, ${opacity})`;
          ctx.shadowBlur = 20;
          ctx.shadowColor = playerProfile.glowColor;
        }
        
        ctx.beginPath();
        ctx.arc(0, 0, target.radius * scale, 0, Math.PI * 2);
        ctx.fill();

        // Inner circle
        ctx.fillStyle = `rgba(255, 255, 255, ${opacity * 0.3})`;
        ctx.beginPath();
        ctx.arc(0, 0, target.radius * scale * 0.5, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.restore();
      });

      // Draw power-ups
      powerUps.forEach((powerUp: PowerUp) => {
        const age = (now - powerUp.spawnTime) / 5000;
        const pulse = Math.sin(now / 200) * 0.2 + 1;
        const opacity = 1 - age;

        ctx.save();
        ctx.translate(powerUp.x, powerUp.y);
        ctx.scale(pulse, pulse);
        
        ctx.fillStyle = `rgba(255, 215, 0, ${opacity})`;
        ctx.shadowBlur = 30;
        ctx.shadowColor = '#ffd700';
        
        ctx.beginPath();
        ctx.arc(0, 0, powerUp.radius, 0, Math.PI * 2);
        ctx.fill();

        // Icon
        ctx.fillStyle = '#000';
        ctx.font = '20px bold sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const icon = powerUp.type === 'double' ? '×2' : powerUp.type === 'slowmo' ? '⏱' : '❄';
        ctx.fillText(icon, 0, 0);
        
        ctx.restore();
      });

      // Draw particles
      particles.forEach((particle: Particle) => {
        const opacity = particle.life / particle.maxLife;
        ctx.fillStyle = particle.color.replace(')', `, ${opacity})`).replace('rgb', 'rgba');
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fill();
      });

      gameLoopRef.current = requestAnimationFrame(gameLoop);
    };

    gameLoopRef.current = requestAnimationFrame(gameLoop);

    return (): void => {
      if (gameLoopRef.current) {
        cancelAnimationFrame(gameLoopRef.current);
      }
    };
  }, [gameState, targets, powerUps, particles, slashEffects, spawnTarget, spawnPowerUp, mode, playerProfile.glowColor]);

  const handleRetry = (): void => {
    setGameState({
      score: 0,
      combo: 0,
      maxCombo: 0,
      targetsHit: 0,
      targetsMissed: 0,
      timeRemaining: 60,
      isPlaying: true,
      isPaused: false,
      activePowerUp: null,
      powerUpEndTime: 0,
    });
    setTargets([]);
    setPowerUps([]);
    setParticles([]);
    setSlashEffects([]);
    setShowSummary(false);
    lastSpawnRef.current = 0;
    lastPowerUpRef.current = 0;
    speedMultiplierRef.current = 1;
  };

  const handleQuit = (): void => {
    const accuracy = gameState.targetsHit + gameState.targetsMissed > 0
      ? (gameState.targetsHit / (gameState.targetsHit + gameState.targetsMissed)) * 100
      : 0;
    onGameEnd(gameState.score, accuracy, gameState.maxCombo);
  };

  return (
    <div className="relative w-full h-full">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 touch-none"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
      />
      
      <GameHUD gameState={gameState} />
      
      {showSummary && (
        <EndGameSummary
          gameState={gameState}
          onRetry={handleRetry}
          onQuit={handleQuit}
        />
      )}
    </div>
  );
}
