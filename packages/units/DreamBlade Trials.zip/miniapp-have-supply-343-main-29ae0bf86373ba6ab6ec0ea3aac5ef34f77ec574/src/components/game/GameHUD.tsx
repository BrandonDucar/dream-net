'use client';

import type { ReactElement } from 'react';
import type { GameState } from '@/types/game';
import { Progress } from '@/components/ui/progress';

interface GameHUDProps {
  gameState: GameState;
}

export function GameHUD({ gameState }: GameHUDProps): ReactElement {
  const comboMultiplier = Math.min(Math.floor(gameState.combo / 5) + 1, 5);

  return (
    <div className="absolute top-0 left-0 right-0 p-4 pointer-events-none">
      <div className="flex justify-between items-start">
        {/* Left side - Score and Combo */}
        <div className="space-y-2">
          <div className="text-4xl font-bold text-white" style={{
            textShadow: '0 0 10px rgba(0, 217, 255, 0.8)'
          }}>
            {gameState.score.toLocaleString()}
          </div>
          
          {gameState.combo > 0 && (
            <div className="text-2xl font-bold" style={{
              color: comboMultiplier === 5 ? '#ff00ff' : '#00d9ff',
              textShadow: `0 0 10px ${comboMultiplier === 5 ? 'rgba(255, 0, 255, 0.8)' : 'rgba(0, 217, 255, 0.8)'}`
            }}>
              {gameState.combo}x COMBO
              {comboMultiplier > 1 && ` (${comboMultiplier}x)`}
            </div>
          )}
        </div>

        {/* Right side - Timer */}
        <div className="text-right space-y-2">
          <div className="text-3xl font-bold text-white" style={{
            textShadow: '0 0 10px rgba(0, 217, 255, 0.8)'
          }}>
            {Math.ceil(gameState.timeRemaining)}s
          </div>
          
          <Progress 
            value={(gameState.timeRemaining / 60) * 100} 
            className="w-32 h-2 bg-gray-800"
          />
        </div>
      </div>

      {/* Active Power-up indicator */}
      {gameState.activePowerUp && (
        <div className="absolute top-20 left-1/2 transform -translate-x-1/2">
          <div className="bg-yellow-500/20 border-2 border-yellow-400 rounded-lg px-6 py-2" style={{
            boxShadow: '0 0 20px rgba(255, 215, 0, 0.5)'
          }}>
            <div className="text-yellow-300 font-bold text-lg text-center">
              {gameState.activePowerUp === 'double' && '⚡ DOUBLE SCORE'}
              {gameState.activePowerUp === 'slowmo' && '⏱ SLOW MOTION'}
              {gameState.activePowerUp === 'freeze' && '❄ TIME FREEZE'}
            </div>
          </div>
        </div>
      )}

      {/* Mobile controls hint */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 md:hidden">
        <div className="text-gray-400 text-sm text-center">
          Swipe across targets to slash
        </div>
      </div>
    </div>
  );
}
