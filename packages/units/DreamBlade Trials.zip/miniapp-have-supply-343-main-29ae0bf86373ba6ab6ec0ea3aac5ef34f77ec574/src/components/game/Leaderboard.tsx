'use client';

import { useEffect, useState } from 'react';
import type { ReactElement } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface LeaderboardProps {
  playerScore: number;
  onBack: () => void;
}

interface LeaderboardEntry {
  rank: number;
  name: string;
  score: number;
  level: number;
  isPlayer?: boolean;
}

export function Leaderboard({ playerScore, onBack }: LeaderboardProps): ReactElement {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);

  useEffect(() => {
    // Generate AI-simulated leaderboard
    const aiNames = [
      'ShadowNinja_X',
      'BladeRunner99',
      'CyberSamurai',
      'NeonSlasher',
      'QuantumBlade',
      'VoidWalker',
      'StormCutter',
      'DarkPhoenix',
      'SilentStrike',
      'ChromeBlade',
    ];

    const generateScore = (rank: number): number => {
      return Math.floor(50000 - (rank * 3000) + Math.random() * 2000);
    };

    const aiEntries: LeaderboardEntry[] = aiNames.map((name: string, index: number) => ({
      rank: index + 1,
      name,
      score: generateScore(index + 1),
      level: Math.floor((generateScore(index + 1) / 1000) + 1),
    }));

    // Insert player if they have a score
    if (playerScore > 0) {
      const playerRank = aiEntries.findIndex((e: LeaderboardEntry) => e.score < playerScore);
      const playerEntry: LeaderboardEntry = {
        rank: playerRank === -1 ? aiEntries.length + 1 : playerRank + 1,
        name: 'You',
        score: playerScore,
        level: Math.floor(playerScore / 1000) + 1,
        isPlayer: true,
      };

      if (playerRank === -1) {
        aiEntries.push(playerEntry);
      } else {
        aiEntries.splice(playerRank, 0, playerEntry);
      }

      // Update ranks
      aiEntries.forEach((entry: LeaderboardEntry, index: number) => {
        entry.rank = index + 1;
      });
    }

    setEntries(aiEntries.slice(0, 10));
  }, [playerScore]);

  return (
    <div className="flex flex-col items-center justify-center h-full w-full px-4 pt-20 pb-8 overflow-y-auto">
      <div className="w-full max-w-2xl">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-white mb-2" style={{
            textShadow: '0 0 20px rgba(0, 217, 255, 0.8)'
          }}>
            Global Rankings
          </h2>
          <p className="text-gray-400">Top ninja warriors worldwide</p>
        </div>

        <Card className="bg-black/80 border-2 border-blue-500 mb-8" style={{
          boxShadow: '0 0 20px rgba(0, 217, 255, 0.3)'
        }}>
          <CardHeader>
            <CardTitle className="text-white text-center">Leaderboard</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {entries.map((entry: LeaderboardEntry) => (
                <div
                  key={`${entry.rank}-${entry.name}`}
                  className={`flex items-center justify-between p-3 rounded-lg transition-all ${
                    entry.isPlayer
                      ? 'bg-blue-900/50 border-2 border-blue-400'
                      : 'bg-gray-900/50 hover:bg-gray-800/50'
                  }`}
                  style={entry.isPlayer ? {
                    boxShadow: '0 0 15px rgba(0, 217, 255, 0.3)'
                  } : {}}
                >
                  <div className="flex items-center gap-4 flex-1">
                    <div className="w-8 text-center">
                      {entry.rank <= 3 ? (
                        <span className="text-2xl">
                          {entry.rank === 1 ? '🥇' : entry.rank === 2 ? '🥈' : '🥉'}
                        </span>
                      ) : (
                        <span className="text-gray-400 font-bold">{entry.rank}</span>
                      )}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className={`font-bold ${entry.isPlayer ? 'text-blue-300' : 'text-white'}`}>
                          {entry.name}
                        </span>
                        {entry.isPlayer && (
                          <Badge className="bg-blue-600 text-white text-xs">YOU</Badge>
                        )}
                      </div>
                      <div className="text-xs text-gray-500">Level {entry.level}</div>
                    </div>

                    <div className="text-right">
                      <div className="text-blue-300 font-bold">
                        {entry.score.toLocaleString()}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="text-center">
          <Button
            onClick={onBack}
            variant="outline"
            className="bg-black/50 border-blue-400 text-blue-300 hover:bg-blue-950/50"
          >
            Back to Menu
          </Button>
        </div>
      </div>
    </div>
  );
}
