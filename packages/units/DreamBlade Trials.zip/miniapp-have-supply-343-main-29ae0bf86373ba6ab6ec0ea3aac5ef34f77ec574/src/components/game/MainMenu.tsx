'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { ReactElement } from 'react';
import type { PlayerProfile, GameMode } from '@/types/game';

interface MainMenuProps {
  playerProfile: PlayerProfile;
  onStartGame: (mode: GameMode) => void;
  onShowGallery: () => void;
  onShowLeaderboard: () => void;
}

export function MainMenu({ 
  playerProfile, 
  onStartGame, 
  onShowGallery, 
  onShowLeaderboard 
}: MainMenuProps): ReactElement {
  return (
    <div className="flex flex-col items-center justify-center h-full w-full px-4 pt-16 pb-8">
      {/* Title */}
      <div className="text-center mb-8">
        <h1 className="text-6xl font-bold text-white mb-2" style={{
          textShadow: '0 0 20px rgba(0, 217, 255, 0.8), 0 0 40px rgba(0, 217, 255, 0.5)'
        }}>
          DreamBlade Trials
        </h1>
        <div className="text-xl text-blue-300 font-mono">$BLADE</div>
      </div>

      {/* Player Stats */}
      <Card className="bg-black/80 border-2 border-blue-500 mb-8 w-full max-w-md" style={{
        boxShadow: '0 0 20px rgba(0, 217, 255, 0.3)'
      }}>
        <CardHeader>
          <CardTitle className="text-white text-center">Ninja Profile</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-gray-300">Rank:</span>
            <Badge className="bg-blue-600 text-white border-blue-400" style={{
              boxShadow: '0 0 10px rgba(0, 217, 255, 0.5)'
            }}>
              {playerProfile.rank}
            </Badge>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-300">Level:</span>
            <span className="text-blue-300 font-bold">{playerProfile.level}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-300">Total Score:</span>
            <span className="text-blue-300 font-bold">{playerProfile.totalScore.toLocaleString()}</span>
          </div>
        </CardContent>
      </Card>

      {/* Mode Selection */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-2xl mb-6">
        <Button
          onClick={(): void => onStartGame('practice')}
          className="h-24 bg-gradient-to-br from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white text-lg font-bold border-2 border-blue-400"
          style={{
            boxShadow: '0 0 20px rgba(0, 217, 255, 0.4)'
          }}
        >
          <div className="text-center">
            <div>Practice Mode</div>
            <div className="text-sm font-normal opacity-80">No hazards, perfect your skill</div>
          </div>
        </Button>
        
        <Button
          onClick={(): void => onStartGame('trial')}
          className="h-24 bg-gradient-to-br from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white text-lg font-bold border-2 border-purple-400"
          style={{
            boxShadow: '0 0 20px rgba(168, 85, 247, 0.4)'
          }}
        >
          <div className="text-center">
            <div>Trial Mode</div>
            <div className="text-sm font-normal opacity-80">Hazards + speed ramp</div>
          </div>
        </Button>
      </div>

      {/* Secondary Options */}
      <div className="flex gap-4">
        <Button
          onClick={onShowGallery}
          variant="outline"
          className="bg-black/50 border-blue-400 text-blue-300 hover:bg-blue-950/50"
        >
          Blade Gallery
        </Button>
        
        <Button
          onClick={onShowLeaderboard}
          variant="outline"
          className="bg-black/50 border-blue-400 text-blue-300 hover:bg-blue-950/50"
        >
          Leaderboard
        </Button>
      </div>

      {/* Footer */}
      <div className="absolute bottom-4 text-center text-gray-500 text-sm">
        Swipe or tap targets to slash • Build combos • Avoid red hazards
      </div>
    </div>
  );
}
