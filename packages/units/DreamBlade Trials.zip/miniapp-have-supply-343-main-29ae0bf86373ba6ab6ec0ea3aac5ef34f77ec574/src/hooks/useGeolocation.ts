'use client';

import { useState, useEffect } from 'react';

interface GeolocationData {
  latitude: number | null;
  longitude: number | null;
  region: string | null;
  localBonus: number;
  error: string | null;
  loading: boolean;
}

export const useGeolocation = (): GeolocationData => {
  const [data, setData] = useState<GeolocationData>({
    latitude: null,
    longitude: null,
    region: null,
    localBonus: 0,
    error: null,
    loading: true,
  });

  useEffect(() => {
    if (!navigator.geolocation) {
      setData((prev: GeolocationData) => ({
        ...prev,
        error: 'Geolocation not supported',
        loading: false,
      }));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position: GeolocationPosition) => {
        const { latitude, longitude } = position.coords;

        try {
          const response = await fetch('/api/geofence', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ latitude, longitude }),
          });

          if (!response.ok) {
            throw new Error('Failed to fetch geofence data');
          }

          const geofenceData = await response.json() as {
            region: string;
            localBonus: number;
          };

          setData({
            latitude,
            longitude,
            region: geofenceData.region,
            localBonus: geofenceData.localBonus,
            error: null,
            loading: false,
          });
        } catch (err) {
          setData((prev: GeolocationData) => ({
            ...prev,
            latitude,
            longitude,
            error: 'Failed to process location',
            loading: false,
          }));
        }
      },
      (error: GeolocationPositionError) => {
        setData((prev: GeolocationData) => ({
          ...prev,
          error: error.message,
          loading: false,
        }));
      }
    );
  }, []);

  return data;
};
