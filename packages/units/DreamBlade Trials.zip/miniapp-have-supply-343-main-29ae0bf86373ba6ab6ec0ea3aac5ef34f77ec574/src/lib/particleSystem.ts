import type { Particle } from '@/types/game';

export const createParticleBurst = (
  x: number,
  y: number,
  color: string,
  count: number
): Particle[] => {
  const particles: Particle[] = [];
  
  for (let i = 0; i < count; i++) {
    const angle = (Math.PI * 2 * i) / count;
    const speed = Math.random() * 5 + 3;
    const vx = Math.cos(angle) * speed;
    const vy = Math.sin(angle) * speed;
    
    particles.push({
      id: `particle-${Date.now()}-${i}`,
      x,
      y,
      vx,
      vy,
      life: Math.random() * 0.5 + 0.5,
      maxLife: Math.random() * 0.5 + 0.5,
      color,
      size: Math.random() * 4 + 2,
    });
  }
  
  return particles;
};
