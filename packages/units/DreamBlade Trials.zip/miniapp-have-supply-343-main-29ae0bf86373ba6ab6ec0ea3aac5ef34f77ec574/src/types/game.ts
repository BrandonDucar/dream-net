export type GameMode = 'practice' | 'trial';

export type RankType = 'Initiate' | 'Striker' | 'Shadow Runner' | 'DreamBlade';

export interface PlayerProfile {
  totalScore: number;
  level: number;
  rank: RankType;
  unlockedBlades: string[];
  selectedBlade: string;
  glowColor: string;
}

export interface Target {
  id: string;
  x: number;
  y: number;
  type: 'normal' | 'hazard';
  points: number;
  radius: number;
  spawnTime: number;
}

export interface PowerUp {
  id: string;
  x: number;
  y: number;
  type: 'double' | 'slowmo' | 'freeze';
  radius: number;
  spawnTime: number;
}

export interface GameState {
  score: number;
  combo: number;
  maxCombo: number;
  targetsHit: number;
  targetsMissed: number;
  timeRemaining: number;
  isPlaying: boolean;
  isPaused: boolean;
  activePowerUp: string | null;
  powerUpEndTime: number;
}

export interface Particle {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

export interface SlashEffect {
  id: string;
  startX: number;
  startY: number;
  endX: number;
  endY: number;
  timestamp: number;
  color: string;
}
