'use client'
import type React, { useEffect } from 'react'
import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Slider } from '@/components/ui/slider'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Sparkles, Copy, Check } from 'lucide-react'
import { generateOptimizedVersions } from '@/lib/content-optimizer'
import type { OptimizedVersions, ContentType, ToneSettings } from '@/lib/content-optimizer'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DreamRankEngine(): React.ReactElement {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [step, setStep] = useState<number>(1)
  const [contentType, setContentType] = useState<ContentType>('post')
  const [inputText, setInputText] = useState<string>('')
  const [optimizedVersions, setOptimizedVersions] = useState<OptimizedVersions | null>(null)
  const [copiedId, setCopiedId] = useState<string>('')
  const [toneSettings, setToneSettings] = useState<ToneSettings>({
    funny: 50,
    serious: 50,
    inspirational: 50,
    mysterious: 50
  })

  const contentTypes: Array<{ value: ContentType; label: string }> = [
    { value: 'post', label: 'Social Post' },
    { value: 'caption', label: 'Caption' },
    { value: 'idea', label: 'Idea' },
    { value: 'headline', label: 'Headline' },
    { value: 'video-concept', label: 'Video Concept' },
    { value: 'product-description', label: 'Product Description' },
    { value: 'bio', label: 'Bio' },
    { value: 'script', label: 'Script' }
  ]

  const handleGenerate = (): void => {
    const versions = generateOptimizedVersions(inputText, contentType, toneSettings)
    setOptimizedVersions(versions)
    setStep(3)
  }

  const copyToClipboard = (text: string, id: string): void => {
    navigator.clipboard.writeText(text)
    setCopiedId(id)
    setTimeout(() => setCopiedId(''), 2000)
  }

  const resetFlow = (): void => {
    setStep(1)
    setInputText('')
    setOptimizedVersions(null)
    setCopiedId('')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8 md:mb-12">
          <div className="inline-flex items-center gap-3 mb-4">
            <Sparkles className="w-8 h-8 md:w-10 md:h-10 text-purple-400" style={{ filter: 'drop-shadow(0 0 8px rgba(168, 85, 247, 0.6))' }} />
            <h1 className="text-3xl md:text-5xl font-bold text-white" style={{ textShadow: '0 0 20px rgba(168, 85, 247, 0.5)' }}>
              DreamRank Engine
            </h1>
            <Badge className="bg-purple-600 text-white border-purple-400 text-sm md:text-base" style={{ boxShadow: '0 0 12px rgba(168, 85, 247, 0.4)' }}>
              $RANK
            </Badge>
          </div>
          <p className="text-purple-200 text-base md:text-lg max-w-2xl mx-auto">
            Boost your content's visibility and reach. Transform any message into engagement gold.
          </p>
        </div>

        {/* Main Content */}
        <div className="space-y-6">
          {/* Step 1: Choose Content Type */}
          {step === 1 && (
            <Card className="border-purple-600/30 bg-slate-900/50 backdrop-blur" style={{ boxShadow: '0 0 30px rgba(168, 85, 247, 0.15)' }}>
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <span className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-sm">1</span>
                  What do you want to improve?
                </CardTitle>
                <CardDescription className="text-purple-200">
                  Choose the type of content you'd like to optimize
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Select value={contentType} onValueChange={(value: string) => setContentType(value as ContentType)}>
                  <SelectTrigger className="w-full bg-slate-800 border-purple-600/30 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-purple-600/30">
                    {contentTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value} className="text-white">
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button 
                  onClick={() => setStep(2)} 
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                  style={{ boxShadow: '0 0 20px rgba(168, 85, 247, 0.3)' }}
                >
                  Continue
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Step 2: Enter Content */}
          {step === 2 && (
            <Card className="border-purple-600/30 bg-slate-900/50 backdrop-blur" style={{ boxShadow: '0 0 30px rgba(168, 85, 247, 0.15)' }}>
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <span className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-sm">2</span>
                  Paste your content
                </CardTitle>
                <CardDescription className="text-purple-200">
                  Enter the text you want to enhance
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="content-input" className="text-white">Your Content</Label>
                  <Textarea
                    id="content-input"
                    value={inputText}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setInputText(e.target.value)}
                    placeholder="Paste your content here..."
                    className="min-h-[200px] bg-slate-800 border-purple-600/30 text-white placeholder:text-purple-300/50"
                  />
                </div>

                {/* Tone Settings */}
                <div className="space-y-4 p-4 rounded-lg bg-slate-800/50 border border-purple-600/20">
                  <h3 className="text-white font-semibold text-sm">Adjust Tone (Optional)</h3>
                  
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <Label className="text-purple-200">Funny</Label>
                        <span className="text-purple-400">{toneSettings.funny}%</span>
                      </div>
                      <Slider
                        value={[toneSettings.funny]}
                        onValueChange={(value: number[]) => setToneSettings({ ...toneSettings, funny: value[0] })}
                        max={100}
                        step={10}
                        className="w-full"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <Label className="text-purple-200">Serious</Label>
                        <span className="text-purple-400">{toneSettings.serious}%</span>
                      </div>
                      <Slider
                        value={[toneSettings.serious]}
                        onValueChange={(value: number[]) => setToneSettings({ ...toneSettings, serious: value[0] })}
                        max={100}
                        step={10}
                        className="w-full"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <Label className="text-purple-200">Inspirational</Label>
                        <span className="text-purple-400">{toneSettings.inspirational}%</span>
                      </div>
                      <Slider
                        value={[toneSettings.inspirational]}
                        onValueChange={(value: number[]) => setToneSettings({ ...toneSettings, inspirational: value[0] })}
                        max={100}
                        step={10}
                        className="w-full"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <Label className="text-purple-200">Mysterious</Label>
                        <span className="text-purple-400">{toneSettings.mysterious}%</span>
                      </div>
                      <Slider
                        value={[toneSettings.mysterious]}
                        onValueChange={(value: number[]) => setToneSettings({ ...toneSettings, mysterious: value[0] })}
                        max={100}
                        step={10}
                        className="w-full"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button 
                    onClick={() => setStep(1)} 
                    variant="outline"
                    className="flex-1 border-purple-600/30 text-purple-200 hover:bg-purple-900/20"
                  >
                    Back
                  </Button>
                  <Button 
                    onClick={handleGenerate} 
                    disabled={!inputText.trim()}
                    className="flex-1 bg-purple-600 hover:bg-purple-700 text-white"
                    style={{ boxShadow: '0 0 20px rgba(168, 85, 247, 0.3)' }}
                  >
                    Generate Optimized Versions
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 3: Results */}
          {step === 3 && optimizedVersions && (
            <div className="space-y-6">
              <Card className="border-purple-600/30 bg-slate-900/50 backdrop-blur" style={{ boxShadow: '0 0 30px rgba(168, 85, 247, 0.15)' }}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-white flex items-center gap-2">
                        <span className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-sm">3</span>
                        Your Optimized Versions
                      </CardTitle>
                      <CardDescription className="text-purple-200">
                        Choose the version that fits your needs
                      </CardDescription>
                    </div>
                    <Button 
                      onClick={resetFlow}
                      variant="outline"
                      className="border-purple-600/30 text-purple-200 hover:bg-purple-900/20"
                    >
                      Start Over
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="core" className="w-full">
                    <TabsList className="w-full grid grid-cols-2 md:grid-cols-3 bg-slate-800/50 mb-6">
                      <TabsTrigger value="core" className="text-white">Core Versions</TabsTrigger>
                      <TabsTrigger value="platform" className="text-white">By Platform</TabsTrigger>
                      <TabsTrigger value="extras" className="text-white">Extras</TabsTrigger>
                    </TabsList>

                    {/* Core Versions */}
                    <TabsContent value="core" className="space-y-4">
                      <VersionCard
                        title="Cleaner Version"
                        description="Polished and professional"
                        content={optimizedVersions.cleaner}
                        id="cleaner"
                        copiedId={copiedId}
                        onCopy={copyToClipboard}
                      />
                      <VersionCard
                        title="High-Engagement Version"
                        description="Designed for maximum interaction"
                        content={optimizedVersions.highEngagement}
                        id="engagement"
                        copiedId={copiedId}
                        onCopy={copyToClipboard}
                      />
                      <VersionCard
                        title="Emotional Version"
                        description="Connects on a deeper level"
                        content={optimizedVersions.emotional}
                        id="emotional"
                        copiedId={copiedId}
                        onCopy={copyToClipboard}
                      />
                      <VersionCard
                        title="Bold/Viral Version"
                        description="Attention-grabbing and shareable"
                        content={optimizedVersions.viral}
                        id="viral"
                        copiedId={copiedId}
                        onCopy={copyToClipboard}
                      />
                      <VersionCard
                        title="Short Punchy Version"
                        description="Quick and impactful"
                        content={optimizedVersions.short}
                        id="short"
                        copiedId={copiedId}
                        onCopy={copyToClipboard}
                      />
                    </TabsContent>

                    {/* Platform-Specific */}
                    <TabsContent value="platform" className="space-y-4">
                      <VersionCard
                        title="Instagram"
                        description="Perfect for feed posts and stories"
                        content={optimizedVersions.platformSpecific.instagram}
                        id="instagram"
                        copiedId={copiedId}
                        onCopy={copyToClipboard}
                      />
                      <VersionCard
                        title="TikTok"
                        description="Optimized for short-form video"
                        content={optimizedVersions.platformSpecific.tiktok}
                        id="tiktok"
                        copiedId={copiedId}
                        onCopy={copyToClipboard}
                      />
                      <VersionCard
                        title="YouTube Shorts"
                        description="Hook viewers in seconds"
                        content={optimizedVersions.platformSpecific.youtubeShorts}
                        id="youtube"
                        copiedId={copiedId}
                        onCopy={copyToClipboard}
                      />
                      <VersionCard
                        title="X (Twitter)"
                        description="Thread-ready and concise"
                        content={optimizedVersions.platformSpecific.twitter}
                        id="twitter"
                        copiedId={copiedId}
                        onCopy={copyToClipboard}
                      />
                    </TabsContent>

                    {/* Extras */}
                    <TabsContent value="extras" className="space-y-4">
                      <ExtraCard
                        title="Hook Suggestions"
                        description="Start strong and capture attention"
                        items={optimizedVersions.extras.hooks}
                      />
                      <ExtraCard
                        title="Call-to-Action Ideas"
                        description="Drive your audience to take action"
                        items={optimizedVersions.extras.ctas}
                      />
                      <ExtraCard
                        title="Hashtag Suggestions"
                        description="Expand your reach"
                        items={optimizedVersions.extras.hashtags}
                      />
                      <Card className="bg-slate-800/50 border-purple-600/20">
                        <CardHeader>
                          <CardTitle className="text-white text-lg">Ideal Posting Time</CardTitle>
                          <CardDescription className="text-purple-200">
                            Best times to share for maximum visibility
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-white">{optimizedVersions.extras.postingTime}</p>
                        </CardContent>
                      </Card>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

interface VersionCardProps {
  title: string
  description: string
  content: string
  id: string
  copiedId: string
  onCopy: (text: string, id: string) => void
}

function VersionCard({ title, description, content, id, copiedId, onCopy }: VersionCardProps): React.ReactElement {
  return (
    <Card className="bg-slate-800/50 border-purple-600/20">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-white text-lg">{title}</CardTitle>
            <CardDescription className="text-purple-200">{description}</CardDescription>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() => onCopy(content, id)}
            className="border-purple-600/30 text-purple-200 hover:bg-purple-900/20"
          >
            {copiedId === id ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-white whitespace-pre-wrap">{content}</p>
      </CardContent>
    </Card>
  )
}

interface ExtraCardProps {
  title: string
  description: string
  items: string[]
}

function ExtraCard({ title, description, items }: ExtraCardProps): React.ReactElement {
  return (
    <Card className="bg-slate-800/50 border-purple-600/20">
      <CardHeader>
        <CardTitle className="text-white text-lg">{title}</CardTitle>
        <CardDescription className="text-purple-200">{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2">
          {items.map((item, index) => (
            <li key={index} className="text-white flex items-start gap-2">
              <span className="text-purple-400 mt-1">•</span>
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}
