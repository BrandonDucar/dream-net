export type ContentType = 
  | 'post' 
  | 'caption' 
  | 'idea' 
  | 'headline' 
  | 'video-concept' 
  | 'product-description' 
  | 'bio' 
  | 'script'

export interface ToneSettings {
  funny: number
  serious: number
  inspirational: number
  mysterious: number
}

export interface PlatformVersions {
  instagram: string
  tiktok: string
  youtubeShorts: string
  twitter: string
}

export interface OptimizedExtras {
  hooks: string[]
  ctas: string[]
  hashtags: string[]
  postingTime: string
}

export interface OptimizedVersions {
  cleaner: string
  highEngagement: string
  emotional: string
  viral: string
  short: string
  platformSpecific: PlatformVersions
  extras: OptimizedExtras
}

export function generateOptimizedVersions(
  text: string,
  contentType: ContentType,
  toneSettings: ToneSettings
): OptimizedVersions {
  const cleanedText = text.trim()
  const words = cleanedText.split(/\s+/)
  const wordCount = words.length

  // Cleaner version - remove extra punctuation, clean up spacing
  const cleaner = cleanText(cleanedText, contentType)

  // High-engagement version - add engaging elements
  const highEngagement = makeEngaging(cleanedText, contentType, toneSettings)

  // Emotional version - add emotional language
  const emotional = makeEmotional(cleanedText, contentType, toneSettings)

  // Viral version - bold, attention-grabbing
  const viral = makeViral(cleanedText, contentType, toneSettings)

  // Short version - condensed but punchy
  const short = makeShort(cleanedText, contentType, wordCount)

  // Platform-specific versions
  const platformSpecific: PlatformVersions = {
    instagram: optimizeForInstagram(cleanedText, contentType),
    tiktok: optimizeForTikTok(cleanedText, contentType),
    youtubeShorts: optimizeForYouTubeShorts(cleanedText, contentType),
    twitter: optimizeForTwitter(cleanedText, contentType, wordCount)
  }

  // Extras
  const extras: OptimizedExtras = {
    hooks: generateHooks(cleanedText, contentType, toneSettings),
    ctas: generateCTAs(contentType),
    hashtags: generateHashtags(cleanedText, contentType),
    postingTime: getIdealPostingTime(contentType)
  }

  return {
    cleaner,
    highEngagement,
    emotional,
    viral,
    short,
    platformSpecific,
    extras
  }
}

function cleanText(text: string, contentType: ContentType): string {
  // Remove excessive punctuation
  let cleaned = text.replace(/\.{3,}/g, '...')
  cleaned = cleaned.replace(/!{2,}/g, '!')
  cleaned = cleaned.replace(/\?{2,}/g, '?')
  
  // Fix spacing
  cleaned = cleaned.replace(/\s+/g, ' ')
  cleaned = cleaned.replace(/\s+([.,!?])/g, '$1')
  
  // Capitalize properly
  cleaned = cleaned.split('. ').map((sentence: string) => {
    return sentence.charAt(0).toUpperCase() + sentence.slice(1)
  }).join('. ')

  return cleaned
}

function makeEngaging(text: string, contentType: ContentType, toneSettings: ToneSettings): string {
  const questions = ['Have you ever wondered?', 'What if I told you?', 'Here is something interesting:']
  const engagers = ['You will not believe this:', 'This changed everything:', 'Pay attention to this:']
  
  let result = text
  
  // Add engaging opener if it doesn't have one
  if (!text.match(/^(Have you|What if|Here is|You will not|This|Did you|Imagine)/i)) {
    const opener = toneSettings.mysterious > 60 ? engagers[Math.floor(Math.random() * engagers.length)] : questions[0]
    result = `${opener} ${result}`
  }
  
  // Add emphasis
  result = result.replace(/\./g, '!')
  
  return result
}

function makeEmotional(text: string, contentType: ContentType, toneSettings: ToneSettings): string {
  const emotionalWords: Record<string, string> = {
    good: 'incredible',
    great: 'amazing',
    nice: 'wonderful',
    bad: 'devastating',
    hard: 'challenging',
    easy: 'effortless',
    new: 'groundbreaking',
    old: 'timeless',
    big: 'monumental',
    small: 'intimate'
  }

  let result = text
  
  // Replace words with emotional equivalents
  Object.entries(emotionalWords).forEach(([word, replacement]) => {
    const regex = new RegExp(`\\b${word}\\b`, 'gi')
    result = result.replace(regex, replacement)
  })

  // Add emotional framing
  if (toneSettings.inspirational > 60) {
    result = `This truly matters: ${result}`
  } else if (toneSettings.serious > 60) {
    result = `Here is the truth: ${result}`
  }

  return result
}

function makeViral(text: string, contentType: ContentType, toneSettings: ToneSettings): string {
  const viralOpeners = [
    '🚨 ATTENTION:',
    '⚡ BREAKING:',
    '🔥 HOT TAKE:',
    '💥 GAME CHANGER:',
    '🎯 TRUTH BOMB:'
  ]
  
  let result = text.toUpperCase()
  
  // Add viral opener
  const opener = viralOpeners[Math.floor(Math.random() * viralOpeners.length)]
  result = `${opener} ${result}`
  
  // Add urgency
  result = result.replace(/\./g, '!')
  
  // Add emojis strategically
  if (!result.includes('🔥')) {
    result = `${result} 🔥`
  }

  return result
}

function makeShort(text: string, contentType: ContentType, wordCount: number): string {
  const sentences = text.split(/[.!?]+/).filter((s: string) => s.trim().length > 0)
  
  // If already short, return as is
  if (wordCount <= 15) {
    return text
  }
  
  // Take first sentence or first ~15 words
  const firstSentence = sentences[0].trim()
  const firstWords = firstSentence.split(/\s+/).slice(0, 15).join(' ')
  
  return `${firstWords}...`
}

function optimizeForInstagram(text: string, contentType: ContentType): string {
  let result = text
  
  // Add line breaks for readability
  const sentences = result.split(/[.!?]+/).filter((s: string) => s.trim().length > 0)
  result = sentences.map((s: string) => s.trim()).join('.\n\n')
  
  // Add emoji
  result = `✨ ${result}`
  
  // Add engagement prompt
  result = `${result}\n\n💬 Drop your thoughts below!`
  
  return result
}

function optimizeForTikTok(text: string, contentType: ContentType): string {
  let result = text
  
  // Make it punchy and attention-grabbing
  result = `🎬 ${result}`
  
  // Add hook
  result = `Wait for it... ${result}`
  
  // Add trending style
  result = result.replace(/\./g, ' 👀')
  
  return result
}

function optimizeForYouTubeShorts(text: string, contentType: ContentType): string {
  let result = text
  
  // Add hook for video
  result = `⏱️ Quick tip: ${result}`
  
  // Add call to action
  result = `${result}\n\n🔔 Follow for more!`
  
  return result
}

function optimizeForTwitter(text: string, contentType: ContentType, wordCount: number): string {
  let result = text
  
  // Keep it concise (280 char limit)
  if (result.length > 250) {
    result = result.substring(0, 247) + '...'
  }
  
  // Add thread indicator if longer
  if (wordCount > 30) {
    result = `${result}\n\n🧵 Thread below 👇`
  }
  
  return result
}

function generateHooks(text: string, contentType: ContentType, toneSettings: ToneSettings): string[] {
  const hooks: string[] = []
  
  if (toneSettings.mysterious > 60) {
    hooks.push('What if everything you knew was wrong?')
    hooks.push('The secret nobody talks about...')
    hooks.push('This one thing changed everything.')
  } else if (toneSettings.funny > 60) {
    hooks.push('Plot twist: nobody saw this coming 😂')
    hooks.push('Okay but hear me out...')
    hooks.push('This is either genius or completely unhinged.')
  } else if (toneSettings.serious > 60) {
    hooks.push('Let us talk about what really matters.')
    hooks.push('The uncomfortable truth is...')
    hooks.push('Here is what they will not tell you.')
  } else {
    hooks.push('Ready to discover something amazing?')
    hooks.push('This will change how you think about things.')
    hooks.push('Pay attention to this.')
  }
  
  return hooks
}

function generateCTAs(contentType: ContentType): string[] {
  const ctas: string[] = [
    'Share this if you agree!',
    'Tag someone who needs to see this.',
    'Save this for later!',
    'Drop a comment with your thoughts!',
    'Follow for more insights like this.',
    'Try this and let me know how it goes!',
    'What is your take? Let us discuss below.'
  ]
  
  if (contentType === 'product-description') {
    ctas.push('Get yours today!', 'Limited time offer - do not miss out!')
  }
  
  return ctas
}

function generateHashtags(text: string, contentType: ContentType): string[] {
  const baseHashtags: string[] = ['#viral', '#trending', '#fyp', '#foryou', '#explore']
  
  const contentTypeHashtags: Record<ContentType, string[]> = {
    post: ['#socialmedia', '#content', '#engagement'],
    caption: ['#instagram', '#instapost', '#photography'],
    idea: ['#innovation', '#creativity', '#inspiration'],
    headline: ['#news', '#breaking', '#update'],
    'video-concept': ['#video', '#videocontent', '#creator'],
    'product-description': ['#product', '#shopping', '#musthave'],
    bio: ['#bio', '#about', '#profile'],
    script: ['#script', '#storytelling', '#content']
  }
  
  return [...baseHashtags.slice(0, 3), ...contentTypeHashtags[contentType]]
}

function getIdealPostingTime(contentType: ContentType): string {
  const times: Record<ContentType, string> = {
    post: 'Best times: Weekdays between 11am-1pm or 7pm-9pm when people are on breaks or winding down.',
    caption: 'Best times: Daily between 11am-1pm for lunch scrolling or 7pm-9pm for evening engagement.',
    idea: 'Best times: Early morning (6am-8am) when people are fresh, or late evening (8pm-10pm) for thoughtful browsing.',
    headline: 'Best times: Morning hours (7am-9am) for news consumption or lunch time (12pm-1pm).',
    'video-concept': 'Best times: Evenings (7pm-10pm) when people have time to watch, or weekends anytime.',
    'product-description': 'Best times: Lunch breaks (12pm-1pm) or evenings (7pm-9pm) when people shop online.',
    bio: 'Best times: Anytime, but update during high-traffic hours (11am-1pm, 7pm-9pm) for immediate visibility.',
    script: 'Best times: Early morning (6am-8am) or late evening (9pm-11pm) when audiences are receptive to longer content.'
  }
  
  return times[contentType]
}
