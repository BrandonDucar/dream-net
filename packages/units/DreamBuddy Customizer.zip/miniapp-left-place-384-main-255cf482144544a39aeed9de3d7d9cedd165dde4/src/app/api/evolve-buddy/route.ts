import { NextRequest, NextResponse } from 'next/server'
import { fluxKontextSubmit } from '@/fluxKontext'

interface EvolutionStage {
  name: string
  description: string
  prompt: string
}

const evolutionStages: EvolutionStage[] = [
  {
    name: 'Seed Form',
    description: 'The initial state, potential waiting to emerge',
    prompt: 'Transform this character into a seed form with crystalline pod structure, glowing core energy, dormant power visible through translucent shell, and subtle pulsing light patterns suggesting life within'
  },
  {
    name: 'Cocoon State',
    description: 'Metamorphosis in progress, energy building',
    prompt: 'Transform this character into a cocoon state with swirling energy patterns, partial transformation visible, glowing cracks showing power emerging, ethereal wisps of energy, and dynamic transition effects'
  },
  {
    name: 'Evolved Form',
    description: 'Full DreamNet evolution complete',
    prompt: 'Transform this character into a fully evolved ultimate form with radiant energy aura, perfected biomechanical enhancements, powerful stance, majestic presence, glowing patterns across body, and transcendent features showing complete transformation'
  }
]

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.json()
    const { imageUrl } = body

    if (!imageUrl) {
      return NextResponse.json(
        { error: 'Missing required field: imageUrl' },
        { status: 400 }
      )
    }

    const stages = []

    // Generate each evolution stage
    for (const stage of evolutionStages) {
      try {
        const result = await fluxKontextSubmit({
          prompt: stage.prompt,
          image_url: imageUrl,
          sync_mode: true,
          num_images: 1,
          aspect_ratio: '1:1',
          output_format: 'png',
          guidance_scale: 3.5
        })

        const images = result.data?.images || result.images || []
        
        if (images.length > 0) {
          stages.push({
            name: stage.name,
            description: stage.description,
            imageUrl: images[0].url
          })
        }
      } catch (stageError) {
        console.error(`Error generating ${stage.name}:`, stageError)
        // Continue to next stage even if one fails
      }
    }

    if (stages.length === 0) {
      return NextResponse.json(
        { error: 'Failed to generate evolution stages' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      success: true,
      stages
    })

  } catch (error) {
    console.error('Evolution error:', error)
    return NextResponse.json(
      { error: 'Evolution generation failed: ' + (error instanceof Error ? error.message : 'Unknown error') },
      { status: 500 }
    )
  }
}
