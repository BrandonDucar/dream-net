import { NextRequest, NextResponse } from 'next/server'
import { fluxKontextSubmit } from '@/fluxKontext'
import { styleOptions } from '@/components/StyleSelector'

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.json()
    const { imageUrl, style } = body

    if (!imageUrl || !style) {
      return NextResponse.json(
        { error: 'Missing required fields: imageUrl and style' },
        { status: 400 }
      )
    }

    // Find the style prompt
    const selectedStyle = styleOptions.find((s) => s.id === style)
    if (!selectedStyle) {
      return NextResponse.json(
        { error: 'Invalid style selected' },
        { status: 400 }
      )
    }

    // Transform the image using Flux Kontext
    const result = await fluxKontextSubmit({
      prompt: selectedStyle.prompt,
      image_url: imageUrl,
      sync_mode: true,
      num_images: 1,
      aspect_ratio: '1:1',
      output_format: 'png',
      guidance_scale: 3.5
    })

    // Extract images from response (handle both nested and root-level)
    const images = result.data?.images || result.images || []
    
    if (images.length === 0) {
      return NextResponse.json(
        { error: 'No images generated' },
        { status: 500 }
      )
    }

    // Return the transformed images
    const transformedImages = images.map((img) => img.url)

    return NextResponse.json({
      success: true,
      transformedImages,
      style: selectedStyle.name
    })

  } catch (error) {
    console.error('Transform error:', error)
    return NextResponse.json(
      { error: 'Transformation failed: ' + (error instanceof Error ? error.message : 'Unknown error') },
      { status: 500 }
    )
  }
}
