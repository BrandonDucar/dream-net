'use client'
import { useState, useEffect } from 'react'
import BuddyUploader from '@/components/BuddyUploader'
import StyleSelector from '@/components/StyleSelector'
import TransformationDisplay from '@/components/TransformationDisplay'
import EvolutionSequence from '@/components/EvolutionSequence'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Sparkles } from 'lucide-react'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DreamBuddyForge(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [uploadedImage, setUploadedImage] = useState<string>('')
  const [selectedStyle, setSelectedStyle] = useState<string>('')
  const [transformedImages, setTransformedImages] = useState<string[]>([])
  const [isTransforming, setIsTransforming] = useState<boolean>(false)
  const [evolutionMode, setEvolutionMode] = useState<boolean>(false)

  const handleImageUpload = (imageUrl: string): void => {
    setUploadedImage(imageUrl)
    setTransformedImages([])
    setSelectedStyle('')
  }

  const handleStyleSelect = async (style: string): Promise<void> => {
    if (!uploadedImage) return
    
    setSelectedStyle(style)
    setIsTransforming(true)
    setTransformedImages([])

    try {
      const response = await fetch('/api/transform-buddy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageUrl: uploadedImage,
          style: style,
          evolutionMode: evolutionMode
        })
      })

      if (!response.ok) {
        throw new Error('Transformation failed')
      }

      const data = await response.json()
      setTransformedImages(data.transformedImages || [])
    } catch (error) {
      console.error('Error transforming buddy:', error)
    } finally {
      setIsTransforming(false)
    }
  }

  return (
    <div className="min-h-screen bg-black text-white pt-16 pb-20 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Sparkles className="w-12 h-12 text-purple-400 mr-3" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
              DreamBuddy Forge
            </h1>
          </div>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Transform your Farcaster buddy into a DreamNet avatar. Choose from biomech armor, neon glow, creature modes, and more.
          </p>
          <div className="mt-4 inline-block bg-purple-900/30 px-4 py-2 rounded-full border border-purple-500/30">
            <span className="text-purple-300 font-mono text-sm">$DBUD • DreamNet Evolution Engine</span>
          </div>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="transform" className="w-full">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8">
            <TabsTrigger value="transform">Transform</TabsTrigger>
            <TabsTrigger value="evolve">Evolution Sequence</TabsTrigger>
          </TabsList>

          {/* Transform Tab */}
          <TabsContent value="transform" className="space-y-8">
            <div className="grid md:grid-cols-2 gap-8">
              {/* Upload Section */}
              <Card className="bg-gray-900 border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Upload Your Buddy</CardTitle>
                  <CardDescription className="text-gray-400">
                    Upload a Farcaster buddy image to start transforming
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <BuddyUploader onImageUpload={handleImageUpload} />
                  
                  {uploadedImage && (
                    <div className="mt-6">
                      <img 
                        src={uploadedImage} 
                        alt="Original Buddy" 
                        className="w-full rounded-lg border-2 border-purple-500/30"
                      />
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Style Selection */}
              <Card className="bg-gray-900 border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Choose Transformation</CardTitle>
                  <CardDescription className="text-gray-400">
                    Select a DreamNet style to transform your buddy
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <StyleSelector 
                    onStyleSelect={handleStyleSelect}
                    disabled={!uploadedImage || isTransforming}
                    selectedStyle={selectedStyle}
                  />
                </CardContent>
              </Card>
            </div>

            {/* Transformation Results */}
            {(transformedImages.length > 0 || isTransforming) && (
              <Card className="bg-gray-900 border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Your Transformed Buddy</CardTitle>
                  <CardDescription className="text-gray-400">
                    HD static, animated loop preview, and badge versions
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <TransformationDisplay 
                    images={transformedImages}
                    isLoading={isTransforming}
                    styleName={selectedStyle}
                  />
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Evolution Sequence Tab */}
          <TabsContent value="evolve" className="space-y-8">
            <Card className="bg-gray-900 border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-white">DreamNet Evolution</CardTitle>
                <CardDescription className="text-gray-400">
                  Watch your buddy evolve: Seed → Cocoon → Evolved Form
                </CardDescription>
              </CardHeader>
              <CardContent>
                <EvolutionSequence 
                  originalImage={uploadedImage}
                  onImageUpload={handleImageUpload}
                />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
