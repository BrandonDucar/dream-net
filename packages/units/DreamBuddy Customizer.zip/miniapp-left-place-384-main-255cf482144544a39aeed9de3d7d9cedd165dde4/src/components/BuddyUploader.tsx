'use client'

import { useState, useCallback } from 'react'
import { Upload, ImageIcon } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface BuddyUploaderProps {
  onImageUpload: (imageUrl: string) => void
}

export default function BuddyUploader({ onImageUpload }: BuddyUploaderProps): JSX.Element {
  const [isDragging, setIsDragging] = useState<boolean>(false)

  const handleFileChange = useCallback((file: File): void => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader()
      reader.onload = (e: ProgressEvent<FileReader>): void => {
        const result = e.target?.result
        if (typeof result === 'string') {
          onImageUpload(result)
        }
      }
      reader.readAsDataURL(file)
    }
  }, [onImageUpload])

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>): void => {
    e.preventDefault()
    setIsDragging(false)
    
    const file = e.dataTransfer.files[0]
    if (file) {
      handleFileChange(file)
    }
  }, [handleFileChange])

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>): void => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>): void => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>): void => {
    const file = e.target.files?.[0]
    if (file) {
      handleFileChange(file)
    }
  }, [handleFileChange])

  return (
    <div className="w-full">
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={`
          relative border-2 border-dashed rounded-lg p-12 text-center transition-all
          ${isDragging 
            ? 'border-purple-400 bg-purple-500/10' 
            : 'border-gray-700 hover:border-purple-500/50 bg-gray-800/50'
          }
        `}
      >
        <input
          type="file"
          accept="image/*"
          onChange={handleInputChange}
          className="hidden"
          id="buddy-upload"
        />
        
        <label htmlFor="buddy-upload" className="cursor-pointer">
          <div className="flex flex-col items-center gap-4">
            {isDragging ? (
              <Upload className="w-16 h-16 text-purple-400 animate-bounce" />
            ) : (
              <ImageIcon className="w-16 h-16 text-gray-500" />
            )}
            
            <div>
              <p className="text-lg font-medium text-white mb-2">
                Drop your Farcaster buddy here
              </p>
              <p className="text-sm text-gray-400">
                or click to browse
              </p>
            </div>
            
            <Button 
              type="button" 
              variant="outline" 
              className="mt-4 border-purple-500/50 hover:bg-purple-500/20"
            >
              Choose Image
            </Button>
          </div>
        </label>
      </div>
    </div>
  )
}
