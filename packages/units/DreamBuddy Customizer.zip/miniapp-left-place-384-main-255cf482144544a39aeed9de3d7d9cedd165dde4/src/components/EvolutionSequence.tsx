'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Loader2, ArrowRight, Sparkles } from 'lucide-react'
import BuddyUploader from '@/components/BuddyUploader'

interface EvolutionSequenceProps {
  originalImage: string
  onImageUpload: (imageUrl: string) => void
}

interface EvolutionStage {
  name: string
  description: string
  imageUrl: string
}

export default function EvolutionSequence({ originalImage, onImageUpload }: EvolutionSequenceProps): JSX.Element {
  const [isGenerating, setIsGenerating] = useState<boolean>(false)
  const [evolutionStages, setEvolutionStages] = useState<EvolutionStage[]>([])

  const generateEvolution = async (): Promise<void> => {
    if (!originalImage) return

    setIsGenerating(true)
    setEvolutionStages([])

    try {
      const response = await fetch('/api/evolve-buddy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageUrl: originalImage })
      })

      if (!response.ok) {
        throw new Error('Evolution generation failed')
      }

      const data = await response.json()
      setEvolutionStages(data.stages || [])
    } catch (error) {
      console.error('Error generating evolution:', error)
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="space-y-8">
      {!originalImage ? (
        <BuddyUploader onImageUpload={onImageUpload} />
      ) : (
        <>
          <div className="flex flex-col items-center gap-6">
            <div className="text-center">
              <h3 className="text-2xl font-bold text-white mb-2">Evolution Sequence</h3>
              <p className="text-gray-400">
                Watch your buddy transform through DreamNet stages
              </p>
            </div>

            <Button
              onClick={generateEvolution}
              disabled={isGenerating}
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating Evolution...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Start Evolution
                </>
              )}
            </Button>
          </div>

          {isGenerating && (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="w-12 h-12 text-purple-400 animate-spin mb-4" />
              <p className="text-gray-400">Forging evolution stages...</p>
            </div>
          )}

          {evolutionStages.length > 0 && (
            <div className="grid md:grid-cols-3 gap-6">
              {evolutionStages.map((stage: EvolutionStage, index: number) => (
                <div key={index} className="relative">
                  <div className="bg-gray-800/50 rounded-lg p-4 border-2 border-purple-500/30">
                    <div className="aspect-square rounded-lg overflow-hidden mb-4 border border-purple-500/20">
                      <img 
                        src={stage.imageUrl} 
                        alt={stage.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    
                    <div className="text-center">
                      <h4 className="text-lg font-semibold text-white mb-2">
                        {stage.name}
                      </h4>
                      <p className="text-sm text-gray-400">
                        {stage.description}
                      </p>
                    </div>
                  </div>
                  
                  {index < evolutionStages.length - 1 && (
                    <div className="hidden md:block absolute top-1/2 -right-3 transform -translate-y-1/2 z-10">
                      <ArrowRight className="w-6 h-6 text-purple-400" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {evolutionStages.length === 0 && !isGenerating && (
            <div className="text-center py-12 bg-gray-800/30 rounded-lg border border-gray-700">
              <p className="text-gray-400">
                Click "Start Evolution" to generate your buddy's transformation sequence
              </p>
            </div>
          )}
        </>
      )}
    </div>
  )
}
