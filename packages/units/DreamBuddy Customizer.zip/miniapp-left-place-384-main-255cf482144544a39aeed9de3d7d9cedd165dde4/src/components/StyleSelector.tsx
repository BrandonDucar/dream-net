'use client'

import { Button } from '@/components/ui/button'
import { Zap, Sparkles, Dna, Shield, Skull, Minimize2, Flame, Fish } from 'lucide-react'

interface StyleSelectorProps {
  onStyleSelect: (style: string) => void
  disabled: boolean
  selectedStyle: string
}

interface StyleOption {
  id: string
  name: string
  description: string
  icon: React.ElementType
  prompt: string
}

const styleOptions: StyleOption[] = [
  {
    id: 'biomech',
    name: 'Biomech Armor',
    description: 'DreamNet biomechanical armor upgrade',
    icon: Shield,
    prompt: 'Transform this character into a biomechanical cyborg with sleek metallic armor plating, glowing circuit patterns, mechanical joints, and futuristic tech enhancements while maintaining the original character silhouette and personality'
  },
  {
    id: 'neon',
    name: 'Neon Glow',
    description: 'DreamScope neon energy aura',
    icon: Zap,
    prompt: 'Add vibrant neon glowing effects to this character with bright cyan and magenta energy trails, holographic overlays, luminous outlines, and electric aura while keeping the character recognizable'
  },
  {
    id: 'dreamsnail',
    name: 'DreamSnail Aura',
    description: 'Mystical spiral energy field',
    icon: Sparkles,
    prompt: 'Surround this character with a mystical spiral energy aura featuring ethereal swirling patterns, cosmic dust particles, magical glowing symbols, and dreamlike flowing energy trails in purple and blue hues'
  },
  {
    id: 'dna',
    name: 'Triple-Helix DNA',
    description: 'Genetic evolution suit',
    icon: Dna,
    prompt: 'Transform this character with a triple-helix DNA bio-suit showing genetic code patterns, molecular structures, evolving organic textures, and bioluminescent genetic markers integrated into the design'
  },
  {
    id: 'tiger',
    name: 'Tiger Mode',
    description: 'Fierce feline transformation',
    icon: Skull,
    prompt: 'Transform this character into a tiger-inspired warrior with orange and black striped patterns, fierce feline features, powerful claws, sharp teeth, and predatory eyes while maintaining the base character structure'
  },
  {
    id: 'dragon',
    name: 'Dragon Mode',
    description: 'Mythical dragon evolution',
    icon: Flame,
    prompt: 'Transform this character into a dragon hybrid with scales, wings, horns, glowing eyes, fire energy emanating from body, mythical dragon features, and majestic presence'
  },
  {
    id: 'squid',
    name: 'Squid Mode',
    description: 'Deep sea creature form',
    icon: Fish,
    prompt: 'Transform this character into a squid-inspired being with tentacles, bioluminescent patterns, aquatic features, flowing movements suggested in the design, and deep ocean aesthetics'
  },
  {
    id: 'badge',
    name: 'Minimalist Badge',
    description: 'Clean identity badge version',
    icon: Minimize2,
    prompt: 'Simplify this character into a clean minimalist badge design with bold lines, simplified shapes, solid colors, iconic silhouette, and professional avatar style suitable for profile pictures'
  }
]

export default function StyleSelector({ onStyleSelect, disabled, selectedStyle }: StyleSelectorProps): JSX.Element {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      {styleOptions.map((style: StyleOption) => {
        const Icon = style.icon
        const isSelected = selectedStyle === style.id
        
        return (
          <Button
            key={style.id}
            onClick={() => onStyleSelect(style.id)}
            disabled={disabled}
            variant={isSelected ? 'default' : 'outline'}
            className={`
              h-auto py-4 px-4 flex flex-col items-start gap-2 text-left transition-all
              ${isSelected 
                ? 'bg-purple-600 hover:bg-purple-700 border-purple-400' 
                : 'bg-gray-800/50 hover:bg-gray-700/50 border-gray-700'
              }
              ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
            `}
          >
            <div className="flex items-center gap-2 w-full">
              <Icon className={`w-5 h-5 ${isSelected ? 'text-white' : 'text-purple-400'}`} />
              <span className="font-semibold text-white">{style.name}</span>
            </div>
            <p className={`text-xs ${isSelected ? 'text-purple-100' : 'text-gray-400'}`}>
              {style.description}
            </p>
          </Button>
        )
      })}
    </div>
  )
}

export { styleOptions }
