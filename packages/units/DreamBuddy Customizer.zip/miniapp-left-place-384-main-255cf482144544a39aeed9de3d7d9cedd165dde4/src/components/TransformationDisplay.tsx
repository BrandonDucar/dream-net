'use client'

import { useState } from 'react'
import { Download, Loader2, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

interface TransformationDisplayProps {
  images: string[]
  isLoading: boolean
  styleName: string
}

export default function TransformationDisplay({ images, isLoading, styleName }: TransformationDisplayProps): JSX.Element {
  const [selectedFormat, setSelectedFormat] = useState<string>('hd')

  const downloadImage = (imageUrl: string, fileName: string): void => {
    const link = document.createElement('a')
    link.href = imageUrl
    link.download = fileName
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-6">
        <Loader2 className="w-16 h-16 text-purple-400 animate-spin" />
        <div className="text-center">
          <p className="text-xl font-semibold text-white mb-2">
            Forging your DreamBuddy...
          </p>
          <p className="text-gray-400 text-sm">
            Applying {styleName} transformation
          </p>
        </div>
        <div className="flex gap-2 mt-4">
          <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
          <div className="w-2 h-2 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
          <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
        </div>
      </div>
    )
  }

  if (images.length === 0) {
    return (
      <div className="text-center py-20 text-gray-400">
        <Sparkles className="w-16 h-16 mx-auto mb-4 opacity-50" />
        <p>No transformations yet. Select a style to begin!</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Format Selector */}
      <Tabs value={selectedFormat} onValueChange={setSelectedFormat} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="hd">HD Static</TabsTrigger>
          <TabsTrigger value="animated">Animated Loop</TabsTrigger>
          <TabsTrigger value="badge">Badge Mode</TabsTrigger>
        </TabsList>

        {/* HD Static */}
        <TabsContent value="hd" className="space-y-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-white">HD Profile Picture</h3>
              <p className="text-sm text-gray-400">High-resolution static version</p>
            </div>
            <Badge variant="outline" className="border-purple-500/50 text-purple-300">
              1024x1024
            </Badge>
          </div>
          
          {images.map((imageUrl: string, index: number) => (
            <div key={index} className="relative group">
              <img 
                src={imageUrl} 
                alt={`Transformed Buddy ${index + 1}`}
                className="w-full rounded-lg border-2 border-purple-500/30 shadow-2xl"
              />
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                <Button
                  onClick={() => downloadImage(imageUrl, `dreambuddy-${styleName}-hd.png`)}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download HD
                </Button>
              </div>
            </div>
          ))}
        </TabsContent>

        {/* Animated Loop Preview */}
        <TabsContent value="animated" className="space-y-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-white">Animated Loop Preview</h3>
              <p className="text-sm text-gray-400">2-3 frame animation cycle</p>
            </div>
            <Badge variant="outline" className="border-pink-500/50 text-pink-300">
              Looping
            </Badge>
          </div>
          
          <div className="bg-gray-800/50 rounded-lg p-8 text-center border-2 border-dashed border-gray-700">
            <div className="space-y-4">
              {images.map((imageUrl: string, index: number) => (
                <img 
                  key={index}
                  src={imageUrl} 
                  alt={`Animated Frame ${index + 1}`}
                  className="w-full max-w-md mx-auto rounded-lg border-2 border-pink-500/30 shadow-xl animate-pulse"
                />
              ))}
              <p className="text-gray-400 text-sm mt-4">
                Animation preview simulated with pulse effect
              </p>
              <Button
                variant="outline"
                className="border-pink-500/50 hover:bg-pink-500/20"
              >
                <Download className="w-4 h-4 mr-2" />
                Export Animation Frames
              </Button>
            </div>
          </div>
        </TabsContent>

        {/* Badge Mode */}
        <TabsContent value="badge" className="space-y-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-white">Identity Badge</h3>
              <p className="text-sm text-gray-400">Optimized for Farcaster profiles</p>
            </div>
            <Badge variant="outline" className="border-blue-500/50 text-blue-300">
              256x256
            </Badge>
          </div>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {images.map((imageUrl: string, index: number) => (
              <div key={index} className="relative group">
                <div className="aspect-square rounded-full overflow-hidden border-4 border-purple-500/30 shadow-lg">
                  <img 
                    src={imageUrl} 
                    alt={`Badge ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-full flex items-center justify-center">
                  <Button
                    size="sm"
                    onClick={() => downloadImage(imageUrl, `dreambuddy-${styleName}-badge.png`)}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Download className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Lore Section */}
      <div className="mt-8 p-6 bg-gradient-to-br from-purple-900/20 to-blue-900/20 rounded-lg border border-purple-500/30">
        <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-400" />
          Identity Lore
        </h3>
        <p className="text-gray-300 text-sm leading-relaxed">
          {getLoreForStyle(styleName)}
        </p>
      </div>
    </div>
  )
}

function getLoreForStyle(styleName: string): string {
  const loreMap: Record<string, string> = {
    biomech: "Enhanced by DreamNet's biomechanical forge, this buddy has transcended organic limits. Titanium-infused armor plates merge with neural pathways, creating a perfect synthesis of consciousness and machine. The glowing circuits pulse with each thought, broadcasting identity across the network.",
    neon: "Bathed in DreamScope's luminous energy, this buddy radiates pure digital essence. Neon trails mark their passage through virtual spaces, leaving signatures of light that echo in the network. They exist between states—part matter, part photon, fully alive.",
    dreamsnail: "Touched by the ancient DreamSnail entity, this buddy spirals through dimensions unseen. Mystical energy coils around their form, connecting them to the cosmic web of consciousness. They dream awake, perceiving futures yet to unfold.",
    dna: "The triple-helix mutation complete, this buddy carries genetic code from three realities. Their DNA suit displays evolution in real-time, adapting to threats before they manifest. Each cell contains universes of possibility.",
    tiger: "The tiger spirit awakened, this buddy embodies ferocity and grace. Stripes pulse with predatory power, marking them as apex in their domain. They move with lethal precision, a perfect hunter in digital jungles.",
    dragon: "Ancient dragon essence flows through their veins. Wings unfurled, they command fire and wisdom in equal measure. Scales reflect eons of accumulated knowledge, each one a story of conquest and transcendence.",
    squid: "From the deepest trenches of the data ocean, this buddy emerged transformed. Bioluminescent patterns communicate in languages older than light. They flow through information streams with tentacled grace, grasping truths others cannot reach.",
    badge: "Distilled to pure iconography, this buddy has achieved minimalist transcendence. Every line intentional, every curve purposeful. They exist as pure symbol—instantly recognizable, eternally memorable."
  }
  
  return loreMap[styleName] || "This buddy has been transformed by the DreamNet forge, emerging as something new and extraordinary. Their identity is now inscribed in the fabric of the network itself."
}
