/**
 * ================================================================================
 * DO NOT MODIFY THIS FILE. This file is READ ONLY and is DETERMINISTIC.
 * FAL Flux Kontext [pro] v1.0 — Strict, Typed, and Agent-Ready API
 * ================================================================================
 */

export type AspectRatio =
  | '21:9'
  | '16:9'
  | '4:3'
  | '3:2'
  | '1:1'
  | '2:3'
  | '3:4'
  | '9:16'
  | '9:21';
export type OutputFormat = 'jpeg' | 'png';
export type SafetyTolerance = '1' | '2' | '3' | '4' | '5' | '6';

export interface FluxKontextRequestInput {
  // Required
  prompt: string;
  image_url: string; // Can be a public URL or Base64 data URI (e.g., "data:image/jpeg;base64,...")

  // Optional
  seed?: number;
  guidance_scale?: number;
  sync_mode?: boolean;
  num_images?: number;
  safety_tolerance?: SafetyTolerance;
  output_format?: OutputFormat;
  aspect_ratio?: AspectRatio;
}

export interface GeneratedImage {
  url: string;
  content_type?: string;
  width?: number;
  height?: number;
}

export interface FluxKontextResponse {
  data?: {
    images: GeneratedImage[];
    timings: Record<string, never>;
    seed: number;
    has_nsfw_concepts: boolean[];
    prompt: string;
  };
  images?: GeneratedImage[]; // Added to support root-level images array
  requestId: string;
}

/**
 * Internal utility: throws if response has any error or missing data, with logging.
 */
function _throwIfError(res: any) {
  console.log('API Response:', res); // Debug logging
  const images = res.data?.images || res.images;
  if (!res || !images || !Array.isArray(images) || images.length === 0) {
    throw new Error('No edited image returned from API. Response: ' + JSON.stringify(res));
  }
  if (res.error) throw new Error('API error: ' + res.error);
}

/**
 * Internal utility: all Flux Kontext API calls must go through this proxy.
 */
async function _proxyFluxKontext<T = any>(options: {
  body?: any;
  path?: string;
  method?: string;
}): Promise<T> {
  const { body, path = '/fal-ai/flux-pro/kontext', method = 'POST' } = options;
  const headers: Record<string, string> = {
    'accept': 'application/json',
    'content-type': 'application/json',
    'authorization': `Key ${process.env.FAL_KEY || 'secret_cmcm3j2ks00003b7ikbgtdo1w'}`,
  };
  const payload = {
    protocol: 'https',
    origin: 'fal.run',
    path,
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  };

  console.log('Proxy Payload:', payload); // Debug logging
  const res = await fetch('/api/proxy', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  console.log('Proxy Response:', data); // Debug logging
  if (!res.ok) throw new Error(`Proxy request failed with status ${res.status}: ${JSON.stringify(data)}`);
  return data;
}

/**
 * Submits a new Flux Kontext image editing job and waits for completion.
 */
export async function fluxKontextSubmit(
  input: FluxKontextRequestInput
): Promise<FluxKontextResponse> {
  if (!input?.prompt || typeof input.prompt !== 'string' || !input.prompt.trim()) {
    throw new Error('Prompt is required and must be a non-empty string.');
  }
  if (!input?.image_url || typeof input.image_url !== 'string' || !input.image_url.trim()) {
    throw new Error('Image URL is required and must be a non-empty string.');
  }
  const isBase64 = input.image_url.startsWith('data:image/');
  if (!isBase64 && !input.image_url.startsWith('http://') && !input.image_url.startsWith('https://')) {
    throw new Error('image_url must be a valid URL or Base64 data URI.');
  }

  const result = await _proxyFluxKontext<FluxKontextResponse>({ body: input });
  _throwIfError(result);
  return result;
}

/**
 * Submits a Flux Kontext job to the queue and returns the request ID.
 */
export async function fluxKontextQueueSubmit(
  input: FluxKontextRequestInput
): Promise<{ request_id: string }> {
  if (!input?.prompt || typeof input.prompt !== 'string' || !input.prompt.trim()) {
    throw new Error('Prompt is required and must be a non-empty string.');
  }
  if (!input?.image_url || typeof input.image_url !== 'string' || !input.image_url.trim()) {
    throw new Error('Image URL is required and must be a non-empty string.');
  }
  const isBase64 = input.image_url.startsWith('data:image/');
  if (!isBase64 && !input.image_url.startsWith('http://') && !input.image_url.startsWith('https://')) {
    throw new Error('image_url must be a valid URL or Base64 data URI.');
  }

  const result = await _proxyFluxKontext({
    body: { ...input, webhookUrl: process.env.WEBHOOK_URL || undefined },
    path: '/fal-ai/flux-pro/kontext/submit',
  });
  if (!result.request_id) throw new Error('Invalid response: missing request_id. Response: ' + JSON.stringify(result));
  return { request_id: result.request_id };
}

/**
 * Fetches the status of a queued Flux Kontext job.
 */
export async function fluxKontextQueueStatus(requestId: string): Promise<any> {
  if (!requestId || typeof requestId !== 'string' || !requestId.trim()) {
    throw new Error('Request ID is required and must be a non-empty string.');
  }

  return await _proxyFluxKontext({
    path: `/fal-ai/flux-pro/kontext/status?requestId=${requestId}`,
    method: 'GET',
  });
}

/**
 * Fetches the result of a completed Flux Kontext job.
 */
export async function fluxKontextQueueResult(
  requestId: string
): Promise<FluxKontextResponse> {
  if (!requestId || typeof requestId !== 'string' || !requestId.trim()) {
    throw new Error('Request ID is required and must be a non-empty string.');
  }

  const result = await _proxyFluxKontext({
    path: `/fal-ai/flux-pro/kontext/result?requestId=${requestId}`,
    method: 'GET',
  });
  _throwIfError(result);
  return result;
}