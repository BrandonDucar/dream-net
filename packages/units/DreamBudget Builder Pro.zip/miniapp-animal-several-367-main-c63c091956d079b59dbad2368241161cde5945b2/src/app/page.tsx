'use client'
import { useState, useEffect } from 'react';
import { BudgetForm } from '@/components/budget-form';
import { BudgetSummary } from '@/components/budget-summary';
import { WeeklySummary } from '@/components/weekly-summary';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, Wallet } from 'lucide-react';
import { calculateBudgetAnalysis } from '@/lib/budget-calculator';
import type { BudgetData, BudgetAnalysis } from '@/types/budget';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Home(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [budgetData, setBudgetData] = useState<BudgetData | null>(null);
  const [analysis, setAnalysis] = useState<BudgetAnalysis | null>(null);
  const [showResults, setShowResults] = useState<boolean>(false);

  const handleBudgetSubmit = (data: BudgetData): void => {
    const calculatedAnalysis = calculateBudgetAnalysis(data);
    setBudgetData(data);
    setAnalysis(calculatedAnalysis);
    setShowResults(true);
  };

  const handleReset = (): void => {
    setBudgetData(null);
    setAnalysis(null);
    setShowResults(false);
  };

  return (
    <main className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Wallet className="h-10 w-10 text-green-600" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
              DreamBudget Builder
            </h1>
          </div>
          <p className="text-lg text-muted-foreground mb-2">
            Build your perfect budget and take control of your finances
          </p>
          <p className="text-sm font-mono text-green-600 dark:text-green-400">$BUD</p>
        </div>

        {!showResults ? (
          <div className="max-w-3xl mx-auto">
            <BudgetForm onSubmit={handleBudgetSubmit} />
          </div>
        ) : budgetData && analysis ? (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <Button onClick={handleReset} variant="outline">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Start Over
              </Button>
              <div className="text-sm text-muted-foreground">
                Your personalized budget analysis
              </div>
            </div>

            <Tabs defaultValue="summary" className="w-full">
              <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
                <TabsTrigger value="summary">Monthly Summary</TabsTrigger>
                <TabsTrigger value="weekly">Weekly Breakdown</TabsTrigger>
              </TabsList>

              <TabsContent value="summary" className="mt-6">
                <BudgetSummary data={budgetData} analysis={analysis} />
              </TabsContent>

              <TabsContent value="weekly" className="mt-6">
                <WeeklySummary weeklyBreakdown={analysis.weeklyBreakdown} />
              </TabsContent>
            </Tabs>
          </div>
        ) : null}

        {/* Footer */}
        <div className="mt-12 text-center text-sm text-muted-foreground">
          <p>Built with ❤️ for smarter financial decisions</p>
        </div>
      </div>
    </main>
  );
}
