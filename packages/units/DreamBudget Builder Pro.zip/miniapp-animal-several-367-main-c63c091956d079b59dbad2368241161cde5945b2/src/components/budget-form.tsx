'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Trash2, Plus } from 'lucide-react';
import type { BudgetData, BillItem, SpendingCategory, SavingsGoal, DebtItem } from '@/types/budget';

interface BudgetFormProps {
  onSubmit: (data: BudgetData) => void;
}

export function BudgetForm({ onSubmit }: BudgetFormProps): JSX.Element {
  const [monthlyIncome, setMonthlyIncome] = useState<string>('');
  const [bills, setBills] = useState<BillItem[]>([{ id: '1', name: '', amount: 0 }]);
  const [spendingCategories, setSpendingCategories] = useState<SpendingCategory[]>([
    { id: '1', name: '', amount: 0, isNeed: false }
  ]);
  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>([
    { id: '1', name: '', targetAmount: 0, monthlyContribution: 0 }
  ]);
  const [debts, setDebts] = useState<DebtItem[]>([]);

  const handleAddBill = (): void => {
    setBills([...bills, { id: Date.now().toString(), name: '', amount: 0 }]);
  };

  const handleRemoveBill = (id: string): void => {
    setBills(bills.filter(bill => bill.id !== id));
  };

  const handleBillChange = (id: string, field: keyof BillItem, value: string | number): void => {
    setBills(bills.map(bill => 
      bill.id === id ? { ...bill, [field]: value } : bill
    ));
  };

  const handleAddCategory = (): void => {
    setSpendingCategories([
      ...spendingCategories,
      { id: Date.now().toString(), name: '', amount: 0, isNeed: false }
    ]);
  };

  const handleRemoveCategory = (id: string): void => {
    setSpendingCategories(spendingCategories.filter(cat => cat.id !== id));
  };

  const handleCategoryChange = (id: string, field: keyof SpendingCategory, value: string | number | boolean): void => {
    setSpendingCategories(spendingCategories.map(cat =>
      cat.id === id ? { ...cat, [field]: value } : cat
    ));
  };

  const handleAddSavingsGoal = (): void => {
    setSavingsGoals([
      ...savingsGoals,
      { id: Date.now().toString(), name: '', targetAmount: 0, monthlyContribution: 0 }
    ]);
  };

  const handleRemoveSavingsGoal = (id: string): void => {
    setSavingsGoals(savingsGoals.filter(goal => goal.id !== id));
  };

  const handleSavingsGoalChange = (id: string, field: keyof SavingsGoal, value: string | number): void => {
    setSavingsGoals(savingsGoals.map(goal =>
      goal.id === id ? { ...goal, [field]: value } : goal
    ));
  };

  const handleAddDebt = (): void => {
    setDebts([
      ...debts,
      { id: Date.now().toString(), name: '', balance: 0, interestRate: 0, minimumPayment: 0 }
    ]);
  };

  const handleRemoveDebt = (id: string): void => {
    setDebts(debts.filter(debt => debt.id !== id));
  };

  const handleDebtChange = (id: string, field: keyof DebtItem, value: string | number): void => {
    setDebts(debts.map(debt =>
      debt.id === id ? { ...debt, [field]: value } : debt
    ));
  };

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    
    const budgetData: BudgetData = {
      monthlyIncome: parseFloat(monthlyIncome) || 0,
      bills: bills.filter(bill => bill.name && bill.amount > 0),
      spendingCategories: spendingCategories.filter(cat => cat.name && cat.amount > 0),
      savingsGoals: savingsGoals.filter(goal => goal.name && goal.monthlyContribution > 0),
      debts: debts.filter(debt => debt.name && debt.balance > 0)
    };

    onSubmit(budgetData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Monthly Income */}
      <Card>
        <CardHeader>
          <CardTitle>Monthly Income</CardTitle>
          <CardDescription>Enter your total monthly income after taxes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Label htmlFor="income">Monthly Income ($)</Label>
            <Input
              id="income"
              type="number"
              placeholder="5000"
              value={monthlyIncome}
              onChange={(e) => setMonthlyIncome(e.target.value)}
              required
            />
          </div>
        </CardContent>
      </Card>

      {/* Bills */}
      <Card>
        <CardHeader>
          <CardTitle>Bills & Fixed Expenses</CardTitle>
          <CardDescription>Rent, utilities, insurance, subscriptions, etc.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {bills.map((bill, index) => (
            <div key={bill.id} className="flex gap-2 items-end">
              <div className="flex-1">
                <Label htmlFor={`bill-name-${bill.id}`}>Bill Name</Label>
                <Input
                  id={`bill-name-${bill.id}`}
                  placeholder="Rent"
                  value={bill.name}
                  onChange={(e) => handleBillChange(bill.id, 'name', e.target.value)}
                />
              </div>
              <div className="w-32">
                <Label htmlFor={`bill-amount-${bill.id}`}>Amount ($)</Label>
                <Input
                  id={`bill-amount-${bill.id}`}
                  type="number"
                  placeholder="1200"
                  value={bill.amount || ''}
                  onChange={(e) => handleBillChange(bill.id, 'amount', parseFloat(e.target.value) || 0)}
                />
              </div>
              {bills.length > 1 && (
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => handleRemoveBill(bill.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
          <Button type="button" variant="outline" onClick={handleAddBill} className="w-full">
            <Plus className="h-4 w-4 mr-2" /> Add Bill
          </Button>
        </CardContent>
      </Card>

      {/* Spending Categories */}
      <Card>
        <CardHeader>
          <CardTitle>Spending Categories</CardTitle>
          <CardDescription>Food, entertainment, shopping, transportation, etc.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {spendingCategories.map((category) => (
            <div key={category.id} className="flex gap-2 items-end">
              <div className="flex-1">
                <Label htmlFor={`cat-name-${category.id}`}>Category</Label>
                <Input
                  id={`cat-name-${category.id}`}
                  placeholder="Groceries"
                  value={category.name}
                  onChange={(e) => handleCategoryChange(category.id, 'name', e.target.value)}
                />
              </div>
              <div className="w-32">
                <Label htmlFor={`cat-amount-${category.id}`}>Amount ($)</Label>
                <Input
                  id={`cat-amount-${category.id}`}
                  type="number"
                  placeholder="400"
                  value={category.amount || ''}
                  onChange={(e) => handleCategoryChange(category.id, 'amount', parseFloat(e.target.value) || 0)}
                />
              </div>
              <div className="w-32">
                <Label htmlFor={`cat-type-${category.id}`}>Type</Label>
                <Select
                  value={category.isNeed ? 'need' : 'want'}
                  onValueChange={(value) => handleCategoryChange(category.id, 'isNeed', value === 'need')}
                >
                  <SelectTrigger id={`cat-type-${category.id}`}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="need">Need</SelectItem>
                    <SelectItem value="want">Want</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {spendingCategories.length > 1 && (
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => handleRemoveCategory(category.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
          <Button type="button" variant="outline" onClick={handleAddCategory} className="w-full">
            <Plus className="h-4 w-4 mr-2" /> Add Category
          </Button>
        </CardContent>
      </Card>

      {/* Savings Goals */}
      <Card>
        <CardHeader>
          <CardTitle>Savings Goals</CardTitle>
          <CardDescription>Emergency fund, vacation, down payment, etc.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {savingsGoals.map((goal) => (
            <div key={goal.id} className="flex gap-2 items-end">
              <div className="flex-1">
                <Label htmlFor={`goal-name-${goal.id}`}>Goal Name</Label>
                <Input
                  id={`goal-name-${goal.id}`}
                  placeholder="Emergency Fund"
                  value={goal.name}
                  onChange={(e) => handleSavingsGoalChange(goal.id, 'name', e.target.value)}
                />
              </div>
              <div className="w-32">
                <Label htmlFor={`goal-target-${goal.id}`}>Target ($)</Label>
                <Input
                  id={`goal-target-${goal.id}`}
                  type="number"
                  placeholder="10000"
                  value={goal.targetAmount || ''}
                  onChange={(e) => handleSavingsGoalChange(goal.id, 'targetAmount', parseFloat(e.target.value) || 0)}
                />
              </div>
              <div className="w-32">
                <Label htmlFor={`goal-monthly-${goal.id}`}>Monthly ($)</Label>
                <Input
                  id={`goal-monthly-${goal.id}`}
                  type="number"
                  placeholder="500"
                  value={goal.monthlyContribution || ''}
                  onChange={(e) => handleSavingsGoalChange(goal.id, 'monthlyContribution', parseFloat(e.target.value) || 0)}
                />
              </div>
              {savingsGoals.length > 1 && (
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => handleRemoveSavingsGoal(goal.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
          <Button type="button" variant="outline" onClick={handleAddSavingsGoal} className="w-full">
            <Plus className="h-4 w-4 mr-2" /> Add Savings Goal
          </Button>
        </CardContent>
      </Card>

      {/* Debts (Optional) */}
      <Card>
        <CardHeader>
          <CardTitle>Debts (Optional)</CardTitle>
          <CardDescription>Credit cards, loans, student debt, etc.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {debts.length === 0 ? (
            <Button type="button" variant="outline" onClick={handleAddDebt} className="w-full">
              <Plus className="h-4 w-4 mr-2" /> Add Debt
            </Button>
          ) : (
            <>
              {debts.map((debt) => (
                <div key={debt.id} className="space-y-2 p-4 border rounded-lg">
                  <div className="flex gap-2 items-end">
                    <div className="flex-1">
                      <Label htmlFor={`debt-name-${debt.id}`}>Debt Name</Label>
                      <Input
                        id={`debt-name-${debt.id}`}
                        placeholder="Credit Card"
                        value={debt.name}
                        onChange={(e) => handleDebtChange(debt.id, 'name', e.target.value)}
                      />
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => handleRemoveDebt(debt.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label htmlFor={`debt-balance-${debt.id}`}>Balance ($)</Label>
                      <Input
                        id={`debt-balance-${debt.id}`}
                        type="number"
                        placeholder="5000"
                        value={debt.balance || ''}
                        onChange={(e) => handleDebtChange(debt.id, 'balance', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    <div>
                      <Label htmlFor={`debt-rate-${debt.id}`}>APR (%)</Label>
                      <Input
                        id={`debt-rate-${debt.id}`}
                        type="number"
                        placeholder="18"
                        value={debt.interestRate || ''}
                        onChange={(e) => handleDebtChange(debt.id, 'interestRate', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    <div>
                      <Label htmlFor={`debt-payment-${debt.id}`}>Min Payment ($)</Label>
                      <Input
                        id={`debt-payment-${debt.id}`}
                        type="number"
                        placeholder="150"
                        value={debt.minimumPayment || ''}
                        onChange={(e) => handleDebtChange(debt.id, 'minimumPayment', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                  </div>
                </div>
              ))}
              <Button type="button" variant="outline" onClick={handleAddDebt} className="w-full">
                <Plus className="h-4 w-4 mr-2" /> Add Another Debt
              </Button>
            </>
          )}
        </CardContent>
      </Card>

      <Button type="submit" className="w-full" size="lg">
        Generate My Budget
      </Button>
    </form>
  );
}
