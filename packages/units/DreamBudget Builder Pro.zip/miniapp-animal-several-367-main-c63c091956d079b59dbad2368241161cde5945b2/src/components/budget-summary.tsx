'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { AlertCircle, TrendingDown, TrendingUp, DollarSign, Target, CreditCard } from 'lucide-react';
import type { BudgetAnalysis, BudgetData } from '@/types/budget';

interface BudgetSummaryProps {
  data: BudgetData;
  analysis: BudgetAnalysis;
}

export function BudgetSummary({ data, analysis }: BudgetSummaryProps): JSX.Element {
  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const getStatusColor = (percentage: number, type: 'needs' | 'wants' | 'savings'): string => {
    if (type === 'needs') {
      return percentage <= 50 ? 'text-green-600' : percentage <= 60 ? 'text-yellow-600' : 'text-red-600';
    }
    if (type === 'wants') {
      return percentage <= 30 ? 'text-green-600' : percentage <= 40 ? 'text-yellow-600' : 'text-red-600';
    }
    if (type === 'savings') {
      return percentage >= 20 ? 'text-green-600' : percentage >= 10 ? 'text-yellow-600' : 'text-red-600';
    }
    return 'text-gray-600';
  };

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Monthly Income</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(data.monthlyIncome)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Remaining</CardDescription>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${analysis.remainingIncome >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(analysis.remainingIncome)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Needs</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(analysis.totalNeeds)}</div>
            <p className={`text-sm ${getStatusColor(analysis.needsPercentage, 'needs')}`}>
              {analysis.needsPercentage.toFixed(1)}% of income
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Wants</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(analysis.totalWants)}</div>
            <p className={`text-sm ${getStatusColor(analysis.wantsPercentage, 'wants')}`}>
              {analysis.wantsPercentage.toFixed(1)}% of income
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Needs vs Wants Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Budget Breakdown: 50/30/20 Rule
          </CardTitle>
          <CardDescription>
            Ideal: 50% needs, 30% wants, 20% savings
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium">Needs</span>
              <span className={`text-sm font-medium ${getStatusColor(analysis.needsPercentage, 'needs')}`}>
                {formatCurrency(analysis.totalNeeds)} ({analysis.needsPercentage.toFixed(1)}%)
              </span>
            </div>
            <Progress value={analysis.needsPercentage} className="h-3" />
          </div>

          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium">Wants</span>
              <span className={`text-sm font-medium ${getStatusColor(analysis.wantsPercentage, 'wants')}`}>
                {formatCurrency(analysis.totalWants)} ({analysis.wantsPercentage.toFixed(1)}%)
              </span>
            </div>
            <Progress value={analysis.wantsPercentage} className="h-3" />
          </div>

          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium">Savings</span>
              <span className={`text-sm font-medium ${getStatusColor(analysis.savingsPercentage, 'savings')}`}>
                {formatCurrency(analysis.totalSavings)} ({analysis.savingsPercentage.toFixed(1)}%)
              </span>
            </div>
            <Progress value={analysis.savingsPercentage} className="h-3" />
          </div>

          {analysis.totalDebtPayments > 0 && (
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">Debt Payments</span>
                <span className="text-sm font-medium">
                  {formatCurrency(analysis.totalDebtPayments)} ({((analysis.totalDebtPayments / data.monthlyIncome) * 100).toFixed(1)}%)
                </span>
              </div>
              <Progress value={(analysis.totalDebtPayments / data.monthlyIncome) * 100} className="h-3" />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Spending Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Spending Summary
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {data.bills.length > 0 && (
            <div>
              <h4 className="font-semibold mb-2">Bills & Fixed Expenses</h4>
              <div className="space-y-2">
                {data.bills.map(bill => (
                  <div key={bill.id} className="flex justify-between text-sm">
                    <span>{bill.name}</span>
                    <span className="font-medium">{formatCurrency(bill.amount)}</span>
                  </div>
                ))}
              </div>
              <Separator className="my-2" />
            </div>
          )}

          {data.spendingCategories.length > 0 && (
            <div>
              <h4 className="font-semibold mb-2">Spending Categories</h4>
              <div className="space-y-2">
                {data.spendingCategories.map(cat => (
                  <div key={cat.id} className="flex justify-between items-center text-sm">
                    <div className="flex items-center gap-2">
                      <span>{cat.name}</span>
                      <Badge variant={cat.isNeed ? 'default' : 'secondary'} className="text-xs">
                        {cat.isNeed ? 'Need' : 'Want'}
                      </Badge>
                    </div>
                    <span className="font-medium">{formatCurrency(cat.amount)}</span>
                  </div>
                ))}
              </div>
              <Separator className="my-2" />
            </div>
          )}

          {data.savingsGoals.length > 0 && (
            <div>
              <h4 className="font-semibold mb-2">Savings Goals</h4>
              <div className="space-y-2">
                {data.savingsGoals.map(goal => (
                  <div key={goal.id} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>{goal.name}</span>
                      <span className="font-medium">{formatCurrency(goal.monthlyContribution)}/mo</span>
                    </div>
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Target: {formatCurrency(goal.targetAmount)}</span>
                      <span>{Math.ceil(goal.targetAmount / goal.monthlyContribution)} months</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recommended Cuts */}
      {analysis.recommendedCuts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingDown className="h-5 w-5" />
              Recommended Cut Areas
            </CardTitle>
            <CardDescription>
              Ways to optimize your budget and increase savings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {analysis.recommendedCuts.map((cut, index) => (
              <div key={index} className="p-4 bg-amber-50 dark:bg-amber-950 rounded-lg space-y-2">
                <div className="flex items-start gap-2">
                  <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="font-semibold text-amber-900 dark:text-amber-100">{cut.category}</h4>
                    <p className="text-sm text-amber-800 dark:text-amber-200 mt-1">{cut.reason}</p>
                    <div className="flex gap-4 mt-2 text-sm">
                      <span>Current: {formatCurrency(cut.currentAmount)}</span>
                      <span>→</span>
                      <span className="font-semibold">Suggested: {formatCurrency(cut.suggestedAmount)}</span>
                    </div>
                    <div className="mt-2">
                      <Badge variant="outline" className="bg-green-100 dark:bg-green-900">
                        <TrendingUp className="h-3 w-3 mr-1" />
                        Save {formatCurrency(cut.savings)}/month
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Debt Payoff Suggestions */}
      {analysis.debtPayoffSuggestions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Debt Payoff Strategy
            </CardTitle>
            <CardDescription>
              Recommended approach to eliminate your debt faster
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {analysis.debtPayoffSuggestions.map((suggestion, index) => (
                <div key={index} className="flex items-start gap-2">
                  <div className="w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-xs font-semibold text-blue-700 dark:text-blue-300 mt-0.5">
                    {index + 1}
                  </div>
                  <p className="text-sm flex-1">{suggestion}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
