'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Calendar } from 'lucide-react';
import type { WeeklyBreakdown } from '@/types/budget';

interface WeeklySummaryProps {
  weeklyBreakdown: WeeklyBreakdown;
}

export function WeeklySummary({ weeklyBreakdown }: WeeklySummaryProps): JSX.Element {
  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const totalWeeklySpending = 
    weeklyBreakdown.weeklyNeeds +
    weeklyBreakdown.weeklyWants +
    weeklyBreakdown.weeklySavings +
    weeklyBreakdown.weeklyDebt;

  const weeklyRemaining = weeklyBreakdown.weeklyIncome - totalWeeklySpending;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Weekly Budget Summary
        </CardTitle>
        <CardDescription>
          Your monthly budget broken down by week (approximate)
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Weekly Income</p>
            <p className="text-2xl font-bold">{formatCurrency(weeklyBreakdown.weeklyIncome)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Weekly Remaining</p>
            <p className={`text-2xl font-bold ${weeklyRemaining >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(weeklyRemaining)}
            </p>
          </div>
        </div>

        <div className="space-y-3 pt-4">
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-sm font-medium">Needs</span>
              <span className="text-sm">{formatCurrency(weeklyBreakdown.weeklyNeeds)}</span>
            </div>
            <Progress 
              value={(weeklyBreakdown.weeklyNeeds / weeklyBreakdown.weeklyIncome) * 100} 
              className="h-2"
            />
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="text-sm font-medium">Wants</span>
              <span className="text-sm">{formatCurrency(weeklyBreakdown.weeklyWants)}</span>
            </div>
            <Progress 
              value={(weeklyBreakdown.weeklyWants / weeklyBreakdown.weeklyIncome) * 100} 
              className="h-2"
            />
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="text-sm font-medium">Savings</span>
              <span className="text-sm">{formatCurrency(weeklyBreakdown.weeklySavings)}</span>
            </div>
            <Progress 
              value={(weeklyBreakdown.weeklySavings / weeklyBreakdown.weeklyIncome) * 100} 
              className="h-2"
            />
          </div>

          {weeklyBreakdown.weeklyDebt > 0 && (
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">Debt Payments</span>
                <span className="text-sm">{formatCurrency(weeklyBreakdown.weeklyDebt)}</span>
              </div>
              <Progress 
                value={(weeklyBreakdown.weeklyDebt / weeklyBreakdown.weeklyIncome) * 100} 
                className="h-2"
              />
            </div>
          )}
        </div>

        <div className="pt-4 border-t">
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>
              <p className="text-muted-foreground">Daily Budget (Needs)</p>
              <p className="font-semibold">{formatCurrency(weeklyBreakdown.weeklyNeeds / 7)}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Daily Budget (Wants)</p>
              <p className="font-semibold">{formatCurrency(weeklyBreakdown.weeklyWants / 7)}</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
