import type { BudgetData, BudgetAnalysis, RecommendedCut, WeeklyBreakdown } from '@/types/budget';

export function calculateBudgetAnalysis(data: BudgetData): BudgetAnalysis {
  // Calculate totals
  const totalBills = data.bills.reduce((sum, bill) => sum + bill.amount, 0);
  const totalNeeds = totalBills + data.spendingCategories
    .filter(cat => cat.isNeed)
    .reduce((sum, cat) => sum + cat.amount, 0);
  
  const totalWants = data.spendingCategories
    .filter(cat => !cat.isNeed)
    .reduce((sum, cat) => sum + cat.amount, 0);
  
  const totalSavings = data.savingsGoals.reduce((sum, goal) => sum + goal.monthlyContribution, 0);
  const totalDebtPayments = data.debts.reduce((sum, debt) => sum + debt.minimumPayment, 0);
  
  const totalSpending = totalNeeds + totalWants + totalSavings + totalDebtPayments;
  const remainingIncome = data.monthlyIncome - totalSpending;
  
  // Calculate percentages
  const needsPercentage = (totalNeeds / data.monthlyIncome) * 100;
  const wantsPercentage = (totalWants / data.monthlyIncome) * 100;
  const savingsPercentage = (totalSavings / data.monthlyIncome) * 100;
  
  // Generate recommendations (50/30/20 rule as baseline)
  const recommendedCuts: RecommendedCut[] = [];
  
  // Check if wants are too high (should be around 30%)
  if (wantsPercentage > 35) {
    const wantCategories = data.spendingCategories.filter(cat => !cat.isNeed);
    wantCategories.forEach(cat => {
      if (cat.amount > 200) {
        const suggested = Math.floor(cat.amount * 0.8);
        recommendedCuts.push({
          category: cat.name,
          currentAmount: cat.amount,
          suggestedAmount: suggested,
          savings: cat.amount - suggested,
          reason: 'Reduce discretionary spending to align with 50/30/20 budget rule'
        });
      }
    });
  }
  
  // Check if savings are too low (should be at least 20%)
  if (savingsPercentage < 15 && totalWants > 0) {
    const largestWant = data.spendingCategories
      .filter(cat => !cat.isNeed)
      .sort((a, b) => b.amount - a.amount)[0];
    
    if (largestWant) {
      const suggested = Math.floor(largestWant.amount * 0.7);
      recommendedCuts.push({
        category: largestWant.name,
        currentAmount: largestWant.amount,
        suggestedAmount: suggested,
        savings: largestWant.amount - suggested,
        reason: 'Increase savings to at least 20% of income'
      });
    }
  }
  
  // Generate debt payoff suggestions
  const debtPayoffSuggestions: string[] = [];
  
  if (data.debts.length > 0) {
    const sortedByRate = [...data.debts].sort((a, b) => b.interestRate - a.interestRate);
    const highestRateDebt = sortedByRate[0];
    
    if (highestRateDebt) {
      debtPayoffSuggestions.push(
        `Focus on "${highestRateDebt.name}" first (${highestRateDebt.interestRate}% interest rate) - use avalanche method`
      );
    }
    
    if (remainingIncome > 0) {
      debtPayoffSuggestions.push(
        `Allocate extra $${Math.floor(remainingIncome)} monthly surplus toward highest-interest debt`
      );
    }
    
    const totalDebt = data.debts.reduce((sum, debt) => sum + debt.balance, 0);
    const avgPayment = totalDebtPayments;
    const estimatedMonths = Math.ceil(totalDebt / avgPayment);
    
    debtPayoffSuggestions.push(
      `With current payments, debt-free in approximately ${estimatedMonths} months`
    );
    
    if (totalWants > totalDebtPayments) {
      debtPayoffSuggestions.push(
        'Consider temporarily reducing wants spending to accelerate debt payoff'
      );
    }
  }
  
  // Calculate weekly breakdown
  const weeklyBreakdown: WeeklyBreakdown = {
    weeklyIncome: Math.floor(data.monthlyIncome / 4.33),
    weeklyNeeds: Math.floor(totalNeeds / 4.33),
    weeklyWants: Math.floor(totalWants / 4.33),
    weeklySavings: Math.floor(totalSavings / 4.33),
    weeklyDebt: Math.floor(totalDebtPayments / 4.33)
  };
  
  return {
    totalNeeds,
    totalWants,
    totalSavings,
    totalDebtPayments,
    remainingIncome,
    needsPercentage,
    wantsPercentage,
    savingsPercentage,
    recommendedCuts,
    debtPayoffSuggestions,
    weeklyBreakdown
  };
}
