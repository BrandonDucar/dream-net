export interface BillItem {
  id: string;
  name: string;
  amount: number;
}

export interface SpendingCategory {
  id: string;
  name: string;
  amount: number;
  isNeed: boolean;
}

export interface SavingsGoal {
  id: string;
  name: string;
  targetAmount: number;
  monthlyContribution: number;
}

export interface DebtItem {
  id: string;
  name: string;
  balance: number;
  interestRate: number;
  minimumPayment: number;
}

export interface BudgetData {
  monthlyIncome: number;
  bills: BillItem[];
  spendingCategories: SpendingCategory[];
  savingsGoals: SavingsGoal[];
  debts: DebtItem[];
}

export interface BudgetAnalysis {
  totalNeeds: number;
  totalWants: number;
  totalSavings: number;
  totalDebtPayments: number;
  remainingIncome: number;
  needsPercentage: number;
  wantsPercentage: number;
  savingsPercentage: number;
  recommendedCuts: RecommendedCut[];
  debtPayoffSuggestions: string[];
  weeklyBreakdown: WeeklyBreakdown;
}

export interface RecommendedCut {
  category: string;
  currentAmount: number;
  suggestedAmount: number;
  savings: number;
  reason: string;
}

export interface WeeklyBreakdown {
  weeklyIncome: number;
  weeklyNeeds: number;
  weeklyWants: number;
  weeklySavings: number;
  weeklyDebt: number;
}
