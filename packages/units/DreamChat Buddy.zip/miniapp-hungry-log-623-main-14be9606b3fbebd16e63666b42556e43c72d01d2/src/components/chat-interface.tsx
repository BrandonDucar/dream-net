'use client'

import { useState, useRef, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { MessageBubble } from '@/components/message-bubble'
import { QuickActions } from '@/components/quick-actions'
import { openaiChatCompletion } from '@/openai-api'
import { Loader2, Send, Sparkles } from 'lucide-react'
import type { OpenAIChatMessage } from '@/openai-api'

interface Message {
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
}

export function ChatInterface(): JSX.Element {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: "Hi there, friend! 💛 I'm here to support you today. What can I help you with? You can chat with me directly, or choose a quick action below to get started!",
      timestamp: new Date()
    }
  ])
  const [input, setInput] = useState<string>('')
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const scrollToBottom = (): void => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const sendMessage = async (userMessage: string): Promise<void> => {
    if (!userMessage.trim() || isLoading) return

    const newUserMessage: Message = {
      role: 'user',
      content: userMessage,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, newUserMessage])
    setInput('')
    setIsLoading(true)

    try {
      const conversationHistory: OpenAIChatMessage[] = [
        {
          role: 'system',
          content: `You are DreamChat Companion — $PAL, a warm, gentle, and deeply supportive AI friend. Your purpose is to provide motivation, encouragement, advice, and a safe space for people to share their feelings.

Your personality:
- Warm, caring, and empathetic
- Use a friendly, conversational tone with occasional emojis (but not too many)
- Be genuine and authentic, like a trusted friend
- Offer practical advice when asked, but also validate feelings
- Keep responses concise but meaningful (2-4 paragraphs max)
- End with an uplifting thought or question to continue the conversation

When users need:
- Motivation: Be energizing and remind them of their strength
- Advice: Be thoughtful and practical
- Encouragement: Be their biggest cheerleader
- Venting space: Listen without judgment, validate their feelings
- Pep talk: Be bold and inspiring
- Planning: Help break things down into manageable steps

Always maintain a supportive, non-judgmental presence. You're here to lift people up.`
        },
        ...messages.map(msg => ({
          role: msg.role as 'user' | 'assistant',
          content: msg.content
        })),
        {
          role: 'user',
          content: userMessage
        }
      ]

      const response = await openaiChatCompletion({
        model: 'gpt-4o',
        messages: conversationHistory
      })

      const assistantMessage: Message = {
        role: 'assistant',
        content: response.choices[0].message.content,
        timestamp: new Date()
      }

      setMessages(prev => [...prev, assistantMessage])
    } catch (error) {
      console.error('Error getting response:', error)
      const errorMessage: Message = {
        role: 'assistant',
        content: "I'm having a little trouble connecting right now. Can you try again in a moment? I'm here for you! 💙",
        timestamp: new Date()
      }
      setMessages(prev => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault()
    sendMessage(input)
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>): void => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage(input)
    }
  }

  const handleQuickAction = (actionMessage: string): void => {
    sendMessage(actionMessage)
  }

  return (
    <div className="container mx-auto max-w-4xl h-screen flex flex-col p-4 pt-12 md:pt-6">
      {/* Header */}
      <div className="text-center mb-6">
        <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 bg-clip-text text-transparent mb-2 flex items-center justify-center gap-2">
          <Sparkles className="w-8 h-8 text-purple-500" />
          DreamChat Companion
        </h1>
        <p className="text-lg text-purple-600 font-medium">$PAL — Your supportive friend</p>
      </div>

      {/* Chat Container */}
      <Card className="flex-1 flex flex-col overflow-hidden shadow-xl border-2 border-purple-100 bg-white/80 backdrop-blur">
        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
          {messages.map((message, index) => (
            <MessageBubble
              key={index}
              role={message.role}
              content={message.content}
              timestamp={message.timestamp}
            />
          ))}
          {isLoading && (
            <div className="flex items-center gap-2 text-purple-400">
              <Loader2 className="w-5 h-5 animate-spin" />
              <span className="text-sm">$PAL is thinking...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Actions */}
        <div className="border-t border-purple-100 p-4 bg-gradient-to-r from-pink-50/50 to-purple-50/50">
          <QuickActions onActionClick={handleQuickAction} />
        </div>

        {/* Input Area */}
        <div className="border-t border-purple-100 p-4 bg-white/90">
          <form onSubmit={handleSubmit} className="flex gap-2">
            <Textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Share what's on your mind..."
              className="min-h-[60px] max-h-[120px] resize-none border-purple-200 focus:border-purple-400 focus:ring-purple-400"
              disabled={isLoading}
            />
            <Button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white self-end"
              size="icon"
            >
              <Send className="w-5 h-5" />
            </Button>
          </form>
        </div>
      </Card>
    </div>
  )
}
