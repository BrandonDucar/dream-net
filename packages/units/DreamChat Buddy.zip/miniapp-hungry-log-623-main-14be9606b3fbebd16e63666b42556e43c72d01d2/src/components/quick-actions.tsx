'use client'

import { Button } from '@/components/ui/button'
import { Sunrise, Heart, Target, Sparkles, MessageCircleHeart, Moon } from 'lucide-react'

interface QuickAction {
  icon: React.ReactNode
  label: string
  message: string
  gradient: string
}

const quickActions: QuickAction[] = [
  {
    icon: <Sunrise className="w-4 h-4" />,
    label: 'Morning boost',
    message: "I'd love a morning boost to start my day right!",
    gradient: 'from-orange-400 to-yellow-400'
  },
  {
    icon: <Heart className="w-4 h-4" />,
    label: 'Fix my mood',
    message: "I'm not feeling great right now. Can you help lift my spirits?",
    gradient: 'from-pink-400 to-rose-400'
  },
  {
    icon: <Target className="w-4 h-4" />,
    label: 'Daily challenge',
    message: 'Give me a daily challenge to help me grow!',
    gradient: 'from-blue-400 to-cyan-400'
  },
  {
    icon: <Sparkles className="w-4 h-4" />,
    label: 'Gratitude prompt',
    message: "I'd like a gratitude prompt to reflect on what I'm thankful for.",
    gradient: 'from-purple-400 to-pink-400'
  },
  {
    icon: <MessageCircleHeart className="w-4 h-4" />,
    label: 'Encouragement',
    message: 'I could use some personalized encouragement right now.',
    gradient: 'from-green-400 to-emerald-400'
  },
  {
    icon: <Moon className="w-4 h-4" />,
    label: 'Evening message',
    message: 'Send me a kind message to end my day peacefully.',
    gradient: 'from-indigo-400 to-purple-400'
  }
]

interface QuickActionsProps {
  onActionClick: (message: string) => void
}

export function QuickActions({ onActionClick }: QuickActionsProps): JSX.Element {
  return (
    <div className="space-y-2">
      <p className="text-sm font-medium text-purple-600 mb-3">Quick actions:</p>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
        {quickActions.map((action, index) => (
          <Button
            key={index}
            onClick={() => onActionClick(action.message)}
            variant="outline"
            className="h-auto py-3 px-3 flex flex-col items-center gap-2 border-2 hover:border-purple-300 hover:bg-purple-50/50 transition-all"
          >
            <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${action.gradient} flex items-center justify-center text-white`}>
              {action.icon}
            </div>
            <span className="text-xs font-medium text-gray-700 text-center leading-tight">
              {action.label}
            </span>
          </Button>
        ))}
      </div>
    </div>
  )
}
