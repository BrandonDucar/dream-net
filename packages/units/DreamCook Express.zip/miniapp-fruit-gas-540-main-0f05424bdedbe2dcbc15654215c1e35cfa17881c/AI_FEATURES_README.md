# 🚀 DreamCookbook - AI & Advanced Features Guide

## Overview
DreamCookbook now includes cutting-edge AI and geofencing features that set it apart from competitors like Mealime, Paprika, and Samsung Food.

---

## 🤖 AI-Powered Features

### 1. AI Recipe Generator
**What it does:** Creates custom recipes from ingredients you have on hand using GPT-4o-mini.

**How to use:**
1. Go to the "AI Tools" tab
2. Enter ingredients you want to use
3. Add preferences (optional): "spicy", "low-carb", "Italian-style", etc.
4. Click "Generate Recipe"
5. Recipe automatically saves to your Cookbook

**API Configuration:**
- Set `OPENAI_API_KEY` environment variable
- Default uses demo mode if no key is provided

### 2. Smart Cooking Assistant
**Capabilities:**
- Ingredient substitution suggestions
- Cooking tips and techniques
- Recipe difficulty analysis
- Nutritional categorization

**API Endpoint:** `/api/ai-recipe`
- Action: `generate` - Create full recipes
- Action: `suggest-substitution` - Get ingredient alternatives
- Action: `cooking-tip` - Receive cooking advice

---

## 📍 Geofencing & Location Features

### Find Nearby Stores
**What it does:** Uses your device's GPS to find grocery stores, farmers markets, and specialty food stores within 5km radius.

**Features:**
- Real-time location detection
- Store ratings and open/closed status
- Distance calculations
- Direct Google Maps integration
- Filter by type: Grocery, Farmers Markets, Specialty

**How to use:**
1. Go to "AI Tools" tab
2. Click "Find Stores Near Me"
3. Grant location permission
4. Browse nearby options
5. Click "Directions" to open in Google Maps

**API Configuration:**
- Set `GOOGLE_MAPS_API_KEY` environment variable
- Falls back to demo data if no key is provided

**API Endpoint:** `/api/geofencing`

---

## 🎯 SEO Optimization

### What's included:
1. **Recipe Schema Markup (schema.org)**
   - Rich snippets for search engines
   - Recipe details, ratings, cooking times
   - Structured data for better discoverability

2. **OpenGraph & Twitter Cards**
   - Beautiful social media previews
   - Custom images and descriptions
   - Optimized for sharing

3. **SEO Metadata**
   - Keywords: "recipe app, meal planning, AI recipe generator"
   - Descriptive titles and meta descriptions
   - Image alt text for accessibility

4. **Recipe Schema Component**
   - Automatically generates JSON-LD structured data
   - Includes prep time, cook time, ingredients, instructions
   - Aggregate ratings and nutrition info

---

## 🆚 Competitive Advantages

### vs. Mealime
- ✅ AI recipe generation from ingredients
- ✅ Location-based store finder
- ✅ Unlimited recipe storage
- ✅ No subscription required for core features

### vs. Paprika
- ✅ Built-in AI assistant
- ✅ Geofencing for local stores
- ✅ Modern, responsive UI
- ✅ Real-time meal planning

### vs. Samsung Food
- ✅ More advanced AI capabilities
- ✅ Better recipe schema for SEO
- ✅ Geofencing without device requirements
- ✅ Open-source friendly

### vs. Ollie
- ✅ More flexible meal planning
- ✅ Manual + AI hybrid approach
- ✅ Better recipe discovery
- ✅ Location-based shopping

---

## 🔧 Environment Variables

Add these to your `.env.local` file:

\`\`\`bash
# Required for AI Recipe Generation
OPENAI_API_KEY=sk-proj-your-key-here

# Required for Geofencing
GOOGLE_MAPS_API_KEY=your-google-maps-key-here
\`\`\`

### Getting API Keys:

**OpenAI:**
1. Go to https://platform.openai.com/api-keys
2. Create new secret key
3. Add to environment variables

**Google Maps:**
1. Go to https://console.cloud.google.com
2. Enable Maps JavaScript API & Places API
3. Create credentials → API Key
4. Add to environment variables

---

## 📊 Feature Comparison Matrix

| Feature | DreamCookbook | Mealime | Paprika | Samsung Food |
|---------|---------------|---------|---------|--------------|
| AI Recipe Gen | ✅ | ❌ | ❌ | ✅ (paid) |
| Geofencing | ✅ | Instacart only | ❌ | Limited |
| SEO Schema | ✅ | ❌ | ❌ | ❌ |
| Free Tier | ✅ Full | Limited | ❌ | Basic |
| Meal Planning | ✅ | ✅ | ✅ | ✅ |
| Recipe Vault | ✅ Unlimited | Limited | ✅ | ✅ |
| Export PDF | ✅ | ❌ | ✅ | ❌ |
| Mobile Controls | ✅ | ✅ | ✅ | ✅ |

---

## 🚀 Future Enhancements

Potential additions based on market analysis:
- Voice-controlled cooking assistant
- Augmented reality recipe visualization
- Smart appliance integration
- Social recipe sharing network
- Nutrition tracking and analysis
- Meal plan templates by dietary preference
- Integration with fitness apps
- Automated grocery delivery API connections

---

## 📱 Usage Tips

1. **Best Practices:**
   - Add ingredients to AI generator as you check your pantry
   - Use geofencing before shopping to find best nearby stores
   - Save AI-generated recipes to Vault for future editing
   - Export meal plans and grocery lists before shopping trips

2. **Performance:**
   - AI generation takes 3-5 seconds
   - Geofencing requires location permission
   - All data stored locally in browser

3. **Privacy:**
   - No user data sent to third parties
   - Location used only for store finding
   - All recipes stored in your browser

---

## 🎨 DreamNet Branding

Color Palette:
- Primary: Soft neon red (#ef4444)
- Secondary: Charcoal gray (#1f2937)
- Background: White to light gray gradient
- Accents: Red for active states

---

## 📄 License & Credits

Built with:
- Next.js 15
- OpenAI GPT-4o-mini
- Google Maps API
- Tailwind CSS
- shadcn/ui components

---

## 🐛 Troubleshooting

**AI features not working?**
- Check OPENAI_API_KEY is set correctly
- Verify API key has credits
- Check browser console for errors

**Geofencing showing demo data?**
- Set GOOGLE_MAPS_API_KEY
- Enable Places API in Google Cloud
- Grant browser location permission

**Build errors?**
- Run `pnpm install`
- Clear `.next` folder
- Check all imports are correct

---

For support or feature requests, check the project documentation or contact the development team.
