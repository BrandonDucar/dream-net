import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge';

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.json();
    const { ingredients, preferences, action } = body as {
      ingredients?: string[];
      preferences?: string;
      action: 'generate' | 'suggest-substitution' | 'cooking-tip';
      recipeContext?: string;
    };

    if (action === 'generate') {
      // AI Recipe Generation from ingredients
      const prompt = `Create a detailed recipe using these ingredients: ${ingredients?.join(', ')}. ${preferences ? `Preferences: ${preferences}` : ''}
      
      Return a JSON object with:
      - title: string
      - description: string
      - ingredients: string[] (with measurements)
      - steps: string[]
      - dreamUpgrades: string[]
      - prepTime: string
      - cookTime: string
      - servings: number
      - difficulty: "Easy" | "Medium" | "Hard"
      - cuisine: string
      - dietary: string[] (e.g., "vegetarian", "gluten-free")`;

      const response = await fetch('/api/proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          protocol: 'https',
          origin: 'api.openai.com',
          path: '/v1/chat/completions',
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${process.env.OPENAI_API_KEY || 'sk-proj-test'}`,
            'Content-Type': 'application/json',
          },
          body: {
            model: 'gpt-4o-mini',
            messages: [
              {
                role: 'system',
                content: 'You are a creative chef who generates detailed, delicious recipes. Always respond with valid JSON only.',
              },
              {
                role: 'user',
                content: prompt,
              },
            ],
            temperature: 0.8,
            response_format: { type: 'json_object' },
          },
        }),
      });

      const data = await response.json();
      const recipeData = JSON.parse(data.choices[0].message.content);

      return NextResponse.json({
        success: true,
        recipe: recipeData,
      });
    } else if (action === 'suggest-substitution') {
      // Ingredient substitution suggestions
      const { ingredient } = body as { ingredient: string };
      const prompt = `Suggest 3-5 substitutes for "${ingredient}" in cooking. Return JSON with: { substitutes: [{ name: string, ratio: string, notes: string }] }`;

      const response = await fetch('/api/proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          protocol: 'https',
          origin: 'api.openai.com',
          path: '/v1/chat/completions',
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${process.env.OPENAI_API_KEY || 'sk-proj-test'}`,
            'Content-Type': 'application/json',
          },
          body: {
            model: 'gpt-4o-mini',
            messages: [
              {
                role: 'system',
                content: 'You are a knowledgeable chef providing ingredient substitutions. Always respond with valid JSON.',
              },
              {
                role: 'user',
                content: prompt,
              },
            ],
            temperature: 0.7,
            response_format: { type: 'json_object' },
          },
        }),
      });

      const data = await response.json();
      const substitutions = JSON.parse(data.choices[0].message.content);

      return NextResponse.json({
        success: true,
        substitutions: substitutions.substitutes,
      });
    } else if (action === 'cooking-tip') {
      // Cooking tips and techniques
      const { recipeContext } = body as { recipeContext: string };
      const prompt = `Provide 3 helpful cooking tips for: "${recipeContext}". Return JSON with: { tips: string[] }`;

      const response = await fetch('/api/proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          protocol: 'https',
          origin: 'api.openai.com',
          path: '/v1/chat/completions',
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${process.env.OPENAI_API_KEY || 'sk-proj-test'}`,
            'Content-Type': 'application/json',
          },
          body: {
            model: 'gpt-4o-mini',
            messages: [
              {
                role: 'system',
                content: 'You are an expert chef providing practical cooking tips. Always respond with valid JSON.',
              },
              {
                role: 'user',
                content: prompt,
              },
            ],
            temperature: 0.7,
            response_format: { type: 'json_object' },
          },
        }),
      });

      const data = await response.json();
      const tipsData = JSON.parse(data.choices[0].message.content);

      return NextResponse.json({
        success: true,
        tips: tipsData.tips,
      });
    }

    return NextResponse.json(
      { success: false, error: 'Invalid action' },
      { status: 400 }
    );
  } catch (error) {
    console.error('AI Recipe API Error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to process AI request' },
      { status: 500 }
    );
  }
}
