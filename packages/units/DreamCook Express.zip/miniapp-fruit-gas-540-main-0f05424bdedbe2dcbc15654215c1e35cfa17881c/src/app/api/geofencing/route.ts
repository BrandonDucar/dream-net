import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge';

interface NearbyPlace {
  name: string;
  address: string;
  distance: string;
  type: 'grocery' | 'farmers-market' | 'specialty';
  rating?: number;
  isOpen?: boolean;
  coordinates: {
    lat: number;
    lng: number;
  };
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.json();
    const { latitude, longitude, radius = 5000, type = 'grocery' } = body as {
      latitude: number;
      longitude: number;
      radius?: number;
      type?: 'grocery' | 'farmers-market' | 'specialty' | 'all';
    };

    if (!latitude || !longitude) {
      return NextResponse.json(
        { success: false, error: 'Location coordinates required' },
        { status: 400 }
      );
    }

    // Define search queries based on type
    const searchQueries: Record<string, string> = {
      'grocery': 'grocery store OR supermarket',
      'farmers-market': 'farmers market',
      'specialty': 'specialty food store OR gourmet market',
      'all': 'grocery store OR supermarket OR farmers market OR food store',
    };

    const query = searchQueries[type] || searchQueries['all'];

    // Use Google Places API through proxy
    const placesResponse = await fetch('/api/proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        protocol: 'https',
        origin: 'maps.googleapis.com',
        path: '/maps/api/place/nearbysearch/json',
        method: 'GET',
        headers: {},
        query: {
          location: `${latitude},${longitude}`,
          radius: radius.toString(),
          keyword: query,
          key: process.env.GOOGLE_MAPS_API_KEY || 'demo-key',
        },
      }),
    });

    const placesData = await placesResponse.json();

    // Transform the results
    const places: NearbyPlace[] = (placesData.results || []).slice(0, 10).map((place: any) => {
      const placeType = place.types?.includes('grocery_or_supermarket')
        ? 'grocery'
        : place.types?.includes('farmers_market')
        ? 'farmers-market'
        : 'specialty';

      return {
        name: place.name,
        address: place.vicinity || place.formatted_address,
        distance: calculateDistance(
          latitude,
          longitude,
          place.geometry.location.lat,
          place.geometry.location.lng
        ),
        type: placeType,
        rating: place.rating,
        isOpen: place.opening_hours?.open_now,
        coordinates: {
          lat: place.geometry.location.lat,
          lng: place.geometry.location.lng,
        },
      };
    });

    return NextResponse.json({
      success: true,
      places,
      userLocation: { latitude, longitude },
    });
  } catch (error) {
    console.error('Geofencing API Error:', error);
    
    // Fallback: Return demo data if API fails
    const demoPlaces: NearbyPlace[] = [
      {
        name: 'Fresh Market Downtown',
        address: '123 Main St',
        distance: '0.5 mi',
        type: 'grocery',
        rating: 4.5,
        isOpen: true,
        coordinates: { lat: 0, lng: 0 },
      },
      {
        name: "Sunday Farmers' Market",
        address: '456 Park Ave',
        distance: '1.2 mi',
        type: 'farmers-market',
        rating: 4.8,
        isOpen: false,
        coordinates: { lat: 0, lng: 0 },
      },
      {
        name: 'Gourmet Specialty Foods',
        address: '789 Oak Blvd',
        distance: '2.1 mi',
        type: 'specialty',
        rating: 4.3,
        isOpen: true,
        coordinates: { lat: 0, lng: 0 },
      },
    ];

    return NextResponse.json({
      success: true,
      places: demoPlaces,
      demo: true,
      message: 'Using demo data. Configure Google Maps API key for live results.',
    });
  }
}

// Calculate distance between two coordinates (Haversine formula)
function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): string {
  const R = 3959; // Earth's radius in miles
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;

  return `${distance.toFixed(1)} mi`;
}

function toRad(degrees: number): number {
  return (degrees * Math.PI) / 180;
}
