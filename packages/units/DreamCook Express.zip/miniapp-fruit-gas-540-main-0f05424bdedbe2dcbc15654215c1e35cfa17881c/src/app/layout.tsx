import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { ResponseLogger } from "@/components/response-logger";
import { cookies } from "next/headers";
import { ReadyNotifier } from "@/components/ready-notifier";
import FarcasterWrapper from "@/components/FarcasterWrapper";

const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const requestId = cookies().get("x-request-id")?.value;

  return (
        <html lang="en">
          <head>
            {requestId && <meta name="x-request-id" content={requestId} />}
          </head>
          <body
            className={`${geistSans.variable} ${geistMono.variable} antialiased`}
          >
            {/* Do not remove this component, we use it to notify the parent that the mini-app is ready */}
            <ReadyNotifier />
            
      <FarcasterWrapper>
        {children}
      </FarcasterWrapper>
      
            <ResponseLogger />
          </body>
        </html>
      );
}

export const metadata: Metadata = {
        title: "DreamCookbook - AI-Powered Recipe & Meal Planning App",
        description: "Create custom recipes with AI, discover local grocery stores, and plan your weekly meals. DreamCookbook offers smart cooking assistance, ingredient substitutions, and location-based shopping recommendations.",
        keywords: "recipe app, meal planning, AI recipe generator, cooking assistant, grocery finder, meal prep, recipe vault, weekly planner",
        openGraph: {
          title: "DreamCookbook - Smart Cooking & Meal Planning",
          description: "AI-powered recipe generation, local store finder, and comprehensive meal planning in one beautiful app",
          type: "website",
          images: [{
            url: "https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_84f2c177-5acc-4c01-b347-f068b09d0ac9-GSEZ8j4xBdElvX3zzX2D5yoJHnExyl",
            width: 1200,
            height: 630,
            alt: "DreamCookbook App",
          }],
        },
        twitter: {
          card: "summary_large_image",
          title: "DreamCookbook - AI Recipe & Meal Planning",
          description: "Generate recipes with AI, find nearby stores, and plan meals effortlessly",
          images: ["https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_84f2c177-5acc-4c01-b347-f068b09d0ac9-GSEZ8j4xBdElvX3zzX2D5yoJHnExyl"],
        },
        other: { "fc:frame": JSON.stringify({"version":"next","imageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_84f2c177-5acc-4c01-b347-f068b09d0ac9-GSEZ8j4xBdElvX3zzX2D5yoJHnExyl","button":{"title":"Open with Ohara","action":{"type":"launch_frame","name":"DreamCook Express","url":"https://fruit-gas-540.app.ohara.ai","splashImageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/farcaster/splash_images/splash_image1.svg","splashBackgroundColor":"#ffffff"}}}
        ) }
    };
