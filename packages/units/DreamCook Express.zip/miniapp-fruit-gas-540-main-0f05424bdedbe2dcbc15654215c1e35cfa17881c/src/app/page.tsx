'use client'
import { useState, useEffect } from 'react';
import type { Recipe, VaultRecipe, WeekMealPlan, GroceryItem } from '@/types/recipe';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { RecipeCard } from '@/components/recipe-card';
import { RecipeDetail } from '@/components/recipe-detail';
import { RecipeForm } from '@/components/recipe-form';
import { VaultItem } from '@/components/vault-item';
import { MealPlannerGrid } from '@/components/meal-planner-grid';
import { GroceryList } from '@/components/grocery-list';
import {
  getCookbookRecipes,
  saveCookbookRecipes,
  addCookbookRecipe,
  updateCookbookRecipe,
  deleteCookbookRecipe,
  getVaultRecipes,
  addVaultRecipe,
  updateVaultRecipe,
  deleteVaultRecipe,
  getMealPlan,
  saveMealPlan,
  getGroceryList,
  saveGroceryList,
} from '@/lib/storage';
import { BookOpen, Archive, Calendar, Plus, Search, Sparkles, Mic, Eye, Zap, Users, Apple, Leaf } from 'lucide-react';
import { AIRecipeGenerator } from '@/components/ai-recipe-generator';
import { LocationFinder } from '@/components/location-finder';
import { VoiceAssistant } from '@/components/voice-assistant';
import { ARViewer } from '@/components/ar-viewer';
import { SmartApplianceHub } from '@/components/smart-appliance-hub';
import { CommunityRecipeSharing } from '@/components/community-recipe-sharing';
import { NutritionTracker } from '@/components/nutrition-tracker';
import { SeasonalRecipes } from '@/components/seasonal-recipes';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DreamCookbook(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [activeTab, setActiveTab] = useState('cookbook');
  const [cookbookRecipes, setCookbookRecipes] = useState<Recipe[]>([]);
  const [vaultRecipes, setVaultRecipes] = useState<VaultRecipe[]>([]);
  const [mealPlan, setMealPlan] = useState<WeekMealPlan>({
    monday: {},
    tuesday: {},
    wednesday: {},
    thursday: {},
    friday: {},
    saturday: {},
    sunday: {},
  });
  const [groceryList, setGroceryList] = useState<GroceryItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | VaultRecipe | null>(null);
  const [showRecipeDetail, setShowRecipeDetail] = useState(false);
  const [showRecipeForm, setShowRecipeForm] = useState(false);
  const [editingRecipe, setEditingRecipe] = useState<Recipe | VaultRecipe | null>(null);
  const [formIsVault, setFormIsVault] = useState(false);
  const [showAITools, setShowAITools] = useState(false);
  const [currentRecipeStep, setCurrentRecipeStep] = useState(0);
  const [activeTimer, setActiveTimer] = useState(0);

  useEffect(() => {
    setCookbookRecipes(getCookbookRecipes());
    setVaultRecipes(getVaultRecipes());
    setMealPlan(getMealPlan());
    setGroceryList(getGroceryList());
  }, []);

  const handleSaveToVault = (recipe: Recipe): void => {
    const vaultRecipe: VaultRecipe = {
      ...recipe,
      id: Date.now().toString(),
      dateAdded: new Date().toISOString(),
    };
    addVaultRecipe(vaultRecipe);
    setVaultRecipes(getVaultRecipes());
    alert('Recipe saved to vault!');
  };

  const handleAddCookbookRecipe = (recipe: Recipe): void => {
    if (editingRecipe) {
      updateCookbookRecipe(editingRecipe.id, recipe);
    } else {
      addCookbookRecipe(recipe);
    }
    setCookbookRecipes(getCookbookRecipes());
    setEditingRecipe(null);
  };

  const handleAIRecipeGenerated = (recipe: Recipe): void => {
    addCookbookRecipe(recipe);
    setCookbookRecipes(getCookbookRecipes());
    setShowAITools(false);
    alert('AI recipe added to cookbook!');
  };

  const handleAddVaultRecipe = (recipe: VaultRecipe): void => {
    if (editingRecipe) {
      updateVaultRecipe(editingRecipe.id, recipe);
    } else {
      addVaultRecipe(recipe);
    }
    setVaultRecipes(getVaultRecipes());
    setEditingRecipe(null);
  };

  const handleDeleteCookbookRecipe = (id: string): void => {
    deleteCookbookRecipe(id);
    setCookbookRecipes(getCookbookRecipes());
  };

  const handleDeleteVaultRecipe = (id: string): void => {
    deleteVaultRecipe(id);
    setVaultRecipes(getVaultRecipes());
  };

  const handleViewRecipe = (recipe: Recipe | VaultRecipe): void => {
    setSelectedRecipe(recipe);
    setShowRecipeDetail(true);
    setCurrentRecipeStep(0);
  };

  const handleImportFromCommunity = (recipe: Recipe): void => {
    addCookbookRecipe(recipe);
    setCookbookRecipes(getCookbookRecipes());
  };

  const handleEditRecipe = (recipe: Recipe | VaultRecipe, isVault: boolean): void => {
    setEditingRecipe(recipe);
    setFormIsVault(isVault);
    setShowRecipeForm(true);
  };

  const handleUpdateMealPlan = (plan: WeekMealPlan): void => {
    setMealPlan(plan);
    saveMealPlan(plan);
  };

  const handleUpdateGroceryList = (items: GroceryItem[]): void => {
    setGroceryList(items);
    saveGroceryList(items);
  };

  const filteredCookbookRecipes = cookbookRecipes.filter((recipe: Recipe) =>
    recipe.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    recipe.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredVaultRecipes = vaultRecipes.filter((recipe: VaultRecipe) =>
    recipe.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    recipe.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-gray-900 to-gray-800 text-white shadow-lg">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-4xl font-bold flex items-center gap-3">
            <BookOpen className="w-10 h-10 text-red-400" />
            DreamCookbook
          </h1>
          <p className="text-gray-300 mt-2">
            Your modular cooking, recipe, and meal-planning system
          </p>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          {/* Tab Navigation */}
          <div className="overflow-x-auto">
            <TabsList className="grid w-full grid-cols-7 min-w-max bg-white border-2 border-gray-200">
              <TabsTrigger 
                value="cookbook" 
                className="data-[state=active]:bg-red-500 data-[state=active]:text-white"
              >
                <BookOpen className="w-4 h-4 mr-2" />
                Cookbook
              </TabsTrigger>
              <TabsTrigger 
                value="vault"
                className="data-[state=active]:bg-red-500 data-[state=active]:text-white"
              >
                <Archive className="w-4 h-4 mr-2" />
                Vault
              </TabsTrigger>
              <TabsTrigger 
                value="planner"
                className="data-[state=active]:bg-red-500 data-[state=active]:text-white"
              >
                <Calendar className="w-4 h-4 mr-2" />
                Planner
              </TabsTrigger>
              <TabsTrigger 
                value="ai-tools"
                className="data-[state=active]:bg-red-500 data-[state=active]:text-white"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                AI Tools
              </TabsTrigger>
              <TabsTrigger 
                value="cooking"
                className="data-[state=active]:bg-red-500 data-[state=active]:text-white"
              >
                <Mic className="w-4 h-4 mr-2" />
                Cooking
              </TabsTrigger>
              <TabsTrigger 
                value="community"
                className="data-[state=active]:bg-red-500 data-[state=active]:text-white"
              >
                <Users className="w-4 h-4 mr-2" />
                Community
              </TabsTrigger>
              <TabsTrigger 
                value="health"
                className="data-[state=active]:bg-red-500 data-[state=active]:text-white"
              >
                <Apple className="w-4 h-4 mr-2" />
                Health
              </TabsTrigger>
            </TabsList>
          </div>

          {/* COOKBOOK TAB */}
          <TabsContent value="cookbook" className="space-y-6">
            <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
              <div className="flex-1 w-full sm:max-w-md">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    placeholder="Search recipes..."
                    value={searchQuery}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Button 
                onClick={() => {
                  setEditingRecipe(null);
                  setFormIsVault(false);
                  setShowRecipeForm(true);
                }}
                className="bg-red-500 hover:bg-red-600 w-full sm:w-auto"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Recipe
              </Button>
            </div>

            {filteredCookbookRecipes.length === 0 ? (
              <div className="text-center py-16 text-gray-500">
                <BookOpen className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p className="text-xl">No recipes found</p>
                <p className="text-sm mt-2">Try adding a new recipe or adjusting your search</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredCookbookRecipes.map((recipe: Recipe) => (
                  <RecipeCard
                    key={recipe.id}
                    recipe={recipe}
                    onView={handleViewRecipe}
                    onSaveToVault={handleSaveToVault}
                    showSaveButton={true}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          {/* VAULT TAB */}
          <TabsContent value="vault" className="space-y-6">
            <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
              <div className="flex-1 w-full sm:max-w-md">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    placeholder="Search vault..."
                    value={searchQuery}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Button 
                onClick={() => {
                  setEditingRecipe(null);
                  setFormIsVault(true);
                  setShowRecipeForm(true);
                }}
                className="bg-red-500 hover:bg-red-600 w-full sm:w-auto"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add to Vault
              </Button>
            </div>

            {filteredVaultRecipes.length === 0 ? (
              <div className="text-center py-16 text-gray-500">
                <Archive className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p className="text-xl">Your vault is empty</p>
                <p className="text-sm mt-2">Save recipes from the cookbook or add your own</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredVaultRecipes.map((recipe: VaultRecipe) => (
                  <VaultItem
                    key={recipe.id}
                    recipe={recipe}
                    onView={handleViewRecipe}
                    onEdit={(r: VaultRecipe) => handleEditRecipe(r, true)}
                    onDelete={handleDeleteVaultRecipe}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          {/* AI TOOLS TAB */}
          <TabsContent value="ai-tools" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <h2 className="text-2xl font-bold mb-4 text-gray-900 flex items-center gap-2">
                  <Sparkles className="w-6 h-6 text-red-500" />
                  AI Recipe Generator
                </h2>
                <AIRecipeGenerator onRecipeGenerated={handleAIRecipeGenerated} />
              </div>
              <div>
                <h2 className="text-2xl font-bold mb-4 text-gray-900">Find Nearby Stores</h2>
                <LocationFinder />
              </div>
            </div>
          </TabsContent>

          {/* COOKING ASSISTANT TAB */}
          <TabsContent value="cooking" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <h2 className="text-2xl font-bold mb-4 text-gray-900 flex items-center gap-2">
                  <Mic className="w-6 h-6 text-red-500" />
                  Voice Assistant
                </h2>
                <VoiceAssistant
                  currentRecipe={selectedRecipe}
                  currentStep={currentRecipeStep}
                  onStepChange={setCurrentRecipeStep}
                  onTimerSet={setActiveTimer}
                />
              </div>
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold mb-4 text-gray-900 flex items-center gap-2">
                    <Eye className="w-6 h-6 text-red-500" />
                    AR Recipe Viewer
                  </h2>
                  <ARViewer recipe={selectedRecipe} />
                </div>
                <div>
                  <h2 className="text-2xl font-bold mb-4 text-gray-900 flex items-center gap-2">
                    <Zap className="w-6 h-6 text-red-500" />
                    Smart Appliances
                  </h2>
                  <SmartApplianceHub />
                </div>
              </div>
            </div>
          </TabsContent>

          {/* COMMUNITY TAB */}
          <TabsContent value="community" className="space-y-6">
            <CommunityRecipeSharing
              userRecipes={cookbookRecipes}
              onImportRecipe={handleImportFromCommunity}
            />
          </TabsContent>

          {/* HEALTH TAB */}
          <TabsContent value="health" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <h2 className="text-2xl font-bold mb-4 text-gray-900 flex items-center gap-2">
                  <Apple className="w-6 h-6 text-red-500" />
                  Nutrition Tracker
                </h2>
                <NutritionTracker recipes={[...cookbookRecipes, ...vaultRecipes]} />
              </div>
              <div>
                <h2 className="text-2xl font-bold mb-4 text-gray-900 flex items-center gap-2">
                  <Leaf className="w-6 h-6 text-green-500" />
                  Seasonal Suggestions
                </h2>
                <SeasonalRecipes
                  recipes={cookbookRecipes}
                  onSelectRecipe={handleViewRecipe}
                />
              </div>
            </div>
          </TabsContent>

          {/* PLANNER TAB */}
          <TabsContent value="planner" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <h2 className="text-2xl font-bold mb-4 text-gray-900">Weekly Meal Plan</h2>
                <MealPlannerGrid
                  mealPlan={mealPlan}
                  onUpdateMealPlan={handleUpdateMealPlan}
                  cookbookRecipes={cookbookRecipes}
                  vaultRecipes={vaultRecipes}
                />
              </div>
              <div>
                <h2 className="text-2xl font-bold mb-4 text-gray-900">Grocery List</h2>
                <GroceryList
                  groceryList={groceryList}
                  onUpdateGroceryList={handleUpdateGroceryList}
                  mealPlan={mealPlan}
                  cookbookRecipes={cookbookRecipes}
                  vaultRecipes={vaultRecipes}
                />
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Recipe Detail Dialog */}
      <RecipeDetail
        recipe={selectedRecipe}
        open={showRecipeDetail}
        onClose={() => {
          setShowRecipeDetail(false);
          setSelectedRecipe(null);
        }}
      />

      {/* Recipe Form Dialog */}
      <RecipeForm
        recipe={editingRecipe}
        open={showRecipeForm}
        onClose={() => {
          setShowRecipeForm(false);
          setEditingRecipe(null);
        }}
        onSave={formIsVault ? handleAddVaultRecipe : handleAddCookbookRecipe}
        isVault={formIsVault}
      />
    </div>
  );
}
