'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, Sparkles, Plus, X } from 'lucide-react';
import type { Recipe } from '@/types/recipe';

interface AIRecipeGeneratorProps {
  onRecipeGenerated: (recipe: Recipe) => void;
}

export function AIRecipeGenerator({ onRecipeGenerated }: AIRecipeGeneratorProps): JSX.Element {
  const [ingredients, setIngredients] = useState<string[]>([]);
  const [currentIngredient, setCurrentIngredient] = useState<string>('');
  const [preferences, setPreferences] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const addIngredient = (): void => {
    if (currentIngredient.trim()) {
      setIngredients([...ingredients, currentIngredient.trim()]);
      setCurrentIngredient('');
    }
  };

  const removeIngredient = (index: number): void => {
    setIngredients(ingredients.filter((_, i) => i !== index));
  };

  const generateRecipe = async (): Promise<void> => {
    if (ingredients.length === 0) {
      setError('Please add at least one ingredient');
      return;
    }

    setIsGenerating(true);
    setError('');

    try {
      const response = await fetch('/api/ai-recipe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'generate',
          ingredients,
          preferences,
        }),
      });

      const data = await response.json();

      if (data.success && data.recipe) {
        const newRecipe: Recipe = {
          id: Date.now().toString(),
          title: data.recipe.title,
          description: data.recipe.description,
          ingredients: data.recipe.ingredients,
          steps: data.recipe.steps,
          dreamUpgrades: data.recipe.dreamUpgrades || [],
          notes: 'AI-generated recipe',
          prepTime: data.recipe.prepTime,
          cookTime: data.recipe.cookTime,
          servings: data.recipe.servings,
          difficulty: data.recipe.difficulty,
          cuisine: data.recipe.cuisine,
          dietary: data.recipe.dietary,
        };

        onRecipeGenerated(newRecipe);
        
        // Reset form
        setIngredients([]);
        setPreferences('');
      } else {
        setError('Failed to generate recipe. Please try again.');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
      console.error('Recipe generation error:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Card className="border-red-500/20 bg-gradient-to-br from-gray-900 to-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-red-500">
          <Sparkles className="h-5 w-5" />
          AI Recipe Generator
        </CardTitle>
        <CardDescription>
          Enter ingredients you have on hand, and let AI create a custom recipe
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Ingredient Input */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Your Ingredients</label>
          <div className="flex gap-2">
            <Input
              placeholder="e.g., chicken breast, garlic, olive oil"
              value={currentIngredient}
              onChange={(e) => setCurrentIngredient(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  addIngredient();
                }
              }}
            />
            <Button
              onClick={addIngredient}
              size="icon"
              variant="outline"
              className="border-red-500/50 hover:bg-red-500/10"
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          {/* Ingredient Tags */}
          {ingredients.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
              {ingredients.map((ingredient, index) => (
                <Badge
                  key={index}
                  variant="secondary"
                  className="bg-red-500/20 text-red-500 hover:bg-red-500/30"
                >
                  {ingredient}
                  <button
                    onClick={() => removeIngredient(index)}
                    className="ml-1 hover:text-red-300"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
          )}
        </div>

        {/* Preferences */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Preferences (Optional)</label>
          <Textarea
            placeholder="e.g., spicy, low-carb, Italian-style, quick meal"
            value={preferences}
            onChange={(e) => setPreferences(e.target.value)}
            rows={2}
          />
        </div>

        {/* Error Message */}
        {error && (
          <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-md text-red-500 text-sm">
            {error}
          </div>
        )}

        {/* Generate Button */}
        <Button
          onClick={generateRecipe}
          disabled={isGenerating || ingredients.length === 0}
          className="w-full bg-red-500 hover:bg-red-600 text-white"
        >
          {isGenerating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating Recipe...
            </>
          ) : (
            <>
              <Sparkles className="mr-2 h-4 w-4" />
              Generate Recipe
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
