'use client'
import { useState, useEffect, useRef, Suspense } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Text, Box, Sphere, Cylinder } from '@react-three/drei';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Eye, RotateCcw, ZoomIn, ZoomOut } from 'lucide-react';
import type { Recipe, VaultRecipe } from '@/types/recipe';
import * as THREE from 'three';

interface ARViewerProps {
  recipe: Recipe | VaultRecipe | null;
}

function RotatingPlate(): JSX.Element {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = state.clock.getElapsedTime() * 0.3;
    }
  });

  return (
    <group>
      <Cylinder ref={meshRef} args={[2, 2, 0.2, 32]} position={[0, -0.5, 0]}>
        <meshStandardMaterial color="#ffffff" />
      </Cylinder>
      
      <Sphere args={[0.8, 32, 32]} position={[0, 0.5, 0]}>
        <meshStandardMaterial color="#ef4444" roughness={0.3} metalness={0.1} />
      </Sphere>

      <Sphere args={[0.4, 16, 16]} position={[-1.2, 0.3, 0.5]}>
        <meshStandardMaterial color="#10b981" roughness={0.4} />
      </Sphere>

      <Sphere args={[0.3, 16, 16]} position={[1.0, 0.2, -0.8]}>
        <meshStandardMaterial color="#f59e0b" roughness={0.4} />
      </Sphere>

      <Box args={[0.5, 0.5, 0.5]} position={[0.8, 0.3, 1.0]}>
        <meshStandardMaterial color="#8b5cf6" roughness={0.5} />
      </Box>

      <Cylinder args={[0.2, 0.2, 0.8, 16]} position={[-0.6, 0.4, -1.0]} rotation={[Math.PI / 4, 0, Math.PI / 4]}>
        <meshStandardMaterial color="#ec4899" roughness={0.4} />
      </Cylinder>
    </group>
  );
}

function Scene({ recipeName }: { recipeName: string }): JSX.Element {
  return (
    <>
      <PerspectiveCamera makeDefault position={[5, 3, 5]} />
      <OrbitControls 
        enablePan={true}
        enableZoom={true}
        enableRotate={true}
        autoRotate={false}
      />
      
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 10, 5]} intensity={1} castShadow />
      <pointLight position={[-10, -10, -5]} intensity={0.5} />

      <Suspense fallback={null}>
        <RotatingPlate />
        
        <Text
          position={[0, 3, 0]}
          fontSize={0.4}
          color="#1f2937"
          anchorX="center"
          anchorY="middle"
        >
          {recipeName}
        </Text>

        <Text
          position={[0, -2, 0]}
          fontSize={0.2}
          color="#6b7280"
          anchorX="center"
          anchorY="middle"
        >
          3D Recipe Visualization
        </Text>
      </Suspense>

      <gridHelper args={[10, 10, '#e5e7eb', '#e5e7eb']} position={[0, -1, 0]} />
    </>
  );
}

export function ARViewer({ recipe }: ARViewerProps): JSX.Element {
  const [isViewing, setIsViewing] = useState(false);
  const [zoom, setZoom] = useState(5);

  if (!recipe) {
    return (
      <Card className="border-2 border-gray-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5 text-gray-400" />
            AR Recipe Viewer
          </CardTitle>
          <CardDescription>Select a recipe to view in 3D</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-center justify-center text-gray-500">
            No recipe selected
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-2 border-red-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Eye className="w-5 h-5 text-red-500" />
          AR Recipe Viewer
        </CardTitle>
        <CardDescription>
          3D visualization of {recipe.title}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Button
            onClick={() => setIsViewing(!isViewing)}
            variant={isViewing ? 'destructive' : 'default'}
            className={isViewing ? 'bg-red-500 hover:bg-red-600' : 'bg-gray-900 hover:bg-gray-800'}
          >
            <Eye className="w-4 h-4 mr-2" />
            {isViewing ? 'Close AR View' : 'View in 3D'}
          </Button>
          {isViewing && (
            <>
              <Button variant="outline" size="icon" onClick={() => setZoom(Math.max(3, zoom - 1))}>
                <ZoomIn className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" onClick={() => setZoom(Math.min(10, zoom + 1))}>
                <ZoomOut className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" onClick={() => setZoom(5)}>
                <RotateCcw className="w-4 h-4" />
              </Button>
            </>
          )}
        </div>

        {isViewing && (
          <div className="h-96 bg-gradient-to-b from-gray-50 to-white rounded-lg border-2 border-gray-200 overflow-hidden">
            <Canvas shadows>
              <Scene recipeName={recipe.title} />
            </Canvas>
          </div>
        )}

        {isViewing && (
          <div className="bg-red-50 p-3 rounded-lg">
            <p className="text-sm text-gray-700">
              <strong>Tip:</strong> Drag to rotate, scroll to zoom, right-click to pan
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
