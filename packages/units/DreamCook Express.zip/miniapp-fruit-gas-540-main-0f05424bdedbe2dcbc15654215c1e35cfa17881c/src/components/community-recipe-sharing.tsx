'use client'
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Users, Heart, MessageCircle, Share2, TrendingUp, Star } from 'lucide-react';
import type { CommunityRecipe, Recipe } from '@/types/recipe';

interface CommunityRecipeSharingProps {
  userRecipes: Recipe[];
  onImportRecipe: (recipe: Recipe) => void;
}

export function CommunityRecipeSharing({ userRecipes, onImportRecipe }: CommunityRecipeSharingProps): JSX.Element {
  const [communityRecipes, setCommunityRecipes] = useState<CommunityRecipe[]>([]);
  const [selectedRecipe, setSelectedRecipe] = useState<CommunityRecipe | null>(null);
  const [comment, setComment] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSharing, setIsSharing] = useState(false);
  const [userName, setUserName] = useState('Chef');

  useEffect(() => {
    const demoRecipes: CommunityRecipe[] = [
      {
        id: 'c1',
        title: 'Viral TikTok Pasta',
        description: 'The famous baked feta pasta that broke the internet',
        ingredients: ['Feta cheese', 'Cherry tomatoes', 'Olive oil', 'Pasta', 'Garlic', 'Basil'],
        steps: ['Place feta and tomatoes in baking dish', 'Drizzle with olive oil', 'Bake at 400°F for 30 minutes', 'Cook pasta', 'Mix everything together'],
        authorId: 'user1',
        authorName: 'PastaQueen',
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        likes: 847,
        comments: ['Amazing!', 'Made this last night!', 'Best pasta ever'],
        tags: ['viral', 'easy', 'vegetarian'],
        rating: 4.8,
        category: 'Dinner',
      },
      {
        id: 'c2',
        title: 'Grandma\'s Secret Chicken Soup',
        description: 'Traditional recipe passed down for generations',
        ingredients: ['Whole chicken', 'Carrots', 'Celery', 'Onions', 'Bay leaves', 'Salt', 'Pepper'],
        steps: ['Simmer chicken for 2 hours', 'Add vegetables', 'Season to taste', 'Serve hot'],
        authorId: 'user2',
        authorName: 'SoupMaster',
        timestamp: new Date(Date.now() - 7200000).toISOString(),
        likes: 523,
        comments: ['Tastes like home', 'Perfect for cold days'],
        tags: ['comfort', 'traditional', 'healing'],
        rating: 4.9,
        category: 'Dinner',
      },
      {
        id: 'c3',
        title: 'Protein Power Smoothie Bowl',
        description: 'Instagram-worthy breakfast packed with nutrients',
        ingredients: ['Frozen berries', 'Banana', 'Protein powder', 'Greek yogurt', 'Granola', 'Chia seeds'],
        steps: ['Blend frozen ingredients', 'Pour into bowl', 'Top with granola and seeds', 'Arrange toppings beautifully'],
        authorId: 'user3',
        authorName: 'FitFoodie',
        timestamp: new Date(Date.now() - 10800000).toISOString(),
        likes: 1234,
        comments: ['So pretty!', 'Tastes great too', 'Made my morning'],
        tags: ['healthy', 'instagram', 'protein'],
        rating: 4.7,
        category: 'Breakfast',
      },
    ];
    setCommunityRecipes(demoRecipes);
  }, []);

  const handleLike = (recipeId: string): void => {
    setCommunityRecipes(communityRecipes.map((r: CommunityRecipe) =>
      r.id === recipeId ? { ...r, likes: r.likes + 1 } : r
    ));
  };

  const handleComment = (recipeId: string): void => {
    if (comment.trim()) {
      setCommunityRecipes(communityRecipes.map((r: CommunityRecipe) =>
        r.id === recipeId ? { ...r, comments: [...r.comments, comment] } : r
      ));
      setComment('');
    }
  };

  const handleShareRecipe = (recipe: Recipe): void => {
    const communityRecipe: CommunityRecipe = {
      ...recipe,
      authorId: 'current-user',
      authorName: userName,
      timestamp: new Date().toISOString(),
      likes: 0,
      comments: [],
      tags: recipe.category ? [recipe.category.toLowerCase()] : [],
      rating: 5.0,
    };
    setCommunityRecipes([communityRecipe, ...communityRecipes]);
    setIsSharing(false);
    alert('Recipe shared with the community!');
  };

  const handleImport = (recipe: CommunityRecipe): void => {
    const { authorId, authorName, timestamp, likes, comments, tags, rating, ...basicRecipe } = recipe;
    onImportRecipe(basicRecipe);
    alert('Recipe imported to your cookbook!');
  };

  const filteredRecipes = searchQuery
    ? communityRecipes.filter((r: CommunityRecipe) =>
        r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.tags.some((t: string) => t.includes(searchQuery.toLowerCase()))
      )
    : communityRecipes;

  const sortedRecipes = [...filteredRecipes].sort((a: CommunityRecipe, b: CommunityRecipe) => b.likes - a.likes);

  return (
    <Card className="border-2 border-red-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="w-5 h-5 text-red-500" />
          Community Recipe Sharing
        </CardTitle>
        <CardDescription>
          Share recipes and discover what others are cooking
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Search community recipes..."
            value={searchQuery}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
          />
          <Button
            onClick={() => setIsSharing(!isSharing)}
            className="bg-red-500 hover:bg-red-600 whitespace-nowrap"
          >
            <Share2 className="w-4 h-4 mr-2" />
            Share Recipe
          </Button>
        </div>

        {isSharing && (
          <div className="bg-gray-50 p-4 rounded-lg space-y-3">
            <Input
              placeholder="Your name"
              value={userName}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setUserName(e.target.value)}
            />
            <div className="space-y-2">
              {userRecipes.slice(0, 5).map((recipe: Recipe) => (
                <Button
                  key={recipe.id}
                  onClick={() => handleShareRecipe(recipe)}
                  variant="outline"
                  className="w-full justify-start"
                >
                  {recipe.title}
                </Button>
              ))}
            </div>
          </div>
        )}

        <div className="space-y-3 max-h-96 overflow-y-auto">
          {sortedRecipes.map((recipe: CommunityRecipe) => (
            <div key={recipe.id} className="bg-white border-2 border-gray-200 rounded-lg p-4 space-y-3">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <h3 className="font-bold text-gray-900">{recipe.title}</h3>
                  <p className="text-sm text-gray-600">{recipe.description}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-xs text-gray-500">by {recipe.authorName}</span>
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                      <span className="text-xs font-medium">{recipe.rating}</span>
                    </div>
                  </div>
                </div>
                <Button
                  onClick={() => handleImport(recipe)}
                  size="sm"
                  variant="outline"
                >
                  Import
                </Button>
              </div>

              <div className="flex gap-2 flex-wrap">
                {recipe.tags.map((tag: string) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>

              <div className="flex items-center gap-4 text-sm">
                <button
                  onClick={() => handleLike(recipe.id)}
                  className="flex items-center gap-1 text-red-500 hover:text-red-600"
                >
                  <Heart className="w-4 h-4" />
                  <span>{recipe.likes}</span>
                </button>
                <button
                  onClick={() => setSelectedRecipe(selectedRecipe?.id === recipe.id ? null : recipe)}
                  className="flex items-center gap-1 text-gray-600 hover:text-gray-700"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>{recipe.comments.length}</span>
                </button>
                <div className="flex items-center gap-1 text-gray-600">
                  <TrendingUp className="w-4 h-4" />
                  <span className="text-xs">
                    {Math.floor((Date.now() - new Date(recipe.timestamp).getTime()) / 3600000)}h ago
                  </span>
                </div>
              </div>

              {selectedRecipe?.id === recipe.id && (
                <div className="space-y-2 border-t pt-3">
                  <div className="space-y-1 max-h-32 overflow-y-auto">
                    {recipe.comments.map((c: string, idx: number) => (
                      <div key={idx} className="text-sm bg-gray-50 p-2 rounded">
                        {c}
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Add a comment..."
                      value={comment}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setComment(e.target.value)}
                      onKeyDown={(e: React.KeyboardEvent) => {
                        if (e.key === 'Enter') handleComment(recipe.id);
                      }}
                    />
                    <Button onClick={() => handleComment(recipe.id)} size="sm">
                      Post
                    </Button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
