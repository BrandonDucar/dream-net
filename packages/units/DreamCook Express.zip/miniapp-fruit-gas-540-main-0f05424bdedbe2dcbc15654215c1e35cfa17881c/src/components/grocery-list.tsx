'use client';

import { useState, useEffect } from 'react';
import type { GroceryItem, Recipe, VaultRecipe, WeekMealPlan } from '@/types/recipe';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, Trash2, Download, FileText } from 'lucide-react';
import { exportGroceryListToPDF, exportGroceryListAsText } from '@/lib/pdf-export';

interface GroceryListProps {
  groceryList: GroceryItem[];
  onUpdateGroceryList: (items: GroceryItem[]) => void;
  mealPlan: WeekMealPlan;
  cookbookRecipes: Recipe[];
  vaultRecipes: VaultRecipe[];
}

export function GroceryList({ 
  groceryList, 
  onUpdateGroceryList, 
  mealPlan, 
  cookbookRecipes, 
  vaultRecipes 
}: GroceryListProps): JSX.Element {
  const [newItem, setNewItem] = useState('');

  const generateFromMealPlan = (): void => {
    const allRecipes = [...cookbookRecipes, ...vaultRecipes];
    const recipeIds: string[] = [];

    Object.values(mealPlan).forEach((day) => {
      if (day.breakfast) recipeIds.push(day.breakfast.recipeId);
      if (day.lunch) recipeIds.push(day.lunch.recipeId);
      if (day.dinner) recipeIds.push(day.dinner.recipeId);
    });

    const uniqueIngredients = new Set<string>();
    recipeIds.forEach((id: string) => {
      const recipe = allRecipes.find((r: Recipe | VaultRecipe) => r.id === id);
      if (recipe) {
        recipe.ingredients.forEach((ing: string) => uniqueIngredients.add(ing));
      }
    });

    const newGroceryList: GroceryItem[] = Array.from(uniqueIngredients).map((name: string) => ({
      name,
      checked: false,
    }));

    onUpdateGroceryList(newGroceryList);
  };

  const addItem = (): void => {
    if (newItem.trim()) {
      onUpdateGroceryList([...groceryList, { name: newItem, checked: false }]);
      setNewItem('');
    }
  };

  const toggleItem = (index: number): void => {
    const updated = [...groceryList];
    updated[index].checked = !updated[index].checked;
    onUpdateGroceryList(updated);
  };

  const removeItem = (index: number): void => {
    const updated = groceryList.filter((_: GroceryItem, i: number) => i !== index);
    onUpdateGroceryList(updated);
  };

  const clearList = (): void => {
    if (confirm('Clear the entire grocery list?')) {
      onUpdateGroceryList([]);
    }
  };

  const downloadAsText = (): void => {
    const text = exportGroceryListAsText(groceryList);
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'dream-grocery-list.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <Card className="border-2 border-gray-200">
        <CardHeader>
          <CardTitle className="text-lg text-gray-900">Grocery List</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Action Buttons */}
          <div className="flex flex-wrap gap-2">
            <Button 
              onClick={generateFromMealPlan}
              className="bg-red-500 hover:bg-red-600"
            >
              Generate from Meal Plan
            </Button>
            <Button 
              onClick={() => exportGroceryListToPDF(groceryList)}
              variant="outline"
              className="border-red-400 text-red-600 hover:bg-red-50"
            >
              <FileText className="w-4 h-4 mr-2" />
              Export PDF
            </Button>
            <Button 
              onClick={downloadAsText}
              variant="outline"
              className="border-red-400 text-red-600 hover:bg-red-50"
            >
              <Download className="w-4 h-4 mr-2" />
              Download Text
            </Button>
            {groceryList.length > 0 && (
              <Button 
                onClick={clearList}
                variant="outline"
                className="border-red-400 text-red-600 hover:bg-red-50 ml-auto"
              >
                Clear All
              </Button>
            )}
          </div>

          {/* Add New Item */}
          <div className="flex gap-2">
            <Input
              value={newItem}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewItem(e.target.value)}
              onKeyPress={(e: React.KeyboardEvent<HTMLInputElement>) => {
                if (e.key === 'Enter') addItem();
              }}
              placeholder="Add item to grocery list"
              className="flex-1"
            />
            <Button onClick={addItem} size="icon" className="bg-red-500 hover:bg-red-600">
              <Plus className="w-4 h-4" />
            </Button>
          </div>

          {/* Grocery Items */}
          {groceryList.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <p>Your grocery list is empty.</p>
              <p className="text-sm mt-2">Add items manually or generate from your meal plan.</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {groceryList.map((item: GroceryItem, index: number) => (
                <div 
                  key={index} 
                  className="flex items-center gap-3 p-3 rounded-lg border border-gray-200 hover:bg-gray-50"
                >
                  <Checkbox
                    checked={item.checked}
                    onCheckedChange={() => toggleItem(index)}
                  />
                  <span 
                    className={`flex-1 ${item.checked ? 'line-through text-gray-400' : 'text-gray-700'}`}
                  >
                    {item.name}
                  </span>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => removeItem(index)}
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          {/* Summary */}
          {groceryList.length > 0 && (
            <div className="text-sm text-gray-500 text-center pt-2 border-t">
              {groceryList.filter((item: GroceryItem) => item.checked).length} of {groceryList.length} items checked
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
