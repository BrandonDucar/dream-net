'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MapPin, Loader2, Navigation, Store, ShoppingCart, Star } from 'lucide-react';

interface NearbyPlace {
  name: string;
  address: string;
  distance: string;
  type: 'grocery' | 'farmers-market' | 'specialty';
  rating?: number;
  isOpen?: boolean;
  coordinates: {
    lat: number;
    lng: number;
  };
}

export function LocationFinder(): JSX.Element {
  const [places, setPlaces] = useState<NearbyPlace[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(
    null
  );
  const [activeFilter, setActiveFilter] = useState<'all' | 'grocery' | 'farmers-market' | 'specialty'>(
    'all'
  );

  const findNearbyStores = async (type: 'all' | 'grocery' | 'farmers-market' | 'specialty'): Promise<void> => {
    setIsLoading(true);
    setError('');
    setActiveFilter(type);

    try {
      // Get user's current location
      if (!navigator.geolocation) {
        throw new Error('Geolocation is not supported by your browser');
      }

      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
        });
      });

      const { latitude, longitude } = position.coords;
      setUserLocation({ latitude, longitude });

      // Call geofencing API
      const response = await fetch('/api/geofencing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          latitude,
          longitude,
          radius: 5000, // 5km radius
          type,
        }),
      });

      const data = await response.json();

      if (data.success) {
        setPlaces(data.places);
        if (data.demo) {
          setError(data.message);
        }
      } else {
        throw new Error(data.error || 'Failed to find nearby stores');
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to get your location';
      setError(errorMessage);
      console.error('Location error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const getTypeIcon = (type: string): JSX.Element => {
    switch (type) {
      case 'grocery':
        return <ShoppingCart className="h-4 w-4" />;
      case 'farmers-market':
        return <Store className="h-4 w-4" />;
      default:
        return <MapPin className="h-4 w-4" />;
    }
  };

  const getTypeColor = (type: string): string => {
    switch (type) {
      case 'grocery':
        return 'bg-blue-500/20 text-blue-500';
      case 'farmers-market':
        return 'bg-green-500/20 text-green-500';
      default:
        return 'bg-purple-500/20 text-purple-500';
    }
  };

  const openInMaps = (place: NearbyPlace): void => {
    const url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
      `${place.name} ${place.address}`
    )}`;
    window.open(url, '_blank');
  };

  return (
    <Card className="border-red-500/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Navigation className="h-5 w-5 text-red-500" />
          Find Nearby Stores
        </CardTitle>
        <CardDescription>
          Discover grocery stores and farmers markets near you
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Filter Tabs */}
        <Tabs value={activeFilter} onValueChange={(v) => setActiveFilter(v as typeof activeFilter)}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="grocery">Grocery</TabsTrigger>
            <TabsTrigger value="farmers-market">Markets</TabsTrigger>
            <TabsTrigger value="specialty">Specialty</TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Find Button */}
        <Button
          onClick={() => findNearbyStores(activeFilter)}
          disabled={isLoading}
          className="w-full bg-red-500 hover:bg-red-600 text-white"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Finding Stores...
            </>
          ) : (
            <>
              <MapPin className="mr-2 h-4 w-4" />
              Find Stores Near Me
            </>
          )}
        </Button>

        {/* Error Message */}
        {error && (
          <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-md text-yellow-500 text-sm">
            {error}
          </div>
        )}

        {/* User Location */}
        {userLocation && (
          <div className="text-xs text-gray-500">
            Your location: {userLocation.latitude.toFixed(4)}, {userLocation.longitude.toFixed(4)}
          </div>
        )}

        {/* Places List */}
        {places.length > 0 && (
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {places.map((place, index) => (
              <Card key={index} className="bg-gray-800/50 border-gray-700">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-white">{place.name}</h4>
                        {place.isOpen !== undefined && (
                          <Badge
                            variant="outline"
                            className={place.isOpen ? 'border-green-500 text-green-500' : 'border-gray-500 text-gray-500'}
                          >
                            {place.isOpen ? 'Open' : 'Closed'}
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-400 mb-2">{place.address}</p>
                      <div className="flex items-center gap-3 text-xs text-gray-500">
                        <Badge className={getTypeColor(place.type)}>
                          {getTypeIcon(place.type)}
                          <span className="ml-1 capitalize">{place.type.replace('-', ' ')}</span>
                        </Badge>
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {place.distance}
                        </span>
                        {place.rating && (
                          <span className="flex items-center gap-1">
                            <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                            {place.rating}
                          </span>
                        )}
                      </div>
                    </div>
                    <Button
                      onClick={() => openInMaps(place)}
                      size="sm"
                      variant="outline"
                      className="border-red-500/50 hover:bg-red-500/10"
                    >
                      Directions
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
