'use client';

import { useState, useEffect } from 'react';
import type { Recipe, VaultRecipe, WeekMealPlan, MealPlanItem } from '@/types/recipe';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, X } from 'lucide-react';

interface MealPlannerGridProps {
  mealPlan: WeekMealPlan;
  onUpdateMealPlan: (plan: WeekMealPlan) => void;
  cookbookRecipes: Recipe[];
  vaultRecipes: VaultRecipe[];
}

type DayKey = keyof WeekMealPlan;
type MealType = 'breakfast' | 'lunch' | 'dinner';

const DAYS: { key: DayKey; label: string }[] = [
  { key: 'monday', label: 'Monday' },
  { key: 'tuesday', label: 'Tuesday' },
  { key: 'wednesday', label: 'Wednesday' },
  { key: 'thursday', label: 'Thursday' },
  { key: 'friday', label: 'Friday' },
  { key: 'saturday', label: 'Saturday' },
  { key: 'sunday', label: 'Sunday' },
];

const MEALS: MealType[] = ['breakfast', 'lunch', 'dinner'];

export function MealPlannerGrid({ 
  mealPlan, 
  onUpdateMealPlan, 
  cookbookRecipes, 
  vaultRecipes 
}: MealPlannerGridProps): JSX.Element {
  const [allRecipes, setAllRecipes] = useState<(Recipe | VaultRecipe)[]>([]);

  useEffect(() => {
    setAllRecipes([...cookbookRecipes, ...vaultRecipes]);
  }, [cookbookRecipes, vaultRecipes]);

  const addMeal = (day: DayKey, mealType: MealType, recipeId: string): void => {
    const recipe = allRecipes.find((r: Recipe | VaultRecipe) => r.id === recipeId);
    if (!recipe) return;

    const updatedPlan: WeekMealPlan = {
      ...mealPlan,
      [day]: {
        ...mealPlan[day],
        [mealType]: {
          recipeId: recipe.id,
          recipeTitle: recipe.title,
        },
      },
    };

    onUpdateMealPlan(updatedPlan);
  };

  const removeMeal = (day: DayKey, mealType: MealType): void => {
    const updatedDay = { ...mealPlan[day] };
    delete updatedDay[mealType];

    const updatedPlan: WeekMealPlan = {
      ...mealPlan,
      [day]: updatedDay,
    };

    onUpdateMealPlan(updatedPlan);
  };

  return (
    <div className="space-y-4">
      {DAYS.map(({ key, label }: { key: DayKey; label: string }) => (
        <Card key={key} className="border-2 border-gray-200">
          <CardHeader className="bg-gray-50">
            <CardTitle className="text-lg text-gray-900">{label}</CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {MEALS.map((mealType: MealType) => {
                const meal = mealPlan[key][mealType];
                return (
                  <div key={mealType} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-semibold capitalize text-gray-700">
                        {mealType}
                      </span>
                      {meal && (
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => removeMeal(key, mealType)}
                          className="h-6 w-6"
                        >
                          <X className="w-4 h-4 text-red-500" />
                        </Button>
                      )}
                    </div>
                    
                    {meal ? (
                      <Badge 
                        variant="outline" 
                        className="w-full justify-center py-2 bg-red-50 text-red-600 border-red-300"
                      >
                        {meal.recipeTitle}
                      </Badge>
                    ) : (
                      <Select onValueChange={(value: string) => addMeal(key, mealType, value)}>
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Add meal" />
                        </SelectTrigger>
                        <SelectContent>
                          {allRecipes.length === 0 ? (
                            <SelectItem value="none">No recipes available</SelectItem>
                          ) : (
                            allRecipes.map((recipe: Recipe | VaultRecipe) => (
                              <SelectItem key={recipe.id} value={recipe.id}>
                                {recipe.title}
                              </SelectItem>
                            ))
                          )}
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
