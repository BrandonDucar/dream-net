'use client'
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Apple, TrendingUp, Target, Activity } from 'lucide-react';
import type { Recipe, VaultRecipe, NutritionInfo } from '@/types/recipe';

interface NutritionTrackerProps {
  recipes?: (Recipe | VaultRecipe)[];
}

const estimateNutrition = (recipe: Recipe | VaultRecipe): NutritionInfo => {
  const ingredientCount = recipe.ingredients.length;
  const hasProtein = recipe.ingredients.some((i: string) => 
    i.toLowerCase().includes('chicken') || 
    i.toLowerCase().includes('beef') || 
    i.toLowerCase().includes('fish') ||
    i.toLowerCase().includes('egg')
  );
  const hasCarbs = recipe.ingredients.some((i: string) => 
    i.toLowerCase().includes('pasta') || 
    i.toLowerCase().includes('rice') || 
    i.toLowerCase().includes('bread') ||
    i.toLowerCase().includes('flour')
  );

  return {
    calories: ingredientCount * 80 + (hasProtein ? 200 : 100),
    protein: hasProtein ? 35 : 12,
    carbs: hasCarbs ? 45 : 25,
    fat: ingredientCount * 3 + 15,
    fiber: ingredientCount * 2 + 5,
  };
};

export function NutritionTracker({ recipes = [] }: NutritionTrackerProps): JSX.Element {
  const [dailyGoals, setDailyGoals] = useState({
    calories: 2000,
    protein: 150,
    carbs: 250,
    fat: 65,
  });
  const [consumed, setConsumed] = useState({
    calories: 0,
    protein: 0,
    carbs: 0,
    fat: 0,
    fiber: 0,
  });

  const handleAddRecipe = (recipe: Recipe | VaultRecipe): void => {
    const nutrition = estimateNutrition(recipe);
    setConsumed({
      calories: consumed.calories + nutrition.calories,
      protein: consumed.protein + nutrition.protein,
      carbs: consumed.carbs + nutrition.carbs,
      fat: consumed.fat + nutrition.fat,
      fiber: consumed.fiber + nutrition.fiber,
    });
  };

  const handleReset = (): void => {
    setConsumed({
      calories: 0,
      protein: 0,
      carbs: 0,
      fat: 0,
      fiber: 0,
    });
  };

  const getProgress = (current: number, goal: number): number => {
    return Math.min((current / goal) * 100, 100);
  };

  return (
    <Card className="border-2 border-red-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Apple className="w-5 h-5 text-red-500" />
          Nutrition Tracker
        </CardTitle>
        <CardDescription>
          Track your daily macro and calorie intake
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-medium text-gray-700 mb-1 block">Calorie Goal</label>
            <Input
              type="number"
              value={dailyGoals.calories}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                setDailyGoals({ ...dailyGoals, calories: parseInt(e.target.value) || 0 })
              }
              className="h-8"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-gray-700 mb-1 block">Protein Goal (g)</label>
            <Input
              type="number"
              value={dailyGoals.protein}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                setDailyGoals({ ...dailyGoals, protein: parseInt(e.target.value) || 0 })
              }
              className="h-8"
            />
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700 flex items-center gap-1">
                <Activity className="w-4 h-4 text-red-500" />
                Calories
              </span>
              <span className="text-sm font-bold text-gray-900">
                {consumed.calories} / {dailyGoals.calories}
              </span>
            </div>
            <Progress value={getProgress(consumed.calories, dailyGoals.calories)} className="h-2" />
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700 flex items-center gap-1">
                <TrendingUp className="w-4 h-4 text-blue-500" />
                Protein (g)
              </span>
              <span className="text-sm font-bold text-gray-900">
                {consumed.protein}g / {dailyGoals.protein}g
              </span>
            </div>
            <Progress value={getProgress(consumed.protein, dailyGoals.protein)} className="h-2" />
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700 flex items-center gap-1">
                <Target className="w-4 h-4 text-orange-500" />
                Carbs (g)
              </span>
              <span className="text-sm font-bold text-gray-900">
                {consumed.carbs}g / {dailyGoals.carbs}g
              </span>
            </div>
            <Progress value={getProgress(consumed.carbs, dailyGoals.carbs)} className="h-2" />
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700 flex items-center gap-1">
                <Target className="w-4 h-4 text-yellow-500" />
                Fat (g)
              </span>
              <span className="text-sm font-bold text-gray-900">
                {consumed.fat}g / {dailyGoals.fat}g
              </span>
            </div>
            <Progress value={getProgress(consumed.fat, dailyGoals.fat)} className="h-2" />
          </div>

          <div className="bg-gray-50 p-3 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-gray-700">Fiber</span>
              <span className="text-sm font-bold text-gray-900">{consumed.fiber}g</span>
            </div>
          </div>
        </div>

        {recipes.length > 0 && (
          <div>
            <p className="text-sm font-medium text-gray-700 mb-2">Add from recipes:</p>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {recipes.slice(0, 5).map((recipe: Recipe | VaultRecipe) => (
                <Button
                  key={recipe.id}
                  onClick={() => handleAddRecipe(recipe)}
                  variant="outline"
                  className="w-full justify-start text-left h-auto py-2"
                  size="sm"
                >
                  <span className="truncate">{recipe.title}</span>
                </Button>
              ))}
            </div>
          </div>
        )}

        <Button onClick={handleReset} variant="outline" className="w-full">
          Reset Daily Tracking
        </Button>
      </CardContent>
    </Card>
  );
}
