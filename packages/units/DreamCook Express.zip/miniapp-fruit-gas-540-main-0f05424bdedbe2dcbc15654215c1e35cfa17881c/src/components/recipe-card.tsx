'use client';

import type { Recipe } from '@/types/recipe';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChefHat, Eye, Save } from 'lucide-react';

interface RecipeCardProps {
  recipe: Recipe;
  onView: (recipe: Recipe) => void;
  onSaveToVault?: (recipe: Recipe) => void;
  showSaveButton?: boolean;
}

export function RecipeCard({ recipe, onView, onSaveToVault, showSaveButton = true }: RecipeCardProps): JSX.Element {
  return (
    <Card className="hover:shadow-lg transition-shadow border-2 border-gray-200 hover:border-red-400">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-xl text-gray-900 flex items-center gap-2">
              <ChefHat className="w-5 h-5 text-red-500" />
              {recipe.title}
            </CardTitle>
            <CardDescription className="mt-2 text-gray-600">
              {recipe.description}
            </CardDescription>
          </div>
        </div>
        {recipe.category && (
          <Badge variant="outline" className="mt-2 w-fit bg-red-50 text-red-600 border-red-300">
            {recipe.category}
          </Badge>
        )}
      </CardHeader>
      <CardContent>
        <div className="flex flex-col gap-2">
          <p className="text-sm text-gray-500">
            {recipe.ingredients.length} ingredients • {recipe.steps.length} steps
          </p>
          <div className="flex gap-2 mt-2">
            <Button 
              onClick={() => onView(recipe)} 
              className="flex-1 bg-gray-800 hover:bg-gray-900"
            >
              <Eye className="w-4 h-4 mr-2" />
              View Recipe
            </Button>
            {showSaveButton && onSaveToVault && (
              <Button 
                onClick={() => onSaveToVault(recipe)} 
                variant="outline"
                className="border-red-400 text-red-600 hover:bg-red-50"
              >
                <Save className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
