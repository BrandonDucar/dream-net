'use client';

import type { Recipe, VaultRecipe } from '@/types/recipe';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ChefHat, Sparkles, StickyNote, FileText, Utensils } from 'lucide-react';
import { exportRecipeToPDF } from '@/lib/pdf-export';

interface RecipeDetailProps {
  recipe: Recipe | VaultRecipe | null;
  open: boolean;
  onClose: () => void;
}

export function RecipeDetail({ recipe, open, onClose }: RecipeDetailProps): JSX.Element {
  if (!recipe) return <></>;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-2 text-gray-900">
            <ChefHat className="w-6 h-6 text-red-500" />
            {recipe.title}
          </DialogTitle>
          <DialogDescription className="text-base text-gray-600">
            {recipe.description}
          </DialogDescription>
          {recipe.category && (
            <Badge variant="outline" className="w-fit bg-red-50 text-red-600 border-red-300">
              {recipe.category}
            </Badge>
          )}
        </DialogHeader>

        <ScrollArea className="max-h-[60vh] pr-4">
          <div className="space-y-6">
            {/* Photo for Vault Recipes */}
            {'photoUrl' in recipe && recipe.photoUrl && (
              <div className="rounded-lg overflow-hidden">
                <img 
                  src={recipe.photoUrl} 
                  alt={recipe.title}
                  className="w-full h-64 object-cover"
                />
              </div>
            )}

            {/* Ingredients */}
            <div>
              <h3 className="text-lg font-semibold flex items-center gap-2 mb-3 text-gray-900">
                <Utensils className="w-5 h-5 text-red-500" />
                Ingredients
              </h3>
              <ul className="space-y-2">
                {recipe.ingredients.map((ingredient: string, index: number) => (
                  <li key={index} className="flex items-start gap-2 text-gray-700">
                    <span className="text-red-500 mt-1">•</span>
                    <span>{ingredient}</span>
                  </li>
                ))}
              </ul>
            </div>

            <Separator />

            {/* Steps */}
            <div>
              <h3 className="text-lg font-semibold flex items-center gap-2 mb-3 text-gray-900">
                <FileText className="w-5 h-5 text-red-500" />
                Instructions
              </h3>
              <ol className="space-y-3">
                {recipe.steps.map((step: string, index: number) => (
                  <li key={index} className="flex gap-3 text-gray-700">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-red-500 text-white flex items-center justify-center text-sm font-semibold">
                      {index + 1}
                    </span>
                    <span className="flex-1">{step}</span>
                  </li>
                ))}
              </ol>
            </div>

            {/* Dream Upgrades */}
            {recipe.dreamUpgrades && recipe.dreamUpgrades.length > 0 && (
              <>
                <Separator />
                <div>
                  <h3 className="text-lg font-semibold flex items-center gap-2 mb-3 text-gray-900">
                    <Sparkles className="w-5 h-5 text-red-500" />
                    Dream Upgrades
                  </h3>
                  <ul className="space-y-2">
                    {recipe.dreamUpgrades.map((upgrade: string, index: number) => (
                      <li key={index} className="flex items-start gap-2 text-gray-700">
                        <span className="text-red-500 mt-1">✨</span>
                        <span>{upgrade}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </>
            )}

            {/* Notes */}
            {recipe.notes && (
              <>
                <Separator />
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="text-lg font-semibold flex items-center gap-2 mb-2 text-gray-900">
                    <StickyNote className="w-5 h-5 text-red-500" />
                    Notes
                  </h3>
                  <p className="text-gray-700">{recipe.notes}</p>
                </div>
              </>
            )}

            {/* Date Added for Vault */}
            {'dateAdded' in recipe && (
              <p className="text-sm text-gray-500">
                Added: {new Date(recipe.dateAdded).toLocaleDateString()}
              </p>
            )}
          </div>
        </ScrollArea>

        <div className="flex gap-2 pt-4 border-t">
          <Button 
            onClick={() => exportRecipeToPDF(recipe)}
            className="flex-1 bg-red-500 hover:bg-red-600"
          >
            Export as PDF
          </Button>
          <Button onClick={onClose} variant="outline" className="flex-1">
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
