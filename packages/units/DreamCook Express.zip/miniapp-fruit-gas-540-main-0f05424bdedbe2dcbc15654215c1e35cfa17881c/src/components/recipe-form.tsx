'use client';

import { useState, useEffect } from 'react';
import type { Recipe, VaultRecipe } from '@/types/recipe';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Plus, Trash2, Upload } from 'lucide-react';

interface RecipeFormProps {
  recipe?: Recipe | VaultRecipe | null;
  open: boolean;
  onClose: () => void;
  onSave: (recipe: Recipe | VaultRecipe) => void;
  isVault?: boolean;
}

export function RecipeForm({ recipe, open, onClose, onSave, isVault = false }: RecipeFormProps): JSX.Element {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [ingredients, setIngredients] = useState<string[]>(['']);
  const [steps, setSteps] = useState<string[]>(['']);
  const [dreamUpgrades, setDreamUpgrades] = useState<string[]>(['']);
  const [notes, setNotes] = useState('');
  const [category, setCategory] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');

  useEffect(() => {
    if (recipe) {
      setTitle(recipe.title);
      setDescription(recipe.description);
      setIngredients(recipe.ingredients);
      setSteps(recipe.steps);
      setDreamUpgrades(recipe.dreamUpgrades || ['']);
      setNotes(recipe.notes || '');
      setCategory(recipe.category || '');
      if ('photoUrl' in recipe) {
        setPhotoUrl(recipe.photoUrl || '');
      }
    } else {
      resetForm();
    }
  }, [recipe, open]);

  const resetForm = (): void => {
    setTitle('');
    setDescription('');
    setIngredients(['']);
    setSteps(['']);
    setDreamUpgrades(['']);
    setNotes('');
    setCategory('');
    setPhotoUrl('');
  };

  const handleSubmit = (): void => {
    const filteredIngredients = ingredients.filter((i: string) => i.trim() !== '');
    const filteredSteps = steps.filter((s: string) => s.trim() !== '');
    const filteredUpgrades = dreamUpgrades.filter((u: string) => u.trim() !== '');

    if (!title || filteredIngredients.length === 0 || filteredSteps.length === 0) {
      alert('Please fill in title, at least one ingredient, and at least one step.');
      return;
    }

    const recipeData: Recipe | VaultRecipe = {
      id: recipe?.id || Date.now().toString(),
      title,
      description,
      ingredients: filteredIngredients,
      steps: filteredSteps,
      dreamUpgrades: filteredUpgrades.length > 0 ? filteredUpgrades : undefined,
      notes: notes || undefined,
      category: category || undefined,
      ...(isVault && {
        dateAdded: 'dateAdded' in (recipe || {}) ? (recipe as VaultRecipe).dateAdded : new Date().toISOString(),
        photoUrl: photoUrl || undefined,
      }),
    };

    onSave(recipeData as Recipe & VaultRecipe);
    onClose();
    resetForm();
  };

  const addItem = (setter: React.Dispatch<React.SetStateAction<string[]>>): void => {
    setter((prev: string[]) => [...prev, '']);
  };

  const removeItem = (index: number, setter: React.Dispatch<React.SetStateAction<string[]>>): void => {
    setter((prev: string[]) => prev.filter((_: string, i: number) => i !== index));
  };

  const updateItem = (index: number, value: string, setter: React.Dispatch<React.SetStateAction<string[]>>): void => {
    setter((prev: string[]) => {
      const updated = [...prev];
      updated[index] = value;
      return updated;
    });
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="text-2xl text-gray-900">
            {recipe ? 'Edit Recipe' : 'Add New Recipe'}
          </DialogTitle>
          <DialogDescription>
            {isVault ? 'Add a new recipe to your personal vault' : 'Create a new recipe for the cookbook'}
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="max-h-[60vh] pr-4">
          <div className="space-y-4">
            {/* Title */}
            <div>
              <Label htmlFor="title" className="text-gray-900">Recipe Title *</Label>
              <Input
                id="title"
                value={title}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTitle(e.target.value)}
                placeholder="e.g., DreamFire Pasta"
                className="mt-1"
              />
            </div>

            {/* Description */}
            <div>
              <Label htmlFor="description" className="text-gray-900">Description *</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
                placeholder="Brief description of the dish"
                className="mt-1"
                rows={2}
              />
            </div>

            {/* Category */}
            <div>
              <Label htmlFor="category" className="text-gray-900">Category</Label>
              <Input
                id="category"
                value={category}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCategory(e.target.value)}
                placeholder="e.g., Breakfast, Lunch, Dinner"
                className="mt-1"
              />
            </div>

            {/* Photo Upload (Vault only) */}
            {isVault && (
              <div>
                <Label htmlFor="photo" className="text-gray-900">Photo</Label>
                <div className="mt-1 space-y-2">
                  <Input
                    id="photo"
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                  />
                  {photoUrl && (
                    <img src={photoUrl} alt="Preview" className="w-full h-48 object-cover rounded" />
                  )}
                </div>
              </div>
            )}

            {/* Ingredients */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label className="text-gray-900">Ingredients *</Label>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={() => addItem(setIngredients)}
                  className="border-red-400 text-red-600 hover:bg-red-50"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Add
                </Button>
              </div>
              <div className="space-y-2">
                {ingredients.map((ingredient: string, index: number) => (
                  <div key={index} className="flex gap-2">
                    <Input
                      value={ingredient}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateItem(index, e.target.value, setIngredients)}
                      placeholder="e.g., 1 cup flour"
                    />
                    {ingredients.length > 1 && (
                      <Button
                        type="button"
                        size="icon"
                        variant="outline"
                        onClick={() => removeItem(index, setIngredients)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Steps */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label className="text-gray-900">Steps *</Label>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={() => addItem(setSteps)}
                  className="border-red-400 text-red-600 hover:bg-red-50"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Add
                </Button>
              </div>
              <div className="space-y-2">
                {steps.map((step: string, index: number) => (
                  <div key={index} className="flex gap-2">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-red-500 text-white flex items-center justify-center text-sm font-semibold mt-2">
                      {index + 1}
                    </span>
                    <Textarea
                      value={step}
                      onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => updateItem(index, e.target.value, setSteps)}
                      placeholder="Describe this step"
                      rows={2}
                    />
                    {steps.length > 1 && (
                      <Button
                        type="button"
                        size="icon"
                        variant="outline"
                        onClick={() => removeItem(index, setSteps)}
                        className="mt-2"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Dream Upgrades */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label className="text-gray-900">Dream Upgrades (Optional)</Label>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={() => addItem(setDreamUpgrades)}
                  className="border-red-400 text-red-600 hover:bg-red-50"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Add
                </Button>
              </div>
              <div className="space-y-2">
                {dreamUpgrades.map((upgrade: string, index: number) => (
                  <div key={index} className="flex gap-2">
                    <Input
                      value={upgrade}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateItem(index, e.target.value, setDreamUpgrades)}
                      placeholder="e.g., Add grilled chicken"
                    />
                    <Button
                      type="button"
                      size="icon"
                      variant="outline"
                      onClick={() => removeItem(index, setDreamUpgrades)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            {/* Notes */}
            <div>
              <Label htmlFor="notes" className="text-gray-900">Notes (Optional)</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNotes(e.target.value)}
                placeholder="Any additional tips or notes"
                className="mt-1"
                rows={3}
              />
            </div>
          </div>
        </ScrollArea>

        <div className="flex gap-2 pt-4 border-t">
          <Button onClick={handleSubmit} className="flex-1 bg-red-500 hover:bg-red-600">
            {recipe ? 'Update' : 'Create'} Recipe
          </Button>
          <Button onClick={onClose} variant="outline" className="flex-1">
            Cancel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
