'use client'
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Leaf, Sun, Wind, Snowflake, MapPin } from 'lucide-react';
import type { Recipe } from '@/types/recipe';

interface SeasonalRecipesProps {
  recipes: Recipe[];
  onSelectRecipe: (recipe: Recipe) => void;
}

type SeasonName = 'spring' | 'summer' | 'fall' | 'winter';

interface SeasonInfo {
  name: SeasonName;
  icon: JSX.Element;
  color: string;
  months: number[];
  tags: string[];
}

const SEASONS: Record<SeasonName, SeasonInfo> = {
  spring: {
    name: 'spring',
    icon: <Leaf className="w-5 h-5" />,
    color: 'bg-green-500',
    months: [3, 4, 5],
    tags: ['fresh', 'light', 'salad', 'asparagus', 'peas', 'herbs'],
  },
  summer: {
    name: 'summer',
    icon: <Sun className="w-5 h-5" />,
    color: 'bg-yellow-500',
    months: [6, 7, 8],
    tags: ['grilled', 'bbq', 'cold', 'smoothie', 'tomato', 'berries'],
  },
  fall: {
    name: 'fall',
    icon: <Wind className="w-5 h-5" />,
    color: 'bg-orange-500',
    months: [9, 10, 11],
    tags: ['warm', 'hearty', 'pumpkin', 'squash', 'apple', 'cinnamon'],
  },
  winter: {
    name: 'winter',
    icon: <Snowflake className="w-5 h-5" />,
    color: 'bg-blue-500',
    months: [12, 1, 2],
    tags: ['soup', 'stew', 'slow', 'comfort', 'hot', 'roasted'],
  },
};

export function SeasonalRecipes({ recipes, onSelectRecipe }: SeasonalRecipesProps): JSX.Element {
  const [currentSeason, setCurrentSeason] = useState<SeasonName>('spring');
  const [location, setLocation] = useState<string>('Unknown');
  const [seasonalRecipes, setSeasonalRecipes] = useState<Recipe[]>([]);

  useEffect(() => {
    const month = new Date().getMonth() + 1;
    const season = Object.entries(SEASONS).find(([_, info]: [string, SeasonInfo]) =>
      info.months.includes(month)
    )?.[0] as SeasonName || 'spring';
    setCurrentSeason(season);

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position: GeolocationPosition) => {
          fetch(`https://nominatim.openstreetmap.org/reverse?lat=${position.coords.latitude}&lon=${position.coords.longitude}&format=json`)
            .then((res: Response) => res.json())
            .then((data: { address?: { city?: string; state?: string; country?: string } }) => {
              const city = data.address?.city || data.address?.state || data.address?.country || 'Unknown';
              setLocation(city);
            })
            .catch(() => setLocation('Location unavailable'));
        },
        () => setLocation('Location unavailable')
      );
    }

    const filtered = recipes.filter((recipe: Recipe) => {
      const recipeText = `${recipe.title} ${recipe.description} ${recipe.ingredients.join(' ')}`.toLowerCase();
      return SEASONS[season].tags.some((tag: string) => recipeText.includes(tag));
    });
    setSeasonalRecipes(filtered);
  }, [recipes]);

  const seasonInfo = SEASONS[currentSeason];

  return (
    <Card className="border-2 border-red-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {seasonInfo.icon}
          Seasonal Recipes
        </CardTitle>
        <CardDescription className="flex items-center gap-2">
          <MapPin className="w-4 h-4" />
          {location} • {currentSeason.charAt(0).toUpperCase() + currentSeason.slice(1)} season
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2 flex-wrap">
          {seasonInfo.tags.map((tag: string) => (
            <Badge key={tag} variant="secondary" className="bg-red-50 text-red-700">
              {tag}
            </Badge>
          ))}
        </div>

        {seasonalRecipes.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <p>No seasonal recipes found for {currentSeason}</p>
            <p className="text-sm mt-2">Try adding recipes with seasonal ingredients</p>
          </div>
        ) : (
          <div className="space-y-3">
            {seasonalRecipes.slice(0, 5).map((recipe: Recipe) => (
              <div
                key={recipe.id}
                onClick={() => onSelectRecipe(recipe)}
                className="p-3 bg-white border-2 border-gray-200 rounded-lg hover:border-red-300 cursor-pointer transition-colors"
              >
                <h4 className="font-semibold text-gray-900">{recipe.title}</h4>
                <p className="text-sm text-gray-600 line-clamp-2">{recipe.description}</p>
                <div className="flex gap-2 mt-2">
                  {recipe.category && (
                    <Badge variant="outline" className="text-xs">
                      {recipe.category}
                    </Badge>
                  )}
                  <Badge className={`${seasonInfo.color} text-white text-xs`}>
                    {currentSeason}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="bg-red-50 p-3 rounded-lg">
          <p className="text-sm text-gray-700">
            <strong>🌿 Tip:</strong> Eating seasonal foods supports local farmers and ensures peak flavor!
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
