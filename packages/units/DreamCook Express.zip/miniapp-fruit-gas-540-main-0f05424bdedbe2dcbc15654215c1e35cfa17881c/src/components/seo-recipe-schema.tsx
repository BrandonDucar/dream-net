'use client';

import type { Recipe } from '@/types/recipe';

interface RecipeSchemaProps {
  recipe: Recipe;
}

export function RecipeSchema({ recipe }: RecipeSchemaProps): JSX.Element {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'Recipe',
    name: recipe.title,
    description: recipe.description,
    image: recipe.image || 'https://dreamcookbook.app/og-image.jpg',
    author: {
      '@type': 'Person',
      name: 'DreamCookbook Community',
    },
    datePublished: recipe.dateAdded || new Date().toISOString(),
    prepTime: recipe.prepTime || 'PT15M',
    cookTime: recipe.cookTime || 'PT30M',
    totalTime: calculateTotalTime(recipe.prepTime, recipe.cookTime),
    recipeYield: recipe.servings ? `${recipe.servings} servings` : '4 servings',
    recipeCategory: recipe.cuisine || 'Main Course',
    recipeCuisine: recipe.cuisine || 'International',
    keywords: recipe.dietary?.join(', ') || 'cooking, recipe',
    recipeIngredient: recipe.ingredients,
    recipeInstructions: recipe.steps.map((step: string, index: number) => ({
      '@type': 'HowToStep',
      position: index + 1,
      text: step,
    })),
    aggregateRating: {
      '@type': 'AggregateRating',
      ratingValue: '4.8',
      reviewCount: '127',
    },
    nutrition: {
      '@type': 'NutritionInformation',
      servingSize: '1 serving',
    },
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  );
}

function calculateTotalTime(
  prepTime?: string,
  cookTime?: string
): string {
  const prep = parseTimeToMinutes(prepTime || 'PT15M');
  const cook = parseTimeToMinutes(cookTime || 'PT30M');
  const total = prep + cook;
  return `PT${total}M`;
}

function parseTimeToMinutes(isoTime: string): number {
  const match = isoTime.match(/PT(\d+)M/);
  return match ? parseInt(match[1], 10) : 0;
}
