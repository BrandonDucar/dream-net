'use client'
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Timer, Thermometer, Power, Play, Pause, Square } from 'lucide-react';
import type { AppliancePreset } from '@/types/recipe';

const INSTANT_POT_PRESETS: AppliancePreset[] = [
  { id: '1', name: 'Pressure Cook', type: 'instant-pot', time: 1200, instructions: 'High pressure for 20 minutes' },
  { id: '2', name: 'Slow Cook', type: 'instant-pot', time: 14400, instructions: 'Low heat for 4 hours' },
  { id: '3', name: 'Steam', type: 'instant-pot', time: 600, instructions: 'Steam mode for 10 minutes' },
  { id: '4', name: 'Sauté', type: 'instant-pot', time: 900, instructions: 'Sauté mode for 15 minutes' },
];

const AIR_FRYER_PRESETS: AppliancePreset[] = [
  { id: '5', name: 'French Fries', type: 'air-fryer', temperature: 400, time: 1200, instructions: '400°F for 20 minutes' },
  { id: '6', name: 'Chicken Wings', type: 'air-fryer', temperature: 380, time: 1500, instructions: '380°F for 25 minutes' },
  { id: '7', name: 'Fish Fillet', type: 'air-fryer', temperature: 360, time: 720, instructions: '360°F for 12 minutes' },
  { id: '8', name: 'Vegetables', type: 'air-fryer', temperature: 375, time: 900, instructions: '375°F for 15 minutes' },
];

const SMART_OVEN_PRESETS: AppliancePreset[] = [
  { id: '9', name: 'Bake', type: 'smart-oven', temperature: 350, time: 1800, instructions: '350°F for 30 minutes' },
  { id: '10', name: 'Roast', type: 'smart-oven', temperature: 425, time: 2700, instructions: '425°F for 45 minutes' },
  { id: '11', name: 'Broil', type: 'smart-oven', temperature: 500, time: 600, instructions: '500°F for 10 minutes' },
  { id: '12', name: 'Pizza', type: 'smart-oven', temperature: 450, time: 900, instructions: '450°F for 15 minutes' },
];

export function SmartApplianceHub(): JSX.Element {
  const [activeAppliance, setActiveAppliance] = useState<'instant-pot' | 'air-fryer' | 'smart-oven'>('instant-pot');
  const [selectedPreset, setSelectedPreset] = useState<AppliancePreset | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(0);

  useEffect(() => {
    if (isRunning && !isPaused && timeRemaining > 0) {
      const timer = setInterval(() => {
        setTimeRemaining((prev: number) => {
          if (prev <= 1) {
            setIsRunning(false);
            alert('Cooking complete!');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isRunning, isPaused, timeRemaining]);

  const handleStartCooking = (): void => {
    if (selectedPreset) {
      setTimeRemaining(selectedPreset.time);
      setIsRunning(true);
      setIsPaused(false);
    }
  };

  const handlePause = (): void => {
    setIsPaused(!isPaused);
  };

  const handleStop = (): void => {
    setIsRunning(false);
    setIsPaused(false);
    setTimeRemaining(0);
  };

  const formatTime = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const getPresets = (): AppliancePreset[] => {
    if (activeAppliance === 'instant-pot') return INSTANT_POT_PRESETS;
    if (activeAppliance === 'air-fryer') return AIR_FRYER_PRESETS;
    return SMART_OVEN_PRESETS;
  };

  return (
    <Card className="border-2 border-red-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Power className="w-5 h-5 text-red-500" />
          Smart Appliance Hub
        </CardTitle>
        <CardDescription>
          Control your cooking devices with preset modes
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Tabs value={activeAppliance} onValueChange={(v: string) => setActiveAppliance(v as typeof activeAppliance)}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="instant-pot">Instant Pot</TabsTrigger>
            <TabsTrigger value="air-fryer">Air Fryer</TabsTrigger>
            <TabsTrigger value="smart-oven">Smart Oven</TabsTrigger>
          </TabsList>

          <TabsContent value={activeAppliance} className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">Select Preset</label>
              <Select onValueChange={(value: string) => {
                const preset = getPresets().find((p: AppliancePreset) => p.id === value);
                setSelectedPreset(preset || null);
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a cooking mode" />
                </SelectTrigger>
                <SelectContent>
                  {getPresets().map((preset: AppliancePreset) => (
                    <SelectItem key={preset.id} value={preset.id}>
                      {preset.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedPreset && (
              <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                <div className="flex items-center gap-2 text-gray-700">
                  <Timer className="w-4 h-4" />
                  <span className="text-sm font-medium">Time: {formatTime(selectedPreset.time)}</span>
                </div>
                {selectedPreset.temperature && (
                  <div className="flex items-center gap-2 text-gray-700">
                    <Thermometer className="w-4 h-4" />
                    <span className="text-sm font-medium">Temperature: {selectedPreset.temperature}°F</span>
                  </div>
                )}
                <p className="text-sm text-gray-600">{selectedPreset.instructions}</p>
              </div>
            )}

            {isRunning && (
              <div className="bg-red-50 p-4 rounded-lg text-center">
                <div className="text-3xl font-bold text-gray-900 mb-2">
                  {formatTime(timeRemaining)}
                </div>
                <p className="text-sm text-gray-600">
                  {isPaused ? 'Paused' : 'Cooking in progress...'}
                </p>
              </div>
            )}

            <div className="flex gap-2">
              {!isRunning ? (
                <Button
                  onClick={handleStartCooking}
                  disabled={!selectedPreset}
                  className="flex-1 bg-red-500 hover:bg-red-600"
                >
                  <Play className="w-4 h-4 mr-2" />
                  Start Cooking
                </Button>
              ) : (
                <>
                  <Button
                    onClick={handlePause}
                    variant="outline"
                    className="flex-1"
                  >
                    <Pause className="w-4 h-4 mr-2" />
                    {isPaused ? 'Resume' : 'Pause'}
                  </Button>
                  <Button
                    onClick={handleStop}
                    variant="destructive"
                    className="flex-1"
                  >
                    <Square className="w-4 h-4 mr-2" />
                    Stop
                  </Button>
                </>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
