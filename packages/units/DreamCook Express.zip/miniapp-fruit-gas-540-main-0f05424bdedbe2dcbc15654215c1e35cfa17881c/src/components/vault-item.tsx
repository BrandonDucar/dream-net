'use client';

import type { VaultRecipe } from '@/types/recipe';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Eye, Edit, Trash2, Calendar } from 'lucide-react';

interface VaultItemProps {
  recipe: VaultRecipe;
  onView: (recipe: VaultRecipe) => void;
  onEdit: (recipe: VaultRecipe) => void;
  onDelete: (id: string) => void;
}

export function VaultItem({ recipe, onView, onEdit, onDelete }: VaultItemProps): JSX.Element {
  return (
    <Card className="hover:shadow-lg transition-shadow border-2 border-gray-200 hover:border-red-400">
      <CardHeader>
        {recipe.photoUrl && (
          <div className="mb-3 rounded-lg overflow-hidden">
            <img 
              src={recipe.photoUrl} 
              alt={recipe.title}
              className="w-full h-48 object-cover"
            />
          </div>
        )}
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-xl text-gray-900">
              {recipe.title}
            </CardTitle>
            <CardDescription className="mt-2 text-gray-600">
              {recipe.description}
            </CardDescription>
          </div>
        </div>
        <div className="flex items-center gap-2 mt-2">
          {recipe.category && (
            <Badge variant="outline" className="bg-red-50 text-red-600 border-red-300">
              {recipe.category}
            </Badge>
          )}
          <div className="flex items-center gap-1 text-xs text-gray-500 ml-auto">
            <Calendar className="w-3 h-3" />
            {new Date(recipe.dateAdded).toLocaleDateString()}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col gap-2">
          <p className="text-sm text-gray-500">
            {recipe.ingredients.length} ingredients • {recipe.steps.length} steps
          </p>
          <div className="flex gap-2 mt-2">
            <Button 
              onClick={() => onView(recipe)} 
              size="sm"
              className="flex-1 bg-gray-800 hover:bg-gray-900"
            >
              <Eye className="w-4 h-4 mr-2" />
              View
            </Button>
            <Button 
              onClick={() => onEdit(recipe)} 
              size="sm"
              variant="outline"
              className="border-red-400 text-red-600 hover:bg-red-50"
            >
              <Edit className="w-4 h-4 mr-2" />
              Edit
            </Button>
            <Button 
              onClick={() => {
                if (confirm('Delete this recipe from your vault?')) {
                  onDelete(recipe.id);
                }
              }} 
              size="sm"
              variant="outline"
              className="border-red-400 text-red-600 hover:bg-red-50"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
