'use client'
import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Mic, MicOff, Volume2, Timer, ListChecks, ArrowRight } from 'lucide-react';
import type { Recipe, VaultRecipe } from '@/types/recipe';

interface VoiceAssistantProps {
  currentRecipe: Recipe | VaultRecipe | null;
  currentStep: number;
  onStepChange: (step: number) => void;
  onTimerSet: (seconds: number) => void;
}

export function VoiceAssistant({ currentRecipe, currentStep, onStepChange, onTimerSet }: VoiceAssistantProps): JSX.Element {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [response, setResponse] = useState('');
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = window.webkitSpeechRecognition || window.SpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = false;
      recognitionInstance.interimResults = false;
      recognitionInstance.lang = 'en-US';

      recognitionInstance.onresult = (event: SpeechRecognitionEvent) => {
        const speechResult = event.results[0][0].transcript.toLowerCase();
        setTranscript(speechResult);
        handleVoiceCommand(speechResult);
      };

      recognitionInstance.onerror = () => {
        setIsListening(false);
      };

      recognitionInstance.onend = () => {
        setIsListening(false);
      };

      setRecognition(recognitionInstance);
    }
  }, []);

  const speak = useCallback((text: string): void => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 1;
      utterance.volume = 1;
      
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      
      window.speechSynthesis.speak(utterance);
    }
  }, []);

  const handleVoiceCommand = useCallback((command: string): void => {
    let responseText = '';

    if (command.includes('next step') || command.includes('next')) {
      if (currentRecipe && currentStep < currentRecipe.steps.length - 1) {
        const nextStep = currentStep + 1;
        onStepChange(nextStep);
        responseText = `Step ${nextStep + 1}: ${currentRecipe.steps[nextStep]}`;
      } else {
        responseText = 'You are on the last step!';
      }
    } else if (command.includes('previous step') || command.includes('back')) {
      if (currentRecipe && currentStep > 0) {
        const prevStep = currentStep - 1;
        onStepChange(prevStep);
        responseText = `Step ${prevStep + 1}: ${currentRecipe.steps[prevStep]}`;
      } else {
        responseText = 'You are on the first step!';
      }
    } else if (command.includes('repeat') || command.includes('say again')) {
      if (currentRecipe && currentRecipe.steps[currentStep]) {
        responseText = `Step ${currentStep + 1}: ${currentRecipe.steps[currentStep]}`;
      } else {
        responseText = 'No recipe selected';
      }
    } else if (command.includes('ingredients')) {
      if (currentRecipe) {
        responseText = `Ingredients: ${currentRecipe.ingredients.join(', ')}`;
      } else {
        responseText = 'No recipe selected';
      }
    } else if (command.includes('timer') || command.includes('set timer')) {
      const minutes = parseInt(command.match(/\d+/)?.[0] || '5');
      onTimerSet(minutes * 60);
      responseText = `Timer set for ${minutes} minutes`;
    } else if (command.includes('how many steps') || command.includes('total steps')) {
      if (currentRecipe) {
        responseText = `This recipe has ${currentRecipe.steps.length} steps`;
      } else {
        responseText = 'No recipe selected';
      }
    } else {
      responseText = 'I can help with: next step, previous step, repeat step, ingredients, set timer, or total steps';
    }

    setResponse(responseText);
    speak(responseText);
  }, [currentRecipe, currentStep, onStepChange, onTimerSet, speak]);

  const toggleListening = (): void => {
    if (isListening) {
      recognition?.stop();
      setIsListening(false);
    } else {
      if (recognition) {
        recognition.start();
        setIsListening(true);
        setTranscript('');
        setResponse('Listening...');
      }
    }
  };

  return (
    <Card className="border-2 border-red-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Volume2 className="w-5 h-5 text-red-500" />
          Voice Cooking Assistant
        </CardTitle>
        <CardDescription>
          Hands-free cooking with voice commands
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Button
            onClick={toggleListening}
            variant={isListening ? 'destructive' : 'default'}
            className={isListening ? 'bg-red-500 hover:bg-red-600' : 'bg-gray-900 hover:bg-gray-800'}
          >
            {isListening ? (
              <>
                <MicOff className="w-4 h-4 mr-2" />
                Stop Listening
              </>
            ) : (
              <>
                <Mic className="w-4 h-4 mr-2" />
                Start Listening
              </>
            )}
          </Button>
        </div>

        {transcript && (
          <div className="bg-gray-50 p-3 rounded-lg">
            <p className="text-sm font-semibold text-gray-700">You said:</p>
            <p className="text-gray-900">{transcript}</p>
          </div>
        )}

        {response && (
          <div className="bg-red-50 p-3 rounded-lg">
            <div className="flex items-start gap-2">
              <Volume2 className={`w-5 h-5 ${isSpeaking ? 'text-red-500 animate-pulse' : 'text-red-400'}`} />
              <div>
                <p className="text-sm font-semibold text-gray-700">Assistant:</p>
                <p className="text-gray-900">{response}</p>
              </div>
            </div>
          </div>
        )}

        <div className="border-t pt-4">
          <p className="text-sm font-semibold text-gray-700 mb-2">Try saying:</p>
          <ul className="space-y-1 text-sm text-gray-600">
            <li className="flex items-center gap-2">
              <ArrowRight className="w-3 h-3" />
              "Next step" or "Previous step"
            </li>
            <li className="flex items-center gap-2">
              <ArrowRight className="w-3 h-3" />
              "Repeat step"
            </li>
            <li className="flex items-center gap-2">
              <Timer className="w-3 h-3" />
              "Set timer for 10 minutes"
            </li>
            <li className="flex items-center gap-2">
              <ListChecks className="w-3 h-3" />
              "Read ingredients"
            </li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}

declare global {
  interface Window {
    webkitSpeechRecognition: typeof SpeechRecognition;
    SpeechRecognition: typeof SpeechRecognition;
  }
}
