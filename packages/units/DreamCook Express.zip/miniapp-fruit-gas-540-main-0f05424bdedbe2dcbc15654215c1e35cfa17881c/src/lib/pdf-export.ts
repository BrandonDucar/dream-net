import type { Recipe, VaultRecipe, GroceryItem } from '@/types/recipe';

export const exportRecipeToPDF = (recipe: Recipe | VaultRecipe): void => {
  const content = generateRecipeHTML(recipe);
  const printWindow = window.open('', '_blank');
  
  if (printWindow) {
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>${recipe.title}</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              max-width: 800px;
              margin: 0 auto;
              padding: 20px;
              line-height: 1.6;
            }
            h1 {
              color: #ef4444;
              border-bottom: 2px solid #1f2937;
              padding-bottom: 10px;
            }
            h2 {
              color: #1f2937;
              margin-top: 20px;
            }
            .description {
              font-style: italic;
              color: #4b5563;
              margin-bottom: 20px;
            }
            ul, ol {
              margin: 10px 0;
            }
            li {
              margin: 5px 0;
            }
            .notes {
              background: #f3f4f6;
              padding: 15px;
              border-radius: 8px;
              margin-top: 20px;
            }
            @media print {
              body { padding: 10px; }
            }
          </style>
        </head>
        <body>
          ${content}
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
    }, 250);
  }
};

export const exportGroceryListToPDF = (items: GroceryItem[]): void => {
  const content = generateGroceryHTML(items);
  const printWindow = window.open('', '_blank');
  
  if (printWindow) {
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Dream Grocery List</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              max-width: 800px;
              margin: 0 auto;
              padding: 20px;
              line-height: 1.6;
            }
            h1 {
              color: #ef4444;
              border-bottom: 2px solid #1f2937;
              padding-bottom: 10px;
            }
            ul {
              list-style: none;
              padding: 0;
            }
            li {
              padding: 8px 0;
              border-bottom: 1px solid #e5e7eb;
            }
            .checked {
              text-decoration: line-through;
              color: #9ca3af;
            }
            @media print {
              body { padding: 10px; }
            }
          </style>
        </head>
        <body>
          ${content}
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
    }, 250);
  }
};

export const exportGroceryListAsText = (items: GroceryItem[]): string => {
  let text = 'DREAM GROCERY LIST\n';
  text += '==================\n\n';
  
  items.forEach((item: GroceryItem, index: number) => {
    const checkbox = item.checked ? '[X]' : '[ ]';
    text += `${checkbox} ${item.name}\n`;
  });
  
  return text;
};

function generateRecipeHTML(recipe: Recipe | VaultRecipe): string {
  let html = `<h1>${recipe.title}</h1>`;
  html += `<p class="description">${recipe.description}</p>`;
  
  html += `<h2>Ingredients</h2><ul>`;
  recipe.ingredients.forEach((ing: string) => {
    html += `<li>${ing}</li>`;
  });
  html += `</ul>`;
  
  html += `<h2>Instructions</h2><ol>`;
  recipe.steps.forEach((step: string) => {
    html += `<li>${step}</li>`;
  });
  html += `</ol>`;
  
  if (recipe.dreamUpgrades && recipe.dreamUpgrades.length > 0) {
    html += `<h2>Dream Upgrades</h2><ul>`;
    recipe.dreamUpgrades.forEach((upgrade: string) => {
      html += `<li>${upgrade}</li>`;
    });
    html += `</ul>`;
  }
  
  if (recipe.notes) {
    html += `<div class="notes"><strong>Notes:</strong> ${recipe.notes}</div>`;
  }
  
  if ('dateAdded' in recipe) {
    html += `<p style="margin-top: 20px; color: #6b7280; font-size: 14px;">Added: ${new Date(recipe.dateAdded).toLocaleDateString()}</p>`;
  }
  
  return html;
}

function generateGroceryHTML(items: GroceryItem[]): string {
  let html = `<h1>Dream Grocery List</h1><ul>`;
  
  items.forEach((item: GroceryItem) => {
    const className = item.checked ? 'checked' : '';
    html += `<li class="${className}">${item.name}</li>`;
  });
  
  html += `</ul>`;
  return html;
}
