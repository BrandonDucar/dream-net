import type { Recipe, VaultRecipe, WeekMealPlan, GroceryItem } from '@/types/recipe';

const STORAGE_KEYS = {
  COOKBOOK: 'dreamcookbook_recipes',
  VAULT: 'dreamcookbook_vault',
  MEALPLAN: 'dreamcookbook_mealplan',
  GROCERY: 'dreamcookbook_grocery',
} as const;

// Cookbook Storage
export const getCookbookRecipes = (): Recipe[] => {
  if (typeof window === 'undefined') return [];
  const stored = localStorage.getItem(STORAGE_KEYS.COOKBOOK);
  return stored ? JSON.parse(stored) : getDefaultRecipes();
};

export const saveCookbookRecipes = (recipes: Recipe[]): void => {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.COOKBOOK, JSON.stringify(recipes));
};

export const addCookbookRecipe = (recipe: Recipe): void => {
  const recipes = getCookbookRecipes();
  recipes.push(recipe);
  saveCookbookRecipes(recipes);
};

export const updateCookbookRecipe = (id: string, updated: Recipe): void => {
  const recipes = getCookbookRecipes();
  const index = recipes.findIndex((r: Recipe) => r.id === id);
  if (index !== -1) {
    recipes[index] = updated;
    saveCookbookRecipes(recipes);
  }
};

export const deleteCookbookRecipe = (id: string): void => {
  const recipes = getCookbookRecipes();
  const filtered = recipes.filter((r: Recipe) => r.id !== id);
  saveCookbookRecipes(filtered);
};

// Vault Storage
export const getVaultRecipes = (): VaultRecipe[] => {
  if (typeof window === 'undefined') return [];
  const stored = localStorage.getItem(STORAGE_KEYS.VAULT);
  return stored ? JSON.parse(stored) : [];
};

export const saveVaultRecipes = (recipes: VaultRecipe[]): void => {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.VAULT, JSON.stringify(recipes));
};

export const addVaultRecipe = (recipe: VaultRecipe): void => {
  const recipes = getVaultRecipes();
  recipes.push(recipe);
  saveVaultRecipes(recipes);
};

export const updateVaultRecipe = (id: string, updated: VaultRecipe): void => {
  const recipes = getVaultRecipes();
  const index = recipes.findIndex((r: VaultRecipe) => r.id === id);
  if (index !== -1) {
    recipes[index] = updated;
    saveVaultRecipes(recipes);
  }
};

export const deleteVaultRecipe = (id: string): void => {
  const recipes = getVaultRecipes();
  const filtered = recipes.filter((r: VaultRecipe) => r.id !== id);
  saveVaultRecipes(filtered);
};

// Meal Plan Storage
export const getMealPlan = (): WeekMealPlan => {
  if (typeof window === 'undefined') {
    return getEmptyMealPlan();
  }
  const stored = localStorage.getItem(STORAGE_KEYS.MEALPLAN);
  return stored ? JSON.parse(stored) : getEmptyMealPlan();
};

export const saveMealPlan = (plan: WeekMealPlan): void => {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.MEALPLAN, JSON.stringify(plan));
};

// Grocery List Storage
export const getGroceryList = (): GroceryItem[] => {
  if (typeof window === 'undefined') return [];
  const stored = localStorage.getItem(STORAGE_KEYS.GROCERY);
  return stored ? JSON.parse(stored) : [];
};

export const saveGroceryList = (items: GroceryItem[]): void => {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.GROCERY, JSON.stringify(items));
};

// Helper Functions
function getEmptyMealPlan(): WeekMealPlan {
  return {
    monday: {},
    tuesday: {},
    wednesday: {},
    thursday: {},
    friday: {},
    saturday: {},
    sunday: {},
  };
}

function getDefaultRecipes(): Recipe[] {
  return [
    {
      id: '1',
      title: 'DreamFire Pasta',
      description: 'A spicy, bold pasta dish with a fiery kick and rich tomato base',
      ingredients: [
        '1 lb penne pasta',
        '2 cups marinara sauce',
        '1 tbsp red pepper flakes',
        '4 cloves garlic, minced',
        '1/4 cup olive oil',
        '1/2 cup fresh basil',
        'Parmesan cheese, to taste',
        'Salt and pepper',
      ],
      steps: [
        'Cook pasta according to package directions until al dente',
        'Heat olive oil in a large pan over medium heat',
        'Add garlic and red pepper flakes, sauté for 1 minute',
        'Pour in marinara sauce and simmer for 5 minutes',
        'Drain pasta and toss with sauce',
        'Garnish with fresh basil and parmesan',
        'Serve hot with extra red pepper flakes on the side',
      ],
      dreamUpgrades: [
        'Add grilled chicken or shrimp for protein',
        'Sprinkle with smoked paprika for extra depth',
        'Top with burrata cheese for creamy contrast',
      ],
      notes: 'Adjust heat level to your preference. Great with garlic bread!',
      category: 'Dinner',
    },
    {
      id: '2',
      title: 'Midnight Lemon Chicken',
      description: 'Tender chicken with a bright citrus glaze, perfect for any hour',
      ingredients: [
        '4 chicken breasts',
        '3 lemons (juice and zest)',
        '4 tbsp butter',
        '3 cloves garlic, minced',
        '1 cup chicken broth',
        '2 tbsp honey',
        'Fresh thyme',
        'Salt and pepper',
      ],
      steps: [
        'Season chicken breasts with salt, pepper, and lemon zest',
        'Heat 2 tbsp butter in a skillet over medium-high heat',
        'Sear chicken until golden, about 5 minutes per side',
        'Remove chicken and set aside',
        'Add remaining butter, garlic, lemon juice, honey, and broth',
        'Simmer sauce until slightly thickened, about 5 minutes',
        'Return chicken to pan, spoon sauce over, and cook 3 more minutes',
        'Garnish with fresh thyme and lemon slices',
      ],
      dreamUpgrades: [
        'Add capers for a briny twist',
        'Serve over creamy risotto or mashed potatoes',
        'Mix in white wine for extra depth',
      ],
      notes: 'The honey balances the tartness perfectly. Pairs well with roasted vegetables.',
      category: 'Dinner',
    },
    {
      id: '3',
      title: 'GlowBerry Smoothie',
      description: 'A vibrant, energizing smoothie packed with antioxidants and natural sweetness',
      ingredients: [
        '1 cup mixed berries (strawberries, blueberries, raspberries)',
        '1 banana',
        '1 cup almond milk',
        '1/2 cup Greek yogurt',
        '1 tbsp honey',
        '1 tbsp chia seeds',
        'Handful of spinach (optional)',
        'Ice cubes',
      ],
      steps: [
        'Add all ingredients to a high-speed blender',
        'Blend on high for 60 seconds until smooth and creamy',
        'Add more liquid if needed for desired consistency',
        'Pour into a glass and enjoy immediately',
      ],
      dreamUpgrades: [
        'Top with granola and fresh berries',
        'Add a scoop of protein powder for post-workout fuel',
        'Swirl in some peanut butter for extra richness',
      ],
      notes: 'Perfect breakfast or snack. The spinach adds nutrients without affecting taste!',
      category: 'Breakfast',
    },
    {
      id: '4',
      title: 'Neon Sunrise Pancakes',
      description: 'Fluffy buttermilk pancakes with a hint of vanilla and citrus brightness',
      ingredients: [
        '2 cups all-purpose flour',
        '2 tbsp sugar',
        '2 tsp baking powder',
        '1 tsp baking soda',
        '1/2 tsp salt',
        '2 cups buttermilk',
        '2 eggs',
        '1/4 cup melted butter',
        '1 tsp vanilla extract',
        'Orange zest from 1 orange',
      ],
      steps: [
        'Mix flour, sugar, baking powder, baking soda, and salt in a bowl',
        'In another bowl, whisk buttermilk, eggs, melted butter, vanilla, and orange zest',
        'Pour wet ingredients into dry and stir until just combined (lumps are okay)',
        'Heat a griddle or pan over medium heat and lightly grease',
        'Pour 1/4 cup batter per pancake onto hot surface',
        'Cook until bubbles form on surface, then flip and cook 1-2 minutes more',
        'Serve warm with maple syrup and fresh fruit',
      ],
      dreamUpgrades: [
        'Add chocolate chips or blueberries to the batter',
        'Top with whipped cream and caramelized bananas',
        'Drizzle with orange-infused syrup',
      ],
      notes: 'Don\'t overmix the batter! Lumps make fluffier pancakes.',
      category: 'Breakfast',
    },
    {
      id: '5',
      title: 'Shadow Spice Tacos',
      description: 'Smoky, flavorful tacos with perfectly seasoned meat and fresh toppings',
      ingredients: [
        '1 lb ground beef or turkey',
        '1 onion, diced',
        '2 cloves garlic, minced',
        '2 tbsp chili powder',
        '1 tsp cumin',
        '1 tsp smoked paprika',
        '1/2 tsp cayenne pepper',
        '1/2 cup tomato sauce',
        'Taco shells or tortillas',
        'Toppings: lettuce, tomato, cheese, sour cream, cilantro',
      ],
      steps: [
        'Brown meat in a large skillet over medium-high heat',
        'Add onion and garlic, cook until softened',
        'Stir in all spices and cook for 1 minute',
        'Add tomato sauce and 1/4 cup water',
        'Simmer for 10 minutes until thickened',
        'Warm taco shells according to package directions',
        'Fill shells with meat and add desired toppings',
      ],
      dreamUpgrades: [
        'Add black beans and corn for extra texture',
        'Top with pickled jalapeños and lime crema',
        'Make it a taco bowl over cilantro lime rice',
      ],
      notes: 'Toast the spices briefly for deeper flavor. Perfect for taco night!',
      category: 'Dinner',
    },
  ];
}
