export interface Recipe {
  id: string;
  title: string;
  description: string;
  ingredients: string[];
  steps: string[];
  dreamUpgrades?: string[];
  notes?: string;
  category?: string;
}

export interface VaultRecipe extends Recipe {
  dateAdded: string;
  photoUrl?: string;
}

export interface WeekMealPlan {
  monday: DayMeals;
  tuesday: DayMeals;
  wednesday: DayMeals;
  thursday: DayMeals;
  friday: DayMeals;
  saturday: DayMeals;
  sunday: DayMeals;
}

export interface DayMeals {
  breakfast?: string;
  lunch?: string;
  dinner?: string;
}

export interface GroceryItem {
  id: string;
  name: string;
  checked: boolean;
}

export interface NutritionInfo {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
}

export interface AppliancePreset {
  id: string;
  name: string;
  type: 'instant-pot' | 'air-fryer' | 'smart-oven';
  temperature?: number;
  time: number;
  instructions: string;
}

export interface CommunityRecipe extends Recipe {
  authorId: string;
  authorName: string;
  timestamp: string;
  likes: number;
  comments: string[];
  tags: string[];
  rating: number;
}

export interface Season {
  name: 'spring' | 'summer' | 'fall' | 'winter';
  months: number[];
}
