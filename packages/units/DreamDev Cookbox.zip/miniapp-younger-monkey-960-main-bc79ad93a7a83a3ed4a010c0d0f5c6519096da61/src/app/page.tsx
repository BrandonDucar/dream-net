'use client'
import { useState, useEffect } from 'react';
import type { CookbookItem, FilterState } from '@/types/cookbook';
import { cookbookData } from '@/data/cookbook-data';
import { filterItems } from '@/lib/cookbook-utils';
import { ModeSelector } from '@/components/cookbook/ModeSelector';
import { FilterBar } from '@/components/cookbook/FilterBar';
import { CookbookCard } from '@/components/cookbook/CookbookCard';
import { CookbookDetail } from '@/components/cookbook/CookbookDetail';
import { Button } from '@/components/ui/button';
import { Sparkles, Github, BookOpen } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function HomePage(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [filters, setFilters] = useState<FilterState>({
    mode: 'all',
    category: 'all',
    searchQuery: '',
    difficulty: 'all'
  });

  const [selectedItem, setSelectedItem] = useState<CookbookItem | null>(null);

  const filteredItems = filterItems(cookbookData, filters);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-950/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center">
                <BookOpen className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                  DreamDev Cookbox
                </h1>
                <p className="text-sm text-gray-500">Structured developer knowledge, DreamNet style</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="border-gray-800 hover:border-cyan-500">
                <Github className="h-4 w-4 mr-2" />
                GitHub
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12 space-y-12">
        {/* Hero Section */}
        <section className="text-center space-y-4 py-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-sm">
            <Sparkles className="h-4 w-4" />
            <span>Four content modes. One clean toolkit.</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white">
            Build faster with{' '}
            <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
              structured knowledge
            </span>
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Access developer patterns, recipes, code shards, and glossary terms in clean, reusable formats.
            No fluff, just practical knowledge at your fingertips.
          </p>
        </section>

        {/* Mode Selector */}
        <section>
          <h3 className="text-xl font-semibold text-white mb-4">Choose Your Format</h3>
          <ModeSelector
            selectedMode={filters.mode}
            onModeSelect={(mode) => setFilters({ ...filters, mode })}
          />
        </section>

        {/* Filter Bar */}
        <section>
          <FilterBar filters={filters} onFiltersChange={setFilters} />
        </section>

        {/* Results */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-semibold text-white">
              {filteredItems.length} {filteredItems.length === 1 ? 'Result' : 'Results'}
            </h3>
            {(filters.mode !== 'all' || filters.category !== 'all' || filters.searchQuery || filters.difficulty !== 'all') && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setFilters({
                  mode: 'all',
                  category: 'all',
                  searchQuery: '',
                  difficulty: 'all'
                })}
                className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10"
              >
                Clear Filters
              </Button>
            )}
          </div>

          {filteredItems.length === 0 ? (
            <div className="text-center py-16 space-y-4">
              <div className="w-16 h-16 mx-auto rounded-full bg-gray-900 flex items-center justify-center">
                <BookOpen className="h-8 w-8 text-gray-600" />
              </div>
              <div>
                <h4 className="text-lg font-medium text-white mb-2">No results found</h4>
                <p className="text-gray-500">Try adjusting your filters or search query</p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredItems.map((item) => (
                <CookbookCard
                  key={item.id}
                  item={item}
                  onClick={() => setSelectedItem(item)}
                />
              ))}
            </div>
          )}
        </section>

        {/* Stats */}
        <section className="border-t border-gray-800 pt-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {[
              { label: 'Knowledge Packs', value: cookbookData.filter(i => i.mode === 'knowledge-pack').length },
              { label: 'Recipe Cards', value: cookbookData.filter(i => i.mode === 'recipe-card').length },
              { label: 'Code Shards', value: cookbookData.filter(i => i.mode === 'code-shard').length },
              { label: 'Glossary Terms', value: cookbookData.filter(i => i.mode === 'devmind-glossary').length },
            ].map((stat) => (
              <div key={stat.label} className="space-y-2">
                <div className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                  {stat.value}
                </div>
                <div className="text-sm text-gray-500">{stat.label}</div>
              </div>
            ))}
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-800 mt-16 py-8 bg-gray-950/50">
        <div className="container mx-auto px-4 text-center text-gray-500 text-sm">
          <p>Built with 💙 on Base • DreamDev Cookbox • Structured knowledge for developers</p>
        </div>
      </footer>

      {/* Detail Modal */}
      {selectedItem && (
        <CookbookDetail
          item={selectedItem}
          onClose={() => setSelectedItem(null)}
        />
      )}
    </div>
  );
}
