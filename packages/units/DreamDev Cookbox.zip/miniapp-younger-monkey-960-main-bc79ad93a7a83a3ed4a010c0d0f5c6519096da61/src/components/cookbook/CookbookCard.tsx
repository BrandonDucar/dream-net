'use client';

import type { CookbookItem } from '@/types/cookbook';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Clock, Tag, ChevronRight } from 'lucide-react';
import { getModeLabel, getModeColor, getDifficultyColor } from '@/lib/cookbook-utils';

interface CookbookCardProps {
  item: CookbookItem;
  onClick: () => void;
}

export function CookbookCard({ item, onClick }: CookbookCardProps): JSX.Element {
  const modeColor = getModeColor(item.mode);
  const difficultyColor = getDifficultyColor(item.difficulty);

  return (
    <Card 
      className="group hover:border-cyan-500/50 transition-all duration-300 cursor-pointer bg-gray-900/30 border-gray-800 overflow-hidden"
      onClick={onClick}
    >
      {/* Gradient header */}
      <div className={`h-2 bg-gradient-to-r ${modeColor}`} />
      
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="space-y-2 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="outline" className="text-xs border-cyan-500/30 text-cyan-400">
                {getModeLabel(item.mode)}
              </Badge>
              <Badge variant="outline" className={`text-xs border ${difficultyColor}`}>
                {item.difficulty}
              </Badge>
            </div>
            <CardTitle className="text-xl group-hover:text-cyan-400 transition-colors">
              {item.title}
            </CardTitle>
          </div>
          <ChevronRight className="h-5 w-5 text-gray-500 group-hover:text-cyan-400 group-hover:translate-x-1 transition-all" />
        </div>
      </CardHeader>

      <CardContent className="space-y-3">
        {/* Preview text */}
        <p className="text-sm text-gray-400 line-clamp-2">
          {item.content.split('\n').find(line => line.trim() && !line.startsWith('#'))}
        </p>

        {/* Tags */}
        <div className="flex items-center gap-2 flex-wrap">
          <Tag className="h-3 w-3 text-gray-500" />
          {item.tags.slice(0, 3).map((tag) => (
            <span key={tag} className="text-xs text-gray-500">
              {tag}
            </span>
          ))}
          {item.tags.length > 3 && (
            <span className="text-xs text-gray-500">+{item.tags.length - 3}</span>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-gray-800">
          <div className="flex items-center gap-1 text-xs text-gray-500">
            <Clock className="h-3 w-3" />
            <span>{item.readTime} min read</span>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10"
          >
            View Details
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
