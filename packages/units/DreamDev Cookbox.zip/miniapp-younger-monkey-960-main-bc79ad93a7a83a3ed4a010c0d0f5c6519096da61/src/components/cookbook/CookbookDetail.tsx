'use client';

import type { CookbookItem } from '@/types/cookbook';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { X, Clock, Copy, Check, Tag, Calendar } from 'lucide-react';
import { getModeLabel, getModeColor, getDifficultyColor, getCategoryLabel, copyToClipboard } from '@/lib/cookbook-utils';
import { useState } from 'react';
import ReactMarkdown from 'react-markdown';

interface CookbookDetailProps {
  item: CookbookItem;
  onClose: () => void;
}

export function CookbookDetail({ item, onClose }: CookbookDetailProps): JSX.Element {
  const [copiedContent, setCopiedContent] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const modeColor = getModeColor(item.mode);
  const difficultyColor = getDifficultyColor(item.difficulty);

  const handleCopy = async (text: string, type: 'content' | 'code'): Promise<void> => {
    try {
      await copyToClipboard(text);
      if (type === 'content') {
        setCopiedContent(true);
        setTimeout(() => setCopiedContent(false), 2000);
      } else {
        setCopiedCode(true);
        setTimeout(() => setCopiedCode(false), 2000);
      }
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-gray-950 border border-gray-800 rounded-lg w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className={`bg-gradient-to-r ${modeColor} p-1`}>
          <div className="bg-gray-950 p-6">
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-3 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge variant="outline" className="text-xs border-cyan-500/30 text-cyan-400">
                    {getModeLabel(item.mode)}
                  </Badge>
                  <Badge variant="outline" className="text-xs bg-gray-800/50 text-gray-300">
                    {getCategoryLabel(item.category)}
                  </Badge>
                  <Badge variant="outline" className={`text-xs border ${difficultyColor}`}>
                    {item.difficulty}
                  </Badge>
                </div>
                <h2 className="text-2xl font-bold text-white">{item.title}</h2>
                <div className="flex items-center gap-4 text-sm text-gray-400">
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{item.readTime} min read</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    <span>Updated {item.updatedAt}</span>
                  </div>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="text-gray-400 hover:text-white hover:bg-gray-800"
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Tags */}
          <div className="flex items-center gap-2 flex-wrap">
            <Tag className="h-4 w-4 text-gray-500" />
            {item.tags.map((tag) => (
              <Badge key={tag} variant="outline" className="text-xs bg-gray-900/50 border-gray-700">
                {tag}
              </Badge>
            ))}
          </div>

          <Separator className="bg-gray-800" />

          {/* Main Content */}
          <div className="prose prose-invert prose-sm max-w-none">
            <div className="relative group">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleCopy(item.content, 'content')}
                className="absolute top-0 right-0 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                {copiedContent ? (
                  <>
                    <Check className="h-4 w-4 mr-1" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4 mr-1" />
                    Copy
                  </>
                )}
              </Button>
              <ReactMarkdown
                components={{
                  h2: ({ children }) => <h2 className="text-xl font-bold text-cyan-400 mt-6 mb-3">{children}</h2>,
                  h3: ({ children }) => <h3 className="text-lg font-semibold text-white mt-4 mb-2">{children}</h3>,
                  p: ({ children }) => <p className="text-gray-300 leading-relaxed mb-3">{children}</p>,
                  ul: ({ children }) => <ul className="list-disc list-inside space-y-1 text-gray-300 mb-3">{children}</ul>,
                  li: ({ children }) => <li className="ml-4">{children}</li>,
                  code: ({ children }) => <code className="bg-gray-900 text-cyan-400 px-2 py-1 rounded text-sm">{children}</code>,
                  pre: ({ children }) => <pre className="bg-gray-900 p-4 rounded-lg overflow-x-auto text-sm mb-3">{children}</pre>,
                }}
              >
                {item.content}
              </ReactMarkdown>
            </div>
          </div>

          {/* Code Section */}
          {item.code && (
            <>
              <Separator className="bg-gray-800" />
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-cyan-400">Code Example</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleCopy(item.code || '', 'code')}
                    className="hover:bg-cyan-500/10 hover:border-cyan-500"
                  >
                    {copiedCode ? (
                      <>
                        <Check className="h-4 w-4 mr-1" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="h-4 w-4 mr-1" />
                        Copy Code
                      </>
                    )}
                  </Button>
                </div>
                <pre className="bg-gray-900 p-4 rounded-lg overflow-x-auto text-sm border border-gray-800">
                  <code className="text-gray-300">{item.code}</code>
                </pre>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-gray-800 p-4 bg-gray-900/50">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-500">
              Created {item.createdAt}
            </p>
            <Button onClick={onClose} className="bg-cyan-500 hover:bg-cyan-600 text-black">
              Close
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
