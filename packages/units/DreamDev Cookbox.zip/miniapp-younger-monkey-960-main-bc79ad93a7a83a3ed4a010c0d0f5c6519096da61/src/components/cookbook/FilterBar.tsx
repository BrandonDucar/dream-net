'use client';

import type { FilterState, ContentMode, Category } from '@/types/cookbook';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search } from 'lucide-react';
import { getModeLabel, getCategoryLabel } from '@/lib/cookbook-utils';

interface FilterBarProps {
  filters: FilterState;
  onFiltersChange: (filters: FilterState) => void;
}

const modes: Array<ContentMode | 'all'> = ['all', 'knowledge-pack', 'recipe-card', 'code-shard', 'devmind-glossary'];
const categories: Array<Category | 'all'> = ['all', 'architecture', 'patterns', 'apis', 'databases', 'frontend', 'backend', 'deployment', 'testing', 'security', 'performance', 'tools'];
const difficulties = ['all', 'beginner', 'intermediate', 'advanced'] as const;

export function FilterBar({ filters, onFiltersChange }: FilterBarProps): JSX.Element {
  return (
    <div className="space-y-4">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
        <Input
          type="text"
          placeholder="Search recipes, patterns, concepts..."
          value={filters.searchQuery}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
            onFiltersChange({ ...filters, searchQuery: e.target.value });
          }}
          className="pl-10 bg-gray-900/50 border-gray-800 focus:border-cyan-500 transition-colors"
        />
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Select
          value={filters.mode}
          onValueChange={(value: string) => {
            onFiltersChange({ ...filters, mode: value as ContentMode | 'all' });
          }}
        >
          <SelectTrigger className="bg-gray-900/50 border-gray-800">
            <SelectValue placeholder="Content Mode" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Modes</SelectItem>
            {modes.slice(1).map((mode) => (
              <SelectItem key={mode} value={mode}>
                {getModeLabel(mode as ContentMode)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={filters.category}
          onValueChange={(value: string) => {
            onFiltersChange({ ...filters, category: value as Category | 'all' });
          }}
        >
          <SelectTrigger className="bg-gray-900/50 border-gray-800">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.slice(1).map((category) => (
              <SelectItem key={category} value={category}>
                {getCategoryLabel(category as Category)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={filters.difficulty}
          onValueChange={(value: string) => {
            onFiltersChange({ ...filters, difficulty: value as FilterState['difficulty'] });
          }}
        >
          <SelectTrigger className="bg-gray-900/50 border-gray-800">
            <SelectValue placeholder="Difficulty" />
          </SelectTrigger>
          <SelectContent>
            {difficulties.map((difficulty) => (
              <SelectItem key={difficulty} value={difficulty}>
                {difficulty === 'all' ? 'All Levels' : difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
