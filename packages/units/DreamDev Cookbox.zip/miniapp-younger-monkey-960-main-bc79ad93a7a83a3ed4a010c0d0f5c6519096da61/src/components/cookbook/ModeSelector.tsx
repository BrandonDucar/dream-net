'use client';

import type { ContentMode } from '@/types/cookbook';
import { Card, CardContent } from '@/components/ui/card';
import { BookOpen, ClipboardList, Code2, BookMarked } from 'lucide-react';
import { getModeLabel, getModeDescription, getModeColor } from '@/lib/cookbook-utils';

interface ModeSelectorProps {
  selectedMode: ContentMode | 'all';
  onModeSelect: (mode: ContentMode | 'all') => void;
}

const modes: Array<{ value: ContentMode | 'all'; icon: typeof BookOpen }> = [
  { value: 'all', icon: BookMarked },
  { value: 'knowledge-pack', icon: BookOpen },
  { value: 'recipe-card', icon: ClipboardList },
  { value: 'code-shard', icon: Code2 },
  { value: 'devmind-glossary', icon: BookMarked },
];

export function ModeSelector({ selectedMode, onModeSelect }: ModeSelectorProps): JSX.Element {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
      {modes.map(({ value, icon: Icon }) => {
        const isSelected = selectedMode === value;
        const modeColor = value !== 'all' ? getModeColor(value as ContentMode) : 'from-gray-500 to-gray-600';
        
        return (
          <Card
            key={value}
            className={`cursor-pointer transition-all duration-300 overflow-hidden ${
              isSelected
                ? 'border-cyan-500 shadow-lg shadow-cyan-500/20'
                : 'border-gray-800 hover:border-gray-700'
            }`}
            onClick={() => onModeSelect(value)}
          >
            {isSelected && <div className={`h-1 bg-gradient-to-r ${modeColor}`} />}
            <CardContent className="p-4 text-center space-y-2">
              <div className={`mx-auto w-12 h-12 rounded-full bg-gradient-to-br ${modeColor} flex items-center justify-center`}>
                <Icon className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="font-medium text-sm text-white">
                  {value === 'all' ? 'All Modes' : getModeLabel(value as ContentMode)}
                </p>
                {value !== 'all' && (
                  <p className="text-xs text-gray-500 mt-1 line-clamp-2">
                    {getModeDescription(value as ContentMode)}
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
