import type { CookbookItem } from '@/types/cookbook';

export const cookbookData: CookbookItem[] = [
  // KNOWLEDGE PACKS
  {
    id: 'kp-001',
    title: 'REST API Design Principles',
    mode: 'knowledge-pack',
    category: 'apis',
    tags: ['rest', 'http', 'api-design', 'best-practices'],
    difficulty: 'intermediate',
    readTime: 8,
    content: `## Core Principles

### 1. Resource-Based URLs
- Use nouns, not verbs: /users not /getUsers
- Hierarchical structure: /users/:id/posts
- Plural names for consistency

### 2. HTTP Methods Matter
- GET: Retrieve data (safe, idempotent)
- POST: Create new resource
- PUT: Full update (idempotent)
- PATCH: Partial update
- DELETE: Remove resource (idempotent)

### 3. Status Codes
- 2xx: Success (200 OK, 201 Created)
- 4xx: Client errors (400 Bad Request, 404 Not Found)
- 5xx: Server errors (500 Internal Server Error)

### 4. Versioning Strategy
- URL versioning: /v1/users
- Header versioning: Accept: application/vnd.api+json;version=1
- Query parameter: /users?version=1

### 5. Filtering & Pagination
- Query params: ?limit=20&offset=40
- Cursor-based for large datasets
- Return metadata: total, hasNext, cursor`,
    createdAt: '2025-01-15',
    updatedAt: '2025-01-15'
  },
  {
    id: 'kp-002',
    title: 'Component Architecture Patterns',
    mode: 'knowledge-pack',
    category: 'frontend',
    tags: ['react', 'components', 'architecture', 'patterns'],
    difficulty: 'intermediate',
    readTime: 10,
    content: `## Component Patterns

### 1. Container/Presentational Split
- **Container**: Logic, state, data fetching
- **Presentational**: Pure UI, props only
- Clear separation of concerns

### 2. Compound Components
- Parent provides context
- Children share implicit state
- Examples: <Select>, <Tabs>

### 3. Render Props
- Pass function as prop
- Inversion of control
- Flexible composition

### 4. Higher-Order Components (HOC)
- Wrap components with additional logic
- Cross-cutting concerns
- withAuth, withLoading patterns

### 5. Custom Hooks Pattern
- Extract reusable logic
- Composable behaviors
- Clean component bodies

### File Structure
\`\`\`
components/
  Button/
    Button.tsx
    Button.test.tsx
    Button.stories.tsx
    index.ts
\`\`\``,
    createdAt: '2025-01-14',
    updatedAt: '2025-01-14'
  },

  // RECIPE CARDS
  {
    id: 'rc-001',
    title: 'Set Up Authentication Flow',
    mode: 'recipe-card',
    category: 'security',
    tags: ['auth', 'jwt', 'session', 'middleware'],
    difficulty: 'intermediate',
    readTime: 15,
    content: `## Ingredients
- Authentication library (NextAuth, Clerk, Privy)
- Protected route middleware
- Session storage strategy
- Login/signup UI components

## Steps

### 1. Install Dependencies
Choose your auth provider and install required packages

### 2. Configure Provider
Set up environment variables:
- Client ID / API keys
- Redirect URLs
- Session secrets

### 3. Create Auth Routes
- /api/auth/login
- /api/auth/logout
- /api/auth/callback
- /api/auth/session

### 4. Implement Middleware
Protect routes by checking session:
- Redirect unauthorized users
- Attach user to request context
- Handle token refresh

### 5. Build UI Components
- Login form with validation
- Signup form with password strength
- Protected layout wrapper
- User profile dropdown

### 6. Handle Edge Cases
- Token expiration → Auto-refresh
- Session persistence → Cookies or localStorage
- Multiple tabs → Cross-tab communication
- Logout → Clear all state

## Testing Checklist
✓ Login with valid credentials
✓ Reject invalid credentials
✓ Protected routes redirect
✓ Session persists on refresh
✓ Logout clears session`,
    code: `// Middleware example (pseudo-code)
function authMiddleware(request) {
  const session = getSession(request);
  
  if (!session && isProtectedRoute(request.url)) {
    return redirect('/login');
  }
  
  if (session && isExpired(session)) {
    return refreshToken(session);
  }
  
  request.user = session.user;
  return next();
}`,
    createdAt: '2025-01-13',
    updatedAt: '2025-01-13'
  },
  {
    id: 'rc-002',
    title: 'Build Real-Time Features',
    mode: 'recipe-card',
    category: 'backend',
    tags: ['websocket', 'real-time', 'events', 'pub-sub'],
    difficulty: 'advanced',
    readTime: 20,
    content: `## Ingredients
- WebSocket library or server
- Event emitter system
- Connection management
- State synchronization logic

## Steps

### 1. Choose Technology
- WebSockets (Socket.io, ws)
- Server-Sent Events (SSE)
- Long polling (fallback)

### 2. Set Up Server
- Create WebSocket endpoint
- Handle connections/disconnections
- Implement heartbeat/ping-pong
- Add reconnection logic

### 3. Design Event System
Define event types:
- User joins/leaves
- Data updates
- System notifications
- Error events

### 4. Implement Pub/Sub
- Room/channel concept
- Subscribe to specific events
- Broadcast to multiple clients
- Private vs public messages

### 5. Handle State Sync
- Send initial state on connect
- Optimistic updates on client
- Conflict resolution strategy
- Rollback on failure

### 6. Add Client Logic
- Auto-reconnect with backoff
- Queue messages during disconnect
- Visual connection status
- Offline mode support

## Performance Tips
- Throttle high-frequency events
- Batch multiple updates
- Use binary protocols for large data
- Implement message compression

## Security Considerations
- Authenticate WebSocket connections
- Validate all incoming events
- Rate limit per connection
- Sanitize broadcast data`,
    code: `// Real-time connection setup (pseudo-code)
class RealtimeClient {
  connect(url, token) {
    this.socket = new WebSocket(url);
    this.socket.onopen = () => {
      this.authenticate(token);
      this.subscribeToChannels();
    };
    
    this.socket.onmessage = (event) => {
      this.handleEvent(event.data);
    };
    
    this.socket.onclose = () => {
      this.reconnectWithBackoff();
    };
  }
  
  send(eventType, data) {
    if (this.isConnected()) {
      this.socket.send({ type: eventType, data });
    } else {
      this.queueMessage({ type: eventType, data });
    }
  }
}`,
    createdAt: '2025-01-12',
    updatedAt: '2025-01-12'
  },

  // CODE SHARDS
  {
    id: 'cs-001',
    title: 'Debounce Pattern',
    mode: 'code-shard',
    category: 'patterns',
    tags: ['optimization', 'events', 'performance', 'throttle'],
    difficulty: 'beginner',
    readTime: 3,
    content: `## What It Does
Delays function execution until after a pause in events. Perfect for search inputs, resize handlers, and scroll events.

## When to Use
- Search-as-you-type features
- Window resize handlers
- Form validation triggers
- Auto-save functionality

## Key Concept
Wait for user to "finish" before executing expensive operations.`,
    code: `// Debounce implementation (pseudo-code)
function debounce(func, delay) {
  let timeoutId;
  
  return function(...args) {
    clearTimeout(timeoutId);
    
    timeoutId = setTimeout(() => {
      func.apply(this, args);
    }, delay);
  };
}

// Usage example
const searchInput = document.querySelector('#search');
const debouncedSearch = debounce(performSearch, 300);

searchInput.addEventListener('input', (e) => {
  debouncedSearch(e.target.value);
});

function performSearch(query) {
  // Expensive API call only happens after 300ms pause
  fetchResults(query);
}`,
    createdAt: '2025-01-11',
    updatedAt: '2025-01-11'
  },
  {
    id: 'cs-002',
    title: 'Repository Pattern',
    mode: 'code-shard',
    category: 'patterns',
    tags: ['architecture', 'database', 'abstraction', 'clean-code'],
    difficulty: 'intermediate',
    readTime: 5,
    content: `## What It Does
Abstracts data access logic into a separate layer. Decouples business logic from database implementation.

## Benefits
- Swap databases easily
- Centralized query logic
- Easier testing with mocks
- Consistent data access patterns

## Structure
Repository → Data Source → Database`,
    code: `// Repository pattern (pseudo-code)
class UserRepository {
  constructor(dataSource) {
    this.db = dataSource;
  }
  
  async findById(id) {
    return await this.db.query('SELECT * FROM users WHERE id = ?', [id]);
  }
  
  async findByEmail(email) {
    return await this.db.query('SELECT * FROM users WHERE email = ?', [email]);
  }
  
  async create(userData) {
    const result = await this.db.insert('users', userData);
    return result.insertId;
  }
  
  async update(id, userData) {
    return await this.db.update('users', userData, { id });
  }
  
  async delete(id) {
    return await this.db.delete('users', { id });
  }
}

// Usage in service layer
class UserService {
  constructor(userRepository) {
    this.users = userRepository;
  }
  
  async registerUser(email, password) {
    const existing = await this.users.findByEmail(email);
    if (existing) throw new Error('Email taken');
    
    const hashedPassword = await hash(password);
    return await this.users.create({ email, password: hashedPassword });
  }
}`,
    createdAt: '2025-01-10',
    updatedAt: '2025-01-10'
  },

  // DEVMIND GLOSSARY
  {
    id: 'dg-001',
    title: 'Idempotency',
    mode: 'devmind-glossary',
    category: 'apis',
    tags: ['http', 'api', 'concepts', 'rest'],
    difficulty: 'intermediate',
    readTime: 3,
    content: `## Definition
An operation is **idempotent** if performing it multiple times produces the same result as performing it once.

## Why It Matters
- Network failures require retries
- Prevents duplicate actions
- Safe to replay requests
- Critical for distributed systems

## Examples

### Idempotent Operations ✓
- GET /users/123 → Always returns same user
- PUT /users/123 → Replaces user entirely each time
- DELETE /users/123 → User deleted (or already gone)

### Non-Idempotent Operations ✗
- POST /users → Creates new user each time
- POST /payments → Charges customer multiple times

## Implementation Strategy
Use **idempotency keys**:
- Client generates unique request ID
- Server stores processed IDs
- Duplicate requests return cached response

## Real-World Application
Payment processors use idempotency keys to prevent double-charging when network hiccups cause request retries.`,
    createdAt: '2025-01-09',
    updatedAt: '2025-01-09'
  },
  {
    id: 'dg-002',
    title: 'Eventual Consistency',
    mode: 'devmind-glossary',
    category: 'databases',
    tags: ['distributed-systems', 'consistency', 'cap-theorem'],
    difficulty: 'advanced',
    readTime: 5,
    content: `## Definition
A consistency model where data updates propagate to all nodes **eventually**, but not immediately.

## Trade-Off: CAP Theorem
In distributed systems, you can't have all three:
- **C**onsistency: All nodes see same data
- **A**vailability: Every request gets response
- **P**artition tolerance: System works despite network splits

Eventual consistency chooses **AP** over **C**.

## How It Works
1. Write accepted immediately (fast)
2. Changes replicate asynchronously
3. Nodes temporarily out of sync
4. System converges to consistent state

## Examples

### Social Media Likes
- You like a post → instant feedback
- Other users see different counts briefly
- Eventually everyone sees correct total

### Shopping Cart
- Add item → shows immediately for you
- Inventory check happens asynchronously
- Occasional overselling resolved later

## When to Use ✓
- High availability needed
- Slight delays acceptable
- Read-heavy workloads
- Global distribution

## When to Avoid ✗
- Financial transactions
- Booking systems
- Strict ordering required
- Strong consistency critical

## Conflict Resolution
- **Last-write-wins**: Timestamp-based
- **Vector clocks**: Track causality
- **CRDTs**: Mathematically merge conflicts
- **Application logic**: Custom merge rules`,
    createdAt: '2025-01-08',
    updatedAt: '2025-01-08'
  },
  {
    id: 'dg-003',
    title: 'Hydration (SSR)',
    mode: 'devmind-glossary',
    category: 'frontend',
    tags: ['ssr', 'react', 'nextjs', 'rendering'],
    difficulty: 'intermediate',
    readTime: 4,
    content: `## Definition
The process of attaching event listeners and interactive JavaScript to server-rendered HTML.

## The Flow
1. **Server**: Renders HTML with content
2. **Browser**: Displays static HTML (fast!)
3. **JS Loads**: Framework code downloads
4. **Hydration**: React "wakes up" the static HTML
5. **Interactive**: Full app functionality

## Why It Exists
Solves the **blank page problem**:
- Pure client-side: User sees nothing until JS loads
- SSR + Hydration: User sees content immediately

## Common Issues

### Hydration Mismatch
Server HTML differs from client render:
- Date/time formatting differences
- Random data without seeds
- Browser-only APIs (window, localStorage)

**Fix**: Ensure server and client render identically

### Double Rendering
Component renders twice:
1. Server render (HTML)
2. Client hydration (JS)

**Solution**: Use \`useEffect\` for client-only logic

## Best Practices
- Keep server/client logic separate
- Use \`suppressHydrationWarning\` sparingly
- Lazy load heavy components
- Stream HTML for faster perceived load

## Frameworks
- Next.js: Built-in SSR + hydration
- Remix: Seamless server/client coordination
- Astro: Optional hydration (partial)`,
    createdAt: '2025-01-07',
    updatedAt: '2025-01-07'
  },

  // Additional entries for variety
  {
    id: 'rc-003',
    title: 'Deploy with Zero Downtime',
    mode: 'recipe-card',
    category: 'deployment',
    tags: ['devops', 'blue-green', 'rolling', 'ci-cd'],
    difficulty: 'advanced',
    readTime: 18,
    content: `## Ingredients
- Load balancer or reverse proxy
- Multiple server instances
- Health check endpoints
- Deployment automation tool

## Steps

### 1. Choose Strategy
- **Blue-Green**: Two identical environments
- **Rolling**: Update servers gradually
- **Canary**: Test on small percentage first

### 2. Set Up Infrastructure
- Multiple instances behind load balancer
- Health check endpoint (/health)
- Graceful shutdown handling
- Connection draining

### 3. Implement Health Checks
Monitor:
- Service availability
- Database connections
- External dependencies
- Memory/CPU usage

### 4. Deployment Flow (Blue-Green)
1. New version → Green environment
2. Run tests on Green
3. Switch load balancer to Green
4. Keep Blue as instant rollback
5. After validation, Blue becomes next staging

### 5. Graceful Shutdown
When stopping instance:
- Stop accepting new requests
- Finish in-flight requests
- Close connections properly
- Signal load balancer removal

### 6. Monitoring
Track during deployment:
- Error rates
- Response times
- Active connections
- Success metrics

## Rollback Plan
- Instant switch back to old version
- Keep database migrations backward-compatible
- Feature flags for gradual rollout`,
    code: `// Health check endpoint (pseudo-code)
app.get('/health', async (req, res) => {
  const checks = {
    database: await checkDatabase(),
    cache: await checkCache(),
    memory: checkMemory()
  };
  
  const healthy = Object.values(checks).every(c => c.ok);
  
  res.status(healthy ? 200 : 503).json({
    status: healthy ? 'healthy' : 'unhealthy',
    checks
  });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  server.close(() => {
    database.disconnect();
    cache.disconnect();
    process.exit(0);
  });
});`,
    createdAt: '2025-01-06',
    updatedAt: '2025-01-06'
  },
  {
    id: 'kp-003',
    title: 'State Management Strategies',
    mode: 'knowledge-pack',
    category: 'frontend',
    tags: ['state', 'redux', 'context', 'zustand'],
    difficulty: 'intermediate',
    readTime: 12,
    content: `## When to Use What

### Local State (useState)
**Best for**: Form inputs, toggles, UI state
- Component-only data
- No sharing needed
- Simple, fast

### Context API
**Best for**: Theme, auth, locale
- Infrequent updates
- Wide distribution
- Built-in React

### URL State
**Best for**: Filters, pagination, tabs
- Shareable links
- Browser history
- SEO-friendly

### Redux / Zustand
**Best for**: Complex app state
- Time-travel debugging
- Middleware needed
- Predictable updates

### Server State (React Query)
**Best for**: API data
- Caching
- Background refetch
- Optimistic updates

## Decision Tree
\`\`\`
Is it server data? → Use React Query
Is it in URL? → Use URL params
Does only one component need it? → useState
Do nearby components share it? → Lift state up
Does whole app need it rarely? → Context
Complex interactions? → Redux/Zustand
\`\`\`

## Anti-Patterns to Avoid
- Everything in global store
- Prop drilling 10+ levels
- Mixing server/UI state
- No loading/error states`,
    createdAt: '2025-01-05',
    updatedAt: '2025-01-05'
  },
  {
    id: 'cs-003',
    title: 'Observer Pattern',
    mode: 'code-shard',
    category: 'patterns',
    tags: ['design-patterns', 'events', 'pub-sub', 'reactive'],
    difficulty: 'beginner',
    readTime: 4,
    content: `## What It Does
Defines one-to-many dependency. When one object changes, all dependents get notified automatically.

## Use Cases
- Event systems
- Model-View updates
- Reactive programming
- State change propagation

## Roles
- **Subject**: Maintains observers list
- **Observer**: Gets notified of changes
- **ConcreteObserver**: Implements update logic`,
    code: `// Observer pattern (pseudo-code)
class Subject {
  constructor() {
    this.observers = [];
  }
  
  attach(observer) {
    this.observers.push(observer);
  }
  
  detach(observer) {
    this.observers = this.observers.filter(o => o !== observer);
  }
  
  notify(data) {
    this.observers.forEach(observer => {
      observer.update(data);
    });
  }
}

class ConcreteObserver {
  update(data) {
    console.log('Received update:', data);
    // React to changes
  }
}

// Usage
const subject = new Subject();
const observer1 = new ConcreteObserver();
const observer2 = new ConcreteObserver();

subject.attach(observer1);
subject.attach(observer2);

// Both observers get notified
subject.notify({ event: 'data-changed' });`,
    createdAt: '2025-01-04',
    updatedAt: '2025-01-04'
  },
  {
    id: 'dg-004',
    title: 'Race Condition',
    mode: 'devmind-glossary',
    category: 'performance',
    tags: ['concurrency', 'bugs', 'async', 'threading'],
    difficulty: 'intermediate',
    readTime: 4,
    content: `## Definition
A bug that occurs when program behavior depends on the unpredictable timing of multiple operations.

## Classic Example
Two requests try to update the same data:
1. Request A reads count = 10
2. Request B reads count = 10
3. Request A writes count = 11
4. Request B writes count = 11
Result: Should be 12, but it's 11!

## Common Scenarios

### Frontend
- Multiple setState calls
- Rapid API requests (search)
- Async operations completing out of order

### Backend
- Concurrent database writes
- File system operations
- Shared memory access

## Prevention Strategies

### Optimistic Locking
- Include version number in updates
- Reject stale updates

### Pessimistic Locking
- Lock resource during operation
- Other requests wait

### Atomic Operations
- Database transactions
- Compare-and-swap (CAS)

### Request Cancellation
- Cancel outdated requests
- Use request IDs to ignore old responses

### Debouncing/Throttling
- Limit operation frequency
- Queue and batch updates

## Real-World Fix
**Search race condition**:
User types "react" quickly → 5 requests fired:
- "r" → slow response (5s)
- "re" → fast response (1s)
- "rea" → fast response (1s)
- "reac" → fast response (1s)
- "react" → fast response (1s)

Wrong results shown if "r" finishes last!

**Solution**: Track request ID, ignore old responses.`,
    code: `// Race condition fix (pseudo-code)
let currentRequestId = 0;

async function search(query) {
  const requestId = ++currentRequestId;
  
  const results = await fetchResults(query);
  
  // Ignore if newer request already fired
  if (requestId !== currentRequestId) {
    return;
  }
  
  displayResults(results);
}`,
    createdAt: '2025-01-03',
    updatedAt: '2025-01-03'
  }
];
