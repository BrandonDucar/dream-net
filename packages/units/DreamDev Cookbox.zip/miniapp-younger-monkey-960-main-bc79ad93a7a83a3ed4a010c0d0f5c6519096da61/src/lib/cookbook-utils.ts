import type { CookbookItem, FilterState, ContentMode, Category } from '@/types/cookbook';

export function filterItems(items: CookbookItem[], filters: FilterState): CookbookItem[] {
  return items.filter(item => {
    // Mode filter
    if (filters.mode !== 'all' && item.mode !== filters.mode) {
      return false;
    }

    // Category filter
    if (filters.category !== 'all' && item.category !== filters.category) {
      return false;
    }

    // Difficulty filter
    if (filters.difficulty !== 'all' && item.difficulty !== filters.difficulty) {
      return false;
    }

    // Search query filter
    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase();
      const matchesTitle = item.title.toLowerCase().includes(query);
      const matchesTags = item.tags.some(tag => tag.toLowerCase().includes(query));
      const matchesContent = item.content.toLowerCase().includes(query);

      if (!matchesTitle && !matchesTags && !matchesContent) {
        return false;
      }
    }

    return true;
  });
}

export function getModeLabel(mode: ContentMode): string {
  const labels: Record<ContentMode, string> = {
    'knowledge-pack': 'Knowledge Pack',
    'recipe-card': 'Recipe Card',
    'code-shard': 'Code Shard',
    'devmind-glossary': 'DevMind Glossary'
  };
  return labels[mode];
}

export function getModeDescription(mode: ContentMode): string {
  const descriptions: Record<ContentMode, string> = {
    'knowledge-pack': 'Structured learning modules with comprehensive explanations',
    'recipe-card': 'Step-by-step templates for common development tasks',
    'code-shard': 'Reusable pseudo-code patterns and snippets',
    'devmind-glossary': 'Clear definitions of developer concepts and terminology'
  };
  return descriptions[mode];
}

export function getCategoryLabel(category: Category): string {
  const labels: Record<Category, string> = {
    'architecture': 'Architecture',
    'patterns': 'Patterns',
    'apis': 'APIs',
    'databases': 'Databases',
    'frontend': 'Frontend',
    'backend': 'Backend',
    'deployment': 'Deployment',
    'testing': 'Testing',
    'security': 'Security',
    'performance': 'Performance',
    'tools': 'Tools'
  };
  return labels[category];
}

export function getModeColor(mode: ContentMode): string {
  const colors: Record<ContentMode, string> = {
    'knowledge-pack': 'from-blue-500 to-cyan-500',
    'recipe-card': 'from-purple-500 to-pink-500',
    'code-shard': 'from-emerald-500 to-teal-500',
    'devmind-glossary': 'from-orange-500 to-red-500'
  };
  return colors[mode];
}

export function getDifficultyColor(difficulty: 'beginner' | 'intermediate' | 'advanced'): string {
  const colors = {
    'beginner': 'bg-green-500/20 text-green-300 border-green-500/30',
    'intermediate': 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
    'advanced': 'bg-red-500/20 text-red-300 border-red-500/30'
  };
  return colors[difficulty];
}

export function copyToClipboard(text: string): Promise<void> {
  if (navigator.clipboard && window.isSecureContext) {
    return navigator.clipboard.writeText(text);
  } else {
    // Fallback for older browsers
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    return new Promise<void>((resolve, reject) => {
      try {
        document.execCommand('copy');
        textArea.remove();
        resolve();
      } catch (error) {
        textArea.remove();
        reject(error);
      }
    });
  }
}
