export type ContentMode = 'knowledge-pack' | 'recipe-card' | 'code-shard' | 'devmind-glossary';

export type Category = 
  | 'architecture'
  | 'patterns'
  | 'apis'
  | 'databases'
  | 'frontend'
  | 'backend'
  | 'deployment'
  | 'testing'
  | 'security'
  | 'performance'
  | 'tools';

export interface CookbookItem {
  id: string;
  title: string;
  mode: ContentMode;
  category: Category;
  tags: string[];
  content: string;
  code?: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  readTime: number; // in minutes
  createdAt: string;
  updatedAt: string;
}

export interface FilterState {
  mode: ContentMode | 'all';
  category: Category | 'all';
  searchQuery: string;
  difficulty: 'all' | 'beginner' | 'intermediate' | 'advanced';
}
