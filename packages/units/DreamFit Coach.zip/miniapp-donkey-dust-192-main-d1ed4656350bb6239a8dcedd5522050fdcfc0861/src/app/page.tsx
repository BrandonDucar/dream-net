'use client'
import { useState, useEffect } from 'react';
import type { Goal, FitnessLevel, Duration, WorkoutPlan } from '@/types/workout';
import { WorkoutForm } from '@/components/workout-form';
import { WorkoutDisplay } from '@/components/workout-display';
import { generateWorkout } from '@/lib/workout-generator';
import { Dumbbell } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function HomePage(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [workout, setWorkout] = useState<WorkoutPlan | null>(null);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [currentPreferences, setCurrentPreferences] = useState<{
    goal: Goal;
    level: FitnessLevel;
    duration: Duration;
  } | null>(null);

  const handleGenerateWorkout = (
    goal: Goal,
    level: FitnessLevel,
    duration: Duration
  ): void => {
    setIsGenerating(true);
    setCurrentPreferences({ goal, level, duration });
    
    setTimeout(() => {
      const newWorkout: WorkoutPlan = generateWorkout({ goal, level, duration });
      setWorkout(newWorkout);
      setIsGenerating(false);
    }, 800);
  };

  const handleRegenerate = (): void => {
    if (currentPreferences) {
      handleGenerateWorkout(
        currentPreferences.goal,
        currentPreferences.level,
        currentPreferences.duration
      );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-yellow-50 py-8 px-4 pt-16">
      <div className="max-w-6xl mx-auto">
        <header className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-r from-orange-500 to-pink-500 rounded-2xl shadow-lg">
              <Dumbbell className="w-10 h-10 text-white" />
            </div>
            <div className="text-left">
              <h1 className="text-4xl md:text-5xl font-bold text-black">
                DreamFit Coach
              </h1>
              <p className="text-xl text-black font-semibold">$FIT</p>
            </div>
          </div>
          <p className="text-lg text-black max-w-2xl mx-auto">
            Your personal fitness companion! Tell us your goals, and we&apos;ll create a workout 
            that&apos;s perfect for you. Let&apos;s make your fitness dreams a reality! 💪
          </p>
        </header>

        {!workout ? (
          <WorkoutForm
            onSubmit={handleGenerateWorkout}
            isGenerating={isGenerating}
          />
        ) : (
          <WorkoutDisplay
            workout={workout}
            onRegenerate={handleRegenerate}
          />
        )}

        <footer className="text-center mt-12 text-sm text-black">
          <p>
            💡 Remember: Always consult with a healthcare professional before starting any new exercise program
          </p>
        </footer>
      </div>
    </div>
  );
}
