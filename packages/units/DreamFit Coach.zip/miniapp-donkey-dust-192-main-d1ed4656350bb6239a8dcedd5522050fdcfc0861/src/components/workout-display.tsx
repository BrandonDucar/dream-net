'use client';

import type { WorkoutPlan, Exercise } from '@/types/workout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { RefreshCcw, Flame, Target, Clock, Lightbulb } from 'lucide-react';

interface WorkoutDisplayProps {
  workout: WorkoutPlan;
  onRegenerate: () => void;
}

function ExerciseCard({ exercise, index }: { exercise: Exercise; index: number }): JSX.Element {
  return (
    <Card className="border-2 border-orange-100 hover:border-orange-300 transition-colors">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg text-black flex items-center gap-2">
              <span className="flex items-center justify-center w-7 h-7 rounded-full bg-orange-500 text-white text-sm font-bold">
                {index + 1}
              </span>
              {exercise.name}
            </CardTitle>
            {(exercise.sets || exercise.duration) && (
              <CardDescription className="mt-1 text-black">
                {exercise.sets && <span className="font-semibold">{exercise.sets} sets</span>}
                {exercise.sets && exercise.reps && <span> × </span>}
                {exercise.reps && <span className="font-semibold">{exercise.reps} reps</span>}
                {exercise.duration && <span className="font-semibold">{exercise.duration}</span>}
              </CardDescription>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm text-black leading-relaxed">{exercise.description}</p>
        
        <div className="space-y-2">
          <div className="flex items-start gap-2">
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 shrink-0">
              Form Tip
            </Badge>
            <p className="text-sm text-black">{exercise.formTip}</p>
          </div>
          
          <div className="flex items-start gap-2">
            <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 shrink-0">
              Alternative
            </Badge>
            <p className="text-sm text-black">{exercise.alternative}</p>
          </div>
          
          <div className="grid grid-cols-2 gap-2 mt-3">
            <div className="p-2 bg-purple-50 rounded-lg border border-purple-200">
              <p className="text-xs font-semibold text-purple-900 mb-1">With Equipment</p>
              <p className="text-sm text-black">{exercise.equipment}</p>
            </div>
            <div className="p-2 bg-orange-50 rounded-lg border border-orange-200">
              <p className="text-xs font-semibold text-orange-900 mb-1">No Equipment</p>
              <p className="text-sm text-black">{exercise.noEquipment}</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function WorkoutDisplay({ workout, onRegenerate }: WorkoutDisplayProps): JSX.Element {
  const goalLabels: Record<string, string> = {
    'lose-weight': 'Lose Weight',
    'tone-up': 'Tone Up',
    'gain-muscle': 'Gain Muscle',
    'feel-healthier': 'Feel Healthier',
    'just-moving': 'Just Get Moving'
  };

  const levelLabels: Record<string, string> = {
    'beginner': 'Beginner',
    'intermediate': 'Intermediate',
    'advanced': 'Advanced'
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 animate-in fade-in duration-500">
      <Card className="border-2 border-orange-300 bg-gradient-to-br from-orange-50 via-pink-50 to-yellow-50">
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <CardTitle className="text-3xl text-black mb-2">
                Your Custom Workout 🎉
              </CardTitle>
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-orange-500 text-white">
                  <Target className="w-3 h-3 mr-1" />
                  {goalLabels[workout.goal]}
                </Badge>
                <Badge className="bg-pink-500 text-white">
                  <Flame className="w-3 h-3 mr-1" />
                  {levelLabels[workout.level]}
                </Badge>
                <Badge className="bg-purple-500 text-white">
                  <Clock className="w-3 h-3 mr-1" />
                  {workout.duration} minutes
                </Badge>
              </div>
            </div>
            <Button
              onClick={onRegenerate}
              className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white"
            >
              <RefreshCcw className="w-4 h-4 mr-2" />
              Regenerate Workout
            </Button>
          </div>
        </CardHeader>
      </Card>

      <div className="space-y-6">
        <section>
          <div className="flex items-center gap-2 mb-4">
            <div className="p-2 bg-blue-500 rounded-lg">
              <Flame className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-black">Warm-up</h2>
          </div>
          <div className="grid gap-4">
            {workout.warmup.map((exercise: Exercise, index: number) => (
              <ExerciseCard key={`warmup-${index}`} exercise={exercise} index={index} />
            ))}
          </div>
        </section>

        <Separator className="my-8" />

        <section>
          <div className="flex items-center gap-2 mb-4">
            <div className="p-2 bg-orange-500 rounded-lg">
              <Target className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-black">Main Routine</h2>
          </div>
          <div className="grid gap-4">
            {workout.mainRoutine.map((exercise: Exercise, index: number) => (
              <ExerciseCard key={`main-${index}`} exercise={exercise} index={index} />
            ))}
          </div>
        </section>

        <Separator className="my-8" />

        <section>
          <div className="flex items-center gap-2 mb-4">
            <div className="p-2 bg-green-500 rounded-lg">
              <Clock className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-black">Cooldown</h2>
          </div>
          <div className="grid gap-4">
            {workout.cooldown.map((exercise: Exercise, index: number) => (
              <ExerciseCard key={`cooldown-${index}`} exercise={exercise} index={index} />
            ))}
          </div>
        </section>

        <Separator className="my-8" />

        <Card className="border-2 border-yellow-300 bg-gradient-to-br from-yellow-50 to-orange-50">
          <CardHeader>
            <CardTitle className="text-xl text-black flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-yellow-600" />
              Pro Tips for Success
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {workout.generalTips.map((tip: string, index: number) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="text-orange-500 font-bold shrink-0">•</span>
                  <span className="text-black">{tip}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
