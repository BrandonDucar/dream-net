'use client';

import type { Goal, FitnessLevel, Duration } from '@/types/workout';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dumbbell } from 'lucide-react';

interface WorkoutFormProps {
  onSubmit: (goal: Goal, level: FitnessLevel, duration: Duration) => void;
  isGenerating: boolean;
}

const goalOptions: Array<{ value: Goal; label: string; emoji: string }> = [
  { value: 'lose-weight', label: 'Lose Weight', emoji: '🔥' },
  { value: 'tone-up', label: 'Tone Up', emoji: '💪' },
  { value: 'gain-muscle', label: 'Gain Muscle', emoji: '🏋️' },
  { value: 'feel-healthier', label: 'Feel Healthier', emoji: '❤️' },
  { value: 'just-moving', label: 'Just Get Moving', emoji: '✨' }
];

const levelOptions: Array<{ value: FitnessLevel; label: string }> = [
  { value: 'beginner', label: 'Beginner' },
  { value: 'intermediate', label: 'Intermediate' },
  { value: 'advanced', label: 'Advanced' }
];

const durationOptions: Array<{ value: Duration; label: string }> = [
  { value: 10, label: '10 minutes' },
  { value: 20, label: '20 minutes' },
  { value: 30, label: '30 minutes' }
];

export function WorkoutForm({ onSubmit, isGenerating }: WorkoutFormProps): JSX.Element {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    const formData: FormData = new FormData(e.currentTarget);
    const goal: Goal = formData.get('goal') as Goal;
    const level: FitnessLevel = formData.get('level') as FitnessLevel;
    const duration: Duration = parseInt(formData.get('duration') as string) as Duration;
    
    if (goal && level && duration) {
      onSubmit(goal, level, duration);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto border-2 border-orange-200 shadow-lg">
      <CardHeader className="bg-gradient-to-r from-orange-50 to-yellow-50">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-orange-500 rounded-lg">
            <Dumbbell className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl text-black">Let&apos;s Build Your Workout!</CardTitle>
            <CardDescription className="text-black">Tell us about your fitness goals</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="goal" className="text-base font-semibold text-black">
              What&apos;s your goal?
            </Label>
            <Select name="goal" required>
              <SelectTrigger id="goal" className="w-full h-12 text-base border-2">
                <SelectValue placeholder="Choose your fitness goal" />
              </SelectTrigger>
              <SelectContent>
                {goalOptions.map((option: { value: Goal; label: string; emoji: string }) => (
                  <SelectItem key={option.value} value={option.value} className="text-base py-3">
                    <span className="flex items-center gap-2">
                      <span className="text-xl">{option.emoji}</span>
                      {option.label}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="level" className="text-base font-semibold text-black">
              What&apos;s your fitness level?
            </Label>
            <Select name="level" required>
              <SelectTrigger id="level" className="w-full h-12 text-base border-2">
                <SelectValue placeholder="Select your level" />
              </SelectTrigger>
              <SelectContent>
                {levelOptions.map((option: { value: FitnessLevel; label: string }) => (
                  <SelectItem key={option.value} value={option.value} className="text-base py-3">
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="duration" className="text-base font-semibold text-black">
              How much time do you have?
            </Label>
            <Select name="duration" required>
              <SelectTrigger id="duration" className="w-full h-12 text-base border-2">
                <SelectValue placeholder="Choose workout duration" />
              </SelectTrigger>
              <SelectContent>
                {durationOptions.map((option: { value: Duration; label: string }) => (
                  <SelectItem key={option.value} value={option.value.toString()} className="text-base py-3">
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button
            type="submit"
            disabled={isGenerating}
            className="w-full h-12 text-lg font-semibold bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white"
          >
            {isGenerating ? '⚡ Generating Your Workout...' : '🚀 Generate My Workout!'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
