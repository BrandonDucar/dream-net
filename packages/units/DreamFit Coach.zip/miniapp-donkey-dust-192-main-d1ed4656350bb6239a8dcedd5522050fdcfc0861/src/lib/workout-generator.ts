import type { WorkoutPlan, UserPreferences, Exercise, Goal, FitnessLevel, Duration } from '@/types/workout';

const warmupExercises: Record<FitnessLevel, Exercise[]> = {
  beginner: [
    {
      name: 'Arm Circles',
      duration: '1 min',
      description: 'Stand with arms extended, make small circles gradually increasing size',
      formTip: 'Keep shoulders relaxed and maintain steady breathing',
      alternative: 'Shoulder rolls if arm circles are uncomfortable',
      equipment: 'None',
      noEquipment: 'None'
    },
    {
      name: 'Marching in Place',
      duration: '2 min',
      description: 'Lift knees to hip height while swinging arms naturally',
      formTip: 'Land softly on the balls of your feet',
      alternative: 'Step touches side to side',
      equipment: 'None',
      noEquipment: 'None'
    }
  ],
  intermediate: [
    {
      name: 'Jumping Jacks',
      duration: '1.5 min',
      description: 'Jump while spreading legs and raising arms overhead',
      formTip: 'Land with soft knees to protect joints',
      alternative: 'Step jacks for lower impact',
      equipment: 'None',
      noEquipment: 'None'
    },
    {
      name: 'High Knees',
      duration: '1.5 min',
      description: 'Run in place bringing knees up to hip level',
      formTip: 'Keep core engaged and maintain upright posture',
      alternative: 'Marching in place at a slower pace',
      equipment: 'None',
      noEquipment: 'None'
    }
  ],
  advanced: [
    {
      name: 'Burpees',
      duration: '2 min',
      description: 'Squat, kick back to plank, push-up, jump back to squat, jump up',
      formTip: 'Maintain core stability throughout the movement',
      alternative: 'Modified burpees without push-up',
      equipment: 'None',
      noEquipment: 'None'
    },
    {
      name: 'Mountain Climbers',
      duration: '1.5 min',
      description: 'From plank position, alternate driving knees toward chest',
      formTip: 'Keep hips level and core tight',
      alternative: 'Slow mountain climbers with pause',
      equipment: 'None',
      noEquipment: 'None'
    }
  ]
};

const cooldownExercises: Exercise[] = [
  {
    name: 'Standing Forward Fold',
    duration: '1 min',
    description: 'Stand and slowly fold forward, letting arms hang toward floor',
    formTip: 'Keep knees slightly bent, relax your neck',
    alternative: 'Seated forward fold on the floor',
    equipment: 'None',
    noEquipment: 'None'
  },
  {
    name: 'Child\'s Pose',
    duration: '1 min',
    description: 'Kneel and sit back on heels, extending arms forward on the floor',
    formTip: 'Breathe deeply and relax shoulders',
    alternative: 'Standing side stretch',
    equipment: 'Yoga mat (optional)',
    noEquipment: 'None'
  },
  {
    name: 'Seated Spinal Twist',
    duration: '1 min each side',
    description: 'Sit cross-legged and gently twist torso to each side',
    formTip: 'Keep spine tall and twist from the waist',
    alternative: 'Standing gentle twist',
    equipment: 'None',
    noEquipment: 'None'
  }
];

const mainExercises: Record<Goal, Record<FitnessLevel, Exercise[]>> = {
  'lose-weight': {
    beginner: [
      {
        name: 'Bodyweight Squats',
        sets: '3',
        reps: '12',
        description: 'Stand with feet hip-width apart, lower hips back and down',
        formTip: 'Keep chest up and knees tracking over toes',
        alternative: 'Chair squats for support',
        equipment: 'Dumbbells for added resistance',
        noEquipment: 'Bodyweight only'
      },
      {
        name: 'Walking Lunges',
        sets: '3',
        reps: '10 each leg',
        description: 'Step forward and lower back knee toward ground',
        formTip: 'Keep front knee behind toes',
        alternative: 'Stationary lunges',
        equipment: 'Dumbbells',
        noEquipment: 'Bodyweight only'
      },
      {
        name: 'Modified Push-ups',
        sets: '3',
        reps: '10',
        description: 'Push-ups from knees or against wall',
        formTip: 'Keep body in straight line from head to knees',
        alternative: 'Wall push-ups',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Plank Hold',
        sets: '3',
        duration: '20 seconds',
        description: 'Hold straight body position on forearms',
        formTip: 'Don\'t let hips sag or pike up',
        alternative: 'Plank from knees',
        equipment: 'None',
        noEquipment: 'None'
      }
    ],
    intermediate: [
      {
        name: 'Jump Squats',
        sets: '4',
        reps: '15',
        description: 'Squat down and explode up into a jump',
        formTip: 'Land softly with bent knees',
        alternative: 'Pulse squats',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Burpees',
        sets: '3',
        reps: '12',
        description: 'Full burpee with push-up and jump',
        formTip: 'Maintain steady pace and control',
        alternative: 'Step back burpees',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Mountain Climbers',
        sets: '4',
        duration: '30 seconds',
        description: 'Fast knee drives from plank position',
        formTip: 'Keep core engaged throughout',
        alternative: 'Slow controlled mountain climbers',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Bicycle Crunches',
        sets: '3',
        reps: '20',
        description: 'Alternate elbow to opposite knee',
        formTip: 'Focus on rotation, not speed',
        alternative: 'Regular crunches',
        equipment: 'None',
        noEquipment: 'None'
      }
    ],
    advanced: [
      {
        name: 'Burpee Box Jumps',
        sets: '4',
        reps: '12',
        description: 'Burpee followed by explosive box jump',
        formTip: 'Land with soft knees on box',
        alternative: 'Regular burpees',
        equipment: 'Plyometric box',
        noEquipment: 'Burpees with tuck jump'
      },
      {
        name: 'Kettlebell Swings',
        sets: '4',
        reps: '20',
        description: 'Hip hinge swing with kettlebell to shoulder height',
        formTip: 'Power comes from hips, not arms',
        alternative: 'Dumbbell swings',
        equipment: 'Kettlebell',
        noEquipment: 'Jump squats'
      },
      {
        name: 'High-Intensity Sprints',
        sets: '5',
        duration: '30 seconds',
        description: 'Sprint at maximum effort',
        formTip: 'Full recovery between sets',
        alternative: 'Fast running in place',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Turkish Get-ups',
        sets: '3',
        reps: '5 each side',
        description: 'Rise from floor to standing with weight overhead',
        formTip: 'Move slowly and maintain control',
        alternative: 'Weighted sit-ups',
        equipment: 'Kettlebell or dumbbell',
        noEquipment: 'Bodyweight get-ups'
      }
    ]
  },
  'tone-up': {
    beginner: [
      {
        name: 'Wall Push-ups',
        sets: '3',
        reps: '12',
        description: 'Push-ups against wall at arm\'s length',
        formTip: 'Keep body straight and core engaged',
        alternative: 'Counter push-ups',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Glute Bridges',
        sets: '3',
        reps: '15',
        description: 'Lie on back, lift hips toward ceiling',
        formTip: 'Squeeze glutes at the top',
        alternative: 'Single-leg glute bridges',
        equipment: 'Resistance band',
        noEquipment: 'Bodyweight only'
      },
      {
        name: 'Bicep Curls',
        sets: '3',
        reps: '12',
        description: 'Curl weights to shoulders',
        formTip: 'Keep elbows stationary',
        alternative: 'Resistance band curls',
        equipment: 'Dumbbells',
        noEquipment: 'Water bottles or cans'
      },
      {
        name: 'Tricep Dips',
        sets: '3',
        reps: '10',
        description: 'Dip on chair or bench',
        formTip: 'Keep shoulders down and back',
        alternative: 'Assisted dips',
        equipment: 'Chair or bench',
        noEquipment: 'Use a sturdy chair'
      }
    ],
    intermediate: [
      {
        name: 'Regular Push-ups',
        sets: '3',
        reps: '15',
        description: 'Standard push-ups from toes',
        formTip: 'Full range of motion',
        alternative: 'Diamond push-ups for triceps',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Dumbbell Rows',
        sets: '3',
        reps: '12 each arm',
        description: 'Bent over, pull weight to hip',
        formTip: 'Keep back flat and core tight',
        alternative: 'Resistance band rows',
        equipment: 'Dumbbells',
        noEquipment: 'Filled backpack'
      },
      {
        name: 'Shoulder Press',
        sets: '3',
        reps: '12',
        description: 'Press weights overhead',
        formTip: 'Don\'t arch lower back',
        alternative: 'Pike push-ups',
        equipment: 'Dumbbells',
        noEquipment: 'Pike push-ups'
      },
      {
        name: 'Reverse Lunges',
        sets: '3',
        reps: '12 each leg',
        description: 'Step back and lower into lunge',
        formTip: 'Keep torso upright',
        alternative: 'Forward lunges',
        equipment: 'Dumbbells',
        noEquipment: 'Bodyweight only'
      }
    ],
    advanced: [
      {
        name: 'Weighted Pull-ups',
        sets: '4',
        reps: '8',
        description: 'Pull-ups with weight belt or vest',
        formTip: 'Full range of motion',
        alternative: 'Regular pull-ups',
        equipment: 'Pull-up bar and weights',
        noEquipment: 'Pull-ups or inverted rows'
      },
      {
        name: 'Barbell Squats',
        sets: '4',
        reps: '10',
        description: 'Squat with barbell on shoulders',
        formTip: 'Depth to parallel or below',
        alternative: 'Goblet squats',
        equipment: 'Barbell',
        noEquipment: 'Jump squats'
      },
      {
        name: 'Bench Press',
        sets: '4',
        reps: '10',
        description: 'Press barbell from chest',
        formTip: 'Control the descent',
        alternative: 'Dumbbell press',
        equipment: 'Barbell and bench',
        noEquipment: 'Decline push-ups'
      },
      {
        name: 'Deadlifts',
        sets: '4',
        reps: '8',
        description: 'Lift barbell from floor to standing',
        formTip: 'Keep back neutral throughout',
        alternative: 'Romanian deadlifts',
        equipment: 'Barbell',
        noEquipment: 'Single-leg deadlifts'
      }
    ]
  },
  'gain-muscle': {
    beginner: [
      {
        name: 'Goblet Squats',
        sets: '3',
        reps: '10',
        description: 'Hold weight at chest, squat down',
        formTip: 'Elbows track inside knees',
        alternative: 'Bodyweight squats',
        equipment: 'Dumbbell or kettlebell',
        noEquipment: 'Bodyweight squats'
      },
      {
        name: 'Dumbbell Chest Press',
        sets: '3',
        reps: '10',
        description: 'Press dumbbells up from chest',
        formTip: 'Keep feet flat on floor',
        alternative: 'Push-ups',
        equipment: 'Dumbbells and bench',
        noEquipment: 'Push-ups'
      },
      {
        name: 'Assisted Pull-ups',
        sets: '3',
        reps: '8',
        description: 'Pull-ups with resistance band assistance',
        formTip: 'Full range of motion',
        alternative: 'Inverted rows',
        equipment: 'Pull-up bar and band',
        noEquipment: 'Inverted rows under table'
      },
      {
        name: 'Dumbbell Shoulder Press',
        sets: '3',
        reps: '10',
        description: 'Press dumbbells overhead',
        formTip: 'Control the movement',
        alternative: 'Pike push-ups',
        equipment: 'Dumbbells',
        noEquipment: 'Pike push-ups'
      }
    ],
    intermediate: [
      {
        name: 'Barbell Squats',
        sets: '4',
        reps: '8',
        description: 'Back squat with barbell',
        formTip: 'Break at hips and knees simultaneously',
        alternative: 'Dumbbell squats',
        equipment: 'Barbell and rack',
        noEquipment: 'Bulgarian split squats'
      },
      {
        name: 'Barbell Bench Press',
        sets: '4',
        reps: '8',
        description: 'Press barbell from chest',
        formTip: 'Bar path slightly diagonal',
        alternative: 'Dumbbell press',
        equipment: 'Barbell and bench',
        noEquipment: 'Weighted push-ups'
      },
      {
        name: 'Barbell Rows',
        sets: '4',
        reps: '8',
        description: 'Pull barbell to lower chest',
        formTip: 'Hinge at hips, keep back flat',
        alternative: 'Dumbbell rows',
        equipment: 'Barbell',
        noEquipment: 'Inverted rows'
      },
      {
        name: 'Romanian Deadlifts',
        sets: '4',
        reps: '10',
        description: 'Hip hinge with slight knee bend',
        formTip: 'Feel stretch in hamstrings',
        alternative: 'Single-leg deadlifts',
        equipment: 'Barbell',
        noEquipment: 'Single-leg deadlifts'
      }
    ],
    advanced: [
      {
        name: 'Heavy Squats',
        sets: '5',
        reps: '5',
        description: 'Low-rep heavy back squats',
        formTip: 'Full depth with control',
        alternative: 'Front squats',
        equipment: 'Barbell and rack',
        noEquipment: 'Pistol squats'
      },
      {
        name: 'Heavy Deadlifts',
        sets: '5',
        reps: '5',
        description: 'Conventional deadlift heavy weight',
        formTip: 'Brace core hard before lift',
        alternative: 'Trap bar deadlifts',
        equipment: 'Barbell',
        noEquipment: 'Single-leg deadlifts with weight'
      },
      {
        name: 'Weighted Pull-ups',
        sets: '4',
        reps: '6',
        description: 'Pull-ups with added weight',
        formTip: 'Chin over bar each rep',
        alternative: 'Regular pull-ups',
        equipment: 'Pull-up bar and weight belt',
        noEquipment: 'Pull-ups with pause'
      },
      {
        name: 'Overhead Press',
        sets: '4',
        reps: '6',
        description: 'Barbell press from shoulders',
        formTip: 'Lock out completely at top',
        alternative: 'Dumbbell press',
        equipment: 'Barbell',
        noEquipment: 'Handstand push-ups'
      }
    ]
  },
  'feel-healthier': {
    beginner: [
      {
        name: 'Gentle Squats',
        sets: '2',
        reps: '10',
        description: 'Slow, controlled squats',
        formTip: 'Focus on form over speed',
        alternative: 'Chair squats',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Wall Push-ups',
        sets: '2',
        reps: '10',
        description: 'Easy push-ups against wall',
        formTip: 'Keep movements smooth',
        alternative: 'Standing arm raises',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Step-ups',
        sets: '2',
        reps: '8 each leg',
        description: 'Step up onto low platform',
        formTip: 'Use full foot on step',
        alternative: 'March in place',
        equipment: 'Low step or stairs',
        noEquipment: 'Use bottom stair'
      },
      {
        name: 'Standing Side Bends',
        sets: '2',
        reps: '10 each side',
        description: 'Gentle side-to-side bends',
        formTip: 'Move slowly and controlled',
        alternative: 'Seated side bends',
        equipment: 'None',
        noEquipment: 'None'
      }
    ],
    intermediate: [
      {
        name: 'Walking',
        sets: '1',
        duration: '10 minutes',
        description: 'Brisk walk at comfortable pace',
        formTip: 'Swing arms naturally',
        alternative: 'Stationary biking',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Bodyweight Squats',
        sets: '3',
        reps: '12',
        description: 'Regular squats',
        formTip: 'Control the movement',
        alternative: 'Chair squats',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Push-ups',
        sets: '3',
        reps: '10',
        description: 'Modified or regular push-ups',
        formTip: 'Keep core engaged',
        alternative: 'Wall push-ups',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Yoga Flow',
        sets: '1',
        duration: '5 minutes',
        description: 'Cat-cow and downward dog sequence',
        formTip: 'Breathe with movements',
        alternative: 'Gentle stretching',
        equipment: 'Yoga mat',
        noEquipment: 'On carpet or towel'
      }
    ],
    advanced: [
      {
        name: 'Jogging',
        sets: '1',
        duration: '15 minutes',
        description: 'Light jog at steady pace',
        formTip: 'Maintain consistent breathing',
        alternative: 'Fast walking',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Circuit Training',
        sets: '3 rounds',
        reps: 'varies',
        description: 'Squats, push-ups, lunges, planks - 30s each',
        formTip: 'Minimal rest between exercises',
        alternative: 'Slower paced circuit',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Yoga Vinyasa Flow',
        sets: '1',
        duration: '10 minutes',
        description: 'Dynamic yoga sequence',
        formTip: 'Focus on breath and movement connection',
        alternative: 'Slow flow yoga',
        equipment: 'Yoga mat',
        noEquipment: 'On carpet or towel'
      },
      {
        name: 'Core Workout',
        sets: '3',
        reps: 'varies',
        description: 'Planks, bicycle crunches, leg raises - 30s each',
        formTip: 'Quality over quantity',
        alternative: 'Modified core exercises',
        equipment: 'None',
        noEquipment: 'None'
      }
    ]
  },
  'just-moving': {
    beginner: [
      {
        name: 'March in Place',
        sets: '1',
        duration: '3 minutes',
        description: 'Lift knees and swing arms',
        formTip: 'Keep it light and fun',
        alternative: 'Side steps',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Arm Circles',
        sets: '2',
        duration: '1 minute each direction',
        description: 'Big circles with arms extended',
        formTip: 'Stay relaxed',
        alternative: 'Shoulder shrugs',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Gentle Squats',
        sets: '2',
        reps: '8',
        description: 'Easy squats, as low as comfortable',
        formTip: 'Go at your own pace',
        alternative: 'Sit-to-stands from chair',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Dance Break',
        sets: '1',
        duration: '3 minutes',
        description: 'Move to your favorite song',
        formTip: 'Have fun with it!',
        alternative: 'Sway and step side to side',
        equipment: 'Music',
        noEquipment: 'None'
      }
    ],
    intermediate: [
      {
        name: 'Brisk Walking',
        sets: '1',
        duration: '8 minutes',
        description: 'Walk at comfortable but energetic pace',
        formTip: 'Enjoy the movement',
        alternative: 'Dancing',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Jumping Jacks',
        sets: '3',
        duration: '30 seconds',
        description: 'Classic jumping jacks',
        formTip: 'Keep it playful',
        alternative: 'Step jacks',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Bodyweight Squats',
        sets: '2',
        reps: '12',
        description: 'Regular squats',
        formTip: 'Feel strong!',
        alternative: 'Pulse squats',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Dance Cardio',
        sets: '1',
        duration: '5 minutes',
        description: 'Free movement to music',
        formTip: 'Express yourself',
        alternative: 'March with arm movements',
        equipment: 'Music',
        noEquipment: 'None'
      }
    ],
    advanced: [
      {
        name: 'Light Jog',
        sets: '1',
        duration: '12 minutes',
        description: 'Easy jog',
        formTip: 'Enjoy the rhythm',
        alternative: 'Fast walking',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Burpees',
        sets: '3',
        reps: '10',
        description: 'Full burpees',
        formTip: 'Feel powerful',
        alternative: 'Step back burpees',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'High Knees',
        sets: '3',
        duration: '45 seconds',
        description: 'Running with high knees',
        formTip: 'Keep energy up',
        alternative: 'Marching with high knees',
        equipment: 'None',
        noEquipment: 'None'
      },
      {
        name: 'Full Body Flow',
        sets: '2',
        duration: '5 minutes',
        description: 'Combination of movements',
        formTip: 'Move with joy',
        alternative: 'Yoga flow',
        equipment: 'None',
        noEquipment: 'None'
      }
    ]
  }
};

const generalTips: Record<Goal, string[]> = {
  'lose-weight': [
    'Stay consistent with your workouts - aim for 4-5 sessions per week',
    'Combine exercise with a balanced diet for best results',
    'Keep your heart rate elevated during main exercises',
    'Stay hydrated before, during, and after your workout',
    'Track your progress weekly to stay motivated'
  ],
  'tone-up': [
    'Focus on controlled movements for better muscle engagement',
    'Progressive overload is key - gradually increase difficulty',
    'Ensure adequate protein intake to support muscle definition',
    'Rest 48 hours between working the same muscle groups',
    'Quality of reps matters more than quantity'
  ],
  'gain-muscle': [
    'Lift heavy with proper form - challenge yourself safely',
    'Eat in a caloric surplus with plenty of protein',
    'Get 7-9 hours of sleep for optimal muscle recovery',
    'Rest 2-3 minutes between heavy sets',
    'Track your lifts to ensure progressive overload'
  ],
  'feel-healthier': [
    'Listen to your body and rest when needed',
    'Consistency is more important than intensity',
    'Stay hydrated throughout the day',
    'Focus on how exercise makes you feel',
    'Celebrate small wins and progress'
  ],
  'just-moving': [
    'Movement is movement - every bit counts!',
    'Make it fun - put on music you love',
    'Don\'t overthink it - just get started',
    'Any exercise is better than none',
    'Enjoy the natural mood boost from moving'
  ]
};

function adjustExercisesForDuration(
  exercises: Exercise[],
  duration: Duration,
  level: FitnessLevel
): Exercise[] {
  const baseExercises: number = duration === 10 ? 4 : duration === 20 ? 6 : 8;
  
  if (exercises.length >= baseExercises) {
    return exercises.slice(0, baseExercises);
  }
  
  return exercises;
}

function getRandomVariation(): number {
  return Math.random();
}

export function generateWorkout(preferences: UserPreferences): WorkoutPlan {
  const { goal, level, duration } = preferences;
  
  const warmup: Exercise[] = warmupExercises[level];
  const main: Exercise[] = mainExercises[goal][level];
  const mainRoutine: Exercise[] = adjustExercisesForDuration(main, duration, level);
  const cooldown: Exercise[] = cooldownExercises;
  
  const variation: number = getRandomVariation();
  if (variation > 0.5 && mainRoutine.length > 1) {
    const temp: Exercise = mainRoutine[0];
    mainRoutine[0] = mainRoutine[1];
    mainRoutine[1] = temp;
  }
  
  return {
    goal,
    level,
    duration,
    warmup,
    mainRoutine,
    cooldown,
    generalTips: generalTips[goal]
  };
}
