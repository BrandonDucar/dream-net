export type Goal = 'lose-weight' | 'tone-up' | 'gain-muscle' | 'feel-healthier' | 'just-moving';
export type FitnessLevel = 'beginner' | 'intermediate' | 'advanced';
export type Duration = 10 | 20 | 30;

export interface Exercise {
  name: string;
  sets?: string;
  reps?: string;
  duration?: string;
  description: string;
  formTip: string;
  alternative: string;
  equipment: string;
  noEquipment: string;
}

export interface WorkoutPlan {
  goal: Goal;
  level: FitnessLevel;
  duration: Duration;
  warmup: Exercise[];
  mainRoutine: Exercise[];
  cooldown: Exercise[];
  generalTips: string[];
}

export interface UserPreferences {
  goal: Goal;
  level: FitnessLevel;
  duration: Duration;
}
