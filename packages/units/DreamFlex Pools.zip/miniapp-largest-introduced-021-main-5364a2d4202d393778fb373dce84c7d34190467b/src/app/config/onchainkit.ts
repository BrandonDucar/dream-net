export const ONCHAINKIT_API_KEY = 'c57f83a5-49b5-49cc-aa50-e81c2f88ea4c';
export const ONCHAINKIT_PROJECT_ID = 'f603e6fe-cd87-40f8-9a1c-2fe87e879dd0';
