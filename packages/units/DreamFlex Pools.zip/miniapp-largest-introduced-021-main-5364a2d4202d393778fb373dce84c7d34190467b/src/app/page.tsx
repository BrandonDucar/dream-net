'use client'
import { useState, useEffect } from 'react';
import { usePrivy } from '@privy-io/react-auth';
import { useAccount } from 'wagmi';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { PoolWizard } from '@/components/pool-wizard';
import { LiquidityManager } from '@/components/liquidity-manager';
import { PositionTracker } from '@/components/position-tracker';
import { Loader2, Wallet, Plus, BarChart3, AlertTriangle } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Home() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const { ready, authenticated, login, logout } = usePrivy();
  const { address, isConnected } = useAccount();
  const [showWizard, setShowWizard] = useState<boolean>(false);

  // Mock positions data
  const mockPositions = [
    {
      id: '1',
      tokenA: 'ETH',
      tokenB: 'USDC',
      liquidityUSD: '50000',
      poolShare: '2.5',
      lpTokens: '162.45',
      feeTier: '0.3',
      pnl: 5.2,
      feesEarned: '125.50',
    },
    {
      id: '2',
      tokenA: 'DAI',
      tokenB: 'USDC',
      liquidityUSD: '25000',
      poolShare: '1.2',
      lpTokens: '89.32',
      feeTier: '0.01',
      pnl: -2.1,
      feesEarned: '45.30',
    },
  ];

  if (!ready) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-slate-600">Loading DreamFlex Pools...</p>
        </div>
      </div>
    );
  }

  if (!authenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 space-y-6">
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
              <Wallet className="h-8 w-8 text-blue-600" />
            </div>
            <h1 className="text-3xl font-bold mb-2">DreamFlex Pools</h1>
            <p className="text-slate-600">
              Create and manage liquidity pools for any ERC-20 token on Base
            </p>
          </div>

          <div className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg space-y-2">
              <h3 className="font-semibold text-blue-900">Features:</h3>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>✓ Create custom liquidity pools</li>
                <li>✓ Choose your fee tier</li>
                <li>✓ Track positions in real-time</li>
                <li>✓ Manage liquidity easily</li>
                <li>✓ View accurate pricing & PnL</li>
              </ul>
            </div>

            <Button onClick={login} className="w-full" size="lg">
              <Wallet className="mr-2 h-5 w-5" />
              Connect Wallet to Start
            </Button>
          </div>

          <p className="text-xs text-center text-slate-500">
            By connecting, you agree to our terms of service
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <header className="mb-8">
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold mb-1">DreamFlex Pools</h1>
                <p className="text-slate-600">Liquidity management on Base</p>
              </div>
              <div className="flex items-center gap-4">
                {isConnected && address && (
                  <div className="bg-slate-100 px-4 py-2 rounded-lg">
                    <p className="text-xs text-slate-600 mb-1">Connected Wallet</p>
                    <p className="font-mono text-sm font-medium">
                      {address.slice(0, 6)}...{address.slice(-4)}
                    </p>
                  </div>
                )}
                <Button onClick={logout} variant="outline">
                  Disconnect
                </Button>
              </div>
            </div>
          </div>
        </header>

        <Alert className="mb-6 bg-blue-50 border-blue-200">
          <AlertTriangle className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-900">
            <strong>Important:</strong> Always verify pool details before adding liquidity. High slippage or low liquidity can result in unfavorable trades.
          </AlertDescription>
        </Alert>

        {showWizard ? (
          <div className="max-w-2xl mx-auto">
            <Button
              variant="outline"
              onClick={() => setShowWizard(false)}
              className="mb-4"
            >
              ← Back to Dashboard
            </Button>
            <PoolWizard onComplete={() => setShowWizard(false)} />
          </div>
        ) : (
          <Tabs defaultValue="positions" className="space-y-6">
            <TabsList className="bg-white">
              <TabsTrigger value="positions" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                My Positions
              </TabsTrigger>
              <TabsTrigger value="create" className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Create Pool
              </TabsTrigger>
            </TabsList>

            <TabsContent value="positions" className="space-y-6">
              <PositionTracker positions={mockPositions} />
              {mockPositions.length > 0 && (
                <LiquidityManager poolAddress="0x123..." />
              )}
            </TabsContent>

            <TabsContent value="create">
              <div className="max-w-2xl mx-auto">
                <PoolWizard onComplete={() => setShowWizard(false)} />
              </div>
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
}
