'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Plus, Minus, AlertTriangle, TrendingUp, DollarSign } from 'lucide-react';

type LiquidityManagerProps = {
  poolAddress: string;
};

export function LiquidityManager({ poolAddress }: LiquidityManagerProps) {
  const [addAmountA, setAddAmountA] = useState<string>('');
  const [addAmountB, setAddAmountB] = useState<string>('');
  const [removePercent, setRemovePercent] = useState<string>('50');

  // Mock pool data
  const poolData = {
    tokenA: { symbol: 'ETH', amount: '10.5' },
    tokenB: { symbol: 'USDC', amount: '25000' },
    lpTokens: '162.45',
    poolShare: '2.5',
    valueUSD: '50000',
    feesEarnedUSD: '125.50',
  };

  const handleAddLiquidity = () => {
    console.log('Adding liquidity:', addAmountA, addAmountB);
  };

  const handleRemoveLiquidity = () => {
    console.log('Removing liquidity:', removePercent);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Manage Liquidity</CardTitle>
        <CardDescription>Add or remove liquidity from your position</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="add" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="add">Add Liquidity</TabsTrigger>
            <TabsTrigger value="remove">Remove Liquidity</TabsTrigger>
          </TabsList>

          <TabsContent value="add" className="space-y-4 mt-4">
            <div className="bg-slate-50 p-4 rounded-lg space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Current Position</span>
                <DollarSign className="h-4 w-4 text-slate-600" />
              </div>
              <div className="flex justify-between">
                <span className="text-sm">{poolData.tokenA.symbol}</span>
                <span className="font-medium">{poolData.tokenA.amount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">{poolData.tokenB.symbol}</span>
                <span className="font-medium">{poolData.tokenB.amount}</span>
              </div>
              <div className="flex justify-between pt-2 border-t">
                <span className="text-sm text-slate-600">Total Value</span>
                <span className="font-medium">${poolData.valueUSD}</span>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="addAmountA">{poolData.tokenA.symbol} Amount</Label>
                <Input
                  id="addAmountA"
                  type="number"
                  placeholder="0.0"
                  value={addAmountA}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAddAmountA(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="addAmountB">{poolData.tokenB.symbol} Amount</Label>
                <Input
                  id="addAmountB"
                  type="number"
                  placeholder="0.0"
                  value={addAmountB}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAddAmountB(e.target.value)}
                />
              </div>
            </div>

            <Alert>
              <TrendingUp className="h-4 w-4" />
              <AlertDescription>
                Adding liquidity will mint new LP tokens proportional to your deposit
              </AlertDescription>
            </Alert>

            <Button onClick={handleAddLiquidity} className="w-full">
              <Plus className="mr-2 h-4 w-4" />
              Add Liquidity
            </Button>
          </TabsContent>

          <TabsContent value="remove" className="space-y-4 mt-4">
            <div className="bg-slate-50 p-4 rounded-lg space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-slate-600">LP Tokens</span>
                <span className="font-medium">{poolData.lpTokens}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-slate-600">Pool Share</span>
                <span className="font-medium">{poolData.poolShare}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-slate-600">Fees Earned</span>
                <span className="font-medium text-green-600">+${poolData.feesEarnedUSD}</span>
              </div>
            </div>

            <div>
              <Label htmlFor="removePercent">Amount to Remove (%)</Label>
              <Input
                id="removePercent"
                type="number"
                min="1"
                max="100"
                value={removePercent}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setRemovePercent(e.target.value)}
              />
              <div className="flex gap-2 mt-2">
                {['25', '50', '75', '100'].map((percent: string) => (
                  <Button
                    key={percent}
                    variant="outline"
                    size="sm"
                    onClick={() => setRemovePercent(percent)}
                    className="flex-1"
                  >
                    {percent}%
                  </Button>
                ))}
              </div>
            </div>

            <div className="bg-slate-50 p-4 rounded-lg space-y-2">
              <div className="text-sm text-slate-600">You will receive:</div>
              <div className="flex justify-between">
                <span>{poolData.tokenA.symbol}</span>
                <span className="font-medium">
                  {(parseFloat(poolData.tokenA.amount) * parseFloat(removePercent) / 100).toFixed(4)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>{poolData.tokenB.symbol}</span>
                <span className="font-medium">
                  {(parseFloat(poolData.tokenB.amount) * parseFloat(removePercent) / 100).toFixed(2)}
                </span>
              </div>
            </div>

            {parseFloat(removePercent) === 100 && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  You are removing all liquidity from this pool
                </AlertDescription>
              </Alert>
            )}

            <Button onClick={handleRemoveLiquidity} variant="destructive" className="w-full">
              <Minus className="mr-2 h-4 w-4" />
              Remove Liquidity
            </Button>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
