'use client';

import { useState } from 'react';
import type { Token } from '@coinbase/onchainkit/token';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, CheckCircle2, Loader2 } from 'lucide-react';
import { TokenSelector } from './token-selector';

type PoolWizardProps = {
  onComplete: () => void;
};

export function PoolWizard({ onComplete }: PoolWizardProps) {
  const [step, setStep] = useState<number>(1);
  const [tokenA, setTokenA] = useState<Token | null>(null);
  const [tokenB, setTokenB] = useState<Token | null>(null);
  const [amountA, setAmountA] = useState<string>('');
  const [amountB, setAmountB] = useState<string>('');
  const [feeTier, setFeeTier] = useState<string>('0.3');
  const [slippage, setSlippage] = useState<string>('0.5');
  const [isCreating, setIsCreating] = useState<boolean>(false);

  const calculateInitialPrice = (): number => {
    if (!amountA || !amountB || parseFloat(amountA) === 0) return 0;
    return parseFloat(amountB) / parseFloat(amountA);
  };

  const calculatePriceImpact = (): number => {
    // Simplified price impact calculation
    const totalValue = parseFloat(amountA) + parseFloat(amountB);
    if (totalValue < 1000) return 5.0;
    if (totalValue < 10000) return 2.0;
    return 0.5;
  };

  const handleCreatePool = async () => {
    setIsCreating(true);
    // Simulate pool creation
    await new Promise((resolve) => setTimeout(resolve, 2000));
    setIsCreating(false);
    onComplete();
  };

  const canProceedStep1 = tokenA && tokenB && tokenA.address !== tokenB.address;
  const canProceedStep2 = amountA && amountB && parseFloat(amountA) > 0 && parseFloat(amountB) > 0;

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Create Liquidity Pool</CardTitle>
        <CardDescription>
          Step {step} of 3: {step === 1 ? 'Select Tokens' : step === 2 ? 'Set Initial Amounts' : 'Review & Confirm'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {step === 1 && (
          <>
            <div className="space-y-4">
              <div>
                <Label>Token A</Label>
                <TokenSelector
                  value={tokenA}
                  onChange={setTokenA}
                  disabled={false}
                />
              </div>
              <div>
                <Label>Token B</Label>
                <TokenSelector
                  value={tokenB}
                  onChange={setTokenB}
                  disabled={false}
                />
              </div>
            </div>

            {tokenA && tokenB && tokenA.address === tokenB.address && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  Please select two different tokens
                </AlertDescription>
              </Alert>
            )}

            <Button
              onClick={() => setStep(2)}
              disabled={!canProceedStep1}
              className="w-full"
            >
              Continue
            </Button>
          </>
        )}

        {step === 2 && (
          <>
            <div className="space-y-4">
              <div>
                <Label htmlFor="amountA">
                  {tokenA?.symbol || 'Token A'} Amount
                </Label>
                <Input
                  id="amountA"
                  type="number"
                  placeholder="0.0"
                  value={amountA}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAmountA(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="amountB">
                  {tokenB?.symbol || 'Token B'} Amount
                </Label>
                <Input
                  id="amountB"
                  type="number"
                  placeholder="0.0"
                  value={amountB}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAmountB(e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="feeTier">Fee Tier</Label>
                <Select value={feeTier} onValueChange={setFeeTier}>
                  <SelectTrigger id="feeTier">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0.01">0.01% - Stable pairs</SelectItem>
                    <SelectItem value="0.1">0.1% - Low volatility</SelectItem>
                    <SelectItem value="0.3">0.3% - Standard</SelectItem>
                    <SelectItem value="1.0">1.0% - High volatility</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="slippage">Slippage Tolerance (%)</Label>
                <Input
                  id="slippage"
                  type="number"
                  step="0.1"
                  value={slippage}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSlippage(e.target.value)}
                />
              </div>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setStep(1)} className="flex-1">
                Back
              </Button>
              <Button onClick={() => setStep(3)} disabled={!canProceedStep2} className="flex-1">
                Continue
              </Button>
            </div>
          </>
        )}

        {step === 3 && (
          <>
            <div className="space-y-4">
              <div className="bg-slate-50 p-4 rounded-lg space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">Pair</span>
                  <span className="font-medium">
                    {tokenA?.symbol}/{tokenB?.symbol}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">Initial Price</span>
                  <span className="font-medium">
                    1 {tokenA?.symbol} = {calculateInitialPrice().toFixed(6)} {tokenB?.symbol}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">Fee Tier</span>
                  <span className="font-medium">{feeTier}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">Your Pool Share</span>
                  <span className="font-medium">100%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">Price Impact</span>
                  <span className={`font-medium ${calculatePriceImpact() > 3 ? 'text-orange-600' : 'text-green-600'}`}>
                    ~{calculatePriceImpact().toFixed(2)}%
                  </span>
                </div>
              </div>

              {calculatePriceImpact() > 3 && (
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    High price impact detected. Consider adding more liquidity to reduce impact.
                  </AlertDescription>
                </Alert>
              )}

              {parseFloat(slippage) > 1 && (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    High slippage tolerance may result in unfavorable trades.
                  </AlertDescription>
                </Alert>
              )}
            </div>

            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setStep(2)} className="flex-1" disabled={isCreating}>
                Back
              </Button>
              <Button onClick={handleCreatePool} disabled={isCreating} className="flex-1">
                {isCreating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating Pool...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="mr-2 h-4 w-4" />
                    Create Pool
                  </>
                )}
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
