'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, DollarSign, Droplets, Percent } from 'lucide-react';

type Position = {
  id: string;
  tokenA: string;
  tokenB: string;
  liquidityUSD: string;
  poolShare: string;
  lpTokens: string;
  feeTier: string;
  pnl: number;
  feesEarned: string;
};

type PositionTrackerProps = {
  positions: Position[];
};

export function PositionTracker({ positions }: PositionTrackerProps) {
  const totalValue = positions.reduce((sum: number, p: Position) => sum + parseFloat(p.liquidityUSD), 0);
  const totalPnL = positions.reduce((sum: number, p: Position) => sum + p.pnl, 0);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Liquidity</CardDescription>
            <CardTitle className="text-2xl flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              ${totalValue.toFixed(2)}
            </CardTitle>
          </CardHeader>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total PnL</CardDescription>
            <CardTitle className={`text-2xl flex items-center gap-2 ${totalPnL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {totalPnL >= 0 ? <TrendingUp className="h-5 w-5" /> : <TrendingDown className="h-5 w-5" />}
              ${Math.abs(totalPnL).toFixed(2)}
            </CardTitle>
          </CardHeader>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Active Positions</CardDescription>
            <CardTitle className="text-2xl flex items-center gap-2">
              <Droplets className="h-5 w-5" />
              {positions.length}
            </CardTitle>
          </CardHeader>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Positions</CardTitle>
          <CardDescription>Track your liquidity positions across all pools</CardDescription>
        </CardHeader>
        <CardContent>
          {positions.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              No active positions. Create a pool to get started!
            </div>
          ) : (
            <div className="space-y-4">
              {positions.map((position: Position) => (
                <div key={position.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-lg">
                        {position.tokenA}/{position.tokenB}
                      </span>
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <Percent className="h-3 w-3" />
                        {position.feeTier}% fee
                      </Badge>
                    </div>
                    <div className={`flex items-center gap-1 ${position.pnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {position.pnl >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                      <span className="font-medium">
                        {position.pnl >= 0 ? '+' : ''}{position.pnl.toFixed(2)}%
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <div className="text-slate-600">Liquidity</div>
                      <div className="font-medium">${position.liquidityUSD}</div>
                    </div>
                    <div>
                      <div className="text-slate-600">Pool Share</div>
                      <div className="font-medium">{position.poolShare}%</div>
                    </div>
                    <div>
                      <div className="text-slate-600">LP Tokens</div>
                      <div className="font-medium">{position.lpTokens}</div>
                    </div>
                    <div>
                      <div className="text-slate-600">Fees Earned</div>
                      <div className="font-medium text-green-600">${position.feesEarned}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
