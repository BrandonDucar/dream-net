'use client';

import { useState, useEffect } from 'react';
import type { Token } from '@coinbase/onchainkit/token';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Search, ChevronDown } from 'lucide-react';
import { getTokens, unwrapOnchainKitResponse } from '@/app/types/api';

type TokenSelectorProps = {
  value: Token | null;
  onChange: (token: Token) => void;
  disabled: boolean;
};

// Common Base tokens
const COMMON_TOKENS: Token[] = [
  {
    name: 'Ethereum',
    address: '0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE',
    symbol: 'ETH',
    decimals: 18,
    image: 'https://ethereum-optimism.github.io/data/ETH/logo.svg',
    chainId: 8453,
  },
  {
    name: 'USD Coin',
    address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
    symbol: 'USDC',
    decimals: 6,
    image: 'https://ethereum-optimism.github.io/data/USDC/logo.png',
    chainId: 8453,
  },
  {
    name: 'Dai Stablecoin',
    address: '0x50c5725949A6F0c72E6C4a641F24049A917DB0Cb',
    symbol: 'DAI',
    decimals: 18,
    image: 'https://ethereum-optimism.github.io/data/DAI/logo.svg',
    chainId: 8453,
  },
];

export function TokenSelector({ value, onChange, disabled }: TokenSelectorProps) {
  const [open, setOpen] = useState<boolean>(false);
  const [search, setSearch] = useState<string>('');
  const [tokens, setTokens] = useState<Token[]>(COMMON_TOKENS);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    if (search.length > 2) {
      searchTokens(search);
    } else {
      setTokens(COMMON_TOKENS);
    }
  }, [search]);

  const searchTokens = async (query: string) => {
    try {
      setLoading(true);
      const response = await getTokens({ search: query, limit: '10' });
      const searchResults = unwrapOnchainKitResponse(response);
      setTokens(searchResults);
    } catch (error) {
      console.error('Token search error:', error);
      setTokens(COMMON_TOKENS);
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = (token: Token) => {
    onChange(token);
    setOpen(false);
    setSearch('');
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          className="w-full justify-between"
          disabled={disabled}
        >
          {value ? (
            <div className="flex items-center gap-2">
              {value.image && (
                <img src={value.image} alt={value.symbol} className="w-5 h-5 rounded-full" />
              )}
              <span>{value.symbol}</span>
            </div>
          ) : (
            <span>Select token</span>
          )}
          <ChevronDown className="h-4 w-4 opacity-50" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Select a token</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Search by name or address..."
              value={search}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <div className="max-h-[400px] overflow-y-auto space-y-1">
            {loading ? (
              <div className="text-center py-8 text-slate-500">Searching...</div>
            ) : tokens.length === 0 ? (
              <div className="text-center py-8 text-slate-500">No tokens found</div>
            ) : (
              tokens.map((token: Token) => (
                <button
                  key={token.address}
                  onClick={() => handleSelect(token)}
                  className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 rounded-lg transition-colors"
                >
                  {token.image && (
                    <img src={token.image} alt={token.symbol} className="w-8 h-8 rounded-full" />
                  )}
                  <div className="flex-1 text-left">
                    <div className="font-medium">{token.symbol}</div>
                    <div className="text-sm text-slate-500">{token.name}</div>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
