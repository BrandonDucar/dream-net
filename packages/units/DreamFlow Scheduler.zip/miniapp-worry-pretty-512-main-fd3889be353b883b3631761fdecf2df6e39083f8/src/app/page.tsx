'use client'
import { useState, useEffect } from 'react'
import type { DayType, Task, TimeWindow, EnergyLevel, ScheduleBlock } from '@/types/scheduler'
import { StepOne } from '@/components/StepOne'
import { StepTwo } from '@/components/StepTwo'
import { StepThree } from '@/components/StepThree'
import { ScheduleView } from '@/components/ScheduleView'
import { generateSchedule } from '@/lib/scheduleGenerator'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DreamFlowScheduler(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [step, setStep] = useState<number>(1)
  const [dayType, setDayType] = useState<DayType | null>(null)
  const [tasks, setTasks] = useState<Task[]>([])
  const [schedule, setSchedule] = useState<ScheduleBlock[] | null>(null)

  const handleDayTypeSelect = (type: DayType): void => {
    setDayType(type)
    setStep(2)
  }

  const handleTasksSubmit = (submittedTasks: Task[]): void => {
    setTasks(submittedTasks)
    setStep(3)
  }

  const handleTaskDetailsSubmit = (detailedTasks: Task[]): void => {
    setTasks(detailedTasks)
    const generatedSchedule = generateSchedule(detailedTasks, dayType!)
    setSchedule(generatedSchedule)
    setStep(4)
  }

  const handleTryDifferentFlow = (): void => {
    const newSchedule = generateSchedule(tasks, dayType!, true)
    setSchedule(newSchedule)
  }

  const handleStartOver = (): void => {
    setStep(1)
    setDayType(null)
    setTasks([])
    setSchedule(null)
  }

  return (
    <div className="min-h-screen bg-white text-black">
      {/* Header */}
      <header className="border-b border-gray-200 bg-white">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">
                DreamFlow Scheduler — <span className="text-purple-600">$FLOW</span>
              </h1>
              <p className="text-sm text-gray-600 mt-1">
                Build your perfect daily flow
              </p>
            </div>
            {step > 1 && (
              <button
                onClick={handleStartOver}
                className="text-sm text-gray-600 hover:text-black transition-colors"
              >
                Start Over
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-12">
        {/* Progress Indicator */}
        <div className="mb-12">
          <div className="flex items-center justify-center space-x-2">
            {[1, 2, 3, 4].map((num: number) => (
              <div key={num} className="flex items-center">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all duration-300 ${
                    step >= num
                      ? 'bg-gradient-to-br from-purple-500 to-blue-500 text-white shadow-lg shadow-purple-500/30'
                      : 'bg-gray-200 text-gray-500'
                  }`}
                >
                  {num}
                </div>
                {num < 4 && (
                  <div
                    className={`w-12 h-0.5 transition-all duration-300 ${
                      step > num ? 'bg-gradient-to-r from-purple-500 to-blue-500' : 'bg-gray-200'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="text-center mt-4 text-sm text-gray-600">
            {step === 1 && 'Choose Your Day'}
            {step === 2 && 'Add Your Tasks'}
            {step === 3 && 'Set Preferences'}
            {step === 4 && 'Your Perfect Flow'}
          </div>
        </div>

        {/* Step Content */}
        {step === 1 && <StepOne onSelect={handleDayTypeSelect} />}
        {step === 2 && <StepTwo onSubmit={handleTasksSubmit} />}
        {step === 3 && (
          <StepThree
            tasks={tasks}
            onSubmit={handleTaskDetailsSubmit}
            onBack={(): void => setStep(2)}
          />
        )}
        {step === 4 && schedule && (
          <ScheduleView
            schedule={schedule}
            dayType={dayType!}
            tasks={tasks}
            onTryDifferentFlow={handleTryDifferentFlow}
            onStartOver={handleStartOver}
          />
        )}
      </main>
    </div>
  )
}
