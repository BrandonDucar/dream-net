'use client'

import type { DayType, Task, ScheduleBlock } from '@/types/scheduler'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { Clock, Zap, RefreshCw, Sparkles } from 'lucide-react'

interface ScheduleViewProps {
  schedule: ScheduleBlock[]
  dayType: DayType
  tasks: Task[]
  onTryDifferentFlow: () => void
  onStartOver: () => void
}

const blockColors: Record<string, { bg: string; border: string; icon: JSX.Element }> = {
  'Focus Block': {
    bg: 'bg-purple-50',
    border: 'border-purple-400',
    icon: <Zap className="w-4 h-4 text-purple-600" />
  },
  'Reset Block': {
    bg: 'bg-blue-50',
    border: 'border-blue-400',
    icon: <RefreshCw className="w-4 h-4 text-blue-600" />
  },
  'Momentum Block': {
    bg: 'bg-pink-50',
    border: 'border-pink-400',
    icon: <Sparkles className="w-4 h-4 text-pink-600" />
  },
  'Recharge Block': {
    bg: 'bg-green-50',
    border: 'border-green-400',
    icon: <Clock className="w-4 h-4 text-green-600" />
  }
}

const motivationalMessages: string[] = [
  "You've got this! One task at a time.",
  "This flow is designed around your personal rhythm.",
  "Trust the process. Your day is perfectly balanced.",
  "Small wins build momentum. Let's make today count.",
  "Smart timing unlocks your best work."
]

const improvements: Record<DayType, string[]> = {
  productive: [
    'Consider adding 10-minute breaks between high-energy tasks',
    'Front-load your most important work in the morning',
    'Reserve afternoons for collaborative work'
  ],
  relaxed: [
    'Perfect! You have breathing room throughout the day',
    'Enjoy the flexibility to adjust as needed',
    'Use extra time for spontaneous activities'
  ],
  creative: [
    'Great flow for inspiration and exploration',
    'Your schedule allows for creative detours',
    'Mix focused work with free-form thinking time'
  ],
  balanced: [
    'Nice balance between work, rest, and personal time',
    'This structure supports sustainable productivity',
    'You have flexibility where you need it most'
  ],
  'family-focused': [
    'Quality time is built into your day',
    'Your schedule protects what matters most',
    'Balance between commitments and presence'
  ],
  'health-focused': [
    'Movement and wellness are priorities today',
    'Your body and mind will thank you',
    'Sustainable energy throughout the day'
  ]
}

export function ScheduleView({
  schedule,
  dayType,
  tasks,
  onTryDifferentFlow,
  onStartOver
}: ScheduleViewProps): JSX.Element {
  const totalTime: number = tasks.reduce((sum: number, task: Task) => sum + (task.estimatedTime || 0), 0)
  const randomMotivation: string =
    motivationalMessages[Math.floor(Math.random() * motivationalMessages.length)]

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 text-white mb-4 shadow-lg shadow-purple-500/30">
          <Sparkles className="w-8 h-8" />
        </div>
        <h2 className="text-3xl font-bold mb-2">Your Perfect Flow</h2>
        <p className="text-gray-600">{randomMotivation}</p>
      </div>

      {/* Daily Summary */}
      <Card className="p-6 border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-blue-50">
        <h3 className="font-semibold mb-4 flex items-center gap-2">
          <Clock className="w-5 h-5 text-purple-600" />
          Daily Summary
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div>
            <div className="text-2xl font-bold text-purple-600">{tasks.length}</div>
            <div className="text-xs text-gray-600">Tasks</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-purple-600">
              {Math.floor(totalTime / 60)}h {totalTime % 60}m
            </div>
            <div className="text-xs text-gray-600">Total Time</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-purple-600">{schedule.length}</div>
            <div className="text-xs text-gray-600">Time Blocks</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-purple-600 capitalize">{dayType}</div>
            <div className="text-xs text-gray-600">Day Type</div>
          </div>
        </div>
      </Card>

      {/* Schedule Blocks */}
      <div className="space-y-4">
        {schedule.map((block: ScheduleBlock, index: number) => {
          const blockStyle = blockColors[block.type]
          return (
            <Card
              key={block.id}
              className={`p-6 border-2 ${blockStyle.border} ${blockStyle.bg} transition-all duration-300 hover:shadow-lg`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  {blockStyle.icon}
                  <div>
                    <Badge variant="outline" className="mb-1">
                      {block.type}
                    </Badge>
                    <div className="text-sm font-medium text-gray-600">
                      {block.startTime} - {block.endTime}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-gray-500">Block {index + 1}</div>
                </div>
              </div>

              <p className="text-sm text-gray-600 mb-3 italic">{block.description}</p>

              {block.tasks.length > 0 && (
                <div className="space-y-2">
                  <Separator />
                  <div className="pt-2">
                    {block.tasks.map((task: Task) => (
                      <div
                        key={task.id}
                        className="flex items-center justify-between py-2 text-sm"
                      >
                        <span className="font-medium">{task.name}</span>
                        <span className="text-gray-500">{task.estimatedTime} min</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </Card>
          )
        })}
      </div>

      {/* Suggestions */}
      <Card className="p-6 border-2 border-gray-200">
        <h3 className="font-semibold mb-3 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-600" />
          Suggested Improvements
        </h3>
        <ul className="space-y-2">
          {improvements[dayType].map((improvement: string, index: number) => (
            <li key={index} className="text-sm text-gray-600 flex items-start gap-2">
              <span className="text-purple-500 mt-0.5">•</span>
              <span>{improvement}</span>
            </li>
          ))}
        </ul>
      </Card>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-3 justify-center">
        <Button
          onClick={onTryDifferentFlow}
          variant="outline"
          className="flex items-center gap-2"
        >
          <RefreshCw className="w-4 h-4" />
          Try a Different Flow
        </Button>
        <Button onClick={onStartOver} variant="outline">
          Start Fresh
        </Button>
      </div>
    </div>
  )
}
