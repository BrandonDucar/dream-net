'use client'

import type { DayType, DayTypeOption } from '@/types/scheduler'
import { Card } from '@/components/ui/card'

interface StepOneProps {
  onSelect: (type: DayType) => void
}

const dayTypeOptions: DayTypeOption[] = [
  {
    type: 'productive',
    title: 'Productive',
    description: 'Maximum output and deep focus time',
    icon: '⚡'
  },
  {
    type: 'relaxed',
    title: 'Relaxed',
    description: 'Easy pace with plenty of breathing room',
    icon: '☁️'
  },
  {
    type: 'creative',
    title: 'Creative',
    description: 'Space for exploration and inspiration',
    icon: '🎨'
  },
  {
    type: 'balanced',
    title: 'Balanced',
    description: 'Mix of work, rest, and personal time',
    icon: '⚖️'
  },
  {
    type: 'family-focused',
    title: 'Family-Focused',
    description: 'Prioritize quality time with loved ones',
    icon: '❤️'
  },
  {
    type: 'health-focused',
    title: 'Health-Focused',
    description: 'Movement, nutrition, and wellness first',
    icon: '💪'
  }
]

export function StepOne({ onSelect }: StepOneProps): JSX.Element {
  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold mb-2">What kind of day do you want?</h2>
        <p className="text-gray-600">Choose the vibe that fits your goals today</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {dayTypeOptions.map((option: DayTypeOption) => (
          <Card
            key={option.type}
            className="p-6 cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-xl border-2 border-gray-200 hover:border-purple-400 bg-white group"
            onClick={(): void => onSelect(option.type)}
          >
            <div className="flex items-start space-x-4">
              <div className="text-4xl group-hover:scale-110 transition-transform duration-300">
                {option.icon}
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold mb-1 group-hover:text-purple-600 transition-colors">
                  {option.title}
                </h3>
                <p className="text-sm text-gray-600">{option.description}</p>
              </div>
            </div>
            <div className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="h-1 w-full bg-gradient-to-r from-purple-500 to-blue-500 rounded-full" />
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
