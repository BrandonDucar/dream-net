'use client'

import { useState } from 'react'
import type { Task, TimeWindow, EnergyLevel } from '@/types/scheduler'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'

interface StepThreeProps {
  tasks: Task[]
  onSubmit: (tasks: Task[]) => void
  onBack: () => void
}

export function StepThree({ tasks, onSubmit, onBack }: StepThreeProps): JSX.Element {
  const [detailedTasks, setDetailedTasks] = useState<Task[]>(
    tasks.map((task: Task) => ({
      ...task,
      estimatedTime: 30,
      preferredWindow: 'flexible' as TimeWindow,
      energyLevel: 'medium' as EnergyLevel
    }))
  )

  const updateTask = (id: string, field: keyof Task, value: number | TimeWindow | EnergyLevel): void => {
    setDetailedTasks(
      detailedTasks.map((task: Task) =>
        task.id === id ? { ...task, [field]: value } : task
      )
    )
  }

  const handleSubmit = (): void => {
    onSubmit(detailedTasks)
  }

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold mb-2">Add some details</h2>
        <p className="text-gray-600">Help us find the best timing for each task</p>
      </div>

      <div className="space-y-4">
        {detailedTasks.map((task: Task) => (
          <Card key={task.id} className="p-6 border-2 border-gray-200 hover:border-purple-300 transition-colors">
            <h3 className="font-semibold mb-4 text-lg">{task.name}</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Estimated Time */}
              <div className="space-y-2">
                <Label className="text-xs text-gray-600">Estimated Time</Label>
                <Select
                  value={String(task.estimatedTime)}
                  onValueChange={(value: string): void =>
                    updateTask(task.id, 'estimatedTime', Number(value))
                  }
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 min</SelectItem>
                    <SelectItem value="30">30 min</SelectItem>
                    <SelectItem value="45">45 min</SelectItem>
                    <SelectItem value="60">1 hour</SelectItem>
                    <SelectItem value="90">1.5 hours</SelectItem>
                    <SelectItem value="120">2 hours</SelectItem>
                    <SelectItem value="180">3 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Preferred Window */}
              <div className="space-y-2">
                <Label className="text-xs text-gray-600">Preferred Time</Label>
                <Select
                  value={task.preferredWindow}
                  onValueChange={(value: TimeWindow): void =>
                    updateTask(task.id, 'preferredWindow', value)
                  }
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="morning">Morning</SelectItem>
                    <SelectItem value="afternoon">Afternoon</SelectItem>
                    <SelectItem value="evening">Evening</SelectItem>
                    <SelectItem value="flexible">Flexible</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Energy Level */}
              <div className="space-y-2">
                <Label className="text-xs text-gray-600">Energy Required</Label>
                <Select
                  value={task.energyLevel}
                  onValueChange={(value: EnergyLevel): void =>
                    updateTask(task.id, 'energyLevel', value)
                  }
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Navigation Buttons */}
      <div className="flex justify-between pt-6">
        <Button onClick={onBack} variant="outline">
          ← Back
        </Button>
        <Button
          onClick={handleSubmit}
          className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white shadow-lg shadow-purple-500/30 px-8"
        >
          Generate My Schedule →
        </Button>
      </div>
    </div>
  )
}
