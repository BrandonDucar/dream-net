'use client'

import { useState } from 'react'
import type { Task } from '@/types/scheduler'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { X } from 'lucide-react'

interface StepTwoProps {
  onSubmit: (tasks: Task[]) => void
}

const suggestedTasks: string[] = [
  'Morning workout',
  'Team meeting',
  'Focus work session',
  'Lunch break',
  'Email responses',
  'Creative brainstorming',
  'Project review',
  'Learning time',
  'Call with client',
  'Evening walk'
]

export function StepTwo({ onSubmit }: StepTwoProps): JSX.Element {
  const [tasks, setTasks] = useState<Task[]>([])
  const [newTaskName, setNewTaskName] = useState<string>('')

  const addTask = (name: string): void => {
    if (name.trim()) {
      const newTask: Task = {
        id: crypto.randomUUID(),
        name: name.trim()
      }
      setTasks([...tasks, newTask])
      setNewTaskName('')
    }
  }

  const removeTask = (id: string): void => {
    setTasks(tasks.filter((task: Task) => task.id !== id))
  }

  const handleSubmit = (): void => {
    if (tasks.length > 0) {
      onSubmit(tasks)
    }
  }

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold mb-2">What's on your plate today?</h2>
        <p className="text-gray-600">Add tasks you want to accomplish</p>
      </div>

      <Card className="p-6 border-2 border-gray-200">
        <div className="space-y-4">
          <div className="flex gap-2">
            <Input
              type="text"
              placeholder="Type a task..."
              value={newTaskName}
              onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                setNewTaskName(e.target.value)
              }
              onKeyPress={(e: React.KeyboardEvent<HTMLInputElement>): void => {
                if (e.key === 'Enter') {
                  addTask(newTaskName)
                }
              }}
              className="flex-1"
            />
            <Button
              onClick={(): void => addTask(newTaskName)}
              disabled={!newTaskName.trim()}
              className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white"
            >
              Add
            </Button>
          </div>

          {/* Suggested Tasks */}
          <div>
            <p className="text-xs text-gray-500 mb-2">Or pick from suggestions:</p>
            <div className="flex flex-wrap gap-2">
              {suggestedTasks.map((suggestion: string) => (
                <button
                  key={suggestion}
                  onClick={(): void => addTask(suggestion)}
                  className="text-xs px-3 py-1.5 rounded-full bg-gray-100 hover:bg-purple-100 hover:text-purple-700 transition-colors border border-gray-200"
                >
                  + {suggestion}
                </button>
              ))}
            </div>
          </div>
        </div>
      </Card>

      {/* Task List */}
      {tasks.length > 0 && (
        <Card className="p-6 border-2 border-gray-200">
          <h3 className="text-lg font-semibold mb-4">Your Tasks ({tasks.length})</h3>
          <div className="space-y-2">
            {tasks.map((task: Task) => (
              <div
                key={task.id}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-lg group hover:bg-purple-50 transition-colors"
              >
                <span className="text-sm">{task.name}</span>
                <button
                  onClick={(): void => removeTask(task.id)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity text-gray-400 hover:text-red-500"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Continue Button */}
      {tasks.length > 0 && (
        <div className="flex justify-center">
          <Button
            onClick={handleSubmit}
            size="lg"
            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white shadow-lg shadow-purple-500/30 px-8"
          >
            Continue to Details →
          </Button>
        </div>
      )}
    </div>
  )
}
