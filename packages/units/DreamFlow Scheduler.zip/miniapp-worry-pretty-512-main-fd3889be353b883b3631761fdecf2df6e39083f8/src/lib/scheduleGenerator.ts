import type { Task, ScheduleBlock, BlockType, DayType } from '@/types/scheduler'

const timeWindows = {
  morning: { start: 7, end: 12 },
  afternoon: { start: 12, end: 17 },
  evening: { start: 17, end: 21 }
}

function formatTime(hour: number, minute: number): string {
  const period = hour >= 12 ? 'PM' : 'AM'
  const displayHour = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour
  return `${displayHour}:${minute.toString().padStart(2, '0')} ${period}`
}

function determineBlockType(
  tasks: Task[],
  isBreak: boolean,
  position: number,
  totalBlocks: number
): BlockType {
  if (isBreak) {
    return position < totalBlocks / 2 ? 'Reset Block' : 'Recharge Block'
  }

  const avgEnergy = tasks.reduce((sum: number, task: Task) => {
    const energyValue: Record<string, number> = { low: 1, medium: 2, high: 3 }
    return sum + (energyValue[task.energyLevel || 'medium'] || 2)
  }, 0) / tasks.length

  if (avgEnergy >= 2.5) {
    return 'Focus Block'
  } else if (avgEnergy >= 1.5) {
    return 'Momentum Block'
  } else {
    return 'Recharge Block'
  }
}

function getBlockDescription(type: BlockType, tasks: Task[], dayType: DayType): string {
  const descriptions: Record<BlockType, Record<DayType, string[]>> = {
    'Focus Block': {
      productive: [
        'Deep work time. Eliminate distractions and tackle your most demanding tasks.',
        'Peak performance zone. Your energy is high—make every minute count.',
        'Power hour. Focus on high-impact work that moves the needle.'
      ],
      relaxed: [
        'Gentle focus time. Work at your own comfortable pace.',
        'Mindful productivity. Stay present with what you are doing.'
      ],
      creative: [
        'Creative flow state. Let your imagination guide you.',
        'Innovation zone. Explore ideas without rushing.'
      ],
      balanced: [
        'Focused work session. Balance effort with sustainability.',
        'Productive momentum. Steady progress on your priorities.'
      ],
      'family-focused': [
        'Quality focus time. Complete tasks so you can be fully present later.',
        'Efficient work block. Finish strong so you can transition to family time.'
      ],
      'health-focused': [
        'Energized work session. Your movement earlier pays off now.',
        'Mindful productivity. Work with awareness of your body and energy.'
      ]
    },
    'Reset Block': {
      productive: [
        'Quick recharge. Step away briefly to maintain peak performance.',
        'Mental reset. A short break now means stronger focus ahead.'
      ],
      relaxed: [
        'Pause and breathe. Enjoy this moment of calm.',
        'Gentle transition. Move into the next part of your day with ease.'
      ],
      creative: [
        'Inspiration break. Let ideas percolate while you rest.',
        'Creative pause. Sometimes the best ideas come when you step back.'
      ],
      balanced: [
        'Balance check. Take a moment to recenter.',
        'Mindful break. Reset your energy for what is ahead.'
      ],
      'family-focused': [
        'Connection moment. Quick check-in with loved ones or yourself.',
        'Transitional pause. Prepare to shift your attention.'
      ],
      'health-focused': [
        'Movement break. Stretch, walk, or hydrate.',
        'Wellness pause. Honor your body need for rest.'
      ]
    },
    'Momentum Block': {
      productive: [
        'Build on your progress. Keep the productive rhythm going.',
        'Steady advancement. Maintain momentum across multiple tasks.'
      ],
      relaxed: [
        'Easy flow. Move through tasks without pressure.',
        'Comfortable pace. Progress feels natural and effortless.'
      ],
      creative: [
        'Creative momentum. Ideas are flowing—capture them.',
        'Inspired action. Transform thoughts into tangible results.'
      ],
      balanced: [
        'Sustainable rhythm. Work that feels both productive and pleasant.',
        'Balanced progress. Accomplish goals without burning out.'
      ],
      'family-focused': [
        'Efficient completion. Wrap up tasks to free your evening.',
        'Transition momentum. Finishing strong so you can shift gears.'
      ],
      'health-focused': [
        'Active engagement. Your wellness choices support your productivity.',
        'Energetic flow. Movement and work complement each other.'
      ]
    },
    'Recharge Block': {
      productive: [
        'Strategic rest. Recharge now for sustained performance.',
        'Energy renewal. Smart breaks fuel better work.'
      ],
      relaxed: [
        'Pure relaxation. Enjoy downtime without guilt.',
        'Complete rest. This is time for you.'
      ],
      creative: [
        'Inspiration time. Feed your creative spirit.',
        'Open exploration. No pressure, just possibilities.'
      ],
      balanced: [
        'Restoration period. Balance activity with genuine rest.',
        'Renewal time. Recharge your batteries fully.'
      ],
      'family-focused': [
        'Together time. Be fully present with your loved ones.',
        'Quality connection. This is what the day was planned for.'
      ],
      'health-focused': [
        'Full recovery. Rest, stretch, or nourish yourself.',
        'Wellness focus. Movement, meditation, or healthy meals.'
      ]
    }
  }

  const options = descriptions[type][dayType]
  return options[Math.floor(Math.random() * options.length)]
}

export function generateSchedule(tasks: Task[], dayType: DayType, alternative: boolean = false): ScheduleBlock[] {
  const schedule: ScheduleBlock[] = []
  let currentHour = 7
  let currentMinute = 0

  // Sort tasks by preferred window and energy level
  const sortedTasks = [...tasks].sort((a: Task, b: Task) => {
    // Window priority
    const windowPriority: Record<string, number> = {
      morning: 1,
      afternoon: 2,
      evening: 3,
      flexible: alternative ? Math.random() * 4 : 2
    }

    const aPriority = windowPriority[a.preferredWindow || 'flexible']
    const bPriority = windowPriority[b.preferredWindow || 'flexible']

    if (aPriority !== bPriority) {
      return aPriority - bPriority
    }

    // Energy priority (high energy tasks first in morning, low energy later)
    const energyValue: Record<string, number> = { low: 1, medium: 2, high: 3 }
    const aEnergy = energyValue[a.energyLevel || 'medium']
    const bEnergy = energyValue[b.energyLevel || 'medium']

    return alternative ? aEnergy - bEnergy : bEnergy - aEnergy
  })

  // Group tasks into blocks with breaks
  let currentBlockTasks: Task[] = []
  let blockTime = 0
  const maxBlockTime = dayType === 'relaxed' ? 60 : dayType === 'productive' ? 120 : 90

  sortedTasks.forEach((task: Task, index: number) => {
    const taskTime = task.estimatedTime || 30

    if (blockTime + taskTime > maxBlockTime && currentBlockTasks.length > 0) {
      // Create block
      const startTime = formatTime(currentHour, currentMinute)
      currentMinute += blockTime
      while (currentMinute >= 60) {
        currentHour += 1
        currentMinute -= 60
      }
      const endTime = formatTime(currentHour, currentMinute)

      const blockType = determineBlockType(
        currentBlockTasks,
        false,
        schedule.length,
        sortedTasks.length
      )

      schedule.push({
        id: crypto.randomUUID(),
        type: blockType,
        startTime,
        endTime,
        tasks: currentBlockTasks,
        description: getBlockDescription(blockType, currentBlockTasks, dayType)
      })

      // Add break
      const breakDuration = dayType === 'relaxed' ? 20 : dayType === 'productive' ? 10 : 15
      const breakStartTime = formatTime(currentHour, currentMinute)
      currentMinute += breakDuration
      while (currentMinute >= 60) {
        currentHour += 1
        currentMinute -= 60
      }
      const breakEndTime = formatTime(currentHour, currentMinute)

      const breakType = determineBlockType([], true, schedule.length, sortedTasks.length)

      schedule.push({
        id: crypto.randomUUID(),
        type: breakType,
        startTime: breakStartTime,
        endTime: breakEndTime,
        tasks: [],
        description: getBlockDescription(breakType, [], dayType)
      })

      currentBlockTasks = []
      blockTime = 0
    }

    currentBlockTasks.push(task)
    blockTime += taskTime
  })

  // Add final block
  if (currentBlockTasks.length > 0) {
    const startTime = formatTime(currentHour, currentMinute)
    currentMinute += blockTime
    while (currentMinute >= 60) {
      currentHour += 1
      currentMinute -= 60
    }
    const endTime = formatTime(currentHour, currentMinute)

    const blockType = determineBlockType(
      currentBlockTasks,
      false,
      schedule.length,
      sortedTasks.length
    )

    schedule.push({
      id: crypto.randomUUID(),
      type: blockType,
      startTime,
      endTime,
      tasks: currentBlockTasks,
      description: getBlockDescription(blockType, currentBlockTasks, dayType)
    })
  }

  return schedule
}
