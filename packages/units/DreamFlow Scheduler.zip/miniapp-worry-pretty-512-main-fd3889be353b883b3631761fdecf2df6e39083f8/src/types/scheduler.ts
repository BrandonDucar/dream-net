export type DayType = 'productive' | 'relaxed' | 'creative' | 'balanced' | 'family-focused' | 'health-focused'

export type TimeWindow = 'morning' | 'afternoon' | 'evening' | 'flexible'

export type EnergyLevel = 'low' | 'medium' | 'high'

export type BlockType = 'Focus Block' | 'Reset Block' | 'Momentum Block' | 'Recharge Block'

export interface Task {
  id: string
  name: string
  estimatedTime?: number
  preferredWindow?: TimeWindow
  energyLevel?: EnergyLevel
}

export interface ScheduleBlock {
  id: string
  type: BlockType
  startTime: string
  endTime: string
  tasks: Task[]
  description: string
}

export interface DayTypeOption {
  type: DayType
  title: string
  description: string
  icon: string
}
