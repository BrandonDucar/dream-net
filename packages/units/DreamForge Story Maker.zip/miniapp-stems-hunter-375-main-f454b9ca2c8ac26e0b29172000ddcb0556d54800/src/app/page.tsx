'use client'
import { useState, useEffect } from 'react';
import { StoryForm } from '@/components/story-form';
import { StoryDisplay } from '@/components/story-display';
import type { StoryFormData, GeneratedStory } from '@/types/story';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function HomePage(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [generatedStory, setGeneratedStory] = useState<GeneratedStory | null>(null);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [currentFormData, setCurrentFormData] = useState<StoryFormData | null>(null);

  const generateStory = async (formData: StoryFormData): Promise<void> => {
    setIsGenerating(true);
    setCurrentFormData(formData);

    try {
      const wordCounts: Record<string, number> = {
        short: 400,
        medium: 700,
        long: 1000,
      };

      const sidekickText: string = formData.sidekick ? ` and their sidekick ${formData.sidekick}` : '';

      const prompt: string = `You are a master children's story writer. Create a complete, engaging children's story with the following details:

Main Character: ${formData.characterName}, a ${formData.characterVibe} ${formData.characterType}${sidekickText}
Setting: ${formData.setting}
Theme: ${formData.theme}
Length: ${formData.storyLength} (approximately ${wordCounts[formData.storyLength]} words)

The story MUST include:
1. An engaging opening that captures attention
2. A clear, child-friendly plot
3. A gentle conflict appropriate for children
4. A fun, unexpected twist
5. An emotional moment that teaches empathy
6. A positive life lesson related to ${formData.theme}
7. A warm, satisfying ending

Write in a warm, friendly tone suitable for children aged 4-10. Use simple language, vivid imagery, and include moments for parent-child interaction.

Format the story as a complete narrative, with proper paragraphs. Do not include any meta-commentary or section labels.`;

      const response = await fetch('/api/proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          protocol: 'https',
          origin: 'api.openai.com',
          path: '/v1/chat/completions',
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer sk-proj-GyQK9uPv-QqYEsQcf7TN7FcD1EiG7t2uqBcJ7Nz13_P-tD0pYNYL3WqJuvxUKUJQ5UmvHOtqBmT3BlbkFJGvuOvQ1_gZU4MnY1JvbJM4lOdXvXp_w6y5S1SaJJhRZKkL6_aW1nZH7_vRXTWn0vWXF-9rZAA',
          },
          body: JSON.stringify({
            model: 'gpt-4o',
            messages: [
              {
                role: 'system',
                content:
                  'You are an expert children\'s story writer who creates magical, engaging stories with positive lessons.',
              },
              { role: 'user', content: prompt },
            ],
            temperature: 0.9,
            max_tokens: 2000,
          }),
        }),
      });

      const data = await response.json();
      const storyText: string = data.choices[0].message.content;

      const illustrationsPrompt: string = `Based on this children's story, suggest exactly 5 vivid, detailed illustration ideas that would bring the story to life. Each suggestion should describe a key moment, scene, or character interaction.

Story: ${storyText.substring(0, 500)}...

Provide 5 numbered illustration suggestions (1-5), each on a new line, describing what should be illustrated.`;

      const illustrationsResponse = await fetch('/api/proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          protocol: 'https',
          origin: 'api.openai.com',
          path: '/v1/chat/completions',
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer sk-proj-GyQK9uPv-QqYEsQcf7TN7FcD1EiG7t2uqBcJ7Nz13_P-tD0pYNYL3WqJuvxUKUJQ5UmvHOtqBmT3BlbkFJGvuOvQ1_gZU4MnY1JvbJM4lOdXvXp_w6y5S1SaJJhRZKkL6_aW1nZH7_vRXTWn0vWXF-9rZAA',
          },
          body: JSON.stringify({
            model: 'gpt-4o',
            messages: [{ role: 'user', content: illustrationsPrompt }],
            temperature: 0.8,
            max_tokens: 500,
          }),
        }),
      });

      const illustrationsData = await illustrationsResponse.json();
      const illustrationsText: string = illustrationsData.choices[0].message.content;
      const illustrations: string[] = illustrationsText
        .split('\n')
        .filter((line: string) => line.trim() && /^\d+[.)]/.test(line.trim()))
        .map((line: string) => line.replace(/^\d+[.)]\s*/, '').trim())
        .slice(0, 5);

      const extrasPrompt: string = `For this children's story, provide:

1. BEDTIME VERSION: Rewrite a brief, calming 2-3 sentence version perfect for bedtime (softer tone, slower pace, peaceful ending)
2. ADVENTURE VERSION: Rewrite a brief, exciting 2-3 sentence version with more action and energy
3. MORAL LESSON: One clear sentence about the main lesson (related to ${formData.theme})
4. CHARACTER TRAITS: List 5 key personality traits of ${formData.characterName}
5. READ ALOUD CUES: Provide 3-4 parent reading cues with [brackets] showing where to pause, ask questions, or add sound effects

Story excerpt: ${storyText.substring(0, 400)}...

Format your response EXACTLY like this:
BEDTIME: [bedtime version]
ADVENTURE: [adventure version]
MORAL: [moral lesson]
TRAITS: [trait1, trait2, trait3, trait4, trait5]
CUES: [reading cues with examples]`;

      const extrasResponse = await fetch('/api/proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          protocol: 'https',
          origin: 'api.openai.com',
          path: '/v1/chat/completions',
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer sk-proj-GyQK9uPv-QqYEsQcf7TN7FcD1EiG7t2uqBcJ7Nz13_P-tD0pYNYL3WqJuvxUKUJQ5UmvHOtqBmT3BlbkFJGvuOvQ1_gZU4MnY1JvbJM4lOdXvXp_w6y5S1SaJJhRZKkL6_aW1nZH7_vRXTWn0vWXF-9rZAA',
          },
          body: JSON.stringify({
            model: 'gpt-4o',
            messages: [{ role: 'user', content: extrasPrompt }],
            temperature: 0.8,
            max_tokens: 800,
          }),
        }),
      });

      const extrasData = await extrasResponse.json();
      const extrasText: string = extrasData.choices[0].message.content;

      const bedtimeMatch: RegExpMatchArray | null = extrasText.match(/BEDTIME:\s*(.+?)(?=\n(?:ADVENTURE|MORAL|TRAITS|CUES|$))/s);
      const adventureMatch: RegExpMatchArray | null = extrasText.match(/ADVENTURE:\s*(.+?)(?=\n(?:MORAL|TRAITS|CUES|$))/s);
      const moralMatch: RegExpMatchArray | null = extrasText.match(/MORAL:\s*(.+?)(?=\n(?:TRAITS|CUES|$))/s);
      const traitsMatch: RegExpMatchArray | null = extrasText.match(/TRAITS:\s*(.+?)(?=\n(?:CUES|$))/s);
      const cuesMatch: RegExpMatchArray | null = extrasText.match(/CUES:\s*(.+?)$/s);

      const characterTraits: string[] = traitsMatch
        ? traitsMatch[1]
            .split(',')
            .map((t: string) => t.trim())
            .filter((t: string) => t.length > 0)
        : [];

      const titlePrompt: string = `Create a magical, catchy title for this children's story in 3-6 words: ${storyText.substring(0, 200)}...`;
      const titleResponse = await fetch('/api/proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          protocol: 'https',
          origin: 'api.openai.com',
          path: '/v1/chat/completions',
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer sk-proj-GyQK9uPv-QqYEsQcf7TN7FcD1EiG7t2uqBcJ7Nz13_P-tD0pYNYL3WqJuvxUKUJQ5UmvHOtqBmT3BlbkFJGvuOvQ1_gZU4MnY1JvbJM4lOdXvXp_w6y5S1SaJJhRZKkL6_aW1nZH7_vRXTWn0vWXF-9rZAA',
          },
          body: JSON.stringify({
            model: 'gpt-4o',
            messages: [{ role: 'user', content: titlePrompt }],
            temperature: 0.9,
            max_tokens: 50,
          }),
        }),
      });

      const titleData = await titleResponse.json();
      const title: string = titleData.choices[0].message.content.replace(/['"]/g, '').trim();

      const story: GeneratedStory = {
        title,
        story: storyText,
        illustrations,
        bedtimeVersion: bedtimeMatch ? bedtimeMatch[1].trim() : undefined,
        adventureVersion: adventureMatch ? adventureMatch[1].trim() : undefined,
        moralLesson: moralMatch ? moralMatch[1].trim() : undefined,
        characterTraits,
        readAloudCues: cuesMatch ? cuesMatch[1].trim() : undefined,
      };

      setGeneratedStory(story);
    } catch (error: unknown) {
      console.error('Error generating story:', error);
      alert('Oops! Something went wrong creating your story. Please try again! 🌟');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleNewStory = (): void => {
    setGeneratedStory(null);
    setCurrentFormData(null);
  };

  const handleGenerateAgain = (): void => {
    if (currentFormData) {
      generateStory(currentFormData);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-100 to-orange-100 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,182,193,0.3),transparent_50%)]"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(216,180,254,0.3),transparent_50%)]"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_80%,rgba(251,207,232,0.3),transparent_50%)]"></div>

      <div className="relative z-10 container mx-auto px-4 py-12">
        <header className="text-center mb-12">
          <h1 className="text-5xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-purple-600 via-pink-500 to-orange-400 bg-clip-text text-transparent drop-shadow-lg">
            DreamForge Story Maker
          </h1>
          <div className="inline-block bg-white/80 backdrop-blur-sm px-6 py-2 rounded-full border-2 border-purple-300 shadow-lg">
            <p className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-500 bg-clip-text text-transparent">
              $STORY
            </p>
          </div>
          <p className="mt-6 text-lg text-gray-700 max-w-2xl mx-auto">
            ✨ Create magical, personalized stories for children ✨
            <br />
            <span className="text-base text-gray-600">
              Every story is unique, engaging, and filled with wonder!
            </span>
          </p>
        </header>

        <main>
          {!generatedStory ? (
            <StoryForm onGenerate={generateStory} isGenerating={isGenerating} />
          ) : (
            <StoryDisplay story={generatedStory} onNewStory={handleNewStory} onGenerateAgain={handleGenerateAgain} />
          )}
        </main>

        <footer className="mt-16 text-center text-gray-600">
          <p className="text-sm">
            Made with ❤️ for dreamers, parents, and curious minds everywhere
          </p>
        </footer>
      </div>
    </div>
  );
}
