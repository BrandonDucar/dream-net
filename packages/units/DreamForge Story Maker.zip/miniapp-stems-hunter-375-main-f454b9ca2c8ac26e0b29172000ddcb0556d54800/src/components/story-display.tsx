'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import type { GeneratedStory } from '@/types/story';

interface StoryDisplayProps {
  story: GeneratedStory;
  onNewStory: () => void;
  onGenerateAgain: () => void;
}

export function StoryDisplay({ story, onNewStory, onGenerateAgain }: StoryDisplayProps): JSX.Element {
  const [savedStories, setSavedStories] = useState<GeneratedStory[]>([]);

  const handleSaveStory = (): void => {
    setSavedStories((prev: GeneratedStory[]) => [...prev, story]);
    alert('Story saved! 📚');
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      <Card className="bg-white/90 backdrop-blur-sm border-2 border-purple-200 shadow-xl">
        <CardHeader className="text-center pb-4">
          <CardTitle className="text-4xl font-bold bg-gradient-to-r from-purple-600 via-pink-500 to-orange-400 bg-clip-text text-transparent">
            {story.title}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="story" className="w-full">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 gap-2 bg-purple-100/50">
              <TabsTrigger value="story" className="data-[state=active]:bg-purple-500 data-[state=active]:text-white">
                📖 Story
              </TabsTrigger>
              <TabsTrigger value="features" className="data-[state=active]:bg-pink-500 data-[state=active]:text-white">
                ✨ Features
              </TabsTrigger>
              <TabsTrigger value="illustrations" className="data-[state=active]:bg-orange-400 data-[state=active]:text-white">
                🎨 Art Ideas
              </TabsTrigger>
              <TabsTrigger value="extras" className="data-[state=active]:bg-purple-500 data-[state=active]:text-white">
                🌟 Extras
              </TabsTrigger>
            </TabsList>

            <TabsContent value="story" className="mt-6">
              <div className="prose prose-lg max-w-none">
                <div className="whitespace-pre-wrap text-gray-800 leading-relaxed p-6 bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 rounded-lg border border-purple-200">
                  {story.story}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="features" className="mt-6 space-y-6">
              {story.bedtimeVersion && (
                <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
                  <CardHeader>
                    <CardTitle className="text-xl text-blue-700 flex items-center gap-2">
                      🌙 Bedtime Smoothing Version
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">{story.bedtimeVersion}</p>
                  </CardContent>
                </Card>
              )}

              {story.adventureVersion && (
                <Card className="bg-gradient-to-br from-orange-50 to-red-50 border-orange-200">
                  <CardHeader>
                    <CardTitle className="text-xl text-orange-700 flex items-center gap-2">
                      ⚡ Adventure Mode Version
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">{story.adventureVersion}</p>
                  </CardContent>
                </Card>
              )}

              {story.readAloudCues && (
                <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
                  <CardHeader>
                    <CardTitle className="text-xl text-green-700 flex items-center gap-2">
                      🎭 Read Aloud Style
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">{story.readAloudCues}</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="illustrations" className="mt-6">
              <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
                <CardHeader>
                  <CardTitle className="text-xl text-purple-700">🎨 Illustration Suggestions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {story.illustrations.map((illustration: string, index: number) => (
                      <div
                        key={index}
                        className="p-4 bg-white rounded-lg border-2 border-purple-200 shadow-sm hover:shadow-md transition-shadow"
                      >
                        <div className="flex items-start gap-3">
                          <Badge className="bg-purple-500 text-white text-sm">#{index + 1}</Badge>
                          <p className="text-gray-700 flex-1">{illustration}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="extras" className="mt-6 space-y-6">
              {story.moralLesson && (
                <Card className="bg-gradient-to-br from-yellow-50 to-amber-50 border-yellow-200">
                  <CardHeader>
                    <CardTitle className="text-xl text-amber-700 flex items-center gap-2">
                      💡 Moral Lesson
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 text-lg font-medium">{story.moralLesson}</p>
                  </CardContent>
                </Card>
              )}

              {story.characterTraits && story.characterTraits.length > 0 && (
                <Card className="bg-gradient-to-br from-pink-50 to-rose-50 border-pink-200">
                  <CardHeader>
                    <CardTitle className="text-xl text-pink-700 flex items-center gap-2">
                      ⭐ Character Traits
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {story.characterTraits.map((trait: string, index: number) => (
                        <Badge
                          key={index}
                          className="bg-gradient-to-r from-pink-400 to-rose-400 text-white px-4 py-2 text-sm"
                        >
                          {trait}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>

          <div className="mt-8 flex flex-col sm:flex-row gap-4">
            <Button
              onClick={onGenerateAgain}
              className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-semibold py-6 text-lg shadow-lg hover:shadow-xl transition-all"
            >
              🔄 Generate Again
            </Button>
            <Button
              onClick={onNewStory}
              className="flex-1 bg-gradient-to-r from-orange-400 to-pink-500 hover:from-orange-500 hover:to-pink-600 text-white font-semibold py-6 text-lg shadow-lg hover:shadow-xl transition-all"
            >
              ✨ New Story
            </Button>
            <Button
              onClick={handleSaveStory}
              className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white font-semibold py-6 text-lg shadow-lg hover:shadow-xl transition-all"
            >
              📚 Save Story
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
