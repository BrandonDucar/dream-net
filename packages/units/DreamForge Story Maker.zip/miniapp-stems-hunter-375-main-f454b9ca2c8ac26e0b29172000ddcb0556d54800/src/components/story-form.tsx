'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import type { StoryFormData } from '@/types/story';

interface StoryFormProps {
  onGenerate: (formData: StoryFormData) => void;
  isGenerating: boolean;
}

export function StoryForm({ onGenerate, isGenerating }: StoryFormProps): JSX.Element {
  const [formData, setFormData] = useState<StoryFormData>({
    characterName: '',
    characterType: 'human',
    characterVibe: 'brave',
    sidekick: '',
    setting: 'forest',
    theme: 'friendship',
    storyLength: 'medium',
  });

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    onGenerate(formData);
  };

  const updateField = <K extends keyof StoryFormData>(field: K, value: StoryFormData[K]): void => {
    setFormData((prev: StoryFormData) => ({ ...prev, [field]: value }));
  };

  return (
    <Card className="w-full max-w-2xl mx-auto bg-white/80 backdrop-blur-sm border-2 border-purple-200 shadow-lg">
      <CardHeader className="text-center pb-4">
        <CardTitle className="text-3xl font-bold bg-gradient-to-r from-purple-600 via-pink-500 to-orange-400 bg-clip-text text-transparent">
          Create Your Story
        </CardTitle>
        <CardDescription className="text-gray-600">
          Fill in the details to create a magical personalized story
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="characterName" className="text-purple-700 font-semibold">
              Main Character Name *
            </Label>
            <Input
              id="characterName"
              value={formData.characterName}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('characterName', e.target.value)}
              placeholder="Enter character name..."
              required
              className="border-purple-200 focus:border-purple-400"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="characterType" className="text-purple-700 font-semibold">
                Character Type
              </Label>
              <Select
                value={formData.characterType}
                onValueChange={(value: StoryFormData['characterType']) => updateField('characterType', value)}
              >
                <SelectTrigger id="characterType" className="border-purple-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="human">Human</SelectItem>
                  <SelectItem value="animal">Animal</SelectItem>
                  <SelectItem value="creature">Creature</SelectItem>
                  <SelectItem value="robot">Robot</SelectItem>
                  <SelectItem value="magical being">Magical Being</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="characterVibe" className="text-purple-700 font-semibold">
                Character Vibe
              </Label>
              <Select
                value={formData.characterVibe}
                onValueChange={(value: StoryFormData['characterVibe']) => updateField('characterVibe', value)}
              >
                <SelectTrigger id="characterVibe" className="border-purple-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cute">Cute</SelectItem>
                  <SelectItem value="brave">Brave</SelectItem>
                  <SelectItem value="silly">Silly</SelectItem>
                  <SelectItem value="curious">Curious</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="sidekick" className="text-purple-700 font-semibold">
              Sidekick (Optional)
            </Label>
            <Input
              id="sidekick"
              value={formData.sidekick}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('sidekick', e.target.value)}
              placeholder="Add a sidekick friend..."
              className="border-purple-200 focus:border-purple-400"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="setting" className="text-purple-700 font-semibold">
                Setting
              </Label>
              <Select
                value={formData.setting}
                onValueChange={(value: StoryFormData['setting']) => updateField('setting', value)}
              >
                <SelectTrigger id="setting" className="border-purple-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="forest">Forest</SelectItem>
                  <SelectItem value="space">Space</SelectItem>
                  <SelectItem value="ocean">Ocean</SelectItem>
                  <SelectItem value="school">School</SelectItem>
                  <SelectItem value="castle">Castle</SelectItem>
                  <SelectItem value="dream world">Dream World</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="theme" className="text-purple-700 font-semibold">
                Theme
              </Label>
              <Select
                value={formData.theme}
                onValueChange={(value: StoryFormData['theme']) => updateField('theme', value)}
              >
                <SelectTrigger id="theme" className="border-purple-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="friendship">Friendship</SelectItem>
                  <SelectItem value="courage">Courage</SelectItem>
                  <SelectItem value="mystery">Mystery</SelectItem>
                  <SelectItem value="learning">Learning</SelectItem>
                  <SelectItem value="bedtime">Bedtime</SelectItem>
                  <SelectItem value="fun">Fun</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="storyLength" className="text-purple-700 font-semibold">
              Story Length
            </Label>
            <Select
              value={formData.storyLength}
              onValueChange={(value: StoryFormData['storyLength']) => updateField('storyLength', value)}
            >
              <SelectTrigger id="storyLength" className="border-purple-200">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="short">Short (5-7 minutes)</SelectItem>
                <SelectItem value="medium">Medium (8-12 minutes)</SelectItem>
                <SelectItem value="long">Long (15+ minutes)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button
            type="submit"
            disabled={isGenerating || !formData.characterName}
            className="w-full bg-gradient-to-r from-purple-500 via-pink-500 to-orange-400 hover:from-purple-600 hover:via-pink-600 hover:to-orange-500 text-white font-semibold py-6 text-lg shadow-lg hover:shadow-xl transition-all"
          >
            {isGenerating ? 'Creating Your Story...' : '✨ Generate Story ✨'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
