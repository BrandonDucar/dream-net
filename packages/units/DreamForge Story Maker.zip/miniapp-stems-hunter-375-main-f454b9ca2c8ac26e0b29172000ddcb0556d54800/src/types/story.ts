export interface StoryFormData {
  characterName: string;
  characterType: 'human' | 'animal' | 'creature' | 'robot' | 'magical being';
  characterVibe: 'cute' | 'brave' | 'silly' | 'curious';
  sidekick: string;
  setting: 'forest' | 'space' | 'ocean' | 'school' | 'castle' | 'dream world';
  theme: 'friendship' | 'courage' | 'mystery' | 'learning' | 'bedtime' | 'fun';
  storyLength: 'short' | 'medium' | 'long';
}

export interface GeneratedStory {
  title: string;
  story: string;
  illustrations: string[];
  bedtimeVersion?: string;
  adventureVersion?: string;
  moralLesson?: string;
  characterTraits?: string[];
  readAloudCues?: string;
}
