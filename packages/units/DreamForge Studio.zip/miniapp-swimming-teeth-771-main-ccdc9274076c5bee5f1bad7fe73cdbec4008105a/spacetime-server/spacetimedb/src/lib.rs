// SpacetimeDB imports
use spacetimedb::{table, reducer, ReducerContext, Table};

// ------------- Helpers -------------

fn now_micros_u64(ctx: &ReducerContext) -> Result<u64, String> {
    let micros = ctx.timestamp.to_micros_since_unix_epoch();
    if micros < 0 {
        return Err("Invalid server timestamp".to_string());
    }
    Ok(micros as u64)
}

fn validate_non_empty(value: &str, field: &str) -> Result<(), String> {
    if value.trim().is_empty() {
        return Err(format!("Field '{}' must not be empty", field));
    }
    Ok(())
}

fn validate_json_array_str(value: &str, field: &str) -> Result<(), String> {
    let v = value.trim();
    if !(v.starts_with('[') && v.ends_with(']')) {
        return Err(format!("Field '{}' must be a JSON array encoded as string (e.g., \"[]\")", field));
    }
    Ok(())
}

fn validate_json_value_str(value: &str, field: &str) -> Result<(), String> {
    let v = value.trim();
    let starts_ok = v.starts_with('{') || v.starts_with('[') || v == "null" || v.starts_with('"') || v.starts_with('t') || v.starts_with('f') || v.starts_with('-') || v.chars().next().map(|c| c.is_ascii_digit()).unwrap_or(false);
    let ends_ok = v.ends_with('}') || v.ends_with(']') || v == "null" || v.ends_with('"') || v.ends_with('e') || v.chars().last().map(|c| c.is_ascii_digit()).unwrap_or(false);
    if !(starts_ok && ends_ok) {
        return Err(format!("Field '{}' must be a JSON value encoded as string", field));
    }
    Ok(())
}

fn validate_target_environment(value: &str) -> Result<(), String> {
    match value {
        "custom-gpt" | "backend-agent" | "ohara-mini-app" | "manual" | "multi" => Ok(()),
        _ => Err("Invalid target_environment. Allowed: custom-gpt, backend-agent, ohara-mini-app, manual, multi".to_string()),
    }
}

fn validate_target_type(value: &str) -> Result<(), String> {
    match value {
        "agent" | "mini-app" | "flow" | "scenario" | "task-type" => Ok(()),
        _ => Err("Invalid target_type. Allowed: agent, mini-app, flow, scenario, task-type".to_string()),
    }
}

fn validate_ab_status(value: &str) -> Result<(), String> {
    match value {
        "draft" | "active" | "completed" => Ok(()),
        _ => Err("Invalid status. Allowed: draft, active, completed".to_string()),
    }
}

fn validate_ab_winner(value: &str) -> Result<(), String> {
    match value {
        "" | "A" | "B" | "inconclusive" => Ok(()),
        _ => Err("Invalid winner. Allowed: \"\" (empty), A, B, inconclusive".to_string()),
    }
}

// ------------- Tables -------------

#[table(name = cognitive_pattern, public)]
#[derive(Clone)]
pub struct CognitivePattern {
    #[primary_key]
    id: String,
    name: String,
    #[index(btree)]
    code: String,
    description: String,
    // JSON arrays encoded as strings
    use_cases: String,
    steps: String,
    recommended_agents: String,
    tags: String,
    notes: String,
    // Inheritance
    #[index(btree)]
    parent_pattern_id: Option<String>,
    // SEO
    seo_title: String,
    seo_description: String,
    seo_keywords: String,
    seo_hashtags: String,
    alt_text: String,
    // Timestamp (micros since epoch)
    created_at: u64,
}

#[table(name = prompt_template, public)]
#[derive(Clone)]
pub struct PromptTemplate {
    #[primary_key]
    id: String,
    name: String,
    #[index(btree)]
    code: String,
    #[index(btree)]
    domain: String,
    description: String,
    #[index(btree)]
    pattern_id: Option<String>,
    // JSON arrays encoded as strings
    variables: String,
    body: String,
    usage_notes: String,
    target_environment: String, // validated string enum
    tags: String,
    notes: String,
    // SEO
    seo_title: String,
    seo_description: String,
    seo_keywords: String,
    seo_hashtags: String,
    alt_text: String,
    // Timestamp (micros since epoch)
    created_at: u64,
}

#[table(name = prompt_kit, public)]
#[derive(Clone)]
pub struct PromptKit {
    #[primary_key]
    id: String,
    name: String,
    description: String,
    #[index(btree)]
    domain: String,
    tags: String, // JSON array string
    notes: String,
    created_at: u64,
}

#[table(name = kit_template, public)]
#[derive(Clone)]
pub struct KitTemplate {
    #[primary_key]
    id: String,
    #[index(btree)]
    kit_id: String,
    #[index(btree)]
    template_id: String,
}

#[table(name = kit_pattern, public)]
#[derive(Clone)]
pub struct KitPattern {
    #[primary_key]
    id: String,
    #[index(btree)]
    kit_id: String,
    #[index(btree)]
    pattern_id: String,
}

#[table(name = usage_mapping, public)]
#[derive(Clone)]
pub struct UsageMapping {
    #[primary_key]
    id: String,
    #[index(btree)]
    target_type: String, // validated string enum
    target_ref: String,
    #[index(btree)]
    primary_pattern_id: Option<String>,
    notes: String,
    created_at: u64,
}

#[table(name = mapping_template, public)]
#[derive(Clone)]
pub struct MappingTemplate {
    #[primary_key]
    id: String,
    #[index(btree)]
    mapping_id: String,
    #[index(btree)]
    template_id: String,
}

// AB Test Recommendations
#[table(name = ab_test_recommendation, public)]
#[derive(Clone)]
pub struct ABTestRecommendation {
    #[primary_key]
    id: String,
    name: String,
    description: String,
    #[index(btree)]
    pattern_a_id: String,
    #[index(btree)]
    pattern_b_id: String,
    hypothesis: String,
    // JSON array string of metrics
    metrics: String,
    #[index(btree)]
    status: String, // "draft" | "active" | "completed"
    winner: String, // "A" | "B" | "inconclusive" | ""
    notes: String,
    created_at: u64,
}

// Export Configurations
#[table(name = export_config, public)]
#[derive(Clone)]
pub struct ExportConfig {
    #[primary_key]
    id: String,
    name: String,   // e.g., "OpenAI GPT", "Claude Project"
    format: String, // target format type
    template_structure: String, // JSON structure for export
    notes: String,
    created_at: u64,
}

// ------------- Reducers: Cognitive Patterns -------------

#[reducer]
pub fn create_cognitive_pattern(
    ctx: &ReducerContext,
    id: String,
    name: String,
    code: String,
    description: String,
    use_cases: String,
    steps: String,
    recommended_agents: String,
    tags: String,
    notes: String,
    parent_pattern_id: Option<String>,
    seo_title: String,
    seo_description: String,
    seo_keywords: String,
    seo_hashtags: String,
    alt_text: String,
) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    validate_non_empty(&name, "name")?;
    validate_non_empty(&code, "code")?;
    validate_non_empty(&description, "description")?;
    validate_json_array_str(&use_cases, "use_cases")?;
    validate_json_array_str(&steps, "steps")?;
    validate_json_array_str(&recommended_agents, "recommended_agents")?;
    validate_json_array_str(&tags, "tags")?;
    validate_json_array_str(&seo_keywords, "seo_keywords")?;
    validate_json_array_str(&seo_hashtags, "seo_hashtags")?;

    if let Some(pid) = &parent_pattern_id {
        if !pid.trim().is_empty() {
            if pid == &id {
                return Err("parent_pattern_id cannot equal id (no self inheritance)".to_string());
            }
            if ctx.db.cognitive_pattern().id().find(pid).is_none() {
                return Err(format!("Referenced parent_pattern_id '{}' does not exist", pid));
            }
        }
    }

    if ctx.db.cognitive_pattern().id().find(&id).is_some() {
        return Err(format!("Cognitive pattern with id '{}' already exists", id));
    }
    // enforce unique code at app level
    for p in ctx.db.cognitive_pattern().iter() {
        if p.code == code {
            return Err(format!("Cognitive pattern with code '{}' already exists", code));
        }
    }

    let created_at = now_micros_u64(ctx)?;
    ctx.db.cognitive_pattern().insert(CognitivePattern {
        id,
        name,
        code,
        description,
        use_cases,
        steps,
        recommended_agents,
        tags,
        notes,
        parent_pattern_id,
        seo_title,
        seo_description,
        seo_keywords,
        seo_hashtags,
        alt_text,
        created_at,
    });
    Ok(())
}

#[reducer]
pub fn update_cognitive_pattern(
    ctx: &ReducerContext,
    id: String,
    name: String,
    code: String,
    description: String,
    use_cases: String,
    steps: String,
    recommended_agents: String,
    tags: String,
    notes: String,
    parent_pattern_id: Option<String>,
    seo_title: String,
    seo_description: String,
    seo_keywords: String,
    seo_hashtags: String,
    alt_text: String,
) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    validate_non_empty(&name, "name")?;
    validate_non_empty(&code, "code")?;
    validate_non_empty(&description, "description")?;
    validate_json_array_str(&use_cases, "use_cases")?;
    validate_json_array_str(&steps, "steps")?;
    validate_json_array_str(&recommended_agents, "recommended_agents")?;
    validate_json_array_str(&tags, "tags")?;
    validate_json_array_str(&seo_keywords, "seo_keywords")?;
    validate_json_array_str(&seo_hashtags, "seo_hashtags")?;

    if let Some(pid) = &parent_pattern_id {
        if !pid.trim().is_empty() {
            if pid == &id {
                return Err("parent_pattern_id cannot equal id (no self inheritance)".to_string());
            }
            if ctx.db.cognitive_pattern().id().find(pid).is_none() {
                return Err(format!("Referenced parent_pattern_id '{}' does not exist", pid));
            }
        }
    }

    if let Some(mut row) = ctx.db.cognitive_pattern().id().find(&id) {
        // ensure no other row uses the same code
        for other in ctx.db.cognitive_pattern().iter() {
            if other.id != id && other.code == code {
                return Err(format!("Another cognitive pattern with code '{}' already exists", code));
            }
        }

        // update fields; preserve created_at
        let created_at_val = row.created_at;
        row.name = name;
        row.code = code;
        row.description = description;
        row.use_cases = use_cases;
        row.steps = steps;
        row.recommended_agents = recommended_agents;
        row.tags = tags;
        row.notes = notes;
        row.parent_pattern_id = parent_pattern_id;
        row.seo_title = seo_title;
        row.seo_description = seo_description;
        row.seo_keywords = seo_keywords;
        row.seo_hashtags = seo_hashtags;
        row.alt_text = alt_text;
        row.created_at = created_at_val;

        ctx.db.cognitive_pattern().id().update(row);
        Ok(())
    } else {
        Err(format!("Cognitive pattern with id '{}' not found", id))
    }
}

#[reducer]
pub fn delete_cognitive_pattern(ctx: &ReducerContext, id: String) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    if ctx.db.cognitive_pattern().id().find(&id).is_none() {
        return Err(format!("Cognitive pattern with id '{}' not found", id));
    }
    // prevent deleting a parent that is referenced by others
    for p in ctx.db.cognitive_pattern().iter() {
        if let Some(pid) = &p.parent_pattern_id {
            if pid == &id {
                return Err(format!(
                    "Cannot delete pattern '{}' because it is referenced as a parent by '{}'",
                    id, p.id
                ));
            }
        }
    }
    ctx.db.cognitive_pattern().id().delete(&id);
    Ok(())
}

// ------------- Reducers: Prompt Templates -------------

#[reducer]
pub fn create_prompt_template(
    ctx: &ReducerContext,
    id: String,
    name: String,
    code: String,
    domain: String,
    description: String,
    pattern_id: Option<String>,
    variables: String,
    body: String,
    usage_notes: String,
    target_environment: String,
    tags: String,
    notes: String,
    seo_title: String,
    seo_description: String,
    seo_keywords: String,
    seo_hashtags: String,
    alt_text: String,
) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    validate_non_empty(&name, "name")?;
    validate_non_empty(&code, "code")?;
    validate_non_empty(&domain, "domain")?;
    validate_non_empty(&body, "body")?;
    validate_target_environment(&target_environment)?;
    validate_json_array_str(&variables, "variables")?;
    validate_json_array_str(&tags, "tags")?;
    validate_json_array_str(&seo_keywords, "seo_keywords")?;
    validate_json_array_str(&seo_hashtags, "seo_hashtags")?;

    if let Some(pid) = &pattern_id {
        if !pid.trim().is_empty() && ctx.db.cognitive_pattern().id().find(pid).is_none() {
            return Err(format!("Referenced pattern_id '{}' does not exist", pid));
        }
    }

    if ctx.db.prompt_template().id().find(&id).is_some() {
        return Err(format!("Prompt template with id '{}' already exists", id));
    }
    for t in ctx.db.prompt_template().iter() {
        if t.code == code {
            return Err(format!("Prompt template with code '{}' already exists", code));
        }
    }

    let created_at = now_micros_u64(ctx)?;
    ctx.db.prompt_template().insert(PromptTemplate {
        id,
        name,
        code,
        domain,
        description,
        pattern_id,
        variables,
        body,
        usage_notes,
        target_environment,
        tags,
        notes,
        seo_title,
        seo_description,
        seo_keywords,
        seo_hashtags,
        alt_text,
        created_at,
    });
    Ok(())
}

#[reducer]
pub fn update_prompt_template(
    ctx: &ReducerContext,
    id: String,
    name: String,
    code: String,
    domain: String,
    description: String,
    pattern_id: Option<String>,
    variables: String,
    body: String,
    usage_notes: String,
    target_environment: String,
    tags: String,
    notes: String,
    seo_title: String,
    seo_description: String,
    seo_keywords: String,
    seo_hashtags: String,
    alt_text: String,
) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    validate_non_empty(&name, "name")?;
    validate_non_empty(&code, "code")?;
    validate_non_empty(&domain, "domain")?;
    validate_non_empty(&body, "body")?;
    validate_target_environment(&target_environment)?;
    validate_json_array_str(&variables, "variables")?;
    validate_json_array_str(&tags, "tags")?;
    validate_json_array_str(&seo_keywords, "seo_keywords")?;
    validate_json_array_str(&seo_hashtags, "seo_hashtags")?;

    if let Some(pid) = &pattern_id {
        if !pid.trim().is_empty() && ctx.db.cognitive_pattern().id().find(pid).is_none() {
            return Err(format!("Referenced pattern_id '{}' does not exist", pid));
        }
    }

    if let Some(mut row) = ctx.db.prompt_template().id().find(&id) {
        for other in ctx.db.prompt_template().iter() {
            if other.id != id && other.code == code {
                return Err(format!("Another prompt template with code '{}' already exists", code));
            }
        }
        let created_at_keep = row.created_at;
        row.name = name;
        row.code = code;
        row.domain = domain;
        row.description = description;
        row.pattern_id = pattern_id;
        row.variables = variables;
        row.body = body;
        row.usage_notes = usage_notes;
        row.target_environment = target_environment;
        row.tags = tags;
        row.notes = notes;
        row.seo_title = seo_title;
        row.seo_description = seo_description;
        row.seo_keywords = seo_keywords;
        row.seo_hashtags = seo_hashtags;
        row.alt_text = alt_text;
        row.created_at = created_at_keep;

        ctx.db.prompt_template().id().update(row);
        Ok(())
    } else {
        Err(format!("Prompt template with id '{}' not found", id))
    }
}

#[reducer]
pub fn delete_prompt_template(ctx: &ReducerContext, id: String) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    if ctx.db.prompt_template().id().find(&id).is_none() {
        return Err(format!("Prompt template with id '{}' not found", id));
    }
    ctx.db.prompt_template().id().delete(&id);
    Ok(())
}

// ------------- Reducers: Prompt Kits -------------

#[reducer]
pub fn create_prompt_kit(
    ctx: &ReducerContext,
    id: String,
    name: String,
    description: String,
    domain: String,
    tags: String,
    notes: String,
) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    validate_non_empty(&name, "name")?;
    validate_non_empty(&domain, "domain")?;
    validate_json_array_str(&tags, "tags")?;

    if ctx.db.prompt_kit().id().find(&id).is_some() {
        return Err(format!("Prompt kit with id '{}' already exists", id));
    }

    let created_at = now_micros_u64(ctx)?;
    ctx.db.prompt_kit().insert(PromptKit {
        id,
        name,
        description,
        domain,
        tags,
        notes,
        created_at,
    });
    Ok(())
}

#[reducer]
pub fn update_prompt_kit(
    ctx: &ReducerContext,
    id: String,
    name: String,
    description: String,
    domain: String,
    tags: String,
    notes: String,
) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    validate_non_empty(&name, "name")?;
    validate_non_empty(&domain, "domain")?;
    validate_json_array_str(&tags, "tags")?;

    if let Some(mut row) = ctx.db.prompt_kit().id().find(&id) {
        let created_at_keep = row.created_at;
        row.name = name;
        row.description = description;
        row.domain = domain;
        row.tags = tags;
        row.notes = notes;
        row.created_at = created_at_keep;

        ctx.db.prompt_kit().id().update(row);
        Ok(())
    } else {
        Err(format!("Prompt kit with id '{}' not found", id))
    }
}

#[reducer]
pub fn delete_prompt_kit(ctx: &ReducerContext, id: String) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    if ctx.db.prompt_kit().id().find(&id).is_none() {
        return Err(format!("Prompt kit with id '{}' not found", id));
    }
    ctx.db.prompt_kit().id().delete(&id);
    Ok(())
}

#[reducer]
pub fn add_template_to_kit(
    ctx: &ReducerContext,
    kit_id: String,
    template_id: String,
) -> Result<(), String> {
    validate_non_empty(&kit_id, "kit_id")?;
    validate_non_empty(&template_id, "template_id")?;

    if ctx.db.prompt_kit().id().find(&kit_id).is_none() {
        return Err(format!("Kit '{}' does not exist", kit_id));
    }
    if ctx.db.prompt_template().id().find(&template_id).is_none() {
        return Err(format!("Template '{}' does not exist", template_id));
    }

    for link in ctx.db.kit_template().iter() {
        if link.kit_id == kit_id && link.template_id == template_id {
            return Err("Template is already linked to this kit".to_string());
        }
    }

    let id = format!("kt_{}_{}_{}", kit_id, template_id, now_micros_u64(ctx)?);
    ctx.db.kit_template().insert(KitTemplate {
        id,
        kit_id,
        template_id,
    });
    Ok(())
}

#[reducer]
pub fn remove_template_from_kit(
    ctx: &ReducerContext,
    kit_id: String,
    template_id: String,
) -> Result<(), String> {
    validate_non_empty(&kit_id, "kit_id")?;
    validate_non_empty(&template_id, "template_id")?;

    let mut to_delete: Vec<String> = Vec::new();
    for link in ctx.db.kit_template().iter() {
        if link.kit_id == kit_id && link.template_id == template_id {
            to_delete.push(link.id.clone());
        }
    }
    if to_delete.is_empty() {
        return Err("No such template-kit link found".to_string());
    }
    for link_id in to_delete.iter() {
        ctx.db.kit_template().id().delete(link_id);
    }
    Ok(())
}

#[reducer]
pub fn add_pattern_to_kit(
    ctx: &ReducerContext,
    kit_id: String,
    pattern_id: String,
) -> Result<(), String> {
    validate_non_empty(&kit_id, "kit_id")?;
    validate_non_empty(&pattern_id, "pattern_id")?;

    if ctx.db.prompt_kit().id().find(&kit_id).is_none() {
        return Err(format!("Kit '{}' does not exist", kit_id));
    }
    if ctx.db.cognitive_pattern().id().find(&pattern_id).is_none() {
        return Err(format!("Pattern '{}' does not exist", pattern_id));
    }

    for link in ctx.db.kit_pattern().iter() {
        if link.kit_id == kit_id && link.pattern_id == pattern_id {
            return Err("Pattern is already linked to this kit".to_string());
        }
    }

    let id = format!("kp_{}_{}_{}", kit_id, pattern_id, now_micros_u64(ctx)?);
    ctx.db.kit_pattern().insert(KitPattern {
        id,
        kit_id,
        pattern_id,
    });
    Ok(())
}

#[reducer]
pub fn remove_pattern_from_kit(
    ctx: &ReducerContext,
    kit_id: String,
    pattern_id: String,
) -> Result<(), String> {
    validate_non_empty(&kit_id, "kit_id")?;
    validate_non_empty(&pattern_id, "pattern_id")?;

    let mut to_delete: Vec<String> = Vec::new();
    for link in ctx.db.kit_pattern().iter() {
        if link.kit_id == kit_id && link.pattern_id == pattern_id {
            to_delete.push(link.id.clone());
        }
    }
    if to_delete.is_empty() {
        return Err("No such pattern-kit link found".to_string());
    }
    for link_id in to_delete.iter() {
        ctx.db.kit_pattern().id().delete(link_id);
    }
    Ok(())
}

// ------------- Reducers: Usage Mapping -------------

#[reducer]
pub fn create_usage_mapping(
    ctx: &ReducerContext,
    id: String,
    target_type: String,
    target_ref: String,
    primary_pattern_id: Option<String>,
    notes: String,
) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    validate_non_empty(&target_ref, "target_ref")?;
    validate_target_type(&target_type)?;

    if let Some(pid) = &primary_pattern_id {
        if !pid.trim().is_empty() && ctx.db.cognitive_pattern().id().find(pid).is_none() {
            return Err(format!("Referenced primary_pattern_id '{}' does not exist", pid));
        }
    }

    if ctx.db.usage_mapping().id().find(&id).is_some() {
        return Err(format!("Usage mapping with id '{}' already exists", id));
    }

    let created_at = now_micros_u64(ctx)?;
    ctx.db.usage_mapping().insert(UsageMapping {
        id,
        target_type,
        target_ref,
        primary_pattern_id,
        notes,
        created_at,
    });
    Ok(())
}

#[reducer]
pub fn update_usage_mapping(
    ctx: &ReducerContext,
    id: String,
    target_type: String,
    target_ref: String,
    primary_pattern_id: Option<String>,
    notes: String,
) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    validate_non_empty(&target_ref, "target_ref")?;
    validate_target_type(&target_type)?;

    if let Some(pid) = &primary_pattern_id {
        if !pid.trim().is_empty() && ctx.db.cognitive_pattern().id().find(pid).is_none() {
            return Err(format!("Referenced primary_pattern_id '{}' does not exist", pid));
        }
    }

    if let Some(mut row) = ctx.db.usage_mapping().id().find(&id) {
        let created_at_keep = row.created_at;
        row.target_type = target_type;
        row.target_ref = target_ref;
        row.primary_pattern_id = primary_pattern_id;
        row.notes = notes;
        row.created_at = created_at_keep;

        ctx.db.usage_mapping().id().update(row);
        Ok(())
    } else {
        Err(format!("Usage mapping with id '{}' not found", id))
    }
}

#[reducer]
pub fn delete_usage_mapping(ctx: &ReducerContext, id: String) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    if ctx.db.usage_mapping().id().find(&id).is_none() {
        return Err(format!("Usage mapping with id '{}' not found", id));
    }
    ctx.db.usage_mapping().id().delete(&id);
    Ok(())
}

#[reducer]
pub fn add_template_to_mapping(
    ctx: &ReducerContext,
    mapping_id: String,
    template_id: String,
) -> Result<(), String> {
    validate_non_empty(&mapping_id, "mapping_id")?;
    validate_non_empty(&template_id, "template_id")?;

    if ctx.db.usage_mapping().id().find(&mapping_id).is_none() {
        return Err(format!("Usage mapping '{}' does not exist", mapping_id));
    }
    if ctx.db.prompt_template().id().find(&template_id).is_none() {
        return Err(format!("Template '{}' does not exist", template_id));
    }

    for link in ctx.db.mapping_template().iter() {
        if link.mapping_id == mapping_id && link.template_id == template_id {
            return Err("Template is already linked to this usage mapping".to_string());
        }
    }

    let id = format!("mt_{}_{}_{}", mapping_id, template_id, now_micros_u64(ctx)?);
    ctx.db.mapping_template().insert(MappingTemplate {
        id,
        mapping_id,
        template_id,
    });
    Ok(())
}

#[reducer]
pub fn remove_template_from_mapping(
    ctx: &ReducerContext,
    mapping_id: String,
    template_id: String,
) -> Result<(), String> {
    validate_non_empty(&mapping_id, "mapping_id")?;
    validate_non_empty(&template_id, "template_id")?;

    let mut to_delete: Vec<String> = Vec::new();
    for link in ctx.db.mapping_template().iter() {
        if link.mapping_id == mapping_id && link.template_id == template_id {
            to_delete.push(link.id.clone());
        }
    }
    if to_delete.is_empty() {
        return Err("No such template-mapping link found".to_string());
    }
    for link_id in to_delete.iter() {
        ctx.db.mapping_template().id().delete(link_id);
    }
    Ok(())
}

// ------------- Reducers: AB Test Recommendations -------------

#[reducer]
pub fn create_ab_test_recommendation(
    ctx: &ReducerContext,
    id: String,
    name: String,
    description: String,
    pattern_a_id: String,
    pattern_b_id: String,
    hypothesis: String,
    metrics: String,
    status: String,
    winner: String,
    notes: String,
) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    validate_non_empty(&name, "name")?;
    validate_non_empty(&pattern_a_id, "pattern_a_id")?;
    validate_non_empty(&pattern_b_id, "pattern_b_id")?;
    if pattern_a_id == pattern_b_id {
        return Err("pattern_a_id and pattern_b_id must be different".to_string());
    }
    if ctx.db.cognitive_pattern().id().find(&pattern_a_id).is_none() {
        return Err(format!("pattern_a_id '{}' does not reference an existing CognitivePattern", pattern_a_id));
    }
    if ctx.db.cognitive_pattern().id().find(&pattern_b_id).is_none() {
        return Err(format!("pattern_b_id '{}' does not reference an existing CognitivePattern", pattern_b_id));
    }
    validate_json_array_str(&metrics, "metrics")?;
    validate_ab_status(&status)?;
    validate_ab_winner(&winner)?;

    if ctx.db.ab_test_recommendation().id().find(&id).is_some() {
        return Err(format!("ABTestRecommendation with id '{}' already exists", id));
    }

    let created_at = now_micros_u64(ctx)?;
    ctx.db.ab_test_recommendation().insert(ABTestRecommendation {
        id,
        name,
        description,
        pattern_a_id,
        pattern_b_id,
        hypothesis,
        metrics,
        status,
        winner,
        notes,
        created_at,
    });
    Ok(())
}

#[reducer]
pub fn update_ab_test_recommendation(
    ctx: &ReducerContext,
    id: String,
    name: String,
    description: String,
    pattern_a_id: String,
    pattern_b_id: String,
    hypothesis: String,
    metrics: String,
    status: String,
    winner: String,
    notes: String,
) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    validate_non_empty(&name, "name")?;
    validate_non_empty(&pattern_a_id, "pattern_a_id")?;
    validate_non_empty(&pattern_b_id, "pattern_b_id")?;
    if pattern_a_id == pattern_b_id {
        return Err("pattern_a_id and pattern_b_id must be different".to_string());
    }
    if ctx.db.cognitive_pattern().id().find(&pattern_a_id).is_none() {
        return Err(format!("pattern_a_id '{}' does not reference an existing CognitivePattern", pattern_a_id));
    }
    if ctx.db.cognitive_pattern().id().find(&pattern_b_id).is_none() {
        return Err(format!("pattern_b_id '{}' does not reference an existing CognitivePattern", pattern_b_id));
    }
    validate_json_array_str(&metrics, "metrics")?;
    validate_ab_status(&status)?;
    validate_ab_winner(&winner)?;

    if let Some(mut row) = ctx.db.ab_test_recommendation().id().find(&id) {
        let created_at_keep = row.created_at;
        row.name = name;
        row.description = description;
        row.pattern_a_id = pattern_a_id;
        row.pattern_b_id = pattern_b_id;
        row.hypothesis = hypothesis;
        row.metrics = metrics;
        row.status = status;
        row.winner = winner;
        row.notes = notes;
        row.created_at = created_at_keep;

        ctx.db.ab_test_recommendation().id().update(row);
        Ok(())
    } else {
        Err(format!("ABTestRecommendation with id '{}' not found", id))
    }
}

#[reducer]
pub fn delete_ab_test_recommendation(ctx: &ReducerContext, id: String) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    if ctx.db.ab_test_recommendation().id().find(&id).is_none() {
        return Err(format!("ABTestRecommendation with id '{}' not found", id));
    }
    ctx.db.ab_test_recommendation().id().delete(&id);
    Ok(())
}

// ------------- Reducers: Export Configurations -------------

#[reducer]
pub fn create_export_config(
    ctx: &ReducerContext,
    id: String,
    name: String,
    format: String,
    template_structure: String,
    notes: String,
) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    validate_non_empty(&name, "name")?;
    validate_non_empty(&format, "format")?;
    validate_json_value_str(&template_structure, "template_structure")?;

    if ctx.db.export_config().id().find(&id).is_some() {
        return Err(format!("ExportConfig with id '{}' already exists", id));
    }

    let created_at = now_micros_u64(ctx)?;
    ctx.db.export_config().insert(ExportConfig {
        id,
        name,
        format,
        template_structure,
        notes,
        created_at,
    });
    Ok(())
}

#[reducer]
pub fn update_export_config(
    ctx: &ReducerContext,
    id: String,
    name: String,
    format: String,
    template_structure: String,
    notes: String,
) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    validate_non_empty(&name, "name")?;
    validate_non_empty(&format, "format")?;
    validate_json_value_str(&template_structure, "template_structure")?;

    if let Some(mut row) = ctx.db.export_config().id().find(&id) {
        let created_at_keep = row.created_at;
        row.name = name;
        row.format = format;
        row.template_structure = template_structure;
        row.notes = notes;
        row.created_at = created_at_keep;

        ctx.db.export_config().id().update(row);
        Ok(())
    } else {
        Err(format!("ExportConfig with id '{}' not found", id))
    }
}

#[reducer]
pub fn delete_export_config(ctx: &ReducerContext, id: String) -> Result<(), String> {
    validate_non_empty(&id, "id")?;
    if ctx.db.export_config().id().find(&id).is_none() {
        return Err(format!("ExportConfig with id '{}' not found", id));
    }
    ctx.db.export_config().id().delete(&id);
    Ok(())
}