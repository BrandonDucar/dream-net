'use client'
import { useState, useMemo, useEffect } from 'react';
import { useSpacetimeDB } from '../hooks/useSpacetimeDB';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { 
  Brain, 
  FileText, 
  Package, 
  GitBranch, 
  Plus, 
  Search, 
  Download,
  Sparkles,
  Settings 
} from 'lucide-react';
import { PatternDialog } from '../components/PatternDialog';
import { TemplateDialog } from '../components/TemplateDialog';
import { KitDialog } from '../components/KitDialog';
import { MappingDialog } from '../components/MappingDialog';
import { PatternDetailDialog } from '../components/PatternDetailDialog';
import { TemplateDetailDialog } from '../components/TemplateDetailDialog';
import { KitDetailDialog } from '../components/KitDetailDialog';
import { MappingDetailDialog } from '../components/MappingDetailDialog';
import { exportCognitivePlaybook, parseJSON } from '../lib/promptUtils';
import type { CognitivePattern, PromptTemplate, PromptKit, UsageMapping } from '../spacetime_module_bindings';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Home() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const {
    connected,
    statusMessage,
    cognitivePatterns,
    promptTemplates,
    promptKits,
    usageMappings,
    connection,
    usingLocalStorage
  } = useSpacetimeDB();

  const [searchPatterns, setSearchPatterns] = useState<string>('');
  const [searchTemplates, setSearchTemplates] = useState<string>('');
  const [searchKits, setSearchKits] = useState<string>('');
  const [searchMappings, setSearchMappings] = useState<string>('');

  const [showPatternDialog, setShowPatternDialog] = useState<boolean>(false);
  const [showTemplateDialog, setShowTemplateDialog] = useState<boolean>(false);
  const [showKitDialog, setShowKitDialog] = useState<boolean>(false);
  const [showMappingDialog, setShowMappingDialog] = useState<boolean>(false);

  const [selectedPattern, setSelectedPattern] = useState<CognitivePattern | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<PromptTemplate | null>(null);
  const [selectedKit, setSelectedKit] = useState<PromptKit | null>(null);
  const [selectedMapping, setSelectedMapping] = useState<UsageMapping | null>(null);
  const [showSettings, setShowSettings] = useState<boolean>(false);

  const handleConfigSaved = () => {
    window.location.reload();
  };

  const filteredPatterns = useMemo(() => {
    const patterns = Array.from(cognitivePatterns.values());
    if (!searchPatterns) return patterns;
    
    const search = searchPatterns.toLowerCase();
    return patterns.filter((p: CognitivePattern) => {
      const tags = parseJSON<string>(p.tags);
      const useCases = parseJSON<string>(p.useCases);
      const recommendedAgents = parseJSON<string>(p.recommendedAgents);
      
      return (
        p.name.toLowerCase().includes(search) ||
        p.code.toLowerCase().includes(search) ||
        p.description.toLowerCase().includes(search) ||
        tags.some((t: string) => t.toLowerCase().includes(search)) ||
        useCases.some((u: string) => u.toLowerCase().includes(search)) ||
        recommendedAgents.some((a: string) => a.toLowerCase().includes(search))
      );
    });
  }, [cognitivePatterns, searchPatterns]);

  const filteredTemplates = useMemo(() => {
    const templates = Array.from(promptTemplates.values());
    if (!searchTemplates) return templates;
    
    const search = searchTemplates.toLowerCase();
    return templates.filter((t: PromptTemplate) => {
      const tags = parseJSON<string>(t.tags);
      
      return (
        t.name.toLowerCase().includes(search) ||
        t.code.toLowerCase().includes(search) ||
        t.domain.toLowerCase().includes(search) ||
        t.description.toLowerCase().includes(search) ||
        t.targetEnvironment.toLowerCase().includes(search) ||
        tags.some((tag: string) => tag.toLowerCase().includes(search))
      );
    });
  }, [promptTemplates, searchTemplates]);

  const filteredKits = useMemo(() => {
    const kits = Array.from(promptKits.values());
    if (!searchKits) return kits;
    
    const search = searchKits.toLowerCase();
    return kits.filter((k: PromptKit) => {
      const tags = parseJSON<string>(k.tags);
      
      return (
        k.name.toLowerCase().includes(search) ||
        k.domain.toLowerCase().includes(search) ||
        k.description.toLowerCase().includes(search) ||
        tags.some((t: string) => t.toLowerCase().includes(search))
      );
    });
  }, [promptKits, searchKits]);

  const filteredMappings = useMemo(() => {
    const mappings = Array.from(usageMappings.values());
    if (!searchMappings) return mappings;
    
    const search = searchMappings.toLowerCase();
    return mappings.filter((m: UsageMapping) => 
      m.targetType.toLowerCase().includes(search) ||
      m.targetRef.toLowerCase().includes(search) ||
      m.notes.toLowerCase().includes(search)
    );
  }, [usageMappings, searchMappings]);

  const handleExportPlaybook = () => {
    const playbook = exportCognitivePlaybook(
      Array.from(cognitivePatterns.values()),
      Array.from(promptTemplates.values()),
      Array.from(promptKits.values()),
      Array.from(usageMappings.values())
    );
    
    const blob = new Blob([playbook], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'dreamnet-cognitive-playbook.md';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (!connected) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
        <Card className="bg-zinc-900 border-zinc-800 max-w-md w-full">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Sparkles className="h-5 w-5 text-purple-500" />
              DreamNet Cognitive Forge
            </CardTitle>
            <CardDescription className="text-zinc-400">{statusMessage}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold flex items-center gap-3">
              <Sparkles className="h-8 w-8 text-purple-500" />
              DreamNet Cognitive Forge
            </h1>
            <p className="text-zinc-400 mt-2">
              Design the thinking patterns and prompt frameworks for your AI ecosystem
            </p>
            {usingLocalStorage && (
              <p className="text-xs text-zinc-500 mt-1 flex items-center gap-1">
                <span className="inline-block w-2 h-2 rounded-full bg-green-500"></span>
                Local Storage Mode
              </p>
            )}
          </div>
          
          <div className="flex gap-2">
            <Button
              onClick={() => setShowSettings(true)}
              size="lg"
              variant="outline"
              className="border-zinc-700 hover:bg-zinc-800"
            >
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </Button>
            <Button
              onClick={handleExportPlaybook}
              size="lg"
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              <Download className="h-4 w-4 mr-2" />
              Export Playbook
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-zinc-900 border-zinc-800">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-zinc-400 text-sm">
                <Brain className="h-4 w-4" />
                <span>Patterns</span>
              </div>
              <p className="text-2xl font-bold text-white mt-1">{cognitivePatterns.size}</p>
            </CardContent>
          </Card>
          
          <Card className="bg-zinc-900 border-zinc-800">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-zinc-400 text-sm">
                <FileText className="h-4 w-4" />
                <span>Templates</span>
              </div>
              <p className="text-2xl font-bold text-white mt-1">{promptTemplates.size}</p>
            </CardContent>
          </Card>
          
          <Card className="bg-zinc-900 border-zinc-800">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-zinc-400 text-sm">
                <Package className="h-4 w-4" />
                <span>Kits</span>
              </div>
              <p className="text-2xl font-bold text-white mt-1">{promptKits.size}</p>
            </CardContent>
          </Card>
          
          <Card className="bg-zinc-900 border-zinc-800">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-zinc-400 text-sm">
                <GitBranch className="h-4 w-4" />
                <span>Mappings</span>
              </div>
              <p className="text-2xl font-bold text-white mt-1">{usageMappings.size}</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="patterns" className="space-y-4">
          <TabsList className="bg-zinc-900 border border-zinc-800">
            <TabsTrigger value="patterns" className="data-[state=active]:bg-purple-600">
              <Brain className="h-4 w-4 mr-2" />
              Patterns
            </TabsTrigger>
            <TabsTrigger value="templates" className="data-[state=active]:bg-purple-600">
              <FileText className="h-4 w-4 mr-2" />
              Templates
            </TabsTrigger>
            <TabsTrigger value="kits" className="data-[state=active]:bg-purple-600">
              <Package className="h-4 w-4 mr-2" />
              Kits
            </TabsTrigger>
            <TabsTrigger value="mappings" className="data-[state=active]:bg-purple-600">
              <GitBranch className="h-4 w-4 mr-2" />
              Mappings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="patterns" className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-zinc-400" />
                <Input
                  placeholder="Search patterns..."
                  value={searchPatterns}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchPatterns(e.target.value)}
                  className="pl-10 bg-zinc-900 border-zinc-800 text-white"
                />
              </div>
              <Button
                onClick={() => setShowPatternDialog(true)}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Pattern
              </Button>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredPatterns.map((pattern: CognitivePattern) => {
                const tags = parseJSON<string>(pattern.tags);
                const useCases = parseJSON<string>(pattern.useCases);
                
                return (
                  <Card
                    key={pattern.id}
                    className="bg-zinc-900 border-zinc-800 cursor-pointer hover:border-purple-600 transition-colors"
                    onClick={() => setSelectedPattern(pattern)}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-white text-lg">{pattern.name}</CardTitle>
                          <Badge variant="outline" className="mt-2 border-purple-600 text-purple-400">
                            {pattern.code}
                          </Badge>
                        </div>
                        <Brain className="h-5 w-5 text-purple-500" />
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-zinc-400 text-sm line-clamp-2 mb-3">
                        {pattern.description}
                      </p>
                      {useCases.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {useCases.slice(0, 2).map((useCase: string, idx: number) => (
                            <Badge key={idx} variant="secondary" className="text-xs bg-zinc-800 text-zinc-300">
                              {useCase}
                            </Badge>
                          ))}
                          {useCases.length > 2 && (
                            <Badge variant="secondary" className="text-xs bg-zinc-800 text-zinc-300">
                              +{useCases.length - 2} more
                            </Badge>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
              
              {filteredPatterns.length === 0 && (
                <div className="col-span-full text-center py-12 text-zinc-400">
                  No patterns found. Create your first thinking pattern!
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="templates" className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-zinc-400" />
                <Input
                  placeholder="Search templates..."
                  value={searchTemplates}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchTemplates(e.target.value)}
                  className="pl-10 bg-zinc-900 border-zinc-800 text-white"
                />
              </div>
              <Button
                onClick={() => setShowTemplateDialog(true)}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Template
              </Button>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredTemplates.map((template: PromptTemplate) => {
                const tags = parseJSON<string>(template.tags);
                const variables = parseJSON<string>(template.variables);
                
                return (
                  <Card
                    key={template.id}
                    className="bg-zinc-900 border-zinc-800 cursor-pointer hover:border-purple-600 transition-colors"
                    onClick={() => setSelectedTemplate(template)}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-white text-lg">{template.name}</CardTitle>
                          <div className="flex gap-2 mt-2">
                            <Badge variant="outline" className="border-purple-600 text-purple-400">
                              {template.code}
                            </Badge>
                            <Badge variant="outline" className="border-blue-600 text-blue-400">
                              {template.domain}
                            </Badge>
                          </div>
                        </div>
                        <FileText className="h-5 w-5 text-blue-500" />
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-zinc-400 text-sm line-clamp-2 mb-3">
                        {template.description}
                      </p>
                      <div className="flex items-center justify-between text-xs text-zinc-500">
                        <span>{template.targetEnvironment}</span>
                        <span>{variables.length} vars</span>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
              
              {filteredTemplates.length === 0 && (
                <div className="col-span-full text-center py-12 text-zinc-400">
                  No templates found. Create your first prompt template!
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="kits" className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-zinc-400" />
                <Input
                  placeholder="Search kits..."
                  value={searchKits}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchKits(e.target.value)}
                  className="pl-10 bg-zinc-900 border-zinc-800 text-white"
                />
              </div>
              <Button
                onClick={() => setShowKitDialog(true)}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Kit
              </Button>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredKits.map((kit: PromptKit) => {
                const tags = parseJSON<string>(kit.tags);
                
                return (
                  <Card
                    key={kit.id}
                    className="bg-zinc-900 border-zinc-800 cursor-pointer hover:border-purple-600 transition-colors"
                    onClick={() => setSelectedKit(kit)}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-white text-lg">{kit.name}</CardTitle>
                          <Badge variant="outline" className="mt-2 border-green-600 text-green-400">
                            {kit.domain}
                          </Badge>
                        </div>
                        <Package className="h-5 w-5 text-green-500" />
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-zinc-400 text-sm line-clamp-2">
                        {kit.description}
                      </p>
                    </CardContent>
                  </Card>
                );
              })}
              
              {filteredKits.length === 0 && (
                <div className="col-span-full text-center py-12 text-zinc-400">
                  No kits found. Create your first prompt kit!
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="mappings" className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-zinc-400" />
                <Input
                  placeholder="Search mappings..."
                  value={searchMappings}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchMappings(e.target.value)}
                  className="pl-10 bg-zinc-900 border-zinc-800 text-white"
                />
              </div>
              <Button
                onClick={() => setShowMappingDialog(true)}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Mapping
              </Button>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredMappings.map((mapping: UsageMapping) => (
                <Card
                  key={mapping.id}
                  className="bg-zinc-900 border-zinc-800 cursor-pointer hover:border-purple-600 transition-colors"
                  onClick={() => setSelectedMapping(mapping)}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-white text-lg">{mapping.targetRef}</CardTitle>
                        <Badge variant="outline" className="mt-2 border-orange-600 text-orange-400">
                          {mapping.targetType}
                        </Badge>
                      </div>
                      <GitBranch className="h-5 w-5 text-orange-500" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    {mapping.primaryPatternId && (
                      <p className="text-zinc-400 text-sm">
                        Pattern: {cognitivePatterns.get(mapping.primaryPatternId)?.name || 'Unknown'}
                      </p>
                    )}
                  </CardContent>
                </Card>
              ))}
              
              {filteredMappings.length === 0 && (
                <div className="col-span-full text-center py-12 text-zinc-400">
                  No mappings found. Create your first usage mapping!
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {showSettings && (
        <SettingsDialog
          open={showSettings}
          onOpenChange={setShowSettings}
          onConfigSaved={handleConfigSaved}
        />
      )}

      {showPatternDialog && (
        <PatternDialog
          connection={connection}
          patterns={Array.from(cognitivePatterns.values())}
          usingLocalStorage={usingLocalStorage}
          onClose={() => setShowPatternDialog(false)}
        />
      )}

      {showTemplateDialog && (
        <TemplateDialog
          connection={connection}
          patterns={Array.from(cognitivePatterns.values())}
          usingLocalStorage={usingLocalStorage}
          onClose={() => setShowTemplateDialog(false)}
        />
      )}

      {showKitDialog && (
        <KitDialog
          connection={connection}
          patterns={Array.from(cognitivePatterns.values())}
          templates={Array.from(promptTemplates.values())}
          usingLocalStorage={usingLocalStorage}
          onClose={() => setShowKitDialog(false)}
        />
      )}

      {showMappingDialog && (
        <MappingDialog
          connection={connection}
          patterns={Array.from(cognitivePatterns.values())}
          templates={Array.from(promptTemplates.values())}
          usingLocalStorage={usingLocalStorage}
          onClose={() => setShowMappingDialog(false)}
        />
      )}

      {selectedPattern && (
        <PatternDetailDialog
          pattern={selectedPattern}
          connection={connection}
          templates={Array.from(promptTemplates.values())}
          kits={Array.from(promptKits.values())}
          mappings={Array.from(usageMappings.values())}
          allPatterns={Array.from(cognitivePatterns.values())}
          usingLocalStorage={usingLocalStorage}
          onClose={() => setSelectedPattern(null)}
        />
      )}

      {selectedTemplate && (
        <TemplateDetailDialog
          template={selectedTemplate}
          connection={connection}
          patterns={Array.from(cognitivePatterns.values())}
          kits={Array.from(promptKits.values())}
          usingLocalStorage={usingLocalStorage}
          onClose={() => setSelectedTemplate(null)}
        />
      )}

      {selectedKit && (
        <KitDetailDialog
          kit={selectedKit}
          connection={connection}
          patterns={Array.from(cognitivePatterns.values())}
          templates={Array.from(promptTemplates.values())}
          usingLocalStorage={usingLocalStorage}
          onClose={() => setSelectedKit(null)}
        />
      )}

      {selectedMapping && (
        <MappingDetailDialog
          mapping={selectedMapping}
          connection={connection}
          patterns={Array.from(cognitivePatterns.values())}
          templates={Array.from(promptTemplates.values())}
          usingLocalStorage={usingLocalStorage}
          onClose={() => setSelectedMapping(null)}
        />
      )}
    </div>
  );
}
