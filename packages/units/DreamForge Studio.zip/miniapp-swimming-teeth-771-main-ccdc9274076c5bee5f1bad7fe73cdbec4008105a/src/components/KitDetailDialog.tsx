'use client';

import { useState, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { Copy, FileText } from 'lucide-react';
import type { DbConnection, CognitivePattern, PromptTemplate, PromptKit } from '../spacetime_module_bindings';
import { generatePromptKitGuide, getPatternsForKit, getTemplatesForKit, parseJSON } from '../lib/promptUtils';
import { useSpacetimeDB } from '../hooks/useSpacetimeDB';

interface KitDetailDialogProps {
  kit: PromptKit;
  connection: DbConnection | null;
  patterns: CognitivePattern[];
  templates: PromptTemplate[];
  onClose: () => void;
}

export function KitDetailDialog({ 
  kit, 
  patterns,
  templates,
  onClose 
}: KitDetailDialogProps) {
  const { kitTemplates, kitPatterns } = useSpacetimeDB();
  const [showGuide, setShowGuide] = useState<boolean>(false);

  const kitTemplatesList = useMemo(() => {
    return getTemplatesForKit(kit.id, kitTemplates, new Map(templates.map((t: PromptTemplate) => [t.id, t])));
  }, [kit.id, kitTemplates, templates]);

  const kitPatternsList = useMemo(() => {
    return getPatternsForKit(kit.id, kitPatterns, new Map(patterns.map((p: CognitivePattern) => [p.id, p])));
  }, [kit.id, kitPatterns, patterns]);

  const tags = parseJSON<string>(kit.tags);

  const guide = useMemo(() => {
    return generatePromptKitGuide(kit, kitTemplatesList, kitPatternsList);
  }, [kit, kitTemplatesList, kitPatternsList]);

  const copyGuide = () => {
    navigator.clipboard.writeText(guide);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div>
              <DialogTitle className="text-2xl">{kit.name}</DialogTitle>
              <Badge variant="outline" className="mt-2 border-green-600 text-green-400">
                {kit.domain}
              </Badge>
            </div>
            <Button
              onClick={() => setShowGuide(!showGuide)}
              variant="outline"
              className="border-zinc-700"
            >
              <FileText className="h-4 w-4 mr-2" />
              {showGuide ? 'Hide' : 'Show'} Guide
            </Button>
          </div>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {showGuide ? (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="font-semibold">Kit Guide</h3>
                <Button
                  onClick={copyGuide}
                  size="sm"
                  variant="outline"
                  className="border-zinc-700"
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy
                </Button>
              </div>
              <Textarea
                value={guide}
                readOnly
                className="bg-zinc-800 border-zinc-700 text-white min-h-[400px] font-mono text-sm"
              />
            </div>
          ) : (
            <>
              {kit.description && (
                <div>
                  <h3 className="font-semibold mb-2">Description</h3>
                  <p className="text-zinc-400">{kit.description}</p>
                </div>
              )}

              {kitPatternsList.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Patterns ({kitPatternsList.length})</h3>
                  <div className="space-y-2">
                    {kitPatternsList.map((pattern: CognitivePattern) => (
                      <div key={pattern.id} className="bg-zinc-800 p-3 rounded-lg">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{pattern.name}</p>
                            <p className="text-sm text-zinc-400">{pattern.code}</p>
                          </div>
                          <Badge variant="outline" className="border-purple-600 text-purple-400">
                            Pattern
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {kitTemplatesList.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Templates ({kitTemplatesList.length})</h3>
                  <div className="space-y-2">
                    {kitTemplatesList.map((template: PromptTemplate) => (
                      <div key={template.id} className="bg-zinc-800 p-3 rounded-lg">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{template.name}</p>
                            <p className="text-sm text-zinc-400">{template.code} • {template.domain}</p>
                          </div>
                          <Badge variant="outline" className="border-blue-600 text-blue-400">
                            {template.targetEnvironment}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {tags.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Tags</h3>
                  <div className="flex flex-wrap gap-2">
                    {tags.map((tag: string, idx: number) => (
                      <Badge key={idx} className="bg-green-600/20 text-green-400">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {kit.notes && (
                <div>
                  <h3 className="font-semibold mb-2">Notes</h3>
                  <p className="text-zinc-400 whitespace-pre-wrap">{kit.notes}</p>
                </div>
              )}

              <div className="border-t border-zinc-800 pt-4">
                <p className="text-sm text-zinc-500">
                  Created: {new Date(Number(kit.createdAt) / 1000).toLocaleString()}
                </p>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
