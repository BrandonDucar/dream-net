'use client';

import { useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Badge } from './ui/badge';
import type { DbConnection, CognitivePattern, PromptTemplate, UsageMapping } from '../spacetime_module_bindings';
import { getTemplatesForMapping } from '../lib/promptUtils';
import { useSpacetimeDB } from '../hooks/useSpacetimeDB';

interface MappingDetailDialogProps {
  mapping: UsageMapping;
  connection: DbConnection | null;
  patterns: CognitivePattern[];
  templates: PromptTemplate[];
  onClose: () => void;
}

export function MappingDetailDialog({ 
  mapping, 
  patterns,
  templates,
  onClose 
}: MappingDetailDialogProps) {
  const { mappingTemplates } = useSpacetimeDB();

  const primaryPattern = useMemo(() => {
    if (!mapping.primaryPatternId) return null;
    return patterns.find((p: CognitivePattern) => p.id === mapping.primaryPatternId);
  }, [patterns, mapping.primaryPatternId]);

  const mappingTemplatesList = useMemo(() => {
    return getTemplatesForMapping(mapping.id, mappingTemplates, new Map(templates.map((t: PromptTemplate) => [t.id, t])));
  }, [mapping.id, mappingTemplates, templates]);

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div>
              <DialogTitle className="text-2xl">{mapping.targetRef}</DialogTitle>
              <Badge variant="outline" className="mt-2 border-orange-600 text-orange-400">
                {mapping.targetType}
              </Badge>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {primaryPattern && (
            <div>
              <h3 className="font-semibold mb-2">Primary Pattern</h3>
              <div className="bg-zinc-800 p-3 rounded-lg">
                <p className="font-medium">{primaryPattern.name}</p>
                <p className="text-sm text-zinc-400">{primaryPattern.code}</p>
                <p className="text-sm text-zinc-500 mt-2">{primaryPattern.description}</p>
              </div>
            </div>
          )}

          {mappingTemplatesList.length > 0 && (
            <div>
              <h3 className="font-semibold mb-2">Linked Templates ({mappingTemplatesList.length})</h3>
              <div className="space-y-2">
                {mappingTemplatesList.map((template: PromptTemplate) => (
                  <div key={template.id} className="bg-zinc-800 p-3 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">{template.name}</p>
                        <p className="text-sm text-zinc-400">{template.code} • {template.domain}</p>
                      </div>
                      <Badge variant="outline" className="border-blue-600 text-blue-400">
                        {template.targetEnvironment}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {mapping.notes && (
            <div>
              <h3 className="font-semibold mb-2">Notes</h3>
              <p className="text-zinc-400 whitespace-pre-wrap">{mapping.notes}</p>
            </div>
          )}

          <div className="border-t border-zinc-800 pt-4">
            <p className="text-sm text-zinc-500">
              Created: {new Date(Number(mapping.createdAt) / 1000).toLocaleString()}
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
