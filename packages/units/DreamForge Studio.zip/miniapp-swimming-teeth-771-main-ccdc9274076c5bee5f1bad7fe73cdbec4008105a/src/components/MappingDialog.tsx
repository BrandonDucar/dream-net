'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import type { DbConnection, CognitivePattern, PromptTemplate } from '../spacetime_module_bindings';

interface MappingDialogProps {
  connection: DbConnection | null;
  patterns: CognitivePattern[];
  templates: PromptTemplate[];
  onClose: () => void;
}

export function MappingDialog({ connection, patterns, onClose }: MappingDialogProps) {
  const [targetType, setTargetType] = useState<string>('agent');
  const [targetRef, setTargetRef] = useState<string>('');
  const [primaryPatternId, setPrimaryPatternId] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [error, setError] = useState<string>('');

  const handleSubmit = () => {
    if (!connection) {
      setError('Not connected to database');
      return;
    }

    if (!targetRef.trim()) {
      setError('Target reference is required');
      return;
    }

    const id = `mapping_${Date.now()}`;

    connection.reducers.createUsageMapping(
      id,
      targetType,
      targetRef,
      primaryPatternId || undefined,
      notes
    );

    onClose();
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-2xl">
        <DialogHeader>
          <DialogTitle>Create Usage Mapping</DialogTitle>
          <DialogDescription className="text-zinc-400">
            Map patterns and templates to agents, apps, or workflows
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="targetType">Target Type *</Label>
            <Select value={targetType} onValueChange={setTargetType}>
              <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-zinc-800 border-zinc-700 text-white">
                <SelectItem value="agent">Agent</SelectItem>
                <SelectItem value="mini-app">Mini-App</SelectItem>
                <SelectItem value="flow">Flow</SelectItem>
                <SelectItem value="scenario">Scenario</SelectItem>
                <SelectItem value="task-type">Task Type</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="targetRef">Target Reference *</Label>
            <Input
              id="targetRef"
              value={targetRef}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTargetRef(e.target.value)}
              placeholder="e.g., Culture Agent, Drop Planner App"
              className="bg-zinc-800 border-zinc-700 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="pattern">Primary Pattern (optional)</Label>
            <Select value={primaryPatternId} onValueChange={setPrimaryPatternId}>
              <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white">
                <SelectValue placeholder="Select a pattern" />
              </SelectTrigger>
              <SelectContent className="bg-zinc-800 border-zinc-700 text-white">
                <SelectItem value="">None</SelectItem>
                {patterns.map((pattern: CognitivePattern) => (
                  <SelectItem key={pattern.id} value={pattern.id}>
                    {pattern.name} ({pattern.code})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNotes(e.target.value)}
              placeholder="Usage instructions or wiring notes..."
              className="bg-zinc-800 border-zinc-700 text-white min-h-[80px]"
            />
          </div>

          {error && (
            <p className="text-red-500 text-sm">{error}</p>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} className="border-zinc-700">
            Cancel
          </Button>
          <Button onClick={handleSubmit} className="bg-purple-600 hover:bg-purple-700 text-white">
            Create Mapping
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
