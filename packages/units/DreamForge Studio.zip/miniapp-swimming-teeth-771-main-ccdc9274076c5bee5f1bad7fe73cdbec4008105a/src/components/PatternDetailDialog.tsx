'use client';

import { useState, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { Copy, FileText, GitBranch, FlaskConical, Download } from 'lucide-react';
import type { DbConnection, CognitivePattern, PromptTemplate, PromptKit, UsageMapping } from '../spacetime_module_bindings';
import { generatePatternGuide, parseJSON } from '../lib/promptUtils';
import { generateFlowDiagram, generateFlowDiagramSVG, buildInheritanceTree } from '../lib/flowDiagram';
import { DEFAULT_EXPORT_FORMATS, exportPatternToFormat } from '../lib/exportFormatters';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface PatternDetailDialogProps {
  pattern: CognitivePattern;
  connection: DbConnection | null;
  templates: PromptTemplate[];
  kits: PromptKit[];
  mappings: UsageMapping[];
  allPatterns: CognitivePattern[];
  onClose: () => void;
}

export function PatternDetailDialog({ 
  pattern, 
  templates, 
  kits,
  mappings,
  allPatterns,
  onClose 
}: PatternDetailDialogProps) {
  const [showGuide, setShowGuide] = useState<boolean>(false);
  const [showFlowDiagram, setShowFlowDiagram] = useState<boolean>(false);
  const [showInheritance, setShowInheritance] = useState<boolean>(false);
  const [showExport, setShowExport] = useState<boolean>(false);
  const [selectedFormat, setSelectedFormat] = useState<string>('openai-gpt');

  const relatedTemplates = useMemo(() => {
    return templates.filter((t: PromptTemplate) => t.patternId === pattern.id);
  }, [templates, pattern.id]);

  const relatedMappings = useMemo(() => {
    return mappings.filter((m: UsageMapping) => m.primaryPatternId === pattern.id);
  }, [mappings, pattern.id]);

  const useCases = parseJSON<string>(pattern.useCases);
  const steps = parseJSON<string>(pattern.steps);
  const recommendedAgents = parseJSON<string>(pattern.recommendedAgents);
  const tags = parseJSON<string>(pattern.tags);

  const guide = useMemo(() => {
    return generatePatternGuide(pattern, relatedTemplates, kits, relatedMappings);
  }, [pattern, relatedTemplates, kits, relatedMappings]);

  const flowDiagram = useMemo(() => {
    return generateFlowDiagram(pattern);
  }, [pattern]);

  const flowDiagramSVG = useMemo(() => {
    return generateFlowDiagramSVG(flowDiagram);
  }, [flowDiagram]);

  const parentPattern = useMemo(() => {
    if (!pattern.parentPatternId) return null;
    return allPatterns.find((p: CognitivePattern) => p.id === pattern.parentPatternId);
  }, [pattern.parentPatternId, allPatterns]);

  const childPatterns = useMemo(() => {
    return allPatterns.filter((p: CognitivePattern) => p.parentPatternId === pattern.id);
  }, [pattern.id, allPatterns]);

  const exportedContent = useMemo(() => {
    const format = DEFAULT_EXPORT_FORMATS.find((f) => f.format === selectedFormat);
    if (!format) return '';
    const relatedTemplate = relatedTemplates[0] || null;
    return exportPatternToFormat(pattern, relatedTemplate, format);
  }, [pattern, relatedTemplates, selectedFormat]);

  const copyGuide = () => {
    navigator.clipboard.writeText(guide);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div>
              <DialogTitle className="text-2xl">{pattern.name}</DialogTitle>
              <Badge variant="outline" className="mt-2 border-purple-600 text-purple-400">
                {pattern.code}
              </Badge>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => { setShowGuide(!showGuide); setShowFlowDiagram(false); setShowInheritance(false); setShowExport(false); }}
                variant="outline"
                className="border-zinc-700"
                size="sm"
              >
                <FileText className="h-4 w-4 mr-2" />
                Guide
              </Button>
              <Button
                onClick={() => { setShowFlowDiagram(!showFlowDiagram); setShowGuide(false); setShowInheritance(false); setShowExport(false); }}
                variant="outline"
                className="border-zinc-700"
                size="sm"
              >
                <GitBranch className="h-4 w-4 mr-2" />
                Flow
              </Button>
              {(parentPattern || childPatterns.length > 0) && (
                <Button
                  onClick={() => { setShowInheritance(!showInheritance); setShowGuide(false); setShowFlowDiagram(false); setShowExport(false); }}
                  variant="outline"
                  className="border-zinc-700"
                  size="sm"
                >
                  <FlaskConical className="h-4 w-4 mr-2" />
                  Inheritance
                </Button>
              )}
              <Button
                onClick={() => { setShowExport(!showExport); setShowGuide(false); setShowFlowDiagram(false); setShowInheritance(false); }}
                variant="outline"
                className="border-zinc-700"
                size="sm"
              >
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {showExport ? (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="font-semibold">Export Pattern</h3>
                <div className="flex gap-2 items-center">
                  <Select value={selectedFormat} onValueChange={setSelectedFormat}>
                    <SelectTrigger className="w-48 bg-zinc-800 border-zinc-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-900 border-zinc-800">
                      {DEFAULT_EXPORT_FORMATS.map((fmt) => (
                        <SelectItem key={fmt.format} value={fmt.format}>
                          {fmt.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    onClick={() => navigator.clipboard.writeText(exportedContent)}
                    size="sm"
                    variant="outline"
                    className="border-zinc-700"
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Copy
                  </Button>
                </div>
              </div>
              <Textarea
                value={exportedContent}
                readOnly
                className="bg-zinc-800 border-zinc-700 text-white min-h-[400px] font-mono text-sm"
              />
            </div>
          ) : showFlowDiagram ? (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="font-semibold">Visual Flow Diagram</h3>
                <Button
                  onClick={() => {
                    const blob = new Blob([flowDiagramSVG], { type: 'image/svg+xml' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `${pattern.code}-flow-diagram.svg`;
                    a.click();
                    URL.revokeObjectURL(url);
                  }}
                  size="sm"
                  variant="outline"
                  className="border-zinc-700"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Save SVG
                </Button>
              </div>
              <div className="bg-zinc-950 p-4 rounded-lg overflow-auto" dangerouslySetInnerHTML={{ __html: flowDiagramSVG }} />
            </div>
          ) : showInheritance ? (
            <div className="space-y-4">
              <h3 className="font-semibold">Inheritance Tree</h3>
              <div className="space-y-3">
                {parentPattern && (
                  <div className="bg-zinc-800 p-4 rounded-lg border-l-4 border-blue-600">
                    <p className="text-sm text-zinc-400 mb-1">Parent Pattern</p>
                    <p className="font-medium">{parentPattern.name}</p>
                    <Badge variant="outline" className="mt-2 border-blue-600 text-blue-400">
                      {parentPattern.code}
                    </Badge>
                  </div>
                )}
                <div className="bg-zinc-800 p-4 rounded-lg border-l-4 border-purple-600">
                  <p className="text-sm text-zinc-400 mb-1">Current Pattern</p>
                  <p className="font-medium">{pattern.name}</p>
                  <Badge variant="outline" className="mt-2 border-purple-600 text-purple-400">
                    {pattern.code}
                  </Badge>
                </div>
                {childPatterns.length > 0 && (
                  <div>
                    <p className="text-sm text-zinc-400 mb-2">Child Patterns ({childPatterns.length})</p>
                    <div className="space-y-2">
                      {childPatterns.map((child: CognitivePattern) => (
                        <div key={child.id} className="bg-zinc-800 p-3 rounded-lg border-l-4 border-green-600">
                          <p className="font-medium text-sm">{child.name}</p>
                          <Badge variant="outline" className="mt-1 text-xs border-green-600 text-green-400">
                            {child.code}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : showGuide ? (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="font-semibold">Pattern Guide</h3>
                <Button
                  onClick={copyGuide}
                  size="sm"
                  variant="outline"
                  className="border-zinc-700"
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy
                </Button>
              </div>
              <Textarea
                value={guide}
                readOnly
                className="bg-zinc-800 border-zinc-700 text-white min-h-[400px] font-mono text-sm"
              />
            </div>
          ) : (
            <>
              <div>
                <h3 className="font-semibold mb-2">Description</h3>
                <p className="text-zinc-400">{pattern.description}</p>
              </div>

              {useCases.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Use Cases</h3>
                  <div className="flex flex-wrap gap-2">
                    {useCases.map((useCase: string, idx: number) => (
                      <Badge key={idx} variant="secondary" className="bg-zinc-800 text-zinc-300">
                        {useCase}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {steps.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Reasoning Steps</h3>
                  <ol className="list-decimal list-inside space-y-2 text-zinc-400">
                    {steps.map((step: string, idx: number) => (
                      <li key={idx}>{step}</li>
                    ))}
                  </ol>
                </div>
              )}

              {recommendedAgents.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Recommended Agents</h3>
                  <div className="flex flex-wrap gap-2">
                    {recommendedAgents.map((agent: string, idx: number) => (
                      <Badge key={idx} variant="outline" className="border-blue-600 text-blue-400">
                        {agent}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {tags.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Tags</h3>
                  <div className="flex flex-wrap gap-2">
                    {tags.map((tag: string, idx: number) => (
                      <Badge key={idx} className="bg-purple-600/20 text-purple-400">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {relatedTemplates.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Related Templates ({relatedTemplates.length})</h3>
                  <div className="space-y-2">
                    {relatedTemplates.map((template: PromptTemplate) => (
                      <div key={template.id} className="bg-zinc-800 p-3 rounded-lg">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{template.name}</p>
                            <p className="text-sm text-zinc-400">{template.code} • {template.domain}</p>
                          </div>
                          <Badge variant="outline" className="border-blue-600 text-blue-400">
                            {template.targetEnvironment}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {relatedMappings.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Usage Mappings ({relatedMappings.length})</h3>
                  <div className="space-y-2">
                    {relatedMappings.map((mapping: UsageMapping) => (
                      <div key={mapping.id} className="bg-zinc-800 p-3 rounded-lg">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{mapping.targetRef}</p>
                            <p className="text-sm text-zinc-400">{mapping.notes}</p>
                          </div>
                          <Badge variant="outline" className="border-orange-600 text-orange-400">
                            {mapping.targetType}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {pattern.notes && (
                <div>
                  <h3 className="font-semibold mb-2">Notes</h3>
                  <p className="text-zinc-400 whitespace-pre-wrap">{pattern.notes}</p>
                </div>
              )}

              <div className="border-t border-zinc-800 pt-4">
                <p className="text-sm text-zinc-500">
                  Created: {new Date(Number(pattern.createdAt) / 1000).toLocaleString()}
                </p>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
