'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import type { DbConnection, CognitivePattern } from '../spacetime_module_bindings';

interface PatternDialogProps {
  connection: DbConnection | null;
  patterns: CognitivePattern[];
  onClose: () => void;
}

export function PatternDialog({ connection, patterns, onClose }: PatternDialogProps) {
  const [name, setName] = useState<string>('');
  const [code, setCode] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [useCases, setUseCases] = useState<string>('');
  const [steps, setSteps] = useState<string>('');
  const [recommendedAgents, setRecommendedAgents] = useState<string>('');
  const [tags, setTags] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [seoTitle, setSeoTitle] = useState<string>('');
  const [seoDescription, setSeoDescription] = useState<string>('');
  const [seoKeywords, setSeoKeywords] = useState<string>('');
  const [seoHashtags, setSeoHashtags] = useState<string>('');
  const [altText, setAltText] = useState<string>('');
  const [parentPatternId, setParentPatternId] = useState<string>('');
  const [error, setError] = useState<string>('');

  const handleSubmit = () => {
    if (!connection) {
      setError('Not connected to database');
      return;
    }

    if (!name.trim() || !code.trim() || !description.trim()) {
      setError('Name, code, and description are required');
      return;
    }

    const useCasesArray = useCases.split(',').map((u: string) => u.trim()).filter((u: string) => u);
    const stepsArray = steps.split('\n').map((s: string) => s.trim()).filter((s: string) => s);
    const agentsArray = recommendedAgents.split(',').map((a: string) => a.trim()).filter((a: string) => a);
    const tagsArray = tags.split(',').map((t: string) => t.trim()).filter((t: string) => t);
    const keywordsArray = seoKeywords.split(',').map((k: string) => k.trim()).filter((k: string) => k);
    const hashtagsArray = seoHashtags.split(',').map((h: string) => h.trim()).filter((h: string) => h);

    const id = `pattern_${Date.now()}`;

    connection.reducers.createCognitivePattern(
      id,
      name,
      code,
      description,
      JSON.stringify(useCasesArray),
      JSON.stringify(stepsArray),
      JSON.stringify(agentsArray),
      JSON.stringify(tagsArray),
      notes,
      parentPatternId || undefined,
      seoTitle || name,
      seoDescription || description,
      JSON.stringify(keywordsArray),
      JSON.stringify(hashtagsArray),
      altText || name
    );

    onClose();
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Cognitive Pattern</DialogTitle>
          <DialogDescription className="text-zinc-400">
            Define a new thinking pattern or reasoning framework
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
              placeholder="e.g., 4D Reasoning Loop"
              className="bg-zinc-800 border-zinc-700 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="code">Code *</Label>
            <Input
              id="code"
              value={code}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCode(e.target.value)}
              placeholder="e.g., 4D_LOOP"
              className="bg-zinc-800 border-zinc-700 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
              placeholder="Describe the cognitive pattern..."
              className="bg-zinc-800 border-zinc-700 text-white min-h-[80px]"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="useCases">Use Cases (comma-separated)</Label>
            <Input
              id="useCases"
              value={useCases}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setUseCases(e.target.value)}
              placeholder="planning flows, evaluating drops, daily ops"
              className="bg-zinc-800 border-zinc-700 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="steps">Reasoning Steps (one per line)</Label>
            <Textarea
              id="steps"
              value={steps}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setSteps(e.target.value)}
              placeholder="Deconstruct&#10;Diagnose&#10;Develop&#10;Deliver"
              className="bg-zinc-800 border-zinc-700 text-white min-h-[100px]"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="agents">Recommended Agents (comma-separated)</Label>
            <Input
              id="agents"
              value={recommendedAgents}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setRecommendedAgents(e.target.value)}
              placeholder="Agent Mesh, Culture Agent, Ops Agent"
              className="bg-zinc-800 border-zinc-700 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="tags">Tags (comma-separated)</Label>
            <Input
              id="tags"
              value={tags}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTags(e.target.value)}
              placeholder="reasoning, planning, strategy"
              className="bg-zinc-800 border-zinc-700 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="parentPattern">Parent Pattern (Inheritance)</Label>
            <Select value={parentPatternId} onValueChange={setParentPatternId}>
              <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white">
                <SelectValue placeholder="None - standalone pattern" />
              </SelectTrigger>
              <SelectContent className="bg-zinc-900 border-zinc-800">
                <SelectItem value="">None - standalone pattern</SelectItem>
                {patterns.map((p: CognitivePattern) => (
                  <SelectItem key={p.id} value={p.id}>
                    {p.name} ({p.code})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNotes(e.target.value)}
              placeholder="Additional notes..."
              className="bg-zinc-800 border-zinc-700 text-white"
            />
          </div>

          <div className="border-t border-zinc-800 pt-4 space-y-4">
            <h4 className="font-semibold text-sm">SEO Metadata</h4>
            
            <div className="space-y-2">
              <Label htmlFor="seoTitle">SEO Title</Label>
              <Input
                id="seoTitle"
                value={seoTitle}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSeoTitle(e.target.value)}
                placeholder="Leave blank to use pattern name"
                className="bg-zinc-800 border-zinc-700 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="seoDescription">SEO Description</Label>
              <Textarea
                id="seoDescription"
                value={seoDescription}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setSeoDescription(e.target.value)}
                placeholder="Leave blank to use pattern description"
                className="bg-zinc-800 border-zinc-700 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="seoKeywords">SEO Keywords (comma-separated)</Label>
              <Input
                id="seoKeywords"
                value={seoKeywords}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSeoKeywords(e.target.value)}
                placeholder="cognitive, pattern, reasoning"
                className="bg-zinc-800 border-zinc-700 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="seoHashtags">SEO Hashtags (comma-separated)</Label>
              <Input
                id="seoHashtags"
                value={seoHashtags}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSeoHashtags(e.target.value)}
                placeholder="#cognitive #AI #patterns"
                className="bg-zinc-800 border-zinc-700 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="altText">Alt Text</Label>
              <Input
                id="altText"
                value={altText}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAltText(e.target.value)}
                placeholder="Leave blank to use pattern name"
                className="bg-zinc-800 border-zinc-700 text-white"
              />
            </div>
          </div>

          {error && (
            <p className="text-red-500 text-sm">{error}</p>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} className="border-zinc-700">
            Cancel
          </Button>
          <Button onClick={handleSubmit} className="bg-purple-600 hover:bg-purple-700 text-white">
            Create Pattern
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
