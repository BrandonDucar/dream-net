'use client'

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import { storageAdapter, type StorageConfig } from '../lib/storageAdapter';
import { Settings, Database, Download, Upload, AlertCircle, CheckCircle2 } from 'lucide-react';

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfigSaved: () => void;
}

export function SettingsDialog({ open, onOpenChange, onConfigSaved }: SettingsDialogProps) {
  const [config, setConfig] = useState<StorageConfig>(storageAdapter.getConfig());
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [importStatus, setImportStatus] = useState<'idle' | 'success' | 'error'>('idle');

  useEffect(() => {
    if (open) {
      setConfig(storageAdapter.getConfig());
      setSaveStatus('idle');
      setImportStatus('idle');
    }
  }, [open]);

  const handleSave = () => {
    try {
      storageAdapter.saveConfig(config);
      setSaveStatus('success');
      setTimeout(() => {
        onConfigSaved();
        onOpenChange(false);
      }, 1000);
    } catch (error) {
      console.error('Failed to save config:', error);
      setSaveStatus('error');
    }
  };

  const handleExport = () => {
    const data = storageAdapter.exportAll();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dreamnet-cognitive-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        storageAdapter.importAll(data);
        setImportStatus('success');
        setTimeout(() => {
          onConfigSaved();
        }, 1000);
      } catch (error) {
        console.error('Failed to import data:', error);
        setImportStatus('error');
      }
    };
    reader.readAsText(file);
  };

  const handleClearAll = () => {
    if (confirm('Are you sure? This will delete all cognitive patterns, templates, kits, and mappings. This action cannot be undone.')) {
      storageAdapter.clearAll();
      onConfigSaved();
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Settings & Configuration
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="storage" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="storage">
              <Database className="w-4 h-4 mr-2" />
              Storage
            </TabsTrigger>
            <TabsTrigger value="backup">
              <Download className="w-4 h-4 mr-2" />
              Backup & Import
            </TabsTrigger>
          </TabsList>

          <TabsContent value="storage" className="space-y-4">
            <div className="space-y-4">
              <div>
                <Label htmlFor="storage-mode">Storage Mode</Label>
                <Select
                  value={config.mode}
                  onValueChange={(value: 'local' | 'spacetime') => 
                    setConfig({ ...config, mode: value })
                  }
                >
                  <SelectTrigger id="storage-mode">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="local">Local Storage (Recommended)</SelectItem>
                    <SelectItem value="spacetime">SpacetimeDB (Advanced)</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-400 mt-1">
                  Local Storage: Data stored in browser, no setup required
                </p>
              </div>

              {config.mode === 'spacetime' && (
                <>
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      SpacetimeDB requires a published module and valid token. Use Local Storage if you haven't set up SpacetimeDB yet.
                    </AlertDescription>
                  </Alert>

                  <div>
                    <Label htmlFor="spacetime-host">SpacetimeDB Host</Label>
                    <Input
                      id="spacetime-host"
                      value={config.spacetimeHost || ''}
                      onChange={(e) => setConfig({ ...config, spacetimeHost: e.target.value })}
                      placeholder="https://testnet.spacetimedb.com"
                    />
                  </div>

                  <div>
                    <Label htmlFor="spacetime-module">Module Name</Label>
                    <Input
                      id="spacetime-module"
                      value={config.spacetimeModuleName || ''}
                      onChange={(e) => setConfig({ ...config, spacetimeModuleName: e.target.value })}
                      placeholder="dreamnet-cognitive-forge"
                    />
                  </div>

                  <div>
                    <Label htmlFor="spacetime-token">Token (Optional)</Label>
                    <Input
                      id="spacetime-token"
                      type="password"
                      value={config.spacetimeToken || ''}
                      onChange={(e) => setConfig({ ...config, spacetimeToken: e.target.value })}
                      placeholder="Your SpacetimeDB token"
                    />
                  </div>
                </>
              )}

              {saveStatus === 'success' && (
                <Alert className="bg-green-900/20 border-green-500">
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                  <AlertDescription className="text-green-300">
                    Configuration saved successfully!
                  </AlertDescription>
                </Alert>
              )}

              {saveStatus === 'error' && (
                <Alert className="bg-red-900/20 border-red-500">
                  <AlertCircle className="h-4 w-4 text-red-500" />
                  <AlertDescription className="text-red-300">
                    Failed to save configuration. Please try again.
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </TabsContent>

          <TabsContent value="backup" className="space-y-4">
            <div className="space-y-4">
              <div>
                <Label>Export Data</Label>
                <p className="text-sm text-gray-400 mb-2">
                  Download all your cognitive patterns, templates, kits, and mappings as JSON
                </p>
                <Button onClick={handleExport} variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Export All Data
                </Button>
              </div>

              <div>
                <Label htmlFor="import-file">Import Data</Label>
                <p className="text-sm text-gray-400 mb-2">
                  Restore from a previously exported backup file
                </p>
                <div className="flex items-center gap-2">
                  <Input
                    id="import-file"
                    type="file"
                    accept=".json"
                    onChange={handleImport}
                    className="flex-1"
                  />
                  <Upload className="w-4 h-4 text-gray-400" />
                </div>
              </div>

              {importStatus === 'success' && (
                <Alert className="bg-green-900/20 border-green-500">
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                  <AlertDescription className="text-green-300">
                    Data imported successfully! Refreshing...
                  </AlertDescription>
                </Alert>
              )}

              {importStatus === 'error' && (
                <Alert className="bg-red-900/20 border-red-500">
                  <AlertCircle className="h-4 w-4 text-red-500" />
                  <AlertDescription className="text-red-300">
                    Failed to import data. Please check the file format.
                  </AlertDescription>
                </Alert>
              )}

              <div className="pt-4 border-t border-gray-700">
                <Label>Danger Zone</Label>
                <p className="text-sm text-gray-400 mb-2">
                  Clear all data from storage (cannot be undone)
                </p>
                <Button 
                  onClick={handleClearAll} 
                  variant="destructive" 
                  className="w-full"
                >
                  Clear All Data
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            Save Configuration
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
