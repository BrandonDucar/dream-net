'use client';

import { useState, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Copy, Wand2 } from 'lucide-react';
import type { DbConnection, CognitivePattern, PromptTemplate, PromptKit } from '../spacetime_module_bindings';
import { fillPromptVariables, parseJSON } from '../lib/promptUtils';

interface TemplateDetailDialogProps {
  template: PromptTemplate;
  connection: DbConnection | null;
  patterns: CognitivePattern[];
  kits: PromptKit[];
  onClose: () => void;
}

export function TemplateDetailDialog({ 
  template, 
  patterns,
  onClose 
}: TemplateDetailDialogProps) {
  const [showFill, setShowFill] = useState<boolean>(false);
  const [variableValues, setVariableValues] = useState<Record<string, string>>({});
  const [filledPrompt, setFilledPrompt] = useState<string>('');

  const variables = parseJSON<string>(template.variables);
  const tags = parseJSON<string>(template.tags);

  const linkedPattern = useMemo(() => {
    if (!template.patternId) return null;
    return patterns.find((p: CognitivePattern) => p.id === template.patternId);
  }, [patterns, template.patternId]);

  const handleVariableChange = (variable: string, value: string) => {
    setVariableValues((prev: Record<string, string>) => ({
      ...prev,
      [variable]: value
    }));
  };

  const handleFillPrompt = () => {
    const filled = fillPromptVariables(template, variableValues);
    setFilledPrompt(filled);
  };

  const copyPrompt = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div>
              <DialogTitle className="text-2xl">{template.name}</DialogTitle>
              <div className="flex gap-2 mt-2">
                <Badge variant="outline" className="border-blue-600 text-blue-400">
                  {template.code}
                </Badge>
                <Badge variant="outline" className="border-green-600 text-green-400">
                  {template.domain}
                </Badge>
                <Badge variant="outline" className="border-purple-600 text-purple-400">
                  {template.targetEnvironment}
                </Badge>
              </div>
            </div>
            {variables.length > 0 && (
              <Button
                onClick={() => setShowFill(!showFill)}
                variant="outline"
                className="border-zinc-700"
              >
                <Wand2 className="h-4 w-4 mr-2" />
                {showFill ? 'Hide' : 'Fill'} Variables
              </Button>
            )}
          </div>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {template.description && (
            <div>
              <h3 className="font-semibold mb-2">Description</h3>
              <p className="text-zinc-400">{template.description}</p>
            </div>
          )}

          {linkedPattern && (
            <div>
              <h3 className="font-semibold mb-2">Linked Pattern</h3>
              <div className="bg-zinc-800 p-3 rounded-lg">
                <p className="font-medium">{linkedPattern.name}</p>
                <p className="text-sm text-zinc-400">{linkedPattern.code}</p>
              </div>
            </div>
          )}

          {variables.length > 0 && (
            <div>
              <h3 className="font-semibold mb-2">Variables ({variables.length})</h3>
              <div className="flex flex-wrap gap-2">
                {variables.map((variable: string, idx: number) => (
                  <Badge key={idx} variant="secondary" className="bg-zinc-800 text-zinc-300 font-mono">
                    {variable}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <div>
            <div className="flex justify-between items-center mb-2">
              <h3 className="font-semibold">Prompt Body</h3>
              <Button
                onClick={() => copyPrompt(template.body)}
                size="sm"
                variant="outline"
                className="border-zinc-700"
              >
                <Copy className="h-4 w-4 mr-2" />
                Copy
              </Button>
            </div>
            <Textarea
              value={template.body}
              readOnly
              className="bg-zinc-800 border-zinc-700 text-white min-h-[200px] font-mono text-sm"
            />
          </div>

          {showFill && variables.length > 0 && (
            <div className="border-t border-zinc-800 pt-4 space-y-4">
              <h3 className="font-semibold">Fill Variables</h3>
              
              {variables.map((variable: string) => (
                <div key={variable} className="space-y-2">
                  <Label htmlFor={variable}>{variable}</Label>
                  <Input
                    id={variable}
                    value={variableValues[variable] || ''}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                      handleVariableChange(variable, e.target.value)
                    }
                    placeholder={`Enter value for ${variable}`}
                    className="bg-zinc-800 border-zinc-700 text-white"
                  />
                </div>
              ))}

              <Button
                onClick={handleFillPrompt}
                className="bg-purple-600 hover:bg-purple-700 text-white w-full"
              >
                <Wand2 className="h-4 w-4 mr-2" />
                Generate Filled Prompt
              </Button>

              {filledPrompt && (
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-semibold">Filled Prompt</h4>
                    <Button
                      onClick={() => copyPrompt(filledPrompt)}
                      size="sm"
                      variant="outline"
                      className="border-zinc-700"
                    >
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                  </div>
                  <Textarea
                    value={filledPrompt}
                    readOnly
                    className="bg-zinc-800 border-zinc-700 text-white min-h-[200px] font-mono text-sm"
                  />
                </div>
              )}
            </div>
          )}

          {template.usageNotes && (
            <div>
              <h3 className="font-semibold mb-2">Usage Notes</h3>
              <p className="text-zinc-400 whitespace-pre-wrap">{template.usageNotes}</p>
            </div>
          )}

          {tags.length > 0 && (
            <div>
              <h3 className="font-semibold mb-2">Tags</h3>
              <div className="flex flex-wrap gap-2">
                {tags.map((tag: string, idx: number) => (
                  <Badge key={idx} className="bg-blue-600/20 text-blue-400">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {template.notes && (
            <div>
              <h3 className="font-semibold mb-2">Notes</h3>
              <p className="text-zinc-400 whitespace-pre-wrap">{template.notes}</p>
            </div>
          )}

          <div className="border-t border-zinc-800 pt-4">
            <p className="text-sm text-zinc-500">
              Created: {new Date(Number(template.createdAt) / 1000).toLocaleString()}
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
