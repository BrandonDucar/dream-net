'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import type { DbConnection, CognitivePattern } from '../spacetime_module_bindings';

interface TemplateDialogProps {
  connection: DbConnection | null;
  patterns: CognitivePattern[];
  onClose: () => void;
}

export function TemplateDialog({ connection, patterns, onClose }: TemplateDialogProps) {
  const [name, setName] = useState<string>('');
  const [code, setCode] = useState<string>('');
  const [domain, setDomain] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [patternId, setPatternId] = useState<string>('');
  const [variables, setVariables] = useState<string>('');
  const [body, setBody] = useState<string>('');
  const [usageNotes, setUsageNotes] = useState<string>('');
  const [targetEnvironment, setTargetEnvironment] = useState<string>('manual');
  const [tags, setTags] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [seoTitle, setSeoTitle] = useState<string>('');
  const [seoDescription, setSeoDescription] = useState<string>('');
  const [seoKeywords, setSeoKeywords] = useState<string>('');
  const [seoHashtags, setSeoHashtags] = useState<string>('');
  const [altText, setAltText] = useState<string>('');
  const [error, setError] = useState<string>('');

  const handleSubmit = () => {
    if (!connection) {
      setError('Not connected to database');
      return;
    }

    if (!name.trim() || !code.trim() || !domain.trim() || !body.trim()) {
      setError('Name, code, domain, and body are required');
      return;
    }

    const variablesArray = variables.split(',').map((v: string) => v.trim()).filter((v: string) => v);
    const tagsArray = tags.split(',').map((t: string) => t.trim()).filter((t: string) => t);
    const keywordsArray = seoKeywords.split(',').map((k: string) => k.trim()).filter((k: string) => k);
    const hashtagsArray = seoHashtags.split(',').map((h: string) => h.trim()).filter((h: string) => h);

    const id = `template_${Date.now()}`;

    connection.reducers.createPromptTemplate(
      id,
      name,
      code,
      domain,
      description,
      patternId || undefined,
      JSON.stringify(variablesArray),
      body,
      usageNotes,
      targetEnvironment,
      JSON.stringify(tagsArray),
      notes,
      seoTitle || name,
      seoDescription || description,
      JSON.stringify(keywordsArray),
      JSON.stringify(hashtagsArray),
      altText || name
    );

    onClose();
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Prompt Template</DialogTitle>
          <DialogDescription className="text-zinc-400">
            Define a reusable prompt template with variables
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
              placeholder="e.g., CultureCoin Spec Prompt"
              className="bg-zinc-800 border-zinc-700 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="code">Code *</Label>
            <Input
              id="code"
              value={code}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCode(e.target.value)}
              placeholder="e.g., PT_COIN_SPEC"
              className="bg-zinc-800 border-zinc-700 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="domain">Domain *</Label>
            <Input
              id="domain"
              value={domain}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setDomain(e.target.value)}
              placeholder="e.g., culture, drops, ops, pickleball"
              className="bg-zinc-800 border-zinc-700 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
              placeholder="Describe the template..."
              className="bg-zinc-800 border-zinc-700 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="pattern">Linked Pattern (optional)</Label>
            <Select value={patternId} onValueChange={setPatternId}>
              <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white">
                <SelectValue placeholder="Select a pattern" />
              </SelectTrigger>
              <SelectContent className="bg-zinc-800 border-zinc-700 text-white">
                <SelectItem value="">None</SelectItem>
                {patterns.map((pattern: CognitivePattern) => (
                  <SelectItem key={pattern.id} value={pattern.id}>
                    {pattern.name} ({pattern.code})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="variables">Variables (comma-separated placeholders)</Label>
            <Input
              id="variables"
              value={variables}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setVariables(e.target.value)}
              placeholder="{TOKEN_NAME}, {CHAIN}, {GOAL}"
              className="bg-zinc-800 border-zinc-700 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="body">Prompt Body *</Label>
            <Textarea
              id="body"
              value={body}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setBody(e.target.value)}
              placeholder="Your prompt template with {VARIABLES}..."
              className="bg-zinc-800 border-zinc-700 text-white min-h-[150px]"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="usageNotes">Usage Notes</Label>
            <Textarea
              id="usageNotes"
              value={usageNotes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setUsageNotes(e.target.value)}
              placeholder="How to use this template effectively..."
              className="bg-zinc-800 border-zinc-700 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="target">Target Environment</Label>
            <Select value={targetEnvironment} onValueChange={setTargetEnvironment}>
              <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-zinc-800 border-zinc-700 text-white">
                <SelectItem value="custom-gpt">Custom GPT</SelectItem>
                <SelectItem value="backend-agent">Backend Agent</SelectItem>
                <SelectItem value="ohara-mini-app">Ohara Mini-App</SelectItem>
                <SelectItem value="manual">Manual Use</SelectItem>
                <SelectItem value="multi">Multiple</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="tags">Tags (comma-separated)</Label>
            <Input
              id="tags"
              value={tags}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTags(e.target.value)}
              placeholder="crypto, culture, spec"
              className="bg-zinc-800 border-zinc-700 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNotes(e.target.value)}
              placeholder="Additional notes..."
              className="bg-zinc-800 border-zinc-700 text-white"
            />
          </div>

          <div className="border-t border-zinc-800 pt-4 space-y-4">
            <h4 className="font-semibold text-sm">SEO Metadata</h4>
            
            <div className="space-y-2">
              <Label htmlFor="seoTitle">SEO Title</Label>
              <Input
                id="seoTitle"
                value={seoTitle}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSeoTitle(e.target.value)}
                className="bg-zinc-800 border-zinc-700 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="seoDescription">SEO Description</Label>
              <Textarea
                id="seoDescription"
                value={seoDescription}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setSeoDescription(e.target.value)}
                className="bg-zinc-800 border-zinc-700 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="seoKeywords">SEO Keywords (comma-separated)</Label>
              <Input
                id="seoKeywords"
                value={seoKeywords}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSeoKeywords(e.target.value)}
                className="bg-zinc-800 border-zinc-700 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="seoHashtags">SEO Hashtags (comma-separated)</Label>
              <Input
                id="seoHashtags"
                value={seoHashtags}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSeoHashtags(e.target.value)}
                className="bg-zinc-800 border-zinc-700 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="altText">Alt Text</Label>
              <Input
                id="altText"
                value={altText}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAltText(e.target.value)}
                className="bg-zinc-800 border-zinc-700 text-white"
              />
            </div>
          </div>

          {error && (
            <p className="text-red-500 text-sm">{error}</p>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} className="border-zinc-700">
            Cancel
          </Button>
          <Button onClick={handleSubmit} className="bg-purple-600 hover:bg-purple-700 text-white">
            Create Template
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
