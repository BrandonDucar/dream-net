'use client'
import { useState, useEffect } from 'react';
import type { DbConnection } from 'spacetimedb';
import { 
  DbConnection as SpacetimeDBConnection,
  type CognitivePattern,
  type PromptTemplate,
  type PromptKit,
  type UsageMapping,
  type KitPattern,
  type KitTemplate,
  type MappingTemplate,
  type ABTestRecommendation,
  type ExportConfig
} from '../spacetime_module_bindings';
import { storageAdapter } from '../lib/storageAdapter';

export function useSpacetimeDB() {
  const [connected, setConnected] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('Initializing DreamNet Cognitive Forge...');
  const [connection, setConnection] = useState<DbConnection | null>(null);
  const [usingLocalStorage, setUsingLocalStorage] = useState<boolean>(false);

  const [cognitivePatterns, setCognitivePatterns] = useState<Map<string, CognitivePattern>>(new Map());
  const [promptTemplates, setPromptTemplates] = useState<Map<string, PromptTemplate>>(new Map());
  const [promptKits, setPromptKits] = useState<Map<string, PromptKit>>(new Map());
  const [usageMappings, setUsageMappings] = useState<Map<string, UsageMapping>>(new Map());
  const [kitPatterns, setKitPatterns] = useState<Map<string, KitPattern>>(new Map());
  const [kitTemplates, setKitTemplates] = useState<Map<string, KitTemplate>>(new Map());
  const [mappingTemplates, setMappingTemplates] = useState<Map<string, MappingTemplate>>(new Map());
  const [abTestRecommendations, setAbTestRecommendations] = useState<Map<string, ABTestRecommendation>>(new Map());
  const [exportConfigs, setExportConfigs] = useState<Map<string, ExportConfig>>(new Map());

  useEffect(() => {
    let conn: DbConnection | null = null;

    const connectToSpacetime = async () => {
      const config = storageAdapter.getConfig();
      
      // Check if we should use local storage
      if (config.mode === 'local') {
        setStatusMessage('Using Local Storage');
        setUsingLocalStorage(true);
        setConnected(true);
        
        // Load data from localStorage
        setCognitivePatterns(storageAdapter.getCognitivePatterns());
        setPromptTemplates(storageAdapter.getPromptTemplates());
        setPromptKits(storageAdapter.getPromptKits());
        setUsageMappings(storageAdapter.getUsageMappings());
        setKitPatterns(storageAdapter.getKitPatterns());
        setKitTemplates(storageAdapter.getKitTemplates());
        setMappingTemplates(storageAdapter.getMappingTemplates());
        setAbTestRecommendations(storageAdapter.getABTestRecommendations());
        setExportConfigs(storageAdapter.getExportConfigs());
        return;
      }
      
      // Try SpacetimeDB connection
      try {
        setStatusMessage('Connecting to SpacetimeDB...');
        
        const host = config.spacetimeHost || 'https://testnet.spacetimedb.com';
        const moduleName = config.spacetimeModuleName || 'dreamnet-cognitive-forge';
        const token = config.spacetimeToken || '';
        
        conn = SpacetimeDBConnection.builder()
          .withUri(host)
          .withModuleName(moduleName)
          .withToken(token)
          .onConnect(() => {
            setStatusMessage('Connected to SpacetimeDB');
            setConnected(true);
            setUsingLocalStorage(false);
          })
          .onConnectError((err: Error) => {
            console.error('SpacetimeDB connection error:', err);
            setStatusMessage('SpacetimeDB unavailable, using Local Storage');
            setUsingLocalStorage(true);
            setConnected(true);
            
            // Fallback to localStorage
            storageAdapter.saveConfig({ mode: 'local' });
            setCognitivePatterns(storageAdapter.getCognitivePatterns());
            setPromptTemplates(storageAdapter.getPromptTemplates());
            setPromptKits(storageAdapter.getPromptKits());
            setUsageMappings(storageAdapter.getUsageMappings());
            setKitPatterns(storageAdapter.getKitPatterns());
            setKitTemplates(storageAdapter.getKitTemplates());
            setMappingTemplates(storageAdapter.getMappingTemplates());
            setAbTestRecommendations(storageAdapter.getABTestRecommendations());
            setExportConfigs(storageAdapter.getExportConfigs());
          })
          .build();

        if (conn) {
          conn.db.cognitivePattern.onInsert((ctx, pattern) => {
            setCognitivePatterns(prev => new Map(prev).set(pattern.id, pattern));
          });

          conn.db.cognitivePattern.onUpdate((ctx, oldPattern, newPattern) => {
            setCognitivePatterns(prev => new Map(prev).set(newPattern.id, newPattern));
          });

          conn.db.cognitivePattern.onDelete((ctx, pattern) => {
            setCognitivePatterns(prev => {
              const next = new Map(prev);
              next.delete(pattern.id);
              return next;
            });
          });

          conn.db.promptTemplate.onInsert((ctx, template) => {
            setPromptTemplates(prev => new Map(prev).set(template.id, template));
          });

          conn.db.promptTemplate.onUpdate((ctx, oldTemplate, newTemplate) => {
            setPromptTemplates(prev => new Map(prev).set(newTemplate.id, newTemplate));
          });

          conn.db.promptTemplate.onDelete((ctx, template) => {
            setPromptTemplates(prev => {
              const next = new Map(prev);
              next.delete(template.id);
              return next;
            });
          });

          conn.db.promptKit.onInsert((ctx, kit) => {
            setPromptKits(prev => new Map(prev).set(kit.id, kit));
          });

          conn.db.promptKit.onUpdate((ctx, oldKit, newKit) => {
            setPromptKits(prev => new Map(prev).set(newKit.id, newKit));
          });

          conn.db.promptKit.onDelete((ctx, kit) => {
            setPromptKits(prev => {
              const next = new Map(prev);
              next.delete(kit.id);
              return next;
            });
          });

          conn.db.usageMapping.onInsert((ctx, mapping) => {
            setUsageMappings(prev => new Map(prev).set(mapping.id, mapping));
          });

          conn.db.usageMapping.onUpdate((ctx, oldMapping, newMapping) => {
            setUsageMappings(prev => new Map(prev).set(newMapping.id, newMapping));
          });

          conn.db.usageMapping.onDelete((ctx, mapping) => {
            setUsageMappings(prev => {
              const next = new Map(prev);
              next.delete(mapping.id);
              return next;
            });
          });

          conn.db.kitPattern.onInsert((ctx, kp) => {
            setKitPatterns(prev => new Map(prev).set(kp.id, kp));
          });

          conn.db.kitPattern.onDelete((ctx, kp) => {
            setKitPatterns(prev => {
              const next = new Map(prev);
              next.delete(kp.id);
              return next;
            });
          });

          conn.db.kitTemplate.onInsert((ctx, kt) => {
            setKitTemplates(prev => new Map(prev).set(kt.id, kt));
          });

          conn.db.kitTemplate.onDelete((ctx, kt) => {
            setKitTemplates(prev => {
              const next = new Map(prev);
              next.delete(kt.id);
              return next;
            });
          });

          conn.db.mappingTemplate.onInsert((ctx, mt) => {
            setMappingTemplates(prev => new Map(prev).set(mt.id, mt));
          });

          conn.db.mappingTemplate.onDelete((ctx, mt) => {
            setMappingTemplates(prev => {
              const next = new Map(prev);
              next.delete(mt.id);
              return next;
            });
          });

          conn.db.abTestRecommendation.onInsert((ctx, test) => {
            setAbTestRecommendations(prev => new Map(prev).set(test.id, test));
          });

          conn.db.abTestRecommendation.onUpdate((ctx, oldTest, newTest) => {
            setAbTestRecommendations(prev => new Map(prev).set(newTest.id, newTest));
          });

          conn.db.abTestRecommendation.onDelete((ctx, test) => {
            setAbTestRecommendations(prev => {
              const next = new Map(prev);
              next.delete(test.id);
              return next;
            });
          });

          conn.db.exportConfig.onInsert((ctx, config) => {
            setExportConfigs(prev => new Map(prev).set(config.id, config));
          });

          conn.db.exportConfig.onUpdate((ctx, oldConfig, newConfig) => {
            setExportConfigs(prev => new Map(prev).set(newConfig.id, newConfig));
          });

          conn.db.exportConfig.onDelete((ctx, config) => {
            setExportConfigs(prev => {
              const next = new Map(prev);
              next.delete(config.id);
              return next;
            });
          });

          setConnection(conn);

          await new Promise<void>((resolve) => {
            const checkConnection = () => {
              if (conn && connected) {
                resolve();
              } else {
                setTimeout(checkConnection, 100);
              }
            };
            checkConnection();
          });

          const patternMap = new Map<string, CognitivePattern>();
          for (const pattern of conn.db.cognitivePattern.iter()) {
            patternMap.set(pattern.id, pattern);
          }
          setCognitivePatterns(patternMap);

          const templateMap = new Map<string, PromptTemplate>();
          for (const template of conn.db.promptTemplate.iter()) {
            templateMap.set(template.id, template);
          }
          setPromptTemplates(templateMap);

          const kitMap = new Map<string, PromptKit>();
          for (const kit of conn.db.promptKit.iter()) {
            kitMap.set(kit.id, kit);
          }
          setPromptKits(kitMap);

          const mappingMap = new Map<string, UsageMapping>();
          for (const mapping of conn.db.usageMapping.iter()) {
            mappingMap.set(mapping.id, mapping);
          }
          setUsageMappings(mappingMap);

          const kpMap = new Map<string, KitPattern>();
          for (const kp of conn.db.kitPattern.iter()) {
            kpMap.set(kp.id, kp);
          }
          setKitPatterns(kpMap);

          const ktMap = new Map<string, KitTemplate>();
          for (const kt of conn.db.kitTemplate.iter()) {
            ktMap.set(kt.id, kt);
          }
          setKitTemplates(ktMap);

          const mtMap = new Map<string, MappingTemplate>();
          for (const mt of conn.db.mappingTemplate.iter()) {
            mtMap.set(mt.id, mt);
          }
          setMappingTemplates(mtMap);

          const abTestMap = new Map<string, ABTestRecommendation>();
          for (const test of conn.db.abTestRecommendation.iter()) {
            abTestMap.set(test.id, test);
          }
          setAbTestRecommendations(abTestMap);

          const exportConfigMap = new Map<string, ExportConfig>();
          for (const config of conn.db.exportConfig.iter()) {
            exportConfigMap.set(config.id, config);
          }
          setExportConfigs(exportConfigMap);
        }
      } catch (error) {
        console.error('Failed to connect to SpacetimeDB:', error);
        setStatusMessage('Using Local Storage (SpacetimeDB unavailable)');
        setUsingLocalStorage(true);
        setConnected(true);
        
        // Fallback to localStorage
        storageAdapter.saveConfig({ mode: 'local' });
        setCognitivePatterns(storageAdapter.getCognitivePatterns());
        setPromptTemplates(storageAdapter.getPromptTemplates());
        setPromptKits(storageAdapter.getPromptKits());
        setUsageMappings(storageAdapter.getUsageMappings());
        setKitPatterns(storageAdapter.getKitPatterns());
        setKitTemplates(storageAdapter.getKitTemplates());
        setMappingTemplates(storageAdapter.getMappingTemplates());
        setAbTestRecommendations(storageAdapter.getABTestRecommendations());
        setExportConfigs(storageAdapter.getExportConfigs());
      }
    };

    connectToSpacetime();

    return () => {
      if (conn) {
        conn.disconnect();
      }
    };
  }, []);

  return {
    connected,
    statusMessage,
    cognitivePatterns,
    promptTemplates,
    promptKits,
    usageMappings,
    kitPatterns,
    kitTemplates,
    mappingTemplates,
    abTestRecommendations,
    exportConfigs,
    connection,
    usingLocalStorage
  };
}
