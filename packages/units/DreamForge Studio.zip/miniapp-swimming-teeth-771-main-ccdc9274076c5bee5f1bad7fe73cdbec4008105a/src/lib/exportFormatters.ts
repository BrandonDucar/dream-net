import type { CognitivePattern, PromptTemplate } from '../spacetime_module_bindings';
import { parseJSON } from './promptUtils';

export interface ExportFormat {
  name: string;
  format: string;
  templateStructure: string;
}

export const DEFAULT_EXPORT_FORMATS: ExportFormat[] = [
  {
    name: 'OpenAI Custom GPT',
    format: 'openai-gpt',
    templateStructure: JSON.stringify({
      instructions: '{PATTERN_STEPS}\n\n{TEMPLATE_BODY}',
      conversation_starters: ['{USE_CASE_1}', '{USE_CASE_2}'],
      name: '{PATTERN_NAME}',
      description: '{PATTERN_DESCRIPTION}'
    })
  },
  {
    name: 'Anthropic Claude Project',
    format: 'claude-project',
    templateStructure: JSON.stringify({
      system_prompt: '{PATTERN_STEPS}\n\n{TEMPLATE_BODY}',
      project_name: '{PATTERN_NAME}',
      description: '{PATTERN_DESCRIPTION}',
      tags: '{TAGS}'
    })
  },
  {
    name: 'Plain Markdown',
    format: 'markdown',
    templateStructure: JSON.stringify({
      template: '# {PATTERN_NAME}\n\n{PATTERN_DESCRIPTION}\n\n## Steps\n{PATTERN_STEPS}\n\n## Template\n{TEMPLATE_BODY}'
    })
  },
  {
    name: 'JSON Schema',
    format: 'json',
    templateStructure: JSON.stringify({
      pattern: {
        name: '{PATTERN_NAME}',
        code: '{PATTERN_CODE}',
        description: '{PATTERN_DESCRIPTION}',
        steps: '{PATTERN_STEPS}',
        useCases: '{USE_CASES}'
      },
      template: {
        name: '{TEMPLATE_NAME}',
        domain: '{TEMPLATE_DOMAIN}',
        body: '{TEMPLATE_BODY}',
        variables: '{TEMPLATE_VARIABLES}'
      }
    })
  }
];

export function exportPatternToFormat(
  pattern: CognitivePattern,
  template: PromptTemplate | null,
  format: ExportFormat
): string {
  const steps = parseJSON<string>(pattern.steps);
  const useCases = parseJSON<string>(pattern.useCases);
  const tags = parseJSON<string>(pattern.tags);

  let structure: Record<string, unknown>;
  try {
    structure = JSON.parse(format.templateStructure);
  } catch {
    return 'Invalid format structure';
  }

  const replacements: Record<string, string> = {
    '{PATTERN_NAME}': pattern.name,
    '{PATTERN_CODE}': pattern.code,
    '{PATTERN_DESCRIPTION}': pattern.description,
    '{PATTERN_STEPS}': steps.map((s: string, i: number) => `${i + 1}. ${s}`).join('\n'),
    '{USE_CASES}': useCases.join(', '),
    '{USE_CASE_1}': useCases[0] || '',
    '{USE_CASE_2}': useCases[1] || '',
    '{TAGS}': tags.join(', '),
    '{TEMPLATE_NAME}': template?.name || '',
    '{TEMPLATE_DOMAIN}': template?.domain || '',
    '{TEMPLATE_BODY}': template?.body || '',
    '{TEMPLATE_VARIABLES}': template ? parseJSON<string>(template.variables).join(', ') : ''
  };

  const replaceInStructure = (obj: unknown): unknown => {
    if (typeof obj === 'string') {
      let result = obj;
      for (const [key, value] of Object.entries(replacements)) {
        result = result.replace(new RegExp(key, 'g'), value);
      }
      return result;
    } else if (Array.isArray(obj)) {
      return obj.map(replaceInStructure);
    } else if (obj && typeof obj === 'object') {
      const result: Record<string, unknown> = {};
      for (const [key, value] of Object.entries(obj)) {
        result[key] = replaceInStructure(value);
      }
      return result;
    }
    return obj;
  };

  const replaced = replaceInStructure(structure);

  switch (format.format) {
    case 'markdown':
      return (replaced as { template?: string }).template || JSON.stringify(replaced, null, 2);
    case 'json':
      return JSON.stringify(replaced, null, 2);
    default:
      return JSON.stringify(replaced, null, 2);
  }
}
