import type { CognitivePattern } from '../spacetime_module_bindings';
import { parseJSON } from './promptUtils';

export interface FlowNode {
  id: string;
  label: string;
  type: 'start' | 'step' | 'decision' | 'end';
  x: number;
  y: number;
}

export interface FlowEdge {
  from: string;
  to: string;
  label?: string;
}

export interface FlowDiagram {
  nodes: FlowNode[];
  edges: FlowEdge[];
}

export function generateFlowDiagram(pattern: CognitivePattern): FlowDiagram {
  const steps = parseJSON<string>(pattern.steps);
  const nodes: FlowNode[] = [];
  const edges: FlowEdge[] = [];

  const nodeSpacing = 120;
  const startY = 50;

  nodes.push({
    id: 'start',
    label: 'Start',
    type: 'start',
    x: 200,
    y: startY
  });

  steps.forEach((step: string, index: number) => {
    const nodeId = `step_${index}`;
    nodes.push({
      id: nodeId,
      label: step,
      type: 'step',
      x: 200,
      y: startY + (index + 1) * nodeSpacing
    });

    if (index === 0) {
      edges.push({
        from: 'start',
        to: nodeId
      });
    } else {
      edges.push({
        from: `step_${index - 1}`,
        to: nodeId
      });
    }
  });

  nodes.push({
    id: 'end',
    label: 'Complete',
    type: 'end',
    x: 200,
    y: startY + (steps.length + 1) * nodeSpacing
  });

  edges.push({
    from: steps.length > 0 ? `step_${steps.length - 1}` : 'start',
    to: 'end'
  });

  return { nodes, edges };
}

export function generateFlowDiagramSVG(diagram: FlowDiagram): string {
  const width = 450;
  const height = Math.max(600, diagram.nodes.length * 120 + 100);

  let svg = `<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">`;
  
  svg += '<defs>';
  svg += '<marker id="arrowhead" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">';
  svg += '<polygon points="0 0, 10 3, 0 6" fill="#a855f7" />';
  svg += '</marker>';
  svg += '</defs>';

  svg += '<rect width="100%" height="100%" fill="#0a0a0a"/>';

  for (const edge of diagram.edges) {
    const fromNode = diagram.nodes.find((n: FlowNode) => n.id === edge.from);
    const toNode = diagram.nodes.find((n: FlowNode) => n.id === edge.to);
    
    if (fromNode && toNode) {
      const fromY = fromNode.y + (fromNode.type === 'start' ? 20 : 25);
      const toY = toNode.y - (toNode.type === 'end' ? 20 : 25);
      
      svg += `<line x1="${fromNode.x}" y1="${fromY}" x2="${toNode.x}" y2="${toY}" stroke="#a855f7" stroke-width="2" marker-end="url(#arrowhead)"/>`;
      
      if (edge.label) {
        const midY = (fromY + toY) / 2;
        svg += `<text x="${fromNode.x + 10}" y="${midY}" fill="#d4d4d8" font-size="12">${edge.label}</text>`;
      }
    }
  }

  for (const node of diagram.nodes) {
    const nodeWidth = 160;
    const nodeHeight = 50;
    const cornerRadius = 8;
    
    let fill = '#27272a';
    let stroke = '#a855f7';
    
    if (node.type === 'start') {
      svg += `<circle cx="${node.x}" cy="${node.y}" r="20" fill="${fill}" stroke="${stroke}" stroke-width="2"/>`;
      svg += `<text x="${node.x}" y="${node.y + 5}" text-anchor="middle" fill="#ffffff" font-size="14" font-weight="bold">${node.label}</text>`;
    } else if (node.type === 'end') {
      svg += `<circle cx="${node.x}" cy="${node.y}" r="20" fill="${fill}" stroke="${stroke}" stroke-width="2"/>`;
      svg += `<circle cx="${node.x}" cy="${node.y}" r="16" fill="none" stroke="${stroke}" stroke-width="2"/>`;
      svg += `<text x="${node.x}" y="${node.y + 5}" text-anchor="middle" fill="#ffffff" font-size="12" font-weight="bold">${node.label}</text>`;
    } else {
      svg += `<rect x="${node.x - nodeWidth / 2}" y="${node.y - nodeHeight / 2}" width="${nodeWidth}" height="${nodeHeight}" rx="${cornerRadius}" fill="${fill}" stroke="${stroke}" stroke-width="2"/>`;
      
      const words = node.label.split(' ');
      const lines: string[] = [];
      let currentLine = '';
      
      for (const word of words) {
        if ((currentLine + word).length > 20) {
          if (currentLine) lines.push(currentLine.trim());
          currentLine = word + ' ';
        } else {
          currentLine += word + ' ';
        }
      }
      if (currentLine) lines.push(currentLine.trim());
      
      const lineHeight = 16;
      const startY = node.y - (lines.length - 1) * lineHeight / 2;
      
      lines.forEach((line: string, i: number) => {
        svg += `<text x="${node.x}" y="${startY + i * lineHeight}" text-anchor="middle" fill="#ffffff" font-size="13">${line}</text>`;
      });
    }
  }

  svg += '</svg>';
  return svg;
}

export function buildInheritanceTree(
  patterns: CognitivePattern[]
): Map<string, CognitivePattern[]> {
  const tree = new Map<string, CognitivePattern[]>();
  
  for (const pattern of patterns) {
    const parentId = pattern.parentPatternId || 'root';
    if (!tree.has(parentId)) {
      tree.set(parentId, []);
    }
    tree.get(parentId)!.push(pattern);
  }
  
  return tree;
}
