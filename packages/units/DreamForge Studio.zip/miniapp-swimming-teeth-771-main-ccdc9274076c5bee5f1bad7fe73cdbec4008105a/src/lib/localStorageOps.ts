'use client'

import { storageAdapter } from './storageAdapter';
import type {
  CognitivePattern,
  PromptTemplate,
  PromptKit,
  UsageMapping,
  KitPattern,
  KitTemplate,
  MappingTemplate,
  ABTestRecommendation,
  ExportConfig
} from '../spacetime_module_bindings';

// Helper to generate IDs
export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

// Cognitive Pattern Operations
export function createCognitivePatternLocal(pattern: Omit<CognitivePattern, 'id'>): CognitivePattern {
  const patterns = storageAdapter.getCognitivePatterns();
  const newPattern: CognitivePattern = { ...pattern, id: generateId() };
  patterns.set(newPattern.id, newPattern);
  storageAdapter.setCognitivePatterns(patterns);
  return newPattern;
}

export function updateCognitivePatternLocal(id: string, updates: Partial<CognitivePattern>): void {
  const patterns = storageAdapter.getCognitivePatterns();
  const existing = patterns.get(id);
  if (existing) {
    patterns.set(id, { ...existing, ...updates });
    storageAdapter.setCognitivePatterns(patterns);
  }
}

export function deleteCognitivePatternLocal(id: string): void {
  const patterns = storageAdapter.getCognitivePatterns();
  patterns.delete(id);
  storageAdapter.setCognitivePatterns(patterns);
}

// Prompt Template Operations
export function createPromptTemplateLocal(template: Omit<PromptTemplate, 'id'>): PromptTemplate {
  const templates = storageAdapter.getPromptTemplates();
  const newTemplate: PromptTemplate = { ...template, id: generateId() };
  templates.set(newTemplate.id, newTemplate);
  storageAdapter.setPromptTemplates(templates);
  return newTemplate;
}

export function updatePromptTemplateLocal(id: string, updates: Partial<PromptTemplate>): void {
  const templates = storageAdapter.getPromptTemplates();
  const existing = templates.get(id);
  if (existing) {
    templates.set(id, { ...existing, ...updates });
    storageAdapter.setPromptTemplates(templates);
  }
}

export function deletePromptTemplateLocal(id: string): void {
  const templates = storageAdapter.getPromptTemplates();
  templates.delete(id);
  storageAdapter.setPromptTemplates(templates);
}

// Prompt Kit Operations
export function createPromptKitLocal(kit: Omit<PromptKit, 'id'>): PromptKit {
  const kits = storageAdapter.getPromptKits();
  const newKit: PromptKit = { ...kit, id: generateId() };
  kits.set(newKit.id, newKit);
  storageAdapter.setPromptKits(kits);
  return newKit;
}

export function updatePromptKitLocal(id: string, updates: Partial<PromptKit>): void {
  const kits = storageAdapter.getPromptKits();
  const existing = kits.get(id);
  if (existing) {
    kits.set(id, { ...existing, ...updates });
    storageAdapter.setPromptKits(kits);
  }
}

export function deletePromptKitLocal(id: string): void {
  const kits = storageAdapter.getPromptKits();
  kits.delete(id);
  storageAdapter.setPromptKits(kits);
}

// Usage Mapping Operations
export function createUsageMappingLocal(mapping: Omit<UsageMapping, 'id'>): UsageMapping {
  const mappings = storageAdapter.getUsageMappings();
  const newMapping: UsageMapping = { ...mapping, id: generateId() };
  mappings.set(newMapping.id, newMapping);
  storageAdapter.setUsageMappings(mappings);
  return newMapping;
}

export function updateUsageMappingLocal(id: string, updates: Partial<UsageMapping>): void {
  const mappings = storageAdapter.getUsageMappings();
  const existing = mappings.get(id);
  if (existing) {
    mappings.set(id, { ...existing, ...updates });
    storageAdapter.setUsageMappings(mappings);
  }
}

export function deleteUsageMappingLocal(id: string): void {
  const mappings = storageAdapter.getUsageMappings();
  mappings.delete(id);
  storageAdapter.setUsageMappings(mappings);
}

// Kit Pattern Operations
export function addPatternToKitLocal(kitId: string, patternId: string): void {
  const kitPatterns = storageAdapter.getKitPatterns();
  const id = generateId();
  const newKitPattern: KitPattern = { id, kitId, patternId };
  kitPatterns.set(id, newKitPattern);
  storageAdapter.setKitPatterns(kitPatterns);
}

export function removePatternFromKitLocal(kitId: string, patternId: string): void {
  const kitPatterns = storageAdapter.getKitPatterns();
  for (const [id, kp] of kitPatterns.entries()) {
    if (kp.kitId === kitId && kp.patternId === patternId) {
      kitPatterns.delete(id);
    }
  }
  storageAdapter.setKitPatterns(kitPatterns);
}

// Kit Template Operations
export function addTemplateToKitLocal(kitId: string, templateId: string): void {
  const kitTemplates = storageAdapter.getKitTemplates();
  const id = generateId();
  const newKitTemplate: KitTemplate = { id, kitId, templateId };
  kitTemplates.set(id, newKitTemplate);
  storageAdapter.setKitTemplates(kitTemplates);
}

export function removeTemplateFromKitLocal(kitId: string, templateId: string): void {
  const kitTemplates = storageAdapter.getKitTemplates();
  for (const [id, kt] of kitTemplates.entries()) {
    if (kt.kitId === kitId && kt.templateId === templateId) {
      kitTemplates.delete(id);
    }
  }
  storageAdapter.setKitTemplates(kitTemplates);
}

// Mapping Template Operations
export function addTemplateToMappingLocal(mappingId: string, templateId: string): void {
  const mappingTemplates = storageAdapter.getMappingTemplates();
  const id = generateId();
  const newMappingTemplate: MappingTemplate = { id, mappingId, templateId };
  mappingTemplates.set(id, newMappingTemplate);
  storageAdapter.setMappingTemplates(mappingTemplates);
}

export function removeTemplateFromMappingLocal(mappingId: string, templateId: string): void {
  const mappingTemplates = storageAdapter.getMappingTemplates();
  for (const [id, mt] of mappingTemplates.entries()) {
    if (mt.mappingId === mappingId && mt.templateId === templateId) {
      mappingTemplates.delete(id);
    }
  }
  storageAdapter.setMappingTemplates(mappingTemplates);
}

// A/B Test Operations
export function createABTestLocal(test: Omit<ABTestRecommendation, 'id'>): ABTestRecommendation {
  const tests = storageAdapter.getABTestRecommendations();
  const newTest: ABTestRecommendation = { ...test, id: generateId() };
  tests.set(newTest.id, newTest);
  storageAdapter.setABTestRecommendations(tests);
  return newTest;
}

export function updateABTestLocal(id: string, updates: Partial<ABTestRecommendation>): void {
  const tests = storageAdapter.getABTestRecommendations();
  const existing = tests.get(id);
  if (existing) {
    tests.set(id, { ...existing, ...updates });
    storageAdapter.setABTestRecommendations(tests);
  }
}

export function deleteABTestLocal(id: string): void {
  const tests = storageAdapter.getABTestRecommendations();
  tests.delete(id);
  storageAdapter.setABTestRecommendations(tests);
}

// Export Config Operations
export function createExportConfigLocal(config: Omit<ExportConfig, 'id'>): ExportConfig {
  const configs = storageAdapter.getExportConfigs();
  const newConfig: ExportConfig = { ...config, id: generateId() };
  configs.set(newConfig.id, newConfig);
  storageAdapter.setExportConfigs(configs);
  return newConfig;
}

export function updateExportConfigLocal(id: string, updates: Partial<ExportConfig>): void {
  const configs = storageAdapter.getExportConfigs();
  const existing = configs.get(id);
  if (existing) {
    configs.set(id, { ...existing, ...updates });
    storageAdapter.setExportConfigs(configs);
  }
}

export function deleteExportConfigLocal(id: string): void {
  const configs = storageAdapter.getExportConfigs();
  configs.delete(id);
  storageAdapter.setExportConfigs(configs);
}
