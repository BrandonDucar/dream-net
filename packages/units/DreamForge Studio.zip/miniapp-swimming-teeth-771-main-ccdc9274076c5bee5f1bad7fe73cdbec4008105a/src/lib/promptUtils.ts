import type { 
  CognitivePattern, 
  PromptTemplate, 
  PromptKit, 
  UsageMapping,
  KitTemplate,
  KitPattern,
  MappingTemplate
} from '../spacetime_module_bindings';

export function parseJSON<T>(jsonString: string): T[] {
  try {
    return JSON.parse(jsonString) as T[];
  } catch {
    return [];
  }
}

export function fillPromptVariables(template: PromptTemplate, values: Record<string, string>): string {
  let result = template.body;
  const variables = parseJSON<string>(template.variables);
  
  for (const variable of variables) {
    const value = values[variable] || '';
    result = result.replace(new RegExp(variable.replace(/[{}]/g, '\\$&'), 'g'), value);
  }
  
  return result;
}

export function generatePatternGuide(
  pattern: CognitivePattern,
  relatedTemplates: PromptTemplate[],
  relatedKits: PromptKit[],
  relatedMappings: UsageMapping[]
): string {
  const useCases = parseJSON<string>(pattern.useCases);
  const steps = parseJSON<string>(pattern.steps);
  const recommendedAgents = parseJSON<string>(pattern.recommendedAgents);
  const tags = parseJSON<string>(pattern.tags);

  let guide = `# ${pattern.name} (${pattern.code})\n\n`;
  guide += `## Description\n${pattern.description}\n\n`;
  
  if (useCases.length > 0) {
    guide += `## Use Cases\n`;
    for (const useCase of useCases) {
      guide += `- ${useCase}\n`;
    }
    guide += '\n';
  }
  
  if (steps.length > 0) {
    guide += `## Reasoning Steps\n`;
    for (let i = 0; i < steps.length; i++) {
      guide += `${i + 1}. ${steps[i]}\n`;
    }
    guide += '\n';
  }
  
  if (recommendedAgents.length > 0) {
    guide += `## Recommended Agents\n`;
    for (const agent of recommendedAgents) {
      guide += `- ${agent}\n`;
    }
    guide += '\n';
  }
  
  if (tags.length > 0) {
    guide += `## Tags\n${tags.join(', ')}\n\n`;
  }
  
  if (relatedTemplates.length > 0) {
    guide += `## Related Prompt Templates\n`;
    for (const template of relatedTemplates) {
      guide += `- ${template.name} (${template.code}) - ${template.domain}\n`;
    }
    guide += '\n';
  }
  
  if (relatedKits.length > 0) {
    guide += `## Related Kits\n`;
    for (const kit of relatedKits) {
      guide += `- ${kit.name} (${kit.domain})\n`;
    }
    guide += '\n';
  }
  
  if (relatedMappings.length > 0) {
    guide += `## Usage Mappings\n`;
    for (const mapping of relatedMappings) {
      guide += `- ${mapping.targetType}: ${mapping.targetRef}\n`;
    }
    guide += '\n';
  }
  
  if (pattern.notes) {
    guide += `## Notes\n${pattern.notes}\n\n`;
  }
  
  guide += `---\n**Created:** ${new Date(Number(pattern.createdAt) / 1000).toLocaleString()}\n`;
  
  return guide;
}

export function generatePromptKitGuide(
  kit: PromptKit,
  templates: PromptTemplate[],
  patterns: CognitivePattern[]
): string {
  const tags = parseJSON<string>(kit.tags);

  let guide = `# ${kit.name} - ${kit.domain}\n\n`;
  guide += `## Description\n${kit.description}\n\n`;
  
  if (patterns.length > 0) {
    guide += `## Cognitive Patterns\n`;
    for (const pattern of patterns) {
      const steps = parseJSON<string>(pattern.steps);
      guide += `\n### ${pattern.name} (${pattern.code})\n`;
      guide += `${pattern.description}\n\n`;
      if (steps.length > 0) {
        guide += `**Steps:**\n`;
        for (const step of steps) {
          guide += `- ${step}\n`;
        }
      }
      guide += '\n';
    }
  }
  
  if (templates.length > 0) {
    guide += `## Prompt Templates\n`;
    for (const template of templates) {
      const variables = parseJSON<string>(template.variables);
      guide += `\n### ${template.name} (${template.code})\n`;
      guide += `**Domain:** ${template.domain}\n`;
      guide += `**Target:** ${template.targetEnvironment}\n`;
      guide += `**Description:** ${template.description}\n\n`;
      
      if (variables.length > 0) {
        guide += `**Variables:**\n`;
        for (const variable of variables) {
          guide += `- ${variable}\n`;
        }
        guide += '\n';
      }
      
      if (template.usageNotes) {
        guide += `**Usage Notes:** ${template.usageNotes}\n\n`;
      }
    }
  }
  
  if (tags.length > 0) {
    guide += `## Tags\n${tags.join(', ')}\n\n`;
  }
  
  if (kit.notes) {
    guide += `## Notes\n${kit.notes}\n\n`;
  }
  
  guide += `---\n**Created:** ${new Date(Number(kit.createdAt) / 1000).toLocaleString()}\n`;
  
  return guide;
}

export function exportCognitivePlaybook(
  patterns: CognitivePattern[],
  templates: PromptTemplate[],
  kits: PromptKit[],
  mappings: UsageMapping[]
): string {
  let playbook = `# DreamNet Cognitive Playbook v1\n\n`;
  playbook += `**Generated:** ${new Date().toLocaleString()}\n\n`;
  playbook += `---\n\n`;
  
  playbook += `## Overview\n`;
  playbook += `This playbook defines the thinking patterns, prompt frameworks, and usage guidelines for the DreamNet ecosystem.\n\n`;
  playbook += `- **${patterns.length}** Cognitive Patterns\n`;
  playbook += `- **${templates.length}** Prompt Templates\n`;
  playbook += `- **${kits.length}** Prompt Kits\n`;
  playbook += `- **${mappings.length}** Usage Mappings\n\n`;
  
  if (patterns.length > 0) {
    playbook += `## Cognitive Patterns\n\n`;
    for (const pattern of patterns) {
      const useCases = parseJSON<string>(pattern.useCases);
      const steps = parseJSON<string>(pattern.steps);
      
      playbook += `### ${pattern.name} (${pattern.code})\n`;
      playbook += `${pattern.description}\n\n`;
      
      if (useCases.length > 0) {
        playbook += `**Use Cases:** ${useCases.join(', ')}\n\n`;
      }
      
      if (steps.length > 0) {
        playbook += `**Steps:**\n`;
        for (const step of steps) {
          playbook += `1. ${step}\n`;
        }
        playbook += '\n';
      }
    }
    playbook += '\n';
  }
  
  if (kits.length > 0) {
    playbook += `## Prompt Kits\n\n`;
    for (const kit of kits) {
      playbook += `### ${kit.name} (${kit.domain})\n`;
      playbook += `${kit.description}\n\n`;
    }
    playbook += '\n';
  }
  
  if (mappings.length > 0) {
    playbook += `## Usage Mappings\n\n`;
    const groupedMappings: Record<string, UsageMapping[]> = {};
    for (const mapping of mappings) {
      if (!groupedMappings[mapping.targetType]) {
        groupedMappings[mapping.targetType] = [];
      }
      groupedMappings[mapping.targetType].push(mapping);
    }
    
    for (const [targetType, mappingsList] of Object.entries(groupedMappings)) {
      playbook += `### ${targetType}\n`;
      for (const mapping of mappingsList) {
        playbook += `- **${mapping.targetRef}**`;
        if (mapping.primaryPatternId) {
          const pattern = patterns.find((p: CognitivePattern) => p.id === mapping.primaryPatternId);
          if (pattern) {
            playbook += ` - uses ${pattern.name}`;
          }
        }
        playbook += '\n';
      }
      playbook += '\n';
    }
  }
  
  playbook += `---\n\n`;
  playbook += `## How to Use This Playbook\n\n`;
  playbook += `1. **Choose a Pattern:** Select a cognitive pattern that matches your task type\n`;
  playbook += `2. **Find Templates:** Look up prompt templates in the relevant domain\n`;
  playbook += `3. **Check Mappings:** See which agents/apps should use which patterns\n`;
  playbook += `4. **Apply Kits:** Use pre-packaged prompt kits for common workflows\n\n`;
  
  return playbook;
}

export function getTemplatesForKit(
  kitId: string,
  kitTemplates: Map<string, KitTemplate>,
  allTemplates: Map<string, PromptTemplate>
): PromptTemplate[] {
  const templateIds: string[] = [];
  for (const kt of kitTemplates.values()) {
    if (kt.kitId === kitId) {
      templateIds.push(kt.templateId);
    }
  }
  
  return templateIds
    .map((id: string) => allTemplates.get(id))
    .filter((t: PromptTemplate | undefined): t is PromptTemplate => t !== undefined);
}

export function getPatternsForKit(
  kitId: string,
  kitPatterns: Map<string, KitPattern>,
  allPatterns: Map<string, CognitivePattern>
): CognitivePattern[] {
  const patternIds: string[] = [];
  for (const kp of kitPatterns.values()) {
    if (kp.kitId === kitId) {
      patternIds.push(kp.patternId);
    }
  }
  
  return patternIds
    .map((id: string) => allPatterns.get(id))
    .filter((p: CognitivePattern | undefined): p is CognitivePattern => p !== undefined);
}

export function getTemplatesForMapping(
  mappingId: string,
  mappingTemplates: Map<string, MappingTemplate>,
  allTemplates: Map<string, PromptTemplate>
): PromptTemplate[] {
  const templateIds: string[] = [];
  for (const mt of mappingTemplates.values()) {
    if (mt.mappingId === mappingId) {
      templateIds.push(mt.templateId);
    }
  }
  
  return templateIds
    .map((id: string) => allTemplates.get(id))
    .filter((t: PromptTemplate | undefined): t is PromptTemplate => t !== undefined);
}
