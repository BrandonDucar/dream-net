'use client'

import type { 
  CognitivePattern,
  PromptTemplate,
  PromptKit,
  UsageMapping,
  KitPattern,
  KitTemplate,
  MappingTemplate,
  ABTestRecommendation,
  ExportConfig
} from '../spacetime_module_bindings';

// Storage configuration
export interface StorageConfig {
  mode: 'spacetime' | 'local';
  spacetimeHost?: string;
  spacetimeModuleName?: string;
  spacetimeToken?: string;
}

// Default configuration
export const DEFAULT_CONFIG: StorageConfig = {
  mode: 'local', // Default to local storage
  spacetimeHost: 'https://testnet.spacetimedb.com',
  spacetimeModuleName: 'dreamnet-cognitive-forge',
  spacetimeToken: ''
};

// Local storage keys
const STORAGE_KEYS = {
  CONFIG: 'dreamnet_storage_config',
  PATTERNS: 'dreamnet_cognitive_patterns',
  TEMPLATES: 'dreamnet_prompt_templates',
  KITS: 'dreamnet_prompt_kits',
  MAPPINGS: 'dreamnet_usage_mappings',
  KIT_PATTERNS: 'dreamnet_kit_patterns',
  KIT_TEMPLATES: 'dreamnet_kit_templates',
  MAPPING_TEMPLATES: 'dreamnet_mapping_templates',
  AB_TESTS: 'dreamnet_ab_tests',
  EXPORT_CONFIGS: 'dreamnet_export_configs'
} as const;

// Universal storage adapter
export class StorageAdapter {
  private config: StorageConfig;

  constructor(config?: Partial<StorageConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.loadConfig();
  }

  // Load configuration from localStorage
  private loadConfig(): void {
    if (typeof window === 'undefined') return;
    
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CONFIG);
      if (saved) {
        this.config = { ...this.config, ...JSON.parse(saved) };
      }
    } catch (error) {
      console.error('Failed to load config:', error);
    }
  }

  // Save configuration to localStorage
  saveConfig(config: Partial<StorageConfig>): void {
    this.config = { ...this.config, ...config };
    
    if (typeof window === 'undefined') return;
    
    try {
      localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(this.config));
    } catch (error) {
      console.error('Failed to save config:', error);
    }
  }

  // Get current configuration
  getConfig(): StorageConfig {
    return { ...this.config };
  }

  // Generic get method
  get<T>(key: string): Map<string, T> {
    if (typeof window === 'undefined') return new Map();
    
    try {
      const data = localStorage.getItem(key);
      if (data) {
        const parsed = JSON.parse(data);
        return new Map(Object.entries(parsed)) as Map<string, T>;
      }
    } catch (error) {
      console.error(`Failed to get ${key}:`, error);
    }
    return new Map();
  }

  // Generic set method
  set<T>(key: string, map: Map<string, T>): void {
    if (typeof window === 'undefined') return;
    
    try {
      const obj = Object.fromEntries(map);
      localStorage.setItem(key, JSON.stringify(obj));
    } catch (error) {
      console.error(`Failed to set ${key}:`, error);
    }
  }

  // Specific getters
  getCognitivePatterns(): Map<string, CognitivePattern> {
    return this.get<CognitivePattern>(STORAGE_KEYS.PATTERNS);
  }

  getPromptTemplates(): Map<string, PromptTemplate> {
    return this.get<PromptTemplate>(STORAGE_KEYS.TEMPLATES);
  }

  getPromptKits(): Map<string, PromptKit> {
    return this.get<PromptKit>(STORAGE_KEYS.KITS);
  }

  getUsageMappings(): Map<string, UsageMapping> {
    return this.get<UsageMapping>(STORAGE_KEYS.MAPPINGS);
  }

  getKitPatterns(): Map<string, KitPattern> {
    return this.get<KitPattern>(STORAGE_KEYS.KIT_PATTERNS);
  }

  getKitTemplates(): Map<string, KitTemplate> {
    return this.get<KitTemplate>(STORAGE_KEYS.KIT_TEMPLATES);
  }

  getMappingTemplates(): Map<string, MappingTemplate> {
    return this.get<MappingTemplate>(STORAGE_KEYS.MAPPING_TEMPLATES);
  }

  getABTestRecommendations(): Map<string, ABTestRecommendation> {
    return this.get<ABTestRecommendation>(STORAGE_KEYS.AB_TESTS);
  }

  getExportConfigs(): Map<string, ExportConfig> {
    return this.get<ExportConfig>(STORAGE_KEYS.EXPORT_CONFIGS);
  }

  // Specific setters
  setCognitivePatterns(map: Map<string, CognitivePattern>): void {
    this.set(STORAGE_KEYS.PATTERNS, map);
  }

  setPromptTemplates(map: Map<string, PromptTemplate>): void {
    this.set(STORAGE_KEYS.TEMPLATES, map);
  }

  setPromptKits(map: Map<string, PromptKit>): void {
    this.set(STORAGE_KEYS.KITS, map);
  }

  setUsageMappings(map: Map<string, UsageMapping>): void {
    this.set(STORAGE_KEYS.MAPPINGS, map);
  }

  setKitPatterns(map: Map<string, KitPattern>): void {
    this.set(STORAGE_KEYS.KIT_PATTERNS, map);
  }

  setKitTemplates(map: Map<string, KitTemplate>): void {
    this.set(STORAGE_KEYS.KIT_TEMPLATES, map);
  }

  setMappingTemplates(map: Map<string, MappingTemplate>): void {
    this.set(STORAGE_KEYS.MAPPING_TEMPLATES, map);
  }

  setABTestRecommendations(map: Map<string, ABTestRecommendation>): void {
    this.set(STORAGE_KEYS.AB_TESTS, map);
  }

  setExportConfigs(map: Map<string, ExportConfig>): void {
    this.set(STORAGE_KEYS.EXPORT_CONFIGS, map);
  }

  // Clear all data
  clearAll(): void {
    if (typeof window === 'undefined') return;
    
    Object.values(STORAGE_KEYS).forEach(key => {
      if (key !== STORAGE_KEYS.CONFIG) {
        localStorage.removeItem(key);
      }
    });
  }

  // Export all data
  exportAll(): Record<string, unknown> {
    return {
      cognitivePatterns: Array.from(this.getCognitivePatterns().values()),
      promptTemplates: Array.from(this.getPromptTemplates().values()),
      promptKits: Array.from(this.getPromptKits().values()),
      usageMappings: Array.from(this.getUsageMappings().values()),
      kitPatterns: Array.from(this.getKitPatterns().values()),
      kitTemplates: Array.from(this.getKitTemplates().values()),
      mappingTemplates: Array.from(this.getMappingTemplates().values()),
      abTestRecommendations: Array.from(this.getABTestRecommendations().values()),
      exportConfigs: Array.from(this.getExportConfigs().values())
    };
  }

  // Import all data
  importAll(data: Record<string, unknown[]>): void {
    if (data.cognitivePatterns) {
      const map = new Map<string, CognitivePattern>();
      (data.cognitivePatterns as CognitivePattern[]).forEach(p => map.set(p.id, p));
      this.setCognitivePatterns(map);
    }
    if (data.promptTemplates) {
      const map = new Map<string, PromptTemplate>();
      (data.promptTemplates as PromptTemplate[]).forEach(t => map.set(t.id, t));
      this.setPromptTemplates(map);
    }
    if (data.promptKits) {
      const map = new Map<string, PromptKit>();
      (data.promptKits as PromptKit[]).forEach(k => map.set(k.id, k));
      this.setPromptKits(map);
    }
    if (data.usageMappings) {
      const map = new Map<string, UsageMapping>();
      (data.usageMappings as UsageMapping[]).forEach(m => map.set(m.id, m));
      this.setUsageMappings(map);
    }
    if (data.kitPatterns) {
      const map = new Map<string, KitPattern>();
      (data.kitPatterns as KitPattern[]).forEach(kp => map.set(kp.id, kp));
      this.setKitPatterns(map);
    }
    if (data.kitTemplates) {
      const map = new Map<string, KitTemplate>();
      (data.kitTemplates as KitTemplate[]).forEach(kt => map.set(kt.id, kt));
      this.setKitTemplates(map);
    }
    if (data.mappingTemplates) {
      const map = new Map<string, MappingTemplate>();
      (data.mappingTemplates as MappingTemplate[]).forEach(mt => map.set(mt.id, mt));
      this.setMappingTemplates(map);
    }
    if (data.abTestRecommendations) {
      const map = new Map<string, ABTestRecommendation>();
      (data.abTestRecommendations as ABTestRecommendation[]).forEach(t => map.set(t.id, t));
      this.setABTestRecommendations(map);
    }
    if (data.exportConfigs) {
      const map = new Map<string, ExportConfig>();
      (data.exportConfigs as ExportConfig[]).forEach(c => map.set(c.id, c));
      this.setExportConfigs(map);
    }
  }
}

// Global storage adapter instance
export const storageAdapter = new StorageAdapter();
