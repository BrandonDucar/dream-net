'use client'
import { useState, useEffect } from 'react';
import { EntityExplorer } from '@/components/entity-explorer';
import { EntityDetailView } from '@/components/entity-detail-view';
import { GroupsPathTemplatesView } from '@/components/groups-path-templates-view';
import { GraphOverviewView } from '@/components/graph-overview-view';
import { GraphVisualization } from '@/components/graph-visualization';
import { AnalyticsDashboard } from '@/components/analytics-dashboard';
import { CommandPalette, useCommandPalette } from '@/components/command-palette';
import { ImportExportDialog } from '@/components/import-export-dialog';
import { VersionControlPanel } from '@/components/version-control-panel';
import { WorkspaceSwitcher } from '@/components/workspace-switcher';
import { SuggestionsPanel } from '@/components/suggestions-panel';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type View = 'explorer' | 'detail' | 'overview';

export default function Home(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [view, setView] = useState<View>('explorer');
  const [selectedEntityId, setSelectedEntityId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('entities');
  const [refreshKey, setRefreshKey] = useState(0);
  
  // Command palette
  const { open: commandOpen, setOpen: setCommandOpen } = useCommandPalette();
  
  const handleSelectEntity = (entityId: string): void => {
    setSelectedEntityId(entityId);
    setView('detail');
  };
  
  const handleBackToEntities = (): void => {
    setView('explorer');
    setSelectedEntityId(null);
    setRefreshKey(prev => prev + 1);
  };
  
  const handleViewOverview = (): void => {
    setView('overview');
  };
  
  const handleBackFromOverview = (): void => {
    setView('explorer');
  };
  
  const handleCommandAction = (action: string): void => {
    switch (action) {
      case 'view-graph':
        setActiveTab('graph');
        break;
      case 'view-analytics':
        setActiveTab('analytics');
        break;
      case 'create-entity':
        setActiveTab('entities');
        break;
      default:
        console.log('Action:', action);
    }
  };
  
  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto py-8 px-4 max-w-7xl">
        <div className="mb-8">
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  DreamNet Knowledge Graph Mapper
                </h1>
                <p className="text-muted-foreground mt-2">
                  Map your ecosystem: tokens, drops, agents, mini-apps, and all their relationships
                </p>
              </div>
            </div>
            
            {/* Toolbar */}
            <div className="flex flex-wrap gap-2 items-center p-4 bg-gray-50 rounded-lg border">
              <WorkspaceSwitcher />
              <ImportExportDialog />
              <VersionControlPanel />
              <SuggestionsPanel />
              <Button 
                variant="outline" 
                onClick={() => setCommandOpen(true)}
                className="ml-auto"
              >
                ⌘ Command Palette
              </Button>
            </div>
          </div>
          
          {view === 'explorer' && (
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-4 max-w-2xl">
                <TabsTrigger value="entities">Entities</TabsTrigger>
                <TabsTrigger value="groups">Groups</TabsTrigger>
                <TabsTrigger value="graph">Graph</TabsTrigger>
                <TabsTrigger value="analytics">Analytics</TabsTrigger>
              </TabsList>
              
              <TabsContent value="entities" className="mt-6">
                <EntityExplorer 
                  key={refreshKey}
                  onSelectEntity={handleSelectEntity} 
                  onViewOverview={handleViewOverview}
                />
              </TabsContent>
              
              <TabsContent value="groups" className="mt-6">
                <GroupsPathTemplatesView />
              </TabsContent>
              
              <TabsContent value="graph" className="mt-6">
                <div className="border rounded-lg overflow-hidden">
                  <GraphVisualization />
                </div>
              </TabsContent>
              
              <TabsContent value="analytics" className="mt-6">
                <AnalyticsDashboard />
              </TabsContent>
            </Tabs>
          )}
          
          {view === 'detail' && selectedEntityId && (
            <EntityDetailView
              entityId={selectedEntityId}
              onBack={handleBackToEntities}
              onRefresh={() => setRefreshKey(prev => prev + 1)}
            />
          )}
          
          {view === 'overview' && (
            <GraphOverviewView onBack={handleBackFromOverview} />
          )}
        </div>
      </div>
      
      <footer className="border-t mt-12 py-6">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>DreamNet Knowledge Graph Mapper v2.0 - Enhanced Edition</p>
          <p className="mt-1">All data stored locally in your browser • Press Cmd+K for command palette</p>
        </div>
      </footer>
      
      {/* Command Palette */}
      <CommandPalette 
        open={commandOpen} 
        onOpenChange={setCommandOpen}
        onEntitySelect={handleSelectEntity}
        onAction={handleCommandAction}
      />
    </main>
  );
}
