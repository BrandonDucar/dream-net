'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import type { GraphMetrics, EntityMetrics, DetectedPattern } from '@/types/knowledge-graph-extended';
import { GraphAnalytics } from '@/lib/graph-analytics';
import { KnowledgeGraphStorage } from '@/lib/storage';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316'];

export function AnalyticsDashboard() {
  const [graphMetrics, setGraphMetrics] = useState<GraphMetrics | null>(null);
  const [topEntities, setTopEntities] = useState<Array<{ entity: { id: string; name: string }; metrics: EntityMetrics }>>([]);
  const [patterns, setPatterns] = useState<DetectedPattern[]>([]);
  
  useEffect(() => {
    loadAnalytics();
  }, []);
  
  const loadAnalytics = () => {
    const metrics = GraphAnalytics.calculateGraphMetrics();
    setGraphMetrics(metrics);
    
    const entities = KnowledgeGraphStorage.getEntities();
    const entityMetrics = entities
      .map((entity) => ({
        entity: { id: entity.id, name: entity.name },
        metrics: GraphAnalytics.calculateEntityMetrics(entity.id),
      }))
      .sort((a, b) => b.metrics.healthScore - a.metrics.healthScore)
      .slice(0, 10);
    
    setTopEntities(entityMetrics);
    
    const detectedPatterns = GraphAnalytics.detectPatterns();
    setPatterns(detectedPatterns);
  };
  
  if (!graphMetrics) {
    return <div>Loading analytics...</div>;
  }
  
  const entitiesByTypeData = Object.entries(graphMetrics.entitiesByType).map(([type, count]) => ({
    name: type,
    value: count,
  }));
  
  const relationshipsByKindData = Object.entries(graphMetrics.relationshipsByKind)
    .map(([kind, count]) => ({
      name: kind,
      count,
    }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);
  
  return (
    <div className="space-y-6 p-6">
      <div>
        <h2 className="text-3xl font-bold">Analytics Dashboard</h2>
        <p className="text-gray-500">Comprehensive metrics and insights for your knowledge graph</p>
      </div>
      
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="entities">Entity Metrics</TabsTrigger>
          <TabsTrigger value="patterns">Patterns</TabsTrigger>
          <TabsTrigger value="health">Health Scores</TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Total Entities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{graphMetrics.totalEntities}</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Total Relationships</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{graphMetrics.totalRelationships}</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Network Density</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{(graphMetrics.networkDensity * 100).toFixed(1)}%</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Connected Components</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{graphMetrics.connectedComponents}</div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Entities by Type</CardTitle>
                <CardDescription>Distribution of entity types in your graph</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={entitiesByTypeData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={(entry) => `${entry.name}: ${entry.value}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {entitiesByTypeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Top Relationship Types</CardTitle>
                <CardDescription>Most common relationship kinds</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={relationshipsByKindData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#3b82f6" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Top Central Entities</CardTitle>
              <CardDescription>Entities with highest PageRank scores</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {graphMetrics.topCentralEntities.map((entity, index) => (
                  <div key={entity.entityId} className="flex items-center justify-between p-2 border rounded">
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline">{index + 1}</Badge>
                      <span className="font-medium">{entity.name}</span>
                    </div>
                    <div className="text-sm text-gray-500">
                      Score: {entity.score.toFixed(3)}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Entity Metrics Tab */}
        <TabsContent value="entities" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Top Entities by Health Score</CardTitle>
              <CardDescription>Entities with highest completeness and connectedness</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topEntities.map(({ entity, metrics }) => (
                  <div key={entity.id} className="space-y-2 p-4 border rounded">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{entity.name}</span>
                      <Badge>{metrics.healthScore}/100</Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                      <div>
                        <div className="text-gray-500">In Degree</div>
                        <div className="font-medium">{metrics.inDegree}</div>
                      </div>
                      <div>
                        <div className="text-gray-500">Out Degree</div>
                        <div className="font-medium">{metrics.outDegree}</div>
                      </div>
                      <div>
                        <div className="text-gray-500">Completeness</div>
                        <div className="font-medium">{metrics.completeness}%</div>
                      </div>
                      <div>
                        <div className="text-gray-500">Connectedness</div>
                        <div className="font-medium">{metrics.connectedness}%</div>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-gray-500">
                        <span>Health Score</span>
                        <span>{metrics.healthScore}%</span>
                      </div>
                      <Progress value={metrics.healthScore} />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Patterns Tab */}
        <TabsContent value="patterns" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Detected Patterns</CardTitle>
              <CardDescription>Automatically detected patterns in your graph</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {patterns.map((pattern) => (
                  <div key={pattern.id} className="p-4 border rounded space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Badge variant={pattern.patternType === 'isolated-entity' ? 'destructive' : 'default'}>
                          {pattern.patternType}
                        </Badge>
                        <span className="font-medium">{pattern.name}</span>
                      </div>
                      <div className="text-sm text-gray-500">
                        Significance: {(pattern.significance * 100).toFixed(0)}%
                      </div>
                    </div>
                    <div className="text-sm text-gray-600">{pattern.description}</div>
                    <div className="text-xs text-gray-500">
                      {pattern.entityIds.length} entities involved
                    </div>
                  </div>
                ))}
                
                {patterns.length === 0 && (
                  <div className="text-center text-gray-500 py-8">
                    No patterns detected yet. Add more entities and relationships!
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Health Tab */}
        <TabsContent value="health" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Average Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Average Degree</span>
                    <span>{graphMetrics.averageDegree.toFixed(2)}</span>
                  </div>
                  <Progress value={Math.min(graphMetrics.averageDegree * 10, 100)} />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Clustering Coefficient</span>
                    <span>{(graphMetrics.clusteringCoefficient * 100).toFixed(1)}%</span>
                  </div>
                  <Progress value={graphMetrics.clusteringCoefficient * 100} />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Average Path Length</span>
                    <span>{graphMetrics.averagePathLength.toFixed(2)}</span>
                  </div>
                  <Progress value={Math.min(graphMetrics.averagePathLength * 10, 100)} />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Graph Health</CardTitle>
                <CardDescription>Overall knowledge graph quality indicators</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Connectivity</span>
                  <Badge variant={graphMetrics.networkDensity > 0.3 ? 'default' : 'secondary'}>
                    {graphMetrics.networkDensity > 0.3 ? 'Good' : 'Sparse'}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Components</span>
                  <Badge variant={graphMetrics.connectedComponents === 1 ? 'default' : 'secondary'}>
                    {graphMetrics.connectedComponents === 1 ? 'Unified' : 'Fragmented'}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Size</span>
                  <Badge>{graphMetrics.totalEntities > 50 ? 'Large' : graphMetrics.totalEntities > 20 ? 'Medium' : 'Small'}</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
