'use client';

import { useEffect, useState, useCallback } from 'react';
import { Command, CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from './ui/command';
import type { Entity, RelationshipEdge, EntityGroup } from '@/types/knowledge-graph';
import { KnowledgeGraphStorage } from '@/lib/storage';
import Fuse from 'fuse.js';

interface CommandPaletteProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onEntitySelect?: (entityId: string) => void;
  onAction?: (action: string, params?: Record<string, unknown>) => void;
}

export function CommandPalette({ open, onOpenChange, onEntitySelect, onAction }: CommandPaletteProps) {
  const [search, setSearch] = useState('');
  const [results, setResults] = useState<{
    entities: Entity[];
    relationships: RelationshipEdge[];
    groups: EntityGroup[];
  }>({
    entities: [],
    relationships: [],
    groups: [],
  });
  
  useEffect(() => {
    if (!open) {
      setSearch('');
      return;
    }
    
    if (search.length < 2) {
      setResults({ entities: [], relationships: [], groups: [] });
      return;
    }
    
    const entities = KnowledgeGraphStorage.getEntities();
    const relationships = KnowledgeGraphStorage.getRelationships();
    const groups = KnowledgeGraphStorage.getGroups();
    
    // Use Fuse.js for fuzzy search
    const entityFuse = new Fuse(entities, {
      keys: ['name', 'description', 'tags', 'type', 'slug', 'externalRef'],
      threshold: 0.3,
    });
    
    const relFuse = new Fuse(relationships, {
      keys: ['kind', 'description', 'context', 'tags'],
      threshold: 0.3,
    });
    
    const groupFuse = new Fuse(groups, {
      keys: ['name', 'description', 'tags'],
      threshold: 0.3,
    });
    
    const entityResults = entityFuse.search(search).map((r) => r.item);
    const relResults = relFuse.search(search).map((r) => r.item);
    const groupResults = groupFuse.search(search).map((r) => r.item);
    
    setResults({
      entities: entityResults.slice(0, 10),
      relationships: relResults.slice(0, 5),
      groups: groupResults.slice(0, 5),
    });
  }, [search, open]);
  
  const actions = [
    { id: 'create-entity', label: '➕ Create Entity', keywords: 'new add entity' },
    { id: 'create-relationship', label: '🔗 Create Relationship', keywords: 'new add relationship edge' },
    { id: 'create-group', label: '📁 Create Group', keywords: 'new add group collection' },
    { id: 'create-path-template', label: '🛤️ Create Path Template', keywords: 'new add path template pattern' },
    { id: 'view-graph', label: '🌐 View Graph Visualization', keywords: 'graph visual network' },
    { id: 'view-analytics', label: '📊 View Analytics Dashboard', keywords: 'analytics metrics stats' },
    { id: 'export-json', label: '💾 Export as JSON', keywords: 'export download backup json' },
    { id: 'export-csv', label: '📊 Export as CSV', keywords: 'export download backup csv' },
    { id: 'import-data', label: '📥 Import Data', keywords: 'import upload load' },
    { id: 'create-snapshot', label: '📸 Create Snapshot', keywords: 'snapshot backup version save' },
    { id: 'view-history', label: '📜 View History', keywords: 'history changelog audit log' },
    { id: 'view-suggestions', label: '💡 View Smart Suggestions', keywords: 'suggestions recommendations ai' },
    { id: 'validate-constraints', label: '✓ Validate Constraints', keywords: 'validate check rules constraints' },
    { id: 'detect-patterns', label: '🔍 Detect Patterns', keywords: 'patterns detect find' },
    { id: 'switch-workspace', label: '🔄 Switch Workspace', keywords: 'workspace switch change' },
  ];
  
  const handleSelect = useCallback((value: string) => {
    if (value.startsWith('entity-')) {
      const entityId = value.substring(7);
      onEntitySelect?.(entityId);
    } else if (value.startsWith('action-')) {
      const actionId = value.substring(7);
      onAction?.(actionId);
    }
    onOpenChange(false);
  }, [onEntitySelect, onAction, onOpenChange]);
  
  return (
    <CommandDialog open={open} onOpenChange={onOpenChange}>
      <CommandInput 
        placeholder="Search entities, actions, or type a command..." 
        value={search}
        onValueChange={setSearch}
      />
      <CommandList>
        <CommandEmpty>No results found.</CommandEmpty>
        
        {/* Actions */}
        {search && (
          <CommandGroup heading="Actions">
            {actions
              .filter((action) => 
                action.label.toLowerCase().includes(search.toLowerCase()) ||
                action.keywords.toLowerCase().includes(search.toLowerCase())
              )
              .map((action) => (
                <CommandItem
                  key={action.id}
                  value={`action-${action.id}`}
                  onSelect={handleSelect}
                >
                  {action.label}
                </CommandItem>
              ))}
          </CommandGroup>
        )}
        
        {/* Entities */}
        {results.entities.length > 0 && (
          <CommandGroup heading="Entities">
            {results.entities.map((entity) => (
              <CommandItem
                key={entity.id}
                value={`entity-${entity.id}`}
                onSelect={handleSelect}
              >
                <div className="flex items-center space-x-2">
                  <span>{entity.primaryEmoji || '🔷'}</span>
                  <div>
                    <div className="font-medium">{entity.name}</div>
                    <div className="text-xs text-gray-500">
                      {entity.type} {entity.canonical && '⭐'}
                    </div>
                  </div>
                </div>
              </CommandItem>
            ))}
          </CommandGroup>
        )}
        
        {/* Groups */}
        {results.groups.length > 0 && (
          <CommandGroup heading="Groups">
            {results.groups.map((group) => (
              <CommandItem
                key={group.id}
                value={`group-${group.id}`}
                onSelect={handleSelect}
              >
                <div>
                  <div className="font-medium">📁 {group.name}</div>
                  <div className="text-xs text-gray-500">
                    {group.entityIds.length} entities
                  </div>
                </div>
              </CommandItem>
            ))}
          </CommandGroup>
        )}
      </CommandList>
    </CommandDialog>
  );
}

// Hook for keyboard shortcut
export function useCommandPalette() {
  const [open, setOpen] = useState(false);
  
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((open) => !open);
      }
    };
    
    document.addEventListener('keydown', down);
    return () => document.removeEventListener('keydown', down);
  }, []);
  
  return { open, setOpen };
}
