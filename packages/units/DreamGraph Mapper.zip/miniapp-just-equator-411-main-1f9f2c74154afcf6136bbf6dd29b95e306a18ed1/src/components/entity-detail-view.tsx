'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import type { Entity, RelationshipEdge, EntityGroup } from '@/types/knowledge-graph';
import { KnowledgeGraphService } from '@/lib/knowledge-graph-service';
import { EntityFormDialog } from './entity-form-dialog';
import { RelationshipFormDialog } from './relationship-form-dialog';
import { ArrowLeft, Star, Copy, Check } from 'lucide-react';

interface EntityDetailViewProps {
  entityId: string;
  onBack: () => void;
  onRefresh: () => void;
}

export function EntityDetailView({ entityId, onBack, onRefresh }: EntityDetailViewProps): JSX.Element {
  const [copied, setCopied] = useState(false);
  const [summary, setSummary] = useState('');
  
  const detail = KnowledgeGraphService.getEntityDetail(entityId);
  
  if (!detail) {
    return (
      <div className="p-8 text-center">
        <p className="text-muted-foreground">Entity not found</p>
        <Button onClick={onBack} className="mt-4">
          Go Back
        </Button>
      </div>
    );
  }
  
  const { entity, inboundEdges, outboundEdges, groups } = detail;
  const allEntities = KnowledgeGraphService.listEntities();
  
  const toggleCanonical = (): void => {
    KnowledgeGraphService.setEntityCanonical(entityId, !entity.canonical);
    onRefresh();
  };
  
  const regenerateSEO = (): void => {
    KnowledgeGraphService.regenerateSEO(entityId);
    onRefresh();
  };
  
  const generateSummary = (): void => {
    const newSummary = KnowledgeGraphService.generateEntityGraphSummary(entityId);
    setSummary(newSummary);
  };
  
  const copyToClipboard = (text: string): void => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  const deleteEntity = (): void => {
    if (confirm(`Delete "${entity.name}"? This will also remove all its relationships.`)) {
      KnowledgeGraphService.deleteEntity(entityId);
      onBack();
    }
  };
  
  const getEntityName = (id: string): string => {
    const e = allEntities.find((ent: Entity) => ent.id === id);
    return e ? e.name : 'Unknown';
  };
  
  const getEntityEmoji = (id: string): string => {
    const e = allEntities.find((ent: Entity) => ent.id === id);
    return e?.primaryEmoji || '•';
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button onClick={onBack} variant="ghost" size="sm">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Entities
        </Button>
        
        <div className="flex items-center gap-2">
          <EntityFormDialog entity={entity} onSave={onRefresh} trigger={<Button size="sm" variant="outline">Edit</Button>} />
          <Button size="sm" variant="destructive" onClick={deleteEntity}>
            Delete
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              {entity.primaryEmoji && <span className="text-4xl">{entity.primaryEmoji}</span>}
              <div>
                <CardTitle className="text-2xl">{entity.name}</CardTitle>
                <CardDescription className="mt-1">{entity.slug}</CardDescription>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {entity.canonical && <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />}
              <Badge variant={entity.importanceLevel === 'critical' ? 'destructive' : 'secondary'}>
                {entity.importanceLevel}
              </Badge>
              <Badge variant="outline">{entity.type}</Badge>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div>
            <p className="text-sm text-muted-foreground mb-2">Description</p>
            <p>{entity.description || 'No description'}</p>
          </div>
          
          <div className="grid grid-cols-3 gap-4 text-sm">
            {entity.sourceMiniApp && (
              <div>
                <p className="text-muted-foreground">Source</p>
                <p className="font-medium">{entity.sourceMiniApp}</p>
              </div>
            )}
            {entity.externalRef && (
              <div>
                <p className="text-muted-foreground">External Ref</p>
                <p className="font-medium truncate">{entity.externalRef}</p>
              </div>
            )}
            {entity.chain && (
              <div>
                <p className="text-muted-foreground">Chain</p>
                <p className="font-medium">{entity.chain}</p>
              </div>
            )}
          </div>
          
          {entity.tags.length > 0 && (
            <div>
              <p className="text-sm text-muted-foreground mb-2">Tags</p>
              <div className="flex flex-wrap gap-2">
                {entity.tags.map((tag: string) => (
                  <Badge key={tag} variant="secondary">{tag}</Badge>
                ))}
              </div>
            </div>
          )}
          
          <Separator />
          
          <div className="flex items-center justify-between">
            <Label htmlFor="canonical" className="text-sm">Canonical Entity</Label>
            <Switch id="canonical" checked={entity.canonical} onCheckedChange={toggleCanonical} />
          </div>
        </CardContent>
      </Card>
      
      <Tabs defaultValue="relationships" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="relationships">Relationships</TabsTrigger>
          <TabsTrigger value="groups">Groups</TabsTrigger>
          <TabsTrigger value="seo">SEO</TabsTrigger>
          <TabsTrigger value="summary">Summary</TabsTrigger>
        </TabsList>
        
        <TabsContent value="relationships" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Outgoing Connections ({outboundEdges.length})</CardTitle>
                <RelationshipFormDialog 
                  defaultFromEntityId={entityId} 
                  onSave={onRefresh}
                  trigger={<Button size="sm">Create From Here</Button>}
                />
              </div>
            </CardHeader>
            <CardContent>
              {outboundEdges.length === 0 ? (
                <p className="text-sm text-muted-foreground">No outgoing connections</p>
              ) : (
                <div className="space-y-2">
                  {outboundEdges.map((edge: RelationshipEdge) => (
                    <div key={edge.id} className="flex items-start justify-between p-3 bg-muted rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline">{edge.kind}</Badge>
                          <Badge variant="secondary">{edge.strength}</Badge>
                          <span className="text-sm">→</span>
                          <span className="font-medium">
                            {getEntityEmoji(edge.toEntityId)} {getEntityName(edge.toEntityId)}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground">{edge.description}</p>
                        {edge.context && <p className="text-xs text-muted-foreground mt-1">Context: {edge.context}</p>}
                      </div>
                      <RelationshipFormDialog relationship={edge} onSave={onRefresh} trigger={<Button size="sm" variant="ghost">Edit</Button>} />
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Incoming Connections ({inboundEdges.length})</CardTitle>
                <RelationshipFormDialog 
                  defaultToEntityId={entityId} 
                  onSave={onRefresh}
                  trigger={<Button size="sm">Create To Here</Button>}
                />
              </div>
            </CardHeader>
            <CardContent>
              {inboundEdges.length === 0 ? (
                <p className="text-sm text-muted-foreground">No incoming connections</p>
              ) : (
                <div className="space-y-2">
                  {inboundEdges.map((edge: RelationshipEdge) => (
                    <div key={edge.id} className="flex items-start justify-between p-3 bg-muted rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium">
                            {getEntityEmoji(edge.fromEntityId)} {getEntityName(edge.fromEntityId)}
                          </span>
                          <span className="text-sm">→</span>
                          <Badge variant="outline">{edge.kind}</Badge>
                          <Badge variant="secondary">{edge.strength}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{edge.description}</p>
                        {edge.context && <p className="text-xs text-muted-foreground mt-1">Context: {edge.context}</p>}
                      </div>
                      <RelationshipFormDialog relationship={edge} onSave={onRefresh} trigger={<Button size="sm" variant="ghost">Edit</Button>} />
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="groups" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Member of {groups.length} Group(s)</CardTitle>
            </CardHeader>
            <CardContent>
              {groups.length === 0 ? (
                <p className="text-sm text-muted-foreground">Not in any groups</p>
              ) : (
                <div className="space-y-2">
                  {groups.map((group: EntityGroup) => (
                    <div key={group.id} className="p-3 bg-muted rounded-lg">
                      <h4 className="font-medium mb-1">📦 {group.name}</h4>
                      <p className="text-sm text-muted-foreground">{group.description}</p>
                      <p className="text-xs text-muted-foreground mt-1">{group.entityIds.length} members</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="seo" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>SEO Metadata</CardTitle>
                <Button size="sm" onClick={regenerateSEO}>
                  Regenerate
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm text-muted-foreground">Title</Label>
                <p className="mt-1">{entity.seoTitle}</p>
              </div>
              <div>
                <Label className="text-sm text-muted-foreground">Description</Label>
                <p className="mt-1">{entity.seoDescription}</p>
              </div>
              <div>
                <Label className="text-sm text-muted-foreground">Keywords</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {entity.seoKeywords.map((kw: string, i: number) => (
                    <Badge key={i} variant="secondary">{kw}</Badge>
                  ))}
                </div>
              </div>
              <div>
                <Label className="text-sm text-muted-foreground">Hashtags</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {entity.seoHashtags.map((tag: string, i: number) => (
                    <Badge key={i} variant="outline">{tag}</Badge>
                  ))}
                </div>
              </div>
              <div>
                <Label className="text-sm text-muted-foreground">Alt Text</Label>
                <p className="mt-1">{entity.altText}</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="summary" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Entity Graph Summary</CardTitle>
                <div className="flex items-center gap-2">
                  {summary && (
                    <Button size="sm" variant="outline" onClick={() => copyToClipboard(summary)}>
                      {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                      {copied ? 'Copied!' : 'Copy'}
                    </Button>
                  )}
                  <Button size="sm" onClick={generateSummary}>
                    Generate Summary
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {summary ? (
                <Textarea
                  value={summary}
                  readOnly
                  className="font-mono text-xs min-h-[400px]"
                />
              ) : (
                <p className="text-sm text-muted-foreground">
                  Click "Generate Summary" to create a readable text summary of this entity and its connections
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
