'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import type { Entity, EntityType, ImportanceLevel, EntityFilter } from '@/types/knowledge-graph';
import { KnowledgeGraphService } from '@/lib/knowledge-graph-service';
import { EntityFormDialog } from './entity-form-dialog';
import { Star, Search } from 'lucide-react';

interface EntityExplorerProps {
  onSelectEntity: (entityId: string) => void;
  onViewOverview: () => void;
}

export function EntityExplorer({ onSelectEntity, onViewOverview }: EntityExplorerProps): JSX.Element {
  const [entities, setEntities] = useState<Entity[]>([]);
  const [filter, setFilter] = useState<EntityFilter>({});
  const [searchText, setSearchText] = useState('');
  
  const loadEntities = (): void => {
    const loaded = KnowledgeGraphService.listEntities(filter);
    setEntities(loaded);
  };
  
  useEffect(() => {
    loadEntities();
  }, [filter]);
  
  const handleSearch = (): void => {
    setFilter({ ...filter, searchText });
  };
  
  const clearFilters = (): void => {
    setFilter({});
    setSearchText('');
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Entity Explorer</h1>
          <p className="text-muted-foreground mt-1">
            Manage all entities in your DreamNet knowledge graph
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={onViewOverview}>
            View Graph Overview
          </Button>
          <EntityFormDialog onSave={loadEntities} />
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
          <CardDescription>Filter and search entities</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-4">
            <div className="col-span-2">
              <div className="flex gap-2">
                <Input
                  placeholder="Search by name, description, or tags..."
                  value={searchText}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchText(e.target.value)}
                  onKeyDown={(e: React.KeyboardEvent) => {
                    if (e.key === 'Enter') {
                      handleSearch();
                    }
                  }}
                />
                <Button onClick={handleSearch}>
                  <Search className="w-4 h-4" />
                </Button>
              </div>
            </div>
            
            <Select
              value={filter.type || 'all'}
              onValueChange={(value: string) => setFilter({ ...filter, type: value === 'all' ? undefined : value as EntityType })}
            >
              <SelectTrigger>
                <SelectValue placeholder="All types" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                <SelectItem value="token">token</SelectItem>
                <SelectItem value="culture-coin">culture-coin</SelectItem>
                <SelectItem value="wallet">wallet</SelectItem>
                <SelectItem value="mini-app">mini-app</SelectItem>
                <SelectItem value="agent">agent</SelectItem>
                <SelectItem value="backend-model">backend-model</SelectItem>
                <SelectItem value="backend-endpoint">backend-endpoint</SelectItem>
                <SelectItem value="drop">drop</SelectItem>
                <SelectItem value="campaign">campaign</SelectItem>
                <SelectItem value="content-stream">content-stream</SelectItem>
                <SelectItem value="social-account">social-account</SelectItem>
                <SelectItem value="segment">segment</SelectItem>
                <SelectItem value="audience">audience</SelectItem>
                <SelectItem value="pickleball">pickleball</SelectItem>
                <SelectItem value="infra">infra</SelectItem>
                <SelectItem value="other">other</SelectItem>
              </SelectContent>
            </Select>
            
            <Select
              value={filter.importanceLevel || 'all'}
              onValueChange={(value: string) => setFilter({ ...filter, importanceLevel: value === 'all' ? undefined : value as ImportanceLevel })}
            >
              <SelectTrigger>
                <SelectValue placeholder="All importance" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All importance</SelectItem>
                <SelectItem value="low">low</SelectItem>
                <SelectItem value="medium">medium</SelectItem>
                <SelectItem value="high">high</SelectItem>
                <SelectItem value="critical">critical</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center gap-2 mt-4">
            <Button
              size="sm"
              variant={filter.canonical === true ? 'default' : 'outline'}
              onClick={() => setFilter({ ...filter, canonical: filter.canonical === true ? undefined : true })}
            >
              <Star className="w-4 h-4 mr-2" />
              Canonical Only
            </Button>
            
            <Button size="sm" variant="ghost" onClick={clearFilters}>
              Clear Filters
            </Button>
            
            <div className="ml-auto text-sm text-muted-foreground">
              {entities.length} {entities.length === 1 ? 'entity' : 'entities'}
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Entities</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12"></TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Importance</TableHead>
                  <TableHead>Tags</TableHead>
                  <TableHead className="w-24">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {entities.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground">
                      No entities found. Create your first entity to get started!
                    </TableCell>
                  </TableRow>
                ) : (
                  entities.map((entity: Entity) => (
                    <TableRow key={entity.id} className="cursor-pointer hover:bg-muted/50" onClick={() => onSelectEntity(entity.id)}>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {entity.canonical && <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />}
                          {entity.primaryEmoji && <span>{entity.primaryEmoji}</span>}
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{entity.name}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{entity.type}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={entity.importanceLevel === 'critical' ? 'destructive' : 'secondary'}>
                          {entity.importanceLevel}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {entity.tags.slice(0, 3).map((tag: string) => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                          {entity.tags.length > 3 && (
                            <Badge variant="secondary" className="text-xs">
                              +{entity.tags.length - 3}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell onClick={(e: React.MouseEvent) => e.stopPropagation()}>
                        <Button size="sm" variant="ghost" onClick={() => onSelectEntity(entity.id)}>
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
