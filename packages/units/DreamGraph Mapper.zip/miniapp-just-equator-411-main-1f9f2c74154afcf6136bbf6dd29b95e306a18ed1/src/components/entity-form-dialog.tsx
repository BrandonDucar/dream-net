'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { Entity, EntityType, ImportanceLevel, CreateEntityInput } from '@/types/knowledge-graph';
import { KnowledgeGraphService } from '@/lib/knowledge-graph-service';

interface EntityFormDialogProps {
  entity?: Entity;
  onSave: () => void;
  trigger?: React.ReactNode;
}

const ENTITY_TYPES: EntityType[] = [
  'token',
  'culture-coin',
  'wallet',
  'mini-app',
  'agent',
  'backend-model',
  'backend-endpoint',
  'drop',
  'campaign',
  'content-stream',
  'social-account',
  'segment',
  'audience',
  'pickleball',
  'infra',
  'other',
];

const IMPORTANCE_LEVELS: ImportanceLevel[] = ['low', 'medium', 'high', 'critical'];

export function EntityFormDialog({ entity, onSave, trigger }: EntityFormDialogProps): JSX.Element {
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState<CreateEntityInput>({
    type: entity?.type || 'other',
    name: entity?.name || '',
    slug: entity?.slug || '',
    description: entity?.description || '',
    primaryEmoji: entity?.primaryEmoji || '',
    importanceLevel: entity?.importanceLevel || 'medium',
    sourceMiniApp: entity?.sourceMiniApp || '',
    externalRef: entity?.externalRef || '',
    chain: entity?.chain || '',
    tags: entity?.tags || [],
  });
  
  const [tagInput, setTagInput] = useState('');
  
  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    
    if (entity) {
      KnowledgeGraphService.updateEntity({
        id: entity.id,
        ...formData,
      });
    } else {
      KnowledgeGraphService.createEntity(formData);
    }
    
    setOpen(false);
    onSave();
  };
  
  const addTag = (): void => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, tagInput.trim()],
      });
      setTagInput('');
    }
  };
  
  const removeTag = (tag: string): void => {
    setFormData({
      ...formData,
      tags: formData.tags.filter((t: string) => t !== tag),
    });
  };
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || <Button>{entity ? 'Edit Entity' : 'Create Entity'}</Button>}
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{entity ? 'Edit Entity' : 'Create New Entity'}</DialogTitle>
          <DialogDescription>
            {entity ? 'Update entity details' : 'Add a new entity to the knowledge graph'}
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="type">Type *</Label>
              <Select
                value={formData.type}
                onValueChange={(value: EntityType) => setFormData({ ...formData, type: value })}
              >
                <SelectTrigger id="type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ENTITY_TYPES.map((type: EntityType) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="importanceLevel">Importance *</Label>
              <Select
                value={formData.importanceLevel}
                onValueChange={(value: ImportanceLevel) => setFormData({ ...formData, importanceLevel: value })}
              >
                <SelectTrigger id="importanceLevel">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {IMPORTANCE_LEVELS.map((level: ImportanceLevel) => (
                    <SelectItem key={level} value={level}>
                      {level}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="name">Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g. DREAM Token, DreamNet Drop Architect"
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="slug">Slug</Label>
              <Input
                id="slug"
                value={formData.slug}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, slug: e.target.value })}
                placeholder="auto-generated if empty"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="primaryEmoji">Emoji</Label>
              <Input
                id="primaryEmoji"
                value={formData.primaryEmoji}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, primaryEmoji: e.target.value })}
                placeholder="🌟"
                maxLength={2}
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe this entity..."
              rows={3}
            />
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="sourceMiniApp">Source Mini App</Label>
              <Input
                id="sourceMiniApp"
                value={formData.sourceMiniApp}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, sourceMiniApp: e.target.value })}
                placeholder="Drop Architect"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="externalRef">External Ref</Label>
              <Input
                id="externalRef"
                value={formData.externalRef}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, externalRef: e.target.value })}
                placeholder="address, handle, ID"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="chain">Chain</Label>
              <Input
                id="chain"
                value={formData.chain}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, chain: e.target.value })}
                placeholder="Base"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="tags">Tags</Label>
            <div className="flex gap-2">
              <Input
                id="tags"
                value={tagInput}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTagInput(e.target.value)}
                onKeyDown={(e: React.KeyboardEvent) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addTag();
                  }
                }}
                placeholder="Add a tag"
              />
              <Button type="button" onClick={addTag} variant="outline">
                Add
              </Button>
            </div>
            {formData.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {formData.tags.map((tag: string) => (
                  <span
                    key={tag}
                    className="bg-secondary text-secondary-foreground px-2 py-1 rounded text-sm flex items-center gap-1"
                  >
                    {tag}
                    <button
                      type="button"
                      onClick={() => removeTag(tag)}
                      className="hover:text-destructive"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>
          
          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit">
              {entity ? 'Update' : 'Create'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
