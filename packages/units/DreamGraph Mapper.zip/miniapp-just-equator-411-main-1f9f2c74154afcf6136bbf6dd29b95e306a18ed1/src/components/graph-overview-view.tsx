'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { KnowledgeGraphService } from '@/lib/knowledge-graph-service';
import { ArrowLeft, Copy, Check, Download } from 'lucide-react';

interface GraphOverviewViewProps {
  onBack: () => void;
}

export function GraphOverviewView({ onBack }: GraphOverviewViewProps): JSX.Element {
  const [overview, setOverview] = useState('');
  const [copied, setCopied] = useState(false);
  
  const generateOverview = (): void => {
    const newOverview = KnowledgeGraphService.exportGraphOverview();
    setOverview(newOverview);
  };
  
  const copyToClipboard = (): void => {
    navigator.clipboard.writeText(overview);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  const downloadOverview = (): void => {
    const blob = new Blob([overview], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dreamnet-knowledge-graph-overview-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button onClick={onBack} variant="ghost" size="sm">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Entities
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl">DreamNet Knowledge Graph Overview</CardTitle>
              <CardDescription className="mt-2">
                A comprehensive summary of all entities, relationships, groups, and patterns in your knowledge graph
              </CardDescription>
            </div>
            
            {!overview && (
              <Button onClick={generateOverview} size="lg">
                Generate Overview
              </Button>
            )}
          </div>
        </CardHeader>
        
        {overview && (
          <CardContent className="space-y-4">
            <div className="flex items-center gap-2">
              <Button onClick={copyToClipboard} variant="outline">
                {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                {copied ? 'Copied!' : 'Copy to Clipboard'}
              </Button>
              
              <Button onClick={downloadOverview} variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Download as TXT
              </Button>
              
              <Button onClick={generateOverview} variant="outline" className="ml-auto">
                Regenerate
              </Button>
            </div>
            
            <Textarea
              value={overview}
              readOnly
              className="font-mono text-xs min-h-[600px]"
            />
          </CardContent>
        )}
        
        {!overview && (
          <CardContent>
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-4">
                Generate a comprehensive overview of your entire knowledge graph
              </p>
              <p className="text-sm text-muted-foreground">
                This will include:
              </p>
              <ul className="text-sm text-muted-foreground mt-2 space-y-1 inline-block text-left">
                <li>• Total counts of entities, relationships, groups, and templates</li>
                <li>• Breakdown of entities by type</li>
                <li>• Breakdown of relationships by kind</li>
                <li>• List of canonical entities</li>
                <li>• List of critical entities</li>
                <li>• Entity groups with descriptions</li>
                <li>• Path templates</li>
              </ul>
            </div>
          </CardContent>
        )}
      </Card>
    </div>
  );
}
