'use client';

import { useCallback, useEffect, useState } from 'react';
import ReactFlow, {
  Node,
  Edge,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
  Panel,
  MiniMap,
} from 'reactflow';
import 'reactflow/dist/style.css';
import dagre from 'dagre';
import type { Entity, RelationshipEdge } from '@/types/knowledge-graph';
import type { LayoutConfig } from '@/types/knowledge-graph-extended';
import { KnowledgeGraphStorage } from '@/lib/storage';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';
import { Switch } from './ui/switch';

const NODE_WIDTH = 180;
const NODE_HEIGHT = 80;

const entityTypeColors: Record<string, string> = {
  token: '#10b981',
  'culture-coin': '#8b5cf6',
  wallet: '#f59e0b',
  'mini-app': '#3b82f6',
  agent: '#ef4444',
  'backend-model': '#6366f1',
  'backend-endpoint': '#14b8a6',
  drop: '#ec4899',
  campaign: '#f97316',
  'content-stream': '#06b6d4',
  'social-account': '#84cc16',
  segment: '#a855f7',
  audience: '#22d3ee',
  pickleball: '#fbbf24',
  infra: '#64748b',
  other: '#9ca3af',
};

export function GraphVisualization() {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [layout, setLayout] = useState<LayoutConfig>({
    algorithm: 'force',
    nodeSize: 'by-importance',
    nodeColor: 'by-type',
    edgeThickness: 'by-strength',
    showLabels: true,
    animate: false,
  });
  
  const [filterEntityTypes, setFilterEntityTypes] = useState<string[]>([]);
  const [filterRelationKinds, setFilterRelationKinds] = useState<string[]>([]);
  
  const loadGraphData = useCallback(() => {
    const entities = KnowledgeGraphStorage.getEntities();
    const relationships = KnowledgeGraphStorage.getRelationships();
    
    // Filter entities
    let filteredEntities = entities;
    if (filterEntityTypes.length > 0) {
      filteredEntities = entities.filter((e: Entity) => filterEntityTypes.includes(e.type));
    }
    
    // Filter relationships
    let filteredRelationships = relationships.filter((r: RelationshipEdge) => {
      const fromEntity = entities.find((e: Entity) => e.id === r.fromEntityId);
      const toEntity = entities.find((e: Entity) => e.id === r.toEntityId);
      
      if (!fromEntity || !toEntity) return false;
      
      if (filterEntityTypes.length > 0) {
        if (!filterEntityTypes.includes(fromEntity.type) || !filterEntityTypes.includes(toEntity.type)) {
          return false;
        }
      }
      
      if (filterRelationKinds.length > 0 && !filterRelationKinds.includes(r.kind)) {
        return false;
      }
      
      return true;
    });
    
    // Create nodes
    const reactFlowNodes: Node[] = filteredEntities.map((entity: Entity) => {
      const size = layout.nodeSize === 'by-degree' 
        ? Math.min(relationships.filter((r: RelationshipEdge) => r.fromEntityId === entity.id || r.toEntityId === entity.id).length * 20 + 60, 150)
        : layout.nodeSize === 'by-importance'
        ? entity.importanceLevel === 'critical' ? 120 : entity.importanceLevel === 'high' ? 100 : entity.importanceLevel === 'medium' ? 80 : 60
        : 80;
      
      let color = entityTypeColors[entity.type] || '#9ca3af';
      if (layout.nodeColor === 'by-importance') {
        color = entity.importanceLevel === 'critical' ? '#dc2626' : entity.importanceLevel === 'high' ? '#f59e0b' : entity.importanceLevel === 'medium' ? '#10b981' : '#6b7280';
      } else if (layout.nodeColor === 'by-canonical') {
        color = entity.canonical ? '#fbbf24' : '#6b7280';
      }
      
      return {
        id: entity.id,
        type: 'default',
        data: { 
          label: layout.showLabels ? `${entity.primaryEmoji || '🔷'} ${entity.name}` : entity.primaryEmoji || '🔷',
        },
        position: { x: 0, y: 0 },
        style: {
          background: color,
          color: '#ffffff',
          border: entity.canonical ? '3px solid #fbbf24' : 'none',
          borderRadius: '8px',
          padding: '10px',
          fontSize: '12px',
          fontWeight: entity.canonical ? 'bold' : 'normal',
          width: size,
          height: size / 2,
        },
      };
    });
    
    // Create edges
    const reactFlowEdges: Edge[] = filteredRelationships.map((rel: RelationshipEdge) => {
      const width = layout.edgeThickness === 'by-strength'
        ? rel.strength === 'critical' ? 4 : rel.strength === 'strong' ? 3 : rel.strength === 'normal' ? 2 : 1
        : 2;
      
      return {
        id: rel.id,
        source: rel.fromEntityId,
        target: rel.toEntityId,
        label: layout.showLabels ? rel.kind : undefined,
        type: rel.direction === 'bidirectional' ? 'default' : 'default',
        animated: layout.animate && rel.strength === 'critical',
        style: {
          strokeWidth: width,
          stroke: rel.strength === 'critical' ? '#dc2626' : '#6b7280',
        },
        labelStyle: {
          fontSize: '10px',
          fill: '#374151',
        },
      };
    });
    
    // Apply layout
    if (layout.algorithm === 'hierarchical' || layout.algorithm === 'force') {
      const layoutedNodes = applyDagreLayout(reactFlowNodes, reactFlowEdges, layout.algorithm);
      setNodes(layoutedNodes);
    } else {
      setNodes(reactFlowNodes);
    }
    
    setEdges(reactFlowEdges);
  }, [filterEntityTypes, filterRelationKinds, layout, setNodes, setEdges]);
  
  useEffect(() => {
    loadGraphData();
  }, [loadGraphData]);
  
  const applyDagreLayout = (nodes: Node[], edges: Edge[], direction: string): Node[] => {
    const dagreGraph = new dagre.graphlib.Graph();
    dagreGraph.setDefaultEdgeLabel(() => ({}));
    dagreGraph.setGraph({ rankdir: direction === 'hierarchical' ? 'TB' : 'LR' });
    
    nodes.forEach((node) => {
      dagreGraph.setNode(node.id, { width: NODE_WIDTH, height: NODE_HEIGHT });
    });
    
    edges.forEach((edge) => {
      dagreGraph.setEdge(edge.source, edge.target);
    });
    
    dagre.layout(dagreGraph);
    
    return nodes.map((node) => {
      const nodeWithPosition = dagreGraph.node(node.id);
      return {
        ...node,
        position: {
          x: nodeWithPosition.x - NODE_WIDTH / 2,
          y: nodeWithPosition.y - NODE_HEIGHT / 2,
        },
      };
    });
  };
  
  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );
  
  return (
    <div className="h-screen w-full relative">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        fitView
      >
        <Background />
        <Controls />
        <MiniMap 
          nodeColor={(node) => node.style?.background as string || '#6b7280'}
          maskColor="rgba(0, 0, 0, 0.1)"
        />
        
        <Panel position="top-right" className="bg-white p-4 rounded-lg shadow-lg space-y-4 max-w-sm">
          <div className="space-y-2">
            <Label>Layout Algorithm</Label>
            <Select 
              value={layout.algorithm} 
              onValueChange={(value) => setLayout({ ...layout, algorithm: value as LayoutConfig['algorithm'] })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="force">Force-Directed</SelectItem>
                <SelectItem value="hierarchical">Hierarchical</SelectItem>
                <SelectItem value="circular">Circular</SelectItem>
                <SelectItem value="grid">Grid</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label>Node Size</Label>
            <Select 
              value={layout.nodeSize} 
              onValueChange={(value) => setLayout({ ...layout, nodeSize: value as LayoutConfig['nodeSize'] })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="uniform">Uniform</SelectItem>
                <SelectItem value="by-degree">By Degree</SelectItem>
                <SelectItem value="by-importance">By Importance</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label>Node Color</Label>
            <Select 
              value={layout.nodeColor} 
              onValueChange={(value) => setLayout({ ...layout, nodeColor: value as LayoutConfig['nodeColor'] })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="by-type">By Type</SelectItem>
                <SelectItem value="by-importance">By Importance</SelectItem>
                <SelectItem value="by-canonical">By Canonical</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center space-x-2">
            <Switch 
              checked={layout.showLabels} 
              onCheckedChange={(checked) => setLayout({ ...layout, showLabels: checked })}
            />
            <Label>Show Labels</Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Switch 
              checked={layout.animate} 
              onCheckedChange={(checked) => setLayout({ ...layout, animate: checked })}
            />
            <Label>Animate Critical</Label>
          </div>
          
          <Button onClick={loadGraphData} className="w-full">
            Refresh Graph
          </Button>
        </Panel>
      </ReactFlow>
    </div>
  );
}
