'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import type { Entity, EntityGroup, PathTemplate, PathMatch } from '@/types/knowledge-graph';
import { KnowledgeGraphService } from '@/lib/knowledge-graph-service';
import { Copy, Check } from 'lucide-react';

export function GroupsPathTemplatesView(): JSX.Element {
  const [groups, setGroups] = useState<EntityGroup[]>([]);
  const [pathTemplates, setPathTemplates] = useState<PathTemplate[]>([]);
  const [selectedGroup, setSelectedGroup] = useState<string | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [groupSummary, setGroupSummary] = useState('');
  const [pathMatches, setPathMatches] = useState<PathMatch[]>([]);
  const [testEntityId, setTestEntityId] = useState('');
  const [copied, setCopied] = useState(false);
  
  const loadData = (): void => {
    setGroups(KnowledgeGraphService.listEntityGroups());
    setPathTemplates(KnowledgeGraphService.listPathTemplates());
  };
  
  useEffect(() => {
    loadData();
  }, []);
  
  const generateGroupSummary = (groupId: string): void => {
    const summary = KnowledgeGraphService.generateGroupSummary(groupId);
    setGroupSummary(summary);
  };
  
  const testPathTemplate = (templateId: string, entityId?: string): void => {
    const matches = KnowledgeGraphService.matchPathTemplate(templateId, entityId);
    setPathMatches(matches);
  };
  
  const copyToClipboard = (text: string): void => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Groups & Path Templates</h1>
        <p className="text-muted-foreground mt-1">
          Organize entities into groups and define expected relationship patterns
        </p>
      </div>
      
      <Tabs defaultValue="groups" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="groups">Groups</TabsTrigger>
          <TabsTrigger value="templates">Path Templates</TabsTrigger>
        </TabsList>
        
        <TabsContent value="groups" className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Entity Groups ({groups.length})</h2>
            <CreateGroupDialog onSave={loadData} />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Groups List</CardTitle>
              </CardHeader>
              <CardContent>
                {groups.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No groups yet. Create one to get started!</p>
                ) : (
                  <div className="space-y-2">
                    {groups.map((group: EntityGroup) => (
                      <div
                        key={group.id}
                        className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                          selectedGroup === group.id ? 'bg-primary/10 border-primary' : 'hover:bg-muted'
                        }`}
                        onClick={() => setSelectedGroup(group.id)}
                      >
                        <h4 className="font-medium">📦 {group.name}</h4>
                        <p className="text-sm text-muted-foreground mt-1">{group.entityIds.length} members</p>
                        {group.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-2">
                            {group.tags.map((tag: string) => (
                              <Badge key={tag} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Group Details</CardTitle>
              </CardHeader>
              <CardContent>
                {selectedGroup ? (
                  <GroupDetail
                    groupId={selectedGroup}
                    onGenerateSummary={generateGroupSummary}
                    summary={groupSummary}
                    onCopy={copyToClipboard}
                    copied={copied}
                    onUpdate={loadData}
                  />
                ) : (
                  <p className="text-sm text-muted-foreground">Select a group to view details</p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="templates" className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Path Templates ({pathTemplates.length})</h2>
            <CreatePathTemplateDialog onSave={loadData} />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Templates List</CardTitle>
              </CardHeader>
              <CardContent>
                {pathTemplates.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No templates yet. Create one to get started!</p>
                ) : (
                  <div className="space-y-2">
                    {pathTemplates.map((template: PathTemplate) => (
                      <div
                        key={template.id}
                        className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                          selectedTemplate === template.id ? 'bg-primary/10 border-primary' : 'hover:bg-muted'
                        }`}
                        onClick={() => setSelectedTemplate(template.id)}
                      >
                        <h4 className="font-medium">🛤️  {template.name}</h4>
                        <p className="text-xs text-muted-foreground mt-1">
                          {template.nodeTypes.join(' → ')}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Template Details</CardTitle>
              </CardHeader>
              <CardContent>
                {selectedTemplate ? (
                  <PathTemplateDetail
                    templateId={selectedTemplate}
                    onTest={testPathTemplate}
                    matches={pathMatches}
                    testEntityId={testEntityId}
                    onTestEntityIdChange={setTestEntityId}
                    onUpdate={loadData}
                  />
                ) : (
                  <p className="text-sm text-muted-foreground">Select a template to view details</p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function CreateGroupDialog({ onSave }: { onSave: () => void }): JSX.Element {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [selectedEntityIds, setSelectedEntityIds] = useState<string[]>([]);
  const [entities, setEntities] = useState<Entity[]>([]);
  
  const handleOpenChange = (isOpen: boolean): void => {
    setOpen(isOpen);
    if (isOpen) {
      setEntities(KnowledgeGraphService.listEntities());
    }
  };
  
  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    KnowledgeGraphService.createEntityGroup({
      name,
      description,
      entityIds: selectedEntityIds,
      tags,
    });
    setOpen(false);
    setName('');
    setDescription('');
    setTags([]);
    setSelectedEntityIds([]);
    onSave();
  };
  
  const addTag = (): void => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };
  
  const toggleEntity = (entityId: string): void => {
    if (selectedEntityIds.includes(entityId)) {
      setSelectedEntityIds(selectedEntityIds.filter((id: string) => id !== entityId));
    } else {
      setSelectedEntityIds([...selectedEntityIds, entityId]);
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button>Create Group</Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Entity Group</DialogTitle>
          <DialogDescription>Group related entities together</DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="group-name">Name *</Label>
            <Input
              id="group-name"
              value={name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
              placeholder="e.g. Core DreamNet Spine"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="group-description">Description</Label>
            <Textarea
              id="group-description"
              value={description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
              placeholder="Describe this group..."
              rows={3}
            />
          </div>
          
          <div className="space-y-2">
            <Label>Tags</Label>
            <div className="flex gap-2">
              <Input
                value={tagInput}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTagInput(e.target.value)}
                onKeyDown={(e: React.KeyboardEvent) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addTag();
                  }
                }}
                placeholder="Add a tag"
              />
              <Button type="button" onClick={addTag} variant="outline">
                Add
              </Button>
            </div>
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {tags.map((tag: string) => (
                  <Badge key={tag} variant="secondary">
                    {tag}
                    <button
                      type="button"
                      onClick={() => setTags(tags.filter((t: string) => t !== tag))}
                      className="ml-1 hover:text-destructive"
                    >
                      ×
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>
          
          <Separator />
          
          <div className="space-y-2">
            <Label>Select Members</Label>
            <div className="border rounded-md max-h-60 overflow-y-auto p-2 space-y-1">
              {entities.map((entity: Entity) => (
                <div
                  key={entity.id}
                  className={`p-2 rounded cursor-pointer ${
                    selectedEntityIds.includes(entity.id) ? 'bg-primary/10' : 'hover:bg-muted'
                  }`}
                  onClick={() => toggleEntity(entity.id)}
                >
                  <span className="text-sm">
                    {entity.primaryEmoji || '•'} {entity.name} <Badge variant="outline" className="ml-2">{entity.type}</Badge>
                  </span>
                </div>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">{selectedEntityIds.length} selected</p>
          </div>
          
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit">Create</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function GroupDetail({
  groupId,
  onGenerateSummary,
  summary,
  onCopy,
  copied,
  onUpdate,
}: {
  groupId: string;
  onGenerateSummary: (id: string) => void;
  summary: string;
  onCopy: (text: string) => void;
  copied: boolean;
  onUpdate: () => void;
}): JSX.Element {
  const group = KnowledgeGraphService.getEntityGroup(groupId);
  const allEntities = KnowledgeGraphService.listEntities();
  
  if (!group) return <p className="text-sm text-muted-foreground">Group not found</p>;
  
  const members = allEntities.filter((e: Entity) => group.entityIds.includes(e.id));
  
  const deleteGroup = (): void => {
    if (confirm(`Delete group "${group.name}"?`)) {
      KnowledgeGraphService.deleteEntityGroup(groupId);
      onUpdate();
    }
  };
  
  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-semibold text-lg">📦 {group.name}</h3>
        <p className="text-sm text-muted-foreground mt-1">{group.description}</p>
      </div>
      
      {group.tags.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {group.tags.map((tag: string) => (
            <Badge key={tag} variant="secondary">{tag}</Badge>
          ))}
        </div>
      )}
      
      <Separator />
      
      <div>
        <h4 className="text-sm font-medium mb-2">Members ({members.length})</h4>
        <div className="space-y-1 max-h-48 overflow-y-auto">
          {members.map((entity: Entity) => (
            <div key={entity.id} className="text-sm p-2 bg-muted rounded">
              {entity.primaryEmoji || '•'} {entity.name} <Badge variant="outline" className="ml-2">{entity.type}</Badge>
            </div>
          ))}
        </div>
      </div>
      
      <Separator />
      
      <div className="flex items-center gap-2">
        <Button size="sm" onClick={() => onGenerateSummary(groupId)}>
          Generate Summary
        </Button>
        {summary && (
          <Button size="sm" variant="outline" onClick={() => onCopy(summary)}>
            {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
            {copied ? 'Copied!' : 'Copy'}
          </Button>
        )}
        <Button size="sm" variant="destructive" onClick={deleteGroup} className="ml-auto">
          Delete
        </Button>
      </div>
      
      {summary && (
        <Textarea
          value={summary}
          readOnly
          className="font-mono text-xs min-h-[200px]"
        />
      )}
    </div>
  );
}

function CreatePathTemplateDialog({ onSave }: { onSave: () => void }): JSX.Element {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [nodeTypes, setNodeTypes] = useState<string[]>(['']);
  const [relationKinds, setRelationKinds] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  
  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    
    const validNodeTypes = nodeTypes.filter((t: string) => t.trim() !== '');
    const validRelationKinds = relationKinds.filter((k: string) => k.trim() !== '');
    
    if (validNodeTypes.length < 2 || validRelationKinds.length !== validNodeTypes.length - 1) {
      alert('Path must have at least 2 nodes, and relation kinds must be one less than nodes');
      return;
    }
    
    KnowledgeGraphService.createPathTemplate({
      name,
      description,
      nodeTypes: validNodeTypes,
      relationKinds: validRelationKinds,
      tags,
    });
    
    setOpen(false);
    setName('');
    setDescription('');
    setNodeTypes(['']);
    setRelationKinds([]);
    setTags([]);
    onSave();
  };
  
  const addNode = (): void => {
    setNodeTypes([...nodeTypes, '']);
    setRelationKinds([...relationKinds, '']);
  };
  
  const updateNodeType = (index: number, value: string): void => {
    const updated = [...nodeTypes];
    updated[index] = value;
    setNodeTypes(updated);
  };
  
  const updateRelationKind = (index: number, value: string): void => {
    const updated = [...relationKinds];
    updated[index] = value;
    setRelationKinds(updated);
  };
  
  const addTag = (): void => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Create Template</Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Path Template</DialogTitle>
          <DialogDescription>Define an expected pattern of entities and relationships</DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="template-name">Name *</Label>
            <Input
              id="template-name"
              value={name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
              placeholder="e.g. DREAM → Drop → Script → Account"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="template-description">Description</Label>
            <Textarea
              id="template-description"
              value={description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
              placeholder="Describe this path pattern..."
              rows={2}
            />
          </div>
          
          <Separator />
          
          <div className="space-y-2">
            <Label>Path Definition</Label>
            <p className="text-xs text-muted-foreground">Define the sequence of entity types and relationships</p>
            
            <div className="space-y-2">
              {nodeTypes.map((nodeType: string, index: number) => (
                <div key={index} className="space-y-2">
                  <Input
                    value={nodeType}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateNodeType(index, e.target.value)}
                    placeholder={`Entity type ${index + 1} (e.g. token, mini-app)`}
                  />
                  
                  {index < nodeTypes.length - 1 && (
                    <div className="pl-4">
                      <Input
                        value={relationKinds[index] || ''}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateRelationKind(index, e.target.value)}
                        placeholder="Relationship kind (e.g. powers, created-by)"
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>
            
            <Button type="button" onClick={addNode} variant="outline" size="sm">
              Add Node
            </Button>
          </div>
          
          <div className="space-y-2">
            <Label>Tags</Label>
            <div className="flex gap-2">
              <Input
                value={tagInput}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTagInput(e.target.value)}
                onKeyDown={(e: React.KeyboardEvent) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addTag();
                  }
                }}
                placeholder="Add a tag"
              />
              <Button type="button" onClick={addTag} variant="outline">
                Add
              </Button>
            </div>
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {tags.map((tag: string) => (
                  <Badge key={tag} variant="secondary">
                    {tag}
                    <button
                      type="button"
                      onClick={() => setTags(tags.filter((t: string) => t !== tag))}
                      className="ml-1 hover:text-destructive"
                    >
                      ×
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>
          
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit">Create</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function PathTemplateDetail({
  templateId,
  onTest,
  matches,
  testEntityId,
  onTestEntityIdChange,
  onUpdate,
}: {
  templateId: string;
  onTest: (id: string, entityId?: string) => void;
  matches: PathMatch[];
  testEntityId: string;
  onTestEntityIdChange: (id: string) => void;
  onUpdate: () => void;
}): JSX.Element {
  const template = KnowledgeGraphService.getPathTemplate(templateId);
  const allEntities = KnowledgeGraphService.listEntities();
  
  if (!template) return <p className="text-sm text-muted-foreground">Template not found</p>;
  
  const deleteTemplate = (): void => {
    if (confirm(`Delete template "${template.name}"?`)) {
      KnowledgeGraphService.deletePathTemplate(templateId);
      onUpdate();
    }
  };
  
  const handleTest = (): void => {
    onTest(templateId, testEntityId || undefined);
  };
  
  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-semibold text-lg">🛤️  {template.name}</h3>
        <p className="text-sm text-muted-foreground mt-1">{template.description}</p>
      </div>
      
      {template.tags.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {template.tags.map((tag: string) => (
            <Badge key={tag} variant="secondary">{tag}</Badge>
          ))}
        </div>
      )}
      
      <Separator />
      
      <div>
        <h4 className="text-sm font-medium mb-2">Path Pattern</h4>
        <div className="bg-muted p-3 rounded-lg space-y-2 text-sm">
          {template.nodeTypes.map((nodeType: string, index: number) => (
            <div key={index}>
              <div className="font-medium">
                {index + 1}. {nodeType}
              </div>
              {index < template.relationKinds.length && (
                <div className="pl-4 text-muted-foreground">
                  ↓ {template.relationKinds[index]}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
      
      <Separator />
      
      <div>
        <h4 className="text-sm font-medium mb-2">Test Path Matching</h4>
        <div className="flex gap-2">
          <Select value={testEntityId} onValueChange={onTestEntityIdChange}>
            <SelectTrigger>
              <SelectValue placeholder="Start from entity (optional)" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">Any entity</SelectItem>
              {allEntities.filter((e: Entity) => e.type === template.nodeTypes[0]).map((entity: Entity) => (
                <SelectItem key={entity.id} value={entity.id}>
                  {entity.primaryEmoji || '•'} {entity.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={handleTest}>Test</Button>
        </div>
        
        {matches.length > 0 && (
          <div className="mt-4 space-y-2">
            <p className="text-sm font-medium">Found {matches.length} matching path(s):</p>
            {matches.map((match: PathMatch, index: number) => (
              <div key={index} className="bg-muted p-3 rounded-lg">
                <div className="text-sm space-y-1">
                  {match.entityIds.map((entityId: string, i: number) => {
                    const entity = allEntities.find((e: Entity) => e.id === entityId);
                    return (
                      <div key={i}>
                        <span className="font-medium">
                          {entity?.primaryEmoji || '•'} {entity?.name || 'Unknown'}
                        </span>
                        {i < match.edgeIds.length && (
                          <div className="pl-4 text-muted-foreground text-xs">
                            ↓ {template.relationKinds[i]}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
        
        {matches.length === 0 && testEntityId && (
          <p className="text-sm text-muted-foreground mt-2">No matching paths found</p>
        )}
      </div>
      
      <div className="flex justify-end">
        <Button size="sm" variant="destructive" onClick={deleteTemplate}>
          Delete
        </Button>
      </div>
    </div>
  );
}
