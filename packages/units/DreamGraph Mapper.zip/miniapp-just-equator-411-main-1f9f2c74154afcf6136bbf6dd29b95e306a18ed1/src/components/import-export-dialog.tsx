'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Textarea } from './ui/textarea';
import { Alert, AlertDescription } from './ui/alert';
import type { ExportFormat, ImportResult } from '@/types/knowledge-graph-extended';
import { ImportExportService } from '@/lib/import-export';
import { toast } from 'sonner';

export function ImportExportDialog() {
  const [open, setOpen] = useState(false);
  const [exportFormat, setExportFormat] = useState<ExportFormat>({
    format: 'json',
    includeEntities: true,
    includeRelationships: true,
    includeGroups: true,
    includePathTemplates: true,
  });
  const [importData, setImportData] = useState('');
  const [importResult, setImportResult] = useState<ImportResult | null>(null);
  
  const handleExport = () => {
    const data = ImportExportService.exportData(exportFormat);
    
    const filename = `dreamnet-graph-${new Date().toISOString().split('T')[0]}.${exportFormat.format}`;
    const mimeTypes: Record<string, string> = {
      json: 'application/json',
      csv: 'text/csv',
      graphml: 'application/xml',
      cypher: 'text/plain',
      markdown: 'text/markdown',
    };
    
    ImportExportService.downloadFile(data, filename, mimeTypes[exportFormat.format]);
    toast.success(`Exported as ${exportFormat.format.toUpperCase()}`);
  };
  
  const handleImport = async () => {
    if (!importData.trim()) {
      toast.error('Please paste data to import');
      return;
    }
    
    try {
      const result = await ImportExportService.importJSON(importData);
      setImportResult(result);
      
      if (result.success) {
        toast.success(`Imported ${result.entitiesCreated} entities, ${result.relationshipsCreated} relationships`);
      } else {
        toast.error('Import failed');
      }
    } catch (error) {
      toast.error('Failed to parse import data');
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">Import/Export</Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Import/Export Data</DialogTitle>
          <DialogDescription>
            Export your knowledge graph or import data from external sources
          </DialogDescription>
        </DialogHeader>
        
        <Tabs defaultValue="export">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="export">Export</TabsTrigger>
            <TabsTrigger value="import">Import</TabsTrigger>
          </TabsList>
          
          {/* Export Tab */}
          <TabsContent value="export" className="space-y-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Export Format</Label>
                <RadioGroup 
                  value={exportFormat.format} 
                  onValueChange={(value) => setExportFormat({ ...exportFormat, format: value as ExportFormat['format'] })}
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="json" id="json" />
                    <Label htmlFor="json">JSON (Full backup with all metadata)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="csv" id="csv" />
                    <Label htmlFor="csv">CSV (Spreadsheet format)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="graphml" id="graphml" />
                    <Label htmlFor="graphml">GraphML (Graph visualization tools)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="cypher" id="cypher" />
                    <Label htmlFor="cypher">Cypher (Neo4j import script)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="markdown" id="markdown" />
                    <Label htmlFor="markdown">Markdown (Human-readable documentation)</Label>
                  </div>
                </RadioGroup>
              </div>
              
              <div className="space-y-2">
                <Label>Include in Export</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      checked={exportFormat.includeEntities}
                      onCheckedChange={(checked) => setExportFormat({ ...exportFormat, includeEntities: !!checked })}
                    />
                    <Label>Entities</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      checked={exportFormat.includeRelationships}
                      onCheckedChange={(checked) => setExportFormat({ ...exportFormat, includeRelationships: !!checked })}
                    />
                    <Label>Relationships</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      checked={exportFormat.includeGroups}
                      onCheckedChange={(checked) => setExportFormat({ ...exportFormat, includeGroups: !!checked })}
                    />
                    <Label>Groups</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      checked={exportFormat.includePathTemplates}
                      onCheckedChange={(checked) => setExportFormat({ ...exportFormat, includePathTemplates: !!checked })}
                    />
                    <Label>Path Templates</Label>
                  </div>
                </div>
              </div>
              
              <Button onClick={handleExport} className="w-full">
                Export Data
              </Button>
            </div>
          </TabsContent>
          
          {/* Import Tab */}
          <TabsContent value="import" className="space-y-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="import-data">JSON Data</Label>
                <Textarea
                  id="import-data"
                  placeholder="Paste your JSON data here..."
                  value={importData}
                  onChange={(e) => setImportData(e.target.value)}
                  className="h-64 font-mono text-xs"
                />
              </div>
              
              <Button onClick={handleImport} className="w-full">
                Import Data
              </Button>
              
              {importResult && (
                <Alert variant={importResult.success ? 'default' : 'destructive'}>
                  <AlertDescription>
                    <div className="space-y-1">
                      <div>✓ Created {importResult.entitiesCreated} entities</div>
                      <div>✓ Created {importResult.relationshipsCreated} relationships</div>
                      <div>✓ Created {importResult.groupsCreated} groups</div>
                      
                      {importResult.warnings.length > 0 && (
                        <div className="mt-2">
                          <div className="font-medium">Warnings:</div>
                          {importResult.warnings.map((warning, i) => (
                            <div key={i} className="text-sm">⚠️ {warning}</div>
                          ))}
                        </div>
                      )}
                      
                      {importResult.errors.length > 0 && (
                        <div className="mt-2">
                          <div className="font-medium">Errors:</div>
                          {importResult.errors.map((error, i) => (
                            <div key={i} className="text-sm">❌ {error}</div>
                          ))}
                        </div>
                      )}
                    </div>
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
