'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { Entity, RelationshipEdge, RelationshipDirection, RelationshipStrength, CreateRelationshipInput } from '@/types/knowledge-graph';
import { KnowledgeGraphService } from '@/lib/knowledge-graph-service';

interface RelationshipFormDialogProps {
  relationship?: RelationshipEdge;
  defaultFromEntityId?: string;
  defaultToEntityId?: string;
  onSave: () => void;
  trigger?: React.ReactNode;
}

const STRENGTHS: RelationshipStrength[] = ['weak', 'normal', 'strong', 'critical'];
const DIRECTIONS: RelationshipDirection[] = ['forward', 'bidirectional'];

export function RelationshipFormDialog({ 
  relationship, 
  defaultFromEntityId,
  defaultToEntityId,
  onSave, 
  trigger 
}: RelationshipFormDialogProps): JSX.Element {
  const [open, setOpen] = useState(false);
  const [entities, setEntities] = useState<Entity[]>([]);
  const [formData, setFormData] = useState<CreateRelationshipInput>({
    fromEntityId: relationship?.fromEntityId || defaultFromEntityId || '',
    toEntityId: relationship?.toEntityId || defaultToEntityId || '',
    kind: relationship?.kind || '',
    direction: relationship?.direction || 'forward',
    description: relationship?.description || '',
    strength: relationship?.strength || 'normal',
    context: relationship?.context || '',
    tags: relationship?.tags || [],
  });
  
  const [tagInput, setTagInput] = useState('');
  
  const handleOpenChange = (isOpen: boolean): void => {
    setOpen(isOpen);
    if (isOpen) {
      setEntities(KnowledgeGraphService.listEntities());
    }
  };
  
  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    
    if (relationship) {
      KnowledgeGraphService.updateRelationship({
        id: relationship.id,
        ...formData,
      });
    } else {
      KnowledgeGraphService.createRelationship(formData);
    }
    
    setOpen(false);
    onSave();
  };
  
  const addTag = (): void => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, tagInput.trim()],
      });
      setTagInput('');
    }
  };
  
  const removeTag = (tag: string): void => {
    setFormData({
      ...formData,
      tags: formData.tags.filter((t: string) => t !== tag),
    });
  };
  
  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        {trigger || <Button size="sm">{relationship ? 'Edit' : 'Create Relationship'}</Button>}
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{relationship ? 'Edit Relationship' : 'Create New Relationship'}</DialogTitle>
          <DialogDescription>
            {relationship ? 'Update relationship details' : 'Define a relationship between two entities'}
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="fromEntityId">From Entity *</Label>
              <Select
                value={formData.fromEntityId}
                onValueChange={(value: string) => setFormData({ ...formData, fromEntityId: value })}
              >
                <SelectTrigger id="fromEntityId">
                  <SelectValue placeholder="Select entity..." />
                </SelectTrigger>
                <SelectContent>
                  {entities.map((entity: Entity) => (
                    <SelectItem key={entity.id} value={entity.id}>
                      {entity.primaryEmoji || '•'} {entity.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="toEntityId">To Entity *</Label>
              <Select
                value={formData.toEntityId}
                onValueChange={(value: string) => setFormData({ ...formData, toEntityId: value })}
              >
                <SelectTrigger id="toEntityId">
                  <SelectValue placeholder="Select entity..." />
                </SelectTrigger>
                <SelectContent>
                  {entities.map((entity: Entity) => (
                    <SelectItem key={entity.id} value={entity.id}>
                      {entity.primaryEmoji || '•'} {entity.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="kind">Relationship Kind *</Label>
            <Input
              id="kind"
              value={formData.kind}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, kind: e.target.value })}
              placeholder="e.g. powers, created-by, posts-to, tracks, governs"
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="direction">Direction</Label>
              <Select
                value={formData.direction}
                onValueChange={(value: RelationshipDirection) => setFormData({ ...formData, direction: value })}
              >
                <SelectTrigger id="direction">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {DIRECTIONS.map((direction: RelationshipDirection) => (
                    <SelectItem key={direction} value={direction}>
                      {direction}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="strength">Strength</Label>
              <Select
                value={formData.strength}
                onValueChange={(value: RelationshipStrength) => setFormData({ ...formData, strength: value })}
              >
                <SelectTrigger id="strength">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STRENGTHS.map((strength: RelationshipStrength) => (
                    <SelectItem key={strength} value={strength}>
                      {strength}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe this relationship..."
              rows={3}
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="context">Context</Label>
            <Input
              id="context"
              value={formData.context}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, context: e.target.value })}
              placeholder="e.g. culture, ops, pickleball, backend"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="tags">Tags</Label>
            <div className="flex gap-2">
              <Input
                id="tags"
                value={tagInput}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTagInput(e.target.value)}
                onKeyDown={(e: React.KeyboardEvent) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addTag();
                  }
                }}
                placeholder="Add a tag"
              />
              <Button type="button" onClick={addTag} variant="outline">
                Add
              </Button>
            </div>
            {formData.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {formData.tags.map((tag: string) => (
                  <span
                    key={tag}
                    className="bg-secondary text-secondary-foreground px-2 py-1 rounded text-sm flex items-center gap-1"
                  >
                    {tag}
                    <button
                      type="button"
                      onClick={() => removeTag(tag)}
                      className="hover:text-destructive"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>
          
          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit">
              {relationship ? 'Update' : 'Create'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
