'use client';

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import type { Suggestion } from '@/types/knowledge-graph-extended';
import { SmartSuggestions } from '@/lib/smart-suggestions';
import { toast } from 'sonner';

export function SuggestionsPanel() {
  const [open, setOpen] = useState(false);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [loading, setLoading] = useState(false);
  
  useEffect(() => {
    if (open) {
      loadSuggestions();
    }
  }, [open]);
  
  const loadSuggestions = () => {
    const existing = SmartSuggestions.getSuggestions().filter((s: Suggestion) => !s.dismissed);
    setSuggestions(existing);
  };
  
  const handleGenerateNew = async () => {
    setLoading(true);
    try {
      const newSuggestions = SmartSuggestions.generateAllSuggestions();
      setSuggestions(newSuggestions.filter((s: Suggestion) => !s.dismissed));
      toast.success(`Generated ${newSuggestions.length} suggestions`);
    } catch (error) {
      toast.error('Failed to generate suggestions');
    } finally {
      setLoading(false);
    }
  };
  
  const handleDismiss = (suggestionId: string) => {
    SmartSuggestions.dismissSuggestion(suggestionId);
    loadSuggestions();
    toast.success('Suggestion dismissed');
  };
  
  const handleClearDismissed = () => {
    SmartSuggestions.clearDismissed();
    toast.success('Cleared dismissed suggestions');
  };
  
  const getPriorityColor = (priority: Suggestion['priority']) => {
    switch (priority) {
      case 'high': return 'destructive';
      case 'medium': return 'default';
      case 'low': return 'secondary';
    }
  };
  
  const getTypeLabel = (type: Suggestion['type']) => {
    switch (type) {
      case 'missing-relationship': return '🔗 Missing Relationship';
      case 'duplicate-entity': return '👥 Possible Duplicate';
      case 'tag-suggestion': return '🏷️ Tag Suggestion';
      case 'completion-prompt': return '✏️ Incomplete';
      case 'pattern-match': return '🔍 Pattern Match';
    }
  };
  
  // Group suggestions by type
  const groupedSuggestions = suggestions.reduce((acc, suggestion) => {
    if (!acc[suggestion.type]) {
      acc[suggestion.type] = [];
    }
    acc[suggestion.type].push(suggestion);
    return acc;
  }, {} as Record<string, Suggestion[]>);
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="relative">
          💡 Suggestions
          {suggestions.length > 0 && (
            <Badge className="ml-2 px-1.5 py-0.5 text-xs">
              {suggestions.length}
            </Badge>
          )}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Smart Suggestions</DialogTitle>
          <DialogDescription>
            AI-powered recommendations to improve your knowledge graph
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex space-x-2">
            <Button onClick={handleGenerateNew} disabled={loading} className="flex-1">
              {loading ? 'Generating...' : '✨ Generate New Suggestions'}
            </Button>
            <Button variant="outline" onClick={handleClearDismissed}>
              Clear Dismissed
            </Button>
          </div>
          
          {suggestions.length === 0 ? (
            <Alert>
              <AlertDescription>
                No suggestions at the moment! Click "Generate New Suggestions" to analyze your graph.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="space-y-4">
              {Object.entries(groupedSuggestions).map(([type, typeSuggestions]) => (
                <div key={type} className="space-y-2">
                  <h3 className="font-semibold text-sm text-gray-500 uppercase">
                    {getTypeLabel(type as Suggestion['type'])}
                  </h3>
                  
                  {typeSuggestions.map((suggestion) => (
                    <Card key={suggestion.id}>
                      <CardContent className="pt-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1 space-y-2">
                            <div className="flex items-center space-x-2">
                              <Badge variant={getPriorityColor(suggestion.priority)}>
                                {suggestion.priority}
                              </Badge>
                              <span className="text-sm font-medium">{suggestion.message}</span>
                            </div>
                            
                            {suggestion.action && (
                              <div className="text-xs text-gray-500">
                                Suggested action: {suggestion.action.type}
                              </div>
                            )}
                          </div>
                          
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleDismiss(suggestion.id)}
                          >
                            Dismiss
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ))}
            </div>
          )}
          
          <div className="text-xs text-gray-500 text-center">
            Suggestions are based on common patterns and best practices
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
