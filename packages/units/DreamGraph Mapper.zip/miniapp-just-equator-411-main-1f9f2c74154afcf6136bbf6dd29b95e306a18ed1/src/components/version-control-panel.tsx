'use client';

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';
import type { GraphSnapshot, ChangeLogEntry } from '@/types/knowledge-graph-extended';
import { VersionControlService } from '@/lib/version-control';
import { toast } from 'sonner';
import { format } from 'date-fns';

export function VersionControlPanel() {
  const [open, setOpen] = useState(false);
  const [snapshots, setSnapshots] = useState<GraphSnapshot[]>([]);
  const [changelog, setChangelog] = useState<ChangeLogEntry[]>([]);
  const [newSnapshotName, setNewSnapshotName] = useState('');
  const [newSnapshotDesc, setNewSnapshotDesc] = useState('');
  const [compareSnapshot1, setCompareSnapshot1] = useState('');
  const [compareSnapshot2, setCompareSnapshot2] = useState('');
  
  useEffect(() => {
    if (open) {
      loadData();
    }
  }, [open]);
  
  const loadData = () => {
    setSnapshots(VersionControlService.getSnapshots());
    setChangelog(VersionControlService.getChangeLog(50));
  };
  
  const handleCreateSnapshot = () => {
    if (!newSnapshotName.trim()) {
      toast.error('Please enter a snapshot name');
      return;
    }
    
    VersionControlService.createSnapshot(newSnapshotName, newSnapshotDesc);
    toast.success('Snapshot created successfully');
    setNewSnapshotName('');
    setNewSnapshotDesc('');
    loadData();
  };
  
  const handleRestoreSnapshot = (snapshotId: string) => {
    const success = VersionControlService.restoreSnapshot(snapshotId);
    if (success) {
      toast.success('Snapshot restored successfully');
      setOpen(false);
      window.location.reload(); // Reload to reflect changes
    } else {
      toast.error('Failed to restore snapshot');
    }
  };
  
  const handleDeleteSnapshot = (snapshotId: string) => {
    VersionControlService.deleteSnapshot(snapshotId);
    toast.success('Snapshot deleted');
    loadData();
  };
  
  const handleCompare = () => {
    if (!compareSnapshot1 || !compareSnapshot2) {
      toast.error('Please select two snapshots to compare');
      return;
    }
    
    const diff = VersionControlService.compareSnapshots(compareSnapshot1, compareSnapshot2);
    
    // Show comparison results
    const summary = [
      `Entities: +${diff.entitiesAdded.length} -${diff.entitiesRemoved.length} ~${diff.entitiesModified.length}`,
      `Relationships: +${diff.relationshipsAdded.length} -${diff.relationshipsRemoved.length} ~${diff.relationshipsModified.length}`,
    ].join('\n');
    
    toast.success(`Comparison:\n${summary}`);
  };
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">Version Control</Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Version Control & History</DialogTitle>
          <DialogDescription>
            Manage snapshots, view change history, and restore previous versions
          </DialogDescription>
        </DialogHeader>
        
        <Tabs defaultValue="snapshots">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="snapshots">Snapshots</TabsTrigger>
            <TabsTrigger value="changelog">Change Log</TabsTrigger>
            <TabsTrigger value="compare">Compare</TabsTrigger>
          </TabsList>
          
          {/* Snapshots Tab */}
          <TabsContent value="snapshots" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Create New Snapshot</CardTitle>
                <CardDescription>Save current graph state as a named snapshot</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <Label htmlFor="snapshot-name">Snapshot Name</Label>
                  <Input
                    id="snapshot-name"
                    placeholder="e.g., Before major refactor"
                    value={newSnapshotName}
                    onChange={(e) => setNewSnapshotName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="snapshot-desc">Description (Optional)</Label>
                  <Textarea
                    id="snapshot-desc"
                    placeholder="Add notes about this snapshot..."
                    value={newSnapshotDesc}
                    onChange={(e) => setNewSnapshotDesc(e.target.value)}
                  />
                </div>
                <Button onClick={handleCreateSnapshot} className="w-full">
                  Create Snapshot
                </Button>
              </CardContent>
            </Card>
            
            <div className="space-y-2">
              <h3 className="font-semibold">Saved Snapshots</h3>
              {snapshots.length === 0 ? (
                <div className="text-center text-gray-500 py-8">
                  No snapshots yet. Create your first snapshot above!
                </div>
              ) : (
                <div className="space-y-2">
                  {snapshots.map((snapshot) => (
                    <Card key={snapshot.id}>
                      <CardContent className="pt-4">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="font-medium">{snapshot.name}</div>
                            {snapshot.description && (
                              <div className="text-sm text-gray-500">{snapshot.description}</div>
                            )}
                            <div className="text-xs text-gray-400">
                              {format(new Date(snapshot.timestamp), 'PPpp')}
                            </div>
                            <div className="flex space-x-2 text-xs">
                              <Badge variant="outline">{snapshot.entities.length} entities</Badge>
                              <Badge variant="outline">{snapshot.relationships.length} relationships</Badge>
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="outline" size="sm">Restore</Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Restore Snapshot?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    This will replace your current graph with the snapshot "{snapshot.name}".
                                    A backup of your current state will be created automatically.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleRestoreSnapshot(snapshot.id)}>
                                    Restore
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleDeleteSnapshot(snapshot.id)}
                            >
                              Delete
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
          
          {/* Change Log Tab */}
          <TabsContent value="changelog" className="space-y-2">
            {changelog.length === 0 ? (
              <div className="text-center text-gray-500 py-8">
                No changes recorded yet
              </div>
            ) : (
              <div className="space-y-2">
                {changelog.map((entry) => (
                  <Card key={entry.id}>
                    <CardContent className="pt-4">
                      <div className="flex items-start space-x-3">
                        <Badge variant={entry.action === 'create' ? 'default' : entry.action === 'update' ? 'secondary' : 'destructive'}>
                          {entry.action}
                        </Badge>
                        <div className="flex-1">
                          <div className="text-sm font-medium">
                            {entry.action} {entry.entityType}: {entry.entityName}
                          </div>
                          <div className="text-xs text-gray-500">
                            {format(new Date(entry.timestamp), 'PPpp')}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
          
          {/* Compare Tab */}
          <TabsContent value="compare" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Compare Snapshots</CardTitle>
                <CardDescription>View differences between two snapshots</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <Label>First Snapshot</Label>
                  <select 
                    className="w-full p-2 border rounded"
                    value={compareSnapshot1}
                    onChange={(e) => setCompareSnapshot1(e.target.value)}
                  >
                    <option value="">Select a snapshot...</option>
                    {snapshots.map((snapshot) => (
                      <option key={snapshot.id} value={snapshot.id}>
                        {snapshot.name} ({format(new Date(snapshot.timestamp), 'PP')})
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <Label>Second Snapshot</Label>
                  <select 
                    className="w-full p-2 border rounded"
                    value={compareSnapshot2}
                    onChange={(e) => setCompareSnapshot2(e.target.value)}
                  >
                    <option value="">Select a snapshot...</option>
                    {snapshots.map((snapshot) => (
                      <option key={snapshot.id} value={snapshot.id}>
                        {snapshot.name} ({format(new Date(snapshot.timestamp), 'PP')})
                      </option>
                    ))}
                  </select>
                </div>
                <Button onClick={handleCompare} className="w-full">
                  Compare Snapshots
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
