'use client';

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import type { Workspace } from '@/types/knowledge-graph-extended';
import { WorkspaceManager } from '@/lib/workspace-manager';
import { toast } from 'sonner';
import { format } from 'date-fns';

export function WorkspaceSwitcher() {
  const [open, setOpen] = useState(false);
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [activeWorkspace, setActiveWorkspace] = useState<Workspace | undefined>();
  const [newWorkspaceName, setNewWorkspaceName] = useState('');
  const [newWorkspaceDesc, setNewWorkspaceDesc] = useState('');
  const [newWorkspaceEmoji, setNewWorkspaceEmoji] = useState('🧠');
  
  useEffect(() => {
    if (open) {
      loadWorkspaces();
    }
  }, [open]);
  
  const loadWorkspaces = () => {
    const ws = WorkspaceManager.getWorkspaces();
    setWorkspaces(ws);
    setActiveWorkspace(WorkspaceManager.getActiveWorkspace());
  };
  
  const handleCreateWorkspace = () => {
    if (!newWorkspaceName.trim()) {
      toast.error('Please enter a workspace name');
      return;
    }
    
    WorkspaceManager.createWorkspace(newWorkspaceName, newWorkspaceDesc, newWorkspaceEmoji);
    toast.success('Workspace created successfully');
    setNewWorkspaceName('');
    setNewWorkspaceDesc('');
    setNewWorkspaceEmoji('🧠');
    loadWorkspaces();
  };
  
  const handleSwitchWorkspace = (workspaceId: string) => {
    const success = WorkspaceManager.switchWorkspace(workspaceId);
    if (success) {
      toast.success('Switched workspace');
      setOpen(false);
      window.location.reload(); // Reload to reflect new workspace data
    } else {
      toast.error('Failed to switch workspace');
    }
  };
  
  const handleDeleteWorkspace = (workspaceId: string) => {
    const success = WorkspaceManager.deleteWorkspace(workspaceId);
    if (success) {
      toast.success('Workspace deleted');
      loadWorkspaces();
    } else {
      toast.error('Cannot delete active workspace');
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">
          {activeWorkspace ? `${activeWorkspace.emoji || '🧠'} ${activeWorkspace.name}` : 'Workspaces'}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Manage Workspaces</DialogTitle>
          <DialogDescription>
            Switch between different knowledge graphs or create new ones
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <Card>
            <CardContent className="pt-6 space-y-3">
              <div className="space-y-2">
                <Label htmlFor="workspace-emoji">Emoji</Label>
                <Input
                  id="workspace-emoji"
                  placeholder="🧠"
                  value={newWorkspaceEmoji}
                  onChange={(e) => setNewWorkspaceEmoji(e.target.value)}
                  maxLength={2}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="workspace-name">Workspace Name</Label>
                <Input
                  id="workspace-name"
                  placeholder="e.g., Pickleball Projects"
                  value={newWorkspaceName}
                  onChange={(e) => setNewWorkspaceName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="workspace-desc">Description</Label>
                <Textarea
                  id="workspace-desc"
                  placeholder="What is this workspace for?"
                  value={newWorkspaceDesc}
                  onChange={(e) => setNewWorkspaceDesc(e.target.value)}
                />
              </div>
              <Button onClick={handleCreateWorkspace} className="w-full">
                Create Workspace
              </Button>
            </CardContent>
          </Card>
          
          <div className="space-y-2">
            <h3 className="font-semibold">Your Workspaces</h3>
            {workspaces.map((workspace) => (
              <Card key={workspace.id}>
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-2xl">{workspace.emoji || '🧠'}</span>
                        <div>
                          <div className="font-medium">{workspace.name}</div>
                          {workspace.description && (
                            <div className="text-sm text-gray-500">{workspace.description}</div>
                          )}
                        </div>
                      </div>
                      <div className="text-xs text-gray-400">
                        Created {format(new Date(workspace.createdAt), 'PP')}
                      </div>
                      {workspace.isActive && (
                        <Badge>Active</Badge>
                      )}
                    </div>
                    <div className="flex space-x-2">
                      {!workspace.isActive && (
                        <>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleSwitchWorkspace(workspace.id)}
                          >
                            Switch
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleDeleteWorkspace(workspace.id)}
                          >
                            Delete
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
