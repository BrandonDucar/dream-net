// Batch Operations Service

import type { BatchOperation } from '@/types/knowledge-graph-extended';
import { KnowledgeGraphService } from './knowledge-graph-service';
import { VersionControlService } from './version-control';

export class BatchOperationsService {
  // ============ BATCH UPDATE TAGS ============
  
  static async batchUpdateTags(params: {
    entityIds: string[];
    action: 'add' | 'remove' | 'replace';
    tags: string[];
  }): Promise<BatchOperation> {
    const operation: BatchOperation = {
      id: this.generateId(),
      type: 'update-tags',
      entityIds: params.entityIds,
      params,
      status: 'running',
      createdAt: new Date().toISOString(),
    };
    
    const results = { success: 0, failed: 0, errors: [] as string[] };
    
    // Create snapshot before batch operation
    VersionControlService.createSnapshot(
      `Before batch tags update`,
      `Batch operation on ${params.entityIds.length} entities`
    );
    
    for (const entityId of params.entityIds) {
      try {
        const entity = KnowledgeGraphService.getEntity(entityId);
        if (!entity) {
          results.failed++;
          results.errors.push(`Entity ${entityId} not found`);
          continue;
        }
        
        let newTags: string[] = [];
        
        switch (params.action) {
          case 'add':
            newTags = [...new Set([...entity.tags, ...params.tags])];
            break;
          case 'remove':
            newTags = entity.tags.filter((t) => !params.tags.includes(t));
            break;
          case 'replace':
            newTags = params.tags;
            break;
        }
        
        KnowledgeGraphService.updateEntity({ id: entityId, tags: newTags });
        results.success++;
      } catch (error) {
        results.failed++;
        results.errors.push(`Failed to update ${entityId}: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    }
    
    operation.status = 'completed';
    operation.completedAt = new Date().toISOString();
    operation.results = results;
    
    return operation;
  }
  
  // ============ BATCH UPDATE IMPORTANCE ============
  
  static async batchUpdateImportance(params: {
    entityIds: string[];
    importanceLevel: 'low' | 'medium' | 'high' | 'critical';
  }): Promise<BatchOperation> {
    const operation: BatchOperation = {
      id: this.generateId(),
      type: 'update-importance',
      entityIds: params.entityIds,
      params,
      status: 'running',
      createdAt: new Date().toISOString(),
    };
    
    const results = { success: 0, failed: 0, errors: [] as string[] };
    
    VersionControlService.createSnapshot(
      `Before batch importance update`,
      `Batch operation on ${params.entityIds.length} entities`
    );
    
    for (const entityId of params.entityIds) {
      try {
        KnowledgeGraphService.updateEntity({
          id: entityId,
          importanceLevel: params.importanceLevel,
        });
        results.success++;
      } catch (error) {
        results.failed++;
        results.errors.push(`Failed to update ${entityId}`);
      }
    }
    
    operation.status = 'completed';
    operation.completedAt = new Date().toISOString();
    operation.results = results;
    
    return operation;
  }
  
  // ============ BATCH DELETE ============
  
  static async batchDelete(entityIds: string[]): Promise<BatchOperation> {
    const operation: BatchOperation = {
      id: this.generateId(),
      type: 'delete-entities',
      entityIds,
      params: {},
      status: 'running',
      createdAt: new Date().toISOString(),
    };
    
    const results = { success: 0, failed: 0, errors: [] as string[] };
    
    VersionControlService.createSnapshot(
      `Before batch delete`,
      `Deleting ${entityIds.length} entities`
    );
    
    for (const entityId of entityIds) {
      try {
        KnowledgeGraphService.deleteEntity(entityId);
        results.success++;
      } catch (error) {
        results.failed++;
        results.errors.push(`Failed to delete ${entityId}`);
      }
    }
    
    operation.status = 'completed';
    operation.completedAt = new Date().toISOString();
    operation.results = results;
    
    return operation;
  }
  
  // ============ BATCH CREATE RELATIONSHIPS ============
  
  static async batchCreateRelationships(params: {
    fromEntityIds: string[];
    toEntityId: string;
    kind: string;
    description?: string;
  }): Promise<BatchOperation> {
    const operation: BatchOperation = {
      id: this.generateId(),
      type: 'create-relationships',
      entityIds: params.fromEntityIds,
      params,
      status: 'running',
      createdAt: new Date().toISOString(),
    };
    
    const results = { success: 0, failed: 0, errors: [] as string[] };
    
    VersionControlService.createSnapshot(
      `Before batch relationship creation`,
      `Creating ${params.fromEntityIds.length} relationships`
    );
    
    for (const fromEntityId of params.fromEntityIds) {
      try {
        KnowledgeGraphService.createRelationship({
          fromEntityId,
          toEntityId: params.toEntityId,
          kind: params.kind,
          description: params.description || '',
        });
        results.success++;
      } catch (error) {
        results.failed++;
        results.errors.push(`Failed to create relationship from ${fromEntityId}`);
      }
    }
    
    operation.status = 'completed';
    operation.completedAt = new Date().toISOString();
    operation.results = results;
    
    return operation;
  }
  
  // ============ BATCH ASSIGN TO GROUP ============
  
  static async batchAssignToGroup(params: {
    entityIds: string[];
    groupId: string;
  }): Promise<BatchOperation> {
    const operation: BatchOperation = {
      id: this.generateId(),
      type: 'assign-to-group',
      entityIds: params.entityIds,
      params,
      status: 'running',
      createdAt: new Date().toISOString(),
    };
    
    const results = { success: 0, failed: 0, errors: [] as string[] };
    
    try {
      const group = KnowledgeGraphService.getEntityGroup(params.groupId);
      if (!group) {
        operation.status = 'failed';
        operation.results = { success: 0, failed: params.entityIds.length, errors: ['Group not found'] };
        return operation;
      }
      
      const updatedEntityIds = [...new Set([...group.entityIds, ...params.entityIds])];
      
      KnowledgeGraphService.updateEntityGroup({
        id: params.groupId,
        entityIds: updatedEntityIds,
      });
      
      results.success = params.entityIds.length;
    } catch (error) {
      results.failed = params.entityIds.length;
      results.errors.push('Failed to update group');
    }
    
    operation.status = 'completed';
    operation.completedAt = new Date().toISOString();
    operation.results = results;
    
    return operation;
  }
  
  // ============ UTILITIES ============
  
  private static generateId(): string {
    return `batch-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  }
}
