// Constraint Rules Service

import type { ConstraintRule, ConstraintViolation } from '@/types/knowledge-graph-extended';
import type { Entity } from '@/types/knowledge-graph';
import { KnowledgeGraphStorage } from './storage';
import { GraphEngine } from './graph-engine';

const STORAGE_KEY = 'dreamnet_kg_constraint_rules';

export class ConstraintRulesService {
  // ============ CRUD ============
  
  static createRule(params: {
    name: string;
    description: string;
    ruleType: ConstraintRule['ruleType'];
    entityTypes: string[];
    config: ConstraintRule['config'];
    severity?: ConstraintRule['severity'];
  }): ConstraintRule {
    const rule: ConstraintRule = {
      id: this.generateId(),
      name: params.name,
      description: params.description,
      ruleType: params.ruleType,
      entityTypes: params.entityTypes,
      config: params.config,
      severity: params.severity || 'warning',
      enabled: true,
      createdAt: new Date().toISOString(),
    };
    
    const rules = this.getRules();
    rules.push(rule);
    this.saveRules(rules);
    
    return rule;
  }
  
  static updateRule(id: string, updates: Partial<ConstraintRule>): ConstraintRule | undefined {
    const rules = this.getRules();
    const index = rules.findIndex((r: ConstraintRule) => r.id === id);
    
    if (index === -1) return undefined;
    
    rules[index] = {
      ...rules[index],
      ...updates,
      id: rules[index].id,
      createdAt: rules[index].createdAt,
    };
    
    this.saveRules(rules);
    return rules[index];
  }
  
  static deleteRule(id: string): void {
    const rules = this.getRules().filter((r: ConstraintRule) => r.id !== id);
    this.saveRules(rules);
  }
  
  static toggleRule(id: string, enabled: boolean): void {
    this.updateRule(id, { enabled });
  }
  
  static getRule(id: string): ConstraintRule | undefined {
    return this.getRules().find((r: ConstraintRule) => r.id === id);
  }
  
  static getRules(): ConstraintRule[] {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : this.getDefaultRules();
  }
  
  private static saveRules(rules: ConstraintRule[]): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rules));
  }
  
  // ============ VALIDATION ============
  
  static validateEntity(entityId: string): ConstraintViolation[] {
    const entity = KnowledgeGraphStorage.getEntity(entityId);
    if (!entity) return [];
    
    const violations: ConstraintViolation[] = [];
    const rules = this.getRules().filter((r: ConstraintRule) => r.enabled);
    
    rules.forEach((rule: ConstraintRule) => {
      // Check if rule applies to this entity type
      if (!rule.entityTypes.includes(entity.type)) return;
      
      const violation = this.checkRule(entity, rule);
      if (violation) {
        violations.push(violation);
      }
    });
    
    return violations;
  }
  
  static validateAllEntities(): ConstraintViolation[] {
    const entities = KnowledgeGraphStorage.getEntities();
    const allViolations: ConstraintViolation[] = [];
    
    entities.forEach((entity: Entity) => {
      const violations = this.validateEntity(entity.id);
      allViolations.push(...violations);
    });
    
    return allViolations;
  }
  
  private static checkRule(entity: Entity, rule: ConstraintRule): ConstraintViolation | null {
    switch (rule.ruleType) {
      case 'required-connection':
        return this.checkRequiredConnection(entity, rule);
      
      case 'forbidden-connection':
        return this.checkForbiddenConnection(entity, rule);
      
      case 'min-connections':
        return this.checkMinConnections(entity, rule);
      
      case 'max-connections':
        return this.checkMaxConnections(entity, rule);
      
      case 'field-required':
        return this.checkFieldRequired(entity, rule);
      
      default:
        return null;
    }
  }
  
  private static checkRequiredConnection(entity: Entity, rule: ConstraintRule): ConstraintViolation | null {
    const { relationKind, targetEntityType } = rule.config;
    
    const outbound = GraphEngine.getOutboundEdges(entity.id);
    const hasRequired = outbound.some((edge) => {
      if (relationKind && edge.kind !== relationKind) return false;
      
      if (targetEntityType) {
        const target = KnowledgeGraphStorage.getEntity(edge.toEntityId);
        return target?.type === targetEntityType;
      }
      
      return true;
    });
    
    if (!hasRequired) {
      return {
        ruleId: rule.id,
        ruleName: rule.name,
        severity: rule.severity,
        entityId: entity.id,
        entityName: entity.name,
        message: `Missing required "${relationKind}" connection${targetEntityType ? ` to ${targetEntityType}` : ''}`,
      };
    }
    
    return null;
  }
  
  private static checkForbiddenConnection(entity: Entity, rule: ConstraintRule): ConstraintViolation | null {
    const { relationKind, targetEntityType } = rule.config;
    
    const outbound = GraphEngine.getOutboundEdges(entity.id);
    const hasForbidden = outbound.some((edge) => {
      if (relationKind && edge.kind !== relationKind) return false;
      
      if (targetEntityType) {
        const target = KnowledgeGraphStorage.getEntity(edge.toEntityId);
        return target?.type === targetEntityType;
      }
      
      return true;
    });
    
    if (hasForbidden) {
      return {
        ruleId: rule.id,
        ruleName: rule.name,
        severity: rule.severity,
        entityId: entity.id,
        entityName: entity.name,
        message: `Has forbidden "${relationKind}" connection${targetEntityType ? ` to ${targetEntityType}` : ''}`,
      };
    }
    
    return null;
  }
  
  private static checkMinConnections(entity: Entity, rule: ConstraintRule): ConstraintViolation | null {
    const { minCount = 1, relationKind } = rule.config;
    
    const outbound = GraphEngine.getOutboundEdges(entity.id);
    const relevant = relationKind 
      ? outbound.filter((edge) => edge.kind === relationKind)
      : outbound;
    
    if (relevant.length < minCount) {
      return {
        ruleId: rule.id,
        ruleName: rule.name,
        severity: rule.severity,
        entityId: entity.id,
        entityName: entity.name,
        message: `Has ${relevant.length} connections, needs at least ${minCount}${relationKind ? ` of type "${relationKind}"` : ''}`,
      };
    }
    
    return null;
  }
  
  private static checkMaxConnections(entity: Entity, rule: ConstraintRule): ConstraintViolation | null {
    const { maxCount = 10, relationKind } = rule.config;
    
    const outbound = GraphEngine.getOutboundEdges(entity.id);
    const relevant = relationKind 
      ? outbound.filter((edge) => edge.kind === relationKind)
      : outbound;
    
    if (relevant.length > maxCount) {
      return {
        ruleId: rule.id,
        ruleName: rule.name,
        severity: rule.severity,
        entityId: entity.id,
        entityName: entity.name,
        message: `Has ${relevant.length} connections, maximum allowed is ${maxCount}${relationKind ? ` of type "${relationKind}"` : ''}`,
      };
    }
    
    return null;
  }
  
  private static checkFieldRequired(entity: Entity, rule: ConstraintRule): ConstraintViolation | null {
    const { requiredFields = [] } = rule.config;
    const missing: string[] = [];
    
    requiredFields.forEach((field) => {
      const value = entity[field as keyof Entity];
      if (!value || (typeof value === 'string' && value.trim() === '')) {
        missing.push(field);
      }
    });
    
    if (missing.length > 0) {
      return {
        ruleId: rule.id,
        ruleName: rule.name,
        severity: rule.severity,
        entityId: entity.id,
        entityName: entity.name,
        message: `Missing required fields: ${missing.join(', ')}`,
      };
    }
    
    return null;
  }
  
  // ============ DEFAULT RULES ============
  
  private static getDefaultRules(): ConstraintRule[] {
    return [
      {
        id: 'rule-tokens-need-chain',
        name: 'Tokens Must Specify Chain',
        description: 'All token entities must have a chain specified',
        ruleType: 'field-required',
        entityTypes: ['token', 'culture-coin'],
        config: {
          requiredFields: ['chain'],
        },
        severity: 'warning',
        enabled: true,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'rule-social-needs-ref',
        name: 'Social Accounts Need External Reference',
        description: 'Social accounts must have an external reference (handle/ID)',
        ruleType: 'field-required',
        entityTypes: ['social-account'],
        config: {
          requiredFields: ['externalRef'],
        },
        severity: 'error',
        enabled: true,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'rule-canonical-needs-connections',
        name: 'Canonical Entities Need Connections',
        description: 'Canonical entities should have at least 3 connections',
        ruleType: 'min-connections',
        entityTypes: ['token', 'culture-coin', 'mini-app', 'agent'],
        config: {
          minCount: 3,
        },
        severity: 'info',
        enabled: false,
        createdAt: new Date().toISOString(),
      },
    ];
  }
  
  // ============ UTILITIES ============
  
  private static generateId(): string {
    return `rule-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  }
}
