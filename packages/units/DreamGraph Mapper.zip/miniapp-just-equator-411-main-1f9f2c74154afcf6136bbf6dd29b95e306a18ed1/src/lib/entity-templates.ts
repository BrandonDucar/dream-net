// Entity Templates Service

import type { EntityTemplate } from '@/types/knowledge-graph-extended';
import type { Entity, EntityType } from '@/types/knowledge-graph';

const STORAGE_KEY = 'dreamnet_kg_entity_templates';

export class EntityTemplateService {
  // ============ CRUD ============
  
  static createTemplate(
    name: string,
    entityType: EntityType,
    description: string,
    defaultFields?: EntityTemplate['defaultFields'],
    fieldPrompts?: Record<string, string>
  ): EntityTemplate {
    const template: EntityTemplate = {
      id: this.generateId(),
      name,
      description,
      entityType,
      defaultFields: defaultFields || {},
      fieldPrompts: fieldPrompts || {},
      createdAt: new Date().toISOString(),
    };
    
    const templates = this.getTemplates();
    templates.push(template);
    this.saveTemplates(templates);
    
    return template;
  }
  
  static updateTemplate(id: string, updates: Partial<EntityTemplate>): EntityTemplate | undefined {
    const templates = this.getTemplates();
    const index = templates.findIndex((t: EntityTemplate) => t.id === id);
    
    if (index === -1) return undefined;
    
    templates[index] = {
      ...templates[index],
      ...updates,
      id: templates[index].id,
      createdAt: templates[index].createdAt,
    };
    
    this.saveTemplates(templates);
    return templates[index];
  }
  
  static deleteTemplate(id: string): void {
    const templates = this.getTemplates().filter((t: EntityTemplate) => t.id !== id);
    this.saveTemplates(templates);
  }
  
  static getTemplate(id: string): EntityTemplate | undefined {
    return this.getTemplates().find((t: EntityTemplate) => t.id === id);
  }
  
  static getTemplates(): EntityTemplate[] {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : this.getDefaultTemplates();
  }
  
  static getTemplatesByType(entityType: EntityType): EntityTemplate[] {
    return this.getTemplates().filter((t: EntityTemplate) => t.entityType === entityType);
  }
  
  private static saveTemplates(templates: EntityTemplate[]): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(templates));
  }
  
  // ============ APPLY TEMPLATE ============
  
  static applyTemplate(templateId: string, overrides?: Partial<Entity>): Partial<Entity> {
    const template = this.getTemplate(templateId);
    if (!template) return overrides || {};
    
    return {
      type: template.entityType,
      importanceLevel: template.defaultFields.importanceLevel || 'medium',
      tags: template.defaultFields.tags || [],
      primaryEmoji: template.defaultFields.primaryEmoji,
      ...overrides,
    };
  }
  
  // ============ DEFAULT TEMPLATES ============
  
  private static getDefaultTemplates(): EntityTemplate[] {
    return [
      {
        id: 'template-token',
        name: 'New Token',
        description: 'Template for creating tokens on Base',
        entityType: 'token',
        defaultFields: {
          importanceLevel: 'high',
          tags: ['defi', 'token', 'base'],
          primaryEmoji: '🪙',
        },
        fieldPrompts: {
          externalRef: 'Contract address',
          chain: 'Base',
          description: 'What does this token do?',
        },
        createdAt: new Date().toISOString(),
      },
      {
        id: 'template-culture-coin',
        name: 'New Culture Coin',
        description: 'Template for Culture Coin projects',
        entityType: 'culture-coin',
        defaultFields: {
          importanceLevel: 'high',
          tags: ['culture', 'community', 'base'],
          primaryEmoji: '💫',
        },
        fieldPrompts: {
          externalRef: 'Contract address',
          chain: 'Base',
          description: 'What community does this represent?',
        },
        createdAt: new Date().toISOString(),
      },
      {
        id: 'template-mini-app',
        name: 'New Mini App',
        description: 'Template for DreamNet mini-apps',
        entityType: 'mini-app',
        defaultFields: {
          importanceLevel: 'medium',
          tags: ['app', 'tool', 'dreamnet'],
          primaryEmoji: '📱',
        },
        fieldPrompts: {
          externalRef: 'URL or app ID',
          description: 'What does this app do?',
          sourceMiniApp: 'Built with which tool?',
        },
        createdAt: new Date().toISOString(),
      },
      {
        id: 'template-agent',
        name: 'New Agent',
        description: 'Template for AI agents',
        entityType: 'agent',
        defaultFields: {
          importanceLevel: 'medium',
          tags: ['ai', 'automation', 'agent'],
          primaryEmoji: '🤖',
        },
        fieldPrompts: {
          description: 'What does this agent do?',
          externalRef: 'Agent ID or endpoint',
        },
        createdAt: new Date().toISOString(),
      },
      {
        id: 'template-social-account',
        name: 'New Social Account',
        description: 'Template for social media accounts',
        entityType: 'social-account',
        defaultFields: {
          importanceLevel: 'medium',
          tags: ['social', 'content', 'engagement'],
          primaryEmoji: '📣',
        },
        fieldPrompts: {
          externalRef: 'Handle or account ID',
          description: 'What platform and purpose?',
        },
        createdAt: new Date().toISOString(),
      },
      {
        id: 'template-drop',
        name: 'New Drop',
        description: 'Template for drop campaigns',
        entityType: 'drop',
        defaultFields: {
          importanceLevel: 'medium',
          tags: ['drop', 'campaign', 'engagement'],
          primaryEmoji: '🎁',
        },
        fieldPrompts: {
          description: 'What are you dropping?',
        },
        createdAt: new Date().toISOString(),
      },
    ];
  }
  
  // ============ UTILITIES ============
  
  private static generateId(): string {
    return `template-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  }
}
