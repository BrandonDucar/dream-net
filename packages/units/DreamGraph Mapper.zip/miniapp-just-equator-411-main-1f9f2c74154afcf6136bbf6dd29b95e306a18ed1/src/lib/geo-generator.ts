import type { Entity, GeoTarget } from '@/types/knowledge-graph';

export class GeoGenerator {
  static generateGeoVariants(
    entity: Pick<Entity, 'name' | 'type' | 'description' | 'tags'>,
    geoTargets: GeoTarget[]
  ): {
    entityIntroLocalized: Record<string, string>;
    tagsLocalized: Record<string, string[]>;
  } {
    const entityIntroLocalized: Record<string, string> = {};
    const tagsLocalized: Record<string, string[]> = {};
    
    for (const geo of geoTargets) {
      const geoKey = geo.id;
      
      // Generate localized intro
      entityIntroLocalized[geoKey] = this.generateLocalizedIntro(entity, geo);
      
      // Generate localized tags
      tagsLocalized[geoKey] = this.generateLocalizedTags(entity.tags, geo);
    }
    
    return {
      entityIntroLocalized,
      tagsLocalized,
    };
  }
  
  private static generateLocalizedIntro(
    entity: Pick<Entity, 'name' | 'type' | 'description'>,
    geo: GeoTarget
  ): string {
    const { language, region, cityOrMarket } = geo;
    
    const locationContext = cityOrMarket 
      ? ` in ${cityOrMarket}` 
      : ` in ${region}`;
    
    let intro = '';
    
    switch (language) {
      case 'es':
        intro = `${entity.name} es un ${entity.type} de DreamNet${locationContext}. ${entity.description}`;
        break;
      case 'pt-BR':
        intro = `${entity.name} é um ${entity.type} do DreamNet${locationContext}. ${entity.description}`;
        break;
      case 'fr':
        intro = `${entity.name} est un ${entity.type} de DreamNet${locationContext}. ${entity.description}`;
        break;
      default: // 'en'
        intro = `${entity.name} is a DreamNet ${entity.type}${locationContext}. ${entity.description}`;
    }
    
    return intro;
  }
  
  private static generateLocalizedTags(
    tags: string[],
    geo: GeoTarget
  ): string[] {
    const { language, region, cityOrMarket } = geo;
    
    const localizedTags = [...tags];
    
    // Add regional tags
    if (region) {
      localizedTags.push(region);
    }
    
    if (cityOrMarket) {
      localizedTags.push(cityOrMarket);
    }
    
    // Add language-specific tags
    switch (language) {
      case 'es':
        localizedTags.push('América Latina', 'LATAM');
        break;
      case 'pt-BR':
        localizedTags.push('Brasil', 'América Latina');
        break;
      case 'fr':
        localizedTags.push('France', 'Europe');
        break;
      default:
        localizedTags.push('Global', 'International');
    }
    
    return localizedTags;
  }
}
