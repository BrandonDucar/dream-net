// Graph Analytics & Metrics Service

import type { EntityMetrics, GraphMetrics, DetectedPattern } from '@/types/knowledge-graph-extended';
import type { Entity, RelationshipEdge } from '@/types/knowledge-graph';
import { KnowledgeGraphStorage } from './storage';
import { GraphEngine } from './graph-engine';

export class GraphAnalytics {
  // ============ ENTITY METRICS ============
  
  static calculateEntityMetrics(entityId: string): EntityMetrics {
    const entity = KnowledgeGraphStorage.getEntity(entityId);
    if (!entity) {
      return this.emptyMetrics(entityId);
    }
    
    const inbound = GraphEngine.getInboundEdges(entityId);
    const outbound = GraphEngine.getOutboundEdges(entityId);
    
    const inDegree = inbound.length;
    const outDegree = outbound.length;
    const totalDegree = inDegree + outDegree;
    
    // Calculate completeness (% of fields filled)
    const completeness = this.calculateCompleteness(entity);
    
    // Calculate connectedness (quality of connections)
    const connectedness = this.calculateConnectedness(inbound, outbound);
    
    // Calculate betweenness centrality (simplified)
    const betweennessCentrality = this.calculateBetweenness(entityId);
    
    // Calculate PageRank (simplified)
    const pageRank = this.calculatePageRank(entityId);
    
    // Calculate clustering coefficient
    const clusteringCoefficient = this.calculateClustering(entityId);
    
    // Calculate overall health score
    const healthScore = Math.round(
      (completeness * 0.3) +
      (connectedness * 0.3) +
      (Math.min(totalDegree / 10, 1) * 0.2) +
      (pageRank * 100 * 0.2)
    );
    
    return {
      entityId,
      inDegree,
      outDegree,
      totalDegree,
      betweennessCentrality,
      pageRank,
      clusteringCoefficient,
      completeness,
      connectedness,
      healthScore,
    };
  }
  
  private static emptyMetrics(entityId: string): EntityMetrics {
    return {
      entityId,
      inDegree: 0,
      outDegree: 0,
      totalDegree: 0,
      betweennessCentrality: 0,
      pageRank: 0,
      clusteringCoefficient: 0,
      completeness: 0,
      connectedness: 0,
      healthScore: 0,
    };
  }
  
  private static calculateCompleteness(entity: Entity): number {
    const fields = [
      entity.description,
      entity.primaryEmoji,
      entity.sourceMiniApp,
      entity.externalRef,
      entity.chain,
      entity.notes,
      entity.seoTitle,
      entity.seoDescription,
    ];
    
    const filled = fields.filter((f) => f && f.trim() !== '').length;
    const tagScore = Math.min(entity.tags.length / 3, 1);
    
    return Math.round(((filled / fields.length) * 0.7 + tagScore * 0.3) * 100);
  }
  
  private static calculateConnectedness(inbound: RelationshipEdge[], outbound: RelationshipEdge[]): number {
    const all = [...inbound, ...outbound];
    if (all.length === 0) return 0;
    
    // Quality based on strength and description completeness
    let totalQuality = 0;
    all.forEach((edge: RelationshipEdge) => {
      let quality = 0.5; // base
      
      if (edge.strength === 'strong') quality += 0.2;
      if (edge.strength === 'critical') quality += 0.3;
      if (edge.description && edge.description.length > 10) quality += 0.2;
      if (edge.context) quality += 0.1;
      if (edge.tags.length > 0) quality += 0.1;
      
      totalQuality += Math.min(quality, 1);
    });
    
    return Math.round((totalQuality / all.length) * 100);
  }
  
  private static calculateBetweenness(entityId: string): number {
    // Simplified betweenness: count paths that pass through this entity
    const entities = KnowledgeGraphStorage.getEntities();
    const relationships = KnowledgeGraphStorage.getRelationships();
    
    if (relationships.length === 0) return 0;
    
    let pathsThrough = 0;
    
    // Sample a subset of entity pairs
    const sampleSize = Math.min(entities.length, 20);
    for (let i = 0; i < sampleSize; i++) {
      const source = entities[i];
      if (source.id === entityId) continue;
      
      for (let j = i + 1; j < sampleSize; j++) {
        const target = entities[j];
        if (target.id === entityId) continue;
        
        // Check if shortest path goes through entityId (simplified)
        const neighbors = GraphEngine.findNeighbors(source.id, { depth: 2 });
        if (neighbors.entities.some((e: Entity) => e.id === entityId) &&
            neighbors.entities.some((e: Entity) => e.id === target.id)) {
          pathsThrough++;
        }
      }
    }
    
    return pathsThrough / (sampleSize * sampleSize);
  }
  
  private static calculatePageRank(entityId: string): number {
    // Simplified PageRank: weighted sum of inbound connections
    const inbound = GraphEngine.getInboundEdges(entityId);
    
    let score = 0.15; // base score
    
    inbound.forEach((edge: RelationshipEdge) => {
      const source = KnowledgeGraphStorage.getEntity(edge.fromEntityId);
      if (!source) return;
      
      let weight = 0.1;
      if (source.canonical) weight += 0.2;
      if (source.importanceLevel === 'high') weight += 0.15;
      if (source.importanceLevel === 'critical') weight += 0.25;
      if (edge.strength === 'strong') weight += 0.1;
      if (edge.strength === 'critical') weight += 0.15;
      
      score += weight;
    });
    
    return Math.min(score, 1);
  }
  
  private static calculateClustering(entityId: string): number {
    // Clustering coefficient: how connected are the neighbors?
    const neighbors = GraphEngine.findNeighbors(entityId, { depth: 1 });
    const neighborIds = neighbors.entities.map((e: Entity) => e.id);
    
    if (neighborIds.length < 2) return 0;
    
    // Count edges between neighbors
    let edgesBetweenNeighbors = 0;
    const relationships = KnowledgeGraphStorage.getRelationships();
    
    relationships.forEach((edge: RelationshipEdge) => {
      if (neighborIds.includes(edge.fromEntityId) && neighborIds.includes(edge.toEntityId)) {
        edgesBetweenNeighbors++;
      }
    });
    
    const possibleEdges = (neighborIds.length * (neighborIds.length - 1)) / 2;
    return possibleEdges > 0 ? edgesBetweenNeighbors / possibleEdges : 0;
  }
  
  // ============ GRAPH-WIDE METRICS ============
  
  static calculateGraphMetrics(): GraphMetrics {
    const entities = KnowledgeGraphStorage.getEntities();
    const relationships = KnowledgeGraphStorage.getRelationships();
    
    const totalEntities = entities.length;
    const totalRelationships = relationships.length;
    
    // Average degree
    const averageDegree = totalEntities > 0 ? (totalRelationships * 2) / totalEntities : 0;
    
    // Network density
    const possibleEdges = (totalEntities * (totalEntities - 1)) / 2;
    const networkDensity = possibleEdges > 0 ? totalRelationships / possibleEdges : 0;
    
    // Count connected components (simplified)
    const connectedComponents = this.countConnectedComponents();
    
    // Average path length (simplified)
    const averagePathLength = this.calculateAveragePathLength();
    
    // Graph clustering coefficient
    const clusteringCoefficient = this.calculateGraphClustering();
    
    // Entities by type
    const entitiesByType: Record<string, number> = {};
    entities.forEach((e: Entity) => {
      entitiesByType[e.type] = (entitiesByType[e.type] || 0) + 1;
    });
    
    // Relationships by kind
    const relationshipsByKind: Record<string, number> = {};
    relationships.forEach((r: RelationshipEdge) => {
      relationshipsByKind[r.kind] = (relationshipsByKind[r.kind] || 0) + 1;
    });
    
    // Top central entities
    const topCentralEntities = entities
      .map((e: Entity) => {
        const metrics = this.calculateEntityMetrics(e.id);
        return {
          entityId: e.id,
          name: e.name,
          score: metrics.pageRank,
        };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
    
    return {
      totalEntities,
      totalRelationships,
      averageDegree,
      networkDensity,
      connectedComponents,
      averagePathLength,
      clusteringCoefficient,
      entitiesByType,
      relationshipsByKind,
      topCentralEntities,
    };
  }
  
  private static countConnectedComponents(): number {
    const entities = KnowledgeGraphStorage.getEntities();
    const visited = new Set<string>();
    let components = 0;
    
    const dfs = (entityId: string): void => {
      if (visited.has(entityId)) return;
      visited.add(entityId);
      
      const neighbors = GraphEngine.findNeighbors(entityId, { depth: 1 });
      neighbors.entities.forEach((e: Entity) => {
        if (!visited.has(e.id)) {
          dfs(e.id);
        }
      });
    };
    
    entities.forEach((e: Entity) => {
      if (!visited.has(e.id)) {
        components++;
        dfs(e.id);
      }
    });
    
    return components;
  }
  
  private static calculateAveragePathLength(): number {
    const entities = KnowledgeGraphStorage.getEntities();
    if (entities.length < 2) return 0;
    
    let totalLength = 0;
    let pathCount = 0;
    
    // Sample paths
    const sampleSize = Math.min(entities.length, 10);
    for (let i = 0; i < sampleSize; i++) {
      for (let j = i + 1; j < sampleSize; j++) {
        const length = this.shortestPathLength(entities[i].id, entities[j].id);
        if (length > 0) {
          totalLength += length;
          pathCount++;
        }
      }
    }
    
    return pathCount > 0 ? totalLength / pathCount : 0;
  }
  
  private static shortestPathLength(fromId: string, toId: string): number {
    // BFS to find shortest path
    const queue: Array<{ id: string; distance: number }> = [{ id: fromId, distance: 0 }];
    const visited = new Set<string>();
    
    while (queue.length > 0) {
      const current = queue.shift()!;
      
      if (current.id === toId) return current.distance;
      if (visited.has(current.id)) continue;
      
      visited.add(current.id);
      
      const neighbors = GraphEngine.findNeighbors(current.id, { depth: 1 });
      neighbors.entities.forEach((e: Entity) => {
        if (!visited.has(e.id)) {
          queue.push({ id: e.id, distance: current.distance + 1 });
        }
      });
    }
    
    return -1; // No path found
  }
  
  private static calculateGraphClustering(): number {
    const entities = KnowledgeGraphStorage.getEntities();
    if (entities.length === 0) return 0;
    
    let sum = 0;
    entities.forEach((e: Entity) => {
      sum += this.calculateClustering(e.id);
    });
    
    return sum / entities.length;
  }
  
  // ============ PATTERN DETECTION ============
  
  static detectPatterns(): DetectedPattern[] {
    const patterns: DetectedPattern[] = [];
    
    // Detect isolated entities
    patterns.push(...this.detectIsolatedEntities());
    
    // Detect hub entities
    patterns.push(...this.detectHubEntities());
    
    // Detect circular dependencies
    patterns.push(...this.detectCircularDependencies());
    
    // Detect common subgraphs
    patterns.push(...this.detectCommonSubgraphs());
    
    // Detect clusters
    patterns.push(...this.detectClusters());
    
    return patterns;
  }
  
  private static detectIsolatedEntities(): DetectedPattern[] {
    const entities = KnowledgeGraphStorage.getEntities();
    const isolated = entities.filter((e: Entity) => {
      const neighbors = GraphEngine.findNeighbors(e.id, { depth: 1 });
      return neighbors.entities.length === 0;
    });
    
    if (isolated.length === 0) return [];
    
    return [{
      id: 'isolated-entities',
      patternType: 'isolated-entity',
      name: 'Isolated Entities',
      description: `${isolated.length} entities with no connections`,
      entityIds: isolated.map((e: Entity) => e.id),
      edgeIds: [],
      occurrences: isolated.length,
      significance: Math.min(isolated.length / entities.length, 1),
    }];
  }
  
  private static detectHubEntities(): DetectedPattern[] {
    const entities = KnowledgeGraphStorage.getEntities();
    const hubs = entities.filter((e: Entity) => {
      const neighbors = GraphEngine.findNeighbors(e.id, { depth: 1 });
      return neighbors.entities.length >= 5;
    }).sort((a, b) => {
      const aNeighbors = GraphEngine.findNeighbors(a.id, { depth: 1 });
      const bNeighbors = GraphEngine.findNeighbors(b.id, { depth: 1 });
      return bNeighbors.entities.length - aNeighbors.entities.length;
    });
    
    if (hubs.length === 0) return [];
    
    return [{
      id: 'hub-entities',
      patternType: 'hub-entity',
      name: 'Hub Entities',
      description: `${hubs.length} highly connected entities (5+ connections)`,
      entityIds: hubs.map((e: Entity) => e.id),
      edgeIds: [],
      occurrences: hubs.length,
      significance: Math.min(hubs.length / 10, 1),
    }];
  }
  
  private static detectCircularDependencies(): DetectedPattern[] {
    const entities = KnowledgeGraphStorage.getEntities();
    const cycles: DetectedPattern[] = [];
    
    // Simplified cycle detection
    entities.forEach((e: Entity) => {
      const visited = new Set<string>();
      const path: string[] = [];
      
      const hasCycle = (id: string): boolean => {
        if (path.includes(id)) {
          const cycleStart = path.indexOf(id);
          const cycle = path.slice(cycleStart);
          
          if (cycle.length >= 3) {
            cycles.push({
              id: `cycle-${id}-${Date.now()}`,
              patternType: 'circular-dependency',
              name: 'Circular Dependency',
              description: `Cycle detected: ${cycle.length} entities`,
              entityIds: cycle,
              edgeIds: [],
              occurrences: 1,
              significance: Math.min(cycle.length / 10, 1),
            });
          }
          
          return true;
        }
        
        if (visited.has(id)) return false;
        
        visited.add(id);
        path.push(id);
        
        const outbound = GraphEngine.getOutboundEdges(id);
        for (const edge of outbound) {
          if (hasCycle(edge.toEntityId)) return true;
        }
        
        path.pop();
        return false;
      };
      
      hasCycle(e.id);
    });
    
    return cycles.slice(0, 10); // Limit to top 10
  }
  
  private static detectCommonSubgraphs(): DetectedPattern[] {
    // Simplified: detect patterns like "Token → Mini-App → Account"
    const patterns: Map<string, { entityIds: Set<string>; count: number }> = new Map();
    
    const entities = KnowledgeGraphStorage.getEntities();
    entities.forEach((e: Entity) => {
      const outbound = GraphEngine.getOutboundEdges(e.id);
      outbound.forEach((edge: RelationshipEdge) => {
        const target = KnowledgeGraphStorage.getEntity(edge.toEntityId);
        if (!target) return;
        
        const patternKey = `${e.type}-${edge.kind}-${target.type}`;
        
        if (!patterns.has(patternKey)) {
          patterns.set(patternKey, { entityIds: new Set(), count: 0 });
        }
        
        const pattern = patterns.get(patternKey)!;
        pattern.entityIds.add(e.id);
        pattern.entityIds.add(target.id);
        pattern.count++;
      });
    });
    
    const result: DetectedPattern[] = [];
    patterns.forEach((data, key) => {
      if (data.count >= 2) {
        result.push({
          id: `subgraph-${key}`,
          patternType: 'common-subgraph',
          name: `Common Pattern: ${key}`,
          description: `Pattern occurs ${data.count} times`,
          entityIds: Array.from(data.entityIds),
          edgeIds: [],
          occurrences: data.count,
          significance: Math.min(data.count / 10, 1),
        });
      }
    });
    
    return result.sort((a, b) => b.occurrences - a.occurrences).slice(0, 10);
  }
  
  private static detectClusters(): DetectedPattern[] {
    // Simplified clustering: group entities by context
    const byContext: Map<string, string[]> = new Map();
    
    const relationships = KnowledgeGraphStorage.getRelationships();
    relationships.forEach((r: RelationshipEdge) => {
      if (!r.context) return;
      
      if (!byContext.has(r.context)) {
        byContext.set(r.context, []);
      }
      
      const cluster = byContext.get(r.context)!;
      if (!cluster.includes(r.fromEntityId)) cluster.push(r.fromEntityId);
      if (!cluster.includes(r.toEntityId)) cluster.push(r.toEntityId);
    });
    
    const result: DetectedPattern[] = [];
    byContext.forEach((entityIds, context) => {
      if (entityIds.length >= 3) {
        result.push({
          id: `cluster-${context}`,
          patternType: 'cluster',
          name: `${context} Cluster`,
          description: `${entityIds.length} entities in ${context} context`,
          entityIds,
          edgeIds: [],
          occurrences: entityIds.length,
          significance: Math.min(entityIds.length / 20, 1),
        });
      }
    });
    
    return result;
  }
}
