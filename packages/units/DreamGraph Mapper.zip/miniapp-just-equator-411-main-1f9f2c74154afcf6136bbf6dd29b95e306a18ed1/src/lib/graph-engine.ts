import type { 
  Entity, 
  RelationshipEdge, 
  PathTemplate, 
  PathMatch,
  NeighborOptions,
  NeighborResult 
} from '@/types/knowledge-graph';
import { KnowledgeGraphStorage } from './storage';

export class GraphEngine {
  static findNeighbors(entityId: string, options: NeighborOptions): NeighborResult {
    const { depth, relationKinds, context } = options;
    const allRelationships = KnowledgeGraphStorage.getRelationships();
    const allEntities = KnowledgeGraphStorage.getEntities();
    
    const visitedEntityIds = new Set<string>([entityId]);
    const resultEntityIds = new Set<string>();
    const resultEdges: RelationshipEdge[] = [];
    
    const queue: Array<{ id: string; currentDepth: number }> = [{ id: entityId, currentDepth: 0 }];
    
    while (queue.length > 0) {
      const current = queue.shift();
      if (!current) break;
      
      if (current.currentDepth >= depth) continue;
      
      // Find all edges from this entity
      const edges = allRelationships.filter((edge: RelationshipEdge) => {
        const isFromCurrent = edge.fromEntityId === current.id;
        const isToCurrent = edge.toEntityId === current.id && edge.direction === 'bidirectional';
        
        if (!isFromCurrent && !isToCurrent) return false;
        
        // Filter by relationKinds if provided
        if (relationKinds && relationKinds.length > 0 && !relationKinds.includes(edge.kind)) {
          return false;
        }
        
        // Filter by context if provided
        if (context && edge.context !== context) {
          return false;
        }
        
        return true;
      });
      
      for (const edge of edges) {
        const nextEntityId = edge.fromEntityId === current.id ? edge.toEntityId : edge.fromEntityId;
        
        if (!visitedEntityIds.has(nextEntityId)) {
          visitedEntityIds.add(nextEntityId);
          resultEntityIds.add(nextEntityId);
          resultEdges.push(edge);
          
          if (current.currentDepth + 1 < depth) {
            queue.push({ id: nextEntityId, currentDepth: current.currentDepth + 1 });
          }
        } else if (resultEntityIds.has(nextEntityId)) {
          // Add edge even if entity was visited
          if (!resultEdges.find((e: RelationshipEdge) => e.id === edge.id)) {
            resultEdges.push(edge);
          }
        }
      }
    }
    
    const entities = allEntities.filter((e: Entity) => resultEntityIds.has(e.id));
    
    return {
      entities,
      edges: resultEdges,
    };
  }
  
  static matchPathTemplate(templateId: string, startEntityId?: string): PathMatch[] {
    const template = KnowledgeGraphStorage.getPathTemplate(templateId);
    if (!template) return [];
    
    const allEntities = KnowledgeGraphStorage.getEntities();
    const allRelationships = KnowledgeGraphStorage.getRelationships();
    
    const { nodeTypes, relationKinds } = template;
    
    if (nodeTypes.length === 0) return [];
    
    // Find starting entities
    let startEntities: Entity[];
    if (startEntityId) {
      const startEntity = allEntities.find((e: Entity) => e.id === startEntityId);
      if (!startEntity || startEntity.type !== nodeTypes[0]) return [];
      startEntities = [startEntity];
    } else {
      startEntities = allEntities.filter((e: Entity) => e.type === nodeTypes[0]);
    }
    
    const matches: PathMatch[] = [];
    
    // For each starting entity, try to build paths
    for (const startEntity of startEntities) {
      this.findPaths(
        startEntity.id,
        0,
        nodeTypes,
        relationKinds,
        [startEntity.id],
        [],
        allEntities,
        allRelationships,
        matches
      );
    }
    
    return matches;
  }
  
  private static findPaths(
    currentEntityId: string,
    stepIndex: number,
    nodeTypes: string[],
    relationKinds: string[],
    pathEntityIds: string[],
    pathEdgeIds: string[],
    allEntities: Entity[],
    allRelationships: RelationshipEdge[],
    matches: PathMatch[]
  ): void {
    // If we've completed the path
    if (stepIndex === nodeTypes.length - 1) {
      matches.push({
        entityIds: [...pathEntityIds],
        edgeIds: [...pathEdgeIds],
      });
      return;
    }
    
    const expectedRelationKind = relationKinds[stepIndex];
    const nextNodeType = nodeTypes[stepIndex + 1];
    
    // Find edges from current entity with the expected kind
    const candidateEdges = allRelationships.filter((edge: RelationshipEdge) => {
      return (
        edge.fromEntityId === currentEntityId &&
        edge.kind === expectedRelationKind
      );
    });
    
    for (const edge of candidateEdges) {
      const nextEntity = allEntities.find((e: Entity) => e.id === edge.toEntityId);
      
      if (nextEntity && nextEntity.type === nextNodeType) {
        // Continue building the path
        this.findPaths(
          nextEntity.id,
          stepIndex + 1,
          nodeTypes,
          relationKinds,
          [...pathEntityIds, nextEntity.id],
          [...pathEdgeIds, edge.id],
          allEntities,
          allRelationships,
          matches
        );
      }
    }
  }
  
  static getInboundEdges(entityId: string): RelationshipEdge[] {
    const allRelationships = KnowledgeGraphStorage.getRelationships();
    return allRelationships.filter((edge: RelationshipEdge) => edge.toEntityId === entityId);
  }
  
  static getOutboundEdges(entityId: string): RelationshipEdge[] {
    const allRelationships = KnowledgeGraphStorage.getRelationships();
    return allRelationships.filter((edge: RelationshipEdge) => edge.fromEntityId === entityId);
  }
  
  static getEntityGroups(entityId: string): string[] {
    const allGroups = KnowledgeGraphStorage.getGroups();
    return allGroups
      .filter((g) => g.entityIds.includes(entityId))
      .map((g) => g.id);
  }
}
