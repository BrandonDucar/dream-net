// Import/Export Service

import type { ExportFormat, ImportResult } from '@/types/knowledge-graph-extended';
import type { Entity, RelationshipEdge, EntityGroup, PathTemplate } from '@/types/knowledge-graph';
import { KnowledgeGraphStorage } from './storage';
import Papa from 'papaparse';

export class ImportExportService {
  // ============ EXPORT ============
  
  static exportData(format: ExportFormat): string {
    switch (format.format) {
      case 'json':
        return this.exportJSON(format);
      case 'csv':
        return this.exportCSV(format);
      case 'graphml':
        return this.exportGraphML(format);
      case 'cypher':
        return this.exportCypher(format);
      case 'markdown':
        return this.exportMarkdown(format);
      default:
        return '';
    }
  }
  
  private static exportJSON(format: ExportFormat): string {
    const data: Record<string, unknown> = {};
    
    if (format.includeEntities) {
      data.entities = KnowledgeGraphStorage.getEntities();
    }
    
    if (format.includeRelationships) {
      data.relationships = KnowledgeGraphStorage.getRelationships();
    }
    
    if (format.includeGroups) {
      data.groups = KnowledgeGraphStorage.getGroups();
    }
    
    if (format.includePathTemplates) {
      data.pathTemplates = KnowledgeGraphStorage.getPathTemplates();
    }
    
    data.exportedAt = new Date().toISOString();
    data.version = '1.0';
    
    return JSON.stringify(data, null, 2);
  }
  
  private static exportCSV(format: ExportFormat): string {
    let csv = '';
    
    if (format.includeEntities) {
      const entities = KnowledgeGraphStorage.getEntities();
      const entityData = entities.map((e: Entity) => ({
        id: e.id,
        type: e.type,
        name: e.name,
        slug: e.slug,
        description: e.description,
        primaryEmoji: e.primaryEmoji || '',
        importanceLevel: e.importanceLevel,
        canonical: e.canonical,
        sourceMiniApp: e.sourceMiniApp || '',
        externalRef: e.externalRef || '',
        chain: e.chain || '',
        tags: e.tags.join(';'),
        notes: e.notes,
      }));
      
      csv += '# ENTITIES\n';
      csv += Papa.unparse(entityData) + '\n\n';
    }
    
    if (format.includeRelationships) {
      const relationships = KnowledgeGraphStorage.getRelationships();
      const relData = relationships.map((r: RelationshipEdge) => ({
        id: r.id,
        fromEntityId: r.fromEntityId,
        toEntityId: r.toEntityId,
        kind: r.kind,
        direction: r.direction,
        description: r.description,
        strength: r.strength,
        context: r.context,
        tags: r.tags.join(';'),
        notes: r.notes,
      }));
      
      csv += '# RELATIONSHIPS\n';
      csv += Papa.unparse(relData) + '\n\n';
    }
    
    return csv;
  }
  
  private static exportGraphML(format: ExportFormat): string {
    let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
    xml += '<graphml xmlns="http://graphml.graphdrawing.org/xmlns">\n';
    xml += '  <graph id="DreamNet" edgedefault="directed">\n';
    
    if (format.includeEntities) {
      const entities = KnowledgeGraphStorage.getEntities();
      entities.forEach((e: Entity) => {
        xml += `    <node id="${this.escapeXml(e.id)}">\n`;
        xml += `      <data key="name">${this.escapeXml(e.name)}</data>\n`;
        xml += `      <data key="type">${this.escapeXml(e.type)}</data>\n`;
        xml += `      <data key="description">${this.escapeXml(e.description)}</data>\n`;
        xml += `    </node>\n`;
      });
    }
    
    if (format.includeRelationships) {
      const relationships = KnowledgeGraphStorage.getRelationships();
      relationships.forEach((r: RelationshipEdge) => {
        xml += `    <edge source="${this.escapeXml(r.fromEntityId)}" target="${this.escapeXml(r.toEntityId)}">\n`;
        xml += `      <data key="kind">${this.escapeXml(r.kind)}</data>\n`;
        xml += `      <data key="strength">${this.escapeXml(r.strength)}</data>\n`;
        xml += `    </edge>\n`;
      });
    }
    
    xml += '  </graph>\n';
    xml += '</graphml>';
    
    return xml;
  }
  
  private static exportCypher(format: ExportFormat): string {
    let cypher = '// Neo4j Cypher Script\n\n';
    
    if (format.includeEntities) {
      const entities = KnowledgeGraphStorage.getEntities();
      entities.forEach((e: Entity) => {
        cypher += `CREATE (e${this.sanitizeId(e.id)}:Entity {\n`;
        cypher += `  id: "${e.id}",\n`;
        cypher += `  type: "${e.type}",\n`;
        cypher += `  name: "${this.escapeCypher(e.name)}",\n`;
        cypher += `  description: "${this.escapeCypher(e.description)}",\n`;
        cypher += `  canonical: ${e.canonical},\n`;
        cypher += `  importanceLevel: "${e.importanceLevel}"\n`;
        cypher += `})\n\n`;
      });
    }
    
    if (format.includeRelationships) {
      const relationships = KnowledgeGraphStorage.getRelationships();
      relationships.forEach((r: RelationshipEdge) => {
        cypher += `MATCH (from:Entity {id: "${r.fromEntityId}"}), (to:Entity {id: "${r.toEntityId}"})\n`;
        cypher += `CREATE (from)-[:${this.sanitizeRelKind(r.kind)} {\n`;
        cypher += `  description: "${this.escapeCypher(r.description)}",\n`;
        cypher += `  strength: "${r.strength}"\n`;
        cypher += `}]->(to)\n\n`;
      });
    }
    
    return cypher;
  }
  
  private static exportMarkdown(format: ExportFormat): string {
    let md = '# DreamNet Knowledge Graph Export\n\n';
    md += `Exported: ${new Date().toISOString()}\n\n`;
    
    if (format.includeEntities) {
      md += '## Entities\n\n';
      const entities = KnowledgeGraphStorage.getEntities();
      
      const byType: Record<string, Entity[]> = {};
      entities.forEach((e: Entity) => {
        if (!byType[e.type]) byType[e.type] = [];
        byType[e.type].push(e);
      });
      
      Object.keys(byType).sort().forEach((type) => {
        md += `### ${type}\n\n`;
        byType[type].forEach((e: Entity) => {
          md += `**${e.primaryEmoji || '🔷'} ${e.name}**`;
          if (e.canonical) md += ' ⭐';
          md += `\n- Type: ${e.type}\n`;
          md += `- Importance: ${e.importanceLevel}\n`;
          if (e.description) md += `- Description: ${e.description}\n`;
          if (e.tags.length > 0) md += `- Tags: ${e.tags.join(', ')}\n`;
          md += '\n';
        });
      });
    }
    
    if (format.includeRelationships) {
      md += '## Relationships\n\n';
      const relationships = KnowledgeGraphStorage.getRelationships();
      
      relationships.forEach((r: RelationshipEdge) => {
        const from = KnowledgeGraphStorage.getEntity(r.fromEntityId);
        const to = KnowledgeGraphStorage.getEntity(r.toEntityId);
        
        md += `- **${from?.name || 'Unknown'}** → \`${r.kind}\` → **${to?.name || 'Unknown'}**\n`;
        md += `  - Strength: ${r.strength}\n`;
        if (r.description) md += `  - ${r.description}\n`;
        md += '\n';
      });
    }
    
    return md;
  }
  
  // ============ IMPORT ============
  
  static async importJSON(jsonString: string): Promise<ImportResult> {
    try {
      const data = JSON.parse(jsonString);
      const result: ImportResult = {
        success: true,
        entitiesCreated: 0,
        relationshipsCreated: 0,
        groupsCreated: 0,
        errors: [],
        warnings: [],
      };
      
      if (data.entities && Array.isArray(data.entities)) {
        const entities = KnowledgeGraphStorage.getEntities();
        data.entities.forEach((e: Entity) => {
          // Check if entity already exists
          if (entities.find((existing: Entity) => existing.id === e.id)) {
            result.warnings.push(`Entity ${e.name} already exists, skipping`);
          } else {
            KnowledgeGraphStorage.addEntity(e);
            result.entitiesCreated++;
          }
        });
      }
      
      if (data.relationships && Array.isArray(data.relationships)) {
        const relationships = KnowledgeGraphStorage.getRelationships();
        data.relationships.forEach((r: RelationshipEdge) => {
          if (relationships.find((existing: RelationshipEdge) => existing.id === r.id)) {
            result.warnings.push(`Relationship ${r.id} already exists, skipping`);
          } else {
            KnowledgeGraphStorage.addRelationship(r);
            result.relationshipsCreated++;
          }
        });
      }
      
      if (data.groups && Array.isArray(data.groups)) {
        const groups = KnowledgeGraphStorage.getGroups();
        data.groups.forEach((g: EntityGroup) => {
          if (groups.find((existing: EntityGroup) => existing.id === g.id)) {
            result.warnings.push(`Group ${g.name} already exists, skipping`);
          } else {
            KnowledgeGraphStorage.addGroup(g);
            result.groupsCreated++;
          }
        });
      }
      
      return result;
    } catch (error) {
      return {
        success: false,
        entitiesCreated: 0,
        relationshipsCreated: 0,
        groupsCreated: 0,
        errors: [error instanceof Error ? error.message : 'Unknown error'],
        warnings: [],
      };
    }
  }
  
  static async importCSV(csvString: string, type: 'entities' | 'relationships'): Promise<ImportResult> {
    const result: ImportResult = {
      success: true,
      entitiesCreated: 0,
      relationshipsCreated: 0,
      groupsCreated: 0,
      errors: [],
      warnings: [],
    };
    
    try {
      const parsed = Papa.parse(csvString, { header: true });
      
      if (type === 'entities') {
        parsed.data.forEach((row: Record<string, string>) => {
          try {
            const entity: Entity = {
              id: row.id || `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
              type: row.type as Entity['type'],
              name: row.name,
              slug: row.slug || row.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
              description: row.description || '',
              primaryEmoji: row.primaryEmoji,
              importanceLevel: (row.importanceLevel as Entity['importanceLevel']) || 'medium',
              canonical: row.canonical === 'true',
              sourceMiniApp: row.sourceMiniApp,
              externalRef: row.externalRef,
              chain: row.chain,
              tags: row.tags ? row.tags.split(';') : [],
              notes: row.notes || '',
              seoTitle: '',
              seoDescription: '',
              seoKeywords: [],
              seoHashtags: [],
              altText: '',
              primaryGeoTargets: [],
              entityIntroLocalized: {},
              tagsLocalized: {},
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            };
            
            KnowledgeGraphStorage.addEntity(entity);
            result.entitiesCreated++;
          } catch (error) {
            result.errors.push(`Failed to import entity: ${error instanceof Error ? error.message : 'Unknown error'}`);
          }
        });
      } else if (type === 'relationships') {
        parsed.data.forEach((row: Record<string, string>) => {
          try {
            const relationship: RelationshipEdge = {
              id: row.id || `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
              fromEntityId: row.fromEntityId,
              toEntityId: row.toEntityId,
              kind: row.kind,
              direction: (row.direction as RelationshipEdge['direction']) || 'forward',
              description: row.description || '',
              strength: (row.strength as RelationshipEdge['strength']) || 'normal',
              context: row.context || '',
              tags: row.tags ? row.tags.split(';') : [],
              notes: row.notes || '',
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            };
            
            KnowledgeGraphStorage.addRelationship(relationship);
            result.relationshipsCreated++;
          } catch (error) {
            result.errors.push(`Failed to import relationship: ${error instanceof Error ? error.message : 'Unknown error'}`);
          }
        });
      }
      
      return result;
    } catch (error) {
      return {
        success: false,
        entitiesCreated: 0,
        relationshipsCreated: 0,
        groupsCreated: 0,
        errors: [error instanceof Error ? error.message : 'Unknown error'],
        warnings: [],
      };
    }
  }
  
  // ============ UTILITIES ============
  
  private static escapeXml(str: string): string {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');
  }
  
  private static escapeCypher(str: string): string {
    return str.replace(/"/g, '\\"').replace(/\n/g, '\\n');
  }
  
  private static sanitizeId(id: string): string {
    return id.replace(/[^a-zA-Z0-9]/g, '_');
  }
  
  private static sanitizeRelKind(kind: string): string {
    return kind.toUpperCase().replace(/[^A-Z0-9_]/g, '_');
  }
  
  // ============ DOWNLOAD HELPER ============
  
  static downloadFile(content: string, filename: string, mimeType: string = 'text/plain'): void {
    if (typeof window === 'undefined') return;
    
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}
