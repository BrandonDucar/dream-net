import type {
  Entity,
  RelationshipEdge,
  EntityGroup,
  PathTemplate,
  CreateEntityInput,
  UpdateEntityInput,
  CreateRelationshipInput,
  UpdateRelationshipInput,
  CreateEntityGroupInput,
  UpdateEntityGroupInput,
  CreatePathTemplateInput,
  UpdatePathTemplateInput,
  EntityFilter,
  GeoTarget,
  NeighborOptions,
  NeighborResult,
  PathMatch,
} from '@/types/knowledge-graph';
import { KnowledgeGraphStorage } from './storage';
import { SEOGenerator } from './seo-generator';
import { GeoGenerator } from './geo-generator';
import { GraphEngine } from './graph-engine';
import { SummaryGenerator } from './summary-generator';

export class KnowledgeGraphService {
  // ============ ENTITIES ============
  
  static createEntity(input: CreateEntityInput): Entity {
    const now = new Date().toISOString();
    const slug = input.slug || this.generateSlug(input.name);
    
    const seoMetadata = SEOGenerator.generateSEOMetadata({
      name: input.name,
      type: input.type,
      description: input.description || '',
      tags: input.tags || [],
      primaryEmoji: input.primaryEmoji,
    });
    
    const entity: Entity = {
      id: this.generateId(),
      type: input.type,
      name: input.name,
      slug,
      description: input.description || '',
      primaryEmoji: input.primaryEmoji,
      importanceLevel: input.importanceLevel || 'medium',
      canonical: false,
      sourceMiniApp: input.sourceMiniApp,
      externalRef: input.externalRef,
      chain: input.chain,
      tags: input.tags || [],
      notes: '',
      ...seoMetadata,
      primaryGeoTargets: [],
      entityIntroLocalized: {},
      tagsLocalized: {},
      createdAt: now,
      updatedAt: now,
    };
    
    KnowledgeGraphStorage.addEntity(entity);
    return entity;
  }
  
  static updateEntity(input: UpdateEntityInput): Entity | undefined {
    const existing = KnowledgeGraphStorage.getEntity(input.id);
    if (!existing) return undefined;
    
    const updated: Entity = {
      ...existing,
      ...input,
      id: existing.id,
      createdAt: existing.createdAt,
      updatedAt: new Date().toISOString(),
    };
    
    KnowledgeGraphStorage.updateEntity(updated);
    return updated;
  }
  
  static setEntityCanonical(id: string, canonical: boolean): Entity | undefined {
    return this.updateEntity({ id, canonical });
  }
  
  static assignGeoTargetsToEntity(entityId: string, geoTargets: GeoTarget[]): Entity | undefined {
    return this.updateEntity({ id: entityId, primaryGeoTargets: geoTargets });
  }
  
  static generateGeoVariantsForEntity(entityId: string): Entity | undefined {
    const entity = KnowledgeGraphStorage.getEntity(entityId);
    if (!entity) return undefined;
    
    const { entityIntroLocalized, tagsLocalized } = GeoGenerator.generateGeoVariants(
      entity,
      entity.primaryGeoTargets
    );
    
    return this.updateEntity({ id: entityId, entityIntroLocalized, tagsLocalized });
  }
  
  static regenerateSEO(entityId: string): Entity | undefined {
    const entity = KnowledgeGraphStorage.getEntity(entityId);
    if (!entity) return undefined;
    
    const seoMetadata = SEOGenerator.generateSEOMetadata(entity);
    
    return this.updateEntity({ id: entityId, ...seoMetadata });
  }
  
  static deleteEntity(id: string): void {
    KnowledgeGraphStorage.deleteEntity(id);
  }
  
  static getEntity(id: string): Entity | undefined {
    return KnowledgeGraphStorage.getEntity(id);
  }
  
  static listEntities(filter?: EntityFilter): Entity[] {
    let entities = KnowledgeGraphStorage.getEntities();
    
    if (!filter) return entities;
    
    if (filter.type) {
      entities = entities.filter((e: Entity) => e.type === filter.type);
    }
    
    if (filter.importanceLevel) {
      entities = entities.filter((e: Entity) => e.importanceLevel === filter.importanceLevel);
    }
    
    if (filter.canonical !== undefined) {
      entities = entities.filter((e: Entity) => e.canonical === filter.canonical);
    }
    
    if (filter.searchText) {
      const searchLower = filter.searchText.toLowerCase();
      entities = entities.filter((e: Entity) => 
        e.name.toLowerCase().includes(searchLower) ||
        e.description.toLowerCase().includes(searchLower) ||
        e.tags.some((tag: string) => tag.toLowerCase().includes(searchLower))
      );
    }
    
    return entities;
  }
  
  static getEntityDetail(entityId: string): {
    entity: Entity;
    inboundEdges: RelationshipEdge[];
    outboundEdges: RelationshipEdge[];
    groups: EntityGroup[];
  } | undefined {
    const entity = KnowledgeGraphStorage.getEntity(entityId);
    if (!entity) return undefined;
    
    const inboundEdges = GraphEngine.getInboundEdges(entityId);
    const outboundEdges = GraphEngine.getOutboundEdges(entityId);
    const groupIds = GraphEngine.getEntityGroups(entityId);
    const groups = groupIds
      .map((id: string) => KnowledgeGraphStorage.getGroup(id))
      .filter((g): g is EntityGroup => g !== undefined);
    
    return {
      entity,
      inboundEdges,
      outboundEdges,
      groups,
    };
  }
  
  // ============ RELATIONSHIPS ============
  
  static createRelationship(input: CreateRelationshipInput): RelationshipEdge {
    const now = new Date().toISOString();
    
    const relationship: RelationshipEdge = {
      id: this.generateId(),
      fromEntityId: input.fromEntityId,
      toEntityId: input.toEntityId,
      kind: input.kind,
      direction: input.direction || 'forward',
      description: input.description,
      strength: input.strength || 'normal',
      context: input.context || '',
      tags: input.tags || [],
      notes: '',
      createdAt: now,
      updatedAt: now,
    };
    
    KnowledgeGraphStorage.addRelationship(relationship);
    return relationship;
  }
  
  static updateRelationship(input: UpdateRelationshipInput): RelationshipEdge | undefined {
    const existing = KnowledgeGraphStorage.getRelationship(input.id);
    if (!existing) return undefined;
    
    const updated: RelationshipEdge = {
      ...existing,
      ...input,
      id: existing.id,
      createdAt: existing.createdAt,
      updatedAt: new Date().toISOString(),
    };
    
    KnowledgeGraphStorage.updateRelationship(updated);
    return updated;
  }
  
  static deleteRelationship(id: string): void {
    KnowledgeGraphStorage.deleteRelationship(id);
  }
  
  static getRelationship(id: string): RelationshipEdge | undefined {
    return KnowledgeGraphStorage.getRelationship(id);
  }
  
  static listRelationships(): RelationshipEdge[] {
    return KnowledgeGraphStorage.getRelationships();
  }
  
  // ============ GROUPS ============
  
  static createEntityGroup(input: CreateEntityGroupInput): EntityGroup {
    const now = new Date().toISOString();
    
    const group: EntityGroup = {
      id: this.generateId(),
      name: input.name,
      description: input.description,
      entityIds: input.entityIds || [],
      tags: input.tags || [],
      createdAt: now,
      updatedAt: now,
    };
    
    KnowledgeGraphStorage.addGroup(group);
    return group;
  }
  
  static updateEntityGroup(input: UpdateEntityGroupInput): EntityGroup | undefined {
    const existing = KnowledgeGraphStorage.getGroup(input.id);
    if (!existing) return undefined;
    
    const updated: EntityGroup = {
      ...existing,
      ...input,
      id: existing.id,
      createdAt: existing.createdAt,
      updatedAt: new Date().toISOString(),
    };
    
    KnowledgeGraphStorage.updateGroup(updated);
    return updated;
  }
  
  static deleteEntityGroup(id: string): void {
    KnowledgeGraphStorage.deleteGroup(id);
  }
  
  static getEntityGroup(id: string): EntityGroup | undefined {
    return KnowledgeGraphStorage.getGroup(id);
  }
  
  static listEntityGroups(): EntityGroup[] {
    return KnowledgeGraphStorage.getGroups();
  }
  
  // ============ PATH TEMPLATES ============
  
  static createPathTemplate(input: CreatePathTemplateInput): PathTemplate {
    const now = new Date().toISOString();
    
    const template: PathTemplate = {
      id: this.generateId(),
      name: input.name,
      description: input.description,
      nodeTypes: input.nodeTypes,
      relationKinds: input.relationKinds,
      tags: input.tags || [],
      createdAt: now,
      updatedAt: now,
    };
    
    KnowledgeGraphStorage.addPathTemplate(template);
    return template;
  }
  
  static updatePathTemplate(input: UpdatePathTemplateInput): PathTemplate | undefined {
    const existing = KnowledgeGraphStorage.getPathTemplate(input.id);
    if (!existing) return undefined;
    
    const updated: PathTemplate = {
      ...existing,
      ...input,
      id: existing.id,
      createdAt: existing.createdAt,
      updatedAt: new Date().toISOString(),
    };
    
    KnowledgeGraphStorage.updatePathTemplate(updated);
    return updated;
  }
  
  static deletePathTemplate(id: string): void {
    KnowledgeGraphStorage.deletePathTemplate(id);
  }
  
  static getPathTemplate(id: string): PathTemplate | undefined {
    return KnowledgeGraphStorage.getPathTemplate(id);
  }
  
  static listPathTemplates(): PathTemplate[] {
    return KnowledgeGraphStorage.getPathTemplates();
  }
  
  // ============ GRAPH OPERATIONS ============
  
  static findNeighbors(entityId: string, options: NeighborOptions): NeighborResult {
    return GraphEngine.findNeighbors(entityId, options);
  }
  
  static matchPathTemplate(templateId: string, startEntityId?: string): PathMatch[] {
    return GraphEngine.matchPathTemplate(templateId, startEntityId);
  }
  
  // ============ SUMMARIES ============
  
  static generateEntityGraphSummary(entityId: string): string {
    return SummaryGenerator.generateEntityGraphSummary(entityId);
  }
  
  static generateGroupSummary(groupId: string): string {
    return SummaryGenerator.generateGroupSummary(groupId);
  }
  
  static exportGraphOverview(): string {
    return SummaryGenerator.exportGraphOverview();
  }
  
  // ============ UTILITIES ============
  
  private static generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  }
  
  private static generateSlug(name: string): string {
    return name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }
}
