// Advanced Path Operations

import type { PathResult } from '@/types/knowledge-graph-extended';
import type { Entity, RelationshipEdge } from '@/types/knowledge-graph';
import { KnowledgeGraphStorage } from './storage';
import { GraphEngine } from './graph-engine';

export class PathOperations {
  // ============ SHORTEST PATH ============
  
  static findShortestPath(fromEntityId: string, toEntityId: string): {
    entityIds: string[];
    edgeIds: string[];
    length: number;
  } | null {
    if (fromEntityId === toEntityId) {
      return { entityIds: [fromEntityId], edgeIds: [], length: 0 };
    }
    
    // BFS for shortest path
    const queue: Array<{
      entityId: string;
      path: string[];
      edges: string[];
    }> = [{ entityId: fromEntityId, path: [fromEntityId], edges: [] }];
    
    const visited = new Set<string>();
    
    while (queue.length > 0) {
      const current = queue.shift()!;
      
      if (visited.has(current.entityId)) continue;
      visited.add(current.entityId);
      
      // Check outbound edges
      const outbound = GraphEngine.getOutboundEdges(current.entityId);
      
      for (const edge of outbound) {
        if (edge.toEntityId === toEntityId) {
          return {
            entityIds: [...current.path, toEntityId],
            edgeIds: [...current.edges, edge.id],
            length: current.path.length,
          };
        }
        
        if (!visited.has(edge.toEntityId)) {
          queue.push({
            entityId: edge.toEntityId,
            path: [...current.path, edge.toEntityId],
            edges: [...current.edges, edge.id],
          });
        }
      }
      
      // Check inbound edges (for bidirectional)
      const inbound = GraphEngine.getInboundEdges(current.entityId);
      
      for (const edge of inbound) {
        if (edge.direction === 'bidirectional' && !visited.has(edge.fromEntityId)) {
          if (edge.fromEntityId === toEntityId) {
            return {
              entityIds: [...current.path, toEntityId],
              edgeIds: [...current.edges, edge.id],
              length: current.path.length,
            };
          }
          
          queue.push({
            entityId: edge.fromEntityId,
            path: [...current.path, edge.fromEntityId],
            edges: [...current.edges, edge.id],
          });
        }
      }
    }
    
    return null; // No path found
  }
  
  // ============ ALL PATHS ============
  
  static findAllPaths(
    fromEntityId: string,
    toEntityId: string,
    maxLength: number = 5,
    maxPaths: number = 10
  ): PathResult {
    const paths: Array<{
      entityIds: string[];
      edgeIds: string[];
      length: number;
      totalStrength: number;
    }> = [];
    
    const visited = new Set<string>();
    
    const dfs = (
      currentId: string,
      currentPath: string[],
      currentEdges: string[],
      depth: number
    ): void => {
      if (depth > maxLength || paths.length >= maxPaths) return;
      
      if (currentId === toEntityId && currentPath.length > 1) {
        const totalStrength = this.calculatePathStrength(currentEdges);
        paths.push({
          entityIds: [...currentPath],
          edgeIds: [...currentEdges],
          length: currentPath.length - 1,
          totalStrength,
        });
        return;
      }
      
      visited.add(currentId);
      
      const outbound = GraphEngine.getOutboundEdges(currentId);
      
      for (const edge of outbound) {
        if (!visited.has(edge.toEntityId)) {
          dfs(
            edge.toEntityId,
            [...currentPath, edge.toEntityId],
            [...currentEdges, edge.id],
            depth + 1
          );
        }
      }
      
      visited.delete(currentId);
    };
    
    dfs(fromEntityId, [fromEntityId], [], 0);
    
    // Calculate summary
    const summary = {
      shortestPath: paths.length > 0 ? Math.min(...paths.map((p) => p.length)) : 0,
      longestPath: paths.length > 0 ? Math.max(...paths.map((p) => p.length)) : 0,
      averageLength: paths.length > 0 
        ? paths.reduce((sum, p) => sum + p.length, 0) / paths.length 
        : 0,
      totalPaths: paths.length,
    };
    
    return { paths, summary };
  }
  
  private static calculatePathStrength(edgeIds: string[]): number {
    let total = 0;
    
    edgeIds.forEach((edgeId) => {
      const edge = KnowledgeGraphStorage.getRelationship(edgeId);
      if (edge) {
        switch (edge.strength) {
          case 'weak': total += 1; break;
          case 'normal': total += 2; break;
          case 'strong': total += 3; break;
          case 'critical': total += 4; break;
        }
      }
    });
    
    return total;
  }
  
  // ============ PATH FINDING WITH CONSTRAINTS ============
  
  static findPathWithConstraints(params: {
    fromEntityId: string;
    toEntityId: string;
    requiredRelationKinds?: string[];
    forbiddenRelationKinds?: string[];
    requiredEntityTypes?: string[];
    maxLength?: number;
  }): {
    entityIds: string[];
    edgeIds: string[];
    length: number;
  } | null {
    const {
      fromEntityId,
      toEntityId,
      requiredRelationKinds = [],
      forbiddenRelationKinds = [],
      requiredEntityTypes = [],
      maxLength = 5,
    } = params;
    
    const queue: Array<{
      entityId: string;
      path: string[];
      edges: string[];
      visitedKinds: Set<string>;
      visitedTypes: Set<string>;
    }> = [{
      entityId: fromEntityId,
      path: [fromEntityId],
      edges: [],
      visitedKinds: new Set(),
      visitedTypes: new Set([KnowledgeGraphStorage.getEntity(fromEntityId)?.type || '']),
    }];
    
    const visited = new Set<string>();
    
    while (queue.length > 0) {
      const current = queue.shift()!;
      
      if (current.path.length > maxLength) continue;
      if (visited.has(current.entityId)) continue;
      visited.add(current.entityId);
      
      // Check if we reached the target
      if (current.entityId === toEntityId) {
        // Verify all required kinds were used
        const hasAllRequired = requiredRelationKinds.every((kind) => 
          current.visitedKinds.has(kind)
        );
        
        const hasAllTypes = requiredEntityTypes.every((type) =>
          current.visitedTypes.has(type)
        );
        
        if (hasAllRequired && hasAllTypes) {
          return {
            entityIds: current.path,
            edgeIds: current.edges,
            length: current.path.length - 1,
          };
        }
      }
      
      const outbound = GraphEngine.getOutboundEdges(current.entityId);
      
      for (const edge of outbound) {
        // Check forbidden kinds
        if (forbiddenRelationKinds.includes(edge.kind)) continue;
        
        if (!visited.has(edge.toEntityId)) {
          const targetEntity = KnowledgeGraphStorage.getEntity(edge.toEntityId);
          
          queue.push({
            entityId: edge.toEntityId,
            path: [...current.path, edge.toEntityId],
            edges: [...current.edges, edge.id],
            visitedKinds: new Set([...current.visitedKinds, edge.kind]),
            visitedTypes: new Set([...current.visitedTypes, targetEntity?.type || '']),
          });
        }
      }
    }
    
    return null;
  }
  
  // ============ RELATIONSHIP CHAINS ============
  
  static findRelationshipChains(params: {
    startEntityId: string;
    chainPattern: Array<{ kind: string; direction: 'forward' | 'backward' | 'any' }>;
    maxResults?: number;
  }): Array<{
    entityIds: string[];
    edgeIds: string[];
  }> {
    const { startEntityId, chainPattern, maxResults = 10 } = params;
    const results: Array<{ entityIds: string[]; edgeIds: string[] }> = [];
    
    const search = (
      currentId: string,
      patternIndex: number,
      path: string[],
      edges: string[]
    ): void => {
      if (results.length >= maxResults) return;
      
      if (patternIndex >= chainPattern.length) {
        results.push({ entityIds: [...path], edgeIds: [...edges] });
        return;
      }
      
      const pattern = chainPattern[patternIndex];
      
      // Forward direction
      if (pattern.direction === 'forward' || pattern.direction === 'any') {
        const outbound = GraphEngine.getOutboundEdges(currentId);
        
        for (const edge of outbound) {
          if (edge.kind === pattern.kind) {
            search(
              edge.toEntityId,
              patternIndex + 1,
              [...path, edge.toEntityId],
              [...edges, edge.id]
            );
          }
        }
      }
      
      // Backward direction
      if (pattern.direction === 'backward' || pattern.direction === 'any') {
        const inbound = GraphEngine.getInboundEdges(currentId);
        
        for (const edge of inbound) {
          if (edge.kind === pattern.kind) {
            search(
              edge.fromEntityId,
              patternIndex + 1,
              [...path, edge.fromEntityId],
              [...edges, edge.id]
            );
          }
        }
      }
    };
    
    search(startEntityId, 0, [startEntityId], []);
    
    return results;
  }
  
  // ============ COMMON ANCESTORS/DESCENDANTS ============
  
  static findCommonAncestors(entityId1: string, entityId2: string): Entity[] {
    const ancestors1 = this.findAncestors(entityId1);
    const ancestors2 = this.findAncestors(entityId2);
    
    const common = ancestors1.filter((a1) =>
      ancestors2.some((a2) => a2.id === a1.id)
    );
    
    return common;
  }
  
  static findCommonDescendants(entityId1: string, entityId2: string): Entity[] {
    const descendants1 = this.findDescendants(entityId1);
    const descendants2 = this.findDescendants(entityId2);
    
    const common = descendants1.filter((d1) =>
      descendants2.some((d2) => d2.id === d1.id)
    );
    
    return common;
  }
  
  private static findAncestors(entityId: string, visited = new Set<string>()): Entity[] {
    if (visited.has(entityId)) return [];
    visited.add(entityId);
    
    const ancestors: Entity[] = [];
    const inbound = GraphEngine.getInboundEdges(entityId);
    
    inbound.forEach((edge) => {
      const parent = KnowledgeGraphStorage.getEntity(edge.fromEntityId);
      if (parent) {
        ancestors.push(parent);
        ancestors.push(...this.findAncestors(edge.fromEntityId, visited));
      }
    });
    
    return ancestors;
  }
  
  private static findDescendants(entityId: string, visited = new Set<string>()): Entity[] {
    if (visited.has(entityId)) return [];
    visited.add(entityId);
    
    const descendants: Entity[] = [];
    const outbound = GraphEngine.getOutboundEdges(entityId);
    
    outbound.forEach((edge) => {
      const child = KnowledgeGraphStorage.getEntity(edge.toEntityId);
      if (child) {
        descendants.push(child);
        descendants.push(...this.findDescendants(edge.toEntityId, visited));
      }
    });
    
    return descendants;
  }
}
