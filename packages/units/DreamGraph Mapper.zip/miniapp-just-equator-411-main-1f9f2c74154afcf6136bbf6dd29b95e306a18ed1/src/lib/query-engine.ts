// Custom Query Engine

import type { CustomQuery } from '@/types/knowledge-graph-extended';
import type { Entity } from '@/types/knowledge-graph';
import { KnowledgeGraphStorage } from './storage';
import { PathOperations } from './path-operations';

const STORAGE_KEY = 'dreamnet_kg_custom_queries';

export class QueryEngine {
  // ============ CRUD ============
  
  static createQuery(params: {
    name: string;
    description: string;
    query: CustomQuery['query'];
  }): CustomQuery {
    const customQuery: CustomQuery = {
      id: this.generateId(),
      name: params.name,
      description: params.description,
      query: params.query,
      createdAt: new Date().toISOString(),
    };
    
    const queries = this.getQueries();
    queries.push(customQuery);
    this.saveQueries(queries);
    
    return customQuery;
  }
  
  static updateQuery(id: string, updates: Partial<CustomQuery>): CustomQuery | undefined {
    const queries = this.getQueries();
    const index = queries.findIndex((q: CustomQuery) => q.id === id);
    
    if (index === -1) return undefined;
    
    queries[index] = {
      ...queries[index],
      ...updates,
      id: queries[index].id,
      createdAt: queries[index].createdAt,
    };
    
    this.saveQueries(queries);
    return queries[index];
  }
  
  static deleteQuery(id: string): void {
    const queries = this.getQueries().filter((q: CustomQuery) => q.id !== id);
    this.saveQueries(queries);
  }
  
  static getQuery(id: string): CustomQuery | undefined {
    return this.getQueries().find((q: CustomQuery) => q.id === id);
  }
  
  static getQueries(): CustomQuery[] {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : this.getDefaultQueries();
  }
  
  private static saveQueries(queries: CustomQuery[]): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(queries));
  }
  
  // ============ EXECUTE QUERY ============
  
  static executeQuery(queryId: string): unknown[] {
    const customQuery = this.getQuery(queryId);
    if (!customQuery) return [];
    
    const results = this.runQuery(customQuery.query);
    
    // Save results
    this.updateQuery(queryId, {
      savedResults: {
        timestamp: new Date().toISOString(),
        results,
      },
    });
    
    return results;
  }
  
  private static runQuery(query: CustomQuery['query']): unknown[] {
    const entities = KnowledgeGraphStorage.getEntities();
    
    // Start with entities matching startEntityType
    let candidates = query.startEntityType
      ? entities.filter((e: Entity) => e.type === query.startEntityType)
      : entities;
    
    // If there's a relationship chain, follow it
    if (query.relationshipChain && query.relationshipChain.length > 0) {
      const results: Array<{
        startEntity: Entity;
        path: string[];
        endEntity?: Entity;
      }> = [];
      
      candidates.forEach((startEntity) => {
        const paths = PathOperations.findRelationshipChains({
          startEntityId: startEntity.id,
          chainPattern: query.relationshipChain!,
          maxResults: 100,
        });
        
        paths.forEach((path) => {
          const endEntityId = path.entityIds[path.entityIds.length - 1];
          const endEntity = KnowledgeGraphStorage.getEntity(endEntityId);
          
          // Check if end entity matches type if specified
          if (query.endEntityType && endEntity?.type !== query.endEntityType) {
            return;
          }
          
          results.push({
            startEntity,
            path: path.entityIds,
            endEntity,
          });
        });
      });
      
      return results;
    }
    
    // Simple entity filter
    if (query.filters) {
      candidates = this.applyFilters(candidates, query.filters);
    }
    
    return candidates;
  }
  
  private static applyFilters(entities: Entity[], filters: Record<string, unknown>): Entity[] {
    return entities.filter((entity: Entity) => {
      for (const key of Object.keys(filters)) {
        const filterValue = filters[key];
        const entityValue = entity[key as keyof Entity];
        
        if (Array.isArray(filterValue)) {
          if (!filterValue.includes(entityValue as string)) return false;
        } else if (filterValue !== entityValue) {
          return false;
        }
      }
      return true;
    });
  }
  
  // ============ DEFAULT QUERIES ============
  
  private static getDefaultQueries(): CustomQuery[] {
    return [
      {
        id: 'query-token-to-social',
        name: 'Token → Mini-App → Social Account',
        description: 'Find all paths from tokens to social accounts through mini-apps',
        query: {
          startEntityType: 'token',
          relationshipChain: [
            { kind: 'powers', direction: 'forward' },
            { kind: 'posts-to', direction: 'forward' },
          ],
          endEntityType: 'social-account',
        },
        createdAt: new Date().toISOString(),
      },
      {
        id: 'query-agent-backend',
        name: 'Agent Dependencies',
        description: 'Find all backend models and endpoints used by agents',
        query: {
          startEntityType: 'agent',
          relationshipChain: [
            { kind: 'uses', direction: 'forward' },
          ],
        },
        createdAt: new Date().toISOString(),
      },
      {
        id: 'query-drop-reach',
        name: 'Drop Campaign Reach',
        description: 'Find all social accounts reached by drop campaigns',
        query: {
          startEntityType: 'drop',
          relationshipChain: [
            { kind: 'posts-to', direction: 'forward' },
          ],
          endEntityType: 'social-account',
        },
        createdAt: new Date().toISOString(),
      },
      {
        id: 'query-canonical-networks',
        name: 'Canonical Entity Networks',
        description: 'All canonical entities and their immediate connections',
        query: {
          filters: {
            canonical: true,
          },
        },
        createdAt: new Date().toISOString(),
      },
    ];
  }
  
  // ============ UTILITIES ============
  
  private static generateId(): string {
    return `query-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  }
}
