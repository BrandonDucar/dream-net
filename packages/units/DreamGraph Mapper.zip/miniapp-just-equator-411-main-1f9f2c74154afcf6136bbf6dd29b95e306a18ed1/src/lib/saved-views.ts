// Saved Views Service

import type { SavedView } from '@/types/knowledge-graph-extended';

const STORAGE_KEY = 'dreamnet_kg_saved_views';

export class SavedViewsService {
  // ============ CRUD ============
  
  static createView(params: {
    name: string;
    description: string;
    filters: SavedView['filters'];
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
    isPinned?: boolean;
  }): SavedView {
    const view: SavedView = {
      id: this.generateId(),
      name: params.name,
      description: params.description,
      filters: params.filters,
      sortBy: params.sortBy,
      sortOrder: params.sortOrder,
      isPinned: params.isPinned || false,
      createdAt: new Date().toISOString(),
    };
    
    const views = this.getViews();
    views.push(view);
    this.saveViews(views);
    
    return view;
  }
  
  static updateView(id: string, updates: Partial<SavedView>): SavedView | undefined {
    const views = this.getViews();
    const index = views.findIndex((v: SavedView) => v.id === id);
    
    if (index === -1) return undefined;
    
    views[index] = {
      ...views[index],
      ...updates,
      id: views[index].id,
      createdAt: views[index].createdAt,
    };
    
    this.saveViews(views);
    return views[index];
  }
  
  static deleteView(id: string): void {
    const views = this.getViews().filter((v: SavedView) => v.id !== id);
    this.saveViews(views);
  }
  
  static togglePin(id: string): void {
    const view = this.getView(id);
    if (view) {
      this.updateView(id, { isPinned: !view.isPinned });
    }
  }
  
  static getView(id: string): SavedView | undefined {
    return this.getViews().find((v: SavedView) => v.id === id);
  }
  
  static getViews(): SavedView[] {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : this.getDefaultViews();
  }
  
  static getPinnedViews(): SavedView[] {
    return this.getViews().filter((v: SavedView) => v.isPinned);
  }
  
  private static saveViews(views: SavedView[]): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(views));
  }
  
  // ============ DEFAULT VIEWS ============
  
  private static getDefaultViews(): SavedView[] {
    return [
      {
        id: 'view-all-canonical',
        name: 'Canonical Entities',
        description: 'All canonical/anchor entities',
        filters: {
          canonical: true,
        },
        sortBy: 'importanceLevel',
        sortOrder: 'desc',
        isPinned: true,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'view-critical-high',
        name: 'Critical & High Priority',
        description: 'Critical and high importance entities',
        filters: {
          importanceLevels: ['critical', 'high'],
        },
        sortBy: 'importanceLevel',
        sortOrder: 'desc',
        isPinned: true,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'view-tokens',
        name: 'All Tokens',
        description: 'Tokens and culture coins',
        filters: {
          entityTypes: ['token', 'culture-coin'],
        },
        isPinned: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'view-mini-apps',
        name: 'Mini Apps & Agents',
        description: 'DreamNet mini-apps and AI agents',
        filters: {
          entityTypes: ['mini-app', 'agent'],
        },
        isPinned: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'view-social',
        name: 'Social Surface',
        description: 'Social accounts and content streams',
        filters: {
          entityTypes: ['social-account', 'content-stream'],
        },
        isPinned: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'view-pickleball',
        name: 'Pickleball Projects',
        description: 'All pickleball-related entities',
        filters: {
          tags: ['pickleball'],
        },
        isPinned: false,
        createdAt: new Date().toISOString(),
      },
    ];
  }
  
  // ============ UTILITIES ============
  
  private static generateId(): string {
    return `view-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  }
}
