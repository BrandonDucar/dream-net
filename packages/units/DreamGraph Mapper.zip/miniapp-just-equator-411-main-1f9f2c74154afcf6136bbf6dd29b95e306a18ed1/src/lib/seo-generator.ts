import type { Entity, EntityType } from '@/types/knowledge-graph';

export class SEOGenerator {
  static generateSEOMetadata(entity: Pick<Entity, 'name' | 'type' | 'description' | 'tags' | 'primaryEmoji'>): {
    seoTitle: string;
    seoDescription: string;
    seoKeywords: string[];
    seoHashtags: string[];
    altText: string;
  } {
    const { name, type, description, tags, primaryEmoji } = entity;
    
    const typeLabel = this.getTypeLabel(type);
    
    const seoTitle = `${name} - ${typeLabel} | DreamNet Knowledge Graph`;
    
    const seoDescription = description 
      ? description.substring(0, 160) 
      : `${name} is a ${typeLabel} in the DreamNet ecosystem. Explore connections and relationships.`;
    
    const seoKeywords = [
      name,
      typeLabel,
      'DreamNet',
      ...tags,
      type,
    ];
    
    const seoHashtags = [
      '#DreamNet',
      `#${type.replace(/-/g, '')}`,
      ...tags.slice(0, 3).map((tag: string) => `#${tag.replace(/\s+/g, '')}`),
    ];
    
    const altText = primaryEmoji 
      ? `${primaryEmoji} ${name} - ${typeLabel}` 
      : `${name} - ${typeLabel}`;
    
    return {
      seoTitle,
      seoDescription,
      seoKeywords,
      seoHashtags,
      altText,
    };
  }
  
  private static getTypeLabel(type: EntityType): string {
    const labels: Record<EntityType, string> = {
      'token': 'Token',
      'culture-coin': 'Culture Coin',
      'wallet': 'Wallet',
      'mini-app': 'Mini App',
      'agent': 'Agent',
      'backend-model': 'Backend Model',
      'backend-endpoint': 'Backend Endpoint',
      'drop': 'Drop',
      'campaign': 'Campaign',
      'content-stream': 'Content Stream',
      'social-account': 'Social Account',
      'segment': 'Segment',
      'audience': 'Audience',
      'pickleball': 'Pickleball',
      'infra': 'Infrastructure',
      'other': 'Entity',
    };
    
    return labels[type] || 'Entity';
  }
}
