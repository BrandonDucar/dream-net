// Smart Suggestions Service

import type { Suggestion, InferredRelationship } from '@/types/knowledge-graph-extended';
import type { Entity, RelationshipEdge } from '@/types/knowledge-graph';
import { KnowledgeGraphStorage } from './storage';
import { GraphEngine } from './graph-engine';
import Fuse from 'fuse.js';

const STORAGE_KEY = 'dreamnet_kg_suggestions';

export class SmartSuggestions {
  // ============ GENERATE SUGGESTIONS ============
  
  static generateAllSuggestions(): Suggestion[] {
    const suggestions: Suggestion[] = [];
    
    suggestions.push(...this.suggestMissingRelationships());
    suggestions.push(...this.suggestDuplicateEntities());
    suggestions.push(...this.suggestTags());
    suggestions.push(...this.suggestCompletionPrompts());
    suggestions.push(...this.suggestPatternMatches());
    
    // Save suggestions
    this.saveSuggestions(suggestions);
    
    return suggestions;
  }
  
  // ============ MISSING RELATIONSHIPS ============
  
  private static suggestMissingRelationships(): Suggestion[] {
    const suggestions: Suggestion[] = [];
    const entities = KnowledgeGraphStorage.getEntities();
    
    // Common patterns: Token → Mini-App, Mini-App → Agent, Agent → Backend
    const patterns = [
      { from: 'token', to: 'mini-app', kind: 'powers' },
      { from: 'culture-coin', to: 'mini-app', kind: 'powers' },
      { from: 'mini-app', to: 'agent', kind: 'uses' },
      { from: 'agent', to: 'backend-model', kind: 'uses' },
      { from: 'agent', to: 'backend-endpoint', kind: 'calls' },
      { from: 'drop', to: 'social-account', kind: 'posts-to' },
      { from: 'campaign', to: 'content-stream', kind: 'feeds' },
      { from: 'mini-app', to: 'social-account', kind: 'posts-to' },
    ];
    
    entities.forEach((entity: Entity) => {
      patterns.forEach((pattern) => {
        if (entity.type === pattern.from) {
          // Check if this entity has any relationship of this kind
          const outbound = GraphEngine.getOutboundEdges(entity.id);
          const hasPattern = outbound.some((edge: RelationshipEdge) => 
            edge.kind === pattern.kind
          );
          
          if (!hasPattern) {
            // Find potential target entities
            const targets = entities.filter((e: Entity) => e.type === pattern.to);
            
            if (targets.length > 0) {
              suggestions.push({
                id: `missing-rel-${entity.id}-${pattern.kind}`,
                type: 'missing-relationship',
                priority: 'medium',
                entityId: entity.id,
                message: `Consider adding a "${pattern.kind}" relationship to a ${pattern.to}`,
                action: {
                  type: 'create-relationship',
                  params: {
                    fromEntityId: entity.id,
                    kind: pattern.kind,
                    suggestedTargetType: pattern.to,
                  },
                },
                dismissed: false,
                createdAt: new Date().toISOString(),
              });
            }
          }
        }
      });
    });
    
    return suggestions.slice(0, 20); // Limit to top 20
  }
  
  // ============ DUPLICATE DETECTION ============
  
  private static suggestDuplicateEntities(): Suggestion[] {
    const suggestions: Suggestion[] = [];
    const entities = KnowledgeGraphStorage.getEntities();
    
    // Use Fuse.js for fuzzy matching
    const fuse = new Fuse(entities, {
      keys: ['name', 'slug', 'externalRef'],
      threshold: 0.3,
    });
    
    entities.forEach((entity: Entity) => {
      const results = fuse.search(entity.name);
      
      // Find potential duplicates (excluding self)
      const duplicates = results
        .map((r) => r.item)
        .filter((e: Entity) => 
          e.id !== entity.id && 
          e.type === entity.type
        );
      
      if (duplicates.length > 0) {
        duplicates.forEach((duplicate: Entity) => {
          suggestions.push({
            id: `duplicate-${entity.id}-${duplicate.id}`,
            type: 'duplicate-entity',
            priority: 'high',
            entityId: entity.id,
            message: `Possible duplicate: "${entity.name}" and "${duplicate.name}"`,
            action: {
              type: 'review-duplicate',
              params: {
                entity1Id: entity.id,
                entity2Id: duplicate.id,
              },
            },
            dismissed: false,
            createdAt: new Date().toISOString(),
          });
        });
      }
    });
    
    // Remove duplicate suggestions
    const uniqueSuggestions = new Map<string, Suggestion>();
    suggestions.forEach((s) => {
      const key = [s.entityId, s.action?.params?.entity2Id].sort().join('-');
      if (!uniqueSuggestions.has(key)) {
        uniqueSuggestions.set(key, s);
      }
    });
    
    return Array.from(uniqueSuggestions.values()).slice(0, 10);
  }
  
  // ============ TAG SUGGESTIONS ============
  
  private static suggestTags(): Suggestion[] {
    const suggestions: Suggestion[] = [];
    const entities = KnowledgeGraphStorage.getEntities();
    
    // Build tag frequency map
    const tagCounts: Map<string, number> = new Map();
    entities.forEach((e: Entity) => {
      e.tags.forEach((tag) => {
        tagCounts.set(tag, (tagCounts.get(tag) || 0) + 1);
      });
    });
    
    // Get popular tags
    const popularTags = Array.from(tagCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map((entry) => entry[0]);
    
    // Suggest tags based on entity type and description
    entities.forEach((entity: Entity) => {
      if (entity.tags.length < 2) {
        const suggestedTags: string[] = [];
        
        // Type-based tags
        if (entity.type === 'token' || entity.type === 'culture-coin') {
          suggestedTags.push('defi', 'token', 'base');
        } else if (entity.type === 'mini-app') {
          suggestedTags.push('app', 'tool', 'dreamnet');
        } else if (entity.type === 'social-account') {
          suggestedTags.push('social', 'content', 'engagement');
        }
        
        // Description-based tags
        const desc = entity.description.toLowerCase();
        if (desc.includes('pickleball')) suggestedTags.push('pickleball');
        if (desc.includes('culture')) suggestedTags.push('culture');
        if (desc.includes('analytics')) suggestedTags.push('analytics');
        if (desc.includes('automation')) suggestedTags.push('automation');
        
        // Popular tags not yet used
        popularTags.forEach((tag) => {
          if (!entity.tags.includes(tag) && !suggestedTags.includes(tag)) {
            suggestedTags.push(tag);
          }
        });
        
        if (suggestedTags.length > 0) {
          suggestions.push({
            id: `tags-${entity.id}`,
            type: 'tag-suggestion',
            priority: 'low',
            entityId: entity.id,
            message: `Suggested tags: ${suggestedTags.slice(0, 3).join(', ')}`,
            action: {
              type: 'add-tags',
              params: {
                tags: suggestedTags.slice(0, 3),
              },
            },
            dismissed: false,
            createdAt: new Date().toISOString(),
          });
        }
      }
    });
    
    return suggestions.slice(0, 15);
  }
  
  // ============ COMPLETION PROMPTS ============
  
  private static suggestCompletionPrompts(): Suggestion[] {
    const suggestions: Suggestion[] = [];
    const entities = KnowledgeGraphStorage.getEntities();
    
    entities.forEach((entity: Entity) => {
      const issues: string[] = [];
      
      if (!entity.description || entity.description.length < 10) {
        issues.push('Add a description');
      }
      
      if (!entity.primaryEmoji) {
        issues.push('Add an emoji');
      }
      
      if (entity.tags.length === 0) {
        issues.push('Add tags');
      }
      
      if (!entity.notes) {
        issues.push('Add notes');
      }
      
      if (entity.type === 'token' && !entity.chain) {
        issues.push('Specify blockchain');
      }
      
      if ((entity.type === 'social-account' || entity.type === 'mini-app') && !entity.externalRef) {
        issues.push('Add external reference');
      }
      
      const neighbors = GraphEngine.findNeighbors(entity.id, { depth: 1 });
      if (neighbors.entities.length === 0) {
        issues.push('Add relationships');
      }
      
      if (issues.length > 0) {
        suggestions.push({
          id: `completion-${entity.id}`,
          type: 'completion-prompt',
          priority: issues.length >= 3 ? 'high' : 'medium',
          entityId: entity.id,
          message: `Incomplete: ${issues.join(', ')}`,
          dismissed: false,
          createdAt: new Date().toISOString(),
        });
      }
    });
    
    return suggestions.slice(0, 20);
  }
  
  // ============ PATTERN MATCHES ============
  
  private static suggestPatternMatches(): Suggestion[] {
    const suggestions: Suggestion[] = [];
    const templates = KnowledgeGraphStorage.getPathTemplates();
    const entities = KnowledgeGraphStorage.getEntities();
    
    templates.forEach((template) => {
      // Check which entities could start this pattern but don't
      const firstType = template.nodeTypes[0];
      
      entities.forEach((entity: Entity) => {
        if (entity.type === firstType) {
          // Check if this entity completes the pattern
          const matches = GraphEngine.matchPathTemplate(template.id, entity.id);
          
          if (matches.length === 0) {
            suggestions.push({
              id: `pattern-${template.id}-${entity.id}`,
              type: 'pattern-match',
              priority: 'low',
              entityId: entity.id,
              message: `Could match pattern "${template.name}" - add missing connections`,
              action: {
                type: 'view-pattern',
                params: {
                  templateId: template.id,
                },
              },
              dismissed: false,
              createdAt: new Date().toISOString(),
            });
          }
        }
      });
    });
    
    return suggestions.slice(0, 10);
  }
  
  // ============ RELATIONSHIP INFERENCE ============
  
  static inferRelationships(entityId: string): InferredRelationship[] {
    const inferred: InferredRelationship[] = [];
    const entity = KnowledgeGraphStorage.getEntity(entityId);
    if (!entity) return inferred;
    
    // Transitive inference: if A → B and B → C, suggest A → C
    const outbound = GraphEngine.getOutboundEdges(entityId);
    
    outbound.forEach((edge1: RelationshipEdge) => {
      const intermediateEdges = GraphEngine.getOutboundEdges(edge1.toEntityId);
      
      intermediateEdges.forEach((edge2: RelationshipEdge) => {
        // Check if direct relationship already exists
        const existing = outbound.find((e: RelationshipEdge) => 
          e.toEntityId === edge2.toEntityId
        );
        
        if (!existing && edge2.toEntityId !== entityId) {
          inferred.push({
            fromEntityId: entityId,
            toEntityId: edge2.toEntityId,
            kind: edge1.kind, // Inherit kind from first edge
            reason: `Transitive: ${entity.name} → [intermediate] → target`,
            confidence: 0.6,
            sourceEdgeIds: [edge1.id, edge2.id],
          });
        }
      });
    });
    
    return inferred.slice(0, 5);
  }
  
  // ============ STORAGE ============
  
  static getSuggestions(): Suggestion[] {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  }
  
  static saveSuggestions(suggestions: Suggestion[]): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(suggestions));
  }
  
  static dismissSuggestion(suggestionId: string): void {
    const suggestions = this.getSuggestions();
    const updated = suggestions.map((s: Suggestion) => 
      s.id === suggestionId ? { ...s, dismissed: true } : s
    );
    this.saveSuggestions(updated);
  }
  
  static clearDismissed(): void {
    const suggestions = this.getSuggestions().filter((s: Suggestion) => !s.dismissed);
    this.saveSuggestions(suggestions);
  }
}
