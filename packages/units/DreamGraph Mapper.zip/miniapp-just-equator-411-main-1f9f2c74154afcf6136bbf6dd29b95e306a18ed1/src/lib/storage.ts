import type { Entity, RelationshipEdge, EntityGroup, PathTemplate } from '@/types/knowledge-graph';

const STORAGE_KEYS = {
  ENTITIES: 'dreamnet_kg_entities',
  RELATIONSHIPS: 'dreamnet_kg_relationships',
  GROUPS: 'dreamnet_kg_groups',
  PATH_TEMPLATES: 'dreamnet_kg_path_templates',
} as const;

export class KnowledgeGraphStorage {
  // Entities
  static getEntities(): Entity[] {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.ENTITIES);
    return data ? JSON.parse(data) : [];
  }

  static saveEntities(entities: Entity[]): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEYS.ENTITIES, JSON.stringify(entities));
  }

  static getEntity(id: string): Entity | undefined {
    return this.getEntities().find((e: Entity) => e.id === id);
  }

  static addEntity(entity: Entity): void {
    const entities = this.getEntities();
    entities.push(entity);
    this.saveEntities(entities);
  }

  static updateEntity(entity: Entity): void {
    const entities = this.getEntities();
    const index = entities.findIndex((e: Entity) => e.id === entity.id);
    if (index !== -1) {
      entities[index] = entity;
      this.saveEntities(entities);
    }
  }

  static deleteEntity(id: string): void {
    const entities = this.getEntities().filter((e: Entity) => e.id !== id);
    this.saveEntities(entities);
    
    // Clean up relationships
    const relationships = this.getRelationships().filter(
      (r: RelationshipEdge) => r.fromEntityId !== id && r.toEntityId !== id
    );
    this.saveRelationships(relationships);
    
    // Clean up groups
    const groups = this.getGroups();
    groups.forEach((g: EntityGroup) => {
      g.entityIds = g.entityIds.filter((eid: string) => eid !== id);
    });
    this.saveGroups(groups);
  }

  // Relationships
  static getRelationships(): RelationshipEdge[] {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.RELATIONSHIPS);
    return data ? JSON.parse(data) : [];
  }

  static saveRelationships(relationships: RelationshipEdge[]): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEYS.RELATIONSHIPS, JSON.stringify(relationships));
  }

  static getRelationship(id: string): RelationshipEdge | undefined {
    return this.getRelationships().find((r: RelationshipEdge) => r.id === id);
  }

  static addRelationship(relationship: RelationshipEdge): void {
    const relationships = this.getRelationships();
    relationships.push(relationship);
    this.saveRelationships(relationships);
  }

  static updateRelationship(relationship: RelationshipEdge): void {
    const relationships = this.getRelationships();
    const index = relationships.findIndex((r: RelationshipEdge) => r.id === relationship.id);
    if (index !== -1) {
      relationships[index] = relationship;
      this.saveRelationships(relationships);
    }
  }

  static deleteRelationship(id: string): void {
    const relationships = this.getRelationships().filter((r: RelationshipEdge) => r.id !== id);
    this.saveRelationships(relationships);
  }

  // Groups
  static getGroups(): EntityGroup[] {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.GROUPS);
    return data ? JSON.parse(data) : [];
  }

  static saveGroups(groups: EntityGroup[]): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEYS.GROUPS, JSON.stringify(groups));
  }

  static getGroup(id: string): EntityGroup | undefined {
    return this.getGroups().find((g: EntityGroup) => g.id === id);
  }

  static addGroup(group: EntityGroup): void {
    const groups = this.getGroups();
    groups.push(group);
    this.saveGroups(groups);
  }

  static updateGroup(group: EntityGroup): void {
    const groups = this.getGroups();
    const index = groups.findIndex((g: EntityGroup) => g.id === group.id);
    if (index !== -1) {
      groups[index] = group;
      this.saveGroups(groups);
    }
  }

  static deleteGroup(id: string): void {
    const groups = this.getGroups().filter((g: EntityGroup) => g.id !== id);
    this.saveGroups(groups);
  }

  // Path Templates
  static getPathTemplates(): PathTemplate[] {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.PATH_TEMPLATES);
    return data ? JSON.parse(data) : [];
  }

  static savePathTemplates(templates: PathTemplate[]): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEYS.PATH_TEMPLATES, JSON.stringify(templates));
  }

  static getPathTemplate(id: string): PathTemplate | undefined {
    return this.getPathTemplates().find((t: PathTemplate) => t.id === id);
  }

  static addPathTemplate(template: PathTemplate): void {
    const templates = this.getPathTemplates();
    templates.push(template);
    this.savePathTemplates(templates);
  }

  static updatePathTemplate(template: PathTemplate): void {
    const templates = this.getPathTemplates();
    const index = templates.findIndex((t: PathTemplate) => t.id === template.id);
    if (index !== -1) {
      templates[index] = template;
      this.savePathTemplates(templates);
    }
  }

  static deletePathTemplate(id: string): void {
    const templates = this.getPathTemplates().filter((t: PathTemplate) => t.id !== id);
    this.savePathTemplates(templates);
  }

  // Clear all data
  static clearAll(): void {
    if (typeof window === 'undefined') return;
    localStorage.removeItem(STORAGE_KEYS.ENTITIES);
    localStorage.removeItem(STORAGE_KEYS.RELATIONSHIPS);
    localStorage.removeItem(STORAGE_KEYS.GROUPS);
    localStorage.removeItem(STORAGE_KEYS.PATH_TEMPLATES);
  }
}
