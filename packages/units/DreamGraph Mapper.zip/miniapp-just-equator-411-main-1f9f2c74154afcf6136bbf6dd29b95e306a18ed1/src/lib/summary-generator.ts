import type { Entity, RelationshipEdge, EntityGroup } from '@/types/knowledge-graph';
import { KnowledgeGraphStorage } from './storage';
import { GraphEngine } from './graph-engine';

export class SummaryGenerator {
  static generateEntityGraphSummary(entityId: string): string {
    const entity = KnowledgeGraphStorage.getEntity(entityId);
    if (!entity) return 'Entity not found';
    
    const allEntities = KnowledgeGraphStorage.getEntities();
    const inboundEdges = GraphEngine.getInboundEdges(entityId);
    const outboundEdges = GraphEngine.getOutboundEdges(entityId);
    
    let summary = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    summary += `${entity.primaryEmoji || '🔷'} ${entity.name}\n`;
    summary += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    
    summary += `TYPE: ${entity.type}\n`;
    summary += `IMPORTANCE: ${entity.importanceLevel.toUpperCase()}\n`;
    summary += `CANONICAL: ${entity.canonical ? 'YES ⭐' : 'NO'}\n`;
    
    if (entity.externalRef) {
      summary += `EXTERNAL REF: ${entity.externalRef}\n`;
    }
    
    if (entity.chain) {
      summary += `CHAIN: ${entity.chain}\n`;
    }
    
    if (entity.sourceMiniApp) {
      summary += `SOURCE: ${entity.sourceMiniApp}\n`;
    }
    
    if (entity.tags.length > 0) {
      summary += `TAGS: ${entity.tags.join(', ')}\n`;
    }
    
    summary += `\nDESCRIPTION:\n${entity.description || 'No description'}\n`;
    
    if (entity.notes) {
      summary += `\nNOTES:\n${entity.notes}\n`;
    }
    
    // Outbound relationships
    if (outboundEdges.length > 0) {
      summary += `\n━━━ OUTGOING CONNECTIONS ━━━\n\n`;
      
      const groupedByKind = this.groupEdgesByKind(outboundEdges);
      
      for (const [kind, edges] of Object.entries(groupedByKind)) {
        summary += `${kind.toUpperCase()} →\n`;
        
        for (const edge of edges) {
          const targetEntity = allEntities.find((e: Entity) => e.id === edge.toEntityId);
          if (targetEntity) {
            const strengthMarker = this.getStrengthMarker(edge.strength);
            summary += `  ${strengthMarker} ${targetEntity.name} (${targetEntity.type})`;
            
            if (edge.context) {
              summary += ` [${edge.context}]`;
            }
            
            summary += `\n`;
            
            if (edge.description) {
              summary += `     "${edge.description}"\n`;
            }
          }
        }
        
        summary += `\n`;
      }
    }
    
    // Inbound relationships
    if (inboundEdges.length > 0) {
      summary += `━━━ INCOMING CONNECTIONS ━━━\n\n`;
      
      const groupedByKind = this.groupEdgesByKind(inboundEdges);
      
      for (const [kind, edges] of Object.entries(groupedByKind)) {
        summary += `${kind.toUpperCase()} ←\n`;
        
        for (const edge of edges) {
          const sourceEntity = allEntities.find((e: Entity) => e.id === edge.fromEntityId);
          if (sourceEntity) {
            const strengthMarker = this.getStrengthMarker(edge.strength);
            summary += `  ${strengthMarker} ${sourceEntity.name} (${sourceEntity.type})`;
            
            if (edge.context) {
              summary += ` [${edge.context}]`;
            }
            
            summary += `\n`;
            
            if (edge.description) {
              summary += `     "${edge.description}"\n`;
            }
          }
        }
        
        summary += `\n`;
      }
    }
    
    if (outboundEdges.length === 0 && inboundEdges.length === 0) {
      summary += `\n⚠️  No connections yet\n`;
    }
    
    summary += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    
    return summary;
  }
  
  static generateGroupSummary(groupId: string): string {
    const group = KnowledgeGraphStorage.getGroup(groupId);
    if (!group) return 'Group not found';
    
    const allEntities = KnowledgeGraphStorage.getEntities();
    const allRelationships = KnowledgeGraphStorage.getRelationships();
    
    let summary = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    summary += `📦 ${group.name}\n`;
    summary += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    
    summary += `DESCRIPTION:\n${group.description}\n\n`;
    
    if (group.tags.length > 0) {
      summary += `TAGS: ${group.tags.join(', ')}\n\n`;
    }
    
    summary += `━━━ MEMBERS (${group.entityIds.length}) ━━━\n\n`;
    
    const members = allEntities.filter((e: Entity) => group.entityIds.includes(e.id));
    
    for (const member of members) {
      const importanceMarker = this.getImportanceMarker(member.importanceLevel);
      const canonicalMarker = member.canonical ? '⭐' : '  ';
      summary += `${canonicalMarker} ${importanceMarker} ${member.primaryEmoji || '•'} ${member.name}\n`;
      summary += `   Type: ${member.type}\n`;
      
      if (member.description) {
        const shortDesc = member.description.substring(0, 80) + (member.description.length > 80 ? '...' : '');
        summary += `   ${shortDesc}\n`;
      }
      
      summary += `\n`;
    }
    
    // Find relationships between members
    const memberEdges = allRelationships.filter((edge: RelationshipEdge) => 
      group.entityIds.includes(edge.fromEntityId) && 
      group.entityIds.includes(edge.toEntityId)
    );
    
    if (memberEdges.length > 0) {
      summary += `━━━ INTERNAL CONNECTIONS (${memberEdges.length}) ━━━\n\n`;
      
      const highStrengthEdges = memberEdges.filter((e: RelationshipEdge) => 
        e.strength === 'strong' || e.strength === 'critical'
      );
      
      const edgesToShow = highStrengthEdges.length > 0 ? highStrengthEdges : memberEdges.slice(0, 10);
      
      for (const edge of edgesToShow) {
        const fromEntity = allEntities.find((e: Entity) => e.id === edge.fromEntityId);
        const toEntity = allEntities.find((e: Entity) => e.id === edge.toEntityId);
        
        if (fromEntity && toEntity) {
          const strengthMarker = this.getStrengthMarker(edge.strength);
          summary += `${strengthMarker} ${fromEntity.name} --[${edge.kind}]--> ${toEntity.name}\n`;
          
          if (edge.description) {
            summary += `   "${edge.description}"\n`;
          }
        }
      }
      
      if (memberEdges.length > edgesToShow.length) {
        summary += `\n   ... and ${memberEdges.length - edgesToShow.length} more connections\n`;
      }
    }
    
    summary += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    
    return summary;
  }
  
  static exportGraphOverview(): string {
    const allEntities = KnowledgeGraphStorage.getEntities();
    const allRelationships = KnowledgeGraphStorage.getRelationships();
    const allGroups = KnowledgeGraphStorage.getGroups();
    const allTemplates = KnowledgeGraphStorage.getPathTemplates();
    
    let overview = `╔════════════════════════════════════════════════════════════╗\n`;
    overview += `║         DREAMNET KNOWLEDGE GRAPH OVERVIEW v1.0             ║\n`;
    overview += `╚════════════════════════════════════════════════════════════╝\n\n`;
    
    overview += `Generated: ${new Date().toLocaleString()}\n\n`;
    
    // Stats
    overview += `━━━━━ STATISTICS ━━━━━\n\n`;
    overview += `Total Entities: ${allEntities.length}\n`;
    overview += `Total Relationships: ${allRelationships.length}\n`;
    overview += `Total Groups: ${allGroups.length}\n`;
    overview += `Total Path Templates: ${allTemplates.length}\n\n`;
    
    // Entities by type
    overview += `━━━━━ ENTITIES BY TYPE ━━━━━\n\n`;
    const entitiesByType: Record<string, number> = {};
    
    for (const entity of allEntities) {
      entitiesByType[entity.type] = (entitiesByType[entity.type] || 0) + 1;
    }
    
    const sortedTypes = Object.entries(entitiesByType).sort((a, b) => b[1] - a[1]);
    
    for (const [type, count] of sortedTypes) {
      overview += `${type.padEnd(20)} : ${count}\n`;
    }
    
    overview += `\n`;
    
    // Relationships by kind
    overview += `━━━━━ RELATIONSHIPS BY KIND ━━━━━\n\n`;
    const relationshipsByKind: Record<string, number> = {};
    
    for (const rel of allRelationships) {
      relationshipsByKind[rel.kind] = (relationshipsByKind[rel.kind] || 0) + 1;
    }
    
    const sortedKinds = Object.entries(relationshipsByKind).sort((a, b) => b[1] - a[1]);
    
    for (const [kind, count] of sortedKinds) {
      overview += `${kind.padEnd(20)} : ${count}\n`;
    }
    
    overview += `\n`;
    
    // Canonical entities
    const canonicalEntities = allEntities.filter((e: Entity) => e.canonical);
    
    if (canonicalEntities.length > 0) {
      overview += `━━━━━ CANONICAL ENTITIES (${canonicalEntities.length}) ━━━━━\n\n`;
      
      for (const entity of canonicalEntities) {
        overview += `⭐ ${entity.primaryEmoji || '•'} ${entity.name} (${entity.type})\n`;
        overview += `   Importance: ${entity.importanceLevel}\n`;
        
        if (entity.description) {
          const shortDesc = entity.description.substring(0, 80) + (entity.description.length > 80 ? '...' : '');
          overview += `   ${shortDesc}\n`;
        }
        
        overview += `\n`;
      }
    }
    
    // Critical entities
    const criticalEntities = allEntities.filter((e: Entity) => e.importanceLevel === 'critical');
    
    if (criticalEntities.length > 0 && criticalEntities.length !== canonicalEntities.length) {
      overview += `━━━━━ CRITICAL ENTITIES (${criticalEntities.length}) ━━━━━\n\n`;
      
      for (const entity of criticalEntities) {
        if (entity.canonical) continue; // Skip already listed
        overview += `🔴 ${entity.primaryEmoji || '•'} ${entity.name} (${entity.type})\n`;
      }
      
      overview += `\n`;
    }
    
    // Groups
    if (allGroups.length > 0) {
      overview += `━━━━━ ENTITY GROUPS (${allGroups.length}) ━━━━━\n\n`;
      
      for (const group of allGroups) {
        overview += `📦 ${group.name} (${group.entityIds.length} members)\n`;
        
        if (group.description) {
          const shortDesc = group.description.substring(0, 80) + (group.description.length > 80 ? '...' : '');
          overview += `   ${shortDesc}\n`;
        }
        
        overview += `\n`;
      }
    }
    
    // Path Templates
    if (allTemplates.length > 0) {
      overview += `━━━━━ PATH TEMPLATES (${allTemplates.length}) ━━━━━\n\n`;
      
      for (const template of allTemplates) {
        overview += `🛤️  ${template.name}\n`;
        overview += `   Path: ${template.nodeTypes.join(' → ')}\n`;
        overview += `   Relations: ${template.relationKinds.join(' → ')}\n\n`;
      }
    }
    
    overview += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    overview += `End of DreamNet Knowledge Graph Overview\n`;
    overview += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    
    return overview;
  }
  
  private static groupEdgesByKind(edges: RelationshipEdge[]): Record<string, RelationshipEdge[]> {
    const grouped: Record<string, RelationshipEdge[]> = {};
    
    for (const edge of edges) {
      if (!grouped[edge.kind]) {
        grouped[edge.kind] = [];
      }
      grouped[edge.kind].push(edge);
    }
    
    return grouped;
  }
  
  private static getStrengthMarker(strength: string): string {
    switch (strength) {
      case 'critical': return '🔴';
      case 'strong': return '🟠';
      case 'normal': return '🟡';
      case 'weak': return '⚪';
      default: return '•';
    }
  }
  
  private static getImportanceMarker(importance: string): string {
    switch (importance) {
      case 'critical': return '🔴';
      case 'high': return '🟠';
      case 'medium': return '🟡';
      case 'low': return '⚪';
      default: return '•';
    }
  }
}
