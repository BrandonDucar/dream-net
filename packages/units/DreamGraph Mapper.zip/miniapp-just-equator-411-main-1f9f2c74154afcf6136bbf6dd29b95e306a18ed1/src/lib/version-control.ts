// Version Control & History Service

import type { GraphSnapshot, ChangeLogEntry } from '@/types/knowledge-graph-extended';
import type { Entity, RelationshipEdge, EntityGroup, PathTemplate } from '@/types/knowledge-graph';
import { KnowledgeGraphStorage } from './storage';

const STORAGE_KEYS = {
  SNAPSHOTS: 'dreamnet_kg_snapshots',
  CHANGELOG: 'dreamnet_kg_changelog',
  AUTO_SNAPSHOT_ENABLED: 'dreamnet_kg_auto_snapshot',
} as const;

export class VersionControlService {
  // ============ SNAPSHOTS ============
  
  static createSnapshot(name: string, description: string = ''): GraphSnapshot {
    const snapshot: GraphSnapshot = {
      id: this.generateId(),
      timestamp: new Date().toISOString(),
      name,
      description,
      entities: KnowledgeGraphStorage.getEntities(),
      relationships: KnowledgeGraphStorage.getRelationships(),
      groups: KnowledgeGraphStorage.getGroups(),
      pathTemplates: KnowledgeGraphStorage.getPathTemplates(),
    };
    
    const snapshots = this.getSnapshots();
    snapshots.push(snapshot);
    this.saveSnapshots(snapshots);
    
    return snapshot;
  }
  
  static restoreSnapshot(snapshotId: string): boolean {
    const snapshot = this.getSnapshot(snapshotId);
    if (!snapshot) return false;
    
    // Save current state as backup before restore
    this.createSnapshot(`Before restore to ${snapshot.name}`, 'Auto-backup');
    
    // Restore all data
    KnowledgeGraphStorage.saveEntities(snapshot.entities);
    KnowledgeGraphStorage.saveRelationships(snapshot.relationships);
    KnowledgeGraphStorage.saveGroups(snapshot.groups);
    KnowledgeGraphStorage.savePathTemplates(snapshot.pathTemplates);
    
    this.logChange({
      action: 'update',
      entityType: 'entity',
      entityId: 'system',
      entityName: 'Graph State',
      changes: { snapshot: { old: 'current', new: snapshot.name } },
    });
    
    return true;
  }
  
  static getSnapshots(): GraphSnapshot[] {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.SNAPSHOTS);
    return data ? JSON.parse(data) : [];
  }
  
  static getSnapshot(id: string): GraphSnapshot | undefined {
    return this.getSnapshots().find((s: GraphSnapshot) => s.id === id);
  }
  
  static deleteSnapshot(id: string): void {
    const snapshots = this.getSnapshots().filter((s: GraphSnapshot) => s.id !== id);
    this.saveSnapshots(snapshots);
  }
  
  private static saveSnapshots(snapshots: GraphSnapshot[]): void {
    if (typeof window === 'undefined') return;
    // Keep only last 50 snapshots
    const limited = snapshots.slice(-50);
    localStorage.setItem(STORAGE_KEYS.SNAPSHOTS, JSON.stringify(limited));
  }
  
  // ============ CHANGE LOG ============
  
  static logChange(params: {
    action: 'create' | 'update' | 'delete';
    entityType: 'entity' | 'relationship' | 'group' | 'pathTemplate';
    entityId: string;
    entityName: string;
    changes: Record<string, { old: unknown; new: unknown }>;
    user?: string;
  }): void {
    const entry: ChangeLogEntry = {
      id: this.generateId(),
      timestamp: new Date().toISOString(),
      ...params,
    };
    
    const changelog = this.getChangeLog();
    changelog.push(entry);
    this.saveChangeLog(changelog);
    
    // Auto-snapshot on every 10 changes if enabled
    if (this.isAutoSnapshotEnabled() && changelog.length % 10 === 0) {
      this.createSnapshot(
        `Auto-snapshot ${changelog.length}`,
        'Automatic snapshot after 10 changes'
      );
    }
  }
  
  static getChangeLog(limit?: number): ChangeLogEntry[] {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.CHANGELOG);
    const log = data ? JSON.parse(data) : [];
    return limit ? log.slice(-limit) : log;
  }
  
  private static saveChangeLog(changelog: ChangeLogEntry[]): void {
    if (typeof window === 'undefined') return;
    // Keep only last 500 entries
    const limited = changelog.slice(-500);
    localStorage.setItem(STORAGE_KEYS.CHANGELOG, JSON.stringify(limited));
  }
  
  static clearChangeLog(): void {
    if (typeof window === 'undefined') return;
    localStorage.removeItem(STORAGE_KEYS.CHANGELOG);
  }
  
  // ============ AUTO-SNAPSHOT ============
  
  static setAutoSnapshotEnabled(enabled: boolean): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEYS.AUTO_SNAPSHOT_ENABLED, JSON.stringify(enabled));
  }
  
  static isAutoSnapshotEnabled(): boolean {
    if (typeof window === 'undefined') return false;
    const data = localStorage.getItem(STORAGE_KEYS.AUTO_SNAPSHOT_ENABLED);
    return data ? JSON.parse(data) : true;
  }
  
  // ============ GRAPH DIFFING ============
  
  static compareSnapshots(snapshot1Id: string, snapshot2Id: string): {
    entitiesAdded: Entity[];
    entitiesRemoved: Entity[];
    entitiesModified: Array<{ before: Entity; after: Entity }>;
    relationshipsAdded: RelationshipEdge[];
    relationshipsRemoved: RelationshipEdge[];
    relationshipsModified: Array<{ before: RelationshipEdge; after: RelationshipEdge }>;
  } {
    const s1 = this.getSnapshot(snapshot1Id);
    const s2 = this.getSnapshot(snapshot2Id);
    
    if (!s1 || !s2) {
      return {
        entitiesAdded: [],
        entitiesRemoved: [],
        entitiesModified: [],
        relationshipsAdded: [],
        relationshipsRemoved: [],
        relationshipsModified: [],
      };
    }
    
    const e1Map = new Map(s1.entities.map((e: Entity) => [e.id, e]));
    const e2Map = new Map(s2.entities.map((e: Entity) => [e.id, e]));
    
    const entitiesAdded = s2.entities.filter((e: Entity) => !e1Map.has(e.id));
    const entitiesRemoved = s1.entities.filter((e: Entity) => !e2Map.has(e.id));
    const entitiesModified = s2.entities
      .filter((e: Entity) => e1Map.has(e.id))
      .map((e: Entity) => ({ before: e1Map.get(e.id)!, after: e }))
      .filter(({ before, after }) => JSON.stringify(before) !== JSON.stringify(after));
    
    const r1Map = new Map(s1.relationships.map((r: RelationshipEdge) => [r.id, r]));
    const r2Map = new Map(s2.relationships.map((r: RelationshipEdge) => [r.id, r]));
    
    const relationshipsAdded = s2.relationships.filter((r: RelationshipEdge) => !r1Map.has(r.id));
    const relationshipsRemoved = s1.relationships.filter((r: RelationshipEdge) => !r2Map.has(r.id));
    const relationshipsModified = s2.relationships
      .filter((r: RelationshipEdge) => r1Map.has(r.id))
      .map((r: RelationshipEdge) => ({ before: r1Map.get(r.id)!, after: r }))
      .filter(({ before, after }) => JSON.stringify(before) !== JSON.stringify(after));
    
    return {
      entitiesAdded,
      entitiesRemoved,
      entitiesModified,
      relationshipsAdded,
      relationshipsRemoved,
      relationshipsModified,
    };
  }
  
  // ============ UTILITIES ============
  
  private static generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  }
}
