// Multi-Graph Workspace Manager

import type { Workspace } from '@/types/knowledge-graph-extended';
import { KnowledgeGraphStorage } from './storage';

const STORAGE_KEYS = {
  WORKSPACES: 'dreamnet_kg_workspaces',
  ACTIVE_WORKSPACE: 'dreamnet_kg_active_workspace',
  WORKSPACE_DATA_PREFIX: 'dreamnet_kg_workspace_',
} as const;

export class WorkspaceManager {
  // ============ WORKSPACE CRUD ============
  
  static createWorkspace(name: string, description: string, emoji?: string): Workspace {
    const workspace: Workspace = {
      id: this.generateId(),
      name,
      description,
      emoji,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      isActive: false,
    };
    
    const workspaces = this.getWorkspaces();
    workspaces.push(workspace);
    this.saveWorkspaces(workspaces);
    
    // Initialize empty data for this workspace
    this.saveWorkspaceData(workspace.id, {
      entities: [],
      relationships: [],
      groups: [],
      pathTemplates: [],
    });
    
    return workspace;
  }
  
  static updateWorkspace(id: string, updates: Partial<Workspace>): Workspace | undefined {
    const workspaces = this.getWorkspaces();
    const index = workspaces.findIndex((w: Workspace) => w.id === id);
    
    if (index === -1) return undefined;
    
    workspaces[index] = {
      ...workspaces[index],
      ...updates,
      id: workspaces[index].id,
      createdAt: workspaces[index].createdAt,
      updatedAt: new Date().toISOString(),
    };
    
    this.saveWorkspaces(workspaces);
    return workspaces[index];
  }
  
  static deleteWorkspace(id: string): boolean {
    // Don't delete if it's the active workspace
    if (this.getActiveWorkspaceId() === id) {
      return false;
    }
    
    const workspaces = this.getWorkspaces().filter((w: Workspace) => w.id !== id);
    this.saveWorkspaces(workspaces);
    
    // Delete workspace data
    if (typeof window !== 'undefined') {
      localStorage.removeItem(STORAGE_KEYS.WORKSPACE_DATA_PREFIX + id);
    }
    
    return true;
  }
  
  static getWorkspaces(): Workspace[] {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.WORKSPACES);
    const workspaces = data ? JSON.parse(data) : [];
    
    // Ensure at least one default workspace exists
    if (workspaces.length === 0) {
      const defaultWorkspace = this.createWorkspace(
        'DreamNet Core',
        'Main knowledge graph for DreamNet ecosystem',
        '🧠'
      );
      this.switchWorkspace(defaultWorkspace.id);
      return [defaultWorkspace];
    }
    
    return workspaces;
  }
  
  static getWorkspace(id: string): Workspace | undefined {
    return this.getWorkspaces().find((w: Workspace) => w.id === id);
  }
  
  private static saveWorkspaces(workspaces: Workspace[]): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEYS.WORKSPACES, JSON.stringify(workspaces));
  }
  
  // ============ WORKSPACE SWITCHING ============
  
  static switchWorkspace(workspaceId: string): boolean {
    const workspace = this.getWorkspace(workspaceId);
    if (!workspace) return false;
    
    // Save current workspace data
    const currentId = this.getActiveWorkspaceId();
    if (currentId) {
      this.saveWorkspaceData(currentId, {
        entities: KnowledgeGraphStorage.getEntities(),
        relationships: KnowledgeGraphStorage.getRelationships(),
        groups: KnowledgeGraphStorage.getGroups(),
        pathTemplates: KnowledgeGraphStorage.getPathTemplates(),
      });
      
      // Mark as inactive
      this.updateWorkspace(currentId, { isActive: false });
    }
    
    // Load new workspace data
    const data = this.getWorkspaceData(workspaceId);
    KnowledgeGraphStorage.saveEntities(data.entities);
    KnowledgeGraphStorage.saveRelationships(data.relationships);
    KnowledgeGraphStorage.saveGroups(data.groups);
    KnowledgeGraphStorage.savePathTemplates(data.pathTemplates);
    
    // Mark as active
    this.updateWorkspace(workspaceId, { isActive: true });
    
    // Set as active workspace
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_WORKSPACE, workspaceId);
    }
    
    return true;
  }
  
  static getActiveWorkspaceId(): string | null {
    if (typeof window === 'undefined') return null;
    return localStorage.getItem(STORAGE_KEYS.ACTIVE_WORKSPACE);
  }
  
  static getActiveWorkspace(): Workspace | undefined {
    const id = this.getActiveWorkspaceId();
    return id ? this.getWorkspace(id) : undefined;
  }
  
  // ============ WORKSPACE DATA ============
  
  private static saveWorkspaceData(workspaceId: string, data: {
    entities: unknown[];
    relationships: unknown[];
    groups: unknown[];
    pathTemplates: unknown[];
  }): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem(
      STORAGE_KEYS.WORKSPACE_DATA_PREFIX + workspaceId,
      JSON.stringify(data)
    );
  }
  
  private static getWorkspaceData(workspaceId: string): {
    entities: unknown[];
    relationships: unknown[];
    groups: unknown[];
    pathTemplates: unknown[];
  } {
    if (typeof window === 'undefined') {
      return { entities: [], relationships: [], groups: [], pathTemplates: [] };
    }
    
    const data = localStorage.getItem(STORAGE_KEYS.WORKSPACE_DATA_PREFIX + workspaceId);
    return data ? JSON.parse(data) : { entities: [], relationships: [], groups: [], pathTemplates: [] };
  }
  
  // ============ WORKSPACE MERGE ============
  
  static mergeWorkspaces(sourceId: string, targetId: string, options: {
    includeEntities: boolean;
    includeRelationships: boolean;
    includeGroups: boolean;
    includePathTemplates: boolean;
  }): boolean {
    const source = this.getWorkspaceData(sourceId);
    const target = this.getWorkspaceData(targetId);
    
    if (!source || !target) return false;
    
    const merged = {
      entities: options.includeEntities ? [...target.entities, ...source.entities] : target.entities,
      relationships: options.includeRelationships ? [...target.relationships, ...source.relationships] : target.relationships,
      groups: options.includeGroups ? [...target.groups, ...source.groups] : target.groups,
      pathTemplates: options.includePathTemplates ? [...target.pathTemplates, ...source.pathTemplates] : target.pathTemplates,
    };
    
    this.saveWorkspaceData(targetId, merged);
    return true;
  }
  
  // ============ UTILITIES ============
  
  private static generateId(): string {
    return `ws-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  }
}
