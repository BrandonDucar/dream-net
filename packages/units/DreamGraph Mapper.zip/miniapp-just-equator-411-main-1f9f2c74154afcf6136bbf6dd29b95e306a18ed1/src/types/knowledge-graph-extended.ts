// Extended types for advanced knowledge graph features

import type { Entity, RelationshipEdge, EntityGroup, PathTemplate } from './knowledge-graph';

// ============ VERSION CONTROL & HISTORY ============

export interface GraphSnapshot {
  id: string;
  timestamp: string;
  name: string;
  description: string;
  entities: Entity[];
  relationships: RelationshipEdge[];
  groups: EntityGroup[];
  pathTemplates: PathTemplate[];
}

export interface ChangeLogEntry {
  id: string;
  timestamp: string;
  action: 'create' | 'update' | 'delete';
  entityType: 'entity' | 'relationship' | 'group' | 'pathTemplate';
  entityId: string;
  entityName: string;
  changes: Record<string, { old: unknown; new: unknown }>;
  user?: string;
}

// ============ MULTI-GRAPH WORKSPACES ============

export interface Workspace {
  id: string;
  name: string;
  description: string;
  emoji?: string;
  createdAt: string;
  updatedAt: string;
  isActive: boolean;
}

// ============ ENTITY TEMPLATES ============

export interface EntityTemplate {
  id: string;
  name: string;
  description: string;
  entityType: string;
  defaultFields: {
    importanceLevel?: string;
    tags?: string[];
    primaryEmoji?: string;
  };
  fieldPrompts: Record<string, string>;
  createdAt: string;
}

// ============ CONSTRAINT RULES ============

export interface ConstraintRule {
  id: string;
  name: string;
  description: string;
  ruleType: 'required-connection' | 'forbidden-connection' | 'min-connections' | 'max-connections' | 'field-required';
  entityTypes: string[];
  config: {
    relationKind?: string;
    minCount?: number;
    maxCount?: number;
    requiredFields?: string[];
    targetEntityType?: string;
  };
  severity: 'error' | 'warning' | 'info';
  enabled: boolean;
  createdAt: string;
}

export interface ConstraintViolation {
  ruleId: string;
  ruleName: string;
  severity: 'error' | 'warning' | 'info';
  entityId: string;
  entityName: string;
  message: string;
}

// ============ GRAPH METRICS ============

export interface EntityMetrics {
  entityId: string;
  inDegree: number;
  outDegree: number;
  totalDegree: number;
  betweennessCentrality: number;
  pageRank: number;
  clusteringCoefficient: number;
  completeness: number; // % of fields filled
  connectedness: number; // quality of connections
  healthScore: number; // overall health (0-100)
}

export interface GraphMetrics {
  totalEntities: number;
  totalRelationships: number;
  averageDegree: number;
  networkDensity: number;
  connectedComponents: number;
  averagePathLength: number;
  clusteringCoefficient: number;
  entitiesByType: Record<string, number>;
  relationshipsByKind: Record<string, number>;
  topCentralEntities: Array<{ entityId: string; name: string; score: number }>;
}

// ============ SAVED VIEWS & FILTERS ============

export interface SavedView {
  id: string;
  name: string;
  description: string;
  filters: {
    entityTypes?: string[];
    importanceLevels?: string[];
    canonical?: boolean;
    tags?: string[];
    searchText?: string;
    relationKinds?: string[];
    context?: string;
  };
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  isPinned: boolean;
  createdAt: string;
}

// ============ CUSTOM QUERIES & REPORTS ============

export interface CustomQuery {
  id: string;
  name: string;
  description: string;
  query: {
    startEntityType?: string;
    relationshipChain?: Array<{ kind: string; direction: 'forward' | 'backward' | 'any' }>;
    endEntityType?: string;
    filters?: Record<string, unknown>;
  };
  savedResults?: {
    timestamp: string;
    results: unknown[];
  };
  createdAt: string;
}

// ============ PATTERN DETECTION ============

export interface DetectedPattern {
  id: string;
  patternType: 'common-subgraph' | 'circular-dependency' | 'isolated-entity' | 'hub-entity' | 'cluster';
  name: string;
  description: string;
  entityIds: string[];
  edgeIds: string[];
  occurrences: number;
  significance: number; // 0-1
}

// ============ SMART SUGGESTIONS ============

export interface Suggestion {
  id: string;
  type: 'missing-relationship' | 'duplicate-entity' | 'tag-suggestion' | 'completion-prompt' | 'pattern-match';
  priority: 'low' | 'medium' | 'high';
  entityId: string;
  message: string;
  action?: {
    type: string;
    params: Record<string, unknown>;
  };
  dismissed: boolean;
  createdAt: string;
}

// ============ DOMAIN-SPECIFIC DATA ============

export interface TokenData {
  contractAddress?: string;
  tokenSymbol?: string;
  decimals?: number;
  totalSupply?: string;
  priceUSD?: number;
  marketCap?: string;
  holders?: number;
  lastUpdated?: string;
}

export interface CampaignMetrics {
  reach?: number;
  impressions?: number;
  engagement?: number;
  conversions?: number;
  cost?: number;
  roi?: number;
  startDate?: string;
  endDate?: string;
}

export interface SocialAccountMetrics {
  followers?: number;
  posts?: number;
  engagement?: number;
  lastActive?: string;
}

// ============ BATCH OPERATIONS ============

export interface BatchOperation {
  id: string;
  type: 'update-tags' | 'update-importance' | 'delete-entities' | 'create-relationships' | 'assign-to-group';
  entityIds: string[];
  params: Record<string, unknown>;
  status: 'pending' | 'running' | 'completed' | 'failed';
  createdAt: string;
  completedAt?: string;
  results?: {
    success: number;
    failed: number;
    errors?: string[];
  };
}

// ============ IMPORT/EXPORT ============

export interface ExportFormat {
  format: 'json' | 'csv' | 'graphml' | 'cypher' | 'markdown';
  includeEntities: boolean;
  includeRelationships: boolean;
  includeGroups: boolean;
  includePathTemplates: boolean;
  filters?: Record<string, unknown>;
}

export interface ImportResult {
  success: boolean;
  entitiesCreated: number;
  relationshipsCreated: number;
  groupsCreated: number;
  errors: string[];
  warnings: string[];
}

// ============ GRAPH VISUALIZATION ============

export interface LayoutConfig {
  algorithm: 'force' | 'hierarchical' | 'circular' | 'grid' | 'radial';
  nodeSize: 'uniform' | 'by-degree' | 'by-importance';
  nodeColor: 'by-type' | 'by-importance' | 'by-canonical' | 'by-context';
  edgeThickness: 'uniform' | 'by-strength';
  showLabels: boolean;
  animate: boolean;
}

export interface GraphViewState {
  zoom: number;
  center: { x: number; y: number };
  selectedNodeIds: string[];
  selectedEdgeIds: string[];
  highlightedPathIds: string[];
  filters: {
    entityTypes: string[];
    relationKinds: string[];
    context?: string;
  };
  layout: LayoutConfig;
}

// ============ PATH OPERATIONS ============

export interface PathResult {
  paths: Array<{
    entityIds: string[];
    edgeIds: string[];
    length: number;
    totalStrength: number;
  }>;
  summary: {
    shortestPath: number;
    longestPath: number;
    averageLength: number;
    totalPaths: number;
  };
}

// ============ RELATIONSHIP INFERENCE ============

export interface InferredRelationship {
  fromEntityId: string;
  toEntityId: string;
  kind: string;
  reason: string;
  confidence: number; // 0-1
  sourceEdgeIds: string[]; // edges that led to this inference
}
