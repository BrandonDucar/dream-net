export type EntityType =
  | "token"
  | "culture-coin"
  | "wallet"
  | "mini-app"
  | "agent"
  | "backend-model"
  | "backend-endpoint"
  | "drop"
  | "campaign"
  | "content-stream"
  | "social-account"
  | "segment"
  | "audience"
  | "pickleball"
  | "infra"
  | "other";

export type ImportanceLevel = "low" | "medium" | "high" | "critical";
export type RelationshipStrength = "weak" | "normal" | "strong" | "critical";
export type RelationshipDirection = "forward" | "bidirectional";

export interface GeoTarget {
  id: string;
  region: string;
  country?: string;
  cityOrMarket?: string;
  language: string;
}

export interface Entity {
  id: string;
  type: EntityType;
  name: string;
  slug: string;
  description: string;
  primaryEmoji?: string;
  importanceLevel: ImportanceLevel;
  canonical: boolean;
  sourceMiniApp?: string;
  externalRef?: string;
  chain?: string;
  tags: string[];
  notes: string;
  
  // SEO fields
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
  
  // Geo targeting
  primaryGeoTargets: GeoTarget[];
  entityIntroLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
  
  createdAt: string;
  updatedAt: string;
}

export interface RelationshipEdge {
  id: string;
  fromEntityId: string;
  toEntityId: string;
  kind: string;
  direction: RelationshipDirection;
  description: string;
  strength: RelationshipStrength;
  context: string;
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface EntityGroup {
  id: string;
  name: string;
  description: string;
  entityIds: string[];
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface PathTemplate {
  id: string;
  name: string;
  description: string;
  nodeTypes: string[];
  relationKinds: string[];
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface PathMatch {
  entityIds: string[];
  edgeIds: string[];
}

export interface CreateEntityInput {
  type: EntityType;
  name: string;
  slug?: string;
  description?: string;
  primaryEmoji?: string;
  importanceLevel?: ImportanceLevel;
  sourceMiniApp?: string;
  externalRef?: string;
  chain?: string;
  tags?: string[];
}

export interface UpdateEntityInput extends Partial<Omit<Entity, 'id' | 'createdAt' | 'updatedAt'>> {
  id: string;
}

export interface CreateRelationshipInput {
  fromEntityId: string;
  toEntityId: string;
  kind: string;
  direction?: RelationshipDirection;
  description: string;
  strength?: RelationshipStrength;
  context?: string;
  tags?: string[];
}

export interface UpdateRelationshipInput extends Partial<Omit<RelationshipEdge, 'id' | 'createdAt' | 'updatedAt'>> {
  id: string;
}

export interface CreateEntityGroupInput {
  name: string;
  description: string;
  entityIds?: string[];
  tags?: string[];
}

export interface UpdateEntityGroupInput extends Partial<Omit<EntityGroup, 'id' | 'createdAt' | 'updatedAt'>> {
  id: string;
}

export interface CreatePathTemplateInput {
  name: string;
  description: string;
  nodeTypes: string[];
  relationKinds: string[];
  tags?: string[];
}

export interface UpdatePathTemplateInput extends Partial<Omit<PathTemplate, 'id' | 'createdAt' | 'updatedAt'>> {
  id: string;
}

export interface EntityFilter {
  type?: EntityType;
  importanceLevel?: ImportanceLevel;
  canonical?: boolean;
  searchText?: string;
}

export interface NeighborOptions {
  depth: 1 | 2;
  relationKinds?: string[];
  context?: string;
}

export interface NeighborResult {
  entities: Entity[];
  edges: RelationshipEdge[];
}
