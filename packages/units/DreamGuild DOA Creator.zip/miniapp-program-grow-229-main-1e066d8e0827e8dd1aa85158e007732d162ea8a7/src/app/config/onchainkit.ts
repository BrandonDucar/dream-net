export const ONCHAINKIT_API_KEY = 'vqhG9Y6b2lzApzB70x6DZHWVFPTXf0Jn';
export const ONCHAINKIT_PROJECT_ID = 'a26dc6e9-3ad2-4c0a-a4b3-07a1c7ca8f51';
