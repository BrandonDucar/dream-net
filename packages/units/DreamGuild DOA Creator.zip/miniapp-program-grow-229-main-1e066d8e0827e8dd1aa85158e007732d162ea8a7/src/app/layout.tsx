import type { Metadata } from 'next';
import '@coinbase/onchainkit/styles.css';
import './globals.css';
import { Providers } from './providers';
import { PrivyWrapper } from '@/lib/privy/provider';
import FarcasterWrapper from "@/components/FarcasterWrapper";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
        <html lang="en">
          <body>
            <PrivyWrapper>
              <Providers>
      <FarcasterWrapper>
        {children}
      </FarcasterWrapper>
      </Providers>
            </PrivyWrapper>
          </body>
        </html>
      );
}

export const metadata: Metadata = {
        title: "MicroGuild Creator",
        description: "Instantly create 2-5 member DAOs with minimal governance. Share voting, goals, and perks via NFTs. Like a group chat with a bank account on Base.",
        other: { "fc:frame": JSON.stringify({"version":"next","imageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_65cdadbf-77d5-487c-b26b-93cd59222f1f-qFoL4Mh5JZ82LeNhWWnnQPq7xZyhou","button":{"title":"Open with Ohara","action":{"type":"launch_frame","name":"MicroGuild Creator","url":"https://program-grow-229.app.ohara.ai","splashImageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/farcaster/splash_images/splash_image1.svg","splashBackgroundColor":"#ffffff"}}}
        ) }
    };
