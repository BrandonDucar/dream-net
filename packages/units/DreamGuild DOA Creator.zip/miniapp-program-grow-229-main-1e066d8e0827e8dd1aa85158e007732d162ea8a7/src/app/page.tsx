'use client'
import { usePrivy } from '@privy-io/react-auth';
import { useAccount } from 'wagmi';
import { CreateGuildModal } from '@/components/create-guild-modal';
import { GuildDashboard } from '@/components/guild-dashboard';
import { GuildList } from '@/components/guild-list';
import { Button } from '@/components/ui/button';
import { useState, useEffect } from 'react';
import { Users, Sparkles, Coins, TrendingUp } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function MicroGuildsPage() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const { ready, authenticated, login } = usePrivy();
  const { address, status } = useAccount();
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [selectedGuild, setSelectedGuild] = useState<string | null>(null);
  const [userGuilds, setUserGuilds] = useState<Array<{
    id: string;
    name: string;
    members: number;
    treasury: string;
    nftAddress: string;
  }>>([]);

  useEffect(() => {
    if (authenticated && address) {
      const storedGuilds = localStorage.getItem(`guilds_${address}`);
      if (storedGuilds) {
        setUserGuilds(JSON.parse(storedGuilds));
      }
    }
  }, [authenticated, address]);

  const handleGuildCreated = (guild: { id: string; name: string; members: number; treasury: string; nftAddress: string }) => {
    const updatedGuilds = [...userGuilds, guild];
    setUserGuilds(updatedGuilds);
    if (address) {
      localStorage.setItem(`guilds_${address}`, JSON.stringify(updatedGuilds));
    }
    setShowCreateModal(false);
    setSelectedGuild(guild.id);
  };

  if (!ready) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading MicroGuilds...</p>
        </div>
      </div>
    );
  }

  if (!authenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <div className="container mx-auto px-4 py-12 md:py-20">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12 pt-8">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-600 rounded-2xl mb-6 shadow-lg">
                <Users className="w-10 h-10 text-white" />
              </div>
              <h1 className="text-5xl md:text-6xl font-bold text-black mb-4">
                MicroGuilds
              </h1>
              <p className="text-xl md:text-2xl text-gray-700 mb-2">
                Tiny DAOs for 2-5 people
              </p>
              <p className="text-lg text-gray-600">
                Group chats with a bank account on Base
              </p>
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 md:p-12 mb-12">
              <div className="grid md:grid-cols-2 gap-8 mb-10">
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    <Sparkles className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-black mb-2">One-Click Creation</h3>
                    <p className="text-gray-600">Create your MicroGuild NFT instantly. No governance overhead.</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                    <Coins className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-black mb-2">Shared Mini-Vault</h3>
                    <p className="text-gray-600">Pool funds together. Simple treasury management.</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-black mb-2">Shared Goals & Boosts</h3>
                    <p className="text-gray-600">Track onchain goals. Unlock perks together.</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                    <Users className="w-6 h-6 text-orange-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-black mb-2">Simple Voting</h3>
                    <p className="text-gray-600">Vote on proposals. Optional revenue splits.</p>
                  </div>
                </div>
              </div>

              <div className="text-center">
                <Button 
                  onClick={login} 
                  size="lg" 
                  className="bg-blue-600 hover:bg-blue-700 text-white px-12 py-6 text-lg rounded-full shadow-lg"
                >
                  Connect Wallet to Start
                </Button>
                <p className="text-sm text-gray-500 mt-4">
                  Built on Base • Powered by OnchainKit
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (status === 'connecting' || status === 'reconnecting') {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Connecting wallet...</p>
        </div>
      </div>
    );
  }

  if (selectedGuild) {
    const guild = userGuilds.find((g: { id: string }) => g.id === selectedGuild);
    if (guild) {
      return (
        <GuildDashboard 
          guild={guild} 
          onBack={() => setSelectedGuild(null)} 
          userAddress={address || ''}
        />
      );
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto pt-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
            <div>
              <h1 className="text-4xl font-bold text-black mb-2">Your MicroGuilds</h1>
              <p className="text-gray-600">
                {address ? `${address.slice(0, 6)}...${address.slice(-4)}` : 'Wallet Connected'}
              </p>
            </div>
            <Button 
              onClick={() => setShowCreateModal(true)}
              size="lg"
              className="bg-blue-600 hover:bg-blue-700 text-white rounded-full shadow-lg"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Create MicroGuild
            </Button>
          </div>

          {userGuilds.length === 0 ? (
            <div className="bg-white rounded-3xl shadow-xl p-12 text-center">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gray-100 rounded-2xl mb-6">
                <Users className="w-10 h-10 text-gray-400" />
              </div>
              <h2 className="text-2xl font-bold text-black mb-3">No MicroGuilds Yet</h2>
              <p className="text-gray-600 mb-8 max-w-md mx-auto">
                Create your first MicroGuild to start collaborating with your crew onchain.
              </p>
              <Button 
                onClick={() => setShowCreateModal(true)}
                size="lg"
                className="bg-blue-600 hover:bg-blue-700 text-white rounded-full"
              >
                <Sparkles className="w-5 h-5 mr-2" />
                Create Your First Guild
              </Button>
            </div>
          ) : (
            <GuildList 
              guilds={userGuilds} 
              onSelectGuild={setSelectedGuild}
            />
          )}
        </div>
      </div>

      {showCreateModal && (
        <CreateGuildModal 
          onClose={() => setShowCreateModal(false)}
          onGuildCreated={handleGuildCreated}
          userAddress={address || ''}
        />
      )}
    </div>
  );
}
