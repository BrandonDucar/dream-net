'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Activity, Users, Wallet, Vote, Target, Zap } from 'lucide-react';

interface ActivityItem {
  id: string;
  type: 'member_joined' | 'deposit' | 'send' | 'vote' | 'goal_completed' | 'boost_activated';
  user: string;
  description: string;
  timestamp: string;
  amount?: string;
}

interface ActivityFeedProps {
  guildId: string;
}

export function ActivityFeed({ guildId }: ActivityFeedProps) {
  const activities: ActivityItem[] = [
    {
      id: '1',
      type: 'boost_activated',
      user: '0x1234...5678',
      description: 'activated 2x Voting Power boost',
      timestamp: '2 hours ago',
    },
    {
      id: '2',
      type: 'vote',
      user: '0xabcd...ef01',
      description: 'voted Yes on "Increase treasury target"',
      timestamp: '5 hours ago',
    },
    {
      id: '3',
      type: 'deposit',
      user: '0x9876...5432',
      description: 'deposited to treasury',
      timestamp: '1 day ago',
      amount: '0.5 ETH',
    },
    {
      id: '4',
      type: 'goal_completed',
      user: 'Guild',
      description: 'completed goal: Reach 5 ETH treasury',
      timestamp: '2 days ago',
    },
    {
      id: '5',
      type: 'member_joined',
      user: '0xdef0...1234',
      description: 'joined the guild',
      timestamp: '3 days ago',
    },
    {
      id: '6',
      type: 'send',
      user: '0x5678...9abc',
      description: 'sent from treasury',
      timestamp: '4 days ago',
      amount: '0.2 ETH',
    },
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case 'member_joined':
        return <Users className="w-5 h-5 text-blue-600" />;
      case 'deposit':
        return <Wallet className="w-5 h-5 text-green-600" />;
      case 'send':
        return <Wallet className="w-5 h-5 text-blue-600" />;
      case 'vote':
        return <Vote className="w-5 h-5 text-purple-600" />;
      case 'goal_completed':
        return <Target className="w-5 h-5 text-orange-600" />;
      case 'boost_activated':
        return <Zap className="w-5 h-5 text-yellow-600" />;
      default:
        return <Activity className="w-5 h-5 text-gray-600" />;
    }
  };

  const getIconBg = (type: string) => {
    switch (type) {
      case 'member_joined':
        return 'bg-blue-100';
      case 'deposit':
        return 'bg-green-100';
      case 'send':
        return 'bg-blue-100';
      case 'vote':
        return 'bg-purple-100';
      case 'goal_completed':
        return 'bg-orange-100';
      case 'boost_activated':
        return 'bg-yellow-100';
      default:
        return 'bg-gray-100';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold text-black mb-1">Activity Feed</h3>
        <p className="text-gray-600">Recent guild activity</p>
      </div>

      <Card className="border-gray-200 rounded-2xl">
        <CardContent className="p-6">
          <div className="space-y-4">
            {activities.map((activity: ActivityItem, index: number) => (
              <div
                key={activity.id}
                className={`flex items-start gap-4 pb-4 ${
                  index < activities.length - 1 ? 'border-b border-gray-100' : ''
                }`}
              >
                <div className={`flex-shrink-0 w-10 h-10 ${getIconBg(activity.type)} rounded-xl flex items-center justify-center`}>
                  {getIcon(activity.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-black">
                    <span className="font-semibold">{activity.user}</span>{' '}
                    <span className="text-gray-700">{activity.description}</span>
                  </p>
                  {activity.amount && (
                    <p className="text-sm font-semibold text-blue-600 mt-1">{activity.amount}</p>
                  )}
                  <p className="text-sm text-gray-500 mt-1">{activity.timestamp}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
