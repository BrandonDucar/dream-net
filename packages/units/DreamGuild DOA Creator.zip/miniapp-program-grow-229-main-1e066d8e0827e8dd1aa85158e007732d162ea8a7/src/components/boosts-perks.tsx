'use client';

import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Zap, Gift, Lock, CheckCircle } from 'lucide-react';

interface Boost {
  id: string;
  name: string;
  description: string;
  cost: string;
  active: boolean;
  locked: boolean;
  requirement?: string;
}

interface BoostsPerksProps {
  type: 'boosts' | 'perks';
  guildId: string;
}

export function BoostsPerks({ type, guildId }: BoostsPerksProps) {
  const boosts: Boost[] = [
    {
      id: '1',
      name: '2x Voting Power',
      description: 'Double your voting weight on proposals',
      cost: '0.1 ETH',
      active: false,
      locked: false,
    },
    {
      id: '2',
      name: 'Fast Transactions',
      description: 'Priority processing for all guild transactions',
      cost: '0.2 ETH',
      active: true,
      locked: false,
    },
    {
      id: '3',
      name: 'Premium Badge',
      description: 'Unlock exclusive guild badge and perks',
      cost: '0.5 ETH',
      active: false,
      locked: true,
      requirement: 'Reach 10 ETH treasury',
    },
  ];

  const perks: Boost[] = [
    {
      id: '1',
      name: 'Gas Fee Discount',
      description: '20% off all transaction gas fees',
      cost: 'Free',
      active: true,
      locked: false,
    },
    {
      id: '2',
      name: 'Early Access',
      description: 'First access to new MicroGuilds features',
      cost: 'Free',
      active: true,
      locked: false,
    },
    {
      id: '3',
      name: 'Revenue Share',
      description: '5% revenue share from guild earnings',
      cost: 'Free',
      active: false,
      locked: true,
      requirement: 'Complete 100 transactions',
    },
  ];

  const items = type === 'boosts' ? boosts : perks;
  const Icon = type === 'boosts' ? Zap : Gift;
  const title = type === 'boosts' ? 'Boosts' : 'Perks';
  const subtitle = type === 'boosts' ? 'Power up your guild' : 'Unlock rewards';

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold text-black mb-1">{title}</h3>
        <p className="text-gray-600">{subtitle}</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {items.map((item: Boost) => (
          <Card
            key={item.id}
            className={`border-gray-200 rounded-2xl ${
              item.active ? 'bg-gradient-to-br from-blue-50 to-purple-50' : ''
            } ${item.locked ? 'opacity-60' : ''}`}
          >
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                        item.active
                          ? 'bg-blue-500'
                          : item.locked
                          ? 'bg-gray-300'
                          : 'bg-blue-100'
                      }`}
                    >
                      {item.locked ? (
                        <Lock className="w-5 h-5 text-white" />
                      ) : item.active ? (
                        <CheckCircle className="w-5 h-5 text-white" />
                      ) : (
                        <Icon className={`w-5 h-5 ${item.active ? 'text-white' : 'text-blue-600'}`} />
                      )}
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-black">{item.name}</h4>
                      {item.active && (
                        <span className="text-xs text-green-600 font-semibold">Active</span>
                      )}
                      {item.locked && (
                        <span className="text-xs text-gray-500 font-semibold">Locked</span>
                      )}
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{item.description}</p>
                </div>
              </div>

              {item.locked && item.requirement && (
                <div className="mb-4 p-3 bg-gray-100 rounded-xl">
                  <p className="text-xs text-gray-600">
                    <Lock className="w-3 h-3 inline mr-1" />
                    <span className="font-semibold">Requirement:</span> {item.requirement}
                  </p>
                </div>
              )}

              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-black">{item.cost}</span>
                {!item.locked && !item.active && (
                  <Button
                    size="sm"
                    className="bg-blue-600 hover:bg-blue-700 text-white rounded-full"
                  >
                    Activate
                  </Button>
                )}
                {item.active && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-red-200 text-red-600 hover:bg-red-50 rounded-full"
                  >
                    Deactivate
                  </Button>
                )}
                {item.locked && (
                  <Button
                    size="sm"
                    disabled
                    className="bg-gray-200 text-gray-500 rounded-full cursor-not-allowed"
                  >
                    Locked
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
