'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { X, Users, Sparkles } from 'lucide-react';
import { usePrivy } from '@privy-io/react-auth';

interface CreateGuildModalProps {
  onClose: () => void;
  onGuildCreated: (guild: {
    id: string;
    name: string;
    members: number;
    treasury: string;
    nftAddress: string;
  }) => void;
  userAddress: string;
}

export function CreateGuildModal({ onClose, onGuildCreated, userAddress }: CreateGuildModalProps) {
  const { sendTransaction } = usePrivy();
  const [guildName, setGuildName] = useState<string>('');
  const [memberAddresses, setMemberAddresses] = useState<string>('');
  const [isCreating, setIsCreating] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const handleCreate = async () => {
    if (!guildName.trim()) {
      setError('Please enter a guild name');
      return;
    }

    const addresses = memberAddresses
      .split(',')
      .map((addr: string) => addr.trim())
      .filter((addr: string) => addr.length > 0);

    if (addresses.length < 1 || addresses.length > 4) {
      setError('Please add 1-4 member addresses (you are automatically included)');
      return;
    }

    const totalMembers = addresses.length + 1;
    if (totalMembers < 2 || totalMembers > 5) {
      setError('MicroGuilds must have 2-5 members total');
      return;
    }

    setIsCreating(true);
    setError('');

    try {
      const mockNftAddress = `0x${Math.random().toString(16).substring(2, 42).padEnd(40, '0')}`;
      
      const newGuild = {
        id: `guild_${Date.now()}_${Math.random().toString(36).substring(7)}`,
        name: guildName,
        members: totalMembers,
        treasury: '0.0',
        nftAddress: mockNftAddress,
      };

      await new Promise((resolve: (value: unknown) => void) => setTimeout(resolve, 2000));

      onGuildCreated(newGuild);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to create MicroGuild';
      setError(errorMessage);
      setIsCreating(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 relative">
        <button
          onClick={onClose}
          className="absolute top-6 right-6 text-gray-400 hover:text-gray-600 transition-colors"
          disabled={isCreating}
        >
          <X className="w-6 h-6" />
        </button>

        <div className="mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-2xl mb-4">
            <Sparkles className="w-8 h-8 text-blue-600" />
          </div>
          <h2 className="text-3xl font-bold text-black mb-2">Create MicroGuild</h2>
          <p className="text-gray-600">Launch your tiny DAO in seconds</p>
        </div>

        <div className="space-y-6">
          <div>
            <Label htmlFor="guildName" className="text-black font-medium mb-2 block">
              Guild Name
            </Label>
            <Input
              id="guildName"
              type="text"
              placeholder="e.g., Builder Squad"
              value={guildName}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setGuildName(e.target.value)}
              className="border-gray-200 focus:border-blue-600 focus:ring-blue-600"
              disabled={isCreating}
            />
          </div>

          <div>
            <Label htmlFor="members" className="text-black font-medium mb-2 block">
              Member Addresses
            </Label>
            <Input
              id="members"
              type="text"
              placeholder="0x123..., 0x456..."
              value={memberAddresses}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setMemberAddresses(e.target.value)}
              className="border-gray-200 focus:border-blue-600 focus:ring-blue-600"
              disabled={isCreating}
            />
            <p className="text-sm text-gray-500 mt-2">
              <Users className="w-4 h-4 inline mr-1" />
              Add 1-4 addresses (comma separated). You&apos;re included automatically.
            </p>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm">
              {error}
            </div>
          )}

          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
            <h4 className="font-semibold text-black mb-2">What you get:</h4>
            <ul className="space-y-1 text-sm text-gray-700">
              <li>✨ MicroGuild NFT minted</li>
              <li>💰 Shared mini-vault</li>
              <li>🗳️ Simple voting system</li>
              <li>📊 Activity feed</li>
              <li>🎯 Onchain goals tracker</li>
            </ul>
          </div>

          <Button
            onClick={handleCreate}
            disabled={isCreating}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-6 rounded-full text-lg font-semibold shadow-lg"
          >
            {isCreating ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                Creating MicroGuild...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 mr-2" />
                Create MicroGuild
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
