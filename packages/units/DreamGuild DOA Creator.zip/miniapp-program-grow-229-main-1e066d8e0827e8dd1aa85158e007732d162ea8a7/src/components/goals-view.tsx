'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Target, Plus, Trophy, TrendingUp } from 'lucide-react';

interface Goal {
  id: string;
  title: string;
  target: number;
  current: number;
  unit: string;
  completed: boolean;
  reward: string;
}

interface GoalsViewProps {
  guildId: string;
}

export function GoalsView({ guildId }: GoalsViewProps) {
  const [goals, setGoals] = useState<Goal[]>([
    {
      id: '1',
      title: 'Reach 10 ETH Treasury',
      target: 10,
      current: 6.5,
      unit: 'ETH',
      completed: false,
      reward: 'Unlock Premium Boost',
    },
    {
      id: '2',
      title: 'Complete 50 Transactions',
      target: 50,
      current: 32,
      unit: 'txns',
      completed: false,
      reward: 'Gas Fee Discount',
    },
    {
      id: '3',
      title: 'Reach 5 Active Members',
      target: 5,
      current: 5,
      unit: 'members',
      completed: true,
      reward: 'Guild Badge NFT',
    },
  ]);
  const [showCreateForm, setShowCreateForm] = useState<boolean>(false);
  const [newGoalTitle, setNewGoalTitle] = useState<string>('');
  const [newGoalTarget, setNewGoalTarget] = useState<string>('');
  const [newGoalReward, setNewGoalReward] = useState<string>('');

  const handleCreateGoal = () => {
    if (!newGoalTitle.trim() || !newGoalTarget || !newGoalReward.trim()) return;

    const newGoal: Goal = {
      id: `${Date.now()}`,
      title: newGoalTitle,
      target: parseFloat(newGoalTarget),
      current: 0,
      unit: 'ETH',
      completed: false,
      reward: newGoalReward,
    };

    setGoals([...goals, newGoal]);
    setNewGoalTitle('');
    setNewGoalTarget('');
    setNewGoalReward('');
    setShowCreateForm(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold text-black mb-1">Onchain Goals</h3>
          <p className="text-gray-600">Track your guild&apos;s progress</p>
        </div>
        <Button
          onClick={() => setShowCreateForm(!showCreateForm)}
          className="bg-blue-600 hover:bg-blue-700 text-white rounded-full"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Goal
        </Button>
      </div>

      {showCreateForm && (
        <Card className="border-gray-200 rounded-2xl">
          <CardHeader>
            <CardTitle className="text-black text-lg">Create Goal</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="goalTitle" className="text-black font-medium mb-2 block">
                Goal Title
              </Label>
              <Input
                id="goalTitle"
                type="text"
                placeholder="e.g., Reach 20 ETH Treasury"
                value={newGoalTitle}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewGoalTitle(e.target.value)}
                className="border-gray-200"
              />
            </div>
            <div>
              <Label htmlFor="goalTarget" className="text-black font-medium mb-2 block">
                Target Value
              </Label>
              <Input
                id="goalTarget"
                type="number"
                step="0.1"
                placeholder="20"
                value={newGoalTarget}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewGoalTarget(e.target.value)}
                className="border-gray-200"
              />
            </div>
            <div>
              <Label htmlFor="goalReward" className="text-black font-medium mb-2 block">
                Reward
              </Label>
              <Input
                id="goalReward"
                type="text"
                placeholder="e.g., Unlock Elite Boost"
                value={newGoalReward}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewGoalReward(e.target.value)}
                className="border-gray-200"
              />
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleCreateGoal}
                disabled={!newGoalTitle.trim() || !newGoalTarget || !newGoalReward.trim()}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white rounded-full"
              >
                Create Goal
              </Button>
              <Button
                onClick={() => {
                  setShowCreateForm(false);
                  setNewGoalTitle('');
                  setNewGoalTarget('');
                  setNewGoalReward('');
                }}
                variant="outline"
                className="rounded-full"
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 md:grid-cols-2">
        {goals.map((goal: Goal) => (
          <Card
            key={goal.id}
            className={`border-gray-200 rounded-2xl ${
              goal.completed ? 'bg-gradient-to-br from-green-50 to-emerald-50' : ''
            }`}
          >
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h4 className="text-lg font-bold text-black">{goal.title}</h4>
                    {goal.completed && (
                      <Trophy className="w-5 h-5 text-green-600" />
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mb-3">
                    <span className="font-semibold">Reward:</span> {goal.reward}
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600">Progress</span>
                  <span className="font-semibold text-black">
                    {goal.current} / {goal.target} {goal.unit}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                  <div
                    className={`h-full transition-all duration-500 ${
                      goal.completed ? 'bg-green-500' : 'bg-blue-600'
                    }`}
                    style={{
                      width: `${Math.min((goal.current / goal.target) * 100, 100)}%`,
                    }}
                  ></div>
                </div>
                <p className="text-xs text-gray-500 text-right">
                  {Math.round((goal.current / goal.target) * 100)}% complete
                </p>
              </div>

              {goal.completed && (
                <div className="mt-4 p-3 bg-green-100 rounded-xl text-center">
                  <p className="text-sm font-semibold text-green-700">
                    🎉 Goal Completed!
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
