'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, Wallet, Vote, Activity, Target, Zap, Gift, Send } from 'lucide-react';
import { TreasuryView } from '@/components/treasury-view';
import { VotingView } from '@/components/voting-view';
import { ActivityFeed } from '@/components/activity-feed';
import { GoalsView } from '@/components/goals-view';
import { BoostsPerks } from '@/components/boosts-perks';

interface Guild {
  id: string;
  name: string;
  members: number;
  treasury: string;
  nftAddress: string;
}

interface GuildDashboardProps {
  guild: Guild;
  onBack: () => void;
  userAddress: string;
}

export function GuildDashboard({ guild, onBack, userAddress }: GuildDashboardProps) {
  const [activeTab, setActiveTab] = useState<string>('treasury');

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto pt-8">
          <div className="mb-6">
            <Button
              onClick={onBack}
              variant="ghost"
              className="text-gray-600 hover:text-black mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Guilds
            </Button>

            <div className="bg-white rounded-3xl shadow-xl p-8">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                <div>
                  <h1 className="text-4xl font-bold text-black mb-2">{guild.name}</h1>
                  <p className="text-gray-600">
                    {guild.members} members • {guild.treasury} ETH treasury
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    NFT: {guild.nftAddress.slice(0, 6)}...{guild.nftAddress.slice(-4)}
                  </p>
                </div>
              </div>

              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-3 md:grid-cols-6 mb-8 bg-gray-100 p-1 rounded-full">
                  <TabsTrigger value="treasury" className="rounded-full data-[state=active]:bg-white">
                    <Wallet className="w-4 h-4 mr-2" />
                    <span className="hidden sm:inline">Treasury</span>
                  </TabsTrigger>
                  <TabsTrigger value="voting" className="rounded-full data-[state=active]:bg-white">
                    <Vote className="w-4 h-4 mr-2" />
                    <span className="hidden sm:inline">Voting</span>
                  </TabsTrigger>
                  <TabsTrigger value="activity" className="rounded-full data-[state=active]:bg-white">
                    <Activity className="w-4 h-4 mr-2" />
                    <span className="hidden sm:inline">Activity</span>
                  </TabsTrigger>
                  <TabsTrigger value="goals" className="rounded-full data-[state=active]:bg-white">
                    <Target className="w-4 h-4 mr-2" />
                    <span className="hidden sm:inline">Goals</span>
                  </TabsTrigger>
                  <TabsTrigger value="boosts" className="rounded-full data-[state=active]:bg-white">
                    <Zap className="w-4 h-4 mr-2" />
                    <span className="hidden sm:inline">Boosts</span>
                  </TabsTrigger>
                  <TabsTrigger value="perks" className="rounded-full data-[state=active]:bg-white">
                    <Gift className="w-4 h-4 mr-2" />
                    <span className="hidden sm:inline">Perks</span>
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="treasury">
                  <TreasuryView guildId={guild.id} currentTreasury={guild.treasury} />
                </TabsContent>

                <TabsContent value="voting">
                  <VotingView guildId={guild.id} userAddress={userAddress} />
                </TabsContent>

                <TabsContent value="activity">
                  <ActivityFeed guildId={guild.id} />
                </TabsContent>

                <TabsContent value="goals">
                  <GoalsView guildId={guild.id} />
                </TabsContent>

                <TabsContent value="boosts">
                  <BoostsPerks type="boosts" guildId={guild.id} />
                </TabsContent>

                <TabsContent value="perks">
                  <BoostsPerks type="perks" guildId={guild.id} />
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
