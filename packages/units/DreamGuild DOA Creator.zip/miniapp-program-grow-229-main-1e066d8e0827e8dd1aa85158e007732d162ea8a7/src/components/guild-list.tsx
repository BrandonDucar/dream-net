'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Users, Wallet, ArrowRight } from 'lucide-react';

interface Guild {
  id: string;
  name: string;
  members: number;
  treasury: string;
  nftAddress: string;
}

interface GuildListProps {
  guilds: Guild[];
  onSelectGuild: (guildId: string) => void;
}

export function GuildList({ guilds, onSelectGuild }: GuildListProps) {
  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {guilds.map((guild: Guild) => (
        <Card key={guild.id} className="border-gray-200 hover:shadow-lg transition-shadow bg-white rounded-2xl overflow-hidden">
          <CardContent className="p-6">
            <div className="mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl mb-3 flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-black mb-1">{guild.name}</h3>
              <p className="text-sm text-gray-500">
                NFT: {guild.nftAddress.slice(0, 6)}...{guild.nftAddress.slice(-4)}
              </p>
            </div>

            <div className="space-y-3 mb-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600 flex items-center">
                  <Users className="w-4 h-4 mr-2" />
                  Members
                </span>
                <span className="font-semibold text-black">{guild.members}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600 flex items-center">
                  <Wallet className="w-4 h-4 mr-2" />
                  Treasury
                </span>
                <span className="font-semibold text-black">{guild.treasury} ETH</span>
              </div>
            </div>

            <Button
              onClick={() => onSelectGuild(guild.id)}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-full"
            >
              Open Guild
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
