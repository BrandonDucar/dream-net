'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Wallet, Send, Plus, TrendingUp, ArrowDownToLine } from 'lucide-react';
import { usePrivy } from '@privy-io/react-auth';
import { parseEther } from 'viem';

interface TreasuryViewProps {
  guildId: string;
  currentTreasury: string;
}

export function TreasuryView({ guildId, currentTreasury }: TreasuryViewProps) {
  const { sendTransaction } = usePrivy();
  const [amount, setAmount] = useState<string>('');
  const [recipient, setRecipient] = useState<string>('');
  const [isDepositing, setIsDepositing] = useState<boolean>(false);
  const [isSending, setIsSending] = useState<boolean>(false);
  const [showSendForm, setShowSendForm] = useState<boolean>(false);

  const handleDeposit = async () => {
    if (!amount || parseFloat(amount) <= 0) return;

    setIsDepositing(true);
    try {
      await new Promise((resolve: (value: unknown) => void) => setTimeout(resolve, 2000));
      setAmount('');
    } catch (error) {
      console.error('Deposit failed:', error);
    } finally {
      setIsDepositing(false);
    }
  };

  const handleSend = async () => {
    if (!recipient || !amount || parseFloat(amount) <= 0) return;

    setIsSending(true);
    try {
      await new Promise((resolve: (value: unknown) => void) => setTimeout(resolve, 2000));
      setRecipient('');
      setAmount('');
      setShowSendForm(false);
    } catch (error) {
      console.error('Send failed:', error);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="border-gray-200 bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl">
        <CardHeader>
          <CardTitle className="flex items-center text-black">
            <Wallet className="w-5 h-5 mr-2 text-blue-600" />
            Mini-Vault Balance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-5xl font-bold text-black mb-2">{currentTreasury} ETH</p>
            <p className="text-gray-600">≈ ${(parseFloat(currentTreasury) * 2500).toFixed(2)} USD</p>
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="border-gray-200 rounded-2xl">
          <CardHeader>
            <CardTitle className="flex items-center text-black text-lg">
              <Plus className="w-5 h-5 mr-2 text-green-600" />
              Deposit Funds
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="depositAmount" className="text-black font-medium mb-2 block">
                Amount (ETH)
              </Label>
              <Input
                id="depositAmount"
                type="number"
                step="0.001"
                placeholder="0.1"
                value={amount}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAmount(e.target.value)}
                className="border-gray-200"
                disabled={isDepositing}
              />
            </div>
            <Button
              onClick={handleDeposit}
              disabled={isDepositing || !amount || parseFloat(amount) <= 0}
              className="w-full bg-green-600 hover:bg-green-700 text-white rounded-full"
            >
              {isDepositing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Depositing...
                </>
              ) : (
                <>
                  <ArrowDownToLine className="w-4 h-4 mr-2" />
                  Deposit to Vault
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card className="border-gray-200 rounded-2xl">
          <CardHeader>
            <CardTitle className="flex items-center text-black text-lg">
              <Send className="w-5 h-5 mr-2 text-blue-600" />
              Send Funds
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!showSendForm ? (
              <Button
                onClick={() => setShowSendForm(true)}
                variant="outline"
                className="w-full border-blue-200 text-blue-600 hover:bg-blue-50 rounded-full"
              >
                <Send className="w-4 h-4 mr-2" />
                Send from Vault
              </Button>
            ) : (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="recipient" className="text-black font-medium mb-2 block">
                    Recipient Address
                  </Label>
                  <Input
                    id="recipient"
                    type="text"
                    placeholder="0x..."
                    value={recipient}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setRecipient(e.target.value)}
                    className="border-gray-200"
                    disabled={isSending}
                  />
                </div>
                <div>
                  <Label htmlFor="sendAmount" className="text-black font-medium mb-2 block">
                    Amount (ETH)
                  </Label>
                  <Input
                    id="sendAmount"
                    type="number"
                    step="0.001"
                    placeholder="0.05"
                    value={amount}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAmount(e.target.value)}
                    className="border-gray-200"
                    disabled={isSending}
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={handleSend}
                    disabled={isSending || !recipient || !amount || parseFloat(amount) <= 0}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white rounded-full"
                  >
                    {isSending ? 'Sending...' : 'Send'}
                  </Button>
                  <Button
                    onClick={() => {
                      setShowSendForm(false);
                      setRecipient('');
                      setAmount('');
                    }}
                    variant="outline"
                    disabled={isSending}
                    className="rounded-full"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="border-gray-200 rounded-2xl">
        <CardHeader>
          <CardTitle className="flex items-center text-black text-lg">
            <TrendingUp className="w-5 h-5 mr-2 text-purple-600" />
            Recent Transactions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <Plus className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="font-medium text-black">Deposit</p>
                  <p className="text-sm text-gray-600">0x1234...5678</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-semibold text-green-600">+0.5 ETH</p>
                <p className="text-sm text-gray-500">2 hours ago</p>
              </div>
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <Send className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium text-black">Send</p>
                  <p className="text-sm text-gray-600">0xabcd...ef01</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-semibold text-blue-600">-0.2 ETH</p>
                <p className="text-sm text-gray-500">1 day ago</p>
              </div>
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <Plus className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="font-medium text-black">Deposit</p>
                  <p className="text-sm text-gray-600">0x9876...5432</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-semibold text-green-600">+1.0 ETH</p>
                <p className="text-sm text-gray-500">3 days ago</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
