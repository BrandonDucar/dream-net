'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Vote, ThumbsUp, ThumbsDown, Plus, Clock } from 'lucide-react';

interface Proposal {
  id: string;
  title: string;
  description: string;
  yesVotes: number;
  noVotes: number;
  totalVotes: number;
  status: 'active' | 'passed' | 'rejected';
  endsIn: string;
  userVoted: boolean;
}

interface VotingViewProps {
  guildId: string;
  userAddress: string;
}

export function VotingView({ guildId, userAddress }: VotingViewProps) {
  const [proposals, setProposals] = useState<Proposal[]>([
    {
      id: '1',
      title: 'Increase treasury target to 10 ETH',
      description: 'We should increase our treasury target to support bigger projects',
      yesVotes: 3,
      noVotes: 1,
      totalVotes: 4,
      status: 'active',
      endsIn: '2 days',
      userVoted: false,
    },
    {
      id: '2',
      title: 'Split 50% revenue with contributors',
      description: 'Proposal to share half of guild revenue with active contributors',
      yesVotes: 4,
      noVotes: 0,
      totalVotes: 4,
      status: 'passed',
      endsIn: 'Ended',
      userVoted: true,
    },
  ]);
  const [showCreateForm, setShowCreateForm] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState<string>('');
  const [newDescription, setNewDescription] = useState<string>('');

  const handleVote = (proposalId: string, vote: 'yes' | 'no') => {
    setProposals(proposals.map((p: Proposal) => {
      if (p.id === proposalId && !p.userVoted) {
        return {
          ...p,
          yesVotes: vote === 'yes' ? p.yesVotes + 1 : p.yesVotes,
          noVotes: vote === 'no' ? p.noVotes + 1 : p.noVotes,
          totalVotes: p.totalVotes + 1,
          userVoted: true,
        };
      }
      return p;
    }));
  };

  const handleCreateProposal = () => {
    if (!newTitle.trim() || !newDescription.trim()) return;

    const newProposal: Proposal = {
      id: `${Date.now()}`,
      title: newTitle,
      description: newDescription,
      yesVotes: 0,
      noVotes: 0,
      totalVotes: 0,
      status: 'active',
      endsIn: '7 days',
      userVoted: false,
    };

    setProposals([newProposal, ...proposals]);
    setNewTitle('');
    setNewDescription('');
    setShowCreateForm(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold text-black mb-1">Active Proposals</h3>
          <p className="text-gray-600">Simple voting for your guild</p>
        </div>
        <Button
          onClick={() => setShowCreateForm(!showCreateForm)}
          className="bg-blue-600 hover:bg-blue-700 text-white rounded-full"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Proposal
        </Button>
      </div>

      {showCreateForm && (
        <Card className="border-gray-200 rounded-2xl">
          <CardHeader>
            <CardTitle className="text-black text-lg">Create Proposal</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="proposalTitle" className="text-black font-medium mb-2 block">
                Title
              </Label>
              <Input
                id="proposalTitle"
                type="text"
                placeholder="Proposal title..."
                value={newTitle}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewTitle(e.target.value)}
                className="border-gray-200"
              />
            </div>
            <div>
              <Label htmlFor="proposalDescription" className="text-black font-medium mb-2 block">
                Description
              </Label>
              <Textarea
                id="proposalDescription"
                placeholder="Describe your proposal..."
                value={newDescription}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNewDescription(e.target.value)}
                className="border-gray-200 min-h-[100px]"
              />
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleCreateProposal}
                disabled={!newTitle.trim() || !newDescription.trim()}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white rounded-full"
              >
                Create Proposal
              </Button>
              <Button
                onClick={() => {
                  setShowCreateForm(false);
                  setNewTitle('');
                  setNewDescription('');
                }}
                variant="outline"
                className="rounded-full"
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-4">
        {proposals.map((proposal: Proposal) => (
          <Card key={proposal.id} className="border-gray-200 rounded-2xl">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h4 className="text-lg font-bold text-black">{proposal.title}</h4>
                    {proposal.status === 'passed' && (
                      <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded-full">
                        Passed
                      </span>
                    )}
                    {proposal.status === 'rejected' && (
                      <span className="px-3 py-1 bg-red-100 text-red-700 text-xs font-semibold rounded-full">
                        Rejected
                      </span>
                    )}
                    {proposal.status === 'active' && (
                      <span className="px-3 py-1 bg-blue-100 text-blue-700 text-xs font-semibold rounded-full">
                        Active
                      </span>
                    )}
                  </div>
                  <p className="text-gray-600 mb-3">{proposal.description}</p>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <span className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      {proposal.endsIn}
                    </span>
                    <span>{proposal.totalVotes} votes</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-gray-100 rounded-full h-8 overflow-hidden">
                    <div
                      className="bg-green-500 h-full transition-all duration-300"
                      style={{
                        width: `${proposal.totalVotes > 0 ? (proposal.yesVotes / proposal.totalVotes) * 100 : 0}%`,
                      }}
                    ></div>
                  </div>
                  <span className="text-sm font-semibold text-black w-16 text-right">
                    {proposal.yesVotes} Yes
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-gray-100 rounded-full h-8 overflow-hidden">
                    <div
                      className="bg-red-500 h-full transition-all duration-300"
                      style={{
                        width: `${proposal.totalVotes > 0 ? (proposal.noVotes / proposal.totalVotes) * 100 : 0}%`,
                      }}
                    ></div>
                  </div>
                  <span className="text-sm font-semibold text-black w-16 text-right">
                    {proposal.noVotes} No
                  </span>
                </div>
              </div>

              {proposal.status === 'active' && !proposal.userVoted && (
                <div className="flex gap-3 mt-4">
                  <Button
                    onClick={() => handleVote(proposal.id, 'yes')}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white rounded-full"
                  >
                    <ThumbsUp className="w-4 h-4 mr-2" />
                    Vote Yes
                  </Button>
                  <Button
                    onClick={() => handleVote(proposal.id, 'no')}
                    className="flex-1 bg-red-600 hover:bg-red-700 text-white rounded-full"
                  >
                    <ThumbsDown className="w-4 h-4 mr-2" />
                    Vote No
                  </Button>
                </div>
              )}

              {proposal.userVoted && (
                <div className="mt-4 text-center">
                  <p className="text-sm text-gray-600">You have voted on this proposal</p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
