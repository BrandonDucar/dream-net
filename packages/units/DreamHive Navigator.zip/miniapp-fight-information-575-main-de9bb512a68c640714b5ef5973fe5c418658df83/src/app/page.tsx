'use client'
import { useState, useEffect } from 'react';
import { SearchPanel } from '@/components/search-panel';
import { HoneycombMap } from '@/components/honeycomb-map';
import { NodeDetail } from '@/components/node-detail';
import { HiveScorePanel } from '@/components/hive-score-panel';
import type { NetworkData, NetworkNode } from '@/types/network';
import { openaiChatCompletion } from '@/openai-api';
import { Hexagon } from 'lucide-react';
import { toast } from 'sonner';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Page() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [networkData, setNetworkData] = useState<NetworkData | null>(null);
  const [selectedNode, setSelectedNode] = useState<NetworkNode | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const analyzeNetwork = async (concept: string): Promise<void> => {
    setIsLoading(true);
    setSelectedNode(null);

    try {
      const response = await openaiChatCompletion({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: `You are an expert network analyst for DreamHive Navigator. Analyze influence networks and identify opportunities, threats, and strategic insights. Generate a comprehensive network of 8-12 related nodes.

For each concept, identify:
- Related concepts, people, projects, or ideas
- Connection strength (0-100)
- Whether each is an opportunity (green), threat (red), or neutral
- Key insights and strategic value

Respond ONLY with valid JSON matching this exact structure:
{
  "nodes": [
    {
      "id": "unique-id",
      "label": "Short Label",
      "type": "opportunity|threat|neutral",
      "description": "Detailed description of this node",
      "connectionStrength": 85,
      "insights": ["Insight 1", "Insight 2", "Insight 3"]
    }
  ],
  "hiveScore": {
    "overall": 75,
    "viralPotential": 80,
    "profitability": 70,
    "strategicValue": 75,
    "reasoning": "Brief explanation of the scores"
  }
}`
          },
          {
            role: 'user',
            content: `Analyze the influence network for: "${concept}". Generate 8-12 related nodes with detailed insights. Focus on crypto, tech, and cultural trends where relevant.`
          }
        ]
      });

      const content = response.choices[0]?.message?.content;
      if (!content) throw new Error('No response from AI');

      const parsed = JSON.parse(content);

      const networkData: NetworkData = {
        centerNode: {
          id: 'center',
          label: concept,
          type: 'center',
          description: `Core concept: ${concept}`,
          connectionStrength: 100,
          insights: []
        },
        nodes: parsed.nodes,
        connections: parsed.nodes.map((node: NetworkNode) => ({
          source: 'center',
          target: node.id,
          strength: node.connectionStrength
        })),
        hiveScore: parsed.hiveScore,
        generatedAt: new Date().toISOString()
      };

      setNetworkData(networkData);
      toast.success('Network analysis complete!');
    } catch (error) {
      console.error('Analysis error:', error);
      toast.error('Failed to analyze network. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleNodeClick = (node: NetworkNode): void => {
    setSelectedNode(node);
  };

  return (
    <main className="min-h-screen bg-black text-white p-4 md:p-6">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <div className="relative">
            <Hexagon className="w-8 h-8 text-yellow-500 fill-yellow-500/20" />
            <Hexagon className="w-8 h-8 text-yellow-500 absolute inset-0 animate-pulse" />
          </div>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-yellow-500 to-orange-500 bg-clip-text text-transparent">
              DreamHive Navigator
            </h1>
            <p className="text-sm text-gray-400">
              Explore hidden influence networks • DHIVE
            </p>
          </div>
        </div>
      </div>

      {/* Search Panel */}
      <div className="mb-6">
        <SearchPanel onSearch={analyzeNetwork} isLoading={isLoading} />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Honeycomb Map - Takes up 2 columns on large screens */}
        <div className="lg:col-span-2 min-h-[600px]">
          <HoneycombMap
            data={networkData}
            onNodeClick={handleNodeClick}
            selectedNodeId={selectedNode?.id || null}
          />
        </div>

        {/* Right Sidebar */}
        <div className="space-y-6">
          {/* Hive Score */}
          <HiveScorePanel score={networkData?.hiveScore || null} />

          {/* Node Detail */}
          <NodeDetail node={selectedNode} />
        </div>
      </div>

      {/* Footer */}
      <div className="mt-8 text-center text-xs text-gray-600">
        <p>DreamHive Navigator • Powered by AI • Built on Base</p>
      </div>
    </main>
  );
}
