'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import type { HiveScore } from '@/types/network';
import { Sparkles, TrendingUp, DollarSign, Target } from 'lucide-react';

interface HiveScorePanelProps {
  score: HiveScore | null;
}

export function HiveScorePanel({ score }: HiveScorePanelProps) {
  if (!score) {
    return (
      <Card className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border-yellow-500/30">
        <CardContent className="p-6 text-center">
          <Sparkles className="w-12 h-12 text-yellow-500/30 mx-auto mb-3" />
          <p className="text-gray-400 text-sm">
            Hive Score will appear here after analysis
          </p>
        </CardContent>
      </Card>
    );
  }

  const getScoreColor = (value: number): string => {
    if (value >= 70) return 'bg-green-500';
    if (value >= 40) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getScoreLabel = (value: number): string => {
    if (value >= 80) return 'Exceptional';
    if (value >= 60) return 'Strong';
    if (value >= 40) return 'Moderate';
    if (value >= 20) return 'Weak';
    return 'Low';
  };

  return (
    <Card className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border-yellow-500/30">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-yellow-500">
          <Sparkles className="w-5 h-5" />
          Hive Score
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Overall Score */}
        <div className="text-center p-4 bg-black/30 rounded-lg border border-yellow-500/20">
          <div className="text-5xl font-bold text-yellow-500 mb-1">
            {score.overall}
          </div>
          <div className="text-sm text-gray-400">
            {getScoreLabel(score.overall)} Potential
          </div>
        </div>

        {/* Individual Metrics */}
        <div className="space-y-3">
          {/* Viral Potential */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-green-500" />
                <span className="text-sm text-gray-300">Viral Potential</span>
              </div>
              <span className="text-sm font-semibold text-white">{score.viralPotential}%</span>
            </div>
            <Progress
              value={score.viralPotential}
              className="h-2"
              indicatorClassName={getScoreColor(score.viralPotential)}
            />
          </div>

          {/* Profitability */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-yellow-500" />
                <span className="text-sm text-gray-300">Profitability</span>
              </div>
              <span className="text-sm font-semibold text-white">{score.profitability}%</span>
            </div>
            <Progress
              value={score.profitability}
              className="h-2"
              indicatorClassName={getScoreColor(score.profitability)}
            />
          </div>

          {/* Strategic Value */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-blue-500" />
                <span className="text-sm text-gray-300">Strategic Value</span>
              </div>
              <span className="text-sm font-semibold text-white">{score.strategicValue}%</span>
            </div>
            <Progress
              value={score.strategicValue}
              className="h-2"
              indicatorClassName={getScoreColor(score.strategicValue)}
            />
          </div>
        </div>

        {/* Reasoning */}
        <div className="pt-3 border-t border-yellow-500/20">
          <h4 className="text-sm font-semibold text-gray-300 mb-2">AI Analysis</h4>
          <p className="text-xs text-gray-400 leading-relaxed">{score.reasoning}</p>
        </div>
      </CardContent>
    </Card>
  );
}
