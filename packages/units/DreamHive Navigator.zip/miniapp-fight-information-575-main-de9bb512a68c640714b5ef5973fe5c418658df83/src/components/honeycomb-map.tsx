'use client';

import { useEffect, useState, useRef } from 'react';
import type { NetworkData, NetworkNode, NetworkConnection } from '@/types/network';
import {
  calculateHoneycombPositions,
  getHexagonPath,
  getNodeColor,
  getConnectionOpacity
} from '@/utils/honeycomb';
import { Card } from '@/components/ui/card';

interface HoneycombMapProps {
  data: NetworkData | null;
  onNodeClick: (node: NetworkNode) => void;
  selectedNodeId: string | null;
}

export function HoneycombMap({ data, onNodeClick, selectedNodeId }: HoneycombMapProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [dimensions, setDimensions] = useState<{ width: number; height: number }>({ width: 800, height: 600 });

  useEffect(() => {
    const updateDimensions = () => {
      if (svgRef.current) {
        const parent = svgRef.current.parentElement;
        if (parent) {
          setDimensions({
            width: parent.clientWidth,
            height: Math.max(600, parent.clientHeight)
          });
        }
      }
    };

    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);

  if (!data) {
    return (
      <Card className="w-full h-full bg-black border-gray-800 flex items-center justify-center min-h-[600px]">
        <div className="text-center">
          <div className="w-24 h-24 mx-auto mb-4 relative">
            <div className="absolute inset-0 border-4 border-yellow-500/20 rounded-full" />
            <div className="absolute inset-2 border-4 border-yellow-500/40 rounded-full" />
            <div className="absolute inset-4 border-4 border-yellow-500/60 rounded-full animate-ping" />
          </div>
          <p className="text-gray-400">
            Enter a concept to visualize its influence network
          </p>
        </div>
      </Card>
    );
  }

  const allNodes = [data.centerNode, ...data.nodes];
  const hexSize = Math.min(60, dimensions.width / 15);
  const centerX = dimensions.width / 2;
  const centerY = dimensions.height / 2;

  const positions = calculateHoneycombPositions(allNodes.length, hexSize, centerX, centerY);

  // Assign positions to nodes
  const nodesWithPositions = allNodes.map((node: NetworkNode, index: number) => ({
    ...node,
    position: positions[index]
  }));

  return (
    <Card className="w-full h-full bg-black border-gray-800 overflow-hidden">
      <svg
        ref={svgRef}
        width={dimensions.width}
        height={dimensions.height}
        className="w-full h-full"
      >
        <defs>
          {/* Glow filters for each node type */}
          <filter id="glow-opportunity" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="4" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <filter id="glow-threat" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="4" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <filter id="glow-center" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="6" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Draw connections */}
        <g className="connections">
          {data.connections.map((conn: NetworkConnection, index: number) => {
            const sourceNode = nodesWithPositions.find((n: NetworkNode) => n.id === conn.source);
            const targetNode = nodesWithPositions.find((n: NetworkNode) => n.id === conn.target);

            if (!sourceNode?.position || !targetNode?.position) return null;

            const opacity = getConnectionOpacity(conn.strength);
            const strokeWidth = Math.max(1, conn.strength / 25);

            return (
              <line
                key={`conn-${index}`}
                x1={sourceNode.position.x}
                y1={sourceNode.position.y}
                x2={targetNode.position.x}
                y2={targetNode.position.y}
                stroke="#fbbf24"
                strokeWidth={strokeWidth}
                opacity={opacity}
                strokeLinecap="round"
              />
            );
          })}
        </g>

        {/* Draw nodes */}
        <g className="nodes">
          {nodesWithPositions.map((node: NetworkNode) => {
            if (!node.position) return null;

            const colors = getNodeColor(node.type);
            const isSelected = node.id === selectedNodeId;
            const scale = node.type === 'center' ? 1.2 : 1;
            const size = hexSize * scale;

            return (
              <g
                key={node.id}
                onClick={() => onNodeClick(node)}
                className="cursor-pointer transition-transform hover:scale-110"
                style={{ transformOrigin: `${node.position.x}px ${node.position.y}px` }}
              >
                {/* Hexagon */}
                <path
                  d={getHexagonPath(node.position.x, node.position.y, size)}
                  fill={colors.fill}
                  stroke={isSelected ? '#fbbf24' : colors.stroke}
                  strokeWidth={isSelected ? 3 : 2}
                  filter={
                    node.type === 'opportunity'
                      ? 'url(#glow-opportunity)'
                      : node.type === 'threat'
                      ? 'url(#glow-threat)'
                      : node.type === 'center'
                      ? 'url(#glow-center)'
                      : undefined
                  }
                />

                {/* Label */}
                <text
                  x={node.position.x}
                  y={node.position.y}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fill="white"
                  fontSize={node.type === 'center' ? 14 : 11}
                  fontWeight={node.type === 'center' ? 'bold' : 'normal'}
                  className="pointer-events-none select-none"
                >
                  {node.label.length > 12 ? `${node.label.slice(0, 12)}...` : node.label}
                </text>

                {/* Connection strength indicator */}
                {node.type !== 'center' && (
                  <text
                    x={node.position.x}
                    y={node.position.y + size + 15}
                    textAnchor="middle"
                    fill="#fbbf24"
                    fontSize={9}
                    className="pointer-events-none select-none"
                  >
                    {node.connectionStrength}%
                  </text>
                )}
              </g>
            );
          })}
        </g>
      </svg>
    </Card>
  );
}
