'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { NetworkNode } from '@/types/network';
import { AlertCircle, TrendingUp, Activity } from 'lucide-react';

interface NodeDetailProps {
  node: NetworkNode | null;
}

export function NodeDetail({ node }: NodeDetailProps) {
  if (!node) {
    return (
      <Card className="bg-gray-900 border-gray-800">
        <CardContent className="p-6 text-center">
          <Activity className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <p className="text-gray-400 text-sm">
            Click on a node to view detailed insights
          </p>
        </CardContent>
      </Card>
    );
  }

  const typeConfig = {
    opportunity: { icon: TrendingUp, color: 'text-green-500', label: 'Opportunity' },
    threat: { icon: AlertCircle, color: 'text-red-500', label: 'Threat' },
    neutral: { icon: Activity, color: 'text-gray-500', label: 'Neutral' },
    center: { icon: Activity, color: 'text-blue-500', label: 'Core Concept' }
  };

  const config = typeConfig[node.type];
  const Icon = config.icon;

  return (
    <Card className="bg-gray-900 border-gray-800 h-full">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <CardTitle className="text-white text-lg">{node.label}</CardTitle>
          <Icon className={`w-5 h-5 ${config.color}`} />
        </div>
        <div className="flex items-center gap-2 mt-2">
          <Badge
            variant="outline"
            className={`${
              node.type === 'opportunity'
                ? 'border-green-500 text-green-500'
                : node.type === 'threat'
                ? 'border-red-500 text-red-500'
                : node.type === 'center'
                ? 'border-blue-500 text-blue-500'
                : 'border-gray-500 text-gray-500'
            }`}
          >
            {config.label}
          </Badge>
          <Badge variant="outline" className="border-yellow-500 text-yellow-500">
            Strength: {node.connectionStrength}%
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h4 className="text-sm font-semibold text-gray-300 mb-2">Description</h4>
          <p className="text-sm text-gray-400 leading-relaxed">{node.description}</p>
        </div>

        {node.insights.length > 0 && (
          <div>
            <h4 className="text-sm font-semibold text-gray-300 mb-2">Key Insights</h4>
            <ul className="space-y-2">
              {node.insights.map((insight: string, index: number) => (
                <li key={index} className="text-sm text-gray-400 flex items-start gap-2">
                  <span className="text-yellow-500 mt-0.5">▸</span>
                  <span>{insight}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
