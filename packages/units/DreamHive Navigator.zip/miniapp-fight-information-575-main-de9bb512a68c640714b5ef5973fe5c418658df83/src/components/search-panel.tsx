'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Search, Sparkles } from 'lucide-react';

interface SearchPanelProps {
  onSearch: (concept: string) => void;
  isLoading: boolean;
}

export function SearchPanel({ onSearch, isLoading }: SearchPanelProps) {
  const [concept, setConcept] = useState<string>('');

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (concept.trim() && !isLoading) {
      onSearch(concept.trim());
    }
  };

  const examples = [
    'Base blockchain',
    'Farcaster',
    'Elon Musk',
    'AI agents',
    'NFT marketplace',
    'DeFi protocols'
  ];

  return (
    <Card className="w-full bg-gradient-to-br from-gray-900 to-black border-yellow-500/30">
      <CardContent className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-6 h-6 text-yellow-500" />
          <h2 className="text-xl font-bold text-white">
            Navigate the DreamHive
          </h2>
        </div>
        
        <form onSubmit={handleSubmit} className="flex gap-2 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              type="text"
              value={concept}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setConcept(e.target.value)}
              placeholder="Enter any concept, person, token, location, or idea..."
              className="pl-10 bg-black border-yellow-500/30 text-white placeholder:text-gray-500"
              disabled={isLoading}
            />
          </div>
          <Button
            type="submit"
            disabled={!concept.trim() || isLoading}
            className="bg-yellow-500 hover:bg-yellow-600 text-black font-bold"
          >
            {isLoading ? 'Analyzing...' : 'Explore'}
          </Button>
        </form>

        <div className="flex flex-wrap gap-2">
          <span className="text-xs text-gray-400">Try:</span>
          {examples.map((example: string) => (
            <button
              key={example}
              onClick={() => {
                setConcept(example);
                onSearch(example);
              }}
              disabled={isLoading}
              className="text-xs px-2 py-1 rounded-full bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500/20 border border-yellow-500/30 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {example}
            </button>
          ))}
        </div>

        <div className="mt-4 pt-4 border-t border-gray-800">
          <p className="text-xs text-gray-400 leading-relaxed">
            DreamHive reveals hidden influence networks. Discover opportunities, threats, 
            and strategic insights powered by AI analysis.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
