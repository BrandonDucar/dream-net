export interface NetworkNode {
  id: string;
  label: string;
  type: 'opportunity' | 'threat' | 'neutral' | 'center';
  description: string;
  connectionStrength: number; // 0-100
  insights: string[];
  position?: { x: number; y: number };
}

export interface NetworkConnection {
  source: string;
  target: string;
  strength: number; // 0-100
}

export interface HiveScore {
  overall: number; // 0-100
  viralPotential: number; // 0-100
  profitability: number; // 0-100
  strategicValue: number; // 0-100
  reasoning: string;
}

export interface NetworkData {
  centerNode: NetworkNode;
  nodes: NetworkNode[];
  connections: NetworkConnection[];
  hiveScore: HiveScore;
  generatedAt: string;
}
