import type { NetworkNode } from '@/types/network';

export interface HexPosition {
  x: number;
  y: number;
  col: number;
  row: number;
}

/**
 * Calculate hexagonal grid positions for nodes
 */
export function calculateHoneycombPositions(
  nodeCount: number,
  hexSize: number = 80,
  centerX: number = 400,
  centerY: number = 300
): HexPosition[] {
  const positions: HexPosition[] = [];
  
  // Center position
  positions.push({ x: centerX, y: centerY, col: 0, row: 0 });
  
  if (nodeCount <= 1) return positions;
  
  // Hexagonal grid math
  const hexWidth = hexSize * Math.sqrt(3);
  const hexHeight = hexSize * 2;
  const vertSpacing = hexHeight * 0.75;
  
  // Create rings around center
  let ring = 1;
  let posIndex = 1;
  
  while (posIndex < nodeCount) {
    const nodesInRing = ring * 6;
    
    for (let i = 0; i < nodesInRing && posIndex < nodeCount; i++) {
      const angle = (i / nodesInRing) * Math.PI * 2;
      const distance = ring * hexWidth * 0.9;
      
      const x = centerX + Math.cos(angle) * distance;
      const y = centerY + Math.sin(angle) * distance;
      
      positions.push({
        x,
        y,
        col: Math.round((x - centerX) / hexWidth),
        row: Math.round((y - centerY) / vertSpacing)
      });
      
      posIndex++;
    }
    
    ring++;
  }
  
  return positions;
}

/**
 * Generate hexagon path for SVG
 */
export function getHexagonPath(
  x: number,
  y: number,
  size: number = 60
): string {
  const points: Array<{ x: number; y: number }> = [];
  
  for (let i = 0; i < 6; i++) {
    const angle = (Math.PI / 3) * i - Math.PI / 2;
    points.push({
      x: x + size * Math.cos(angle),
      y: y + size * Math.sin(angle)
    });
  }
  
  return points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ') + ' Z';
}

/**
 * Get color based on node type
 */
export function getNodeColor(type: NetworkNode['type']): {
  fill: string;
  stroke: string;
  glow: string;
} {
  switch (type) {
    case 'opportunity':
      return {
        fill: 'rgba(34, 197, 94, 0.2)',
        stroke: '#22c55e',
        glow: '#22c55e'
      };
    case 'threat':
      return {
        fill: 'rgba(239, 68, 68, 0.2)',
        stroke: '#ef4444',
        glow: '#ef4444'
      };
    case 'center':
      return {
        fill: 'rgba(59, 130, 246, 0.3)',
        stroke: '#3b82f6',
        glow: '#3b82f6'
      };
    default:
      return {
        fill: 'rgba(107, 114, 128, 0.2)',
        stroke: '#6b7280',
        glow: '#6b7280'
      };
  }
}

/**
 * Calculate connection strength opacity
 */
export function getConnectionOpacity(strength: number): number {
  return Math.max(0.1, Math.min(1, strength / 100));
}
