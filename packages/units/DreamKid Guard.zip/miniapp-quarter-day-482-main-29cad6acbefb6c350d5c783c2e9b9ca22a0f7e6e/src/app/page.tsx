'use client'
import { useState, useEffect } from 'react';
import { DailyLessons } from '@/components/daily-lessons';
import { ParentScripts } from '@/components/parent-scripts';
import { BadgeCollection } from '@/components/badge-collection';
import { TechTimeTracker } from '@/components/tech-time-tracker';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Award, BookOpen, Clock, Users } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function HealthyTechHabitsApp(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [mounted, setMounted] = useState<boolean>(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return <div className="min-h-screen bg-gradient-to-br from-blue-100 via-purple-100 to-pink-100" />;
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-100 via-purple-100 to-pink-100 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <header className="text-center mb-8 pt-8">
          <h1 className="text-4xl md:text-6xl font-bold text-purple-700 mb-4">
            🌟 DreamKid Guard 🌟
          </h1>
          <p className="text-lg md:text-xl text-gray-700">
            Fun lessons for ages 3-8 about using technology wisely!
          </p>
        </header>

        <Tabs defaultValue="lessons" className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 gap-2 bg-white/80 p-2 rounded-xl mb-6">
            <TabsTrigger 
              value="lessons" 
              className="flex items-center gap-2 text-base md:text-lg py-3 data-[state=active]:bg-purple-500 data-[state=active]:text-white"
            >
              <BookOpen className="w-5 h-5" />
              <span className="hidden sm:inline">Lessons</span>
            </TabsTrigger>
            <TabsTrigger 
              value="badges" 
              className="flex items-center gap-2 text-base md:text-lg py-3 data-[state=active]:bg-yellow-500 data-[state=active]:text-white"
            >
              <Award className="w-5 h-5" />
              <span className="hidden sm:inline">Badges</span>
            </TabsTrigger>
            <TabsTrigger 
              value="tracker" 
              className="flex items-center gap-2 text-base md:text-lg py-3 data-[state=active]:bg-blue-500 data-[state=active]:text-white"
            >
              <Clock className="w-5 h-5" />
              <span className="hidden sm:inline">Timer</span>
            </TabsTrigger>
            <TabsTrigger 
              value="parents" 
              className="flex items-center gap-2 text-base md:text-lg py-3 data-[state=active]:bg-green-500 data-[state=active]:text-white"
            >
              <Users className="w-5 h-5" />
              <span className="hidden sm:inline">Parents</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="lessons">
            <DailyLessons />
          </TabsContent>

          <TabsContent value="badges">
            <BadgeCollection />
          </TabsContent>

          <TabsContent value="tracker">
            <TechTimeTracker />
          </TabsContent>

          <TabsContent value="parents">
            <ParentScripts />
          </TabsContent>
        </Tabs>
      </div>
    </main>
  );
}
