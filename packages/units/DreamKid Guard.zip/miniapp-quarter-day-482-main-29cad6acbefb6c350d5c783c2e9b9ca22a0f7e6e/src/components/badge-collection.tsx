'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Award, Lock } from 'lucide-react';
import type { UserProgress } from '@/types/app-types';

interface Badge {
  id: number;
  name: string;
  emoji: string;
  description: string;
  color: string;
}

const badges: Badge[] = [
  {
    id: 1,
    name: "Balance Master",
    emoji: "⚖️",
    description: "Learned about screen time balance!",
    color: "from-blue-400 to-blue-600"
  },
  {
    id: 2,
    name: "Posture Pro",
    emoji: "🧘",
    description: "Mastered good posture habits!",
    color: "from-green-400 to-green-600"
  },
  {
    id: 3,
    name: "Sleep Champion",
    emoji: "😴",
    description: "Knows how to sleep better!",
    color: "from-purple-400 to-purple-600"
  },
  {
    id: 4,
    name: "Safety Star",
    emoji: "🛡️",
    description: "Learned to stay safe online!",
    color: "from-red-400 to-red-600"
  },
  {
    id: 5,
    name: "Active Hero",
    emoji: "🏃",
    description: "Knows the importance of active play!",
    color: "from-orange-400 to-orange-600"
  },
  {
    id: 6,
    name: "Kindness King/Queen",
    emoji: "💝",
    description: "Spreads kindness everywhere!",
    color: "from-pink-400 to-pink-600"
  },
  {
    id: 7,
    name: "Rule Keeper",
    emoji: "👨‍👩‍👧‍👦",
    description: "Follows family tech rules!",
    color: "from-yellow-400 to-yellow-600"
  }
];

export function BadgeCollection(): JSX.Element {
  const [progress, setProgress] = useState<UserProgress>({
    completedLessons: [],
    earnedBadges: [],
    quizScores: []
  });

  useEffect(() => {
    const savedProgress = localStorage.getItem('techHabitsProgress');
    if (savedProgress) {
      setProgress(JSON.parse(savedProgress) as UserProgress);
    }
  }, []);

  const earnedCount = progress.earnedBadges.length;
  const totalBadges = badges.length;

  return (
    <div className="space-y-6">
      <Card className="bg-white/90 backdrop-blur-sm border-4 border-yellow-300">
        <CardHeader className="text-center">
          <div className="text-6xl mb-4">🏆</div>
          <CardTitle className="text-3xl md:text-4xl text-yellow-700">
            Your Badge Collection
          </CardTitle>
          <CardDescription className="text-xl">
            You&apos;ve earned {earnedCount} of {totalBadges} badges!
          </CardDescription>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        {badges.map((badge: Badge) => {
          const isEarned = progress.earnedBadges.includes(badge.id);

          return (
            <Card
              key={badge.id}
              className={`relative overflow-hidden border-4 transition-all ${
                isEarned
                  ? 'border-yellow-400 shadow-2xl animate-pulse'
                  : 'border-gray-300 opacity-60'
              }`}
            >
              {isEarned && (
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${badge.color} opacity-10`}
                />
              )}
              <CardHeader className="text-center relative">
                <div className="text-6xl md:text-7xl mb-3">
                  {isEarned ? badge.emoji : <Lock className="w-16 h-16 mx-auto text-gray-400" />}
                </div>
                <CardTitle className={`text-2xl mb-2 ${isEarned ? 'text-yellow-700' : 'text-gray-500'}`}>
                  {isEarned ? badge.name : '???'}
                </CardTitle>
                <CardDescription className="text-base">
                  {isEarned ? badge.description : 'Complete the lesson to unlock!'}
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                {isEarned ? (
                  <div className="flex items-center justify-center gap-2 text-green-600 font-semibold">
                    <Award className="w-5 h-5" />
                    <span>Earned!</span>
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-2 text-gray-400">
                    <Lock className="w-5 h-5" />
                    <span>Locked</span>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {earnedCount === totalBadges && (
        <Card className="bg-gradient-to-br from-yellow-400 to-orange-400 border-4 border-yellow-600 text-white">
          <CardHeader className="text-center">
            <div className="text-8xl mb-4">🎉</div>
            <CardTitle className="text-4xl mb-3">
              Congratulations!
            </CardTitle>
            <CardDescription className="text-xl text-white">
              You&apos;ve collected all the badges! You&apos;re a Healthy Tech Habits Champion! 🏆
            </CardDescription>
          </CardHeader>
        </Card>
      )}
    </div>
  );
}
