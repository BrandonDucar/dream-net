'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { QuizModal } from '@/components/quiz-modal';
import { CheckCircle2, Lock, Play } from 'lucide-react';
import type { Lesson, UserProgress } from '@/types/app-types';

const lessons: Lesson[] = [
  {
    id: 1,
    title: "Screen Time Balance",
    emoji: "⚖️",
    description: "Learn why taking breaks from screens is important!",
    content: "Just like you need to eat healthy foods and play outside, your eyes and brain need breaks from screens! Let's learn about the 20-20-20 rule: Every 20 minutes, look at something 20 feet away for 20 seconds.",
    quiz: {
      question: "How often should you take a break from screens?",
      options: [
        "Every 20 minutes",
        "Once a day",
        "Never",
        "Only when sleepy"
      ],
      correctAnswer: 0
    }
  },
  {
    id: 2,
    title: "Good Posture",
    emoji: "🧘",
    description: "Sit up straight and feel great!",
    content: "When you use a tablet or computer, sit up straight like a superhero! Your back should be against the chair, feet on the floor, and the screen should be at eye level. This helps you feel better and stay healthy!",
    quiz: {
      question: "Where should your feet be when using a computer?",
      options: [
        "On the floor",
        "On the chair",
        "In the air",
        "Under the table"
      ],
      correctAnswer: 0
    }
  },
  {
    id: 3,
    title: "Bedtime Without Screens",
    emoji: "😴",
    description: "Why screens before bed make it hard to sleep.",
    content: "Screens have bright lights that tell your brain to stay awake! To sleep better, put away all screens 1 hour before bedtime. Instead, read a book, draw, or talk with your family!",
    quiz: {
      question: "When should you stop using screens before bed?",
      options: [
        "1 hour before",
        "Right before bed",
        "2 minutes before",
        "While falling asleep"
      ],
      correctAnswer: 0
    }
  },
  {
    id: 4,
    title: "Online Safety",
    emoji: "🛡️",
    description: "Stay safe while having fun online!",
    content: "Never share your name, address, or school with strangers online. Always ask a parent before clicking on something new. If something makes you feel uncomfortable, tell an adult right away!",
    quiz: {
      question: "What should you do before clicking something new?",
      options: [
        "Ask a parent",
        "Click it quickly",
        "Close your eyes",
        "Tell your friends"
      ],
      correctAnswer: 0
    }
  },
  {
    id: 5,
    title: "Active Play Time",
    emoji: "🏃",
    description: "Your body needs to move and play!",
    content: "Every day, you should play and move your body for at least 1 hour! Run, jump, dance, or play sports. This makes your body strong and your brain happy!",
    quiz: {
      question: "How long should you play actively each day?",
      options: [
        "At least 1 hour",
        "5 minutes",
        "All day on screens",
        "Never"
      ],
      correctAnswer: 0
    }
  },
  {
    id: 6,
    title: "Kind Words Online",
    emoji: "💝",
    description: "Be nice to everyone, even online!",
    content: "The same rules for being nice in real life apply online too! Use kind words, don't say mean things, and if you see someone being unkind, tell an adult. Treat others how you want to be treated!",
    quiz: {
      question: "How should you treat people online?",
      options: [
        "With kindness",
        "It doesn't matter",
        "However I want",
        "Ignore everyone"
      ],
      correctAnswer: 0
    }
  },
  {
    id: 7,
    title: "Family Tech Rules",
    emoji: "👨‍👩‍👧‍👦",
    description: "Following rules helps everyone!",
    content: "Every family has tech rules to keep everyone healthy and happy. Maybe no phones at dinner, or only certain shows. Following these rules shows respect and helps you grow into a responsible tech user!",
    quiz: {
      question: "Why do families have tech rules?",
      options: [
        "To keep everyone healthy and happy",
        "To be mean",
        "For no reason",
        "Only for kids"
      ],
      correctAnswer: 0
    }
  }
];

export function DailyLessons(): JSX.Element {
  const [progress, setProgress] = useState<UserProgress>({
    completedLessons: [],
    earnedBadges: [],
    quizScores: []
  });
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [showQuiz, setShowQuiz] = useState<boolean>(false);

  useEffect(() => {
    const savedProgress = localStorage.getItem('techHabitsProgress');
    if (savedProgress) {
      setProgress(JSON.parse(savedProgress) as UserProgress);
    }
  }, []);

  const saveProgress = (newProgress: UserProgress): void => {
    setProgress(newProgress);
    localStorage.setItem('techHabitsProgress', JSON.stringify(newProgress));
  };

  const startLesson = (lesson: Lesson): void => {
    setSelectedLesson(lesson);
  };

  const completeLesson = (): void => {
    setShowQuiz(true);
  };

  const handleQuizComplete = (score: number): void => {
    if (selectedLesson) {
      const newProgress: UserProgress = {
        ...progress,
        completedLessons: progress.completedLessons.includes(selectedLesson.id)
          ? progress.completedLessons
          : [...progress.completedLessons, selectedLesson.id],
        quizScores: [...progress.quizScores, { lessonId: selectedLesson.id, score }]
      };

      if (score === 100 && !progress.earnedBadges.includes(selectedLesson.id)) {
        newProgress.earnedBadges = [...progress.earnedBadges, selectedLesson.id];
      }

      saveProgress(newProgress);
    }
    setShowQuiz(false);
    setSelectedLesson(null);
  };

  const progressPercentage = (progress.completedLessons.length / lessons.length) * 100;

  if (selectedLesson && !showQuiz) {
    return (
      <Card className="bg-white/90 backdrop-blur-sm border-4 border-purple-300">
        <CardHeader>
          <div className="text-center">
            <div className="text-7xl mb-4">{selectedLesson.emoji}</div>
            <CardTitle className="text-3xl md:text-4xl text-purple-700 mb-2">
              {selectedLesson.title}
            </CardTitle>
            <CardDescription className="text-lg text-gray-600">
              Lesson {selectedLesson.id} of {lessons.length}
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-blue-50 p-6 rounded-xl border-2 border-blue-200">
            <p className="text-xl leading-relaxed text-gray-800">
              {selectedLesson.content}
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              onClick={() => setSelectedLesson(null)}
              variant="outline"
              size="lg"
              className="flex-1 text-lg py-6"
            >
              Back to Lessons
            </Button>
            <Button
              onClick={completeLesson}
              size="lg"
              className="flex-1 text-lg py-6 bg-purple-500 hover:bg-purple-600"
            >
              Take the Quiz! 🎯
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="bg-white/90 backdrop-blur-sm border-4 border-purple-300">
        <CardHeader>
          <CardTitle className="text-2xl text-purple-700">Your Progress</CardTitle>
          <div className="space-y-2">
            <Progress value={progressPercentage} className="h-4" />
            <p className="text-lg text-gray-600">
              {progress.completedLessons.length} of {lessons.length} lessons completed! 🌟
            </p>
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-4 md:gap-6">
        {lessons.map((lesson: Lesson) => {
          const isCompleted = progress.completedLessons.includes(lesson.id);
          const isLocked = lesson.id > 1 && !progress.completedLessons.includes(lesson.id - 1);

          return (
            <Card
              key={lesson.id}
              className={`bg-white/90 backdrop-blur-sm border-4 transition-all ${
                isCompleted
                  ? 'border-green-400 shadow-lg'
                  : isLocked
                  ? 'border-gray-300 opacity-60'
                  : 'border-purple-300 hover:shadow-xl hover:scale-[1.02]'
              }`}
            >
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className="text-5xl md:text-6xl">{lesson.emoji}</div>
                  <div className="flex-1">
                    <CardTitle className="text-2xl md:text-3xl text-purple-700 mb-2">
                      {lesson.title}
                    </CardTitle>
                    <CardDescription className="text-base md:text-lg">
                      {lesson.description}
                    </CardDescription>
                  </div>
                  {isCompleted && (
                    <CheckCircle2 className="w-8 h-8 text-green-500 flex-shrink-0" />
                  )}
                  {isLocked && (
                    <Lock className="w-8 h-8 text-gray-400 flex-shrink-0" />
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={() => startLesson(lesson)}
                  disabled={isLocked}
                  size="lg"
                  className={`w-full text-lg py-6 ${
                    isCompleted
                      ? 'bg-green-500 hover:bg-green-600'
                      : 'bg-purple-500 hover:bg-purple-600'
                  }`}
                >
                  {isLocked ? (
                    <>
                      <Lock className="w-5 h-5 mr-2" />
                      Complete Previous Lesson First
                    </>
                  ) : isCompleted ? (
                    <>
                      <CheckCircle2 className="w-5 h-5 mr-2" />
                      Review Lesson
                    </>
                  ) : (
                    <>
                      <Play className="w-5 h-5 mr-2" />
                      Start Lesson
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {showQuiz && selectedLesson && (
        <QuizModal
          lesson={selectedLesson}
          onComplete={handleQuizComplete}
          onClose={() => {
            setShowQuiz(false);
            setSelectedLesson(null);
          }}
        />
      )}
    </div>
  );
}
