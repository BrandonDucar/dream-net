'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

interface ParentScript {
  id: number;
  topic: string;
  ageGroup: string;
  script: string;
  tips: string[];
}

const parentScripts: ParentScript[] = [
  {
    id: 1,
    topic: "Introducing Screen Time Limits",
    ageGroup: "Ages 3-5",
    script: "Hey sweetie, just like we have bedtime and snack time, we also have screen time! That means we only use tablets and phones for a little while each day. This helps keep our eyes healthy and gives us time to play with toys, read books, and play outside. Does that sound good?",
    tips: [
      "Use a visual timer so they can see time passing",
      "Offer fun alternatives when screen time ends",
      "Be consistent with the rules every day",
      "Praise them when they follow the limits"
    ]
  },
  {
    id: 2,
    topic: "Introducing Screen Time Limits",
    ageGroup: "Ages 6-8",
    script: "I want to talk about screen time. Our brains and eyes need breaks from screens, just like our bodies need rest after playing. We're going to set a timer for screen time each day. When the timer goes off, it's time to do other activities. I know it might feel hard at first, but it helps us stay healthy. What activities would you like to do when screen time ends?",
    tips: [
      "Involve them in creating a schedule",
      "Explain the reasons in age-appropriate terms",
      "Create a reward system for following rules",
      "Model good screen habits yourself"
    ]
  },
  {
    id: 3,
    topic: "Talking About Online Safety",
    ageGroup: "Ages 3-5",
    script: "When we play games or watch videos, we never tell anyone our name, where we live, or where we go to school. If anyone asks, you come tell mommy or daddy right away. And if you see something that makes you feel funny or scared, you can always tell us. We're here to keep you safe!",
    tips: [
      "Keep devices in common areas where you can supervise",
      "Use parental controls and kid-safe apps",
      "Review content together regularly",
      "Create an open, judgment-free environment"
    ]
  },
  {
    id: 4,
    topic: "Talking About Online Safety",
    ageGroup: "Ages 6-8",
    script: "The internet can be fun, but not everyone online is who they say they are. That's why we have some important rules: Never share personal information like your full name, address, phone number, or school name. Never agree to meet someone you only know online. If anyone makes you uncomfortable or asks you to keep secrets from me, tell me immediately. I won't be mad—I want to help keep you safe.",
    tips: [
      "Review their online activity regularly",
      "Friend/follow their accounts if age-appropriate",
      "Discuss real examples (age-appropriate)",
      "Establish clear consequences for breaking rules"
    ]
  },
  {
    id: 5,
    topic: "Encouraging Physical Activity",
    ageGroup: "Ages 3-5",
    script: "Your body loves to move and play! Let's put the tablet away and go outside. We can run, jump, dance, or play with your toys. Moving our bodies makes us strong and happy. What would you like to play today?",
    tips: [
      "Make physical activity fun, not a chore",
      "Join them in active play",
      "Create a daily outdoor time routine",
      "Celebrate their physical achievements"
    ]
  },
  {
    id: 6,
    topic: "Encouraging Physical Activity",
    ageGroup: "Ages 6-8",
    script: "Did you know that kids your age should play and be active for at least one hour every day? When we move our bodies, it helps our brains work better, makes us stronger, and even helps us sleep better at night! Screen time is fun, but it's important to balance it with running, jumping, sports, or dancing. What's your favorite way to be active?",
    tips: [
      "Enroll them in sports or activities they enjoy",
      "Make family physical activity a regular event",
      "Track their activity together with a chart",
      "Limit screen time to create space for movement"
    ]
  },
  {
    id: 7,
    topic: "Bedtime Without Screens",
    ageGroup: "Ages 3-5",
    script: "The lights from tablets and phones can trick our brains into thinking it's daytime! That makes it harder to fall asleep. So, one hour before bedtime, we're going to put all the screens away. Instead, we can read stories, color, or talk about our day. This will help you sleep better and feel great in the morning!",
    tips: [
      "Create a calming bedtime routine without screens",
      "Keep devices out of the bedroom entirely",
      "Provide alternative calming activities",
      "Stay consistent even on weekends"
    ]
  },
  {
    id: 8,
    topic: "Bedtime Without Screens",
    ageGroup: "Ages 6-8",
    script: "Our bodies make a special sleepy hormone called melatonin when it gets dark. But screens have bright blue light that tells our brain to stay awake. That's why we turn off all screens one hour before bed. This gives your brain time to get ready for sleep. I know you might not feel tired right away, but trust me—you'll sleep better and feel more rested. Let's choose some other bedtime activities you enjoy.",
    tips: [
      "Remove all screens from bedrooms",
      "Establish a consistent sleep schedule",
      "Offer books, journals, or quiet activities",
      "Explain the science in simple terms they can understand"
    ]
  },
  {
    id: 9,
    topic: "Managing Digital Tantrums",
    ageGroup: "Ages 3-5",
    script: "I know you're upset that screen time is over, and it's okay to feel sad. But we have rules to keep you healthy. Let's take some deep breaths together. Now, would you like to play with blocks or read a book? I'll do it with you!",
    tips: [
      "Stay calm and don't give in to tantrums",
      "Acknowledge their feelings while maintaining boundaries",
      "Redirect to a positive activity",
      "Give a 5-minute warning before screen time ends"
    ]
  },
  {
    id: 10,
    topic: "Managing Digital Tantrums",
    ageGroup: "Ages 6-8",
    script: "I understand you're frustrated that you have to stop playing. It can be hard to stop doing something fun. But just like we can't eat candy all day, we can't use screens all day either. These limits help keep you healthy. Let's take a few minutes to calm down, and then you can choose another activity from our list. Remember, if you handle this well, it shows me you're mature and responsible.",
    tips: [
      "Empathize but don't negotiate the rules",
      "Use timers and warnings to ease transitions",
      "Reward positive responses to limits",
      "Stay united with other caregivers on rules"
    ]
  },
  {
    id: 11,
    topic: "Teaching Digital Citizenship",
    ageGroup: "Ages 3-5",
    script: "When we watch videos or play games, we use our nice words and kind actions—just like we do with our friends at school! We don't say mean things, and we're gentle with the device. Being kind is important everywhere, even on screens!",
    tips: [
      "Model kind online behavior",
      "Watch content together and discuss it",
      "Praise kind online interactions",
      "Keep online interactions simple at this age"
    ]
  },
  {
    id: 12,
    topic: "Teaching Digital Citizenship",
    ageGroup: "Ages 6-8",
    script: "Everything you say and do online is just as important as what you do in person. Being a good digital citizen means being kind in comments, respecting others' privacy, and thinking before you post or share. If you wouldn't say something to someone's face, don't say it online. And remember, once something is online, it can be there forever. Let's practice making good choices together.",
    tips: [
      "Review their posts and messages together",
      "Discuss real-world examples of good/poor digital citizenship",
      "Create a family technology agreement",
      "Praise positive online interactions"
    ]
  }
];

export function ParentScripts(): JSX.Element {
  const ageGroups = ['Ages 3-5', 'Ages 6-8'];

  return (
    <div className="space-y-6">
      <Card className="bg-white/90 backdrop-blur-sm border-4 border-green-300">
        <CardHeader className="text-center">
          <div className="text-6xl mb-4">👨‍👩‍👧‍👦</div>
          <CardTitle className="text-3xl md:text-4xl text-green-700">
            Parent Talking Scripts
          </CardTitle>
          <CardDescription className="text-xl">
            Ready-to-use conversation starters for discussing healthy tech habits with your children
          </CardDescription>
        </CardHeader>
      </Card>

      {ageGroups.map((ageGroup: string) => (
        <div key={ageGroup}>
          <h2 className="text-2xl md:text-3xl font-bold text-purple-700 mb-4 text-center">
            {ageGroup}
          </h2>

          <Accordion type="single" collapsible className="space-y-4">
            {parentScripts
              .filter((script: ParentScript) => script.ageGroup === ageGroup)
              .map((script: ParentScript) => (
                <AccordionItem
                  key={script.id}
                  value={`script-${script.id}`}
                  className="bg-white/90 backdrop-blur-sm border-4 border-green-200 rounded-xl px-4"
                >
                  <AccordionTrigger className="text-xl md:text-2xl font-semibold text-green-700 hover:text-green-800 py-6">
                    {script.topic}
                  </AccordionTrigger>
                  <AccordionContent className="space-y-4 pb-6">
                    <Card className="bg-blue-50 border-2 border-blue-200">
                      <CardHeader>
                        <CardTitle className="text-lg text-blue-700">
                          Sample Script:
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-base md:text-lg leading-relaxed text-gray-800">
                          &quot;{script.script}&quot;
                        </p>
                      </CardContent>
                    </Card>

                    <Card className="bg-green-50 border-2 border-green-200">
                      <CardHeader>
                        <CardTitle className="text-lg text-green-700">
                          💡 Helpful Tips:
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          {script.tips.map((tip: string, index: number) => (
                            <li key={index} className="flex items-start gap-2 text-base md:text-lg">
                              <span className="text-green-600 font-bold">•</span>
                              <span className="text-gray-700">{tip}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  </AccordionContent>
                </AccordionItem>
              ))}
          </Accordion>
        </div>
      ))}

      <Card className="bg-gradient-to-br from-green-100 to-blue-100 border-4 border-green-400">
        <CardHeader>
          <CardTitle className="text-2xl text-green-700">
            General Tips for All Conversations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3 text-base md:text-lg">
            <li className="flex items-start gap-2">
              <span className="text-2xl">💬</span>
              <span>Choose calm moments when both you and your child are relaxed</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-2xl">👂</span>
              <span>Listen to their perspective and validate their feelings</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-2xl">🔄</span>
              <span>Be consistent with rules and consequences</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-2xl">👀</span>
              <span>Model the behavior you want to see (limit your own screen time!)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-2xl">🤝</span>
              <span>Make it a team effort—you and your child working together</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-2xl">🎯</span>
              <span>Focus on one topic at a time to avoid overwhelming them</span>
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
