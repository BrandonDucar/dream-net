'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import type { Lesson } from '@/types/app-types';

interface QuizModalProps {
  lesson: Lesson;
  onComplete: (score: number) => void;
  onClose: () => void;
}

export function QuizModal({ lesson, onComplete, onClose }: QuizModalProps): JSX.Element {
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState<boolean>(false);

  const handleSubmit = (): void => {
    if (selectedAnswer === null) return;
    setShowResult(true);
  };

  const handleComplete = (): void => {
    const score = selectedAnswer === lesson.quiz.correctAnswer ? 100 : 0;
    onComplete(score);
  };

  const isCorrect = selectedAnswer === lesson.quiz.correctAnswer;

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-gradient-to-br from-purple-50 to-pink-50 border-4 border-purple-300">
        <DialogHeader>
          <DialogTitle className="text-3xl text-center text-purple-700 mb-4">
            {lesson.emoji} Quiz Time! {lesson.emoji}
          </DialogTitle>
        </DialogHeader>

        {!showResult ? (
          <div className="space-y-6">
            <Card className="bg-white p-6 border-2 border-purple-200">
              <p className="text-xl md:text-2xl text-center text-gray-800 font-semibold">
                {lesson.quiz.question}
              </p>
            </Card>

            <div className="grid gap-3">
              {lesson.quiz.options.map((option: string, index: number) => (
                <Button
                  key={index}
                  onClick={() => setSelectedAnswer(index)}
                  variant={selectedAnswer === index ? 'default' : 'outline'}
                  size="lg"
                  className={`text-lg py-6 h-auto whitespace-normal ${
                    selectedAnswer === index
                      ? 'bg-purple-500 hover:bg-purple-600 text-white'
                      : 'bg-white hover:bg-purple-50'
                  }`}
                >
                  {option}
                </Button>
              ))}
            </div>

            <Button
              onClick={handleSubmit}
              disabled={selectedAnswer === null}
              size="lg"
              className="w-full text-xl py-6 bg-green-500 hover:bg-green-600"
            >
              Submit Answer ✓
            </Button>
          </div>
        ) : (
          <div className="space-y-6 text-center">
            <div className="text-8xl mb-4">
              {isCorrect ? '🎉' : '💪'}
            </div>
            <div className="space-y-4">
              <h3 className={`text-3xl font-bold ${isCorrect ? 'text-green-600' : 'text-orange-600'}`}>
                {isCorrect ? 'Amazing Job!' : 'Keep Learning!'}
              </h3>
              <p className="text-xl text-gray-700">
                {isCorrect
                  ? 'You got it right! You earned a badge! 🏆'
                  : `The correct answer was: ${lesson.quiz.options[lesson.quiz.correctAnswer]}. Try reviewing the lesson again!`}
              </p>
            </div>
            <Button
              onClick={handleComplete}
              size="lg"
              className="w-full text-xl py-6 bg-purple-500 hover:bg-purple-600"
            >
              Continue
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
