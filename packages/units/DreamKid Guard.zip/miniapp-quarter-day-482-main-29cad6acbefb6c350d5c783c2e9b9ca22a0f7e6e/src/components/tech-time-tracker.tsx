'use client';

import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Play, Pause, RotateCcw, Clock } from 'lucide-react';

export function TechTimeTracker(): JSX.Element {
  const [timeLimit, setTimeLimit] = useState<number>(30);
  const [timeRemaining, setTimeRemaining] = useState<number>(30 * 60);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [hasStarted, setHasStarted] = useState<boolean>(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isRunning && timeRemaining > 0) {
      intervalRef.current = setInterval(() => {
        setTimeRemaining((prev: number) => {
          if (prev <= 1) {
            setIsRunning(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning, timeRemaining]);

  const startTimer = (): void => {
    setIsRunning(true);
    setHasStarted(true);
  };

  const pauseTimer = (): void => {
    setIsRunning(false);
  };

  const resetTimer = (): void => {
    setIsRunning(false);
    setTimeRemaining(timeLimit * 60);
    setHasStarted(false);
  };

  const setNewTimeLimit = (minutes: number): void => {
    setTimeLimit(minutes);
    setTimeRemaining(minutes * 60);
    setIsRunning(false);
    setHasStarted(false);
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercentage = ((timeLimit * 60 - timeRemaining) / (timeLimit * 60)) * 100;

  const timeLimitOptions = [15, 30, 45, 60];

  return (
    <div className="space-y-6">
      <Card className="bg-white/90 backdrop-blur-sm border-4 border-blue-300">
        <CardHeader className="text-center">
          <div className="text-6xl mb-4">⏰</div>
          <CardTitle className="text-3xl md:text-4xl text-blue-700">
            Tech Time Tracker
          </CardTitle>
          <CardDescription className="text-xl">
            Set a timer to help manage your screen time!
          </CardDescription>
        </CardHeader>
      </Card>

      {!hasStarted && (
        <Card className="bg-white/90 backdrop-blur-sm border-4 border-purple-300">
          <CardHeader>
            <CardTitle className="text-2xl text-center text-purple-700">
              Choose Your Screen Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              {timeLimitOptions.map((minutes: number) => (
                <Button
                  key={minutes}
                  onClick={() => setNewTimeLimit(minutes)}
                  variant={timeLimit === minutes ? 'default' : 'outline'}
                  size="lg"
                  className={`text-xl py-8 ${
                    timeLimit === minutes
                      ? 'bg-blue-500 hover:bg-blue-600'
                      : 'bg-white hover:bg-blue-50'
                  }`}
                >
                  {minutes} minutes
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="bg-gradient-to-br from-blue-100 to-purple-100 border-4 border-blue-400">
        <CardContent className="pt-8">
          <div className="text-center space-y-6">
            <div className="relative">
              <div className="text-8xl md:text-9xl font-bold text-blue-700">
                {formatTime(timeRemaining)}
              </div>
              {timeRemaining === 0 && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-6xl animate-bounce">🎉</div>
                </div>
              )}
            </div>

            <Progress value={progressPercentage} className="h-6" />

            {timeRemaining === 0 && (
              <div className="bg-yellow-100 border-4 border-yellow-400 rounded-xl p-6">
                <p className="text-2xl font-bold text-yellow-800 mb-2">
                  Time&apos;s Up! 🎯
                </p>
                <p className="text-xl text-yellow-700">
                  Great job managing your screen time! Now take a break!
                </p>
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {!isRunning && timeRemaining > 0 && (
                <Button
                  onClick={startTimer}
                  size="lg"
                  className="text-xl py-6 bg-green-500 hover:bg-green-600"
                >
                  <Play className="w-6 h-6 mr-2" />
                  {hasStarted ? 'Resume' : 'Start Timer'}
                </Button>
              )}

              {isRunning && (
                <Button
                  onClick={pauseTimer}
                  size="lg"
                  className="text-xl py-6 bg-orange-500 hover:bg-orange-600"
                >
                  <Pause className="w-6 h-6 mr-2" />
                  Pause
                </Button>
              )}

              {hasStarted && (
                <Button
                  onClick={resetTimer}
                  size="lg"
                  variant="outline"
                  className="text-xl py-6"
                >
                  <RotateCcw className="w-6 h-6 mr-2" />
                  Reset
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-blue-50 border-4 border-blue-200">
        <CardHeader>
          <CardTitle className="text-xl text-blue-700 flex items-center gap-2">
            <Clock className="w-6 h-6" />
            Tips for Healthy Screen Time
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3 text-lg">
            <li className="flex items-start gap-2">
              <span className="text-2xl">✨</span>
              <span>Take breaks every 20 minutes to rest your eyes</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-2xl">🏃</span>
              <span>Stand up and stretch when the timer goes off</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-2xl">💧</span>
              <span>Drink water during your break</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-2xl">🎨</span>
              <span>Do something without screens after your time is up</span>
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
