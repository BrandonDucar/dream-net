export interface Quiz {
  question: string;
  options: string[];
  correctAnswer: number;
}

export interface Lesson {
  id: number;
  title: string;
  emoji: string;
  description: string;
  content: string;
  quiz: Quiz;
}

export interface UserProgress {
  completedLessons: number[];
  earnedBadges: number[];
  quizScores: Array<{
    lessonId: number;
    score: number;
  }>;
}
