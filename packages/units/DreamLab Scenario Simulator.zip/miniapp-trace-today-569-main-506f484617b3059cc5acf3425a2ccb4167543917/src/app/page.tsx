'use client'
import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScenarioDashboard } from '@/components/scenario-dashboard';
import { ScenarioDetail } from '@/components/scenario-detail';
import { AssumptionSetsManager } from '@/components/assumption-sets-manager';
import { SimulationModelsManager } from '@/components/simulation-models-manager';
import { SimObjectsManager } from '@/components/sim-objects-manager';
import { ScenarioComparison } from '@/components/scenario-comparison';
import { CreateScenarioDialog } from '@/components/create-scenario-dialog';
import { ExportReportDialog } from '@/components/export-report-dialog';
import { TournamentManager } from '@/components/tournament-manager';
import { exportScenarioReport, exportSimulationPlaybook } from '@/lib/export-utils';
import { initializeSampleData } from '@/lib/sample-data';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type ViewMode =
  | 'dashboard'
  | 'scenario-detail'
  | 'comparison'
  | 'assumptions'
  | 'models'
  | 'objects';

export default function Home() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [viewMode, setViewMode] = useState<ViewMode>('dashboard');
  const [selectedScenarioId, setSelectedScenarioId] = useState<string | null>(null);
  const [comparisonScenarioIds, setComparisonScenarioIds] = useState<string[]>([]);
  const [createDialogOpen, setCreateDialogOpen] = useState<boolean>(false);
  const [exportDialogOpen, setExportDialogOpen] = useState<boolean>(false);
  const [exportContent, setExportContent] = useState<string>('');
  const [exportTitle, setExportTitle] = useState<string>('');
  const [initialized, setInitialized] = useState<boolean>(false);

  useEffect(() => {
    if (!initialized) {
      initializeSampleData();
      setInitialized(true);
    }
  }, [initialized]);

  function handleViewScenario(scenarioId: string): void {
    setSelectedScenarioId(scenarioId);
    setViewMode('scenario-detail');
  }

  function handleCompareScenarios(scenarioIds: string[]): void {
    setComparisonScenarioIds(scenarioIds);
    setViewMode('comparison');
  }

  function handleCreateScenario(): void {
    setCreateDialogOpen(true);
  }

  function handleScenarioCreated(scenarioId: string): void {
    setSelectedScenarioId(scenarioId);
    setViewMode('scenario-detail');
  }

  function handleExportScenarioReport(scenarioId: string): void {
    const report = exportScenarioReport(scenarioId);
    setExportContent(report);
    setExportTitle('Scenario Report');
    setExportDialogOpen(true);
  }

  function handleExportPlaybook(): void {
    const playbook = exportSimulationPlaybook();
    setExportContent(playbook);
    setExportTitle('Simulation Playbook');
    setExportDialogOpen(true);
  }

  function handleBackToDashboard(): void {
    setViewMode('dashboard');
    setSelectedScenarioId(null);
    setComparisonScenarioIds([]);
  }

  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">DreamNet Simulation Lab</h1>
          <p className="text-muted-foreground">
            Test flows, campaigns, and actions before launching them in the wild
          </p>
        </div>

        {viewMode === 'scenario-detail' && selectedScenarioId ? (
          <ScenarioDetail
            scenarioId={selectedScenarioId}
            onBack={handleBackToDashboard}
            onExportReport={handleExportScenarioReport}
          />
        ) : viewMode === 'comparison' ? (
          <ScenarioComparison
            scenarioIds={comparisonScenarioIds}
            onBack={handleBackToDashboard}
          />
        ) : (
          <Tabs defaultValue="scenarios" className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="scenarios">Scenarios</TabsTrigger>
              <TabsTrigger value="objects">Objects</TabsTrigger>
              <TabsTrigger value="assumptions">Assumptions</TabsTrigger>
              <TabsTrigger value="models">Models</TabsTrigger>
              <TabsTrigger value="tournaments">Tournaments</TabsTrigger>
            </TabsList>

            <TabsContent value="scenarios" className="mt-6">
              <ScenarioDashboard
                onCreateScenario={handleCreateScenario}
                onViewScenario={handleViewScenario}
                onCompareScenarios={handleCompareScenarios}
                onExportPlaybook={handleExportPlaybook}
              />
            </TabsContent>

            <TabsContent value="objects" className="mt-6">
              <SimObjectsManager />
            </TabsContent>

            <TabsContent value="assumptions" className="mt-6">
              <AssumptionSetsManager />
            </TabsContent>

            <TabsContent value="models" className="mt-6">
              <SimulationModelsManager />
            </TabsContent>

            <TabsContent value="tournaments" className="mt-6">
              <TournamentManager />
            </TabsContent>
          </Tabs>
        )}

        <div className="mt-8 p-4 bg-muted rounded-lg">
          <h3 className="font-semibold mb-2">About This Lab</h3>
          <p className="text-sm text-muted-foreground">
            The DreamNet Simulation Lab lets you model and anticipate outcomes for your
            DreamNet actions. Create scenarios, define market assumptions, attach simulation
            objects (tokens, drops, campaigns), configure inputs, and run deterministic
            simulations to see projected reach, conversions, resonance scores, and more.
            All data is stored locally - no external APIs.
          </p>
        </div>
      </div>

      <CreateScenarioDialog
        open={createDialogOpen}
        onClose={() => setCreateDialogOpen(false)}
        onCreated={handleScenarioCreated}
      />

      <ExportReportDialog
        open={exportDialogOpen}
        onClose={() => setExportDialogOpen(false)}
        report={exportContent}
        title={exportTitle}
      />
    </main>
  );
}
