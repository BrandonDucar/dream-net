'use client'
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import {
  Sparkles,
  TrendingUp,
  Zap,
  Network,
  AlertTriangle,
  GitBranch,
  Play,
  BarChart3,
  Trophy,
} from 'lucide-react';

// Import all engines
import { findSimilarHistoricalPatterns, generateHistoricalInsight } from '@/lib/historical-pattern-engine';
import { simulateCompetitiveScenario, generateCompetitiveInsight } from '@/lib/competitive-engine';
import { predictMemeVelocity, generateMemeVelocityInsight } from '@/lib/meme-velocity-engine';
import { modelNetworkEffects, generateNetworkEffectInsight } from '@/lib/network-effect-engine';
import { generateRiskHeatMap, generateRiskHeatMapInsight } from '@/lib/risk-heatmap-engine';
import { generateExecutionPlan, generateExecutionPlanInsight } from '@/lib/execution-plan-engine';
import { compareScenarioToBenchmarks, generateBenchmarkInsight, initializeSampleBenchmarks } from '@/lib/benchmark-engine';

import type { HistoricalPattern, CompetitiveScenario, MemeVelocityMetrics, NetworkSimulation, RiskHeatMap, ExecutionPlan, BenchmarkComparison } from '@/types/advanced-features';

interface AdvancedInsightsPanelProps {
  scenarioId: string;
  onExportExecutionPlan?: (plan: ExecutionPlan) => void;
}

export function AdvancedInsightsPanel({ scenarioId, onExportExecutionPlan }: AdvancedInsightsPanelProps) {
  const [loading, setLoading] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>('historical');
  
  // State for each feature
  const [historicalPatterns, setHistoricalPatterns] = useState<HistoricalPattern[]>([]);
  const [historicalInsight, setHistoricalInsight] = useState<string>('');
  const [competitiveScenario, setCompetitiveScenario] = useState<CompetitiveScenario | null>(null);
  const [competitiveInsight, setCompetitiveInsight] = useState<string>('');
  const [memeVelocity, setMemeVelocity] = useState<MemeVelocityMetrics | null>(null);
  const [memeInsight, setMemeInsight] = useState<string>('');
  const [networkSim, setNetworkSim] = useState<NetworkSimulation | null>(null);
  const [networkInsight, setNetworkInsight] = useState<string>('');
  const [riskHeatMap, setRiskHeatMap] = useState<RiskHeatMap | null>(null);
  const [riskInsight, setRiskInsight] = useState<string>('');
  const [executionPlan, setExecutionPlan] = useState<ExecutionPlan | null>(null);
  const [executionInsight, setExecutionInsight] = useState<string>('');
  const [benchmarkComparison, setBenchmarkComparison] = useState<BenchmarkComparison | null>(null);
  const [benchmarkInsight, setBenchmarkInsight] = useState<string>('');

  useEffect(() => {
    // Initialize benchmarks
    initializeSampleBenchmarks();
    // Load insights when scenario changes
    loadAllInsights();
  }, [scenarioId]);

  async function loadAllInsights(): Promise<void> {
    setLoading(true);
    try {
      // Historical Patterns
      const patterns = findSimilarHistoricalPatterns(scenarioId, 60);
      setHistoricalPatterns(patterns);
      const histInsight = generateHistoricalInsight(scenarioId);
      setHistoricalInsight(histInsight);

      // Meme Velocity
      const memeMetrics = predictMemeVelocity(scenarioId);
      if (memeMetrics) {
        setMemeVelocity(memeMetrics);
        setMemeInsight(generateMemeVelocityInsight(memeMetrics));
      }

      // Network Effects
      const netSim = modelNetworkEffects(scenarioId);
      if (netSim) {
        setNetworkSim(netSim);
        setNetworkInsight(generateNetworkEffectInsight(netSim));
      }

      // Risk Heat Map
      const riskMap = generateRiskHeatMap(scenarioId);
      if (riskMap) {
        setRiskHeatMap(riskMap);
        setRiskInsight(generateRiskHeatMapInsight(riskMap));
      }

      // Benchmark Comparison
      const benchmark = compareScenarioToBenchmarks(scenarioId);
      if (benchmark) {
        setBenchmarkComparison(benchmark);
        setBenchmarkInsight(generateBenchmarkInsight(benchmark));
      }
    } catch (error) {
      console.error('Failed to load advanced insights:', error);
    } finally {
      setLoading(false);
    }
  }

  function handleGenerateExecutionPlan(): void {
    const plan = generateExecutionPlan(scenarioId, 'action-router');
    if (plan) {
      setExecutionPlan(plan);
      setExecutionInsight(generateExecutionPlanInsight(plan));
    }
  }

  function handleExportPlan(): void {
    if (executionPlan && onExportExecutionPlan) {
      onExportExecutionPlan(executionPlan);
    }
  }

  function renderMarkdown(text: string): JSX.Element {
    const lines = text.split('\n');
    return (
      <div className="space-y-2">
        {lines.map((line, idx) => {
          if (line.startsWith('## ')) {
            return <h2 key={idx} className="text-xl font-bold mt-4 mb-2">{line.substring(3)}</h2>;
          } else if (line.startsWith('### ')) {
            return <h3 key={idx} className="text-lg font-semibold mt-3 mb-1">{line.substring(4)}</h3>;
          } else if (line.startsWith('**') && line.endsWith('**')) {
            return <p key={idx} className="font-semibold mt-2">{line.replace(/\*\*/g, '')}</p>;
          } else if (line.startsWith('- ')) {
            return <li key={idx} className="ml-4">{line.substring(2)}</li>;
          } else if (line.startsWith('| ')) {
            return <p key={idx} className="font-mono text-sm">{line}</p>;
          } else if (line.trim().length > 0) {
            return <p key={idx} className="text-sm text-muted-foreground">{line}</p>;
          }
          return <br key={idx} />;
        })}
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5" />
          Advanced Insights & Analysis
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8">
            <TabsTrigger value="historical" className="text-xs">
              <TrendingUp className="w-3 h-3 mr-1" />
              History
            </TabsTrigger>
            <TabsTrigger value="meme" className="text-xs">
              <Zap className="w-3 h-3 mr-1" />
              Memes
            </TabsTrigger>
            <TabsTrigger value="network" className="text-xs">
              <Network className="w-3 h-3 mr-1" />
              Networks
            </TabsTrigger>
            <TabsTrigger value="risk" className="text-xs">
              <AlertTriangle className="w-3 h-3 mr-1" />
              Risks
            </TabsTrigger>
            <TabsTrigger value="execution" className="text-xs">
              <Play className="w-3 h-3 mr-1" />
              Plan
            </TabsTrigger>
            <TabsTrigger value="benchmark" className="text-xs">
              <BarChart3 className="w-3 h-3 mr-1" />
              Benchmark
            </TabsTrigger>
            <TabsTrigger value="branch" className="text-xs">
              <GitBranch className="w-3 h-3 mr-1" />
              Branch
            </TabsTrigger>
            <TabsTrigger value="tournament" className="text-xs">
              <Trophy className="w-3 h-3 mr-1" />
              Compete
            </TabsTrigger>
          </TabsList>

          <TabsContent value="historical" className="space-y-4 mt-4">
            <Alert>
              <TrendingUp className="w-4 h-4" />
              <AlertDescription>
                Historical pattern matching finds similar past scenarios and their actual outcomes.
              </AlertDescription>
            </Alert>
            {historicalPatterns.length > 0 ? (
              <div className="space-y-4">
                {renderMarkdown(historicalInsight)}
                <Separator />
                <div>
                  <h4 className="font-semibold mb-2">Matched Patterns</h4>
                  <div className="space-y-2">
                    {historicalPatterns.slice(0, 3).map(pattern => (
                      <div key={pattern.id} className="border rounded p-3">
                        <div className="flex justify-between items-start mb-2">
                          <span className="font-medium">{pattern.name}</span>
                          <Badge variant="secondary">{pattern.similarity}% match</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{pattern.description}</p>
                        <div className="mt-2 grid grid-cols-4 gap-2 text-xs">
                          <div>
                            <span className="text-muted-foreground">Reach: </span>
                            <span className="font-medium">{pattern.actualOutcomes.reach.toLocaleString()}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Conv: </span>
                            <span className="font-medium">{pattern.actualOutcomes.conversions.toLocaleString()}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Resonance: </span>
                            <span className="font-medium">{pattern.actualOutcomes.resonanceScore}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Viral: </span>
                            <span className="font-medium">{pattern.actualOutcomes.viralCoefficient}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-muted-foreground">No similar historical patterns found. This scenario is pioneering new territory!</p>
            )}
          </TabsContent>

          <TabsContent value="meme" className="space-y-4 mt-4">
            <Alert>
              <Zap className="w-4 h-4" />
              <AlertDescription>
                Meme velocity prediction analyzes remix potential and viral pathways across platforms.
              </AlertDescription>
            </Alert>
            {memeVelocity ? (
              <div className="space-y-4">
                {renderMarkdown(memeInsight)}
                <Separator />
                <div className="grid grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Meme Potential</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold">{memeVelocity.memePotentialScore}</div>
                      <div className="text-xs text-muted-foreground">out of 100</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Expected Remixes</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold">{memeVelocity.expectedRemixCount}</div>
                      <div className="text-xs text-muted-foreground">remixes</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Peak Day</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold">Day {memeVelocity.peakViralityDay}</div>
                      <div className="text-xs text-muted-foreground">peak virality</div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            ) : (
              <p className="text-muted-foreground">Run a simulation first to generate meme velocity predictions.</p>
            )}
          </TabsContent>

          <TabsContent value="network" className="space-y-4 mt-4">
            <Alert>
              <Network className="w-4 h-4" />
              <AlertDescription>
                Network effect modeling shows optimal launch sequencing across platforms for maximum cascade.
              </AlertDescription>
            </Alert>
            {networkSim ? (
              <div className="space-y-4">
                {renderMarkdown(networkInsight)}
                <Separator />
                <div>
                  <h4 className="font-semibold mb-2">Cascade Breakpoints</h4>
                  <div className="space-y-2">
                    {networkSim.cascadeBreakpoints.map((bp, idx) => (
                      <div key={idx} className="flex justify-between items-center p-2 border rounded">
                        <span className="font-medium">{bp.network}</span>
                        <div className="text-right">
                          <div className="text-sm">Need {bp.reachThreshold.toLocaleString()} reach</div>
                          <div className="text-xs text-muted-foreground">{bp.multiplierGained}x multiplier</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-muted-foreground">Run a simulation first to generate network effect predictions.</p>
            )}
          </TabsContent>

          <TabsContent value="risk" className="space-y-4 mt-4">
            <Alert variant={riskHeatMap && riskHeatMap.overallRiskScore > 60 ? "destructive" : "default"}>
              <AlertTriangle className="w-4 h-4" />
              <AlertDescription>
                Risk heat map identifies potential failure points and black swan scenarios.
              </AlertDescription>
            </Alert>
            {riskHeatMap ? (
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Risk Score</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold">{riskHeatMap.overallRiskScore}</div>
                      <div className="text-xs text-muted-foreground">out of 100</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Distribution</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-lg font-bold">{riskHeatMap.riskDistribution}</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Volatility</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold">{riskHeatMap.volatilityIndex}</div>
                      <div className="text-xs text-muted-foreground">out of 100</div>
                    </CardContent>
                  </Card>
                </div>
                {renderMarkdown(riskInsight)}
              </div>
            ) : (
              <p className="text-muted-foreground">Generating risk heat map...</p>
            )}
          </TabsContent>

          <TabsContent value="execution" className="space-y-4 mt-4">
            <Alert>
              <Play className="w-4 h-4" />
              <AlertDescription>
                Auto-generate execution plans ready for export to Action Router, Social Relay, or Drop Architect.
              </AlertDescription>
            </Alert>
            {!executionPlan ? (
              <Button onClick={handleGenerateExecutionPlan}>
                Generate Execution Plan
              </Button>
            ) : (
              <div className="space-y-4">
                {renderMarkdown(executionInsight)}
                <Separator />
                <div className="flex gap-2">
                  <Button onClick={handleExportPlan}>Export to Action Router</Button>
                  <Button variant="outline" onClick={() => navigator.clipboard.writeText(executionPlan.exportableFormat)}>
                    Copy to Clipboard
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="benchmark" className="space-y-4 mt-4">
            <Alert>
              <BarChart3 className="w-4 h-4" />
              <AlertDescription>
                Compare your scenario against community benchmarks from 150+ scenarios.
              </AlertDescription>
            </Alert>
            {benchmarkComparison ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Overall Performance</h3>
                  <Badge variant={
                    benchmarkComparison.overallPerformance === "top-tier" ? "default" :
                    benchmarkComparison.overallPerformance === "above-average" ? "secondary" :
                    "outline"
                  }>
                    {benchmarkComparison.overallPerformance}
                  </Badge>
                </div>
                {renderMarkdown(benchmarkInsight)}
              </div>
            ) : (
              <p className="text-muted-foreground">Run a simulation first to compare against benchmarks.</p>
            )}
          </TabsContent>

          <TabsContent value="branch" className="space-y-4 mt-4">
            <Alert>
              <GitBranch className="w-4 h-4" />
              <AlertDescription>
                Create scenario branches to explore alternative approaches collaboratively.
              </AlertDescription>
            </Alert>
            <p className="text-sm text-muted-foreground">
              Collaborative branching allows teams to fork scenarios and test different strategies (conservative vs. aggressive).
              Coming soon: full branch management UI.
            </p>
          </TabsContent>

          <TabsContent value="tournament" className="space-y-4 mt-4">
            <Alert>
              <Trophy className="w-4 h-4" />
              <AlertDescription>
                Enter live simulation tournaments and compete for prizes based on prediction accuracy.
              </AlertDescription>
            </Alert>
            <p className="text-sm text-muted-foreground">
              Weekly tournaments challenge you to design the highest-performing scenarios.
              Leaderboards track top strategists and award prizes for accuracy.
              Coming soon: tournament submission and leaderboard UI.
            </p>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
