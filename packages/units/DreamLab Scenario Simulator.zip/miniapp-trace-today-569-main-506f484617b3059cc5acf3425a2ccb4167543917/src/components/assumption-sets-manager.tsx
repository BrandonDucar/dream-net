'use client';

import { useState, useEffect } from 'react';
import type { AssumptionSet } from '@/types/simulation';
import {
  listAssumptionSets,
  createAssumptionSet,
  updateAssumptionSet,
  deleteAssumptionSet,
} from '@/lib/simulation-storage';
import { generateSEOForAssumptionSet } from '@/lib/seo-generator';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

export function AssumptionSetsManager() {
  const [assumptionSets, setAssumptionSets] = useState<AssumptionSet[]>([]);
  const [editingSet, setEditingSet] = useState<AssumptionSet | null>(null);
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);

  useEffect(() => {
    loadAssumptionSets();
  }, []);

  function loadAssumptionSets(): void {
    const sets = listAssumptionSets();
    setAssumptionSets(sets);
  }

  function handleCreate(): void {
    const seo = generateSEOForAssumptionSet('New Assumption Set', 'Default assumptions');
    setEditingSet({
      id: '',
      name: 'New Assumption Set',
      description: 'Default market conditions',
      baseReachFactor: 1.0,
      engagementFactor: 1.0,
      conversionFactor: 1.0,
      remixFactor: 1.0,
      fatigueFactor: 0.2,
      riskMultiplierHigh: 1.5,
      notes: '',
      tags: [],
      ...seo,
    });
    setDialogOpen(true);
  }

  function handleEdit(set: AssumptionSet): void {
    setEditingSet({ ...set });
    setDialogOpen(true);
  }

  function handleSave(): void {
    if (!editingSet) return;

    if (editingSet.id) {
      updateAssumptionSet(editingSet.id, editingSet);
    } else {
      createAssumptionSet(editingSet);
    }

    setDialogOpen(false);
    setEditingSet(null);
    loadAssumptionSets();
  }

  function handleDelete(id: string): void {
    if (confirm('Delete this assumption set? This cannot be undone.')) {
      deleteAssumptionSet(id);
      loadAssumptionSets();
    }
  }

  function updateField<K extends keyof AssumptionSet>(field: K, value: AssumptionSet[K]): void {
    if (!editingSet) return;
    setEditingSet({ ...editingSet, [field]: value });
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-2xl">Assumption Sets</CardTitle>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={handleCreate}>Create Assumption Set</Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>
                    {editingSet?.id ? 'Edit Assumption Set' : 'Create Assumption Set'}
                  </DialogTitle>
                </DialogHeader>
                {editingSet && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Name</Label>
                      <Input
                        value={editingSet.name}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('name', e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Description</Label>
                      <Textarea
                        value={editingSet.description}
                        onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                          updateField('description', e.target.value)
                        }
                        rows={3}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Base Reach Factor</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={editingSet.baseReachFactor}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                            updateField('baseReachFactor', parseFloat(e.target.value))
                          }
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Engagement Factor</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={editingSet.engagementFactor}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                            updateField('engagementFactor', parseFloat(e.target.value))
                          }
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Conversion Factor</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={editingSet.conversionFactor}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                            updateField('conversionFactor', parseFloat(e.target.value))
                          }
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Remix Factor</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={editingSet.remixFactor}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                            updateField('remixFactor', parseFloat(e.target.value))
                          }
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Fatigue Factor</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={editingSet.fatigueFactor}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                            updateField('fatigueFactor', parseFloat(e.target.value))
                          }
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Risk Multiplier (High)</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={editingSet.riskMultiplierHigh}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                            updateField('riskMultiplierHigh', parseFloat(e.target.value))
                          }
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Tags (comma-separated)</Label>
                      <Input
                        value={editingSet.tags.join(', ')}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                          updateField('tags', e.target.value.split(',').map((t: string) => t.trim()))
                        }
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Notes</Label>
                      <Textarea
                        value={editingSet.notes}
                        onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => updateField('notes', e.target.value)}
                        rows={3}
                      />
                    </div>

                    <div className="flex gap-2 justify-end">
                      <Button variant="outline" onClick={() => setDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleSave}>Save</Button>
                    </div>
                  </div>
                )}
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {assumptionSets.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              No assumption sets yet. Create one to define market conditions for scenarios.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Base Reach</TableHead>
                  <TableHead>Engagement</TableHead>
                  <TableHead>Conversion</TableHead>
                  <TableHead>Remix</TableHead>
                  <TableHead>Fatigue</TableHead>
                  <TableHead>Risk</TableHead>
                  <TableHead>Tags</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {assumptionSets.map((set: AssumptionSet) => (
                  <TableRow key={set.id}>
                    <TableCell className="font-medium">{set.name}</TableCell>
                    <TableCell>{set.baseReachFactor}x</TableCell>
                    <TableCell>{set.engagementFactor}x</TableCell>
                    <TableCell>{set.conversionFactor}x</TableCell>
                    <TableCell>{set.remixFactor}x</TableCell>
                    <TableCell>{set.fatigueFactor}</TableCell>
                    <TableCell>{set.riskMultiplierHigh}x</TableCell>
                    <TableCell>
                      <div className="flex gap-1 flex-wrap">
                        {set.tags.map((tag: string) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button size="sm" variant="ghost" onClick={() => handleEdit(set)}>
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDelete(set.id)}
                        >
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
