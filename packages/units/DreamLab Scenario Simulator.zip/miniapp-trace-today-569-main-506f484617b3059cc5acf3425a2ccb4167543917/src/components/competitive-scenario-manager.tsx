'use client'
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Plus, Trash2, AlertCircle } from 'lucide-react';
import type { CompetitorAction } from '@/types/advanced-features';
import { simulateCompetitiveScenario, generateCompetitiveInsight } from '@/lib/competitive-engine';

interface CompetitiveScenarioManagerProps {
  scenarioId: string;
}

export function CompetitiveScenarioManager({ scenarioId }: CompetitiveScenarioManagerProps) {
  const [competitors, setCompetitors] = useState<CompetitorAction[]>([]);
  const [insight, setInsight] = useState<string>('');
  const [showForm, setShowForm] = useState<boolean>(false);
  
  // Form state
  const [competitorName, setCompetitorName] = useState<string>('');
  const [actionType, setActionType] = useState<"token-launch" | "drop" | "campaign" | "content-blitz" | "other">('campaign');
  const [timing, setTiming] = useState<"same-week" | "overlap" | "before" | "after">('same-week');
  const [estimatedImpact, setEstimatedImpact] = useState<"low" | "medium" | "high" | "critical">('medium');
  const [marketShareImpact, setMarketShareImpact] = useState<number>(10);
  const [notes, setNotes] = useState<string>('');

  function handleAddCompetitor(): void {
    const newCompetitor: CompetitorAction = {
      id: `comp-${Date.now()}`,
      competitorName,
      actionType,
      timing,
      estimatedImpact,
      marketShareImpact,
      notes,
    };
    
    setCompetitors([...competitors, newCompetitor]);
    
    // Reset form
    setCompetitorName('');
    setActionType('campaign');
    setTiming('same-week');
    setEstimatedImpact('medium');
    setMarketShareImpact(10);
    setNotes('');
    setShowForm(false);
  }

  function handleRemoveCompetitor(id: string): void {
    setCompetitors(competitors.filter(c => c.id !== id));
  }

  function handleRunCompetitiveSimulation(): void {
    const result = simulateCompetitiveScenario(scenarioId, competitors);
    if (result) {
      const insightText = generateCompetitiveInsight(result);
      setInsight(insightText);
    }
  }

  function renderMarkdown(text: string): JSX.Element {
    const lines = text.split('\n');
    return (
      <div className="space-y-2">
        {lines.map((line, idx) => {
          if (line.startsWith('## ')) {
            return <h2 key={idx} className="text-xl font-bold mt-4 mb-2">{line.substring(3)}</h2>;
          } else if (line.startsWith('**') && line.endsWith(':**')) {
            return <p key={idx} className="font-semibold mt-2">{line.replace(/\*\*/g, '')}</p>;
          } else if (line.startsWith('- ')) {
            return <li key={idx} className="ml-4">{line.substring(2)}</li>;
          } else if (line.trim().length > 0) {
            return <p key={idx} className="text-sm text-muted-foreground">{line}</p>;
          }
          return <br key={idx} />;
        })}
      </div>
    );
  }

  const impactColors = {
    low: "bg-green-100 text-green-800",
    medium: "bg-yellow-100 text-yellow-800",
    high: "bg-orange-100 text-orange-800",
    critical: "bg-red-100 text-red-800",
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          Competitive Simulation
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <p className="text-sm text-muted-foreground mb-4">
            Model what happens if competitors launch during your time window. Adjust projections based on market saturation and timing conflicts.
          </p>
          
          {competitors.length > 0 && (
            <div className="space-y-2 mb-4">
              {competitors.map(comp => (
                <div key={comp.id} className="border rounded p-3 flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium">{comp.competitorName}</span>
                      <Badge variant="outline">{comp.actionType}</Badge>
                      <Badge className={impactColors[comp.estimatedImpact]}>{comp.estimatedImpact} impact</Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Timing: {comp.timing} · Market share impact: {comp.marketShareImpact}%
                    </div>
                    {comp.notes && <p className="text-xs mt-1">{comp.notes}</p>}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleRemoveCompetitor(comp.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          {!showForm ? (
            <Button variant="outline" onClick={() => setShowForm(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Competitor
            </Button>
          ) : (
            <div className="border rounded p-4 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Competitor Name</Label>
                  <Input
                    value={competitorName}
                    onChange={(e) => setCompetitorName(e.target.value)}
                    placeholder="e.g., TokenX Launch"
                  />
                </div>
                <div>
                  <Label>Action Type</Label>
                  <Select value={actionType} onValueChange={(val: "token-launch" | "drop" | "campaign" | "content-blitz" | "other") => setActionType(val)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="token-launch">Token Launch</SelectItem>
                      <SelectItem value="drop">Drop</SelectItem>
                      <SelectItem value="campaign">Campaign</SelectItem>
                      <SelectItem value="content-blitz">Content Blitz</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Timing</Label>
                  <Select value={timing} onValueChange={(val: "same-week" | "overlap" | "before" | "after") => setTiming(val)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="same-week">Same Week</SelectItem>
                      <SelectItem value="overlap">Overlapping</SelectItem>
                      <SelectItem value="before">Before</SelectItem>
                      <SelectItem value="after">After</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Estimated Impact</Label>
                  <Select value={estimatedImpact} onValueChange={(val: "low" | "medium" | "high" | "critical") => setEstimatedImpact(val)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="col-span-2">
                  <Label>Market Share Impact (%)</Label>
                  <Input
                    type="number"
                    value={marketShareImpact}
                    onChange={(e) => setMarketShareImpact(Number(e.target.value))}
                    min={0}
                    max={100}
                  />
                </div>
                <div className="col-span-2">
                  <Label>Notes</Label>
                  <Textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Additional context about this competitor..."
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={handleAddCompetitor}>Add</Button>
                <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
              </div>
            </div>
          )}
        </div>

        {competitors.length > 0 && (
          <>
            <Button onClick={handleRunCompetitiveSimulation} className="w-full">
              Run Competitive Simulation
            </Button>

            {insight && (
              <>
                <Separator />
                <div>{renderMarkdown(insight)}</div>
              </>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
