'use client';

import { useState, useEffect } from 'react';
import type { Scenario, AssumptionSet, SimulationModel } from '@/types/simulation';
import {
  createScenario,
  listAssumptionSets,
  listSimulationModels,
} from '@/lib/simulation-storage';
import { generateSEOForScenario } from '@/lib/seo-generator';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface CreateScenarioDialogProps {
  open: boolean;
  onClose: () => void;
  onCreated: (scenarioId: string) => void;
}

export function CreateScenarioDialog({
  open,
  onClose,
  onCreated,
}: CreateScenarioDialogProps) {
  const [name, setName] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [category, setCategory] = useState<string>('');
  const [assumptionSetId, setAssumptionSetId] = useState<string>('');
  const [simulationModelId, setSimulationModelId] = useState<string>('');

  const [assumptionSets, setAssumptionSets] = useState<AssumptionSet[]>([]);
  const [models, setModels] = useState<SimulationModel[]>([]);

  useEffect(() => {
    if (open) {
      const sets = listAssumptionSets();
      const mods = listSimulationModels();
      setAssumptionSets(sets);
      setModels(mods);

      if (sets.length > 0 && !assumptionSetId) {
        setAssumptionSetId(sets[0].id);
      }
      if (mods.length > 0 && !simulationModelId) {
        setSimulationModelId(mods[0].id);
      }
    }
  }, [open]);

  function handleCreate(): void {
    if (!name || !category || !assumptionSetId || !simulationModelId) {
      alert('Please fill in all required fields');
      return;
    }

    const seo = generateSEOForScenario(name, description, category);

    const scenario = createScenario({
      name,
      description,
      category,
      priorityLevel: 'medium',
      simObjectIds: [],
      assumptionSetId,
      simulationModelId,
      timeWindowStart: null,
      timeWindowEnd: null,
      tags: [],
      notes: '',
      status: 'draft',
      ...seo,
      primaryGeoTargets: [],
      scenarioIntroLocalized: {},
      tagsLocalized: {},
    });

    onCreated(scenario.id);
    resetForm();
    onClose();
  }

  function resetForm(): void {
    setName('');
    setDescription('');
    setCategory('');
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Create New Scenario</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>
              Name <span className="text-red-500">*</span>
            </Label>
            <Input
              value={name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
              placeholder="e.g., DREAM + Jaggy Drop Next Week"
            />
          </div>

          <div className="space-y-2">
            <Label>
              Category <span className="text-red-500">*</span>
            </Label>
            <Input
              value={category}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCategory(e.target.value)}
              placeholder="e.g., culture-launch, pickleball, maintenance"
            />
          </div>

          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea
              value={description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
              rows={4}
              placeholder="What are you testing with this scenario?"
            />
          </div>

          <div className="space-y-2">
            <Label>
              Assumption Set <span className="text-red-500">*</span>
            </Label>
            {assumptionSets.length === 0 ? (
              <div className="text-sm text-muted-foreground">
                No assumption sets available. Create one first.
              </div>
            ) : (
              <Select value={assumptionSetId} onValueChange={setAssumptionSetId}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {assumptionSets.map((set: AssumptionSet) => (
                    <SelectItem key={set.id} value={set.id}>
                      {set.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>

          <div className="space-y-2">
            <Label>
              Simulation Model <span className="text-red-500">*</span>
            </Label>
            {models.length === 0 ? (
              <div className="text-sm text-muted-foreground">
                No simulation models available. Create one first.
              </div>
            ) : (
              <Select value={simulationModelId} onValueChange={setSimulationModelId}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {models.map((model: SimulationModel) => (
                    <SelectItem key={model.id} value={model.id}>
                      {model.name} ({model.version})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>

          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleCreate}>Create Scenario</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
