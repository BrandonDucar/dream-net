'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';

interface ExportReportDialogProps {
  open: boolean;
  onClose: () => void;
  report: string;
  title: string;
}

export function ExportReportDialog({
  open,
  onClose,
  report,
  title,
}: ExportReportDialogProps) {
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    if (!open) {
      setCopied(false);
    }
  }, [open]);

  function handleCopy(): void {
    navigator.clipboard.writeText(report);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <Textarea
            value={report}
            readOnly
            className="font-mono text-xs h-[60vh] resize-none"
          />
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
            <Button onClick={handleCopy}>{copied ? 'Copied!' : 'Copy All'}</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
