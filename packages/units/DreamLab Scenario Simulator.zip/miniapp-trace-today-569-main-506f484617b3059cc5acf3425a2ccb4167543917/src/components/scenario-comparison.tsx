'use client';

import { useState, useEffect } from 'react';
import type { Scenario, ScenarioRunResult } from '@/types/simulation';
import { getScenario, getLatestScenarioRunResult } from '@/lib/simulation-storage';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { compareScenarios } from '@/lib/simulation-engine';

interface ScenarioComparisonProps {
  scenarioIds: string[];
  onBack: () => void;
}

export function ScenarioComparison({ scenarioIds, onBack }: ScenarioComparisonProps) {
  const [comparisons, setComparisons] = useState<
    Array<{
      scenarioId: string;
      scenarioName: string;
      latestResult: ScenarioRunResult | null;
    }>
  >([]);
  const [summary, setSummary] = useState<string>('');

  useEffect(() => {
    loadComparison();
  }, [scenarioIds]);

  function loadComparison(): void {
    const data = scenarioIds.map((id: string) => {
      const scenario = getScenario(id);
      if (!scenario) return null;

      const latestResult = getLatestScenarioRunResult(id);

      return {
        scenarioId: id,
        scenarioName: scenario.name,
        latestResult,
      };
    }).filter((item): item is { scenarioId: string; scenarioName: string; latestResult: ScenarioRunResult | null } => item !== null);

    setComparisons(data);

    const comparisonResult = compareScenarios(scenarioIds);
    if (comparisonResult) {
      setSummary(comparisonResult.summary);
    }
  }

  const allMetricKeys = Array.from(
    new Set(
      comparisons.flatMap((c) =>
        c.latestResult ? Object.keys(c.latestResult.outputMetrics) : []
      )
    )
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <Button onClick={onBack} variant="outline">
          ← Back to Dashboard
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Scenario Comparison</CardTitle>
          <div className="text-sm text-muted-foreground">
            Comparing {comparisons.length} scenarios
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {comparisons.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              No scenarios selected for comparison
            </div>
          ) : (
            <>
              <div className="border rounded-lg overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="font-semibold">Scenario</TableHead>
                      {allMetricKeys.map((key: string) => (
                        <TableHead key={key} className="text-center">
                          {key}
                        </TableHead>
                      ))}
                      <TableHead className="text-center">Run Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {comparisons.map((comp) => (
                      <TableRow key={comp.scenarioId}>
                        <TableCell className="font-medium">{comp.scenarioName}</TableCell>
                        {allMetricKeys.map((key: string) => {
                          const value = comp.latestResult?.outputMetrics[key];
                          const allValues = comparisons
                            .map((c) => c.latestResult?.outputMetrics[key] || 0)
                            .filter((v: number) => v > 0);
                          const maxValue = Math.max(...allValues);
                          const isMax = value === maxValue && value && value > 0;

                          return (
                            <TableCell key={key} className="text-center">
                              {value !== undefined ? (
                                <span
                                  className={
                                    isMax ? 'font-bold text-green-600' : ''
                                  }
                                >
                                  {typeof value === 'number'
                                    ? value.toLocaleString()
                                    : value}
                                </span>
                              ) : (
                                <span className="text-muted-foreground">N/A</span>
                              )}
                            </TableCell>
                          );
                        })}
                        <TableCell className="text-center text-sm text-muted-foreground">
                          {comp.latestResult
                            ? new Date(comp.latestResult.runAt).toLocaleDateString()
                            : 'Not run'}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {summary && (
                <Card className="bg-blue-50 border-blue-200">
                  <CardHeader>
                    <CardTitle className="text-lg">Comparison Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="prose prose-sm max-w-none whitespace-pre-wrap">
                      {summary}
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="grid grid-cols-1 gap-4">
                {comparisons.map((comp) => {
                  if (!comp.latestResult) return null;

                  return (
                    <Card key={comp.scenarioId}>
                      <CardHeader>
                        <CardTitle className="text-base">{comp.scenarioName}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div>
                          <strong className="text-sm">Narrative Summary:</strong>
                          <div className="mt-1 text-sm text-muted-foreground whitespace-pre-wrap">
                            {comp.latestResult.narrativeSummary}
                          </div>
                        </div>

                        <div>
                          <strong className="text-sm">Risk Notes:</strong>
                          <div className="mt-1 text-sm text-muted-foreground">
                            {comp.latestResult.riskNotes}
                          </div>
                        </div>

                        <div>
                          <strong className="text-sm">Recommended Actions:</strong>
                          <ul className="mt-1 list-disc list-inside text-sm text-muted-foreground">
                            {comp.latestResult.recommendedActions.map((action: string, idx: number) => (
                              <li key={idx}>{action}</li>
                            ))}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
