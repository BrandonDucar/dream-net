'use client';

import { useState, useEffect } from 'react';
import type { Scenario, SimulationModel, AssumptionSet } from '@/types/simulation';
import {
  listScenarios,
  getSimulationModel,
  getAssumptionSet,
} from '@/lib/simulation-storage';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface ScenarioDashboardProps {
  onCreateScenario: () => void;
  onViewScenario: (scenarioId: string) => void;
  onCompareScenarios: (scenarioIds: string[]) => void;
  onExportPlaybook: () => void;
}

export function ScenarioDashboard({
  onCreateScenario,
  onViewScenario,
  onCompareScenarios,
  onExportPlaybook,
}: ScenarioDashboardProps) {
  const [scenarios, setScenarios] = useState<Scenario[]>([]);
  const [filteredScenarios, setFilteredScenarios] = useState<Scenario[]>([]);
  const [searchText, setSearchText] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [selectedScenarios, setSelectedScenarios] = useState<Set<string>>(new Set());

  useEffect(() => {
    loadScenarios();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [scenarios, searchText, statusFilter, categoryFilter]);

  function loadScenarios(): void {
    const allScenarios = listScenarios();
    setScenarios(allScenarios);
  }

  function applyFilters(): void {
    let filtered = [...scenarios];

    if (searchText) {
      const search = searchText.toLowerCase();
      filtered = filtered.filter(
        (s: Scenario) =>
          s.name.toLowerCase().includes(search) ||
          s.description.toLowerCase().includes(search) ||
          s.tags.some((tag: string) => tag.toLowerCase().includes(search))
      );
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter((s: Scenario) => s.status === statusFilter);
    }

    if (categoryFilter !== 'all') {
      filtered = filtered.filter((s: Scenario) => s.category === categoryFilter);
    }

    setFilteredScenarios(filtered);
  }

  function toggleScenarioSelection(scenarioId: string): void {
    const newSelected = new Set(selectedScenarios);
    if (newSelected.has(scenarioId)) {
      newSelected.delete(scenarioId);
    } else {
      newSelected.add(scenarioId);
    }
    setSelectedScenarios(newSelected);
  }

  function handleCompare(): void {
    if (selectedScenarios.size < 2) {
      alert('Please select at least 2 scenarios to compare');
      return;
    }
    onCompareScenarios(Array.from(selectedScenarios));
  }

  const categories = Array.from(new Set(scenarios.map((s: Scenario) => s.category)));

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Scenario Dashboard</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4 flex-wrap">
            <Input
              placeholder="Search scenarios..."
              value={searchText}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchText(e.target.value)}
              className="max-w-xs"
            />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="ready">Ready</SelectItem>
                <SelectItem value="run">Run</SelectItem>
                <SelectItem value="archived">Archived</SelectItem>
              </SelectContent>
            </Select>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map((cat: string) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-2">
            <Button onClick={onCreateScenario}>Create Scenario</Button>
            <Button
              onClick={handleCompare}
              disabled={selectedScenarios.size < 2}
              variant="outline"
            >
              Compare Selected ({selectedScenarios.size})
            </Button>
            <Button onClick={onExportPlaybook} variant="outline">
              Export Simulation Playbook
            </Button>
          </div>

          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">Select</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Model</TableHead>
                  <TableHead>Time Window</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredScenarios.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground">
                      No scenarios found. Create your first scenario to get started.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredScenarios.map((scenario: Scenario) => {
                    const model = getSimulationModel(scenario.simulationModelId);
                    const assumptions = getAssumptionSet(scenario.assumptionSetId);

                    return (
                      <TableRow key={scenario.id}>
                        <TableCell>
                          <input
                            type="checkbox"
                            checked={selectedScenarios.has(scenario.id)}
                            onChange={() => toggleScenarioSelection(scenario.id)}
                            className="w-4 h-4"
                          />
                        </TableCell>
                        <TableCell className="font-medium">{scenario.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{scenario.category}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              scenario.status === 'run'
                                ? 'default'
                                : scenario.status === 'ready'
                                ? 'secondary'
                                : 'outline'
                            }
                          >
                            {scenario.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              scenario.priorityLevel === 'critical'
                                ? 'destructive'
                                : scenario.priorityLevel === 'high'
                                ? 'default'
                                : 'outline'
                            }
                          >
                            {scenario.priorityLevel}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">
                          {model?.name || 'N/A'}
                          <br />
                          <span className="text-xs text-muted-foreground">
                            {assumptions?.name || 'N/A'}
                          </span>
                        </TableCell>
                        <TableCell className="text-sm">
                          {scenario.timeWindowStart && scenario.timeWindowEnd
                            ? `${new Date(scenario.timeWindowStart).toLocaleDateString()} - ${new Date(scenario.timeWindowEnd).toLocaleDateString()}`
                            : 'Not set'}
                        </TableCell>
                        <TableCell>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => onViewScenario(scenario.id)}
                          >
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
