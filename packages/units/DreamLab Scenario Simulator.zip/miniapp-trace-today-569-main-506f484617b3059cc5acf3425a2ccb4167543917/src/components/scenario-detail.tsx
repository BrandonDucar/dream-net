'use client';

import { useState, useEffect } from 'react';
import type {
  Scenario,
  SimObjectRef,
  AssumptionSet,
  SimulationModel,
  ScenarioInput,
  ScenarioRunResult,
  GeoTarget,
  PriorityLevel,
  ScenarioStatus,
} from '@/types/simulation';
import {
  getScenario,
  updateScenario,
  getSimObjectRef,
  listSimObjectRefs,
  getAssumptionSet,
  listAssumptionSets,
  getSimulationModel,
  listSimulationModels,
  attachObjectToScenario,
  removeObjectFromScenario,
  getScenarioInputs,
  setScenarioInput,
  deleteScenarioInput,
  getScenarioRunResults,
  assignGeoTargetsToScenario,
} from '@/lib/simulation-storage';
import { runScenarioSimulation } from '@/lib/simulation-engine';
import { generateSEOForScenario } from '@/lib/seo-generator';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { AdvancedInsightsPanel } from './advanced-insights-panel';
import { CompetitiveScenarioManager } from './competitive-scenario-manager';

interface ScenarioDetailProps {
  scenarioId: string;
  onBack: () => void;
  onExportReport: (scenarioId: string) => void;
}

export function ScenarioDetail({ scenarioId, onBack, onExportReport }: ScenarioDetailProps) {
  const [scenario, setScenario] = useState<Scenario | null>(null);
  const [objects, setObjects] = useState<SimObjectRef[]>([]);
  const [assumptions, setAssumptions] = useState<AssumptionSet | null>(null);
  const [model, setModel] = useState<SimulationModel | null>(null);
  const [inputs, setInputs] = useState<ScenarioInput[]>([]);
  const [runResults, setRunResults] = useState<ScenarioRunResult[]>([]);
  const [editing, setEditing] = useState<boolean>(false);

  useEffect(() => {
    loadScenarioData();
  }, [scenarioId]);

  function loadScenarioData(): void {
    const s = getScenario(scenarioId);
    if (!s) return;

    setScenario(s);

    const objs = s.simObjectIds
      .map((id: string) => getSimObjectRef(id))
      .filter((obj: SimObjectRef | null): obj is SimObjectRef => obj !== null);
    setObjects(objs);

    const ass = getAssumptionSet(s.assumptionSetId);
    setAssumptions(ass);

    const mod = getSimulationModel(s.simulationModelId);
    setModel(mod);

    const inp = getScenarioInputs(scenarioId);
    setInputs(inp);

    const results = getScenarioRunResults(scenarioId);
    setRunResults(results);
  }

  function handleUpdate(field: keyof Omit<Scenario, 'id'>, value: unknown): void {
    if (!scenario) return;
    const updated = updateScenario(scenarioId, { [field]: value });
    if (updated) {
      setScenario(updated);
    }
  }

  function handleRunSimulation(): void {
    const result = runScenarioSimulation(scenarioId);
    if (result) {
      loadScenarioData();
      alert('Simulation complete!');
    } else {
      alert('Simulation failed. Check configuration.');
    }
  }

  function handleAttachObject(objectId: string): void {
    attachObjectToScenario(scenarioId, objectId);
    loadScenarioData();
  }

  function handleRemoveObject(objectId: string): void {
    removeObjectFromScenario(scenarioId, objectId);
    loadScenarioData();
  }

  function handleAddInput(): void {
    const key = prompt('Input key (e.g., plannedPosts, baseAudience):');
    if (!key) return;

    const valueNum = prompt('Numeric value (leave empty if text):');
    const valueText = prompt('Text value (leave empty if numeric):');
    const notes = prompt('Notes (optional):') || '';

    setScenarioInput(
      scenarioId,
      key,
      valueNum ? parseFloat(valueNum) : null,
      valueText || null,
      notes
    );
    loadScenarioData();
  }

  function handleDeleteInput(inputId: string): void {
    if (confirm('Delete this input?')) {
      deleteScenarioInput(inputId);
      loadScenarioData();
    }
  }

  function handleRegenerateSEO(): void {
    if (!scenario) return;
    const seo = generateSEOForScenario(scenario.name, scenario.description, scenario.category);
    const updated = updateScenario(scenarioId, { ...seo });
    if (updated) {
      setScenario(updated);
      alert('SEO regenerated!');
    }
  }

  function handleAddGeoTarget(): void {
    const region = prompt('Region:') || '';
    const country = prompt('Country:') || '';
    const cityOrMarket = prompt('City/Market:') || '';
    const language = prompt('Language:') || '';

    const newGeo: GeoTarget = {
      id: `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      region,
      country,
      cityOrMarket,
      language,
    };

    const current = scenario?.primaryGeoTargets || [];
    assignGeoTargetsToScenario(scenarioId, [...current, newGeo]);
    loadScenarioData();
  }

  if (!scenario) {
    return <div className="p-6">Scenario not found</div>;
  }

  const allObjects = listSimObjectRefs();
  const unattachedObjects = allObjects.filter(
    (o: SimObjectRef) => !scenario.simObjectIds.includes(o.id)
  );

  const allAssumptions = listAssumptionSets();
  const allModels = listSimulationModels();

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <Button onClick={onBack} variant="outline">
          ← Back to Dashboard
        </Button>
        <div className="flex gap-2">
          <Button onClick={() => setEditing(!editing)} variant="outline">
            {editing ? 'View Mode' : 'Edit Mode'}
          </Button>
          <Button onClick={() => onExportReport(scenarioId)} variant="outline">
            Export Report
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">{scenario.name}</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="info" className="w-full">
            <TabsList className="grid w-full grid-cols-7">
              <TabsTrigger value="info">Info</TabsTrigger>
              <TabsTrigger value="objects">Objects</TabsTrigger>
              <TabsTrigger value="assumptions">Assumptions & Model</TabsTrigger>
              <TabsTrigger value="inputs">Inputs</TabsTrigger>
              <TabsTrigger value="runs">Runs</TabsTrigger>
              <TabsTrigger value="advanced">Advanced</TabsTrigger>
              <TabsTrigger value="competitive">Competitive</TabsTrigger>
            </TabsList>

            <TabsContent value="info" className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Name</Label>
                  {editing ? (
                    <Input
                      value={scenario.name}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleUpdate('name', e.target.value)}
                    />
                  ) : (
                    <div className="p-2 border rounded">{scenario.name}</div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label>Category</Label>
                  {editing ? (
                    <Input
                      value={scenario.category}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleUpdate('category', e.target.value)}
                    />
                  ) : (
                    <div className="p-2 border rounded">{scenario.category}</div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label>Status</Label>
                  {editing ? (
                    <Select
                      value={scenario.status}
                      onValueChange={(value: ScenarioStatus) => handleUpdate('status', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="ready">Ready</SelectItem>
                        <SelectItem value="run">Run</SelectItem>
                        <SelectItem value="archived">Archived</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <div className="p-2 border rounded">{scenario.status}</div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label>Priority</Label>
                  {editing ? (
                    <Select
                      value={scenario.priorityLevel}
                      onValueChange={(value: PriorityLevel) => handleUpdate('priorityLevel', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <div className="p-2 border rounded">{scenario.priorityLevel}</div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label>Time Window Start</Label>
                  {editing ? (
                    <Input
                      type="date"
                      value={scenario.timeWindowStart ? scenario.timeWindowStart.split('T')[0] : ''}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                        handleUpdate('timeWindowStart', e.target.value ? new Date(e.target.value).toISOString() : null)
                      }
                    />
                  ) : (
                    <div className="p-2 border rounded">
                      {scenario.timeWindowStart
                        ? new Date(scenario.timeWindowStart).toLocaleDateString()
                        : 'Not set'}
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label>Time Window End</Label>
                  {editing ? (
                    <Input
                      type="date"
                      value={scenario.timeWindowEnd ? scenario.timeWindowEnd.split('T')[0] : ''}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                        handleUpdate('timeWindowEnd', e.target.value ? new Date(e.target.value).toISOString() : null)
                      }
                    />
                  ) : (
                    <div className="p-2 border rounded">
                      {scenario.timeWindowEnd
                        ? new Date(scenario.timeWindowEnd).toLocaleDateString()
                        : 'Not set'}
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Description</Label>
                {editing ? (
                  <Textarea
                    value={scenario.description}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => handleUpdate('description', e.target.value)}
                    rows={4}
                  />
                ) : (
                  <div className="p-2 border rounded whitespace-pre-wrap">{scenario.description}</div>
                )}
              </div>

              <div className="space-y-2">
                <Label>Tags (comma-separated)</Label>
                {editing ? (
                  <Input
                    value={scenario.tags.join(', ')}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleUpdate('tags', e.target.value.split(',').map((t: string) => t.trim()))}
                  />
                ) : (
                  <div className="flex gap-2 flex-wrap">
                    {scenario.tags.map((tag: string) => (
                      <Badge key={tag} variant="secondary">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              <Separator />

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold">SEO Metadata</h3>
                  <Button onClick={handleRegenerateSEO} size="sm" variant="outline">
                    Regenerate SEO
                  </Button>
                </div>

                <div className="space-y-2">
                  <Label>SEO Title</Label>
                  <Input
                    value={scenario.seoTitle}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleUpdate('seoTitle', e.target.value)}
                    disabled={!editing}
                  />
                </div>

                <div className="space-y-2">
                  <Label>SEO Description</Label>
                  <Textarea
                    value={scenario.seoDescription}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => handleUpdate('seoDescription', e.target.value)}
                    disabled={!editing}
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Keywords (comma-separated)</Label>
                  <Input
                    value={scenario.seoKeywords.join(', ')}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      handleUpdate('seoKeywords', e.target.value.split(',').map((k: string) => k.trim()))
                    }
                    disabled={!editing}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Hashtags (comma-separated)</Label>
                  <Input
                    value={scenario.seoHashtags.join(', ')}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      handleUpdate('seoHashtags', e.target.value.split(',').map((h: string) => h.trim()))
                    }
                    disabled={!editing}
                  />
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold">Geo Targeting</h3>
                  {editing && (
                    <Button onClick={handleAddGeoTarget} size="sm" variant="outline">
                      Add Geo Target
                    </Button>
                  )}
                </div>

                {scenario.primaryGeoTargets.length > 0 ? (
                  <div className="space-y-2">
                    {scenario.primaryGeoTargets.map((geo: GeoTarget) => (
                      <div key={geo.id} className="p-3 border rounded">
                        <div className="grid grid-cols-4 gap-2 text-sm">
                          <div>
                            <strong>Region:</strong> {geo.region}
                          </div>
                          <div>
                            <strong>Country:</strong> {geo.country}
                          </div>
                          <div>
                            <strong>City:</strong> {geo.cityOrMarket}
                          </div>
                          <div>
                            <strong>Language:</strong> {geo.language}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-muted-foreground">No geo targets configured</div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="objects" className="space-y-4 mt-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Attached Objects ({objects.length})</h3>
              </div>

              {objects.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Type</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Source App</TableHead>
                      <TableHead>Tags</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {objects.map((obj: SimObjectRef) => (
                      <TableRow key={obj.id}>
                        <TableCell>
                          <Badge>{obj.type}</Badge>
                        </TableCell>
                        <TableCell className="font-medium">{obj.name}</TableCell>
                        <TableCell>{obj.sourceApp || 'N/A'}</TableCell>
                        <TableCell>
                          <div className="flex gap-1 flex-wrap">
                            {obj.tags.map((tag: string) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell>
                          {editing && (
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleRemoveObject(obj.id)}
                            >
                              Remove
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-muted-foreground">No objects attached</div>
              )}

              {editing && unattachedObjects.length > 0 && (
                <>
                  <Separator />
                  <div className="space-y-2">
                    <h3 className="text-lg font-semibold">Available Objects</h3>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Type</TableHead>
                          <TableHead>Name</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {unattachedObjects.map((obj: SimObjectRef) => (
                          <TableRow key={obj.id}>
                            <TableCell>
                              <Badge>{obj.type}</Badge>
                            </TableCell>
                            <TableCell>{obj.name}</TableCell>
                            <TableCell>
                              <Button size="sm" onClick={() => handleAttachObject(obj.id)}>
                                Attach
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </>
              )}
            </TabsContent>

            <TabsContent value="assumptions" className="space-y-4 mt-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Assumption Set</Label>
                  {editing ? (
                    <Select
                      value={scenario.assumptionSetId}
                      onValueChange={(value: string) => handleUpdate('assumptionSetId', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {allAssumptions.map((ass: AssumptionSet) => (
                          <SelectItem key={ass.id} value={ass.id}>
                            {ass.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  ) : (
                    <div className="p-2 border rounded">{assumptions?.name || 'Not set'}</div>
                  )}
                </div>

                {assumptions && (
                  <div className="p-4 border rounded space-y-2">
                    <h4 className="font-semibold">{assumptions.name}</h4>
                    <p className="text-sm text-muted-foreground">{assumptions.description}</p>
                    <div className="grid grid-cols-3 gap-4 text-sm mt-3">
                      <div>
                        <strong>Base Reach:</strong> {assumptions.baseReachFactor}x
                      </div>
                      <div>
                        <strong>Engagement:</strong> {assumptions.engagementFactor}x
                      </div>
                      <div>
                        <strong>Conversion:</strong> {assumptions.conversionFactor}x
                      </div>
                      <div>
                        <strong>Remix:</strong> {assumptions.remixFactor}x
                      </div>
                      <div>
                        <strong>Fatigue:</strong> {assumptions.fatigueFactor}
                      </div>
                      <div>
                        <strong>Risk Multiplier:</strong> {assumptions.riskMultiplierHigh}x
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <Separator />

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Simulation Model</Label>
                  {editing ? (
                    <Select
                      value={scenario.simulationModelId}
                      onValueChange={(value: string) => handleUpdate('simulationModelId', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {allModels.map((mod: SimulationModel) => (
                          <SelectItem key={mod.id} value={mod.id}>
                            {mod.name} ({mod.version})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  ) : (
                    <div className="p-2 border rounded">
                      {model?.name || 'Not set'} {model?.version && `(${model.version})`}
                    </div>
                  )}
                </div>

                {model && (
                  <div className="p-4 border rounded space-y-3">
                    <h4 className="font-semibold">{model.name}</h4>
                    <p className="text-sm text-muted-foreground">{model.description}</p>
                    <div>
                      <strong className="text-sm">Version:</strong> {model.version}
                    </div>
                    <div>
                      <strong className="text-sm">Applies To:</strong>{' '}
                      {model.appliesToTypes.join(', ')}
                    </div>
                    <div>
                      <strong className="text-sm">Input Metrics:</strong>{' '}
                      {model.inputMetrics.join(', ')}
                    </div>
                    <div>
                      <strong className="text-sm">Output Metrics:</strong>{' '}
                      {model.outputMetrics.join(', ')}
                    </div>
                    <div className="mt-3">
                      <strong className="text-sm">How it works:</strong>
                      <p className="text-sm mt-1 text-muted-foreground whitespace-pre-wrap">
                        {model.heuristicDescription}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="inputs" className="space-y-4 mt-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Scenario Inputs ({inputs.length})</h3>
                {editing && (
                  <Button onClick={handleAddInput} size="sm">
                    Add Input
                  </Button>
                )}
              </div>

              {inputs.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Key</TableHead>
                      <TableHead>Numeric Value</TableHead>
                      <TableHead>Text Value</TableHead>
                      <TableHead>Notes</TableHead>
                      {editing && <TableHead>Actions</TableHead>}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {inputs.map((input: ScenarioInput) => (
                      <TableRow key={input.id}>
                        <TableCell className="font-medium">{input.key}</TableCell>
                        <TableCell>{input.valueNumber ?? 'N/A'}</TableCell>
                        <TableCell>{input.valueText || 'N/A'}</TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {input.notes}
                        </TableCell>
                        {editing && (
                          <TableCell>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDeleteInput(input.id)}
                            >
                              Delete
                            </Button>
                          </TableCell>
                        )}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-muted-foreground">
                  No inputs configured. Add inputs like plannedPosts, baseAudience, etc.
                </div>
              )}
            </TabsContent>

            <TabsContent value="runs" className="space-y-4 mt-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Simulation Runs ({runResults.length})</h3>
                <Button onClick={handleRunSimulation}>Run Simulation</Button>
              </div>

              {runResults.length > 0 ? (
                <div className="space-y-4">
                  {runResults.map((result: ScenarioRunResult) => (
                    <Card key={result.id}>
                      <CardHeader>
                        <div className="flex justify-between items-center">
                          <CardTitle className="text-base">
                            Run: {new Date(result.runAt).toLocaleString()}
                          </CardTitle>
                          <Badge variant="outline">Model: {result.modelVersion}</Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <h4 className="font-semibold mb-2">Output Metrics</h4>
                          <div className="grid grid-cols-4 gap-4 text-sm">
                            {Object.entries(result.outputMetrics).map(([key, value]: [string, number]) => (
                              <div key={key} className="p-2 border rounded">
                                <div className="text-muted-foreground">{key}</div>
                                <div className="font-semibold text-lg">{value.toLocaleString()}</div>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2">Narrative Summary</h4>
                          <div className="p-3 bg-muted rounded text-sm whitespace-pre-wrap">
                            {result.narrativeSummary}
                          </div>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2">Risk Notes</h4>
                          <div className="p-3 bg-yellow-50 border border-yellow-200 rounded text-sm">
                            {result.riskNotes}
                          </div>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2">Recommended Actions</h4>
                          <ul className="list-disc list-inside space-y-1 text-sm">
                            {result.recommendedActions.map((action: string, idx: number) => (
                              <li key={idx}>{action}</li>
                            ))}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-muted-foreground">
                  No simulation runs yet. Click "Run Simulation" to generate predictions.
                </div>
              )}
            </TabsContent>

            <TabsContent value="advanced" className="space-y-4 mt-4">
              <AdvancedInsightsPanel scenarioId={scenarioId} />
            </TabsContent>

            <TabsContent value="competitive" className="space-y-4 mt-4">
              <CompetitiveScenarioManager scenarioId={scenarioId} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
