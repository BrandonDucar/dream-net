'use client';

import { useState, useEffect } from 'react';
import type { SimObjectRef, SimObjectType } from '@/types/simulation';
import {
  listSimObjectRefs,
  createSimObjectRef,
  updateSimObjectRef,
  deleteSimObjectRef,
} from '@/lib/simulation-storage';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

export function SimObjectsManager() {
  const [objects, setObjects] = useState<SimObjectRef[]>([]);
  const [editingObject, setEditingObject] = useState<SimObjectRef | null>(null);
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);

  useEffect(() => {
    loadObjects();
  }, []);

  function loadObjects(): void {
    const allObjects = listSimObjectRefs();
    setObjects(allObjects);
  }

  function handleCreate(): void {
    setEditingObject({
      id: '',
      type: 'token',
      name: '',
      description: '',
      sourceApp: null,
      externalRef: null,
      tags: [],
      notes: '',
    });
    setDialogOpen(true);
  }

  function handleEdit(obj: SimObjectRef): void {
    setEditingObject({ ...obj });
    setDialogOpen(true);
  }

  function handleSave(): void {
    if (!editingObject) return;

    if (editingObject.id) {
      updateSimObjectRef(editingObject.id, editingObject);
    } else {
      createSimObjectRef(editingObject);
    }

    setDialogOpen(false);
    setEditingObject(null);
    loadObjects();
  }

  function handleDelete(id: string): void {
    if (confirm('Delete this simulation object? This cannot be undone.')) {
      deleteSimObjectRef(id);
      loadObjects();
    }
  }

  function updateField<K extends keyof SimObjectRef>(field: K, value: SimObjectRef[K]): void {
    if (!editingObject) return;
    setEditingObject({ ...editingObject, [field]: value });
  }

  const objectTypes: SimObjectType[] = [
    'token',
    'culture-coin',
    'drop',
    'campaign',
    'flow',
    'content-stream',
    'audience-segment',
    'pickleball-program',
    'action-bundle',
    'other',
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-2xl">Simulation Objects</CardTitle>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={handleCreate}>Register Object</Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>
                    {editingObject?.id ? 'Edit Simulation Object' : 'Register Simulation Object'}
                  </DialogTitle>
                </DialogHeader>
                {editingObject && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Type</Label>
                      <Select
                        value={editingObject.type}
                        onValueChange={(value: SimObjectType) => updateField('type', value)}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {objectTypes.map((type: SimObjectType) => (
                            <SelectItem key={type} value={type}>
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Name</Label>
                      <Input
                        value={editingObject.name}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('name', e.target.value)}
                        placeholder="e.g., DREAM Token, Jaggy Season 1 Drop"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Description</Label>
                      <Textarea
                        value={editingObject.description}
                        onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                          updateField('description', e.target.value)
                        }
                        rows={3}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Source App (optional)</Label>
                      <Input
                        value={editingObject.sourceApp || ''}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                          updateField('sourceApp', e.target.value || null)
                        }
                        placeholder="e.g., Action Router, Drop Architect"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>External Reference (optional)</Label>
                      <Input
                        value={editingObject.externalRef || ''}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                          updateField('externalRef', e.target.value || null)
                        }
                        placeholder="Backend ID, contract address, etc."
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Tags (comma-separated)</Label>
                      <Input
                        value={editingObject.tags.join(', ')}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                          updateField('tags', e.target.value.split(',').map((t: string) => t.trim()).filter((t: string) => t))
                        }
                        placeholder="base, culture, high-risk"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Notes</Label>
                      <Textarea
                        value={editingObject.notes}
                        onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => updateField('notes', e.target.value)}
                        rows={3}
                      />
                    </div>

                    <div className="flex gap-2 justify-end">
                      <Button variant="outline" onClick={() => setDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleSave}>Save</Button>
                    </div>
                  </div>
                )}
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {objects.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              No simulation objects yet. Register tokens, drops, campaigns, and other objects.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Source App</TableHead>
                  <TableHead>Tags</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {objects.map((obj: SimObjectRef) => (
                  <TableRow key={obj.id}>
                    <TableCell>
                      <Badge>{obj.type}</Badge>
                    </TableCell>
                    <TableCell className="font-medium">{obj.name}</TableCell>
                    <TableCell className="max-w-md text-sm text-muted-foreground">
                      {obj.description.substring(0, 100)}
                      {obj.description.length > 100 ? '...' : ''}
                    </TableCell>
                    <TableCell className="text-sm">{obj.sourceApp || 'N/A'}</TableCell>
                    <TableCell>
                      <div className="flex gap-1 flex-wrap">
                        {obj.tags.map((tag: string) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button size="sm" variant="ghost" onClick={() => handleEdit(obj)}>
                          Edit
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => handleDelete(obj.id)}>
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
