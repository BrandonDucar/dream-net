'use client';

import { useState, useEffect } from 'react';
import type { SimulationModel } from '@/types/simulation';
import {
  listSimulationModels,
  createSimulationModel,
  updateSimulationModel,
  deleteSimulationModel,
} from '@/lib/simulation-storage';
import { generateSEOForSimulationModel } from '@/lib/seo-generator';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

export function SimulationModelsManager() {
  const [models, setModels] = useState<SimulationModel[]>([]);
  const [editingModel, setEditingModel] = useState<SimulationModel | null>(null);
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);

  useEffect(() => {
    loadModels();
  }, []);

  function loadModels(): void {
    const allModels = listSimulationModels();
    setModels(allModels);
  }

  function handleCreate(): void {
    const seo = generateSEOForSimulationModel('New Model', 'A simulation model');
    setEditingModel({
      id: '',
      name: 'New Simulation Model',
      description: 'Describe what this model predicts',
      version: 'v1.0',
      appliesToTypes: [],
      inputMetrics: [],
      outputMetrics: [],
      heuristicDescription: 'Explain the heuristic logic in plain language',
      tags: [],
      notes: '',
      ...seo,
    });
    setDialogOpen(true);
  }

  function handleEdit(model: SimulationModel): void {
    setEditingModel({ ...model });
    setDialogOpen(true);
  }

  function handleSave(): void {
    if (!editingModel) return;

    if (editingModel.id) {
      updateSimulationModel(editingModel.id, editingModel);
    } else {
      createSimulationModel(editingModel);
    }

    setDialogOpen(false);
    setEditingModel(null);
    loadModels();
  }

  function handleDelete(id: string): void {
    if (confirm('Delete this simulation model? This cannot be undone.')) {
      deleteSimulationModel(id);
      loadModels();
    }
  }

  function updateField<K extends keyof SimulationModel>(
    field: K,
    value: SimulationModel[K]
  ): void {
    if (!editingModel) return;
    setEditingModel({ ...editingModel, [field]: value });
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-2xl">Simulation Models</CardTitle>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={handleCreate}>Create Model</Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>
                    {editingModel?.id ? 'Edit Simulation Model' : 'Create Simulation Model'}
                  </DialogTitle>
                </DialogHeader>
                {editingModel && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Name</Label>
                      <Input
                        value={editingModel.name}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('name', e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Version</Label>
                      <Input
                        value={editingModel.version}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('version', e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Description</Label>
                      <Textarea
                        value={editingModel.description}
                        onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                          updateField('description', e.target.value)
                        }
                        rows={3}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Applies To Types (comma-separated)</Label>
                      <Input
                        value={editingModel.appliesToTypes.join(', ')}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                          updateField('appliesToTypes', e.target.value.split(',').map((t: string) => t.trim()))
                        }
                        placeholder="culture-coin, drop, campaign"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Input Metrics (comma-separated)</Label>
                      <Input
                        value={editingModel.inputMetrics.join(', ')}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                          updateField('inputMetrics', e.target.value.split(',').map((m: string) => m.trim()))
                        }
                        placeholder="plannedPosts, baseAudience, segmentSize"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Output Metrics (comma-separated)</Label>
                      <Input
                        value={editingModel.outputMetrics.join(', ')}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                          updateField('outputMetrics', e.target.value.split(',').map((m: string) => m.trim()))
                        }
                        placeholder="estimatedReach, estimatedMints, resonanceScore"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Heuristic Description</Label>
                      <Textarea
                        value={editingModel.heuristicDescription}
                        onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                          updateField('heuristicDescription', e.target.value)
                        }
                        rows={5}
                        placeholder="Explain in plain language how this model calculates outcomes..."
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Tags (comma-separated)</Label>
                      <Input
                        value={editingModel.tags.join(', ')}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                          updateField('tags', e.target.value.split(',').map((t: string) => t.trim()))
                        }
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Notes</Label>
                      <Textarea
                        value={editingModel.notes}
                        onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => updateField('notes', e.target.value)}
                        rows={3}
                      />
                    </div>

                    <div className="flex gap-2 justify-end">
                      <Button variant="outline" onClick={() => setDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleSave}>Save</Button>
                    </div>
                  </div>
                )}
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {models.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              No simulation models yet. Create one to define prediction logic for scenarios.
            </div>
          ) : (
            <div className="space-y-4">
              {models.map((model: SimulationModel) => (
                <Card key={model.id}>
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <div>
                        <CardTitle className="text-lg">{model.name}</CardTitle>
                        <div className="text-sm text-muted-foreground mt-1">
                          Version {model.version}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => handleEdit(model)}>
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDelete(model.id)}
                        >
                          Delete
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <p className="text-sm text-muted-foreground">{model.description}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <strong>Applies To:</strong>
                        <div className="flex gap-1 flex-wrap mt-1">
                          {model.appliesToTypes.map((type: string) => (
                            <Badge key={type} variant="outline" className="text-xs">
                              {type}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div>
                        <strong>Tags:</strong>
                        <div className="flex gap-1 flex-wrap mt-1">
                          {model.tags.map((tag: string) => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div>
                        <strong>Input Metrics:</strong>
                        <div className="text-muted-foreground mt-1">
                          {model.inputMetrics.join(', ')}
                        </div>
                      </div>

                      <div>
                        <strong>Output Metrics:</strong>
                        <div className="text-muted-foreground mt-1">
                          {model.outputMetrics.join(', ')}
                        </div>
                      </div>
                    </div>

                    <div>
                      <strong className="text-sm">How it works:</strong>
                      <div className="mt-1 p-3 bg-muted rounded text-sm whitespace-pre-wrap">
                        {model.heuristicDescription}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
