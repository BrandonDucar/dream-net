'use client'
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Trophy, Plus, Clock, Users } from 'lucide-react';
import type { SimulationTournament, LeaderboardEntry } from '@/types/advanced-features';
import {
  listTournaments,
  calculateLeaderboard,
  generateTournamentInsight,
  initializeSampleTournaments,
  submitTournamentEntry,
} from '@/lib/tournament-engine';

export function TournamentManager() {
  const [tournaments, setTournaments] = useState<SimulationTournament[]>([]);
  const [selectedTournament, setSelectedTournament] = useState<SimulationTournament | null>(null);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [insight, setInsight] = useState<string>('');
  const [participantName, setParticipantName] = useState<string>('');
  const [scenarioId, setScenarioId] = useState<string>('');

  useEffect(() => {
    initializeSampleTournaments();
    loadTournaments();
  }, []);

  function loadTournaments(): void {
    const allTournaments = listTournaments();
    setTournaments(allTournaments);
  }

  function handleSelectTournament(tournament: SimulationTournament): void {
    setSelectedTournament(tournament);
    const board = calculateLeaderboard(tournament.id);
    setLeaderboard(board);
    const insightText = generateTournamentInsight(tournament, board);
    setInsight(insightText);
  }

  function handleSubmitEntry(): void {
    if (!selectedTournament || !participantName || !scenarioId) return;
    
    const entry = submitTournamentEntry(selectedTournament.id, participantName, scenarioId);
    if (entry) {
      // Refresh leaderboard
      const board = calculateLeaderboard(selectedTournament.id);
      setLeaderboard(board);
      const insightText = generateTournamentInsight(selectedTournament, board);
      setInsight(insightText);
      
      // Reset form
      setParticipantName('');
      setScenarioId('');
    }
  }

  function renderMarkdown(text: string): JSX.Element {
    const lines = text.split('\n');
    return (
      <div className="space-y-2">
        {lines.map((line, idx) => {
          if (line.startsWith('## ')) {
            return <h2 key={idx} className="text-xl font-bold mt-4 mb-2">{line.substring(3)}</h2>;
          } else if (line.startsWith('**') && line.endsWith(':**')) {
            return <p key={idx} className="font-semibold mt-2">{line.replace(/\*\*/g, '')}</p>;
          } else if (line.startsWith('- ')) {
            return <li key={idx} className="ml-4 text-sm">{line.substring(2)}</li>;
          } else if (line.startsWith('| ')) {
            return <p key={idx} className="font-mono text-xs">{line}</p>;
          } else if (line.trim().length > 0) {
            return <p key={idx} className="text-sm text-muted-foreground">{line}</p>;
          }
          return <br key={idx} />;
        })}
      </div>
    );
  }

  const statusColors = {
    upcoming: "bg-blue-100 text-blue-800",
    active: "bg-green-100 text-green-800",
    judging: "bg-yellow-100 text-yellow-800",
    completed: "bg-gray-100 text-gray-800",
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="w-5 h-5" />
            Simulation Tournaments
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            Enter weekly challenges to design the best-performing scenarios and compete for prizes. Build a reputation as a top strategist!
          </p>

          <Tabs defaultValue="active">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="active">Active</TabsTrigger>
              <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
              <TabsTrigger value="completed">Completed</TabsTrigger>
            </TabsList>

            <TabsContent value="active" className="space-y-4 mt-4">
              {tournaments.filter(t => t.status === 'active').length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No active tournaments right now. Check back soon!
                </p>
              ) : (
                <div className="space-y-3">
                  {tournaments
                    .filter(t => t.status === 'active')
                    .map(tournament => (
                      <div
                        key={tournament.id}
                        className="border rounded p-4 cursor-pointer hover:bg-accent"
                        onClick={() => handleSelectTournament(tournament)}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-semibold">{tournament.name}</h3>
                          <Badge className={statusColors[tournament.status]}>{tournament.status}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{tournament.description}</p>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            Ends {new Date(tournament.endDate).toLocaleDateString()}
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            {tournament.entries.length} entries
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="upcoming" className="space-y-4 mt-4">
              {tournaments.filter(t => t.status === 'upcoming').length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No upcoming tournaments scheduled.
                </p>
              ) : (
                <div className="space-y-3">
                  {tournaments
                    .filter(t => t.status === 'upcoming')
                    .map(tournament => (
                      <div
                        key={tournament.id}
                        className="border rounded p-4 cursor-pointer hover:bg-accent"
                        onClick={() => handleSelectTournament(tournament)}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-semibold">{tournament.name}</h3>
                          <Badge className={statusColors[tournament.status]}>{tournament.status}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{tournament.description}</p>
                        <div className="text-xs text-muted-foreground">
                          Starts {new Date(tournament.startDate).toLocaleDateString()}
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="completed" className="space-y-4 mt-4">
              <p className="text-sm text-muted-foreground text-center py-8">
                No completed tournaments yet.
              </p>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {selectedTournament && (
        <Card>
          <CardHeader>
            <CardTitle>{selectedTournament.name}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {renderMarkdown(insight)}

            {selectedTournament.status === 'active' && (
              <>
                <div className="border-t pt-4">
                  <h4 className="font-semibold mb-3">Submit Your Entry</h4>
                  <div className="space-y-3">
                    <div>
                      <Label>Your Name</Label>
                      <Input
                        value={participantName}
                        onChange={(e) => setParticipantName(e.target.value)}
                        placeholder="Enter your name or team name"
                      />
                    </div>
                    <div>
                      <Label>Scenario ID</Label>
                      <Input
                        value={scenarioId}
                        onChange={(e) => setScenarioId(e.target.value)}
                        placeholder="Enter the ID of your scenario"
                      />
                    </div>
                    <Button onClick={handleSubmitEntry} disabled={!participantName || !scenarioId}>
                      Submit Entry
                    </Button>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
