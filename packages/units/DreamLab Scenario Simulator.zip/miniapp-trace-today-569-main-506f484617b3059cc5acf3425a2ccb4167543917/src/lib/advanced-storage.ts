// Advanced Storage Layer for New Features
import type {
  AdvancedSimulationData,
  HistoricalPattern,
  CompetitiveScenario,
  MemeVelocityMetrics,
  NetworkSimulation,
  RiskHeatMap,
  ScenarioBranch,
  ExecutionPlan,
  CommunityBenchmark,
  SimulationTournament,
  TournamentEntry,
  SocialListeningSnapshot,
} from "@/types/advanced-features";
import { generateId } from "./simulation-storage";

const ADVANCED_STORAGE_KEY = "dreamnet_advanced_simulation_data";

function getInitialAdvancedData(): AdvancedSimulationData {
  return {
    historicalPatterns: [],
    competitiveScenarios: [],
    memeVelocityMetrics: [],
    networkSimulations: [],
    riskHeatMaps: [],
    scenarioBranches: [],
    executionPlans: [],
    communityBenchmarks: [],
    tournaments: [],
    tournamentEntries: [],
  };
}

export function loadAdvancedData(): AdvancedSimulationData {
  if (typeof window === "undefined") return getInitialAdvancedData();
  
  try {
    const stored = localStorage.getItem(ADVANCED_STORAGE_KEY);
    if (!stored) return getInitialAdvancedData();
    return JSON.parse(stored) as AdvancedSimulationData;
  } catch (error) {
    console.error("Failed to load advanced simulation data:", error);
    return getInitialAdvancedData();
  }
}

export function saveAdvancedData(data: AdvancedSimulationData): void {
  if (typeof window === "undefined") return;
  
  try {
    localStorage.setItem(ADVANCED_STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error("Failed to save advanced simulation data:", error);
  }
}

// Historical Patterns
export function createHistoricalPattern(pattern: Omit<HistoricalPattern, "id">): HistoricalPattern {
  const data = loadAdvancedData();
  const newPattern: HistoricalPattern = { ...pattern, id: generateId() };
  data.historicalPatterns.push(newPattern);
  saveAdvancedData(data);
  return newPattern;
}

export function listHistoricalPatterns(): HistoricalPattern[] {
  return loadAdvancedData().historicalPatterns;
}

export function getHistoricalPattern(id: string): HistoricalPattern | null {
  const data = loadAdvancedData();
  return data.historicalPatterns.find((p) => p.id === id) || null;
}

// Competitive Scenarios
export function createCompetitiveScenario(scenario: Omit<CompetitiveScenario, "id">): CompetitiveScenario {
  const data = loadAdvancedData();
  const newScenario: CompetitiveScenario = { ...scenario, id: generateId() };
  data.competitiveScenarios.push(newScenario);
  saveAdvancedData(data);
  return newScenario;
}

export function getCompetitiveScenario(scenarioId: string): CompetitiveScenario | null {
  const data = loadAdvancedData();
  return data.competitiveScenarios.find((s) => s.scenarioId === scenarioId) || null;
}

export function updateCompetitiveScenario(id: string, updates: Partial<CompetitiveScenario>): CompetitiveScenario | null {
  const data = loadAdvancedData();
  const index = data.competitiveScenarios.findIndex((s) => s.id === id);
  if (index === -1) return null;
  
  data.competitiveScenarios[index] = { ...data.competitiveScenarios[index], ...updates };
  saveAdvancedData(data);
  return data.competitiveScenarios[index];
}

// Meme Velocity
export function createMemeVelocityMetrics(metrics: Omit<MemeVelocityMetrics, "id">): MemeVelocityMetrics {
  const data = loadAdvancedData();
  const newMetrics: MemeVelocityMetrics = { ...metrics, id: generateId() };
  data.memeVelocityMetrics.push(newMetrics);
  saveAdvancedData(data);
  return newMetrics;
}

export function getMemeVelocityMetrics(scenarioId: string): MemeVelocityMetrics | null {
  const data = loadAdvancedData();
  return data.memeVelocityMetrics.find((m) => m.scenarioId === scenarioId) || null;
}

// Network Simulation
export function createNetworkSimulation(simulation: Omit<NetworkSimulation, "id">): NetworkSimulation {
  const data = loadAdvancedData();
  const newSim: NetworkSimulation = { ...simulation, id: generateId() };
  data.networkSimulations.push(newSim);
  saveAdvancedData(data);
  return newSim;
}

export function getNetworkSimulation(scenarioId: string): NetworkSimulation | null {
  const data = loadAdvancedData();
  return data.networkSimulations.find((s) => s.scenarioId === scenarioId) || null;
}

// Risk Heat Maps
export function createRiskHeatMap(heatMap: Omit<RiskHeatMap, "id">): RiskHeatMap {
  const data = loadAdvancedData();
  const newMap: RiskHeatMap = { ...heatMap, id: generateId() };
  data.riskHeatMaps.push(newMap);
  saveAdvancedData(data);
  return newMap;
}

export function getRiskHeatMap(scenarioId: string): RiskHeatMap | null {
  const data = loadAdvancedData();
  return data.riskHeatMaps.find((r) => r.scenarioId === scenarioId) || null;
}

// Scenario Branches
export function createScenarioBranch(branch: Omit<ScenarioBranch, "id">): ScenarioBranch {
  const data = loadAdvancedData();
  const newBranch: ScenarioBranch = { ...branch, id: generateId() };
  data.scenarioBranches.push(newBranch);
  saveAdvancedData(data);
  return newBranch;
}

export function listScenarioBranches(parentScenarioId: string): ScenarioBranch[] {
  const data = loadAdvancedData();
  return data.scenarioBranches.filter((b) => b.parentScenarioId === parentScenarioId);
}

export function getScenarioBranch(id: string): ScenarioBranch | null {
  const data = loadAdvancedData();
  return data.scenarioBranches.find((b) => b.id === id) || null;
}

// Execution Plans
export function createExecutionPlan(plan: Omit<ExecutionPlan, "id">): ExecutionPlan {
  const data = loadAdvancedData();
  const newPlan: ExecutionPlan = { ...plan, id: generateId() };
  data.executionPlans.push(newPlan);
  saveAdvancedData(data);
  return newPlan;
}

export function getExecutionPlan(scenarioId: string): ExecutionPlan | null {
  const data = loadAdvancedData();
  return data.executionPlans.find((p) => p.scenarioId === scenarioId) || null;
}

export function listExecutionPlans(scenarioId: string): ExecutionPlan[] {
  const data = loadAdvancedData();
  return data.executionPlans.filter((p) => p.scenarioId === scenarioId);
}

// Community Benchmarks
export function createCommunityBenchmark(benchmark: Omit<CommunityBenchmark, "id">): CommunityBenchmark {
  const data = loadAdvancedData();
  const newBenchmark: CommunityBenchmark = { ...benchmark, id: generateId() };
  data.communityBenchmarks.push(newBenchmark);
  saveAdvancedData(data);
  return newBenchmark;
}

export function listCommunityBenchmarks(category?: string): CommunityBenchmark[] {
  const data = loadAdvancedData();
  if (!category) return data.communityBenchmarks;
  return data.communityBenchmarks.filter((b) => b.category === category);
}

// Tournaments
export function createTournament(tournament: Omit<SimulationTournament, "id">): SimulationTournament {
  const data = loadAdvancedData();
  const newTournament: SimulationTournament = { ...tournament, id: generateId() };
  data.tournaments.push(newTournament);
  saveAdvancedData(data);
  return newTournament;
}

export function listTournaments(status?: string): SimulationTournament[] {
  const data = loadAdvancedData();
  if (!status) return data.tournaments;
  return data.tournaments.filter((t) => t.status === status);
}

export function getTournament(id: string): SimulationTournament | null {
  const data = loadAdvancedData();
  return data.tournaments.find((t) => t.id === id) || null;
}

export function createTournamentEntry(entry: Omit<TournamentEntry, "id">): TournamentEntry {
  const data = loadAdvancedData();
  const newEntry: TournamentEntry = { ...entry, id: generateId() };
  data.tournamentEntries.push(newEntry);
  saveAdvancedData(data);
  return newEntry;
}

export function listTournamentEntries(tournamentId: string): TournamentEntry[] {
  const data = loadAdvancedData();
  return data.tournamentEntries.filter((e) => e.tournamentId === tournamentId);
}

// Social Listening (stored separately, not in AdvancedSimulationData yet)
const SOCIAL_LISTENING_KEY = "dreamnet_social_listening";

export function saveSocialListeningSnapshot(snapshot: SocialListeningSnapshot): void {
  if (typeof window === "undefined") return;
  
  try {
    const stored = localStorage.getItem(SOCIAL_LISTENING_KEY);
    const snapshots: SocialListeningSnapshot[] = stored ? JSON.parse(stored) : [];
    snapshots.push(snapshot);
    // Keep only last 100 snapshots
    if (snapshots.length > 100) {
      snapshots.splice(0, snapshots.length - 100);
    }
    localStorage.setItem(SOCIAL_LISTENING_KEY, JSON.stringify(snapshots));
  } catch (error) {
    console.error("Failed to save social listening snapshot:", error);
  }
}

export function getLatestSocialListeningSnapshot(): SocialListeningSnapshot | null {
  if (typeof window === "undefined") return null;
  
  try {
    const stored = localStorage.getItem(SOCIAL_LISTENING_KEY);
    if (!stored) return null;
    const snapshots: SocialListeningSnapshot[] = JSON.parse(stored);
    return snapshots.length > 0 ? snapshots[snapshots.length - 1] : null;
  } catch (error) {
    console.error("Failed to load social listening snapshot:", error);
    return null;
  }
}
