// Community Benchmark Engine
import type { ScenarioRunResult } from "@/types/simulation";
import type { CommunityBenchmark, BenchmarkComparison } from "@/types/advanced-features";
import { listCommunityBenchmarks, createCommunityBenchmark } from "./advanced-storage";
import { getScenario, getLatestScenarioRunResult } from "./simulation-storage";

// Initialize sample benchmarks (in a real app, these would be crowdsourced)
export function initializeSampleBenchmarks(): void {
  const existingBenchmarks = listCommunityBenchmarks();
  if (existingBenchmarks.length > 0) return; // Already initialized
  
  const categories = ["culture-launch", "drop", "campaign", "token-launch"];
  const metrics = ["estimatedReach", "estimatedConversions", "resonanceScore", "viralCoefficient"];
  const percentiles = [10, 25, 50, 75, 90];
  
  categories.forEach(category => {
    metrics.forEach(metric => {
      percentiles.forEach(percentile => {
        const value = generateSampleBenchmarkValue(category, metric, percentile);
        createCommunityBenchmark({
          category,
          metric,
          percentile,
          value,
          sampleSize: 150, // Simulated sample size
          lastUpdated: new Date().toISOString(),
          tags: [category, metric],
        });
      });
    });
  });
}

function generateSampleBenchmarkValue(
  category: string,
  metric: string,
  percentile: number
): number {
  const baseValues: Record<string, Record<string, number>> = {
    "culture-launch": {
      estimatedReach: 5000,
      estimatedConversions: 250,
      resonanceScore: 55,
      viralCoefficient: 1.5,
    },
    drop: {
      estimatedReach: 8000,
      estimatedConversions: 400,
      resonanceScore: 60,
      viralCoefficient: 1.8,
    },
    campaign: {
      estimatedReach: 3000,
      estimatedConversions: 150,
      resonanceScore: 50,
      viralCoefficient: 1.2,
    },
    "token-launch": {
      estimatedReach: 15000,
      estimatedConversions: 800,
      resonanceScore: 65,
      viralCoefficient: 2.0,
    },
  };
  
  const base = baseValues[category]?.[metric] || 1000;
  
  // Scale based on percentile
  const percentileMultipliers: Record<number, number> = {
    10: 0.3,
    25: 0.6,
    50: 1.0,
    75: 1.6,
    90: 2.5,
  };
  
  const multiplier = percentileMultipliers[percentile] || 1.0;
  return Math.round(base * multiplier * 10) / 10;
}

function determinePercentile(
  scenarioValue: number,
  benchmarks: CommunityBenchmark[]
): number {
  // Sort benchmarks by value
  const sorted = [...benchmarks].sort((a, b) => a.value - b.value);
  
  // Find where scenario value falls
  for (let i = 0; i < sorted.length; i++) {
    if (scenarioValue <= sorted[i].value) {
      return sorted[i].percentile;
    }
  }
  
  // If higher than all benchmarks
  return 95;
}

function getPercentileLabel(
  percentile: number
): "bottom-10%" | "bottom-25%" | "median" | "top-25%" | "top-10%" {
  if (percentile >= 90) return "top-10%";
  if (percentile >= 75) return "top-25%";
  if (percentile >= 25) return "median";
  if (percentile >= 10) return "bottom-25%";
  return "bottom-10%";
}

export function compareScenarioToBenchmarks(scenarioId: string): BenchmarkComparison | null {
  const scenario = getScenario(scenarioId);
  if (!scenario) return null;
  
  const result = getLatestScenarioRunResult(scenarioId);
  if (!result) return null;
  
  const categoryBenchmarks = listCommunityBenchmarks(scenario.category);
  if (categoryBenchmarks.length === 0) {
    // Try generic benchmarks
    return null;
  }
  
  const scenarioMetrics = result.outputMetrics;
  const comparisons = [];
  
  // Compare each metric
  for (const [metricName, metricValue] of Object.entries(scenarioMetrics)) {
    const metricBenchmarks = categoryBenchmarks.filter(b => b.metric === metricName);
    if (metricBenchmarks.length === 0) continue;
    
    const percentile = determinePercentile(metricValue, metricBenchmarks);
    const percentileLabel = getPercentileLabel(percentile);
    
    // Find closest benchmark value for gap calculation
    const medianBenchmark = metricBenchmarks.find(b => b.percentile === 50);
    const gap = medianBenchmark ? metricValue - medianBenchmark.value : 0;
    
    comparisons.push({
      metric: metricName,
      scenarioValue: metricValue,
      percentile,
      percentileLabel,
      gap,
    });
  }
  
  // Determine overall performance
  const avgPercentile =
    comparisons.reduce((sum, c) => sum + c.percentile, 0) / comparisons.length;
  
  const overallPerformance: "below-average" | "average" | "above-average" | "top-tier" =
    avgPercentile >= 75
      ? "top-tier"
      : avgPercentile >= 55
      ? "above-average"
      : avgPercentile >= 35
      ? "average"
      : "below-average";
  
  // Identify top characteristics
  const topCharacteristics = identifyTopCharacteristics(comparisons);
  
  return {
    scenarioId,
    scenarioMetrics,
    benchmarks: comparisons,
    overallPerformance,
    topCharacteristics,
  };
}

function identifyTopCharacteristics(
  comparisons: Array<{
    metric: string;
    scenarioValue: number;
    percentile: number;
    percentileLabel: string;
    gap: number;
  }>
): string[] {
  const characteristics: string[] = [];
  
  const topMetrics = comparisons.filter(c => c.percentile >= 75);
  topMetrics.forEach(m => {
    if (m.metric === "estimatedReach") {
      characteristics.push("Exceptional reach potential");
    } else if (m.metric === "resonanceScore") {
      characteristics.push("Strong audience resonance");
    } else if (m.metric === "estimatedConversions") {
      characteristics.push("High conversion efficiency");
    } else if (m.metric === "viralCoefficient") {
      characteristics.push("Viral spread capability");
    }
  });
  
  if (topMetrics.length >= 3) {
    characteristics.push("Well-rounded high performance");
  }
  
  const weakMetrics = comparisons.filter(c => c.percentile < 25);
  if (weakMetrics.length === 0) {
    characteristics.push("No weak points identified");
  }
  
  return characteristics.length > 0
    ? characteristics
    : ["Standard performance across metrics"];
}

export function generateBenchmarkInsight(comparison: BenchmarkComparison): string {
  let insight = `## Community Benchmark Comparison\n\n`;
  
  insight += `**Overall Performance: ${comparison.overallPerformance}**\n\n`;
  
  insight += `**Metric Breakdown:**\n\n`;
  insight += `| Metric | Your Value | Percentile | vs. Median |\n`;
  insight += `|--------|------------|------------|------------|\n`;
  
  comparison.benchmarks.forEach(b => {
    const icon =
      b.percentileLabel === "top-10%"
        ? "🏆"
        : b.percentileLabel === "top-25%"
        ? "⭐"
        : b.percentileLabel === "median"
        ? "✅"
        : "📊";
    
    const gapText =
      b.gap > 0 ? `+${Math.round(b.gap).toLocaleString()}` : Math.round(b.gap).toLocaleString();
    
    insight += `| ${icon} ${b.metric} | ${b.scenarioValue.toLocaleString()} | ${b.percentile}th | ${gapText} |\n`;
  });
  insight += `\n`;
  
  insight += `**Top Characteristics:**\n`;
  comparison.topCharacteristics.forEach(char => {
    insight += `- ${char}\n`;
  });
  insight += `\n`;
  
  // Recommendations based on performance
  insight += `**Insights:**\n`;
  if (comparison.overallPerformance === "top-tier") {
    insight += `Your scenario ranks in the top 25% across most metrics. This is a strong candidate for execution.`;
  } else if (comparison.overallPerformance === "above-average") {
    insight += `Your scenario performs above average. Consider optimizing weak points to reach top-tier status.`;
  } else if (comparison.overallPerformance === "average") {
    insight += `Your scenario shows average performance. Review top-performing scenarios for improvement ideas.`;
  } else {
    insight += `Your scenario is below average. Consider revisiting assumptions, objects, and inputs to improve projections.`;
  }
  
  const weakBenchmarks = comparison.benchmarks.filter(b => b.percentile < 25);
  if (weakBenchmarks.length > 0) {
    insight += `\n\n**Areas for Improvement:**\n`;
    weakBenchmarks.forEach(b => {
      insight += `- ${b.metric}: Currently at ${b.percentile}th percentile, aim for 50th+ with targeted optimizations\n`;
    });
  }
  
  return insight;
}
