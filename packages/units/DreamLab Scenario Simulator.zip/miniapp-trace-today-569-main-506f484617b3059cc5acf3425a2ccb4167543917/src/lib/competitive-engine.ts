// Competitive Simulation Engine
import type { Scenario, ScenarioRunResult } from "@/types/simulation";
import type { CompetitiveScenario, CompetitorAction } from "@/types/advanced-features";
import { getCompetitiveScenario, createCompetitiveScenario } from "./advanced-storage";
import { getScenario, getLatestScenarioRunResult } from "./simulation-storage";

function calculateCompetitiveImpact(competitors: CompetitorAction[]): {
  reachReduction: number;
  conversionReduction: number;
  resonanceReduction: number;
  marketShareImpact: number;
} {
  let totalReachReduction = 0;
  let totalConversionReduction = 0;
  let totalResonanceReduction = 0;
  let totalMarketShareImpact = 0;
  
  competitors.forEach(competitor => {
    const { timing, estimatedImpact, marketShareImpact } = competitor;
    
    // Base impact multipliers
    const impactMultipliers = {
      low: 0.05,
      medium: 0.15,
      high: 0.30,
      critical: 0.50,
    };
    
    const baseImpact = impactMultipliers[estimatedImpact];
    
    // Timing multipliers (same-week has highest impact)
    const timingMultipliers: Record<string, number> = {
      "same-week": 1.0,
      overlap: 0.7,
      before: 0.4,
      after: 0.3,
    };
    
    const timingMultiplier = timingMultipliers[timing] || 0.5;
    const adjustedImpact = baseImpact * timingMultiplier;
    
    totalReachReduction += adjustedImpact;
    totalConversionReduction += adjustedImpact * 1.2; // Conversions hit harder
    totalResonanceReduction += adjustedImpact * 0.8; // Resonance less affected
    totalMarketShareImpact += marketShareImpact;
  });
  
  return {
    reachReduction: Math.min(totalReachReduction, 0.7), // Cap at 70% reduction
    conversionReduction: Math.min(totalConversionReduction, 0.8),
    resonanceReduction: Math.min(totalResonanceReduction, 0.5),
    marketShareImpact: totalMarketShareImpact,
  };
}

export function simulateCompetitiveScenario(
  scenarioId: string,
  competitors: CompetitorAction[]
): CompetitiveScenario | null {
  const scenario = getScenario(scenarioId);
  if (!scenario) return null;
  
  const baseResult = getLatestScenarioRunResult(scenarioId);
  if (!baseResult) return null;
  
  const impact = calculateCompetitiveImpact(competitors);
  
  // Calculate market saturation (increases with competitor count)
  const marketSaturation = Math.min(competitors.length * 15, 100);
  
  // Count timing conflicts
  const timingConflicts = competitors.filter(
    c => c.timing === "same-week" || c.timing === "overlap"
  ).length;
  
  // Adjust metrics based on competitive impact
  const adjustedMetrics: Record<string, number> = {
    estimatedReach: Math.round(
      baseResult.outputMetrics.estimatedReach * (1 - impact.reachReduction)
    ),
    estimatedConversions: Math.round(
      baseResult.outputMetrics.estimatedConversions * (1 - impact.conversionReduction)
    ),
    resonanceScore: Math.round(
      baseResult.outputMetrics.resonanceScore * (1 - impact.resonanceReduction) * 10
    ) / 10,
    estimatedMints: Math.round(
      (baseResult.outputMetrics.estimatedMints || 0) * (1 - impact.conversionReduction)
    ),
    remixCount: Math.round(
      baseResult.outputMetrics.remixCount * (1 - impact.reachReduction * 0.8)
    ),
    viralCoefficient: Math.round(
      baseResult.outputMetrics.viralCoefficient * (1 - impact.reachReduction * 0.5) * 100
    ) / 100,
    engagementRate: Math.round(
      baseResult.outputMetrics.engagementRate * (1 - impact.reachReduction * 0.6) * 10
    ) / 10,
    marketShareCaptured: Math.round((100 - impact.marketShareImpact) * 10) / 10,
  };
  
  const competitiveScenario = createCompetitiveScenario({
    scenarioId,
    competitors,
    marketSaturation,
    timingConflicts,
    adjustedMetrics,
  });
  
  return competitiveScenario;
}

export function generateCompetitiveInsight(competitiveScenario: CompetitiveScenario): string {
  const { competitors, marketSaturation, timingConflicts, adjustedMetrics } = competitiveScenario;
  
  let insight = `## Competitive Simulation Results\n\n`;
  insight += `**Market Conditions:**\n`;
  insight += `- ${competitors.length} competitor(s) detected\n`;
  insight += `- Market saturation: ${marketSaturation}%\n`;
  insight += `- Timing conflicts: ${timingConflicts}\n\n`;
  
  insight += `**Adjusted Projections:**\n`;
  insight += `- Reach: ${adjustedMetrics.estimatedReach.toLocaleString()}\n`;
  insight += `- Conversions: ${adjustedMetrics.estimatedConversions.toLocaleString()}\n`;
  insight += `- Resonance: ${adjustedMetrics.resonanceScore}/100\n`;
  insight += `- Market Share Captured: ${adjustedMetrics.marketShareCaptured}%\n\n`;
  
  if (timingConflicts > 0) {
    insight += `⚠️ **Warning**: ${timingConflicts} competitor(s) launching in the same time window. `;
    insight += `Consider shifting timing to avoid saturation.\n\n`;
  }
  
  const criticalCompetitors = competitors.filter(c => c.estimatedImpact === "critical");
  if (criticalCompetitors.length > 0) {
    insight += `🚨 **Critical Threats:**\n`;
    criticalCompetitors.forEach(c => {
      insight += `- ${c.competitorName} (${c.actionType}) - ${c.notes}\n`;
    });
    insight += `\n`;
  }
  
  insight += `**Recommendation:** `;
  if (marketSaturation > 60) {
    insight += `High market saturation. Consider delaying launch or differentiating positioning.`;
  } else if (timingConflicts > 2) {
    insight += `Multiple timing conflicts. Shift your launch window for better impact.`;
  } else {
    insight += `Competitive environment is manageable. Proceed with enhanced monitoring.`;
  }
  
  return insight;
}
