// Execution Plan Generation Engine
import type { Scenario, ScenarioInput, ScenarioRunResult } from "@/types/simulation";
import type { ExecutionPlan, ExecutionAction, ExecutionTimeline } from "@/types/advanced-features";
import { getScenario, getScenarioInputs, getLatestScenarioRunResult } from "./simulation-storage";
import { createExecutionPlan } from "./advanced-storage";

function generateActionsFromScenario(
  scenario: Scenario,
  inputs: ScenarioInput[],
  result: ScenarioRunResult
): ExecutionAction[] {
  const actions: ExecutionAction[] = [];
  let actionIdCounter = 1;
  
  const plannedPosts = inputs.find(i => i.key === "plannedPosts")?.valueNumber || 10;
  const plannedDrops = inputs.find(i => i.key === "plannedDrops")?.valueNumber || 0;
  const baseAudience = inputs.find(i => i.key === "baseAudience")?.valueNumber || 1000;
  
  // Day 0: Pre-launch setup
  actions.push({
    id: `action-${actionIdCounter++}`,
    type: "other",
    day: 0,
    description: "Finalize all assets, messaging, and technical setup",
    parameters: { priority: "critical" },
    dependencies: [],
  });
  
  actions.push({
    id: `action-${actionIdCounter++}`,
    type: "other",
    day: 0,
    description: "Set up monitoring dashboards and analytics",
    parameters: { tools: "analytics" },
    dependencies: [],
  });
  
  // Day 1: Launch
  actions.push({
    id: `action-${actionIdCounter++}`,
    type: "campaign-start",
    day: 1,
    description: `Launch ${scenario.name} campaign`,
    parameters: { targetAudience: baseAudience },
    dependencies: [`action-1`, `action-2`],
  });
  
  // Distribute posts across campaign
  const days = calculateTimeWindowDays(scenario);
  const postsPerDay = Math.ceil(plannedPosts / Math.max(days, 1));
  
  for (let day = 1; day <= days; day++) {
    if (day <= plannedPosts) {
      actions.push({
        id: `action-${actionIdCounter++}`,
        type: "post",
        day,
        description: `Post ${Math.min(postsPerDay, plannedPosts - (day - 1) * postsPerDay)} content pieces`,
        parameters: {
          count: Math.min(postsPerDay, plannedPosts - (day - 1) * postsPerDay),
          platforms: "farcaster,x",
        },
        dependencies: day === 1 ? [`action-3`] : [`action-${actionIdCounter - 2}`],
      });
    }
  }
  
  // Drops
  if (plannedDrops > 0) {
    const dropInterval = Math.floor(days / plannedDrops);
    for (let i = 0; i < plannedDrops; i++) {
      const dropDay = Math.min(2 + i * dropInterval, days);
      actions.push({
        id: `action-${actionIdCounter++}`,
        type: "drop",
        day: dropDay,
        description: `Launch drop ${i + 1}/${plannedDrops}`,
        parameters: { dropNumber: i + 1 },
        dependencies: [`action-3`],
      });
    }
  }
  
  // Monitoring actions
  const monitoringDays = [3, 7, 14];
  monitoringDays.forEach(day => {
    if (day <= days) {
      actions.push({
        id: `action-${actionIdCounter++}`,
        type: "monitor",
        day,
        description: `Review metrics and adjust strategy if needed`,
        parameters: { checkpoint: `day-${day}` },
        dependencies: [],
      });
    }
  });
  
  // Mid-campaign adjustment
  if (days > 7) {
    actions.push({
      id: `action-${actionIdCounter++}`,
      type: "adjust",
      day: Math.floor(days / 2),
      description: "Implement mid-campaign optimizations based on performance",
      parameters: { type: "optimization" },
      dependencies: [],
    });
  }
  
  return actions.sort((a, b) => a.day - b.day);
}

function generateTimeline(actions: ExecutionAction[]): ExecutionTimeline[] {
  const timeline: ExecutionTimeline[] = [];
  const dayGroups = new Map<number, string[]>();
  
  // Group actions by day
  actions.forEach(action => {
    const existing = dayGroups.get(action.day) || [];
    existing.push(action.id);
    dayGroups.set(action.day, existing);
  });
  
  // Create timeline entries
  dayGroups.forEach((actionIds, day) => {
    const dayActions = actions.filter(a => actionIds.includes(a.id));
    const milestone = determineMilestone(day, dayActions);
    const outcome = determineExpectedOutcome(day, dayActions);
    
    timeline.push({
      day,
      milestone,
      actions: actionIds,
      expectedOutcome: outcome,
    });
  });
  
  return timeline.sort((a, b) => a.day - b.day);
}

function determineMilestone(day: number, actions: ExecutionAction[]): string {
  if (day === 0) return "Pre-Launch Preparation";
  if (day === 1) return "Campaign Launch";
  
  const hasDrop = actions.some(a => a.type === "drop");
  if (hasDrop) return `Drop Launch (Day ${day})`;
  
  const hasMonitor = actions.some(a => a.type === "monitor");
  if (hasMonitor) return `Performance Checkpoint`;
  
  const hasAdjust = actions.some(a => a.type === "adjust");
  if (hasAdjust) return `Mid-Campaign Optimization`;
  
  return `Day ${day} Activities`;
}

function determineExpectedOutcome(day: number, actions: ExecutionAction[]): string {
  if (day === 0) return "All systems ready for launch";
  if (day === 1) return "Initial engagement and reach established";
  
  const hasDrop = actions.some(a => a.type === "drop");
  if (hasDrop) return "NFT mints and conversion spike";
  
  const hasMonitor = actions.some(a => a.type === "monitor");
  if (hasMonitor) return "Data-driven insights for optimization";
  
  const postCount = actions.filter(a => a.type === "post").length;
  if (postCount > 0) return `${postCount} content pieces published, engagement sustained`;
  
  return "Campaign momentum maintained";
}

function calculateTimeWindowDays(scenario: Scenario): number {
  if (!scenario.timeWindowStart || !scenario.timeWindowEnd) return 14;
  
  const start = new Date(scenario.timeWindowStart);
  const end = new Date(scenario.timeWindowEnd);
  const diffTime = Math.abs(end.getTime() - start.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  return Math.max(1, diffDays);
}

function formatAsActionRouterExport(plan: ExecutionPlan): string {
  let output = `# Action Router Export: ${plan.scenarioId}\n`;
  output += `# Generated: ${plan.generatedAt}\n\n`;
  
  output += `## Timeline\n\n`;
  plan.timeline.forEach(tl => {
    output += `### Day ${tl.day}: ${tl.milestone}\n`;
    output += `**Expected Outcome:** ${tl.expectedOutcome}\n\n`;
    
    const tlActions = plan.actions.filter(a => tl.actions.includes(a.id));
    tlActions.forEach(action => {
      output += `- [${action.type.toUpperCase()}] ${action.description}\n`;
      if (Object.keys(action.parameters).length > 0) {
        output += `  Parameters: ${JSON.stringify(action.parameters)}\n`;
      }
    });
    output += `\n`;
  });
  
  output += `## Prerequisites\n`;
  plan.prerequisites.forEach(prereq => {
    output += `- ${prereq}\n`;
  });
  output += `\n`;
  
  output += `## Estimated Effort\n${plan.estimatedEffort}\n`;
  
  return output;
}

function determinePrerequisites(
  scenario: Scenario,
  actions: ExecutionAction[]
): string[] {
  const prerequisites: string[] = [];
  
  prerequisites.push("All campaign assets (images, copy, videos) finalized");
  prerequisites.push("Analytics and monitoring tools configured");
  
  const hasDrops = actions.some(a => a.type === "drop");
  if (hasDrops) {
    prerequisites.push("NFT smart contracts deployed and tested");
    prerequisites.push("Drop mechanics and pricing confirmed");
  }
  
  const postCount = actions.filter(a => a.type === "post").length;
  if (postCount > 10) {
    prerequisites.push("Content calendar populated with all posts");
  }
  
  if (scenario.simObjectIds.length > 3) {
    prerequisites.push("Cross-component integrations tested");
  }
  
  prerequisites.push("Team roles and responsibilities assigned");
  prerequisites.push("Emergency response plan documented");
  
  return prerequisites;
}

function estimateEffort(actions: ExecutionAction[], scenario: Scenario): string {
  const postCount = actions.filter(a => a.type === "post").length;
  const dropCount = actions.filter(a => a.type === "drop").length;
  const complexity = scenario.simObjectIds.length;
  
  let effort = postCount * 2; // 2 hours per post
  effort += dropCount * 8; // 8 hours per drop
  effort += complexity * 3; // 3 hours per object
  effort += 10; // Base setup time
  
  const days = calculateTimeWindowDays(scenario);
  const teamSize = effort > 100 ? "3-5 people" : effort > 50 ? "2-3 people" : "1-2 people";
  
  return `Approximately ${effort} person-hours over ${days} days. Recommended team: ${teamSize}.`;
}

export function generateExecutionPlan(
  scenarioId: string,
  format: "action-router" | "social-relay" | "drop-architect" | "generic" = "generic"
): ExecutionPlan | null {
  const scenario = getScenario(scenarioId);
  if (!scenario) return null;
  
  const inputs = getScenarioInputs(scenarioId);
  const result = getLatestScenarioRunResult(scenarioId);
  if (!result) return null;
  
  const actions = generateActionsFromScenario(scenario, inputs, result);
  const timeline = generateTimeline(actions);
  const prerequisites = determinePrerequisites(scenario, actions);
  const estimatedEffort = estimateEffort(actions, scenario);
  
  let exportableFormat = "";
  if (format === "action-router") {
    // Will be populated after creation
  }
  
  const plan = createExecutionPlan({
    scenarioId,
    format,
    generatedAt: new Date().toISOString(),
    actions,
    timeline,
    estimatedEffort,
    prerequisites,
    exportableFormat: "", // Will update after
  });
  
  // Generate exportable format
  if (format === "action-router") {
    plan.exportableFormat = formatAsActionRouterExport(plan);
  } else {
    plan.exportableFormat = JSON.stringify({
      scenario: scenario.name,
      actions,
      timeline,
      prerequisites,
      estimatedEffort,
    }, null, 2);
  }
  
  return plan;
}

export function generateExecutionPlanInsight(plan: ExecutionPlan): string {
  let insight = `## Execution Plan Generated\n\n`;
  
  insight += `**Format:** ${plan.format}\n`;
  insight += `**Total Actions:** ${plan.actions.length}\n`;
  insight += `**Campaign Duration:** ${plan.timeline.length} days\n`;
  insight += `**Effort Estimate:** ${plan.estimatedEffort}\n\n`;
  
  insight += `**Key Milestones:**\n`;
  const keyMilestones = plan.timeline.filter(
    tl => tl.milestone.includes("Launch") || tl.milestone.includes("Drop") || tl.milestone.includes("Optimization")
  );
  keyMilestones.forEach(tl => {
    insight += `- Day ${tl.day}: ${tl.milestone}\n`;
  });
  insight += `\n`;
  
  insight += `**Prerequisites (${plan.prerequisites.length}):**\n`;
  plan.prerequisites.slice(0, 5).forEach(prereq => {
    insight += `- ${prereq}\n`;
  });
  if (plan.prerequisites.length > 5) {
    insight += `- ...and ${plan.prerequisites.length - 5} more\n`;
  }
  insight += `\n`;
  
  const postActions = plan.actions.filter(a => a.type === "post").length;
  const dropActions = plan.actions.filter(a => a.type === "drop").length;
  
  insight += `**Action Breakdown:**\n`;
  insight += `- Content Posts: ${postActions}\n`;
  insight += `- Drops: ${dropActions}\n`;
  insight += `- Monitoring Checkpoints: ${plan.actions.filter(a => a.type === "monitor").length}\n`;
  insight += `- Other Actions: ${plan.actions.length - postActions - dropActions}\n\n`;
  
  insight += `*This execution plan can be exported to Action Router, Social Relay, or Drop Architect for implementation.*`;
  
  return insight;
}
