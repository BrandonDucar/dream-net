import type {
  Scenario,
  SimObjectRef,
  AssumptionSet,
  SimulationModel,
  ScenarioInput,
  ScenarioRunResult,
} from '@/types/simulation';
import {
  getScenario,
  getSimObjectRef,
  getAssumptionSet,
  getSimulationModel,
  getScenarioInputs,
  getLatestScenarioRunResult,
  listAssumptionSets,
  listSimulationModels,
  listScenarios,
} from './simulation-storage';

export function exportScenarioReport(scenarioId: string): string {
  const scenario = getScenario(scenarioId);
  if (!scenario) return 'Scenario not found';

  const objects = scenario.simObjectIds
    .map((id: string) => getSimObjectRef(id))
    .filter((obj: SimObjectRef | null): obj is SimObjectRef => obj !== null);

  const assumptions = getAssumptionSet(scenario.assumptionSetId);
  const model = getSimulationModel(scenario.simulationModelId);
  const inputs = getScenarioInputs(scenarioId);
  const latestResult = getLatestScenarioRunResult(scenarioId);

  let report = '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n';
  report += '   DREAMNET SIMULATION LAB - SCENARIO REPORT\n';
  report += '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n';

  report += `SCENARIO: ${scenario.name}\n`;
  report += `Category: ${scenario.category}\n`;
  report += `Priority: ${scenario.priorityLevel}\n`;
  report += `Status: ${scenario.status}\n\n`;

  report += `DESCRIPTION:\n${scenario.description}\n\n`;

  if (scenario.timeWindowStart && scenario.timeWindowEnd) {
    report += `TIME WINDOW:\n`;
    report += `${new Date(scenario.timeWindowStart).toLocaleDateString()} - ${new Date(scenario.timeWindowEnd).toLocaleDateString()}\n\n`;
  }

  report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  report += `SIMULATION OBJECTS (${objects.length})\n`;
  report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

  objects.forEach((obj: SimObjectRef, idx: number) => {
    report += `${idx + 1}. [${obj.type}] ${obj.name}\n`;
    report += `   ${obj.description}\n`;
    if (obj.sourceApp) report += `   Source: ${obj.sourceApp}\n`;
    if (obj.tags.length > 0) report += `   Tags: ${obj.tags.join(', ')}\n`;
    report += '\n';
  });

  report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  report += `ASSUMPTIONS: ${assumptions?.name || 'N/A'}\n`;
  report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

  if (assumptions) {
    report += `${assumptions.description}\n\n`;
    report += `Multipliers:\n`;
    report += `  • Base Reach Factor: ${assumptions.baseReachFactor}x\n`;
    report += `  • Engagement Factor: ${assumptions.engagementFactor}x\n`;
    report += `  • Conversion Factor: ${assumptions.conversionFactor}x\n`;
    report += `  • Remix Factor: ${assumptions.remixFactor}x\n`;
    report += `  • Fatigue Factor: ${assumptions.fatigueFactor}\n`;
    report += `  • Risk Multiplier (High): ${assumptions.riskMultiplierHigh}x\n\n`;
  }

  report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  report += `SIMULATION MODEL: ${model?.name || 'N/A'}\n`;
  report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

  if (model) {
    report += `Version: ${model.version}\n`;
    report += `${model.description}\n\n`;
    report += `Input Metrics: ${model.inputMetrics.join(', ')}\n`;
    report += `Output Metrics: ${model.outputMetrics.join(', ')}\n\n`;
    report += `HOW IT WORKS:\n${model.heuristicDescription}\n\n`;
  }

  report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  report += `INPUTS (${inputs.length})\n`;
  report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

  inputs.forEach((input: ScenarioInput) => {
    report += `  • ${input.key}: `;
    if (input.valueNumber !== null) report += `${input.valueNumber}`;
    if (input.valueText) report += `"${input.valueText}"`;
    if (input.notes) report += ` (${input.notes})`;
    report += '\n';
  });
  report += '\n';

  if (latestResult) {
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    report += `LATEST SIMULATION RESULTS\n`;
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

    report += `Run At: ${new Date(latestResult.runAt).toLocaleString()}\n`;
    report += `Model Version: ${latestResult.modelVersion}\n\n`;

    report += `OUTPUT METRICS:\n`;
    Object.entries(latestResult.outputMetrics).forEach(([key, value]: [string, number]) => {
      report += `  • ${key}: ${value.toLocaleString()}\n`;
    });
    report += '\n';

    report += `NARRATIVE SUMMARY:\n`;
    report += `${latestResult.narrativeSummary}\n\n`;

    report += `RISK NOTES:\n`;
    report += `${latestResult.riskNotes}\n\n`;

    report += `RECOMMENDED ACTIONS:\n`;
    latestResult.recommendedActions.forEach((action: string, idx: number) => {
      report += `  ${idx + 1}. ${action}\n`;
    });
    report += '\n';
  } else {
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    report += `No simulation results yet. Run a simulation first.\n`;
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
  }

  if (scenario.primaryGeoTargets.length > 0) {
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    report += `GEO TARGETS\n`;
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    scenario.primaryGeoTargets.forEach((geo, idx: number) => {
      report += `${idx + 1}. ${geo.region} / ${geo.country} / ${geo.cityOrMarket} (${geo.language})\n`;
    });
    report += '\n';
  }

  report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  report += `SEO METADATA\n`;
  report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
  report += `Title: ${scenario.seoTitle}\n`;
  report += `Description: ${scenario.seoDescription}\n`;
  report += `Keywords: ${scenario.seoKeywords.join(', ')}\n`;
  report += `Hashtags: ${scenario.seoHashtags.join(', ')}\n\n`;

  report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  report += `END OF REPORT\n`;
  report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;

  return report;
}

export function exportSimulationPlaybook(): string {
  const assumptionSets = listAssumptionSets();
  const models = listSimulationModels();
  const scenarios = listScenarios();

  let playbook = '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n';
  playbook += '   DREAMNET SIMULATION LAB - PLAYBOOK\n';
  playbook += '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n';

  playbook += `Generated: ${new Date().toLocaleString()}\n\n`;

  playbook += `This playbook documents all assumption sets, simulation models,\n`;
  playbook += `and example scenarios in the DreamNet Simulation Lab.\n\n`;

  playbook += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  playbook += `ASSUMPTION SETS (${assumptionSets.length})\n`;
  playbook += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

  assumptionSets.forEach((set: AssumptionSet, idx: number) => {
    playbook += `${idx + 1}. ${set.name}\n`;
    playbook += `   ${set.description}\n\n`;
    playbook += `   Factors:\n`;
    playbook += `   • Base Reach: ${set.baseReachFactor}x\n`;
    playbook += `   • Engagement: ${set.engagementFactor}x\n`;
    playbook += `   • Conversion: ${set.conversionFactor}x\n`;
    playbook += `   • Remix: ${set.remixFactor}x\n`;
    playbook += `   • Fatigue: ${set.fatigueFactor}\n`;
    playbook += `   • Risk Multiplier: ${set.riskMultiplierHigh}x\n\n`;
  });

  playbook += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  playbook += `SIMULATION MODELS (${models.length})\n`;
  playbook += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

  models.forEach((model: SimulationModel, idx: number) => {
    playbook += `${idx + 1}. ${model.name} (${model.version})\n`;
    playbook += `   ${model.description}\n\n`;
    playbook += `   Applies To: ${model.appliesToTypes.join(', ')}\n`;
    playbook += `   Inputs: ${model.inputMetrics.join(', ')}\n`;
    playbook += `   Outputs: ${model.outputMetrics.join(', ')}\n\n`;
    playbook += `   How It Works:\n`;
    playbook += `   ${model.heuristicDescription}\n\n`;
  });

  playbook += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  playbook += `EXAMPLE SCENARIOS (${scenarios.length})\n`;
  playbook += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

  scenarios.slice(0, 5).forEach((scenario: Scenario, idx: number) => {
    const latestResult = getLatestScenarioRunResult(scenario.id);

    playbook += `${idx + 1}. ${scenario.name}\n`;
    playbook += `   Category: ${scenario.category}\n`;
    playbook += `   Status: ${scenario.status}\n`;
    playbook += `   ${scenario.description}\n\n`;

    if (latestResult) {
      playbook += `   Latest Results:\n`;
      Object.entries(latestResult.outputMetrics).forEach(([key, value]: [string, number]) => {
        playbook += `   • ${key}: ${value.toLocaleString()}\n`;
      });
      playbook += '\n';
    }
  });

  playbook += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  playbook += `END OF PLAYBOOK\n`;
  playbook += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;

  return playbook;
}
