// Historical Pattern Matching Engine
import type { Scenario, ScenarioInput, SimObjectRef } from "@/types/simulation";
import type { HistoricalPattern } from "@/types/advanced-features";
import { listHistoricalPatterns } from "./advanced-storage";
import { getScenario, getScenarioInputs, getSimObjectRef } from "./simulation-storage";

interface ScenarioFingerprint {
  categoryHash: string;
  objectTypesHash: string;
  inputMagnitudeHash: string;
  tagsHash: string;
}

function hashString(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36);
}

function generateScenarioFingerprint(
  scenario: Scenario,
  inputs: ScenarioInput[],
  objects: SimObjectRef[]
): string {
  const categoryHash = hashString(scenario.category);
  const objectTypesHash = hashString(objects.map(o => o.type).sort().join(','));
  
  const totalInputMagnitude = inputs.reduce((sum, i) => sum + (i.valueNumber || 0), 0);
  const inputMagnitudeHash = hashString(Math.floor(totalInputMagnitude / 100).toString());
  
  const tagsHash = hashString(scenario.tags.sort().join(','));
  
  return `${categoryHash}-${objectTypesHash}-${inputMagnitudeHash}-${tagsHash}`;
}

function calculateSimilarity(
  scenarioFingerprint: string,
  patternFingerprint: string,
  scenarioCategory: string,
  patternCategory: string,
  scenarioTags: string[],
  patternTags: string[]
): number {
  let similarity = 0;
  
  // Exact fingerprint match = 40 points
  if (scenarioFingerprint === patternFingerprint) {
    similarity += 40;
  }
  
  // Category match = 30 points
  if (scenarioCategory === patternCategory) {
    similarity += 30;
  }
  
  // Tag overlap = up to 30 points
  const commonTags = scenarioTags.filter(tag => patternTags.includes(tag));
  const tagSimilarity = (commonTags.length / Math.max(scenarioTags.length, patternTags.length)) * 30;
  similarity += tagSimilarity;
  
  return Math.round(similarity);
}

export function findSimilarHistoricalPatterns(
  scenarioId: string,
  minSimilarity: number = 60
): HistoricalPattern[] {
  const scenario = getScenario(scenarioId);
  if (!scenario) return [];
  
  const inputs = getScenarioInputs(scenarioId);
  const objects = scenario.simObjectIds
    .map(id => getSimObjectRef(id))
    .filter((obj): obj is SimObjectRef => obj !== null);
  
  const scenarioFingerprint = generateScenarioFingerprint(scenario, inputs, objects);
  const allPatterns = listHistoricalPatterns();
  
  const matchedPatterns = allPatterns
    .map(pattern => {
      const similarity = calculateSimilarity(
        scenarioFingerprint,
        pattern.scenarioFingerprint,
        scenario.category,
        pattern.category,
        scenario.tags,
        pattern.contextTags
      );
      
      return {
        ...pattern,
        similarity,
      };
    })
    .filter(pattern => pattern.similarity >= minSimilarity)
    .sort((a, b) => b.similarity - a.similarity);
  
  return matchedPatterns;
}

export function generateHistoricalInsight(
  scenarioId: string
): string {
  const similarPatterns = findSimilarHistoricalPatterns(scenarioId, 70);
  
  if (similarPatterns.length === 0) {
    return "No similar historical patterns found. This scenario is breaking new ground!";
  }
  
  const topMatch = similarPatterns[0];
  
  let insight = `## Historical Pattern Match\n\n`;
  insight += `Your scenario is **${topMatch.similarity}% similar** to **${topMatch.name}** `;
  insight += `(${new Date(topMatch.dateRange.start).toLocaleDateString()} - ${new Date(topMatch.dateRange.end).toLocaleDateString()}).\n\n`;
  insight += `**Historical Outcomes:**\n`;
  insight += `- Reach: ${topMatch.actualOutcomes.reach.toLocaleString()}\n`;
  insight += `- Conversions: ${topMatch.actualOutcomes.conversions.toLocaleString()}\n`;
  insight += `- Resonance Score: ${topMatch.actualOutcomes.resonanceScore}/100\n`;
  insight += `- Viral Coefficient: ${topMatch.actualOutcomes.viralCoefficient}\n\n`;
  
  if (similarPatterns.length > 1) {
    insight += `**Other Similar Patterns:**\n`;
    similarPatterns.slice(1, 4).forEach(pattern => {
      insight += `- ${pattern.name} (${pattern.similarity}% match)\n`;
    });
  }
  
  insight += `\n*Use these historical outcomes to calibrate your expectations and refine your strategy.*`;
  
  return insight;
}
