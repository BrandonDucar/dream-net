// Meme Velocity Prediction Engine
import type { Scenario, ScenarioInput, SimObjectRef } from "@/types/simulation";
import type { MemeVelocityMetrics, ViralPathway } from "@/types/advanced-features";
import { getScenario, getScenarioInputs, getSimObjectRef } from "./simulation-storage";
import { createMemeVelocityMetrics } from "./advanced-storage";

function calculateMemePotentialScore(
  objects: SimObjectRef[],
  inputs: ScenarioInput[],
  scenario: Scenario
): number {
  let score = 50; // Base score
  
  // Object types that are meme-friendly
  const memeTypes = ["culture-coin", "content-stream", "meme-engine"];
  const memeObjectCount = objects.filter(o => 
    memeTypes.some(type => o.type.includes(type) || o.name.toLowerCase().includes("meme"))
  ).length;
  
  score += memeObjectCount * 10;
  
  // Tags that indicate meme potential
  const memeTags = ["meme", "viral", "culture", "remix", "social"];
  const memeTagCount = scenario.tags.filter(tag => 
    memeTags.some(mt => tag.toLowerCase().includes(mt))
  ).length;
  
  score += memeTagCount * 5;
  
  // Planned posts boost meme potential
  const plannedPosts = inputs.find(i => i.key === "plannedPosts")?.valueNumber || 0;
  if (plannedPosts > 20) score += 15;
  else if (plannedPosts > 10) score += 10;
  
  // Category-based adjustments
  if (scenario.category.includes("culture")) score += 15;
  if (scenario.category.includes("experimental")) score += 10;
  
  return Math.min(Math.max(score, 0), 100);
}

function calculateRemixabilityScore(
  objects: SimObjectRef[],
  scenario: Scenario
): number {
  let score = 40; // Base remixability
  
  // More objects = more remixable combinations
  score += Math.min(objects.length * 8, 30);
  
  // Certain object types are inherently remixable
  const remixableTypes = ["culture-coin", "drop", "content-stream"];
  const remixableCount = objects.filter(o => 
    remixableTypes.includes(o.type)
  ).length;
  
  score += remixableCount * 10;
  
  // Description complexity (more words = more remixable)
  const wordCount = scenario.description.split(/\s+/).length;
  if (wordCount > 50) score += 10;
  else if (wordCount > 20) score += 5;
  
  return Math.min(Math.max(score, 0), 100);
}

function predictViralPathways(
  memePotentialScore: number,
  inputs: ScenarioInput[]
): ViralPathway[] {
  const pathways: ViralPathway[] = [];
  const plannedPosts = inputs.find(i => i.key === "plannedPosts")?.valueNumber || 10;
  const baseAudience = inputs.find(i => i.key === "baseAudience")?.valueNumber || 1000;
  
  // Farcaster pathway (primary for Web3 culture)
  pathways.push({
    platform: "farcaster",
    initialReach: Math.round(baseAudience * 0.6),
    cascadeMultiplier: memePotentialScore > 70 ? 3.5 : 2.0,
    expectedPeakDay: 2,
  });
  
  // X pathway (secondary, larger reach potential)
  if (memePotentialScore > 50) {
    pathways.push({
      platform: "x",
      initialReach: Math.round(baseAudience * 1.2),
      cascadeMultiplier: memePotentialScore > 70 ? 4.0 : 2.5,
      expectedPeakDay: 3,
    });
  }
  
  // TikTok pathway (for highly memeable content)
  if (memePotentialScore > 75 && plannedPosts > 15) {
    pathways.push({
      platform: "tiktok",
      initialReach: Math.round(baseAudience * 0.3),
      cascadeMultiplier: 6.0, // TikTok has highest viral potential
      expectedPeakDay: 5,
    });
  }
  
  return pathways;
}

function calculateCulturalFitScore(
  scenario: Scenario,
  objects: SimObjectRef[]
): number {
  let score = 50; // Neutral baseline
  
  // Web3-native categories have high cultural fit
  const web3Categories = ["culture-launch", "token-launch", "pickleball"];
  if (web3Categories.some(cat => scenario.category.includes(cat))) {
    score += 20;
  }
  
  // Object diversity indicates cultural understanding
  const uniqueTypes = new Set(objects.map(o => o.type));
  score += Math.min(uniqueTypes.size * 5, 20);
  
  // Tags indicating cultural awareness
  const culturalTags = ["base", "onchain", "crypto", "web3", "defi", "nft"];
  const culturalTagCount = scenario.tags.filter(tag =>
    culturalTags.some(ct => tag.toLowerCase().includes(ct))
  ).length;
  
  score += culturalTagCount * 5;
  
  return Math.min(Math.max(score, 0), 100);
}

export function predictMemeVelocity(scenarioId: string): MemeVelocityMetrics | null {
  const scenario = getScenario(scenarioId);
  if (!scenario) return null;
  
  const inputs = getScenarioInputs(scenarioId);
  const objects = scenario.simObjectIds
    .map(id => getSimObjectRef(id))
    .filter((obj): obj is SimObjectRef => obj !== null);
  
  const memePotentialScore = calculateMemePotentialScore(objects, inputs, scenario);
  const remixabilityScore = calculateRemixabilityScore(objects, scenario);
  const culturalFitScore = calculateCulturalFitScore(scenario, objects);
  const viralPathways = predictViralPathways(memePotentialScore, inputs);
  
  // Calculate expected remix count
  const plannedPosts = inputs.find(i => i.key === "plannedPosts")?.valueNumber || 10;
  const remixMultiplier = (remixabilityScore / 100) * (memePotentialScore / 100);
  const expectedRemixCount = Math.round(plannedPosts * remixMultiplier * 15);
  
  // Peak virality occurs when meme potential is highest
  const peakViralityDay = memePotentialScore > 75 ? 3 : 5;
  
  // Decay rate (higher meme potential = slower decay)
  const decayRate = memePotentialScore > 70 ? 0.15 : 0.25;
  
  const metrics = createMemeVelocityMetrics({
    scenarioId,
    memePotentialScore: Math.round(memePotentialScore),
    remixabilityScore: Math.round(remixabilityScore),
    viralPathways,
    expectedRemixCount,
    peakViralityDay,
    decayRate,
    culturalFitScore: Math.round(culturalFitScore),
  });
  
  return metrics;
}

export function generateMemeVelocityInsight(metrics: MemeVelocityMetrics): string {
  let insight = `## Meme Velocity Prediction\n\n`;
  
  insight += `**Meme Potential Score: ${metrics.memePotentialScore}/100**\n\n`;
  
  if (metrics.memePotentialScore >= 75) {
    insight += `🔥 **High Meme Potential** - This scenario has strong viral characteristics.\n\n`;
  } else if (metrics.memePotentialScore >= 50) {
    insight += `✅ **Moderate Meme Potential** - Solid foundation for organic spread.\n\n`;
  } else {
    insight += `📊 **Lower Meme Potential** - Consider adding more remixable elements.\n\n`;
  }
  
  insight += `**Remixability:** ${metrics.remixabilityScore}/100\n`;
  insight += `**Cultural Fit:** ${metrics.culturalFitScore}/100\n`;
  insight += `**Expected Remixes:** ${metrics.expectedRemixCount}\n`;
  insight += `**Peak Virality:** Day ${metrics.peakViralityDay}\n`;
  insight += `**Decay Rate:** ${(metrics.decayRate * 100).toFixed(0)}% per week\n\n`;
  
  insight += `**Viral Pathways:**\n`;
  metrics.viralPathways.forEach(pathway => {
    insight += `- **${pathway.platform.charAt(0).toUpperCase() + pathway.platform.slice(1)}**: `;
    insight += `${pathway.initialReach.toLocaleString()} initial → `;
    insight += `${Math.round(pathway.initialReach * pathway.cascadeMultiplier).toLocaleString()} peak `;
    insight += `(${pathway.cascadeMultiplier}x cascade, day ${pathway.expectedPeakDay})\n`;
  });
  
  insight += `\n**Strategy Tips:**\n`;
  if (metrics.memePotentialScore > 70) {
    insight += `- Front-load your best content in the first 3 days\n`;
    insight += `- Encourage remixes explicitly with templates or challenges\n`;
  }
  if (metrics.viralPathways.length > 2) {
    insight += `- Cross-post strategically across platforms for maximum cascade\n`;
  }
  if (metrics.decayRate > 0.2) {
    insight += `- Plan refresh content to counter decay after week 2\n`;
  }
  
  return insight;
}
