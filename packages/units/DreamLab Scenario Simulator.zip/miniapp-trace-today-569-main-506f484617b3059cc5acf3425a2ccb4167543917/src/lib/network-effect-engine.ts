// Network Effect Modeling Engine
import type { Scenario, ScenarioInput } from "@/types/simulation";
import type { NetworkSimulation, NetworkEffect } from "@/types/advanced-features";
import { getScenario, getScenarioInputs, getLatestScenarioRunResult } from "./simulation-storage";
import { createNetworkSimulation } from "./advanced-storage";

// Predefined network effects based on Web3 ecosystem knowledge
const NETWORK_EFFECTS: NetworkEffect[] = [
  {
    id: "farcaster-x",
    name: "Farcaster → X Cascade",
    description: "Launching on Farcaster first primes X audience",
    sourceNetwork: "Farcaster",
    targetNetworks: ["X"],
    cascadeMultiplier: 1.4,
    timingBonus: 0.2,
    requiredCriticalMass: 5000,
  },
  {
    id: "x-tiktok",
    name: "X → TikTok Cascade",
    description: "X momentum can trigger TikTok viral spread",
    sourceNetwork: "X",
    targetNetworks: ["TikTok"],
    cascadeMultiplier: 2.5,
    timingBonus: 0.3,
    requiredCriticalMass: 50000,
  },
  {
    id: "farcaster-base",
    name: "Farcaster → Base Community",
    description: "Farcaster culture amplifies Base builder engagement",
    sourceNetwork: "Farcaster",
    targetNetworks: ["Base Builders", "Onchain Community"],
    cascadeMultiplier: 1.8,
    timingBonus: 0.25,
    requiredCriticalMass: 3000,
  },
  {
    id: "base-defi",
    name: "Base → DeFi Community",
    description: "Base ecosystem adoption drives DeFi protocol interest",
    sourceNetwork: "Base Builders",
    targetNetworks: ["DeFi Community"],
    cascadeMultiplier: 1.5,
    timingBonus: 0.15,
    requiredCriticalMass: 10000,
  },
];

function determineOptimalSequence(
  baseReach: number,
  availableNetworks: NetworkEffect[]
): string[] {
  const sequence: string[] = [];
  let currentReach = baseReach;
  const activated = new Set<string>();
  
  // Start with networks that have lowest critical mass
  const sortedEffects = [...availableNetworks].sort(
    (a, b) => a.requiredCriticalMass - b.requiredCriticalMass
  );
  
  // Build sequence by checking which networks can be activated
  for (const effect of sortedEffects) {
    if (currentReach >= effect.requiredCriticalMass && !activated.has(effect.sourceNetwork)) {
      sequence.push(effect.sourceNetwork);
      activated.add(effect.sourceNetwork);
      
      // Add target networks that get activated
      effect.targetNetworks.forEach(target => {
        if (!activated.has(target)) {
          sequence.push(target);
          activated.add(target);
        }
      });
      
      // Update reach with cascade bonus
      currentReach *= effect.cascadeMultiplier;
    }
  }
  
  return sequence;
}

function calculateCrossNetworkReach(
  baseReach: number,
  sequence: string[],
  networkEffects: NetworkEffect[]
): Record<string, number> {
  const reaches: Record<string, number> = {};
  let currentReach = baseReach;
  
  sequence.forEach((network, index) => {
    // Find effect that activates this network
    const effect = networkEffects.find(
      e => e.sourceNetwork === network || e.targetNetworks.includes(network)
    );
    
    if (effect) {
      const multiplier = index === 0 ? 1.0 : effect.cascadeMultiplier;
      const bonus = index > 0 ? 1 + effect.timingBonus : 1.0;
      currentReach *= multiplier * bonus;
    }
    
    reaches[network] = Math.round(currentReach);
  });
  
  return reaches;
}

export function modelNetworkEffects(scenarioId: string): NetworkSimulation | null {
  const scenario = getScenario(scenarioId);
  if (!scenario) return null;
  
  const result = getLatestScenarioRunResult(scenarioId);
  if (!result) return null;
  
  const baseReach = result.outputMetrics.estimatedReach;
  
  // Filter network effects that are relevant and achievable
  const applicableEffects = NETWORK_EFFECTS.filter(
    effect => baseReach >= effect.requiredCriticalMass * 0.5 // 50% threshold for consideration
  );
  
  const optimalSequence = determineOptimalSequence(baseReach, applicableEffects);
  const projectedReaches = calculateCrossNetworkReach(baseReach, optimalSequence, applicableEffects);
  
  // Calculate cascade breakpoints
  const cascadeBreakpoints = applicableEffects.map(effect => ({
    network: effect.targetNetworks[0],
    reachThreshold: effect.requiredCriticalMass,
    multiplierGained: effect.cascadeMultiplier,
  }));
  
  const simulation = createNetworkSimulation({
    scenarioId,
    networkEffects: applicableEffects,
    optimalSequence,
    projectedCrossNetworkReach: projectedReaches,
    cascadeBreakpoints,
  });
  
  return simulation;
}

export function generateNetworkEffectInsight(simulation: NetworkSimulation): string {
  let insight = `## Network Effect Simulation\n\n`;
  
  insight += `**Optimal Launch Sequence:**\n`;
  simulation.optimalSequence.forEach((network, index) => {
    const reach = simulation.projectedCrossNetworkReach[network];
    insight += `${index + 1}. **${network}**: ${reach ? reach.toLocaleString() : 'N/A'} projected reach\n`;
  });
  insight += `\n`;
  
  insight += `**Cross-Network Amplification:**\n`;
  const totalReach = Object.values(simulation.projectedCrossNetworkReach).reduce((sum, r) => sum + r, 0);
  const initialReach = simulation.projectedCrossNetworkReach[simulation.optimalSequence[0]] || 0;
  const amplification = initialReach > 0 ? totalReach / initialReach : 1;
  
  insight += `- Total projected reach: ${totalReach.toLocaleString()}\n`;
  insight += `- Network amplification: ${amplification.toFixed(1)}x\n\n`;
  
  if (simulation.cascadeBreakpoints.length > 0) {
    insight += `**Cascade Breakpoints:**\n`;
    simulation.cascadeBreakpoints.forEach(bp => {
      insight += `- **${bp.network}**: Need ${bp.reachThreshold.toLocaleString()} reach to unlock `;
      insight += `${bp.multiplierGained}x cascade multiplier\n`;
    });
    insight += `\n`;
  }
  
  insight += `**Strategy Recommendation:**\n`;
  if (simulation.optimalSequence.length >= 3) {
    insight += `Strong multi-network potential. Launch sequentially following the optimal order above to maximize cascade effects.`;
  } else if (simulation.optimalSequence.length === 2) {
    insight += `Dual-network strategy recommended. Focus on establishing presence in ${simulation.optimalSequence[0]} before expanding.`;
  } else {
    insight += `Single-network launch. Build critical mass before attempting cross-network expansion.`;
  }
  
  return insight;
}
