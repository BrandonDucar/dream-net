// Risk Heat Map Generation Engine
import type { Scenario, ScenarioInput, AssumptionSet } from "@/types/simulation";
import type { RiskHeatMap, RiskCategory } from "@/types/advanced-features";
import { getScenario, getScenarioInputs, getAssumptionSet } from "./simulation-storage";
import { getCompetitiveScenario } from "./advanced-storage";
import { createRiskHeatMap } from "./advanced-storage";

function assessTimingRisk(
  scenario: Scenario,
  inputs: ScenarioInput[]
): RiskCategory {
  const now = new Date();
  const start = scenario.timeWindowStart ? new Date(scenario.timeWindowStart) : null;
  
  let severity: "low" | "medium" | "high" | "critical" = "low";
  let probability = 20;
  let mitigation = "Standard launch timing";
  
  if (start) {
    const daysUntilLaunch = Math.ceil((start.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntilLaunch < 3) {
      severity = "high";
      probability = 70;
      mitigation = "Very tight timeline. Ensure all assets and messaging are finalized.";
    } else if (daysUntilLaunch < 7) {
      severity = "medium";
      probability = 50;
      mitigation = "Short preparation window. Prioritize critical path tasks.";
    }
  }
  
  // Check for holidays or major crypto events (simplified heuristic)
  const month = start ? start.getMonth() : now.getMonth();
  if (month === 11 || month === 0) { // December or January
    severity = severity === "low" ? "medium" : severity;
    probability += 20;
    mitigation += " Consider holiday season impact on engagement.";
  }
  
  return {
    category: "timing",
    severity,
    probability: Math.min(probability, 100),
    impact: 40,
    mitigation,
  };
}

function assessFatigueRisk(
  assumptions: AssumptionSet,
  inputs: ScenarioInput[]
): RiskCategory {
  const fatigueFactor = assumptions.fatigueFactor;
  const plannedPosts = inputs.find(i => i.key === "plannedPosts")?.valueNumber || 10;
  
  let severity: "low" | "medium" | "high" | "critical" = "low";
  let probability = fatigueFactor * 100;
  let impact = 30;
  
  if (fatigueFactor > 0.4) {
    severity = "high";
    impact = 60;
  } else if (fatigueFactor > 0.25) {
    severity = "medium";
    impact = 45;
  }
  
  if (plannedPosts > 50) {
    severity = severity === "low" ? "medium" : "critical";
    probability += 20;
    impact += 15;
  }
  
  const mitigation = severity === "high" || severity === "critical"
    ? "High posting volume + high fatigue factor. Space out content and use varied formats."
    : "Monitor engagement metrics closely. Adjust posting frequency if needed.";
  
  return {
    category: "fatigue",
    severity,
    probability: Math.min(probability, 100),
    impact: Math.min(impact, 100),
    mitigation,
  };
}

function assessCompetitionRisk(scenarioId: string): RiskCategory {
  const competitiveScenario = getCompetitiveScenario(scenarioId);
  
  if (!competitiveScenario || competitiveScenario.competitors.length === 0) {
    return {
      category: "competition",
      severity: "low",
      probability: 10,
      impact: 20,
      mitigation: "No major competitive threats identified.",
    };
  }
  
  const { competitors, marketSaturation, timingConflicts } = competitiveScenario;
  const criticalCompetitors = competitors.filter(c => c.estimatedImpact === "critical").length;
  
  let severity: "low" | "medium" | "high" | "critical" = "low";
  let probability = marketSaturation;
  let impact = 40;
  
  if (criticalCompetitors > 0 || timingConflicts > 2) {
    severity = "critical";
    probability = 80;
    impact = 70;
  } else if (timingConflicts > 0 || marketSaturation > 50) {
    severity = "high";
    probability = 60;
    impact = 55;
  } else if (competitors.length > 1) {
    severity = "medium";
    probability = 40;
    impact = 40;
  }
  
  const mitigation = severity === "critical"
    ? "Critical competitive pressure. Consider delaying or repositioning."
    : severity === "high"
    ? "Significant competition. Differentiate messaging and consider timing adjustments."
    : "Moderate competition. Monitor closely and be ready to adapt.";
  
  return {
    category: "competition",
    severity,
    probability: Math.min(probability, 100),
    impact: Math.min(impact, 100),
    mitigation,
  };
}

function assessTechRisk(scenario: Scenario, inputs: ScenarioInput[]): RiskCategory {
  const drops = inputs.find(i => i.key === "plannedDrops")?.valueNumber || 0;
  const objectCount = scenario.simObjectIds.length;
  
  let severity: "low" | "medium" | "high" | "critical" = "low";
  let probability = 15;
  let impact = 50;
  
  // More complex scenarios have higher tech risk
  if (drops > 2 || objectCount > 5) {
    severity = "medium";
    probability = 35;
    impact = 60;
  }
  
  if (drops > 5 || objectCount > 8) {
    severity = "high";
    probability = 50;
    impact = 75;
  }
  
  const mitigation = severity === "high"
    ? "Complex technical setup. Test thoroughly and have rollback plans."
    : severity === "medium"
    ? "Moderate technical complexity. Validate all integrations before launch."
    : "Standard technical requirements. Follow normal QA procedures.";
  
  return {
    category: "tech",
    severity,
    probability: Math.min(probability, 100),
    impact: Math.min(impact, 100),
    mitigation,
  };
}

function assessMarketRisk(assumptions: AssumptionSet): RiskCategory {
  const baseReachFactor = assumptions.baseReachFactor;
  const riskMultiplier = assumptions.riskMultiplierHigh;
  
  let severity: "low" | "medium" | "high" | "critical" = "low";
  let probability = 30;
  let impact = 40;
  
  if (baseReachFactor < 0.8) {
    severity = "medium";
    probability = 50;
    impact = 55;
  }
  
  if (riskMultiplier > 1.5) {
    severity = severity === "low" ? "medium" : "high";
    probability += 20;
    impact += 15;
  }
  
  const mitigation = severity === "high"
    ? "Bearish market conditions with high risk multiplier. Prepare for volatility."
    : "Standard market conditions. Monitor sentiment and be ready to adapt.";
  
  return {
    category: "market",
    severity,
    probability: Math.min(probability, 100),
    impact: Math.min(impact, 100),
    mitigation,
  };
}

function assessExecutionRisk(
  scenario: Scenario,
  inputs: ScenarioInput[]
): RiskCategory {
  const highRiskActions = inputs.find(i => i.key === "highRiskActions")?.valueNumber || 0;
  const objectCount = scenario.simObjectIds.length;
  
  let severity: "low" | "medium" | "high" | "critical" = "low";
  let probability = 25;
  let impact = 35;
  
  if (highRiskActions > 2 || objectCount > 6) {
    severity = "medium";
    probability = 45;
    impact = 50;
  }
  
  if (highRiskActions > 4 || objectCount > 10) {
    severity = "high";
    probability = 65;
    impact = 70;
  }
  
  const mitigation = severity === "high"
    ? "Complex execution with multiple moving parts. Assign clear owners and checkpoints."
    : severity === "medium"
    ? "Moderate execution complexity. Use project management tools and daily standups."
    : "Straightforward execution. Standard monitoring sufficient.";
  
  return {
    category: "execution",
    severity,
    probability: Math.min(probability, 100),
    impact: Math.min(impact, 100),
    mitigation,
  };
}

function calculateVolatilityIndex(risks: RiskCategory[]): number {
  const highRisks = risks.filter(r => r.severity === "high" || r.severity === "critical");
  const averageProbability = risks.reduce((sum, r) => sum + r.probability, 0) / risks.length;
  const averageImpact = risks.reduce((sum, r) => sum + r.impact, 0) / risks.length;
  
  const volatility = (highRisks.length * 15) + (averageProbability * 0.3) + (averageImpact * 0.2);
  
  return Math.min(Math.round(volatility), 100);
}

function determineRiskDistribution(
  risks: RiskCategory[]
): "stable" | "moderate" | "lumpy" | "black-swan-prone" {
  const critical = risks.filter(r => r.severity === "critical").length;
  const high = risks.filter(r => r.severity === "high").length;
  const highProbability = risks.filter(r => r.probability > 60).length;
  
  if (critical > 0 || (high > 2 && highProbability > 2)) {
    return "black-swan-prone";
  }
  
  if (high > 1 || highProbability > 2) {
    return "lumpy";
  }
  
  if (high > 0 || highProbability > 0) {
    return "moderate";
  }
  
  return "stable";
}

function identifyBlackSwanScenarios(risks: RiskCategory[]): Array<{
  description: string;
  probability: number;
  impact: string;
}> {
  const blackSwans: Array<{ description: string; probability: number; impact: string }> = [];
  
  const criticalRisks = risks.filter(r => r.severity === "critical");
  const highImpactRisks = risks.filter(r => r.impact > 70);
  
  criticalRisks.forEach(risk => {
    blackSwans.push({
      description: `${risk.category.charAt(0).toUpperCase() + risk.category.slice(1)} failure: ${risk.mitigation}`,
      probability: risk.probability,
      impact: "Critical",
    });
  });
  
  highImpactRisks.forEach(risk => {
    if (!criticalRisks.includes(risk)) {
      blackSwans.push({
        description: `Severe ${risk.category} disruption`,
        probability: risk.probability * 0.6, // Lower probability for non-critical
        impact: "High",
      });
    }
  });
  
  // Add generic black swan events
  if (risks.some(r => r.category === "market" && r.severity !== "low")) {
    blackSwans.push({
      description: "Sudden market crash or regulatory action",
      probability: 5,
      impact: "Critical",
    });
  }
  
  return blackSwans.slice(0, 3); // Top 3 black swan scenarios
}

export function generateRiskHeatMap(scenarioId: string): RiskHeatMap | null {
  const scenario = getScenario(scenarioId);
  if (!scenario) return null;
  
  const inputs = getScenarioInputs(scenarioId);
  const assumptions = getAssumptionSet(scenario.assumptionSetId);
  if (!assumptions) return null;
  
  const risks: RiskCategory[] = [
    assessTimingRisk(scenario, inputs),
    assessFatigueRisk(assumptions, inputs),
    assessCompetitionRisk(scenarioId),
    assessTechRisk(scenario, inputs),
    assessMarketRisk(assumptions),
    assessExecutionRisk(scenario, inputs),
  ];
  
  const overallRiskScore = risks.reduce(
    (sum, r) => sum + (r.probability * r.impact / 100),
    0
  ) / risks.length;
  
  const riskDistribution = determineRiskDistribution(risks);
  const volatilityIndex = calculateVolatilityIndex(risks);
  const blackSwanScenarios = identifyBlackSwanScenarios(risks);
  
  const heatMap = createRiskHeatMap({
    scenarioId,
    risks,
    overallRiskScore: Math.round(overallRiskScore),
    riskDistribution,
    volatilityIndex,
    blackSwanScenarios,
  });
  
  return heatMap;
}

export function generateRiskHeatMapInsight(heatMap: RiskHeatMap): string {
  let insight = `## Risk Heat Map Analysis\n\n`;
  
  insight += `**Overall Risk Score: ${heatMap.overallRiskScore}/100**\n`;
  insight += `**Risk Distribution: ${heatMap.riskDistribution}**\n`;
  insight += `**Volatility Index: ${heatMap.volatilityIndex}/100**\n\n`;
  
  // Risk matrix
  insight += `**Risk Categories:**\n\n`;
  insight += `| Category | Severity | Probability | Impact |\n`;
  insight += `|----------|----------|-------------|--------|\n`;
  heatMap.risks.forEach(risk => {
    const icon = risk.severity === "critical" ? "🚨" : risk.severity === "high" ? "⚠️" : risk.severity === "medium" ? "⚡" : "✅";
    insight += `| ${icon} ${risk.category} | ${risk.severity} | ${risk.probability}% | ${risk.impact}% |\n`;
  });
  insight += `\n`;
  
  // Mitigation strategies
  const highPriorityRisks = heatMap.risks.filter(r => r.severity === "high" || r.severity === "critical");
  if (highPriorityRisks.length > 0) {
    insight += `**Priority Mitigations:**\n`;
    highPriorityRisks.forEach(risk => {
      insight += `- **${risk.category}**: ${risk.mitigation}\n`;
    });
    insight += `\n`;
  }
  
  // Black swan scenarios
  if (heatMap.blackSwanScenarios.length > 0) {
    insight += `**Black Swan Scenarios (Low Probability, High Impact):**\n`;
    heatMap.blackSwanScenarios.forEach((bs, idx) => {
      insight += `${idx + 1}. ${bs.description} (${bs.probability.toFixed(1)}% probability, ${bs.impact} impact)\n`;
    });
    insight += `\n`;
  }
  
  // Overall assessment
  insight += `**Overall Assessment:** `;
  if (heatMap.riskDistribution === "stable") {
    insight += `This scenario has stable, predictable risk characteristics. Proceed with confidence.`;
  } else if (heatMap.riskDistribution === "moderate") {
    insight += `Moderate risk profile with some variability. Standard risk management practices apply.`;
  } else if (heatMap.riskDistribution === "lumpy") {
    insight += `Lumpy risk distribution with potential for significant variance. Prepare contingency plans.`;
  } else {
    insight += `Black-swan-prone scenario with high-impact tail risks. Consider risk reduction measures before proceeding.`;
  }
  
  return insight;
}
