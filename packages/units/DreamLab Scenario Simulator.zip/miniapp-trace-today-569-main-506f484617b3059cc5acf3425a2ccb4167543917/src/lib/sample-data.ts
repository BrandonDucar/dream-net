import {
  createSimObjectRef,
  createAssumptionSet,
  createSimulationModel,
  listSimObjectRefs,
  listAssumptionSets,
  listSimulationModels,
} from './simulation-storage';
import { generateSEOForAssumptionSet, generateSEOForSimulationModel } from './seo-generator';
import { createHistoricalPattern, listHistoricalPatterns } from './advanced-storage';
import { initializeSampleTournaments } from './tournament-engine';
import { initializeSampleBenchmarks } from './benchmark-engine';

export function initializeSampleData(): void {
  if (typeof window === 'undefined') return;

  const existingObjects = listSimObjectRefs();
  const existingAssumptions = listAssumptionSets();
  const existingModels = listSimulationModels();
  const existingHistoricalPatterns = listHistoricalPatterns();

  if (existingObjects.length > 0 || existingAssumptions.length > 0 || existingModels.length > 0) {
    return;
  }

  // Initialize advanced features
  if (existingHistoricalPatterns.length === 0) {
    initializeHistoricalPatterns();
  }
  initializeSampleTournaments();
  initializeSampleBenchmarks();

  createSimObjectRef({
    type: 'culture-coin',
    name: 'DREAM Token',
    description: 'Base culture coin for DreamNet ecosystem',
    sourceApp: 'CultureCoin Forge',
    externalRef: '0x1234...abcd',
    tags: ['base', 'culture', 'token'],
    notes: 'Primary ecosystem token',
  });

  createSimObjectRef({
    type: 'drop',
    name: 'Jaggy Season 1 Drop',
    description: 'Limited edition Jaggy character NFT drop',
    sourceApp: 'Drop Architect',
    externalRef: null,
    tags: ['nft', 'limited', 'character'],
    notes: 'First season character release',
  });

  createSimObjectRef({
    type: 'campaign',
    name: 'PickleRank Launch Campaign',
    description: 'Launch campaign for pickleball ranking system',
    sourceApp: 'Action Router',
    externalRef: null,
    tags: ['pickleball', 'launch', 'ranking'],
    notes: 'Multi-phase launch with influencer partnerships',
  });

  createSimObjectRef({
    type: 'content-stream',
    name: 'Meme Engine Daily',
    description: 'Daily meme content generation and distribution',
    sourceApp: 'MemeEngine',
    externalRef: null,
    tags: ['meme', 'viral', 'daily'],
    notes: 'Automated meme creation and posting',
  });

  const bullishSEO = generateSEOForAssumptionSet('Bullish Base Week', 'High activity market conditions');
  createAssumptionSet({
    name: 'Bullish Base Week',
    description: 'High activity week on Base with elevated engagement across the ecosystem',
    baseReachFactor: 1.3,
    engagementFactor: 1.4,
    conversionFactor: 1.2,
    remixFactor: 1.5,
    fatigueFactor: 0.15,
    riskMultiplierHigh: 1.8,
    notes: 'Optimal conditions for launches',
    tags: ['bullish', 'high-activity', 'base'],
    ...bullishSEO,
  });

  const normalSEO = generateSEOForAssumptionSet('Normal Week', 'Baseline market conditions');
  createAssumptionSet({
    name: 'Normal Week',
    description: 'Baseline conditions with standard engagement and reach',
    baseReachFactor: 1.0,
    engagementFactor: 1.0,
    conversionFactor: 1.0,
    remixFactor: 1.0,
    fatigueFactor: 0.25,
    riskMultiplierHigh: 1.5,
    notes: 'Standard baseline assumptions',
    tags: ['baseline', 'normal'],
    ...normalSEO,
  });

  const quietSEO = generateSEOForAssumptionSet('Quiet Season', 'Low activity period');
  createAssumptionSet({
    name: 'Quiet Season',
    description: 'Lower activity period with reduced engagement',
    baseReachFactor: 0.7,
    engagementFactor: 0.8,
    conversionFactor: 0.85,
    remixFactor: 0.6,
    fatigueFactor: 0.35,
    riskMultiplierHigh: 1.2,
    notes: 'Conservative assumptions for low-activity periods',
    tags: ['quiet', 'conservative', 'low-activity'],
    ...quietSEO,
  });

  const cultureSEO = generateSEOForSimulationModel(
    'Culture Launch Model v1',
    'Predicts outcomes for culture coin launches'
  );
  createSimulationModel({
    name: 'Culture Launch Model v1',
    description: 'Predicts reach, engagement, and conversion for culture coin + drop launches',
    version: 'v1.0',
    appliesToTypes: ['culture-coin', 'drop', 'campaign'],
    inputMetrics: [
      'plannedPosts',
      'plannedDrops',
      'baseAudience',
      'initialResonance',
      'highRiskActions',
    ],
    outputMetrics: [
      'estimatedReach',
      'estimatedConversions',
      'estimatedMints',
      'remixCount',
      'resonanceScore',
      'engagementRate',
      'estimatedTraffic',
      'viralCoefficient',
    ],
    heuristicDescription: `This model calculates outcomes based on:
1. Base score from planned posts and drops, multiplied by baseReachFactor
2. Applies engagement multiplier and fatigue penalty over time
3. Calculates conversions using conversionFactor
4. Estimates remix/viral potential using remixFactor
5. High-risk actions amplify both potential gains and variance
6. Generates resonance score (0-100) based on all factors
7. Provides narrative summary and recommended actions`,
    tags: ['culture', 'launch', 'v1'],
    notes: 'First iteration of culture launch prediction model',
    ...cultureSEO,
  });

  const pickleballSEO = generateSEOForSimulationModel(
    'Pickleball Engagement Model',
    'Predicts engagement for pickleball programs'
  );
  createSimulationModel({
    name: 'Pickleball Engagement Model',
    description: 'Predicts engagement and growth for pickleball programs and campaigns',
    version: 'v0.9',
    appliesToTypes: ['pickleball-program', 'campaign', 'content-stream'],
    inputMetrics: [
      'plannedPosts',
      'baseAudience',
      'segmentSize',
      'partnershipCount',
      'initialResonance',
    ],
    outputMetrics: [
      'estimatedReach',
      'estimatedConversions',
      'remixCount',
      'resonanceScore',
      'engagementRate',
      'communityGrowth',
    ],
    heuristicDescription: `Pickleball-focused model that:
1. Factors in partnership multipliers for influencer collaborations
2. Calculates community growth based on segment size and engagement
3. Models viral spread through pickleball networks
4. Considers seasonal factors and tournament timing
5. Provides community-building recommendations`,
    tags: ['pickleball', 'sports', 'community'],
    notes: 'Experimental model for pickleball vertical',
    ...pickleballSEO,
  });
}

function initializeHistoricalPatterns(): void {
  // Historical Pattern 1: Degen Launch Feb 2024
  createHistoricalPattern({
    name: 'Degen Token Launch (Feb 2024)',
    description: 'Successful Farcaster-native token launch with high community engagement',
    category: 'culture-launch',
    dateRange: {
      start: '2024-02-01T00:00:00Z',
      end: '2024-02-14T00:00:00Z',
    },
    actualOutcomes: {
      reach: 45000,
      conversions: 2800,
      resonanceScore: 87,
      viralCoefficient: 3.2,
    },
    contextTags: ['farcaster', 'culture', 'token', 'community-driven'],
    scenarioFingerprint: 'culture-token-high-engagement',
  });

  // Historical Pattern 2: Base Builder Season 1
  createHistoricalPattern({
    name: 'Base Builder Season 1 Campaign',
    description: 'Multi-week campaign targeting Base builders with educational content',
    category: 'campaign',
    dateRange: {
      start: '2024-03-15T00:00:00Z',
      end: '2024-04-15T00:00:00Z',
    },
    actualOutcomes: {
      reach: 22000,
      conversions: 950,
      resonanceScore: 72,
      viralCoefficient: 1.8,
    },
    contextTags: ['base', 'builders', 'education', 'campaign'],
    scenarioFingerprint: 'campaign-education-moderate',
  });

  // Historical Pattern 3: Zora Creator Drop
  createHistoricalPattern({
    name: 'Zora Creator NFT Drop (Jan 2024)',
    description: 'Limited edition creator NFT drop with strong collector base',
    category: 'drop',
    dateRange: {
      start: '2024-01-20T00:00:00Z',
      end: '2024-01-27T00:00:00Z',
    },
    actualOutcomes: {
      reach: 18000,
      conversions: 1200,
      resonanceScore: 79,
      viralCoefficient: 2.1,
    },
    contextTags: ['nft', 'drop', 'creators', 'zora'],
    scenarioFingerprint: 'drop-creator-high-conversion',
  });

  // Historical Pattern 4: Quiet Week Experiment
  createHistoricalPattern({
    name: 'Holiday Season Test Campaign',
    description: 'Small test campaign during December holidays showing reduced engagement',
    category: 'campaign',
    dateRange: {
      start: '2023-12-20T00:00:00Z',
      end: '2024-01-05T00:00:00Z',
    },
    actualOutcomes: {
      reach: 8500,
      conversions: 320,
      resonanceScore: 48,
      viralCoefficient: 0.9,
    },
    contextTags: ['holiday', 'low-activity', 'test'],
    scenarioFingerprint: 'campaign-quiet-low-reach',
  });

  // Historical Pattern 5: Viral Meme Campaign
  createHistoricalPattern({
    name: 'OnlyFrames Meme Campaign',
    description: 'Highly viral meme-driven campaign with exceptional organic spread',
    category: 'campaign',
    dateRange: {
      start: '2024-02-10T00:00:00Z',
      end: '2024-02-17T00:00:00Z',
    },
    actualOutcomes: {
      reach: 67000,
      conversions: 1800,
      resonanceScore: 91,
      viralCoefficient: 4.5,
    },
    contextTags: ['meme', 'viral', 'frames', 'farcaster'],
    scenarioFingerprint: 'campaign-meme-viral-high',
  });
}
