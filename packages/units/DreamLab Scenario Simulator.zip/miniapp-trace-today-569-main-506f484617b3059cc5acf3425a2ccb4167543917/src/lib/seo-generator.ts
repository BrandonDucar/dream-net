export interface SEOMetadata {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export function generateSEOForAssumptionSet(name: string, description: string): SEOMetadata {
  const keywords = [
    "simulation assumptions",
    "market conditions",
    name.toLowerCase(),
    "scenario planning",
    "DreamNet",
  ];

  const hashtags = [
    "#DreamNet",
    "#SimulationLab",
    "#ScenarioPlanning",
    `#${name.replace(/\s+/g, "")}`,
  ];

  return {
    seoTitle: `${name} - Assumption Set | DreamNet Simulation Lab`,
    seoDescription: `${description.substring(0, 150)}... Market conditions and multiplier factors for scenario simulation.`,
    seoKeywords: keywords,
    seoHashtags: hashtags,
    altText: `Assumption Set: ${name}`,
  };
}

export function generateSEOForSimulationModel(name: string, description: string): SEOMetadata {
  const keywords = [
    "simulation model",
    "heuristic prediction",
    name.toLowerCase(),
    "outcome modeling",
    "DreamNet",
  ];

  const hashtags = [
    "#DreamNet",
    "#SimulationModel",
    "#PredictiveAnalytics",
    `#${name.replace(/\s+/g, "")}`,
  ];

  return {
    seoTitle: `${name} - Simulation Model | DreamNet Lab`,
    seoDescription: `${description.substring(0, 150)}... Predictive model for scenario outcomes and projections.`,
    seoKeywords: keywords,
    seoHashtags: hashtags,
    altText: `Simulation Model: ${name}`,
  };
}

export function generateSEOForScenario(
  name: string,
  description: string,
  category: string
): SEOMetadata {
  const keywords = [
    "scenario simulation",
    category.toLowerCase(),
    name.toLowerCase(),
    "outcome projection",
    "DreamNet",
  ];

  const hashtags = [
    "#DreamNet",
    "#ScenarioLab",
    `#${category.replace(/\s+/g, "")}`,
    `#${name.replace(/\s+/g, "")}`,
  ];

  return {
    seoTitle: `${name} - Scenario | DreamNet Simulation Lab`,
    seoDescription: `${description.substring(0, 150)}... Simulate outcomes and projections for ${category}.`,
    seoKeywords: keywords,
    seoHashtags: hashtags,
    altText: `Scenario: ${name}`,
  };
}
