import type {
  Scenario,
  AssumptionSet,
  SimulationModel,
  ScenarioInput,
  SimObjectRef,
  ScenarioRunResult,
} from "@/types/simulation";
import {
  getScenario,
  getAssumptionSet,
  getSimulationModel,
  getScenarioInputs,
  getSimObjectRef,
  createScenarioRunResult,
} from "./simulation-storage";

interface SimulationContext {
  scenario: Scenario;
  assumptions: AssumptionSet;
  model: SimulationModel;
  inputs: ScenarioInput[];
  objects: SimObjectRef[];
}

function getInputValue(inputs: ScenarioInput[], key: string, defaultValue: number = 0): number {
  const input = inputs.find((i: ScenarioInput) => i.key === key);
  return input?.valueNumber ?? defaultValue;
}

function calculateTimeWindowDays(scenario: Scenario): number {
  if (!scenario.timeWindowStart || !scenario.timeWindowEnd) return 7;
  
  const start = new Date(scenario.timeWindowStart);
  const end = new Date(scenario.timeWindowEnd);
  const diffTime = Math.abs(end.getTime() - start.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  return Math.max(1, diffDays);
}

function runHeuristicSimulation(context: SimulationContext): {
  outputMetrics: Record<string, number>;
  narrativeSummary: string;
  riskNotes: string;
  recommendedActions: string[];
} {
  const { scenario, assumptions, model, inputs, objects } = context;
  
  const days = calculateTimeWindowDays(scenario);
  const objectCount = objects.length;
  
  // Get key inputs
  const plannedPosts = getInputValue(inputs, "plannedPosts", 10);
  const plannedDrops = getInputValue(inputs, "plannedDrops", 0);
  const baseAudience = getInputValue(inputs, "baseAudience", 1000);
  const initialResonance = getInputValue(inputs, "initialResonance", 50);
  const highRiskActions = getInputValue(inputs, "highRiskActions", 0);
  
  // Base calculations
  let baseScore = plannedPosts * assumptions.baseReachFactor * 100;
  baseScore += plannedDrops * assumptions.baseReachFactor * 300;
  baseScore += baseAudience * 0.5;
  baseScore += objectCount * 150;
  
  // Apply engagement multiplier
  let estimatedReach = baseScore * assumptions.engagementFactor;
  
  // Apply fatigue over time
  const fatiguePenalty = 1 - (assumptions.fatigueFactor * (days / 30));
  estimatedReach *= Math.max(0.5, fatiguePenalty);
  
  // Conversions (mints, actions, etc.)
  let estimatedConversions = estimatedReach * assumptions.conversionFactor * 0.05;
  
  // Remix and viral potential
  const remixCount = estimatedReach * assumptions.remixFactor * 0.03;
  
  // High-risk actions amplify variance
  if (highRiskActions > 0) {
    estimatedReach *= (1 + highRiskActions * 0.1 * assumptions.riskMultiplierHigh);
    estimatedConversions *= (1 + highRiskActions * 0.15 * assumptions.riskMultiplierHigh);
  }
  
  // Resonance score (0-100)
  let resonanceScore = initialResonance;
  resonanceScore += assumptions.engagementFactor * 10;
  resonanceScore -= assumptions.fatigueFactor * 15;
  resonanceScore += (remixCount / estimatedReach) * 20;
  resonanceScore = Math.max(0, Math.min(100, resonanceScore));
  
  // Engagement rate
  const engagementRate = assumptions.engagementFactor * assumptions.conversionFactor * 100;
  
  // Traffic estimate
  const estimatedTraffic = estimatedReach * 1.5;
  
  // Mints (if drops involved)
  const estimatedMints = plannedDrops > 0 ? estimatedConversions * 0.7 : 0;
  
  const outputMetrics: Record<string, number> = {
    estimatedReach: Math.round(estimatedReach),
    estimatedConversions: Math.round(estimatedConversions),
    estimatedMints: Math.round(estimatedMints),
    remixCount: Math.round(remixCount),
    resonanceScore: Math.round(resonanceScore * 10) / 10,
    engagementRate: Math.round(engagementRate * 10) / 10,
    estimatedTraffic: Math.round(estimatedTraffic),
    viralCoefficient: Math.round(remixCount / plannedPosts * 100) / 100,
  };
  
  // Generate narrative summary
  const narrativeSummary = generateNarrative(context, outputMetrics);
  
  // Generate risk notes
  const riskNotes = generateRiskNotes(context, outputMetrics);
  
  // Generate recommended actions
  const recommendedActions = generateRecommendations(context, outputMetrics);
  
  return {
    outputMetrics,
    narrativeSummary,
    riskNotes,
    recommendedActions,
  };
}

function generateNarrative(context: SimulationContext, metrics: Record<string, number>): string {
  const { scenario, assumptions, objects } = context;
  
  const reach = metrics.estimatedReach;
  const conversions = metrics.estimatedConversions;
  const resonance = metrics.resonanceScore;
  
  let narrative = `## ${scenario.name} - Projection\n\n`;
  
  narrative += `Running this scenario with ${objects.length} configured objects under **${assumptions.name}** conditions.\n\n`;
  
  if (resonance >= 75) {
    narrative += `🔥 **High Impact Expected**: This scenario shows strong potential with a resonance score of ${resonance}/100. `;
  } else if (resonance >= 50) {
    narrative += `✅ **Moderate Impact Expected**: This scenario shows reasonable potential with a resonance score of ${resonance}/100. `;
  } else {
    narrative += `⚠️ **Lower Impact Expected**: This scenario shows modest potential with a resonance score of ${resonance}/100. `;
  }
  
  narrative += `Estimated reach of **${reach.toLocaleString()} people** with approximately **${conversions.toLocaleString()} conversions**.\n\n`;
  
  if (metrics.remixCount > reach * 0.05) {
    narrative += `**Viral Potential**: Strong remix activity expected (${metrics.remixCount.toLocaleString()} remixes), indicating high memetic spread potential.\n\n`;
  }
  
  if (assumptions.fatigueFactor > 0.3) {
    narrative += `**Attention Decay**: Moderate to high fatigue factor suggests diminishing returns over time. Consider spacing actions strategically.\n\n`;
  }
  
  narrative += `**Key Strengths**: ${identifyStrengths(context, metrics).join(", ")}.\n\n`;
  
  return narrative;
}

function identifyStrengths(context: SimulationContext, metrics: Record<string, number>): string[] {
  const strengths: string[] = [];
  const { assumptions } = context;
  
  if (assumptions.engagementFactor >= 1.2) {
    strengths.push("High engagement environment");
  }
  
  if (assumptions.conversionFactor >= 1.2) {
    strengths.push("Strong conversion potential");
  }
  
  if (metrics.viralCoefficient > 2) {
    strengths.push("Excellent viral coefficient");
  }
  
  if (metrics.resonanceScore >= 75) {
    strengths.push("High resonance with audience");
  }
  
  if (context.objects.length >= 3) {
    strengths.push("Multi-faceted approach");
  }
  
  return strengths.length > 0 ? strengths : ["Baseline performance expected"];
}

function generateRiskNotes(context: SimulationContext, metrics: Record<string, number>): string {
  const risks: string[] = [];
  const { assumptions, inputs } = context;
  
  const highRiskActions = getInputValue(inputs, "highRiskActions", 0);
  
  if (highRiskActions > 0) {
    risks.push(`${highRiskActions} high-risk actions increase both potential upside and variance. Monitor closely for unexpected outcomes.`);
  }
  
  if (assumptions.fatigueFactor > 0.4) {
    risks.push("High fatigue factor may lead to faster-than-expected attention decay. Consider refresh strategies.");
  }
  
  if (metrics.resonanceScore < 40) {
    risks.push("Low resonance score suggests potential audience misalignment. Validate messaging and targeting.");
  }
  
  if (assumptions.riskMultiplierHigh > 1.5) {
    risks.push("High risk multiplier amplifies both gains and losses. Ensure contingency plans are in place.");
  }
  
  const plannedPosts = getInputValue(inputs, "plannedPosts", 0);
  if (plannedPosts > 50) {
    risks.push("Very high posting volume may trigger spam filters or audience fatigue. Consider pacing.");
  }
  
  return risks.length > 0 ? risks.join(" ") : "No major risks identified. Standard monitoring recommended.";
}

function generateRecommendations(context: SimulationContext, metrics: Record<string, number>): string[] {
  const recommendations: string[] = [];
  const { assumptions, inputs } = context;
  
  if (assumptions.fatigueFactor > 0.3) {
    recommendations.push("Space out posts and actions to minimize fatigue effects");
  }
  
  if (metrics.viralCoefficient < 1) {
    recommendations.push("Boost MemeEngine early to increase remix potential");
  }
  
  const plannedDrops = getInputValue(inputs, "plannedDrops", 0);
  if (plannedDrops === 0 && metrics.resonanceScore > 60) {
    recommendations.push("Consider adding a drop to capitalize on high resonance");
  }
  
  if (assumptions.engagementFactor < 1.0) {
    recommendations.push("Enhance content quality or timing to boost engagement");
  }
  
  if (metrics.estimatedConversions < metrics.estimatedReach * 0.02) {
    recommendations.push("Optimize conversion funnels to improve conversion rate");
  }
  
  const highRiskActions = getInputValue(inputs, "highRiskActions", 0);
  if (highRiskActions > 2) {
    recommendations.push("Prepare contingency plans for high-risk action outcomes");
  }
  
  if (context.objects.length < 2) {
    recommendations.push("Consider adding more simulation objects for a richer scenario");
  }
  
  return recommendations.length > 0 ? recommendations : ["Scenario looks balanced. Proceed as planned and monitor results."];
}

export function runScenarioSimulation(scenarioId: string): ScenarioRunResult | null {
  const scenario = getScenario(scenarioId);
  if (!scenario) return null;
  
  const assumptions = getAssumptionSet(scenario.assumptionSetId);
  if (!assumptions) return null;
  
  const model = getSimulationModel(scenario.simulationModelId);
  if (!model) return null;
  
  const inputs = getScenarioInputs(scenarioId);
  const objects = scenario.simObjectIds
    .map((id: string) => getSimObjectRef(id))
    .filter((obj: SimObjectRef | null): obj is SimObjectRef => obj !== null);
  
  const context: SimulationContext = {
    scenario,
    assumptions,
    model,
    inputs,
    objects,
  };
  
  const simulation = runHeuristicSimulation(context);
  
  const inputSnapshot = JSON.stringify({
    assumptions: {
      name: assumptions.name,
      baseReachFactor: assumptions.baseReachFactor,
      engagementFactor: assumptions.engagementFactor,
      conversionFactor: assumptions.conversionFactor,
      remixFactor: assumptions.remixFactor,
      fatigueFactor: assumptions.fatigueFactor,
      riskMultiplierHigh: assumptions.riskMultiplierHigh,
    },
    inputs: inputs.map((i: ScenarioInput) => ({
      key: i.key,
      valueNumber: i.valueNumber,
      valueText: i.valueText,
    })),
    objects: objects.map((o: SimObjectRef) => ({
      type: o.type,
      name: o.name,
    })),
  });
  
  const result = createScenarioRunResult({
    scenarioId,
    runAt: new Date().toISOString(),
    modelVersion: model.version,
    inputSnapshot,
    outputMetrics: simulation.outputMetrics,
    narrativeSummary: simulation.narrativeSummary,
    riskNotes: simulation.riskNotes,
    recommendedActions: simulation.recommendedActions,
    tags: scenario.tags,
  });
  
  return result;
}

export function compareScenarios(scenarioIds: string[]): {
  comparison: Array<{
    scenarioId: string;
    scenarioName: string;
    latestResult: ScenarioRunResult | null;
  }>;
  summary: string;
} | null {
  const comparisons = scenarioIds.map((id: string) => {
    const scenario = getScenario(id);
    if (!scenario) return null;
    
    const data = require("./simulation-storage").loadSimulationData();
    const results = data.scenarioRunResults
      .filter((r: ScenarioRunResult) => r.scenarioId === id)
      .sort((a: ScenarioRunResult, b: ScenarioRunResult) => new Date(b.runAt).getTime() - new Date(a.runAt).getTime());
    
    return {
      scenarioId: id,
      scenarioName: scenario.name,
      latestResult: results.length > 0 ? results[0] : null,
    };
  }).filter((c): c is { scenarioId: string; scenarioName: string; latestResult: ScenarioRunResult | null } => c !== null);
  
  if (comparisons.length === 0) return null;
  
  const summary = generateComparisonSummary(comparisons);
  
  return {
    comparison: comparisons,
    summary,
  };
}

function generateComparisonSummary(
  comparisons: Array<{
    scenarioId: string;
    scenarioName: string;
    latestResult: ScenarioRunResult | null;
  }>
): string {
  let summary = "## Scenario Comparison\n\n";
  
  const withResults = comparisons.filter((c) => c.latestResult !== null);
  
  if (withResults.length === 0) {
    return "No simulation results available for comparison. Run simulations first.";
  }
  
  const reaches = withResults.map((c) => ({
    name: c.scenarioName,
    value: c.latestResult?.outputMetrics.estimatedReach || 0,
  }));
  
  const conversions = withResults.map((c) => ({
    name: c.scenarioName,
    value: c.latestResult?.outputMetrics.estimatedConversions || 0,
  }));
  
  const resonances = withResults.map((c) => ({
    name: c.scenarioName,
    value: c.latestResult?.outputMetrics.resonanceScore || 0,
  }));
  
  const loudest = reaches.reduce((max, curr) => (curr.value > max.value ? curr : max));
  const bestConversion = conversions.reduce((max, curr) => (curr.value > max.value ? curr : max));
  const highestResonance = resonances.reduce((max, curr) => (curr.value > max.value ? curr : max));
  
  summary += `**Loudest (Highest Reach)**: ${loudest.name} with ${loudest.value.toLocaleString()} estimated reach\n\n`;
  summary += `**Best Conversion**: ${bestConversion.name} with ${bestConversion.value.toLocaleString()} conversions\n\n`;
  summary += `**Highest Resonance**: ${highestResonance.name} with ${highestResonance.value} resonance score\n\n`;
  
  summary += "### Analysis:\n";
  
  if (loudest.name === bestConversion.name && bestConversion.name === highestResonance.name) {
    summary += `**${loudest.name}** dominates across all key metrics - clear winner for maximum impact.\n\n`;
  } else {
    summary += `Different scenarios excel in different areas:\n`;
    summary += `- Choose **${loudest.name}** for maximum reach and visibility\n`;
    summary += `- Choose **${bestConversion.name}** for highest conversion efficiency\n`;
    summary += `- Choose **${highestResonance.name}** for strongest audience resonance\n\n`;
  }
  
  return summary;
}
