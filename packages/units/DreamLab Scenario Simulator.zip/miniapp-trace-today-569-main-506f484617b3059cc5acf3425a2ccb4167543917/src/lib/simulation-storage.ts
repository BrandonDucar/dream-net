import type {
  SimObjectRef,
  AssumptionSet,
  SimulationModel,
  Scenario,
  ScenarioInput,
  ScenarioRunResult,
  SimulationData,
  GeoTarget,
} from "@/types/simulation";

const STORAGE_KEY = "dreamnet_simulation_data";

function getInitialData(): SimulationData {
  return {
    simObjects: [],
    assumptionSets: [],
    simulationModels: [],
    scenarios: [],
    scenarioInputs: [],
    scenarioRunResults: [],
  };
}

export function loadSimulationData(): SimulationData {
  if (typeof window === "undefined") return getInitialData();
  
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return getInitialData();
    return JSON.parse(stored) as SimulationData;
  } catch (error) {
    console.error("Failed to load simulation data:", error);
    return getInitialData();
  }
}

export function saveSimulationData(data: SimulationData): void {
  if (typeof window === "undefined") return;
  
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error("Failed to save simulation data:", error);
  }
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

// SimObjectRef operations
export function createSimObjectRef(obj: Omit<SimObjectRef, "id">): SimObjectRef {
  const data = loadSimulationData();
  const newObj: SimObjectRef = { ...obj, id: generateId() };
  data.simObjects.push(newObj);
  saveSimulationData(data);
  return newObj;
}

export function updateSimObjectRef(id: string, updates: Partial<Omit<SimObjectRef, "id">>): SimObjectRef | null {
  const data = loadSimulationData();
  const index = data.simObjects.findIndex((o: SimObjectRef) => o.id === id);
  if (index === -1) return null;
  
  data.simObjects[index] = { ...data.simObjects[index], ...updates };
  saveSimulationData(data);
  return data.simObjects[index];
}

export function deleteSimObjectRef(id: string): boolean {
  const data = loadSimulationData();
  const initialLength = data.simObjects.length;
  data.simObjects = data.simObjects.filter((o: SimObjectRef) => o.id !== id);
  saveSimulationData(data);
  return data.simObjects.length < initialLength;
}

export function getSimObjectRef(id: string): SimObjectRef | null {
  const data = loadSimulationData();
  return data.simObjects.find((o: SimObjectRef) => o.id === id) || null;
}

export function listSimObjectRefs(): SimObjectRef[] {
  const data = loadSimulationData();
  return data.simObjects;
}

// AssumptionSet operations
export function createAssumptionSet(set: Omit<AssumptionSet, "id">): AssumptionSet {
  const data = loadSimulationData();
  const newSet: AssumptionSet = { ...set, id: generateId() };
  data.assumptionSets.push(newSet);
  saveSimulationData(data);
  return newSet;
}

export function updateAssumptionSet(id: string, updates: Partial<Omit<AssumptionSet, "id">>): AssumptionSet | null {
  const data = loadSimulationData();
  const index = data.assumptionSets.findIndex((s: AssumptionSet) => s.id === id);
  if (index === -1) return null;
  
  data.assumptionSets[index] = { ...data.assumptionSets[index], ...updates };
  saveSimulationData(data);
  return data.assumptionSets[index];
}

export function deleteAssumptionSet(id: string): boolean {
  const data = loadSimulationData();
  const initialLength = data.assumptionSets.length;
  data.assumptionSets = data.assumptionSets.filter((s: AssumptionSet) => s.id !== id);
  saveSimulationData(data);
  return data.assumptionSets.length < initialLength;
}

export function getAssumptionSet(id: string): AssumptionSet | null {
  const data = loadSimulationData();
  return data.assumptionSets.find((s: AssumptionSet) => s.id === id) || null;
}

export function listAssumptionSets(): AssumptionSet[] {
  const data = loadSimulationData();
  return data.assumptionSets;
}

// SimulationModel operations
export function createSimulationModel(model: Omit<SimulationModel, "id">): SimulationModel {
  const data = loadSimulationData();
  const newModel: SimulationModel = { ...model, id: generateId() };
  data.simulationModels.push(newModel);
  saveSimulationData(data);
  return newModel;
}

export function updateSimulationModel(id: string, updates: Partial<Omit<SimulationModel, "id">>): SimulationModel | null {
  const data = loadSimulationData();
  const index = data.simulationModels.findIndex((m: SimulationModel) => m.id === id);
  if (index === -1) return null;
  
  data.simulationModels[index] = { ...data.simulationModels[index], ...updates };
  saveSimulationData(data);
  return data.simulationModels[index];
}

export function deleteSimulationModel(id: string): boolean {
  const data = loadSimulationData();
  const initialLength = data.simulationModels.length;
  data.simulationModels = data.simulationModels.filter((m: SimulationModel) => m.id !== id);
  saveSimulationData(data);
  return data.simulationModels.length < initialLength;
}

export function getSimulationModel(id: string): SimulationModel | null {
  const data = loadSimulationData();
  return data.simulationModels.find((m: SimulationModel) => m.id === id) || null;
}

export function listSimulationModels(): SimulationModel[] {
  const data = loadSimulationData();
  return data.simulationModels;
}

// Scenario operations
export function createScenario(scenario: Omit<Scenario, "id">): Scenario {
  const data = loadSimulationData();
  const newScenario: Scenario = { ...scenario, id: generateId() };
  data.scenarios.push(newScenario);
  saveSimulationData(data);
  return newScenario;
}

export function updateScenario(id: string, updates: Partial<Omit<Scenario, "id">>): Scenario | null {
  const data = loadSimulationData();
  const index = data.scenarios.findIndex((s: Scenario) => s.id === id);
  if (index === -1) return null;
  
  data.scenarios[index] = { ...data.scenarios[index], ...updates };
  saveSimulationData(data);
  return data.scenarios[index];
}

export function deleteScenario(id: string): boolean {
  const data = loadSimulationData();
  const initialLength = data.scenarios.length;
  data.scenarios = data.scenarios.filter((s: Scenario) => s.id !== id);
  // Also delete related inputs and results
  data.scenarioInputs = data.scenarioInputs.filter((i: ScenarioInput) => i.scenarioId !== id);
  data.scenarioRunResults = data.scenarioRunResults.filter((r: ScenarioRunResult) => r.scenarioId !== id);
  saveSimulationData(data);
  return data.scenarios.length < initialLength;
}

export function getScenario(id: string): Scenario | null {
  const data = loadSimulationData();
  return data.scenarios.find((s: Scenario) => s.id === id) || null;
}

export function listScenarios(filter?: {
  category?: string;
  status?: string;
  tag?: string;
}): Scenario[] {
  const data = loadSimulationData();
  let scenarios = data.scenarios;
  
  if (filter?.category) {
    scenarios = scenarios.filter((s: Scenario) => s.category === filter.category);
  }
  
  if (filter?.status) {
    scenarios = scenarios.filter((s: Scenario) => s.status === filter.status);
  }
  
  if (filter?.tag) {
    scenarios = scenarios.filter((s: Scenario) => s.tags.includes(filter.tag));
  }
  
  return scenarios;
}

export function attachObjectToScenario(scenarioId: string, simObjectId: string): Scenario | null {
  const data = loadSimulationData();
  const scenario = data.scenarios.find((s: Scenario) => s.id === scenarioId);
  if (!scenario) return null;
  
  if (!scenario.simObjectIds.includes(simObjectId)) {
    scenario.simObjectIds.push(simObjectId);
    saveSimulationData(data);
  }
  
  return scenario;
}

export function removeObjectFromScenario(scenarioId: string, simObjectId: string): Scenario | null {
  const data = loadSimulationData();
  const scenario = data.scenarios.find((s: Scenario) => s.id === scenarioId);
  if (!scenario) return null;
  
  scenario.simObjectIds = scenario.simObjectIds.filter((id: string) => id !== simObjectId);
  saveSimulationData(data);
  
  return scenario;
}

export function assignGeoTargetsToScenario(scenarioId: string, geoTargets: GeoTarget[]): Scenario | null {
  const data = loadSimulationData();
  const scenario = data.scenarios.find((s: Scenario) => s.id === scenarioId);
  if (!scenario) return null;
  
  scenario.primaryGeoTargets = geoTargets;
  saveSimulationData(data);
  
  return scenario;
}

// ScenarioInput operations
export function setScenarioInput(
  scenarioId: string,
  key: string,
  valueNumber: number | null,
  valueText: string | null,
  notes: string
): ScenarioInput {
  const data = loadSimulationData();
  const existing = data.scenarioInputs.find(
    (i: ScenarioInput) => i.scenarioId === scenarioId && i.key === key
  );
  
  if (existing) {
    existing.valueNumber = valueNumber;
    existing.valueText = valueText;
    existing.notes = notes;
    saveSimulationData(data);
    return existing;
  }
  
  const newInput: ScenarioInput = {
    id: generateId(),
    scenarioId,
    key,
    valueNumber,
    valueText,
    notes,
  };
  
  data.scenarioInputs.push(newInput);
  saveSimulationData(data);
  return newInput;
}

export function getScenarioInputs(scenarioId: string): ScenarioInput[] {
  const data = loadSimulationData();
  return data.scenarioInputs.filter((i: ScenarioInput) => i.scenarioId === scenarioId);
}

export function deleteScenarioInput(id: string): boolean {
  const data = loadSimulationData();
  const initialLength = data.scenarioInputs.length;
  data.scenarioInputs = data.scenarioInputs.filter((i: ScenarioInput) => i.id !== id);
  saveSimulationData(data);
  return data.scenarioInputs.length < initialLength;
}

// ScenarioRunResult operations
export function createScenarioRunResult(result: Omit<ScenarioRunResult, "id">): ScenarioRunResult {
  const data = loadSimulationData();
  const newResult: ScenarioRunResult = { ...result, id: generateId() };
  data.scenarioRunResults.push(newResult);
  saveSimulationData(data);
  return newResult;
}

export function getScenarioRunResults(scenarioId: string): ScenarioRunResult[] {
  const data = loadSimulationData();
  return data.scenarioRunResults
    .filter((r: ScenarioRunResult) => r.scenarioId === scenarioId)
    .sort((a: ScenarioRunResult, b: ScenarioRunResult) => new Date(b.runAt).getTime() - new Date(a.runAt).getTime());
}

export function getLatestScenarioRunResult(scenarioId: string): ScenarioRunResult | null {
  const results = getScenarioRunResults(scenarioId);
  return results.length > 0 ? results[0] : null;
}
