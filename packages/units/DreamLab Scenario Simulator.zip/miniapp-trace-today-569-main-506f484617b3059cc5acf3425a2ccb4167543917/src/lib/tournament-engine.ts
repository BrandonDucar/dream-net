// Tournament and Leaderboard Engine
import type { SimulationTournament, TournamentEntry, LeaderboardEntry } from "@/types/advanced-features";
import {
  createTournament,
  listTournaments,
  getTournament,
  createTournamentEntry,
  listTournamentEntries,
} from "./advanced-storage";
import { getScenario, getLatestScenarioRunResult } from "./simulation-storage";

export function createSimulationTournament(
  name: string,
  description: string,
  challenge: string,
  objectiveMetric: string,
  startDate: string,
  endDate: string,
  prizes: string[]
): SimulationTournament {
  const tournament = createTournament({
    name,
    description,
    startDate,
    endDate,
    challenge,
    objectiveMetric,
    entries: [],
    leaderboard: [],
    status: "upcoming",
    prizes,
  });
  
  return tournament;
}

export function submitTournamentEntry(
  tournamentId: string,
  participantName: string,
  scenarioId: string
): TournamentEntry | null {
  const tournament = getTournament(tournamentId);
  if (!tournament) return null;
  
  const scenario = getScenario(scenarioId);
  if (!scenario) return null;
  
  const result = getLatestScenarioRunResult(scenarioId);
  if (!result) return null;
  
  const entry = createTournamentEntry({
    tournamentId,
    participantName,
    scenarioId,
    submittedAt: new Date().toISOString(),
    predictedMetrics: result.outputMetrics,
  });
  
  return entry;
}

export function calculateLeaderboard(tournamentId: string): LeaderboardEntry[] {
  const tournament = getTournament(tournamentId);
  if (!tournament) return [];
  
  const entries = listTournamentEntries(tournamentId);
  if (entries.length === 0) return [];
  
  const { objectiveMetric } = tournament;
  
  // Calculate scores based on objective metric
  const scoredEntries = entries
    .map(entry => {
      const scenario = getScenario(entry.scenarioId);
      const scoreValue = entry.predictedMetrics[objectiveMetric] || 0;
      
      // Calculate accuracy if actual metrics are available
      const accuracy = entry.actualMetrics
        ? calculateAccuracy(entry.predictedMetrics, entry.actualMetrics, objectiveMetric)
        : undefined;
      
      // Determine approach based on scenario characteristics
      const approach = determineApproach(entry);
      
      // Award badges
      const badges = awardBadges(entry, scoreValue, accuracy);
      
      return {
        entry,
        scoreValue,
        accuracy,
        scenarioName: scenario?.name || "Unknown Scenario",
        approach,
        badges,
      };
    })
    .sort((a, b) => {
      // If actual metrics available, sort by accuracy
      if (a.accuracy !== undefined && b.accuracy !== undefined) {
        return b.accuracy - a.accuracy;
      }
      // Otherwise, sort by predicted score
      return b.scoreValue - a.scoreValue;
    });
  
  // Build leaderboard
  const leaderboard: LeaderboardEntry[] = scoredEntries.map((scored, index) => ({
    rank: index + 1,
    participantName: scored.entry.participantName,
    scenarioName: scored.scenarioName,
    scoreValue: scored.scoreValue,
    accuracy: scored.accuracy,
    approach: scored.approach,
    badges: scored.badges,
  }));
  
  return leaderboard;
}

function calculateAccuracy(
  predicted: Record<string, number>,
  actual: Record<string, number>,
  objectiveMetric: string
): number {
  const predictedValue = predicted[objectiveMetric] || 0;
  const actualValue = actual[objectiveMetric] || 0;
  
  if (actualValue === 0) return 0;
  
  const error = Math.abs(predictedValue - actualValue) / actualValue;
  const accuracy = Math.max(0, 100 - error * 100);
  
  return Math.round(accuracy * 10) / 10;
}

function determineApproach(entry: TournamentEntry): string {
  const scenario = getScenario(entry.scenarioId);
  if (!scenario) return "Unknown";
  
  const resonance = entry.predictedMetrics.resonanceScore || 50;
  const reach = entry.predictedMetrics.estimatedReach || 0;
  const conversions = entry.predictedMetrics.estimatedConversions || 0;
  
  if (resonance >= 75 && reach >= 10000) {
    return "Aggressive High-Impact";
  } else if (resonance >= 60 && conversions >= 500) {
    return "Balanced Growth";
  } else if (reach >= 20000) {
    return "Maximum Reach";
  } else if (conversions >= 1000) {
    return "Conversion Focused";
  } else {
    return "Conservative Stable";
  }
}

function awardBadges(
  entry: TournamentEntry,
  scoreValue: number,
  accuracy?: number
): string[] {
  const badges: string[] = [];
  
  // Score-based badges
  if (scoreValue >= 50000) badges.push("🚀 Moonshot");
  if (scoreValue >= 100000) badges.push("🌟 Superstar");
  
  // Accuracy badges (if actual metrics available)
  if (accuracy !== undefined) {
    if (accuracy >= 95) badges.push("🎯 Precision Master");
    if (accuracy >= 90) badges.push("📊 Accurate Predictor");
  }
  
  // Metric-specific badges
  const resonance = entry.predictedMetrics.resonanceScore || 0;
  if (resonance >= 90) badges.push("🔥 Cultural Icon");
  
  const viralCoeff = entry.predictedMetrics.viralCoefficient || 0;
  if (viralCoeff >= 3) badges.push("🌊 Viral Wave");
  
  const conversions = entry.predictedMetrics.estimatedConversions || 0;
  if (conversions >= 1000) badges.push("💰 Conversion King");
  
  return badges;
}

export function generateTournamentInsight(
  tournament: SimulationTournament,
  leaderboard: LeaderboardEntry[]
): string {
  let insight = `## ${tournament.name}\n\n`;
  insight += `**Challenge:** ${tournament.challenge}\n`;
  insight += `**Objective Metric:** ${tournament.objectiveMetric}\n`;
  insight += `**Status:** ${tournament.status}\n`;
  insight += `**Dates:** ${new Date(tournament.startDate).toLocaleDateString()} - ${new Date(tournament.endDate).toLocaleDateString()}\n\n`;
  
  if (tournament.prizes.length > 0) {
    insight += `**Prizes:**\n`;
    tournament.prizes.forEach((prize, idx) => {
      insight += `${idx + 1}. ${prize}\n`;
    });
    insight += `\n`;
  }
  
  if (leaderboard.length === 0) {
    insight += `No entries yet. Be the first to submit!\n`;
    return insight;
  }
  
  insight += `**Leaderboard (${leaderboard.length} entries):**\n\n`;
  insight += `| Rank | Participant | Scenario | Score | Approach |\n`;
  insight += `|------|-------------|----------|-------|----------|\n`;
  
  leaderboard.slice(0, 10).forEach(entry => {
    const badgeStr = entry.badges.length > 0 ? ` ${entry.badges.join(" ")}` : "";
    insight += `| ${entry.rank} | ${entry.participantName}${badgeStr} | ${entry.scenarioName} | ${entry.scoreValue.toLocaleString()} | ${entry.approach} |\n`;
  });
  
  if (leaderboard.length > 10) {
    insight += `\n*...and ${leaderboard.length - 10} more entries*\n`;
  }
  
  insight += `\n`;
  
  // Top performers analysis
  if (leaderboard.length >= 3) {
    insight += `**Top 3 Analysis:**\n`;
    leaderboard.slice(0, 3).forEach(entry => {
      insight += `- **#${entry.rank} ${entry.participantName}**: ${entry.approach} strategy with ${entry.scoreValue.toLocaleString()} ${tournament.objectiveMetric}\n`;
    });
    insight += `\n`;
  }
  
  // Approach distribution
  const approaches = new Map<string, number>();
  leaderboard.forEach(entry => {
    approaches.set(entry.approach, (approaches.get(entry.approach) || 0) + 1);
  });
  
  insight += `**Strategy Distribution:**\n`;
  approaches.forEach((count, approach) => {
    const percentage = Math.round((count / leaderboard.length) * 100);
    insight += `- ${approach}: ${count} entries (${percentage}%)\n`;
  });
  
  return insight;
}

export function initializeSampleTournaments(): void {
  const existing = listTournaments();
  if (existing.length > 0) return; // Already initialized
  
  const now = new Date();
  const weekFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  const monthFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
  
  createSimulationTournament(
    "Culture Launch Championship",
    "Design the most resonant culture launch campaign",
    "Create a scenario with the highest resonance score while maintaining at least 10,000 reach",
    "resonanceScore",
    now.toISOString(),
    weekFromNow.toISOString(),
    ["🏆 DreamNet Pro for 3 months", "🎨 Featured in Community Showcase", "🎯 Strategy Consulting Session"]
  );
  
  createSimulationTournament(
    "Viral Coefficient Challenge",
    "Maximize organic spread and remix potential",
    "Build a scenario with the highest viral coefficient",
    "viralCoefficient",
    weekFromNow.toISOString(),
    monthFromNow.toISOString(),
    ["🚀 $500 USDC Prize", "🌟 Viral Strategy Guide Co-Author Credit", "📢 Social Media Feature"]
  );
}
