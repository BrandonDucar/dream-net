// Advanced Features Types for DreamNet Simulation Lab

// 1. Historical Pattern Matching
export interface HistoricalPattern {
  id: string;
  name: string;
  description: string;
  category: string;
  dateRange: {
    start: string;
    end: string;
  };
  actualOutcomes: {
    reach: number;
    conversions: number;
    resonanceScore: number;
    viralCoefficient: number;
  };
  contextTags: string[];
  scenarioFingerprint: string; // hash of key characteristics
  similarity?: number; // 0-100, calculated when matching
}

// 2. Competitive Simulation
export interface CompetitorAction {
  id: string;
  competitorName: string;
  actionType: "token-launch" | "drop" | "campaign" | "content-blitz" | "other";
  timing: "same-week" | "overlap" | "before" | "after";
  estimatedImpact: "low" | "medium" | "high" | "critical";
  marketShareImpact: number; // percentage reduction
  notes: string;
}

export interface CompetitiveScenario {
  id: string;
  scenarioId: string;
  competitors: CompetitorAction[];
  marketSaturation: number; // 0-100
  timingConflicts: number; // count of overlapping launches
  adjustedMetrics: Record<string, number>; // metrics after competitive impact
}

// 3. Meme Velocity Predictor
export interface MemeVelocityMetrics {
  id: string;
  scenarioId: string;
  memePotentialScore: number; // 0-100
  remixabilityScore: number; // 0-100
  viralPathways: ViralPathway[];
  expectedRemixCount: number;
  peakViralityDay: number; // day number in campaign
  decayRate: number; // how fast meme loses momentum
  culturalFitScore: number; // 0-100
}

export interface ViralPathway {
  platform: "farcaster" | "x" | "tiktok" | "instagram" | "other";
  initialReach: number;
  cascadeMultiplier: number;
  expectedPeakDay: number;
}

export interface RemixTree {
  originalPost: string;
  remixGenerations: Array<{
    generation: number;
    count: number;
    platforms: string[];
  }>;
  totalReach: number;
}

// 4. Network Effect Modeling
export interface NetworkEffect {
  id: string;
  name: string;
  description: string;
  sourceNetwork: string; // e.g., "Farcaster", "Base Builders"
  targetNetworks: string[];
  cascadeMultiplier: number; // how much boost when crossing networks
  timingBonus: number; // bonus for optimal sequencing
  requiredCriticalMass: number; // minimum reach to trigger cascade
}

export interface NetworkSimulation {
  id: string;
  scenarioId: string;
  networkEffects: NetworkEffect[];
  optimalSequence: string[]; // ordered network launch sequence
  projectedCrossNetworkReach: Record<string, number>;
  cascadeBreakpoints: Array<{
    network: string;
    reachThreshold: number;
    multiplierGained: number;
  }>;
}

// 5. Risk Heat Maps
export interface RiskCategory {
  category: "timing" | "fatigue" | "competition" | "tech" | "market" | "execution";
  severity: "low" | "medium" | "high" | "critical";
  probability: number; // 0-100
  impact: number; // 0-100
  mitigation: string;
}

export interface RiskHeatMap {
  id: string;
  scenarioId: string;
  risks: RiskCategory[];
  overallRiskScore: number; // 0-100
  riskDistribution: "stable" | "moderate" | "lumpy" | "black-swan-prone";
  volatilityIndex: number; // how much outcomes could vary
  blackSwanScenarios: Array<{
    description: string;
    probability: number;
    impact: string;
  }>;
}

// 6. Collaborative Scenario Branching
export interface ScenarioBranch {
  id: string;
  parentScenarioId: string;
  branchName: string;
  creator: string;
  description: string;
  modifications: string; // what changed from parent
  createdAt: string;
  tags: string[];
  approach: "conservative" | "moderate" | "aggressive" | "experimental";
}

export interface BranchComparison {
  branches: Array<{
    branchId: string;
    branchName: string;
    approach: string;
    latestMetrics: Record<string, number>;
  }>;
  consensus: string; // which approach team prefers
  debate: Array<{
    branchId: string;
    pros: string[];
    cons: string[];
  }>;
}

// 7. Auto-Generate Execution Plans
export interface ExecutionPlan {
  id: string;
  scenarioId: string;
  format: "action-router" | "social-relay" | "drop-architect" | "generic";
  generatedAt: string;
  actions: ExecutionAction[];
  timeline: ExecutionTimeline[];
  estimatedEffort: string;
  prerequisites: string[];
  exportableFormat: string; // JSON or formatted text
}

export interface ExecutionAction {
  id: string;
  type: "post" | "drop" | "campaign-start" | "monitor" | "adjust" | "other";
  day: number; // day in campaign
  description: string;
  parameters: Record<string, string | number>;
  dependencies: string[]; // action IDs this depends on
}

export interface ExecutionTimeline {
  day: number;
  milestone: string;
  actions: string[]; // action IDs
  expectedOutcome: string;
}

// 8. Community Benchmark Database
export interface CommunityBenchmark {
  id: string;
  category: string; // "culture-launch", "drop", "campaign", etc.
  metric: string; // "reach", "conversions", "resonance", etc.
  percentile: number; // 10th, 25th, 50th, 75th, 90th
  value: number;
  sampleSize: number;
  lastUpdated: string;
  tags: string[];
}

export interface BenchmarkComparison {
  scenarioId: string;
  scenarioMetrics: Record<string, number>;
  benchmarks: Array<{
    metric: string;
    scenarioValue: number;
    percentile: number;
    percentileLabel: "bottom-10%" | "bottom-25%" | "median" | "top-25%" | "top-10%";
    gap: number;
  }>;
  overallPerformance: "below-average" | "average" | "above-average" | "top-tier";
  topCharacteristics: string[];
}

// 9. Live Simulation Tournaments
export interface SimulationTournament {
  id: string;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  challenge: string; // e.g., "Design the highest-resonance culture launch"
  objectiveMetric: string; // "resonanceScore", "reach", "conversions", etc.
  entries: TournamentEntry[];
  leaderboard: LeaderboardEntry[];
  status: "upcoming" | "active" | "judging" | "completed";
  prizes: string[];
}

export interface TournamentEntry {
  id: string;
  tournamentId: string;
  participantName: string;
  scenarioId: string;
  submittedAt: string;
  predictedMetrics: Record<string, number>;
  actualMetrics?: Record<string, number>; // filled in after real launch
  accuracyScore?: number; // how close prediction was to reality
}

export interface LeaderboardEntry {
  rank: number;
  participantName: string;
  scenarioName: string;
  scoreValue: number;
  accuracy?: number; // if comparing predicted vs actual
  approach: string;
  badges: string[];
}

// Extended SimulationData to include new features
export interface AdvancedSimulationData {
  historicalPatterns: HistoricalPattern[];
  competitiveScenarios: CompetitiveScenario[];
  memeVelocityMetrics: MemeVelocityMetrics[];
  networkSimulations: NetworkSimulation[];
  riskHeatMaps: RiskHeatMap[];
  scenarioBranches: ScenarioBranch[];
  executionPlans: ExecutionPlan[];
  communityBenchmarks: CommunityBenchmark[];
  tournaments: SimulationTournament[];
  tournamentEntries: TournamentEntry[];
}

// Social Listening (placeholder for future integration)
export interface SocialSentiment {
  platform: string;
  sentiment: "bullish" | "neutral" | "bearish";
  memeultureFatigue: number; // 0-100
  governanceFatigue: number; // 0-100
  topicsHot: string[];
  topicsCold: string[];
  sampledAt: string;
  confidence: number; // 0-100
}

export interface SocialListeningSnapshot {
  id: string;
  timestamp: string;
  platforms: SocialSentiment[];
  overallVibe: "very-bullish" | "bullish" | "neutral" | "bearish" | "very-bearish";
  suggestedAssumptionAdjustments: Record<string, number>; // factor adjustments
  notes: string;
}
