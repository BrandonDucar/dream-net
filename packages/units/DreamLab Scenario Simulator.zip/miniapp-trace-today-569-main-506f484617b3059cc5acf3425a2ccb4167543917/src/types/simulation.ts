export type SimObjectType =
  | "token"
  | "culture-coin"
  | "drop"
  | "campaign"
  | "flow"
  | "content-stream"
  | "audience-segment"
  | "pickleball-program"
  | "action-bundle"
  | "other";

export interface SimObjectRef {
  id: string;
  type: SimObjectType;
  name: string;
  description: string;
  sourceApp: string | null;
  externalRef: string | null;
  tags: string[];
  notes: string;
}

export interface AssumptionSet {
  id: string;
  name: string;
  description: string;
  baseReachFactor: number;
  engagementFactor: number;
  conversionFactor: number;
  remixFactor: number;
  fatigueFactor: number;
  riskMultiplierHigh: number;
  notes: string;
  tags: string[];
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export interface SimulationModel {
  id: string;
  name: string;
  description: string;
  version: string;
  appliesToTypes: string[];
  inputMetrics: string[];
  outputMetrics: string[];
  heuristicDescription: string;
  tags: string[];
  notes: string;
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export type ScenarioStatus = "draft" | "ready" | "run" | "archived";
export type PriorityLevel = "low" | "medium" | "high" | "critical";

export interface GeoTarget {
  id: string;
  region: string;
  country: string;
  cityOrMarket: string;
  language: string;
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  category: string;
  priorityLevel: PriorityLevel;
  simObjectIds: string[];
  assumptionSetId: string;
  simulationModelId: string;
  timeWindowStart: string | null;
  timeWindowEnd: string | null;
  tags: string[];
  notes: string;
  status: ScenarioStatus;
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
  primaryGeoTargets: GeoTarget[];
  scenarioIntroLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
}

export interface ScenarioInput {
  id: string;
  scenarioId: string;
  key: string;
  valueNumber: number | null;
  valueText: string | null;
  notes: string;
}

export interface ScenarioRunResult {
  id: string;
  scenarioId: string;
  runAt: string;
  modelVersion: string;
  inputSnapshot: string;
  outputMetrics: Record<string, number>;
  narrativeSummary: string;
  riskNotes: string;
  recommendedActions: string[];
  tags: string[];
}

export interface SimulationData {
  simObjects: SimObjectRef[];
  assumptionSets: AssumptionSet[];
  simulationModels: SimulationModel[];
  scenarios: Scenario[];
  scenarioInputs: ScenarioInput[];
  scenarioRunResults: ScenarioRunResult[];
}
