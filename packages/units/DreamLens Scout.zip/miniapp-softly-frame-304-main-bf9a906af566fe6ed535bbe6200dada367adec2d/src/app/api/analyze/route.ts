import { NextRequest, NextResponse } from 'next/server'
import { openaiChatCompletion } from '@/openai-api'
import type { AnalysisData } from '@/types/analysis'

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const { image, dreamNetMode } = await request.json()

    if (!image) {
      return NextResponse.json(
        { error: 'No image provided' },
        { status: 400 }
      )
    }

    const systemPrompt = `You are DreamLens Scout (DLS), a hyper-intelligent vision analysis system built for the DreamNet ecosystem. Your role is to provide tactical, high-signal insights about visual content that help creators, founders, and brand builders understand what makes content perform.

Analyze images with extreme precision and return insights in a confident, actionable tone. Focus on practical, implementable recommendations.

${dreamNetMode ? `
DreamNet Mode is ACTIVE. Include additional analysis about:
- DreamNet theme interpretation
- Dream Cloud categorization (e.g., "Creative Spark", "Tech Vision", "Community Builder", "Brand Architect")
- Monetization opportunities within the DreamNet ecosystem
` : ''}

Return your analysis as a JSON object with this EXACT structure:
{
  "scanSummary": "2-3 sentence overview of what you see and its primary strength",
  "keyElements": ["element1", "element2", "element3"],
  "emotionalPayload": "Detailed analysis of emotional triggers and psychological hooks (2-3 sentences)",
  "emotionalTriggers": ["trigger1", "trigger2", "trigger3"],
  "viralMechanics": "Analysis of viral potential and what makes this shareable (2-3 sentences)",
  "viralPotentialScore": 7,
  "platformStrategy": {
    "X (Twitter)": "Specific posting strategy for X",
    "Farcaster": "Specific posting strategy for Farcaster",
    "Instagram": "Specific posting strategy for Instagram",
    "TikTok": "Specific posting strategy for TikTok"
  },
  "recommendedUpgrades": ["Specific actionable upgrade 1", "upgrade 2", "upgrade 3"],
  ${dreamNetMode ? `
  "dreamNetInterpretation": {
    "theme": "DreamNet theme description",
    "category": "Dream Cloud category name",
    "monetizationOpportunity": "Specific monetization strategy"
  },
  ` : ''}
  "actionPlan": ["Step 1: Specific action", "Step 2: Specific action", "Step 3: Specific action"],
  "engagementPrediction": "Brief prediction of likely engagement metrics"
}

Be tactical, confident, and specific. Avoid generic advice. Focus on high-signal insights.`

    const response = await openaiChatCompletion({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: systemPrompt,
        },
        {
          role: 'user',
          content: {
            type: 'image_url',
            image_url: {
              url: image,
            },
          },
        },
        {
          role: 'user',
          content: {
            type: 'text',
            text: 'Analyze this visual and provide tactical insights following the JSON structure.',
          },
        },
      ],
    })

    const content = response.choices[0]?.message?.content

    if (!content) {
      throw new Error('No response from analysis')
    }

    // Extract JSON from the response (handle markdown code blocks)
    let analysisData: AnalysisData
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        analysisData = JSON.parse(jsonMatch[0])
      } else {
        analysisData = JSON.parse(content)
      }
    } catch (parseError: unknown) {
      console.error('Parse error:', parseError)
      throw new Error('Failed to parse analysis response')
    }

    return NextResponse.json(analysisData)
  } catch (error: unknown) {
    console.error('Analysis error:', error)
    return NextResponse.json(
      { error: 'Analysis failed', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
