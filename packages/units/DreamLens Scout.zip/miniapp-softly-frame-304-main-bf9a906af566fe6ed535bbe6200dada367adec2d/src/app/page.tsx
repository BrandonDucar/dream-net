'use client'
import { useState, useCallback, useEffect } from 'react'
import { Upload, Sparkles, Target, TrendingUp, Lightbulb, Map, Zap } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { ImageUploadZone } from '@/components/image-upload-zone'
import { AnalysisResults } from '@/components/analysis-results'
import type { AnalysisData } from '@/types/analysis'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DreamLensScout(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [uploadedImage, setUploadedImage] = useState<string>('')
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false)
  const [analysisData, setAnalysisData] = useState<AnalysisData | null>(null)
  const [dreamNetMode, setDreamNetMode] = useState<boolean>(false)
  const [progress, setProgress] = useState<number>(0)

  const handleImageUpload = useCallback((imageDataUrl: string): void => {
    setUploadedImage(imageDataUrl)
    setAnalysisData(null)
  }, [])

  const analyzeImage = useCallback(async (): Promise<void> => {
    if (!uploadedImage) return

    setIsAnalyzing(true)
    setProgress(0)

    // Simulate progress
    const progressInterval = setInterval(() => {
      setProgress((prev: number) => {
        if (prev >= 90) {
          clearInterval(progressInterval)
          return 90
        }
        return prev + 10
      })
    }, 200)

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          image: uploadedImage,
          dreamNetMode 
        }),
      })

      if (!response.ok) {
        throw new Error('Analysis failed')
      }

      const data: AnalysisData = await response.json()
      setAnalysisData(data)
      setProgress(100)
    } catch (error: unknown) {
      console.error('Analysis error:', error)
    } finally {
      clearInterval(progressInterval)
      setIsAnalyzing(false)
      setProgress(0)
    }
  }, [uploadedImage, dreamNetMode])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 text-white pt-16 pb-16">
      <div className="container mx-auto px-4 max-w-7xl">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600">
              <Sparkles className="w-8 h-8" />
            </div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              DreamLens Scout
            </h1>
          </div>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            Hyper-intelligent vision scanner for creators, founders, and brand builders
          </p>
          <div className="flex items-center justify-center gap-4 mt-6 flex-wrap">
            <Badge variant="outline" className="text-indigo-300 border-indigo-500">
              <Target className="w-3 h-3 mr-1" />
              Pattern Recognition
            </Badge>
            <Badge variant="outline" className="text-purple-300 border-purple-500">
              <TrendingUp className="w-3 h-3 mr-1" />
              Viral Analysis
            </Badge>
            <Badge variant="outline" className="text-pink-300 border-pink-500">
              <Zap className="w-3 h-3 mr-1" />
              DreamNet Powered
            </Badge>
          </div>
        </div>

        {/* DreamNet Mode Toggle */}
        <Card className="mb-8 bg-slate-900/50 border-slate-700 backdrop-blur-sm">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/30">
                  <Sparkles className="w-5 h-5 text-purple-400" />
                </div>
                <div>
                  <Label htmlFor="dreamnet-mode" className="text-base font-semibold text-white cursor-pointer">
                    DreamNet Mode
                  </Label>
                  <p className="text-sm text-slate-400">
                    Unlock theme interpretation & monetization insights
                  </p>
                </div>
              </div>
              <Switch
                id="dreamnet-mode"
                checked={dreamNetMode}
                onCheckedChange={setDreamNetMode}
                className="data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-purple-500 data-[state=checked]:to-pink-500"
              />
            </div>
          </CardContent>
        </Card>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left: Upload Section */}
          <div>
            <Card className="bg-slate-900/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="w-5 h-5 text-indigo-400" />
                  Upload Visual
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Drop any image, video frame, or screenshot
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ImageUploadZone 
                  onImageUpload={handleImageUpload}
                  uploadedImage={uploadedImage}
                />
                
                {uploadedImage && (
                  <div className="mt-6">
                    <Button 
                      onClick={analyzeImage}
                      disabled={isAnalyzing}
                      className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-semibold py-6 text-lg"
                    >
                      {isAnalyzing ? (
                        <>
                          <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                          Scanning...
                        </>
                      ) : (
                        <>
                          <Zap className="w-5 h-5 mr-2" />
                          Analyze Vision
                        </>
                      )}
                    </Button>
                    
                    {isAnalyzing && (
                      <div className="mt-4">
                        <Progress value={progress} className="h-2" />
                        <p className="text-sm text-slate-400 text-center mt-2">
                          Processing visual intelligence...
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Info */}
            <Card className="mt-6 bg-gradient-to-br from-indigo-950/50 to-purple-950/50 border-indigo-700/50">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-yellow-400" />
                  What DLS Detects
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-slate-300">
                  <li className="flex items-start gap-2">
                    <span className="text-indigo-400 mt-1">•</span>
                    <span>Emotional triggers and psychological hooks</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-purple-400 mt-1">•</span>
                    <span>Visual style breakdown and theme classification</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-pink-400 mt-1">•</span>
                    <span>Viral potential scoring with pattern recognition</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-indigo-400 mt-1">•</span>
                    <span>Platform-specific posting strategies</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-purple-400 mt-1">•</span>
                    <span>Recommended edits to increase performance</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Right: Results Section */}
          <div>
            {analysisData ? (
              <AnalysisResults data={analysisData} dreamNetMode={dreamNetMode} />
            ) : (
              <Card className="bg-slate-900/30 border-slate-700 border-dashed backdrop-blur-sm h-full flex items-center justify-center">
                <CardContent className="text-center py-16">
                  <div className="p-6 rounded-full bg-slate-800/50 w-24 h-24 mx-auto mb-6 flex items-center justify-center">
                    <Map className="w-12 h-12 text-slate-500" />
                  </div>
                  <h3 className="text-xl font-semibold text-slate-400 mb-2">
                    Upload to Scan
                  </h3>
                  <p className="text-slate-500 max-w-sm mx-auto">
                    Your tactical intelligence report will appear here after analysis
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-12 text-center text-slate-500 text-sm">
          <p>Powered by DreamNet • Built for tactical creators</p>
        </div>
      </div>
    </div>
  )
}
