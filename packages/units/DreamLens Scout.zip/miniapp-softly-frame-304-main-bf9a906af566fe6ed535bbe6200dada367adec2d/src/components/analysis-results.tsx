'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  FileText, 
  Heart, 
  TrendingUp, 
  Wrench, 
  Sparkles, 
  ListChecks,
  Target,
  Eye,
  Palette,
  Users
} from 'lucide-react'
import type { AnalysisData } from '@/types/analysis'

interface AnalysisResultsProps {
  data: AnalysisData
  dreamNetMode: boolean
}

export function AnalysisResults({ data, dreamNetMode }: AnalysisResultsProps): JSX.Element {
  return (
    <div className="space-y-6">
      {/* Scan Summary */}
      <Card className="bg-slate-900/50 border-slate-700 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-indigo-400">
            <FileText className="w-5 h-5" />
            Scan Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-200 leading-relaxed">{data.scanSummary}</p>
          
          {data.keyElements && data.keyElements.length > 0 && (
            <div className="mt-4">
              <p className="text-sm font-semibold text-slate-400 mb-2">Key Elements:</p>
              <div className="flex flex-wrap gap-2">
                {data.keyElements.map((element: string, index: number) => (
                  <Badge key={index} variant="secondary" className="bg-slate-800 text-slate-300">
                    <Eye className="w-3 h-3 mr-1" />
                    {element}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Emotional Payload */}
      <Card className="bg-slate-900/50 border-slate-700 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-pink-400">
            <Heart className="w-5 h-5" />
            Emotional Payload
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-200 leading-relaxed mb-4">{data.emotionalPayload}</p>
          
          {data.emotionalTriggers && data.emotionalTriggers.length > 0 && (
            <div className="space-y-2">
              <p className="text-sm font-semibold text-slate-400">Detected Triggers:</p>
              {data.emotionalTriggers.map((trigger: string, index: number) => (
                <div key={index} className="flex items-start gap-2 text-sm">
                  <span className="text-pink-400 mt-1">→</span>
                  <span className="text-slate-300">{trigger}</span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Viral Mechanics */}
      <Card className="bg-slate-900/50 border-slate-700 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-purple-400">
            <TrendingUp className="w-5 h-5" />
            Viral Mechanics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-semibold text-slate-300">Viral Potential Score</span>
                <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                  {data.viralPotentialScore}/10
                </span>
              </div>
              <Progress 
                value={data.viralPotentialScore * 10} 
                className="h-2 bg-slate-800"
              />
            </div>
            
            <p className="text-slate-200 leading-relaxed">{data.viralMechanics}</p>
            
            {data.platformStrategy && Object.keys(data.platformStrategy).length > 0 && (
              <div className="mt-4 space-y-3">
                <p className="text-sm font-semibold text-slate-400 flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Platform Strategy:
                </p>
                <div className="grid gap-2">
                  {Object.entries(data.platformStrategy).map(([platform, strategy]: [string, string], index: number) => (
                    <div key={index} className="bg-slate-800/50 rounded-lg p-3 border border-slate-700">
                      <p className="text-sm font-semibold text-purple-400 mb-1">{platform}</p>
                      <p className="text-sm text-slate-300">{strategy}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recommended Upgrades */}
      <Card className="bg-slate-900/50 border-slate-700 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-yellow-400">
            <Wrench className="w-5 h-5" />
            Recommended Upgrades
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {data.recommendedUpgrades.map((upgrade: string, index: number) => (
              <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-slate-800/50 border border-slate-700">
                <div className="p-1 rounded bg-yellow-400/20 mt-0.5">
                  <Target className="w-4 h-4 text-yellow-400" />
                </div>
                <p className="text-slate-200 text-sm flex-1">{upgrade}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* DreamNet Mode Interpretation */}
      {dreamNetMode && data.dreamNetInterpretation && (
        <Card className="bg-gradient-to-br from-purple-950/50 to-pink-950/50 border-purple-700/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-transparent bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text">
              <Sparkles className="w-5 h-5 text-purple-400" />
              DreamNet Mode Interpretation
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {data.dreamNetInterpretation.theme && (
              <div>
                <p className="text-sm font-semibold text-purple-300 mb-1 flex items-center gap-2">
                  <Palette className="w-4 h-4" />
                  DreamNet Theme:
                </p>
                <p className="text-slate-200">{data.dreamNetInterpretation.theme}</p>
              </div>
            )}
            
            {data.dreamNetInterpretation.category && (
              <div>
                <p className="text-sm font-semibold text-purple-300 mb-1">Dream Cloud Category:</p>
                <Badge className="bg-purple-500/20 text-purple-300 border-purple-500">
                  {data.dreamNetInterpretation.category}
                </Badge>
              </div>
            )}
            
            {data.dreamNetInterpretation.monetizationOpportunity && (
              <div>
                <p className="text-sm font-semibold text-purple-300 mb-1">Monetization Opportunity:</p>
                <p className="text-slate-200">{data.dreamNetInterpretation.monetizationOpportunity}</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Action Plan */}
      <Card className="bg-gradient-to-br from-indigo-950/50 to-slate-950/50 border-indigo-700/50 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-indigo-400">
            <ListChecks className="w-5 h-5" />
            Creator Sprint Action Plan
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {data.actionPlan.map((action: string, index: number) => (
              <div key={index} className="flex items-start gap-3">
                <div className="flex-shrink-0 w-6 h-6 rounded-full bg-indigo-500 text-white flex items-center justify-center text-sm font-bold">
                  {index + 1}
                </div>
                <p className="text-slate-200 pt-0.5">{action}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
