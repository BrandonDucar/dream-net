'use client'

import { useCallback, useState } from 'react'
import { Upload, X } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface ImageUploadZoneProps {
  onImageUpload: (imageDataUrl: string) => void
  uploadedImage: string
}

export function ImageUploadZone({ onImageUpload, uploadedImage }: ImageUploadZoneProps): JSX.Element {
  const [isDragging, setIsDragging] = useState<boolean>(false)

  const handleFile = useCallback((file: File): void => {
    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file')
      return
    }

    const reader = new FileReader()
    reader.onload = (e: ProgressEvent<FileReader>): void => {
      if (e.target?.result) {
        onImageUpload(e.target.result as string)
      }
    }
    reader.readAsDataURL(file)
  }, [onImageUpload])

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>): void => {
    e.preventDefault()
    setIsDragging(false)
    
    const file = e.dataTransfer.files[0]
    if (file) {
      handleFile(file)
    }
  }, [handleFile])

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>): void => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>): void => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>): void => {
    const file = e.target.files?.[0]
    if (file) {
      handleFile(file)
    }
  }, [handleFile])

  const clearImage = useCallback((): void => {
    onImageUpload('')
  }, [onImageUpload])

  if (uploadedImage) {
    return (
      <div className="relative rounded-xl overflow-hidden border-2 border-slate-700 bg-slate-800">
        <img 
          src={uploadedImage} 
          alt="Uploaded visual" 
          className="w-full h-auto max-h-96 object-contain"
        />
        <Button
          onClick={clearImage}
          variant="destructive"
          size="sm"
          className="absolute top-3 right-3 rounded-full w-8 h-8 p-0"
        >
          <X className="w-4 h-4" />
        </Button>
      </div>
    )
  }

  return (
    <div
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      className={`
        relative border-2 border-dashed rounded-xl p-12 text-center transition-all
        ${isDragging 
          ? 'border-indigo-500 bg-indigo-950/50' 
          : 'border-slate-700 bg-slate-800/30 hover:border-slate-600'
        }
      `}
    >
      <input
        type="file"
        accept="image/*"
        onChange={handleFileInput}
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
      />
      
      <div className="pointer-events-none">
        <div className="p-4 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
          <Upload className="w-8 h-8 text-indigo-400" />
        </div>
        <p className="text-lg font-semibold text-slate-200 mb-2">
          Drop image here or click to upload
        </p>
        <p className="text-sm text-slate-400">
          Supports JPG, PNG, WebP
        </p>
      </div>
    </div>
  )
}
