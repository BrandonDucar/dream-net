export interface AnalysisData {
  scanSummary: string
  keyElements?: string[]
  emotionalPayload: string
  emotionalTriggers?: string[]
  viralMechanics: string
  viralPotentialScore: number
  platformStrategy?: Record<string, string>
  recommendedUpgrades: string[]
  dreamNetInterpretation?: {
    theme?: string
    category?: string
    monetizationOpportunity?: string
  }
  actionPlan: string[]
  engagementPrediction?: string
}
