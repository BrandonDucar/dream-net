'use client'
import { useState, useEffect } from 'react'
import { GoalSelection } from '@/components/GoalSelection'
import { DietaryPreferencesSelection } from '@/components/DietaryPreferencesSelection'
import { MealPlanDisplay } from '@/components/MealPlanDisplay'
import type { Goal, DietaryPreference, MealPlan } from '@/types/meal'
import { generateMealPlan } from '@/lib/meal-generator'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Home(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [step, setStep] = useState<number>(1)
  const [goal, setGoal] = useState<Goal | null>(null)
  const [dietaryPreference, setDietaryPreference] = useState<DietaryPreference | null>(null)
  const [duration, setDuration] = useState<1 | 7>(7)
  const [makeFaster, setMakeFaster] = useState<boolean>(false)
  const [budgetMode, setBudgetMode] = useState<boolean>(false)
  const [mealPlan, setMealPlan] = useState<MealPlan | null>(null)

  const handleGoalSelect = (selectedGoal: Goal): void => {
    setGoal(selectedGoal)
    setStep(2)
  }

  const handleDietaryPreferenceSelect = (preference: DietaryPreference, selectedDuration: 1 | 7): void => {
    setDietaryPreference(preference)
    setDuration(selectedDuration)
    
    const generatedPlan = generateMealPlan({
      goal: goal!,
      dietaryPreference: preference,
      duration: selectedDuration,
      makeFaster,
      budgetMode
    })
    
    setMealPlan(generatedPlan)
    setStep(3)
  }

  const handleRegenerate = (): void => {
    if (goal && dietaryPreference) {
      const generatedPlan = generateMealPlan({
        goal,
        dietaryPreference,
        duration,
        makeFaster,
        budgetMode
      })
      setMealPlan(generatedPlan)
    }
  }

  const handleBack = (): void => {
    if (step === 2) {
      setStep(1)
      setGoal(null)
    } else if (step === 3) {
      setStep(2)
      setDietaryPreference(null)
      setMealPlan(null)
    }
  }

  const handleToggleFaster = (enabled: boolean): void => {
    setMakeFaster(enabled)
    if (goal && dietaryPreference) {
      const generatedPlan = generateMealPlan({
        goal,
        dietaryPreference,
        duration,
        makeFaster: enabled,
        budgetMode
      })
      setMealPlan(generatedPlan)
    }
  }

  const handleToggleBudget = (enabled: boolean): void => {
    setBudgetMode(enabled)
    if (goal && dietaryPreference) {
      const generatedPlan = generateMealPlan({
        goal,
        dietaryPreference,
        duration,
        makeFaster,
        budgetMode: enabled
      })
      setMealPlan(generatedPlan)
    }
  }

  const handleRegenerateDay = (dayIndex: number): void => {
    if (goal && dietaryPreference && mealPlan) {
      const newDayPlan = generateMealPlan({
        goal,
        dietaryPreference,
        duration: 1,
        makeFaster,
        budgetMode
      })
      
      const updatedDays = [...mealPlan.days]
      updatedDays[dayIndex] = newDayPlan.days[0]
      
      setMealPlan({
        ...mealPlan,
        days: updatedDays
      })
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-yellow-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8 pt-8">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold bg-gradient-to-r from-orange-500 via-pink-500 to-yellow-500 text-transparent bg-clip-text mb-2">
            DreamMeal Planner
          </h1>
          <p className="text-xl sm:text-2xl text-gray-700 font-medium">$MEAL</p>
        </div>

        {step === 1 && (
          <GoalSelection onSelect={handleGoalSelect} />
        )}

        {step === 2 && (
          <DietaryPreferencesSelection
            onSelect={handleDietaryPreferenceSelect}
            onBack={handleBack}
            makeFaster={makeFaster}
            onToggleFaster={handleToggleFaster}
            budgetMode={budgetMode}
            onToggleBudget={handleToggleBudget}
          />
        )}

        {step === 3 && mealPlan && (
          <MealPlanDisplay
            mealPlan={mealPlan}
            onBack={handleBack}
            onRegenerate={handleRegenerate}
            onRegenerateDay={handleRegenerateDay}
            makeFaster={makeFaster}
            budgetMode={budgetMode}
          />
        )}
      </div>
    </main>
  )
}
