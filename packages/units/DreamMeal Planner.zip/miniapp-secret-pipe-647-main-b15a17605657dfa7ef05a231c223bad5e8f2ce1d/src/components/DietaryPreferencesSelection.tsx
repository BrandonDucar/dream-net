'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import type { DietaryPreference } from '@/types/meal'
import { ChevronLeft, Leaf, Pizza, Salad, Wheat, Users, Apple } from 'lucide-react'

interface DietaryPreferencesSelectionProps {
  onSelect: (preference: DietaryPreference, duration: 1 | 7) => void
  onBack: () => void
  makeFaster: boolean
  onToggleFaster: (enabled: boolean) => void
  budgetMode: boolean
  onToggleBudget: (enabled: boolean) => void
}

export function DietaryPreferencesSelection({
  onSelect,
  onBack,
  makeFaster,
  onToggleFaster,
  budgetMode,
  onToggleBudget
}: DietaryPreferencesSelectionProps): JSX.Element {
  const [selectedDuration, setSelectedDuration] = useState<1 | 7>(7)

  const preferences: Array<{
    value: DietaryPreference
    label: string
    description: string
    icon: JSX.Element
    color: string
  }> = [
    {
      value: 'regular',
      label: 'Regular',
      description: 'Balanced, varied diet',
      icon: <Pizza className="h-7 w-7" />,
      color: 'from-orange-400 to-red-400'
    },
    {
      value: 'keto',
      label: 'Keto',
      description: 'Low-carb, high-fat',
      icon: <Wheat className="h-7 w-7" />,
      color: 'from-purple-400 to-pink-400'
    },
    {
      value: 'vegan',
      label: 'Vegan',
      description: 'Plant-based only',
      icon: <Leaf className="h-7 w-7" />,
      color: 'from-green-400 to-emerald-400'
    },
    {
      value: 'vegetarian',
      label: 'Vegetarian',
      description: 'No meat, eggs & dairy OK',
      icon: <Salad className="h-7 w-7" />,
      color: 'from-lime-400 to-green-400'
    },
    {
      value: 'simple',
      label: 'Simple',
      description: 'Easy, basic ingredients',
      icon: <Apple className="h-7 w-7" />,
      color: 'from-yellow-400 to-orange-400'
    },
    {
      value: 'picky-eater',
      label: 'Picky Eater',
      description: 'Familiar, kid-friendly foods',
      icon: <Users className="h-7 w-7" />,
      color: 'from-blue-400 to-cyan-400'
    }
  ]

  return (
    <Card className="shadow-xl border-2 border-white/50 bg-white/90 backdrop-blur">
      <CardHeader>
        <div className="flex items-center gap-4 mb-2">
          <Button variant="ghost" size="icon" onClick={onBack} className="hover:bg-gray-100">
            <ChevronLeft className="h-6 w-6" />
          </Button>
          <div className="flex-1 text-center">
            <CardTitle className="text-3xl text-gray-800">Dietary Preferences</CardTitle>
            <CardDescription className="text-lg text-gray-600">
              How do you like to eat?
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {preferences.map((pref) => (
            <button
              key={pref.value}
              onClick={() => onSelect(pref.value, selectedDuration)}
              className="group relative overflow-hidden rounded-xl border-2 border-gray-200 bg-white p-5 text-left transition-all hover:border-transparent hover:shadow-2xl hover:scale-105"
            >
              <div
                className={`absolute inset-0 bg-gradient-to-br ${pref.color} opacity-0 transition-opacity group-hover:opacity-100`}
              />
              <div className="relative z-10">
                <div className="mb-3 text-gray-700 group-hover:text-white transition-colors">
                  {pref.icon}
                </div>
                <h3 className="text-lg font-bold text-gray-800 mb-1 group-hover:text-white transition-colors">
                  {pref.label}
                </h3>
                <p className="text-sm text-gray-600 group-hover:text-white/90 transition-colors">
                  {pref.description}
                </p>
              </div>
            </button>
          ))}
        </div>

        <div className="border-t pt-6 space-y-4">
          <div className="flex items-center justify-between bg-gradient-to-r from-yellow-50 to-orange-50 p-4 rounded-lg border border-yellow-200">
            <Label htmlFor="duration" className="text-lg font-semibold text-gray-800">
              Plan Duration
            </Label>
            <div className="flex gap-2">
              <Button
                variant={selectedDuration === 1 ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedDuration(1)}
                className={selectedDuration === 1 ? 'bg-gradient-to-r from-orange-500 to-pink-500' : ''}
              >
                1 Day
              </Button>
              <Button
                variant={selectedDuration === 7 ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedDuration(7)}
                className={selectedDuration === 7 ? 'bg-gradient-to-r from-orange-500 to-pink-500' : ''}
              >
                7 Days
              </Button>
            </div>
          </div>

          <div className="flex items-center justify-between bg-gradient-to-r from-pink-50 to-purple-50 p-4 rounded-lg border border-pink-200">
            <Label htmlFor="faster" className="text-lg font-semibold text-gray-800">
              Make It Faster (15-min meals)
            </Label>
            <Switch id="faster" checked={makeFaster} onCheckedChange={onToggleFaster} />
          </div>

          <div className="flex items-center justify-between bg-gradient-to-r from-green-50 to-teal-50 p-4 rounded-lg border border-green-200">
            <Label htmlFor="budget" className="text-lg font-semibold text-gray-800">
              Budget Mode
            </Label>
            <Switch id="budget" checked={budgetMode} onCheckedChange={onToggleBudget} />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
