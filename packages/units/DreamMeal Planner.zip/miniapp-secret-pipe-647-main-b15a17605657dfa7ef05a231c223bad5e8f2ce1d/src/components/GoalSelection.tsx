'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import type { Goal } from '@/types/meal'
import { Flame, Dumbbell, Heart, Wallet, Zap } from 'lucide-react'

interface GoalSelectionProps {
  onSelect: (goal: Goal) => void
}

export function GoalSelection({ onSelect }: GoalSelectionProps): JSX.Element {
  const goals: Array<{ value: Goal; label: string; description: string; icon: JSX.Element; color: string }> = [
    {
      value: 'lose-weight',
      label: 'Lose Weight',
      description: 'Balanced, calorie-conscious meals',
      icon: <Flame className="h-8 w-8" />,
      color: 'from-red-400 to-orange-400'
    },
    {
      value: 'build-muscle',
      label: 'Build Muscle',
      description: 'High-protein, energy-rich meals',
      icon: <Dumbbell className="h-8 w-8" />,
      color: 'from-blue-400 to-purple-400'
    },
    {
      value: 'eat-healthier',
      label: 'Eat Healthier',
      description: 'Nutritious, whole food options',
      icon: <Heart className="h-8 w-8" />,
      color: 'from-green-400 to-teal-400'
    },
    {
      value: 'save-money',
      label: 'Save Money',
      description: 'Budget-friendly, affordable meals',
      icon: <Wallet className="h-8 w-8" />,
      color: 'from-yellow-400 to-amber-400'
    },
    {
      value: 'eat-quick',
      label: 'Eat Quick Meals',
      description: 'Fast, simple meal prep',
      icon: <Zap className="h-8 w-8" />,
      color: 'from-pink-400 to-rose-400'
    }
  ]

  return (
    <Card className="shadow-xl border-2 border-white/50 bg-white/90 backdrop-blur">
      <CardHeader className="text-center">
        <CardTitle className="text-3xl text-gray-800">What&apos;s Your Goal?</CardTitle>
        <CardDescription className="text-lg text-gray-600">
          Choose what matters most to you
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {goals.map((goal) => (
            <button
              key={goal.value}
              onClick={() => onSelect(goal.value)}
              className="group relative overflow-hidden rounded-xl border-2 border-gray-200 bg-white p-6 text-left transition-all hover:border-transparent hover:shadow-2xl hover:scale-105"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${goal.color} opacity-0 transition-opacity group-hover:opacity-100`} />
              <div className="relative z-10">
                <div className="mb-3 text-gray-700 group-hover:text-white transition-colors">
                  {goal.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2 group-hover:text-white transition-colors">
                  {goal.label}
                </h3>
                <p className="text-sm text-gray-600 group-hover:text-white/90 transition-colors">
                  {goal.description}
                </p>
              </div>
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
