'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import type { GroceryList } from '@/types/meal'
import { Apple, Beef, Wheat, Milk, ShoppingCart, Lightbulb } from 'lucide-react'

interface GroceryListDisplayProps {
  groceryList: GroceryList
  shoppingTips: string[]
}

export function GroceryListDisplay({ groceryList, shoppingTips }: GroceryListDisplayProps): JSX.Element {
  const categories: Array<{
    title: string
    items: string[]
    icon: JSX.Element
    color: string
  }> = [
    {
      title: 'Produce',
      items: groceryList.produce,
      icon: <Apple className="h-5 w-5" />,
      color: 'from-green-400 to-emerald-400'
    },
    {
      title: 'Proteins',
      items: groceryList.proteins,
      icon: <Beef className="h-5 w-5" />,
      color: 'from-red-400 to-pink-400'
    },
    {
      title: 'Grains & Bread',
      items: groceryList.grains,
      icon: <Wheat className="h-5 w-5" />,
      color: 'from-yellow-400 to-orange-400'
    },
    {
      title: 'Dairy & Eggs',
      items: groceryList.dairy,
      icon: <Milk className="h-5 w-5" />,
      color: 'from-blue-400 to-cyan-400'
    },
    {
      title: 'Pantry Staples',
      items: groceryList.pantry,
      icon: <ShoppingCart className="h-5 w-5" />,
      color: 'from-purple-400 to-pink-400'
    }
  ]

  return (
    <div className="space-y-6">
      <Card className="shadow-xl border-2 border-white/50 bg-white/90 backdrop-blur">
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <CardTitle className="text-2xl text-gray-800 flex items-center gap-3">
              <ShoppingCart className="h-7 w-7 text-green-500" />
              Your Grocery List
            </CardTitle>
            <Badge className="bg-gradient-to-r from-green-500 to-teal-500 text-white text-lg px-4 py-2">
              Estimated: {groceryList.estimatedCost}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {categories.map((category) => (
            <div key={category.title} className="space-y-3">
              <div className={`flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r ${category.color} text-white font-bold`}>
                {category.icon}
                <h3 className="text-lg">{category.title}</h3>
              </div>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 pl-4">
                {category.items.map((item, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <span className="text-gray-400 mt-1">•</span>
                    <span className="text-gray-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="shadow-xl border-2 border-white/50 bg-gradient-to-br from-yellow-50 to-orange-50 backdrop-blur">
        <CardHeader>
          <CardTitle className="text-2xl text-gray-800 flex items-center gap-3">
            <Lightbulb className="h-7 w-7 text-yellow-500" />
            Shopping Tips
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            {shoppingTips.map((tip, index) => (
              <li key={index} className="flex items-start gap-3">
                <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white shrink-0 mt-1">
                  {index + 1}
                </Badge>
                <p className="text-gray-700 font-medium">{tip}</p>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
