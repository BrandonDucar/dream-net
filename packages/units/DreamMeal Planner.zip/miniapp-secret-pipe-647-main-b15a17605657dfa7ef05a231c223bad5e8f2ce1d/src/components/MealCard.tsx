'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import type { Meal } from '@/types/meal'
import { Clock, Flame, Beef, ChevronDown, ChevronUp } from 'lucide-react'

interface MealCardProps {
  meal: Meal
  mealType: string
  color: string
}

export function MealCard({ meal, mealType, color }: MealCardProps): JSX.Element {
  const [showSwaps, setShowSwaps] = useState<boolean>(false)
  const [showIngredients, setShowIngredients] = useState<boolean>(false)

  return (
    <Card className="border-2 border-gray-200 overflow-hidden hover:shadow-lg transition-shadow">
      <CardHeader className={`bg-gradient-to-r ${color} text-white`}>
        <CardTitle className="text-xl font-bold">{mealType}</CardTitle>
      </CardHeader>
      <CardContent className="p-5 space-y-4">
        <div>
          <h3 className="text-2xl font-bold text-gray-800 mb-3">{meal.name}</h3>
          <div className="flex flex-wrap gap-3">
            <Badge variant="outline" className="flex items-center gap-1 px-3 py-1">
              <Flame className="h-4 w-4 text-orange-500" />
              <span className="font-semibold">{meal.calories} cal</span>
            </Badge>
            <Badge variant="outline" className="flex items-center gap-1 px-3 py-1">
              <Beef className="h-4 w-4 text-red-500" />
              <span className="font-semibold">{meal.protein} protein</span>
            </Badge>
            <Badge variant="outline" className="flex items-center gap-1 px-3 py-1">
              <Clock className="h-4 w-4 text-blue-500" />
              <span className="font-semibold">{meal.prepTime}</span>
            </Badge>
          </div>
        </div>

        <div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowIngredients(!showIngredients)}
            className="text-gray-700 hover:text-gray-900 p-0 h-auto font-semibold"
          >
            Ingredients {showIngredients ? <ChevronUp className="h-4 w-4 ml-1" /> : <ChevronDown className="h-4 w-4 ml-1" />}
          </Button>
          {showIngredients && (
            <ul className="mt-2 space-y-1 pl-5">
              {meal.ingredients.map((ingredient, index) => (
                <li key={index} className="text-gray-700 list-disc">
                  {ingredient}
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="border-t pt-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowSwaps(!showSwaps)}
            className="w-full justify-between border-2 border-purple-200 text-purple-700 hover:bg-purple-50"
          >
            <span className="font-semibold">View Swap Options (3)</span>
            {showSwaps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </Button>
          {showSwaps && (
            <div className="mt-3 space-y-2">
              {meal.swaps.map((swap, index) => (
                <div
                  key={index}
                  className="p-3 rounded-lg bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200"
                >
                  <p className="text-gray-800 font-medium">
                    <span className="text-purple-600 font-bold">Option {index + 1}:</span> {swap}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
