'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { MealCard } from '@/components/MealCard'
import { GroceryListDisplay } from '@/components/GroceryListDisplay'
import type { MealPlan } from '@/types/meal'
import { ChevronLeft, RefreshCw, Calendar } from 'lucide-react'

interface MealPlanDisplayProps {
  mealPlan: MealPlan
  onBack: () => void
  onRegenerate: () => void
  onRegenerateDay: (dayIndex: number) => void
  makeFaster: boolean
  budgetMode: boolean
}

export function MealPlanDisplay({
  mealPlan,
  onBack,
  onRegenerate,
  onRegenerateDay,
  makeFaster,
  budgetMode
}: MealPlanDisplayProps): JSX.Element {
  return (
    <div className="space-y-6">
      <Card className="shadow-xl border-2 border-white/50 bg-white/90 backdrop-blur">
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={onBack} className="hover:bg-gray-100">
                <ChevronLeft className="h-6 w-6" />
              </Button>
              <div>
                <CardTitle className="text-3xl text-gray-800 flex items-center gap-3">
                  <Calendar className="h-8 w-8 text-pink-500" />
                  Your {mealPlan.duration}-Day Meal Plan
                </CardTitle>
                <div className="flex gap-2 mt-2 flex-wrap">
                  <Badge className="bg-gradient-to-r from-orange-500 to-pink-500 text-white">
                    {mealPlan.goal.replace('-', ' ').toUpperCase()}
                  </Badge>
                  <Badge className="bg-gradient-to-r from-green-500 to-teal-500 text-white">
                    {mealPlan.dietaryPreference.replace('-', ' ').toUpperCase()}
                  </Badge>
                  {makeFaster && (
                    <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                      15-MIN MEALS
                    </Badge>
                  )}
                  {budgetMode && (
                    <Badge className="bg-gradient-to-r from-yellow-500 to-amber-500 text-white">
                      BUDGET MODE
                    </Badge>
                  )}
                </div>
              </div>
            </div>
            <Button
              onClick={onRegenerate}
              className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Regenerate Plan
            </Button>
          </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="meals" className="w-full">
        <TabsList className="grid w-full grid-cols-2 h-auto bg-white/90 backdrop-blur border-2 border-white/50 shadow-lg">
          <TabsTrigger
            value="meals"
            className="text-lg py-3 data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-pink-500 data-[state=active]:text-white"
          >
            Meal Plans
          </TabsTrigger>
          <TabsTrigger
            value="grocery"
            className="text-lg py-3 data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500 data-[state=active]:to-teal-500 data-[state=active]:text-white"
          >
            Grocery List
          </TabsTrigger>
        </TabsList>

        <TabsContent value="meals" className="space-y-6 mt-6">
          {mealPlan.days.map((day, dayIndex) => (
            <Card key={dayIndex} className="shadow-xl border-2 border-white/50 bg-white/90 backdrop-blur">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-2xl text-gray-800">
                    {mealPlan.duration === 7 ? `Day ${day.dayNumber}` : 'Your Daily Plan'}
                  </CardTitle>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onRegenerateDay(dayIndex)}
                    className="border-pink-300 text-pink-600 hover:bg-pink-50"
                  >
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Regenerate This Day
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <MealCard meal={day.breakfast} mealType="Breakfast" color="from-yellow-400 to-orange-400" />
                <MealCard meal={day.lunch} mealType="Lunch" color="from-green-400 to-teal-400" />
                <MealCard meal={day.dinner} mealType="Dinner" color="from-blue-400 to-purple-400" />
                <MealCard meal={day.snacks} mealType="Snacks" color="from-pink-400 to-rose-400" />
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="grocery" className="mt-6">
          <GroceryListDisplay
            groceryList={mealPlan.groceryList}
            shoppingTips={mealPlan.shoppingTips}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}
