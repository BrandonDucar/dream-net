import type { MealGenerationOptions, MealPlan, DayPlan, Meal, GroceryList } from '@/types/meal'

const mealDatabase: Record<string, Record<string, Meal[]>> = {
  breakfast: {
    regular: [
      {
        name: 'Classic Avocado Toast',
        calories: 350,
        protein: '12g',
        prepTime: '10 min',
        ingredients: ['2 slices whole grain bread', '1 avocado', '2 eggs', 'Cherry tomatoes', 'Salt & pepper'],
        swaps: [
          'Scrambled Egg Wrap with spinach and feta',
          'Greek Yogurt Bowl with granola and berries',
          'Banana Oatmeal Pancakes with maple syrup'
        ]
      },
      {
        name: 'Berry Protein Smoothie Bowl',
        calories: 380,
        protein: '25g',
        prepTime: '8 min',
        ingredients: ['1 cup mixed berries', '1 scoop protein powder', '1 banana', 'Almond milk', 'Granola'],
        swaps: [
          'Peanut Butter Banana Toast',
          'Veggie Omelet with whole wheat toast',
          'Overnight Oats with chia seeds'
        ]
      }
    ],
    keto: [
      {
        name: 'Keto Egg Muffins',
        calories: 320,
        protein: '24g',
        prepTime: '20 min',
        ingredients: ['6 eggs', 'Cheddar cheese', 'Bacon bits', 'Spinach', 'Bell peppers'],
        swaps: [
          'Bulletproof Coffee with MCT oil',
          'Smoked Salmon & Cream Cheese Roll-ups',
          'Keto Breakfast Skillet with sausage'
        ]
      }
    ],
    vegan: [
      {
        name: 'Tofu Scramble Bowl',
        calories: 310,
        protein: '18g',
        prepTime: '12 min',
        ingredients: ['Firm tofu', 'Turmeric', 'Spinach', 'Cherry tomatoes', 'Nutritional yeast'],
        swaps: [
          'Chia Pudding with coconut milk',
          'Vegan Protein Smoothie with dates',
          'Chickpea Flour Pancakes'
        ]
      }
    ],
    vegetarian: [
      {
        name: 'Veggie Breakfast Burrito',
        calories: 420,
        protein: '16g',
        prepTime: '15 min',
        ingredients: ['Whole wheat tortilla', '3 eggs', 'Black beans', 'Cheese', 'Salsa', 'Avocado'],
        swaps: [
          'Cottage Cheese Bowl with fruit',
          'French Toast with berries',
          'Spinach & Feta Frittata'
        ]
      }
    ],
    simple: [
      {
        name: 'Peanut Butter Toast',
        calories: 280,
        protein: '12g',
        prepTime: '5 min',
        ingredients: ['2 slices bread', 'Peanut butter', 'Banana slices', 'Honey'],
        swaps: [
          'Cereal with milk and banana',
          'Bagel with cream cheese',
          'Instant Oatmeal with brown sugar'
        ]
      }
    ],
    'picky-eater': [
      {
        name: 'Classic Scrambled Eggs & Toast',
        calories: 300,
        protein: '14g',
        prepTime: '8 min',
        ingredients: ['3 eggs', '2 slices white bread', 'Butter', 'Salt'],
        swaps: [
          'Waffles with syrup',
          'Pancakes with butter',
          'French Toast Sticks'
        ]
      }
    ]
  },
  lunch: {
    regular: [
      {
        name: 'Grilled Chicken Caesar Salad',
        calories: 480,
        protein: '38g',
        prepTime: '20 min',
        ingredients: ['Chicken breast', 'Romaine lettuce', 'Parmesan', 'Caesar dressing', 'Croutons'],
        swaps: [
          'Turkey & Avocado Wrap',
          'Quinoa Buddha Bowl with chickpeas',
          'Caprese Sandwich with pesto'
        ]
      },
      {
        name: 'Mediterranean Grain Bowl',
        calories: 520,
        protein: '22g',
        prepTime: '18 min',
        ingredients: ['Quinoa', 'Chickpeas', 'Cucumber', 'Tomatoes', 'Feta', 'Hummus', 'Olive oil'],
        swaps: [
          'Chicken Fajita Bowl',
          'Asian Noodle Salad',
          'Greek Pita Pocket'
        ]
      }
    ],
    keto: [
      {
        name: 'Keto Chicken Alfredo Zoodles',
        calories: 450,
        protein: '35g',
        prepTime: '15 min',
        ingredients: ['Zucchini noodles', 'Grilled chicken', 'Heavy cream', 'Parmesan', 'Garlic'],
        swaps: [
          'Bunless Burger with side salad',
          'Cobb Salad with ranch',
          'Keto Taco Bowl'
        ]
      }
    ],
    vegan: [
      {
        name: 'Vegan Buddha Bowl',
        calories: 460,
        protein: '16g',
        prepTime: '25 min',
        ingredients: ['Brown rice', 'Chickpeas', 'Sweet potato', 'Kale', 'Tahini dressing'],
        swaps: [
          'Lentil Soup with bread',
          'Veggie Stir-fry with tofu',
          'Falafel Wrap with hummus'
        ]
      }
    ],
    vegetarian: [
      {
        name: 'Caprese Panini',
        calories: 440,
        protein: '18g',
        prepTime: '12 min',
        ingredients: ['Ciabatta bread', 'Fresh mozzarella', 'Tomatoes', 'Basil', 'Balsamic glaze'],
        swaps: [
          'Grilled Cheese & Tomato Soup',
          'Veggie Pizza Slice',
          'Egg Salad Sandwich'
        ]
      }
    ],
    simple: [
      {
        name: 'Ham & Cheese Sandwich',
        calories: 380,
        protein: '20g',
        prepTime: '5 min',
        ingredients: ['2 slices bread', 'Ham', 'Cheese', 'Lettuce', 'Mayo'],
        swaps: [
          'PB&J Sandwich',
          'Grilled Cheese',
          'Tuna Salad Sandwich'
        ]
      }
    ],
    'picky-eater': [
      {
        name: 'Mac & Cheese with Chicken Nuggets',
        calories: 520,
        protein: '24g',
        prepTime: '15 min',
        ingredients: ['Macaroni', 'Cheddar cheese', 'Milk', 'Butter', 'Chicken nuggets'],
        swaps: [
          'Cheese Pizza Slice',
          'Hot Dog with fries',
          'Chicken Fingers with ketchup'
        ]
      }
    ]
  },
  dinner: {
    regular: [
      {
        name: 'Baked Salmon with Roasted Vegetables',
        calories: 580,
        protein: '42g',
        prepTime: '35 min',
        ingredients: ['Salmon fillet', 'Broccoli', 'Carrots', 'Sweet potato', 'Olive oil', 'Lemon'],
        swaps: [
          'Grilled Chicken with Quinoa',
          'Beef Stir-fry with brown rice',
          'Turkey Meatballs with marinara'
        ]
      },
      {
        name: 'Chicken Fajita Bowl',
        calories: 540,
        protein: '38g',
        prepTime: '25 min',
        ingredients: ['Chicken breast', 'Bell peppers', 'Onions', 'Rice', 'Black beans', 'Salsa', 'Avocado'],
        swaps: [
          'Shrimp Tacos',
          'Beef Burrito Bowl',
          'Grilled Steak Salad'
        ]
      }
    ],
    keto: [
      {
        name: 'Keto Steak with Cauliflower Mash',
        calories: 620,
        protein: '48g',
        prepTime: '30 min',
        ingredients: ['Ribeye steak', 'Cauliflower', 'Butter', 'Cream cheese', 'Asparagus'],
        swaps: [
          'Garlic Butter Shrimp with Zoodles',
          'Keto Meatloaf with green beans',
          'Pork Chops with Brussels sprouts'
        ]
      }
    ],
    vegan: [
      {
        name: 'Vegan Curry with Chickpeas',
        calories: 510,
        protein: '18g',
        prepTime: '30 min',
        ingredients: ['Chickpeas', 'Coconut milk', 'Curry paste', 'Cauliflower', 'Spinach', 'Rice'],
        swaps: [
          'Vegan Pasta Primavera',
          'Lentil Shepherd\'s Pie',
          'Black Bean Tacos'
        ]
      }
    ],
    vegetarian: [
      {
        name: 'Eggplant Parmesan',
        calories: 480,
        protein: '22g',
        prepTime: '40 min',
        ingredients: ['Eggplant', 'Marinara sauce', 'Mozzarella', 'Parmesan', 'Breadcrumbs', 'Pasta'],
        swaps: [
          'Vegetarian Lasagna',
          'Mushroom Risotto',
          'Veggie Pizza'
        ]
      }
    ],
    simple: [
      {
        name: 'Spaghetti with Meat Sauce',
        calories: 560,
        protein: '28g',
        prepTime: '25 min',
        ingredients: ['Spaghetti', 'Ground beef', 'Marinara sauce', 'Garlic', 'Parmesan'],
        swaps: [
          'Baked Chicken with rice',
          'Beef Tacos',
          'Hamburger with fries'
        ]
      }
    ],
    'picky-eater': [
      {
        name: 'Chicken Tenders with Mashed Potatoes',
        calories: 540,
        protein: '30g',
        prepTime: '20 min',
        ingredients: ['Chicken tenders', 'Potatoes', 'Butter', 'Milk', 'Breadcrumbs'],
        swaps: [
          'Cheese Pizza',
          'Spaghetti with butter',
          'Grilled Cheese with soup'
        ]
      }
    ]
  },
  snacks: {
    regular: [
      {
        name: 'Apple with Almond Butter',
        calories: 220,
        protein: '6g',
        prepTime: '2 min',
        ingredients: ['1 apple', '2 tbsp almond butter'],
        swaps: [
          'Greek Yogurt with honey',
          'Trail mix',
          'Protein bar'
        ]
      }
    ],
    keto: [
      {
        name: 'Cheese & Pepperoni Roll-ups',
        calories: 180,
        protein: '14g',
        prepTime: '3 min',
        ingredients: ['Mozzarella cheese', 'Pepperoni slices'],
        swaps: [
          'Celery with cream cheese',
          'Handful of macadamia nuts',
          'Keto fat bombs'
        ]
      }
    ],
    vegan: [
      {
        name: 'Hummus with Veggies',
        calories: 160,
        protein: '7g',
        prepTime: '5 min',
        ingredients: ['Hummus', 'Carrots', 'Cucumber', 'Bell peppers'],
        swaps: [
          'Mixed nuts',
          'Fruit smoothie',
          'Rice cakes with avocado'
        ]
      }
    ],
    vegetarian: [
      {
        name: 'String Cheese & Crackers',
        calories: 200,
        protein: '10g',
        prepTime: '2 min',
        ingredients: ['String cheese', 'Whole grain crackers'],
        swaps: [
          'Yogurt parfait',
          'Granola bar',
          'Popcorn'
        ]
      }
    ],
    simple: [
      {
        name: 'Banana with Peanut Butter',
        calories: 190,
        protein: '7g',
        prepTime: '2 min',
        ingredients: ['1 banana', '1 tbsp peanut butter'],
        swaps: [
          'Graham crackers',
          'Pretzels',
          'Fruit cup'
        ]
      }
    ],
    'picky-eater': [
      {
        name: 'Goldfish Crackers',
        calories: 140,
        protein: '3g',
        prepTime: '1 min',
        ingredients: ['Goldfish crackers'],
        swaps: [
          'Animal crackers',
          'Cheese cubes',
          'Apple sauce'
        ]
      }
    ]
  }
}

function selectMeal(mealType: string, dietaryPreference: string, goal: string, makeFaster: boolean, usedMeals: Set<string>): Meal {
  let meals = mealDatabase[mealType][dietaryPreference] || mealDatabase[mealType].regular
  
  const availableMeals = meals.filter(meal => !usedMeals.has(`${mealType}-${meal.name}`))
  if (availableMeals.length === 0) {
    usedMeals.clear()
    meals = mealDatabase[mealType][dietaryPreference] || mealDatabase[mealType].regular
  } else {
    meals = availableMeals
  }
  
  const randomMeal = meals[Math.floor(Math.random() * meals.length)]
  usedMeals.add(`${mealType}-${randomMeal.name}`)
  
  if (makeFaster) {
    return {
      ...randomMeal,
      prepTime: '15 min'
    }
  }
  
  if (goal === 'lose-weight') {
    return {
      ...randomMeal,
      calories: Math.round(randomMeal.calories * 0.85)
    }
  }
  
  if (goal === 'build-muscle') {
    return {
      ...randomMeal,
      calories: Math.round(randomMeal.calories * 1.15),
      protein: `${parseInt(randomMeal.protein) + 5}g`
    }
  }
  
  return randomMeal
}

function generateGroceryList(days: DayPlan[], budgetMode: boolean, dietaryPreference: string): GroceryList {
  const produceMap: Record<string, string[]> = {
    regular: ['Avocados', 'Bananas', 'Berries', 'Tomatoes', 'Spinach', 'Broccoli', 'Carrots', 'Sweet potatoes', 'Onions', 'Bell peppers'],
    keto: ['Avocados', 'Spinach', 'Broccoli', 'Cauliflower', 'Zucchini', 'Bell peppers', 'Asparagus', 'Mushrooms'],
    vegan: ['Avocados', 'Bananas', 'Berries', 'Tomatoes', 'Spinach', 'Kale', 'Sweet potatoes', 'Cauliflower', 'Bell peppers', 'Cucumbers'],
    vegetarian: ['Avocados', 'Tomatoes', 'Spinach', 'Broccoli', 'Bell peppers', 'Lettuce', 'Carrots', 'Mushrooms'],
    simple: ['Bananas', 'Apples', 'Carrots', 'Potatoes', 'Onions'],
    'picky-eater': ['Bananas', 'Apples', 'Carrots', 'Corn', 'Potatoes']
  }
  
  const proteinsMap: Record<string, string[]> = {
    regular: ['Chicken breast', 'Salmon', 'Ground beef', 'Eggs', 'Turkey'],
    keto: ['Chicken breast', 'Salmon', 'Ribeye steak', 'Bacon', 'Eggs', 'Pork chops'],
    vegan: ['Firm tofu', 'Chickpeas', 'Black beans', 'Lentils', 'Tempeh'],
    vegetarian: ['Eggs', 'Chickpeas', 'Black beans', 'Cheese', 'Greek yogurt'],
    simple: ['Ground beef', 'Chicken', 'Eggs', 'Ham'],
    'picky-eater': ['Chicken nuggets', 'Hot dogs', 'Eggs', 'Cheese']
  }
  
  const grainsMap: Record<string, string[]> = {
    regular: ['Whole grain bread', 'Brown rice', 'Quinoa', 'Whole wheat pasta', 'Oats'],
    keto: [],
    vegan: ['Whole grain bread', 'Brown rice', 'Quinoa', 'Pasta'],
    vegetarian: ['Whole grain bread', 'Pasta', 'Rice', 'Tortillas'],
    simple: ['White bread', 'White rice', 'Pasta'],
    'picky-eater': ['White bread', 'Macaroni', 'Crackers', 'Cereal']
  }
  
  const dairyMap: Record<string, string[]> = {
    regular: ['Milk', 'Greek yogurt', 'Cheddar cheese', 'Mozzarella', 'Butter'],
    keto: ['Heavy cream', 'Cream cheese', 'Cheddar cheese', 'Mozzarella', 'Butter'],
    vegan: [],
    vegetarian: ['Milk', 'Greek yogurt', 'Cheese', 'Eggs', 'Butter'],
    simple: ['Milk', 'Butter', 'Cheese'],
    'picky-eater': ['Milk', 'Cheese', 'Butter']
  }
  
  const pantryMap: Record<string, string[]> = {
    regular: ['Olive oil', 'Salt & pepper', 'Garlic', 'Almond butter', 'Protein powder', 'Honey'],
    keto: ['Olive oil', 'Coconut oil', 'MCT oil', 'Salt & pepper', 'Garlic'],
    vegan: ['Olive oil', 'Tahini', 'Nutritional yeast', 'Curry paste', 'Coconut milk'],
    vegetarian: ['Olive oil', 'Marinara sauce', 'Pesto', 'Hummus'],
    simple: ['Ketchup', 'Mayo', 'Peanut butter', 'Cooking oil'],
    'picky-eater': ['Ketchup', 'Ranch dressing', 'Peanut butter', 'Syrup']
  }
  
  const estimatedCosts: Record<string, string> = {
    '1-budget': '$25-35',
    '1-premium': '$45-60',
    '7-budget': '$60-80',
    '7-premium': '$120-160'
  }
  
  const duration = days.length
  const costKey = `${duration}-${budgetMode ? 'budget' : 'premium'}`
  
  return {
    produce: produceMap[dietaryPreference] || produceMap.regular,
    proteins: proteinsMap[dietaryPreference] || proteinsMap.regular,
    grains: grainsMap[dietaryPreference] || grainsMap.regular,
    dairy: dairyMap[dietaryPreference] || dairyMap.regular,
    pantry: pantryMap[dietaryPreference] || pantryMap.regular,
    estimatedCost: estimatedCosts[costKey]
  }
}

function generateShoppingTips(budgetMode: boolean, goal: string): string[] {
  const baseTips = [
    'Shop the perimeter of the store for fresh, whole foods',
    'Buy seasonal produce for better prices and quality',
    'Check unit prices to compare different sizes and brands',
    'Make a list and stick to it to avoid impulse purchases'
  ]
  
  if (budgetMode) {
    return [
      ...baseTips,
      'Buy store brands instead of name brands',
      'Purchase frozen vegetables – they\'re just as nutritious and cheaper',
      'Buy in bulk for items you use frequently'
    ]
  }
  
  return [
    ...baseTips,
    'Choose organic for the "Dirty Dozen" produce items',
    'Look for grass-fed meats and wild-caught fish when possible',
    'Don\'t be afraid to try premium ingredients that enhance flavor'
  ]
}

export function generateMealPlan(options: MealGenerationOptions): MealPlan {
  const { goal, dietaryPreference, duration, makeFaster, budgetMode } = options
  const days: DayPlan[] = []
  const usedMeals = new Set<string>()
  
  for (let i = 0; i < duration; i++) {
    days.push({
      dayNumber: i + 1,
      breakfast: selectMeal('breakfast', dietaryPreference, goal, makeFaster, usedMeals),
      lunch: selectMeal('lunch', dietaryPreference, goal, makeFaster, usedMeals),
      dinner: selectMeal('dinner', dietaryPreference, goal, makeFaster, usedMeals),
      snacks: selectMeal('snacks', dietaryPreference, goal, makeFaster, usedMeals)
    })
  }
  
  return {
    goal,
    dietaryPreference,
    duration,
    days,
    groceryList: generateGroceryList(days, budgetMode, dietaryPreference),
    shoppingTips: generateShoppingTips(budgetMode, goal)
  }
}
