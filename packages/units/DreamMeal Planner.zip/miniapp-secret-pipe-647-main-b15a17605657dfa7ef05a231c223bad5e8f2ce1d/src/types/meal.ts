export type Goal = 
  | 'lose-weight'
  | 'build-muscle'
  | 'eat-healthier'
  | 'save-money'
  | 'eat-quick'

export type DietaryPreference = 
  | 'regular'
  | 'keto'
  | 'vegan'
  | 'vegetarian'
  | 'simple'
  | 'picky-eater'

export interface Meal {
  name: string
  calories: number
  protein: string
  prepTime: string
  ingredients: string[]
  swaps: string[]
}

export interface DayPlan {
  dayNumber: number
  breakfast: Meal
  lunch: Meal
  dinner: Meal
  snacks: Meal
}

export interface MealPlan {
  goal: Goal
  dietaryPreference: DietaryPreference
  duration: 1 | 7
  days: DayPlan[]
  groceryList: GroceryList
  shoppingTips: string[]
}

export interface GroceryList {
  produce: string[]
  proteins: string[]
  grains: string[]
  dairy: string[]
  pantry: string[]
  estimatedCost: string
}

export interface MealGenerationOptions {
  goal: Goal
  dietaryPreference: DietaryPreference
  duration: 1 | 7
  makeFaster: boolean
  budgetMode: boolean
}
