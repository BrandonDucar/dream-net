'use client'
import React, { useState, useEffect } from 'react'
import { BackendProvider } from '@/context/BackendContext'
import { ModelsOverview } from '@/components/backend/ModelsOverview'
import { EndpointsOverview } from '@/components/backend/EndpointsOverview'
import { ModelDetail } from '@/components/backend/ModelDetail'
import { EndpointDetail } from '@/components/backend/EndpointDetail'
import { MiniAppsView } from '@/components/backend/MiniAppsView'
import { SpecsExport } from '@/components/backend/SpecsExport'
import { CodeGenerationTab } from '@/components/backend/CodeGenerationTab'
import { ValidationDashboard } from '@/components/backend/ValidationDashboard'
import { ImportExportPanel } from '@/components/backend/ImportExportPanel'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card } from '@/components/ui/card'
import { Toaster } from '@/components/ui/sonner'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type ViewMode = 'overview' | 'modelDetail' | 'endpointDetail';

export default function DreamNetBackendArchitect(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [viewMode, setViewMode] = useState<ViewMode>('overview');
  const [selectedModelId, setSelectedModelId] = useState<string | null>(null);
  const [selectedEndpointId, setSelectedEndpointId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>('models');

  const handleSelectModel = (modelId: string): void => {
    setSelectedModelId(modelId);
    setViewMode('modelDetail');
  };

  const handleSelectEndpoint = (endpointId: string): void => {
    setSelectedEndpointId(endpointId);
    setViewMode('endpointDetail');
  };

  const handleBackToOverview = (): void => {
    setViewMode('overview');
    setSelectedModelId(null);
    setSelectedEndpointId(null);
  };

  return (
    <BackendProvider>
      <div className="min-h-screen bg-background">
        <Toaster />
        
        {/* Header */}
        <header className="border-b bg-card">
          <div className="container mx-auto px-4 py-6">
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <h1 className="text-3xl font-bold tracking-tight">DreamNet Shared Backend Architect</h1>
                <span className="px-3 py-1 text-xs font-bold bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-full">
                  v2.0 PRO
                </span>
              </div>
              <p className="text-muted-foreground">
                AI-powered schema design • Code generation • Validation • Import/Export • Cost estimation
              </p>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="container mx-auto px-4 py-8">
          {viewMode === 'modelDetail' && selectedModelId ? (
            <ModelDetail modelId={selectedModelId} onBack={handleBackToOverview} />
          ) : viewMode === 'endpointDetail' && selectedEndpointId ? (
            <EndpointDetail endpointId={selectedEndpointId} onBack={handleBackToOverview} />
          ) : (
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3 lg:grid-cols-7 lg:w-auto">
                <TabsTrigger value="models">Models</TabsTrigger>
                <TabsTrigger value="miniapps">Mini-Apps</TabsTrigger>
                <TabsTrigger value="codegen">Code Gen</TabsTrigger>
                <TabsTrigger value="validation">Validation</TabsTrigger>
                <TabsTrigger value="import">Import/Export</TabsTrigger>
                <TabsTrigger value="export">Specs</TabsTrigger>
                <TabsTrigger value="about">About</TabsTrigger>
              </TabsList>

              <TabsContent value="models" className="space-y-6 mt-6">
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                  <ModelsOverview onSelectModel={handleSelectModel} />
                  <EndpointsOverview onSelectEndpoint={handleSelectEndpoint} />
                </div>
              </TabsContent>

              <TabsContent value="miniapps" className="mt-6">
                <MiniAppsView />
              </TabsContent>

              <TabsContent value="codegen" className="mt-6">
                <CodeGenerationTab />
              </TabsContent>

              <TabsContent value="validation" className="mt-6">
                <ValidationDashboard />
              </TabsContent>

              <TabsContent value="import" className="mt-6">
                <ImportExportPanel />
              </TabsContent>

              <TabsContent value="export" className="mt-6">
                <SpecsExport />
              </TabsContent>

              <TabsContent value="about" className="mt-6">
                <Card className="p-6">
                  <div className="space-y-6">
                    <div>
                      <h2 className="text-2xl font-bold mb-3">About DreamNet Backend Architect</h2>
                      <p className="text-muted-foreground">
                        Your schema & API forge for designing the shared data model and API surface for DreamNet - the
                        single source of truth for how all Ohara mini-apps will eventually talk to a shared backend.
                      </p>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-2">🚀 Enhanced Features</h3>
                      <div className="grid md:grid-cols-2 gap-3">
                        <div className="space-y-2 text-sm text-muted-foreground">
                          <li>• <strong>Backend Models:</strong> Define models with fields, relationships, indexes</li>
                          <li>• <strong>API Endpoints:</strong> Design REST-style endpoints with full schemas</li>
                          <li>• <strong>Mini-App Mapping:</strong> Track which apps use which endpoints</li>
                          <li>• <strong>SEO & Geo:</strong> Auto-generated SEO + localized descriptions</li>
                        </div>
                        <div className="space-y-2 text-sm text-muted-foreground">
                          <li>• <strong>Code Generation:</strong> Prisma, TypeScript, SQL, API clients, React hooks</li>
                          <li>• <strong>AI Validation:</strong> Schema validation, security audit, cost estimation</li>
                          <li>• <strong>Import/Export:</strong> JSON, CSV, Prisma, OpenAPI, SQL formats</li>
                          <li>• <strong>GraphQL:</strong> Generate GraphQL schemas alongside REST</li>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-2">Data Model Categories</h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                        <div className="p-3 border rounded-lg">
                          <div className="font-medium">Culture</div>
                          <div className="text-muted-foreground text-xs">CultureCoins, tokens</div>
                        </div>
                        <div className="p-3 border rounded-lg">
                          <div className="font-medium">Distribution</div>
                          <div className="text-muted-foreground text-xs">Drops, campaigns</div>
                        </div>
                        <div className="p-3 border rounded-lg">
                          <div className="font-medium">Social</div>
                          <div className="text-muted-foreground text-xs">Accounts, profiles</div>
                        </div>
                        <div className="p-3 border rounded-lg">
                          <div className="font-medium">Operations</div>
                          <div className="text-muted-foreground text-xs">Scripts, actions</div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-2">Workflow</h3>
                      <ol className="space-y-2 text-sm text-muted-foreground list-decimal list-inside">
                        <li>Register your Ohara mini-apps in the Mini-Apps tab</li>
                        <li>Create backend models and define their fields</li>
                        <li>Design API endpoints that operate on these models</li>
                        <li>Map which mini-apps use which endpoints</li>
                        <li>Export specs (SQL schema, OpenAPI, full documentation) to hand off to developers</li>
                      </ol>
                    </div>

                    <div className="pt-4 border-t">
                      <p className="text-xs text-muted-foreground">
                        <strong>Note:</strong> This app designs your backend architecture but doesn't implement it. All
                        data is stored locally in your browser. Use the Export Specs tab to generate implementation-ready
                        documentation.
                      </p>
                    </div>
                  </div>
                </Card>
              </TabsContent>
            </Tabs>
          )}
        </main>

        {/* Footer */}
        <footer className="border-t mt-12">
          <div className="container mx-auto px-4 py-6">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-sm text-muted-foreground">
                DreamNet Shared Backend Architect - Your schema & API forge
              </p>
              <div className="flex gap-4 text-sm text-muted-foreground">
                <span>Models: {viewMode === 'overview' ? '✓' : ''}</span>
                <span>Endpoints: {viewMode === 'overview' ? '✓' : ''}</span>
                <span>Local Storage: Enabled</span>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </BackendProvider>
  );
}
