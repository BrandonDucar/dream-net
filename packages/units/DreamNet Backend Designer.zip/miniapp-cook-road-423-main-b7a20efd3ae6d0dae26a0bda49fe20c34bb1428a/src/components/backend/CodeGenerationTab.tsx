'use client'

import React, { useState } from 'react';
import { useBackend } from '@/context/BackendContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { 
  Code2, 
  Database, 
  FileCode, 
  FileJson, 
  Download,
  Copy,
  CheckCircle2
} from 'lucide-react';
import { toast } from 'sonner';
import {
  generatePrismaSchema,
  generateTypeScriptTypes,
  generateMigrationSQL,
  generateAPIClientSDK,
  generateReactHooks,
  generateGraphQLSchema,
  generateAPITests,
  generateNextJSAPIRoutes,
} from '@/lib/code-generators';

interface CodeGeneratorProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  generate: () => string;
}

function CodeGenerator({ title, description, icon, generate }: CodeGeneratorProps): JSX.Element {
  const [code, setCode] = useState<string>('');
  const [generated, setGenerated] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  const handleGenerate = (): void => {
    try {
      const generatedCode = generate();
      setCode(generatedCode);
      setGenerated(true);
      toast.success(`${title} generated successfully!`);
    } catch (error) {
      toast.error('Failed to generate code');
      console.error(error);
    }
  };

  const handleCopy = async (): Promise<void> => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      toast.success('Copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast.error('Failed to copy to clipboard');
    }
  };

  const handleDownload = (): void => {
    const extension = title.includes('SQL') ? 'sql' : 
                      title.includes('GraphQL') ? 'graphql' :
                      title.includes('Prisma') ? 'prisma' : 'ts';
    const filename = `${title.toLowerCase().replace(/\s+/g, '-')}.${extension}`;
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`Downloaded ${filename}`);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start gap-3">
          <div className="p-2 bg-primary/10 rounded-lg">{icon}</div>
          <div className="flex-1">
            <CardTitle className="text-lg">{title}</CardTitle>
            <CardDescription className="text-sm mt-1">{description}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex gap-2">
          <Button onClick={handleGenerate} className="flex-1">
            <Code2 className="w-4 h-4 mr-2" />
            Generate Code
          </Button>
          {generated && (
            <>
              <Button onClick={handleCopy} variant="outline" size="icon">
                {copied ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
              </Button>
              <Button onClick={handleDownload} variant="outline" size="icon">
                <Download className="w-4 h-4" />
              </Button>
            </>
          )}
        </div>

        {generated && (
          <Textarea
            value={code}
            readOnly
            className="font-mono text-xs h-64 resize-none"
            placeholder="Generated code will appear here..."
          />
        )}
      </CardContent>
    </Card>
  );
}

export function CodeGenerationTab(): JSX.Element {
  const { models, fields, endpoints } = useBackend();

  const generators: CodeGeneratorProps[] = [
    {
      title: 'Prisma Schema',
      description: 'Generate a complete Prisma schema for your models',
      icon: <Database className="w-5 h-5 text-purple-500" />,
      generate: () => generatePrismaSchema(models, fields),
    },
    {
      title: 'TypeScript Types',
      description: 'Generate TypeScript interfaces and types',
      icon: <FileCode className="w-5 h-5 text-blue-500" />,
      generate: () => generateTypeScriptTypes(models, fields),
    },
    {
      title: 'SQL Migration',
      description: 'Generate SQL migration for PostgreSQL',
      icon: <Database className="w-5 h-5 text-green-500" />,
      generate: () => generateMigrationSQL(models, fields),
    },
    {
      title: 'API Client SDK',
      description: 'Generate TypeScript API client',
      icon: <FileCode className="w-5 h-5 text-orange-500" />,
      generate: () => generateAPIClientSDK(endpoints, models),
    },
    {
      title: 'React Hooks',
      description: 'Generate React hooks for API endpoints',
      icon: <FileCode className="w-5 h-5 text-cyan-500" />,
      generate: () => generateReactHooks(endpoints, models),
    },
    {
      title: 'GraphQL Schema',
      description: 'Generate GraphQL schema definition',
      icon: <FileJson className="w-5 h-5 text-pink-500" />,
      generate: () => generateGraphQLSchema(models, fields),
    },
    {
      title: 'API Tests',
      description: 'Generate automated test suite',
      icon: <FileCode className="w-5 h-5 text-red-500" />,
      generate: () => generateAPITests(endpoints),
    },
    {
      title: 'Next.js API Routes',
      description: 'Generate Next.js API route boilerplate',
      icon: <FileCode className="w-5 h-5 text-black" />,
      generate: () => generateNextJSAPIRoutes(endpoints, models, fields),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Code Generation</h2>
          <p className="text-muted-foreground mt-1">
            Generate production-ready code from your schema
          </p>
        </div>
        <div className="flex gap-2">
          <Badge variant="outline">{models.length} Models</Badge>
          <Badge variant="outline">{fields.length} Fields</Badge>
          <Badge variant="outline">{endpoints.length} Endpoints</Badge>
        </div>
      </div>

      <Tabs defaultValue="database" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="database">Database</TabsTrigger>
          <TabsTrigger value="api">API & SDK</TabsTrigger>
          <TabsTrigger value="frontend">Frontend</TabsTrigger>
          <TabsTrigger value="testing">Testing</TabsTrigger>
        </TabsList>

        <TabsContent value="database" className="space-y-4 mt-6">
          <div className="grid gap-4 md:grid-cols-2">
            {generators.slice(0, 3).map((gen: CodeGeneratorProps) => (
              <CodeGenerator key={gen.title} {...gen} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="api" className="space-y-4 mt-6">
          <div className="grid gap-4 md:grid-cols-2">
            {[generators[3], generators[5], generators[7]].map((gen: CodeGeneratorProps) => (
              <CodeGenerator key={gen.title} {...gen} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="frontend" className="space-y-4 mt-6">
          <div className="grid gap-4 md:grid-cols-2">
            <CodeGenerator {...generators[4]} />
          </div>
        </TabsContent>

        <TabsContent value="testing" className="space-y-4 mt-6">
          <div className="grid gap-4 md:grid-cols-2">
            <CodeGenerator {...generators[6]} />
          </div>
        </TabsContent>
      </Tabs>

      <Card className="bg-muted/50">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-blue-500/10 rounded">
              <Code2 className="w-5 h-5 text-blue-500" />
            </div>
            <div className="space-y-1">
              <h3 className="font-medium">Production-Ready Code</h3>
              <p className="text-sm text-muted-foreground">
                All generated code follows best practices and includes proper typing,
                error handling, and documentation. Ready to integrate into your project!
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
