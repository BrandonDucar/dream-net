'use client'

import React, { useState } from 'react'
import { useBackend } from '@/context/BackendContext'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import type { Endpoint, EndpointMethod, ModelStatus, RateSensitivity, UsageType } from '@/types/backend'

interface EndpointDetailProps {
  endpointId: string;
  onBack: () => void;
}

export function EndpointDetail({ endpointId, onBack }: EndpointDetailProps): JSX.Element {
  const {
    endpoints,
    models,
    miniApps,
    endpointUsages,
    updateEndpoint,
    deleteEndpoint,
    regenerateEndpointSEO,
    registerEndpointUsage,
    deleteEndpointUsage,
  } = useBackend();

  const endpoint = endpoints.find((e) => e.id === endpointId);
  const [editingEndpoint, setEditingEndpoint] = useState<Partial<Endpoint> | null>(null);
  const [isUsageOpen, setIsUsageOpen] = useState(false);

  const [newUsage, setNewUsage] = useState({
    miniAppId: '',
    usageType: 'read' as UsageType,
    notes: '',
  });

  if (!endpoint) {
    return (
      <Card>
        <CardContent className="py-8">
          <div className="text-center">
            <p className="text-muted-foreground">Endpoint not found</p>
            <Button onClick={onBack} className="mt-4">
              Go Back
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const usages = endpointUsages.filter((u) => u.endpointId === endpointId);
  const primaryModel = endpoint.primaryModelId ? models.find((m) => m.id === endpoint.primaryModelId) : null;

  const handleUpdateEndpoint = (): void => {
    if (editingEndpoint) {
      updateEndpoint(endpointId, editingEndpoint);
      setEditingEndpoint(null);
    }
  };

  const handleRegisterUsage = (): void => {
    if (newUsage.miniAppId) {
      registerEndpointUsage(endpointId, newUsage.miniAppId, newUsage.usageType, newUsage.notes);
      setNewUsage({ miniAppId: '', usageType: 'read', notes: '' });
      setIsUsageOpen(false);
    }
  };

  const methodColors: Record<EndpointMethod, string> = {
    GET: 'bg-blue-500',
    POST: 'bg-green-500',
    PUT: 'bg-yellow-500',
    PATCH: 'bg-orange-500',
    DELETE: 'bg-red-500',
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <Button variant="ghost" onClick={onBack} className="mb-2">
            ← Back to Endpoints
          </Button>
          <div className="flex items-center gap-3">
            <Badge className={`${methodColors[endpoint.method]} text-white`}>{endpoint.method}</Badge>
            <h2 className="text-2xl font-bold">{endpoint.name}</h2>
          </div>
          <p className="text-muted-foreground font-mono">{endpoint.path}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setEditingEndpoint(endpoint)}>
            Edit Endpoint
          </Button>
          <Button
            variant="destructive"
            onClick={() => {
              deleteEndpoint(endpointId);
              onBack();
            }}
          >
            Delete Endpoint
          </Button>
        </div>
      </div>

      <Tabs defaultValue="info" className="w-full">
        <TabsList>
          <TabsTrigger value="info">Endpoint Info</TabsTrigger>
          <TabsTrigger value="schemas">Schemas</TabsTrigger>
          <TabsTrigger value="seo">SEO</TabsTrigger>
          <TabsTrigger value="usage">Usage ({usages.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="info" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Endpoint Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Description</Label>
                <p className="text-sm">{endpoint.description}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Primary Model</Label>
                  <p className="text-sm">
                    {primaryModel ? <Badge variant="outline">{primaryModel.name}</Badge> : '-'}
                  </p>
                </div>
                <div>
                  <Label>Status</Label>
                  <p className="text-sm">
                    <Badge
                      variant={
                        endpoint.status === 'stable'
                          ? 'default'
                          : endpoint.status === 'draft'
                          ? 'secondary'
                          : 'destructive'
                      }
                    >
                      {endpoint.status}
                    </Badge>
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Authentication Required</Label>
                  <p className="text-sm">
                    {endpoint.authRequired ? (
                      <Badge variant="outline">Yes</Badge>
                    ) : (
                      <Badge variant="secondary">No</Badge>
                    )}
                  </p>
                </div>
                <div>
                  <Label>Auth Strategy</Label>
                  <p className="text-sm">{endpoint.authStrategy}</p>
                </div>
              </div>
              <div>
                <Label>Rate Sensitivity</Label>
                <p className="text-sm">
                  <Badge
                    variant={
                      endpoint.rateSensitivity === 'high'
                        ? 'destructive'
                        : endpoint.rateSensitivity === 'medium'
                        ? 'default'
                        : 'secondary'
                    }
                  >
                    {endpoint.rateSensitivity}
                  </Badge>
                </p>
              </div>
              <div>
                <Label>Tags</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {endpoint.tags.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No tags</p>
                  ) : (
                    endpoint.tags.map((tag, idx) => (
                      <Badge key={idx} variant="secondary">
                        {tag}
                      </Badge>
                    ))
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="schemas" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Request Schema</CardTitle>
            </CardHeader>
            <CardContent>
              {endpoint.requestSchema ? (
                <pre className="bg-muted p-4 rounded-lg overflow-x-auto text-sm">
                  {endpoint.requestSchema}
                </pre>
              ) : (
                <p className="text-sm text-muted-foreground">No request schema defined</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Response Schema</CardTitle>
            </CardHeader>
            <CardContent>
              {endpoint.responseSchema ? (
                <pre className="bg-muted p-4 rounded-lg overflow-x-auto text-sm">
                  {endpoint.responseSchema}
                </pre>
              ) : (
                <p className="text-sm text-muted-foreground">No response schema defined</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="seo" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>SEO Metadata</CardTitle>
              <Button onClick={() => regenerateEndpointSEO(endpointId)}>Regenerate SEO</Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>SEO Title</Label>
                <p className="text-sm">{endpoint.seoTitle}</p>
              </div>
              <div>
                <Label>SEO Description</Label>
                <p className="text-sm">{endpoint.seoDescription}</p>
              </div>
              <div>
                <Label>Keywords</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {endpoint.seoKeywords.map((kw, idx) => (
                    <Badge key={idx} variant="outline">
                      {kw}
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <Label>Hashtags</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {endpoint.seoHashtags.map((tag, idx) => (
                    <Badge key={idx} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <Label>Alt Text</Label>
                <p className="text-sm">{endpoint.altText}</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="usage" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Mini-App Usage</CardTitle>
              <Dialog open={isUsageOpen} onOpenChange={setIsUsageOpen}>
                <DialogTrigger asChild>
                  <Button>Register Usage</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Register Endpoint Usage</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div>
                      <Label htmlFor="miniApp">Mini App</Label>
                      <Select
                        value={newUsage.miniAppId}
                        onValueChange={(value) => setNewUsage({ ...newUsage, miniAppId: value })}
                      >
                        <SelectTrigger id="miniApp">
                          <SelectValue placeholder="Select a mini app" />
                        </SelectTrigger>
                        <SelectContent>
                          {miniApps.map((app) => (
                            <SelectItem key={app.id} value={app.id}>
                              {app.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="usageType">Usage Type</Label>
                      <Select
                        value={newUsage.usageType}
                        onValueChange={(value) => setNewUsage({ ...newUsage, usageType: value as UsageType })}
                      >
                        <SelectTrigger id="usageType">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="read">Read</SelectItem>
                          <SelectItem value="write">Write</SelectItem>
                          <SelectItem value="read-write">Read-Write</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="usageNotes">Notes</Label>
                      <Textarea
                        id="usageNotes"
                        value={newUsage.notes}
                        onChange={(e) => setNewUsage({ ...newUsage, notes: e.target.value })}
                        placeholder="Optional notes about how this mini app uses this endpoint"
                      />
                    </div>
                    <Button onClick={handleRegisterUsage} className="w-full">
                      Register Usage
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {usages.length === 0 ? (
                <p className="text-sm text-muted-foreground">No mini-apps registered yet</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Mini App</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Usage Type</TableHead>
                      <TableHead>Notes</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {usages.map((usage) => {
                      const app = miniApps.find((a) => a.id === usage.miniAppId);
                      return (
                        <TableRow key={usage.id}>
                          <TableCell className="font-medium">{app?.name || 'Unknown'}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{app?.role || '-'}</Badge>
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                usage.usageType === 'read-write'
                                  ? 'default'
                                  : usage.usageType === 'write'
                                  ? 'destructive'
                                  : 'secondary'
                              }
                            >
                              {usage.usageType}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm">{usage.notes || '-'}</TableCell>
                          <TableCell>
                            <Button variant="ghost" size="sm" onClick={() => deleteEndpointUsage(usage.id)}>
                              Remove
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Edit Dialog */}
      {editingEndpoint && (
        <Dialog open={!!editingEndpoint} onOpenChange={() => setEditingEndpoint(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit Endpoint</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4 max-h-[70vh] overflow-y-auto">
              <div>
                <Label htmlFor="editEndpointName">Name</Label>
                <Input
                  id="editEndpointName"
                  value={editingEndpoint.name || ''}
                  onChange={(e) => setEditingEndpoint({ ...editingEndpoint, name: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="editMethod">Method</Label>
                  <Select
                    value={editingEndpoint.method || 'GET'}
                    onValueChange={(value) =>
                      setEditingEndpoint({ ...editingEndpoint, method: value as EndpointMethod })
                    }
                  >
                    <SelectTrigger id="editMethod">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="GET">GET</SelectItem>
                      <SelectItem value="POST">POST</SelectItem>
                      <SelectItem value="PUT">PUT</SelectItem>
                      <SelectItem value="PATCH">PATCH</SelectItem>
                      <SelectItem value="DELETE">DELETE</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="editPath">Path</Label>
                  <Input
                    id="editPath"
                    value={editingEndpoint.path || ''}
                    onChange={(e) => setEditingEndpoint({ ...editingEndpoint, path: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="editEndpointDescription">Description</Label>
                <Textarea
                  id="editEndpointDescription"
                  value={editingEndpoint.description || ''}
                  onChange={(e) => setEditingEndpoint({ ...editingEndpoint, description: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="editRequestSchema">Request Schema</Label>
                <Textarea
                  id="editRequestSchema"
                  value={editingEndpoint.requestSchema || ''}
                  onChange={(e) => setEditingEndpoint({ ...editingEndpoint, requestSchema: e.target.value })}
                  placeholder="Describe the request body/params"
                />
              </div>
              <div>
                <Label htmlFor="editResponseSchema">Response Schema</Label>
                <Textarea
                  id="editResponseSchema"
                  value={editingEndpoint.responseSchema || ''}
                  onChange={(e) => setEditingEndpoint({ ...editingEndpoint, responseSchema: e.target.value })}
                  placeholder="Describe the response body"
                />
              </div>
              <div>
                <Label htmlFor="editStatus">Status</Label>
                <Select
                  value={editingEndpoint.status || 'draft'}
                  onValueChange={(value) => setEditingEndpoint({ ...editingEndpoint, status: value as ModelStatus })}
                >
                  <SelectTrigger id="editStatus">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="stable">Stable</SelectItem>
                    <SelectItem value="deprecated">Deprecated</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="editRateSensitivity">Rate Sensitivity</Label>
                <Select
                  value={editingEndpoint.rateSensitivity || 'medium'}
                  onValueChange={(value) =>
                    setEditingEndpoint({ ...editingEndpoint, rateSensitivity: value as RateSensitivity })
                  }
                >
                  <SelectTrigger id="editRateSensitivity">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="editAuthRequired">Authentication Required</Label>
                <Switch
                  id="editAuthRequired"
                  checked={editingEndpoint.authRequired || false}
                  onCheckedChange={(checked) => setEditingEndpoint({ ...editingEndpoint, authRequired: checked })}
                />
              </div>
              {editingEndpoint.authRequired && (
                <div>
                  <Label htmlFor="editAuthStrategy">Auth Strategy</Label>
                  <Input
                    id="editAuthStrategy"
                    value={editingEndpoint.authStrategy || ''}
                    onChange={(e) => setEditingEndpoint({ ...editingEndpoint, authStrategy: e.target.value })}
                  />
                </div>
              )}
              <Button onClick={handleUpdateEndpoint} className="w-full">
                Save Changes
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
