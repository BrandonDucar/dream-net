'use client'

import React, { useState } from 'react'
import { useBackend } from '@/context/BackendContext'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import type { EndpointMethod, ModelStatus, RateSensitivity } from '@/types/backend'

interface EndpointsOverviewProps {
  onSelectEndpoint: (endpointId: string) => void;
}

export function EndpointsOverview({ onSelectEndpoint }: EndpointsOverviewProps): JSX.Element {
  const { endpoints, models, createEndpoint, listEndpoints } = useBackend();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [methodFilter, setMethodFilter] = useState<EndpointMethod | ''>('');
  const [statusFilter, setStatusFilter] = useState<ModelStatus | ''>('');
  const [authFilter, setAuthFilter] = useState<boolean | ''>('');
  const [searchFilter, setSearchFilter] = useState<string>('');

  const [newEndpoint, setNewEndpoint] = useState({
    name: '',
    path: '',
    method: 'GET' as EndpointMethod,
    description: '',
    primaryModelId: '',
    authRequired: false,
    authStrategy: 'none',
    rateSensitivity: 'medium' as RateSensitivity,
  });

  const handleCreate = (): void => {
    if (newEndpoint.name && newEndpoint.path && newEndpoint.description) {
      createEndpoint(
        newEndpoint.name,
        newEndpoint.path,
        newEndpoint.method,
        newEndpoint.description,
        newEndpoint.primaryModelId || null,
        newEndpoint.authRequired,
        newEndpoint.authStrategy,
        newEndpoint.rateSensitivity
      );
      setNewEndpoint({
        name: '',
        path: '',
        method: 'GET',
        description: '',
        primaryModelId: '',
        authRequired: false,
        authStrategy: 'none',
        rateSensitivity: 'medium',
      });
      setIsCreateOpen(false);
    }
  };

  const filteredEndpoints = listEndpoints({
    method: methodFilter || undefined,
    status: statusFilter || undefined,
    authRequired: authFilter === '' ? undefined : authFilter,
    search: searchFilter || undefined,
  });

  const getModelName = (modelId: string | null): string => {
    if (!modelId) return '-';
    const model = models.find((m) => m.id === modelId);
    return model ? model.name : 'Unknown';
  };

  const methodColors: Record<EndpointMethod, string> = {
    GET: 'bg-blue-500',
    POST: 'bg-green-500',
    PUT: 'bg-yellow-500',
    PATCH: 'bg-orange-500',
    DELETE: 'bg-red-500',
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>API Endpoints</CardTitle>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button>Create Endpoint</Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Endpoint</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4 max-h-[70vh] overflow-y-auto">
              <div>
                <Label htmlFor="endpointName">Endpoint Name</Label>
                <Input
                  id="endpointName"
                  value={newEndpoint.name}
                  onChange={(e) => setNewEndpoint({ ...newEndpoint, name: e.target.value })}
                  placeholder="e.g., List CultureCoins"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="method">Method</Label>
                  <Select
                    value={newEndpoint.method}
                    onValueChange={(value) => setNewEndpoint({ ...newEndpoint, method: value as EndpointMethod })}
                  >
                    <SelectTrigger id="method">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="GET">GET</SelectItem>
                      <SelectItem value="POST">POST</SelectItem>
                      <SelectItem value="PUT">PUT</SelectItem>
                      <SelectItem value="PATCH">PATCH</SelectItem>
                      <SelectItem value="DELETE">DELETE</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="path">Path</Label>
                  <Input
                    id="path"
                    value={newEndpoint.path}
                    onChange={(e) => setNewEndpoint({ ...newEndpoint, path: e.target.value })}
                    placeholder="/v1/coins"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="endpointDescription">Description</Label>
                <Input
                  id="endpointDescription"
                  value={newEndpoint.description}
                  onChange={(e) => setNewEndpoint({ ...newEndpoint, description: e.target.value })}
                  placeholder="Describe what this endpoint does"
                />
              </div>
              <div>
                <Label htmlFor="primaryModel">Primary Model (Optional)</Label>
                <Select
                  value={newEndpoint.primaryModelId}
                  onValueChange={(value) => setNewEndpoint({ ...newEndpoint, primaryModelId: value })}
                >
                  <SelectTrigger id="primaryModel">
                    <SelectValue placeholder="Select a model" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {models.map((model) => (
                      <SelectItem key={model.id} value={model.id}>
                        {model.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="authRequired">Authentication Required</Label>
                <Switch
                  id="authRequired"
                  checked={newEndpoint.authRequired}
                  onCheckedChange={(checked) => setNewEndpoint({ ...newEndpoint, authRequired: checked })}
                />
              </div>
              {newEndpoint.authRequired && (
                <div>
                  <Label htmlFor="authStrategy">Auth Strategy</Label>
                  <Input
                    id="authStrategy"
                    value={newEndpoint.authStrategy}
                    onChange={(e) => setNewEndpoint({ ...newEndpoint, authStrategy: e.target.value })}
                    placeholder="e.g., Farcaster JWT, API key"
                  />
                </div>
              )}
              <div>
                <Label htmlFor="rateSensitivity">Rate Sensitivity</Label>
                <Select
                  value={newEndpoint.rateSensitivity}
                  onValueChange={(value) => setNewEndpoint({ ...newEndpoint, rateSensitivity: value as RateSensitivity })}
                >
                  <SelectTrigger id="rateSensitivity">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleCreate} className="w-full">
                Create Endpoint
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div>
              <Label htmlFor="searchEndpoint">Search</Label>
              <Input
                id="searchEndpoint"
                placeholder="Search endpoints..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="methodFilter">Method</Label>
              <Select value={methodFilter} onValueChange={(value) => setMethodFilter(value as EndpointMethod | '')}>
                <SelectTrigger id="methodFilter">
                  <SelectValue placeholder="All methods" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All methods</SelectItem>
                  <SelectItem value="GET">GET</SelectItem>
                  <SelectItem value="POST">POST</SelectItem>
                  <SelectItem value="PUT">PUT</SelectItem>
                  <SelectItem value="PATCH">PATCH</SelectItem>
                  <SelectItem value="DELETE">DELETE</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="statusFilterEndpoint">Status</Label>
              <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as ModelStatus | '')}>
                <SelectTrigger id="statusFilterEndpoint">
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="stable">Stable</SelectItem>
                  <SelectItem value="deprecated">Deprecated</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="authFilterEndpoint">Auth</Label>
              <Select value={authFilter.toString()} onValueChange={(value) => setAuthFilter(value === 'all' ? '' : value === 'true')}>
                <SelectTrigger id="authFilterEndpoint">
                  <SelectValue placeholder="All" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="true">Auth Required</SelectItem>
                  <SelectItem value="false">No Auth</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Table */}
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Method</TableHead>
                  <TableHead>Path</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Primary Model</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Auth</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEndpoints.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-foreground">
                      No endpoints found. Create your first API endpoint!
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredEndpoints.map((endpoint) => (
                    <TableRow key={endpoint.id}>
                      <TableCell>
                        <Badge className={`${methodColors[endpoint.method]} text-white`}>
                          {endpoint.method}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-sm">{endpoint.path}</TableCell>
                      <TableCell className="font-medium">{endpoint.name}</TableCell>
                      <TableCell>{getModelName(endpoint.primaryModelId)}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            endpoint.status === 'stable'
                              ? 'default'
                              : endpoint.status === 'draft'
                              ? 'secondary'
                              : 'destructive'
                          }
                        >
                          {endpoint.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {endpoint.authRequired ? (
                          <Badge variant="outline">Required</Badge>
                        ) : (
                          <Badge variant="secondary">None</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm" onClick={() => onSelectEndpoint(endpoint.id)}>
                          View Details
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
