'use client'

import React, { useState, useRef } from 'react';
import { useBackend } from '@/context/BackendContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import {
  Upload,
  Download,
  FileJson,
  FileCode,
  Database,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';
import {
  exportAsJSON,
  exportModelsAsCSV,
  exportFieldsAsCSV,
  exportEndpointsAsCSV,
  importFromJSON,
  importFromPrisma,
  importFromOpenAPI,
  importFromSQL,
} from '@/lib/import-export';
import type { BackendState } from '@/types/backend-enhanced';

export function ImportExportPanel(): JSX.Element {
  const backend = useBackend();
  const { models, fields, endpoints, miniApps, endpointUsages } = backend;
  const [importText, setImportText] = useState<string>('');
  const [importStatus, setImportStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Export functions
  const handleExportJSON = (): void => {
    const state: BackendState = {
      models,
      fields,
      endpoints,
      miniApps,
      endpointUsages,
      versions: [],
      comments: [],
      webhooks: [],
      graphqlTypes: [],
    };
    const json = exportAsJSON(state);
    downloadFile('dreamnet-backend.json', json, 'application/json');
    toast.success('Exported as JSON');
  };

  const handleExportModelsCSV = (): void => {
    const csv = exportModelsAsCSV(models);
    downloadFile('dreamnet-models.csv', csv, 'text/csv');
    toast.success('Exported models as CSV');
  };

  const handleExportFieldsCSV = (): void => {
    const csv = exportFieldsAsCSV(fields, models);
    downloadFile('dreamnet-fields.csv', csv, 'text/csv');
    toast.success('Exported fields as CSV');
  };

  const handleExportEndpointsCSV = (): void => {
    const csv = exportEndpointsAsCSV(endpoints, models);
    downloadFile('dreamnet-endpoints.csv', csv, 'text/csv');
    toast.success('Exported endpoints as CSV');
  };

  // Import functions
  const handleImportJSON = (): void => {
    try {
      const imported = importFromJSON(importText);
      if (!imported) {
        setImportStatus('error');
        toast.error('Failed to parse JSON');
        return;
      }

      // Merge imported data (simplified - in production, handle conflicts)
      imported.models.forEach((model) => {
        backend.createBackendModel(model.name, model.tableName, model.description, model.category);
      });

      setImportStatus('success');
      toast.success('Imported successfully!');
      setImportText('');
    } catch (error) {
      setImportStatus('error');
      toast.error('Import failed');
      console.error(error);
    }
  };

  const handleImportPrisma = (): void => {
    try {
      const imported = importFromPrisma(importText);
      if (!imported) {
        setImportStatus('error');
        toast.error('Failed to parse Prisma schema');
        return;
      }

      let importedCount = 0;
      imported.models.forEach((model) => {
        const newModel = backend.createBackendModel(
          model.name,
          model.tableName,
          model.description,
          model.category
        );
        
        imported.fields
          .filter((f) => f.modelId === model.id)
          .forEach((field) => {
            backend.addBackendField(
              newModel.id,
              field.name,
              field.type,
              field.isPrimaryKey,
              field.isNullable,
              field.isUnique,
              field.defaultValue,
              field.description,
              field.exampleValue
            );
          });
        
        importedCount++;
      });

      setImportStatus('success');
      toast.success(`Imported ${importedCount} models from Prisma schema`);
      setImportText('');
    } catch (error) {
      setImportStatus('error');
      toast.error('Import failed');
      console.error(error);
    }
  };

  const handleImportOpenAPI = (): void => {
    try {
      const imported = importFromOpenAPI(importText);
      if (!imported) {
        setImportStatus('error');
        toast.error('Failed to parse OpenAPI spec');
        return;
      }

      let importedCount = 0;
      imported.endpoints.forEach((endpoint) => {
        backend.createEndpoint(
          endpoint.name,
          endpoint.path,
          endpoint.method,
          endpoint.description,
          null,
          endpoint.authRequired,
          endpoint.authStrategy,
          endpoint.rateSensitivity
        );
        importedCount++;
      });

      setImportStatus('success');
      toast.success(`Imported ${importedCount} endpoints from OpenAPI spec`);
      setImportText('');
    } catch (error) {
      setImportStatus('error');
      toast.error('Import failed');
      console.error(error);
    }
  };

  const handleImportSQL = (): void => {
    try {
      const imported = importFromSQL(importText);
      if (!imported) {
        setImportStatus('error');
        toast.error('Failed to parse SQL DDL');
        return;
      }

      let importedCount = 0;
      imported.models.forEach((model) => {
        const newModel = backend.createBackendModel(
          model.name,
          model.tableName,
          model.description,
          model.category
        );
        
        imported.fields
          .filter((f) => f.modelId === model.id)
          .forEach((field) => {
            backend.addBackendField(
              newModel.id,
              field.name,
              field.type,
              field.isPrimaryKey,
              field.isNullable,
              field.isUnique,
              field.defaultValue,
              field.description,
              field.exampleValue
            );
          });
        
        importedCount++;
      });

      setImportStatus('success');
      toast.success(`Imported ${importedCount} models from SQL DDL`);
      setImportText('');
    } catch (error) {
      setImportStatus('error');
      toast.error('Import failed');
      console.error(error);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>): void => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e: ProgressEvent<FileReader>): void => {
      const text = e.target?.result as string;
      setImportText(text);
    };
    reader.readAsText(file);
  };

  const downloadFile = (filename: string, content: string, type: string): void => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Import & Export</h2>
        <p className="text-muted-foreground mt-1">
          Import from existing schemas or export your architecture
        </p>
      </div>

      <Tabs defaultValue="export" className="w-full">
        <TabsList>
          <TabsTrigger value="export">Export</TabsTrigger>
          <TabsTrigger value="import">Import</TabsTrigger>
        </TabsList>

        <TabsContent value="export" className="space-y-4 mt-6">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FileJson className="w-5 h-5 text-blue-500" />
                  <CardTitle>Full Export (JSON)</CardTitle>
                </div>
                <CardDescription>
                  Export complete backend architecture as JSON
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button onClick={handleExportJSON} className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Export JSON
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FileCode className="w-5 h-5 text-green-500" />
                  <CardTitle>Models (CSV)</CardTitle>
                </div>
                <CardDescription>
                  Export models as CSV spreadsheet
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button onClick={handleExportModelsCSV} className="w-full" variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export Models CSV
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FileCode className="w-5 h-5 text-purple-500" />
                  <CardTitle>Fields (CSV)</CardTitle>
                </div>
                <CardDescription>
                  Export all fields as CSV spreadsheet
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button onClick={handleExportFieldsCSV} className="w-full" variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export Fields CSV
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FileCode className="w-5 h-5 text-orange-500" />
                  <CardTitle>Endpoints (CSV)</CardTitle>
                </div>
                <CardDescription>
                  Export endpoints as CSV spreadsheet
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button onClick={handleExportEndpointsCSV} className="w-full" variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export Endpoints CSV
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="import" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Import from File or Paste</CardTitle>
              <CardDescription>
                Import schemas from various formats
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <input
                ref={fileInputRef}
                type="file"
                accept=".json,.prisma,.sql,.yaml,.yml"
                onChange={handleFileUpload}
                className="hidden"
              />
              
              <Button
                onClick={() => fileInputRef.current?.click()}
                variant="outline"
                className="w-full"
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload File
              </Button>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-background px-2 text-muted-foreground">
                    Or paste content
                  </span>
                </div>
              </div>

              <Textarea
                value={importText}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setImportText(e.target.value)}
                placeholder="Paste your schema here (JSON, Prisma, SQL DDL, or OpenAPI)..."
                className="font-mono text-xs min-h-[200px]"
              />

              {importStatus === 'success' && (
                <div className="flex items-center gap-2 text-green-500 text-sm">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Import successful!</span>
                </div>
              )}

              {importStatus === 'error' && (
                <div className="flex items-center gap-2 text-red-500 text-sm">
                  <AlertCircle className="w-4 h-4" />
                  <span>Import failed. Check the format and try again.</span>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <Button onClick={handleImportJSON} disabled={!importText}>
                  <FileJson className="w-4 h-4 mr-2" />
                  Import JSON
                </Button>
                <Button onClick={handleImportPrisma} variant="outline" disabled={!importText}>
                  <Database className="w-4 h-4 mr-2" />
                  Import Prisma
                </Button>
                <Button onClick={handleImportSQL} variant="outline" disabled={!importText}>
                  <Database className="w-4 h-4 mr-2" />
                  Import SQL
                </Button>
                <Button onClick={handleImportOpenAPI} variant="outline" disabled={!importText}>
                  <FileCode className="w-4 h-4 mr-2" />
                  Import OpenAPI
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-blue-500/5 border-blue-500/20">
            <CardContent className="pt-6">
              <div className="flex items-start gap-3">
                <FileJson className="w-5 h-5 text-blue-500 flex-shrink-0" />
                <div className="space-y-1">
                  <h3 className="font-medium">Supported Formats</h3>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• <strong>JSON:</strong> Full DreamNet export format</li>
                    <li>• <strong>Prisma:</strong> Prisma schema files (.prisma)</li>
                    <li>• <strong>SQL DDL:</strong> CREATE TABLE statements</li>
                    <li>• <strong>OpenAPI:</strong> OpenAPI 3.0 specs (JSON/YAML)</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="flex gap-3">
              <Badge variant="outline">{models.length} Models</Badge>
              <Badge variant="outline">{fields.length} Fields</Badge>
              <Badge variant="outline">{endpoints.length} Endpoints</Badge>
            </div>
            <p className="text-sm text-muted-foreground">
              Ready to export or import
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
