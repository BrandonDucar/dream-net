'use client'

import React, { useState } from 'react'
import { useBackend } from '@/context/BackendContext'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'

export function MiniAppsView(): JSX.Element {
  const {
    miniApps,
    models,
    registerMiniAppRef,
    updateMiniAppRef,
    deleteMiniAppRef,
    listEndpointUsageForMiniApp,
  } = useBackend();

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);

  const [newApp, setNewApp] = useState({
    name: '',
    role: '',
    notes: '',
  });

  const handleCreate = (): void => {
    if (newApp.name && newApp.role) {
      registerMiniAppRef(newApp.name, newApp.role, newApp.notes);
      setNewApp({ name: '', role: '', notes: '' });
      setIsCreateOpen(false);
    }
  };

  const selectedApp = selectedAppId ? miniApps.find((a) => a.id === selectedAppId) : null;
  const selectedAppUsages = selectedAppId ? listEndpointUsageForMiniApp(selectedAppId) : [];

  // Get unique models from usages
  const getUsedModels = (appId: string): string[] => {
    const usages = listEndpointUsageForMiniApp(appId);
    const modelIds = new Set<string>();
    usages.forEach((usage) => {
      if (usage.endpoint.primaryModelId) {
        modelIds.add(usage.endpoint.primaryModelId);
      }
    });
    return Array.from(modelIds);
  };

  const getModelName = (modelId: string): string => {
    const model = models.find((m) => m.id === modelId);
    return model ? model.name : 'Unknown';
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Mini-App Registry</CardTitle>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button>Register Mini-App</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Register New Mini-App</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div>
                  <Label htmlFor="appName">Mini-App Name</Label>
                  <Input
                    id="appName"
                    value={newApp.name}
                    onChange={(e) => setNewApp({ ...newApp, name: e.target.value })}
                    placeholder="e.g., CultureCoin Foundry"
                  />
                </div>
                <div>
                  <Label htmlFor="appRole">Role</Label>
                  <Input
                    id="appRole"
                    value={newApp.role}
                    onChange={(e) => setNewApp({ ...newApp, role: e.target.value })}
                    placeholder="e.g., generator, planner, analytics"
                  />
                </div>
                <div>
                  <Label htmlFor="appNotes">Notes (Optional)</Label>
                  <Textarea
                    id="appNotes"
                    value={newApp.notes}
                    onChange={(e) => setNewApp({ ...newApp, notes: e.target.value })}
                    placeholder="Additional notes about this mini-app"
                  />
                </div>
                <Button onClick={handleCreate} className="w-full">
                  Register Mini-App
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          {miniApps.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              No mini-apps registered yet. Register your first mini-app!
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Endpoints Used</TableHead>
                  <TableHead>Models Accessed</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {miniApps.map((app) => {
                  const usageCount = listEndpointUsageForMiniApp(app.id).length;
                  const usedModels = getUsedModels(app.id);
                  return (
                    <TableRow key={app.id} className={selectedAppId === app.id ? 'bg-muted' : ''}>
                      <TableCell className="font-medium">{app.name}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{app.role}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{usageCount}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="default">{usedModels.length}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedAppId(app.id === selectedAppId ? null : app.id)}
                          >
                            {app.id === selectedAppId ? 'Hide Details' : 'View Details'}
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => deleteMiniAppRef(app.id)}>
                            Delete
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {selectedApp && (
        <Card>
          <CardHeader>
            <CardTitle>
              {selectedApp.name} - Usage Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label>Role</Label>
              <p className="text-sm">
                <Badge variant="outline">{selectedApp.role}</Badge>
              </p>
            </div>

            {selectedApp.notes && (
              <div>
                <Label>Notes</Label>
                <p className="text-sm">{selectedApp.notes}</p>
              </div>
            )}

            <div>
              <Label>Endpoints Used</Label>
              {selectedAppUsages.length === 0 ? (
                <p className="text-sm text-muted-foreground mt-2">No endpoints registered yet</p>
              ) : (
                <div className="mt-2 border rounded-lg">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Method</TableHead>
                        <TableHead>Path</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Usage Type</TableHead>
                        <TableHead>Notes</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedAppUsages.map((usage) => (
                        <TableRow key={usage.id}>
                          <TableCell>
                            <Badge>{usage.endpoint.method}</Badge>
                          </TableCell>
                          <TableCell className="font-mono text-sm">{usage.endpoint.path}</TableCell>
                          <TableCell>{usage.endpoint.name}</TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                usage.usageType === 'read-write'
                                  ? 'default'
                                  : usage.usageType === 'write'
                                  ? 'destructive'
                                  : 'secondary'
                              }
                            >
                              {usage.usageType}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm">{usage.notes || '-'}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>

            <div>
              <Label>Models Accessed (via endpoints)</Label>
              {(() => {
                const usedModelIds = getUsedModels(selectedApp.id);
                if (usedModelIds.length === 0) {
                  return <p className="text-sm text-muted-foreground mt-2">No models accessed yet</p>;
                }
                return (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {usedModelIds.map((modelId) => (
                      <Badge key={modelId} variant="default">
                        {getModelName(modelId)}
                      </Badge>
                    ))}
                  </div>
                );
              })()}
            </div>

            <div>
              <Label>Summary</Label>
              <div className="text-sm space-y-1 mt-2">
                <p>
                  • <strong>Read operations:</strong>{' '}
                  {selectedAppUsages.filter((u) => u.usageType === 'read' || u.usageType === 'read-write').length}
                </p>
                <p>
                  • <strong>Write operations:</strong>{' '}
                  {selectedAppUsages.filter((u) => u.usageType === 'write' || u.usageType === 'read-write').length}
                </p>
                <p>
                  • <strong>Total endpoints:</strong> {selectedAppUsages.length}
                </p>
                <p>
                  • <strong>Models touched:</strong> {getUsedModels(selectedApp.id).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
