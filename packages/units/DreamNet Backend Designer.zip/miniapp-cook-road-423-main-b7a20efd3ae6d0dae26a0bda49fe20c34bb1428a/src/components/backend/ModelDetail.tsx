'use client'

import React, { useState } from 'react'
import { useBackend } from '@/context/BackendContext'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import type { BackendModel, GeoTarget, ModelStatus } from '@/types/backend'

interface ModelDetailProps {
  modelId: string;
  onBack: () => void;
}

export function ModelDetail({ modelId, onBack }: ModelDetailProps): JSX.Element {
  const {
    models,
    fields,
    endpoints,
    updateBackendModel,
    deleteBackendModel,
    addBackendField,
    updateBackendField,
    deleteBackendField,
    listFieldsForModel,
    listEndpoints,
    regenerateModelSEO,
    assignGeoTargetsToModel,
    generateGeoVariantsForModel,
  } = useBackend();

  const model = models.find((m) => m.id === modelId);
  const [isAddFieldOpen, setIsAddFieldOpen] = useState(false);
  const [isGeoOpen, setIsGeoOpen] = useState(false);
  const [editingModel, setEditingModel] = useState<Partial<BackendModel> | null>(null);

  const [newField, setNewField] = useState({
    name: '',
    type: 'string',
    isPrimaryKey: false,
    isNullable: true,
    isUnique: false,
    defaultValue: '',
    description: '',
    exampleValue: '',
  });

  const [newGeoTarget, setNewGeoTarget] = useState<GeoTarget>({
    id: '',
    region: '',
    country: '',
    cityOrMarket: '',
    language: '',
  });

  if (!model) {
    return (
      <Card>
        <CardContent className="py-8">
          <div className="text-center">
            <p className="text-muted-foreground">Model not found</p>
            <Button onClick={onBack} className="mt-4">
              Go Back
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const modelFields = listFieldsForModel(modelId);
  const relatedEndpoints = listEndpoints({ primaryModelId: modelId });

  const handleAddField = (): void => {
    if (newField.name && newField.type) {
      addBackendField(
        modelId,
        newField.name,
        newField.type,
        newField.isPrimaryKey,
        newField.isNullable,
        newField.isUnique,
        newField.defaultValue || null,
        newField.description,
        newField.exampleValue || null
      );
      setNewField({
        name: '',
        type: 'string',
        isPrimaryKey: false,
        isNullable: true,
        isUnique: false,
        defaultValue: '',
        description: '',
        exampleValue: '',
      });
      setIsAddFieldOpen(false);
    }
  };

  const handleUpdateModel = (): void => {
    if (editingModel) {
      updateBackendModel(modelId, editingModel);
      setEditingModel(null);
    }
  };

  const handleAddGeoTarget = (): void => {
    if (newGeoTarget.region && newGeoTarget.language) {
      const geoId = `${newGeoTarget.region.toLowerCase()}-${newGeoTarget.language}`;
      const updatedGeos = [...model.primaryGeoTargets, { ...newGeoTarget, id: geoId }];
      assignGeoTargetsToModel(modelId, updatedGeos);
      setNewGeoTarget({ id: '', region: '', country: '', cityOrMarket: '', language: '' });
    }
  };

  const handleGenerateGeoVariants = (): void => {
    generateGeoVariantsForModel(modelId);
    setIsGeoOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <Button variant="ghost" onClick={onBack} className="mb-2">
            ← Back to Models
          </Button>
          <h2 className="text-2xl font-bold">{model.name}</h2>
          <p className="text-muted-foreground">Table: {model.tableName}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setEditingModel(model)}>
            Edit Model
          </Button>
          <Button variant="destructive" onClick={() => { deleteBackendModel(modelId); onBack(); }}>
            Delete Model
          </Button>
        </div>
      </div>

      <Tabs defaultValue="info" className="w-full">
        <TabsList>
          <TabsTrigger value="info">Model Info</TabsTrigger>
          <TabsTrigger value="fields">Fields ({modelFields.length})</TabsTrigger>
          <TabsTrigger value="seo">SEO & Geo</TabsTrigger>
          <TabsTrigger value="endpoints">Related Endpoints ({relatedEndpoints.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="info" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Model Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Description</Label>
                <p className="text-sm">{model.description}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Category</Label>
                  <p className="text-sm">
                    <Badge variant="outline">{model.category}</Badge>
                  </p>
                </div>
                <div>
                  <Label>Status</Label>
                  <p className="text-sm">
                    <Badge
                      variant={
                        model.status === 'stable' ? 'default' : model.status === 'draft' ? 'secondary' : 'destructive'
                      }
                    >
                      {model.status}
                    </Badge>
                  </p>
                </div>
              </div>
              <div>
                <Label>Primary Key</Label>
                <p className="text-sm font-mono">{model.primaryKey}</p>
              </div>
              <div>
                <Label>Relationships</Label>
                {model.relationships.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No relationships defined</p>
                ) : (
                  <ul className="text-sm space-y-1">
                    {model.relationships.map((rel, idx) => (
                      <li key={idx} className="font-mono">
                        {rel}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              <div>
                <Label>Indexes</Label>
                {model.indexes.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No indexes defined</p>
                ) : (
                  <ul className="text-sm space-y-1">
                    {model.indexes.map((idx, i) => (
                      <li key={i} className="font-mono">
                        {idx}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              <div>
                <Label>Tags</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {model.tags.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No tags</p>
                  ) : (
                    model.tags.map((tag, idx) => (
                      <Badge key={idx} variant="secondary">
                        {tag}
                      </Badge>
                    ))
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fields" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Fields</CardTitle>
              <Dialog open={isAddFieldOpen} onOpenChange={setIsAddFieldOpen}>
                <DialogTrigger asChild>
                  <Button>Add Field</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New Field</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div>
                      <Label htmlFor="fieldName">Field Name</Label>
                      <Input
                        id="fieldName"
                        value={newField.name}
                        onChange={(e) => setNewField({ ...newField, name: e.target.value })}
                        placeholder="e.g., id, name, symbol"
                      />
                    </div>
                    <div>
                      <Label htmlFor="fieldType">Type</Label>
                      <Select value={newField.type} onValueChange={(value) => setNewField({ ...newField, type: value })}>
                        <SelectTrigger id="fieldType">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="string">string</SelectItem>
                          <SelectItem value="text">text</SelectItem>
                          <SelectItem value="int">int</SelectItem>
                          <SelectItem value="float">float</SelectItem>
                          <SelectItem value="boolean">boolean</SelectItem>
                          <SelectItem value="timestamp">timestamp</SelectItem>
                          <SelectItem value="json">json</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="fieldDescription">Description</Label>
                      <Input
                        id="fieldDescription"
                        value={newField.description}
                        onChange={(e) => setNewField({ ...newField, description: e.target.value })}
                        placeholder="Describe the field"
                      />
                    </div>
                    <div>
                      <Label htmlFor="exampleValue">Example Value</Label>
                      <Input
                        id="exampleValue"
                        value={newField.exampleValue}
                        onChange={(e) => setNewField({ ...newField, exampleValue: e.target.value })}
                        placeholder="e.g., 'abc-123'"
                      />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="isPrimaryKey">Primary Key</Label>
                        <Switch
                          id="isPrimaryKey"
                          checked={newField.isPrimaryKey}
                          onCheckedChange={(checked) => setNewField({ ...newField, isPrimaryKey: checked })}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="isNullable">Nullable</Label>
                        <Switch
                          id="isNullable"
                          checked={newField.isNullable}
                          onCheckedChange={(checked) => setNewField({ ...newField, isNullable: checked })}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="isUnique">Unique</Label>
                        <Switch
                          id="isUnique"
                          checked={newField.isUnique}
                          onCheckedChange={(checked) => setNewField({ ...newField, isUnique: checked })}
                        />
                      </div>
                    </div>
                    <Button onClick={handleAddField} className="w-full">
                      Add Field
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Flags</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Example</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {modelFields.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-muted-foreground">
                        No fields yet. Add your first field!
                      </TableCell>
                    </TableRow>
                  ) : (
                    modelFields.map((field) => (
                      <TableRow key={field.id}>
                        <TableCell className="font-mono">{field.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{field.type}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1 flex-wrap">
                            {field.isPrimaryKey && <Badge variant="default">PK</Badge>}
                            {field.isUnique && <Badge variant="secondary">UNIQUE</Badge>}
                            {!field.isNullable && <Badge variant="destructive">NOT NULL</Badge>}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm">{field.description || '-'}</TableCell>
                        <TableCell className="text-sm font-mono">{field.exampleValue || '-'}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" onClick={() => deleteBackendField(field.id)}>
                            Delete
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="seo" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>SEO Metadata</CardTitle>
              <Button onClick={() => regenerateModelSEO(modelId)}>Regenerate SEO</Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>SEO Title</Label>
                <p className="text-sm">{model.seoTitle}</p>
              </div>
              <div>
                <Label>SEO Description</Label>
                <p className="text-sm">{model.seoDescription}</p>
              </div>
              <div>
                <Label>Keywords</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {model.seoKeywords.map((kw, idx) => (
                    <Badge key={idx} variant="outline">
                      {kw}
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <Label>Hashtags</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {model.seoHashtags.map((tag, idx) => (
                    <Badge key={idx} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Geo Targeting</CardTitle>
              <Dialog open={isGeoOpen} onOpenChange={setIsGeoOpen}>
                <DialogTrigger asChild>
                  <Button>Add Geo Target</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Geo Target</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div>
                      <Label htmlFor="region">Region</Label>
                      <Input
                        id="region"
                        value={newGeoTarget.region}
                        onChange={(e) => setNewGeoTarget({ ...newGeoTarget, region: e.target.value })}
                        placeholder="e.g., US, LATAM, EU"
                      />
                    </div>
                    <div>
                      <Label htmlFor="country">Country (Optional)</Label>
                      <Input
                        id="country"
                        value={newGeoTarget.country}
                        onChange={(e) => setNewGeoTarget({ ...newGeoTarget, country: e.target.value })}
                        placeholder="e.g., US, BR"
                      />
                    </div>
                    <div>
                      <Label htmlFor="cityOrMarket">City/Market</Label>
                      <Input
                        id="cityOrMarket"
                        value={newGeoTarget.cityOrMarket}
                        onChange={(e) => setNewGeoTarget({ ...newGeoTarget, cityOrMarket: e.target.value })}
                        placeholder="e.g., Miami, Berlin"
                      />
                    </div>
                    <div>
                      <Label htmlFor="language">Language</Label>
                      <Input
                        id="language"
                        value={newGeoTarget.language}
                        onChange={(e) => setNewGeoTarget({ ...newGeoTarget, language: e.target.value })}
                        placeholder="e.g., en, es, pt-BR"
                      />
                    </div>
                    <Button onClick={handleAddGeoTarget} className="w-full">
                      Add Geo Target
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {model.primaryGeoTargets.length === 0 ? (
                <p className="text-sm text-muted-foreground">No geo targets defined</p>
              ) : (
                <div className="space-y-4">
                  <div className="flex flex-wrap gap-2">
                    {model.primaryGeoTargets.map((geo) => (
                      <Badge key={geo.id} variant="default">
                        {geo.region} - {geo.language}
                      </Badge>
                    ))}
                  </div>
                  <Button onClick={handleGenerateGeoVariants}>Generate Localized Variants</Button>
                  {Object.keys(model.modelIntroLocalized).length > 0 && (
                    <div className="space-y-2">
                      <Label>Localized Intros:</Label>
                      {Object.entries(model.modelIntroLocalized).map(([key, value]) => (
                        <div key={key} className="text-sm">
                          <strong>{key}:</strong> {value}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="endpoints" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Related Endpoints</CardTitle>
            </CardHeader>
            <CardContent>
              {relatedEndpoints.length === 0 ? (
                <p className="text-sm text-muted-foreground">No endpoints using this model</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Method</TableHead>
                      <TableHead>Path</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {relatedEndpoints.map((endpoint) => (
                      <TableRow key={endpoint.id}>
                        <TableCell>
                          <Badge>{endpoint.method}</Badge>
                        </TableCell>
                        <TableCell className="font-mono">{endpoint.path}</TableCell>
                        <TableCell>{endpoint.name}</TableCell>
                        <TableCell>
                          <Badge variant={endpoint.status === 'stable' ? 'default' : 'secondary'}>
                            {endpoint.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Edit Dialog */}
      {editingModel && (
        <Dialog open={!!editingModel} onOpenChange={() => setEditingModel(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit Model</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4 max-h-[70vh] overflow-y-auto">
              <div>
                <Label htmlFor="editName">Name</Label>
                <Input
                  id="editName"
                  value={editingModel.name || ''}
                  onChange={(e) => setEditingModel({ ...editingModel, name: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="editTableName">Table Name</Label>
                <Input
                  id="editTableName"
                  value={editingModel.tableName || ''}
                  onChange={(e) => setEditingModel({ ...editingModel, tableName: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="editDescription">Description</Label>
                <Textarea
                  id="editDescription"
                  value={editingModel.description || ''}
                  onChange={(e) => setEditingModel({ ...editingModel, description: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="editCategory">Category</Label>
                <Input
                  id="editCategory"
                  value={editingModel.category || ''}
                  onChange={(e) => setEditingModel({ ...editingModel, category: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="editStatus">Status</Label>
                <Select
                  value={editingModel.status || 'draft'}
                  onValueChange={(value) => setEditingModel({ ...editingModel, status: value as ModelStatus })}
                >
                  <SelectTrigger id="editStatus">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="stable">Stable</SelectItem>
                    <SelectItem value="deprecated">Deprecated</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleUpdateModel} className="w-full">
                Save Changes
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
