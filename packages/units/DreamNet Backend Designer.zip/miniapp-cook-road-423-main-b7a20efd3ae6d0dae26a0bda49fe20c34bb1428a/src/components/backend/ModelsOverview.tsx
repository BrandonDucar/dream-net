'use client'

import React, { useState } from 'react'
import { useBackend } from '@/context/BackendContext'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import type { ModelStatus } from '@/types/backend'

interface ModelsOverviewProps {
  onSelectModel: (modelId: string) => void;
}

export function ModelsOverview({ onSelectModel }: ModelsOverviewProps): JSX.Element {
  const { models, fields, createBackendModel, listModels } = useBackend();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<ModelStatus | ''>('');
  const [searchFilter, setSearchFilter] = useState<string>('');

  const [newModel, setNewModel] = useState({
    name: '',
    tableName: '',
    description: '',
    category: '',
  });

  const handleCreate = (): void => {
    if (newModel.name && newModel.tableName && newModel.description && newModel.category) {
      createBackendModel(newModel.name, newModel.tableName, newModel.description, newModel.category);
      setNewModel({ name: '', tableName: '', description: '', category: '' });
      setIsCreateOpen(false);
    }
  };

  const filteredModels = listModels({
    category: categoryFilter || undefined,
    status: statusFilter || undefined,
    search: searchFilter || undefined,
  });

  const getFieldCount = (modelId: string): number => {
    return fields.filter((f) => f.modelId === modelId).length;
  };

  const categories = [...new Set(models.map((m) => m.category))];

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Backend Models</CardTitle>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button>Create Backend Model</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Backend Model</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div>
                <Label htmlFor="name">Model Name</Label>
                <Input
                  id="name"
                  value={newModel.name}
                  onChange={(e) => setNewModel({ ...newModel, name: e.target.value })}
                  placeholder="e.g., CultureCoin"
                />
              </div>
              <div>
                <Label htmlFor="tableName">Table Name</Label>
                <Input
                  id="tableName"
                  value={newModel.tableName}
                  onChange={(e) => setNewModel({ ...newModel, tableName: e.target.value })}
                  placeholder="e.g., culture_coins"
                />
              </div>
              <div>
                <Label htmlFor="category">Category</Label>
                <Input
                  id="category"
                  value={newModel.category}
                  onChange={(e) => setNewModel({ ...newModel, category: e.target.value })}
                  placeholder="e.g., culture, distribution, social"
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Input
                  id="description"
                  value={newModel.description}
                  onChange={(e) => setNewModel({ ...newModel, description: e.target.value })}
                  placeholder="Describe the model's purpose"
                />
              </div>
              <Button onClick={handleCreate} className="w-full">
                Create Model
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <Label htmlFor="search">Search</Label>
              <Input
                id="search"
                placeholder="Search models..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="categoryFilter">Category</Label>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger id="categoryFilter">
                  <SelectValue placeholder="All categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All categories</SelectItem>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="statusFilter">Status</Label>
              <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as ModelStatus | '')}>
                <SelectTrigger id="statusFilter">
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="stable">Stable</SelectItem>
                  <SelectItem value="deprecated">Deprecated</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Table */}
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Table Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Fields</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredModels.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground">
                      No models found. Create your first backend model!
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredModels.map((model) => (
                    <TableRow key={model.id}>
                      <TableCell className="font-medium">{model.name}</TableCell>
                      <TableCell className="font-mono text-sm">{model.tableName}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{model.category}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            model.status === 'stable'
                              ? 'default'
                              : model.status === 'draft'
                              ? 'secondary'
                              : 'destructive'
                          }
                        >
                          {model.status}
                        </Badge>
                      </TableCell>
                      <TableCell>{getFieldCount(model.id)}</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm" onClick={() => onSelectModel(model.id)}>
                          View Details
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
