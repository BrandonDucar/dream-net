'use client'

import React, { useState } from 'react'
import { useBackend } from '@/context/BackendContext'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from 'sonner'

export function SpecsExport(): JSX.Element {
  const { generateSQLSchemaPreview, generateOpenAPIPreview, exportBackendSpec } = useBackend();

  const [sqlSchema, setSqlSchema] = useState<string>('');
  const [openApiSpec, setOpenApiSpec] = useState<string>('');
  const [backendSpec, setBackendSpec] = useState<string>('');

  const handleGenerateSQL = (): void => {
    const schema = generateSQLSchemaPreview();
    setSqlSchema(schema);
    toast.success('SQL schema generated');
  };

  const handleGenerateOpenAPI = (): void => {
    const spec = generateOpenAPIPreview();
    setOpenApiSpec(spec);
    toast.success('OpenAPI spec generated');
  };

  const handleExportBackendSpec = (): void => {
    const spec = exportBackendSpec();
    setBackendSpec(spec);
    toast.success('Full backend spec generated');
  };

  const handleCopy = (text: string, label: string): void => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard`);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Export & Generate Specs</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            Generate technical specifications from your backend architecture. Use these exports to hand off to
            developers or implement the backend yourself.
          </p>

          <Tabs defaultValue="sql" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="sql">SQL Schema</TabsTrigger>
              <TabsTrigger value="openapi">OpenAPI</TabsTrigger>
              <TabsTrigger value="full">Full Spec</TabsTrigger>
            </TabsList>

            <TabsContent value="sql" className="space-y-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>SQL Schema Preview</CardTitle>
                    <div className="flex gap-2">
                      <Button onClick={handleGenerateSQL}>Generate SQL</Button>
                      {sqlSchema && (
                        <Button variant="outline" onClick={() => handleCopy(sqlSchema, 'SQL schema')}>
                          Copy All
                        </Button>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {!sqlSchema ? (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      Click "Generate SQL" to create a SQL schema preview
                    </p>
                  ) : (
                    <Textarea
                      value={sqlSchema}
                      readOnly
                      className="font-mono text-sm min-h-[500px]"
                      placeholder="SQL schema will appear here..."
                    />
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="openapi" className="space-y-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>OpenAPI Preview</CardTitle>
                    <div className="flex gap-2">
                      <Button onClick={handleGenerateOpenAPI}>Generate OpenAPI</Button>
                      {openApiSpec && (
                        <Button variant="outline" onClick={() => handleCopy(openApiSpec, 'OpenAPI spec')}>
                          Copy All
                        </Button>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {!openApiSpec ? (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      Click "Generate OpenAPI" to create an API specification
                    </p>
                  ) : (
                    <Textarea
                      value={openApiSpec}
                      readOnly
                      className="font-mono text-sm min-h-[500px]"
                      placeholder="OpenAPI spec will appear here..."
                    />
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="full" className="space-y-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Full Backend Specification</CardTitle>
                    <div className="flex gap-2">
                      <Button onClick={handleExportBackendSpec}>Export Full Spec</Button>
                      {backendSpec && (
                        <Button variant="outline" onClick={() => handleCopy(backendSpec, 'Backend spec')}>
                          Copy All
                        </Button>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {!backendSpec ? (
                    <div className="text-sm text-muted-foreground text-center py-8 space-y-2">
                      <p>Click "Export Full Spec" to generate the complete DreamNet Backend Specification</p>
                      <p className="text-xs">
                        Includes: models, fields, relationships, endpoints, schemas, and mini-app usage mapping
                      </p>
                    </div>
                  ) : (
                    <Textarea
                      value={backendSpec}
                      readOnly
                      className="font-mono text-sm min-h-[500px]"
                      placeholder="Full backend spec will appear here..."
                    />
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Quick Export Tips</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <h4 className="font-medium text-sm">SQL Schema</h4>
            <p className="text-sm text-muted-foreground">
              PostgreSQL-compatible CREATE TABLE statements with constraints and indexes. Use this to initialize your
              database.
            </p>
          </div>
          <div>
            <h4 className="font-medium text-sm">OpenAPI Specification</h4>
            <p className="text-sm text-muted-foreground">
              JSON format API documentation. Import into tools like Swagger UI, Postman, or use for code generation.
            </p>
          </div>
          <div>
            <h4 className="font-medium text-sm">Full Backend Spec</h4>
            <p className="text-sm text-muted-foreground">
              Comprehensive Markdown documentation including models, endpoints, schemas, and mini-app usage. Perfect
              for handoff to developers or as implementation blueprint.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
