'use client'

import React, { useMemo } from 'react';
import { useBackend } from '@/context/BackendContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertTriangle,
  CheckCircle2,
  Info,
  XCircle,
  TrendingUp,
  Shield,
  DollarSign,
  Lightbulb
} from 'lucide-react';
import {
  validateSchema,
  generateSchemaRecommendations,
  performSecurityAudit,
  estimateDatabaseCosts
} from '@/lib/validation';
import type { ValidationIssue } from '@/types/backend-enhanced';

export function ValidationDashboard(): JSX.Element {
  const { models, fields, endpoints } = useBackend();

  const validationIssues = useMemo(
    () => validateSchema(models, fields, endpoints),
    [models, fields, endpoints]
  );

  const recommendations = useMemo(
    () => generateSchemaRecommendations(models, fields),
    [models, fields]
  );

  const securityIssues = useMemo(
    () => performSecurityAudit(endpoints),
    [endpoints]
  );

  const costEstimate = useMemo(
    () => estimateDatabaseCosts(models, fields),
    [models, fields]
  );

  const errors = validationIssues.filter((issue: ValidationIssue) => issue.severity === 'error');
  const warnings = validationIssues.filter((issue: ValidationIssue) => issue.severity === 'warning');
  const infos = validationIssues.filter((issue: ValidationIssue) => issue.severity === 'info');

  const getStatusColor = (): string => {
    if (errors.length > 0) return 'text-red-500';
    if (warnings.length > 0) return 'text-yellow-500';
    return 'text-green-500';
  };

  const getStatusText = (): string => {
    if (errors.length > 0) return 'Issues Found';
    if (warnings.length > 0) return 'Warnings';
    return 'All Good';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Schema Validation & Analysis</h2>
          <p className="text-muted-foreground mt-1">
            AI-powered validation, security audit, and cost estimation
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className={`flex items-center gap-2 ${getStatusColor()}`}>
            {errors.length === 0 ? (
              <CheckCircle2 className="w-5 h-5" />
            ) : (
              <XCircle className="w-5 h-5" />
            )}
            <span className="font-medium">{getStatusText()}</span>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Errors</p>
                <p className="text-2xl font-bold">{errors.length}</p>
              </div>
              <XCircle className="w-8 h-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Warnings</p>
                <p className="text-2xl font-bold">{warnings.length}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Info</p>
                <p className="text-2xl font-bold">{infos.length}</p>
              </div>
              <Info className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Security</p>
                <p className="text-2xl font-bold">{securityIssues.length}</p>
              </div>
              <Shield className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="validation" className="w-full">
        <TabsList>
          <TabsTrigger value="validation">Validation</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          <TabsTrigger value="costs">Cost Estimate</TabsTrigger>
        </TabsList>

        <TabsContent value="validation" className="space-y-4 mt-6">
          {validationIssues.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <CheckCircle2 className="w-12 h-12 text-green-500 mb-3" />
                  <h3 className="text-lg font-medium mb-2">Schema Looks Great!</h3>
                  <p className="text-sm text-muted-foreground">
                    No validation issues found. Your schema follows best practices.
                  </p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {validationIssues.map((issue: ValidationIssue, idx: number) => (
                <Card key={idx} className={
                  issue.severity === 'error' ? 'border-red-500/50' :
                  issue.severity === 'warning' ? 'border-yellow-500/50' :
                  'border-blue-500/50'
                }>
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-3">
                      <div className="flex-shrink-0">
                        {issue.severity === 'error' && <XCircle className="w-5 h-5 text-red-500" />}
                        {issue.severity === 'warning' && <AlertTriangle className="w-5 h-5 text-yellow-500" />}
                        {issue.severity === 'info' && <Info className="w-5 h-5 text-blue-500" />}
                      </div>
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2">
                          <Badge variant={
                            issue.severity === 'error' ? 'destructive' :
                            issue.severity === 'warning' ? 'default' : 'secondary'
                          }>
                            {issue.severity}
                          </Badge>
                          <span className="text-sm text-muted-foreground">{issue.entity}</span>
                        </div>
                        <p className="text-sm font-medium">{issue.message}</p>
                        {issue.suggestion && (
                          <p className="text-sm text-muted-foreground">
                            💡 {issue.suggestion}
                          </p>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="security" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Security Audit
              </CardTitle>
              <CardDescription>
                Automated security checks for your API endpoints
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {securityIssues.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <CheckCircle2 className="w-12 h-12 text-green-500 mb-3" />
                  <h3 className="text-lg font-medium mb-2">Security Looks Good!</h3>
                  <p className="text-sm text-muted-foreground">
                    No critical security issues found in your endpoints.
                  </p>
                </div>
              ) : (
                <>
                  {securityIssues.map((issue: ValidationIssue, idx: number) => (
                    <Card key={idx} className="border-red-500/50">
                      <CardContent className="pt-6">
                        <div className="flex items-start gap-3">
                          <Shield className="w-5 h-5 text-red-500 flex-shrink-0" />
                          <div className="flex-1 space-y-2">
                            <div className="flex items-center gap-2">
                              <Badge variant="destructive">{issue.severity}</Badge>
                            </div>
                            <p className="text-sm font-medium">{issue.message}</p>
                            {issue.suggestion && (
                              <p className="text-sm text-muted-foreground">
                                🔒 {issue.suggestion}
                              </p>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="w-5 h-5" />
                AI-Powered Recommendations
              </CardTitle>
              <CardDescription>
                Smart suggestions to improve your schema
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {recommendations.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <TrendingUp className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No recommendations at this time. Your schema looks well-structured!</p>
                </div>
              ) : (
                <>
                  {recommendations.map((rec: string, idx: number) => (
                    <div key={idx} className="flex items-start gap-3 p-3 rounded-lg bg-blue-500/5 border border-blue-500/20">
                      <Lightbulb className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
                      <p className="text-sm">{rec}</p>
                    </div>
                  ))}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="costs" className="space-y-4 mt-6">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  Estimated Costs
                </CardTitle>
                <CardDescription>
                  Monthly cost projections by provider
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 rounded-lg bg-purple-500/5 border border-purple-500/20">
                    <span className="font-medium">PostgreSQL</span>
                    <span className="text-lg font-bold">${costEstimate.monthlyCostUSD.postgresql.toFixed(2)}/mo</span>
                  </div>
                  <div className="flex justify-between items-center p-3 rounded-lg bg-blue-500/5 border border-blue-500/20">
                    <span className="font-medium">MySQL</span>
                    <span className="text-lg font-bold">${costEstimate.monthlyCostUSD.mysql.toFixed(2)}/mo</span>
                  </div>
                  <div className="flex justify-between items-center p-3 rounded-lg bg-green-500/5 border border-green-500/20">
                    <span className="font-medium">Supabase</span>
                    <span className="text-lg font-bold">${costEstimate.monthlyCostUSD.supabase.toFixed(2)}/mo</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Storage Estimate</CardTitle>
                <CardDescription>
                  Projected database size
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Estimated Rows</span>
                    <span className="font-medium">{costEstimate.estimatedRows.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Storage Size</span>
                    <span className="font-medium">{costEstimate.estimatedStorageGB} GB</span>
                  </div>
                </div>

                {costEstimate.recommendations.length > 0 && (
                  <div className="mt-4 space-y-2">
                    <h4 className="text-sm font-medium">Cost Recommendations:</h4>
                    {costEstimate.recommendations.map((rec: string, idx: number) => (
                      <p key={idx} className="text-sm text-muted-foreground">{rec}</p>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <Card className="bg-muted/50">
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground">
                <strong>Note:</strong> Cost estimates are approximate and based on assumed usage patterns.
                Actual costs will vary based on query volume, storage growth, and provider pricing.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
