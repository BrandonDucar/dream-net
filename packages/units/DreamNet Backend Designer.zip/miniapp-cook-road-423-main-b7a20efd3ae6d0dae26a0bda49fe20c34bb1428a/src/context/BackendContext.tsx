'use client'

import React, { createContext, useContext, useState, useEffect, type ReactNode } from 'react'
import type {
  MiniAppRef,
  BackendModel,
  BackendField,
  Endpoint,
  EndpointUsage,
  GeoTarget,
  BackendState,
  ModelStatus,
  EndpointMethod,
  UsageType,
  RateSensitivity,
} from '@/types/backend'

interface BackendContextType extends BackendState {
  // MiniApp functions
  registerMiniAppRef: (name: string, role: string, notes?: string) => MiniAppRef;
  updateMiniAppRef: (id: string, updates: Partial<MiniAppRef>) => void;
  deleteMiniAppRef: (id: string) => void;

  // Model functions
  createBackendModel: (name: string, tableName: string, description: string, category: string) => BackendModel;
  updateBackendModel: (id: string, updates: Partial<BackendModel>) => void;
  deleteBackendModel: (id: string) => void;
  assignGeoTargetsToModel: (modelId: string, geoTargets: GeoTarget[]) => void;
  generateGeoVariantsForModel: (modelId: string) => void;
  regenerateModelSEO: (modelId: string) => void;

  // Field functions
  addBackendField: (
    modelId: string,
    name: string,
    type: string,
    isPrimaryKey: boolean,
    isNullable: boolean,
    isUnique: boolean,
    defaultValue: string | null,
    description: string,
    exampleValue: string | null
  ) => BackendField;
  updateBackendField: (id: string, updates: Partial<BackendField>) => void;
  deleteBackendField: (id: string) => void;

  // Endpoint functions
  createEndpoint: (
    name: string,
    path: string,
    method: EndpointMethod,
    description: string,
    primaryModelId: string | null,
    authRequired: boolean,
    authStrategy: string,
    rateSensitivity: RateSensitivity
  ) => Endpoint;
  updateEndpoint: (id: string, updates: Partial<Endpoint>) => void;
  deleteEndpoint: (id: string) => void;
  regenerateEndpointSEO: (endpointId: string) => void;

  // Usage functions
  registerEndpointUsage: (endpointId: string, miniAppId: string, usageType: UsageType, notes: string) => EndpointUsage;
  deleteEndpointUsage: (id: string) => void;

  // Query functions
  listModels: (filters?: { category?: string; status?: ModelStatus; search?: string }) => BackendModel[];
  listFieldsForModel: (modelId: string) => BackendField[];
  listEndpoints: (filters?: { primaryModelId?: string; method?: EndpointMethod; status?: ModelStatus; authRequired?: boolean; search?: string }) => Endpoint[];
  listEndpointUsageForMiniApp: (miniAppId: string) => Array<EndpointUsage & { endpoint: Endpoint }>;

  // Generation functions
  generateSQLSchemaPreview: () => string;
  generateOpenAPIPreview: () => string;
  exportBackendSpec: () => string;
}

const BackendContext = createContext<BackendContextType | undefined>(undefined);

const generateId = (): string => {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
};

const generateSEO = (name: string, description: string, category?: string): {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
} => {
  const keywords = [
    ...name.toLowerCase().split(/\s+/),
    ...(category ? category.toLowerCase().split(/\s+/) : []),
    'backend', 'api', 'dreamnet'
  ].filter(Boolean);

  return {
    seoTitle: `${name} - DreamNet Backend`,
    seoDescription: description.substring(0, 160),
    seoKeywords: [...new Set(keywords)],
    seoHashtags: keywords.map((k: string) => `#${k}`),
    altText: `${name} schema diagram`
  };
};

export function BackendProvider({ children }: { children: ReactNode }): JSX.Element {
  const [state, setState] = useState<BackendState>({
    miniApps: [],
    models: [],
    fields: [],
    endpoints: [],
    endpointUsages: [],
  });

  // Load from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('dreamnet-backend-state');
    if (saved) {
      try {
        setState(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to load state:', e);
      }
    }
  }, []);

  // Save to localStorage on state change
  useEffect(() => {
    localStorage.setItem('dreamnet-backend-state', JSON.stringify(state));
  }, [state]);

  // MiniApp functions
  const registerMiniAppRef = (name: string, role: string, notes = ''): MiniAppRef => {
    const miniApp: MiniAppRef = {
      id: generateId(),
      name,
      role,
      notes,
    };
    setState((prev: BackendState) => ({ ...prev, miniApps: [...prev.miniApps, miniApp] }));
    return miniApp;
  };

  const updateMiniAppRef = (id: string, updates: Partial<MiniAppRef>): void => {
    setState((prev: BackendState) => ({
      ...prev,
      miniApps: prev.miniApps.map((app: MiniAppRef) => (app.id === id ? { ...app, ...updates } : app)),
    }));
  };

  const deleteMiniAppRef = (id: string): void => {
    setState((prev: BackendState) => ({
      ...prev,
      miniApps: prev.miniApps.filter((app: MiniAppRef) => app.id !== id),
      endpointUsages: prev.endpointUsages.filter((usage: EndpointUsage) => usage.miniAppId !== id),
    }));
  };

  // Model functions
  const createBackendModel = (name: string, tableName: string, description: string, category: string): BackendModel => {
    const seo = generateSEO(name, description, category);
    const model: BackendModel = {
      id: generateId(),
      name,
      tableName,
      description,
      category,
      primaryKey: 'id',
      relationships: [],
      indexes: [],
      tags: [],
      status: 'draft',
      primaryGeoTargets: [],
      modelIntroLocalized: {},
      tagsLocalized: {},
      ...seo,
    };
    setState((prev: BackendState) => ({ ...prev, models: [...prev.models, model] }));
    return model;
  };

  const updateBackendModel = (id: string, updates: Partial<BackendModel>): void => {
    setState((prev: BackendState) => ({
      ...prev,
      models: prev.models.map((model: BackendModel) => (model.id === id ? { ...model, ...updates } : model)),
    }));
  };

  const deleteBackendModel = (id: string): void => {
    setState((prev: BackendState) => ({
      ...prev,
      models: prev.models.filter((model: BackendModel) => model.id !== id),
      fields: prev.fields.filter((field: BackendField) => field.modelId !== id),
      endpoints: prev.endpoints.map((endpoint: Endpoint) =>
        endpoint.primaryModelId === id ? { ...endpoint, primaryModelId: null } : endpoint
      ),
    }));
  };

  const assignGeoTargetsToModel = (modelId: string, geoTargets: GeoTarget[]): void => {
    setState((prev: BackendState) => ({
      ...prev,
      models: prev.models.map((model: BackendModel) =>
        model.id === modelId ? { ...model, primaryGeoTargets: geoTargets } : model
      ),
    }));
  };

  const generateGeoVariantsForModel = (modelId: string): void => {
    setState((prev: BackendState) => ({
      ...prev,
      models: prev.models.map((model: BackendModel) => {
        if (model.id !== modelId) return model;

        const modelIntroLocalized: Record<string, string> = {};
        const tagsLocalized: Record<string, string[]> = {};

        model.primaryGeoTargets.forEach((geo: GeoTarget) => {
          const geoKey = geo.id;
          modelIntroLocalized[geoKey] = `${model.description} (localized for ${geo.region} - ${geo.language})`;
          tagsLocalized[geoKey] = [
            ...model.tags,
            geo.region.toLowerCase(),
            geo.language,
            geo.cityOrMarket.toLowerCase(),
          ].filter(Boolean);
        });

        return { ...model, modelIntroLocalized, tagsLocalized };
      }),
    }));
  };

  const regenerateModelSEO = (modelId: string): void => {
    setState((prev: BackendState) => ({
      ...prev,
      models: prev.models.map((model: BackendModel) => {
        if (model.id !== modelId) return model;
        const seo = generateSEO(model.name, model.description, model.category);
        return { ...model, ...seo };
      }),
    }));
  };

  // Field functions
  const addBackendField = (
    modelId: string,
    name: string,
    type: string,
    isPrimaryKey: boolean,
    isNullable: boolean,
    isUnique: boolean,
    defaultValue: string | null,
    description: string,
    exampleValue: string | null
  ): BackendField => {
    const field: BackendField = {
      id: generateId(),
      modelId,
      name,
      type,
      isPrimaryKey,
      isNullable,
      isUnique,
      defaultValue,
      description,
      exampleValue,
    };
    setState((prev: BackendState) => ({ ...prev, fields: [...prev.fields, field] }));
    return field;
  };

  const updateBackendField = (id: string, updates: Partial<BackendField>): void => {
    setState((prev: BackendState) => ({
      ...prev,
      fields: prev.fields.map((field: BackendField) => (field.id === id ? { ...field, ...updates } : field)),
    }));
  };

  const deleteBackendField = (id: string): void => {
    setState((prev: BackendState) => ({
      ...prev,
      fields: prev.fields.filter((field: BackendField) => field.id !== id),
    }));
  };

  // Endpoint functions
  const createEndpoint = (
    name: string,
    path: string,
    method: EndpointMethod,
    description: string,
    primaryModelId: string | null,
    authRequired: boolean,
    authStrategy: string,
    rateSensitivity: RateSensitivity
  ): Endpoint => {
    const seo = generateSEO(name, description);
    const endpoint: Endpoint = {
      id: generateId(),
      name,
      path,
      method,
      description,
      primaryModelId,
      requestSchema: '',
      responseSchema: '',
      authRequired,
      authStrategy,
      rateSensitivity,
      tags: [],
      status: 'draft',
      ...seo,
    };
    setState((prev: BackendState) => ({ ...prev, endpoints: [...prev.endpoints, endpoint] }));
    return endpoint;
  };

  const updateEndpoint = (id: string, updates: Partial<Endpoint>): void => {
    setState((prev: BackendState) => ({
      ...prev,
      endpoints: prev.endpoints.map((endpoint: Endpoint) => (endpoint.id === id ? { ...endpoint, ...updates } : endpoint)),
    }));
  };

  const deleteEndpoint = (id: string): void => {
    setState((prev: BackendState) => ({
      ...prev,
      endpoints: prev.endpoints.filter((endpoint: Endpoint) => endpoint.id !== id),
      endpointUsages: prev.endpointUsages.filter((usage: EndpointUsage) => usage.endpointId !== id),
    }));
  };

  const regenerateEndpointSEO = (endpointId: string): void => {
    setState((prev: BackendState) => ({
      ...prev,
      endpoints: prev.endpoints.map((endpoint: Endpoint) => {
        if (endpoint.id !== endpointId) return endpoint;
        const seo = generateSEO(endpoint.name, endpoint.description);
        return { ...endpoint, ...seo };
      }),
    }));
  };

  // Usage functions
  const registerEndpointUsage = (endpointId: string, miniAppId: string, usageType: UsageType, notes: string): EndpointUsage => {
    const usage: EndpointUsage = {
      id: generateId(),
      endpointId,
      miniAppId,
      usageType,
      notes,
    };
    setState((prev: BackendState) => ({ ...prev, endpointUsages: [...prev.endpointUsages, usage] }));
    return usage;
  };

  const deleteEndpointUsage = (id: string): void => {
    setState((prev: BackendState) => ({
      ...prev,
      endpointUsages: prev.endpointUsages.filter((usage: EndpointUsage) => usage.id !== id),
    }));
  };

  // Query functions
  const listModels = (filters?: { category?: string; status?: ModelStatus; search?: string }): BackendModel[] => {
    let result = state.models;

    if (filters?.category) {
      result = result.filter((m: BackendModel) => m.category === filters.category);
    }
    if (filters?.status) {
      result = result.filter((m: BackendModel) => m.status === filters.status);
    }
    if (filters?.search) {
      const search = filters.search.toLowerCase();
      result = result.filter((m: BackendModel) =>
        m.name.toLowerCase().includes(search) ||
        m.tableName.toLowerCase().includes(search) ||
        m.description.toLowerCase().includes(search)
      );
    }

    return result;
  };

  const listFieldsForModel = (modelId: string): BackendField[] => {
    return state.fields.filter((f: BackendField) => f.modelId === modelId);
  };

  const listEndpoints = (filters?: {
    primaryModelId?: string;
    method?: EndpointMethod;
    status?: ModelStatus;
    authRequired?: boolean;
    search?: string;
  }): Endpoint[] => {
    let result = state.endpoints;

    if (filters?.primaryModelId) {
      result = result.filter((e: Endpoint) => e.primaryModelId === filters.primaryModelId);
    }
    if (filters?.method) {
      result = result.filter((e: Endpoint) => e.method === filters.method);
    }
    if (filters?.status) {
      result = result.filter((e: Endpoint) => e.status === filters.status);
    }
    if (filters?.authRequired !== undefined) {
      result = result.filter((e: Endpoint) => e.authRequired === filters.authRequired);
    }
    if (filters?.search) {
      const search = filters.search.toLowerCase();
      result = result.filter((e: Endpoint) =>
        e.name.toLowerCase().includes(search) ||
        e.path.toLowerCase().includes(search) ||
        e.description.toLowerCase().includes(search)
      );
    }

    return result;
  };

  const listEndpointUsageForMiniApp = (miniAppId: string): Array<EndpointUsage & { endpoint: Endpoint }> => {
    return state.endpointUsages
      .filter((usage: EndpointUsage) => usage.miniAppId === miniAppId)
      .map((usage: EndpointUsage) => {
        const endpoint = state.endpoints.find((e: Endpoint) => e.id === usage.endpointId);
        return { ...usage, endpoint: endpoint! };
      })
      .filter((item: EndpointUsage & { endpoint: Endpoint }) => item.endpoint);
  };

  // Generation functions
  const generateSQLSchemaPreview = (): string => {
    let sql = '-- DreamNet Backend SQL Schema Preview\n';
    sql += '-- Generated: ' + new Date().toISOString() + '\n\n';

    state.models.forEach((model: BackendModel) => {
      sql += `-- Model: ${model.name} (${model.category})\n`;
      sql += `-- ${model.description}\n`;
      sql += `CREATE TABLE ${model.tableName} (\n`;

      const fields = state.fields.filter((f: BackendField) => f.modelId === model.id);
      fields.forEach((field: BackendField, idx: number) => {
        const sqlType = field.type.toUpperCase();
        const nullable = field.isNullable ? '' : ' NOT NULL';
        const unique = field.isUnique ? ' UNIQUE' : '';
        const defaultVal = field.defaultValue ? ` DEFAULT ${field.defaultValue}` : '';
        const comma = idx < fields.length - 1 ? ',' : '';

        sql += `  ${field.name} ${sqlType}${nullable}${unique}${defaultVal}${comma}`;
        if (field.description) {
          sql += ` -- ${field.description}`;
        }
        sql += '\n';
      });

      if (model.primaryKey) {
        sql += `,\n  PRIMARY KEY (${model.primaryKey})`;
      }

      sql += '\n);\n\n';

      // Indexes
      model.indexes.forEach((index: string) => {
        sql += `CREATE INDEX ${index} ON ${model.tableName};\n`;
      });

      sql += '\n';
    });

    return sql;
  };

  const generateOpenAPIPreview = (): string => {
    const spec = {
      openapi: '3.0.0',
      info: {
        title: 'DreamNet Backend API',
        version: '1.0.0',
        description: 'Auto-generated API specification for DreamNet shared backend',
      },
      servers: [{ url: 'https://api.dreamnet.example.com' }],
      paths: {} as Record<string, Record<string, unknown>>,
    };

    state.endpoints.forEach((endpoint: Endpoint) => {
      if (!spec.paths[endpoint.path]) {
        spec.paths[endpoint.path] = {};
      }

      const operation = {
        summary: endpoint.name,
        description: endpoint.description,
        tags: endpoint.tags,
        security: endpoint.authRequired ? [{ [endpoint.authStrategy]: [] }] : [],
        requestBody: endpoint.requestSchema ? {
          content: { 'application/json': { schema: { description: endpoint.requestSchema } } }
        } : undefined,
        responses: {
          '200': {
            description: 'Success',
            content: { 'application/json': { schema: { description: endpoint.responseSchema } } }
          }
        }
      };

      spec.paths[endpoint.path][endpoint.method.toLowerCase()] = operation;
    });

    return JSON.stringify(spec, null, 2);
  };

  const exportBackendSpec = (): string => {
    let spec = '# DreamNet Backend Specification v1\n\n';
    spec += `Generated: ${new Date().toISOString()}\n\n`;
    spec += '---\n\n';

    // Models
    spec += '## Backend Models\n\n';
    state.models.forEach((model: BackendModel) => {
      spec += `### ${model.name}\n`;
      spec += `- **Table:** ${model.tableName}\n`;
      spec += `- **Category:** ${model.category}\n`;
      spec += `- **Status:** ${model.status}\n`;
      spec += `- **Description:** ${model.description}\n`;
      spec += `- **Primary Key:** ${model.primaryKey}\n`;

      if (model.relationships.length > 0) {
        spec += `- **Relationships:**\n`;
        model.relationships.forEach((rel: string) => {
          spec += `  - ${rel}\n`;
        });
      }

      if (model.indexes.length > 0) {
        spec += `- **Indexes:** ${model.indexes.join(', ')}\n`;
      }

      spec += '\n**Fields:**\n\n';
      const fields = state.fields.filter((f: BackendField) => f.modelId === model.id);
      fields.forEach((field: BackendField) => {
        spec += `- \`${field.name}\` (${field.type})`;
        if (field.isPrimaryKey) spec += ' [PK]';
        if (field.isUnique) spec += ' [UNIQUE]';
        if (!field.isNullable) spec += ' [NOT NULL]';
        if (field.description) spec += ` - ${field.description}`;
        spec += '\n';
      });

      spec += '\n---\n\n';
    });

    // Endpoints
    spec += '## API Endpoints\n\n';
    state.endpoints.forEach((endpoint: Endpoint) => {
      spec += `### ${endpoint.method} ${endpoint.path}\n`;
      spec += `**Name:** ${endpoint.name}\n`;
      spec += `**Description:** ${endpoint.description}\n`;
      spec += `**Status:** ${endpoint.status}\n`;
      spec += `**Auth Required:** ${endpoint.authRequired ? `Yes (${endpoint.authStrategy})` : 'No'}\n`;
      spec += `**Rate Sensitivity:** ${endpoint.rateSensitivity}\n`;

      if (endpoint.primaryModelId) {
        const model = state.models.find((m: BackendModel) => m.id === endpoint.primaryModelId);
        if (model) {
          spec += `**Primary Model:** ${model.name}\n`;
        }
      }

      if (endpoint.requestSchema) {
        spec += `\n**Request Schema:**\n\`\`\`\n${endpoint.requestSchema}\n\`\`\`\n`;
      }

      if (endpoint.responseSchema) {
        spec += `\n**Response Schema:**\n\`\`\`\n${endpoint.responseSchema}\n\`\`\`\n`;
      }

      spec += '\n---\n\n';
    });

    // Mini-app usage
    spec += '## Mini-App Usage Mapping\n\n';
    state.miniApps.forEach((app: MiniAppRef) => {
      spec += `### ${app.name}\n`;
      spec += `- **Role:** ${app.role}\n`;
      if (app.notes) spec += `- **Notes:** ${app.notes}\n`;

      const usages = listEndpointUsageForMiniApp(app.id);
      if (usages.length > 0) {
        spec += '\n**Endpoints Used:**\n';
        usages.forEach((usage: EndpointUsage & { endpoint: Endpoint }) => {
          spec += `- ${usage.endpoint.method} ${usage.endpoint.path} (${usage.usageType})`;
          if (usage.notes) spec += ` - ${usage.notes}`;
          spec += '\n';
        });
      }

      spec += '\n';
    });

    return spec;
  };

  const value: BackendContextType = {
    ...state,
    registerMiniAppRef,
    updateMiniAppRef,
    deleteMiniAppRef,
    createBackendModel,
    updateBackendModel,
    deleteBackendModel,
    assignGeoTargetsToModel,
    generateGeoVariantsForModel,
    regenerateModelSEO,
    addBackendField,
    updateBackendField,
    deleteBackendField,
    createEndpoint,
    updateEndpoint,
    deleteEndpoint,
    regenerateEndpointSEO,
    registerEndpointUsage,
    deleteEndpointUsage,
    listModels,
    listFieldsForModel,
    listEndpoints,
    listEndpointUsageForMiniApp,
    generateSQLSchemaPreview,
    generateOpenAPIPreview,
    exportBackendSpec,
  };

  return <BackendContext.Provider value={value}>{children}</BackendContext.Provider>;
}

export function useBackend(): BackendContextType {
  const context = useContext(BackendContext);
  if (!context) {
    throw new Error('useBackend must be used within BackendProvider');
  }
  return context;
}
