// Import/Export utilities for DreamNet Backend Architect
import type { BackendModel, BackendField, Endpoint, BackendState } from '@/types/backend-enhanced';

// ============================================
// EXPORT FUNCTIONS
// ============================================

// Export as JSON (full state)
export function exportAsJSON(state: BackendState): string {
  return JSON.stringify(state, null, 2);
}

// Export as CSV (models)
export function exportModelsAsCSV(models: BackendModel[]): string {
  let csv = 'Name,TableName,Category,Status,Description,PrimaryKey,Relationships,Indexes\n';
  
  models.forEach((model: BackendModel) => {
    const row = [
      escapeCSV(model.name),
      escapeCSV(model.tableName),
      escapeCSV(model.category),
      escapeCSV(model.status),
      escapeCSV(model.description),
      escapeCSV(model.primaryKey),
      escapeCSV(model.relationships.join('; ')),
      escapeCSV(model.indexes.join('; ')),
    ];
    csv += row.join(',') + '\n';
  });
  
  return csv;
}

// Export fields as CSV
export function exportFieldsAsCSV(fields: BackendField[], models: BackendModel[]): string {
  let csv = 'Model,FieldName,Type,IsPrimaryKey,IsNullable,IsUnique,DefaultValue,Description,ExampleValue\n';
  
  fields.forEach((field: BackendField) => {
    const model = models.find((m: BackendModel) => m.id === field.modelId);
    const row = [
      escapeCSV(model?.name || 'Unknown'),
      escapeCSV(field.name),
      escapeCSV(field.type),
      field.isPrimaryKey ? 'Yes' : 'No',
      field.isNullable ? 'Yes' : 'No',
      field.isUnique ? 'Yes' : 'No',
      escapeCSV(field.defaultValue || ''),
      escapeCSV(field.description),
      escapeCSV(field.exampleValue || ''),
    ];
    csv += row.join(',') + '\n';
  });
  
  return csv;
}

// Export endpoints as CSV
export function exportEndpointsAsCSV(endpoints: Endpoint[], models: BackendModel[]): string {
  let csv = 'Name,Path,Method,Status,AuthRequired,AuthStrategy,PrimaryModel,Description\n';
  
  endpoints.forEach((endpoint: Endpoint) => {
    const model = endpoint.primaryModelId 
      ? models.find((m: BackendModel) => m.id === endpoint.primaryModelId)
      : null;
    
    const row = [
      escapeCSV(endpoint.name),
      escapeCSV(endpoint.path),
      escapeCSV(endpoint.method),
      escapeCSV(endpoint.status),
      endpoint.authRequired ? 'Yes' : 'No',
      escapeCSV(endpoint.authStrategy),
      escapeCSV(model?.name || 'N/A'),
      escapeCSV(endpoint.description),
    ];
    csv += row.join(',') + '\n';
  });
  
  return csv;
}

function escapeCSV(value: string): string {
  if (!value) return '""';
  const needsEscape = value.includes(',') || value.includes('"') || value.includes('\n');
  if (needsEscape) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

// ============================================
// IMPORT FUNCTIONS
// ============================================

// Import from JSON
export function importFromJSON(jsonString: string): BackendState | null {
  try {
    const state = JSON.parse(jsonString) as BackendState;
    
    // Validate structure
    if (!state.models || !state.fields || !state.endpoints) {
      throw new Error('Invalid JSON structure');
    }
    
    return state;
  } catch (error) {
    console.error('Failed to import JSON:', error);
    return null;
  }
}

// Import from Prisma schema
export function importFromPrisma(prismaSchema: string): {
  models: BackendModel[];
  fields: BackendField[];
} | null {
  try {
    const models: BackendModel[] = [];
    const fields: BackendField[] = [];

    // Simple parser - extract model blocks
    const modelRegex = /model\s+(\w+)\s*\{([^}]+)\}/g;
    let match;

    while ((match = modelRegex.exec(prismaSchema)) !== null) {
      const modelName = match[1];
      const modelBody = match[2];
      
      const modelId = generateId();
      const model: BackendModel = {
        id: modelId,
        name: modelName,
        tableName: modelName.toLowerCase() + 's',
        description: `Imported from Prisma: ${modelName}`,
        category: 'imported',
        primaryKey: 'id',
        relationships: [],
        indexes: [],
        tags: ['imported', 'prisma'],
        status: 'draft',
        primaryGeoTargets: [],
        modelIntroLocalized: {},
        tagsLocalized: {},
        seoTitle: `${modelName} - Imported`,
        seoDescription: `${modelName} model imported from Prisma schema`,
        seoKeywords: [modelName.toLowerCase(), 'prisma', 'model'],
        seoHashtags: ['#prisma', '#import'],
        altText: `${modelName} schema`,
      };
      models.push(model);

      // Parse fields
      const fieldLines = modelBody.split('\n').filter((line: string) => line.trim() && !line.trim().startsWith('//'));
      
      fieldLines.forEach((line: string) => {
        const fieldMatch = line.match(/^\s*(\w+)\s+(\w+)(\?)?/);
        if (fieldMatch) {
          const fieldName = fieldMatch[1];
          const fieldType = fieldMatch[2];
          const isNullable = !!fieldMatch[3];
          
          // Skip metadata fields
          if (fieldName.startsWith('@@') || fieldName.startsWith('@')) return;
          
          const field: BackendField = {
            id: generateId(),
            modelId,
            name: fieldName,
            type: mapPrismaType(fieldType),
            isPrimaryKey: line.includes('@id'),
            isNullable,
            isUnique: line.includes('@unique'),
            defaultValue: null,
            description: `Imported from Prisma`,
            exampleValue: null,
          };
          fields.push(field);
        }
      });
    }

    return { models, fields };
  } catch (error) {
    console.error('Failed to import Prisma schema:', error);
    return null;
  }
}

function mapPrismaType(prismaType: string): string {
  const typeMap: Record<string, string> = {
    'String': 'string',
    'Int': 'int',
    'Float': 'float',
    'Boolean': 'boolean',
    'DateTime': 'timestamp',
    'Json': 'json',
  };
  return typeMap[prismaType] || 'string';
}

// Import from OpenAPI/Swagger
export function importFromOpenAPI(openApiJSON: string): {
  endpoints: Endpoint[];
} | null {
  try {
    const spec = JSON.parse(openApiJSON);
    const endpoints: Endpoint[] = [];

    if (!spec.paths) {
      throw new Error('Invalid OpenAPI structure: missing paths');
    }

    Object.entries(spec.paths as Record<string, Record<string, unknown>>).forEach(([path, methods]) => {
      Object.entries(methods).forEach(([method, operation]: [string, unknown]) => {
        const op = operation as Record<string, unknown>;
        const endpointId = generateId();
        
        const endpoint: Endpoint = {
          id: endpointId,
          name: (op.summary as string) || `${method.toUpperCase()} ${path}`,
          path,
          method: method.toUpperCase() as 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE',
          description: (op.description as string) || '',
          primaryModelId: null,
          requestSchema: JSON.stringify(op.requestBody || {}, null, 2),
          responseSchema: JSON.stringify(op.responses || {}, null, 2),
          authRequired: !!(op.security && Array.isArray(op.security) && op.security.length > 0),
          authStrategy: 'bearer',
          rateSensitivity: 'medium',
          tags: (op.tags as string[]) || [],
          status: 'draft',
          seoTitle: `${method.toUpperCase()} ${path}`,
          seoDescription: (op.description as string) || '',
          seoKeywords: [method, 'api', 'endpoint'],
          seoHashtags: ['#api', '#openapi'],
          altText: `API endpoint ${path}`,
        };
        endpoints.push(endpoint);
      });
    });

    return { endpoints };
  } catch (error) {
    console.error('Failed to import OpenAPI:', error);
    return null;
  }
}

// Import from SQL DDL
export function importFromSQL(sqlDDL: string): {
  models: BackendModel[];
  fields: BackendField[];
} | null {
  try {
    const models: BackendModel[] = [];
    const fields: BackendField[] = [];

    // Simple parser - extract CREATE TABLE statements
    const tableRegex = /CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)\s*\(([^;]+)\);/gi;
    let match;

    while ((match = tableRegex.exec(sqlDDL)) !== null) {
      const tableName = match[1];
      const tableBody = match[2];
      
      const modelId = generateId();
      const model: BackendModel = {
        id: modelId,
        name: toPascalCase(tableName),
        tableName: tableName.toLowerCase(),
        description: `Imported from SQL: ${tableName}`,
        category: 'imported',
        primaryKey: 'id',
        relationships: [],
        indexes: [],
        tags: ['imported', 'sql'],
        status: 'draft',
        primaryGeoTargets: [],
        modelIntroLocalized: {},
        tagsLocalized: {},
        seoTitle: `${tableName} - Imported`,
        seoDescription: `${tableName} table imported from SQL DDL`,
        seoKeywords: [tableName.toLowerCase(), 'sql', 'table'],
        seoHashtags: ['#sql', '#import'],
        altText: `${tableName} schema`,
      };
      models.push(model);

      // Parse columns
      const columnLines = tableBody.split(',').map((line: string) => line.trim());
      
      columnLines.forEach((line: string) => {
        const columnMatch = line.match(/^\s*(\w+)\s+(\w+(?:\([^)]+\))?)/i);
        if (columnMatch && !line.toUpperCase().includes('PRIMARY KEY') && !line.toUpperCase().includes('CONSTRAINT')) {
          const columnName = columnMatch[1];
          const columnType = columnMatch[2];
          
          const field: BackendField = {
            id: generateId(),
            modelId,
            name: columnName,
            type: mapSQLType(columnType),
            isPrimaryKey: line.toUpperCase().includes('PRIMARY KEY'),
            isNullable: !line.toUpperCase().includes('NOT NULL'),
            isUnique: line.toUpperCase().includes('UNIQUE'),
            defaultValue: null,
            description: `Imported from SQL`,
            exampleValue: null,
          };
          fields.push(field);
        }
      });
    }

    return { models, fields };
  } catch (error) {
    console.error('Failed to import SQL:', error);
    return null;
  }
}

function mapSQLType(sqlType: string): string {
  const type = sqlType.toUpperCase().split('(')[0];
  const typeMap: Record<string, string> = {
    'VARCHAR': 'string',
    'CHAR': 'string',
    'TEXT': 'text',
    'INT': 'int',
    'INTEGER': 'int',
    'BIGINT': 'int',
    'FLOAT': 'float',
    'DOUBLE': 'float',
    'DECIMAL': 'decimal',
    'BOOLEAN': 'boolean',
    'BOOL': 'boolean',
    'TIMESTAMP': 'timestamp',
    'DATETIME': 'datetime',
    'DATE': 'date',
    'JSON': 'json',
    'JSONB': 'json',
    'UUID': 'uuid',
  };
  return typeMap[type] || 'string';
}

function toPascalCase(str: string): string {
  return str
    .split('_')
    .map((word: string) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join('');
}

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}
