// Validation and AI-powered recommendations for DreamNet
import type { BackendModel, BackendField, Endpoint, ValidationIssue } from '@/types/backend-enhanced';

export function validateSchema(
  models: BackendModel[],
  fields: BackendField[],
  endpoints: Endpoint[]
): ValidationIssue[] {
  const issues: ValidationIssue[] = [];

  // Validate models
  models.forEach((model: BackendModel) => {
    // Check for primary key
    const modelFields = fields.filter((f: BackendField) => f.modelId === model.id);
    const hasPrimaryKey = modelFields.some((f: BackendField) => f.isPrimaryKey);
    
    if (!hasPrimaryKey) {
      issues.push({
        severity: 'error',
        entity: 'model',
        entityId: model.id,
        message: `Model "${model.name}" has no primary key field`,
        suggestion: 'Add a field marked as primary key (usually "id")',
      });
    }

    // Check for createdAt/updatedAt timestamps
    const hasCreatedAt = modelFields.some((f: BackendField) => f.name.toLowerCase() === 'createdat');
    const hasUpdatedAt = modelFields.some((f: BackendField) => f.name.toLowerCase() === 'updatedat');
    
    if (!hasCreatedAt || !hasUpdatedAt) {
      issues.push({
        severity: 'warning',
        entity: 'model',
        entityId: model.id,
        message: `Model "${model.name}" missing timestamp fields`,
        suggestion: 'Add createdAt and updatedAt fields for audit trail',
      });
    }

    // Check for naming conventions
    if (model.tableName !== model.tableName.toLowerCase()) {
      issues.push({
        severity: 'info',
        entity: 'model',
        entityId: model.id,
        message: `Table name "${model.tableName}" contains uppercase characters`,
        suggestion: 'Use lowercase with underscores for table names (e.g., culture_coins)',
      });
    }

    // Check for indexes on foreign keys
    const relationshipFields = model.relationships
      .map((r: string) => {
        const match = r.match(/(\w+)\.\w+\s*→/);
        return match ? match[1] : null;
      })
      .filter(Boolean);
    
    relationshipFields.forEach((fieldName: string | null) => {
      if (fieldName && !model.indexes.includes(fieldName)) {
        issues.push({
          severity: 'warning',
          entity: 'model',
          entityId: model.id,
          message: `Foreign key "${fieldName}" in "${model.name}" is not indexed`,
          suggestion: `Add index on ${fieldName} for better query performance`,
        });
      }
    });
  });

  // Validate fields
  fields.forEach((field: BackendField) => {
    // Check for nullable primary keys
    if (field.isPrimaryKey && field.isNullable) {
      issues.push({
        severity: 'error',
        entity: 'field',
        entityId: field.id,
        message: `Primary key field "${field.name}" is nullable`,
        suggestion: 'Primary keys must be NOT NULL',
      });
    }

    // Check for description
    if (!field.description) {
      issues.push({
        severity: 'info',
        entity: 'field',
        entityId: field.id,
        message: `Field "${field.name}" has no description`,
        suggestion: 'Add descriptions to document your schema',
      });
    }

    // Check for example values
    if (!field.exampleValue && !field.isPrimaryKey) {
      issues.push({
        severity: 'info',
        entity: 'field',
        entityId: field.id,
        message: `Field "${field.name}" has no example value`,
        suggestion: 'Add example values for better documentation',
      });
    }
  });

  // Validate endpoints
  endpoints.forEach((endpoint: Endpoint) => {
    // Check for request/response schemas
    if (['POST', 'PUT', 'PATCH'].includes(endpoint.method) && !endpoint.requestSchema) {
      issues.push({
        severity: 'warning',
        entity: 'endpoint',
        entityId: endpoint.id,
        message: `${endpoint.method} endpoint "${endpoint.path}" has no request schema`,
        suggestion: 'Define the expected request body structure',
      });
    }

    if (!endpoint.responseSchema) {
      issues.push({
        severity: 'warning',
        entity: 'endpoint',
        entityId: endpoint.id,
        message: `Endpoint "${endpoint.path}" has no response schema`,
        suggestion: 'Define the expected response structure',
      });
    }

    // Check for auth on write operations
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(endpoint.method) && !endpoint.authRequired) {
      issues.push({
        severity: 'warning',
        entity: 'endpoint',
        entityId: endpoint.id,
        message: `${endpoint.method} endpoint "${endpoint.path}" has no authentication`,
        suggestion: 'Consider adding authentication for write operations',
      });
    }

    // Check path format
    if (!endpoint.path.startsWith('/')) {
      issues.push({
        severity: 'error',
        entity: 'endpoint',
        entityId: endpoint.id,
        message: `Endpoint path "${endpoint.path}" doesn't start with /`,
        suggestion: 'Paths must start with /',
      });
    }

    // Check for consistent path params
    const pathParams = endpoint.path.match(/\{([^}]+)\}/g);
    if (pathParams) {
      pathParams.forEach((param: string) => {
        const paramName = param.slice(1, -1);
        if (paramName !== paramName.toLowerCase()) {
          issues.push({
            severity: 'info',
            entity: 'endpoint',
            entityId: endpoint.id,
            message: `Path parameter ${param} uses mixed case`,
            suggestion: 'Use lowercase for consistency (e.g., {user_id})',
          });
        }
      });
    }
  });

  return issues;
}

// AI-powered schema suggestions
export function generateSchemaRecommendations(
  models: BackendModel[],
  fields: BackendField[]
): string[] {
  const recommendations: string[] = [];

  // Check for common patterns
  const hasUserModel = models.some((m: BackendModel) => 
    m.name.toLowerCase().includes('user') || m.name.toLowerCase().includes('account')
  );

  if (!hasUserModel) {
    recommendations.push('💡 Consider adding a User or Account model for authentication');
  }

  // Check for audit fields
  models.forEach((model: BackendModel) => {
    const modelFields = fields.filter((f: BackendField) => f.modelId === model.id);
    const fieldNames = modelFields.map((f: BackendField) => f.name.toLowerCase());

    if (!fieldNames.includes('createdat') || !fieldNames.includes('updatedat')) {
      recommendations.push(`💡 Add createdAt/updatedAt timestamps to "${model.name}" for audit trail`);
    }

    if (model.isWeb3Native && !fieldNames.some((n: string) => n.includes('address') || n.includes('wallet'))) {
      recommendations.push(`💡 Web3 model "${model.name}" should include wallet address field`);
    }
  });

  // Check for relationships
  if (models.length > 2) {
    const modelsWithRelationships = models.filter((m: BackendModel) => m.relationships.length > 0);
    if (modelsWithRelationships.length < models.length / 2) {
      recommendations.push('💡 Define relationships between your models for referential integrity');
    }
  }

  // Performance recommendations
  models.forEach((model: BackendModel) => {
    const modelFields = fields.filter((f: BackendField) => f.modelId === model.id);
    const textFields = modelFields.filter((f: BackendField) => f.type === 'text');
    
    if (textFields.length > 3) {
      recommendations.push(`💡 Model "${model.name}" has many text fields - consider full-text search indexes`);
    }
  });

  return recommendations;
}

// Check for security issues
export function performSecurityAudit(endpoints: Endpoint[]): ValidationIssue[] {
  const issues: ValidationIssue[] = [];

  endpoints.forEach((endpoint: Endpoint) => {
    // Check for sensitive operations without auth
    const isSensitive = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(endpoint.method);
    if (isSensitive && !endpoint.authRequired) {
      issues.push({
        severity: 'error',
        entity: 'endpoint',
        entityId: endpoint.id,
        message: `Sensitive endpoint "${endpoint.path}" has no authentication`,
        suggestion: 'Enable authentication for write operations',
      });
    }

    // Check for missing rate limiting on public endpoints
    if (!endpoint.authRequired && endpoint.rateSensitivity === 'low') {
      issues.push({
        severity: 'warning',
        entity: 'endpoint',
        entityId: endpoint.id,
        message: `Public endpoint "${endpoint.path}" has low rate sensitivity`,
        suggestion: 'Consider increasing rate limiting for public endpoints',
      });
    }

    // Check for proper HTTP methods
    const pathLower = endpoint.path.toLowerCase();
    if (pathLower.includes('delete') && endpoint.method !== 'DELETE') {
      issues.push({
        severity: 'warning',
        entity: 'endpoint',
        entityId: endpoint.id,
        message: `Endpoint "${endpoint.path}" suggests DELETE but uses ${endpoint.method}`,
        suggestion: 'Use appropriate HTTP methods for RESTful design',
      });
    }
  });

  return issues;
}

// Estimate database size and costs
export function estimateDatabaseCosts(models: BackendModel[], fields: BackendField[]): {
  estimatedRows: number;
  estimatedStorageGB: number;
  monthlyCostUSD: { postgresql: number; mysql: number; supabase: number };
  recommendations: string[];
} {
  let totalRows = 0;
  let totalSizeBytes = 0;

  models.forEach((model: BackendModel) => {
    const modelFields = fields.filter((f: BackendField) => f.modelId === model.id);
    
    // Rough estimation: assume 1000 rows per model as baseline
    const estimatedModelRows = 1000;
    totalRows += estimatedModelRows;

    // Estimate row size
    let rowSizeBytes = 0;
    modelFields.forEach((field: BackendField) => {
      rowSizeBytes += estimateFieldSize(field.type);
    });

    totalSizeBytes += rowSizeBytes * estimatedModelRows;
  });

  const storageGB = totalSizeBytes / (1024 ** 3);

  // Rough cost estimates (simplified)
  const costs = {
    postgresql: storageGB * 0.10 + 20, // $0.10/GB + $20 base
    mysql: storageGB * 0.08 + 15, // $0.08/GB + $15 base
    supabase: storageGB * 0.125 + 25, // $0.125/GB + $25 base
  };

  const recommendations: string[] = [];
  if (storageGB > 10) {
    recommendations.push('💰 Consider database sharding for large datasets');
  }
  if (models.length > 20) {
    recommendations.push('💰 Review schema normalization to reduce redundancy');
  }

  return {
    estimatedRows: totalRows,
    estimatedStorageGB: parseFloat(storageGB.toFixed(2)),
    monthlyCostUSD: costs,
    recommendations,
  };
}

function estimateFieldSize(type: string): number {
  const sizeMap: Record<string, number> = {
    'string': 255,
    'text': 1000,
    'int': 4,
    'integer': 4,
    'float': 8,
    'decimal': 8,
    'boolean': 1,
    'timestamp': 8,
    'json': 500,
    'uuid': 36,
    'address': 42,
    'hash': 66,
  };
  return sizeMap[type.toLowerCase()] || 100;
}
