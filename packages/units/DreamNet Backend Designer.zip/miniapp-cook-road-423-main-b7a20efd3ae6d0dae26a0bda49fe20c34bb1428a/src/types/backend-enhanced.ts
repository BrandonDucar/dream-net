// Enhanced types for DreamNet Backend Architect v2.0
export type ModelStatus = "draft" | "stable" | "deprecated";
export type EndpointMethod = "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
export type UsageType = "read" | "write" | "read-write";
export type RateSensitivity = "low" | "medium" | "high";

// Web3/Blockchain native types
export type BlockchainFieldType = "address" | "hash" | "signature" | "tokenId" | "chainId";
export type DataProvider = "postgresql" | "mysql" | "mongodb" | "supabase" | "planetscale";

// Version control
export interface SchemaVersion {
  id: string;
  timestamp: number;
  author: string;
  message: string;
  snapshot: string; // JSON snapshot of entire state
  changes: ChangeRecord[];
}

export interface ChangeRecord {
  type: "create" | "update" | "delete";
  entity: "model" | "field" | "endpoint" | "usage";
  entityId: string;
  entityName: string;
  diff: string;
}

// Comments & Collaboration
export interface Comment {
  id: string;
  entityType: "model" | "field" | "endpoint";
  entityId: string;
  author: string;
  text: string;
  timestamp: number;
  resolved: boolean;
}

// Webhooks & Events
export interface Webhook {
  id: string;
  name: string;
  url: string;
  events: string[]; // e.g., ["user.created", "order.updated"]
  description: string;
  authHeader: string;
  status: ModelStatus;
}

// GraphQL support
export interface GraphQLType {
  id: string;
  name: string;
  description: string;
  fields: GraphQLField[];
  modelId: string | null;
}

export interface GraphQLField {
  name: string;
  type: string;
  nullable: boolean;
  description: string;
}

// Validation & Recommendations
export interface ValidationIssue {
  severity: "error" | "warning" | "info";
  entity: string;
  entityId: string;
  message: string;
  suggestion?: string;
}

// Cost estimation
export interface CostEstimate {
  provider: DataProvider;
  monthlyEstimate: number;
  currency: string;
  breakdown: {
    storage: number;
    compute: number;
    requests: number;
  };
  assumptions: string[];
}

// Enhanced existing types
export interface MiniAppRef {
  id: string;
  name: string;
  role: string;
  notes: string;
  repository?: string;
  liveUrl?: string;
}

export interface GeoTarget {
  id: string;
  region: string;
  country: string;
  cityOrMarket: string;
  language: string;
}

export interface SEOMeta {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export interface BackendModel extends SEOMeta {
  id: string;
  name: string;
  tableName: string;
  description: string;
  category: string;
  primaryKey: string;
  relationships: string[];
  indexes: string[];
  tags: string[];
  status: ModelStatus;
  primaryGeoTargets: GeoTarget[];
  modelIntroLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
  // New fields
  position?: { x: number; y: number }; // For ERD canvas
  isWeb3Native?: boolean;
  template?: string; // e.g., "erc20", "nft", "user"
}

export interface BackendField {
  id: string;
  modelId: string;
  name: string;
  type: string;
  isPrimaryKey: boolean;
  isNullable: boolean;
  isUnique: boolean;
  defaultValue: string | null;
  description: string;
  exampleValue: string | null;
  // New fields
  isBlockchainType?: boolean;
  blockchainType?: BlockchainFieldType;
  validationRules?: string[];
  isIndexed?: boolean;
}

export interface Endpoint extends SEOMeta {
  id: string;
  name: string;
  path: string;
  method: EndpointMethod;
  description: string;
  primaryModelId: string | null;
  requestSchema: string;
  responseSchema: string;
  authRequired: boolean;
  authStrategy: string;
  rateSensitivity: RateSensitivity;
  tags: string[];
  status: ModelStatus;
  // New fields
  isWeb3Auth?: boolean; // Farcaster, WalletConnect, etc.
  mockResponse?: string;
  testCases?: TestCase[];
}

export interface TestCase {
  name: string;
  request: string;
  expectedResponse: string;
  expectedStatus: number;
}

export interface EndpointUsage {
  id: string;
  endpointId: string;
  miniAppId: string;
  usageType: UsageType;
  notes: string;
}

export interface BackendState {
  miniApps: MiniAppRef[];
  models: BackendModel[];
  fields: BackendField[];
  endpoints: Endpoint[];
  endpointUsages: EndpointUsage[];
  // New state
  versions: SchemaVersion[];
  comments: Comment[];
  webhooks: Webhook[];
  graphqlTypes: GraphQLType[];
}
