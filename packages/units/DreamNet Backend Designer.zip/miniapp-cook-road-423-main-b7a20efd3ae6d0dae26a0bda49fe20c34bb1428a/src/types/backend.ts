export type ModelStatus = "draft" | "stable" | "deprecated";
export type EndpointMethod = "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
export type UsageType = "read" | "write" | "read-write";
export type RateSensitivity = "low" | "medium" | "high";

export interface MiniAppRef {
  id: string;
  name: string;
  role: string;
  notes: string;
}

export interface GeoTarget {
  id: string;
  region: string;
  country: string;
  cityOrMarket: string;
  language: string;
}

export interface SEOMeta {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export interface BackendModel extends SEOMeta {
  id: string;
  name: string;
  tableName: string;
  description: string;
  category: string;
  primaryKey: string;
  relationships: string[];
  indexes: string[];
  tags: string[];
  status: ModelStatus;
  primaryGeoTargets: GeoTarget[];
  modelIntroLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
}

export interface BackendField {
  id: string;
  modelId: string;
  name: string;
  type: string;
  isPrimaryKey: boolean;
  isNullable: boolean;
  isUnique: boolean;
  defaultValue: string | null;
  description: string;
  exampleValue: string | null;
}

export interface Endpoint extends SEOMeta {
  id: string;
  name: string;
  path: string;
  method: EndpointMethod;
  description: string;
  primaryModelId: string | null;
  requestSchema: string;
  responseSchema: string;
  authRequired: boolean;
  authStrategy: string;
  rateSensitivity: RateSensitivity;
  tags: string[];
  status: ModelStatus;
}

export interface EndpointUsage {
  id: string;
  endpointId: string;
  miniAppId: string;
  usageType: UsageType;
  notes: string;
}

export interface BackendState {
  miniApps: MiniAppRef[];
  models: BackendModel[];
  fields: BackendField[];
  endpoints: Endpoint[];
  endpointUsages: EndpointUsage[];
}
