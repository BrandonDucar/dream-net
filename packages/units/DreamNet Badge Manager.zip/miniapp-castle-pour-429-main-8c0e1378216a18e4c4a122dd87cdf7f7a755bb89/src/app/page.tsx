'use client'
import { useState, useEffect } from 'react';
import { SubjectDashboard } from '@/components/dreamnet/subject-dashboard';
import { SubjectDetail } from '@/components/dreamnet/subject-detail';
import { BadgeTypeCatalog } from '@/components/dreamnet/badge-type-catalog';
import { BadgeTypeDetail } from '@/components/dreamnet/badge-type-detail';
import { CreateSubjectDialog } from '@/components/dreamnet/create-subject-dialog';
import { CreateBadgeTypeDialog } from '@/components/dreamnet/create-badge-type-dialog';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type View = 
  | { type: 'dashboard' }
  | { type: 'subject-detail'; subjectId: string }
  | { type: 'badge-catalog' }
  | { type: 'badge-detail'; badgeTypeId: string };

export default function DreamNetPage() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [view, setView] = useState<View>({ type: 'dashboard' });
  const [showCreateSubject, setShowCreateSubject] = useState<boolean>(false);
  const [showCreateBadgeType, setShowCreateBadgeType] = useState<boolean>(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {view.type === 'dashboard' && (
          <SubjectDashboard
            onSelectSubject={(subjectId: string) => setView({ type: 'subject-detail', subjectId })}
            onCreateSubject={() => setShowCreateSubject(true)}
            onViewBadgeTypes={() => setView({ type: 'badge-catalog' })}
          />
        )}

        {view.type === 'subject-detail' && (
          <SubjectDetail
            subjectId={view.subjectId}
            onBack={() => setView({ type: 'dashboard' })}
          />
        )}

        {view.type === 'badge-catalog' && (
          <BadgeTypeCatalog
            onBack={() => setView({ type: 'dashboard' })}
            onCreateBadgeType={() => setShowCreateBadgeType(true)}
            onSelectBadgeType={(badgeTypeId: string) => setView({ type: 'badge-detail', badgeTypeId })}
          />
        )}

        {view.type === 'badge-detail' && (
          <BadgeTypeDetail
            badgeTypeId={view.badgeTypeId}
            onBack={() => setView({ type: 'badge-catalog' })}
          />
        )}

        {showCreateSubject && (
          <CreateSubjectDialog
            onClose={() => setShowCreateSubject(false)}
            onCreate={() => {
              setShowCreateSubject(false);
              setView({ type: 'dashboard' });
            }}
          />
        )}

        {showCreateBadgeType && (
          <CreateBadgeTypeDialog
            onClose={() => setShowCreateBadgeType(false)}
            onCreate={() => {
              setShowCreateBadgeType(false);
              setView({ type: 'badge-catalog' });
            }}
          />
        )}
      </div>
    </div>
  );
}
