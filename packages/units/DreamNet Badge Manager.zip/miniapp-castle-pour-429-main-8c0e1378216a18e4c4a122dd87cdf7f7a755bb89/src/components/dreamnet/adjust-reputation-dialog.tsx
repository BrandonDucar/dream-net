'use client';

import { useState } from 'react';
import { adjustReputation } from '@/lib/dreamnet-store';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

interface AdjustReputationDialogProps {
  subjectId: string;
  onClose: () => void;
  onAdjust: () => void;
}

export function AdjustReputationDialog({ subjectId, onClose, onAdjust }: AdjustReputationDialogProps) {
  const [activityBonus, setActivityBonus] = useState<number>(0);
  const [penalty, setPenalty] = useState<number>(0);
  const [reason, setReason] = useState<string>('');

  const handleSubmit = () => {
    adjustReputation(subjectId, activityBonus, penalty, reason);
    onAdjust();
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Adjust Reputation</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div>
            <Label htmlFor="activityBonus">Activity Bonus (positive number)</Label>
            <Input
              id="activityBonus"
              type="number"
              value={activityBonus}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setActivityBonus(Number(e.target.value))}
              placeholder="e.g., 5"
            />
            <p className="text-xs text-gray-500 mt-1">Add points for positive activity or contributions</p>
          </div>

          <div>
            <Label htmlFor="penalty">Penalty (positive number)</Label>
            <Input
              id="penalty"
              type="number"
              value={penalty}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPenalty(Number(e.target.value))}
              placeholder="e.g., 3"
            />
            <p className="text-xs text-gray-500 mt-1">Add penalty points for negative behavior (subtracts from total)</p>
          </div>

          <div>
            <Label htmlFor="reason">Reason *</Label>
            <Textarea
              id="reason"
              value={reason}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setReason(e.target.value)}
              placeholder="Explain why this adjustment is being made"
              rows={3}
            />
          </div>

          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-sm">
            <p className="font-semibold mb-1">Reputation Calculation:</p>
            <p className="text-gray-700">
              Total Score = Base Score + Badge Bonus + Activity Bonus - Penalty
            </p>
            <p className="text-xs text-gray-600 mt-2">
              Levels: Shadow (&lt;0), Newcomer (0-9), Contributor (10-24), Trusted (25-49), Guardian (50+)
            </p>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!reason}>
            Apply Adjustment
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
