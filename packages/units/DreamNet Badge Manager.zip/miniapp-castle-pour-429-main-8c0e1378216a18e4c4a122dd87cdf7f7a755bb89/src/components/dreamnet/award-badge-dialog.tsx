'use client';

import { useState, useEffect } from 'react';
import type { BadgeType, SubjectType } from '@/types/dreamnet';
import { listBadgeTypes, awardBadge } from '@/lib/dreamnet-store';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent } from '@/components/ui/card';

interface AwardBadgeDialogProps {
  subjectId: string;
  subjectType: SubjectType;
  onClose: () => void;
  onAward: () => void;
}

export function AwardBadgeDialog({ subjectId, subjectType, onClose, onAward }: AwardBadgeDialogProps) {
  const [badgeTypes, setBadgeTypes] = useState<BadgeType[]>([]);
  const [selectedBadgeTypeId, setSelectedBadgeTypeId] = useState<string>('');
  const [reason, setReason] = useState<string>('');

  useEffect(() => {
    const allBadgeTypes = listBadgeTypes();
    const applicable = allBadgeTypes.filter((bt: BadgeType) =>
      bt.applicableSubjectTypes.includes(subjectType) && bt.status === 'active'
    );
    setBadgeTypes(applicable);
  }, [subjectType]);

  const handleSubmit = () => {
    if (!selectedBadgeTypeId) return;

    awardBadge(subjectId, selectedBadgeTypeId, reason);
    onAward();
  };

  const tierColors: Record<string, string> = {
    common: 'bg-gray-500',
    rare: 'bg-blue-500',
    legendary: 'bg-purple-500',
    mythic: 'bg-red-500',
    system: 'bg-green-500',
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>Award Badge</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div>
            <Label>Select Badge Type</Label>
            <ScrollArea className="h-[300px] mt-2 border rounded-lg p-2">
              {badgeTypes.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <p>No applicable badge types found for this subject type.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {badgeTypes.map((badgeType: BadgeType) => (
                    <Card
                      key={badgeType.id}
                      className={`cursor-pointer transition-colors ${
                        selectedBadgeTypeId === badgeType.id ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
                      }`}
                      onClick={() => setSelectedBadgeTypeId(badgeType.id)}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-start gap-3">
                          <span className="text-3xl">{badgeType.iconEmoji}</span>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-semibold">{badgeType.name}</h4>
                              <Badge className={`${tierColors[badgeType.tier]} text-white text-xs`}>
                                {badgeType.tier}
                              </Badge>
                            </div>
                            <div className="text-sm text-gray-600">{badgeType.description}</div>
                            <div className="text-xs text-gray-500 mt-1">
                              Criteria: {badgeType.criteriaDescription}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </ScrollArea>
          </div>

          <div>
            <Label htmlFor="reason">Reason (Optional)</Label>
            <Textarea
              id="reason"
              value={reason}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setReason(e.target.value)}
              placeholder="Why is this badge being awarded?"
              rows={3}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!selectedBadgeTypeId}>
            Award Badge
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
