'use client';

import { useState, useEffect } from 'react';
import type { BadgeType, BadgeTier, BadgeScope, BadgeStatus } from '@/types/dreamnet';
import { listBadgeTypes, exportBadgeCatalog } from '@/lib/dreamnet-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ArrowLeft, Plus, Trophy, FileDown } from 'lucide-react';
import { ExportBriefDialog } from './export-brief-dialog';

interface BadgeTypeCatalogProps {
  onBack: () => void;
  onCreateBadgeType: () => void;
  onSelectBadgeType: (badgeTypeId: string) => void;
}

export function BadgeTypeCatalog({ onBack, onCreateBadgeType, onSelectBadgeType }: BadgeTypeCatalogProps) {
  const [badgeTypes, setBadgeTypes] = useState<BadgeType[]>([]);
  const [filteredBadgeTypes, setFilteredBadgeTypes] = useState<BadgeType[]>([]);
  const [tierFilter, setTierFilter] = useState<string>('all');
  const [scopeFilter, setScopeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showExportCatalog, setShowExportCatalog] = useState<boolean>(false);
  const [exportedCatalog, setExportedCatalog] = useState<string>('');

  const loadBadgeTypes = () => {
    const data = listBadgeTypes();
    setBadgeTypes(data);
    setFilteredBadgeTypes(data);
  };

  useEffect(() => {
    loadBadgeTypes();

    const handleStorageChange = () => {
      loadBadgeTypes();
    };

    window.addEventListener('dreamnet-update', handleStorageChange);
    return () => window.removeEventListener('dreamnet-update', handleStorageChange);
  }, []);

  useEffect(() => {
    let filtered = [...badgeTypes];

    if (tierFilter !== 'all') {
      filtered = filtered.filter((bt: BadgeType) => bt.tier === tierFilter);
    }

    if (scopeFilter !== 'all') {
      filtered = filtered.filter((bt: BadgeType) => bt.scope === scopeFilter);
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter((bt: BadgeType) => bt.status === statusFilter);
    }

    setFilteredBadgeTypes(filtered);
  }, [badgeTypes, tierFilter, scopeFilter, statusFilter]);

  const handleExportCatalog = () => {
    const catalog = exportBadgeCatalog();
    setExportedCatalog(catalog);
    setShowExportCatalog(true);
  };

  const tierColors: Record<string, string> = {
    common: 'bg-gray-500',
    rare: 'bg-blue-500',
    legendary: 'bg-purple-500',
    mythic: 'bg-red-500',
    system: 'bg-green-500',
  };

  const statusColors: Record<string, string> = {
    draft: 'bg-gray-400',
    active: 'bg-green-500',
    deprecated: 'bg-red-400',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleExportCatalog}>
            <FileDown className="w-4 h-4 mr-2" />
            Export Catalog
          </Button>
          <Button onClick={onCreateBadgeType}>
            <Plus className="w-4 h-4 mr-2" />
            Create Badge Type
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="w-6 h-6 text-yellow-500" />
            Badge Type Catalog ({filteredBadgeTypes.length})
          </CardTitle>
          <div className="flex flex-wrap gap-2 mt-4">
            <Select value={tierFilter} onValueChange={setTierFilter}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Filter by tier" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tiers</SelectItem>
                <SelectItem value="common">Common</SelectItem>
                <SelectItem value="rare">Rare</SelectItem>
                <SelectItem value="legendary">Legendary</SelectItem>
                <SelectItem value="mythic">Mythic</SelectItem>
                <SelectItem value="system">System</SelectItem>
              </SelectContent>
            </Select>

            <Select value={scopeFilter} onValueChange={setScopeFilter}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Filter by scope" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Scopes</SelectItem>
                <SelectItem value="global">Global</SelectItem>
                <SelectItem value="project">Project</SelectItem>
                <SelectItem value="local">Local</SelectItem>
              </SelectContent>
            </Select>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="deprecated">Deprecated</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[600px]">
            {filteredBadgeTypes.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <Trophy className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No badge types found. Create your first badge type to get started!</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredBadgeTypes.map((badgeType: BadgeType) => (
                  <Card
                    key={badgeType.id}
                    className="cursor-pointer hover:bg-gray-50 transition-colors"
                    onClick={() => onSelectBadgeType(badgeType.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <span className="text-4xl">{badgeType.iconEmoji}</span>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-semibold text-lg">{badgeType.name}</h3>
                            <Badge className={`${tierColors[badgeType.tier]} text-white text-xs`}>
                              {badgeType.tier}
                            </Badge>
                          </div>
                          <div className="text-sm space-y-1">
                            <div className="text-gray-600 font-mono text-xs">[{badgeType.code}]</div>
                            <div className="text-gray-700 line-clamp-2">{badgeType.description}</div>
                            <div className="flex gap-2 mt-2">
                              <Badge variant="outline" className="text-xs">
                                {badgeType.scope}
                              </Badge>
                              <Badge className={`${statusColors[badgeType.status]} text-white text-xs`}>
                                {badgeType.status}
                              </Badge>
                            </div>
                            {badgeType.applicableSubjectTypes.length > 0 && (
                              <div className="text-xs text-gray-500 mt-2">
                                Applies to: {badgeType.applicableSubjectTypes.slice(0, 3).join(', ')}
                                {badgeType.applicableSubjectTypes.length > 3 && '...'}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {showExportCatalog && (
        <ExportBriefDialog
          brief={exportedCatalog}
          subjectName="Badge Catalog"
          onClose={() => setShowExportCatalog(false)}
        />
      )}
    </div>
  );
}
