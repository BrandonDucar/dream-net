'use client';

import { useState, useEffect } from 'react';
import type { BadgeType, GeoTarget } from '@/types/dreamnet';
import { listBadgeTypes, updateBadgeType, regenerateBadgeSEO, assignGeoTargetsToBadgeType, generateGeoVariantsForBadgeType } from '@/lib/dreamnet-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ArrowLeft, Edit2, Save, RefreshCw, Globe } from 'lucide-react';
import type { BadgeTier, BadgeScope, BadgeStatus, SubjectType } from '@/types/dreamnet';

interface BadgeTypeDetailProps {
  badgeTypeId: string;
  onBack: () => void;
}

export function BadgeTypeDetail({ badgeTypeId, onBack }: BadgeTypeDetailProps) {
  const [badgeType, setBadgeType] = useState<BadgeType | null>(null);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editForm, setEditForm] = useState<Partial<BadgeType>>({});

  const loadBadgeType = () => {
    const badgeTypes = listBadgeTypes();
    const found = badgeTypes.find((bt: BadgeType) => bt.id === badgeTypeId);
    if (found) {
      setBadgeType(found);
      setEditForm(found);
    }
  };

  useEffect(() => {
    loadBadgeType();
  }, [badgeTypeId]);

  const handleSave = () => {
    if (badgeType && editForm) {
      updateBadgeType(badgeType.id, editForm);
      loadBadgeType();
      setIsEditing(false);
      window.dispatchEvent(new Event('dreamnet-update'));
    }
  };

  const handleRegenerateSEO = () => {
    if (badgeType) {
      regenerateBadgeSEO(badgeType.id);
      loadBadgeType();
      window.dispatchEvent(new Event('dreamnet-update'));
    }
  };

  const handleGenerateGeoVariants = () => {
    if (badgeType) {
      generateGeoVariantsForBadgeType(badgeType.id);
      loadBadgeType();
      window.dispatchEvent(new Event('dreamnet-update'));
    }
  };

  if (!badgeType) {
    return (
      <div className="flex items-center justify-center h-96">
        <p className="text-gray-500">Badge type not found</p>
      </div>
    );
  }

  const tierColors: Record<string, string> = {
    common: 'bg-gray-500',
    rare: 'bg-blue-500',
    legendary: 'bg-purple-500',
    mythic: 'bg-red-500',
    system: 'bg-green-500',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Catalog
        </Button>
        {!isEditing ? (
          <Button variant="outline" onClick={() => setIsEditing(true)}>
            <Edit2 className="w-4 h-4 mr-2" />
            Edit
          </Button>
        ) : (
          <Button onClick={handleSave}>
            <Save className="w-4 h-4 mr-2" />
            Save Changes
          </Button>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Badge Type Details</CardTitle>
        </CardHeader>
        <CardContent>
          {!isEditing ? (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <span className="text-5xl">{badgeType.iconEmoji}</span>
                <div>
                  <h2 className="text-3xl font-bold">{badgeType.name}</h2>
                  <div className="flex gap-2 mt-2">
                    <Badge className={`${tierColors[badgeType.tier]} text-white`}>{badgeType.tier}</Badge>
                    <Badge variant="outline">{badgeType.scope}</Badge>
                    <Badge variant="outline">{badgeType.status}</Badge>
                  </div>
                </div>
              </div>
              <Separator />
              <div>
                <div className="text-sm text-gray-600">Code</div>
                <div className="font-mono">{badgeType.code}</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Description</div>
                <div>{badgeType.description}</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Criteria / How to Earn</div>
                <div>{badgeType.criteriaDescription}</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Applicable Subject Types</div>
                <div className="flex flex-wrap gap-2 mt-1">
                  {badgeType.applicableSubjectTypes.map((type: SubjectType) => (
                    <Badge key={type} variant="secondary">
                      {type}
                    </Badge>
                  ))}
                </div>
              </div>
              {badgeType.tags.length > 0 && (
                <div>
                  <div className="text-sm text-gray-600">Tags</div>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {badgeType.tags.map((tag: string) => (
                      <Badge key={tag} variant="outline">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Badge Name</Label>
                  <Input
                    value={editForm.name || ''}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, name: e.target.value })}
                  />
                </div>
                <div>
                  <Label>Code</Label>
                  <Input
                    value={editForm.code || ''}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, code: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <Label>Icon Emoji</Label>
                <Input
                  value={editForm.iconEmoji || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, iconEmoji: e.target.value })}
                />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea
                  value={editForm.description || ''}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setEditForm({ ...editForm, description: e.target.value })}
                  rows={2}
                />
              </div>
              <div>
                <Label>Criteria Description</Label>
                <Textarea
                  value={editForm.criteriaDescription || ''}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                    setEditForm({ ...editForm, criteriaDescription: e.target.value })
                  }
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label>Tier</Label>
                  <Select
                    value={editForm.tier}
                    onValueChange={(value: BadgeTier) => setEditForm({ ...editForm, tier: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="common">Common</SelectItem>
                      <SelectItem value="rare">Rare</SelectItem>
                      <SelectItem value="legendary">Legendary</SelectItem>
                      <SelectItem value="mythic">Mythic</SelectItem>
                      <SelectItem value="system">System</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Scope</Label>
                  <Select
                    value={editForm.scope}
                    onValueChange={(value: BadgeScope) => setEditForm({ ...editForm, scope: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="global">Global</SelectItem>
                      <SelectItem value="project">Project</SelectItem>
                      <SelectItem value="local">Local</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Status</Label>
                  <Select
                    value={editForm.status}
                    onValueChange={(value: BadgeStatus) => setEditForm({ ...editForm, status: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="deprecated">Deprecated</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Tabs defaultValue="seo" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="seo">SEO Metadata</TabsTrigger>
          <TabsTrigger value="geo">Geo Targeting</TabsTrigger>
        </TabsList>

        <TabsContent value="seo">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>SEO Metadata</CardTitle>
                <Button variant="outline" size="sm" onClick={handleRegenerateSEO}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Regenerate SEO
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label>SEO Title</Label>
                  <Input value={badgeType.seoTitle} readOnly className="bg-gray-50" />
                </div>
                <div>
                  <Label>SEO Description</Label>
                  <Textarea value={badgeType.seoDescription} readOnly rows={2} className="bg-gray-50" />
                </div>
                <div>
                  <Label>Keywords</Label>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {badgeType.seoKeywords.map((keyword: string) => (
                      <Badge key={keyword} variant="secondary">
                        {keyword}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <Label>Hashtags</Label>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {badgeType.seoHashtags.map((hashtag: string) => (
                      <Badge key={hashtag} variant="outline">
                        {hashtag}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <Label>Alt Text</Label>
                  <Input value={badgeType.altText} readOnly className="bg-gray-50" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="geo">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Geo Targeting</CardTitle>
                <Button variant="outline" size="sm" onClick={handleGenerateGeoVariants}>
                  <Globe className="w-4 h-4 mr-2" />
                  Generate Geo Variants
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {badgeType.primaryGeoTargets.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Globe className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No geo targets configured yet.</p>
                    <p className="text-sm mt-2">Add geo targets to create localized badge variants.</p>
                  </div>
                ) : (
                  <ScrollArea className="h-[300px]">
                    <div className="space-y-4">
                      {badgeType.primaryGeoTargets.map((geo: GeoTarget) => (
                        <Card key={geo.id}>
                          <CardContent className="p-4">
                            <div className="font-semibold mb-2">
                              {geo.region} - {geo.language} ({geo.id})
                            </div>
                            {badgeType.badgeIntroLocalized[geo.id] && (
                              <div className="text-sm mb-2">
                                <div className="text-gray-600">Localized Intro:</div>
                                <div>{badgeType.badgeIntroLocalized[geo.id]}</div>
                              </div>
                            )}
                            {badgeType.tagsLocalized[geo.id] && (
                              <div className="text-sm">
                                <div className="text-gray-600">Localized Tags:</div>
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {badgeType.tagsLocalized[geo.id].map((tag: string) => (
                                    <Badge key={tag} variant="outline" className="text-xs">
                                      {tag}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </ScrollArea>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
