'use client';

import { useState } from 'react';
import type { SubjectType, BadgeTier, BadgeScope, CreateBadgeTypeInput } from '@/types/dreamnet';
import { createBadgeType } from '@/lib/dreamnet-store';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';

interface CreateBadgeTypeDialogProps {
  onClose: () => void;
  onCreate: () => void;
}

const SUBJECT_TYPES: SubjectType[] = [
  'wallet',
  'agent',
  'mini-app',
  'content-stream',
  'token',
  'drop',
  'campaign',
  'segment',
  'creator',
  'picker',
  'other',
];

export function CreateBadgeTypeDialog({ onClose, onCreate }: CreateBadgeTypeDialogProps) {
  const [form, setForm] = useState<CreateBadgeTypeInput>({
    name: '',
    code: '',
    description: '',
    tier: 'common',
    scope: 'project',
    iconEmoji: '🏆',
    applicableSubjectTypes: [],
    criteriaDescription: '',
  });

  const handleSubmit = () => {
    if (!form.name || !form.code || !form.description || !form.criteriaDescription) {
      return;
    }

    createBadgeType(form);
    window.dispatchEvent(new Event('dreamnet-update'));
    onCreate();
  };

  const toggleSubjectType = (type: SubjectType) => {
    const current = form.applicableSubjectTypes;
    if (current.includes(type)) {
      setForm({ ...form, applicableSubjectTypes: current.filter((t: SubjectType) => t !== type) });
    } else {
      setForm({ ...form, applicableSubjectTypes: [...current, type] });
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>Create New Badge Type</DialogTitle>
        </DialogHeader>
        <ScrollArea className="max-h-[60vh]">
          <div className="space-y-4 py-4 pr-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Badge Name *</Label>
                <Input
                  id="name"
                  value={form.name}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, name: e.target.value })}
                  placeholder="e.g., Signal Sniper"
                />
              </div>

              <div>
                <Label htmlFor="code">Code *</Label>
                <Input
                  id="code"
                  value={form.code}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, code: e.target.value })}
                  placeholder="e.g., SIG-SNIPER"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={form.description}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setForm({ ...form, description: e.target.value })}
                placeholder="Brief description of this badge"
                rows={2}
              />
            </div>

            <div>
              <Label htmlFor="criteriaDescription">Criteria / How to Earn *</Label>
              <Textarea
                id="criteriaDescription"
                value={form.criteriaDescription}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                  setForm({ ...form, criteriaDescription: e.target.value })
                }
                placeholder="Explain how this badge is earned"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="iconEmoji">Icon Emoji</Label>
                <Input
                  id="iconEmoji"
                  value={form.iconEmoji}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, iconEmoji: e.target.value })}
                  placeholder="🏆"
                />
              </div>

              <div>
                <Label htmlFor="tier">Tier *</Label>
                <Select value={form.tier} onValueChange={(value: BadgeTier) => setForm({ ...form, tier: value })}>
                  <SelectTrigger id="tier">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="common">Common (+1)</SelectItem>
                    <SelectItem value="rare">Rare (+3)</SelectItem>
                    <SelectItem value="legendary">Legendary (+7)</SelectItem>
                    <SelectItem value="mythic">Mythic (+12)</SelectItem>
                    <SelectItem value="system">System (+0)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="scope">Scope *</Label>
                <Select value={form.scope} onValueChange={(value: BadgeScope) => setForm({ ...form, scope: value })}>
                  <SelectTrigger id="scope">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="global">Global</SelectItem>
                    <SelectItem value="project">Project</SelectItem>
                    <SelectItem value="local">Local</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Applicable Subject Types *</Label>
              <div className="grid grid-cols-2 gap-2 mt-2 p-4 border rounded-lg">
                {SUBJECT_TYPES.map((type: SubjectType) => (
                  <div key={type} className="flex items-center space-x-2">
                    <Checkbox
                      id={type}
                      checked={form.applicableSubjectTypes.includes(type)}
                      onCheckedChange={() => toggleSubjectType(type)}
                    />
                    <label
                      htmlFor={type}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 capitalize"
                    >
                      {type}
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </ScrollArea>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={
              !form.name || !form.code || !form.description || !form.criteriaDescription || form.applicableSubjectTypes.length === 0
            }
          >
            Create Badge Type
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
