'use client';

import { useState } from 'react';
import type { SubjectType, CreateSubjectInput } from '@/types/dreamnet';
import { createSubject } from '@/lib/dreamnet-store';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface CreateSubjectDialogProps {
  onClose: () => void;
  onCreate: () => void;
}

export function CreateSubjectDialog({ onClose, onCreate }: CreateSubjectDialogProps) {
  const [form, setForm] = useState<CreateSubjectInput>({
    type: 'wallet',
    refId: '',
    displayName: '',
    primaryEmoji: '🎯',
    chain: 'Base',
    category: '',
  });

  const handleSubmit = () => {
    if (!form.displayName || !form.refId) {
      return;
    }

    createSubject(form);
    window.dispatchEvent(new Event('dreamnet-update'));
    onCreate();
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Create New Subject</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div>
            <Label htmlFor="displayName">Display Name *</Label>
            <Input
              id="displayName"
              value={form.displayName}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, displayName: e.target.value })}
              placeholder="e.g., Alice's Wallet"
            />
          </div>

          <div>
            <Label htmlFor="type">Type *</Label>
            <Select value={form.type} onValueChange={(value: SubjectType) => setForm({ ...form, type: value })}>
              <SelectTrigger id="type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="wallet">Wallet</SelectItem>
                <SelectItem value="agent">Agent</SelectItem>
                <SelectItem value="mini-app">Mini-app</SelectItem>
                <SelectItem value="content-stream">Content Stream</SelectItem>
                <SelectItem value="token">Token</SelectItem>
                <SelectItem value="drop">Drop</SelectItem>
                <SelectItem value="campaign">Campaign</SelectItem>
                <SelectItem value="segment">Segment</SelectItem>
                <SelectItem value="creator">Creator</SelectItem>
                <SelectItem value="picker">Picker (Pickleball)</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="refId">Ref ID *</Label>
            <Input
              id="refId"
              value={form.refId}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, refId: e.target.value })}
              placeholder="e.g., 0x1234... or @handle"
            />
          </div>

          <div>
            <Label htmlFor="primaryEmoji">Primary Emoji</Label>
            <Input
              id="primaryEmoji"
              value={form.primaryEmoji}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, primaryEmoji: e.target.value })}
              placeholder="🎯"
            />
          </div>

          <div>
            <Label htmlFor="chain">Chain</Label>
            <Input
              id="chain"
              value={form.chain || ''}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, chain: e.target.value })}
              placeholder="e.g., Base, Ethereum"
            />
          </div>

          <div>
            <Label htmlFor="category">Category</Label>
            <Input
              id="category"
              value={form.category}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, category: e.target.value })}
              placeholder="e.g., culture, ops, pickleball"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!form.displayName || !form.refId}>
            Create Subject
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
