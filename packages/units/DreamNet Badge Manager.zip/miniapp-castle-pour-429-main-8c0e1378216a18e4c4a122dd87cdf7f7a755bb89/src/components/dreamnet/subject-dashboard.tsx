'use client';

import { useState, useEffect } from 'react';
import type { Subject, SubjectType, ReputationRecord } from '@/types/dreamnet';
import { getAllSubjectsWithReputation } from '@/lib/dreamnet-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Plus, Trophy, Users } from 'lucide-react';

interface SubjectWithDetails {
  subject: Subject;
  reputation: ReputationRecord;
  badgeCount: number;
}

interface SubjectDashboardProps {
  onSelectSubject: (subjectId: string) => void;
  onCreateSubject: () => void;
  onViewBadgeTypes: () => void;
}

const LEVEL_COLORS: Record<string, string> = {
  Shadow: 'bg-gray-600',
  Newcomer: 'bg-blue-500',
  Contributor: 'bg-green-500',
  Trusted: 'bg-purple-500',
  Guardian: 'bg-yellow-500',
};

export function SubjectDashboard({ onSelectSubject, onCreateSubject, onViewBadgeTypes }: SubjectDashboardProps) {
  const [subjects, setSubjects] = useState<SubjectWithDetails[]>([]);
  const [filteredSubjects, setFilteredSubjects] = useState<SubjectWithDetails[]>([]);
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [levelFilter, setLevelFilter] = useState<string>('all');

  const loadSubjects = () => {
    const data = getAllSubjectsWithReputation();
    setSubjects(data);
    setFilteredSubjects(data);
  };

  useEffect(() => {
    loadSubjects();

    const handleStorageChange = () => {
      loadSubjects();
    };

    window.addEventListener('dreamnet-update', handleStorageChange);
    return () => window.removeEventListener('dreamnet-update', handleStorageChange);
  }, []);

  useEffect(() => {
    let filtered = [...subjects];

    if (typeFilter !== 'all') {
      filtered = filtered.filter((s: SubjectWithDetails) => s.subject.type === typeFilter);
    }

    if (levelFilter !== 'all') {
      filtered = filtered.filter((s: SubjectWithDetails) => s.reputation.levelName === levelFilter);
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (s: SubjectWithDetails) =>
          s.subject.displayName.toLowerCase().includes(query) ||
          s.subject.category.toLowerCase().includes(query) ||
          s.subject.refId.toLowerCase().includes(query)
      );
    }

    setFilteredSubjects(filtered);
  }, [subjects, typeFilter, levelFilter, searchQuery]);

  const stats = {
    total: subjects.length,
    avgScore: subjects.length > 0 ? Math.round(subjects.reduce((sum: number, s: SubjectWithDetails) => sum + s.reputation.totalScore, 0) / subjects.length) : 0,
    totalBadges: subjects.reduce((sum: number, s: SubjectWithDetails) => sum + s.badgeCount, 0),
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">DreamNet Reputation Lab</h1>
          <p className="text-gray-600">Badge forge & reputation control room</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={onViewBadgeTypes} variant="outline">
            <Trophy className="w-4 h-4 mr-2" />
            Badge Types
          </Button>
          <Button onClick={onCreateSubject}>
            <Plus className="w-4 h-4 mr-2" />
            Create Subject
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Total Subjects</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold flex items-center gap-2">
              <Users className="w-8 h-8 text-blue-500" />
              {stats.total}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Average Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{stats.avgScore}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Total Badges Awarded</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold flex items-center gap-2">
              <Trophy className="w-8 h-8 text-yellow-500" />
              {stats.totalBadges}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Subjects & Reputation</CardTitle>
          <div className="flex flex-wrap gap-2 mt-4">
            <Input
              placeholder="Search by name, category, or refId..."
              value={searchQuery}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
              className="max-w-xs"
            />
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="wallet">Wallet</SelectItem>
                <SelectItem value="agent">Agent</SelectItem>
                <SelectItem value="mini-app">Mini-app</SelectItem>
                <SelectItem value="content-stream">Content Stream</SelectItem>
                <SelectItem value="token">Token</SelectItem>
                <SelectItem value="drop">Drop</SelectItem>
                <SelectItem value="campaign">Campaign</SelectItem>
                <SelectItem value="segment">Segment</SelectItem>
                <SelectItem value="creator">Creator</SelectItem>
                <SelectItem value="picker">Picker</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
            <Select value={levelFilter} onValueChange={setLevelFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="Shadow">Shadow</SelectItem>
                <SelectItem value="Newcomer">Newcomer</SelectItem>
                <SelectItem value="Contributor">Contributor</SelectItem>
                <SelectItem value="Trusted">Trusted</SelectItem>
                <SelectItem value="Guardian">Guardian</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[500px]">
            <div className="space-y-2">
              {filteredSubjects.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No subjects found. Create your first subject to get started!</p>
                </div>
              ) : (
                filteredSubjects.map((item: SubjectWithDetails) => (
                  <Card
                    key={item.subject.id}
                    className="cursor-pointer hover:bg-gray-50 transition-colors"
                    onClick={() => onSelectSubject(item.subject.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3 flex-1">
                          <div className="text-3xl">{item.subject.primaryEmoji}</div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="font-semibold text-lg">{item.subject.displayName}</h3>
                              <Badge variant="outline" className="text-xs">
                                {item.subject.type}
                              </Badge>
                            </div>
                            <div className="text-sm text-gray-600 space-y-1">
                              <div>Ref ID: {item.subject.refId}</div>
                              {item.subject.category && <div>Category: {item.subject.category}</div>}
                              {item.subject.chain && <div>Chain: {item.subject.chain}</div>}
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <Badge className={`${LEVEL_COLORS[item.reputation.levelName] || 'bg-gray-500'} text-white`}>
                            {item.reputation.levelName}
                          </Badge>
                          <div className="text-right">
                            <div className="text-2xl font-bold text-blue-600">{item.reputation.totalScore}</div>
                            <div className="text-xs text-gray-500">{item.badgeCount} badges</div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
