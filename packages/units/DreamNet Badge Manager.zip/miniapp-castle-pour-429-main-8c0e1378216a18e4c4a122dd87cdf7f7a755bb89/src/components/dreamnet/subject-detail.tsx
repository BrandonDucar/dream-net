'use client';

import { useState, useEffect } from 'react';
import type { Subject, ReputationRecord, BadgeInstance, BadgeType } from '@/types/dreamnet';
import { getSubjectDetails, updateSubject, adjustReputation, revokeBadge, exportSubjectReputationBrief } from '@/lib/dreamnet-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ArrowLeft, Edit2, Save, Award, TrendingUp, FileText, Trash2 } from 'lucide-react';
import { AwardBadgeDialog } from './award-badge-dialog';
import { AdjustReputationDialog } from './adjust-reputation-dialog';
import { ExportBriefDialog } from './export-brief-dialog';

interface SubjectDetailProps {
  subjectId: string;
  onBack: () => void;
}

export function SubjectDetail({ subjectId, onBack }: SubjectDetailProps) {
  const [subject, setSubject] = useState<Subject | null>(null);
  const [reputation, setReputation] = useState<ReputationRecord | null>(null);
  const [badges, setBadges] = useState<Array<BadgeInstance & { badgeType: BadgeType | null }>>([]);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editForm, setEditForm] = useState<Partial<Subject>>({});
  const [showAwardBadge, setShowAwardBadge] = useState<boolean>(false);
  const [showAdjustReputation, setShowAdjustReputation] = useState<boolean>(false);
  const [showExportBrief, setShowExportBrief] = useState<boolean>(false);
  const [exportedBrief, setExportedBrief] = useState<string>('');

  const loadDetails = () => {
    const details = getSubjectDetails(subjectId);
    setSubject(details.subject);
    setReputation(details.reputation);
    setBadges(details.badges);
    if (details.subject) {
      setEditForm(details.subject);
    }
  };

  useEffect(() => {
    loadDetails();
  }, [subjectId]);

  const handleSave = () => {
    if (subject && editForm) {
      updateSubject(subject.id, editForm);
      loadDetails();
      setIsEditing(false);
      window.dispatchEvent(new Event('dreamnet-update'));
    }
  };

  const handleRevokeBadge = (badgeInstanceId: string) => {
    revokeBadge(badgeInstanceId);
    loadDetails();
    window.dispatchEvent(new Event('dreamnet-update'));
  };

  const handleAwardBadge = () => {
    setShowAwardBadge(false);
    loadDetails();
    window.dispatchEvent(new Event('dreamnet-update'));
  };

  const handleAdjustReputation = () => {
    setShowAdjustReputation(false);
    loadDetails();
    window.dispatchEvent(new Event('dreamnet-update'));
  };

  const handleExportBrief = () => {
    const brief = exportSubjectReputationBrief(subjectId);
    setExportedBrief(brief);
    setShowExportBrief(true);
  };

  if (!subject || !reputation) {
    return (
      <div className="flex items-center justify-center h-96">
        <p className="text-gray-500">Subject not found</p>
      </div>
    );
  }

  const tierColors: Record<string, string> = {
    common: 'bg-gray-500',
    rare: 'bg-blue-500',
    legendary: 'bg-purple-500',
    mythic: 'bg-red-500',
    system: 'bg-green-500',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleExportBrief}>
            <FileText className="w-4 h-4 mr-2" />
            Export Brief
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Subject Identity</CardTitle>
            {!isEditing ? (
              <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                <Edit2 className="w-4 h-4 mr-2" />
                Edit
              </Button>
            ) : (
              <Button size="sm" onClick={handleSave}>
                <Save className="w-4 h-4 mr-2" />
                Save
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {!isEditing ? (
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <span className="text-4xl">{subject.primaryEmoji}</span>
                <div>
                  <h2 className="text-2xl font-bold">{subject.displayName}</h2>
                  <div className="flex gap-2 mt-1">
                    <Badge variant="outline">{subject.type}</Badge>
                    {subject.chain && <Badge variant="outline">{subject.chain}</Badge>}
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <div className="text-sm text-gray-600">Ref ID</div>
                  <div className="font-mono text-sm">{subject.refId}</div>
                </div>
                {subject.category && (
                  <div>
                    <div className="text-sm text-gray-600">Category</div>
                    <div>{subject.category}</div>
                  </div>
                )}
              </div>
              {subject.notes && (
                <div className="mt-4">
                  <div className="text-sm text-gray-600">Notes</div>
                  <div className="text-sm">{subject.notes}</div>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Display Name</label>
                <Input
                  value={editForm.displayName || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, displayName: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Primary Emoji</label>
                <Input
                  value={editForm.primaryEmoji || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, primaryEmoji: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Ref ID</label>
                <Input
                  value={editForm.refId || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, refId: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Category</label>
                <Input
                  value={editForm.category || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, category: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Chain</label>
                <Input
                  value={editForm.chain || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, chain: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Notes</label>
                <Textarea
                  value={editForm.notes || ''}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setEditForm({ ...editForm, notes: e.target.value })}
                  rows={3}
                />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Reputation</CardTitle>
            <Button variant="outline" size="sm" onClick={() => setShowAdjustReputation(true)}>
              <TrendingUp className="w-4 h-4 mr-2" />
              Adjust
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-600">Level</div>
                <div className="text-2xl font-bold text-purple-600">{reputation.levelName}</div>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-600">Total Score</div>
                <div className="text-4xl font-bold text-blue-600">{reputation.totalScore}</div>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t">
              <div>
                <div className="text-xs text-gray-600">Base Score</div>
                <div className="text-xl font-semibold">{reputation.baseScore}</div>
              </div>
              <div>
                <div className="text-xs text-gray-600">Badge Bonus</div>
                <div className="text-xl font-semibold text-green-600">+{reputation.badgeBonus}</div>
              </div>
              <div>
                <div className="text-xs text-gray-600">Activity Bonus</div>
                <div className="text-xl font-semibold text-blue-600">+{reputation.activityBonus}</div>
              </div>
              <div>
                <div className="text-xs text-gray-600">Penalty</div>
                <div className="text-xl font-semibold text-red-600">-{reputation.penalty}</div>
              </div>
            </div>
            <div className="text-xs text-gray-500">
              Last updated: {new Date(reputation.lastUpdated).toLocaleString()}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Badges ({badges.length})</CardTitle>
            <Button variant="outline" size="sm" onClick={() => setShowAwardBadge(true)}>
              <Award className="w-4 h-4 mr-2" />
              Award Badge
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[300px]">
            {badges.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Award className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No badges awarded yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {badges.map((badge) => (
                  <Card key={badge.id}>
                    <CardContent className="p-4">
                      {badge.badgeType ? (
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-3">
                            <span className="text-3xl">{badge.badgeType.iconEmoji}</span>
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <h4 className="font-semibold">{badge.badgeType.name}</h4>
                                <Badge className={`${tierColors[badge.badgeType.tier]} text-white text-xs`}>
                                  {badge.badgeType.tier}
                                </Badge>
                              </div>
                              <div className="text-sm text-gray-600 space-y-1">
                                <div>Awarded: {new Date(badge.awardedAt).toLocaleDateString()}</div>
                                <div>By: {badge.awardedBy}</div>
                                {badge.reason && <div>Reason: {badge.reason}</div>}
                              </div>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRevokeBadge(badge.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      ) : (
                        <div className="text-gray-500">Badge type not found</div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {showAwardBadge && (
        <AwardBadgeDialog
          subjectId={subjectId}
          subjectType={subject.type}
          onClose={() => setShowAwardBadge(false)}
          onAward={handleAwardBadge}
        />
      )}

      {showAdjustReputation && (
        <AdjustReputationDialog
          subjectId={subjectId}
          onClose={() => setShowAdjustReputation(false)}
          onAdjust={handleAdjustReputation}
        />
      )}

      {showExportBrief && (
        <ExportBriefDialog
          brief={exportedBrief}
          subjectName={subject.displayName}
          onClose={() => setShowExportBrief(false)}
        />
      )}
    </div>
  );
}
