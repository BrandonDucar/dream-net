import type {
  Subject,
  BadgeType,
  BadgeInstance,
  ReputationRecord,
  CreateSubjectInput,
  CreateBadgeTypeInput,
  SubjectFilter,
  BadgeTypeFilter,
  GeoTarget,
  BadgeTier,
} from '@/types/dreamnet';

const SUBJECTS_KEY = 'dreamnet_subjects';
const BADGE_TYPES_KEY = 'dreamnet_badge_types';
const BADGE_INSTANCES_KEY = 'dreamnet_badge_instances';
const REPUTATION_RECORDS_KEY = 'dreamnet_reputation_records';

// Tier to bonus points mapping
const TIER_BONUS: Record<BadgeTier, number> = {
  common: 1,
  rare: 3,
  legendary: 7,
  mythic: 12,
  system: 0,
};

// Helper to generate IDs
function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

// Helper to calculate level name from total score
function calculateLevelName(totalScore: number): string {
  if (totalScore < 0) return 'Shadow';
  if (totalScore < 10) return 'Newcomer';
  if (totalScore < 25) return 'Contributor';
  if (totalScore < 50) return 'Trusted';
  return 'Guardian';
}

// Storage helpers
function getFromStorage<T>(key: string): T[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

function saveToStorage<T>(key: string, data: T[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(key, JSON.stringify(data));
}

// Generate SEO metadata
function generateSEOMeta(name: string, description: string, tier: string, scope: string) {
  return {
    seoTitle: `${name} Badge - ${tier.charAt(0).toUpperCase() + tier.slice(1)} Tier | DreamNet`,
    seoDescription: `${description} - A ${tier} tier badge for ${scope} recognition in the DreamNet ecosystem.`,
    seoKeywords: [name.toLowerCase(), tier, scope, 'badge', 'reputation', 'DreamNet'],
    seoHashtags: [`#${name.replace(/\s+/g, '')}`, `#${tier}Badge`, '#DreamNet', '#Reputation'],
    altText: `${name} badge icon - ${tier} tier`,
  };
}

// ====== SUBJECT FUNCTIONS ======

export function createSubject(input: CreateSubjectInput): { subject: Subject; reputation: ReputationRecord } {
  const subjects = getFromStorage<Subject>(SUBJECTS_KEY);
  const reputations = getFromStorage<ReputationRecord>(REPUTATION_RECORDS_KEY);

  const subject: Subject = {
    id: generateId(),
    type: input.type,
    refId: input.refId,
    displayName: input.displayName,
    primaryEmoji: input.primaryEmoji || '🎯',
    chain: input.chain || null,
    category: input.category || '',
    notes: '',
  };

  const reputation: ReputationRecord = {
    subjectId: subject.id,
    baseScore: 0,
    badgeBonus: 0,
    activityBonus: 0,
    penalty: 0,
    totalScore: 0,
    levelName: 'Newcomer',
    lastUpdated: new Date().toISOString(),
  };

  subjects.push(subject);
  reputations.push(reputation);

  saveToStorage(SUBJECTS_KEY, subjects);
  saveToStorage(REPUTATION_RECORDS_KEY, reputations);

  return { subject, reputation };
}

export function updateSubject(id: string, updates: Partial<Subject>): Subject | null {
  const subjects = getFromStorage<Subject>(SUBJECTS_KEY);
  const index = subjects.findIndex((s: Subject) => s.id === id);

  if (index === -1) return null;

  subjects[index] = { ...subjects[index], ...updates };
  saveToStorage(SUBJECTS_KEY, subjects);

  return subjects[index];
}

export function listSubjects(filter?: SubjectFilter): Subject[] {
  let subjects = getFromStorage<Subject>(SUBJECTS_KEY);
  const reputations = getFromStorage<ReputationRecord>(REPUTATION_RECORDS_KEY);

  if (filter?.type) {
    subjects = subjects.filter((s: Subject) => s.type === filter.type);
  }

  if (filter?.category) {
    subjects = subjects.filter((s: Subject) => s.category.toLowerCase().includes(filter.category!.toLowerCase()));
  }

  if (filter?.minScore !== undefined) {
    const qualifyingSubjectIds = reputations
      .filter((r: ReputationRecord) => r.totalScore >= filter.minScore!)
      .map((r: ReputationRecord) => r.subjectId);
    subjects = subjects.filter((s: Subject) => qualifyingSubjectIds.includes(s.id));
  }

  if (filter?.levelName) {
    const qualifyingSubjectIds = reputations
      .filter((r: ReputationRecord) => r.levelName === filter.levelName)
      .map((r: ReputationRecord) => r.subjectId);
    subjects = subjects.filter((s: Subject) => qualifyingSubjectIds.includes(s.id));
  }

  return subjects;
}

export function getSubjectDetails(subjectId: string): {
  subject: Subject | null;
  reputation: ReputationRecord | null;
  badges: Array<BadgeInstance & { badgeType: BadgeType | null }>;
} {
  const subjects = getFromStorage<Subject>(SUBJECTS_KEY);
  const reputations = getFromStorage<ReputationRecord>(REPUTATION_RECORDS_KEY);
  const instances = getFromStorage<BadgeInstance>(BADGE_INSTANCES_KEY);
  const badgeTypes = getFromStorage<BadgeType>(BADGE_TYPES_KEY);

  const subject = subjects.find((s: Subject) => s.id === subjectId) || null;
  const reputation = reputations.find((r: ReputationRecord) => r.subjectId === subjectId) || null;

  const badges = instances
    .filter((i: BadgeInstance) => i.subjectId === subjectId)
    .map((instance: BadgeInstance) => ({
      ...instance,
      badgeType: badgeTypes.find((bt: BadgeType) => bt.id === instance.badgeTypeId) || null,
    }));

  return { subject, reputation, badges };
}

// ====== BADGE TYPE FUNCTIONS ======

export function createBadgeType(input: CreateBadgeTypeInput): BadgeType {
  const badgeTypes = getFromStorage<BadgeType>(BADGE_TYPES_KEY);

  const seoMeta = generateSEOMeta(input.name, input.description, input.tier, input.scope);

  const badgeType: BadgeType = {
    id: generateId(),
    name: input.name,
    code: input.code,
    description: input.description,
    tier: input.tier,
    scope: input.scope,
    iconEmoji: input.iconEmoji,
    criteriaDescription: input.criteriaDescription,
    applicableSubjectTypes: input.applicableSubjectTypes,
    tags: [],
    status: 'active',
    primaryGeoTargets: [],
    badgeIntroLocalized: {},
    tagsLocalized: {},
    ...seoMeta,
  };

  badgeTypes.push(badgeType);
  saveToStorage(BADGE_TYPES_KEY, badgeTypes);

  return badgeType;
}

export function updateBadgeType(id: string, updates: Partial<BadgeType>): BadgeType | null {
  const badgeTypes = getFromStorage<BadgeType>(BADGE_TYPES_KEY);
  const index = badgeTypes.findIndex((bt: BadgeType) => bt.id === id);

  if (index === -1) return null;

  badgeTypes[index] = { ...badgeTypes[index], ...updates };
  saveToStorage(BADGE_TYPES_KEY, badgeTypes);

  return badgeTypes[index];
}

export function listBadgeTypes(filter?: BadgeTypeFilter): BadgeType[] {
  let badgeTypes = getFromStorage<BadgeType>(BADGE_TYPES_KEY);

  if (filter?.tier) {
    badgeTypes = badgeTypes.filter((bt: BadgeType) => bt.tier === filter.tier);
  }

  if (filter?.scope) {
    badgeTypes = badgeTypes.filter((bt: BadgeType) => bt.scope === filter.scope);
  }

  if (filter?.status) {
    badgeTypes = badgeTypes.filter((bt: BadgeType) => bt.status === filter.status);
  }

  if (filter?.applicableSubjectTypes && filter.applicableSubjectTypes.length > 0) {
    badgeTypes = badgeTypes.filter((bt: BadgeType) =>
      bt.applicableSubjectTypes.some((t) => filter.applicableSubjectTypes!.includes(t))
    );
  }

  return badgeTypes;
}

export function regenerateBadgeSEO(badgeTypeId: string): BadgeType | null {
  const badgeTypes = getFromStorage<BadgeType>(BADGE_TYPES_KEY);
  const index = badgeTypes.findIndex((bt: BadgeType) => bt.id === badgeTypeId);

  if (index === -1) return null;

  const badgeType = badgeTypes[index];
  const seoMeta = generateSEOMeta(badgeType.name, badgeType.description, badgeType.tier, badgeType.scope);

  badgeTypes[index] = { ...badgeType, ...seoMeta };
  saveToStorage(BADGE_TYPES_KEY, badgeTypes);

  return badgeTypes[index];
}

export function assignGeoTargetsToBadgeType(badgeTypeId: string, geoTargets: GeoTarget[]): BadgeType | null {
  const badgeTypes = getFromStorage<BadgeType>(BADGE_TYPES_KEY);
  const index = badgeTypes.findIndex((bt: BadgeType) => bt.id === badgeTypeId);

  if (index === -1) return null;

  badgeTypes[index].primaryGeoTargets = geoTargets;
  saveToStorage(BADGE_TYPES_KEY, badgeTypes);

  return badgeTypes[index];
}

export function generateGeoVariantsForBadgeType(badgeTypeId: string): BadgeType | null {
  const badgeTypes = getFromStorage<BadgeType>(BADGE_TYPES_KEY);
  const index = badgeTypes.findIndex((bt: BadgeType) => bt.id === badgeTypeId);

  if (index === -1) return null;

  const badgeType = badgeTypes[index];
  const badgeIntroLocalized: Record<string, string> = {};
  const tagsLocalized: Record<string, string[]> = {};

  badgeType.primaryGeoTargets.forEach((geo: GeoTarget) => {
    const geoKey = geo.id;
    badgeIntroLocalized[geoKey] = `${badgeType.description} (${geo.region} - ${geo.language})`;
    tagsLocalized[geoKey] = [...badgeType.tags, geo.region, geo.language];
  });

  badgeTypes[index] = {
    ...badgeType,
    badgeIntroLocalized,
    tagsLocalized,
  };

  saveToStorage(BADGE_TYPES_KEY, badgeTypes);

  return badgeTypes[index];
}

// ====== BADGE INSTANCE FUNCTIONS ======

export function awardBadge(
  subjectId: string,
  badgeTypeId: string,
  reason: string
): { instance: BadgeInstance; reputation: ReputationRecord } | null {
  const instances = getFromStorage<BadgeInstance>(BADGE_INSTANCES_KEY);
  const reputations = getFromStorage<ReputationRecord>(REPUTATION_RECORDS_KEY);
  const badgeTypes = getFromStorage<BadgeType>(BADGE_TYPES_KEY);

  const badgeType = badgeTypes.find((bt: BadgeType) => bt.id === badgeTypeId);
  if (!badgeType) return null;

  const instance: BadgeInstance = {
    id: generateId(),
    badgeTypeId,
    subjectId,
    awardedAt: new Date().toISOString(),
    awardedBy: 'manual',
    reason,
    notes: '',
  };

  instances.push(instance);
  saveToStorage(BADGE_INSTANCES_KEY, instances);

  // Update reputation
  const repIndex = reputations.findIndex((r: ReputationRecord) => r.subjectId === subjectId);
  if (repIndex !== -1) {
    const bonus = TIER_BONUS[badgeType.tier];
    reputations[repIndex].badgeBonus += bonus;
    reputations[repIndex].totalScore =
      reputations[repIndex].baseScore +
      reputations[repIndex].badgeBonus +
      reputations[repIndex].activityBonus -
      reputations[repIndex].penalty;
    reputations[repIndex].levelName = calculateLevelName(reputations[repIndex].totalScore);
    reputations[repIndex].lastUpdated = new Date().toISOString();

    saveToStorage(REPUTATION_RECORDS_KEY, reputations);

    return { instance, reputation: reputations[repIndex] };
  }

  return null;
}

export function revokeBadge(badgeInstanceId: string): ReputationRecord | null {
  const instances = getFromStorage<BadgeInstance>(BADGE_INSTANCES_KEY);
  const reputations = getFromStorage<ReputationRecord>(REPUTATION_RECORDS_KEY);
  const badgeTypes = getFromStorage<BadgeType>(BADGE_TYPES_KEY);

  const instanceIndex = instances.findIndex((i: BadgeInstance) => i.id === badgeInstanceId);
  if (instanceIndex === -1) return null;

  const instance = instances[instanceIndex];
  const badgeType = badgeTypes.find((bt: BadgeType) => bt.id === instance.badgeTypeId);
  if (!badgeType) return null;

  // Remove instance
  instances.splice(instanceIndex, 1);
  saveToStorage(BADGE_INSTANCES_KEY, instances);

  // Update reputation
  const repIndex = reputations.findIndex((r: ReputationRecord) => r.subjectId === instance.subjectId);
  if (repIndex !== -1) {
    const bonus = TIER_BONUS[badgeType.tier];
    reputations[repIndex].badgeBonus -= bonus;
    reputations[repIndex].totalScore =
      reputations[repIndex].baseScore +
      reputations[repIndex].badgeBonus +
      reputations[repIndex].activityBonus -
      reputations[repIndex].penalty;
    reputations[repIndex].levelName = calculateLevelName(reputations[repIndex].totalScore);
    reputations[repIndex].lastUpdated = new Date().toISOString();

    saveToStorage(REPUTATION_RECORDS_KEY, reputations);

    return reputations[repIndex];
  }

  return null;
}

export function listBadgesForSubject(subjectId: string): Array<BadgeInstance & { badgeType: BadgeType | null }> {
  const instances = getFromStorage<BadgeInstance>(BADGE_INSTANCES_KEY);
  const badgeTypes = getFromStorage<BadgeType>(BADGE_TYPES_KEY);

  return instances
    .filter((i: BadgeInstance) => i.subjectId === subjectId)
    .map((instance: BadgeInstance) => ({
      ...instance,
      badgeType: badgeTypes.find((bt: BadgeType) => bt.id === instance.badgeTypeId) || null,
    }));
}

// ====== REPUTATION FUNCTIONS ======

export function adjustReputation(
  subjectId: string,
  deltaActivityBonus: number,
  deltaPenalty: number,
  reason: string
): ReputationRecord | null {
  const reputations = getFromStorage<ReputationRecord>(REPUTATION_RECORDS_KEY);
  const repIndex = reputations.findIndex((r: ReputationRecord) => r.subjectId === subjectId);

  if (repIndex === -1) return null;

  reputations[repIndex].activityBonus += deltaActivityBonus;
  reputations[repIndex].penalty += deltaPenalty;
  reputations[repIndex].totalScore =
    reputations[repIndex].baseScore +
    reputations[repIndex].badgeBonus +
    reputations[repIndex].activityBonus -
    reputations[repIndex].penalty;
  reputations[repIndex].levelName = calculateLevelName(reputations[repIndex].totalScore);
  reputations[repIndex].lastUpdated = new Date().toISOString();

  saveToStorage(REPUTATION_RECORDS_KEY, reputations);

  return reputations[repIndex];
}

export function getReputationRecord(subjectId: string): ReputationRecord | null {
  const reputations = getFromStorage<ReputationRecord>(REPUTATION_RECORDS_KEY);
  return reputations.find((r: ReputationRecord) => r.subjectId === subjectId) || null;
}

// ====== EXPORT FUNCTIONS ======

export function exportSubjectReputationBrief(subjectId: string): string {
  const { subject, reputation, badges } = getSubjectDetails(subjectId);

  if (!subject || !reputation) return 'Subject not found';

  let brief = `═══════════════════════════════════════════════════════\n`;
  brief += `  DREAMNET REPUTATION BRIEF\n`;
  brief += `═══════════════════════════════════════════════════════\n\n`;

  brief += `SUBJECT IDENTITY\n`;
  brief += `────────────────────────────────────────────────────────\n`;
  brief += `${subject.primaryEmoji} ${subject.displayName}\n`;
  brief += `Type: ${subject.type}\n`;
  brief += `Ref ID: ${subject.refId}\n`;
  if (subject.chain) brief += `Chain: ${subject.chain}\n`;
  if (subject.category) brief += `Category: ${subject.category}\n`;
  brief += `\n`;

  brief += `REPUTATION RECORD\n`;
  brief += `────────────────────────────────────────────────────────\n`;
  brief += `Level: ${reputation.levelName}\n`;
  brief += `Total Score: ${reputation.totalScore}\n`;
  brief += `  ├─ Base Score: ${reputation.baseScore}\n`;
  brief += `  ├─ Badge Bonus: ${reputation.badgeBonus}\n`;
  brief += `  ├─ Activity Bonus: ${reputation.activityBonus}\n`;
  brief += `  └─ Penalty: -${reputation.penalty}\n`;
  brief += `Last Updated: ${new Date(reputation.lastUpdated).toLocaleString()}\n`;
  brief += `\n`;

  if (badges.length > 0) {
    brief += `BADGES EARNED (${badges.length})\n`;
    brief += `────────────────────────────────────────────────────────\n`;
    badges.forEach((badge) => {
      if (badge.badgeType) {
        brief += `${badge.badgeType.iconEmoji} ${badge.badgeType.name} (${badge.badgeType.tier})\n`;
        brief += `   Awarded: ${new Date(badge.awardedAt).toLocaleDateString()}\n`;
        brief += `   By: ${badge.awardedBy}\n`;
        if (badge.reason) brief += `   Reason: ${badge.reason}\n`;
        brief += `\n`;
      }
    });
  }

  brief += `INTERPRETATION\n`;
  brief += `────────────────────────────────────────────────────────\n`;
  const interpretation = generateInterpretation(subject, reputation, badges.length);
  brief += interpretation;
  brief += `\n\n`;
  brief += `═══════════════════════════════════════════════════════\n`;
  brief += `Generated: ${new Date().toLocaleString()}\n`;
  brief += `═══════════════════════════════════════════════════════\n`;

  return brief;
}

function generateInterpretation(subject: Subject, reputation: ReputationRecord, badgeCount: number): string {
  let text = `This ${subject.type} is recognized as a "${reputation.levelName}" `;
  text += `in the DreamNet ecosystem with a reputation score of ${reputation.totalScore}. `;

  if (badgeCount === 0) {
    text += `They have not yet earned any badges but show potential for growth.`;
  } else if (badgeCount === 1) {
    text += `They have earned 1 badge, demonstrating initial engagement.`;
  } else {
    text += `They have earned ${badgeCount} badges, demonstrating active participation and value contribution.`;
  }

  if (reputation.totalScore >= 50) {
    text += ` Their Guardian status marks them as a core pillar of the ecosystem.`;
  } else if (reputation.totalScore >= 25) {
    text += ` Their Trusted status indicates reliability and consistent contribution.`;
  } else if (reputation.totalScore >= 10) {
    text += ` As a Contributor, they are building momentum in the community.`;
  }

  return text;
}

export function exportBadgeCatalog(): string {
  const badgeTypes = getFromStorage<BadgeType>(BADGE_TYPES_KEY);

  let catalog = `═══════════════════════════════════════════════════════\n`;
  catalog += `  DREAMNET BADGE CATALOG\n`;
  catalog += `═══════════════════════════════════════════════════════\n\n`;

  const byTier: Record<string, BadgeType[]> = {
    mythic: [],
    legendary: [],
    rare: [],
    common: [],
    system: [],
  };

  badgeTypes.forEach((bt: BadgeType) => {
    byTier[bt.tier].push(bt);
  });

  Object.entries(byTier).forEach(([tier, badges]) => {
    if (badges.length === 0) return;

    catalog += `\n${tier.toUpperCase()} TIER\n`;
    catalog += `────────────────────────────────────────────────────────\n\n`;

    badges.forEach((badge: BadgeType) => {
      catalog += `${badge.iconEmoji} ${badge.name} [${badge.code}]\n`;
      catalog += `Status: ${badge.status} | Scope: ${badge.scope}\n`;
      catalog += `Description: ${badge.description}\n`;
      catalog += `Criteria: ${badge.criteriaDescription}\n`;
      catalog += `Applicable to: ${badge.applicableSubjectTypes.join(', ')}\n`;
      if (badge.tags.length > 0) {
        catalog += `Tags: ${badge.tags.join(', ')}\n`;
      }
      catalog += `\nSEO Metadata:\n`;
      catalog += `  Title: ${badge.seoTitle}\n`;
      catalog += `  Description: ${badge.seoDescription}\n`;
      catalog += `  Keywords: ${badge.seoKeywords.join(', ')}\n`;
      catalog += `  Hashtags: ${badge.seoHashtags.join(', ')}\n`;
      catalog += `\n`;
    });
  });

  catalog += `═══════════════════════════════════════════════════════\n`;
  catalog += `Total Badges: ${badgeTypes.length}\n`;
  catalog += `Generated: ${new Date().toLocaleString()}\n`;
  catalog += `═══════════════════════════════════════════════════════\n`;

  return catalog;
}

// ====== UTILITY ======

export function getBadgeCount(subjectId: string): number {
  const instances = getFromStorage<BadgeInstance>(BADGE_INSTANCES_KEY);
  return instances.filter((i: BadgeInstance) => i.subjectId === subjectId).length;
}

export function getAllSubjectsWithReputation(): Array<{
  subject: Subject;
  reputation: ReputationRecord;
  badgeCount: number;
}> {
  const subjects = getFromStorage<Subject>(SUBJECTS_KEY);
  const reputations = getFromStorage<ReputationRecord>(REPUTATION_RECORDS_KEY);

  return subjects.map((subject: Subject) => {
    const reputation = reputations.find((r: ReputationRecord) => r.subjectId === subject.id) || {
      subjectId: subject.id,
      baseScore: 0,
      badgeBonus: 0,
      activityBonus: 0,
      penalty: 0,
      totalScore: 0,
      levelName: 'Newcomer',
      lastUpdated: new Date().toISOString(),
    };
    const badgeCount = getBadgeCount(subject.id);

    return { subject, reputation, badgeCount };
  });
}
