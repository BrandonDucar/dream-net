export type SubjectType = 
  | "wallet"
  | "agent"
  | "mini-app"
  | "content-stream"
  | "token"
  | "drop"
  | "campaign"
  | "segment"
  | "creator"
  | "picker"
  | "other";

export type BadgeTier = "common" | "rare" | "legendary" | "mythic" | "system";

export type BadgeScope = "global" | "project" | "local";

export type BadgeStatus = "draft" | "active" | "deprecated";

export interface Subject {
  id: string;
  type: SubjectType;
  refId: string;
  displayName: string;
  primaryEmoji: string;
  chain: string | null;
  category: string;
  notes: string;
}

export interface SEOMeta {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export interface GeoTarget {
  id: string;
  region: string;
  country: string;
  cityOrMarket: string;
  language: string;
}

export interface BadgeType extends SEOMeta {
  id: string;
  name: string;
  code: string;
  description: string;
  tier: BadgeTier;
  scope: BadgeScope;
  iconEmoji: string;
  criteriaDescription: string;
  applicableSubjectTypes: SubjectType[];
  tags: string[];
  status: BadgeStatus;
  primaryGeoTargets: GeoTarget[];
  badgeIntroLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
}

export interface BadgeInstance {
  id: string;
  badgeTypeId: string;
  subjectId: string;
  awardedAt: string;
  awardedBy: string;
  reason: string;
  notes: string;
}

export interface ReputationRecord {
  subjectId: string;
  baseScore: number;
  badgeBonus: number;
  activityBonus: number;
  penalty: number;
  totalScore: number;
  levelName: string;
  lastUpdated: string;
}

export interface CreateSubjectInput {
  type: SubjectType;
  refId: string;
  displayName: string;
  primaryEmoji?: string;
  chain?: string | null;
  category?: string;
}

export interface CreateBadgeTypeInput {
  name: string;
  code: string;
  description: string;
  tier: BadgeTier;
  scope: BadgeScope;
  iconEmoji: string;
  applicableSubjectTypes: SubjectType[];
  criteriaDescription: string;
}

export interface SubjectFilter {
  type?: SubjectType;
  category?: string;
  minScore?: number;
  levelName?: string;
}

export interface BadgeTypeFilter {
  tier?: BadgeTier;
  scope?: BadgeScope;
  status?: BadgeStatus;
  applicableSubjectTypes?: SubjectType[];
}
