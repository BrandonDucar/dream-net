"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  ArrowLeft, 
  TrendingUp, 
  Search as SearchIcon, 
  AlertCircle, 
  Clock,
  BarChart3,
  Activity
} from "lucide-react";
import {
  getUsageStats,
  getMostSearchedTerms,
  getMostUsedCommands,
  getDeadEndSearches,
  getSearchQueries,
  getCommandHistory,
  getProductivityInsights,
  clearAllAnalytics,
} from "@/lib/analytics-service";
import type { UsageStats, SearchQuery, DeadEndSearch, CommandHistory, ProductivityInsight } from "@/types/navigator-advanced";

export default function AnalyticsPage() {
  const router = useRouter();
  const [period, setPeriod] = useState<"daily" | "weekly" | "monthly">("weekly");
  const [stats, setStats] = useState<UsageStats | null>(null);
  const [searchTerms, setSearchTerms] = useState<Array<{ term: string; count: number }>>([]);
  const [topCommands, setTopCommands] = useState<Array<{ commandId: string; commandName: string; count: number }>>([]);
  const [deadEnds, setDeadEnds] = useState<DeadEndSearch[]>([]);
  const [recentSearches, setRecentSearches] = useState<SearchQuery[]>([]);
  const [history, setHistory] = useState<CommandHistory[]>([]);
  const [insights, setInsights] = useState<ProductivityInsight | null>(null);

  useEffect(() => {
    loadAnalytics();
  }, [period]);

  const loadAnalytics = (): void => {
    const usageStats = getUsageStats(period);
    setStats(usageStats);

    setSearchTerms(getMostSearchedTerms(10));
    setTopCommands(getMostUsedCommands(10));
    setDeadEnds(getDeadEndSearches(20));
    setRecentSearches(getSearchQueries(50));
    setHistory(getCommandHistory(30));
    
    const productivityInsights = getProductivityInsights(period);
    setInsights(productivityInsights);
  };

  const handleClearAnalytics = (): void => {
    if (confirm("Are you sure you want to clear all analytics data?")) {
      clearAllAnalytics();
      loadAnalytics();
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="border-b bg-white">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => router.push("/")}
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <BarChart3 className="h-6 w-6" />
                  Analytics & Insights
                </h1>
                <p className="text-sm text-gray-500 mt-1">
                  Track usage patterns and discover insights
                </p>
              </div>
            </div>
            <Button variant="destructive" size="sm" onClick={handleClearAnalytics}>
              Clear Analytics
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-6">
        {/* Period Selector */}
        <div className="flex gap-2 mb-6">
          <Button
            variant={period === "daily" ? "default" : "outline"}
            size="sm"
            onClick={() => setPeriod("daily")}
          >
            Daily
          </Button>
          <Button
            variant={period === "weekly" ? "default" : "outline"}
            size="sm"
            onClick={() => setPeriod("weekly")}
          >
            Weekly
          </Button>
          <Button
            variant={period === "monthly" ? "default" : "outline"}
            size="sm"
            onClick={() => setPeriod("monthly")}
          >
            Monthly
          </Button>
        </div>

        {/* Overview Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Searches</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats?.totalSearches || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Commands Executed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats?.totalCommands || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Dead-End Searches</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-600">{stats?.deadEndSearches || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Avg. Search Time</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{Math.round(stats?.avgTimeToSelect || 0)}ms</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="searches" className="space-y-4">
          <TabsList>
            <TabsTrigger value="searches">Searches</TabsTrigger>
            <TabsTrigger value="commands">Commands</TabsTrigger>
            <TabsTrigger value="dead-ends">Dead Ends</TabsTrigger>
            <TabsTrigger value="productivity">Productivity</TabsTrigger>
          </TabsList>

          {/* Searches Tab */}
          <TabsContent value="searches" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Top Search Terms
                  </CardTitle>
                  <CardDescription>Most frequently searched terms</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    <div className="space-y-2">
                      {searchTerms.map((item, index) => (
                        <div key={item.term} className="flex items-center justify-between p-2 border rounded">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{index + 1}</Badge>
                            <span className="text-sm">{item.term}</span>
                          </div>
                          <span className="text-sm font-medium">{item.count}</span>
                        </div>
                      ))}
                      {searchTerms.length === 0 && (
                        <p className="text-sm text-gray-500 text-center py-4">No search data yet</p>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Clock className="h-5 w-5" />
                    Recent Searches
                  </CardTitle>
                  <CardDescription>Last 20 searches</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    <div className="space-y-2">
                      {recentSearches.slice(0, 20).map((search) => (
                        <div key={search.id} className="p-2 border rounded text-sm">
                          <div className="flex items-center justify-between">
                            <span className="font-medium">{search.query}</span>
                            <span className="text-xs text-gray-500">
                              {search.resultsCount} results
                            </span>
                          </div>
                          <div className="text-xs text-gray-500 mt-1">
                            {new Date(search.timestamp).toLocaleString()}
                          </div>
                        </div>
                      ))}
                      {recentSearches.length === 0 && (
                        <p className="text-sm text-gray-500 text-center py-4">No searches yet</p>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Commands Tab */}
          <TabsContent value="commands" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Most Used Commands</CardTitle>
                  <CardDescription>Your top commands by usage</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    <div className="space-y-2">
                      {topCommands.map((cmd, index) => (
                        <div key={cmd.commandId} className="flex items-center justify-between p-2 border rounded">
                          <div className="flex items-center gap-2">
                            <Badge>{index + 1}</Badge>
                            <span className="text-sm">{cmd.commandName || cmd.commandId}</span>
                          </div>
                          <span className="text-sm font-medium">{cmd.count}x</span>
                        </div>
                      ))}
                      {topCommands.length === 0 && (
                        <p className="text-sm text-gray-500 text-center py-4">No command data yet</p>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Command History
                  </CardTitle>
                  <CardDescription>Recent command executions</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    <div className="space-y-2">
                      {history.map((item) => (
                        <div key={item.id} className="p-2 border rounded text-sm">
                          <div className="font-medium">{item.commandName}</div>
                          <div className="text-xs text-gray-500">
                            {new Date(item.executedAt).toLocaleString()}
                            {item.duration && ` • ${item.duration}ms`}
                          </div>
                        </div>
                      ))}
                      {history.length === 0 && (
                        <p className="text-sm text-gray-500 text-center py-4">No history yet</p>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Dead Ends Tab */}
          <TabsContent value="dead-ends">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-orange-600" />
                  Dead-End Searches
                </CardTitle>
                <CardDescription>
                  Searches that returned no results - consider adding these as commands or aliases
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-3">
                    {deadEnds.map((deadEnd) => (
                      <div key={deadEnd.id} className="p-3 border rounded bg-orange-50 border-orange-200">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">{deadEnd.query}</span>
                          <Badge variant="outline">{deadEnd.attemptCount}x attempts</Badge>
                        </div>
                        {deadEnd.suggestedAlternatives.length > 0 && (
                          <div className="text-xs text-gray-600">
                            <span className="font-medium">Suggestions:</span>
                            <ul className="list-disc list-inside mt-1">
                              {deadEnd.suggestedAlternatives.map((alt, i) => (
                                <li key={i}>{alt}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    ))}
                    {deadEnds.length === 0 && (
                      <p className="text-sm text-gray-500 text-center py-8">
                        No dead-end searches yet - great job!
                      </p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Productivity Tab */}
          <TabsContent value="productivity">
            <div className="grid md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Productivity Insights</CardTitle>
                  <CardDescription>Your work patterns and suggestions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-3 border rounded">
                      <div className="text-sm text-gray-600 mb-1">Most Productive Time</div>
                      <div className="text-xl font-bold">{insights?.mostProductiveTime || "N/A"}</div>
                    </div>

                    <div className="p-3 border rounded">
                      <div className="text-sm text-gray-600 mb-1">Usage Streak</div>
                      <div className="text-xl font-bold">{insights?.streak || 0} days</div>
                    </div>

                    <div className="p-3 border rounded">
                      <div className="text-sm text-gray-600 mb-1">Avg. Session Length</div>
                      <div className="text-xl font-bold">{insights?.avgSessionLength || 0} min</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Suggestions</CardTitle>
                  <CardDescription>Tips to improve your workflow</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-2">
                      {insights?.suggestions.map((suggestion, i) => (
                        <div key={i} className="p-2 border rounded bg-blue-50 border-blue-200 text-sm">
                          {suggestion}
                        </div>
                      ))}
                      {(!insights || insights.suggestions.length === 0) && (
                        <p className="text-sm text-gray-500 text-center py-4">
                          No suggestions yet - keep using DreamNet!
                        </p>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
