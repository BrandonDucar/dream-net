"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { CommandPalette } from "@/components/navigator/command-palette";
import { NavHeader } from "@/components/navigator/nav-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { 
  Plus, 
  ExternalLink, 
  Pin, 
  Edit,
  Trash2,
  Filter,
  Star,
} from "lucide-react";
import type { AppRef, ImportanceLevel } from "@/types/navigator";
import { 
  getAllApps, 
  getAllCommands,
  registerAppRef,
  updateAppRef,
  deleteApp,
  pinItem,
  logRecentItem,
} from "@/lib/navigator-service";

export default function AppsPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const selectedId = searchParams.get("id");

  const [paletteOpen, setPaletteOpen] = useState<boolean>(false);
  const [apps, setApps] = useState<AppRef[]>([]);
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [filterImportance, setFilterImportance] = useState<string>("all");
  const [filterTag, setFilterTag] = useState<string>("");
  const [createDialogOpen, setCreateDialogOpen] = useState<boolean>(false);
  const [editDialogOpen, setEditDialogOpen] = useState<boolean>(false);
  const [selectedApp, setSelectedApp] = useState<AppRef | null>(null);

  // Form state
  const [formName, setFormName] = useState<string>("");
  const [formCategory, setFormCategory] = useState<string>("");
  const [formLaunchUrl, setFormLaunchUrl] = useState<string>("");
  const [formDescription, setFormDescription] = useState<string>("");
  const [formImportance, setFormImportance] = useState<ImportanceLevel>("medium");
  const [formTags, setFormTags] = useState<string>("");
  const [formNotes, setFormNotes] = useState<string>("");

  useEffect(() => {
    loadApps();
    
    // If ID in URL, select that app
    if (selectedId) {
      const app = apps.find((a: AppRef) => a.id === selectedId);
      if (app) {
        setSelectedApp(app);
        logRecentItem("app", app.id, app.name);
      }
    }
  }, [selectedId]);

  const loadApps = (): void => {
    const allApps = getAllApps();
    setApps(allApps);
  };

  // Ctrl+K to open palette
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent): void => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setPaletteOpen(true);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const categories = [...new Set(apps.map((app: AppRef) => app.category))];
  const allTags = [...new Set(apps.flatMap((app: AppRef) => app.tags))];

  const filteredApps = apps.filter((app: AppRef) => {
    if (filterCategory !== "all" && app.category !== filterCategory) return false;
    if (filterImportance !== "all" && app.importanceLevel !== filterImportance) return false;
    if (filterTag && !app.tags.includes(filterTag)) return false;
    return true;
  });

  const handleCreate = (): void => {
    if (!formName || !formCategory || !formLaunchUrl) return;

    registerAppRef({
      name: formName,
      category: formCategory,
      launchUrl: formLaunchUrl,
      description: formDescription,
      importanceLevel: formImportance,
      tags: formTags.split(",").map((t: string) => t.trim()).filter(Boolean),
      notes: formNotes,
    });

    resetForm();
    setCreateDialogOpen(false);
    loadApps();
  };

  const handleEdit = (): void => {
    if (!selectedApp) return;

    updateAppRef(selectedApp.id, {
      name: formName,
      category: formCategory,
      launchUrl: formLaunchUrl,
      description: formDescription,
      importanceLevel: formImportance,
      tags: formTags.split(",").map((t: string) => t.trim()).filter(Boolean),
      notes: formNotes,
    });

    resetForm();
    setEditDialogOpen(false);
    loadApps();
    setSelectedApp(null);
  };

  const handleDelete = (id: string): void => {
    if (confirm("Are you sure you want to delete this app?")) {
      deleteApp(id);
      loadApps();
      if (selectedApp?.id === id) {
        setSelectedApp(null);
      }
    }
  };

  const resetForm = (): void => {
    setFormName("");
    setFormCategory("");
    setFormLaunchUrl("");
    setFormDescription("");
    setFormImportance("medium");
    setFormTags("");
    setFormNotes("");
  };

  const openEditDialog = (app: AppRef): void => {
    setSelectedApp(app);
    setFormName(app.name);
    setFormCategory(app.category);
    setFormLaunchUrl(app.launchUrl);
    setFormDescription(app.description);
    setFormImportance(app.importanceLevel);
    setFormTags(app.tags.join(", "));
    setFormNotes(app.notes);
    setEditDialogOpen(true);
  };

  const handlePinApp = (app: AppRef): void => {
    pinItem("app", app.id, app.name);
  };

  const relatedCommands = selectedApp
    ? getAllCommands().filter((cmd) => 
        cmd.primaryAppId === selectedApp.id || 
        cmd.secondaryAppIds.includes(selectedApp.id)
      )
    : [];

  return (
    <div className="min-h-screen bg-gray-50">
      <NavHeader onSearchClick={() => setPaletteOpen(true)} />
      <CommandPalette
        open={paletteOpen}
        onOpenChange={setPaletteOpen}
        onResultSelect={(result) => {
          if (result.type === "app") {
            router.push(`/apps?id=${result.id}`);
          }
        }}
      />

      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold">App Directory</h2>
            <p className="text-gray-600">Browse and manage all DreamNet apps</p>
          </div>
          <Button onClick={() => setCreateDialogOpen(true)} className="gap-2">
            <Plus className="h-4 w-4" />
            Register App
          </Button>
        </div>

        <Tabs defaultValue="list">
          <TabsList>
            <TabsTrigger value="list">List View</TabsTrigger>
            <TabsTrigger value="grid">Grid View</TabsTrigger>
          </TabsList>

          {/* Filters */}
          <div className="flex gap-3 my-4 flex-wrap">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-gray-600" />
              <span className="text-sm font-medium">Filters:</span>
            </div>
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map((cat: string) => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterImportance} onValueChange={setFilterImportance}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Importance" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterTag} onValueChange={setFilterTag}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Tag" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Tags</SelectItem>
                {allTags.map((tag: string) => (
                  <SelectItem key={tag} value={tag}>{tag}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => {
                setFilterCategory("all");
                setFilterImportance("all");
                setFilterTag("");
              }}
            >
              Clear Filters
            </Button>
          </div>

          <TabsContent value="list" className="space-y-3">
            {filteredApps.map((app: AppRef) => (
              <Card 
                key={app.id}
                className="cursor-pointer hover:border-blue-300 transition-colors"
                onClick={() => {
                  setSelectedApp(app);
                  logRecentItem("app", app.id, app.name);
                }}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="flex items-center gap-2">
                        {app.name}
                        {app.importanceLevel === "critical" && (
                          <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                        )}
                      </CardTitle>
                      <CardDescription>{app.description}</CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          handlePinApp(app);
                        }}
                      >
                        <Pin className="h-4 w-4" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          openEditDialog(app);
                        }}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(app.id);
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-2 flex-wrap mb-2">
                    <Badge variant="outline">{app.category}</Badge>
                    <Badge variant="secondary">{app.importanceLevel}</Badge>
                    {app.tags.map((tag: string) => (
                      <Badge key={tag} variant="outline">{tag}</Badge>
                    ))}
                  </div>
                  <p className="text-sm text-blue-600 flex items-center gap-1">
                    <ExternalLink className="h-3 w-3" />
                    {app.launchUrl}
                  </p>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="grid">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredApps.map((app: AppRef) => (
                <Card 
                  key={app.id}
                  className="cursor-pointer hover:border-blue-300 transition-colors"
                  onClick={() => {
                    setSelectedApp(app);
                    logRecentItem("app", app.id, app.name);
                  }}
                >
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                      {app.name}
                      {app.importanceLevel === "critical" && (
                        <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                      )}
                    </CardTitle>
                    <CardDescription className="line-clamp-2">
                      {app.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-2 flex-wrap">
                      <Badge variant="outline">{app.category}</Badge>
                      <Badge variant="secondary">{app.importanceLevel}</Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* App Detail Sidebar */}
        {selectedApp && (
          <Dialog open={!!selectedApp} onOpenChange={() => setSelectedApp(null)}>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {selectedApp.name}
                  {selectedApp.importanceLevel === "critical" && (
                    <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                  )}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Description</Label>
                  <p className="text-sm text-gray-700">{selectedApp.description}</p>
                </div>
                <div>
                  <Label>Category</Label>
                  <p className="text-sm">{selectedApp.category}</p>
                </div>
                <div>
                  <Label>Launch URL</Label>
                  <p className="text-sm text-blue-600">{selectedApp.launchUrl}</p>
                </div>
                <div>
                  <Label>Importance Level</Label>
                  <Badge>{selectedApp.importanceLevel}</Badge>
                </div>
                <div>
                  <Label>Tags</Label>
                  <div className="flex gap-2 flex-wrap">
                    {selectedApp.tags.map((tag: string) => (
                      <Badge key={tag} variant="outline">{tag}</Badge>
                    ))}
                  </div>
                </div>
                {selectedApp.notes && (
                  <div>
                    <Label>Notes</Label>
                    <p className="text-sm text-gray-700">{selectedApp.notes}</p>
                  </div>
                )}
                {relatedCommands.length > 0 && (
                  <div>
                    <Label>Related Commands</Label>
                    <div className="space-y-2 mt-2">
                      {relatedCommands.map((cmd) => (
                        <div key={cmd.id} className="p-2 border rounded text-sm">
                          {cmd.name}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button 
                  variant="outline"
                  onClick={() => handlePinApp(selectedApp)}
                >
                  <Pin className="h-4 w-4 mr-2" />
                  Pin App
                </Button>
                <Button onClick={() => openEditDialog(selectedApp)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}

        {/* Create Dialog */}
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Register New App</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Name *</Label>
                <Input value={formName} onChange={(e) => setFormName(e.target.value)} />
              </div>
              <div>
                <Label>Category *</Label>
                <Input value={formCategory} onChange={(e) => setFormCategory(e.target.value)} />
              </div>
              <div>
                <Label>Launch URL *</Label>
                <Input value={formLaunchUrl} onChange={(e) => setFormLaunchUrl(e.target.value)} />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea value={formDescription} onChange={(e) => setFormDescription(e.target.value)} />
              </div>
              <div>
                <Label>Importance Level</Label>
                <Select value={formImportance} onValueChange={(val) => setFormImportance(val as ImportanceLevel)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Tags (comma-separated)</Label>
                <Input value={formTags} onChange={(e) => setFormTags(e.target.value)} />
              </div>
              <div>
                <Label>Notes</Label>
                <Textarea value={formNotes} onChange={(e) => setFormNotes(e.target.value)} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleCreate}>Create</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Dialog */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit App</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Name *</Label>
                <Input value={formName} onChange={(e) => setFormName(e.target.value)} />
              </div>
              <div>
                <Label>Category *</Label>
                <Input value={formCategory} onChange={(e) => setFormCategory(e.target.value)} />
              </div>
              <div>
                <Label>Launch URL *</Label>
                <Input value={formLaunchUrl} onChange={(e) => setFormLaunchUrl(e.target.value)} />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea value={formDescription} onChange={(e) => setFormDescription(e.target.value)} />
              </div>
              <div>
                <Label>Importance Level</Label>
                <Select value={formImportance} onValueChange={(val) => setFormImportance(val as ImportanceLevel)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Tags (comma-separated)</Label>
                <Input value={formTags} onChange={(e) => setFormTags(e.target.value)} />
              </div>
              <div>
                <Label>Notes</Label>
                <Textarea value={formNotes} onChange={(e) => setFormNotes(e.target.value)} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleEdit}>Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
