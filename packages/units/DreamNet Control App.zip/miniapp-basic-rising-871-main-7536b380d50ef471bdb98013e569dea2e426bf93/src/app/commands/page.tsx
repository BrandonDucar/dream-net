"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { CommandPalette } from "@/components/navigator/command-palette";
import { NavHeader } from "@/components/navigator/nav-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { 
  Plus, 
  Pin, 
  Edit,
  Trash2,
  Filter,
  Star,
  ArrowRight,
  Zap,
} from "lucide-react";
import type { Command, CommandType, ImportanceLevel, AppRef } from "@/types/navigator";
import { 
  getAllCommands,
  getAllApps,
  createCommand,
  updateCommand,
  deleteCommand,
  pinItem,
  logRecentItem,
} from "@/lib/navigator-service";

export default function CommandsPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const selectedId = searchParams.get("id");

  const [paletteOpen, setPaletteOpen] = useState<boolean>(false);
  const [commands, setCommands] = useState<Command[]>([]);
  const [apps, setApps] = useState<AppRef[]>([]);
  const [filterType, setFilterType] = useState<string>("all");
  const [filterImportance, setFilterImportance] = useState<string>("all");
  const [filterApp, setFilterApp] = useState<string>("all");
  const [createDialogOpen, setCreateDialogOpen] = useState<boolean>(false);
  const [editDialogOpen, setEditDialogOpen] = useState<boolean>(false);
  const [selectedCommand, setSelectedCommand] = useState<Command | null>(null);

  // Form state
  const [formName, setFormName] = useState<string>("");
  const [formType, setFormType] = useState<CommandType>("open-app");
  const [formDescription, setFormDescription] = useState<string>("");
  const [formPrimaryApp, setFormPrimaryApp] = useState<string>("");
  const [formSecondaryApps, setFormSecondaryApps] = useState<string>("");
  const [formObjectTypes, setFormObjectTypes] = useState<string>("");
  const [formEntities, setFormEntities] = useState<string>("");
  const [formNextSteps, setFormNextSteps] = useState<string>("");
  const [formImportance, setFormImportance] = useState<ImportanceLevel>("medium");
  const [formTags, setFormTags] = useState<string>("");
  const [formNotes, setFormNotes] = useState<string>("");

  useEffect(() => {
    loadData();
    
    // If ID in URL, select that command
    if (selectedId) {
      const cmd = commands.find((c: Command) => c.id === selectedId);
      if (cmd) {
        setSelectedCommand(cmd);
        logRecentItem("command", cmd.id, cmd.name);
      }
    }
  }, [selectedId]);

  const loadData = (): void => {
    const allCommands = getAllCommands();
    const allApps = getAllApps();
    setCommands(allCommands);
    setApps(allApps);
  };

  // Ctrl+K to open palette
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent): void => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setPaletteOpen(true);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const filteredCommands = commands.filter((cmd: Command) => {
    if (filterType !== "all" && cmd.commandType !== filterType) return false;
    if (filterImportance !== "all" && cmd.importanceLevel !== filterImportance) return false;
    if (filterApp !== "all" && cmd.primaryAppId !== filterApp) return false;
    return true;
  });

  const handleCreate = (): void => {
    if (!formName || !formDescription) return;

    createCommand({
      name: formName,
      commandType: formType,
      description: formDescription,
      primaryAppId: formPrimaryApp || null,
      secondaryAppIds: formSecondaryApps.split(",").map((s: string) => s.trim()).filter(Boolean),
      relatedObjectTypes: formObjectTypes.split(",").map((s: string) => s.trim()).filter(Boolean),
      relatedEntities: formEntities.split(",").map((s: string) => s.trim()).filter(Boolean),
      recommendedNextSteps: formNextSteps.split("\n").filter(Boolean),
      importanceLevel: formImportance,
      tags: formTags.split(",").map((t: string) => t.trim()).filter(Boolean),
      notes: formNotes,
    });

    resetForm();
    setCreateDialogOpen(false);
    loadData();
  };

  const handleEdit = (): void => {
    if (!selectedCommand) return;

    updateCommand(selectedCommand.id, {
      name: formName,
      commandType: formType,
      description: formDescription,
      primaryAppId: formPrimaryApp || null,
      secondaryAppIds: formSecondaryApps.split(",").map((s: string) => s.trim()).filter(Boolean),
      relatedObjectTypes: formObjectTypes.split(",").map((s: string) => s.trim()).filter(Boolean),
      relatedEntities: formEntities.split(",").map((s: string) => s.trim()).filter(Boolean),
      recommendedNextSteps: formNextSteps.split("\n").filter(Boolean),
      importanceLevel: formImportance,
      tags: formTags.split(",").map((t: string) => t.trim()).filter(Boolean),
      notes: formNotes,
    });

    resetForm();
    setEditDialogOpen(false);
    loadData();
    setSelectedCommand(null);
  };

  const handleDelete = (id: string): void => {
    if (confirm("Are you sure you want to delete this command?")) {
      deleteCommand(id);
      loadData();
      if (selectedCommand?.id === id) {
        setSelectedCommand(null);
      }
    }
  };

  const resetForm = (): void => {
    setFormName("");
    setFormType("open-app");
    setFormDescription("");
    setFormPrimaryApp("");
    setFormSecondaryApps("");
    setFormObjectTypes("");
    setFormEntities("");
    setFormNextSteps("");
    setFormImportance("medium");
    setFormTags("");
    setFormNotes("");
  };

  const openEditDialog = (cmd: Command): void => {
    setSelectedCommand(cmd);
    setFormName(cmd.name);
    setFormType(cmd.commandType);
    setFormDescription(cmd.description);
    setFormPrimaryApp(cmd.primaryAppId || "");
    setFormSecondaryApps(cmd.secondaryAppIds.join(", "));
    setFormObjectTypes(cmd.relatedObjectTypes.join(", "));
    setFormEntities(cmd.relatedEntities.join(", "));
    setFormNextSteps(cmd.recommendedNextSteps.join("\n"));
    setFormImportance(cmd.importanceLevel);
    setFormTags(cmd.tags.join(", "));
    setFormNotes(cmd.notes);
    setEditDialogOpen(true);
  };

  const handlePinCommand = (cmd: Command): void => {
    pinItem("command", cmd.id, cmd.name);
  };

  const getAppName = (appId: string | null): string => {
    if (!appId) return "N/A";
    const app = apps.find((a: AppRef) => a.id === appId);
    return app ? app.name : "Unknown";
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavHeader onSearchClick={() => setPaletteOpen(true)} />
      <CommandPalette
        open={paletteOpen}
        onOpenChange={setPaletteOpen}
        onResultSelect={(result) => {
          if (result.type === "command") {
            router.push(`/commands?id=${result.id}`);
          }
        }}
      />

      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold">Command Library</h2>
            <p className="text-gray-600">Browse and manage all commands</p>
          </div>
          <Button onClick={() => setCreateDialogOpen(true)} className="gap-2">
            <Plus className="h-4 w-4" />
            Create Command
          </Button>
        </div>

        {/* Filters */}
        <div className="flex gap-3 mb-4 flex-wrap">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-gray-600" />
            <span className="text-sm font-medium">Filters:</span>
          </div>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="open-app">Open App</SelectItem>
              <SelectItem value="open-view">Open View</SelectItem>
              <SelectItem value="create-object">Create Object</SelectItem>
              <SelectItem value="run-routine">Run Routine</SelectItem>
              <SelectItem value="inspect">Inspect</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterImportance} onValueChange={setFilterImportance}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Importance" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Levels</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterApp} onValueChange={setFilterApp}>
            <SelectTrigger className="w-52">
              <SelectValue placeholder="App" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Apps</SelectItem>
              {apps.map((app: AppRef) => (
                <SelectItem key={app.id} value={app.id}>{app.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => {
              setFilterType("all");
              setFilterImportance("all");
              setFilterApp("all");
            }}
          >
            Clear Filters
          </Button>
        </div>

        {/* Commands List */}
        <div className="space-y-3">
          {filteredCommands.map((cmd: Command) => (
            <Card 
              key={cmd.id}
              className="cursor-pointer hover:border-blue-300 transition-colors"
              onClick={() => {
                setSelectedCommand(cmd);
                logRecentItem("command", cmd.id, cmd.name);
              }}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="h-5 w-5 text-blue-600" />
                      {cmd.name}
                      {cmd.importanceLevel === "critical" && (
                        <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                      )}
                    </CardTitle>
                    <CardDescription>{cmd.description}</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePinCommand(cmd);
                      }}
                    >
                      <Pin className="h-4 w-4" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        openEditDialog(cmd);
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(cmd.id);
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2 flex-wrap mb-2">
                  <Badge variant="outline">{cmd.commandType}</Badge>
                  <Badge variant="secondary">{cmd.importanceLevel}</Badge>
                  {cmd.tags.map((tag: string) => (
                    <Badge key={tag} variant="outline">{tag}</Badge>
                  ))}
                </div>
                <p className="text-sm text-blue-600 flex items-center gap-1">
                  <ArrowRight className="h-3 w-3" />
                  Routes to: {getAppName(cmd.primaryAppId)}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Command Detail Dialog */}
        {selectedCommand && (
          <Dialog open={!!selectedCommand} onOpenChange={() => setSelectedCommand(null)}>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-blue-600" />
                  {selectedCommand.name}
                  {selectedCommand.importanceLevel === "critical" && (
                    <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                  )}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Description</Label>
                  <p className="text-sm text-gray-700">{selectedCommand.description}</p>
                </div>
                <div>
                  <Label>Command Type</Label>
                  <Badge>{selectedCommand.commandType}</Badge>
                </div>
                <div>
                  <Label>Primary App</Label>
                  <p className="text-sm">{getAppName(selectedCommand.primaryAppId)}</p>
                </div>
                {selectedCommand.secondaryAppIds.length > 0 && (
                  <div>
                    <Label>Secondary Apps</Label>
                    <div className="flex gap-2 flex-wrap">
                      {selectedCommand.secondaryAppIds.map((appId: string) => (
                        <Badge key={appId} variant="outline">{getAppName(appId)}</Badge>
                      ))}
                    </div>
                  </div>
                )}
                {selectedCommand.relatedObjectTypes.length > 0 && (
                  <div>
                    <Label>Related Object Types</Label>
                    <div className="flex gap-2 flex-wrap">
                      {selectedCommand.relatedObjectTypes.map((type: string) => (
                        <Badge key={type} variant="outline">{type}</Badge>
                      ))}
                    </div>
                  </div>
                )}
                {selectedCommand.relatedEntities.length > 0 && (
                  <div>
                    <Label>Related Entities</Label>
                    <div className="flex gap-2 flex-wrap">
                      {selectedCommand.relatedEntities.map((entity: string) => (
                        <Badge key={entity} variant="outline">{entity}</Badge>
                      ))}
                    </div>
                  </div>
                )}
                {selectedCommand.recommendedNextSteps.length > 0 && (
                  <div>
                    <Label>Recommended Next Steps</Label>
                    <ul className="list-disc list-inside text-sm text-gray-700 space-y-1">
                      {selectedCommand.recommendedNextSteps.map((step: string, i: number) => (
                        <li key={i}>{step}</li>
                      ))}
                    </ul>
                  </div>
                )}
                <div>
                  <Label>Importance Level</Label>
                  <Badge>{selectedCommand.importanceLevel}</Badge>
                </div>
                <div>
                  <Label>Tags</Label>
                  <div className="flex gap-2 flex-wrap">
                    {selectedCommand.tags.map((tag: string) => (
                      <Badge key={tag} variant="outline">{tag}</Badge>
                    ))}
                  </div>
                </div>
                {selectedCommand.notes && (
                  <div>
                    <Label>Notes</Label>
                    <p className="text-sm text-gray-700">{selectedCommand.notes}</p>
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button 
                  variant="outline"
                  onClick={() => handlePinCommand(selectedCommand)}
                >
                  <Pin className="h-4 w-4 mr-2" />
                  Pin Command
                </Button>
                <Button onClick={() => openEditDialog(selectedCommand)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}

        {/* Create Dialog */}
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Command</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Name *</Label>
                <Input value={formName} onChange={(e) => setFormName(e.target.value)} />
              </div>
              <div>
                <Label>Command Type *</Label>
                <Select value={formType} onValueChange={(val) => setFormType(val as CommandType)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open-app">Open App</SelectItem>
                    <SelectItem value="open-view">Open View</SelectItem>
                    <SelectItem value="create-object">Create Object</SelectItem>
                    <SelectItem value="run-routine">Run Routine</SelectItem>
                    <SelectItem value="inspect">Inspect</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Description *</Label>
                <Textarea value={formDescription} onChange={(e) => setFormDescription(e.target.value)} />
              </div>
              <div>
                <Label>Primary App</Label>
                <Select value={formPrimaryApp} onValueChange={setFormPrimaryApp}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select app" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">None</SelectItem>
                    {apps.map((app: AppRef) => (
                      <SelectItem key={app.id} value={app.id}>{app.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Secondary Apps (comma-separated IDs)</Label>
                <Input value={formSecondaryApps} onChange={(e) => setFormSecondaryApps(e.target.value)} />
              </div>
              <div>
                <Label>Related Object Types (comma-separated)</Label>
                <Input value={formObjectTypes} onChange={(e) => setFormObjectTypes(e.target.value)} />
              </div>
              <div>
                <Label>Related Entities (comma-separated)</Label>
                <Input value={formEntities} onChange={(e) => setFormEntities(e.target.value)} />
              </div>
              <div>
                <Label>Recommended Next Steps (one per line)</Label>
                <Textarea 
                  value={formNextSteps} 
                  onChange={(e) => setFormNextSteps(e.target.value)}
                  rows={3}
                />
              </div>
              <div>
                <Label>Importance Level</Label>
                <Select value={formImportance} onValueChange={(val) => setFormImportance(val as ImportanceLevel)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Tags (comma-separated)</Label>
                <Input value={formTags} onChange={(e) => setFormTags(e.target.value)} />
              </div>
              <div>
                <Label>Notes</Label>
                <Textarea value={formNotes} onChange={(e) => setFormNotes(e.target.value)} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleCreate}>Create</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Dialog */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Command</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Name *</Label>
                <Input value={formName} onChange={(e) => setFormName(e.target.value)} />
              </div>
              <div>
                <Label>Command Type *</Label>
                <Select value={formType} onValueChange={(val) => setFormType(val as CommandType)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open-app">Open App</SelectItem>
                    <SelectItem value="open-view">Open View</SelectItem>
                    <SelectItem value="create-object">Create Object</SelectItem>
                    <SelectItem value="run-routine">Run Routine</SelectItem>
                    <SelectItem value="inspect">Inspect</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Description *</Label>
                <Textarea value={formDescription} onChange={(e) => setFormDescription(e.target.value)} />
              </div>
              <div>
                <Label>Primary App</Label>
                <Select value={formPrimaryApp} onValueChange={setFormPrimaryApp}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select app" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">None</SelectItem>
                    {apps.map((app: AppRef) => (
                      <SelectItem key={app.id} value={app.id}>{app.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Secondary Apps (comma-separated IDs)</Label>
                <Input value={formSecondaryApps} onChange={(e) => setFormSecondaryApps(e.target.value)} />
              </div>
              <div>
                <Label>Related Object Types (comma-separated)</Label>
                <Input value={formObjectTypes} onChange={(e) => setFormObjectTypes(e.target.value)} />
              </div>
              <div>
                <Label>Related Entities (comma-separated)</Label>
                <Input value={formEntities} onChange={(e) => setFormEntities(e.target.value)} />
              </div>
              <div>
                <Label>Recommended Next Steps (one per line)</Label>
                <Textarea 
                  value={formNextSteps} 
                  onChange={(e) => setFormNextSteps(e.target.value)}
                  rows={3}
                />
              </div>
              <div>
                <Label>Importance Level</Label>
                <Select value={formImportance} onValueChange={(val) => setFormImportance(val as ImportanceLevel)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Tags (comma-separated)</Label>
                <Input value={formTags} onChange={(e) => setFormTags(e.target.value)} />
              </div>
              <div>
                <Label>Notes</Label>
                <Textarea value={formNotes} onChange={(e) => setFormNotes(e.target.value)} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleEdit}>Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
