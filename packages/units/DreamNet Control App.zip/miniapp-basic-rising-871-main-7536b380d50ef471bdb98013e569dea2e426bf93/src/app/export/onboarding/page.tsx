"use client";

import { useState, useEffect } from "react";
import { NavHeader } from "@/components/navigator/nav-header";
import { CommandPalette } from "@/components/navigator/command-palette";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { BookOpen, Copy, Download, Check } from "lucide-react";
import { exportOnboardingGuide } from "@/lib/navigator-service";

export default function ExportOnboardingPage() {
  const [paletteOpen, setPaletteOpen] = useState<boolean>(false);
  const [guide, setGuide] = useState<string>("");
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    const onboarding = exportOnboardingGuide();
    setGuide(onboarding);
  }, []);

  // Ctrl+K to open palette
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent): void => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setPaletteOpen(true);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const handleCopy = (): void => {
    navigator.clipboard.writeText(guide);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = (): void => {
    const blob = new Blob([guide], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "dreamnet-onboarding-guide.txt";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavHeader onSearchClick={() => setPaletteOpen(true)} />
      <CommandPalette
        open={paletteOpen}
        onOpenChange={setPaletteOpen}
        onResultSelect={() => {}}
      />

      <main className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-6 w-6" />
              Export Onboarding Guide
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-600">
              This onboarding guide introduces new users to the DreamNet Navigator and explains
              how to use the command palette, apps, and key commands.
            </p>

            <Textarea
              value={guide}
              readOnly
              className="font-mono text-xs h-96"
            />

            <div className="flex gap-2">
              <Button onClick={handleCopy} className="gap-2">
                {copied ? (
                  <>
                    <Check className="h-4 w-4" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4" />
                    Copy to Clipboard
                  </>
                )}
              </Button>
              <Button onClick={handleDownload} variant="outline" className="gap-2">
                <Download className="h-4 w-4" />
                Download as File
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
