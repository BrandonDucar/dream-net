"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { CommandPalette } from "@/components/navigator/command-palette";
import { NavHeader } from "@/components/navigator/nav-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Clock, 
  Pin,
  Trash2,
  ArrowRight,
  Star,
} from "lucide-react";
import type { Pin as PinType, RecentItem } from "@/types/navigator";
import { 
  getAllPins,
  getAllRecents,
  unpinItem,
  clearRecents,
  pinStorage,
} from "@/lib/navigator-service";

export default function HistoryPage() {
  const router = useRouter();
  const [paletteOpen, setPaletteOpen] = useState<boolean>(false);
  const [pins, setPins] = useState<PinType[]>([]);
  const [recents, setRecents] = useState<RecentItem[]>([]);
  const [pinSortBy, setPinSortBy] = useState<string>("priority");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = (): void => {
    const allPins = getAllPins();
    const allRecents = getAllRecents();
    setPins(allPins);
    setRecents(allRecents);
  };

  // Ctrl+K to open palette
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent): void => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setPaletteOpen(true);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const handleUnpin = (pinId: string): void => {
    unpinItem(pinId);
    loadData();
  };

  const handleClearRecents = (): void => {
    if (confirm("Are you sure you want to clear all recent history?")) {
      clearRecents();
      loadData();
    }
  };

  const handleChangePriority = (pinId: string, newPriority: string): void => {
    pinStorage.update(pinId, { priorityLevel: newPriority as "low" | "medium" | "high" });
    loadData();
  };

  const sortedPins = [...pins].sort((a: PinType, b: PinType) => {
    if (pinSortBy === "priority") {
      const priorityOrder: Record<string, number> = { high: 3, medium: 2, low: 1 };
      return priorityOrder[b.priorityLevel] - priorityOrder[a.priorityLevel];
    } else {
      // Sort by date (newest first)
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
  });

  const handleNavigate = (item: PinType | RecentItem): void => {
    const itemType = "itemType" in item ? item.itemType : "";
    const refId = "refId" in item ? item.refId : "";

    if (itemType === "app") {
      router.push(`/apps?id=${refId}`);
    } else if (itemType === "command") {
      router.push(`/commands?id=${refId}`);
    } else if (itemType === "object") {
      router.push(`/objects?id=${refId}`);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavHeader onSearchClick={() => setPaletteOpen(true)} />
      <CommandPalette
        open={paletteOpen}
        onOpenChange={setPaletteOpen}
        onResultSelect={() => {}}
      />

      <main className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <h2 className="text-2xl font-bold">Pins & Recents</h2>
          <p className="text-gray-600">Manage your pinned items and recent activity</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Pins */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Pin className="h-5 w-5 text-blue-600" />
                    Pinned Items
                  </CardTitle>
                  <CardDescription>
                    Your favorite apps, commands, and objects
                  </CardDescription>
                </div>
                <Select value={pinSortBy} onValueChange={setPinSortBy}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="priority">Priority</SelectItem>
                    <SelectItem value="date">Date</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {pins.length === 0 ? (
                <p className="text-sm text-gray-500 py-8 text-center">
                  No pinned items yet. Pin items from any page for quick access!
                </p>
              ) : (
                <div className="space-y-3">
                  {sortedPins.map((pin: PinType) => (
                    <div
                      key={pin.id}
                      className="p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2">
                            <Pin className="h-4 w-4 text-blue-600" />
                            <span className="font-medium text-sm">{pin.label}</span>
                            <Badge variant="outline" className="text-xs">
                              {pin.itemType}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-xs text-gray-500">Priority:</span>
                            <Select 
                              value={pin.priorityLevel}
                              onValueChange={(val) => handleChangePriority(pin.id, val)}
                            >
                              <SelectTrigger className="w-24 h-7 text-xs">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="low">Low</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="high">High</SelectItem>
                              </SelectContent>
                            </Select>
                            {pin.priorityLevel === "high" && (
                              <Star className="h-3 w-3 text-yellow-500 fill-yellow-500" />
                            )}
                          </div>
                          {pin.notes && (
                            <p className="text-xs text-gray-600 mt-1">{pin.notes}</p>
                          )}
                          <p className="text-xs text-gray-400 mt-1">
                            Pinned {new Date(pin.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleNavigate(pin)}
                          >
                            <ArrowRight className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleUnpin(pin.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recents */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-gray-600" />
                    Recent Activity
                  </CardTitle>
                  <CardDescription>
                    Recently accessed items
                  </CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleClearRecents}
                >
                  Clear All
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {recents.length === 0 ? (
                <p className="text-sm text-gray-500 py-8 text-center">
                  No recent activity yet.
                </p>
              ) : (
                <div className="space-y-3">
                  {recents.map((recent: RecentItem) => (
                    <div
                      key={recent.id}
                      className="p-4 border rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                      onClick={() => handleNavigate(recent)}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-sm">{recent.label}</span>
                            <Badge variant="outline" className="text-xs">
                              {recent.itemType}
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-500">
                            {new Date(recent.openedAt).toLocaleString()}
                          </p>
                          {recent.notes && (
                            <p className="text-xs text-gray-600 mt-1">{recent.notes}</p>
                          )}
                        </div>
                        <ArrowRight className="h-4 w-4 text-gray-400 shrink-0 mt-1" />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Stats */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 border rounded-lg text-center">
                <div className="text-3xl font-bold text-blue-600">{pins.length}</div>
                <div className="text-sm text-gray-600">Pinned Items</div>
              </div>
              <div className="p-4 border rounded-lg text-center">
                <div className="text-3xl font-bold text-gray-600">{recents.length}</div>
                <div className="text-sm text-gray-600">Recent Items</div>
              </div>
              <div className="p-4 border rounded-lg text-center">
                <div className="text-3xl font-bold text-yellow-600">
                  {pins.filter((p: PinType) => p.priorityLevel === "high").length}
                </div>
                <div className="text-sm text-gray-600">High Priority Pins</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
