"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Plus, Lightbulb, FileText, Link as LinkIcon, Trash2, CheckCircle } from "lucide-react";
import {
  getInboxItems,
  captureToInbox,
  markInboxItemProcessed,
  deleteInboxItem,
  clearProcessedInboxItems,
  getInboxStats,
  initializeDefaultQuickActions,
  getQuickActions,
} from "@/lib/quick-actions-service";
import type { InboxItem } from "@/types/navigator-advanced";

export default function InboxPage() {
  const router = useRouter();
  const [items, setItems] = useState<InboxItem[]>([]);
  const [stats, setStats] = useState<ReturnType<typeof getInboxStats> | null>(null);
  const [showCaptureDialog, setShowCaptureDialog] = useState<boolean>(false);
  const [showUnprocessedOnly, setShowUnprocessedOnly] = useState<boolean>(true);
  const [newCapture, setNewCapture] = useState({
    type: "idea" as "idea" | "note" | "link" | "voice" | "screenshot",
    content: "",
    tags: "",
  });

  useEffect(() => {
    loadInbox();
    initializeDefaultQuickActions();
  }, [showUnprocessedOnly]);

  const loadInbox = (): void => {
    setItems(getInboxItems(!showUnprocessedOnly));
    setStats(getInboxStats());
  };

  const handleCapture = (): void => {
    if (!newCapture.content.trim()) return;

    captureToInbox(
      newCapture.type,
      newCapture.content,
      {},
      newCapture.tags.split(",").map((t) => t.trim()).filter(Boolean)
    );

    setShowCaptureDialog(false);
    setNewCapture({ type: "idea", content: "", tags: "" });
    loadInbox();
  };

  const handleMarkProcessed = (id: string): void => {
    markInboxItemProcessed(id);
    loadInbox();
  };

  const handleDelete = (id: string): void => {
    if (confirm("Delete this item?")) {
      deleteInboxItem(id);
      loadInbox();
    }
  };

  const handleClearProcessed = (): void => {
    if (confirm("Clear all processed items?")) {
      clearProcessedInboxItems();
      loadInbox();
    }
  };

  const getItemIcon = (type: string): JSX.Element => {
    switch (type) {
      case "idea":
        return <Lightbulb className="h-4 w-4" />;
      case "note":
        return <FileText className="h-4 w-4" />;
      case "link":
        return <LinkIcon className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="border-b bg-white">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => router.push("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <Lightbulb className="h-6 w-6" />
                  Inbox
                </h1>
                <p className="text-sm text-gray-500 mt-1">
                  Quick capture and processing center
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handleClearProcessed}>
                Clear Processed
              </Button>
              <Button size="sm" onClick={() => setShowCaptureDialog(true)}>
                <Plus className="h-4 w-4 mr-1" />
                Quick Capture
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-6">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Items</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats?.total || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Unprocessed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-600">{stats?.unprocessed || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Processed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">{stats?.processed || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Last 24h</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats?.recentCaptures || 0}</div>
            </CardContent>
          </Card>
        </div>

        {/* Filter */}
        <div className="mb-4">
          <Button
            variant={showUnprocessedOnly ? "default" : "outline"}
            size="sm"
            onClick={() => setShowUnprocessedOnly(!showUnprocessedOnly)}
          >
            {showUnprocessedOnly ? "Show All" : "Show Unprocessed Only"}
          </Button>
        </div>

        {/* Inbox Items */}
        <Card>
          <CardHeader>
            <CardTitle>Inbox Items</CardTitle>
            <CardDescription>
              {showUnprocessedOnly ? "Unprocessed items" : "All items"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px]">
              <div className="space-y-3">
                {items.map((item) => (
                  <div
                    key={item.id}
                    className={`p-4 border rounded-lg ${
                      item.processed ? "bg-gray-50 border-gray-300" : "bg-white border-blue-200"
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {getItemIcon(item.type)}
                        <Badge variant="outline">{item.type}</Badge>
                        {item.processed && (
                          <Badge variant="default" className="bg-green-600">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Processed
                          </Badge>
                        )}
                      </div>
                      <div className="flex gap-1">
                        {!item.processed && (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleMarkProcessed(item.id)}
                          >
                            <CheckCircle className="h-4 w-4 text-green-600" />
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(item.id)}
                        >
                          <Trash2 className="h-4 w-4 text-red-600" />
                        </Button>
                      </div>
                    </div>

                    <div className="text-sm mb-2 whitespace-pre-wrap">{item.content}</div>

                    {item.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-2">
                        {item.tags.map((tag) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    )}

                    <div className="text-xs text-gray-500">
                      {new Date(item.capturedAt).toLocaleString()}
                    </div>

                    {item.routedTo && (
                      <div className="text-xs text-blue-600 mt-1">
                        Routed to: {item.routedTo}
                      </div>
                    )}
                  </div>
                ))}

                {items.length === 0 && (
                  <div className="text-center py-12 text-gray-500">
                    <Lightbulb className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                    <p className="mb-2">Your inbox is empty</p>
                    <p className="text-sm">Capture ideas, notes, and links quickly</p>
                  </div>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Quick Capture Dialog */}
      <Dialog open={showCaptureDialog} onOpenChange={setShowCaptureDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Quick Capture</DialogTitle>
            <DialogDescription>
              Capture an idea, note, or link to process later
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="type">Type</Label>
              <Select
                value={newCapture.type}
                onValueChange={(value) =>
                  setNewCapture({ ...newCapture, type: value as typeof newCapture.type })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="idea">Idea</SelectItem>
                  <SelectItem value="note">Note</SelectItem>
                  <SelectItem value="link">Link</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="content">Content</Label>
              <Textarea
                id="content"
                value={newCapture.content}
                onChange={(e) => setNewCapture({ ...newCapture, content: e.target.value })}
                placeholder="What's on your mind?"
                rows={4}
              />
            </div>
            <div>
              <Label htmlFor="tags">Tags (comma-separated)</Label>
              <Input
                id="tags"
                value={newCapture.tags}
                onChange={(e) => setNewCapture({ ...newCapture, tags: e.target.value })}
                placeholder="culture, drop, important"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCaptureDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleCapture}>Capture</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
