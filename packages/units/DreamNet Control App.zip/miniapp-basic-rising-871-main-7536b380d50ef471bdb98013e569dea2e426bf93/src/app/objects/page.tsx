"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { CommandPalette } from "@/components/navigator/command-palette";
import { NavHeader } from "@/components/navigator/nav-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { 
  Plus, 
  Pin, 
  Edit,
  Trash2,
  Box,
  ArrowRight,
} from "lucide-react";
import type { ObjectShortcut, AppRef } from "@/types/navigator";
import { 
  getAllObjects,
  getAllApps,
  createObjectShortcut,
  updateObjectShortcut,
  deleteObject,
  pinItem,
  logRecentItem,
} from "@/lib/navigator-service";

export default function ObjectsPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const selectedId = searchParams.get("id");

  const [paletteOpen, setPaletteOpen] = useState<boolean>(false);
  const [objects, setObjects] = useState<ObjectShortcut[]>([]);
  const [apps, setApps] = useState<AppRef[]>([]);
  const [filterType, setFilterType] = useState<string>("all");
  const [createDialogOpen, setCreateDialogOpen] = useState<boolean>(false);
  const [editDialogOpen, setEditDialogOpen] = useState<boolean>(false);
  const [selectedObject, setSelectedObject] = useState<ObjectShortcut | null>(null);

  // Form state
  const [formObjectType, setFormObjectType] = useState<string>("");
  const [formName, setFormName] = useState<string>("");
  const [formDescription, setFormDescription] = useState<string>("");
  const [formOpenInApp, setFormOpenInApp] = useState<string>("");
  const [formInstructions, setFormInstructions] = useState<string>("");
  const [formTags, setFormTags] = useState<string>("");

  useEffect(() => {
    loadData();
    
    // If ID in URL, select that object
    if (selectedId) {
      const obj = objects.find((o: ObjectShortcut) => o.id === selectedId);
      if (obj) {
        setSelectedObject(obj);
        logRecentItem("object", obj.id, obj.name);
      }
    }
  }, [selectedId]);

  const loadData = (): void => {
    const allObjects = getAllObjects();
    const allApps = getAllApps();
    setObjects(allObjects);
    setApps(allApps);
  };

  // Ctrl+K to open palette
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent): void => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setPaletteOpen(true);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const objectTypes = [...new Set(objects.map((obj: ObjectShortcut) => obj.objectType))];

  const filteredObjects = objects.filter((obj: ObjectShortcut) => {
    if (filterType !== "all" && obj.objectType !== filterType) return false;
    return true;
  });

  const handleCreate = (): void => {
    if (!formObjectType || !formName) return;

    createObjectShortcut({
      objectType: formObjectType,
      name: formName,
      description: formDescription,
      openInAppId: formOpenInApp || null,
      openInstructions: formInstructions,
      tags: formTags.split(",").map((t: string) => t.trim()).filter(Boolean),
    });

    resetForm();
    setCreateDialogOpen(false);
    loadData();
  };

  const handleEdit = (): void => {
    if (!selectedObject) return;

    updateObjectShortcut(selectedObject.id, {
      objectType: formObjectType,
      name: formName,
      description: formDescription,
      openInAppId: formOpenInApp || null,
      openInstructions: formInstructions,
      tags: formTags.split(",").map((t: string) => t.trim()).filter(Boolean),
    });

    resetForm();
    setEditDialogOpen(false);
    loadData();
    setSelectedObject(null);
  };

  const handleDelete = (id: string): void => {
    if (confirm("Are you sure you want to delete this object shortcut?")) {
      deleteObject(id);
      loadData();
      if (selectedObject?.id === id) {
        setSelectedObject(null);
      }
    }
  };

  const resetForm = (): void => {
    setFormObjectType("");
    setFormName("");
    setFormDescription("");
    setFormOpenInApp("");
    setFormInstructions("");
    setFormTags("");
  };

  const openEditDialog = (obj: ObjectShortcut): void => {
    setSelectedObject(obj);
    setFormObjectType(obj.objectType);
    setFormName(obj.name);
    setFormDescription(obj.description);
    setFormOpenInApp(obj.openInAppId || "");
    setFormInstructions(obj.openInstructions);
    setFormTags(obj.tags.join(", "));
    setEditDialogOpen(true);
  };

  const handlePinObject = (obj: ObjectShortcut): void => {
    pinItem("object", obj.id, `${obj.objectType}: ${obj.name}`);
  };

  const getAppName = (appId: string | null): string => {
    if (!appId) return "N/A";
    const app = apps.find((a: AppRef) => a.id === appId);
    return app ? app.name : "Unknown";
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavHeader onSearchClick={() => setPaletteOpen(true)} />
      <CommandPalette
        open={paletteOpen}
        onOpenChange={setPaletteOpen}
        onResultSelect={(result) => {
          if (result.type === "object") {
            router.push(`/objects?id=${result.id}`);
          }
        }}
      />

      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold">Object Shortcuts</h2>
            <p className="text-gray-600">Quick links to tokens, drops, flows, agents, and more</p>
          </div>
          <Button onClick={() => setCreateDialogOpen(true)} className="gap-2">
            <Plus className="h-4 w-4" />
            Create Shortcut
          </Button>
        </div>

        {/* Filter */}
        <div className="flex gap-3 mb-4 flex-wrap">
          <span className="text-sm font-medium">Filter by type:</span>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Object Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {objectTypes.map((type: string) => (
                <SelectItem key={type} value={type}>{type}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setFilterType("all")}
          >
            Clear Filter
          </Button>
        </div>

        {/* Objects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredObjects.map((obj: ObjectShortcut) => (
            <Card 
              key={obj.id}
              className="cursor-pointer hover:border-blue-300 transition-colors"
              onClick={() => {
                setSelectedObject(obj);
                logRecentItem("object", obj.id, `${obj.objectType}: ${obj.name}`);
              }}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Box className="h-5 w-5 text-blue-600" />
                      {obj.name}
                    </CardTitle>
                    <CardDescription className="line-clamp-2">
                      {obj.description}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Badge variant="outline">{obj.objectType}</Badge>
                  <p className="text-xs text-blue-600 flex items-center gap-1">
                    <ArrowRight className="h-3 w-3" />
                    Opens in: {getAppName(obj.openInAppId)}
                  </p>
                  <div className="flex gap-1 flex-wrap">
                    {obj.tags.map((tag: string) => (
                      <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Object Detail Dialog */}
        {selectedObject && (
          <Dialog open={!!selectedObject} onOpenChange={() => setSelectedObject(null)}>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Box className="h-5 w-5 text-blue-600" />
                  {selectedObject.objectType}: {selectedObject.name}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Description</Label>
                  <p className="text-sm text-gray-700">{selectedObject.description}</p>
                </div>
                <div>
                  <Label>Object Type</Label>
                  <Badge>{selectedObject.objectType}</Badge>
                </div>
                <div>
                  <Label>Opens In</Label>
                  <p className="text-sm">{getAppName(selectedObject.openInAppId)}</p>
                </div>
                {selectedObject.openInstructions && (
                  <div>
                    <Label>Open Instructions</Label>
                    <p className="text-sm text-gray-700">{selectedObject.openInstructions}</p>
                  </div>
                )}
                <div>
                  <Label>Tags</Label>
                  <div className="flex gap-2 flex-wrap">
                    {selectedObject.tags.map((tag: string) => (
                      <Badge key={tag} variant="outline">{tag}</Badge>
                    ))}
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button 
                  variant="outline"
                  onClick={() => handlePinObject(selectedObject)}
                >
                  <Pin className="h-4 w-4 mr-2" />
                  Pin Shortcut
                </Button>
                <Button onClick={() => openEditDialog(selectedObject)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
                <Button 
                  variant="destructive"
                  onClick={() => handleDelete(selectedObject.id)}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}

        {/* Create Dialog */}
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Object Shortcut</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Object Type *</Label>
                <Input 
                  value={formObjectType} 
                  onChange={(e) => setFormObjectType(e.target.value)}
                  placeholder="e.g., token, drop, flow, agent"
                />
              </div>
              <div>
                <Label>Name *</Label>
                <Input 
                  value={formName} 
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g., DREAM Token"
                />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea value={formDescription} onChange={(e) => setFormDescription(e.target.value)} />
              </div>
              <div>
                <Label>Opens In (App)</Label>
                <Select value={formOpenInApp} onValueChange={setFormOpenInApp}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select app" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">None</SelectItem>
                    {apps.map((app: AppRef) => (
                      <SelectItem key={app.id} value={app.id}>{app.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Open Instructions</Label>
                <Textarea 
                  value={formInstructions} 
                  onChange={(e) => setFormInstructions(e.target.value)}
                  placeholder="How to access this object..."
                />
              </div>
              <div>
                <Label>Tags (comma-separated)</Label>
                <Input value={formTags} onChange={(e) => setFormTags(e.target.value)} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleCreate}>Create</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Dialog */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Object Shortcut</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Object Type *</Label>
                <Input 
                  value={formObjectType} 
                  onChange={(e) => setFormObjectType(e.target.value)}
                />
              </div>
              <div>
                <Label>Name *</Label>
                <Input 
                  value={formName} 
                  onChange={(e) => setFormName(e.target.value)}
                />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea value={formDescription} onChange={(e) => setFormDescription(e.target.value)} />
              </div>
              <div>
                <Label>Opens In (App)</Label>
                <Select value={formOpenInApp} onValueChange={setFormOpenInApp}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select app" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">None</SelectItem>
                    {apps.map((app: AppRef) => (
                      <SelectItem key={app.id} value={app.id}>{app.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Open Instructions</Label>
                <Textarea 
                  value={formInstructions} 
                  onChange={(e) => setFormInstructions(e.target.value)}
                />
              </div>
              <div>
                <Label>Tags (comma-separated)</Label>
                <Input value={formTags} onChange={(e) => setFormTags(e.target.value)} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleEdit}>Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
