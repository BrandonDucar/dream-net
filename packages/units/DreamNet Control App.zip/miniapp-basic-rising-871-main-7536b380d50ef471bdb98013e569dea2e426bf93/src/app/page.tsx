'use client'
import { useState, useEffect } from "react";
import { EnhancedCommandPalette } from "@/components/navigator/command-palette-enhanced";
import { NavHeader } from "@/components/navigator/nav-header";
import { SeedButton } from "@/components/navigator/seed-button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Star, 
  Clock, 
  Zap, 
  BookOpen, 
  FileText,
  ArrowRight,
  Pin,
  BarChart3,
  GitBranch,
  Lightbulb,
  Settings,
  Activity,
} from "lucide-react";
import type { HomeView, SearchResult } from "@/types/navigator";
import { getHomeView, logRecentItem, pinItem, getAllApps } from "@/lib/navigator-service";
import { useRouter } from "next/navigation";
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function HomePage() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const router = useRouter();
  const [paletteOpen, setPaletteOpen] = useState<boolean>(false);
  const [homeData, setHomeData] = useState<HomeView | null>(null);

  // Load home data
  useEffect(() => {
    loadHomeData();
  }, []);

  const loadHomeData = (): void => {
    const data = getHomeView();
    setHomeData(data);
  };

  // Ctrl+K to open palette
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent): void => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setPaletteOpen(true);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const handleResultSelect = (result: SearchResult): void => {
    // Log the selection
    logRecentItem(result.type, result.id, result.label);
    
    // Navigate based on type
    if (result.type === "app") {
      router.push(`/apps?id=${result.id}`);
    } else if (result.type === "command") {
      router.push(`/commands?id=${result.id}`);
    } else if (result.type === "object") {
      router.push(`/objects?id=${result.id}`);
    }
    
    // Reload home data
    loadHomeData();
  };

  const handlePinClick = (itemType: string, refId: string, label: string): void => {
    pinItem(itemType as "app" | "command" | "view", refId, label);
    loadHomeData();
  };

  const handleExportCommandMap = (): void => {
    router.push("/export/command-map");
  };

  const handleExportOnboarding = (): void => {
    router.push("/export/onboarding");
  };

  if (!homeData) {
    return (
      <div className="min-h-screen bg-gray-50">
        <NavHeader onSearchClick={() => setPaletteOpen(true)} />
        <div className="container mx-auto px-4 py-12">
          <p className="text-center text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <NavHeader onSearchClick={() => setPaletteOpen(true)} />
      <EnhancedCommandPalette
        open={paletteOpen}
        onOpenChange={setPaletteOpen}
        onResultSelect={handleResultSelect}
      />

      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="mb-8 text-center">
          <h2 className="text-3xl font-bold mb-2">
            Welcome to DreamNet Navigator
          </h2>
          <p className="text-gray-600 mb-4">
            Your unified command center for the DreamNet ecosystem
          </p>
          <div className="flex gap-3 justify-center">
            <Button
              onClick={() => setPaletteOpen(true)}
              size="lg"
              className="gap-2"
            >
              <Zap className="h-5 w-5" />
              Open Command Palette
            </Button>
            {getAllApps().length === 0 && <SeedButton />}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-8">
          <Button
            variant="outline"
            className="h-auto flex-col gap-2 py-4"
            onClick={() => router.push("/apps")}
          >
            <BookOpen className="h-6 w-6" />
            <div className="text-sm font-medium">Apps</div>
          </Button>
          <Button
            variant="outline"
            className="h-auto flex-col gap-2 py-4"
            onClick={() => router.push("/commands")}
          >
            <Zap className="h-6 w-6" />
            <div className="text-sm font-medium">Commands</div>
          </Button>
          <Button
            variant="outline"
            className="h-auto flex-col gap-2 py-4"
            onClick={() => router.push("/objects")}
          >
            <FileText className="h-6 w-6" />
            <div className="text-sm font-medium">Objects</div>
          </Button>
          <Button
            variant="outline"
            className="h-auto flex-col gap-2 py-4"
            onClick={() => router.push("/history")}
          >
            <Clock className="h-6 w-6" />
            <div className="text-sm font-medium">History</div>
          </Button>
          <Button
            variant="outline"
            className="h-auto flex-col gap-2 py-4"
            onClick={() => router.push("/analytics")}
          >
            <BarChart3 className="h-6 w-6" />
            <div className="text-sm font-medium">Analytics</div>
          </Button>
          <Button
            variant="outline"
            className="h-auto flex-col gap-2 py-4"
            onClick={() => router.push("/workflows")}
          >
            <GitBranch className="h-6 w-6" />
            <div className="text-sm font-medium">Workflows</div>
          </Button>
          <Button
            variant="outline"
            className="h-auto flex-col gap-2 py-4"
            onClick={() => router.push("/inbox")}
          >
            <Lightbulb className="h-6 w-6" />
            <div className="text-sm font-medium">Inbox</div>
          </Button>
          <Button
            variant="outline"
            className="h-auto flex-col gap-2 py-4"
            onClick={() => router.push("/settings")}
          >
            <Settings className="h-6 w-6" />
            <div className="text-sm font-medium">Settings</div>
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Pinned Items */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5 text-yellow-500" />
                Pinned
              </CardTitle>
              <CardDescription>
                Your favorite apps and commands
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                {homeData.pinnedItems.length === 0 ? (
                  <p className="text-sm text-gray-500 py-4">
                    No pinned items yet. Pin items for quick access!
                  </p>
                ) : (
                  <div className="space-y-2">
                    {homeData.pinnedItems.map(({ pin, details }) => (
                      <div
                        key={pin.id}
                        className="p-3 border rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <Pin className="h-3 w-3 text-blue-600" />
                              <span className="font-medium text-sm">
                                {pin.label}
                              </span>
                              <Badge variant="outline" className="text-xs">
                                {pin.itemType}
                              </Badge>
                            </div>
                            {details && "description" in details && (
                              <p className="text-xs text-gray-600 line-clamp-2">
                                {details.description}
                              </p>
                            )}
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              if (pin.itemType === "app") {
                                router.push(`/apps?id=${pin.refId}`);
                              } else if (pin.itemType === "command") {
                                router.push(`/commands?id=${pin.refId}`);
                              }
                            }}
                          >
                            <ArrowRight className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Recent Items */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-gray-600" />
                Recent
              </CardTitle>
              <CardDescription>
                Recently accessed items
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                {homeData.recentItems.length === 0 ? (
                  <p className="text-sm text-gray-500 py-4">
                    No recent activity yet.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {homeData.recentItems.map(({ recent, details }) => (
                      <div
                        key={recent.id}
                        className="p-3 border rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium text-sm">
                                {recent.label}
                              </span>
                              <Badge variant="outline" className="text-xs">
                                {recent.itemType}
                              </Badge>
                            </div>
                            <p className="text-xs text-gray-500">
                              {new Date(recent.openedAt).toLocaleString()}
                            </p>
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              if (recent.itemType === "app") {
                                router.push(`/apps?id=${recent.refId}`);
                              } else if (recent.itemType === "command") {
                                router.push(`/commands?id=${recent.refId}`);
                              }
                            }}
                          >
                            <ArrowRight className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Suggested Commands */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-blue-600" />
                Suggested Commands
              </CardTitle>
              <CardDescription>
                High-priority commands to get you started
              </CardDescription>
            </CardHeader>
            <CardContent>
              {homeData.suggestedCommands.length === 0 ? (
                <p className="text-sm text-gray-500 py-4">
                  No commands available yet. Create some to get started!
                </p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {homeData.suggestedCommands.map(({ command, app }) => (
                    <div
                      key={command.id}
                      className="p-4 border rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-all cursor-pointer"
                      onClick={() => router.push(`/commands?id=${command.id}`)}
                    >
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <h3 className="font-medium text-sm">{command.name}</h3>
                        {command.importanceLevel === "critical" && (
                          <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 shrink-0" />
                        )}
                      </div>
                      <p className="text-xs text-gray-600 mb-2 line-clamp-2">
                        {command.description}
                      </p>
                      {app && (
                        <p className="text-xs text-blue-600">→ {app.name}</p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
