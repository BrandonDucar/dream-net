"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Palette, Keyboard, Download, Upload, Trash2 } from "lucide-react";
import {
  getThemes,
  createTheme,
  activateTheme,
  deleteTheme,
  initializeDefaultThemes,
  getActiveTheme,
} from "@/lib/theme-service";
import {
  getShortcuts,
  registerShortcut,
  deleteShortcut,
  formatKeyCombo,
  initializeDefaultShortcuts,
} from "@/lib/shortcuts-service";
import {
  createBackup,
  getBackups,
  restoreFromBackup,
  deleteBackup,
  downloadBackup,
  getBackupStats,
} from "@/lib/export-import-service";
import type { ThemeConfig, KeyboardShortcut, ConfigBackup } from "@/types/navigator-advanced";

export default function SettingsPage() {
  const router = useRouter();
  const [themes, setThemes] = useState<ThemeConfig[]>([]);
  const [shortcuts, setShortcuts] = useState<KeyboardShortcut[]>([]);
  const [backups, setBackups] = useState<ConfigBackup[]>([]);
  const [backupStats, setBackupStats] = useState<ReturnType<typeof getBackupStats> | null>(null);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = (): void => {
    setThemes(getThemes());
    setShortcuts(getShortcuts());
    setBackups(getBackups());
    setBackupStats(getBackupStats());
  };

  const handleThemeChange = (themeId: string): void => {
    activateTheme(themeId);
    loadSettings();
  };

  const handleDeleteShortcut = (id: string): void => {
    if (confirm("Delete this shortcut?")) {
      deleteShortcut(id);
      loadSettings();
    }
  };

  const handleCreateBackup = (): void => {
    const name = prompt("Backup name:");
    if (name) {
      createBackup(name, `Manual backup created on ${new Date().toLocaleString()}`);
      loadSettings();
    }
  };

  const handleRestoreBackup = (backupId: string): void => {
    if (confirm("Restore this backup? This will overwrite current data.")) {
      restoreFromBackup(backupId);
      alert("Backup restored successfully!");
      loadSettings();
    }
  };

  const handleDeleteBackup = (id: string): void => {
    if (confirm("Delete this backup?")) {
      deleteBackup(id);
      loadSettings();
    }
  };

  const handleDownloadBackup = (id: string): void => {
    downloadBackup(id);
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="border-b bg-white">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => router.push("/")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Settings</h1>
              <p className="text-sm text-gray-500 mt-1">
                Customize themes, shortcuts, and manage backups
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-6">
        <Tabs defaultValue="themes" className="space-y-4">
          <TabsList>
            <TabsTrigger value="themes">Themes</TabsTrigger>
            <TabsTrigger value="shortcuts">Shortcuts</TabsTrigger>
            <TabsTrigger value="backup">Backup & Export</TabsTrigger>
          </TabsList>

          {/* Themes Tab */}
          <TabsContent value="themes" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Palette className="h-5 w-5" />
                Themes
              </h3>
              <Button
                size="sm"
                onClick={() => {
                  initializeDefaultThemes();
                  loadSettings();
                }}
              >
                Load Defaults
              </Button>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {themes.map((theme) => (
                <Card key={theme.id} className={theme.active ? "border-blue-500 border-2" : ""}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{theme.name}</CardTitle>
                      {theme.active && (
                        <Badge variant="default">Active</Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Mode:</span>
                        <Badge variant="outline">{theme.mode}</Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Accent:</span>
                        <div className="flex items-center gap-2">
                          <div
                            className="w-6 h-6 rounded border"
                            style={{ backgroundColor: theme.accentColor }}
                          />
                          <span className="font-mono text-xs">{theme.accentColor}</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Density:</span>
                        <Badge variant="secondary">{theme.layoutDensity}</Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Font Scale:</span>
                        <span className="font-medium">{theme.fontScale}x</span>
                      </div>

                      <div className="pt-3 border-t flex gap-2">
                        {!theme.active && (
                          <Button
                            size="sm"
                            onClick={() => handleThemeChange(theme.id)}
                            className="flex-1"
                          >
                            Activate
                          </Button>
                        )}
                        {!theme.active && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              if (confirm("Delete this theme?")) {
                                deleteTheme(theme.id);
                                loadSettings();
                              }
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Shortcuts Tab */}
          <TabsContent value="shortcuts" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Keyboard className="h-5 w-5" />
                Keyboard Shortcuts
              </h3>
              <Button
                size="sm"
                onClick={() => {
                  initializeDefaultShortcuts();
                  loadSettings();
                }}
              >
                Load Defaults
              </Button>
            </div>

            <Card>
              <CardContent className="pt-6">
                <ScrollArea className="h-96">
                  <div className="space-y-2">
                    {shortcuts.map((shortcut) => (
                      <div
                        key={shortcut.id}
                        className="flex items-center justify-between p-3 border rounded"
                      >
                        <div className="flex-1">
                          <div className="font-medium text-sm">{shortcut.description}</div>
                          <div className="text-xs text-gray-500 mt-1">
                            Command: {shortcut.commandId}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary" className="font-mono">
                            {formatKeyCombo(shortcut.key)}
                          </Badge>
                          {shortcut.global && (
                            <Badge variant="outline" className="text-xs">
                              Global
                            </Badge>
                          )}
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeleteShortcut(shortcut.id)}
                          >
                            <Trash2 className="h-4 w-4 text-red-600" />
                          </Button>
                        </div>
                      </div>
                    ))}
                    {shortcuts.length === 0 && (
                      <p className="text-sm text-gray-500 text-center py-8">
                        No shortcuts configured
                      </p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Backup Tab */}
          <TabsContent value="backup" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Backup & Export</h3>
              <Button size="sm" onClick={handleCreateBackup}>
                <Download className="h-4 w-4 mr-1" />
                Create Backup
              </Button>
            </div>

            {/* Stats */}
            <div className="grid md:grid-cols-3 gap-4 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Total Backups</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{backupStats?.totalBackups || 0}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Total Size</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{backupStats?.totalSize || "0 KB"}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Latest Backup</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-sm">
                    {backupStats?.newestBackup
                      ? new Date(backupStats.newestBackup).toLocaleDateString()
                      : "None"}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Backups</CardTitle>
                <CardDescription>Manage your configuration backups</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-2">
                    {backups.map((backup) => (
                      <div key={backup.id} className="p-3 border rounded">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <div className="font-medium">{backup.name}</div>
                            <div className="text-xs text-gray-500 mt-1">{backup.description}</div>
                            <div className="text-xs text-gray-400 mt-1">
                              {new Date(backup.createdAt).toLocaleString()}
                            </div>
                          </div>
                          <Badge variant="outline">{backup.version}</Badge>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleRestoreBackup(backup.id)}
                          >
                            <Upload className="h-3 w-3 mr-1" />
                            Restore
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDownloadBackup(backup.id)}
                          >
                            <Download className="h-3 w-3 mr-1" />
                            Download
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDeleteBackup(backup.id)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                    {backups.length === 0 && (
                      <p className="text-sm text-gray-500 text-center py-8">
                        No backups yet. Create your first backup!
                      </p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
