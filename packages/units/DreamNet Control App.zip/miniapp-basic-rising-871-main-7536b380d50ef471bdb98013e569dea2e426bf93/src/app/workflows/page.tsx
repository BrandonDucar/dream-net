"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Plus, Play, Pause, GitBranch, Trash2, Clock } from "lucide-react";
import {
  getWorkflows,
  createWorkflow,
  deleteWorkflow,
  startWorkflowExecution,
  getWorkflowHistory,
  getRecentExecutions,
  initializeDefaultWorkflows,
} from "@/lib/workflow-service";
import type { Workflow, WorkflowExecution } from "@/types/navigator-advanced";

export default function WorkflowsPage() {
  const router = useRouter();
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [executions, setExecutions] = useState<WorkflowExecution[]>([]);
  const [selectedWorkflow, setSelectedWorkflow] = useState<Workflow | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState<boolean>(false);
  const [newWorkflow, setNewWorkflow] = useState({
    name: "",
    description: "",
    tags: "",
  });

  useEffect(() => {
    loadWorkflows();
  }, []);

  const loadWorkflows = (): void => {
    setWorkflows(getWorkflows());
    setExecutions(getRecentExecutions(20));
  };

  const handleCreateWorkflow = (): void => {
    if (!newWorkflow.name) return;

    createWorkflow({
      name: newWorkflow.name,
      description: newWorkflow.description,
      steps: [], // Would be added via workflow builder
      triggers: [],
      tags: newWorkflow.tags.split(",").map((t) => t.trim()).filter(Boolean),
    });

    setShowCreateDialog(false);
    setNewWorkflow({ name: "", description: "", tags: "" });
    loadWorkflows();
  };

  const handleDeleteWorkflow = (id: string): void => {
    if (confirm("Are you sure you want to delete this workflow?")) {
      deleteWorkflow(id);
      loadWorkflows();
    }
  };

  const handleStartWorkflow = (workflowId: string): void => {
    const execution = startWorkflowExecution(workflowId);
    if (execution) {
      alert(`Workflow started! Execution ID: ${execution.id}`);
      loadWorkflows();
    }
  };

  const handleLoadDefaults = (): void => {
    initializeDefaultWorkflows();
    loadWorkflows();
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="border-b bg-white">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => router.push("/")}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  <GitBranch className="h-6 w-6" />
                  Workflows & Command Chaining
                </h1>
                <p className="text-sm text-gray-500 mt-1">
                  Automate sequences of commands
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handleLoadDefaults}>
                Load Defaults
              </Button>
              <Button size="sm" onClick={() => setShowCreateDialog(true)}>
                <Plus className="h-4 w-4 mr-1" />
                New Workflow
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-6">
        <Tabs defaultValue="workflows" className="space-y-4">
          <TabsList>
            <TabsTrigger value="workflows">Workflows</TabsTrigger>
            <TabsTrigger value="executions">Execution History</TabsTrigger>
          </TabsList>

          {/* Workflows Tab */}
          <TabsContent value="workflows">
            {workflows.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <GitBranch className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                  <p className="text-gray-600 mb-4">No workflows yet</p>
                  <Button onClick={handleLoadDefaults}>Load Default Workflows</Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                {workflows.map((workflow) => (
                  <Card key={workflow.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg">{workflow.name}</CardTitle>
                          <CardDescription className="mt-1">
                            {workflow.description}
                          </CardDescription>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteWorkflow(workflow.id)}
                        >
                          <Trash2 className="h-4 w-4 text-red-600" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div>
                          <div className="text-sm text-gray-600 mb-2">Steps:</div>
                          <div className="space-y-1">
                            {workflow.steps.map((step, index) => (
                              <div
                                key={step.id}
                                className="text-xs p-2 bg-gray-50 rounded border flex items-center gap-2"
                              >
                                <Badge variant="outline" className="w-6 h-6 flex items-center justify-center">
                                  {index + 1}
                                </Badge>
                                <span>{step.commandId}</span>
                                {step.waitForCompletion && (
                                  <Clock className="h-3 w-3 text-gray-500 ml-auto" />
                                )}
                              </div>
                            ))}
                          </div>
                        </div>

                        {workflow.triggers.length > 0 && (
                          <div>
                            <div className="text-sm text-gray-600 mb-2">Triggers:</div>
                            <div className="flex flex-wrap gap-1">
                              {workflow.triggers.map((trigger) => (
                                <Badge key={trigger} variant="secondary" className="text-xs">
                                  {trigger}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}

                        {workflow.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {workflow.tags.map((tag) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}

                        <div className="pt-3 border-t flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => handleStartWorkflow(workflow.id)}
                            className="flex-1"
                          >
                            <Play className="h-4 w-4 mr-1" />
                            Run
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setSelectedWorkflow(workflow)}
                            className="flex-1"
                          >
                            View History
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Executions Tab */}
          <TabsContent value="executions">
            <Card>
              <CardHeader>
                <CardTitle>Recent Executions</CardTitle>
                <CardDescription>Last 20 workflow runs</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-2">
                    {executions.map((execution) => {
                      const workflow = workflows.find((w) => w.id === execution.workflowId);
                      
                      return (
                        <div
                          key={execution.id}
                          className="p-3 border rounded flex items-center justify-between"
                        >
                          <div className="flex-1">
                            <div className="font-medium text-sm">
                              {workflow?.name || execution.workflowId}
                            </div>
                            <div className="text-xs text-gray-500">
                              {new Date(execution.startedAt).toLocaleString()}
                            </div>
                          </div>
                          <Badge
                            variant={
                              execution.status === "completed"
                                ? "default"
                                : execution.status === "failed"
                                ? "destructive"
                                : "secondary"
                            }
                          >
                            {execution.status}
                          </Badge>
                        </div>
                      );
                    })}
                    {executions.length === 0 && (
                      <p className="text-sm text-gray-500 text-center py-8">
                        No executions yet
                      </p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Create Workflow Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Workflow</DialogTitle>
            <DialogDescription>
              Define a workflow name and description. Steps can be added later.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={newWorkflow.name}
                onChange={(e) => setNewWorkflow({ ...newWorkflow, name: e.target.value })}
                placeholder="My Daily Routine"
              />
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={newWorkflow.description}
                onChange={(e) => setNewWorkflow({ ...newWorkflow, description: e.target.value })}
                placeholder="What does this workflow do?"
              />
            </div>
            <div>
              <Label htmlFor="tags">Tags (comma-separated)</Label>
              <Input
                id="tags"
                value={newWorkflow.tags}
                onChange={(e) => setNewWorkflow({ ...newWorkflow, tags: e.target.value })}
                placeholder="daily, ops, automation"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateWorkflow}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
