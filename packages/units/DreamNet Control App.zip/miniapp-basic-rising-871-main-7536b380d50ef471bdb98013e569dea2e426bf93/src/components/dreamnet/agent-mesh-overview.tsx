'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import type { AgentNode, AgentType, ImportanceLevel, AgentStatus } from '@/types/dreamnet';
import { useDreamNetStore } from '@/hooks/use-dreamnet-store';
import { Download, Plus, Search } from 'lucide-react';

interface AgentMeshOverviewProps {
  onSelectAgent: (agentId: string) => void;
  onCreateAgent: () => void;
}

export function AgentMeshOverview({ onSelectAgent, onCreateAgent }: AgentMeshOverviewProps) {
  const { store, exportAgentMeshOverview } = useDreamNetStore();
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [domainFilter, setDomainFilter] = useState<string>('all');
  const [importanceFilter, setImportanceFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filteredAgents = store.agents.filter((agent: AgentNode): boolean => {
    const matchesSearch = agent.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         agent.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         agent.archetype.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === 'all' || agent.type === typeFilter;
    const matchesDomain = domainFilter === 'all' || agent.primaryDomain === domainFilter;
    const matchesImportance = importanceFilter === 'all' || agent.importanceLevel === importanceFilter;
    const matchesStatus = statusFilter === 'all' || agent.status === statusFilter;
    
    return matchesSearch && matchesType && matchesDomain && matchesImportance && matchesStatus;
  });

  const allDomains = Array.from(new Set(store.agents.map((a: AgentNode): string => a.primaryDomain).filter(Boolean)));

  const handleExport = (): void => {
    const overview = exportAgentMeshOverview();
    const blob = new Blob([overview], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dreamnet-agent-mesh-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getTypeColor = (type: AgentType): string => {
    const colors: Record<AgentType, string> = {
      'gpt': 'bg-purple-100 text-purple-800',
      'backend-service': 'bg-blue-100 text-blue-800',
      'ohara-mini-app': 'bg-green-100 text-green-800',
      'bot': 'bg-orange-100 text-orange-800',
      'human-operator': 'bg-pink-100 text-pink-800',
      'external-integration': 'bg-yellow-100 text-yellow-800',
      'other': 'bg-gray-100 text-gray-800'
    };
    return colors[type] || colors['other'];
  };

  const getImportanceColor = (level: ImportanceLevel): string => {
    const colors: Record<ImportanceLevel, string> = {
      'low': 'bg-gray-100 text-gray-800',
      'medium': 'bg-blue-100 text-blue-800',
      'high': 'bg-orange-100 text-orange-800',
      'critical': 'bg-red-100 text-red-800'
    };
    return colors[level];
  };

  const getStatusColor = (status: AgentStatus): string => {
    const colors: Record<AgentStatus, string> = {
      'idea': 'bg-gray-100 text-gray-800',
      'planned': 'bg-yellow-100 text-yellow-800',
      'implemented': 'bg-green-100 text-green-800',
      'paused': 'bg-orange-100 text-orange-800',
      'retired': 'bg-red-100 text-red-800'
    };
    return colors[status];
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Agent Mesh Overview</h2>
          <p className="text-gray-600 mt-1">
            {filteredAgents.length} of {store.agents.length} agents
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleExport} variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export Overview
          </Button>
          <Button onClick={onCreateAgent}>
            <Plus className="h-4 w-4 mr-2" />
            Create Agent
          </Button>
        </div>
      </div>

      <Card className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search agents..."
              value={searchTerm}
              onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="gpt">GPT</SelectItem>
              <SelectItem value="backend-service">Backend Service</SelectItem>
              <SelectItem value="ohara-mini-app">Ohara Mini-App</SelectItem>
              <SelectItem value="bot">Bot</SelectItem>
              <SelectItem value="human-operator">Human Operator</SelectItem>
              <SelectItem value="external-integration">External Integration</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>

          <Select value={domainFilter} onValueChange={setDomainFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Domain" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Domains</SelectItem>
              {allDomains.map((domain: string): React.ReactElement => (
                <SelectItem key={domain} value={domain}>{domain}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={importanceFilter} onValueChange={setImportanceFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Importance" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Importance</SelectItem>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
            </SelectContent>
          </Select>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="idea">Idea</SelectItem>
              <SelectItem value="planned">Planned</SelectItem>
              <SelectItem value="implemented">Implemented</SelectItem>
              <SelectItem value="paused">Paused</SelectItem>
              <SelectItem value="retired">Retired</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Archetype</TableHead>
              <TableHead>Primary Domain</TableHead>
              <TableHead>Importance</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredAgents.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                  No agents found. Create your first agent to get started.
                </TableCell>
              </TableRow>
            ) : (
              filteredAgents.map((agent: AgentNode): React.ReactElement => (
                <TableRow 
                  key={agent.id} 
                  className="cursor-pointer hover:bg-gray-50"
                  onClick={(): void => onSelectAgent(agent.id)}
                >
                  <TableCell className="font-medium">{agent.name}</TableCell>
                  <TableCell>
                    <Badge className={getTypeColor(agent.type)}>{agent.type}</Badge>
                  </TableCell>
                  <TableCell>{agent.archetype || '-'}</TableCell>
                  <TableCell>{agent.primaryDomain || '-'}</TableCell>
                  <TableCell>
                    <Badge className={getImportanceColor(agent.importanceLevel)}>
                      {agent.importanceLevel}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(agent.status)}>{agent.status}</Badge>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
