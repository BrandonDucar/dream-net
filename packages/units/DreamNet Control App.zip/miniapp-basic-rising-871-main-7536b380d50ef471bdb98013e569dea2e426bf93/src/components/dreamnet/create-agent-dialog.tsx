'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { AgentType, ImportanceLevel } from '@/types/dreamnet';
import { useDreamNetStore } from '@/hooks/use-dreamnet-store';
import { Plus, X } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface CreateAgentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: (agentId: string) => void;
}

export function CreateAgentDialog({ open, onOpenChange, onSuccess }: CreateAgentDialogProps) {
  const { createAgentNode } = useDreamNetStore();
  const [name, setName] = useState<string>('');
  const [type, setType] = useState<AgentType>('gpt');
  const [description, setDescription] = useState<string>('');
  const [archetype, setArchetype] = useState<string>('');
  const [primaryDomain, setPrimaryDomain] = useState<string>('');
  const [secondaryDomains, setSecondaryDomains] = useState<string[]>([]);
  const [newSecondaryDomain, setNewSecondaryDomain] = useState<string>('');
  const [capabilities, setCapabilities] = useState<string[]>([]);
  const [newCapability, setNewCapability] = useState<string>('');
  const [limitations, setLimitations] = useState<string[]>([]);
  const [newLimitation, setNewLimitation] = useState<string>('');
  const [importanceLevel, setImportanceLevel] = useState<ImportanceLevel>('medium');

  const handleSubmit = (): void => {
    if (!name || !description) return;

    const agent = createAgentNode({
      name,
      type,
      description,
      archetype,
      capabilities,
      limitations,
      primaryDomain,
      secondaryDomains,
      importanceLevel
    });

    onSuccess?.(agent.id);
    handleClose();
  };

  const handleClose = (): void => {
    setName('');
    setType('gpt');
    setDescription('');
    setArchetype('');
    setPrimaryDomain('');
    setSecondaryDomains([]);
    setNewSecondaryDomain('');
    setCapabilities([]);
    setNewCapability('');
    setLimitations([]);
    setNewLimitation('');
    setImportanceLevel('medium');
    onOpenChange(false);
  };

  const addSecondaryDomain = (): void => {
    if (newSecondaryDomain.trim()) {
      setSecondaryDomains([...secondaryDomains, newSecondaryDomain.trim()]);
      setNewSecondaryDomain('');
    }
  };

  const removeSecondaryDomain = (index: number): void => {
    setSecondaryDomains(secondaryDomains.filter((_: string, i: number): boolean => i !== index));
  };

  const addCapability = (): void => {
    if (newCapability.trim()) {
      setCapabilities([...capabilities, newCapability.trim()]);
      setNewCapability('');
    }
  };

  const removeCapability = (index: number): void => {
    setCapabilities(capabilities.filter((_: string, i: number): boolean => i !== index));
  };

  const addLimitation = (): void => {
    if (newLimitation.trim()) {
      setLimitations([...limitations, newLimitation.trim()]);
      setNewLimitation('');
    }
  };

  const removeLimitation = (index: number): void => {
    setLimitations(limitations.filter((_: string, i: number): boolean => i !== index));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New Agent</DialogTitle>
          <DialogDescription>
            Define a new agent for your DreamNet mesh.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label htmlFor="name">Name *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setName(e.target.value)}
              placeholder="e.g., DreamNet Core GPT"
            />
          </div>

          <div>
            <Label htmlFor="type">Type *</Label>
            <Select value={type} onValueChange={(value: string): void => setType(value as AgentType)}>
              <SelectTrigger id="type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="gpt">GPT</SelectItem>
                <SelectItem value="backend-service">Backend Service</SelectItem>
                <SelectItem value="ohara-mini-app">Ohara Mini-App</SelectItem>
                <SelectItem value="bot">Bot</SelectItem>
                <SelectItem value="human-operator">Human Operator</SelectItem>
                <SelectItem value="external-integration">External Integration</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>): void => setDescription(e.target.value)}
              placeholder="What does this agent do?"
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="archetype">Archetype</Label>
            <Input
              id="archetype"
              value={archetype}
              onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setArchetype(e.target.value)}
              placeholder="e.g., planner, executor, watcher, healer"
            />
          </div>

          <div>
            <Label htmlFor="primaryDomain">Primary Domain</Label>
            <Input
              id="primaryDomain"
              value={primaryDomain}
              onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setPrimaryDomain(e.target.value)}
              placeholder="e.g., culture, drops, social, ops"
            />
          </div>

          <div>
            <Label>Secondary Domains</Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newSecondaryDomain}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setNewSecondaryDomain(e.target.value)}
                placeholder="Add secondary domain"
                onKeyPress={(e: React.KeyboardEvent): void => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addSecondaryDomain();
                  }
                }}
              />
              <Button type="button" onClick={addSecondaryDomain} size="sm">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {secondaryDomains.map((domain: string, index: number): React.ReactElement => (
                <Badge key={index} variant="secondary">
                  {domain}
                  <button
                    onClick={(): void => removeSecondaryDomain(index)}
                    className="ml-2 hover:text-red-600"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>

          <div>
            <Label>Capabilities</Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newCapability}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setNewCapability(e.target.value)}
                placeholder="Add capability"
                onKeyPress={(e: React.KeyboardEvent): void => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addCapability();
                  }
                }}
              />
              <Button type="button" onClick={addCapability} size="sm">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <div className="space-y-1">
              {capabilities.map((cap: string, index: number): React.ReactElement => (
                <div key={index} className="flex items-center gap-2 text-sm">
                  <span>• {cap}</span>
                  <button
                    onClick={(): void => removeCapability(index)}
                    className="ml-auto text-red-600 hover:text-red-700"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label>Limitations</Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newLimitation}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setNewLimitation(e.target.value)}
                placeholder="Add limitation"
                onKeyPress={(e: React.KeyboardEvent): void => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addLimitation();
                  }
                }}
              />
              <Button type="button" onClick={addLimitation} size="sm">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <div className="space-y-1">
              {limitations.map((lim: string, index: number): React.ReactElement => (
                <div key={index} className="flex items-center gap-2 text-sm">
                  <span>• {lim}</span>
                  <button
                    onClick={(): void => removeLimitation(index)}
                    className="ml-auto text-red-600 hover:text-red-700"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="importanceLevel">Importance Level</Label>
            <Select value={importanceLevel} onValueChange={(value: string): void => setImportanceLevel(value as ImportanceLevel)}>
              <SelectTrigger id="importanceLevel">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={!name || !description}>
            Create Agent
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
