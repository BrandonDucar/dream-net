"use client";

import { useState, useEffect } from "react";
import { Search, Terminal, ArrowRight, Star, Lightbulb, Zap, Clock } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { SearchResult } from "@/types/navigator";
import { enhancedSearch } from "@/lib/navigator-search-enhanced";
import { logRecentItem } from "@/lib/navigator-service";
import { logSearchQuery } from "@/lib/analytics-service";

interface CommandPaletteProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onResultSelect?: (result: SearchResult) => void;
}

export function EnhancedCommandPalette({
  open,
  onOpenChange,
  onResultSelect,
}: CommandPaletteProps) {
  const [query, setQuery] = useState<string>("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [corrections, setCorrections] = useState<string[]>([]);
  const [intent, setIntent] = useState<{ intent: string | null; action: string | null; object: string | null }>({
    intent: null,
    action: null,
    object: null,
  });
  const [contextSuggestions, setContextSuggestions] = useState<string[]>([]);
  const [selectedIndex, setSelectedIndex] = useState<number>(0);
  const [searchId, setSearchId] = useState<string>("");
  const [searchStartTime, setSearchStartTime] = useState<number>(0);

  // Enhanced search whenever query changes
  useEffect(() => {
    const searchResult = enhancedSearch(query);
    setResults(searchResult.results);
    setCorrections(searchResult.corrections);
    setIntent(searchResult.intent);
    setContextSuggestions(searchResult.contextSuggestions);
    setSearchId(searchResult.searchId);
    setSearchStartTime(searchResult.searchStartTime);
    setSelectedIndex(0);
  }, [query]);

  // Reset when dialog opens
  useEffect(() => {
    if (open) {
      setQuery("");
      setSelectedIndex(0);
    }
  }, [open]);

  const handleSelect = (result: SearchResult): void => {
    // Calculate time to select
    const timeToSelect = Date.now() - searchStartTime;

    // Log selection in analytics
    logSearchQuery(query, results.length, result.id, result.type, timeToSelect);

    // Log as recent
    logRecentItem(result.type, result.id, result.label);

    // Notify parent
    if (onResultSelect) {
      onResultSelect(result);
    }

    // Close dialog
    onOpenChange(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent): void => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % results.length);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + results.length) % results.length);
    } else if (e.key === "Enter" && results.length > 0) {
      e.preventDefault();
      handleSelect(results[selectedIndex]);
    }
  };

  const handleCorrectionClick = (correction: string): void => {
    setQuery(correction);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl p-0">
        <DialogHeader className="border-b px-4 py-3">
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Terminal className="h-5 w-5" />
            DreamNet Command Palette
            {intent.intent && (
              <Badge variant="secondary" className="ml-2 text-xs">
                <Lightbulb className="h-3 w-3 mr-1" />
                {intent.intent}
              </Badge>
            )}
          </DialogTitle>
        </DialogHeader>

        <div className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a command, app, or object... (try natural language!)"
              className="pl-10"
              autoFocus
            />
          </div>

          {/* Intent Display */}
          {intent.action && intent.object && (
            <div className="mt-2 text-xs text-blue-600 flex items-center gap-2">
              <Zap className="h-3 w-3" />
              Understanding: {intent.action} {intent.object}
            </div>
          )}

          {/* Typo Corrections */}
          {corrections.length > 0 && (
            <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-xs text-yellow-800 mb-1">Did you mean:</p>
              <div className="flex flex-wrap gap-1">
                {corrections.map((correction) => (
                  <button
                    key={correction}
                    onClick={() => handleCorrectionClick(correction)}
                    className="text-xs px-2 py-1 bg-white border border-yellow-300 rounded hover:bg-yellow-100 transition-colors"
                  >
                    {correction}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Context Suggestions */}
          {!query && contextSuggestions.length > 0 && (
            <div className="mt-2 p-2 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-xs text-blue-800 flex items-center gap-1">
                <Clock className="h-3 w-3" />
                Suggested for this time
              </p>
            </div>
          )}
        </div>

        <ScrollArea className="max-h-96">
          <div className="px-2 pb-4">
            {results.length === 0 ? (
              <div className="py-8 text-center">
                <p className="text-sm text-gray-500 mb-2">
                  {query
                    ? "No results found. Try different keywords or check suggestions."
                    : "Start typing to search across apps, commands, and objects"}
                </p>
                {!query && (
                  <p className="text-xs text-gray-400 mt-2">
                    💡 Try natural language like "I want to create a drop" or "help me with agents"
                  </p>
                )}
              </div>
            ) : (
              <div className="space-y-1">
                {results.map((result: SearchResult, index: number) => {
                  const isContextSuggested = contextSuggestions.includes(result.id);
                  
                  return (
                    <button
                      key={result.id}
                      onClick={() => handleSelect(result)}
                      className={`w-full rounded-lg p-3 text-left transition-all ${
                        index === selectedIndex
                          ? "bg-blue-50 border-2 border-blue-300 shadow-sm"
                          : "hover:bg-gray-50 border border-transparent"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <span className="font-medium text-sm">
                              {result.label}
                            </span>
                            <Badge
                              variant="outline"
                              className="text-xs shrink-0"
                            >
                              {result.type}
                            </Badge>
                            {result.importanceLevel === "critical" && (
                              <Star className="h-3 w-3 text-yellow-500 fill-yellow-500" />
                            )}
                            {isContextSuggested && (
                              <Badge variant="secondary" className="text-xs">
                                <Clock className="h-3 w-3 mr-1" />
                                Suggested
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-gray-600 line-clamp-2">
                            {result.description}
                          </p>
                          {result.primaryAppName && (
                            <p className="text-xs text-blue-600 mt-1 flex items-center gap-1">
                              <ArrowRight className="h-3 w-3" />
                              {result.primaryAppName}
                            </p>
                          )}
                          {result.tags && result.tags.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-2">
                              {result.tags.slice(0, 3).map((tag) => (
                                <span
                                  key={tag}
                                  className="text-xs px-1.5 py-0.5 bg-gray-100 text-gray-600 rounded"
                                >
                                  {tag}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                        <div className="text-xs text-gray-400 shrink-0">
                          Score: {Math.round(result.score)}
                        </div>
                      </div>
                      {result.instructions.length > 0 && (
                        <div className="mt-2 text-xs text-gray-500 border-t pt-2">
                          <span className="font-medium">Next step:</span> {result.instructions[0]}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </ScrollArea>

        <div className="border-t px-4 py-2 text-xs text-gray-500">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <span>↑↓ Navigate</span>
              <span>Enter Select</span>
              <span>Esc Close</span>
            </div>
            <span className="text-gray-400">
              {results.length} result{results.length !== 1 ? "s" : ""}
            </span>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
