"use client";

import { useState, useEffect } from "react";
import { Search, Terminal, ArrowRight, Star } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { SearchResult } from "@/types/navigator";
import { getCommandPaletteSuggestions } from "@/lib/navigator-search";
import { logRecentItem } from "@/lib/navigator-service";

interface CommandPaletteProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onResultSelect?: (result: SearchResult) => void;
}

export function CommandPalette({
  open,
  onOpenChange,
  onResultSelect,
}: CommandPaletteProps) {
  const [query, setQuery] = useState<string>("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [selectedIndex, setSelectedIndex] = useState<number>(0);

  // Search whenever query changes
  useEffect(() => {
    const suggestions = getCommandPaletteSuggestions(query);
    setResults(suggestions);
    setSelectedIndex(0);
  }, [query]);

  // Reset when dialog opens
  useEffect(() => {
    if (open) {
      setQuery("");
      setSelectedIndex(0);
    }
  }, [open]);

  const handleSelect = (result: SearchResult): void => {
    // Log as recent
    logRecentItem(result.type, result.id, result.label);

    // Notify parent
    if (onResultSelect) {
      onResultSelect(result);
    }

    // Close dialog
    onOpenChange(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent): void => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % results.length);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + results.length) % results.length);
    } else if (e.key === "Enter" && results.length > 0) {
      e.preventDefault();
      handleSelect(results[selectedIndex]);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl p-0">
        <DialogHeader className="border-b px-4 py-3">
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Terminal className="h-5 w-5" />
            DreamNet Command Palette
          </DialogTitle>
        </DialogHeader>

        <div className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a command, app, or object..."
              className="pl-10"
              autoFocus
            />
          </div>
        </div>

        <ScrollArea className="max-h-96">
          <div className="px-2 pb-4">
            {results.length === 0 ? (
              <div className="py-8 text-center text-sm text-gray-500">
                {query
                  ? "No results found. Try a different search."
                  : "Start typing to search..."}
              </div>
            ) : (
              <div className="space-y-1">
                {results.map((result: SearchResult, index: number) => (
                  <button
                    key={result.id}
                    onClick={() => handleSelect(result)}
                    className={`w-full rounded-lg p-3 text-left transition-colors ${
                      index === selectedIndex
                        ? "bg-blue-50 border border-blue-200"
                        : "hover:bg-gray-50 border border-transparent"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm">
                            {result.label}
                          </span>
                          <Badge
                            variant="outline"
                            className="text-xs shrink-0"
                          >
                            {result.type}
                          </Badge>
                          {result.importanceLevel === "critical" && (
                            <Star className="h-3 w-3 text-yellow-500 fill-yellow-500" />
                          )}
                        </div>
                        <p className="text-xs text-gray-600 line-clamp-1">
                          {result.description}
                        </p>
                        {result.primaryAppName && (
                          <p className="text-xs text-blue-600 mt-1">
                            → {result.primaryAppName}
                          </p>
                        )}
                      </div>
                      <ArrowRight className="h-4 w-4 text-gray-400 shrink-0 mt-1" />
                    </div>
                    {result.instructions.length > 0 && (
                      <div className="mt-2 text-xs text-gray-500 border-t pt-2">
                        Next: {result.instructions[0]}
                      </div>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>
        </ScrollArea>

        <div className="border-t px-4 py-2 text-xs text-gray-500">
          <div className="flex items-center justify-between">
            <span>↑↓ Navigate • Enter Select • Esc Close</span>
            <span className="text-gray-400">
              {results.length} result{results.length !== 1 ? "s" : ""}
            </span>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
