"use client";

import { Terminal, Search } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

interface NavHeaderProps {
  onSearchClick: () => void;
}

export function NavHeader({ onSearchClick }: NavHeaderProps) {
  return (
    <header className="border-b bg-white sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 hover:opacity-80">
            <Terminal className="h-6 w-6 text-blue-600" />
            <div>
              <h1 className="text-lg font-bold">DreamNet Navigator</h1>
              <p className="text-xs text-gray-600">Command Center</p>
            </div>
          </Link>

          <Button
            onClick={onSearchClick}
            variant="outline"
            className="gap-2"
          >
            <Search className="h-4 w-4" />
            Command Palette
            <kbd className="ml-2 rounded bg-gray-100 px-2 py-0.5 text-xs">
              Ctrl+K
            </kbd>
          </Button>
        </div>

        <nav className="flex gap-1 mt-3">
          <Link href="/">
            <Button variant="ghost" size="sm">
              Home
            </Button>
          </Link>
          <Link href="/apps">
            <Button variant="ghost" size="sm">
              Apps
            </Button>
          </Link>
          <Link href="/commands">
            <Button variant="ghost" size="sm">
              Commands
            </Button>
          </Link>
          <Link href="/objects">
            <Button variant="ghost" size="sm">
              Objects
            </Button>
          </Link>
          <Link href="/history">
            <Button variant="ghost" size="sm">
              History
            </Button>
          </Link>
        </nav>
      </div>
    </header>
  );
}
