"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Database, Check } from "lucide-react";
import { seedNavigatorData } from "@/lib/navigator-seed";

export function SeedButton() {
  const [seeded, setSeeded] = useState<boolean>(false);

  const handleSeed = (): void => {
    seedNavigatorData();
    setSeeded(true);
    setTimeout(() => {
      window.location.reload();
    }, 500);
  };

  if (seeded) {
    return (
      <Button disabled className="gap-2">
        <Check className="h-4 w-4" />
        Data Loaded!
      </Button>
    );
  }

  return (
    <Button onClick={handleSeed} variant="outline" className="gap-2">
      <Database className="h-4 w-4" />
      Load Sample Data
    </Button>
  );
}
