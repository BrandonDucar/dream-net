'use client';

// DreamNet Agent Mesh & Taskboard - Data Store Hook

import { useState, useEffect, useCallback } from 'react';
import type {
  DreamNetStore,
  AgentNode,
  AgentInterface,
  TaskType,
  TaskInstance,
  Routine,
  AgentLink,
  AgentType,
  ImportanceLevel,
  AgentStatus,
  InterfaceType,
  FrequencyHint,
  PriorityLevel,
  TaskStatus,
  RoutineFrequency,
  RelationKind,
  LinkStrength
} from '@/types/dreamnet';
import { generateId, generateSlug, generateSEO } from '@/lib/dreamnet-utils';

const STORAGE_KEY = 'dreamnet-store';

const initialStore: DreamNetStore = {
  agents: [],
  interfaces: [],
  taskTypes: [],
  taskInstances: [],
  routines: [],
  agentLinks: []
};

export function useDreamNetStore() {
  const [store, setStore] = useState<DreamNetStore>(initialStore);
  const [isLoaded, setIsLoaded] = useState<boolean>(false);

  // Load from localStorage
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setStore(JSON.parse(stored));
      } catch (e) {
        console.error('Failed to parse stored data', e);
      }
    }
    setIsLoaded(true);
  }, []);

  // Save to localStorage
  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
    }
  }, [store, isLoaded]);

  // ==================== AGENT NODE ====================

  const createAgentNode = useCallback((data: {
    name: string;
    type: AgentType;
    description: string;
    archetype?: string;
    capabilities?: string[];
    limitations?: string[];
    primaryDomain?: string;
    secondaryDomains?: string[];
    importanceLevel?: ImportanceLevel;
  }): AgentNode => {
    const agent: AgentNode = {
      id: generateId(),
      name: data.name,
      slug: generateSlug(data.name),
      type: data.type,
      description: data.description,
      archetype: data.archetype || '',
      capabilities: data.capabilities || [],
      limitations: data.limitations || [],
      primaryDomain: data.primaryDomain || '',
      secondaryDomains: data.secondaryDomains || [],
      importanceLevel: data.importanceLevel || 'medium',
      status: 'idea',
      notes: '',
      seo: generateSEO(data.name, data.description, 'agent')
    };

    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      agents: [...prev.agents, agent]
    }));

    return agent;
  }, []);

  const updateAgentNode = useCallback((id: string, updates: Partial<AgentNode>): void => {
    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      agents: prev.agents.map((a: AgentNode): AgentNode => 
        a.id === id ? { ...a, ...updates } : a
      )
    }));
  }, []);

  const deleteAgentNode = useCallback((id: string): void => {
    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      agents: prev.agents.filter((a: AgentNode): boolean => a.id !== id),
      interfaces: prev.interfaces.filter((i: AgentInterface): boolean => i.agentId !== id),
      agentLinks: prev.agentLinks.filter((l: AgentLink): boolean => 
        l.fromAgentId !== id && l.toAgentId !== id
      )
    }));
  }, []);

  // ==================== AGENT INTERFACE ====================

  const createAgentInterface = useCallback((data: {
    agentId: string;
    interfaceType: InterfaceType;
    endpointOrIdentifier: string;
    description: string;
  }): AgentInterface => {
    const agentInterface: AgentInterface = {
      id: generateId(),
      agentId: data.agentId,
      interfaceType: data.interfaceType,
      endpointOrIdentifier: data.endpointOrIdentifier,
      description: data.description,
      notes: ''
    };

    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      interfaces: [...prev.interfaces, agentInterface]
    }));

    return agentInterface;
  }, []);

  const updateAgentInterface = useCallback((id: string, updates: Partial<AgentInterface>): void => {
    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      interfaces: prev.interfaces.map((i: AgentInterface): AgentInterface => 
        i.id === id ? { ...i, ...updates } : i
      )
    }));
  }, []);

  const deleteAgentInterface = useCallback((id: string): void => {
    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      interfaces: prev.interfaces.filter((i: AgentInterface): boolean => i.id !== id)
    }));
  }, []);

  // ==================== TASK TYPE ====================

  const createTaskType = useCallback((data: {
    name: string;
    code: string;
    description: string;
    category: string;
    defaultOwnerAgentIds?: string[];
    expectedInputs?: string[];
    expectedOutputs?: string[];
    frequencyHint?: FrequencyHint;
    tags?: string[];
  }): TaskType => {
    const taskType: TaskType = {
      id: generateId(),
      name: data.name,
      code: data.code,
      description: data.description,
      category: data.category,
      defaultOwnerAgentIds: data.defaultOwnerAgentIds || [],
      expectedInputs: data.expectedInputs || [],
      expectedOutputs: data.expectedOutputs || [],
      frequencyHint: data.frequencyHint || 'ad-hoc',
      tags: data.tags || [],
      notes: '',
      seo: generateSEO(data.name, data.description, 'task')
    };

    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      taskTypes: [...prev.taskTypes, taskType]
    }));

    return taskType;
  }, []);

  const updateTaskType = useCallback((id: string, updates: Partial<TaskType>): void => {
    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      taskTypes: prev.taskTypes.map((t: TaskType): TaskType => 
        t.id === id ? { ...t, ...updates } : t
      )
    }));
  }, []);

  const deleteTaskType = useCallback((id: string): void => {
    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      taskTypes: prev.taskTypes.filter((t: TaskType): boolean => t.id !== id)
    }));
  }, []);

  // ==================== TASK INSTANCE ====================

  const createTaskInstance = useCallback((data: {
    taskTypeId: string;
    title: string;
    description: string;
    ownerAgentId?: string | null;
    participants?: string[];
    priorityLevel?: PriorityLevel;
    dueAt?: string | null;
    relatedObjectRefs?: Record<string, string>;
  }): TaskInstance => {
    const now = new Date().toISOString();
    const taskInstance: TaskInstance = {
      id: generateId(),
      taskTypeId: data.taskTypeId,
      title: data.title,
      description: data.description,
      ownerAgentId: data.ownerAgentId || null,
      participants: data.participants || [],
      priorityLevel: data.priorityLevel || 'medium',
      status: 'planned',
      dueAt: data.dueAt || null,
      createdAt: now,
      updatedAt: now,
      relatedObjectRefs: data.relatedObjectRefs || {},
      notes: ''
    };

    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      taskInstances: [...prev.taskInstances, taskInstance]
    }));

    return taskInstance;
  }, []);

  const updateTaskInstance = useCallback((id: string, updates: Partial<TaskInstance>): void => {
    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      taskInstances: prev.taskInstances.map((t: TaskInstance): TaskInstance => 
        t.id === id 
          ? { ...t, ...updates, updatedAt: new Date().toISOString() } 
          : t
      )
    }));
  }, []);

  const deleteTaskInstance = useCallback((id: string): void => {
    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      taskInstances: prev.taskInstances.filter((t: TaskInstance): boolean => t.id !== id)
    }));
  }, []);

  // ==================== ROUTINE ====================

  const createRoutine = useCallback((data: {
    name: string;
    description: string;
    frequency: RoutineFrequency;
    ownerAgentId?: string | null;
    stepTaskTypeIds?: string[];
    tags?: string[];
  }): Routine => {
    const routine: Routine = {
      id: generateId(),
      name: data.name,
      description: data.description,
      frequency: data.frequency,
      ownerAgentId: data.ownerAgentId || null,
      stepTaskTypeIds: data.stepTaskTypeIds || [],
      tags: data.tags || [],
      notes: ''
    };

    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      routines: [...prev.routines, routine]
    }));

    return routine;
  }, []);

  const updateRoutine = useCallback((id: string, updates: Partial<Routine>): void => {
    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      routines: prev.routines.map((r: Routine): Routine => 
        r.id === id ? { ...r, ...updates } : r
      )
    }));
  }, []);

  const deleteRoutine = useCallback((id: string): void => {
    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      routines: prev.routines.filter((r: Routine): boolean => r.id !== id)
    }));
  }, []);

  // ==================== AGENT LINK ====================

  const createAgentLink = useCallback((data: {
    fromAgentId: string;
    toAgentId: string;
    relationKind: RelationKind;
    strength: LinkStrength;
    description: string;
  }): AgentLink => {
    const link: AgentLink = {
      id: generateId(),
      fromAgentId: data.fromAgentId,
      toAgentId: data.toAgentId,
      relationKind: data.relationKind,
      description: data.description,
      strength: data.strength,
      notes: ''
    };

    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      agentLinks: [...prev.agentLinks, link]
    }));

    return link;
  }, []);

  const updateAgentLink = useCallback((id: string, updates: Partial<AgentLink>): void => {
    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      agentLinks: prev.agentLinks.map((l: AgentLink): AgentLink => 
        l.id === id ? { ...l, ...updates } : l
      )
    }));
  }, []);

  const deleteAgentLink = useCallback((id: string): void => {
    setStore((prev: DreamNetStore): DreamNetStore => ({
      ...prev,
      agentLinks: prev.agentLinks.filter((l: AgentLink): boolean => l.id !== id)
    }));
  }, []);

  // ==================== QUERY FUNCTIONS ====================

  const getAgentById = useCallback((id: string): AgentNode | undefined => {
    return store.agents.find((a: AgentNode): boolean => a.id === id);
  }, [store.agents]);

  const getTaskTypeById = useCallback((id: string): TaskType | undefined => {
    return store.taskTypes.find((t: TaskType): boolean => t.id === id);
  }, [store.taskTypes]);

  const getTaskInstanceById = useCallback((id: string): TaskInstance | undefined => {
    return store.taskInstances.find((t: TaskInstance): boolean => t.id === id);
  }, [store.taskInstances]);

  const getRoutineById = useCallback((id: string): Routine | undefined => {
    return store.routines.find((r: Routine): boolean => r.id === id);
  }, [store.routines]);

  const getInterfacesByAgentId = useCallback((agentId: string): AgentInterface[] => {
    return store.interfaces.filter((i: AgentInterface): boolean => i.agentId === agentId);
  }, [store.interfaces]);

  const getLinksByAgentId = useCallback((agentId: string): AgentLink[] => {
    return store.agentLinks.filter((l: AgentLink): boolean => 
      l.fromAgentId === agentId || l.toAgentId === agentId
    );
  }, [store.agentLinks]);

  const getTaskTypesByAgentId = useCallback((agentId: string): TaskType[] => {
    return store.taskTypes.filter((t: TaskType): boolean => 
      t.defaultOwnerAgentIds.includes(agentId)
    );
  }, [store.taskTypes]);

  const getTaskInstancesByAgentId = useCallback((agentId: string): TaskInstance[] => {
    return store.taskInstances.filter((t: TaskInstance): boolean => 
      t.ownerAgentId === agentId
    );
  }, [store.taskInstances]);

  const getRoutinesByAgentId = useCallback((agentId: string): Routine[] => {
    return store.routines.filter((r: Routine): boolean => 
      r.ownerAgentId === agentId
    );
  }, [store.routines]);

  // ==================== GENERATION FUNCTIONS ====================

  const generateAgentPlaybook = useCallback((agentId: string): string => {
    const agent = getAgentById(agentId);
    if (!agent) return 'Agent not found';

    const interfaces = getInterfacesByAgentId(agentId);
    const links = getLinksByAgentId(agentId);
    const taskTypes = getTaskTypesByAgentId(agentId);
    const taskInstances = getTaskInstancesByAgentId(agentId);
    const routines = getRoutinesByAgentId(agentId);

    let playbook = `═══════════════════════════════════════════════════\n`;
    playbook += `AGENT PLAYBOOK: ${agent.name.toUpperCase()}\n`;
    playbook += `═══════════════════════════════════════════════════\n\n`;

    playbook += `IDENTITY\n`;
    playbook += `───────────────────────────────────────────────────\n`;
    playbook += `Type: ${agent.type}\n`;
    playbook += `Archetype: ${agent.archetype}\n`;
    playbook += `Primary Domain: ${agent.primaryDomain}\n`;
    playbook += `Secondary Domains: ${agent.secondaryDomains.join(', ')}\n`;
    playbook += `Importance: ${agent.importanceLevel}\n`;
    playbook += `Status: ${agent.status}\n\n`;

    playbook += `DESCRIPTION\n`;
    playbook += `───────────────────────────────────────────────────\n`;
    playbook += `${agent.description}\n\n`;

    playbook += `CAPABILITIES\n`;
    playbook += `───────────────────────────────────────────────────\n`;
    agent.capabilities.forEach((cap: string): void => {
      playbook += `• ${cap}\n`;
    });
    playbook += `\n`;

    playbook += `LIMITATIONS\n`;
    playbook += `───────────────────────────────────────────────────\n`;
    agent.limitations.forEach((lim: string): void => {
      playbook += `• ${lim}\n`;
    });
    playbook += `\n`;

    playbook += `INTERFACES\n`;
    playbook += `───────────────────────────────────────────────────\n`;
    interfaces.forEach((iface: AgentInterface): void => {
      playbook += `[${iface.interfaceType}] ${iface.endpointOrIdentifier}\n`;
      playbook += `  ${iface.description}\n\n`;
    });

    playbook += `RELATIONSHIPS\n`;
    playbook += `───────────────────────────────────────────────────\n`;
    links.forEach((link: AgentLink): void => {
      const otherAgentId = link.fromAgentId === agentId ? link.toAgentId : link.fromAgentId;
      const otherAgent = getAgentById(otherAgentId);
      const direction = link.fromAgentId === agentId ? '→' : '←';
      playbook += `${direction} [${link.relationKind}] ${otherAgent?.name || 'Unknown'} (${link.strength})\n`;
      playbook += `  ${link.description}\n\n`;
    });

    playbook += `TYPICAL TASKS\n`;
    playbook += `───────────────────────────────────────────────────\n`;
    taskTypes.forEach((tt: TaskType): void => {
      playbook += `[${tt.code}] ${tt.name}\n`;
      playbook += `  Category: ${tt.category} | Frequency: ${tt.frequencyHint}\n`;
      playbook += `  ${tt.description}\n\n`;
    });

    playbook += `CURRENT ASSIGNMENTS (${taskInstances.length})\n`;
    playbook += `───────────────────────────────────────────────────\n`;
    taskInstances.slice(0, 10).forEach((ti: TaskInstance): void => {
      playbook += `[${ti.status}] ${ti.title} (${ti.priorityLevel})\n`;
    });
    if (taskInstances.length > 10) {
      playbook += `... and ${taskInstances.length - 10} more\n`;
    }
    playbook += `\n`;

    playbook += `ROUTINES (${routines.length})\n`;
    playbook += `───────────────────────────────────────────────────\n`;
    routines.forEach((routine: Routine): void => {
      playbook += `[${routine.frequency}] ${routine.name}\n`;
      playbook += `  ${routine.description}\n\n`;
    });

    if (agent.notes) {
      playbook += `NOTES\n`;
      playbook += `───────────────────────────────────────────────────\n`;
      playbook += `${agent.notes}\n\n`;
    }

    playbook += `═══════════════════════════════════════════════════\n`;
    playbook += `End of Playbook\n`;
    playbook += `═══════════════════════════════════════════════════\n`;

    return playbook;
  }, [store, getAgentById, getInterfacesByAgentId, getLinksByAgentId, getTaskTypesByAgentId, getTaskInstancesByAgentId, getRoutinesByAgentId]);

  const generateRoutineBrief = useCallback((routineId: string): string => {
    const routine = getRoutineById(routineId);
    if (!routine) return 'Routine not found';

    const owner = routine.ownerAgentId ? getAgentById(routine.ownerAgentId) : null;

    let brief = `═══════════════════════════════════════════════════\n`;
    brief += `ROUTINE BRIEF: ${routine.name.toUpperCase()}\n`;
    brief += `═══════════════════════════════════════════════════\n\n`;

    brief += `OVERVIEW\n`;
    brief += `───────────────────────────────────────────────────\n`;
    brief += `Frequency: ${routine.frequency}\n`;
    brief += `Owner: ${owner ? owner.name : 'Unassigned'}\n`;
    brief += `Tags: ${routine.tags.join(', ')}\n\n`;

    brief += `DESCRIPTION\n`;
    brief += `───────────────────────────────────────────────────\n`;
    brief += `${routine.description}\n\n`;

    brief += `STEPS\n`;
    brief += `───────────────────────────────────────────────────\n`;
    routine.stepTaskTypeIds.forEach((ttId: string, index: number): void => {
      const taskType = getTaskTypeById(ttId);
      if (taskType) {
        brief += `Step ${index + 1}: [${taskType.code}] ${taskType.name}\n`;
        brief += `  Category: ${taskType.category}\n`;
        brief += `  ${taskType.description}\n`;
        brief += `  Inputs: ${taskType.expectedInputs.join(', ')}\n`;
        brief += `  Outputs: ${taskType.expectedOutputs.join(', ')}\n\n`;
      }
    });

    if (routine.notes) {
      brief += `NOTES\n`;
      brief += `───────────────────────────────────────────────────\n`;
      brief += `${routine.notes}\n\n`;
    }

    brief += `═══════════════════════════════════════════════════\n`;
    brief += `End of Brief\n`;
    brief += `═══════════════════════════════════════════════════\n`;

    return brief;
  }, [store, getRoutineById, getAgentById, getTaskTypeById]);

  const exportAgentMeshOverview = useCallback((): string => {
    let overview = `═══════════════════════════════════════════════════\n`;
    overview += `DREAMNET AGENT MESH v1.0\n`;
    overview += `═══════════════════════════════════════════════════\n\n`;

    overview += `EXECUTIVE SUMMARY\n`;
    overview += `───────────────────────────────────────────────────\n`;
    overview += `Total Agents: ${store.agents.length}\n`;
    overview += `Total Task Types: ${store.taskTypes.length}\n`;
    overview += `Active Tasks: ${store.taskInstances.filter((t: TaskInstance): boolean => t.status !== 'completed' && t.status !== 'cancelled').length}\n`;
    overview += `Routines: ${store.routines.length}\n`;
    overview += `Agent Links: ${store.agentLinks.length}\n\n`;

    overview += `AGENTS BY DOMAIN\n`;
    overview += `───────────────────────────────────────────────────\n`;
    const domainMap: Record<string, AgentNode[]> = {};
    store.agents.forEach((agent: AgentNode): void => {
      const domain = agent.primaryDomain || 'unassigned';
      if (!domainMap[domain]) domainMap[domain] = [];
      domainMap[domain].push(agent);
    });
    Object.keys(domainMap).forEach((domain: string): void => {
      overview += `\n${domain.toUpperCase()}\n`;
      domainMap[domain].forEach((agent: AgentNode): void => {
        overview += `  • ${agent.name} [${agent.type}] (${agent.archetype})\n`;
      });
    });
    overview += `\n`;

    overview += `AGENTS BY ARCHETYPE\n`;
    overview += `───────────────────────────────────────────────────\n`;
    const archetypeMap: Record<string, AgentNode[]> = {};
    store.agents.forEach((agent: AgentNode): void => {
      const archetype = agent.archetype || 'unspecified';
      if (!archetypeMap[archetype]) archetypeMap[archetype] = [];
      archetypeMap[archetype].push(agent);
    });
    Object.keys(archetypeMap).forEach((archetype: string): void => {
      overview += `\n${archetype.toUpperCase()}\n`;
      archetypeMap[archetype].forEach((agent: AgentNode): void => {
        overview += `  • ${agent.name} [${agent.primaryDomain}]\n`;
      });
    });
    overview += `\n`;

    overview += `KEY RELATIONSHIPS\n`;
    overview += `───────────────────────────────────────────────────\n`;
    store.agentLinks.forEach((link: AgentLink): void => {
      const fromAgent = getAgentById(link.fromAgentId);
      const toAgent = getAgentById(link.toAgentId);
      overview += `${fromAgent?.name || '?'} --[${link.relationKind}]--> ${toAgent?.name || '?'}\n`;
      overview += `  (${link.strength}): ${link.description}\n\n`;
    });

    overview += `ROUTINES\n`;
    overview += `───────────────────────────────────────────────────\n`;
    store.routines.forEach((routine: Routine): void => {
      const owner = routine.ownerAgentId ? getAgentById(routine.ownerAgentId) : null;
      overview += `[${routine.frequency}] ${routine.name}\n`;
      overview += `  Owner: ${owner?.name || 'Unassigned'}\n`;
      overview += `  Steps: ${routine.stepTaskTypeIds.length}\n`;
      overview += `  ${routine.description}\n\n`;
    });

    overview += `═══════════════════════════════════════════════════\n`;
    overview += `Generated: ${new Date().toISOString()}\n`;
    overview += `═══════════════════════════════════════════════════\n`;

    return overview;
  }, [store, getAgentById]);

  return {
    // Store
    store,
    isLoaded,

    // Agent Node
    createAgentNode,
    updateAgentNode,
    deleteAgentNode,
    getAgentById,

    // Agent Interface
    createAgentInterface,
    updateAgentInterface,
    deleteAgentInterface,
    getInterfacesByAgentId,

    // Task Type
    createTaskType,
    updateTaskType,
    deleteTaskType,
    getTaskTypeById,
    getTaskTypesByAgentId,

    // Task Instance
    createTaskInstance,
    updateTaskInstance,
    deleteTaskInstance,
    getTaskInstanceById,
    getTaskInstancesByAgentId,

    // Routine
    createRoutine,
    updateRoutine,
    deleteRoutine,
    getRoutineById,
    getRoutinesByAgentId,

    // Agent Link
    createAgentLink,
    updateAgentLink,
    deleteAgentLink,
    getLinksByAgentId,

    // Generation
    generateAgentPlaybook,
    generateRoutineBrief,
    exportAgentMeshOverview
  };
}
