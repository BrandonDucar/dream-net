// DreamNet Navigator - Analytics & Insights Service

import type {
  SearchQuery,
  CommandExecution,
  DeadEndSearch,
  UsageStats,
  CommandHistory,
  ProductivityInsight,
} from "@/types/navigator-advanced";

const STORAGE_KEYS = {
  SEARCH_QUERIES: "dreamnet_search_queries",
  COMMAND_EXECUTIONS: "dreamnet_command_executions",
  DEAD_END_SEARCHES: "dreamnet_dead_end_searches",
  COMMAND_HISTORY: "dreamnet_command_history",
} as const;

// Helper functions
function getFromStorage<T>(key: string): T[] {
  if (typeof window === "undefined") return [];
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error(`Error reading analytics from ${key}:`, error);
    return [];
  }
}

function saveToStorage<T>(key: string, data: T[]): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error saving analytics to ${key}:`, error);
  }
}

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

// ========================================
// SEARCH ANALYTICS
// ========================================

export function logSearchQuery(
  query: string,
  resultsCount: number,
  selectedResultId: string | null = null,
  selectedResultType: "app" | "command" | "object" | "view" | null = null,
  timeToSelect: number | null = null
): SearchQuery {
  const searchQuery: SearchQuery = {
    id: generateId(),
    query,
    timestamp: new Date().toISOString(),
    resultsCount,
    selectedResultId,
    selectedResultType,
    timeToSelect,
  };

  const queries = getFromStorage<SearchQuery>(STORAGE_KEYS.SEARCH_QUERIES);
  queries.push(searchQuery);
  
  // Keep last 1000 queries
  const trimmed = queries.slice(-1000);
  saveToStorage(STORAGE_KEYS.SEARCH_QUERIES, trimmed);

  // Check for dead-end search
  if (resultsCount === 0) {
    logDeadEndSearch(query);
  }

  return searchQuery;
}

export function getSearchQueries(limit: number = 100): SearchQuery[] {
  const queries = getFromStorage<SearchQuery>(STORAGE_KEYS.SEARCH_QUERIES);
  return queries.slice(-limit).reverse();
}

export function getMostSearchedTerms(limit: number = 10): Array<{ term: string; count: number }> {
  const queries = getFromStorage<SearchQuery>(STORAGE_KEYS.SEARCH_QUERIES);
  const termCounts: Record<string, number> = {};

  for (const query of queries) {
    const term = query.query.toLowerCase().trim();
    termCounts[term] = (termCounts[term] || 0) + 1;
  }

  return Object.entries(termCounts)
    .map(([term, count]) => ({ term, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, limit);
}

// ========================================
// COMMAND EXECUTION ANALYTICS
// ========================================

export function logCommandExecution(
  commandId: string,
  commandName: string,
  duration: number | null = null,
  success: boolean = true
): CommandExecution {
  const execution: CommandExecution = {
    id: generateId(),
    commandId,
    commandName,
    timestamp: new Date().toISOString(),
    duration,
    success,
  };

  const executions = getFromStorage<CommandExecution>(STORAGE_KEYS.COMMAND_EXECUTIONS);
  executions.push(execution);
  
  // Keep last 1000 executions
  const trimmed = executions.slice(-1000);
  saveToStorage(STORAGE_KEYS.COMMAND_EXECUTIONS, trimmed);

  // Also log to command history
  logToCommandHistory(commandId, commandName, {}, null, duration);

  return execution;
}

export function getCommandExecutions(limit: number = 100): CommandExecution[] {
  const executions = getFromStorage<CommandExecution>(STORAGE_KEYS.COMMAND_EXECUTIONS);
  return executions.slice(-limit).reverse();
}

export function getMostUsedCommands(limit: number = 10): Array<{ commandId: string; commandName: string; count: number }> {
  const executions = getFromStorage<CommandExecution>(STORAGE_KEYS.COMMAND_EXECUTIONS);
  const commandCounts: Record<string, { name: string; count: number }> = {};

  for (const exec of executions) {
    if (!commandCounts[exec.commandId]) {
      commandCounts[exec.commandId] = { name: exec.commandName, count: 0 };
    }
    commandCounts[exec.commandId].count++;
  }

  return Object.entries(commandCounts)
    .map(([commandId, data]) => ({ commandId, commandName: data.name, count: data.count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, limit);
}

// ========================================
// DEAD-END SEARCH TRACKING
// ========================================

export function logDeadEndSearch(query: string): DeadEndSearch {
  const deadEnds = getFromStorage<DeadEndSearch>(STORAGE_KEYS.DEAD_END_SEARCHES);
  
  // Check if this query was already logged recently
  const existing = deadEnds.find((d) => d.query.toLowerCase() === query.toLowerCase());
  
  if (existing) {
    existing.attemptCount++;
    existing.timestamp = new Date().toISOString();
    saveToStorage(STORAGE_KEYS.DEAD_END_SEARCHES, deadEnds);
    return existing;
  }

  const deadEnd: DeadEndSearch = {
    id: generateId(),
    query,
    timestamp: new Date().toISOString(),
    attemptCount: 1,
    suggestedAlternatives: generateSuggestedAlternatives(query),
  };

  deadEnds.push(deadEnd);
  
  // Keep last 200
  const trimmed = deadEnds.slice(-200);
  saveToStorage(STORAGE_KEYS.DEAD_END_SEARCHES, trimmed);

  return deadEnd;
}

export function getDeadEndSearches(limit: number = 50): DeadEndSearch[] {
  const deadEnds = getFromStorage<DeadEndSearch>(STORAGE_KEYS.DEAD_END_SEARCHES);
  return deadEnds
    .sort((a, b) => b.attemptCount - a.attemptCount)
    .slice(0, limit);
}

function generateSuggestedAlternatives(query: string): string[] {
  // Simple suggestion logic - could be enhanced with fuzzy matching
  const suggestions: string[] = [];
  const lower = query.toLowerCase();

  if (lower.includes("create") || lower.includes("new")) {
    suggestions.push("Try searching for specific object types like 'culture coin' or 'drop'");
  }
  if (lower.includes("open") || lower.includes("view")) {
    suggestions.push("Search for app names like 'foundry' or 'architect'");
  }
  if (lower.length < 3) {
    suggestions.push("Try using more specific search terms");
  }

  return suggestions.length > 0 ? suggestions : ["Try different keywords or check the Commands page"];
}

// ========================================
// COMMAND HISTORY
// ========================================

export function logToCommandHistory(
  commandId: string,
  commandName: string,
  context: Record<string, unknown>,
  result: string | null = null,
  duration: number | null = null
): CommandHistory {
  const historyItem: CommandHistory = {
    id: generateId(),
    commandId,
    commandName,
    executedAt: new Date().toISOString(),
    context,
    result,
    duration,
  };

  const history = getFromStorage<CommandHistory>(STORAGE_KEYS.COMMAND_HISTORY);
  history.push(historyItem);
  
  // Keep last 50
  const trimmed = history.slice(-50);
  saveToStorage(STORAGE_KEYS.COMMAND_HISTORY, trimmed);

  return historyItem;
}

export function getCommandHistory(limit: number = 50): CommandHistory[] {
  const history = getFromStorage<CommandHistory>(STORAGE_KEYS.COMMAND_HISTORY);
  return history.slice(-limit).reverse();
}

export function clearCommandHistory(): void {
  saveToStorage(STORAGE_KEYS.COMMAND_HISTORY, []);
}

// ========================================
// USAGE STATISTICS
// ========================================

export function getUsageStats(period: "daily" | "weekly" | "monthly"): UsageStats {
  const now = new Date();
  let startDate: Date;

  if (period === "daily") {
    startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  } else if (period === "weekly") {
    startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  } else {
    startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  }

  const queries = getFromStorage<SearchQuery>(STORAGE_KEYS.SEARCH_QUERIES).filter(
    (q) => new Date(q.timestamp) >= startDate
  );

  const executions = getFromStorage<CommandExecution>(STORAGE_KEYS.COMMAND_EXECUTIONS).filter(
    (e) => new Date(e.timestamp) >= startDate
  );

  const deadEnds = getFromStorage<DeadEndSearch>(STORAGE_KEYS.DEAD_END_SEARCHES).filter(
    (d) => new Date(d.timestamp) >= startDate
  );

  // Calculate most used commands
  const commandCounts: Record<string, number> = {};
  for (const exec of executions) {
    commandCounts[exec.commandId] = (commandCounts[exec.commandId] || 0) + 1;
  }
  const mostUsedCommands = Object.entries(commandCounts)
    .map(([commandId, count]) => ({ commandId, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  // Calculate peak usage hours
  const hourCounts: number[] = new Array(24).fill(0);
  for (const exec of executions) {
    const hour = new Date(exec.timestamp).getHours();
    hourCounts[hour]++;
  }
  const peakUsageHours = hourCounts
    .map((count, hour) => ({ hour, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 3)
    .map((item) => item.hour);

  // Calculate average time to select
  const timesToSelect = queries
    .filter((q) => q.timeToSelect !== null)
    .map((q) => q.timeToSelect as number);
  const avgTimeToSelect = timesToSelect.length > 0
    ? timesToSelect.reduce((sum, time) => sum + time, 0) / timesToSelect.length
    : 0;

  return {
    period,
    startDate: startDate.toISOString(),
    endDate: now.toISOString(),
    totalSearches: queries.length,
    totalCommands: executions.length,
    mostUsedCommands,
    mostUsedApps: [], // TODO: Track app usage
    peakUsageHours,
    deadEndSearches: deadEnds.length,
    avgTimeToSelect,
  };
}

// ========================================
// PRODUCTIVITY INSIGHTS
// ========================================

export function getProductivityInsights(period: "daily" | "weekly" | "monthly"): ProductivityInsight {
  const stats = getUsageStats(period);
  const executions = getFromStorage<CommandExecution>(STORAGE_KEYS.COMMAND_EXECUTIONS);

  // Most productive time
  const mostProductiveHour = stats.peakUsageHours[0] || 9;
  const mostProductiveTime = `${mostProductiveHour}:00-${mostProductiveHour + 1}:00`;

  // Most used command
  const mostUsedCommand = stats.mostUsedCommands[0]?.commandId || "N/A";

  // Average session length (calculate based on gaps in executions)
  const sessions: number[] = [];
  let currentSession = 0;
  for (let i = 1; i < executions.length; i++) {
    const prevTime = new Date(executions[i - 1].timestamp).getTime();
    const currTime = new Date(executions[i].timestamp).getTime();
    const gap = (currTime - prevTime) / (1000 * 60); // minutes

    if (gap < 30) {
      currentSession += gap;
    } else {
      if (currentSession > 0) sessions.push(currentSession);
      currentSession = 0;
    }
  }
  const avgSessionLength = sessions.length > 0
    ? sessions.reduce((sum, len) => sum + len, 0) / sessions.length
    : 0;

  // Calculate streak (days of consecutive usage)
  const executionDates = new Set(
    executions.map((e) => new Date(e.timestamp).toISOString().split("T")[0])
  );
  let streak = 0;
  const today = new Date();
  for (let i = 0; i < 365; i++) {
    const checkDate = new Date(today.getTime() - i * 24 * 60 * 60 * 1000);
    const dateStr = checkDate.toISOString().split("T")[0];
    if (executionDates.has(dateStr)) {
      streak++;
    } else {
      break;
    }
  }

  // Generate suggestions
  const suggestions: string[] = [];
  if (stats.deadEndSearches > stats.totalSearches * 0.2) {
    suggestions.push("Many searches return no results - consider adding more commands or aliases");
  }
  if (stats.mostUsedCommands.length > 0 && stats.mostUsedCommands[0].count > 10) {
    suggestions.push(`You use "${stats.mostUsedCommands[0].commandId}" frequently - consider pinning it`);
  }
  if (avgSessionLength < 5) {
    suggestions.push("Quick sessions detected - consider creating workflows for common task sequences");
  }

  return {
    period,
    mostProductiveTime,
    mostUsedCommand,
    commandsExecuted: stats.totalCommands,
    appsOpened: 0, // TODO: Track
    avgSessionLength: Math.round(avgSessionLength),
    streak,
    suggestions,
  };
}

// ========================================
// CLEAR ANALYTICS
// ========================================

export function clearAllAnalytics(): void {
  saveToStorage(STORAGE_KEYS.SEARCH_QUERIES, []);
  saveToStorage(STORAGE_KEYS.COMMAND_EXECUTIONS, []);
  saveToStorage(STORAGE_KEYS.DEAD_END_SEARCHES, []);
  saveToStorage(STORAGE_KEYS.COMMAND_HISTORY, []);
}
