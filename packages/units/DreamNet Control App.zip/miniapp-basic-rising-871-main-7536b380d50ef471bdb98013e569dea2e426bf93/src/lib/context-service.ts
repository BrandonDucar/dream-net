// DreamNet Navigator - Context Awareness Service

import type { ContextRule, WorkContext, AutoSuggestion, UsagePattern } from "@/types/navigator-advanced";
import type { Command } from "@/types/navigator";

const STORAGE_KEYS = {
  CONTEXT_RULES: "dreamnet_context_rules",
  WORK_CONTEXT: "dreamnet_work_context",
  AUTO_SUGGESTIONS: "dreamnet_auto_suggestions",
  USAGE_PATTERNS: "dreamnet_usage_patterns",
} as const;

function getFromStorage<T>(key: string): T[] {
  if (typeof window === "undefined") return [];
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error(`Error reading from ${key}:`, error);
    return [];
  }
}

function saveToStorage<T>(key: string, data: T[]): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error saving to ${key}:`, error);
  }
}

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

// ========================================
// CONTEXT RULES
// ========================================

export function createContextRule(
  name: string,
  condition: ContextRule["condition"],
  suggestions: string[],
  priority: number = 5
): ContextRule {
  const rule: ContextRule = {
    id: generateId(),
    name,
    condition,
    suggestions,
    priority,
  };

  const rules = getFromStorage<ContextRule>(STORAGE_KEYS.CONTEXT_RULES);
  rules.push(rule);
  saveToStorage(STORAGE_KEYS.CONTEXT_RULES, rules);

  return rule;
}

export function getContextRules(): ContextRule[] {
  return getFromStorage<ContextRule>(STORAGE_KEYS.CONTEXT_RULES);
}

export function deleteContextRule(id: string): boolean {
  const rules = getContextRules();
  const filtered = rules.filter((r) => r.id !== id);

  if (filtered.length < rules.length) {
    saveToStorage(STORAGE_KEYS.CONTEXT_RULES, filtered);
    return true;
  }

  return false;
}

// ========================================
// CONTEXT EVALUATION
// ========================================

export function evaluateContext(): string[] {
  const rules = getContextRules();
  const suggestions: string[] = [];
  const now = new Date();

  for (const rule of rules) {
    if (evaluateCondition(rule.condition, now)) {
      suggestions.push(...rule.suggestions);
    }
  }

  // Remove duplicates and sort by priority
  return Array.from(new Set(suggestions));
}

function evaluateCondition(condition: ContextRule["condition"], now: Date): boolean {
  switch (condition.type) {
    case "time": {
      const hour = now.getHours();
      const startHour = condition.params.startHour as number;
      const endHour = condition.params.endHour as number;
      return hour >= startHour && hour < endHour;
    }

    case "day": {
      const day = now.getDay(); // 0 = Sunday, 6 = Saturday
      const targetDays = condition.params.days as number[];
      return targetDays.includes(day);
    }

    case "usage-pattern": {
      // Check if user typically uses certain commands at this time
      const pattern = condition.params.pattern as string;
      return checkUsagePattern(pattern);
    }

    case "recent-object": {
      // Check if user recently worked with specific objects
      const objectType = condition.params.objectType as string;
      return checkRecentObjectUsage(objectType);
    }

    case "custom": {
      // Custom evaluation logic
      return true;
    }

    default:
      return false;
  }
}

function checkUsagePattern(pattern: string): boolean {
  const patterns = getFromStorage<UsagePattern>(STORAGE_KEYS.USAGE_PATTERNS);
  const match = patterns.find((p) => p.pattern === pattern);
  
  if (!match) return false;

  // Check if pattern occurred recently and frequently
  const lastOccurrence = new Date(match.lastOccurrence);
  const daysSince = (Date.now() - lastOccurrence.getTime()) / (1000 * 60 * 60 * 24);
  
  return daysSince < 7 && match.frequency > 3 && match.confidence > 0.7;
}

function checkRecentObjectUsage(objectType: string): boolean {
  try {
    const workContextData = localStorage.getItem(STORAGE_KEYS.WORK_CONTEXT);
    if (!workContextData) return false;

    const context: WorkContext = JSON.parse(workContextData);
    return context.currentObjects.some((obj) => obj.type === objectType);
  } catch {
    return false;
  }
}

// ========================================
// WORK CONTEXT
// ========================================

export function updateWorkContext(context: Partial<WorkContext>): void {
  const current = getWorkContext();
  const updated: WorkContext = {
    ...current,
    ...context,
    lastActivity: new Date().toISOString(),
  };

  if (typeof window !== "undefined") {
    localStorage.setItem(STORAGE_KEYS.WORK_CONTEXT, JSON.stringify(updated));
  }
}

export function getWorkContext(): WorkContext {
  if (typeof window === "undefined") {
    return {
      currentObjects: [],
      recentPatterns: [],
      activeProjects: [],
      lastActivity: new Date().toISOString(),
    };
  }

  try {
    const data = localStorage.getItem(STORAGE_KEYS.WORK_CONTEXT);
    if (!data) {
      return {
        currentObjects: [],
        recentPatterns: [],
        activeProjects: [],
        lastActivity: new Date().toISOString(),
      };
    }
    return JSON.parse(data);
  } catch {
    return {
      currentObjects: [],
      recentPatterns: [],
      activeProjects: [],
      lastActivity: new Date().toISOString(),
    };
  }
}

export function addCurrentObject(type: string, id: string, name: string): void {
  const context = getWorkContext();
  
  // Remove if already exists
  context.currentObjects = context.currentObjects.filter(
    (obj) => !(obj.type === type && obj.id === id)
  );
  
  // Add to beginning
  context.currentObjects.unshift({ type, id, name });
  
  // Keep last 10
  context.currentObjects = context.currentObjects.slice(0, 10);
  
  updateWorkContext(context);
}

export function addRecentPattern(pattern: string): void {
  const context = getWorkContext();
  
  // Remove if already exists
  context.recentPatterns = context.recentPatterns.filter((p) => p !== pattern);
  
  // Add to beginning
  context.recentPatterns.unshift(pattern);
  
  // Keep last 20
  context.recentPatterns = context.recentPatterns.slice(0, 20);
  
  updateWorkContext(context);
}

// ========================================
// AUTO SUGGESTIONS
// ========================================

export function generateAutoSuggestions(commands: Command[]): AutoSuggestion[] {
  const suggestions: AutoSuggestion[] = [];
  const now = new Date();
  const hour = now.getHours();

  // Time-based suggestions
  if (hour >= 8 && hour < 10) {
    suggestions.push({
      id: generateId(),
      suggestionType: "time-based",
      title: "Morning Routine",
      description: "Start your day with Daily Operations Sweep",
      actionable: true,
      actionData: { commandSlug: "daily-ops" },
      confidence: 0.8,
      createdAt: now.toISOString(),
      dismissed: false,
    });
  }

  // Pin suggestions based on usage
  const highUseCommands = commands.filter(
    (c) => c.importanceLevel === "critical" || c.importanceLevel === "high"
  );

  for (const command of highUseCommands.slice(0, 3)) {
    suggestions.push({
      id: generateId(),
      suggestionType: "pin-command",
      title: `Pin "${command.name}"`,
      description: "You use this command frequently. Consider pinning it for quick access.",
      actionable: true,
      actionData: { commandId: command.id },
      confidence: 0.7,
      createdAt: now.toISOString(),
      dismissed: false,
    });
  }

  // Workflow suggestions
  const context = getWorkContext();
  if (context.recentPatterns.length >= 3) {
    const pattern = context.recentPatterns.slice(0, 3).join(" → ");
    suggestions.push({
      id: generateId(),
      suggestionType: "create-workflow",
      title: "Create Workflow",
      description: `You frequently run this sequence: ${pattern}. Create a workflow?`,
      actionable: true,
      actionData: { pattern: context.recentPatterns.slice(0, 3) },
      confidence: 0.75,
      createdAt: now.toISOString(),
      dismissed: false,
    });
  }

  return suggestions;
}

export function getAutoSuggestions(): AutoSuggestion[] {
  return getFromStorage<AutoSuggestion>(STORAGE_KEYS.AUTO_SUGGESTIONS);
}

export function saveAutoSuggestion(suggestion: AutoSuggestion): void {
  const suggestions = getAutoSuggestions();
  suggestions.push(suggestion);
  
  // Keep last 50
  const trimmed = suggestions.slice(-50);
  saveToStorage(STORAGE_KEYS.AUTO_SUGGESTIONS, trimmed);
}

export function dismissSuggestion(id: string): void {
  const suggestions = getAutoSuggestions();
  const index = suggestions.findIndex((s) => s.id === id);
  
  if (index !== -1) {
    suggestions[index].dismissed = true;
    saveToStorage(STORAGE_KEYS.AUTO_SUGGESTIONS, suggestions);
  }
}

// ========================================
// USAGE PATTERNS
// ========================================

export function recordUsagePattern(pattern: string, patternType: UsagePattern["patternType"]): void {
  const patterns = getFromStorage<UsagePattern>(STORAGE_KEYS.USAGE_PATTERNS);
  const existing = patterns.find((p) => p.pattern === pattern && p.patternType === patternType);

  if (existing) {
    existing.frequency++;
    existing.lastOccurrence = new Date().toISOString();
    existing.confidence = Math.min(1, existing.confidence + 0.1);
  } else {
    patterns.push({
      id: generateId(),
      patternType,
      pattern,
      frequency: 1,
      lastOccurrence: new Date().toISOString(),
      confidence: 0.5,
    });
  }

  // Keep last 100 patterns
  const trimmed = patterns.slice(-100);
  saveToStorage(STORAGE_KEYS.USAGE_PATTERNS, trimmed);
}

export function getUsagePatterns(): UsagePattern[] {
  return getFromStorage<UsagePattern>(STORAGE_KEYS.USAGE_PATTERNS);
}

// ========================================
// DEFAULT CONTEXT RULES
// ========================================

export function initializeDefaultContextRules(): void {
  const existing = getContextRules();
  
  // Only initialize if no rules exist
  if (existing.length > 0) return;

  // Morning routine (8am-10am)
  createContextRule(
    "Morning Routine",
    {
      type: "time",
      params: { startHour: 8, endHour: 10 },
    },
    ["daily-ops", "review-agents"],
    10
  );

  // Weekday operations (Monday-Friday)
  createContextRule(
    "Weekday Operations",
    {
      type: "day",
      params: { days: [1, 2, 3, 4, 5] },
    },
    ["daily-ops"],
    8
  );

  // End of day review (5pm-7pm)
  createContextRule(
    "End of Day Review",
    {
      type: "time",
      params: { startHour: 17, endHour: 19 },
    },
    ["generate-report", "review-activity"],
    7
  );
}
