// DreamNet Agent Mesh & Taskboard - Utility Functions

import type { SEOMetadata } from '@/types/dreamnet';

export function generateSlug(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

export function generateSEO(name: string, description: string, type: 'agent' | 'task'): SEOMetadata {
  const keywords = extractKeywords(name, description);
  const hashtags = keywords.slice(0, 5).map((k: string): string => `#${k.replace(/\s+/g, '')}`);
  
  return {
    seoTitle: `${name} | DreamNet ${type === 'agent' ? 'Agent' : 'Task'}`,
    seoDescription: description.slice(0, 160),
    seoKeywords: keywords,
    seoHashtags: hashtags,
    altText: `${name} - ${type === 'agent' ? 'AI Agent' : 'Task Type'} in DreamNet`
  };
}

function extractKeywords(name: string, description: string): string[] {
  const text = `${name} ${description}`.toLowerCase();
  const words = text.split(/\s+/);
  const stopWords = new Set(['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'from', 'as', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'should', 'could', 'may', 'might', 'must', 'can', 'this', 'that', 'these', 'those', 'it', 'its', 'they', 'them', 'their']);
  
  const keywords = words
    .filter((w: string): boolean => w.length > 3 && !stopWords.has(w))
    .filter((w: string, i: number, arr: string[]): boolean => arr.indexOf(w) === i)
    .slice(0, 10);
  
  return keywords;
}

export function formatDate(isoString: string | null): string {
  if (!isoString) return 'No date';
  const date = new Date(isoString);
  return date.toLocaleDateString('en-US', { 
    month: 'short', 
    day: 'numeric', 
    year: 'numeric' 
  });
}

export function formatDateTime(isoString: string): string {
  const date = new Date(isoString);
  return date.toLocaleString('en-US', { 
    month: 'short', 
    day: 'numeric', 
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit'
  });
}

export function isOverdue(dueAt: string | null): boolean {
  if (!dueAt) return false;
  return new Date(dueAt) < new Date();
}
