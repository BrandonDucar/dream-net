// DreamNet Navigator - Export/Import & Backup Service

import type { ConfigBackup } from "@/types/navigator-advanced";
import type { AppRef, Command, Pin, ObjectShortcut } from "@/types/navigator";
import { appStorage, commandStorage, pinStorage, objectStorage } from "./navigator-storage";
import { getWorkflows } from "./workflow-service";
import { getShortcuts } from "./shortcuts-service";
import { getTemplates } from "./templates-service";

const STORAGE_KEY = "dreamnet_backups";
const APP_VERSION = "1.0.0";

function getFromStorage(): ConfigBackup[] {
  if (typeof window === "undefined") return [];
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error("Error reading backups:", error);
    return [];
  }
}

function saveToStorage(backups: ConfigBackup[]): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(backups));
  } catch (error) {
    console.error("Error saving backups:", error);
  }
}

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

// ========================================
// BACKUP CREATION
// ========================================

export function createBackup(name: string, description: string = ""): ConfigBackup {
  const backup: ConfigBackup = {
    id: generateId(),
    name,
    description,
    version: APP_VERSION,
    createdAt: new Date().toISOString(),
    data: {
      apps: appStorage.getAll(),
      commands: commandStorage.getAll(),
      pins: pinStorage.getAll(),
      workflows: getWorkflows(),
      shortcuts: getShortcuts(),
      templates: getTemplates(),
      settings: {
        // Add any global settings here
      },
    },
  };

  const backups = getFromStorage();
  backups.push(backup);

  // Keep last 20 backups
  const trimmed = backups.slice(-20);
  saveToStorage(trimmed);

  return backup;
}

export function getBackups(): ConfigBackup[] {
  return getFromStorage().sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

export function getBackupById(id: string): ConfigBackup | null {
  const backups = getBackups();
  return backups.find((b) => b.id === id) || null;
}

export function deleteBackup(id: string): boolean {
  const backups = getFromStorage();
  const filtered = backups.filter((b) => b.id !== id);

  if (filtered.length < backups.length) {
    saveToStorage(filtered);
    return true;
  }

  return false;
}

// ========================================
// RESTORE FROM BACKUP
// ========================================

export function restoreFromBackup(backupId: string, options: {
  restoreApps?: boolean;
  restoreCommands?: boolean;
  restorePins?: boolean;
  restoreWorkflows?: boolean;
  restoreShortcuts?: boolean;
  restoreTemplates?: boolean;
} = {}): boolean {
  const backup = getBackupById(backupId);
  if (!backup) return false;

  const {
    restoreApps = true,
    restoreCommands = true,
    restorePins = true,
    restoreWorkflows = true,
    restoreShortcuts = true,
    restoreTemplates = true,
  } = options;

  try {
    if (restoreApps && backup.data.apps) {
      appStorage.save(backup.data.apps as AppRef[]);
    }

    if (restoreCommands && backup.data.commands) {
      commandStorage.save(backup.data.commands as Command[]);
    }

    if (restorePins && backup.data.pins) {
      pinStorage.save(backup.data.pins as Pin[]);
    }

    if (restoreWorkflows && backup.data.workflows) {
      localStorage.setItem("dreamnet_workflows", JSON.stringify(backup.data.workflows));
    }

    if (restoreShortcuts && backup.data.shortcuts) {
      localStorage.setItem("dreamnet_keyboard_shortcuts", JSON.stringify(backup.data.shortcuts));
    }

    if (restoreTemplates && backup.data.templates) {
      localStorage.setItem("dreamnet_templates", JSON.stringify(backup.data.templates));
    }

    return true;
  } catch (error) {
    console.error("Error restoring backup:", error);
    return false;
  }
}

// ========================================
// EXPORT TO FILE
// ========================================

export function exportToJSON(backupId?: string): string {
  let dataToExport: ConfigBackup;

  if (backupId) {
    const backup = getBackupById(backupId);
    if (!backup) throw new Error("Backup not found");
    dataToExport = backup;
  } else {
    // Create a new backup for export
    dataToExport = createBackup("Export", "Exported configuration");
  }

  return JSON.stringify(dataToExport, null, 2);
}

export function downloadBackup(backupId?: string, filename?: string): void {
  if (typeof window === "undefined") return;

  const json = exportToJSON(backupId);
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement("a");
  link.href = url;
  link.download = filename || `dreamnet-backup-${new Date().toISOString().split("T")[0]}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  URL.revokeObjectURL(url);
}

// ========================================
// IMPORT FROM FILE
// ========================================

export function importFromJSON(json: string): ConfigBackup | null {
  try {
    const imported: ConfigBackup = JSON.parse(json);

    // Validate structure
    if (!imported.data || !imported.version) {
      throw new Error("Invalid backup format");
    }

    // Generate new ID and timestamp
    const backup: ConfigBackup = {
      ...imported,
      id: generateId(),
      name: `${imported.name} (Imported)`,
      createdAt: new Date().toISOString(),
    };

    // Save as a backup
    const backups = getFromStorage();
    backups.push(backup);
    saveToStorage(backups);

    return backup;
  } catch (error) {
    console.error("Error importing backup:", error);
    return null;
  }
}

// ========================================
// SELECTIVE EXPORT
// ========================================

export function exportApps(): string {
  const apps = appStorage.getAll();
  return JSON.stringify(apps, null, 2);
}

export function exportCommands(): string {
  const commands = commandStorage.getAll();
  return JSON.stringify(commands, null, 2);
}

export function exportPins(): string {
  const pins = pinStorage.getAll();
  return JSON.stringify(pins, null, 2);
}

export function exportObjects(): string {
  const objects = objectStorage.getAll();
  return JSON.stringify(objects, null, 2);
}

// ========================================
// SELECTIVE IMPORT
// ========================================

export function importApps(json: string, mode: "merge" | "replace" = "merge"): boolean {
  try {
    const apps: AppRef[] = JSON.parse(json);

    if (mode === "replace") {
      appStorage.save(apps);
    } else {
      const existing = appStorage.getAll();
      const merged = [...existing];

      for (const app of apps) {
        const existingIndex = merged.findIndex((a) => a.id === app.id);
        if (existingIndex !== -1) {
          merged[existingIndex] = app;
        } else {
          merged.push(app);
        }
      }

      appStorage.save(merged);
    }

    return true;
  } catch (error) {
    console.error("Error importing apps:", error);
    return false;
  }
}

export function importCommands(json: string, mode: "merge" | "replace" = "merge"): boolean {
  try {
    const commands: Command[] = JSON.parse(json);

    if (mode === "replace") {
      commandStorage.save(commands);
    } else {
      const existing = commandStorage.getAll();
      const merged = [...existing];

      for (const command of commands) {
        const existingIndex = merged.findIndex((c) => c.id === command.id);
        if (existingIndex !== -1) {
          merged[existingIndex] = command;
        } else {
          merged.push(command);
        }
      }

      commandStorage.save(merged);
    }

    return true;
  } catch (error) {
    console.error("Error importing commands:", error);
    return false;
  }
}

export function importObjects(json: string, mode: "merge" | "replace" = "merge"): boolean {
  try {
    const objects: ObjectShortcut[] = JSON.parse(json);

    if (mode === "replace") {
      objectStorage.save(objects);
    } else {
      const existing = objectStorage.getAll();
      const merged = [...existing];

      for (const object of objects) {
        const existingIndex = merged.findIndex((o) => o.id === object.id);
        if (existingIndex !== -1) {
          merged[existingIndex] = object;
        } else {
          merged.push(object);
        }
      }

      objectStorage.save(merged);
    }

    return true;
  } catch (error) {
    console.error("Error importing objects:", error);
    return false;
  }
}

// ========================================
// AUTO-BACKUP
// ========================================

export function setupAutoBackup(intervalDays: number = 7): void {
  if (typeof window === "undefined") return;

  const lastBackupKey = "dreamnet_last_auto_backup";
  const lastBackupStr = localStorage.getItem(lastBackupKey);

  if (lastBackupStr) {
    const lastBackup = new Date(lastBackupStr);
    const daysSince = (Date.now() - lastBackup.getTime()) / (1000 * 60 * 60 * 24);

    if (daysSince < intervalDays) {
      return; // Too soon for auto-backup
    }
  }

  // Create auto-backup
  createBackup("Auto Backup", `Automatic backup on ${new Date().toLocaleString()}`);
  localStorage.setItem(lastBackupKey, new Date().toISOString());
}

// ========================================
// BACKUP STATISTICS
// ========================================

export function getBackupStats(): {
  totalBackups: number;
  totalSize: string;
  oldestBackup: string | null;
  newestBackup: string | null;
} {
  const backups = getBackups();

  if (backups.length === 0) {
    return {
      totalBackups: 0,
      totalSize: "0 KB",
      oldestBackup: null,
      newestBackup: null,
    };
  }

  // Calculate total size (approximate)
  const json = JSON.stringify(backups);
  const sizeInBytes = new Blob([json]).size;
  const sizeInKB = (sizeInBytes / 1024).toFixed(2);

  const sorted = backups.sort((a, b) => 
    new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
  );

  return {
    totalBackups: backups.length,
    totalSize: `${sizeInKB} KB`,
    oldestBackup: sorted[0].createdAt,
    newestBackup: sorted[sorted.length - 1].createdAt,
  };
}
