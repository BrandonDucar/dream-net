// DreamNet Navigator - Fuzzy Search & Aliases Service

import type { CommandAlias, FuzzyMatchResult } from "@/types/navigator-advanced";
import type { Command, AppRef, ObjectShortcut } from "@/types/navigator";

const STORAGE_KEY = "dreamnet_command_aliases";

// Helper functions
function getFromStorage(): CommandAlias[] {
  if (typeof window === "undefined") return [];
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error("Error reading aliases:", error);
    return [];
  }
}

function saveToStorage(aliases: CommandAlias[]): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(aliases));
  } catch (error) {
    console.error("Error saving aliases:", error);
  }
}

// ========================================
// LEVENSHTEIN DISTANCE (Fuzzy Matching)
// ========================================

export function levenshteinDistance(a: string, b: string): number {
  const an = a.length;
  const bn = b.length;
  
  if (an === 0) return bn;
  if (bn === 0) return an;

  const matrix: number[][] = [];

  for (let i = 0; i <= bn; i++) {
    matrix[i] = [i];
  }

  for (let j = 0; j <= an; j++) {
    matrix[0][j] = j;
  }

  for (let i = 1; i <= bn; i++) {
    for (let j = 1; j <= an; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1, // substitution
          matrix[i][j - 1] + 1,     // insertion
          matrix[i - 1][j] + 1      // deletion
        );
      }
    }
  }

  return matrix[bn][an];
}

// ========================================
// FUZZY MATCH
// ========================================

export function fuzzyMatch(query: string, target: string, threshold: number = 3): FuzzyMatchResult | null {
  const queryLower = query.toLowerCase().trim();
  const targetLower = target.toLowerCase().trim();

  // Exact match
  if (queryLower === targetLower) {
    return {
      text: target,
      score: 100,
      distance: 0,
      type: "exact",
    };
  }

  // Starts with match
  if (targetLower.startsWith(queryLower)) {
    return {
      text: target,
      score: 90,
      distance: 0,
      type: "exact",
    };
  }

  // Contains match
  if (targetLower.includes(queryLower)) {
    return {
      text: target,
      score: 70,
      distance: 0,
      type: "exact",
    };
  }

  // Fuzzy match with Levenshtein distance
  const distance = levenshteinDistance(queryLower, targetLower);
  
  if (distance <= threshold) {
    const score = Math.max(0, 60 - (distance * 10));
    return {
      text: target,
      score,
      distance,
      type: "fuzzy",
    };
  }

  // Word-level fuzzy matching
  const queryWords = queryLower.split(/\s+/);
  const targetWords = targetLower.split(/\s+/);
  
  let wordMatches = 0;
  for (const qWord of queryWords) {
    for (const tWord of targetWords) {
      if (tWord.includes(qWord) || levenshteinDistance(qWord, tWord) <= 2) {
        wordMatches++;
        break;
      }
    }
  }

  if (wordMatches > 0 && wordMatches >= queryWords.length * 0.5) {
    const score = (wordMatches / queryWords.length) * 50;
    return {
      text: target,
      score,
      distance: queryWords.length - wordMatches,
      type: "fuzzy",
    };
  }

  return null;
}

// ========================================
// COMMAND ALIASES
// ========================================

export function addCommandAlias(
  commandId: string,
  aliases: string[],
  naturalLanguagePatterns: string[] = []
): CommandAlias {
  const allAliases = getFromStorage();
  
  // Remove existing entry for this command
  const filtered = allAliases.filter((a) => a.commandId !== commandId);
  
  const newAlias: CommandAlias = {
    commandId,
    aliases,
    naturalLanguagePatterns,
  };

  filtered.push(newAlias);
  saveToStorage(filtered);

  return newAlias;
}

export function getCommandAliases(commandId: string): CommandAlias | null {
  const aliases = getFromStorage();
  return aliases.find((a) => a.commandId === commandId) || null;
}

export function getAllAliases(): CommandAlias[] {
  return getFromStorage();
}

export function removeCommandAlias(commandId: string): boolean {
  const aliases = getFromStorage();
  const filtered = aliases.filter((a) => a.commandId !== commandId);
  
  if (filtered.length < aliases.length) {
    saveToStorage(filtered);
    return true;
  }

  return false;
}

// ========================================
// SMART SEARCH WITH ALIASES
// ========================================

export function searchWithAliases(
  query: string,
  commands: Command[]
): Array<{ command: Command; matchType: FuzzyMatchResult }> {
  const results: Array<{ command: Command; matchType: FuzzyMatchResult }> = [];
  const aliases = getAllAliases();

  for (const command of commands) {
    const commandAliases = aliases.find((a) => a.commandId === command.id);

    // Check command name
    const nameMatch = fuzzyMatch(query, command.name, 3);
    if (nameMatch) {
      results.push({ command, matchType: nameMatch });
      continue;
    }

    // Check slug
    const slugMatch = fuzzyMatch(query, command.slug, 3);
    if (slugMatch) {
      results.push({ command, matchType: slugMatch });
      continue;
    }

    // Check aliases
    if (commandAliases) {
      for (const alias of commandAliases.aliases) {
        const aliasMatch = fuzzyMatch(query, alias, 2);
        if (aliasMatch) {
          results.push({ command, matchType: { ...aliasMatch, type: "alias" } });
          break;
        }
      }

      // Check natural language patterns
      const queryLower = query.toLowerCase();
      for (const pattern of commandAliases.naturalLanguagePatterns) {
        if (queryLower.includes(pattern.toLowerCase())) {
          results.push({
            command,
            matchType: {
              text: pattern,
              score: 80,
              distance: 0,
              type: "natural",
            },
          });
          break;
        }
      }
    }

    // Check description (lower priority)
    const descMatch = fuzzyMatch(query, command.description, 5);
    if (descMatch && descMatch.score > 30) {
      results.push({ command, matchType: { ...descMatch, score: descMatch.score * 0.5 } });
    }
  }

  // Sort by score
  results.sort((a, b) => b.matchType.score - a.matchType.score);

  return results;
}

// ========================================
// NATURAL LANGUAGE PARSING
// ========================================

export function parseNaturalLanguage(query: string): {
  intent: string | null;
  action: string | null;
  object: string | null;
} {
  const lower = query.toLowerCase().trim();

  // Extract intent
  let intent: string | null = null;
  if (lower.startsWith("i want to") || lower.startsWith("i need to") || lower.startsWith("help me")) {
    intent = "execute";
  } else if (lower.startsWith("show me") || lower.startsWith("find") || lower.startsWith("where is")) {
    intent = "find";
  } else if (lower.startsWith("create") || lower.startsWith("make") || lower.startsWith("new")) {
    intent = "create";
  } else if (lower.startsWith("open") || lower.startsWith("go to") || lower.startsWith("launch")) {
    intent = "open";
  } else if (lower.startsWith("how do i") || lower.startsWith("how to")) {
    intent = "help";
  }

  // Extract action
  let action: string | null = null;
  const actionWords = ["create", "make", "build", "open", "launch", "view", "edit", "delete", "run"];
  for (const word of actionWords) {
    if (lower.includes(word)) {
      action = word;
      break;
    }
  }

  // Extract object (what they're trying to work with)
  let object: string | null = null;
  const objectKeywords = [
    "culture coin", "culturecoin", "drop", "flow", "agent", "token", 
    "segment", "identity", "ops", "daily ops"
  ];
  for (const keyword of objectKeywords) {
    if (lower.includes(keyword)) {
      object = keyword;
      break;
    }
  }

  return { intent, action, object };
}

// ========================================
// TYPO CORRECTION SUGGESTIONS
// ========================================

export function suggestCorrections(
  query: string,
  commands: Command[],
  apps: AppRef[],
  objects: ObjectShortcut[]
): string[] {
  const suggestions: string[] = [];
  const threshold = 2;

  // Check commands
  for (const command of commands) {
    const distance = levenshteinDistance(query.toLowerCase(), command.name.toLowerCase());
    if (distance <= threshold && distance > 0) {
      suggestions.push(command.name);
    }
  }

  // Check apps
  for (const app of apps) {
    const distance = levenshteinDistance(query.toLowerCase(), app.name.toLowerCase());
    if (distance <= threshold && distance > 0) {
      suggestions.push(app.name);
    }
  }

  // Check objects
  for (const object of objects) {
    const distance = levenshteinDistance(query.toLowerCase(), object.name.toLowerCase());
    if (distance <= threshold && distance > 0) {
      suggestions.push(object.name);
    }
  }

  // Return unique suggestions
  return Array.from(new Set(suggestions)).slice(0, 5);
}
