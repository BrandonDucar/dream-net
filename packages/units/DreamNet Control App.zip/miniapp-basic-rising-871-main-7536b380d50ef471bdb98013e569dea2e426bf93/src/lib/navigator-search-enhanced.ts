// DreamNet Navigator - Enhanced Search with All Advanced Features

import type { SearchResult } from "@/types/navigator";
import type { AppRef, Command, ObjectShortcut } from "@/types/navigator";
import { appStorage, commandStorage, objectStorage } from "./navigator-storage";
import { searchWithAliases, parseNaturalLanguage, suggestCorrections } from "./fuzzy-search-service";
import { logSearchQuery } from "./analytics-service";
import { evaluateContext } from "./context-service";

// ========================================
// ENHANCED SEARCH WITH ALL FEATURES
// ========================================

export function enhancedSearch(queryText: string): {
  results: SearchResult[];
  corrections: string[];
  intent: { intent: string | null; action: string | null; object: string | null };
  contextSuggestions: string[];
  searchId: string;
  searchStartTime: number;
} {
  const searchStartTime = Date.now();
  const query = queryText.toLowerCase().trim();

  // Parse natural language
  const intent = parseNaturalLanguage(queryText);

  // Get context-aware suggestions
  const contextSuggestions = evaluateContext();

  // If empty query, return context-based defaults
  if (!query) {
    return {
      results: getContextBasedDefaults(contextSuggestions),
      corrections: [],
      intent,
      contextSuggestions,
      searchId: `search-${Date.now()}`,
      searchStartTime,
    };
  }

  const results: SearchResult[] = [];
  const commands = commandStorage.getAll();
  const apps = appStorage.getAll();
  const objects = objectStorage.getAll();

  // 1. Search commands with fuzzy matching and aliases
  const commandMatches = searchWithAliases(query, commands);
  for (const match of commandMatches) {
    const app = match.command.primaryAppId ? appStorage.getById(match.command.primaryAppId) : null;
    
    results.push({
      type: "command",
      id: match.command.id,
      label: match.command.name,
      description: match.command.description,
      primaryApp: match.command.primaryAppId,
      primaryAppName: app ? app.name : null,
      instructions: match.command.recommendedNextSteps,
      score: match.matchType.score,
      tags: match.command.tags,
      importanceLevel: match.command.importanceLevel,
    });
  }

  // 2. Search apps with fuzzy matching
  for (const app of apps) {
    const score = calculateFuzzyScore(query, {
      name: app.name,
      slug: app.slug,
      description: app.description,
      tags: app.tags,
      importanceLevel: app.importanceLevel,
    });

    if (score > 0) {
      results.push({
        type: "app",
        id: app.id,
        label: app.name,
        description: app.description,
        primaryApp: app.id,
        primaryAppName: app.name,
        instructions: [`Open ${app.name}`],
        score,
        tags: app.tags,
        importanceLevel: app.importanceLevel,
      });
    }
  }

  // 3. Search objects with fuzzy matching
  for (const object of objects) {
    const score = calculateObjectFuzzyScore(query, object);

    if (score > 0) {
      const app = object.openInAppId ? appStorage.getById(object.openInAppId) : null;
      
      results.push({
        type: "object",
        id: object.id,
        label: `${object.objectType}: ${object.name}`,
        description: object.description,
        primaryApp: object.openInAppId,
        primaryAppName: app ? app.name : null,
        instructions: object.openInstructions ? [object.openInstructions] : [],
        score,
        tags: object.tags,
      });
    }
  }

  // 4. Boost context-relevant results
  for (const result of results) {
    if (contextSuggestions.includes(result.id)) {
      result.score += 15;
    }
  }

  // 5. Boost based on natural language intent
  if (intent.action && intent.object) {
    for (const result of results) {
      const matchesIntent = 
        result.label.toLowerCase().includes(intent.action) ||
        result.description.toLowerCase().includes(intent.action) ||
        (intent.object && (
          result.label.toLowerCase().includes(intent.object) ||
          result.description.toLowerCase().includes(intent.object)
        ));

      if (matchesIntent) {
        result.score += 20;
      }
    }
  }

  // Sort by score
  results.sort((a, b) => b.score - a.score);

  // Get typo corrections
  const corrections = results.length === 0 
    ? suggestCorrections(query, commands, apps, objects)
    : [];

  // Log search analytics
  const searchId = logSearchQuery(query, results.length).id;

  return {
    results: results.slice(0, 20),
    corrections,
    intent,
    contextSuggestions,
    searchId,
    searchStartTime,
  };
}

// ========================================
// FUZZY SCORING
// ========================================

function calculateFuzzyScore(
  query: string,
  input: {
    name: string;
    slug: string;
    description: string;
    tags: string[];
    importanceLevel: string;
  }
): number {
  let score = 0;

  const queryLower = query.toLowerCase();
  const nameLower = input.name.toLowerCase();
  const slugLower = input.slug.toLowerCase();
  const descLower = input.description.toLowerCase();

  // Exact matches
  if (nameLower === queryLower) score += 100;
  if (slugLower === queryLower) score += 100;

  // Starts with
  if (nameLower.startsWith(queryLower)) score += 80;
  if (slugLower.startsWith(queryLower)) score += 70;

  // Contains
  if (nameLower.includes(queryLower)) score += 50;
  if (slugLower.includes(queryLower)) score += 40;

  // Word matches
  const queryWords = queryLower.split(/\s+/);
  const nameWords = nameLower.split(/\s+/);

  for (const qWord of queryWords) {
    for (const nWord of nameWords) {
      if (nWord.startsWith(qWord)) score += 30;
      if (nWord.includes(qWord)) score += 15;
    }
  }

  // Tag matches
  for (const tag of input.tags) {
    if (tag.toLowerCase() === queryLower) score += 60;
    if (tag.toLowerCase().includes(queryLower)) score += 30;
  }

  // Description match
  if (descLower.includes(queryLower)) score += 20;

  // Importance boost
  const importanceBoost: Record<string, number> = {
    critical: 25,
    high: 15,
    medium: 5,
    low: 0,
  };
  score += importanceBoost[input.importanceLevel] || 0;

  return score;
}

function calculateObjectFuzzyScore(query: string, object: ObjectShortcut): number {
  let score = 0;

  const queryLower = query.toLowerCase();
  const nameLower = object.name.toLowerCase();
  const typeLower = object.objectType.toLowerCase();
  const descLower = object.description.toLowerCase();

  // Exact matches
  if (nameLower === queryLower) score += 100;
  if (typeLower === queryLower) score += 80;

  // Starts with
  if (nameLower.startsWith(queryLower)) score += 70;
  if (typeLower.startsWith(queryLower)) score += 60;

  // Contains
  if (nameLower.includes(queryLower)) score += 45;
  if (typeLower.includes(queryLower)) score += 35;

  // Tags
  for (const tag of object.tags) {
    if (tag.toLowerCase() === queryLower) score += 60;
    if (tag.toLowerCase().includes(queryLower)) score += 30;
  }

  // Description
  if (descLower.includes(queryLower)) score += 20;

  return score;
}

// ========================================
// CONTEXT-BASED DEFAULTS
// ========================================

function getContextBasedDefaults(contextSuggestions: string[]): SearchResult[] {
  const results: SearchResult[] = [];
  const commands = commandStorage.getAll();
  const apps = appStorage.getAll();

  // Add context-suggested commands
  for (const commandId of contextSuggestions.slice(0, 5)) {
    const command = commands.find((c) => c.id === commandId);
    if (command) {
      const app = command.primaryAppId ? appStorage.getById(command.primaryAppId) : null;
      
      results.push({
        type: "command",
        id: command.id,
        label: command.name,
        description: command.description,
        primaryApp: command.primaryAppId,
        primaryAppName: app ? app.name : null,
        instructions: command.recommendedNextSteps,
        score: 100,
        tags: command.tags,
        importanceLevel: command.importanceLevel,
      });
    }
  }

  // Add high-priority commands
  const highPriority = commands
    .filter((c) => c.importanceLevel === "critical" || c.importanceLevel === "high")
    .slice(0, 5);

  for (const command of highPriority) {
    // Skip if already added
    if (results.some((r) => r.id === command.id)) continue;

    const app = command.primaryAppId ? appStorage.getById(command.primaryAppId) : null;
    
    results.push({
      type: "command",
      id: command.id,
      label: command.name,
      description: command.description,
      primaryApp: command.primaryAppId,
      primaryAppName: app ? app.name : null,
      instructions: command.recommendedNextSteps,
      score: 80,
      tags: command.tags,
      importanceLevel: command.importanceLevel,
    });
  }

  // Add important apps
  const importantApps = apps
    .filter((a) => a.importanceLevel === "critical" || a.importanceLevel === "high")
    .slice(0, 5);

  for (const app of importantApps) {
    // Skip if already added
    if (results.some((r) => r.id === app.id)) continue;

    results.push({
      type: "app",
      id: app.id,
      label: app.name,
      description: app.description,
      primaryApp: app.id,
      primaryAppName: app.name,
      instructions: [`Open ${app.name}`],
      score: 75,
      tags: app.tags,
      importanceLevel: app.importanceLevel,
    });
  }

  return results.slice(0, 10);
}
