// DreamNet Navigator - Search & Ranking Logic

import type { AppRef, Command, ObjectShortcut, SearchResult } from "@/types/navigator";
import { appStorage, commandStorage, objectStorage, pinStorage } from "./navigator-storage";

// ========================================
// 10) getCommandPaletteSuggestions
// ========================================
export function getCommandPaletteSuggestions(queryText: string): SearchResult[] {
  if (!queryText.trim()) {
    return getDefaultSuggestions();
  }
  
  const query = queryText.toLowerCase().trim();
  const results: SearchResult[] = [];
  
  // Search commands
  const commands = commandStorage.getAll();
  for (const command of commands) {
    const score = calculateScore(query, {
      name: command.name,
      slug: command.slug,
      description: command.description,
      tags: command.tags,
      importanceLevel: command.importanceLevel,
    });
    
    if (score > 0) {
      const app = command.primaryAppId ? appStorage.getById(command.primaryAppId) : null;
      
      results.push({
        type: "command",
        id: command.id,
        label: command.name,
        description: command.description,
        primaryApp: command.primaryAppId,
        primaryAppName: app ? app.name : null,
        instructions: command.recommendedNextSteps,
        score,
        tags: command.tags,
        importanceLevel: command.importanceLevel,
      });
    }
  }
  
  // Search apps
  const apps = appStorage.getAll();
  for (const app of apps) {
    const score = calculateScore(query, {
      name: app.name,
      slug: app.slug,
      description: app.description,
      tags: app.tags,
      importanceLevel: app.importanceLevel,
    });
    
    if (score > 0) {
      results.push({
        type: "app",
        id: app.id,
        label: app.name,
        description: app.description,
        primaryApp: app.id,
        primaryAppName: app.name,
        instructions: [`Open ${app.name}`, app.description],
        score,
        tags: app.tags,
        importanceLevel: app.importanceLevel,
      });
    }
  }
  
  // Search object shortcuts
  const objects = objectStorage.getAll();
  for (const object of objects) {
    const score = calculateObjectScore(query, object);
    
    if (score > 0) {
      const app = object.openInAppId ? appStorage.getById(object.openInAppId) : null;
      
      results.push({
        type: "object",
        id: object.id,
        label: `${object.objectType}: ${object.name}`,
        description: object.description,
        primaryApp: object.openInAppId,
        primaryAppName: app ? app.name : null,
        instructions: object.openInstructions ? [object.openInstructions] : [],
        score,
        tags: object.tags,
      });
    }
  }
  
  // Sort by score (descending)
  results.sort((a: SearchResult, b: SearchResult) => b.score - a.score);
  
  // Boost pinned items
  const pins = pinStorage.getAll();
  const pinnedIds = new Set(pins.map((pin) => pin.refId));
  
  for (const result of results) {
    if (pinnedIds.has(result.id)) {
      result.score += 10; // Boost pinned items
    }
  }
  
  // Re-sort after boosting
  results.sort((a: SearchResult, b: SearchResult) => b.score - a.score);
  
  return results.slice(0, 20); // Return top 20
}

// Calculate search score
interface ScoreInput {
  name: string;
  slug: string;
  description: string;
  tags: string[];
  importanceLevel: string;
}

function calculateScore(query: string, input: ScoreInput): number {
  let score = 0;
  
  const nameLower = input.name.toLowerCase();
  const slugLower = input.slug.toLowerCase();
  const descLower = input.description.toLowerCase();
  
  // Exact slug match (highest priority)
  if (slugLower === query) {
    score += 100;
  }
  
  // Exact name match
  if (nameLower === query) {
    score += 90;
  }
  
  // Name starts with query
  if (nameLower.startsWith(query)) {
    score += 70;
  }
  
  // Slug starts with query
  if (slugLower.startsWith(query)) {
    score += 60;
  }
  
  // Name contains query
  if (nameLower.includes(query)) {
    score += 40;
  }
  
  // Slug contains query
  if (slugLower.includes(query)) {
    score += 35;
  }
  
  // Tag exact match
  for (const tag of input.tags) {
    if (tag.toLowerCase() === query) {
      score += 50;
    } else if (tag.toLowerCase().includes(query)) {
      score += 25;
    }
  }
  
  // Description contains query
  if (descLower.includes(query)) {
    score += 15;
  }
  
  // Boost by importance level
  const importanceBoost: Record<string, number> = {
    critical: 20,
    high: 10,
    medium: 5,
    low: 0,
  };
  score += importanceBoost[input.importanceLevel] || 0;
  
  return score;
}

function calculateObjectScore(query: string, object: ObjectShortcut): number {
  let score = 0;
  
  const nameLower = object.name.toLowerCase();
  const typeLower = object.objectType.toLowerCase();
  const descLower = object.description.toLowerCase();
  
  // Exact name match
  if (nameLower === query) {
    score += 90;
  }
  
  // Name starts with query
  if (nameLower.startsWith(query)) {
    score += 70;
  }
  
  // Type matches
  if (typeLower === query || typeLower.includes(query)) {
    score += 50;
  }
  
  // Name contains query
  if (nameLower.includes(query)) {
    score += 40;
  }
  
  // Tag match
  for (const tag of object.tags) {
    if (tag.toLowerCase() === query) {
      score += 50;
    } else if (tag.toLowerCase().includes(query)) {
      score += 25;
    }
  }
  
  // Description contains query
  if (descLower.includes(query)) {
    score += 15;
  }
  
  return score;
}

// Get default suggestions when no query
function getDefaultSuggestions(): SearchResult[] {
  const commands = commandStorage.getAll();
  const apps = appStorage.getAll();
  const pins = pinStorage.getAll();
  
  const results: SearchResult[] = [];
  
  // Add pinned items first
  for (const pin of pins) {
    if (pin.itemType === "command") {
      const command = commandStorage.getById(pin.refId);
      if (command) {
        const app = command.primaryAppId ? appStorage.getById(command.primaryAppId) : null;
        results.push({
          type: "command",
          id: command.id,
          label: command.name,
          description: command.description,
          primaryApp: command.primaryAppId,
          primaryAppName: app ? app.name : null,
          instructions: command.recommendedNextSteps,
          score: 100,
          tags: command.tags,
          importanceLevel: command.importanceLevel,
        });
      }
    } else if (pin.itemType === "app") {
      const app = appStorage.getById(pin.refId);
      if (app) {
        results.push({
          type: "app",
          id: app.id,
          label: app.name,
          description: app.description,
          primaryApp: app.id,
          primaryAppName: app.name,
          instructions: [`Open ${app.name}`],
          score: 95,
          tags: app.tags,
          importanceLevel: app.importanceLevel,
        });
      }
    }
  }
  
  // Add high-priority commands
  const highPriorityCommands = commands
    .filter((cmd) => cmd.importanceLevel === "critical" || cmd.importanceLevel === "high")
    .slice(0, 5);
  
  for (const command of highPriorityCommands) {
    // Skip if already in results (pinned)
    if (results.some((r) => r.id === command.id)) continue;
    
    const app = command.primaryAppId ? appStorage.getById(command.primaryAppId) : null;
    results.push({
      type: "command",
      id: command.id,
      label: command.name,
      description: command.description,
      primaryApp: command.primaryAppId,
      primaryAppName: app ? app.name : null,
      instructions: command.recommendedNextSteps,
      score: 80,
      tags: command.tags,
      importanceLevel: command.importanceLevel,
    });
  }
  
  // Add some high-importance apps
  const importantApps = apps
    .filter((app) => app.importanceLevel === "critical" || app.importanceLevel === "high")
    .slice(0, 5);
  
  for (const app of importantApps) {
    // Skip if already in results
    if (results.some((r) => r.id === app.id)) continue;
    
    results.push({
      type: "app",
      id: app.id,
      label: app.name,
      description: app.description,
      primaryApp: app.id,
      primaryAppName: app.name,
      instructions: [`Open ${app.name}`],
      score: 75,
      tags: app.tags,
      importanceLevel: app.importanceLevel,
    });
  }
  
  return results.slice(0, 10);
}
