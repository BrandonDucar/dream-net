// DreamNet Navigator - Seed Data for Initial Setup

import {
  registerAppRef,
  createCommand,
  createObjectShortcut,
} from "./navigator-service";

export function seedNavigatorData(): void {
  // Check if already seeded
  if (typeof window !== "undefined") {
    const seeded = localStorage.getItem("dreamnet_navigator_seeded");
    if (seeded === "true") {
      return; // Already seeded
    }
  }

  // Seed Apps
  const cultureCoinFoundry = registerAppRef({
    name: "CultureCoin Foundry",
    category: "culture",
    launchUrl: "/apps/culturecoin-foundry",
    description: "Design and mint CultureCoins with custom tokenomics, distribution, and on-chain metadata.",
    importanceLevel: "critical",
    tags: ["tokens", "culture", "blockchain", "minting"],
    notes: "Primary app for creating culture tokens in the DreamNet ecosystem.",
  });

  const dropArchitect = registerAppRef({
    name: "Drop Architect",
    category: "distribution",
    launchUrl: "/apps/drop-architect",
    description: "Plan and execute token drops, airdrops, and distribution campaigns with sophisticated targeting.",
    importanceLevel: "high",
    tags: ["drops", "distribution", "campaigns", "airdrops"],
    notes: "Central hub for all drop planning and execution.",
  });

  const resonanceRadar = registerAppRef({
    name: "Resonance Radar",
    category: "analytics",
    launchUrl: "/apps/resonance-radar",
    description: "Track community engagement, token velocity, and cultural resonance across the ecosystem.",
    importanceLevel: "high",
    tags: ["analytics", "metrics", "engagement", "community"],
  });

  const agentMesh = registerAppRef({
    name: "Agent Mesh",
    category: "agents",
    launchUrl: "/apps/agent-mesh",
    description: "Design, deploy, and orchestrate AI agents that power autonomous culture operations.",
    importanceLevel: "critical",
    tags: ["agents", "ai", "automation", "mesh"],
    notes: "Core infrastructure for agent-based automation.",
  });

  const flowComposer = registerAppRef({
    name: "Flow Composer",
    category: "ops",
    launchUrl: "/apps/flow-composer",
    description: "Build and manage operational flows - routines, tasks, and automated sequences.",
    importanceLevel: "high",
    tags: ["flows", "automation", "ops", "routines"],
  });

  const identityForge = registerAppRef({
    name: "Identity Forge",
    category: "identity",
    launchUrl: "/apps/identity-forge",
    description: "Manage on-chain identities, reputation, and community segments.",
    importanceLevel: "medium",
    tags: ["identity", "reputation", "segments", "community"],
  });

  const metaConsole = registerAppRef({
    name: "Meta Console",
    category: "meta",
    launchUrl: "/apps/meta-console",
    description: "Meta-level system configuration, monitoring, and governance tools.",
    importanceLevel: "high",
    tags: ["meta", "config", "monitoring", "governance"],
  });

  const baseBuilder = registerAppRef({
    name: "Base Builder",
    category: "blockchain",
    launchUrl: "https://base.org",
    description: "Access Base blockchain tools and resources for deploying contracts and infrastructure.",
    importanceLevel: "medium",
    tags: ["blockchain", "base", "contracts", "infrastructure"],
  });

  // Seed Commands
  createCommand({
    name: "Create New CultureCoin",
    commandType: "create-object",
    description: "Launch the CultureCoin Foundry to design and mint a new culture token with custom tokenomics.",
    primaryAppId: cultureCoinFoundry.id,
    relatedObjectTypes: ["culture-coin", "token"],
    recommendedNextSteps: [
      "Define token name, symbol, and supply",
      "Configure tokenomics and distribution model",
      "Set culture metadata and narrative",
      "Deploy to Base blockchain",
    ],
    importanceLevel: "critical",
    tags: ["create", "token", "culture"],
  });

  createCommand({
    name: "Plan Drop Campaign",
    commandType: "create-object",
    description: "Open Drop Architect to design a new drop campaign with targeting and distribution rules.",
    primaryAppId: dropArchitect.id,
    relatedObjectTypes: ["drop", "campaign"],
    relatedEntities: ["CultureCoin", "Community Segments"],
    recommendedNextSteps: [
      "Define drop objectives and targets",
      "Select distribution method (airdrop, claim, etc.)",
      "Set eligibility criteria and segments",
      "Schedule and launch drop",
    ],
    importanceLevel: "high",
    tags: ["drops", "distribution", "planning"],
  });

  createCommand({
    name: "Run Daily Ops Sweep",
    commandType: "run-routine",
    description: "Execute the daily operations routine to check system health, metrics, and pending actions.",
    primaryAppId: metaConsole.id,
    secondaryAppIds: [resonanceRadar.id, flowComposer.id],
    relatedObjectTypes: ["routine", "ops-flow"],
    recommendedNextSteps: [
      "Review system health dashboard",
      "Check pending agent tasks",
      "Monitor token metrics",
      "Approve or adjust automated flows",
    ],
    importanceLevel: "critical",
    tags: ["ops", "routine", "daily", "monitoring"],
  });

  createCommand({
    name: "Deploy New Agent",
    commandType: "create-object",
    description: "Create and deploy a new AI agent in the Agent Mesh to automate specific culture operations.",
    primaryAppId: agentMesh.id,
    relatedObjectTypes: ["agent", "automation"],
    recommendedNextSteps: [
      "Define agent role and objectives",
      "Configure agent permissions and scope",
      "Set agent triggers and routines",
      "Deploy and monitor agent activity",
    ],
    importanceLevel: "high",
    tags: ["agents", "automation", "deploy"],
  });

  createCommand({
    name: "Review Community Analytics",
    commandType: "inspect",
    description: "Open Resonance Radar to analyze community engagement, token flows, and cultural resonance.",
    primaryAppId: resonanceRadar.id,
    relatedObjectTypes: ["metrics", "analytics", "community"],
    recommendedNextSteps: [
      "View engagement trends",
      "Analyze token velocity",
      "Identify high-resonance content",
      "Export insights for planning",
    ],
    importanceLevel: "medium",
    tags: ["analytics", "community", "metrics"],
  });

  createCommand({
    name: "Create Operational Flow",
    commandType: "create-object",
    description: "Design a new operational flow in Flow Composer to automate repetitive tasks and routines.",
    primaryAppId: flowComposer.id,
    relatedObjectTypes: ["flow", "routine", "automation"],
    recommendedNextSteps: [
      "Map out flow steps and triggers",
      "Define inputs, outputs, and conditions",
      "Connect to agents and data sources",
      "Test and activate flow",
    ],
    importanceLevel: "medium",
    tags: ["flows", "automation", "ops"],
  });

  createCommand({
    name: "Manage Identity Segments",
    commandType: "open-view",
    description: "Open Identity Forge to create and manage community segments based on on-chain behavior.",
    primaryAppId: identityForge.id,
    relatedObjectTypes: ["identity", "segment", "reputation"],
    recommendedNextSteps: [
      "Define segment criteria",
      "Review segment membership",
      "Update reputation scores",
      "Export segment for targeting",
    ],
    importanceLevel: "medium",
    tags: ["identity", "segments", "community"],
  });

  createCommand({
    name: "Configure System Settings",
    commandType: "open-app",
    description: "Access Meta Console to adjust system-wide configuration, monitoring, and governance settings.",
    primaryAppId: metaConsole.id,
    relatedObjectTypes: ["config", "system"],
    recommendedNextSteps: [
      "Review current system configuration",
      "Adjust monitoring thresholds",
      "Update governance parameters",
      "Save and apply changes",
    ],
    importanceLevel: "high",
    tags: ["meta", "config", "system"],
  });

  // Seed Object Shortcuts
  createObjectShortcut({
    objectType: "token",
    name: "DREAM Token",
    description: "Primary culture token for the DreamNet ecosystem - represents collective creative energy.",
    openInAppId: cultureCoinFoundry.id,
    openInstructions: "Open CultureCoin Foundry → Navigate to Tokens → Search for DREAM",
    tags: ["token", "primary", "culture"],
  });

  createObjectShortcut({
    objectType: "drop",
    name: "Genesis Drop",
    description: "Initial distribution campaign that launched the DreamNet community.",
    openInAppId: dropArchitect.id,
    openInstructions: "Open Drop Architect → View Drop History → Select Genesis Drop",
    tags: ["drop", "genesis", "historical"],
  });

  createObjectShortcut({
    objectType: "agent",
    name: "Culture Curator Agent",
    description: "AI agent that identifies and amplifies high-resonance cultural content.",
    openInAppId: agentMesh.id,
    openInstructions: "Open Agent Mesh → Active Agents → Select Culture Curator",
    tags: ["agent", "curator", "automation"],
  });

  createObjectShortcut({
    objectType: "flow",
    name: "Daily Ops Flow v1",
    description: "Automated daily operations routine that checks system health and executes maintenance tasks.",
    openInAppId: flowComposer.id,
    openInstructions: "Open Flow Composer → Flows → Select Daily Ops Flow v1",
    tags: ["flow", "ops", "daily", "routine"],
  });

  createObjectShortcut({
    objectType: "segment",
    name: "Early Adopters",
    description: "Community segment of users who joined during the genesis period.",
    openInAppId: identityForge.id,
    openInstructions: "Open Identity Forge → Segments → Select Early Adopters",
    tags: ["segment", "community", "genesis"],
  });

  createObjectShortcut({
    objectType: "segment",
    name: "High Engagement",
    description: "Community members with consistently high participation and contribution scores.",
    openInAppId: identityForge.id,
    openInstructions: "Open Identity Forge → Segments → Select High Engagement",
    tags: ["segment", "engagement", "community"],
  });

  // Mark as seeded
  if (typeof window !== "undefined") {
    localStorage.setItem("dreamnet_navigator_seeded", "true");
  }
}
