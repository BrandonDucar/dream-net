// DreamNet Navigator - Core Service Functions

import type {
  AppRef,
  Command,
  RecentItem,
  Pin,
  ObjectShortcut,
  ImportanceLevel,
  CommandType,
  ItemType,
  PriorityLevel,
  HomeView,
} from "@/types/navigator";
import {
  appStorage,
  commandStorage,
  recentStorage,
  pinStorage,
  objectStorage,
} from "./navigator-storage";

// Re-export storage for direct access when needed
export { pinStorage };

// Utility: Generate slug from name
function generateSlug(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

// Utility: Generate SEO metadata
function generateSEO(name: string, description: string, tags: string[]) {
  return {
    seoTitle: name,
    seoDescription: description,
    seoKeywords: tags,
    seoHashtags: tags.map((tag: string) => `#${tag}`),
    altText: name,
  };
}

// Utility: Generate ID
function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

// ========================================
// 1) registerAppRef
// ========================================
export interface RegisterAppInput {
  name: string;
  category: string;
  launchUrl: string;
  description?: string;
  importanceLevel?: ImportanceLevel;
  tags?: string[];
  notes?: string;
}

export function registerAppRef(input: RegisterAppInput): AppRef {
  const now = new Date().toISOString();
  const slug = generateSlug(input.name);
  const tags = input.tags || [];
  const description = input.description || "";
  
  const app: AppRef = {
    id: generateId(),
    name: input.name,
    slug,
    category: input.category,
    description,
    launchUrl: input.launchUrl,
    importanceLevel: input.importanceLevel || "medium",
    tags,
    notes: input.notes || "",
    ...generateSEO(input.name, description, tags),
    createdAt: now,
    updatedAt: now,
  };
  
  appStorage.add(app);
  return app;
}

// ========================================
// 2) updateAppRef
// ========================================
export function updateAppRef(
  id: string,
  updates: Partial<Omit<AppRef, "id" | "createdAt" | "updatedAt">>
): AppRef | null {
  const app = appStorage.getById(id);
  if (!app) return null;
  
  // If name changed, regenerate slug
  if (updates.name && updates.name !== app.name) {
    updates.slug = generateSlug(updates.name);
  }
  
  // If name, description, or tags changed, regenerate SEO
  const needsSEO = updates.name || updates.description || updates.tags;
  if (needsSEO) {
    const seo = generateSEO(
      updates.name || app.name,
      updates.description || app.description,
      updates.tags || app.tags
    );
    Object.assign(updates, seo);
  }
  
  appStorage.update(id, updates);
  return appStorage.getById(id);
}

// ========================================
// 3) createCommand
// ========================================
export interface CreateCommandInput {
  name: string;
  commandType: CommandType;
  description: string;
  primaryAppId?: string | null;
  secondaryAppIds?: string[];
  relatedObjectTypes?: string[];
  relatedEntities?: string[];
  recommendedNextSteps?: string[];
  importanceLevel?: ImportanceLevel;
  tags?: string[];
  notes?: string;
}

export function createCommand(input: CreateCommandInput): Command {
  const now = new Date().toISOString();
  const slug = generateSlug(input.name);
  const tags = input.tags || [];
  
  const command: Command = {
    id: generateId(),
    name: input.name,
    slug,
    description: input.description,
    commandType: input.commandType,
    primaryAppId: input.primaryAppId || null,
    secondaryAppIds: input.secondaryAppIds || [],
    relatedObjectTypes: input.relatedObjectTypes || [],
    relatedEntities: input.relatedEntities || [],
    recommendedNextSteps: input.recommendedNextSteps || [],
    importanceLevel: input.importanceLevel || "medium",
    tags,
    notes: input.notes || "",
    ...generateSEO(input.name, input.description, tags),
    createdAt: now,
    updatedAt: now,
  };
  
  commandStorage.add(command);
  return command;
}

// ========================================
// 4) updateCommand
// ========================================
export function updateCommand(
  id: string,
  updates: Partial<Omit<Command, "id" | "createdAt" | "updatedAt">>
): Command | null {
  const command = commandStorage.getById(id);
  if (!command) return null;
  
  // If name changed, regenerate slug
  if (updates.name && updates.name !== command.name) {
    updates.slug = generateSlug(updates.name);
  }
  
  // If name, description, or tags changed, regenerate SEO
  const needsSEO = updates.name || updates.description || updates.tags;
  if (needsSEO) {
    const seo = generateSEO(
      updates.name || command.name,
      updates.description || command.description,
      updates.tags || command.tags
    );
    Object.assign(updates, seo);
  }
  
  commandStorage.update(id, updates);
  return commandStorage.getById(id);
}

// ========================================
// 5) logRecentItem
// ========================================
export function logRecentItem(
  itemType: ItemType,
  refId: string,
  label: string,
  notes: string = ""
): RecentItem {
  const recent: RecentItem = {
    id: generateId(),
    itemType,
    refId,
    label,
    openedAt: new Date().toISOString(),
    notes,
  };
  
  recentStorage.add(recent);
  return recent;
}

// ========================================
// 6) pinItem
// ========================================
export function pinItem(
  itemType: ItemType,
  refId: string,
  label: string,
  priorityLevel: PriorityLevel = "medium",
  notes: string = ""
): Pin {
  const pin: Pin = {
    id: generateId(),
    itemType,
    refId,
    label,
    priorityLevel,
    notes,
    createdAt: new Date().toISOString(),
  };
  
  pinStorage.add(pin);
  return pin;
}

// ========================================
// 7) unpinItem
// ========================================
export function unpinItem(pinId: string): boolean {
  const pin = pinStorage.getById(pinId);
  if (!pin) return false;
  
  pinStorage.delete(pinId);
  return true;
}

// ========================================
// 8) createObjectShortcut
// ========================================
export interface CreateObjectShortcutInput {
  objectType: string;
  name: string;
  description: string;
  openInAppId?: string | null;
  openInstructions?: string;
  tags?: string[];
}

export function createObjectShortcut(input: CreateObjectShortcutInput): ObjectShortcut {
  const now = new Date().toISOString();
  
  const object: ObjectShortcut = {
    id: generateId(),
    objectType: input.objectType,
    name: input.name,
    description: input.description,
    openInAppId: input.openInAppId || null,
    openInstructions: input.openInstructions || "",
    tags: input.tags || [],
    createdAt: now,
    updatedAt: now,
  };
  
  objectStorage.add(object);
  return object;
}

// ========================================
// 9) updateObjectShortcut
// ========================================
export function updateObjectShortcut(
  id: string,
  updates: Partial<Omit<ObjectShortcut, "id" | "createdAt" | "updatedAt">>
): ObjectShortcut | null {
  const object = objectStorage.getById(id);
  if (!object) return null;
  
  objectStorage.update(id, updates);
  return objectStorage.getById(id);
}

// ========================================
// 11) getHomeView
// ========================================
export function getHomeView(): HomeView {
  const pins = pinStorage.getAll();
  const recents = recentStorage.getAll();
  const commands = commandStorage.getAll();
  const apps = appStorage.getAll();
  
  // Get pinned items with details
  const pinnedItems = pins.map((pin: Pin) => {
    let details: AppRef | Command | ObjectShortcut | null = null;
    
    if (pin.itemType === "app") {
      details = appStorage.getById(pin.refId);
    } else if (pin.itemType === "command") {
      details = commandStorage.getById(pin.refId);
    } else if (pin.itemType === "object") {
      details = objectStorage.getById(pin.refId);
    }
    
    return { pin, details };
  });
  
  // Get recent items with details (last 10)
  const recentItems = recents.slice(0, 10).map((recent: RecentItem) => {
    let details: AppRef | Command | ObjectShortcut | null = null;
    
    if (recent.itemType === "app") {
      details = appStorage.getById(recent.refId);
    } else if (recent.itemType === "command") {
      details = commandStorage.getById(recent.refId);
    } else if (recent.itemType === "object") {
      details = objectStorage.getById(recent.refId);
    }
    
    return { recent, details };
  });
  
  // Get suggested commands (high/critical importance)
  const suggestedCommands = commands
    .filter((cmd: Command) => cmd.importanceLevel === "high" || cmd.importanceLevel === "critical")
    .slice(0, 6)
    .map((command: Command) => {
      const app = command.primaryAppId ? appStorage.getById(command.primaryAppId) : null;
      return { command, app };
    });
  
  return {
    pinnedItems,
    recentItems,
    suggestedCommands,
  };
}

// ========================================
// 12) exportCommandMap
// ========================================
export function exportCommandMap(): string {
  const apps = appStorage.getAll();
  const commands = commandStorage.getAll();
  
  let output = "# DreamNet Navigator - Command Map\n\n";
  output += "Generated: " + new Date().toLocaleString() + "\n\n";
  
  // List all apps
  output += "## Registered Apps\n\n";
  const categories = [...new Set(apps.map((app: AppRef) => app.category))];
  
  for (const category of categories) {
    output += `### ${category}\n\n`;
    const categoryApps = apps.filter((app: AppRef) => app.category === category);
    
    for (const app of categoryApps) {
      output += `- **${app.name}** (${app.slug})\n`;
      output += `  - ${app.description}\n`;
      output += `  - Launch: ${app.launchUrl}\n`;
      output += `  - Importance: ${app.importanceLevel}\n`;
      output += `  - Tags: ${app.tags.join(", ")}\n\n`;
    }
  }
  
  // List all commands
  output += "## Commands\n\n";
  const commandTypes = [...new Set(commands.map((cmd: Command) => cmd.commandType))];
  
  for (const type of commandTypes) {
    output += `### ${type}\n\n`;
    const typeCommands = commands.filter((cmd: Command) => cmd.commandType === type);
    
    for (const cmd of typeCommands) {
      const app = cmd.primaryAppId ? appStorage.getById(cmd.primaryAppId) : null;
      
      output += `- **${cmd.name}** (${cmd.slug})\n`;
      output += `  - ${cmd.description}\n`;
      output += `  - Routes to: ${app ? app.name : "N/A"}\n`;
      
      if (cmd.relatedObjectTypes.length > 0) {
        output += `  - Related objects: ${cmd.relatedObjectTypes.join(", ")}\n`;
      }
      
      if (cmd.recommendedNextSteps.length > 0) {
        output += `  - Next steps:\n`;
        for (const step of cmd.recommendedNextSteps) {
          output += `    - ${step}\n`;
        }
      }
      
      output += `  - Importance: ${cmd.importanceLevel}\n`;
      output += `  - Tags: ${cmd.tags.join(", ")}\n\n`;
    }
  }
  
  return output;
}

// ========================================
// 13) exportOnboardingGuide
// ========================================
export function exportOnboardingGuide(): string {
  const apps = appStorage.getAll();
  const commands = commandStorage.getAll();
  
  let guide = "# Welcome to DreamNet Navigator\n\n";
  guide += "Your unified command center for the DreamNet ecosystem.\n\n";
  
  guide += "## What is DreamNet Navigator?\n\n";
  guide += "DreamNet Navigator is your front door to everything in DreamNet. ";
  guide += "It's a command palette and launcher that lets you:\n\n";
  guide += "- Quickly search for apps, commands, and objects\n";
  guide += "- Jump to the right tool for any task\n";
  guide += "- Pin your favorite commands and apps\n";
  guide += "- Track your recent activity\n\n";
  
  guide += "## How to Use the Command Palette\n\n";
  guide += "1. Click the search bar at the top of the home screen\n";
  guide += "2. Type what you want to do (e.g., \"create culture coin\", \"daily ops\")\n";
  guide += "3. Select the matching command or app\n";
  guide += "4. Follow the suggested next steps\n\n";
  
  guide += "## Core Apps\n\n";
  const criticalApps = apps.filter((app: AppRef) => app.importanceLevel === "critical" || app.importanceLevel === "high");
  
  for (const app of criticalApps.slice(0, 10)) {
    guide += `### ${app.name}\n`;
    guide += `${app.description}\n`;
    guide += `- Category: ${app.category}\n`;
    guide += `- Tags: ${app.tags.join(", ")}\n\n`;
  }
  
  guide += "## Key Commands to Get Started\n\n";
  const keyCommands = commands
    .filter((cmd: Command) => cmd.importanceLevel === "critical" || cmd.importanceLevel === "high")
    .slice(0, 8);
  
  for (const cmd of keyCommands) {
    const app = cmd.primaryAppId ? appStorage.getById(cmd.primaryAppId) : null;
    
    guide += `### ${cmd.name}\n`;
    guide += `${cmd.description}\n`;
    guide += `- Routes to: ${app ? app.name : "Multiple apps"}\n`;
    
    if (cmd.recommendedNextSteps.length > 0) {
      guide += `- Next steps: ${cmd.recommendedNextSteps[0]}\n`;
    }
    
    guide += "\n";
  }
  
  guide += "## Tips\n\n";
  guide += "- Pin frequently used commands for instant access\n";
  guide += "- Use tags to quickly filter apps and commands\n";
  guide += "- Check your recents to revisit what you were working on\n";
  guide += "- Export the Command Map to see all available tools\n\n";
  
  guide += "---\n\n";
  guide += "Ready to explore? Start typing in the command palette!\n";
  
  return guide;
}

// Utility functions for getting all items
export function getAllApps(): AppRef[] {
  return appStorage.getAll();
}

export function getAllCommands(): Command[] {
  return commandStorage.getAll();
}

export function getAllObjects(): ObjectShortcut[] {
  return objectStorage.getAll();
}

export function getAllPins(): Pin[] {
  return pinStorage.getAll();
}

export function getAllRecents(): RecentItem[] {
  return recentStorage.getAll();
}

export function clearRecents(): void {
  recentStorage.clear();
}

export function deleteApp(id: string): void {
  appStorage.delete(id);
}

export function deleteCommand(id: string): void {
  commandStorage.delete(id);
}

export function deleteObject(id: string): void {
  objectStorage.delete(id);
}
