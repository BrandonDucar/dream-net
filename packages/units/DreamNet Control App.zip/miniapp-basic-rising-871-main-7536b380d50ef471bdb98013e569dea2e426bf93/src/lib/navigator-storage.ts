// DreamNet Navigator - Local Storage Utilities

import type {
  AppRef,
  Command,
  RecentItem,
  Pin,
  ObjectShortcut,
} from "@/types/navigator";

const STORAGE_KEYS = {
  APPS: "dreamnet_navigator_apps",
  COMMANDS: "dreamnet_navigator_commands",
  RECENTS: "dreamnet_navigator_recents",
  PINS: "dreamnet_navigator_pins",
  OBJECTS: "dreamnet_navigator_objects",
} as const;

// Generic storage functions
function getFromStorage<T>(key: string): T[] {
  if (typeof window === "undefined") return [];
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error(`Error reading from storage key ${key}:`, error);
    return [];
  }
}

function saveToStorage<T>(key: string, data: T[]): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error saving to storage key ${key}:`, error);
  }
}

// AppRef storage
export const appStorage = {
  getAll: (): AppRef[] => getFromStorage<AppRef>(STORAGE_KEYS.APPS),
  
  save: (apps: AppRef[]): void => saveToStorage(STORAGE_KEYS.APPS, apps),
  
  getById: (id: string): AppRef | null => {
    const apps = appStorage.getAll();
    return apps.find((app: AppRef) => app.id === id) || null;
  },
  
  add: (app: AppRef): void => {
    const apps = appStorage.getAll();
    apps.push(app);
    appStorage.save(apps);
  },
  
  update: (id: string, updates: Partial<AppRef>): void => {
    const apps = appStorage.getAll();
    const index = apps.findIndex((app: AppRef) => app.id === id);
    if (index !== -1) {
      apps[index] = { ...apps[index], ...updates, updatedAt: new Date().toISOString() };
      appStorage.save(apps);
    }
  },
  
  delete: (id: string): void => {
    const apps = appStorage.getAll();
    const filtered = apps.filter((app: AppRef) => app.id !== id);
    appStorage.save(filtered);
  },
};

// Command storage
export const commandStorage = {
  getAll: (): Command[] => getFromStorage<Command>(STORAGE_KEYS.COMMANDS),
  
  save: (commands: Command[]): void => saveToStorage(STORAGE_KEYS.COMMANDS, commands),
  
  getById: (id: string): Command | null => {
    const commands = commandStorage.getAll();
    return commands.find((cmd: Command) => cmd.id === id) || null;
  },
  
  add: (command: Command): void => {
    const commands = commandStorage.getAll();
    commands.push(command);
    commandStorage.save(commands);
  },
  
  update: (id: string, updates: Partial<Command>): void => {
    const commands = commandStorage.getAll();
    const index = commands.findIndex((cmd: Command) => cmd.id === id);
    if (index !== -1) {
      commands[index] = { ...commands[index], ...updates, updatedAt: new Date().toISOString() };
      commandStorage.save(commands);
    }
  },
  
  delete: (id: string): void => {
    const commands = commandStorage.getAll();
    const filtered = commands.filter((cmd: Command) => cmd.id !== id);
    commandStorage.save(filtered);
  },
};

// RecentItem storage (with max limit)
const MAX_RECENTS = 50;

export const recentStorage = {
  getAll: (): RecentItem[] => getFromStorage<RecentItem>(STORAGE_KEYS.RECENTS),
  
  save: (recents: RecentItem[]): void => saveToStorage(STORAGE_KEYS.RECENTS, recents),
  
  add: (recent: RecentItem): void => {
    let recents = recentStorage.getAll();
    
    // Remove duplicates (same itemType + refId)
    recents = recents.filter(
      (r: RecentItem) => !(r.itemType === recent.itemType && r.refId === recent.refId)
    );
    
    // Add to beginning
    recents.unshift(recent);
    
    // Keep only MAX_RECENTS
    if (recents.length > MAX_RECENTS) {
      recents = recents.slice(0, MAX_RECENTS);
    }
    
    recentStorage.save(recents);
  },
  
  clear: (): void => {
    recentStorage.save([]);
  },
};

// Pin storage
export const pinStorage = {
  getAll: (): Pin[] => getFromStorage<Pin>(STORAGE_KEYS.PINS),
  
  save: (pins: Pin[]): void => saveToStorage(STORAGE_KEYS.PINS, pins),
  
  getById: (id: string): Pin | null => {
    const pins = pinStorage.getAll();
    return pins.find((pin: Pin) => pin.id === id) || null;
  },
  
  add: (pin: Pin): void => {
    const pins = pinStorage.getAll();
    pins.push(pin);
    pinStorage.save(pins);
  },
  
  update: (id: string, updates: Partial<Pin>): void => {
    const pins = pinStorage.getAll();
    const index = pins.findIndex((pin: Pin) => pin.id === id);
    if (index !== -1) {
      pins[index] = { ...pins[index], ...updates };
      pinStorage.save(pins);
    }
  },
  
  delete: (id: string): void => {
    const pins = pinStorage.getAll();
    const filtered = pins.filter((pin: Pin) => pin.id !== id);
    pinStorage.save(filtered);
  },
};

// ObjectShortcut storage
export const objectStorage = {
  getAll: (): ObjectShortcut[] => getFromStorage<ObjectShortcut>(STORAGE_KEYS.OBJECTS),
  
  save: (objects: ObjectShortcut[]): void => saveToStorage(STORAGE_KEYS.OBJECTS, objects),
  
  getById: (id: string): ObjectShortcut | null => {
    const objects = objectStorage.getAll();
    return objects.find((obj: ObjectShortcut) => obj.id === id) || null;
  },
  
  add: (object: ObjectShortcut): void => {
    const objects = objectStorage.getAll();
    objects.push(object);
    objectStorage.save(objects);
  },
  
  update: (id: string, updates: Partial<ObjectShortcut>): void => {
    const objects = objectStorage.getAll();
    const index = objects.findIndex((obj: ObjectShortcut) => obj.id === id);
    if (index !== -1) {
      objects[index] = { ...objects[index], ...updates, updatedAt: new Date().toISOString() };
      objectStorage.save(objects);
    }
  },
  
  delete: (id: string): void => {
    const objects = objectStorage.getAll();
    const filtered = objects.filter((obj: ObjectShortcut) => obj.id !== id);
    objectStorage.save(filtered);
  },
};
