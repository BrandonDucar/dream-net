// DreamNet Navigator - Quick Actions & Inbox Service

import type { QuickAction, InboxItem } from "@/types/navigator-advanced";

const STORAGE_KEYS = {
  QUICK_ACTIONS: "dreamnet_quick_actions",
  INBOX: "dreamnet_inbox",
} as const;

function getFromStorage<T>(key: string): T[] {
  if (typeof window === "undefined") return [];
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error(`Error reading from ${key}:`, error);
    return [];
  }
}

function saveToStorage<T>(key: string, data: T[]): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error saving to ${key}:`, error);
  }
}

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

// ========================================
// QUICK ACTIONS
// ========================================

export function registerQuickAction(input: Omit<QuickAction, "id">): QuickAction {
  const action: QuickAction = {
    id: generateId(),
    ...input,
  };

  const actions = getFromStorage<QuickAction>(STORAGE_KEYS.QUICK_ACTIONS);
  actions.push(action);
  saveToStorage(STORAGE_KEYS.QUICK_ACTIONS, actions);

  return action;
}

export function getQuickActions(): QuickAction[] {
  return getFromStorage<QuickAction>(STORAGE_KEYS.QUICK_ACTIONS);
}

export function getQuickActionById(id: string): QuickAction | null {
  const actions = getQuickActions();
  return actions.find((a) => a.id === id) || null;
}

export function updateQuickAction(id: string, updates: Partial<Omit<QuickAction, "id">>): QuickAction | null {
  const actions = getQuickActions();
  const index = actions.findIndex((a) => a.id === id);

  if (index === -1) return null;

  actions[index] = { ...actions[index], ...updates };
  saveToStorage(STORAGE_KEYS.QUICK_ACTIONS, actions);

  return actions[index];
}

export function deleteQuickAction(id: string): boolean {
  const actions = getQuickActions();
  const filtered = actions.filter((a) => a.id !== id);

  if (filtered.length < actions.length) {
    saveToStorage(STORAGE_KEYS.QUICK_ACTIONS, filtered);
    return true;
  }

  return false;
}

// ========================================
// INBOX
// ========================================

export function captureToInbox(
  type: "idea" | "note" | "link" | "voice" | "screenshot",
  content: string,
  metadata: Record<string, unknown> = {},
  tags: string[] = []
): InboxItem {
  const item: InboxItem = {
    id: generateId(),
    type,
    content,
    metadata,
    capturedAt: new Date().toISOString(),
    processed: false,
    routedTo: null,
    tags,
  };

  const inbox = getFromStorage<InboxItem>(STORAGE_KEYS.INBOX);
  inbox.unshift(item); // Add to beginning

  // Keep last 200 items
  const trimmed = inbox.slice(0, 200);
  saveToStorage(STORAGE_KEYS.INBOX, trimmed);

  return item;
}

export function getInboxItems(includeProcessed: boolean = false): InboxItem[] {
  const inbox = getFromStorage<InboxItem>(STORAGE_KEYS.INBOX);
  
  if (includeProcessed) {
    return inbox;
  }

  return inbox.filter((item) => !item.processed);
}

export function getInboxItemById(id: string): InboxItem | null {
  const inbox = getInboxItems(true);
  return inbox.find((item) => item.id === id) || null;
}

export function markInboxItemProcessed(id: string, routedTo: string | null = null): InboxItem | null {
  const inbox = getFromStorage<InboxItem>(STORAGE_KEYS.INBOX);
  const index = inbox.findIndex((item) => item.id === id);

  if (index === -1) return null;

  inbox[index].processed = true;
  inbox[index].routedTo = routedTo;
  saveToStorage(STORAGE_KEYS.INBOX, inbox);

  return inbox[index];
}

export function deleteInboxItem(id: string): boolean {
  const inbox = getFromStorage<InboxItem>(STORAGE_KEYS.INBOX);
  const filtered = inbox.filter((item) => item.id !== id);

  if (filtered.length < inbox.length) {
    saveToStorage(STORAGE_KEYS.INBOX, filtered);
    return true;
  }

  return false;
}

export function clearProcessedInboxItems(): void {
  const inbox = getFromStorage<InboxItem>(STORAGE_KEYS.INBOX);
  const unprocessed = inbox.filter((item) => !item.processed);
  saveToStorage(STORAGE_KEYS.INBOX, unprocessed);
}

export function clearAllInboxItems(): void {
  saveToStorage(STORAGE_KEYS.INBOX, []);
}

// ========================================
// BUILT-IN QUICK ACTIONS
// ========================================

export function initializeDefaultQuickActions(): void {
  const existingActions = getQuickActions();
  
  // Only initialize if no actions exist
  if (existingActions.length > 0) return;

  const defaultActions: Omit<QuickAction, "id">[] = [
    {
      name: "Quick Capture Idea",
      description: "Instantly capture an idea to your inbox",
      actionType: "capture",
      icon: "💡",
      shortcut: "ctrl+shift+i",
      executeInline: true,
      formFields: [
        {
          name: "content",
          type: "text",
          label: "What's your idea?",
          placeholder: "Type your idea here...",
          required: true,
        },
        {
          name: "tags",
          type: "text",
          label: "Tags (comma-separated)",
          placeholder: "culture, drop, agent",
          required: false,
        },
      ],
    },
    {
      name: "Quick Note",
      description: "Save a quick note for later",
      actionType: "capture",
      icon: "📝",
      shortcut: "ctrl+shift+n",
      executeInline: true,
      formFields: [
        {
          name: "content",
          type: "text",
          label: "Note",
          placeholder: "Enter your note...",
          required: true,
        },
      ],
    },
    {
      name: "Save Link",
      description: "Save a link to review later",
      actionType: "capture",
      icon: "🔗",
      shortcut: null,
      executeInline: true,
      formFields: [
        {
          name: "url",
          type: "text",
          label: "URL",
          placeholder: "https://...",
          required: true,
        },
        {
          name: "description",
          type: "text",
          label: "Description",
          placeholder: "What is this link about?",
          required: false,
        },
      ],
    },
  ];

  for (const action of defaultActions) {
    registerQuickAction(action);
  }
}

// ========================================
// INBOX STATISTICS
// ========================================

export function getInboxStats(): {
  total: number;
  unprocessed: number;
  processed: number;
  byType: Record<string, number>;
  recentCaptures: number; // last 24 hours
} {
  const inbox = getFromStorage<InboxItem>(STORAGE_KEYS.INBOX);
  const unprocessed = inbox.filter((item) => !item.processed).length;
  const processed = inbox.filter((item) => item.processed).length;

  const byType: Record<string, number> = {};
  for (const item of inbox) {
    byType[item.type] = (byType[item.type] || 0) + 1;
  }

  // Recent captures (last 24 hours)
  const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const recentCaptures = inbox.filter(
    (item) => new Date(item.capturedAt) >= oneDayAgo
  ).length;

  return {
    total: inbox.length,
    unprocessed,
    processed,
    byType,
    recentCaptures,
  };
}
