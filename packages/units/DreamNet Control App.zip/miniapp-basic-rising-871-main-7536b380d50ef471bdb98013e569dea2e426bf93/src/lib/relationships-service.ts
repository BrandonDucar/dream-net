// DreamNet Navigator - Relationships & Dependencies Service

import type { AppRelationship, CommandDependency } from "@/types/navigator-advanced";
import type { AppRef, Command } from "@/types/navigator";

const STORAGE_KEYS = {
  APP_RELATIONSHIPS: "dreamnet_app_relationships",
  COMMAND_DEPENDENCIES: "dreamnet_command_dependencies",
} as const;

function getFromStorage<T>(key: string): T[] {
  if (typeof window === "undefined") return [];
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error(`Error reading from ${key}:`, error);
    return [];
  }
}

function saveToStorage<T>(key: string, data: T[]): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error saving to ${key}:`, error);
  }
}

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

// ========================================
// APP RELATIONSHIPS
// ========================================

export function createAppRelationship(
  sourceAppId: string,
  targetAppId: string,
  relationshipType: AppRelationship["relationshipType"],
  strength: number = 0.5,
  notes: string = ""
): AppRelationship {
  const relationship: AppRelationship = {
    id: generateId(),
    sourceAppId,
    targetAppId,
    relationshipType,
    strength: Math.max(0, Math.min(1, strength)),
    notes,
  };

  const relationships = getFromStorage<AppRelationship>(STORAGE_KEYS.APP_RELATIONSHIPS);
  relationships.push(relationship);
  saveToStorage(STORAGE_KEYS.APP_RELATIONSHIPS, relationships);

  return relationship;
}

export function getAppRelationships(): AppRelationship[] {
  return getFromStorage<AppRelationship>(STORAGE_KEYS.APP_RELATIONSHIPS);
}

export function getRelationshipsForApp(appId: string): AppRelationship[] {
  const relationships = getAppRelationships();
  return relationships.filter(
    (r) => r.sourceAppId === appId || r.targetAppId === appId
  );
}

export function getAppDependencies(appId: string): AppRelationship[] {
  const relationships = getAppRelationships();
  return relationships.filter(
    (r) => r.sourceAppId === appId && r.relationshipType === "depends-on"
  );
}

export function getAppDependents(appId: string): AppRelationship[] {
  const relationships = getAppRelationships();
  return relationships.filter(
    (r) => r.targetAppId === appId && r.relationshipType === "depends-on"
  );
}

export function deleteAppRelationship(id: string): boolean {
  const relationships = getAppRelationships();
  const filtered = relationships.filter((r) => r.id !== id);

  if (filtered.length < relationships.length) {
    saveToStorage(STORAGE_KEYS.APP_RELATIONSHIPS, filtered);
    return true;
  }

  return false;
}

// ========================================
// COMMAND DEPENDENCIES
// ========================================

export function setCommandDependencies(
  commandId: string,
  requiredApps: string[],
  optionalApps: string[] = [],
  requiredObjects: string[] = []
): CommandDependency {
  const dependencies = getFromStorage<CommandDependency>(STORAGE_KEYS.COMMAND_DEPENDENCIES);
  
  // Remove existing entry
  const filtered = dependencies.filter((d) => d.commandId !== commandId);
  
  const dependency: CommandDependency = {
    commandId,
    requiredApps,
    optionalApps,
    requiredObjects,
  };

  filtered.push(dependency);
  saveToStorage(STORAGE_KEYS.COMMAND_DEPENDENCIES, filtered);

  return dependency;
}

export function getCommandDependencies(): CommandDependency[] {
  return getFromStorage<CommandDependency>(STORAGE_KEYS.COMMAND_DEPENDENCIES);
}

export function getCommandDependency(commandId: string): CommandDependency | null {
  const dependencies = getCommandDependencies();
  return dependencies.find((d) => d.commandId === commandId) || null;
}

export function getCommandsRequiringApp(appId: string): CommandDependency[] {
  const dependencies = getCommandDependencies();
  return dependencies.filter(
    (d) => d.requiredApps.includes(appId) || d.optionalApps.includes(appId)
  );
}

export function deleteCommandDependency(commandId: string): boolean {
  const dependencies = getCommandDependencies();
  const filtered = dependencies.filter((d) => d.commandId !== commandId);

  if (filtered.length < dependencies.length) {
    saveToStorage(STORAGE_KEYS.COMMAND_DEPENDENCIES, filtered);
    return true;
  }

  return false;
}

// ========================================
// GRAPH GENERATION
// ========================================

export interface GraphNode {
  id: string;
  type: "app" | "command" | "object";
  label: string;
  category?: string;
  importance?: string;
}

export interface GraphEdge {
  source: string;
  target: string;
  type: string;
  strength: number;
}

export interface DependencyGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

export function generateDependencyGraph(
  apps: AppRef[],
  commands: Command[]
): DependencyGraph {
  const nodes: GraphNode[] = [];
  const edges: GraphEdge[] = [];

  // Add app nodes
  for (const app of apps) {
    nodes.push({
      id: app.id,
      type: "app",
      label: app.name,
      category: app.category,
      importance: app.importanceLevel,
    });
  }

  // Add command nodes
  for (const command of commands) {
    nodes.push({
      id: command.id,
      type: "command",
      label: command.name,
      importance: command.importanceLevel,
    });
  }

  // Add app relationship edges
  const relationships = getAppRelationships();
  for (const rel of relationships) {
    edges.push({
      source: rel.sourceAppId,
      target: rel.targetAppId,
      type: rel.relationshipType,
      strength: rel.strength,
    });
  }

  // Add command dependency edges
  const dependencies = getCommandDependencies();
  for (const dep of dependencies) {
    // Connect command to required apps
    for (const appId of dep.requiredApps) {
      edges.push({
        source: dep.commandId,
        target: appId,
        type: "requires",
        strength: 1,
      });
    }

    // Connect command to optional apps
    for (const appId of dep.optionalApps) {
      edges.push({
        source: dep.commandId,
        target: appId,
        type: "uses",
        strength: 0.5,
      });
    }
  }

  // Add command to primary app edges
  for (const command of commands) {
    if (command.primaryAppId) {
      // Check if edge already exists
      const exists = edges.some(
        (e) => e.source === command.id && e.target === command.primaryAppId && e.type === "routes-to"
      );
      
      if (!exists) {
        edges.push({
          source: command.id,
          target: command.primaryAppId,
          type: "routes-to",
          strength: 0.8,
        });
      }
    }
  }

  return { nodes, edges };
}

// ========================================
// GRAPH ANALYSIS
// ========================================

export function findShortestPath(
  graph: DependencyGraph,
  startId: string,
  endId: string
): string[] | null {
  // Simple BFS to find shortest path
  const queue: Array<{ id: string; path: string[] }> = [{ id: startId, path: [startId] }];
  const visited = new Set<string>();

  while (queue.length > 0) {
    const current = queue.shift()!;
    
    if (current.id === endId) {
      return current.path;
    }

    if (visited.has(current.id)) continue;
    visited.add(current.id);

    // Find all connected nodes
    const connectedEdges = graph.edges.filter((e) => e.source === current.id);
    
    for (const edge of connectedEdges) {
      if (!visited.has(edge.target)) {
        queue.push({
          id: edge.target,
          path: [...current.path, edge.target],
        });
      }
    }
  }

  return null;
}

export function getConnectedNodes(graph: DependencyGraph, nodeId: string): GraphNode[] {
  const connectedIds = new Set<string>();

  // Find direct connections
  for (const edge of graph.edges) {
    if (edge.source === nodeId) {
      connectedIds.add(edge.target);
    }
    if (edge.target === nodeId) {
      connectedIds.add(edge.source);
    }
  }

  return graph.nodes.filter((n) => connectedIds.has(n.id));
}

export function getMostConnectedNodes(graph: DependencyGraph, limit: number = 10): Array<{
  node: GraphNode;
  connections: number;
}> {
  const connectionCounts = new Map<string, number>();

  for (const edge of graph.edges) {
    connectionCounts.set(edge.source, (connectionCounts.get(edge.source) || 0) + 1);
    connectionCounts.set(edge.target, (connectionCounts.get(edge.target) || 0) + 1);
  }

  return Array.from(connectionCounts.entries())
    .map(([id, connections]) => ({
      node: graph.nodes.find((n) => n.id === id)!,
      connections,
    }))
    .filter((item) => item.node !== undefined)
    .sort((a, b) => b.connections - a.connections)
    .slice(0, limit);
}

// ========================================
// IMPACT ANALYSIS
// ========================================

export function analyzeAppImpact(appId: string, commands: Command[]): {
  commandsAffected: string[];
  appsDependent: string[];
  replacementSuggestions: string[];
} {
  const commandDeps = getCommandsRequiringApp(appId);
  const appDependents = getAppDependents(appId);

  return {
    commandsAffected: commandDeps.map((d) => d.commandId),
    appsDependent: appDependents.map((r) => r.sourceAppId),
    replacementSuggestions: findReplacementApps(appId),
  };
}

function findReplacementApps(appId: string): string[] {
  const relationships = getAppRelationships();
  return relationships
    .filter((r) => r.targetAppId === appId && r.relationshipType === "replaces")
    .map((r) => r.sourceAppId);
}
