// DreamNet Navigator - Keyboard Shortcuts Service

import type { KeyboardShortcut } from "@/types/navigator-advanced";

const STORAGE_KEY = "dreamnet_keyboard_shortcuts";

function getFromStorage(): KeyboardShortcut[] {
  if (typeof window === "undefined") return [];
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error("Error reading shortcuts:", error);
    return [];
  }
}

function saveToStorage(shortcuts: KeyboardShortcut[]): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(shortcuts));
  } catch (error) {
    console.error("Error saving shortcuts:", error);
  }
}

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

// ========================================
// KEYBOARD SHORTCUT MANAGEMENT
// ========================================

export function registerShortcut(
  key: string,
  commandId: string,
  description: string,
  global: boolean = false
): KeyboardShortcut | null {
  // Validate key format
  if (!isValidKeyCombo(key)) {
    console.error(`Invalid key combination: ${key}`);
    return null;
  }

  // Check for conflicts
  const existing = getShortcutByKey(key);
  if (existing) {
    console.warn(`Shortcut ${key} already exists for command ${existing.commandId}`);
    return null;
  }

  const shortcut: KeyboardShortcut = {
    id: generateId(),
    key: normalizeKeyCombo(key),
    commandId,
    description,
    global,
    enabled: true,
    createdAt: new Date().toISOString(),
  };

  const shortcuts = getFromStorage();
  shortcuts.push(shortcut);
  saveToStorage(shortcuts);

  return shortcut;
}

export function getShortcuts(): KeyboardShortcut[] {
  return getFromStorage();
}

export function getShortcutById(id: string): KeyboardShortcut | null {
  const shortcuts = getShortcuts();
  return shortcuts.find((s) => s.id === id) || null;
}

export function getShortcutByKey(key: string): KeyboardShortcut | null {
  const normalized = normalizeKeyCombo(key);
  const shortcuts = getShortcuts();
  return shortcuts.find((s) => s.key === normalized) || null;
}

export function getShortcutsByCommand(commandId: string): KeyboardShortcut[] {
  const shortcuts = getShortcuts();
  return shortcuts.filter((s) => s.commandId === commandId);
}

export function updateShortcut(
  id: string,
  updates: Partial<Omit<KeyboardShortcut, "id" | "createdAt">>
): KeyboardShortcut | null {
  const shortcuts = getShortcuts();
  const index = shortcuts.findIndex((s) => s.id === id);

  if (index === -1) return null;

  // If changing key, validate and check for conflicts
  if (updates.key) {
    const normalized = normalizeKeyCombo(updates.key);
    const existing = getShortcutByKey(normalized);
    if (existing && existing.id !== id) {
      console.error(`Key ${normalized} already in use`);
      return null;
    }
    updates.key = normalized;
  }

  shortcuts[index] = { ...shortcuts[index], ...updates };
  saveToStorage(shortcuts);

  return shortcuts[index];
}

export function deleteShortcut(id: string): boolean {
  const shortcuts = getShortcuts();
  const filtered = shortcuts.filter((s) => s.id !== id);

  if (filtered.length < shortcuts.length) {
    saveToStorage(filtered);
    return true;
  }

  return false;
}

export function toggleShortcut(id: string): KeyboardShortcut | null {
  const shortcut = getShortcutById(id);
  if (!shortcut) return null;

  return updateShortcut(id, { enabled: !shortcut.enabled });
}

// ========================================
// KEY COMBO UTILITIES
// ========================================

export function normalizeKeyCombo(key: string): string {
  // Normalize to lowercase and standardize modifier order: ctrl+shift+alt+meta+key
  const parts = key.toLowerCase().split("+").map((p) => p.trim());
  
  const modifiers: string[] = [];
  let mainKey = "";

  for (const part of parts) {
    if (part === "ctrl" || part === "control") {
      modifiers.push("ctrl");
    } else if (part === "shift") {
      modifiers.push("shift");
    } else if (part === "alt" || part === "option") {
      modifiers.push("alt");
    } else if (part === "meta" || part === "cmd" || part === "command") {
      modifiers.push("meta");
    } else {
      mainKey = part;
    }
  }

  // Sort modifiers in standard order
  const order = ["ctrl", "shift", "alt", "meta"];
  modifiers.sort((a, b) => order.indexOf(a) - order.indexOf(b));

  return [...modifiers, mainKey].join("+");
}

export function isValidKeyCombo(key: string): boolean {
  const normalized = normalizeKeyCombo(key);
  const parts = normalized.split("+");

  // Must have at least a main key
  if (parts.length === 0) return false;

  // Last part should be the main key (not a modifier)
  const mainKey = parts[parts.length - 1];
  if (["ctrl", "shift", "alt", "meta"].includes(mainKey)) return false;

  return true;
}

export function formatKeyCombo(key: string): string {
  // Format for display (e.g., "ctrl+shift+d" -> "Ctrl+Shift+D")
  const parts = key.split("+");
  return parts
    .map((part) => {
      if (part === "ctrl") return "Ctrl";
      if (part === "shift") return "Shift";
      if (part === "alt") return "Alt";
      if (part === "meta") return "⌘";
      return part.toUpperCase();
    })
    .join("+");
}

// ========================================
// EVENT HANDLING
// ========================================

export function matchesKeyEvent(shortcut: KeyboardShortcut, event: KeyboardEvent): boolean {
  if (!shortcut.enabled) return false;

  const parts = shortcut.key.split("+");
  const mainKey = parts[parts.length - 1];
  const modifiers = parts.slice(0, -1);

  // Check main key
  if (event.key.toLowerCase() !== mainKey) return false;

  // Check modifiers
  const hasCtrl = modifiers.includes("ctrl");
  const hasShift = modifiers.includes("shift");
  const hasAlt = modifiers.includes("alt");
  const hasMeta = modifiers.includes("meta");

  if (hasCtrl && !event.ctrlKey) return false;
  if (!hasCtrl && event.ctrlKey) return false;
  
  if (hasShift && !event.shiftKey) return false;
  if (!hasShift && event.shiftKey) return false;
  
  if (hasAlt && !event.altKey) return false;
  if (!hasAlt && event.altKey) return false;
  
  if (hasMeta && !event.metaKey) return false;
  if (!hasMeta && event.metaKey) return false;

  return true;
}

export function createKeyboardHandler(
  onShortcut: (shortcut: KeyboardShortcut) => void
): (event: KeyboardEvent) => void {
  return (event: KeyboardEvent) => {
    const shortcuts = getShortcuts().filter((s) => s.enabled);

    for (const shortcut of shortcuts) {
      if (matchesKeyEvent(shortcut, event)) {
        event.preventDefault();
        onShortcut(shortcut);
        break;
      }
    }
  };
}

// ========================================
// DEFAULT SHORTCUTS
// ========================================

export function initializeDefaultShortcuts(): void {
  const existing = getShortcuts();
  
  // Only initialize if no shortcuts exist
  if (existing.length > 0) return;

  const defaults: Array<Omit<KeyboardShortcut, "id" | "createdAt">> = [
    {
      key: "ctrl+k",
      commandId: "__open_palette__",
      description: "Open command palette",
      global: true,
      enabled: true,
    },
    {
      key: "ctrl+shift+i",
      commandId: "__quick_capture__",
      description: "Quick capture idea",
      global: true,
      enabled: true,
    },
    {
      key: "ctrl+shift+n",
      commandId: "__quick_note__",
      description: "Quick note",
      global: true,
      enabled: true,
    },
    {
      key: "ctrl+shift+h",
      commandId: "__command_history__",
      description: "Show command history",
      global: false,
      enabled: true,
    },
    {
      key: "ctrl+shift+p",
      commandId: "__pins_view__",
      description: "View pinned items",
      global: false,
      enabled: true,
    },
  ];

  for (const shortcut of defaults) {
    registerShortcut(
      shortcut.key,
      shortcut.commandId,
      shortcut.description,
      shortcut.global
    );
  }
}

// ========================================
// SHORTCUT CONFLICTS
// ========================================

export function checkConflicts(): Array<{ key: string; shortcuts: KeyboardShortcut[] }> {
  const shortcuts = getShortcuts();
  const conflicts: Map<string, KeyboardShortcut[]> = new Map();

  for (const shortcut of shortcuts) {
    if (!conflicts.has(shortcut.key)) {
      conflicts.set(shortcut.key, []);
    }
    conflicts.get(shortcut.key)!.push(shortcut);
  }

  return Array.from(conflicts.entries())
    .filter(([, shortcuts]) => shortcuts.length > 1)
    .map(([key, shortcuts]) => ({ key, shortcuts }));
}
