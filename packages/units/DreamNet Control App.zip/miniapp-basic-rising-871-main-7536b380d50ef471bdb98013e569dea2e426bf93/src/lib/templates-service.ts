// DreamNet Navigator - Templates & Snippets Service

import type { Template, Snippet } from "@/types/navigator-advanced";

const STORAGE_KEYS = {
  TEMPLATES: "dreamnet_templates",
  SNIPPETS: "dreamnet_snippets",
} as const;

function getFromStorage<T>(key: string): T[] {
  if (typeof window === "undefined") return [];
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error(`Error reading from ${key}:`, error);
    return [];
  }
}

function saveToStorage<T>(key: string, data: T[]): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error saving to ${key}:`, error);
  }
}

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

// ========================================
// TEMPLATE MANAGEMENT
// ========================================

export interface CreateTemplateInput {
  name: string;
  description: string;
  templateType: "drop-config" | "agent-prompt" | "flow-pattern" | "custom";
  content: string;
  variables?: Template["variables"];
  tags?: string[];
}

export function createTemplate(input: CreateTemplateInput): Template {
  const now = new Date().toISOString();

  const template: Template = {
    id: generateId(),
    name: input.name,
    description: input.description,
    templateType: input.templateType,
    content: input.content,
    variables: input.variables || [],
    tags: input.tags || [],
    usageCount: 0,
    createdAt: now,
    updatedAt: now,
  };

  const templates = getFromStorage<Template>(STORAGE_KEYS.TEMPLATES);
  templates.push(template);
  saveToStorage(STORAGE_KEYS.TEMPLATES, templates);

  return template;
}

export function getTemplates(): Template[] {
  return getFromStorage<Template>(STORAGE_KEYS.TEMPLATES);
}

export function getTemplateById(id: string): Template | null {
  const templates = getTemplates();
  return templates.find((t) => t.id === id) || null;
}

export function getTemplatesByType(
  type: "drop-config" | "agent-prompt" | "flow-pattern" | "custom"
): Template[] {
  const templates = getTemplates();
  return templates.filter((t) => t.templateType === type);
}

export function updateTemplate(
  id: string,
  updates: Partial<Omit<Template, "id" | "createdAt" | "usageCount">>
): Template | null {
  const templates = getTemplates();
  const index = templates.findIndex((t) => t.id === id);

  if (index === -1) return null;

  templates[index] = {
    ...templates[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };
  saveToStorage(STORAGE_KEYS.TEMPLATES, templates);

  return templates[index];
}

export function deleteTemplate(id: string): boolean {
  const templates = getTemplates();
  const filtered = templates.filter((t) => t.id !== id);

  if (filtered.length < templates.length) {
    saveToStorage(STORAGE_KEYS.TEMPLATES, filtered);
    return true;
  }

  return false;
}

export function incrementTemplateUsage(id: string): Template | null {
  const templates = getTemplates();
  const index = templates.findIndex((t) => t.id === id);

  if (index === -1) return null;

  templates[index].usageCount++;
  saveToStorage(STORAGE_KEYS.TEMPLATES, templates);

  return templates[index];
}

// ========================================
// TEMPLATE RENDERING
// ========================================

export function renderTemplate(
  templateId: string,
  variables: Record<string, string>
): string | null {
  const template = getTemplateById(templateId);
  if (!template) return null;

  let rendered = template.content;

  // Replace variables (format: {{variableName}})
  for (const [key, value] of Object.entries(variables)) {
    const regex = new RegExp(`{{${key}}}`, "g");
    rendered = rendered.replace(regex, value);
  }

  // Increment usage
  incrementTemplateUsage(templateId);

  return rendered;
}

export function getTemplateVariables(templateId: string): Template["variables"] | null {
  const template = getTemplateById(templateId);
  return template ? template.variables : null;
}

// ========================================
// SNIPPET MANAGEMENT
// ========================================

export interface CreateSnippetInput {
  trigger: string;
  expansion: string;
  description: string;
  tags?: string[];
}

export function createSnippet(input: CreateSnippetInput): Snippet {
  const snippet: Snippet = {
    id: generateId(),
    trigger: input.trigger,
    expansion: input.expansion,
    description: input.description,
    tags: input.tags || [],
    usageCount: 0,
    createdAt: new Date().toISOString(),
  };

  const snippets = getFromStorage<Snippet>(STORAGE_KEYS.SNIPPETS);
  snippets.push(snippet);
  saveToStorage(STORAGE_KEYS.SNIPPETS, snippets);

  return snippet;
}

export function getSnippets(): Snippet[] {
  return getFromStorage<Snippet>(STORAGE_KEYS.SNIPPETS);
}

export function getSnippetById(id: string): Snippet | null {
  const snippets = getSnippets();
  return snippets.find((s) => s.id === id) || null;
}

export function getSnippetByTrigger(trigger: string): Snippet | null {
  const snippets = getSnippets();
  return snippets.find((s) => s.trigger === trigger) || null;
}

export function updateSnippet(
  id: string,
  updates: Partial<Omit<Snippet, "id" | "createdAt" | "usageCount">>
): Snippet | null {
  const snippets = getSnippets();
  const index = snippets.findIndex((s) => s.id === id);

  if (index === -1) return null;

  snippets[index] = { ...snippets[index], ...updates };
  saveToStorage(STORAGE_KEYS.SNIPPETS, snippets);

  return snippets[index];
}

export function deleteSnippet(id: string): boolean {
  const snippets = getSnippets();
  const filtered = snippets.filter((s) => s.id !== id);

  if (filtered.length < snippets.length) {
    saveToStorage(STORAGE_KEYS.SNIPPETS, filtered);
    return true;
  }

  return false;
}

export function incrementSnippetUsage(id: string): Snippet | null {
  const snippets = getSnippets();
  const index = snippets.findIndex((s) => s.id === id);

  if (index === -1) return null;

  snippets[index].usageCount++;
  saveToStorage(STORAGE_KEYS.SNIPPETS, snippets);

  return snippets[index];
}

// ========================================
// SNIPPET EXPANSION
// ========================================

export function expandSnippet(trigger: string): string | null {
  const snippet = getSnippetByTrigger(trigger);
  if (!snippet) return null;

  incrementSnippetUsage(snippet.id);
  return snippet.expansion;
}

export function detectSnippetTrigger(text: string): Snippet | null {
  const snippets = getSnippets();
  
  // Sort by trigger length (longest first) to match longer triggers first
  const sorted = snippets.sort((a, b) => b.trigger.length - a.trigger.length);

  for (const snippet of sorted) {
    if (text.endsWith(snippet.trigger)) {
      return snippet;
    }
  }

  return null;
}

// ========================================
// DEFAULT TEMPLATES & SNIPPETS
// ========================================

export function initializeDefaultTemplates(): void {
  const existing = getTemplates();
  
  // Only initialize if no templates exist
  if (existing.length > 0) return;

  const defaults: CreateTemplateInput[] = [
    {
      name: "Culture Drop Configuration",
      description: "Standard configuration for a new culture drop",
      templateType: "drop-config",
      content: `Drop Name: {{dropName}}
Token Symbol: {{symbol}}
Total Supply: {{supply}}
Distribution Method: {{distributionMethod}}
Launch Date: {{launchDate}}
Target Audience: {{audience}}
Special Rules: {{rules}}`,
      variables: [
        { name: "dropName", type: "text", required: true, description: "Name of the drop" },
        { name: "symbol", type: "text", required: true, description: "Token symbol" },
        { name: "supply", type: "number", required: true, description: "Total supply" },
        { name: "distributionMethod", type: "select", required: true, description: "How tokens are distributed" },
        { name: "launchDate", type: "date", required: true, description: "When to launch" },
        { name: "audience", type: "text", required: false, description: "Target audience" },
        { name: "rules", type: "text", required: false, description: "Special rules" },
      ],
      tags: ["drop", "culture", "configuration"],
    },
    {
      name: "Agent System Prompt",
      description: "Base system prompt for DreamNet agents",
      templateType: "agent-prompt",
      content: `You are {{agentName}}, a {{agentRole}} agent in the DreamNet ecosystem.

Your primary responsibilities:
{{responsibilities}}

Your capabilities:
{{capabilities}}

Context: {{context}}

Guidelines:
- {{guideline1}}
- {{guideline2}}
- {{guideline3}}`,
      variables: [
        { name: "agentName", type: "text", required: true, description: "Agent name" },
        { name: "agentRole", type: "text", required: true, description: "Agent role" },
        { name: "responsibilities", type: "text", required: true, description: "Primary responsibilities" },
        { name: "capabilities", type: "text", required: true, description: "Agent capabilities" },
        { name: "context", type: "text", required: false, description: "Additional context" },
        { name: "guideline1", type: "text", required: true, description: "First guideline" },
        { name: "guideline2", type: "text", required: true, description: "Second guideline" },
        { name: "guideline3", type: "text", required: true, description: "Third guideline" },
      ],
      tags: ["agent", "prompt", "system"],
    },
  ];

  for (const template of defaults) {
    createTemplate(template);
  }
}

export function initializeDefaultSnippets(): void {
  const existing = getSnippets();
  
  // Only initialize if no snippets exist
  if (existing.length > 0) return;

  const defaults: CreateSnippetInput[] = [
    {
      trigger: "/drop",
      expansion: "Create new drop → Design → Set distribution → Launch",
      description: "Drop creation workflow",
      tags: ["drop", "workflow"],
    },
    {
      trigger: "/agent",
      expansion: "Define agent role → Set capabilities → Configure prompts → Test",
      description: "Agent setup workflow",
      tags: ["agent", "workflow"],
    },
    {
      trigger: "/ops",
      expansion: "Daily Ops: Sweep → Review Agents → Check Drops → Generate Report",
      description: "Daily operations checklist",
      tags: ["ops", "daily"],
    },
  ];

  for (const snippet of defaults) {
    createSnippet(snippet);
  }
}

// ========================================
// TEMPLATE STATISTICS
// ========================================

export function getTemplateStats(): {
  total: number;
  byType: Record<string, number>;
  mostUsed: Array<{ template: Template; count: number }>;
} {
  const templates = getTemplates();

  const byType: Record<string, number> = {};
  for (const template of templates) {
    byType[template.templateType] = (byType[template.templateType] || 0) + 1;
  }

  const mostUsed = templates
    .sort((a, b) => b.usageCount - a.usageCount)
    .slice(0, 5)
    .map((template) => ({ template, count: template.usageCount }));

  return {
    total: templates.length,
    byType,
    mostUsed,
  };
}
