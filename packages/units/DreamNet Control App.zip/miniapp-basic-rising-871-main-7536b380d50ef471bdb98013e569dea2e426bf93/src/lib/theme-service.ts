// DreamNet Navigator - Theme & Customization Service

import type { ThemeConfig } from "@/types/navigator-advanced";

const STORAGE_KEY = "dreamnet_themes";
const ACTIVE_THEME_KEY = "dreamnet_active_theme";

function getFromStorage(): ThemeConfig[] {
  if (typeof window === "undefined") return [];
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error("Error reading themes:", error);
    return [];
  }
}

function saveToStorage(themes: ThemeConfig[]): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(themes));
  } catch (error) {
    console.error("Error saving themes:", error);
  }
}

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

// ========================================
// THEME MANAGEMENT
// ========================================

export function createTheme(
  name: string,
  mode: "light" | "dark" | "auto",
  accentColor: string = "#3b82f6",
  layoutDensity: "compact" | "comfortable" | "spacious" = "comfortable",
  fontScale: number = 1.0,
  customCSS: string = ""
): ThemeConfig {
  const theme: ThemeConfig = {
    id: generateId(),
    name,
    mode,
    accentColor,
    layoutDensity,
    fontScale: Math.max(0.8, Math.min(1.5, fontScale)),
    customCSS,
    active: false,
  };

  const themes = getFromStorage();
  themes.push(theme);
  saveToStorage(themes);

  return theme;
}

export function getThemes(): ThemeConfig[] {
  return getFromStorage();
}

export function getThemeById(id: string): ThemeConfig | null {
  const themes = getThemes();
  return themes.find((t) => t.id === id) || null;
}

export function getActiveTheme(): ThemeConfig | null {
  const themes = getThemes();
  return themes.find((t) => t.active) || null;
}

export function updateTheme(id: string, updates: Partial<Omit<ThemeConfig, "id">>): ThemeConfig | null {
  const themes = getThemes();
  const index = themes.findIndex((t) => t.id === id);

  if (index === -1) return null;

  // Validate fontScale
  if (updates.fontScale) {
    updates.fontScale = Math.max(0.8, Math.min(1.5, updates.fontScale));
  }

  themes[index] = { ...themes[index], ...updates };
  saveToStorage(themes);

  // If this theme is active, apply it
  if (themes[index].active) {
    applyTheme(themes[index]);
  }

  return themes[index];
}

export function deleteTheme(id: string): boolean {
  const theme = getThemeById(id);
  if (theme?.active) {
    console.error("Cannot delete active theme. Switch to another theme first.");
    return false;
  }

  const themes = getThemes();
  const filtered = themes.filter((t) => t.id !== id);

  if (filtered.length < themes.length) {
    saveToStorage(filtered);
    return true;
  }

  return false;
}

export function activateTheme(id: string): boolean {
  const themes = getThemes();
  const theme = themes.find((t) => t.id === id);

  if (!theme) return false;

  // Deactivate all themes
  for (const t of themes) {
    t.active = false;
  }

  // Activate selected theme
  theme.active = true;
  saveToStorage(themes);

  // Apply theme
  applyTheme(theme);

  if (typeof window !== "undefined") {
    localStorage.setItem(ACTIVE_THEME_KEY, id);
  }

  return true;
}

// ========================================
// THEME APPLICATION
// ========================================

export function applyTheme(theme: ThemeConfig): void {
  if (typeof window === "undefined") return;

  const root = document.documentElement;

  // Apply color mode
  if (theme.mode === "auto") {
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    root.classList.toggle("dark", prefersDark);
  } else {
    root.classList.toggle("dark", theme.mode === "dark");
  }

  // Apply accent color
  root.style.setProperty("--accent-color", theme.accentColor);

  // Apply layout density
  const densityMap = {
    compact: "0.875rem",
    comfortable: "1rem",
    spacious: "1.25rem",
  };
  root.style.setProperty("--base-spacing", densityMap[theme.layoutDensity]);

  // Apply font scale
  root.style.setProperty("--font-scale", theme.fontScale.toString());

  // Apply custom CSS
  let styleElement = document.getElementById("dreamnet-custom-theme");
  if (!styleElement) {
    styleElement = document.createElement("style");
    styleElement.id = "dreamnet-custom-theme";
    document.head.appendChild(styleElement);
  }
  styleElement.textContent = theme.customCSS;
}

export function removeCustomCSS(): void {
  if (typeof window === "undefined") return;
  
  const styleElement = document.getElementById("dreamnet-custom-theme");
  if (styleElement) {
    styleElement.remove();
  }
}

// ========================================
// PRESET THEMES
// ========================================

export function initializeDefaultThemes(): void {
  const existing = getThemes();
  
  // Only initialize if no themes exist
  if (existing.length > 0) return;

  // Default Light Theme
  const defaultLight = createTheme(
    "Default Light",
    "light",
    "#3b82f6",
    "comfortable",
    1.0
  );
  activateTheme(defaultLight.id);

  // Default Dark Theme
  createTheme(
    "Default Dark",
    "dark",
    "#60a5fa",
    "comfortable",
    1.0
  );

  // High Contrast Theme
  createTheme(
    "High Contrast",
    "dark",
    "#fbbf24",
    "comfortable",
    1.1
  );

  // Compact Theme
  createTheme(
    "Compact",
    "auto",
    "#8b5cf6",
    "compact",
    0.95
  );

  // Spacious Theme
  createTheme(
    "Spacious",
    "auto",
    "#10b981",
    "spacious",
    1.05
  );
}

// ========================================
// THEME EXPORT/IMPORT
// ========================================

export function exportTheme(id: string): string | null {
  const theme = getThemeById(id);
  if (!theme) return null;

  return JSON.stringify(theme, null, 2);
}

export function importTheme(themeJson: string): ThemeConfig | null {
  try {
    const theme: ThemeConfig = JSON.parse(themeJson);
    
    // Validate theme structure
    if (!theme.name || !theme.mode || !theme.accentColor) {
      throw new Error("Invalid theme structure");
    }

    // Generate new ID
    const newTheme: ThemeConfig = {
      ...theme,
      id: generateId(),
      active: false,
    };

    const themes = getThemes();
    themes.push(newTheme);
    saveToStorage(themes);

    return newTheme;
  } catch (error) {
    console.error("Error importing theme:", error);
    return null;
  }
}

// ========================================
// THEME UTILITIES
// ========================================

export function duplicateTheme(id: string, newName: string): ThemeConfig | null {
  const theme = getThemeById(id);
  if (!theme) return null;

  return createTheme(
    newName,
    theme.mode,
    theme.accentColor,
    theme.layoutDensity,
    theme.fontScale,
    theme.customCSS
  );
}

export function resetTheme(): void {
  const themes = getThemes();
  const defaultLight = themes.find((t) => t.name === "Default Light");

  if (defaultLight) {
    activateTheme(defaultLight.id);
  } else {
    // Create and activate default theme
    initializeDefaultThemes();
  }
}

// ========================================
// SYSTEM THEME DETECTION
// ========================================

export function setupAutoThemeSync(): void {
  if (typeof window === "undefined") return;

  const activeTheme = getActiveTheme();
  if (!activeTheme || activeTheme.mode !== "auto") return;

  const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
  
  const handleChange = (e: MediaQueryListEvent): void => {
    const theme = getActiveTheme();
    if (theme && theme.mode === "auto") {
      applyTheme(theme);
    }
  };

  // Modern browsers
  if (mediaQuery.addEventListener) {
    mediaQuery.addEventListener("change", handleChange);
  } else {
    // Fallback for older browsers
    mediaQuery.addListener(handleChange);
  }
}

// ========================================
// INITIALIZE ON LOAD
// ========================================

export function initializeThemeSystem(): void {
  const themes = getThemes();
  
  if (themes.length === 0) {
    initializeDefaultThemes();
  }

  const activeTheme = getActiveTheme();
  if (activeTheme) {
    applyTheme(activeTheme);
  }

  setupAutoThemeSync();
}
