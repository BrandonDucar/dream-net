// DreamNet Navigator - Workflows & Command Chaining Service

import type { Workflow, WorkflowStep, WorkflowExecution } from "@/types/navigator-advanced";

const STORAGE_KEYS = {
  WORKFLOWS: "dreamnet_workflows",
  EXECUTIONS: "dreamnet_workflow_executions",
} as const;

function getFromStorage<T>(key: string): T[] {
  if (typeof window === "undefined") return [];
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error(`Error reading from ${key}:`, error);
    return [];
  }
}

function saveToStorage<T>(key: string, data: T[]): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error saving to ${key}:`, error);
  }
}

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

// ========================================
// WORKFLOW MANAGEMENT
// ========================================

export interface CreateWorkflowInput {
  name: string;
  description: string;
  steps: Omit<WorkflowStep, "id">[];
  triggers?: string[];
  tags?: string[];
}

export function createWorkflow(input: CreateWorkflowInput): Workflow {
  const now = new Date().toISOString();

  const workflow: Workflow = {
    id: generateId(),
    name: input.name,
    description: input.description,
    steps: input.steps.map((step, index) => ({
      id: generateId(),
      order: index,
      ...step,
    })),
    triggers: input.triggers || [],
    createdAt: now,
    updatedAt: now,
    tags: input.tags || [],
  };

  const workflows = getFromStorage<Workflow>(STORAGE_KEYS.WORKFLOWS);
  workflows.push(workflow);
  saveToStorage(STORAGE_KEYS.WORKFLOWS, workflows);

  return workflow;
}

export function getWorkflows(): Workflow[] {
  return getFromStorage<Workflow>(STORAGE_KEYS.WORKFLOWS);
}

export function getWorkflowById(id: string): Workflow | null {
  const workflows = getWorkflows();
  return workflows.find((w) => w.id === id) || null;
}

export function updateWorkflow(id: string, updates: Partial<Omit<Workflow, "id" | "createdAt">>): Workflow | null {
  const workflows = getWorkflows();
  const index = workflows.findIndex((w) => w.id === id);

  if (index === -1) return null;

  workflows[index] = {
    ...workflows[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };
  saveToStorage(STORAGE_KEYS.WORKFLOWS, workflows);

  return workflows[index];
}

export function deleteWorkflow(id: string): boolean {
  const workflows = getWorkflows();
  const filtered = workflows.filter((w) => w.id !== id);

  if (filtered.length < workflows.length) {
    saveToStorage(STORAGE_KEYS.WORKFLOWS, filtered);
    return true;
  }

  return false;
}

// ========================================
// WORKFLOW EXECUTION
// ========================================

export function startWorkflowExecution(workflowId: string): WorkflowExecution | null {
  const workflow = getWorkflowById(workflowId);
  if (!workflow || workflow.steps.length === 0) return null;

  const execution: WorkflowExecution = {
    id: generateId(),
    workflowId,
    startedAt: new Date().toISOString(),
    completedAt: null,
    currentStepId: workflow.steps[0].id,
    status: "running",
    results: {},
  };

  const executions = getFromStorage<WorkflowExecution>(STORAGE_KEYS.EXECUTIONS);
  executions.push(execution);

  // Keep last 100 executions
  const trimmed = executions.slice(-100);
  saveToStorage(STORAGE_KEYS.EXECUTIONS, trimmed);

  return execution;
}

export function getWorkflowExecution(executionId: string): WorkflowExecution | null {
  const executions = getFromStorage<WorkflowExecution>(STORAGE_KEYS.EXECUTIONS);
  return executions.find((e) => e.id === executionId) || null;
}

export function updateWorkflowExecution(
  executionId: string,
  updates: Partial<Omit<WorkflowExecution, "id" | "workflowId" | "startedAt">>
): WorkflowExecution | null {
  const executions = getFromStorage<WorkflowExecution>(STORAGE_KEYS.EXECUTIONS);
  const index = executions.findIndex((e) => e.id === executionId);

  if (index === -1) return null;

  executions[index] = { ...executions[index], ...updates };
  saveToStorage(STORAGE_KEYS.EXECUTIONS, executions);

  return executions[index];
}

export function completeWorkflowStep(
  executionId: string,
  stepId: string,
  result: Record<string, unknown>
): WorkflowExecution | null {
  const execution = getWorkflowExecution(executionId);
  if (!execution) return null;

  const workflow = getWorkflowById(execution.workflowId);
  if (!workflow) return null;

  // Store step result
  execution.results[stepId] = result;

  // Find next step
  const currentStepIndex = workflow.steps.findIndex((s) => s.id === stepId);
  if (currentStepIndex === -1) return null;

  const currentStep = workflow.steps[currentStepIndex];

  // Check for conditional branching
  let nextStepId: string | null = null;

  if (currentStep.conditionalNext) {
    // Simple condition evaluation (in real implementation, this would be more sophisticated)
    const condition = currentStep.conditionalNext.condition;
    const success = result.success === true;

    if (condition.includes("success") && success) {
      nextStepId = currentStep.conditionalNext.nextStepId;
    } else if (currentStep.conditionalNext.elseStepId) {
      nextStepId = currentStep.conditionalNext.elseStepId;
    }
  } else {
    // Move to next step in sequence
    if (currentStepIndex < workflow.steps.length - 1) {
      nextStepId = workflow.steps[currentStepIndex + 1].id;
    }
  }

  if (nextStepId) {
    // Continue to next step
    return updateWorkflowExecution(executionId, {
      currentStepId: nextStepId,
      results: execution.results,
    });
  } else {
    // Workflow complete
    return updateWorkflowExecution(executionId, {
      currentStepId: null,
      completedAt: new Date().toISOString(),
      status: "completed",
      results: execution.results,
    });
  }
}

export function pauseWorkflowExecution(executionId: string): WorkflowExecution | null {
  return updateWorkflowExecution(executionId, { status: "paused" });
}

export function resumeWorkflowExecution(executionId: string): WorkflowExecution | null {
  return updateWorkflowExecution(executionId, { status: "running" });
}

export function failWorkflowExecution(executionId: string, error: string): WorkflowExecution | null {
  return updateWorkflowExecution(executionId, {
    status: "failed",
    completedAt: new Date().toISOString(),
    results: { error },
  });
}

// ========================================
// WORKFLOW DISCOVERY
// ========================================

export function getWorkflowsByTrigger(trigger: string): Workflow[] {
  const workflows = getWorkflows();
  return workflows.filter((w) => w.triggers.includes(trigger));
}

export function getWorkflowHistory(workflowId: string, limit: number = 10): WorkflowExecution[] {
  const executions = getFromStorage<WorkflowExecution>(STORAGE_KEYS.EXECUTIONS);
  return executions
    .filter((e) => e.workflowId === workflowId)
    .sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime())
    .slice(0, limit);
}

export function getRecentExecutions(limit: number = 10): WorkflowExecution[] {
  const executions = getFromStorage<WorkflowExecution>(STORAGE_KEYS.EXECUTIONS);
  return executions
    .sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime())
    .slice(0, limit);
}

// ========================================
// BUILT-IN WORKFLOWS
// ========================================

export function initializeDefaultWorkflows(): void {
  const existingWorkflows = getWorkflows();
  
  // Only initialize if no workflows exist
  if (existingWorkflows.length > 0) return;

  // Daily Ops Workflow
  createWorkflow({
    name: "Daily Operations Sweep",
    description: "Complete daily operational tasks in sequence",
    triggers: ["daily-ops", "morning-routine"],
    tags: ["ops", "daily", "routine"],
    steps: [
      {
        order: 0,
        commandId: "placeholder-daily-sweep",
        waitForCompletion: true,
        conditionalNext: null,
        params: {},
      },
      {
        order: 1,
        commandId: "placeholder-review-agents",
        waitForCompletion: true,
        conditionalNext: null,
        params: {},
      },
      {
        order: 2,
        commandId: "placeholder-check-drops",
        waitForCompletion: false,
        conditionalNext: null,
        params: {},
      },
    ],
  });

  // New Culture Drop Workflow
  createWorkflow({
    name: "Create New Culture Drop",
    description: "Complete workflow for creating and launching a culture drop",
    triggers: ["new-drop", "create-drop"],
    tags: ["culture", "drop", "creation"],
    steps: [
      {
        order: 0,
        commandId: "placeholder-create-culture-coin",
        waitForCompletion: true,
        conditionalNext: null,
        params: {},
      },
      {
        order: 1,
        commandId: "placeholder-design-drop",
        waitForCompletion: true,
        conditionalNext: null,
        params: {},
      },
      {
        order: 2,
        commandId: "placeholder-set-distribution",
        waitForCompletion: true,
        conditionalNext: null,
        params: {},
      },
    ],
  });
}
