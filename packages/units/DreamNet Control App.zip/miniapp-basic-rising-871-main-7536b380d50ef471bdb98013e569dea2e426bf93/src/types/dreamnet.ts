// DreamNet Agent Mesh & Taskboard - Type Definitions

export type AgentType = 
  | "gpt" 
  | "backend-service" 
  | "ohara-mini-app" 
  | "bot" 
  | "human-operator" 
  | "external-integration" 
  | "other";

export type ImportanceLevel = "low" | "medium" | "high" | "critical";

export type AgentStatus = "idea" | "planned" | "implemented" | "paused" | "retired";

export interface SEOMetadata {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export interface AgentNode {
  id: string;
  name: string;
  slug: string;
  type: AgentType;
  description: string;
  archetype: string;
  capabilities: string[];
  limitations: string[];
  primaryDomain: string;
  secondaryDomains: string[];
  importanceLevel: ImportanceLevel;
  status: AgentStatus;
  notes: string;
  seo: SEOMetadata;
}

export type InterfaceType = 
  | "api" 
  | "cli" 
  | "ohara-ui" 
  | "gpt-frontend" 
  | "webhook" 
  | "cron" 
  | "manual";

export interface AgentInterface {
  id: string;
  agentId: string;
  interfaceType: InterfaceType;
  endpointOrIdentifier: string;
  description: string;
  notes: string;
}

export type FrequencyHint = 
  | "ad-hoc" 
  | "on-demand" 
  | "daily" 
  | "weekly" 
  | "per-launch" 
  | "per-event";

export interface TaskType {
  id: string;
  name: string;
  code: string;
  description: string;
  category: string;
  defaultOwnerAgentIds: string[];
  expectedInputs: string[];
  expectedOutputs: string[];
  frequencyHint: FrequencyHint;
  tags: string[];
  notes: string;
  seo: SEOMetadata;
}

export type PriorityLevel = "low" | "medium" | "high" | "critical";

export type TaskStatus = 
  | "planned" 
  | "in-progress" 
  | "blocked" 
  | "waiting-on-external" 
  | "completed" 
  | "cancelled";

export interface TaskInstance {
  id: string;
  taskTypeId: string;
  title: string;
  description: string;
  ownerAgentId: string | null;
  participants: string[];
  priorityLevel: PriorityLevel;
  status: TaskStatus;
  dueAt: string | null;
  createdAt: string;
  updatedAt: string;
  relatedObjectRefs: Record<string, string>;
  notes: string;
}

export type RoutineFrequency = 
  | "daily" 
  | "weekly" 
  | "monthly" 
  | "per-launch" 
  | "per-event" 
  | "custom";

export interface Routine {
  id: string;
  name: string;
  description: string;
  frequency: RoutineFrequency;
  ownerAgentId: string | null;
  stepTaskTypeIds: string[];
  tags: string[];
  notes: string;
}

export type RelationKind = 
  | "delegates-to" 
  | "supervises" 
  | "depends-on" 
  | "mirrors" 
  | "backs-up" 
  | "feeds" 
  | "monitors";

export type LinkStrength = "weak" | "normal" | "strong" | "critical";

export interface AgentLink {
  id: string;
  fromAgentId: string;
  toAgentId: string;
  relationKind: RelationKind;
  description: string;
  strength: LinkStrength;
  notes: string;
}

export interface DreamNetStore {
  agents: AgentNode[];
  interfaces: AgentInterface[];
  taskTypes: TaskType[];
  taskInstances: TaskInstance[];
  routines: Routine[];
  agentLinks: AgentLink[];
}
