// DreamNet Navigator - Advanced Feature Types

import type { ImportanceLevel, ItemType } from "./navigator";

// ========================================
// ANALYTICS & INSIGHTS
// ========================================

export interface SearchQuery {
  id: string;
  query: string;
  timestamp: string;
  resultsCount: number;
  selectedResultId: string | null;
  selectedResultType: ItemType | null;
  timeToSelect: number | null; // milliseconds
}

export interface CommandExecution {
  id: string;
  commandId: string;
  commandName: string;
  timestamp: string;
  duration: number | null; // milliseconds spent in command context
  success: boolean;
}

export interface DeadEndSearch {
  id: string;
  query: string;
  timestamp: string;
  attemptCount: number;
  suggestedAlternatives: string[];
}

export interface UsageStats {
  period: "daily" | "weekly" | "monthly";
  startDate: string;
  endDate: string;
  totalSearches: number;
  totalCommands: number;
  mostUsedCommands: Array<{ commandId: string; count: number }>;
  mostUsedApps: Array<{ appId: string; count: number }>;
  peakUsageHours: number[];
  deadEndSearches: number;
  avgTimeToSelect: number;
}

// ========================================
// FUZZY MATCHING & ALIASES
// ========================================

export interface CommandAlias {
  commandId: string;
  aliases: string[]; // Multiple ways to trigger the same command
  naturalLanguagePatterns: string[]; // "I want to...", "help me..."
}

export interface FuzzyMatchResult {
  text: string;
  score: number;
  distance: number; // Levenshtein distance
  type: "exact" | "fuzzy" | "alias" | "natural";
}

// ========================================
// QUICK ACTIONS & INBOX
// ========================================

export interface QuickAction {
  id: string;
  name: string;
  description: string;
  actionType: "capture" | "execute" | "preview";
  icon: string;
  shortcut: string | null;
  executeInline: boolean; // Can run without leaving palette
  formFields?: QuickActionField[];
}

export interface QuickActionField {
  name: string;
  type: "text" | "number" | "select" | "date";
  label: string;
  placeholder?: string;
  required: boolean;
  options?: string[]; // For select type
}

export interface InboxItem {
  id: string;
  type: "idea" | "note" | "link" | "voice" | "screenshot";
  content: string;
  metadata: Record<string, unknown>;
  capturedAt: string;
  processed: boolean;
  routedTo: string | null; // AppRef.id or Command.id
  tags: string[];
}

// ========================================
// CONTEXT AWARENESS
// ========================================

export interface ContextRule {
  id: string;
  name: string;
  condition: ContextCondition;
  suggestions: string[]; // Command IDs to suggest
  priority: number;
}

export interface ContextCondition {
  type: "time" | "day" | "usage-pattern" | "recent-object" | "custom";
  params: Record<string, unknown>;
}

export interface WorkContext {
  currentObjects: Array<{ type: string; id: string; name: string }>;
  recentPatterns: string[]; // Recent command sequences
  activeProjects: string[];
  lastActivity: string;
}

// ========================================
// WORKFLOWS & COMMAND CHAINING
// ========================================

export interface Workflow {
  id: string;
  name: string;
  description: string;
  steps: WorkflowStep[];
  triggers: string[]; // Command slugs that can trigger this
  createdAt: string;
  updatedAt: string;
  tags: string[];
}

export interface WorkflowStep {
  id: string;
  order: number;
  commandId: string;
  waitForCompletion: boolean;
  conditionalNext: ConditionalBranch | null;
  params: Record<string, unknown>;
}

export interface ConditionalBranch {
  condition: string; // e.g., "if success"
  nextStepId: string;
  elseStepId: string | null;
}

export interface WorkflowExecution {
  id: string;
  workflowId: string;
  startedAt: string;
  completedAt: string | null;
  currentStepId: string | null;
  status: "running" | "completed" | "failed" | "paused";
  results: Record<string, unknown>;
}

// ========================================
// KEYBOARD SHORTCUTS
// ========================================

export interface KeyboardShortcut {
  id: string;
  key: string; // e.g., "ctrl+shift+d"
  commandId: string;
  description: string;
  global: boolean; // Works across all DreamNet apps
  enabled: boolean;
  createdAt: string;
}

// ========================================
// RELATIONSHIPS & DEPENDENCIES
// ========================================

export interface AppRelationship {
  id: string;
  sourceAppId: string;
  targetAppId: string;
  relationshipType: "depends-on" | "uses" | "integrates-with" | "replaces";
  strength: number; // 0-1
  notes: string;
}

export interface CommandDependency {
  commandId: string;
  requiredApps: string[]; // AppRef IDs
  optionalApps: string[];
  requiredObjects: string[]; // ObjectShortcut IDs
}

// ========================================
// TEMPLATES & SNIPPETS
// ========================================

export interface Template {
  id: string;
  name: string;
  description: string;
  templateType: "drop-config" | "agent-prompt" | "flow-pattern" | "custom";
  content: string;
  variables: TemplateVariable[];
  tags: string[];
  usageCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface TemplateVariable {
  name: string;
  type: "text" | "number" | "select" | "date";
  defaultValue?: string;
  required: boolean;
  description: string;
}

export interface Snippet {
  id: string;
  trigger: string; // e.g., "/drop", "!agent"
  expansion: string;
  description: string;
  tags: string[];
  usageCount: number;
  createdAt: string;
}

// ========================================
// COLLABORATION
// ========================================

export interface SharedCommandSet {
  id: string;
  name: string;
  description: string;
  author: string;
  commands: string[]; // Command IDs
  shared: boolean;
  downloads: number;
  rating: number;
  createdAt: string;
  updatedAt: string;
}

export interface CommandComment {
  id: string;
  commandId: string;
  userId: string;
  userName: string;
  comment: string;
  commentType: "tip" | "warning" | "best-practice" | "question";
  helpful: number; // upvote count
  createdAt: string;
}

// ========================================
// VISUAL & CUSTOMIZATION
// ========================================

export interface VisualPreview {
  id: string;
  itemId: string;
  itemType: ItemType;
  previewType: "screenshot" | "icon" | "video";
  url: string;
  thumbnailUrl: string | null;
}

export interface ThemeConfig {
  id: string;
  name: string;
  mode: "light" | "dark" | "auto";
  accentColor: string;
  layoutDensity: "compact" | "comfortable" | "spacious";
  fontScale: number;
  customCSS: string;
  active: boolean;
}

// ========================================
// AI & INTELLIGENCE
// ========================================

export interface IntentDetection {
  query: string;
  detectedIntent: string;
  confidence: number;
  suggestedCommands: string[]; // Command IDs
  suggestedApps: string[];
  timestamp: string;
}

export interface AutoSuggestion {
  id: string;
  suggestionType: "pin-command" | "create-workflow" | "cleanup-unused" | "time-based";
  title: string;
  description: string;
  actionable: boolean;
  actionData: Record<string, unknown>;
  confidence: number;
  createdAt: string;
  dismissed: boolean;
}

export interface UsagePattern {
  id: string;
  patternType: "time-based" | "sequence" | "context-based";
  pattern: string;
  frequency: number;
  lastOccurrence: string;
  confidence: number;
}

// ========================================
// COMMAND HISTORY
// ========================================

export interface CommandHistory {
  id: string;
  commandId: string;
  commandName: string;
  executedAt: string;
  context: Record<string, unknown>;
  result: string | null;
  duration: number | null;
}

// ========================================
// HEALTH & PRODUCTIVITY
// ========================================

export interface ProductivityInsight {
  period: "daily" | "weekly" | "monthly";
  mostProductiveTime: string; // e.g., "9am-11am"
  mostUsedCommand: string;
  commandsExecuted: number;
  appsOpened: number;
  avgSessionLength: number; // minutes
  streak: number; // days of consecutive usage
  suggestions: string[];
}

// ========================================
// EXPORT/IMPORT
// ========================================

export interface ConfigBackup {
  id: string;
  name: string;
  description: string;
  version: string;
  createdAt: string;
  data: {
    apps: unknown[];
    commands: unknown[];
    pins: unknown[];
    workflows: unknown[];
    shortcuts: unknown[];
    templates: unknown[];
    settings: unknown;
  };
}
