// DreamNet Command Palette & Navigator - Type Definitions

export type ImportanceLevel = "low" | "medium" | "high" | "critical";
export type CommandType = 
  | "open-app" 
  | "open-view" 
  | "create-object" 
  | "run-routine" 
  | "inspect" 
  | "other";

export type ItemType = "app" | "command" | "object" | "view";
export type PriorityLevel = "low" | "medium" | "high";

// SEO & Meta fields for AppRef and Command
export interface SEOMetadata {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

// AppRef: Represents a DreamNet mini-app or external tool
export interface AppRef extends SEOMetadata {
  id: string;
  name: string;
  slug: string;
  category: string;
  description: string;
  launchUrl: string;
  importanceLevel: ImportanceLevel;
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

// Command: Represents an action/intent that routes to app(s)
export interface Command extends SEOMetadata {
  id: string;
  name: string;
  slug: string;
  description: string;
  commandType: CommandType;
  primaryAppId: string | null;
  secondaryAppIds: string[];
  relatedObjectTypes: string[];
  relatedEntities: string[];
  recommendedNextSteps: string[];
  importanceLevel: ImportanceLevel;
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

// RecentItem: Tracks recently used items
export interface RecentItem {
  id: string;
  itemType: ItemType;
  refId: string;
  label: string;
  openedAt: string;
  notes: string;
}

// Pin: User-pinned items for quick access
export interface Pin {
  id: string;
  itemType: ItemType;
  refId: string;
  label: string;
  priorityLevel: PriorityLevel;
  notes: string;
  createdAt: string;
}

// ObjectShortcut: Quick links to specific objects (tokens, drops, flows, etc.)
export interface ObjectShortcut {
  id: string;
  objectType: string;
  name: string;
  description: string;
  openInAppId: string | null;
  openInstructions: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

// Search result type for command palette
export interface SearchResult {
  type: "command" | "app" | "object";
  id: string;
  label: string;
  description: string;
  primaryApp: string | null;
  primaryAppName: string | null;
  instructions: string[];
  score: number;
  tags: string[];
  importanceLevel?: ImportanceLevel;
}

// Home view structure
export interface HomeView {
  pinnedItems: Array<{
    pin: Pin;
    details: AppRef | Command | ObjectShortcut | null;
  }>;
  recentItems: Array<{
    recent: RecentItem;
    details: AppRef | Command | ObjectShortcut | null;
  }>;
  suggestedCommands: Array<{
    command: Command;
    app: AppRef | null;
  }>;
}
