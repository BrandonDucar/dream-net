import { NextResponse } from 'next/server';
import { openaiChatCompletion } from '@/openai-api';
import type { TransformationResult } from '@/types/transformation';

export async function POST(request: Request): Promise<NextResponse> {
  try {
    const body: { idea: string } = await request.json();
    const { idea } = body;

    if (!idea || typeof idea !== 'string' || !idea.trim()) {
      return NextResponse.json(
        { error: 'Invalid idea provided' },
        { status: 400 }
      );
    }

    const systemPrompt = `You are a creative transformation engine for DreamNet, a system that converts any idea into six parallel "device/world" forms.

For any input idea, you MUST generate ALL SIX forms with the exact structure specified:

1) PHONE APP VERSION
   - core feature (one line)
   - home screen layout (one line)
   - main interaction (one line)
   - one advanced "DreamNet-style" upgrade (one line)

2) WATCH FACE VERSION
   - minimalist adaptation (one line)
   - motion or animation cue (one line)
   - one stat or metric (one line)
   - optional DreamNet glyph (one line)

3) WEB DASHBOARD VERSION
   - modules (one line)
   - data panels (one line)
   - user flow (one line)
   - a "DreamCore" extension (one line)

4) VR / SPATIAL SCENE VERSION
   - environment description (one line)
   - interaction model (one line)
   - one ambient effect (one line)
   - portal or layer change (one line)

5) PHYSICAL OBJECT VERSION
   - materials (one line)
   - shape (one line)
   - function (one line)
   - a hidden "DreamNet node" (one line)

6) BIOMECH ENTITY VERSION
   - appearance (one line)
   - organs/systems (one line)
   - behavior (one line)
   - evolution path (one line)
   - "Dream Essence" signature (one line)

Rules:
- Keep all six forms distinct but recognizable as the same idea
- Maintain DreamNet flavor (futuristic, slightly mystical, tech-organic)
- Be creative and imaginative
- Keep each field to one concise line

You MUST respond with ONLY a valid JSON object in this exact format:
{
  "phoneApp": {
    "coreFeature": "...",
    "homeScreenLayout": "...",
    "mainInteraction": "...",
    "dreamNetUpgrade": "..."
  },
  "watchFace": {
    "minimalistAdaptation": "...",
    "motionCue": "...",
    "stat": "...",
    "dreamNetGlyph": "..."
  },
  "webDashboard": {
    "modules": "...",
    "dataPanels": "...",
    "userFlow": "...",
    "dreamCoreExtension": "..."
  },
  "vrSpatial": {
    "environment": "...",
    "interactionModel": "...",
    "ambientEffect": "...",
    "portalChange": "..."
  },
  "physicalObject": {
    "materials": "...",
    "shape": "...",
    "function": "...",
    "hiddenNode": "..."
  },
  "biomechEntity": {
    "appearance": "...",
    "organsSystems": "...",
    "behavior": "...",
    "evolutionPath": "...",
    "dreamEssence": "..."
  }
}`;

    const userPrompt = `Transform this idea into all six parallel forms: "${idea}"`;

    const completion = await openaiChatCompletion({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
    });

    const responseContent: string = completion.choices[0].message.content;
    
    let parsedResult: Omit<TransformationResult, 'originalIdea'>;
    try {
      parsedResult = JSON.parse(responseContent);
    } catch (parseError) {
      console.error('Failed to parse OpenAI response:', responseContent);
      return NextResponse.json(
        { error: 'Failed to parse transformation result' },
        { status: 500 }
      );
    }

    const result: TransformationResult = {
      originalIdea: idea,
      ...parsedResult,
    };

    return NextResponse.json(result);
  } catch (error) {
    console.error('Transformation error:', error);
    return NextResponse.json(
      { error: 'Failed to generate transformation' },
      { status: 500 }
    );
  }
}
