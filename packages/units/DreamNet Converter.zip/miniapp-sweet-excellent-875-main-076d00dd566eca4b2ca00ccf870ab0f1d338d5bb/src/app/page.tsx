'use client'
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';
import { DreamNetResult } from '@/components/dream-net-result';
import type { TransformationResult } from '@/types/transformation';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DreamNetConverter() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [idea, setIdea] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [result, setResult] = useState<TransformationResult | null>(null);
  const [error, setError] = useState<string>('');

  const handleGenerate = async (): Promise<void> => {
    if (!idea.trim()) {
      setError('Please enter an idea first');
      return;
    }

    setIsGenerating(true);
    setError('');
    setResult(null);

    try {
      const response = await fetch('/api/transform', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idea: idea.trim() }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate transformation');
      }

      const data: TransformationResult = await response.json();
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>): void => {
    if (e.key === 'Enter' && !isGenerating) {
      handleGenerate();
    }
  };

  return (
    <div className="min-h-screen bg-black text-white pt-16 pb-20 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
            DreamNet
          </h1>
          <p className="text-xl text-gray-400 mb-2">Dream-to-Device Converter</p>
          <p className="text-sm text-gray-500">
            Transform any idea into six parallel device/world forms
          </p>
        </div>

        {/* Input Section */}
        <Card className="bg-gray-900 border-gray-800 mb-8">
          <CardHeader>
            <CardTitle className="text-white">Enter Your Idea</CardTitle>
            <CardDescription className="text-gray-400">
              Any object, animal, concept, dream, product name, emoji, or vision
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <Input
                type="text"
                placeholder="e.g., 🌊 ocean wave, quantum computer, flying city..."
                value={idea}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setIdea(e.target.value)}
                onKeyPress={handleKeyPress}
                disabled={isGenerating}
                className="flex-1 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
              />
              <Button
                onClick={handleGenerate}
                disabled={isGenerating || !idea.trim()}
                className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  'Generate'
                )}
              </Button>
            </div>
            {error && <p className="text-red-400 text-sm mt-2">{error}</p>}
          </CardContent>
        </Card>

        {/* Results Section */}
        {!result && !isGenerating && (
          <div className="text-center py-20">
            <div className="inline-block px-6 py-3 bg-gray-900 border border-cyan-500/30 rounded-lg">
              <p className="text-cyan-400 text-lg">Ready for your idea. 🌀</p>
            </div>
          </div>
        )}

        {isGenerating && (
          <div className="text-center py-20">
            <Loader2 className="h-12 w-12 animate-spin mx-auto text-cyan-400 mb-4" />
            <p className="text-gray-400">Transforming across six parallel forms...</p>
          </div>
        )}

        {result && <DreamNetResult result={result} />}
      </div>
    </div>
  );
}
