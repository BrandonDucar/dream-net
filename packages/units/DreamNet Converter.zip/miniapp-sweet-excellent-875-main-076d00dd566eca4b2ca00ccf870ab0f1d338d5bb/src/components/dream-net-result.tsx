'use client';

import type { TransformationResult } from '@/types/transformation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface DreamNetResultProps {
  result: TransformationResult;
}

export function DreamNetResult({ result }: DreamNetResultProps) {
  return (
    <div className="space-y-6">
      {/* Original Idea */}
      <div className="text-center mb-8">
        <Badge className="bg-gradient-to-r from-cyan-500 to-purple-600 text-white px-4 py-2 text-lg">
          {result.originalIdea}
        </Badge>
      </div>

      {/* 1. Phone App Version */}
      <Card className="bg-gradient-to-br from-gray-900 to-gray-800 border-cyan-500/30">
        <CardHeader>
          <CardTitle className="text-cyan-400 flex items-center gap-2">
            <span className="text-2xl">📱</span>
            Phone App Version
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-gray-300">
          <div>
            <span className="text-cyan-400 font-semibold">Core Feature:</span>{' '}
            {result.phoneApp.coreFeature}
          </div>
          <div>
            <span className="text-cyan-400 font-semibold">Home Screen Layout:</span>{' '}
            {result.phoneApp.homeScreenLayout}
          </div>
          <div>
            <span className="text-cyan-400 font-semibold">Main Interaction:</span>{' '}
            {result.phoneApp.mainInteraction}
          </div>
          <div>
            <span className="text-purple-400 font-semibold">DreamNet Upgrade:</span>{' '}
            {result.phoneApp.dreamNetUpgrade}
          </div>
        </CardContent>
      </Card>

      {/* 2. Watch Face Version */}
      <Card className="bg-gradient-to-br from-gray-900 to-gray-800 border-purple-500/30">
        <CardHeader>
          <CardTitle className="text-purple-400 flex items-center gap-2">
            <span className="text-2xl">⌚</span>
            Watch Face Version
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-gray-300">
          <div>
            <span className="text-purple-400 font-semibold">Minimalist Adaptation:</span>{' '}
            {result.watchFace.minimalistAdaptation}
          </div>
          <div>
            <span className="text-purple-400 font-semibold">Motion Cue:</span>{' '}
            {result.watchFace.motionCue}
          </div>
          <div>
            <span className="text-purple-400 font-semibold">Stat/Metric:</span>{' '}
            {result.watchFace.stat}
          </div>
          <div>
            <span className="text-cyan-400 font-semibold">DreamNet Glyph:</span>{' '}
            {result.watchFace.dreamNetGlyph}
          </div>
        </CardContent>
      </Card>

      {/* 3. Web Dashboard Version */}
      <Card className="bg-gradient-to-br from-gray-900 to-gray-800 border-pink-500/30">
        <CardHeader>
          <CardTitle className="text-pink-400 flex items-center gap-2">
            <span className="text-2xl">💻</span>
            Web Dashboard Version
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-gray-300">
          <div>
            <span className="text-pink-400 font-semibold">Modules:</span>{' '}
            {result.webDashboard.modules}
          </div>
          <div>
            <span className="text-pink-400 font-semibold">Data Panels:</span>{' '}
            {result.webDashboard.dataPanels}
          </div>
          <div>
            <span className="text-pink-400 font-semibold">User Flow:</span>{' '}
            {result.webDashboard.userFlow}
          </div>
          <div>
            <span className="text-purple-400 font-semibold">DreamCore Extension:</span>{' '}
            {result.webDashboard.dreamCoreExtension}
          </div>
        </CardContent>
      </Card>

      {/* 4. VR/Spatial Scene Version */}
      <Card className="bg-gradient-to-br from-gray-900 to-gray-800 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <span className="text-2xl">🥽</span>
            VR / Spatial Scene Version
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-gray-300">
          <div>
            <span className="text-blue-400 font-semibold">Environment:</span>{' '}
            {result.vrSpatial.environment}
          </div>
          <div>
            <span className="text-blue-400 font-semibold">Interaction Model:</span>{' '}
            {result.vrSpatial.interactionModel}
          </div>
          <div>
            <span className="text-blue-400 font-semibold">Ambient Effect:</span>{' '}
            {result.vrSpatial.ambientEffect}
          </div>
          <div>
            <span className="text-cyan-400 font-semibold">Portal/Layer Change:</span>{' '}
            {result.vrSpatial.portalChange}
          </div>
        </CardContent>
      </Card>

      {/* 5. Physical Object Version */}
      <Card className="bg-gradient-to-br from-gray-900 to-gray-800 border-green-500/30">
        <CardHeader>
          <CardTitle className="text-green-400 flex items-center gap-2">
            <span className="text-2xl">🔮</span>
            Physical Object Version
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-gray-300">
          <div>
            <span className="text-green-400 font-semibold">Materials:</span>{' '}
            {result.physicalObject.materials}
          </div>
          <div>
            <span className="text-green-400 font-semibold">Shape:</span>{' '}
            {result.physicalObject.shape}
          </div>
          <div>
            <span className="text-green-400 font-semibold">Function:</span>{' '}
            {result.physicalObject.function}
          </div>
          <div>
            <span className="text-purple-400 font-semibold">Hidden DreamNet Node:</span>{' '}
            {result.physicalObject.hiddenNode}
          </div>
        </CardContent>
      </Card>

      {/* 6. Biomech Entity Version */}
      <Card className="bg-gradient-to-br from-gray-900 to-gray-800 border-yellow-500/30">
        <CardHeader>
          <CardTitle className="text-yellow-400 flex items-center gap-2">
            <span className="text-2xl">🧬</span>
            Biomech Entity Version
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-gray-300">
          <div>
            <span className="text-yellow-400 font-semibold">Appearance:</span>{' '}
            {result.biomechEntity.appearance}
          </div>
          <div>
            <span className="text-yellow-400 font-semibold">Organs/Systems:</span>{' '}
            {result.biomechEntity.organsSystems}
          </div>
          <div>
            <span className="text-yellow-400 font-semibold">Behavior:</span>{' '}
            {result.biomechEntity.behavior}
          </div>
          <div>
            <span className="text-yellow-400 font-semibold">Evolution Path:</span>{' '}
            {result.biomechEntity.evolutionPath}
          </div>
          <div>
            <span className="text-purple-400 font-semibold">Dream Essence:</span>{' '}
            {result.biomechEntity.dreamEssence}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
