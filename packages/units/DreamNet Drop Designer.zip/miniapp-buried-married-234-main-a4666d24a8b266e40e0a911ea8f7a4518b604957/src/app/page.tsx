'use client'
import { useState, useEffect } from 'react'
import { useDropArchitect } from '@/hooks/use-drop-architect'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { CultureRefList } from '@/components/drop-architect/culture-ref-list'
import { CultureRefForm } from '@/components/drop-architect/culture-ref-form'
import { DropList } from '@/components/drop-architect/drop-list'
import { DropDetail } from '@/components/drop-architect/drop-detail'
import { DropsOverview } from '@/components/drop-architect/drops-overview'
import { NewDropDialog } from '@/components/drop-architect/new-drop-dialog'
import { Card } from '@/components/ui/card'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type View = 'dashboard' | 'culture-ref-form' | 'drop-detail' | 'overview'

export default function DreamNetDropArchitect() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const {
    cultureRefs,
    drops,
    isLoaded,
    createCultureRef,
    updateCultureRef,
    deleteCultureRef,
    createDropForCultureRef,
    updateDrop,
    deleteDrop,
    regenerateNarrativeForDrop,
    regenerateEconomics,
    regenerateMessagingAndSEO,
    generateGeoVariantsForDrop,
    setDropTiming,
    listDrops,
    getDrop,
    exportDropBrief
  } = useDropArchitect()

  const [view, setView] = useState<View>('dashboard')
  const [selectedCultureRefId, setSelectedCultureRefId] = useState<string | null>(null)
  const [selectedDropId, setSelectedDropId] = useState<string | null>(null)
  const [editingCultureRefId, setEditingCultureRefId] = useState<string | null>(null)
  const [showNewDropDialog, setShowNewDropDialog] = useState<boolean>(false)

  if (!isLoaded) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-4">⚡</div>
          <p className="text-gray-600">Loading DreamNet Drop Architect...</p>
        </div>
      </div>
    )
  }

  const selectedCultureRef = selectedCultureRefId ? cultureRefs.find(ref => ref.id === selectedCultureRefId) : null
  const selectedDrop = selectedDropId ? getDrop(selectedDropId) : null
  const dropsForSelectedRef = selectedCultureRefId ? listDrops({ cultureRefId: selectedCultureRefId }) : []

  const handleSelectCultureRef = (id: string): void => {
    setSelectedCultureRefId(id)
    setView('dashboard')
  }

  const handleNewCultureRef = (): void => {
    setEditingCultureRefId(null)
    setView('culture-ref-form')
  }

  const handleSaveCultureRef = (data: Omit<import('@/types/drop-architect').CultureRef, 'id'>): void => {
    if (editingCultureRefId) {
      updateCultureRef(editingCultureRefId, data)
    } else {
      const newRef = createCultureRef(data)
      setSelectedCultureRefId(newRef.id)
    }
    setView('dashboard')
    setEditingCultureRefId(null)
  }

  const handleCancelCultureRefForm = (): void => {
    setView('dashboard')
    setEditingCultureRefId(null)
  }

  const handleNewDrop = (): void => {
    if (!selectedCultureRefId) return
    setShowNewDropDialog(true)
  }

  const handleCreateDrop = (notes: string): void => {
    if (!selectedCultureRefId) return
    const newDrop = createDropForCultureRef(selectedCultureRefId, notes)
    setSelectedDropId(newDrop.id)
    setShowNewDropDialog(false)
    setView('drop-detail')
  }

  const handleViewDrop = (dropId: string): void => {
    setSelectedDropId(dropId)
    setView('drop-detail')
  }

  const handleBackToDashboard = (): void => {
    setView('dashboard')
    setSelectedDropId(null)
  }

  const handleRegenerateNarrative = (): void => {
    if (selectedDropId) {
      regenerateNarrativeForDrop(selectedDropId)
    }
  }

  const handleRegenerateEconomics = (hints?: string): void => {
    if (selectedDropId) {
      regenerateEconomics(selectedDropId, hints)
    }
  }

  const handleRegenerateMessaging = (): void => {
    if (selectedDropId) {
      regenerateMessagingAndSEO(selectedDropId)
    }
  }

  const handleGenerateGeoVariants = (): void => {
    if (selectedDropId) {
      generateGeoVariantsForDrop(selectedDropId)
    }
  }

  const handleSetTiming = (start: string | null, end: string | null): void => {
    if (selectedDropId) {
      setDropTiming(selectedDropId, start, end)
    }
  }

  const handleExportBrief = (): string => {
    if (!selectedDropId) return ''
    return exportDropBrief(selectedDropId)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <div className="container mx-auto px-4 py-8">
        <header className="mb-8 text-center">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            ⚡ DreamNet Drop Architect
          </h1>
          <p className="text-gray-600">Design & manage on-chain culture drops for Base/Zora</p>
        </header>

        <Tabs value={view === 'overview' ? 'overview' : 'workspace'} onValueChange={(value) => {
          if (value === 'overview') {
            setView('overview')
          } else {
            setView('dashboard')
          }
        }} className="space-y-6">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2">
            <TabsTrigger value="workspace">Workspace</TabsTrigger>
            <TabsTrigger value="overview">All Drops</TabsTrigger>
          </TabsList>

          <TabsContent value="workspace">
            {view === 'culture-ref-form' ? (
              <CultureRefForm
                initialData={editingCultureRefId ? cultureRefs.find(r => r.id === editingCultureRefId) : undefined}
                onSave={handleSaveCultureRef}
                onCancel={handleCancelCultureRefForm}
              />
            ) : view === 'drop-detail' && selectedDrop && selectedCultureRef ? (
              <DropDetail
                drop={selectedDrop}
                cultureRef={selectedCultureRef}
                onUpdate={(updates) => updateDrop(selectedDrop.id, updates)}
                onRegenerateNarrative={handleRegenerateNarrative}
                onRegenerateEconomics={handleRegenerateEconomics}
                onRegenerateMessaging={handleRegenerateMessaging}
                onSetTiming={handleSetTiming}
                onGenerateGeoVariants={handleGenerateGeoVariants}
                onExportBrief={handleExportBrief}
                onBack={handleBackToDashboard}
              />
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="p-6 h-[calc(100vh-280px)] overflow-hidden">
                  <CultureRefList
                    cultureRefs={cultureRefs}
                    selectedId={selectedCultureRefId}
                    onSelect={handleSelectCultureRef}
                    onDelete={deleteCultureRef}
                    onNew={handleNewCultureRef}
                  />
                </Card>

                <Card className="p-6 h-[calc(100vh-280px)] overflow-hidden">
                  <DropList
                    drops={dropsForSelectedRef}
                    cultureRef={selectedCultureRef}
                    onView={handleViewDrop}
                    onDelete={deleteDrop}
                    onNewDrop={handleNewDrop}
                  />
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="overview">
            <DropsOverview
              drops={drops}
              cultureRefs={cultureRefs}
              onViewDrop={handleViewDrop}
            />
          </TabsContent>
        </Tabs>

        {showNewDropDialog && selectedCultureRef && (
          <NewDropDialog
            isOpen={showNewDropDialog}
            cultureRefName={selectedCultureRef.name}
            onConfirm={handleCreateDrop}
            onCancel={() => setShowNewDropDialog(false)}
          />
        )}
      </div>
    </div>
  )
}
