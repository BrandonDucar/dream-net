'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Search, TrendingUp } from 'lucide-react'
import { getAllComps, searchComps } from '@/lib/pricing-oracle'
import type { DropComp } from '@/types/drop-architect-extended'

export function CompsBrowser() {
  const [comps] = useState<DropComp[]>(getAllComps())
  const [searchQuery, setSearchQuery] = useState('')
  const [filteredComps, setFilteredComps] = useState<DropComp[]>(comps)

  const handleSearch = (query: string): void => {
    setSearchQuery(query)
    if (query.trim() === '') {
      setFilteredComps(comps)
    } else {
      const results = searchComps(query)
      setFilteredComps(results)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          Successful Drops Database
        </CardTitle>
        <CardDescription>
          Learn from {comps.length} successful Base/Zora drops
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by name, theme, or drop type..."
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            className="pl-9"
          />
        </div>

        <div className="space-y-3 max-h-[600px] overflow-y-auto">
          {filteredComps.map((comp) => (
            <div key={comp.id} className="p-4 border rounded-lg hover:bg-accent transition-colors">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h4 className="font-medium">{comp.name}</h4>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline">{comp.dropType}</Badge>
                    <Badge variant="secondary">{comp.theme}</Badge>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold">{comp.priceETH.toFixed(4)} ETH</div>
                  <div className="text-xs text-muted-foreground">
                    {'⭐'.repeat(comp.successRating)}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 text-sm mt-3">
                <div>
                  <div className="text-xs text-muted-foreground">Edition</div>
                  <div className="font-medium">{comp.editionSize || 'Open'}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Minted</div>
                  <div className="font-medium">{comp.mintedCount}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Duration</div>
                  <div className="font-medium">{comp.mintDuration}</div>
                </div>
              </div>

              <div className="mt-3 pt-3 border-t">
                <p className="text-xs text-muted-foreground">{comp.notes}</p>
              </div>

              <div className="flex gap-2 mt-2">
                <Badge variant="outline" className="text-xs">{comp.chain}</Badge>
                <Badge variant="outline" className="text-xs">{comp.platform}</Badge>
              </div>
            </div>
          ))}
        </div>

        {filteredComps.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            No drops found matching your search.
          </div>
        )}
      </CardContent>
    </Card>
  )
}
