'use client'

import { useState, useEffect } from 'react'
import type { CultureRef } from '@/types/drop-architect'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

interface CultureRefFormProps {
  initialData?: CultureRef;
  onSave: (data: Omit<CultureRef, 'id'>) => void;
  onCancel: () => void;
}

export function CultureRefForm({ initialData, onSave, onCancel }: CultureRefFormProps) {
  const [formData, setFormData] = useState({
    name: initialData?.name || '',
    ticker: initialData?.ticker || '',
    primaryEmoji: initialData?.primaryEmoji || '💎',
    theme: initialData?.theme || '',
    archetype: initialData?.archetype || ''
  })

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault()
    if (!formData.name || !formData.ticker) {
      alert('Name and Ticker are required')
      return
    }
    onSave(formData)
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>{initialData ? 'Edit' : 'Create'} CultureRef</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g. DreamNet"
              required
            />
          </div>

          <div>
            <Label htmlFor="ticker">Ticker</Label>
            <Input
              id="ticker"
              value={formData.ticker}
              onChange={(e) => setFormData({ ...formData, ticker: e.target.value.toUpperCase() })}
              placeholder="e.g. DREAM"
              required
            />
          </div>

          <div>
            <Label htmlFor="emoji">Primary Emoji</Label>
            <Input
              id="emoji"
              value={formData.primaryEmoji}
              onChange={(e) => setFormData({ ...formData, primaryEmoji: e.target.value })}
              placeholder="💎"
              className="text-2xl"
            />
          </div>

          <div>
            <Label htmlFor="theme">Theme</Label>
            <Input
              id="theme"
              value={formData.theme}
              onChange={(e) => setFormData({ ...formData, theme: e.target.value })}
              placeholder="e.g. future-optimism, cyber-punk, art-collective"
            />
          </div>

          <div>
            <Label htmlFor="archetype">Archetype</Label>
            <Input
              id="archetype"
              value={formData.archetype}
              onChange={(e) => setFormData({ ...formData, archetype: e.target.value })}
              placeholder="e.g. builder, visionary, rebel, artist"
            />
          </div>

          <div className="flex gap-2 pt-4">
            <Button type="submit" className="flex-1">
              {initialData ? 'Update' : 'Create'} CultureRef
            </Button>
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
