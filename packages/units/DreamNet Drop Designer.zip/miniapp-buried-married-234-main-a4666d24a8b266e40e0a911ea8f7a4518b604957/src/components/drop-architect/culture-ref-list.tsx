'use client'

import type { CultureRef } from '@/types/drop-architect'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Trash2 } from 'lucide-react'

interface CultureRefListProps {
  cultureRefs: CultureRef[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
  onNew: () => void;
}

export function CultureRefList({ cultureRefs, selectedId, onSelect, onDelete, onNew }: CultureRefListProps) {
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">CultureRefs</h2>
        <Button onClick={onNew} size="sm">+ New</Button>
      </div>
      
      <div className="space-y-2 overflow-y-auto flex-1">
        {cultureRefs.length === 0 ? (
          <Card className="p-4">
            <p className="text-sm text-gray-500 text-center">No CultureRefs yet. Create one to start designing drops.</p>
          </Card>
        ) : (
          cultureRefs.map(ref => (
            <Card
              key={ref.id}
              className={`p-3 cursor-pointer hover:border-blue-400 transition-colors ${
                selectedId === ref.id ? 'border-blue-500 bg-blue-50' : ''
              }`}
              onClick={() => onSelect(ref.id)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-2xl">{ref.primaryEmoji}</span>
                    <div>
                      <div className="font-semibold text-sm">{ref.name}</div>
                      <div className="text-xs text-gray-600">${ref.ticker}</div>
                    </div>
                  </div>
                  <div className="flex gap-1 mt-2">
                    <Badge variant="outline" className="text-xs">{ref.theme}</Badge>
                    <Badge variant="secondary" className="text-xs">{ref.archetype}</Badge>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation()
                    if (confirm(`Delete ${ref.name}? This will also delete all associated drops.`)) {
                      onDelete(ref.id)
                    }
                  }}
                  className="text-red-500 hover:text-red-700"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
