'use client'

import { useState } from 'react'
import type { Drop, CultureRef, GeoTarget } from '@/types/drop-architect'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Separator } from '@/components/ui/separator'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { RefreshCw, Copy, ArrowLeft, Plus, Trash2 } from 'lucide-react'
import { GeoTargetManager } from './geo-target-manager'
import { VisualGenerator } from './visual-generator'
import { PricingOracleDisplay } from './pricing-oracle-display'
import { SuccessPredictorDisplay } from './success-predictor-display'
import { DropSimulatorDisplay } from './drop-simulator-display'
import { FarcasterFrameGenerator } from './farcaster-frame-generator'
import { LaunchChecklistDisplay } from './launch-checklist-display'
import { ExportHub } from './export-hub'
import { HashtagOptimizer } from './hashtag-optimizer'
import { CompsBrowser } from './comps-browser'
import { VisualPreviewCard } from './visual-preview-card'

interface DropDetailProps {
  drop: Drop;
  cultureRef: CultureRef;
  onUpdate: (updates: Partial<Omit<Drop, 'id'>>) => void;
  onRegenerateNarrative: () => void;
  onRegenerateEconomics: (hints?: string) => void;
  onRegenerateMessaging: () => void;
  onSetTiming: (start: string | null, end: string | null) => void;
  onGenerateGeoVariants: () => void;
  onExportBrief: () => string;
  onBack: () => void;
}

export function DropDetail({
  drop,
  cultureRef,
  onUpdate,
  onRegenerateNarrative,
  onRegenerateEconomics,
  onRegenerateMessaging,
  onSetTiming,
  onGenerateGeoVariants,
  onExportBrief,
  onBack
}: DropDetailProps) {
  const [economicsHint, setEconomicsHint] = useState<string>('')
  const [showBrief, setShowBrief] = useState<boolean>(false)
  const [brief, setBrief] = useState<string>('')

  const handleExport = (): void => {
    const exportedBrief = onExportBrief()
    setBrief(exportedBrief)
    setShowBrief(true)
  }

  const handleCopyBrief = (): void => {
    navigator.clipboard.writeText(brief)
    alert('Drop brief copied to clipboard!')
  }

  const updateMediaPrompts = (index: number, value: string): void => {
    const newPrompts = [...drop.mediaPrompts]
    newPrompts[index] = value
    onUpdate({ mediaPrompts: newPrompts })
  }

  const addMediaPrompt = (): void => {
    onUpdate({ mediaPrompts: [...drop.mediaPrompts, ''] })
  }

  const removeMediaPrompt = (index: number): void => {
    onUpdate({ mediaPrompts: drop.mediaPrompts.filter((_, i) => i !== index) })
  }

  const updateChannel = (channels: string[]): void => {
    onUpdate({ supportingChannels: channels })
  }

  const toggleChannel = (channel: string): void => {
    const current = drop.supportingChannels
    if (current.includes(channel)) {
      updateChannel(current.filter(c => c !== channel))
    } else {
      updateChannel([...current, channel])
    }
  }

  const updatePreLaunch = (index: number, value: string): void => {
    const newIdeas = [...drop.preLaunchIdeas]
    newIdeas[index] = value
    onUpdate({ preLaunchIdeas: newIdeas })
  }

  const addPreLaunch = (): void => {
    onUpdate({ preLaunchIdeas: [...drop.preLaunchIdeas, ''] })
  }

  const removePreLaunch = (index: number): void => {
    onUpdate({ preLaunchIdeas: drop.preLaunchIdeas.filter((_, i) => i !== index) })
  }

  const updatePostLaunch = (index: number, value: string): void => {
    const newIdeas = [...drop.postLaunchFollowUps]
    newIdeas[index] = value
    onUpdate({ postLaunchFollowUps: newIdeas })
  }

  const addPostLaunch = (): void => {
    onUpdate({ postLaunchFollowUps: [...drop.postLaunchFollowUps, ''] })
  }

  const removePostLaunch = (index: number): void => {
    onUpdate({ postLaunchFollowUps: drop.postLaunchFollowUps.filter((_, i) => i !== index) })
  }

  const updateKeyword = (keywords: string[]): void => {
    onUpdate({ seoKeywords: keywords })
  }

  const updateHashtag = (hashtags: string[]): void => {
    onUpdate({ seoHashtags: hashtags })
  }

  return (
    <div className="max-w-5xl mx-auto pb-20">
      <Button variant="ghost" onClick={onBack} className="mb-4">
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Dashboard
      </Button>

      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold mb-2">{drop.name}</h1>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <span>{cultureRef.primaryEmoji}</span>
            <span>{cultureRef.name} (${cultureRef.ticker})</span>
            <span>•</span>
            <Badge>{drop.status}</Badge>
          </div>
        </div>
        <Button onClick={handleExport}>
          Export Drop Brief
        </Button>
      </div>

      {showBrief && (
        <Card className="mb-6 bg-gray-50">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Drop Brief</CardTitle>
              <Button size="sm" onClick={handleCopyBrief}>
                <Copy className="w-4 h-4 mr-2" />
                Copy
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <pre className="text-xs whitespace-pre-wrap font-mono bg-white p-4 rounded border max-h-96 overflow-y-auto">
              {brief}
            </pre>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="preview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8 xl:grid-cols-10 gap-1">
          <TabsTrigger value="preview">✨ Preview</TabsTrigger>
          <TabsTrigger value="identity">Identity</TabsTrigger>
          <TabsTrigger value="economics">💰 Economics</TabsTrigger>
          <TabsTrigger value="narrative">Narrative</TabsTrigger>
          <TabsTrigger value="visuals">🎨 Visuals</TabsTrigger>
          <TabsTrigger value="prediction">🎯 Predict</TabsTrigger>
          <TabsTrigger value="simulator">⚡ Simulate</TabsTrigger>
          <TabsTrigger value="farcaster">🟪 Frame</TabsTrigger>
          <TabsTrigger value="checklist">✅ Checklist</TabsTrigger>
          <TabsTrigger value="messaging">Messaging</TabsTrigger>
          <TabsTrigger value="seo">SEO</TabsTrigger>
          <TabsTrigger value="hashtags">#️⃣ Tags</TabsTrigger>
          <TabsTrigger value="timing">Timing</TabsTrigger>
          <TabsTrigger value="geo">🌍 Geo</TabsTrigger>
          <TabsTrigger value="channels">Channels</TabsTrigger>
          <TabsTrigger value="export">📤 Export</TabsTrigger>
          <TabsTrigger value="comps">📊 Comps</TabsTrigger>
        </TabsList>

        <TabsContent value="preview">
          <VisualPreviewCard drop={drop} cultureRef={cultureRef} />
        </TabsContent>

        <TabsContent value="identity">
          <Card>
            <CardHeader>
              <CardTitle>Identity & Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name">Drop Name</Label>
                <Input
                  id="name"
                  value={drop.name}
                  onChange={(e) => onUpdate({ name: e.target.value })}
                />
              </div>

              <div>
                <Label htmlFor="dropType">Drop Type</Label>
                <Input
                  id="dropType"
                  value={drop.dropType}
                  onChange={(e) => onUpdate({ dropType: e.target.value })}
                  placeholder="edition, 1/1, open edition, frame, etc."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="chain">Chain</Label>
                  <Input
                    id="chain"
                    value={drop.chain}
                    onChange={(e) => onUpdate({ chain: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="platform">Platform</Label>
                  <Input
                    id="platform"
                    value={drop.platform}
                    onChange={(e) => onUpdate({ platform: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="status">Status</Label>
                <Select value={drop.status} onValueChange={(value) => onUpdate({ status: value as Drop['status'] })}>
                  <SelectTrigger id="status">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="idea">Idea</SelectItem>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="scheduled">Scheduled</SelectItem>
                    <SelectItem value="live">Live</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="archived">Archived</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="visuals">
          <VisualGenerator drop={drop} cultureRef={cultureRef} />
        </TabsContent>

        <TabsContent value="prediction">
          <div className="space-y-6">
            <PricingOracleDisplay 
              drop={drop} 
              cultureRef={cultureRef}
              onApplyRecommendation={(price) => onUpdate({ priceETH: price })}
            />
            <SuccessPredictorDisplay drop={drop} cultureRef={cultureRef} />
          </div>
        </TabsContent>

        <TabsContent value="simulator">
          <DropSimulatorDisplay drop={drop} cultureRef={cultureRef} />
        </TabsContent>

        <TabsContent value="farcaster">
          <FarcasterFrameGenerator drop={drop} cultureRef={cultureRef} />
        </TabsContent>

        <TabsContent value="checklist">
          <LaunchChecklistDisplay drop={drop} cultureRef={cultureRef} />
        </TabsContent>

        <TabsContent value="hashtags">
          <HashtagOptimizer 
            drop={drop} 
            cultureRef={cultureRef}
            onApplyOptimized={(hashtags) => onUpdate({ seoHashtags: hashtags })}
          />
        </TabsContent>

        <TabsContent value="export">
          <ExportHub drop={drop} cultureRef={cultureRef} />
        </TabsContent>

        <TabsContent value="comps">
          <CompsBrowser />
        </TabsContent>

        <TabsContent value="economics">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Economics</CardTitle>
                <div className="flex gap-2">
                  <Input
                    placeholder="Hint: accessible, premium, etc."
                    value={economicsHint}
                    onChange={(e) => setEconomicsHint(e.target.value)}
                    className="w-64"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      onRegenerateEconomics(economicsHint)
                      setEconomicsHint('')
                    }}
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Regenerate
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="freeMint">Free Mint</Label>
                <Switch
                  id="freeMint"
                  checked={drop.freeMint}
                  onCheckedChange={(checked) => onUpdate({ freeMint: checked })}
                />
              </div>

              {!drop.freeMint && (
                <>
                  <div>
                    <Label htmlFor="priceETH">Price (ETH)</Label>
                    <Input
                      id="priceETH"
                      type="number"
                      step="0.001"
                      value={drop.priceETH || ''}
                      onChange={(e) => onUpdate({ priceETH: parseFloat(e.target.value) || null })}
                    />
                  </div>

                  <Separator />

                  <div>
                    <Label htmlFor="priceToken">Price Token (Optional)</Label>
                    <Input
                      id="priceToken"
                      value={drop.priceToken || ''}
                      onChange={(e) => onUpdate({ priceToken: e.target.value || null })}
                      placeholder="e.g. DREAM, DEGEN"
                    />
                  </div>

                  {drop.priceToken && (
                    <div>
                      <Label htmlFor="priceTokenAmount">Token Amount</Label>
                      <Input
                        id="priceTokenAmount"
                        type="number"
                        value={drop.priceTokenAmount || ''}
                        onChange={(e) => onUpdate({ priceTokenAmount: parseFloat(e.target.value) || null })}
                      />
                    </div>
                  )}
                </>
              )}

              <Separator />

              <div>
                <Label htmlFor="editionSize">Edition Size (null for open edition)</Label>
                <Input
                  id="editionSize"
                  type="number"
                  value={drop.editionSize === null ? '' : drop.editionSize}
                  onChange={(e) => onUpdate({ editionSize: e.target.value === '' ? null : parseInt(e.target.value) })}
                  placeholder="Leave empty for open edition"
                />
              </div>

              <div>
                <Label htmlFor="royaltyPercent">Royalty %</Label>
                <Input
                  id="royaltyPercent"
                  type="number"
                  step="0.1"
                  value={drop.royaltyPercent || ''}
                  onChange={(e) => onUpdate({ royaltyPercent: parseFloat(e.target.value) || null })}
                />
              </div>

              <div>
                <Label htmlFor="allowlistNotes">Allowlist Notes</Label>
                <Textarea
                  id="allowlistNotes"
                  value={drop.allowlistNotes}
                  onChange={(e) => onUpdate({ allowlistNotes: e.target.value })}
                  rows={3}
                  placeholder="Who gets in? Any special access requirements?"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="narrative">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Narrative & Content</CardTitle>
                <Button variant="outline" size="sm" onClick={onRegenerateNarrative}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Regenerate
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="conceptSummary">Concept Summary</Label>
                <Textarea
                  id="conceptSummary"
                  value={drop.conceptSummary}
                  onChange={(e) => onUpdate({ conceptSummary: e.target.value })}
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="loreSnippet">Lore Snippet</Label>
                <Textarea
                  id="loreSnippet"
                  value={drop.loreSnippet}
                  onChange={(e) => onUpdate({ loreSnippet: e.target.value })}
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="mediaType">Media Type</Label>
                <Input
                  id="mediaType"
                  value={drop.mediaType}
                  onChange={(e) => onUpdate({ mediaType: e.target.value })}
                  placeholder="image, video, gif, audio, multi"
                />
              </div>

              <div>
                <Label htmlFor="visualDirection">Visual Direction</Label>
                <Textarea
                  id="visualDirection"
                  value={drop.visualDirection}
                  onChange={(e) => onUpdate({ visualDirection: e.target.value })}
                  rows={4}
                />
              </div>

              <Separator />

              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label>Media Prompts</Label>
                  <Button variant="ghost" size="sm" onClick={addMediaPrompt}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="space-y-2">
                  {drop.mediaPrompts.map((prompt, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        value={prompt}
                        onChange={(e) => updateMediaPrompts(index, e.target.value)}
                        placeholder={`Prompt ${index + 1}`}
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeMediaPrompt(index)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="messaging">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Messaging & Distribution</CardTitle>
                <Button variant="outline" size="sm" onClick={onRegenerateMessaging}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Regenerate
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="targetAudienceNotes">Target Audience</Label>
                <Textarea
                  id="targetAudienceNotes"
                  value={drop.targetAudienceNotes}
                  onChange={(e) => onUpdate({ targetAudienceNotes: e.target.value })}
                  rows={3}
                />
              </div>

              <Separator />

              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label>Pre-Launch Ideas</Label>
                  <Button variant="ghost" size="sm" onClick={addPreLaunch}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="space-y-2">
                  {drop.preLaunchIdeas.map((idea, index) => (
                    <div key={index} className="flex gap-2">
                      <Textarea
                        value={idea}
                        onChange={(e) => updatePreLaunch(index, e.target.value)}
                        placeholder={`Idea ${index + 1}`}
                        rows={2}
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removePreLaunch(index)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label>Post-Launch Follow-Ups</Label>
                  <Button variant="ghost" size="sm" onClick={addPostLaunch}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="space-y-2">
                  {drop.postLaunchFollowUps.map((idea, index) => (
                    <div key={index} className="flex gap-2">
                      <Textarea
                        value={idea}
                        onChange={(e) => updatePostLaunch(index, e.target.value)}
                        placeholder={`Follow-up ${index + 1}`}
                        rows={2}
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removePostLaunch(index)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="seo">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>SEO & Meta</CardTitle>
                <Button variant="outline" size="sm" onClick={onRegenerateMessaging}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Regenerate
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="seoTitle">SEO Title</Label>
                <Input
                  id="seoTitle"
                  value={drop.seoTitle}
                  onChange={(e) => onUpdate({ seoTitle: e.target.value })}
                />
              </div>

              <div>
                <Label htmlFor="seoDescription">SEO Description</Label>
                <Textarea
                  id="seoDescription"
                  value={drop.seoDescription}
                  onChange={(e) => onUpdate({ seoDescription: e.target.value })}
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="altText">Alt Text</Label>
                <Input
                  id="altText"
                  value={drop.altText}
                  onChange={(e) => onUpdate({ altText: e.target.value })}
                />
              </div>

              <Separator />

              <div>
                <Label htmlFor="seoKeywords">SEO Keywords (comma-separated)</Label>
                <Textarea
                  id="seoKeywords"
                  value={drop.seoKeywords.join(', ')}
                  onChange={(e) => updateKeyword(e.target.value.split(',').map(k => k.trim()).filter(k => k))}
                  rows={3}
                  placeholder="keyword1, keyword2, keyword3"
                />
              </div>

              <div>
                <Label htmlFor="seoHashtags">SEO Hashtags (comma-separated)</Label>
                <Textarea
                  id="seoHashtags"
                  value={drop.seoHashtags.join(', ')}
                  onChange={(e) => updateHashtag(e.target.value.split(',').map(h => h.trim()).filter(h => h))}
                  rows={2}
                  placeholder="#tag1, #tag2, #tag3"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="timing">
          <Card>
            <CardHeader>
              <CardTitle>Timing & Launch Window</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="launchTiming">Launch Timing (Description)</Label>
                <Input
                  id="launchTiming"
                  value={drop.launchTiming}
                  onChange={(e) => onUpdate({ launchTiming: e.target.value })}
                  placeholder="e.g. next week, Q1 2024, after mainnet launch"
                />
              </div>

              <Separator />

              <div>
                <Label htmlFor="launchWindowStart">Launch Window Start</Label>
                <Input
                  id="launchWindowStart"
                  type="datetime-local"
                  value={drop.launchWindowStart || ''}
                  onChange={(e) => onSetTiming(e.target.value || null, drop.launchWindowEnd)}
                />
              </div>

              <div>
                <Label htmlFor="launchWindowEnd">Launch Window End</Label>
                <Input
                  id="launchWindowEnd"
                  type="datetime-local"
                  value={drop.launchWindowEnd || ''}
                  onChange={(e) => onSetTiming(drop.launchWindowStart, e.target.value || null)}
                />
              </div>

              {drop.launchWindowStart && (
                <div className="text-sm text-gray-600 bg-blue-50 p-3 rounded">
                  💡 Best practice: Launch on weekdays between 10 AM - 2 PM EST for maximum visibility.
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="geo">
          <GeoTargetManager
            drop={drop}
            onUpdate={onUpdate}
            onGenerateVariants={onGenerateGeoVariants}
          />
        </TabsContent>

        <TabsContent value="channels">
          <Card>
            <CardHeader>
              <CardTitle>Supporting Channels</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {['farcaster', 'x', 'zora', 'base-feed', 'lens', 'discord', 'telegram', 'website'].map(channel => (
                  <div key={channel} className="flex items-center justify-between p-3 border rounded hover:bg-gray-50">
                    <span className="capitalize font-medium">{channel}</span>
                    <Switch
                      checked={drop.supportingChannels.includes(channel)}
                      onCheckedChange={() => toggleChannel(channel)}
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
