'use client'

import type { Drop, CultureRef } from '@/types/drop-architect'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Eye, Trash2 } from 'lucide-react'

interface DropListProps {
  drops: Drop[];
  cultureRef: CultureRef | null;
  onView: (dropId: string) => void;
  onDelete: (dropId: string) => void;
  onNewDrop: () => void;
}

export function DropList({ drops, cultureRef, onView, onDelete, onNewDrop }: DropListProps) {
  if (!cultureRef) {
    return (
      <Card className="p-8 text-center">
        <p className="text-gray-500">Select a CultureRef to view and manage drops</p>
      </Card>
    )
  }

  const statusColors: Record<string, string> = {
    'idea': 'bg-gray-100 text-gray-800',
    'draft': 'bg-yellow-100 text-yellow-800',
    'scheduled': 'bg-blue-100 text-blue-800',
    'live': 'bg-green-100 text-green-800',
    'completed': 'bg-purple-100 text-purple-800',
    'archived': 'bg-gray-100 text-gray-500'
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-semibold">Drops for {cultureRef.name}</h2>
          <p className="text-sm text-gray-600">{drops.length} drop{drops.length !== 1 ? 's' : ''}</p>
        </div>
        <Button onClick={onNewDrop} size="sm">+ New Drop</Button>
      </div>

      <div className="space-y-3 overflow-y-auto flex-1">
        {drops.length === 0 ? (
          <Card className="p-6">
            <p className="text-sm text-gray-500 text-center">
              No drops yet. Create your first drop for {cultureRef.name}!
            </p>
          </Card>
        ) : (
          drops.map(drop => (
            <Card key={drop.id} className="p-4 hover:border-blue-400 transition-colors">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="font-semibold mb-1">{drop.name}</div>
                  <div className="flex gap-2 mb-2 flex-wrap">
                    <Badge className={statusColors[drop.status]}>{drop.status}</Badge>
                    <Badge variant="outline">{drop.dropType}</Badge>
                    <Badge variant="secondary">{drop.chain}</Badge>
                    <Badge variant="secondary">{drop.platform}</Badge>
                  </div>
                  <div className="text-sm text-gray-600">
                    {drop.freeMint ? (
                      <span className="font-semibold text-green-600">FREE MINT</span>
                    ) : (
                      <span>
                        {drop.priceETH} ETH
                        {drop.priceToken && ` + ${drop.priceTokenAmount} ${drop.priceToken}`}
                      </span>
                    )}
                    {' • '}
                    {drop.editionSize === null ? 'Open Edition' : `${drop.editionSize} editions`}
                  </div>
                </div>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onView(drop.id)}
                  >
                    <Eye className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      if (confirm(`Delete ${drop.name}?`)) {
                        onDelete(drop.id)
                      }
                    }}
                    className="text-red-500 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
