'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { PlayCircle, TrendingUp, AlertCircle } from 'lucide-react'
import { simulateDropLaunch } from '@/lib/drop-simulator'
import type { Drop, CultureRef } from '@/types/drop-architect'
import type { SimulationResult } from '@/types/drop-architect-extended'

interface DropSimulatorDisplayProps {
  drop: Drop
  cultureRef: CultureRef
}

export function DropSimulatorDisplay({ drop, cultureRef }: DropSimulatorDisplayProps) {
  const [simulation, setSimulation] = useState<SimulationResult | null>(null)

  useEffect(() => {
    const sim = simulateDropLaunch(drop, cultureRef)
    setSimulation(sim)
  }, [drop, cultureRef])

  if (!simulation) return null

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PlayCircle className="h-5 w-5" />
            Drop Launch Simulator
          </CardTitle>
          <CardDescription>
            Virtual launch experience showing hour-by-hour projections
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="timeline">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="timeline">Timeline</TabsTrigger>
              <TabsTrigger value="outcomes">Outcomes</TabsTrigger>
              <TabsTrigger value="recommendations">Tips</TabsTrigger>
            </TabsList>

            <TabsContent value="timeline" className="space-y-4 mt-4">
              <div className="space-y-3">
                {simulation.timeline.map((point, i) => (
                  <div key={i} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">Hour {point.hour}</span>
                      <div className="flex items-center gap-2">
                        <Badge variant={point.trending ? 'default' : 'outline'}>
                          {point.percentMinted}% minted
                        </Badge>
                        {point.trending && (
                          <Badge variant="secondary">
                            <TrendingUp className="h-3 w-3 mr-1" />
                            Trending
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground mb-2">
                      <div>Minted: {point.totalMinted}</div>
                      <div>Collectors: {point.uniqueCollectors}</div>
                    </div>
                    
                    {point.events.length > 0 && (
                      <div className="mt-2 pt-2 border-t">
                        <div className="space-y-1">
                          {point.events.map((event, j) => (
                            <div key={j} className="text-sm flex items-center gap-2">
                              <span className="text-primary">•</span>
                              <span>{event}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="outcomes" className="space-y-4 mt-4">
              <div className="grid gap-4">
                <div className="p-4 border rounded-lg bg-green-50 border-green-200">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge variant="default" className="bg-green-600">Best Case</Badge>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Sellout Time:</span>
                      <span className="font-medium">{simulation.outcomes.bestCase.selloutTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Total Volume:</span>
                      <span className="font-medium">{simulation.outcomes.bestCase.totalVolume.toFixed(4)} ETH</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Collectors:</span>
                      <span className="font-medium">{simulation.outcomes.bestCase.collectorCount}</span>
                    </div>
                  </div>
                </div>

                <div className="p-4 border rounded-lg bg-blue-50 border-blue-200">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge variant="default" className="bg-blue-600">Likely Case</Badge>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Sellout Time:</span>
                      <span className="font-medium">{simulation.outcomes.likelyCase.selloutTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Total Volume:</span>
                      <span className="font-medium">{simulation.outcomes.likelyCase.totalVolume.toFixed(4)} ETH</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Collectors:</span>
                      <span className="font-medium">{simulation.outcomes.likelyCase.collectorCount}</span>
                    </div>
                  </div>
                </div>

                <div className="p-4 border rounded-lg bg-orange-50 border-orange-200">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge variant="default" className="bg-orange-600">Worst Case</Badge>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Sellout Time:</span>
                      <span className="font-medium">{simulation.outcomes.worstCase.selloutTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Total Volume:</span>
                      <span className="font-medium">{simulation.outcomes.worstCase.totalVolume.toFixed(4)} ETH</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Collectors:</span>
                      <span className="font-medium">{simulation.outcomes.worstCase.collectorCount}</span>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="recommendations" className="space-y-4 mt-4">
              <div className="space-y-3">
                {simulation.recommendations.map((rec, i) => (
                  <div key={i} className="p-4 border rounded-lg flex items-start gap-3">
                    <span className="text-lg">💡</span>
                    <p className="text-sm flex-1">{rec}</p>
                  </div>
                ))}
              </div>

              {simulation.warnings.length > 0 && (
                <div className="mt-4">
                  <h4 className="font-medium text-sm mb-3 flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-orange-600" />
                    Warnings
                  </h4>
                  <div className="space-y-2">
                    {simulation.warnings.map((warning, i) => (
                      <div key={i} className="p-3 border border-orange-200 bg-orange-50 rounded-lg text-sm">
                        {warning}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
