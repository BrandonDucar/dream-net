'use client'

import { useState } from 'react'
import type { Drop, CultureRef, DropFilter } from '@/types/drop-architect'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Eye, Filter } from 'lucide-react'

interface DropsOverviewProps {
  drops: Drop[];
  cultureRefs: CultureRef[];
  onViewDrop: (dropId: string) => void;
}

export function DropsOverview({ drops, cultureRefs, onViewDrop }: DropsOverviewProps) {
  const [filter, setFilter] = useState<DropFilter>({})
  const [searchTerm, setSearchTerm] = useState<string>('')

  const getCultureRef = (cultureRefId: string): CultureRef | undefined => {
    return cultureRefs.find(ref => ref.id === cultureRefId)
  }

  const filteredDrops = drops.filter(drop => {
    if (filter.status && drop.status !== filter.status) return false
    if (filter.platform && drop.platform !== filter.platform) return false
    if (filter.chain && drop.chain !== filter.chain) return false
    if (filter.cultureRefId && drop.cultureRefId !== filter.cultureRefId) return false
    
    if (searchTerm) {
      const search = searchTerm.toLowerCase()
      const cultureRef = getCultureRef(drop.cultureRefId)
      return (
        drop.name.toLowerCase().includes(search) ||
        cultureRef?.name.toLowerCase().includes(search) ||
        cultureRef?.ticker.toLowerCase().includes(search)
      )
    }
    
    return true
  })

  const statusColors: Record<string, string> = {
    'idea': 'bg-gray-100 text-gray-800',
    'draft': 'bg-yellow-100 text-yellow-800',
    'scheduled': 'bg-blue-100 text-blue-800',
    'live': 'bg-green-100 text-green-800',
    'completed': 'bg-purple-100 text-purple-800',
    'archived': 'bg-gray-100 text-gray-500'
  }

  const uniquePlatforms = Array.from(new Set(drops.map(d => d.platform)))
  const uniqueChains = Array.from(new Set(drops.map(d => d.chain)))

  return (
    <div className="max-w-7xl mx-auto">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>All Drops Overview</CardTitle>
            <Badge variant="secondary">{filteredDrops.length} drops</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex gap-3 flex-wrap items-end">
              <div className="flex-1 min-w-64">
                <Input
                  placeholder="Search by drop name or CultureRef..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <Select value={filter.status || 'all'} onValueChange={(value) => setFilter({ ...filter, status: value === 'all' ? undefined : value as Drop['status'] })}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="idea">Idea</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="live">Live</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="archived">Archived</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filter.platform || 'all'} onValueChange={(value) => setFilter({ ...filter, platform: value === 'all' ? undefined : value })}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Platform" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Platforms</SelectItem>
                  {uniquePlatforms.map(platform => (
                    <SelectItem key={platform} value={platform}>{platform}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={filter.chain || 'all'} onValueChange={(value) => setFilter({ ...filter, chain: value === 'all' ? undefined : value })}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Chain" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Chains</SelectItem>
                  {uniqueChains.map(chain => (
                    <SelectItem key={chain} value={chain}>{chain}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={filter.cultureRefId || 'all'} onValueChange={(value) => setFilter({ ...filter, cultureRefId: value === 'all' ? undefined : value })}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="CultureRef" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All CultureRefs</SelectItem>
                  {cultureRefs.map(ref => (
                    <SelectItem key={ref.id} value={ref.id}>
                      {ref.primaryEmoji} {ref.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {(filter.status || filter.platform || filter.chain || filter.cultureRefId || searchTerm) && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setFilter({})
                    setSearchTerm('')
                  }}
                >
                  Clear Filters
                </Button>
              )}
            </div>

            {filteredDrops.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <Filter className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No drops found matching your filters.</p>
              </div>
            ) : (
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Drop Name</TableHead>
                      <TableHead>CultureRef</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Chain</TableHead>
                      <TableHead>Platform</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Edition</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredDrops.map(drop => {
                      const cultureRef = getCultureRef(drop.cultureRefId)
                      return (
                        <TableRow key={drop.id}>
                          <TableCell className="font-medium">{drop.name}</TableCell>
                          <TableCell>
                            {cultureRef && (
                              <div className="flex items-center gap-2">
                                <span>{cultureRef.primaryEmoji}</span>
                                <div>
                                  <div className="text-sm font-medium">{cultureRef.name}</div>
                                  <div className="text-xs text-gray-500">${cultureRef.ticker}</div>
                                </div>
                              </div>
                            )}
                          </TableCell>
                          <TableCell>
                            <Badge className={statusColors[drop.status]}>{drop.status}</Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{drop.dropType}</Badge>
                          </TableCell>
                          <TableCell>{drop.chain}</TableCell>
                          <TableCell>{drop.platform}</TableCell>
                          <TableCell>
                            {drop.freeMint ? (
                              <span className="text-green-600 font-semibold text-sm">FREE</span>
                            ) : (
                              <span className="text-sm">
                                {drop.priceETH} ETH
                                {drop.priceToken && <span className="text-xs text-gray-500"> +{drop.priceToken}</span>}
                              </span>
                            )}
                          </TableCell>
                          <TableCell>
                            <span className="text-sm">
                              {drop.editionSize === null ? 'Open' : drop.editionSize}
                            </span>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onViewDrop(drop.id)}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
