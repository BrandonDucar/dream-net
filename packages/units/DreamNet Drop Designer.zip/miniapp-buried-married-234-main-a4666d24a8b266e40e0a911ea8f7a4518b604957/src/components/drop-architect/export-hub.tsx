'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Copy, Check, Download } from 'lucide-react'
import { exportAllFormats } from '@/lib/export-formats'
import type { Drop, CultureRef } from '@/types/drop-architect'
import type { ExportFormat } from '@/types/drop-architect-extended'

interface ExportHubProps {
  drop: Drop
  cultureRef: CultureRef
}

export function ExportHub({ drop, cultureRef }: ExportHubProps) {
  const [formats] = useState<ExportFormat[]>(() => exportAllFormats(drop, cultureRef))
  const [copiedFormat, setCopiedFormat] = useState<string | null>(null)

  const handleCopy = async (format: ExportFormat): Promise<void> => {
    await navigator.clipboard.writeText(format.content)
    setCopiedFormat(format.format)
    setTimeout(() => setCopiedFormat(null), 2000)
  }

  const handleDownload = (format: ExportFormat): void => {
    const extensions: Record<string, string> = {
      'zora-json': 'json',
      'farcaster-post': 'txt',
      'x-thread': 'txt',
      'discord': 'txt',
      'mirror-blog': 'md'
    }
    
    const ext = extensions[format.format] || 'txt'
    const blob = new Blob([format.content], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${drop.name.replace(/\s+/g, '-').toLowerCase()}-${format.format}.${ext}`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const getFormatLabel = (format: string): string => {
    const labels: Record<string, string> = {
      'zora-json': 'Zora Metadata JSON',
      'farcaster-post': 'Farcaster Post',
      'x-thread': 'X (Twitter) Thread',
      'discord': 'Discord Announcement',
      'mirror-blog': 'Mirror Blog Post'
    }
    return labels[format] || format
  }

  const getFormatIcon = (format: string): string => {
    const icons: Record<string, string> = {
      'zora-json': '⚡',
      'farcaster-post': '🟪',
      'x-thread': '🐦',
      'discord': '💬',
      'mirror-blog': '📝'
    }
    return icons[format] || '📄'
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Export Hub</CardTitle>
        <CardDescription>
          Export your drop to multiple platforms with one click
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue={formats[0]?.format || 'zora-json'}>
          <TabsList className="grid w-full grid-cols-5">
            {formats.map(format => (
              <TabsTrigger key={format.format} value={format.format} className="text-xs">
                {getFormatIcon(format.format)}
              </TabsTrigger>
            ))}
          </TabsList>

          {formats.map(format => (
            <TabsContent key={format.format} value={format.format} className="space-y-4 mt-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium">{getFormatLabel(format.format)}</h4>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDownload(format)}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => handleCopy(format)}
                  >
                    {copiedFormat === format.format ? (
                      <>
                        <Check className="h-4 w-4 mr-2" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="h-4 w-4 mr-2" />
                        Copy
                      </>
                    )}
                  </Button>
                </div>
              </div>

              <Textarea
                value={format.content}
                readOnly
                className={`font-mono text-sm ${format.format === 'zora-json' ? 'text-xs' : ''}`}
                rows={format.format === 'mirror-blog' ? 20 : format.format === 'x-thread' ? 15 : 10}
              />

              <div className="p-3 bg-muted rounded-lg text-sm">
                <h5 className="font-medium mb-2">Usage Instructions:</h5>
                {format.format === 'zora-json' && (
                  <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                    <li>Use this metadata when creating your Zora contract</li>
                    <li>Add your actual image URL before deploying</li>
                    <li>Verify all pricing and edition size fields</li>
                  </ul>
                )}
                {format.format === 'farcaster-post' && (
                  <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                    <li>Copy and paste into Warpcast</li>
                    <li>Add your mint link at the end</li>
                    <li>Attach your frame if available</li>
                  </ul>
                )}
                {format.format === 'x-thread' && (
                  <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                    <li>Post each numbered section as a separate tweet</li>
                    <li>Thread them together in order</li>
                    <li>Pin the first tweet to your profile</li>
                  </ul>
                )}
                {format.format === 'discord' && (
                  <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                    <li>Post in your announcement channel</li>
                    <li>@everyone tag already included</li>
                    <li>Add your mint link</li>
                  </ul>
                )}
                {format.format === 'mirror-blog' && (
                  <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                    <li>Paste into Mirror editor (markdown format)</li>
                    <li>Add images where indicated</li>
                    <li>Publish and share the Mirror link</li>
                  </ul>
                )}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  )
}
