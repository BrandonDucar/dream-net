'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Copy, Check, Code, Eye } from 'lucide-react'
import { generateFarcasterFrame, generateFramePreview, generateWarpcastPost } from '@/lib/farcaster-frames'
import type { Drop, CultureRef } from '@/types/drop-architect'

interface FarcasterFrameGeneratorProps {
  drop: Drop
  cultureRef: CultureRef
  imageUrl?: string
}

export function FarcasterFrameGenerator({ drop, cultureRef, imageUrl }: FarcasterFrameGeneratorProps) {
  const [frame] = useState(() => generateFarcasterFrame(drop, cultureRef, imageUrl))
  const [preview] = useState(() => generateFramePreview(drop, cultureRef, imageUrl))
  const [post] = useState(() => generateWarpcastPost(drop, cultureRef, frame.frameUrl))
  const [copiedCode, setCopiedCode] = useState(false)
  const [copiedPost, setCopiedPost] = useState(false)
  const [showCode, setShowCode] = useState(false)

  const handleCopyCode = async (): Promise<void> => {
    await navigator.clipboard.writeText(frame.frameCode)
    setCopiedCode(true)
    setTimeout(() => setCopiedCode(false), 2000)
  }

  const handleCopyPost = async (): Promise<void> => {
    await navigator.clipboard.writeText(post)
    setCopiedPost(true)
    setTimeout(() => setCopiedPost(false), 2000)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            🟪 Farcaster Frame Generator
          </CardTitle>
          <CardDescription>
            Generate a Farcaster frame for easy minting on Warpcast
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-sm">Frame Preview</h4>
              <Badge variant="outline">ASCII Preview</Badge>
            </div>
            <pre className="p-4 bg-muted rounded-lg text-xs font-mono whitespace-pre overflow-x-auto">
              {preview}
            </pre>
          </div>

          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-sm">Warpcast Post Copy</h4>
              <Button
                size="sm"
                variant="outline"
                onClick={handleCopyPost}
              >
                {copiedPost ? (
                  <>
                    <Check className="h-4 w-4 mr-2" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4 mr-2" />
                    Copy
                  </>
                )}
              </Button>
            </div>
            <Textarea
              value={post}
              readOnly
              className="font-mono text-sm"
              rows={8}
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-sm">Frame Metadata</h4>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setShowCode(!showCode)}
                >
                  {showCode ? (
                    <>
                      <Eye className="h-4 w-4 mr-2" />
                      Hide Code
                    </>
                  ) : (
                    <>
                      <Code className="h-4 w-4 mr-2" />
                      Show Code
                    </>
                  )}
                </Button>
                <Button
                  size="sm"
                  onClick={handleCopyCode}
                >
                  {copiedCode ? (
                    <>
                      <Check className="h-4 w-4 mr-2" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4 mr-2" />
                      Copy HTML
                    </>
                  )}
                </Button>
              </div>
            </div>
            {showCode && (
              <Textarea
                value={frame.frameCode}
                readOnly
                className="font-mono text-xs"
                rows={20}
              />
            )}
          </div>

          <div className="p-4 border rounded-lg bg-blue-50 border-blue-200">
            <h4 className="font-medium text-sm mb-2">How to Use</h4>
            <ol className="text-sm space-y-1 list-decimal list-inside text-muted-foreground">
              <li>Copy the HTML code above</li>
              <li>Deploy to your hosting (Vercel, Netlify, etc.)</li>
              <li>Copy the Warpcast post text</li>
              <li>Post on Farcaster with the frame URL</li>
              <li>Users can mint directly from the frame!</li>
            </ol>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 border rounded-lg">
              <div className="text-xs text-muted-foreground mb-1">Frame URL</div>
              <div className="text-sm font-mono break-all">{frame.frameUrl}</div>
            </div>
            <div className="p-3 border rounded-lg">
              <div className="text-xs text-muted-foreground mb-1">Buttons</div>
              <div className="text-sm">{frame.buttons.length} actions</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
