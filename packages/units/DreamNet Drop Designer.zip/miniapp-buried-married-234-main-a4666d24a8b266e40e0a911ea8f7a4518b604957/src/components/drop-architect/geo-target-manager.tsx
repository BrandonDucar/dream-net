'use client'

import { useState } from 'react'
import type { Drop, GeoTarget } from '@/types/drop-architect'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Plus, Trash2, RefreshCw } from 'lucide-react'

interface GeoTargetManagerProps {
  drop: Drop;
  onUpdate: (updates: Partial<Omit<Drop, 'id'>>) => void;
  onGenerateVariants: () => void;
}

export function GeoTargetManager({ drop, onUpdate, onGenerateVariants }: GeoTargetManagerProps) {
  const [newTarget, setNewTarget] = useState<Omit<GeoTarget, 'id'>>({
    region: '',
    country: '',
    cityOrMarket: '',
    language: ''
  })
  const [isAdding, setIsAdding] = useState<boolean>(false)

  const addGeoTarget = (): void => {
    if (!newTarget.region || !newTarget.language) {
      alert('Region and Language are required')
      return
    }

    const target: GeoTarget = {
      id: `${newTarget.region.toLowerCase()}-${newTarget.language}`,
      ...newTarget
    }

    onUpdate({
      primaryGeoTargets: [...drop.primaryGeoTargets, target]
    })

    setNewTarget({ region: '', country: '', cityOrMarket: '', language: '' })
    setIsAdding(false)
  }

  const removeGeoTarget = (id: string): void => {
    const updated = drop.primaryGeoTargets.filter(t => t.id !== id)
    
    const newCaptionLocalized = { ...drop.captionLocalized }
    delete newCaptionLocalized[id]
    
    const newTagsLocalized = { ...drop.tagsLocalized }
    delete newTagsLocalized[id]

    onUpdate({
      primaryGeoTargets: updated,
      captionLocalized: newCaptionLocalized,
      tagsLocalized: newTagsLocalized
    })
  }

  const updateLocalizedCaption = (geoId: string, caption: string): void => {
    onUpdate({
      captionLocalized: { ...drop.captionLocalized, [geoId]: caption }
    })
  }

  const updateLocalizedTags = (geoId: string, tags: string): void => {
    onUpdate({
      tagsLocalized: { ...drop.tagsLocalized, [geoId]: tags.split(',').map(t => t.trim()).filter(t => t) }
    })
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Geo Targets</CardTitle>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setIsAdding(!isAdding)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Target
              </Button>
              {drop.primaryGeoTargets.length > 0 && (
                <Button variant="outline" size="sm" onClick={onGenerateVariants}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Generate Variants
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {isAdding && (
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="pt-6 space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="newRegion">Region*</Label>
                    <Input
                      id="newRegion"
                      value={newTarget.region}
                      onChange={(e) => setNewTarget({ ...newTarget, region: e.target.value })}
                      placeholder="US, EU, LATAM, ASIA"
                    />
                  </div>
                  <div>
                    <Label htmlFor="newLanguage">Language*</Label>
                    <Input
                      id="newLanguage"
                      value={newTarget.language}
                      onChange={(e) => setNewTarget({ ...newTarget, language: e.target.value })}
                      placeholder="en, es, pt-BR, fr, de, ja"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="newCountry">Country (Optional)</Label>
                    <Input
                      id="newCountry"
                      value={newTarget.country}
                      onChange={(e) => setNewTarget({ ...newTarget, country: e.target.value })}
                      placeholder="ISO code, e.g. BR, MX"
                    />
                  </div>
                  <div>
                    <Label htmlFor="newCity">City/Market (Optional)</Label>
                    <Input
                      id="newCity"
                      value={newTarget.cityOrMarket}
                      onChange={(e) => setNewTarget({ ...newTarget, cityOrMarket: e.target.value })}
                      placeholder="Miami, Berlin, São Paulo"
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button onClick={addGeoTarget} size="sm">Add</Button>
                  <Button variant="outline" onClick={() => setIsAdding(false)} size="sm">Cancel</Button>
                </div>
              </CardContent>
            </Card>
          )}

          {drop.primaryGeoTargets.length === 0 ? (
            <div className="text-center text-gray-500 py-8">
              No geo targets configured. Add targets to localize your drop messaging.
            </div>
          ) : (
            <div className="space-y-3">
              {drop.primaryGeoTargets.map(target => (
                <Card key={target.id} className="border-l-4 border-l-blue-500">
                  <CardContent className="pt-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex gap-2 flex-wrap">
                        <Badge>{target.region}</Badge>
                        <Badge variant="secondary">{target.language}</Badge>
                        {target.country && <Badge variant="outline">{target.country}</Badge>}
                        {target.cityOrMarket && <Badge variant="outline">{target.cityOrMarket}</Badge>}
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeGeoTarget(target.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <Label htmlFor={`caption-${target.id}`}>Localized Caption</Label>
                        <Textarea
                          id={`caption-${target.id}`}
                          value={drop.captionLocalized[target.id] || ''}
                          onChange={(e) => updateLocalizedCaption(target.id, e.target.value)}
                          rows={3}
                          placeholder="Enter localized caption for this region"
                        />
                      </div>

                      <div>
                        <Label htmlFor={`tags-${target.id}`}>Localized Tags (comma-separated)</Label>
                        <Textarea
                          id={`tags-${target.id}`}
                          value={drop.tagsLocalized[target.id]?.join(', ') || ''}
                          onChange={(e) => updateLocalizedTags(target.id, e.target.value)}
                          rows={2}
                          placeholder="#tag1, #tag2, #tag3"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
