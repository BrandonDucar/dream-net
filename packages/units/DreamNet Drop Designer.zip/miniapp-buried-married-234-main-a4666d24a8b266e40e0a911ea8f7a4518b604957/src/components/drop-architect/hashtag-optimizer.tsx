'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Hash, TrendingUp, TrendingDown, AlertCircle, Sparkles } from 'lucide-react'
import { analyzeHashtags, optimizeHashtagSet, getRecommendedHashtags } from '@/lib/hashtag-analyzer'
import type { Drop, CultureRef } from '@/types/drop-architect'
import type { HashtagAnalysis } from '@/types/drop-architect-extended'

interface HashtagOptimizerProps {
  drop: Drop
  cultureRef: CultureRef
  onApplyOptimized?: (hashtags: string[]) => void
}

export function HashtagOptimizer({ drop, cultureRef, onApplyOptimized }: HashtagOptimizerProps) {
  const [analysis, setAnalysis] = useState<HashtagAnalysis[]>([])
  const [recommendations, setRecommendations] = useState<string[]>([])
  const [optimized, setOptimized] = useState<{ optimized: string[]; removed: string[]; reasoning: string[] } | null>(null)

  useEffect(() => {
    const analyzed = analyzeHashtags(drop.seoHashtags)
    setAnalysis(analyzed)
    
    const recs = getRecommendedHashtags(
      cultureRef.theme,
      drop.dropType,
      drop.platform,
      drop.chain
    )
    setRecommendations(recs)
    
    const opt = optimizeHashtagSet(drop.seoHashtags)
    setOptimized(opt)
  }, [drop, cultureRef])

  const getStatusColor = (status: HashtagAnalysis['status']): string => {
    switch (status) {
      case 'trending': return 'bg-green-500'
      case 'emerging': return 'bg-blue-500'
      case 'oversaturated': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  const getStatusIcon = (status: HashtagAnalysis['status']): JSX.Element => {
    switch (status) {
      case 'trending': return <TrendingUp className="h-3 w-3" />
      case 'emerging': return <Sparkles className="h-3 w-3" />
      case 'oversaturated': return <AlertCircle className="h-3 w-3" />
      default: return <TrendingDown className="h-3 w-3" />
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Hash className="h-5 w-5" />
          Hashtag Optimizer
        </CardTitle>
        <CardDescription>
          Analyze performance and optimize your hashtag strategy
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h4 className="font-medium text-sm mb-3">Current Hashtags Analysis</h4>
          <div className="space-y-2">
            {analysis.map((item) => (
              <div key={item.tag} className="p-3 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-medium">{item.tag}</span>
                    <Badge variant="outline" className={getStatusColor(item.status)}>
                      <span className="text-white flex items-center gap-1">
                        {getStatusIcon(item.status)}
                        {item.status}
                      </span>
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Activity: {item.baseActivity}/100
                  </div>
                </div>
                
                {item.alternatives.length > 0 && (
                  <div className="mt-2 pt-2 border-t">
                    <div className="text-xs text-muted-foreground mb-1">Alternatives:</div>
                    <div className="flex flex-wrap gap-1">
                      {item.alternatives.map(alt => (
                        <Badge key={alt} variant="secondary" className="text-xs">
                          {alt}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {optimized && optimized.reasoning.length > 0 && (
          <div className="p-4 border rounded-lg bg-blue-50 border-blue-200">
            <h4 className="font-medium text-sm mb-2">Optimization Suggestions</h4>
            <ul className="space-y-1">
              {optimized.reasoning.map((reason, i) => (
                <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                  <span className="text-blue-600">•</span>
                  <span>{reason}</span>
                </li>
              ))}
            </ul>
            
            {onApplyOptimized && optimized.optimized.length > 0 && (
              <Button
                size="sm"
                className="mt-3 w-full"
                onClick={() => onApplyOptimized(optimized.optimized)}
              >
                Apply Optimized Set ({optimized.optimized.length} tags)
              </Button>
            )}
          </div>
        )}

        <div>
          <h4 className="font-medium text-sm mb-3">Recommended Hashtags</h4>
          <p className="text-xs text-muted-foreground mb-3">
            Based on {cultureRef.theme}, {drop.dropType}, {drop.platform}, and {drop.chain}
          </p>
          <div className="flex flex-wrap gap-2">
            {recommendations.map(tag => (
              <Badge key={tag} variant="outline" className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors">
                {tag}
              </Badge>
            ))}
          </div>
        </div>

        <div className="p-4 bg-muted rounded-lg text-sm">
          <h5 className="font-medium mb-2">Hashtag Best Practices</h5>
          <ul className="space-y-1 text-muted-foreground list-disc list-inside">
            <li>Use 5-10 hashtags for optimal reach</li>
            <li>Mix trending and niche tags</li>
            <li>Avoid oversaturated tags unless highly relevant</li>
            <li>Include chain (#Base) and platform (#Zora) tags</li>
            <li>Add community-specific tags ($DREAM, culture-related)</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  )
}
