'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { CheckCircle2, Clock } from 'lucide-react'
import { generateLaunchChecklist, getChecklistProgress } from '@/lib/checklist-generator'
import type { Drop, CultureRef } from '@/types/drop-architect'
import type { LaunchChecklist } from '@/types/drop-architect-extended'

interface LaunchChecklistDisplayProps {
  drop: Drop
  cultureRef: CultureRef
}

export function LaunchChecklistDisplay({ drop, cultureRef }: LaunchChecklistDisplayProps) {
  const [checklist, setChecklist] = useState<LaunchChecklist | null>(null)
  const [progress, setProgress] = useState({ total: 0, completed: 0, percentage: 0, byCategory: {} as Record<string, { total: number; completed: number }> })

  useEffect(() => {
    const generated = generateLaunchChecklist(drop, cultureRef)
    setChecklist(generated)
    setProgress(getChecklistProgress(generated))
  }, [drop, cultureRef])

  const handleToggleItem = (itemId: string): void => {
    if (!checklist) return
    
    const updated: LaunchChecklist = {
      ...checklist,
      items: checklist.items.map(item =>
        item.id === itemId ? { ...item, completed: !item.completed } : item
      )
    }
    setChecklist(updated)
    setProgress(getChecklistProgress(updated))
  }

  if (!checklist) return null

  const preLaunchItems = checklist.items.filter(i => i.category === 'pre-launch')
  const launchDayItems = checklist.items.filter(i => i.category === 'launch-day')
  const postLaunchItems = checklist.items.filter(i => i.category === 'post-launch')

  const renderItems = (items: LaunchChecklist['items']): JSX.Element => (
    <div className="space-y-3">
      {items.map((item) => (
        <div
          key={item.id}
          className={`p-4 border rounded-lg transition-all ${
            item.completed ? 'bg-green-50 border-green-200' : 'bg-background'
          }`}
        >
          <div className="flex items-start gap-3">
            <Checkbox
              checked={item.completed}
              onCheckedChange={() => handleToggleItem(item.id)}
              className="mt-1"
            />
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <p className={`font-medium text-sm ${item.completed ? 'line-through text-muted-foreground' : ''}`}>
                  {item.task}
                </p>
                {item.completed && (
                  <Badge variant="default" className="bg-green-600">
                    <CheckCircle2 className="h-3 w-3 mr-1" />
                    Done
                  </Badge>
                )}
              </div>
              {item.dueDate && (
                <div className="flex items-center gap-1 text-xs text-muted-foreground mb-1">
                  <Clock className="h-3 w-3" />
                  {new Date(item.dueDate).toLocaleDateString()}
                </div>
              )}
              {item.notes && (
                <p className="text-xs text-muted-foreground mt-1">{item.notes}</p>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  )

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Launch Checklist</span>
            <Badge variant={progress.percentage === 100 ? 'default' : 'secondary'}>
              {progress.completed}/{progress.total}
            </Badge>
          </CardTitle>
          <CardDescription>
            Complete guide from pre-launch to post-launch activities
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex items-center justify-between text-sm mb-2">
              <span>Overall Progress</span>
              <span className="font-bold">{progress.percentage}%</span>
            </div>
            <Progress value={progress.percentage} className="h-2" />
          </div>

          <Tabs defaultValue="pre-launch">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="pre-launch">
                Pre-Launch
                <Badge variant="outline" className="ml-2">
                  {progress.byCategory['pre-launch']?.completed || 0}/{progress.byCategory['pre-launch']?.total || 0}
                </Badge>
              </TabsTrigger>
              <TabsTrigger value="launch-day">
                Launch Day
                <Badge variant="outline" className="ml-2">
                  {progress.byCategory['launch-day']?.completed || 0}/{progress.byCategory['launch-day']?.total || 0}
                </Badge>
              </TabsTrigger>
              <TabsTrigger value="post-launch">
                Post-Launch
                <Badge variant="outline" className="ml-2">
                  {progress.byCategory['post-launch']?.completed || 0}/{progress.byCategory['post-launch']?.total || 0}
                </Badge>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="pre-launch" className="mt-4">
              {renderItems(preLaunchItems)}
            </TabsContent>

            <TabsContent value="launch-day" className="mt-4">
              {renderItems(launchDayItems)}
            </TabsContent>

            <TabsContent value="post-launch" className="mt-4">
              {renderItems(postLaunchItems)}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
