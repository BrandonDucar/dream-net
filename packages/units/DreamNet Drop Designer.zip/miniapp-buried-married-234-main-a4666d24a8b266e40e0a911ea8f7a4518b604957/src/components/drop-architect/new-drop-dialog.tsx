'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog'

interface NewDropDialogProps {
  isOpen: boolean;
  cultureRefName: string;
  onConfirm: (notes: string) => void;
  onCancel: () => void;
}

export function NewDropDialog({ isOpen, cultureRefName, onConfirm, onCancel }: NewDropDialogProps) {
  const [notes, setNotes] = useState<string>('')

  const handleConfirm = (): void => {
    onConfirm(notes)
    setNotes('')
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onCancel()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create New Drop for {cultureRefName}</DialogTitle>
        </DialogHeader>
        <div className="py-4">
          <Label htmlFor="notes">Drop Notes (Optional)</Label>
          <Textarea
            id="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="e.g. open edition, 1/1 artwork, frame for announcement, etc."
            rows={4}
            className="mt-2"
          />
          <p className="text-xs text-gray-500 mt-2">
            These notes will help generate the initial drop concept. Leave blank for default edition settings.
          </p>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onCancel}>Cancel</Button>
          <Button onClick={handleConfirm}>Create Drop</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
