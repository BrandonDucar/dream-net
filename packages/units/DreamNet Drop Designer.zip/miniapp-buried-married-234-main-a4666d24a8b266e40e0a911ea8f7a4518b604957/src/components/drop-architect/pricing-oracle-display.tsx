'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { TrendingUp, AlertTriangle, CheckCircle, RefreshCw } from 'lucide-react'
import { getPricingRecommendation } from '@/lib/pricing-oracle'
import type { Drop, CultureRef } from '@/types/drop-architect'
import type { PricingRecommendation } from '@/types/drop-architect-extended'

interface PricingOracleDisplayProps {
  drop: Drop
  cultureRef: CultureRef
  onApplyRecommendation?: (priceETH: number) => void
}

export function PricingOracleDisplay({ drop, cultureRef, onApplyRecommendation }: PricingOracleDisplayProps) {
  const [recommendation, setRecommendation] = useState<PricingRecommendation | null>(null)

  useEffect(() => {
    const rec = getPricingRecommendation(drop, cultureRef)
    setRecommendation(rec)
  }, [drop, cultureRef])

  if (!recommendation) return null

  const currentPrice = drop.priceETH || 0
  const recommendedPrice = recommendation.recommendedPriceETH
  const priceDiff = recommendedPrice - currentPrice
  const priceDiffPercent = currentPrice > 0 ? (priceDiff / currentPrice) * 100 : 0

  const confidenceColor = recommendation.confidenceScore >= 0.7 ? 'text-green-500' : 
                          recommendation.confidenceScore >= 0.5 ? 'text-yellow-500' : 
                          'text-orange-500'

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Smart Pricing Oracle
          </span>
          <Badge variant={Math.abs(priceDiffPercent) < 20 ? 'default' : 'outline'}>
            {Math.round(recommendation.confidenceScore * 100)}% confidence
          </Badge>
        </CardTitle>
        <CardDescription>
          Data-driven pricing recommendation based on {recommendation.comparableDrops.length} successful drops
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 border rounded-lg">
            <div className="text-sm text-muted-foreground mb-1">Current Price</div>
            <div className="text-2xl font-bold">{currentPrice.toFixed(4)} ETH</div>
          </div>
          <div className="p-4 border rounded-lg bg-primary/5">
            <div className="text-sm text-muted-foreground mb-1">Recommended Price</div>
            <div className="text-2xl font-bold text-primary">{recommendedPrice.toFixed(4)} ETH</div>
          </div>
        </div>

        {Math.abs(priceDiff) > 0.001 && (
          <div className={`p-4 border rounded-lg ${priceDiff > 0 ? 'bg-green-50 border-green-200' : 'bg-orange-50 border-orange-200'}`}>
            <div className="flex items-start gap-3">
              {priceDiff > 0 ? (
                <TrendingUp className="h-5 w-5 text-green-600 mt-0.5" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-orange-600 mt-0.5" />
              )}
              <div className="flex-1">
                <p className="font-medium text-sm mb-1">
                  {priceDiff > 0 ? 'Consider increasing price' : 'Consider lowering price'}
                </p>
                <p className="text-sm text-muted-foreground">
                  {Math.abs(priceDiffPercent).toFixed(0)}% {priceDiff > 0 ? 'increase' : 'decrease'} ({priceDiff > 0 ? '+' : ''}{priceDiff.toFixed(4)} ETH)
                </p>
              </div>
            </div>
          </div>
        )}

        <div>
          <h4 className="font-medium text-sm mb-2">Reasoning</h4>
          <div className="p-3 bg-muted rounded-lg">
            <pre className="text-xs whitespace-pre-wrap font-mono">{recommendation.reasoning}</pre>
          </div>
        </div>

        <div>
          <h4 className="font-medium text-sm mb-2">Market Conditions</h4>
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 border rounded-lg">
              <div className="text-xs text-muted-foreground mb-1">Base Activity</div>
              <Badge variant={recommendation.marketConditions.baseActivity === 'high' ? 'default' : 'secondary'}>
                {recommendation.marketConditions.baseActivity}
              </Badge>
            </div>
            <div className="p-3 border rounded-lg">
              <div className="text-xs text-muted-foreground mb-1">Zora Volume</div>
              <Badge variant={recommendation.marketConditions.zoraVolume === 'high' ? 'default' : 'secondary'}>
                {recommendation.marketConditions.zoraVolume}
              </Badge>
            </div>
          </div>
        </div>

        {recommendation.marketConditions.trendingThemes.length > 0 && (
          <div>
            <h4 className="font-medium text-sm mb-2">Trending Themes</h4>
            <div className="flex flex-wrap gap-2">
              {recommendation.marketConditions.trendingThemes.map(theme => (
                <Badge key={theme} variant="outline">{theme}</Badge>
              ))}
            </div>
          </div>
        )}

        {recommendation.comparableDrops.length > 0 && (
          <div>
            <h4 className="font-medium text-sm mb-2">Similar Successful Drops</h4>
            <div className="space-y-2">
              {recommendation.comparableDrops.slice(0, 3).map(comp => (
                <div key={comp.id} className="p-3 border rounded-lg text-sm">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium">{comp.name}</span>
                    <Badge variant="outline">{comp.priceETH.toFixed(4)} ETH</Badge>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {comp.editionSize ? `${comp.editionSize} editions` : 'Open edition'} • 
                    {comp.mintedCount} minted • {comp.mintDuration} • 
                    {'⭐'.repeat(comp.successRating)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {onApplyRecommendation && Math.abs(priceDiff) > 0.001 && (
          <Button 
            className="w-full" 
            onClick={() => onApplyRecommendation(recommendedPrice)}
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            Apply Recommended Price
          </Button>
        )}
      </CardContent>
    </Card>
  )
}
