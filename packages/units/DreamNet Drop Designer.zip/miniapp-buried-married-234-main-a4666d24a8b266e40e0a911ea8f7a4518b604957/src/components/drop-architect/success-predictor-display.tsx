'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Target, TrendingUp, AlertTriangle, Lightbulb, Clock } from 'lucide-react'
import { predictDropSuccess } from '@/lib/success-predictor'
import type { Drop, CultureRef } from '@/types/drop-architect'
import type { SuccessPrediction } from '@/types/drop-architect-extended'

interface SuccessPredictorDisplayProps {
  drop: Drop
  cultureRef: CultureRef
}

export function SuccessPredictorDisplay({ drop, cultureRef }: SuccessPredictorDisplayProps) {
  const [prediction, setPrediction] = useState<SuccessPrediction | null>(null)

  useEffect(() => {
    const pred = predictDropSuccess(drop, cultureRef)
    setPrediction(pred)
  }, [drop, cultureRef])

  if (!prediction) return null

  const getScoreColor = (score: number): string => {
    if (score >= 80) return 'text-green-600'
    if (score >= 60) return 'text-yellow-600'
    return 'text-orange-600'
  }

  const getScoreVariant = (score: number): 'default' | 'secondary' | 'destructive' => {
    if (score >= 80) return 'default'
    if (score >= 60) return 'secondary'
    return 'destructive'
  }

  const velocityColor = {
    fast: 'text-green-600',
    medium: 'text-yellow-600',
    slow: 'text-orange-600'
  }[prediction.predictedMintVelocity]

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Drop Success Prediction
            </span>
            <Badge variant={getScoreVariant(prediction.overallScore)}>
              {prediction.overallScore}/100
            </Badge>
          </CardTitle>
          <CardDescription>
            AI-powered analysis of your drop's success potential ({Math.round(prediction.confidence * 100)}% confidence)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span>Success Score</span>
              <span className={`font-bold ${getScoreColor(prediction.overallScore)}`}>
                {prediction.overallScore}/100
              </span>
            </div>
            <Progress value={prediction.overallScore} className="h-3" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 border rounded-lg">
              <div className="text-sm text-muted-foreground mb-2">Predicted Velocity</div>
              <div className={`text-xl font-bold capitalize ${velocityColor}`}>
                {prediction.predictedMintVelocity}
              </div>
            </div>
            <div className="p-4 border rounded-lg">
              <div className="text-sm text-muted-foreground mb-2">Estimated Sellout</div>
              <div className="text-xl font-bold">
                {prediction.estimatedSelloutTime}
              </div>
            </div>
          </div>

          <div className="p-4 border rounded-lg bg-blue-50 border-blue-200">
            <div className="flex items-start gap-3">
              <Clock className="h-5 w-5 text-blue-600 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-sm mb-1">Ideal Launch Window</p>
                <p className="text-sm text-muted-foreground">
                  {prediction.idealLaunchWindow.dayOfWeek} at {prediction.idealLaunchWindow.timeRange}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  ({prediction.idealLaunchWindow.timezone})
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {prediction.riskFactors.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-600">
              <AlertTriangle className="h-5 w-5" />
              Risk Factors ({prediction.riskFactors.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {prediction.riskFactors.map((risk, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <span className="text-orange-600">⚠️</span>
                  <span>{risk}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {prediction.opportunities.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-600">
              <TrendingUp className="h-5 w-5" />
              Opportunities ({prediction.opportunities.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {prediction.opportunities.map((opp, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <span className="text-green-600">✨</span>
                  <span>{opp}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {prediction.improvements.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lightbulb className="h-5 w-5" />
              Suggested Improvements ({prediction.improvements.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {prediction.improvements.map((improvement, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <span>💡</span>
                  <span>{improvement}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
