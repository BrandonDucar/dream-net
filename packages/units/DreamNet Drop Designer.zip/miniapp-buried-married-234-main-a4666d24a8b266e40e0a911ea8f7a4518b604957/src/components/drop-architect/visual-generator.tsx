'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Loader2, Sparkles, Download, Check } from 'lucide-react'
import type { Drop, CultureRef } from '@/types/drop-architect'
import type { GeneratedVisual } from '@/types/drop-architect-extended'

interface VisualGeneratorProps {
  drop: Drop
  cultureRef: CultureRef
  onVisualGenerated?: (visual: GeneratedVisual) => void
}

export function VisualGenerator({ drop, cultureRef, onVisualGenerated }: VisualGeneratorProps) {
  const [visuals, setVisuals] = useState<GeneratedVisual[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const [selectedVisualId, setSelectedVisualId] = useState<string | null>(null)
  const [generatingPromptIndex, setGeneratingPromptIndex] = useState<number | null>(null)

  const handleGenerateFromPrompt = async (prompt: string, index: number): Promise<void> => {
    setIsGenerating(true)
    setGeneratingPromptIndex(index)
    
    try {
      // Simulate AI image generation (in production, this would call generate_image tool)
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      const newVisual: GeneratedVisual = {
        id: `visual-${Date.now()}-${index}`,
        dropId: drop.id,
        prompt,
        imageUrl: `https://picsum.photos/seed/${drop.id}-${index}/800/600`, // placeholder
        createdAt: new Date().toISOString(),
        isSelected: false
      }
      
      setVisuals(prev => [...prev, newVisual])
      if (onVisualGenerated) onVisualGenerated(newVisual)
    } catch (error) {
      console.error('Failed to generate visual:', error)
    } finally {
      setIsGenerating(false)
      setGeneratingPromptIndex(null)
    }
  }

  const handleSelectVisual = (visualId: string): void => {
    setSelectedVisualId(visualId)
    setVisuals(prev => prev.map(v => ({
      ...v,
      isSelected: v.id === visualId
    })))
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5" />
            AI Visual Generation
          </CardTitle>
          <CardDescription>
            Generate artwork based on your media prompts using AI
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Click any prompt below to generate artwork:
            </p>
            {drop.mediaPrompts.map((prompt, index) => (
              <div key={index} className="flex items-start gap-3 p-3 border rounded-lg">
                <div className="flex-1">
                  <p className="text-sm font-medium mb-1">Prompt {index + 1}</p>
                  <p className="text-sm text-muted-foreground">{prompt}</p>
                </div>
                <Button
                  size="sm"
                  onClick={() => handleGenerateFromPrompt(prompt, index)}
                  disabled={isGenerating}
                >
                  {isGenerating && generatingPromptIndex === index ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4 mr-2" />
                      Generate
                    </>
                  )}
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {visuals.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Generated Visuals ({visuals.length})</CardTitle>
            <CardDescription>
              Select your favorite to use for the drop
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {visuals.map((visual) => (
                <div
                  key={visual.id}
                  className={`relative border-2 rounded-lg overflow-hidden cursor-pointer transition-all ${
                    visual.isSelected ? 'border-primary ring-2 ring-primary' : 'border-border hover:border-primary/50'
                  }`}
                  onClick={() => handleSelectVisual(visual.id)}
                >
                  <img
                    src={visual.imageUrl}
                    alt={visual.prompt.substring(0, 50)}
                    className="w-full aspect-[4/3] object-cover"
                  />
                  {visual.isSelected && (
                    <div className="absolute top-2 right-2">
                      <Badge className="bg-primary">
                        <Check className="h-3 w-3 mr-1" />
                        Selected
                      </Badge>
                    </div>
                  )}
                  <div className="p-2 bg-background/95">
                    <p className="text-xs text-muted-foreground line-clamp-2">
                      {visual.prompt}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
