'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import type { Drop, CultureRef } from '@/types/drop-architect'

interface VisualPreviewCardProps {
  drop: Drop
  cultureRef: CultureRef
  imageUrl?: string
}

export function VisualPreviewCard({ drop, cultureRef, imageUrl }: VisualPreviewCardProps) {
  const price = drop.freeMint ? 'FREE' : `${drop.priceETH} ETH`
  const edition = drop.editionSize === null ? 'Open Edition' : `${drop.editionSize} editions`

  return (
    <Card className="overflow-hidden">
      <CardHeader>
        <CardTitle className="text-sm">Drop Preview Card</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="bg-gradient-to-br from-purple-500 via-blue-500 to-cyan-500 p-6">
          {imageUrl ? (
            <img 
              src={imageUrl} 
              alt={drop.name}
              className="w-full aspect-[4/3] object-cover rounded-lg mb-4"
            />
          ) : (
            <div className="w-full aspect-[4/3] bg-black/20 rounded-lg mb-4 flex items-center justify-center backdrop-blur-sm">
              <div className="text-center">
                <div className="text-6xl mb-2">{cultureRef.primaryEmoji}</div>
                <div className="text-white/80 text-sm">Generate artwork to preview</div>
              </div>
            </div>
          )}
          
          <div className="bg-white/95 backdrop-blur-md rounded-lg p-4 space-y-3">
            <div>
              <div className="flex items-start gap-2 mb-1">
                <span className="text-2xl">{cultureRef.primaryEmoji}</span>
                <div className="flex-1">
                  <h3 className="font-bold text-lg">{drop.name}</h3>
                  <p className="text-sm text-muted-foreground line-clamp-2">{drop.conceptSummary}</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-between pt-2 border-t">
              <div>
                <div className="text-xs text-muted-foreground">Price</div>
                <div className="font-bold">{price}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Edition</div>
                <div className="font-bold">{edition}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Chain</div>
                <Badge variant="outline">{drop.chain}</Badge>
              </div>
            </div>
          </div>
        </div>
        
        <div className="p-4 bg-muted text-xs text-center text-muted-foreground">
          Preview of how this drop will appear on Zora, X, and Farcaster
        </div>
      </CardContent>
    </Card>
  )
}
