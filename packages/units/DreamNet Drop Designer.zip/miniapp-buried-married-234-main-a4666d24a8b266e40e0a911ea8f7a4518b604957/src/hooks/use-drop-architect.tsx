'use client'

import { useState, useEffect } from 'react'
import type { CultureRef, Drop, GeoTarget, DropFilter } from '@/types/drop-architect'

const STORAGE_KEY_CULTURE_REFS = 'dreamnet-culture-refs'
const STORAGE_KEY_DROPS = 'dreamnet-drops'

export function useDropArchitect() {
  const [cultureRefs, setCultureRefs] = useState<CultureRef[]>([])
  const [drops, setDrops] = useState<Drop[]>([])
  const [isLoaded, setIsLoaded] = useState<boolean>(false)

  // Load from localStorage on mount
  useEffect(() => {
    const loadedRefs = localStorage.getItem(STORAGE_KEY_CULTURE_REFS)
    const loadedDrops = localStorage.getItem(STORAGE_KEY_DROPS)
    
    if (loadedRefs) {
      setCultureRefs(JSON.parse(loadedRefs))
    }
    if (loadedDrops) {
      setDrops(JSON.parse(loadedDrops))
    }
    
    setIsLoaded(true)
  }, [])

  // Save to localStorage whenever data changes
  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(STORAGE_KEY_CULTURE_REFS, JSON.stringify(cultureRefs))
    }
  }, [cultureRefs, isLoaded])

  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(STORAGE_KEY_DROPS, JSON.stringify(drops))
    }
  }, [drops, isLoaded])

  // 1) Create CultureRef
  const createCultureRef = (data: Omit<CultureRef, 'id'>): CultureRef => {
    const newRef: CultureRef = {
      id: `cr-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      ...data
    }
    setCultureRefs(prev => [...prev, newRef])
    return newRef
  }

  // Update CultureRef
  const updateCultureRef = (id: string, data: Partial<Omit<CultureRef, 'id'>>): void => {
    setCultureRefs(prev => prev.map(ref => 
      ref.id === id ? { ...ref, ...data } : ref
    ))
  }

  // Delete CultureRef
  const deleteCultureRef = (id: string): void => {
    setCultureRefs(prev => prev.filter(ref => ref.id !== id))
    // Also delete associated drops
    setDrops(prev => prev.filter(drop => drop.cultureRefId !== id))
  }

  // 2) Create Drop for CultureRef
  const createDropForCultureRef = (cultureRefId: string, notes?: string): Drop => {
    const cultureRef = cultureRefs.find(ref => ref.id === cultureRefId)
    if (!cultureRef) throw new Error('CultureRef not found')

    const dropId = `drop-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    
    // Infer drop name and generate content
    const inferredName = `${cultureRef.name} ${notes ? notes.split(' ').slice(0, 3).join(' ') : 'Drop'}`
    const dropType = inferDropType(notes)
    const editionSize = inferEditionSize(dropType)
    const pricing = inferPricing(dropType)
    
    const newDrop: Drop = {
      id: dropId,
      cultureRefId,
      name: inferredName,
      dropType,
      chain: 'Base',
      platform: 'Zora',
      status: 'idea',
      
      // Economics
      editionSize,
      priceETH: pricing.eth,
      priceToken: pricing.token,
      priceTokenAmount: pricing.tokenAmount,
      freeMint: pricing.free,
      allowlistNotes: '',
      royaltyPercent: 10,
      
      // Content & Narrative
      conceptSummary: generateConceptSummary(cultureRef, dropType, notes),
      loreSnippet: generateLoreSnippet(cultureRef),
      visualDirection: generateVisualDirection(cultureRef, dropType),
      mediaType: inferMediaType(dropType),
      mediaPrompts: generateMediaPrompts(cultureRef, dropType),
      
      // Launch & Distribution
      targetAudienceNotes: generateTargetAudience(cultureRef),
      launchTiming: 'TBD - next 1-2 weeks',
      launchWindowStart: null,
      launchWindowEnd: null,
      supportingChannels: ['farcaster', 'x', 'zora', 'base-feed'],
      preLaunchIdeas: generatePreLaunchIdeas(cultureRef, dropType),
      postLaunchFollowUps: generatePostLaunchFollowUps(cultureRef),
      
      // SEO & META
      seoTitle: generateSEOTitle(cultureRef, inferredName),
      seoDescription: generateSEODescription(cultureRef, dropType),
      seoKeywords: generateSEOKeywords(cultureRef),
      seoHashtags: generateSEOHashtags(cultureRef),
      altText: generateAltText(cultureRef, dropType),
      
      // Geo Targeting
      primaryGeoTargets: [],
      captionLocalized: {},
      tagsLocalized: {}
    }

    setDrops(prev => [...prev, newDrop])
    return newDrop
  }

  // 3) Update Drop
  const updateDrop = (id: string, data: Partial<Omit<Drop, 'id'>>): void => {
    setDrops(prev => prev.map(drop => 
      drop.id === id ? { ...drop, ...data } : drop
    ))
  }

  // 4) Regenerate Narrative
  const regenerateNarrativeForDrop = (id: string): Drop | null => {
    const drop = drops.find(d => d.id === id)
    if (!drop) return null
    
    const cultureRef = cultureRefs.find(ref => ref.id === drop.cultureRefId)
    if (!cultureRef) return null

    const updates = {
      conceptSummary: generateConceptSummary(cultureRef, drop.dropType),
      loreSnippet: generateLoreSnippet(cultureRef),
      visualDirection: generateVisualDirection(cultureRef, drop.dropType),
      mediaPrompts: generateMediaPrompts(cultureRef, drop.dropType)
    }

    updateDrop(id, updates)
    return { ...drop, ...updates }
  }

  // 5) Regenerate Economics
  const regenerateEconomics = (id: string, hints?: string): Drop | null => {
    const drop = drops.find(d => d.id === id)
    if (!drop) return null

    const adjustedPricing = adjustPricingByHint(drop.dropType, hints)
    const updates = {
      editionSize: adjustedPricing.editionSize,
      priceETH: adjustedPricing.eth,
      priceToken: adjustedPricing.token,
      priceTokenAmount: adjustedPricing.tokenAmount,
      freeMint: adjustedPricing.free,
      royaltyPercent: adjustedPricing.royalty
    }

    updateDrop(id, updates)
    return { ...drop, ...updates }
  }

  // 6) Regenerate Messaging and SEO
  const regenerateMessagingAndSEO = (id: string): Drop | null => {
    const drop = drops.find(d => d.id === id)
    if (!drop) return null
    
    const cultureRef = cultureRefs.find(ref => ref.id === drop.cultureRefId)
    if (!cultureRef) return null

    const updates = {
      targetAudienceNotes: generateTargetAudience(cultureRef),
      preLaunchIdeas: generatePreLaunchIdeas(cultureRef, drop.dropType),
      postLaunchFollowUps: generatePostLaunchFollowUps(cultureRef),
      seoTitle: generateSEOTitle(cultureRef, drop.name),
      seoDescription: generateSEODescription(cultureRef, drop.dropType),
      seoKeywords: generateSEOKeywords(cultureRef),
      seoHashtags: generateSEOHashtags(cultureRef),
      altText: generateAltText(cultureRef, drop.dropType)
    }

    updateDrop(id, updates)
    return { ...drop, ...updates }
  }

  // 7) Assign Geo Targets
  const assignGeoTargetsToDrop = (id: string, geoTargets: GeoTarget[]): void => {
    updateDrop(id, { primaryGeoTargets: geoTargets })
  }

  // 8) Generate Geo Variants
  const generateGeoVariantsForDrop = (id: string): Drop | null => {
    const drop = drops.find(d => d.id === id)
    if (!drop) return null

    const cultureRef = cultureRefs.find(ref => ref.id === drop.cultureRefId)
    if (!cultureRef) return null

    const baseCaption = drop.conceptSummary
    const captionLocalized: Record<string, string> = {}
    const tagsLocalized: Record<string, string[]> = {}

    drop.primaryGeoTargets.forEach(target => {
      const geoKey = target.id
      captionLocalized[geoKey] = localizeCaption(baseCaption, target, cultureRef)
      tagsLocalized[geoKey] = localizeTags(drop.seoHashtags, target, cultureRef)
    })

    updateDrop(id, { captionLocalized, tagsLocalized })
    return { ...drop, captionLocalized, tagsLocalized }
  }

  // 9) Set Drop Timing
  const setDropTiming = (id: string, start: string | null, end: string | null): void => {
    let timingText = 'TBD'
    if (start && end) {
      const startDate = new Date(start)
      const endDate = new Date(end)
      timingText = `${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}`
    } else if (start) {
      timingText = `Starting ${new Date(start).toLocaleDateString()}`
    }

    updateDrop(id, {
      launchWindowStart: start,
      launchWindowEnd: end,
      launchTiming: timingText
    })
  }

  // 10) List Drops with filters
  const listDrops = (filter?: DropFilter): Drop[] => {
    let filtered = [...drops]

    if (filter?.status) {
      filtered = filtered.filter(d => d.status === filter.status)
    }
    if (filter?.platform) {
      filtered = filtered.filter(d => d.platform === filter.platform)
    }
    if (filter?.chain) {
      filtered = filtered.filter(d => d.chain === filter.chain)
    }
    if (filter?.cultureRefId) {
      filtered = filtered.filter(d => d.cultureRefId === filter.cultureRefId)
    }

    return filtered
  }

  // 11) Get Drop by ID
  const getDrop = (id: string): Drop | undefined => {
    return drops.find(d => d.id === id)
  }

  // 12) Export Drop Brief
  const exportDropBrief = (id: string): string => {
    const drop = drops.find(d => d.id === id)
    if (!drop) return 'Drop not found'

    const cultureRef = cultureRefs.find(ref => ref.id === drop.cultureRefId)
    if (!cultureRef) return 'CultureRef not found'

    const pricingInfo = drop.freeMint 
      ? 'FREE MINT' 
      : `${drop.priceETH || 0} ETH${drop.priceToken ? ` + ${drop.priceTokenAmount} ${drop.priceToken}` : ''}`

    const geoSummary = drop.primaryGeoTargets.map(target => {
      const caption = drop.captionLocalized[target.id] || 'N/A'
      const tags = drop.tagsLocalized[target.id] || []
      return `  ${target.region} (${target.language}):\n    Caption: ${caption}\n    Tags: ${tags.join(', ')}`
    }).join('\n\n')

    return `
═══════════════════════════════════════════════
  DREAMNET DROP ARCHITECT - DROP BRIEF
═══════════════════════════════════════════════

DROP IDENTITY
────────────────────────────────────────────────
Name: ${drop.name}
Type: ${drop.dropType}
Status: ${drop.status}
Chain: ${drop.chain}
Platform: ${drop.platform}

CULTUREREF
────────────────────────────────────────────────
${cultureRef.primaryEmoji} ${cultureRef.name} ($${cultureRef.ticker})
Theme: ${cultureRef.theme}
Archetype: ${cultureRef.archetype}

CONCEPT
────────────────────────────────────────────────
${drop.conceptSummary}

LORE
────────────────────────────────────────────────
${drop.loreSnippet}

VISUAL DIRECTION
────────────────────────────────────────────────
Media Type: ${drop.mediaType}
${drop.visualDirection}

Media Prompts:
${drop.mediaPrompts.map((p, i) => `${i + 1}. ${p}`).join('\n')}

ECONOMICS
────────────────────────────────────────────────
Edition Size: ${drop.editionSize === null ? 'Open Edition' : drop.editionSize}
Price: ${pricingInfo}
Royalty: ${drop.royaltyPercent}%
Allowlist: ${drop.allowlistNotes || 'None'}

TARGET AUDIENCE
────────────────────────────────────────────────
${drop.targetAudienceNotes}

LAUNCH STRATEGY
────────────────────────────────────────────────
Timing: ${drop.launchTiming}
${drop.launchWindowStart ? `Window: ${new Date(drop.launchWindowStart).toLocaleString()} - ${drop.launchWindowEnd ? new Date(drop.launchWindowEnd).toLocaleString() : 'TBD'}` : ''}

Channels: ${drop.supportingChannels.join(', ')}

PRE-LAUNCH IDEAS
────────────────────────────────────────────────
${drop.preLaunchIdeas.map((idea, i) => `${i + 1}. ${idea}`).join('\n')}

POST-LAUNCH FOLLOW-UPS
────────────────────────────────────────────────
${drop.postLaunchFollowUps.map((idea, i) => `${i + 1}. ${idea}`).join('\n')}

SEO & META
────────────────────────────────────────────────
Title: ${drop.seoTitle}
Description: ${drop.seoDescription}
Keywords: ${drop.seoKeywords.join(', ')}
Hashtags: ${drop.seoHashtags.join(' ')}
Alt Text: ${drop.altText}

GEO TARGETING
────────────────────────────────────────────────
${drop.primaryGeoTargets.length > 0 ? geoSummary : 'No geo targets configured'}

═══════════════════════════════════════════════
  End of Drop Brief - Ready to Ship! 🚀
═══════════════════════════════════════════════
`.trim()
  }

  // Delete Drop
  const deleteDrop = (id: string): void => {
    setDrops(prev => prev.filter(drop => drop.id !== id))
  }

  return {
    cultureRefs,
    drops,
    isLoaded,
    createCultureRef,
    updateCultureRef,
    deleteCultureRef,
    createDropForCultureRef,
    updateDrop,
    deleteDrop,
    regenerateNarrativeForDrop,
    regenerateEconomics,
    regenerateMessagingAndSEO,
    assignGeoTargetsToDrop,
    generateGeoVariantsForDrop,
    setDropTiming,
    listDrops,
    getDrop,
    exportDropBrief
  }
}

// Helper functions for content generation

function inferDropType(notes?: string): string {
  if (!notes) return 'edition'
  const lower = notes.toLowerCase()
  if (lower.includes('1/1') || lower.includes('one of one')) return '1/1'
  if (lower.includes('open')) return 'open edition'
  if (lower.includes('frame')) return 'frame'
  if (lower.includes('airdrop')) return 'airdrop concept'
  return 'edition'
}

function inferEditionSize(dropType: string): number | null {
  if (dropType === 'open edition') return null
  if (dropType === '1/1') return 1
  if (dropType === 'edition') return 100
  return 50
}

function inferPricing(dropType: string): { eth: number | null; token: string | null; tokenAmount: number | null; free: boolean } {
  if (dropType === 'airdrop concept') return { eth: null, token: null, tokenAmount: null, free: true }
  if (dropType === 'open edition') return { eth: 0.001, token: null, tokenAmount: null, free: false }
  if (dropType === '1/1') return { eth: 0.1, token: null, tokenAmount: null, free: false }
  return { eth: 0.005, token: null, tokenAmount: null, free: false }
}

function inferMediaType(dropType: string): string {
  if (dropType === 'frame') return 'image'
  return 'image'
}

function generateConceptSummary(cultureRef: CultureRef, dropType: string, notes?: string): string {
  const summaries = [
    `${cultureRef.primaryEmoji} This ${dropType} celebrates ${cultureRef.name}'s ${cultureRef.theme} through on-chain culture. A rare opportunity to own a piece of the ${cultureRef.archetype} movement on Base.`,
    `Introducing a ${dropType} that captures the essence of ${cultureRef.name} ($${cultureRef.ticker}). This drop embodies ${cultureRef.theme} and brings ${cultureRef.archetype} energy to the Zora ecosystem.`,
    `${cultureRef.name} manifests on-chain with this exclusive ${dropType}. Designed for the community, this drop channels ${cultureRef.theme} and the spirit of ${cultureRef.archetype}.`
  ]
  return summaries[Math.floor(Math.random() * summaries.length)]
}

function generateLoreSnippet(cultureRef: CultureRef): string {
  return `In the realm of ${cultureRef.theme}, ${cultureRef.name} emerges as the ${cultureRef.archetype}. Every token holder becomes part of the ${cultureRef.ticker} mythos, building culture on Base, one mint at a time. ${cultureRef.primaryEmoji}`
}

function generateVisualDirection(cultureRef: CultureRef, dropType: string): string {
  return `Visual style: ${cultureRef.theme}-inspired aesthetic with ${cultureRef.archetype} elements. Color palette should evoke ${cultureRef.name}'s energy. Include ${cultureRef.primaryEmoji} as a central motif. Style: modern, crypto-native, bold.`
}

function generateMediaPrompts(cultureRef: CultureRef, dropType: string): string[] {
  return [
    `${cultureRef.primaryEmoji} ${cultureRef.name} ${cultureRef.theme} ${cultureRef.archetype} on-chain culture Base blockchain`,
    `Abstract representation of ${cultureRef.ticker} token with ${cultureRef.theme} aesthetic`,
    `${cultureRef.archetype} inspired by ${cultureRef.name}, crypto-native art style`
  ]
}

function generateTargetAudience(cultureRef: CultureRef): string {
  return `Base builders, ${cultureRef.theme} enthusiasts, ${cultureRef.archetype} community, Zora collectors, ${cultureRef.ticker} believers, and crypto-culture pioneers.`
}

function generatePreLaunchIdeas(cultureRef: CultureRef, dropType: string): string[] {
  return [
    `Teaser frame: "${cultureRef.primaryEmoji} Something's brewing in ${cultureRef.name}..."`,
    `Behind-the-scenes thread on X showing the creative process`,
    `Allowlist contest for ${cultureRef.ticker} community members`,
    `Sneak peek of visual direction in Farcaster channels`
  ]
}

function generatePostLaunchFollowUps(cultureRef: CultureRef): string[] {
  return [
    `Collector spotlight series featuring early minters`,
    `Stats update: edition progress, collector count, volume`,
    `Community call to discuss future ${cultureRef.name} drops`,
    `Exclusive holder channel for ${cultureRef.ticker} minters`
  ]
}

function generateSEOTitle(cultureRef: CultureRef, dropName: string): string {
  return `${dropName} | ${cultureRef.name} Drop on Zora`
}

function generateSEODescription(cultureRef: CultureRef, dropType: string): string {
  return `Mint the ${cultureRef.name} ${dropType} on Base via Zora. ${cultureRef.theme} meets on-chain culture. $${cultureRef.ticker} ${cultureRef.primaryEmoji}`
}

function generateSEOKeywords(cultureRef: CultureRef): string[] {
  return [
    cultureRef.name,
    cultureRef.ticker,
    'Base',
    'Zora',
    'NFT',
    'on-chain culture',
    cultureRef.theme,
    cultureRef.archetype,
    'crypto art',
    'mint'
  ]
}

function generateSEOHashtags(cultureRef: CultureRef): string[] {
  return [
    `#${cultureRef.ticker}`,
    '#Base',
    '#Zora',
    '#NFT',
    '#OnChainCulture',
    `#${cultureRef.name.replace(/\s/g, '')}`,
    '#CryptoArt'
  ]
}

function generateAltText(cultureRef: CultureRef, dropType: string): string {
  return `${cultureRef.name} ${dropType} featuring ${cultureRef.theme} aesthetic with ${cultureRef.primaryEmoji} motif`
}

function adjustPricingByHint(dropType: string, hints?: string): {
  editionSize: number | null;
  eth: number | null;
  token: string | null;
  tokenAmount: number | null;
  free: boolean;
  royalty: number;
} {
  const base = inferPricing(dropType)
  let eth = base.eth
  let editionSize = inferEditionSize(dropType)
  let royalty = 10

  if (hints) {
    const lower = hints.toLowerCase()
    if (lower.includes('accessible') || lower.includes('cheap') || lower.includes('affordable')) {
      eth = eth ? eth * 0.5 : 0.001
      if (editionSize) editionSize = Math.floor(editionSize * 1.5)
      royalty = 7
    }
    if (lower.includes('premium') || lower.includes('expensive') || lower.includes('exclusive')) {
      eth = eth ? eth * 3 : 0.05
      if (editionSize) editionSize = Math.floor(editionSize * 0.5)
      royalty = 15
    }
    if (lower.includes('free')) {
      return { ...base, eth: null, free: true, editionSize, royalty }
    }
  }

  return { ...base, eth, editionSize, royalty }
}

function localizeCaption(baseCaption: string, target: GeoTarget, cultureRef: CultureRef): string {
  const variants: Record<string, string> = {
    'es': `${cultureRef.primaryEmoji} ${cultureRef.name} llega a ${target.region}. ${baseCaption.substring(0, 80)}... ¡Únete a la cultura on-chain!`,
    'pt-BR': `${cultureRef.primaryEmoji} ${cultureRef.name} chega em ${target.region}. ${baseCaption.substring(0, 80)}... Junte-se à cultura on-chain!`,
    'fr': `${cultureRef.primaryEmoji} ${cultureRef.name} arrive en ${target.region}. ${baseCaption.substring(0, 80)}... Rejoignez la culture on-chain!`,
    'de': `${cultureRef.primaryEmoji} ${cultureRef.name} kommt nach ${target.region}. ${baseCaption.substring(0, 80)}... Schließe dich der On-Chain-Kultur an!`,
    'ja': `${cultureRef.primaryEmoji} ${cultureRef.name}が${target.region}に登場。${baseCaption.substring(0, 60)}... オンチェーン文化に参加しよう！`,
    'en': baseCaption
  }

  return variants[target.language] || baseCaption
}

function localizeTags(baseTags: string[], target: GeoTarget, cultureRef: CultureRef): string[] {
  const regionTags: Record<string, string[]> = {
    'US': ['#USCrypto', '#BuildOnBase'],
    'LATAM': ['#CryptoLatam', '#LatamNFT'],
    'EU': ['#EuropeCrypto', '#EUWeb3'],
    'ASIA': ['#AsiaCrypto', '#Web3Asia']
  }

  return [...baseTags, ...(regionTags[target.region] || [])]
}
