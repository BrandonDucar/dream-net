// Allowlist Builder

import type { Drop } from '@/types/drop-architect'
import type { Allowlist } from '@/types/drop-architect-extended'

export function generateAllowlistFromCriteria(drop: Drop): Allowlist {
  const criteria = parseAllowlistCriteria(drop.targetAudienceNotes)
  
  return {
    id: `al-${Date.now()}`,
    dropId: drop.id,
    name: `${drop.name} Allowlist`,
    criteria,
    addresses: [],
    maxSpots: drop.editionSize ? Math.floor(drop.editionSize * 0.3) : 100, // 30% of edition
    expiresAt: drop.launchWindowStart || null
  }
}

function parseAllowlistCriteria(targetAudienceNotes: string): Allowlist['criteria'] {
  const criteria: Allowlist['criteria'] = []
  const lower = targetAudienceNotes.toLowerCase()
  
  // Detect token holders
  const tokenMatch = lower.match(/\$(\w+)/g)
  if (tokenMatch) {
    tokenMatch.forEach(token => {
      criteria.push({
        type: 'token-holder',
        value: token.replace('$', ''),
        description: `Holders of ${token} token`
      })
    })
  }
  
  // Detect NFT mentions
  if (lower.includes('nft') || lower.includes('collector')) {
    criteria.push({
      type: 'nft-holder',
      value: 'any-base-nft',
      description: 'Base NFT collectors'
    })
  }
  
  // Detect community/followers
  if (lower.includes('follower') || lower.includes('community')) {
    criteria.push({
      type: 'farcaster-follower',
      value: '@channel',
      description: 'Farcaster followers'
    })
  }
  
  // Default to manual if no criteria detected
  if (criteria.length === 0) {
    criteria.push({
      type: 'manual',
      value: 'curated',
      description: 'Manually curated list'
    })
  }
  
  return criteria
}

export function generateGuildXYZConfig(allowlist: Allowlist): string {
  const requirements = allowlist.criteria.map(c => {
    switch (c.type) {
      case 'token-holder':
        return `- Hold ${c.value} token`
      case 'nft-holder':
        return `- Own NFTs on Base`
      case 'farcaster-follower':
        return `- Follow on Farcaster`
      default:
        return `- ${c.description}`
    }
  }).join('\n')
  
  return `# Guild.xyz Configuration for ${allowlist.name}

## Requirements
${requirements}

## Settings
- Max Spots: ${allowlist.maxSpots || 'Unlimited'}
- Expires: ${allowlist.expiresAt ? new Date(allowlist.expiresAt).toLocaleString() : 'Never'}

## Integration
1. Create a Guild at guild.xyz
2. Add requirements above
3. Export member addresses
4. Import to allowlist

## Snapshot
Take snapshot at: ${allowlist.expiresAt ? new Date(allowlist.expiresAt).toLocaleDateString() : 'Launch time'}`
}

export function exportAllowlistCSV(allowlist: Allowlist): string {
  const header = 'Address,Added Date,Criteria Met\n'
  const rows = allowlist.addresses.map(addr => `${addr},${new Date().toISOString()},Yes`).join('\n')
  return header + rows
}

export function exportAllowlistJSON(allowlist: Allowlist): string {
  return JSON.stringify(
    {
      name: allowlist.name,
      dropId: allowlist.dropId,
      maxSpots: allowlist.maxSpots,
      expiresAt: allowlist.expiresAt,
      addresses: allowlist.addresses,
      criteria: allowlist.criteria,
      generatedAt: new Date().toISOString()
    },
    null,
    2
  )
}

export function validateAddress(address: string): boolean {
  // Basic Ethereum address validation
  return /^0x[a-fA-F0-9]{40}$/.test(address)
}

export function importAddressesFromText(text: string): string[] {
  const lines = text.split('\n')
  const addresses: string[] = []
  
  lines.forEach(line => {
    const trimmed = line.trim()
    // Extract anything that looks like an address
    const matches = trimmed.match(/0x[a-fA-F0-9]{40}/g)
    if (matches) {
      matches.forEach(addr => {
        if (validateAddress(addr) && !addresses.includes(addr)) {
          addresses.push(addr)
        }
      })
    }
  })
  
  return addresses
}

export function generateMerkleTree(addresses: string[]): {
  root: string
  proofs: Record<string, string[]>
} {
  // Simplified merkle tree (in production, use proper library)
  // This is a placeholder implementation
  
  const root = `0x${Array.from({ length: 64 }, () => 
    Math.floor(Math.random() * 16).toString(16)
  ).join('')}`
  
  const proofs: Record<string, string[]> = {}
  addresses.forEach(addr => {
    proofs[addr] = [
      `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`
    ]
  })
  
  return { root, proofs }
}
