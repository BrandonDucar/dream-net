// Multi-Drop Campaign Planner

import type { Drop, CultureRef } from '@/types/drop-architect'
import type { DropCampaign } from '@/types/drop-architect-extended'

export function createCampaign(
  name: string,
  description: string,
  drops: Drop[],
  cultureRefs: CultureRef[]
): DropCampaign {
  const startDate = findEarliestDate(drops)
  const endDate = findLatestDate(drops)
  const narrative = generateCampaignNarrative(drops, cultureRefs)
  const goals = generateCampaignGoals(drops)
  
  return {
    id: `campaign-${Date.now()}`,
    name,
    description,
    startDate: startDate.toISOString(),
    endDate: endDate.toISOString(),
    dropIds: drops.map(d => d.id),
    narrative,
    goals,
    status: 'planning'
  }
}

function findEarliestDate(drops: Drop[]): Date {
  const dates = drops
    .map(d => d.launchWindowStart)
    .filter(Boolean)
    .map(d => new Date(d as string))
  
  if (dates.length === 0) return new Date()
  return new Date(Math.min(...dates.map(d => d.getTime())))
}

function findLatestDate(drops: Drop[]): Date {
  const dates = drops
    .map(d => d.launchWindowEnd || d.launchWindowStart)
    .filter(Boolean)
    .map(d => new Date(d as string))
  
  if (dates.length === 0) {
    const future = new Date()
    future.setDate(future.getDate() + 30)
    return future
  }
  
  const latest = new Date(Math.max(...dates.map(d => d.getTime())))
  latest.setDate(latest.getDate() + 7) // Add buffer
  return latest
}

function generateCampaignNarrative(drops: Drop[], cultureRefs: CultureRef[]): string {
  const themes = [...new Set(cultureRefs.map(c => c.theme))]
  const archetypes = [...new Set(cultureRefs.map(c => c.archetype))]
  
  return `This ${drops.length}-drop campaign explores ${themes.join(', ')} through the lens of ${archetypes.join(', ')} archetypes. Each drop builds on the previous, creating a cohesive narrative arc across the Base ecosystem.`
}

function generateCampaignGoals(drops: Drop[]): string[] {
  const goals: string[] = []
  
  const totalEditions = drops.reduce((sum, d) => sum + (d.editionSize || 0), 0)
  const totalETH = drops.reduce((sum, d) => sum + ((d.editionSize || 100) * (d.priceETH || 0)), 0)
  
  goals.push(`Mint ${totalEditions > 0 ? totalEditions : 'all'} editions across ${drops.length} drops`)
  if (totalETH > 0) goals.push(`Generate ${totalETH.toFixed(2)} ETH in primary sales`)
  goals.push(`Build community across Farcaster, X, and Base`)
  goals.push(`Establish presence in Base culture ecosystem`)
  goals.push(`Create sustained engagement over campaign period`)
  
  return goals
}

export function getCampaignTimeline(campaign: DropCampaign, drops: Drop[]): {
  date: Date
  dropId: string
  dropName: string
  event: string
}[] {
  const timeline: ReturnType<typeof getCampaignTimeline> = []
  
  const campaignDrops = drops.filter(d => campaign.dropIds.includes(d.id))
  
  campaignDrops.forEach(drop => {
    if (drop.launchWindowStart) {
      timeline.push({
        date: new Date(drop.launchWindowStart),
        dropId: drop.id,
        dropName: drop.name,
        event: 'Launch'
      })
    }
    
    if (drop.launchWindowEnd) {
      timeline.push({
        date: new Date(drop.launchWindowEnd),
        dropId: drop.id,
        dropName: drop.name,
        event: 'End'
      })
    }
  })
  
  return timeline.sort((a, b) => a.date.getTime() - b.date.getTime())
}

export function analyzeCampaignPacing(
  campaign: DropCampaign,
  drops: Drop[]
): {
  pace: 'fast' | 'balanced' | 'slow'
  averageDaysBetweenDrops: number
  recommendations: string[]
} {
  const campaignDrops = drops
    .filter(d => campaign.dropIds.includes(d.id))
    .sort((a, b) => {
      const aDate = a.launchWindowStart ? new Date(a.launchWindowStart).getTime() : 0
      const bDate = b.launchWindowStart ? new Date(b.launchWindowStart).getTime() : 0
      return aDate - bDate
    })
  
  if (campaignDrops.length < 2) {
    return {
      pace: 'balanced',
      averageDaysBetweenDrops: 0,
      recommendations: ['Add more drops to create a campaign sequence']
    }
  }
  
  // Calculate gaps between drops
  const gaps: number[] = []
  for (let i = 1; i < campaignDrops.length; i++) {
    const prev = campaignDrops[i - 1]
    const curr = campaignDrops[i]
    
    if (prev.launchWindowStart && curr.launchWindowStart) {
      const prevDate = new Date(prev.launchWindowStart)
      const currDate = new Date(curr.launchWindowStart)
      const daysDiff = (currDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24)
      gaps.push(daysDiff)
    }
  }
  
  const avgGap = gaps.reduce((sum, gap) => sum + gap, 0) / gaps.length
  
  let pace: 'fast' | 'balanced' | 'slow' = 'balanced'
  const recommendations: string[] = []
  
  if (avgGap < 5) {
    pace = 'fast'
    recommendations.push('Fast-paced campaign may overwhelm audience')
    recommendations.push('Consider spreading drops out for sustained engagement')
    recommendations.push('Ensure adequate marketing time between drops')
  } else if (avgGap > 14) {
    pace = 'slow'
    recommendations.push('Long gaps between drops may lose momentum')
    recommendations.push('Consider adding interim content or smaller drops')
    recommendations.push('Maintain community engagement between major drops')
  } else {
    pace = 'balanced'
    recommendations.push('Well-paced campaign with good breathing room')
    recommendations.push('Maintain consistent communication throughout')
  }
  
  return {
    pace,
    averageDaysBetweenDrops: Math.round(avgGap),
    recommendations
  }
}

export function generateCampaignBrief(
  campaign: DropCampaign,
  drops: Drop[],
  cultureRefs: CultureRef[]
): string {
  const campaignDrops = drops.filter(d => campaign.dropIds.includes(d.id))
  const timeline = getCampaignTimeline(campaign, drops)
  const pacing = analyzeCampaignPacing(campaign, drops)
  
  const dropSummaries = campaignDrops.map((drop, i) => {
    const cultureRef = cultureRefs.find(c => c.id === drop.cultureRefId)
    return `${i + 1}. ${drop.name}
   - Type: ${drop.dropType}
   - Price: ${drop.freeMint ? 'FREE' : `${drop.priceETH} ETH`}
   - Edition: ${drop.editionSize || 'Open'}
   - Culture: ${cultureRef?.name || 'Unknown'}
   - Timing: ${drop.launchTiming}`
  }).join('\n\n')
  
  return `
═══════════════════════════════════════════════
  DREAMNET DROP ARCHITECT - CAMPAIGN BRIEF
═══════════════════════════════════════════════

CAMPAIGN: ${campaign.name}
────────────────────────────────────────────────
${campaign.description}

TIMELINE
────────────────────────────────────────────────
Start: ${new Date(campaign.startDate).toLocaleDateString()}
End: ${new Date(campaign.endDate).toLocaleDateString()}
Duration: ${Math.ceil((new Date(campaign.endDate).getTime() - new Date(campaign.startDate).getTime()) / (1000 * 60 * 60 * 24))} days
Pace: ${pacing.pace.toUpperCase()} (${pacing.averageDaysBetweenDrops} days between drops)

NARRATIVE ARC
────────────────────────────────────────────────
${campaign.narrative}

GOALS
────────────────────────────────────────────────
${campaign.goals.map((g, i) => `${i + 1}. ${g}`).join('\n')}

DROPS (${campaignDrops.length})
────────────────────────────────────────────────
${dropSummaries}

TIMELINE EVENTS
────────────────────────────────────────────────
${timeline.map(t => `${t.date.toLocaleDateString()} - ${t.dropName}: ${t.event}`).join('\n')}

PACING RECOMMENDATIONS
────────────────────────────────────────────────
${pacing.recommendations.map((r, i) => `${i + 1}. ${r}`).join('\n')}

STATUS: ${campaign.status.toUpperCase()}

═══════════════════════════════════════════════
  Ready to Launch Campaign! 🚀
═══════════════════════════════════════════════
`.trim()
}
