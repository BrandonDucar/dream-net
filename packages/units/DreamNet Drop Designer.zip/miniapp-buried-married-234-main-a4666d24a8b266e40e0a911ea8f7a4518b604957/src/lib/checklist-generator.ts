// Launch Checklist Generator

import type { Drop, CultureRef } from '@/types/drop-architect'
import type { LaunchChecklist } from '@/types/drop-architect-extended'

export function generateLaunchChecklist(drop: Drop, cultureRef: CultureRef): LaunchChecklist {
  const items: LaunchChecklist['items'] = []
  
  // Calculate dates relative to launch
  const launchDate = drop.launchWindowStart ? new Date(drop.launchWindowStart) : new Date()
  
  // PRE-LAUNCH (2 weeks to 1 day before)
  const twoWeeksBefore = new Date(launchDate)
  twoWeeksBefore.setDate(twoWeeksBefore.getDate() - 14)
  
  const oneWeekBefore = new Date(launchDate)
  oneWeekBefore.setDate(oneWeekBefore.getDate() - 7)
  
  const threeDaysBefore = new Date(launchDate)
  threeDaysBefore.setDate(threeDaysBefore.getDate() - 3)
  
  const twoDaysBefore = new Date(launchDate)
  twoDaysBefore.setDate(twoDaysBefore.getDate() - 2)
  
  const oneDayBefore = new Date(launchDate)
  oneDayBefore.setDate(oneDayBefore.getDate() - 1)
  
  // Pre-launch items
  items.push({
    id: 'pre-1',
    category: 'pre-launch',
    task: 'Create artwork based on media prompts',
    completed: false,
    dueDate: twoWeeksBefore.toISOString(),
    notes: `Visual direction: ${drop.visualDirection.substring(0, 100)}`
  })
  
  items.push({
    id: 'pre-2',
    category: 'pre-launch',
    task: 'Set up Zora contract and upload metadata',
    completed: false,
    dueDate: oneWeekBefore.toISOString(),
    notes: `Edition size: ${drop.editionSize || 'Open'}, Price: ${drop.priceETH || 0} ETH`
  })
  
  items.push({
    id: 'pre-3',
    category: 'pre-launch',
    task: 'Test mint contract on testnet',
    completed: false,
    dueDate: oneWeekBefore.toISOString(),
    notes: 'Verify pricing, edition size, and royalties'
  })
  
  if (drop.allowlistNotes) {
    items.push({
      id: 'pre-4',
      category: 'pre-launch',
      task: 'Set up allowlist and verify addresses',
      completed: false,
      dueDate: oneWeekBefore.toISOString(),
      notes: drop.allowlistNotes
    })
  }
  
  items.push({
    id: 'pre-5',
    category: 'pre-launch',
    task: 'Create Farcaster frame',
    completed: false,
    dueDate: threeDaysBefore.toISOString(),
    notes: 'Generate frame code and test in Warpcast'
  })
  
  items.push({
    id: 'pre-6',
    category: 'pre-launch',
    task: 'Prepare social media content',
    completed: false,
    dueDate: threeDaysBefore.toISOString(),
    notes: 'X thread, Farcaster posts, Discord announcement'
  })
  
  drop.preLaunchIdeas.forEach((idea, i) => {
    items.push({
      id: `pre-idea-${i}`,
      category: 'pre-launch',
      task: idea,
      completed: false,
      dueDate: twoDaysBefore.toISOString(),
      notes: 'Pre-launch marketing'
    })
  })
  
  items.push({
    id: 'pre-7',
    category: 'pre-launch',
    task: 'Post teaser on Farcaster',
    completed: false,
    dueDate: twoDaysBefore.toISOString(),
    notes: `"${cultureRef.primaryEmoji} Something's brewing..."`
  })
  
  items.push({
    id: 'pre-8',
    category: 'pre-launch',
    task: 'Final contract verification',
    completed: false,
    dueDate: oneDayBefore.toISOString(),
    notes: 'Double-check all parameters on mainnet'
  })
  
  items.push({
    id: 'pre-9',
    category: 'pre-launch',
    task: 'Schedule launch announcement posts',
    completed: false,
    dueDate: oneDayBefore.toISOString(),
    notes: 'Prepare for simultaneous cross-platform posting'
  })
  
  // LAUNCH DAY
  const launchMorning = new Date(launchDate)
  launchMorning.setHours(8, 0, 0, 0)
  
  items.push({
    id: 'launch-1',
    category: 'launch-day',
    task: 'Activate mint contract',
    completed: false,
    dueDate: launchDate.toISOString(),
    notes: 'Make contract live at scheduled time'
  })
  
  items.push({
    id: 'launch-2',
    category: 'launch-day',
    task: 'Post launch announcement on X',
    completed: false,
    dueDate: launchDate.toISOString(),
    notes: 'Thread with all drop details'
  })
  
  items.push({
    id: 'launch-3',
    category: 'launch-day',
    task: 'Share frame on Farcaster',
    completed: false,
    dueDate: launchDate.toISOString(),
    notes: 'Post in relevant channels and tag communities'
  })
  
  items.push({
    id: 'launch-4',
    category: 'launch-day',
    task: 'Announce in Discord',
    completed: false,
    dueDate: launchDate.toISOString(),
    notes: '@everyone announcement with all details'
  })
  
  items.push({
    id: 'launch-5',
    category: 'launch-day',
    task: 'Monitor first hour of minting',
    completed: false,
    dueDate: launchDate.toISOString(),
    notes: 'Watch for issues, engage with early minters'
  })
  
  items.push({
    id: 'launch-6',
    category: 'launch-day',
    task: 'Post 25% milestone update',
    completed: false,
    dueDate: launchDate.toISOString(),
    notes: 'Share progress and thank collectors'
  })
  
  items.push({
    id: 'launch-7',
    category: 'launch-day',
    task: 'Post 50% milestone update',
    completed: false,
    dueDate: launchDate.toISOString(),
    notes: 'Momentum update with collector count'
  })
  
  items.push({
    id: 'launch-8',
    category: 'launch-day',
    task: 'Post 75% milestone update',
    completed: false,
    dueDate: launchDate.toISOString(),
    notes: 'Final push - nearly sold out!'
  })
  
  // POST-LAUNCH (1 day to 1 week after)
  const oneDayAfter = new Date(launchDate)
  oneDayAfter.setDate(oneDayAfter.getDate() + 1)
  
  const threeDaysAfter = new Date(launchDate)
  threeDaysAfter.setDate(threeDaysAfter.getDate() + 3)
  
  const oneWeekAfter = new Date(launchDate)
  oneWeekAfter.setDate(oneWeekAfter.getDate() + 7)
  
  items.push({
    id: 'post-1',
    category: 'post-launch',
    task: 'Post final stats and thank you',
    completed: false,
    dueDate: oneDayAfter.toISOString(),
    notes: 'Total minted, unique collectors, volume'
  })
  
  drop.postLaunchFollowUps.forEach((followUp, i) => {
    items.push({
      id: `post-idea-${i}`,
      category: 'post-launch',
      task: followUp,
      completed: false,
      dueDate: threeDaysAfter.toISOString(),
      notes: 'Post-launch engagement'
    })
  })
  
  items.push({
    id: 'post-2',
    category: 'post-launch',
    task: 'Collector spotlight posts',
    completed: false,
    dueDate: threeDaysAfter.toISOString(),
    notes: 'Feature early supporters and collectors'
  })
  
  items.push({
    id: 'post-3',
    category: 'post-launch',
    task: 'Share learnings and metrics',
    completed: false,
    dueDate: oneWeekAfter.toISOString(),
    notes: 'What worked, what to improve for next drop'
  })
  
  items.push({
    id: 'post-4',
    category: 'post-launch',
    task: 'Set up holder benefits/channel',
    completed: false,
    dueDate: oneWeekAfter.toISOString(),
    notes: 'Exclusive access for minters'
  })
  
  return {
    dropId: drop.id,
    items: items.sort((a, b) => {
      if (!a.dueDate || !b.dueDate) return 0
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
    })
  }
}

export function getChecklistProgress(checklist: LaunchChecklist): {
  total: number
  completed: number
  percentage: number
  byCategory: Record<string, { total: number; completed: number }>
} {
  const total = checklist.items.length
  const completed = checklist.items.filter(item => item.completed).length
  const percentage = total > 0 ? Math.round((completed / total) * 100) : 0
  
  const byCategory: Record<string, { total: number; completed: number }> = {
    'pre-launch': { total: 0, completed: 0 },
    'launch-day': { total: 0, completed: 0 },
    'post-launch': { total: 0, completed: 0 }
  }
  
  checklist.items.forEach(item => {
    byCategory[item.category].total++
    if (item.completed) byCategory[item.category].completed++
  })
  
  return { total, completed, percentage, byCategory }
}
