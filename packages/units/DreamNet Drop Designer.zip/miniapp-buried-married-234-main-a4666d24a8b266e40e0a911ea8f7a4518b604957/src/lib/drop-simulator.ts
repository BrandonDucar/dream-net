// Drop Simulator - Virtual Launch Experience

import type { Drop, CultureRef } from '@/types/drop-architect'
import type { SimulationResult } from '@/types/drop-architect-extended'

export function simulateDropLaunch(drop: Drop, cultureRef: CultureRef): SimulationResult {
  const editionSize = drop.editionSize || 1000 // for open editions
  const velocity = determineVelocity(drop)
  const timeline = generateTimeline(drop, editionSize, velocity)
  const outcomes = generateOutcomes(drop, editionSize, velocity)
  const recommendations = generateRecommendations(drop, velocity)
  const warnings = generateWarnings(drop, timeline)
  
  return {
    dropId: drop.id,
    timeline,
    outcomes,
    recommendations,
    warnings
  }
}

function determineVelocity(drop: Drop): 'fast' | 'medium' | 'slow' {
  // Calculate velocity multiplier
  let velocityScore = 50
  
  if (drop.freeMint) velocityScore += 30
  if (drop.priceETH && drop.priceETH <= 0.003) velocityScore += 20
  if (drop.priceETH && drop.priceETH > 0.01) velocityScore -= 20
  if (drop.editionSize && drop.editionSize <= 25) velocityScore += 15
  if (drop.dropType === 'open edition') velocityScore += 10
  
  if (velocityScore >= 80) return 'fast'
  if (velocityScore >= 50) return 'medium'
  return 'slow'
}

function generateTimeline(
  drop: Drop,
  editionSize: number,
  velocity: 'fast' | 'medium' | 'slow'
): SimulationResult['timeline'] {
  const timeline: SimulationResult['timeline'] = []
  
  // Velocity curves
  const curves = {
    fast: [15, 35, 55, 70, 82, 90, 95, 98, 99, 100],
    medium: [5, 12, 20, 30, 42, 55, 68, 80, 90, 100],
    slow: [2, 5, 10, 18, 28, 40, 55, 70, 85, 100]
  }
  
  const curve = curves[velocity]
  const hours = velocity === 'fast' ? 10 : velocity === 'medium' ? 24 : 48
  const interval = hours / 10
  
  for (let i = 0; i < 10; i++) {
    const hour = Math.round(i * interval)
    const percentMinted = curve[i]
    const totalMinted = Math.round((percentMinted / 100) * editionSize)
    const uniqueCollectors = Math.round(totalMinted * 0.75) // assume 75% unique
    
    const events: string[] = []
    const trending = percentMinted >= 20 && percentMinted <= 80
    
    if (i === 0) events.push('Drop goes live')
    if (percentMinted >= 25 && curve[i - 1] < 25) events.push('25% minted')
    if (percentMinted >= 50 && curve[i - 1] < 50) events.push('Halfway sold')
    if (percentMinted >= 75 && curve[i - 1] < 75) events.push('75% minted')
    if (percentMinted >= 90 && curve[i - 1] < 90) events.push('Nearly sold out')
    if (percentMinted === 100) events.push('SOLD OUT! 🎉')
    
    if (trending && i % 2 === 0) events.push('Trending on Farcaster')
    if (i === 1) events.push('Early collectors share on X')
    if (i === 5) events.push('Community engagement peaks')
    
    timeline.push({
      hour,
      percentMinted,
      totalMinted,
      uniqueCollectors,
      trending,
      events
    })
  }
  
  return timeline
}

function generateOutcomes(
  drop: Drop,
  editionSize: number,
  velocity: 'fast' | 'medium' | 'slow'
): SimulationResult['outcomes'] {
  const priceETH = drop.priceETH || 0.005
  
  const selloutTimes = {
    fast: { best: '2 hours', likely: '4 hours', worst: '8 hours' },
    medium: { best: '12 hours', likely: '24 hours', worst: '3 days' },
    slow: { best: '2 days', likely: '5 days', worst: '2 weeks' }
  }
  
  const times = selloutTimes[velocity]
  
  const bestCase = {
    selloutTime: times.best,
    totalVolume: editionSize * priceETH * 1.2, // 20% bonus from momentum
    collectorCount: Math.round(editionSize * 0.85) // high unique collectors
  }
  
  const likelyCase = {
    selloutTime: times.likely,
    totalVolume: editionSize * priceETH,
    collectorCount: Math.round(editionSize * 0.75)
  }
  
  const worstCase = {
    selloutTime: times.worst,
    totalVolume: editionSize * priceETH * 0.8, // might not fully sell out
    collectorCount: Math.round(editionSize * 0.65)
  }
  
  return { bestCase, likelyCase, worstCase }
}

function generateRecommendations(
  drop: Drop,
  velocity: 'fast' | 'medium' | 'slow'
): string[] {
  const recommendations: string[] = []
  
  if (velocity === 'fast') {
    recommendations.push('Prepare for high traffic - test mint contract beforehand')
    recommendations.push('Have community moderation ready for influx')
    recommendations.push('Consider raising edition size if demand exceeds supply')
    recommendations.push('Capture screenshots at 25%, 50%, 75% for social proof')
  } else if (velocity === 'medium') {
    recommendations.push('Plan sustained marketing throughout mint period')
    recommendations.push('Post milestone updates every 25%')
    recommendations.push('Engage with early minters to build momentum')
    recommendations.push('Share collector spotlights during mint')
  } else {
    recommendations.push('Consider lowering price or edition size')
    recommendations.push('Amplify pre-launch marketing')
    recommendations.push('Add utility or perks for holders')
    recommendations.push('Engage allowlist for initial momentum')
  }
  
  recommendations.push('Monitor Farcaster frames for engagement')
  recommendations.push('Be active in drop channels during launch')
  
  return recommendations
}

function generateWarnings(drop: Drop, timeline: SimulationResult['timeline']): string[] {
  const warnings: string[] = []
  
  const finalHour = timeline[timeline.length - 1].hour
  
  if (finalHour > 72) {
    warnings.push('⚠️ Projected sellout time exceeds 3 days - consider adjusting strategy')
  }
  
  if (drop.editionSize && drop.editionSize > 200 && drop.priceETH && drop.priceETH > 0.01) {
    warnings.push('⚠️ Large edition + high price may limit demand')
  }
  
  if (!drop.preLaunchIdeas || drop.preLaunchIdeas.length < 2) {
    warnings.push('⚠️ Limited pre-launch marketing may reduce initial momentum')
  }
  
  if (!drop.launchWindowStart) {
    warnings.push('⚠️ No launch timing set - schedule for optimal visibility')
  }
  
  if (drop.freeMint && drop.editionSize && drop.editionSize < 50) {
    warnings.push('⚠️ Free mint with small edition may sell out instantly')
  }
  
  return warnings
}

export function compareToSimulation(
  simulationResult: SimulationResult,
  actualPercentMinted: number,
  actualHoursElapsed: number
): {
  status: 'ahead' | 'on-track' | 'behind'
  difference: number
  message: string
} {
  // Find closest timeline entry
  const closest = simulationResult.timeline.reduce((prev, curr) => {
    return Math.abs(curr.hour - actualHoursElapsed) < Math.abs(prev.hour - actualHoursElapsed)
      ? curr
      : prev
  })
  
  const expectedPercent = closest.percentMinted
  const difference = actualPercentMinted - expectedPercent
  
  let status: 'ahead' | 'on-track' | 'behind' = 'on-track'
  let message = 'Tracking as expected'
  
  if (difference > 10) {
    status = 'ahead'
    message = `🚀 Ahead of projection! ${difference.toFixed(0)}% above expected`
  } else if (difference < -10) {
    status = 'behind'
    message = `⚠️ Behind projection by ${Math.abs(difference).toFixed(0)}%`
  }
  
  return { status, difference, message }
}
