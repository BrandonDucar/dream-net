// Export Formats for Multiple Platforms

import type { Drop, CultureRef } from '@/types/drop-architect'
import type { ExportFormat } from '@/types/drop-architect-extended'

export function exportToZoraJSON(drop: Drop, cultureRef: CultureRef): ExportFormat {
  const metadata = {
    name: drop.name,
    description: drop.conceptSummary,
    image: '', // To be filled with actual image URL
    attributes: [
      { trait_type: 'Culture', value: cultureRef.name },
      { trait_type: 'Ticker', value: cultureRef.ticker },
      { trait_type: 'Theme', value: cultureRef.theme },
      { trait_type: 'Archetype', value: cultureRef.archetype },
      { trait_type: 'Drop Type', value: drop.dropType },
      { trait_type: 'Chain', value: drop.chain }
    ],
    external_url: '',
    animation_url: drop.mediaType === 'video' ? '' : undefined
  }

  const zoraConfig = {
    metadata,
    salesConfig: {
      publicSalePrice: drop.priceETH ? (drop.priceETH * 1e18).toString() : '0',
      maxSalePurchasePerAddress: drop.dropType === '1/1' ? 1 : 10,
      publicSaleStart: drop.launchWindowStart ? new Date(drop.launchWindowStart).getTime() / 1000 : 0,
      publicSaleEnd: drop.launchWindowEnd ? new Date(drop.launchWindowEnd).getTime() / 1000 : 0
    },
    editionSize: drop.editionSize,
    royaltyBPS: (drop.royaltyPercent || 0) * 100
  }

  return {
    format: 'zora-json',
    content: JSON.stringify(zoraConfig, null, 2),
    metadata: zoraConfig
  }
}

export function exportToFarcasterPost(drop: Drop, cultureRef: CultureRef): ExportFormat {
  const price = drop.freeMint ? '🆓 Free Mint' : `💰 ${drop.priceETH} ETH`
  const edition = drop.editionSize === null ? '∞ Open Edition' : `${drop.editionSize} editions`
  const emoji = cultureRef.primaryEmoji

  const content = `${emoji} ${drop.name}

${drop.conceptSummary}

${price} • ${edition}
⛓️ ${drop.chain} • ${drop.platform}

${drop.loreSnippet.substring(0, 100)}...

${drop.seoHashtags.slice(0, 5).join(' ')}

🔗 [Mint link here]`

  return {
    format: 'farcaster-post',
    content
  }
}

export function exportToXThread(drop: Drop, cultureRef: CultureRef): ExportFormat {
  const tweets: string[] = []

  // Tweet 1: Announcement
  tweets.push(
    `${cultureRef.primaryEmoji} Introducing ${drop.name}

${drop.conceptSummary.substring(0, 200)}

${drop.seoHashtags.slice(0, 3).join(' ')}`
  )

  // Tweet 2: Details
  const price = drop.freeMint ? 'FREE' : `${drop.priceETH} ETH`
  const edition = drop.editionSize === null ? 'Open Edition' : `${drop.editionSize} editions`
  tweets.push(
    `📊 Drop Details:

💰 Price: ${price}
📈 Edition: ${edition}
⛓️ Chain: ${drop.chain}
🏪 Platform: ${drop.platform}
👑 Royalty: ${drop.royaltyPercent}%

${drop.launchTiming}`
  )

  // Tweet 3: Lore
  tweets.push(
    `📖 The Story:

${drop.loreSnippet}

$${cultureRef.ticker} ${cultureRef.primaryEmoji}`
  )

  // Tweet 4: Visual Direction
  tweets.push(
    `🎨 Visual Direction:

${drop.visualDirection}

${drop.mediaType === 'video' ? '🎥' : '🖼️'} ${drop.mediaType.toUpperCase()}`
  )

  // Tweet 5: Target Audience
  tweets.push(
    `👥 This is for:

${drop.targetAudienceNotes}

Ready to join? Link below 👇`
  )

  // Tweet 6: CTA
  tweets.push(
    `✨ Mint ${drop.name}

[Mint link]

${drop.seoHashtags.join(' ')}`
  )

  const numbered = tweets.map((t, i) => `${i + 1}/${tweets.length}

${t}`).join('\n\n---\n\n')

  return {
    format: 'x-thread',
    content: numbered
  }
}

export function exportToDiscord(drop: Drop, cultureRef: CultureRef): ExportFormat {
  const price = drop.freeMint ? '🆓 FREE MINT' : `💰 ${drop.priceETH} ETH`
  const edition = drop.editionSize === null ? '∞ Open Edition' : `📊 ${drop.editionSize} editions`

  const content = `@everyone

${cultureRef.primaryEmoji} **${drop.name}** is live!

**About:**
${drop.conceptSummary}

**Drop Details:**
${price}
${edition}
⛓️ Chain: ${drop.chain}
🏪 Platform: ${drop.platform}
👑 Royalty: ${drop.royaltyPercent}%

**Launch:**
${drop.launchTiming}

**The Story:**
${drop.loreSnippet}

**Who This Is For:**
${drop.targetAudienceNotes}

**Mint here:** [Link]

${drop.seoHashtags.slice(0, 5).join(' ')}

---
*Powered by DreamNet Drop Architect*`

  return {
    format: 'discord',
    content
  }
}

export function exportToMirrorBlog(drop: Drop, cultureRef: CultureRef): ExportFormat {
  const price = drop.freeMint ? 'free' : `${drop.priceETH} ETH`
  const edition = drop.editionSize === null ? 'open edition' : `limited to ${drop.editionSize} editions`

  const content = `# ${cultureRef.primaryEmoji} ${drop.name}

## ${drop.conceptSummary}

---

### The Story

${drop.loreSnippet}

### What We're Creating

This ${drop.dropType} is ${edition}, minting for ${price} on ${drop.chain} via ${drop.platform}.

**Visual Direction:**
${drop.visualDirection}

We're creating ${drop.mediaType} content that captures:
${drop.mediaPrompts.map(p => `- ${p}`).join('\n')}

---

### Who This Is For

${drop.targetAudienceNotes}

If you're part of the $${cultureRef.ticker} community or aligned with ${cultureRef.theme} and the ${cultureRef.archetype} archetype, this drop is for you.

---

### Launch Strategy

**Timing:** ${drop.launchTiming}

**Pre-Launch:**
${drop.preLaunchIdeas.map((idea, i) => `${i + 1}. ${idea}`).join('\n')}

**Post-Launch:**
${drop.postLaunchFollowUps.map((idea, i) => `${i + 1}. ${idea}`).join('\n')}

**Channels:**
We'll be activating across: ${drop.supportingChannels.join(', ')}

---

### Economics

- **Price:** ${price}
- **Edition Size:** ${drop.editionSize === null ? 'Open Edition' : drop.editionSize}
- **Royalty:** ${drop.royaltyPercent}%
- **Allowlist:** ${drop.allowlistNotes || 'Public mint'}

---

### Mint

Ready to collect? [Mint ${drop.name} here](#)

${drop.seoHashtags.join(' ')}

---

*This drop was designed with DreamNet Drop Architect*`

  return {
    format: 'mirror-blog',
    content
  }
}

export function exportAllFormats(drop: Drop, cultureRef: CultureRef): ExportFormat[] {
  return [
    exportToZoraJSON(drop, cultureRef),
    exportToFarcasterPost(drop, cultureRef),
    exportToXThread(drop, cultureRef),
    exportToDiscord(drop, cultureRef),
    exportToMirrorBlog(drop, cultureRef)
  ]
}
