// Farcaster Frame Generator

import type { Drop, CultureRef } from '@/types/drop-architect'
import type { FarcasterFrame } from '@/types/drop-architect-extended'

export function generateFarcasterFrame(
  drop: Drop,
  cultureRef: CultureRef,
  imageUrl?: string
): FarcasterFrame {
  const deployUrl = `https://zora.co/collect/base:${drop.id}` // placeholder
  
  const frameCode = generateFrameCode(drop, cultureRef, imageUrl, deployUrl)
  
  return {
    dropId: drop.id,
    frameUrl: `${window.location.origin}/frames/${drop.id}`,
    frameCode,
    imageUrl: imageUrl || '',
    buttons: [
      {
        label: drop.freeMint ? 'Mint Free' : `Mint ${drop.priceETH} ETH`,
        action: 'link',
        target: deployUrl
      },
      {
        label: 'Share',
        action: 'post'
      }
    ],
    metadata: {
      title: drop.name,
      description: drop.conceptSummary.substring(0, 200),
      image: imageUrl || ''
    }
  }
}

function generateFrameCode(
  drop: Drop,
  cultureRef: CultureRef,
  imageUrl: string | undefined,
  mintUrl: string
): string {
  const price = drop.freeMint ? 'FREE' : `${drop.priceETH} ETH`
  const edition = drop.editionSize === null ? 'Open Edition' : `${drop.editionSize} editions`
  
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${drop.name}</title>
  
  <!-- Farcaster Frame Meta Tags -->
  <meta property="fc:frame" content="vNext" />
  <meta property="fc:frame:image" content="${imageUrl || 'https://placeholder.com/800x600'}" />
  <meta property="fc:frame:image:aspect_ratio" content="1.91:1" />
  
  <!-- Frame Buttons -->
  <meta property="fc:frame:button:1" content="${drop.freeMint ? '🆓 Mint Free' : `✨ Mint ${drop.priceETH} ETH`}" />
  <meta property="fc:frame:button:1:action" content="link" />
  <meta property="fc:frame:button:1:target" content="${mintUrl}" />
  
  <meta property="fc:frame:button:2" content="📊 Details" />
  <meta property="fc:frame:button:2:action" content="link" />
  <meta property="fc:frame:button:2:target" content="${window.location.origin}/drops/${drop.id}" />
  
  <meta property="fc:frame:button:3" content="🔄 Share" />
  <meta property="fc:frame:button:3:action" content="post" />
  
  <!-- Open Graph -->
  <meta property="og:title" content="${drop.name}" />
  <meta property="og:description" content="${drop.conceptSummary.substring(0, 200)}" />
  <meta property="og:image" content="${imageUrl || 'https://placeholder.com/800x600'}" />
  
  <!-- Twitter -->
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="${drop.name}" />
  <meta name="twitter:description" content="${drop.conceptSummary.substring(0, 200)}" />
  <meta name="twitter:image" content="${imageUrl || 'https://placeholder.com/800x600'}" />
</head>
<body style="margin: 0; padding: 20px; font-family: system-ui, sans-serif; background: #000; color: #fff;">
  <div style="max-width: 600px; margin: 0 auto;">
    <h1 style="font-size: 2em; margin-bottom: 0.5em;">
      ${cultureRef.primaryEmoji} ${drop.name}
    </h1>
    
    <div style="background: #111; border: 2px solid #333; border-radius: 12px; padding: 20px; margin-bottom: 20px;">
      ${imageUrl ? `<img src="${imageUrl}" alt="${drop.name}" style="width: 100%; border-radius: 8px; margin-bottom: 16px;" />` : ''}
      
      <p style="font-size: 1.1em; line-height: 1.6; color: #ccc;">
        ${drop.conceptSummary}
      </p>
    </div>
    
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px;">
      <div style="background: #111; border: 1px solid #333; border-radius: 8px; padding: 16px;">
        <div style="font-size: 0.9em; color: #888; margin-bottom: 4px;">Price</div>
        <div style="font-size: 1.3em; font-weight: bold;">${price}</div>
      </div>
      
      <div style="background: #111; border: 1px solid #333; border-radius: 8px; padding: 16px;">
        <div style="font-size: 0.9em; color: #888; margin-bottom: 4px;">Edition</div>
        <div style="font-size: 1.3em; font-weight: bold;">${edition}</div>
      </div>
    </div>
    
    <div style="background: #111; border: 1px solid #333; border-radius: 8px; padding: 16px; margin-bottom: 20px;">
      <div style="font-size: 0.9em; color: #888; margin-bottom: 8px;">About ${cultureRef.name}</div>
      <p style="margin: 0; color: #ccc; font-size: 0.95em;">
        ${drop.loreSnippet}
      </p>
    </div>
    
    <a href="${mintUrl}" 
       style="display: block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
              color: white; text-align: center; padding: 16px; border-radius: 8px; 
              text-decoration: none; font-weight: bold; font-size: 1.1em;">
      ${drop.freeMint ? '🆓 Mint Free on Zora' : `✨ Mint for ${drop.priceETH} ETH on Zora`}
    </a>
    
    <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #333; 
                text-align: center; font-size: 0.9em; color: #666;">
      <p>Built with DreamNet Drop Architect</p>
      <p style="margin-top: 8px;">
        Chain: ${drop.chain} • Platform: ${drop.platform}
      </p>
    </div>
  </div>
</body>
</html>`
}

export function generateFramePreview(
  drop: Drop,
  cultureRef: CultureRef,
  imageUrl?: string
): string {
  return `
┌─────────────────────────────────────┐
│                                     │
│  ${imageUrl ? '[IMAGE PREVIEW]' : '[NO IMAGE]'}                      │
│                                     │
├─────────────────────────────────────┤
│  ${cultureRef.primaryEmoji} ${drop.name.substring(0, 25)}${drop.name.length > 25 ? '...' : ''}  │
│                                     │
│  ${drop.conceptSummary.substring(0, 35)}...  │
│                                     │
│  💰 ${drop.freeMint ? 'FREE' : `${drop.priceETH} ETH`}  •  📊 ${drop.editionSize || 'Open'} eds  │
│                                     │
├─────────────────────────────────────┤
│ [${drop.freeMint ? 'Mint Free' : `Mint ${drop.priceETH} ETH`}] [Details] [Share] │
└─────────────────────────────────────┘
`
}

export function generateWarpcastPost(drop: Drop, cultureRef: CultureRef, frameUrl: string): string {
  return `${cultureRef.primaryEmoji} ${drop.name}

${drop.conceptSummary}

${drop.freeMint ? '🆓 Free Mint' : `💰 ${drop.priceETH} ETH`} • ${drop.editionSize === null ? '∞ Open Edition' : `${drop.editionSize} editions`}

${drop.seoHashtags.slice(0, 3).join(' ')}

Frame: ${frameUrl}`
}
