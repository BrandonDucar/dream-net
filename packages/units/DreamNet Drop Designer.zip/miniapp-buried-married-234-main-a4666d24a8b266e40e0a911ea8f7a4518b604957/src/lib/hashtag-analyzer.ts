// Hashtag Performance Analyzer

import type { HashtagAnalysis } from '@/types/drop-architect-extended'

// Simulated hashtag performance data (in production, would come from APIs)
const HASHTAG_DATA: Record<string, { activity: number; trend: 'up' | 'down' | 'stable' }> = {
  '#Base': { activity: 95, trend: 'up' },
  '#Zora': { activity: 88, trend: 'up' },
  '#OnChainCulture': { activity: 72, trend: 'up' },
  '#NFT': { activity: 98, trend: 'stable' },
  '#CryptoArt': { activity: 65, trend: 'down' },
  '#BuildOnBase': { activity: 85, trend: 'up' },
  '#BaseSummer': { activity: 45, trend: 'down' },
  '#Farcaster': { activity: 90, trend: 'up' },
  '#Web3': { activity: 92, trend: 'stable' },
  '#NFTCommunity': { activity: 88, trend: 'stable' },
  '#DigitalArt': { activity: 70, trend: 'stable' },
  '#Ethereum': { activity: 95, trend: 'up' },
  '#L2': { activity: 55, trend: 'up' },
  '#OnChain': { activity: 68, trend: 'up' },
  '#Mint': { activity: 75, trend: 'stable' }
}

export function analyzeHashtags(hashtags: string[]): HashtagAnalysis[] {
  return hashtags.map(tag => analyzeHashtag(tag))
}

export function analyzeHashtag(hashtag: string): HashtagAnalysis {
  const normalized = hashtag.startsWith('#') ? hashtag : `#${hashtag}`
  const data = HASHTAG_DATA[normalized] || { activity: 50, trend: 'stable' }
  
  let status: HashtagAnalysis['status'] = 'moderate'
  
  if (data.activity >= 90) {
    status = 'oversaturated'
  } else if (data.activity >= 70) {
    status = 'trending'
  } else if (data.activity >= 40 && data.trend === 'up') {
    status = 'emerging'
  }
  
  const alternatives = suggestAlternatives(normalized, data.activity)
  
  return {
    tag: normalized,
    status,
    baseActivity: data.activity,
    alternatives
  }
}

function suggestAlternatives(hashtag: string, currentActivity: number): string[] {
  const alternatives: Record<string, string[]> = {
    '#NFT': ['#OnChain', '#DigitalCollectibles', '#CryptoCollectibles'],
    '#CryptoArt': ['#OnChainArt', '#GenerativeArt', '#DigitalArt'],
    '#Base': ['#BuildOnBase', '#BaseChain', '#BaseEcosystem'],
    '#Zora': ['#ZoraNFT', '#MintOnZora', '#ZoraProtocol'],
    '#Web3': ['#OnChain', '#Decentralized', '#CryptoNative'],
    '#Ethereum': ['#ETH', '#EthereumNFTs', '#OnChain']
  }
  
  const alts = alternatives[hashtag] || []
  
  // If current tag is oversaturated, suggest lower-activity alternatives
  if (currentActivity >= 90) {
    return alts.length > 0 ? alts : ['Try more specific tags']
  }
  
  return alts
}

export function getRecommendedHashtags(
  theme: string,
  dropType: string,
  platform: string,
  chain: string
): string[] {
  const recommended: string[] = []
  
  // Always include platform and chain
  if (chain === 'Base') recommended.push('#Base', '#BuildOnBase')
  if (platform === 'Zora') recommended.push('#Zora')
  
  // Core tags
  recommended.push('#NFT', '#OnChain', '#Mint')
  
  // Theme-based
  const themeMap: Record<string, string[]> = {
    'culture': ['#OnChainCulture', '#CryptoCulture', '#BaseCulture'],
    'art': ['#CryptoArt', '#DigitalArt', '#OnChainArt'],
    'gaming': ['#GameFi', '#Web3Gaming', '#CryptoGaming'],
    'music': ['#MusicNFT', '#OnChainMusic', '#Web3Music'],
    'defi': ['#DeFi', '#Yield', '#Farming'],
    'social': ['#SocialFi', '#Web3Social', '#Farcaster']
  }
  
  const themeLower = theme.toLowerCase()
  for (const [key, tags] of Object.entries(themeMap)) {
    if (themeLower.includes(key)) {
      recommended.push(...tags.slice(0, 2))
    }
  }
  
  // Drop type specific
  if (dropType === 'open edition') recommended.push('#OpenEdition')
  if (dropType === '1/1') recommended.push('#OneOfOne')
  if (dropType === 'frame') recommended.push('#Frames', '#Farcaster')
  
  // Remove duplicates and limit
  return [...new Set(recommended)].slice(0, 10)
}

export function optimizeHashtagSet(
  currentTags: string[],
  maxTags: number = 10
): {
  optimized: string[]
  removed: string[]
  reasoning: string[]
} {
  const analyzed = analyzeHashtags(currentTags)
  const reasoning: string[] = []
  
  // Remove oversaturated tags
  const oversaturated = analyzed.filter(a => a.status === 'oversaturated')
  const toRemove = oversaturated.map(a => a.tag)
  
  if (toRemove.length > 0) {
    reasoning.push(`Removed oversaturated tags: ${toRemove.join(', ')}`)
  }
  
  // Keep trending and emerging
  let optimized = analyzed
    .filter(a => a.status !== 'oversaturated')
    .map(a => a.tag)
  
  // Add alternatives for removed tags
  oversaturated.forEach(ot => {
    if (ot.alternatives.length > 0 && optimized.length < maxTags) {
      const alt = ot.alternatives[0]
      optimized.push(alt)
      reasoning.push(`Replaced ${ot.tag} with ${alt}`)
    }
  })
  
  // Limit to maxTags
  if (optimized.length > maxTags) {
    const excess = optimized.slice(maxTags)
    optimized = optimized.slice(0, maxTags)
    reasoning.push(`Limited to ${maxTags} tags, removed: ${excess.join(', ')}`)
  }
  
  return {
    optimized,
    removed: toRemove,
    reasoning
  }
}
