// Smart Pricing Oracle

import type { Drop, CultureRef } from '@/types/drop-architect'
import type { PricingRecommendation, DropComp } from '@/types/drop-architect-extended'

// Curated database of successful Base/Zora drops
const SUCCESSFUL_DROPS: DropComp[] = [
  {
    id: 'comp-1',
    name: 'Base God Mode',
    platform: 'Zora',
    chain: 'Base',
    dropType: 'edition',
    editionSize: 100,
    priceETH: 0.005,
    mintedCount: 100,
    mintDuration: '3 hours',
    successRating: 5,
    theme: 'culture',
    notes: 'Sold out fast, strong Base community support'
  },
  {
    id: 'comp-2',
    name: 'Onchain Summer Vibes',
    platform: 'Zora',
    chain: 'Base',
    dropType: 'open edition',
    editionSize: null,
    priceETH: 0.001,
    mintedCount: 847,
    mintDuration: '24 hours',
    successRating: 5,
    theme: 'summer',
    notes: 'High volume, accessible pricing, viral on Farcaster'
  },
  {
    id: 'comp-3',
    name: 'Builder Genesis',
    platform: 'Zora',
    chain: 'Base',
    dropType: '1/1',
    editionSize: 1,
    priceETH: 0.5,
    mintedCount: 1,
    mintDuration: '1 hour',
    successRating: 4,
    theme: 'builder',
    notes: 'Premium 1/1, sold to serious collector'
  },
  {
    id: 'comp-4',
    name: 'Culture Coin Airdrop',
    platform: 'Zora',
    chain: 'Base',
    dropType: 'airdrop concept',
    editionSize: 500,
    priceETH: 0,
    mintedCount: 500,
    mintDuration: '6 hours',
    successRating: 5,
    theme: 'culture',
    notes: 'Free mint, community building, high engagement'
  },
  {
    id: 'comp-5',
    name: 'Based Frames Collection',
    platform: 'Zora',
    chain: 'Base',
    dropType: 'edition',
    editionSize: 50,
    priceETH: 0.01,
    mintedCount: 50,
    mintDuration: '12 hours',
    successRating: 4,
    theme: 'frames',
    notes: 'Medium edition, strong frame integration'
  },
  {
    id: 'comp-6',
    name: 'Crypto Art Movement',
    platform: 'Zora',
    chain: 'Base',
    dropType: 'edition',
    editionSize: 25,
    priceETH: 0.02,
    mintedCount: 25,
    mintDuration: '8 hours',
    successRating: 5,
    theme: 'art',
    notes: 'Premium pricing, exclusive, strong narrative'
  },
  {
    id: 'comp-7',
    name: 'Base Believers Pass',
    platform: 'Zora',
    chain: 'Base',
    dropType: 'edition',
    editionSize: 200,
    priceETH: 0.003,
    mintedCount: 198,
    mintDuration: '2 days',
    successRating: 3,
    theme: 'community',
    notes: 'Large edition, slow mint, eventually sold out'
  }
]

export function getPricingRecommendation(
  drop: Drop,
  cultureRef: CultureRef
): PricingRecommendation {
  // Find comparable drops
  const comparables = findComparableDrops(drop, cultureRef)
  
  // Calculate market conditions
  const marketConditions = getMarketConditions()
  
  // Calculate recommended price
  const basePrice = calculateBasePrice(drop.dropType, comparables)
  const adjustedPrice = adjustForMarket(basePrice, marketConditions)
  const finalPrice = adjustForArchetype(adjustedPrice, cultureRef.archetype)
  
  // Calculate confidence
  const confidence = calculateConfidence(comparables.length, marketConditions)
  
  // Generate reasoning
  const reasoning = generateReasoning(
    finalPrice,
    comparables,
    marketConditions,
    cultureRef
  )
  
  return {
    recommendedPriceETH: finalPrice,
    confidenceScore: confidence,
    reasoning,
    comparableDrops: comparables,
    marketConditions
  }
}

function findComparableDrops(drop: Drop, cultureRef: CultureRef): DropComp[] {
  return SUCCESSFUL_DROPS
    .filter(comp => {
      // Match by drop type
      if (comp.dropType !== drop.dropType && drop.dropType !== 'edition') return false
      
      // Match by theme similarity
      const themeMatch = comp.theme.toLowerCase().includes(cultureRef.theme.toLowerCase()) ||
                        cultureRef.theme.toLowerCase().includes(comp.theme.toLowerCase())
      
      return themeMatch || comp.successRating >= 4
    })
    .slice(0, 5)
}

function calculateBasePrice(dropType: string, comparables: DropComp[]): number {
  if (comparables.length === 0) {
    // Fallback defaults
    const defaults: Record<string, number> = {
      '1/1': 0.1,
      'edition': 0.005,
      'open edition': 0.001,
      'frame': 0.003,
      'airdrop concept': 0
    }
    return defaults[dropType] || 0.005
  }
  
  // Average price of comparables
  const avg = comparables.reduce((sum, comp) => sum + comp.priceETH, 0) / comparables.length
  return avg
}

function adjustForMarket(
  basePrice: number,
  market: PricingRecommendation['marketConditions']
): number {
  let multiplier = 1.0
  
  if (market.baseActivity === 'high' && market.zoraVolume === 'high') {
    multiplier = 1.2 // bullish
  } else if (market.baseActivity === 'low' || market.zoraVolume === 'low') {
    multiplier = 0.8 // bearish
  }
  
  return basePrice * multiplier
}

function adjustForArchetype(price: number, archetype: string): number {
  const archetypeMultipliers: Record<string, number> = {
    'rebel': 0.9, // more accessible
    'sage': 1.2, // premium
    'hero': 1.1, // slightly premium
    'explorer': 1.0,
    'creator': 1.15,
    'caregiver': 0.85
  }
  
  const multiplier = archetypeMultipliers[archetype.toLowerCase()] || 1.0
  return price * multiplier
}

function calculateConfidence(comparableCount: number, market: PricingRecommendation['marketConditions']): number {
  let confidence = 0.5
  
  // More comparables = higher confidence
  confidence += Math.min(comparableCount * 0.1, 0.3)
  
  // Strong market = higher confidence
  if (market.baseActivity === 'high' && market.zoraVolume === 'high') {
    confidence += 0.2
  }
  
  return Math.min(confidence, 0.95)
}

function generateReasoning(
  price: number,
  comparables: DropComp[],
  market: PricingRecommendation['marketConditions'],
  cultureRef: CultureRef
): string {
  const parts: string[] = []
  
  parts.push(`Based on ${comparables.length} similar successful drops on Base/Zora:`)
  
  if (comparables.length > 0) {
    const avgPrice = comparables.reduce((sum, c) => sum + c.priceETH, 0) / comparables.length
    parts.push(`Average price of comparable drops: ${avgPrice.toFixed(4)} ETH`)
  }
  
  parts.push(`Current market: Base activity is ${market.baseActivity}, Zora volume is ${market.zoraVolume}`)
  
  if (market.trendingThemes.length > 0) {
    parts.push(`Trending themes: ${market.trendingThemes.join(', ')}`)
  }
  
  parts.push(`${cultureRef.archetype} archetype suggests ${getArchetypeStrategy(cultureRef.archetype)} strategy`)
  
  parts.push(`\nRecommended: ${price.toFixed(4)} ETH`)
  
  return parts.join('\n')
}

function getArchetypeStrategy(archetype: string): string {
  const strategies: Record<string, string> = {
    'rebel': 'accessible, community-first',
    'sage': 'premium, exclusive',
    'hero': 'aspirational',
    'explorer': 'experimental',
    'creator': 'value-focused',
    'caregiver': 'inclusive'
  }
  return strategies[archetype.toLowerCase()] || 'balanced'
}

function getMarketConditions(): PricingRecommendation['marketConditions'] {
  // In a real app, this would fetch from APIs
  // For now, we'll use heuristics
  
  const hour = new Date().getHours()
  const dayOfWeek = new Date().getDay()
  
  // Simulate market activity based on time/day
  const isWeekend = dayOfWeek === 0 || dayOfWeek === 6
  const isPeakHours = hour >= 14 && hour <= 20 // 2pm-8pm
  
  let baseActivity: 'high' | 'medium' | 'low' = 'medium'
  let zoraVolume: 'high' | 'medium' | 'low' = 'medium'
  
  if (!isWeekend && isPeakHours) {
    baseActivity = 'high'
    zoraVolume = 'high'
  } else if (isWeekend) {
    baseActivity = 'low'
    zoraVolume = 'medium'
  }
  
  return {
    baseActivity,
    zoraVolume,
    trendingThemes: ['onchain culture', 'base summer', 'frames', 'builder movement']
  }
}

export function searchComps(query: string): DropComp[] {
  const lowerQuery = query.toLowerCase()
  return SUCCESSFUL_DROPS.filter(comp => 
    comp.name.toLowerCase().includes(lowerQuery) ||
    comp.theme.toLowerCase().includes(lowerQuery) ||
    comp.dropType.toLowerCase().includes(lowerQuery)
  )
}

export function getAllComps(): DropComp[] {
  return [...SUCCESSFUL_DROPS]
}

export function getCompById(id: string): DropComp | undefined {
  return SUCCESSFUL_DROPS.find(comp => comp.id === id)
}
