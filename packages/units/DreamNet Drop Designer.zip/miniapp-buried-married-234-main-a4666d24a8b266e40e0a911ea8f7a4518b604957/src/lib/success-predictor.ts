// Drop Success Predictor

import type { Drop, CultureRef } from '@/types/drop-architect'
import type { SuccessPrediction } from '@/types/drop-architect-extended'

export function predictDropSuccess(drop: Drop, cultureRef: CultureRef): SuccessPrediction {
  const scores = calculateScores(drop, cultureRef)
  const overallScore = calculateOverallScore(scores)
  const velocity = predictMintVelocity(drop, scores)
  const idealWindow = calculateIdealLaunchWindow(drop, cultureRef)
  const risks = identifyRisks(drop, scores)
  const opportunities = identifyOpportunities(drop, cultureRef, scores)
  const improvements = suggestImprovements(drop, scores)
  const confidence = calculatePredictionConfidence(drop, scores)
  
  return {
    dropId: drop.id,
    overallScore,
    predictedMintVelocity: velocity,
    estimatedSelloutTime: estimateSelloutTime(drop, velocity),
    idealLaunchWindow: idealWindow,
    riskFactors: risks,
    opportunities,
    improvements,
    confidence
  }
}

interface Scores {
  pricing: number
  narrative: number
  timing: number
  audience: number
  economics: number
  seo: number
}

function calculateScores(drop: Drop, cultureRef: CultureRef): Scores {
  return {
    pricing: scorePricing(drop),
    narrative: scoreNarrative(drop, cultureRef),
    timing: scoreTiming(drop),
    audience: scoreAudience(drop),
    economics: scoreEconomics(drop),
    seo: scoreSEO(drop)
  }
}

function scorePricing(drop: Drop): number {
  let score = 50
  
  // Sweet spot pricing for each type
  const sweetSpots: Record<string, { min: number; max: number }> = {
    'edition': { min: 0.003, max: 0.01 },
    'open edition': { min: 0.0005, max: 0.003 },
    '1/1': { min: 0.05, max: 0.5 },
    'frame': { min: 0.001, max: 0.005 }
  }
  
  const spot = sweetSpots[drop.dropType] || sweetSpots['edition']
  const price = drop.priceETH || 0
  
  if (drop.freeMint) {
    score = 85 // Free mints perform well for community building
  } else if (price >= spot.min && price <= spot.max) {
    score = 90
  } else if (price < spot.min) {
    score = 70 // Too cheap might signal low quality
  } else if (price > spot.max * 2) {
    score = 40 // Too expensive
  } else {
    score = 60
  }
  
  return score
}

function scoreNarrative(drop: Drop, cultureRef: CultureRef): number {
  let score = 50
  
  // Check narrative completeness
  if (drop.conceptSummary.length > 100) score += 15
  if (drop.loreSnippet.length > 50) score += 10
  if (drop.visualDirection.length > 50) score += 10
  if (drop.mediaPrompts.length >= 3) score += 10
  
  // Check emoji presence (important for Base culture)
  if (cultureRef.primaryEmoji) score += 5
  
  return Math.min(score, 100)
}

function scoreTiming(drop: Drop): number {
  let score = 50
  
  if (drop.launchWindowStart && drop.launchWindowEnd) {
    score += 20
    
    const start = new Date(drop.launchWindowStart)
    const dayOfWeek = start.getDay()
    const hour = start.getHours()
    
    // Tuesday-Thursday are best
    if (dayOfWeek >= 2 && dayOfWeek <= 4) score += 15
    
    // 2pm-8pm EST is prime time
    if (hour >= 14 && hour <= 20) score += 15
  }
  
  return Math.min(score, 100)
}

function scoreAudience(drop: Drop): number {
  let score = 50
  
  if (drop.targetAudienceNotes.length > 50) score += 20
  if (drop.preLaunchIdeas.length >= 3) score += 15
  if (drop.supportingChannels.length >= 3) score += 15
  
  return Math.min(score, 100)
}

function scoreEconomics(drop: Drop): number {
  let score = 50
  
  // Edition size sweet spots
  if (drop.dropType === 'edition') {
    const size = drop.editionSize || 0
    if (size >= 10 && size <= 100) score += 20
    else if (size > 100 && size <= 500) score += 10
    else if (size > 500) score += 5
  }
  
  // Open editions score well
  if (drop.dropType === 'open edition') score += 15
  
  // Royalty reasonableness
  const royalty = drop.royaltyPercent || 0
  if (royalty >= 5 && royalty <= 15) score += 15
  else if (royalty > 15) score += 5
  
  return Math.min(score, 100)
}

function scoreSEO(drop: Drop): number {
  let score = 50
  
  if (drop.seoTitle.length > 0) score += 10
  if (drop.seoDescription.length > 50) score += 10
  if (drop.seoKeywords.length >= 5) score += 10
  if (drop.seoHashtags.length >= 3) score += 10
  if (drop.altText.length > 0) score += 10
  
  return Math.min(score, 100)
}

function calculateOverallScore(scores: Scores): number {
  const weights = {
    pricing: 0.25,
    narrative: 0.20,
    timing: 0.15,
    audience: 0.15,
    economics: 0.15,
    seo: 0.10
  }
  
  const weighted = 
    scores.pricing * weights.pricing +
    scores.narrative * weights.narrative +
    scores.timing * weights.timing +
    scores.audience * weights.audience +
    scores.economics * weights.economics +
    scores.seo * weights.seo
  
  return Math.round(weighted)
}

function predictMintVelocity(drop: Drop, scores: Scores): 'fast' | 'medium' | 'slow' {
  const avgScore = (scores.pricing + scores.narrative + scores.economics) / 3
  
  if (drop.freeMint) return 'fast'
  if (drop.dropType === 'open edition') return 'medium'
  if (drop.editionSize && drop.editionSize <= 25) return 'fast'
  
  if (avgScore >= 80) return 'fast'
  if (avgScore >= 60) return 'medium'
  return 'slow'
}

function estimateSelloutTime(drop: Drop, velocity: 'fast' | 'medium' | 'slow'): string {
  if (drop.dropType === 'open edition') return 'N/A (open edition)'
  
  const size = drop.editionSize || 100
  
  const velocityTimes: Record<string, Record<string, string>> = {
    'fast': {
      'small': '1-3 hours',
      'medium': '6-12 hours',
      'large': '1-2 days'
    },
    'medium': {
      'small': '12-24 hours',
      'medium': '2-4 days',
      'large': '1-2 weeks'
    },
    'slow': {
      'small': '3-7 days',
      'medium': '1-2 weeks',
      'large': '2-4 weeks'
    }
  }
  
  let sizeCategory = 'medium'
  if (size <= 25) sizeCategory = 'small'
  else if (size > 100) sizeCategory = 'large'
  
  return velocityTimes[velocity][sizeCategory]
}

function calculateIdealLaunchWindow(drop: Drop, cultureRef: CultureRef): SuccessPrediction['idealLaunchWindow'] {
  // Best days: Tuesday-Thursday
  // Best times: 2pm-8pm EST
  
  return {
    dayOfWeek: 'Tuesday or Wednesday',
    timeRange: '2:00 PM - 4:00 PM EST',
    timezone: 'America/New_York'
  }
}

function identifyRisks(drop: Drop, scores: Scores): string[] {
  const risks: string[] = []
  
  if (scores.pricing < 60) {
    const price = drop.priceETH || 0
    if (price > 0.05 && drop.dropType === 'edition') {
      risks.push('Price may be too high for edition size')
    }
  }
  
  if (scores.timing < 60 && drop.launchWindowStart) {
    const start = new Date(drop.launchWindowStart)
    if (start.getDay() === 0 || start.getDay() === 6) {
      risks.push('Weekend launch may reduce visibility')
    }
  }
  
  if (scores.narrative < 60) {
    risks.push('Narrative could be more compelling')
  }
  
  if (!drop.launchWindowStart) {
    risks.push('No launch window set - timing is critical')
  }
  
  if (drop.preLaunchIdeas.length < 2) {
    risks.push('Limited pre-launch marketing plan')
  }
  
  if (drop.editionSize && drop.editionSize > 200 && drop.priceETH && drop.priceETH > 0.01) {
    risks.push('Large edition + high price may limit demand')
  }
  
  return risks
}

function identifyOpportunities(drop: Drop, cultureRef: CultureRef, scores: Scores): string[] {
  const opportunities: string[] = []
  
  if (cultureRef.theme.toLowerCase().includes('culture')) {
    opportunities.push('Strong alignment with Base culture movement')
  }
  
  if (drop.supportingChannels.includes('farcaster')) {
    opportunities.push('Farcaster integration can drive viral growth')
  }
  
  if (drop.freeMint) {
    opportunities.push('Free mints build community quickly')
  }
  
  if (scores.narrative >= 80) {
    opportunities.push('Strong narrative will resonate with collectors')
  }
  
  if (drop.dropType === 'frame') {
    opportunities.push('Frames are trending on Farcaster')
  }
  
  opportunities.push('Base ecosystem is highly active')
  
  return opportunities
}

function suggestImprovements(drop: Drop, scores: Scores): string[] {
  const improvements: string[] = []
  
  if (scores.pricing < 70) {
    improvements.push('Consider adjusting price to 0.003-0.01 ETH sweet spot')
  }
  
  if (scores.narrative < 70) {
    improvements.push('Expand concept summary and lore snippet')
  }
  
  if (scores.timing < 70) {
    improvements.push('Set launch window for Tuesday-Thursday, 2-4pm EST')
  }
  
  if (scores.audience < 70) {
    improvements.push('Add more pre-launch marketing ideas')
  }
  
  if (scores.seo < 70) {
    improvements.push('Complete SEO metadata for better discovery')
  }
  
  if (!drop.primaryGeoTargets || drop.primaryGeoTargets.length === 0) {
    improvements.push('Add geo-targeting for localized reach')
  }
  
  return improvements
}

function calculatePredictionConfidence(drop: Drop, scores: Scores): number {
  let confidence = 0.5
  
  // More complete data = higher confidence
  if (drop.launchWindowStart) confidence += 0.1
  if (scores.narrative >= 70) confidence += 0.1
  if (scores.pricing >= 70) confidence += 0.1
  if (drop.preLaunchIdeas.length >= 3) confidence += 0.1
  if (drop.seoHashtags.length >= 5) confidence += 0.1
  
  return Math.min(confidence, 0.95)
}
