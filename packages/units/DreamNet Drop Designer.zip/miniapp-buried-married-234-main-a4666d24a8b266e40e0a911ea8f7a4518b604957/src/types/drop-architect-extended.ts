// DreamNet Drop Architect - Extended Type Definitions

import type { Drop, CultureRef, GeoTarget, DropStatus } from './drop-architect'

// AI Visual Generation
export interface GeneratedVisual {
  id: string
  dropId: string
  prompt: string
  imageUrl: string
  createdAt: string
  isSelected: boolean
}

// Smart Pricing Oracle
export interface PricingRecommendation {
  recommendedPriceETH: number
  confidenceScore: number // 0-1
  reasoning: string
  comparableDrops: DropComp[]
  marketConditions: {
    baseActivity: 'high' | 'medium' | 'low'
    zoraVolume: 'high' | 'medium' | 'low'
    trendingThemes: string[]
  }
}

// Comps Database
export interface DropComp {
  id: string
  name: string
  platform: string
  chain: string
  dropType: string
  editionSize: number | null
  priceETH: number
  mintedCount: number
  mintDuration: string // e.g., "2 hours", "3 days"
  successRating: number // 1-5
  theme: string
  notes: string
}

// Drop Success Predictor
export interface SuccessPrediction {
  dropId: string
  overallScore: number // 0-100
  predictedMintVelocity: 'fast' | 'medium' | 'slow'
  estimatedSelloutTime: string
  idealLaunchWindow: {
    dayOfWeek: string
    timeRange: string
    timezone: string
  }
  riskFactors: string[]
  opportunities: string[]
  improvements: string[]
  confidence: number // 0-1
}

// Farcaster Frame
export interface FarcasterFrame {
  dropId: string
  frameUrl: string
  frameCode: string
  imageUrl: string
  buttons: {
    label: string
    action: string
    target?: string
  }[]
  metadata: {
    title: string
    description: string
    image: string
  }
}

// Multi-Drop Campaign
export interface DropCampaign {
  id: string
  name: string
  description: string
  startDate: string
  endDate: string
  dropIds: string[]
  narrative: string
  goals: string[]
  status: 'planning' | 'active' | 'completed'
}

// Allowlist
export interface Allowlist {
  id: string
  dropId: string
  name: string
  criteria: {
    type: 'token-holder' | 'nft-holder' | 'manual' | 'guild' | 'farcaster-follower'
    value: string
    description: string
  }[]
  addresses: string[]
  maxSpots: number | null
  expiresAt: string | null
}

// Post-Launch Performance
export interface DropPerformance {
  dropId: string
  launchedAt: string
  metrics: {
    totalMinted: number
    uniqueCollectors: number
    totalVolumeETH: number
    averageMintTime: string
    selloutTime: string | null
    secondaryVolume: number
    floorPrice: number
  }
  milestones: {
    timestamp: string
    event: string
    description: string
  }[]
  socialMetrics: {
    farcasterMentions: number
    xPosts: number
    zoraViews: number
  }
  comparisonToPrediction: {
    velocityMatch: 'faster' | 'as-expected' | 'slower'
    pricePerformance: 'above' | 'at' | 'below'
    audienceReach: 'exceeded' | 'met' | 'missed'
  }
  learnings: string[]
}

// Launch Checklist
export interface LaunchChecklist {
  dropId: string
  items: {
    id: string
    category: 'pre-launch' | 'launch-day' | 'post-launch'
    task: string
    completed: boolean
    dueDate: string | null
    notes: string
  }[]
}

// Drop Simulator
export interface SimulationResult {
  dropId: string
  timeline: {
    hour: number
    percentMinted: number
    totalMinted: number
    uniqueCollectors: number
    trending: boolean
    events: string[]
  }[]
  outcomes: {
    bestCase: {
      selloutTime: string
      totalVolume: number
      collectorCount: number
    }
    likelyCase: {
      selloutTime: string
      totalVolume: number
      collectorCount: number
    }
    worstCase: {
      selloutTime: string
      totalVolume: number
      collectorCount: number
    }
  }
  recommendations: string[]
  warnings: string[]
}

// Export Formats
export interface ExportFormat {
  format: 'zora-json' | 'farcaster-post' | 'x-thread' | 'discord' | 'mirror-blog'
  content: string
  metadata?: Record<string, unknown>
}

// Hashtag Performance
export interface HashtagAnalysis {
  tag: string
  status: 'trending' | 'moderate' | 'oversaturated' | 'emerging'
  baseActivity: number // relative score
  alternatives: string[]
}

// Collaborative Sharing
export interface SharedBrief {
  id: string
  dropId: string
  shareUrl: string
  createdAt: string
  expiresAt: string | null
  allowComments: boolean
  comments: {
    id: string
    author: string
    text: string
    timestamp: string
  }[]
  versions: {
    timestamp: string
    changes: string
    snapshot: Partial<Drop>
  }[]
}

// Visual Preview Card
export interface VisualPreview {
  dropId: string
  cardImageUrl: string
  zoraPreviewUrl: string
  farcasterPreviewUrl: string
  xPreviewUrl: string
}
