// DreamNet Drop Architect - Type Definitions

export interface CultureRef {
  id: string;
  name: string;
  ticker: string;
  primaryEmoji: string;
  theme: string;
  archetype: string;
}

export interface GeoTarget {
  id: string;
  region: string;
  country: string;
  cityOrMarket: string;
  language: string;
}

export type DropStatus = 'idea' | 'draft' | 'scheduled' | 'live' | 'completed' | 'archived';

export interface Drop {
  id: string;
  cultureRefId: string;
  name: string;
  dropType: string;
  chain: string;
  platform: string;
  status: DropStatus;
  
  // Mint / Economics
  editionSize: number | null;
  priceETH: number | null;
  priceToken: string | null;
  priceTokenAmount: number | null;
  freeMint: boolean;
  allowlistNotes: string;
  royaltyPercent: number | null;
  
  // Content & Narrative
  conceptSummary: string;
  loreSnippet: string;
  visualDirection: string;
  mediaType: string;
  mediaPrompts: string[];
  
  // Launch & Distribution
  targetAudienceNotes: string;
  launchTiming: string;
  launchWindowStart: string | null;
  launchWindowEnd: string | null;
  supportingChannels: string[];
  preLaunchIdeas: string[];
  postLaunchFollowUps: string[];
  
  // SEO & META
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
  
  // Geo Targeting
  primaryGeoTargets: GeoTarget[];
  captionLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
}

export interface DropFilter {
  status?: DropStatus;
  platform?: string;
  chain?: string;
  cultureRefId?: string;
}
