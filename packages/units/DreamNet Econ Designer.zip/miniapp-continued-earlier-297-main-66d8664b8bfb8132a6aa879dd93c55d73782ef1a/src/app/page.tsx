'use client'
import { useState, useEffect } from 'react';
import type { Asset, Pool, EconomicScenario } from '@/types/economic';
import { exportTokenomicsDoc } from '@/lib/economic-utils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Overview } from '@/components/economic/overview';
import { AssetsManager } from '@/components/economic/assets-manager';
import { PoolsManager } from '@/components/economic/pools-manager';
import { RolesManager } from '@/components/economic/roles-manager';
import { FlowsManager } from '@/components/economic/flows-manager';
import { ParametersManager } from '@/components/economic/parameters-manager';
import { ScenariosManager } from '@/components/economic/scenarios-manager';
import { AssetForm } from '@/components/economic/asset-form';
import { PoolForm } from '@/components/economic/pool-form';
import { ScenarioForm } from '@/components/economic/scenario-form';
import { ScenarioDetail } from '@/components/economic/scenario-detail';
import { TemplatesLibrary } from '@/components/economic/templates-library';
import { SimulationRunner } from '@/components/economic/simulation-runner';
import { RiskAnalysisViewer } from '@/components/economic/risk-analysis-viewer';
import { VersionControl } from '@/components/economic/version-control';
import { ScenarioComparison } from '@/components/economic/scenario-comparison';
import { NetworkGraphViewer } from '@/components/economic/network-graph-viewer';
import { ExportTools } from '@/components/economic/export-tools';
import { getAssets, saveAssets, getPools, savePools, getScenarios, saveScenarios } from '@/lib/economic-storage';
import { generateSEO } from '@/lib/economic-utils';
import { Copy } from 'lucide-react';
import { toast } from 'sonner';
import { Toaster } from '@/components/ui/sonner';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type ViewMode = 
  | 'overview'
  | 'create-asset'
  | 'create-pool'
  | 'create-scenario'
  | 'view-asset'
  | 'view-pool'
  | 'view-scenario';

export default function Home() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [activeTab, setActiveTab] = useState('overview');
  const [viewMode, setViewMode] = useState<ViewMode>('overview');
  const [selectedAsset, setSelectedAsset] = useState<Asset | undefined>();
  const [selectedPool, setSelectedPool] = useState<Pool | undefined>();
  const [selectedScenario, setSelectedScenario] = useState<EconomicScenario | undefined>();
  const [tokenomicsDoc, setTokenomicsDoc] = useState('');
  const [showTokenomicsDialog, setShowTokenomicsDialog] = useState(false);

  const handleCreateAsset = () => {
    setViewMode('create-asset');
    setActiveTab('overview');
  };

  const handleCreatePool = () => {
    setViewMode('create-pool');
    setActiveTab('overview');
  };

  const handleCreateScenario = () => {
    setViewMode('create-scenario');
    setActiveTab('overview');
  };

  const handleViewAsset = (asset: Asset) => {
    setSelectedAsset(asset);
    setViewMode('view-asset');
  };

  const handleViewPool = (pool: Pool) => {
    setSelectedPool(pool);
    setViewMode('view-pool');
  };

  const handleViewScenario = (scenario: EconomicScenario) => {
    setSelectedScenario(scenario);
    setViewMode('view-scenario');
  };

  const handleSaveAsset = (assetData: Partial<Asset>) => {
    const now = Date.now();
    const assets = getAssets();

    if (selectedAsset) {
      // Update
      const seoData = generateSEO(
        assetData.name || selectedAsset.name,
        assetData.description || selectedAsset.description,
        assetData.tags || selectedAsset.tags
      );

      const updatedAssets = assets.map((a: Asset) =>
        a.id === selectedAsset.id
          ? { ...a, ...assetData, ...seoData, updatedAt: now }
          : a
      );
      saveAssets(updatedAssets);
      toast.success('Asset updated successfully!');
    } else {
      // Create
      const seoData = generateSEO(
        assetData.name || '',
        assetData.description || '',
        assetData.tags || []
      );

      const newAsset: Asset = {
        id: `asset_${now}`,
        name: assetData.name || '',
        code: assetData.code || '',
        assetType: assetData.assetType || 'token',
        chain: assetData.chain || null,
        description: assetData.description || '',
        unitDescription: assetData.unitDescription || '',
        isPrimary: assetData.isPrimary || 'no',
        tags: assetData.tags || [],
        notes: assetData.notes || '',
        ...seoData,
        createdAt: now,
        updatedAt: now,
      };
      saveAssets([...assets, newAsset]);
      toast.success('Asset created successfully!');
    }

    setViewMode('overview');
    setSelectedAsset(undefined);
  };

  const handleSavePool = (poolData: Partial<Pool>) => {
    const now = Date.now();
    const pools = getPools();

    if (selectedPool) {
      // Update
      const seoData = generateSEO(
        poolData.name || selectedPool.name,
        poolData.description || selectedPool.description,
        poolData.tags || selectedPool.tags
      );

      const updatedPools = pools.map((p: Pool) =>
        p.id === selectedPool.id
          ? { ...p, ...poolData, ...seoData, updatedAt: now }
          : p
      );
      savePools(updatedPools);
      toast.success('Pool updated successfully!');
    } else {
      // Create
      const seoData = generateSEO(
        poolData.name || '',
        poolData.description || '',
        poolData.tags || []
      );

      const newPool: Pool = {
        id: `pool_${now}`,
        name: poolData.name || '',
        description: poolData.description || '',
        assetIds: poolData.assetIds || [],
        poolType: poolData.poolType || 'treasury',
        sourceOfFunds: poolData.sourceOfFunds || [],
        usageOfFunds: poolData.usageOfFunds || [],
        tags: poolData.tags || [],
        notes: poolData.notes || '',
        ...seoData,
        createdAt: now,
        updatedAt: now,
      };
      savePools([...pools, newPool]);
      toast.success('Pool created successfully!');
    }

    setViewMode('overview');
    setSelectedPool(undefined);
  };

  const handleSaveScenario = (scenarioData: Partial<EconomicScenario>) => {
    const now = Date.now();
    const scenarios = getScenarios();

    if (selectedScenario) {
      // Update
      const seoData = generateSEO(
        scenarioData.name || selectedScenario.name,
        scenarioData.description || selectedScenario.description,
        selectedScenario.seoHashtags || []
      );

      const updatedScenarios = scenarios.map((s: EconomicScenario) =>
        s.id === selectedScenario.id
          ? { ...s, ...scenarioData, ...seoData, updatedAt: now }
          : s
      );
      saveScenarios(updatedScenarios);
      toast.success('Scenario updated successfully!');
    } else {
      // Create
      const seoData = generateSEO(
        scenarioData.name || '',
        scenarioData.description || '',
        []
      );

      const newScenario: EconomicScenario = {
        id: `scenario_${now}`,
        name: scenarioData.name || '',
        description: scenarioData.description || '',
        parameterSetId: scenarioData.parameterSetId || '',
        activeFlowIds: scenarioData.activeFlowIds || [],
        notes: scenarioData.notes || '',
        ...seoData,
        createdAt: now,
        updatedAt: now,
      };
      saveScenarios([...scenarios, newScenario]);
      toast.success('Scenario created successfully!');
    }

    setViewMode('overview');
    setSelectedScenario(undefined);
  };

  const handleExportTokenomics = () => {
    const doc = exportTokenomicsDoc();
    setTokenomicsDoc(doc);
    setShowTokenomicsDialog(true);
  };

  const handleCopyTokenomics = () => {
    navigator.clipboard.writeText(tokenomicsDoc);
    toast.success('Tokenomics documentation copied to clipboard!');
  };

  const renderContent = () => {
    switch (viewMode) {
      case 'create-asset':
        return (
          <AssetForm
            onSave={handleSaveAsset}
            onCancel={() => setViewMode('overview')}
          />
        );
      case 'create-pool':
        return (
          <PoolForm
            onSave={handleSavePool}
            onCancel={() => setViewMode('overview')}
          />
        );
      case 'create-scenario':
        return (
          <ScenarioForm
            onSave={handleSaveScenario}
            onCancel={() => setViewMode('overview')}
          />
        );
      case 'view-asset':
        return selectedAsset ? (
          <AssetForm
            asset={selectedAsset}
            onSave={handleSaveAsset}
            onCancel={() => {
              setViewMode('overview');
              setSelectedAsset(undefined);
            }}
          />
        ) : null;
      case 'view-pool':
        return selectedPool ? (
          <PoolForm
            pool={selectedPool}
            onSave={handleSavePool}
            onCancel={() => {
              setViewMode('overview');
              setSelectedPool(undefined);
            }}
          />
        ) : null;
      case 'view-scenario':
        return selectedScenario ? (
          <ScenarioDetail
            scenario={selectedScenario}
            onBack={() => {
              setViewMode('overview');
              setSelectedScenario(undefined);
            }}
            onEdit={() => {
              // Keep the scenario selected but switch to form
              setViewMode('create-scenario');
            }}
          />
        ) : null;
      default:
        return (
          <Overview
            onCreateAsset={handleCreateAsset}
            onCreatePool={handleCreatePool}
            onCreateScenario={handleCreateScenario}
            onViewAsset={handleViewAsset}
            onViewPool={handleViewPool}
            onViewScenario={handleViewScenario}
            onExportTokenomics={handleExportTokenomics}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Hero Header */}
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            DreamNet Economic Engine
          </h1>
          <p className="text-muted-foreground">
            Complete tokenomics workbench with 20+ advanced features
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid grid-cols-5 lg:grid-cols-10 w-full gap-2">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="assets">Assets</TabsTrigger>
            <TabsTrigger value="pools">Pools</TabsTrigger>
            <TabsTrigger value="roles">Roles</TabsTrigger>
            <TabsTrigger value="flows">Flows</TabsTrigger>
            <TabsTrigger value="parameters">Parameters</TabsTrigger>
            <TabsTrigger value="scenarios">Scenarios</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
            <TabsTrigger value="advanced">Advanced</TabsTrigger>
            <TabsTrigger value="export">Export</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {renderContent()}
          </TabsContent>

          <TabsContent value="assets">
            <AssetsManager />
          </TabsContent>

          <TabsContent value="pools">
            <PoolsManager />
          </TabsContent>

          <TabsContent value="roles">
            <RolesManager />
          </TabsContent>

          <TabsContent value="flows">
            <FlowsManager />
          </TabsContent>

          <TabsContent value="parameters">
            <ParametersManager />
          </TabsContent>

          <TabsContent value="scenarios">
            <ScenariosManager />
          </TabsContent>

          <TabsContent value="templates">
            <TemplatesLibrary />
          </TabsContent>

          <TabsContent value="advanced">
            <Tabs defaultValue="simulation" className="w-full">
              <TabsList className="grid grid-cols-3 lg:grid-cols-6 w-full">
                <TabsTrigger value="simulation">Simulation</TabsTrigger>
                <TabsTrigger value="risk">Risk Analysis</TabsTrigger>
                <TabsTrigger value="version">Versions</TabsTrigger>
                <TabsTrigger value="compare">Compare</TabsTrigger>
                <TabsTrigger value="network">Network</TabsTrigger>
                <TabsTrigger value="export-adv">Export</TabsTrigger>
              </TabsList>

              <TabsContent value="simulation">
                {selectedScenario ? (
                  <SimulationRunner scenarioId={selectedScenario.id} />
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    Select a scenario from the Scenarios tab to run simulations
                  </div>
                )}
              </TabsContent>

              <TabsContent value="risk">
                {selectedScenario ? (
                  <RiskAnalysisViewer scenarioId={selectedScenario.id} />
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    Select a scenario from the Scenarios tab to analyze risks
                  </div>
                )}
              </TabsContent>

              <TabsContent value="version">
                <VersionControl />
              </TabsContent>

              <TabsContent value="compare">
                <ScenarioComparison />
              </TabsContent>

              <TabsContent value="network">
                {selectedScenario ? (
                  <NetworkGraphViewer scenarioId={selectedScenario.id} />
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    Select a scenario from the Scenarios tab to view network graph
                  </div>
                )}
              </TabsContent>

              <TabsContent value="export-adv">
                <ExportTools scenarioId={selectedScenario?.id} />
              </TabsContent>
            </Tabs>
          </TabsContent>

          <TabsContent value="export">
            <ExportTools scenarioId={selectedScenario?.id} />
          </TabsContent>
        </Tabs>

        {/* Tokenomics Export Dialog */}
        <Dialog open={showTokenomicsDialog} onOpenChange={setShowTokenomicsDialog}>
          <DialogContent className="max-w-4xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle className="flex items-center justify-between">
                DreamNet Economic & Tokenomics Documentation
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleCopyTokenomics}
                >
                  <Copy className="mr-2 h-4 w-4" />
                  Copy
                </Button>
              </DialogTitle>
            </DialogHeader>
            <ScrollArea className="h-[60vh]">
              <pre className="text-xs font-mono whitespace-pre p-4 bg-gray-50 rounded">
                {tokenomicsDoc}
              </pre>
            </ScrollArea>
          </DialogContent>
        </Dialog>

        <Toaster />
      </div>
    </div>
  );
}
