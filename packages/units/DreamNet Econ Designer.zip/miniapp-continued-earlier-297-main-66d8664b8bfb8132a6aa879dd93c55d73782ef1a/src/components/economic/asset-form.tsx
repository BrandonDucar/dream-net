'use client';

import { useState } from 'react';
import type { Asset, AssetType } from '@/types/economic';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { X } from 'lucide-react';

interface AssetFormProps {
  asset?: Asset;
  onSave: (asset: Partial<Asset>) => void;
  onCancel: () => void;
}

export function AssetForm({ asset, onSave, onCancel }: AssetFormProps) {
  const [name, setName] = useState(asset?.name || '');
  const [code, setCode] = useState(asset?.code || '');
  const [assetType, setAssetType] = useState<AssetType>(asset?.assetType || 'token');
  const [chain, setChain] = useState(asset?.chain || '');
  const [description, setDescription] = useState(asset?.description || '');
  const [unitDescription, setUnitDescription] = useState(asset?.unitDescription || '');
  const [isPrimary, setIsPrimary] = useState<'yes' | 'no'>(asset?.isPrimary || 'no');
  const [tags, setTags] = useState<string[]>(asset?.tags || []);
  const [tagInput, setTagInput] = useState('');
  const [notes, setNotes] = useState(asset?.notes || '');

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    setTags(tags.filter((t: string) => t !== tag));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name,
      code,
      assetType,
      chain: chain || null,
      description,
      unitDescription,
      isPrimary,
      tags,
      notes,
    });
  };

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle>{asset ? 'Edit Asset' : 'Create New Asset'}</CardTitle>
        <CardDescription>
          Define a new asset in the DreamNet economy (tokens, points, badges, vouchers)
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Asset Name*</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., DREAM Token"
                required
              />
            </div>
            <div>
              <Label htmlFor="code">Code*</Label>
              <Input
                id="code"
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                placeholder="e.g., DREAM"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="assetType">Asset Type*</Label>
              <Select value={assetType} onValueChange={(value) => setAssetType(value as AssetType)}>
                <SelectTrigger id="assetType">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="token">Token</SelectItem>
                  <SelectItem value="offchain-points">Off-chain Points</SelectItem>
                  <SelectItem value="badge-score">Badge Score</SelectItem>
                  <SelectItem value="voucher">Voucher</SelectItem>
                  <SelectItem value="credit">Credit</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="chain">Blockchain (optional)</Label>
              <Input
                id="chain"
                value={chain}
                onChange={(e) => setChain(e.target.value)}
                placeholder="e.g., Base, Ethereum"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="description">Description*</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe this asset's purpose and characteristics"
              required
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="unitDescription">Unit Description*</Label>
            <Input
              id="unitDescription"
              value={unitDescription}
              onChange={(e) => setUnitDescription(e.target.value)}
              placeholder="e.g., 1 DREAM, 100 points"
              required
            />
          </div>

          <div>
            <Label htmlFor="isPrimary">Primary Asset?</Label>
            <Select value={isPrimary} onValueChange={(value) => setIsPrimary(value as 'yes' | 'no')}>
              <SelectTrigger id="isPrimary">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="yes">Yes - Primary</SelectItem>
                <SelectItem value="no">No - Secondary</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="tags">Tags</Label>
            <div className="flex gap-2 mb-2">
              <Input
                id="tags"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                placeholder="Add a tag"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddTag();
                  }
                }}
              />
              <Button type="button" onClick={handleAddTag} variant="outline">
                Add
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {tags.map((tag: string) => (
                <Badge key={tag} variant="secondary">
                  {tag}
                  <X
                    className="ml-1 h-3 w-3 cursor-pointer"
                    onClick={() => handleRemoveTag(tag)}
                  />
                </Badge>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Additional notes or considerations"
              rows={2}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit">
              {asset ? 'Update Asset' : 'Create Asset'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
