'use client';

import { useState, useEffect } from 'react';
import type { Asset } from '@/types/economic';
import { getAssets, saveAssets, getFlows, getPools } from '@/lib/economic-storage';
import { generateSEO } from '@/lib/economic-utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, Trash2 } from 'lucide-react';
import { AssetForm } from './asset-form';
import { toast } from 'sonner';

export function AssetsManager() {
  const [assets, setAssets] = useState<Asset[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingAsset, setEditingAsset] = useState<Asset | undefined>();

  const loadAssets = () => {
    setAssets(getAssets());
  };

  useEffect(() => {
    loadAssets();
  }, []);

  const handleSave = (assetData: Partial<Asset>) => {
    const now = Date.now();

    if (editingAsset) {
      // Update existing asset
      const seoData = generateSEO(
        assetData.name || editingAsset.name,
        assetData.description || editingAsset.description,
        assetData.tags || editingAsset.tags
      );

      const updatedAssets = assets.map((a: Asset) =>
        a.id === editingAsset.id
          ? { ...a, ...assetData, ...seoData, updatedAt: now }
          : a
      );
      saveAssets(updatedAssets);
      toast.success('Asset updated successfully!');
    } else {
      // Create new asset
      const seoData = generateSEO(
        assetData.name || '',
        assetData.description || '',
        assetData.tags || []
      );

      const newAsset: Asset = {
        id: `asset_${now}`,
        name: assetData.name || '',
        code: assetData.code || '',
        assetType: assetData.assetType || 'token',
        chain: assetData.chain || null,
        description: assetData.description || '',
        unitDescription: assetData.unitDescription || '',
        isPrimary: assetData.isPrimary || 'no',
        tags: assetData.tags || [],
        notes: assetData.notes || '',
        ...seoData,
        createdAt: now,
        updatedAt: now,
      };
      saveAssets([...assets, newAsset]);
      toast.success('Asset created successfully!');
    }

    setShowForm(false);
    setEditingAsset(undefined);
    loadAssets();
  };

  const handleDelete = (asset: Asset) => {
    // Check if asset is used in flows or pools
    const flows = getFlows();
    const pools = getPools();
    
    const usedInFlows = flows.filter((f) => f.assetId === asset.id);
    const usedInPools = pools.filter((p) => p.assetIds.includes(asset.id));

    if (usedInFlows.length > 0 || usedInPools.length > 0) {
      toast.error(
        `Cannot delete asset. It's used in ${usedInFlows.length} flow(s) and ${usedInPools.length} pool(s).`
      );
      return;
    }

    if (confirm(`Delete asset "${asset.name}"?`)) {
      const updatedAssets = assets.filter((a: Asset) => a.id !== asset.id);
      saveAssets(updatedAssets);
      toast.success('Asset deleted successfully!');
      loadAssets();
    }
  };

  const handleEdit = (asset: Asset) => {
    setEditingAsset(asset);
    setShowForm(true);
  };

  if (showForm) {
    return (
      <AssetForm
        asset={editingAsset}
        onSave={handleSave}
        onCancel={() => {
          setShowForm(false);
          setEditingAsset(undefined);
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Assets</h1>
          <p className="text-gray-600 mt-1">Manage tokens, points, badges, and other value assets</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Create Asset
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          {assets.length === 0 ? (
            <p className="text-gray-500 text-center py-8">
              No assets yet. Create your first asset to get started!
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Code</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Chain</TableHead>
                  <TableHead>Primary</TableHead>
                  <TableHead>Tags</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {assets.map((asset: Asset) => (
                  <TableRow key={asset.id}>
                    <TableCell className="font-medium">{asset.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{asset.code}</Badge>
                    </TableCell>
                    <TableCell className="capitalize">{asset.assetType}</TableCell>
                    <TableCell>{asset.chain || 'Off-chain'}</TableCell>
                    <TableCell>
                      {asset.isPrimary === 'yes' && (
                        <Badge variant="default">Primary</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {asset.tags.slice(0, 2).map((tag: string) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {asset.tags.length > 2 && (
                          <Badge variant="outline" className="text-xs">
                            +{asset.tags.length - 2}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(asset)}
                        >
                          Edit
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(asset)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
