'use client';

import { useState } from 'react';
import { generateSmartContracts } from '@/lib/smart-contract-export';
import { downloadAllCSVs, downloadJSON, exportSummaryReport } from '@/lib/spreadsheet-export';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Download, Code, FileJson, FileText, Table } from 'lucide-react';
import type { ContractExport } from '@/types/economic-extended';

interface ExportToolsProps {
  scenarioId?: string;
}

export function ExportTools({ scenarioId }: ExportToolsProps) {
  const [contractExport, setContractExport] = useState<ContractExport | null>(null);
  const [generatingContracts, setGeneratingContracts] = useState<boolean>(false);

  const handleGenerateContracts = () => {
    if (!scenarioId) {
      alert('No scenario selected');
      return;
    }

    setGeneratingContracts(true);
    try {
      const contracts = generateSmartContracts(scenarioId);
      setContractExport(contracts);
    } catch (error) {
      alert('Error generating contracts: ' + (error instanceof Error ? error.message : 'Unknown error'));
    } finally {
      setGeneratingContracts(false);
    }
  };

  const handleDownloadContract = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadSummary = () => {
    const report = exportSummaryReport();
    const blob = new Blob([report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'economic-summary.txt';
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Export Tools
          </CardTitle>
          <CardDescription>
            Export your economic design in various formats
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue="contracts" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="contracts">Smart Contracts</TabsTrigger>
          <TabsTrigger value="json">JSON</TabsTrigger>
          <TabsTrigger value="csv">CSV/Excel</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="contracts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code className="h-5 w-5" />
                Smart Contract Export
              </CardTitle>
              <CardDescription>
                Generate Solidity contracts from your economic design
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <FileText className="h-4 w-4" />
                <AlertDescription>
                  Generates production-ready smart contracts with token economics, treasury management, and rewards distribution.
                </AlertDescription>
              </Alert>

              <Button
                onClick={handleGenerateContracts}
                disabled={!scenarioId || generatingContracts}
                className="w-full"
              >
                {generatingContracts ? 'Generating...' : 'Generate Smart Contracts'}
              </Button>

              {contractExport && (
                <div className="space-y-3">
                  <p className="text-sm font-semibold">Generated Contracts:</p>
                  {contractExport.contracts.map((contract) => (
                    <Card key={contract.name}>
                      <CardHeader>
                        <CardTitle className="text-sm flex items-center justify-between">
                          <span>{contract.name}</span>
                          <Badge>{contract.language}</Badge>
                        </CardTitle>
                        <CardDescription className="text-xs">{contract.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDownloadContract(contract.name, contract.code)}
                        >
                          <Download className="h-3 w-3 mr-2" />
                          Download Contract
                        </Button>
                      </CardContent>
                    </Card>
                  ))}

                  <p className="text-sm font-semibold mt-4">Config Files:</p>
                  {contractExport.configFiles.map((config) => (
                    <Card key={config.name}>
                      <CardHeader>
                        <CardTitle className="text-sm flex items-center justify-between">
                          <span>{config.name}</span>
                          <Badge variant="outline">{config.format}</Badge>
                        </CardTitle>
                        <CardDescription className="text-xs">{config.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDownloadContract(config.name, config.content)}
                        >
                          <Download className="h-3 w-3 mr-2" />
                          Download Config
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="json" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileJson className="h-5 w-5" />
                JSON Export
              </CardTitle>
              <CardDescription>
                Export complete economic design as JSON
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <FileJson className="h-4 w-4" />
                <AlertDescription>
                  Exports all assets, pools, roles, flows, parameters, and scenarios in JSON format for backup or integration.
                </AlertDescription>
              </Alert>

              <Button onClick={() => downloadJSON()} className="w-full">
                <Download className="h-4 w-4 mr-2" />
                Download JSON Export
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="csv" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Table className="h-5 w-5" />
                CSV/Excel Export
              </CardTitle>
              <CardDescription>
                Export data as CSV files for spreadsheet analysis
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <Table className="h-4 w-4" />
                <AlertDescription>
                  Exports separate CSV files for assets, pools, roles, flows, parameters, and scenarios.
                </AlertDescription>
              </Alert>

              <Button onClick={downloadAllCSVs} className="w-full">
                <Download className="h-4 w-4 mr-2" />
                Download All CSV Files
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Summary Reports
              </CardTitle>
              <CardDescription>
                Generate comprehensive tokenomics documentation
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <FileText className="h-4 w-4" />
                <AlertDescription>
                  Generates human-readable summary report with statistics and breakdowns.
                </AlertDescription>
              </Alert>

              <Button onClick={handleDownloadSummary} className="w-full">
                <Download className="h-4 w-4 mr-2" />
                Download Summary Report
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
