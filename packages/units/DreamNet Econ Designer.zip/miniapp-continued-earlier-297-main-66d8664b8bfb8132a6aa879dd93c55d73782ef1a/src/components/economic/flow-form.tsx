'use client';

import { useState } from 'react';
import type { ValueFlow, TriggerType, FrequencyType } from '@/types/economic';
import { getAssets, getRoles, getPools } from '@/lib/economic-storage';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

interface FlowFormProps {
  flow?: ValueFlow;
  onSave: (flow: Partial<ValueFlow>) => void;
  onCancel: () => void;
}

export function FlowForm({ flow, onSave, onCancel }: FlowFormProps) {
  const assets = getAssets();
  const roles = getRoles();
  const pools = getPools();

  const [name, setName] = useState(flow?.name || '');
  const [description, setDescription] = useState(flow?.description || '');
  const [assetId, setAssetId] = useState(flow?.assetId || '');
  const [fromRoleId, setFromRoleId] = useState<string | null>(flow?.fromRoleId || null);
  const [toRoleId, setToRoleId] = useState<string | null>(flow?.toRoleId || null);
  const [fromPoolId, setFromPoolId] = useState<string | null>(flow?.fromPoolId || null);
  const [toPoolId, setToPoolId] = useState<string | null>(flow?.toPoolId || null);
  const [trigger, setTrigger] = useState<TriggerType>(flow?.trigger || 'mint');
  const [formula, setFormula] = useState(flow?.formula || '');
  const [frequency, setFrequency] = useState<FrequencyType>(flow?.frequency || 'per-event');
  const [notes, setNotes] = useState(flow?.notes || '');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name,
      description,
      assetId,
      fromRoleId,
      toRoleId,
      fromPoolId,
      toPoolId,
      trigger,
      formula,
      frequency,
      notes,
    });
  };

  return (
    <Card className="w-full max-w-3xl">
      <CardHeader>
        <CardTitle>{flow ? 'Edit Value Flow' : 'Create New Value Flow'}</CardTitle>
        <CardDescription>
          Define how value moves between roles and pools in the economy
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Flow Name*</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Mint → Treasury, Rewards Distribution"
              required
            />
          </div>

          <div>
            <Label htmlFor="description">Description*</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe this value flow"
              required
              rows={2}
            />
          </div>

          <div>
            <Label htmlFor="assetId">Asset*</Label>
            <Select value={assetId} onValueChange={setAssetId}>
              <SelectTrigger id="assetId">
                <SelectValue placeholder="Select asset" />
              </SelectTrigger>
              <SelectContent>
                {assets.length === 0 ? (
                  <SelectItem value="none" disabled>
                    No assets available
                  </SelectItem>
                ) : (
                  assets.map((asset) => (
                    <SelectItem key={asset.id} value={asset.id}>
                      {asset.name} ({asset.code})
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="trigger">Trigger*</Label>
              <Select value={trigger} onValueChange={(value) => setTrigger(value as TriggerType)}>
                <SelectTrigger id="trigger">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mint">Mint</SelectItem>
                  <SelectItem value="trade">Trade</SelectItem>
                  <SelectItem value="badge-earned">Badge Earned</SelectItem>
                  <SelectItem value="participation">Participation</SelectItem>
                  <SelectItem value="donation">Donation</SelectItem>
                  <SelectItem value="manual">Manual</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="frequency">Frequency*</Label>
              <Select value={frequency} onValueChange={(value) => setFrequency(value as FrequencyType)}>
                <SelectTrigger id="frequency">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="per-event">Per Event</SelectItem>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="on-demand">On Demand</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="formula">Formula*</Label>
            <Input
              id="formula"
              value={formula}
              onChange={(e) => setFormula(e.target.value)}
              placeholder="e.g., 10% of mint price, flat 50 tokens"
              required
            />
          </div>

          <div className="border-t pt-4 mt-4">
            <h3 className="text-sm font-semibold mb-3">Flow Direction</h3>
            <p className="text-xs text-gray-600 mb-3">
              Define where value comes from and where it goes. Select either roles or pools (or leave as System).
            </p>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="fromRoleId">From Role</Label>
                <Select value={fromRoleId || 'none'} onValueChange={(value) => setFromRoleId(value === 'none' ? null : value)}>
                  <SelectTrigger id="fromRoleId">
                    <SelectValue placeholder="System / None" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">System / None</SelectItem>
                    {roles.map((role) => (
                      <SelectItem key={role.id} value={role.id}>
                        {role.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="toRoleId">To Role</Label>
                <Select value={toRoleId || 'none'} onValueChange={(value) => setToRoleId(value === 'none' ? null : value)}>
                  <SelectTrigger id="toRoleId">
                    <SelectValue placeholder="System / None" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">System / None</SelectItem>
                    {roles.map((role) => (
                      <SelectItem key={role.id} value={role.id}>
                        {role.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mt-3">
              <div>
                <Label htmlFor="fromPoolId">From Pool</Label>
                <Select value={fromPoolId || 'none'} onValueChange={(value) => setFromPoolId(value === 'none' ? null : value)}>
                  <SelectTrigger id="fromPoolId">
                    <SelectValue placeholder="None" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {pools.map((pool) => (
                      <SelectItem key={pool.id} value={pool.id}>
                        {pool.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="toPoolId">To Pool</Label>
                <Select value={toPoolId || 'none'} onValueChange={(value) => setToPoolId(value === 'none' ? null : value)}>
                  <SelectTrigger id="toPoolId">
                    <SelectValue placeholder="None" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {pools.map((pool) => (
                      <SelectItem key={pool.id} value={pool.id}>
                        {pool.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Additional notes or considerations"
              rows={2}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit" disabled={!assetId}>
              {flow ? 'Update Flow' : 'Create Flow'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
