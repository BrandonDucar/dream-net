'use client';

import { useState, useEffect } from 'react';
import type { ValueFlow, ValueFlowFilter } from '@/types/economic';
import { getFlows, saveFlows, getAssetById, getRoleById, getPoolById } from '@/lib/economic-storage';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, ArrowRight, Trash2 } from 'lucide-react';
import { FlowForm } from './flow-form';
import { generateSEO } from '@/lib/economic-utils';
import { toast } from 'sonner';

export function FlowsManager() {
  const [flows, setFlows] = useState<ValueFlow[]>([]);
  const [filteredFlows, setFilteredFlows] = useState<ValueFlow[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingFlow, setEditingFlow] = useState<ValueFlow | undefined>();
  
  // Filters
  const [filterAsset, setFilterAsset] = useState<string>('all');
  const [filterTrigger, setFilterTrigger] = useState<string>('all');

  const loadFlows = () => {
    const allFlows = getFlows();
    setFlows(allFlows);
    applyFilters(allFlows);
  };

  const applyFilters = (flowsToFilter: ValueFlow[]) => {
    let filtered = [...flowsToFilter];

    if (filterAsset !== 'all') {
      filtered = filtered.filter((f: ValueFlow) => f.assetId === filterAsset);
    }

    if (filterTrigger !== 'all') {
      filtered = filtered.filter((f: ValueFlow) => f.trigger === filterTrigger);
    }

    setFilteredFlows(filtered);
  };

  useEffect(() => {
    loadFlows();
  }, []);

  useEffect(() => {
    applyFilters(flows);
  }, [filterAsset, filterTrigger]);

  const handleSave = (flowData: Partial<ValueFlow>) => {
    const now = Date.now();

    if (editingFlow) {
      // Update existing flow
      const updatedFlows = flows.map((f: ValueFlow) =>
        f.id === editingFlow.id
          ? { ...f, ...flowData, updatedAt: now }
          : f
      );
      saveFlows(updatedFlows);
      toast.success('Flow updated successfully!');
    } else {
      // Create new flow
      const newFlow: ValueFlow = {
        id: `flow_${now}`,
        name: flowData.name || '',
        description: flowData.description || '',
        assetId: flowData.assetId || '',
        fromRoleId: flowData.fromRoleId || null,
        toRoleId: flowData.toRoleId || null,
        fromPoolId: flowData.fromPoolId || null,
        toPoolId: flowData.toPoolId || null,
        trigger: flowData.trigger || 'mint',
        formula: flowData.formula || '',
        frequency: flowData.frequency || 'per-event',
        notes: flowData.notes || '',
        createdAt: now,
        updatedAt: now,
      };
      saveFlows([...flows, newFlow]);
      toast.success('Flow created successfully!');
    }

    setShowForm(false);
    setEditingFlow(undefined);
    loadFlows();
  };

  const handleDelete = (flow: ValueFlow) => {
    if (confirm(`Delete flow "${flow.name}"?`)) {
      const updatedFlows = flows.filter((f: ValueFlow) => f.id !== flow.id);
      saveFlows(updatedFlows);
      toast.success('Flow deleted successfully!');
      loadFlows();
    }
  };

  const handleEdit = (flow: ValueFlow) => {
    setEditingFlow(flow);
    setShowForm(true);
  };

  if (showForm) {
    return (
      <FlowForm
        flow={editingFlow}
        onSave={handleSave}
        onCancel={() => {
          setShowForm(false);
          setEditingFlow(undefined);
        }}
      />
    );
  }

  // Get unique assets for filter
  const uniqueAssets = Array.from(new Set(flows.map((f: ValueFlow) => f.assetId)))
    .map((id: string) => getAssetById(id))
    .filter((a) => a !== undefined);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Value Flows</h1>
          <p className="text-gray-600 mt-1">Define how value moves through the economy</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Create Value Flow
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Asset</Label>
              <Select value={filterAsset} onValueChange={setFilterAsset}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Assets</SelectItem>
                  {uniqueAssets.map((asset) => (
                    <SelectItem key={asset?.id} value={asset?.id || ''}>
                      {asset?.name} ({asset?.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Trigger</Label>
              <Select value={filterTrigger} onValueChange={setFilterTrigger}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Triggers</SelectItem>
                  <SelectItem value="mint">Mint</SelectItem>
                  <SelectItem value="trade">Trade</SelectItem>
                  <SelectItem value="badge-earned">Badge Earned</SelectItem>
                  <SelectItem value="participation">Participation</SelectItem>
                  <SelectItem value="donation">Donation</SelectItem>
                  <SelectItem value="manual">Manual</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Flows Table */}
      <Card>
        <CardContent className="pt-6">
          {filteredFlows.length === 0 ? (
            <p className="text-gray-500 text-center py-8">
              No flows found. Create your first value flow!
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Asset</TableHead>
                  <TableHead>Flow</TableHead>
                  <TableHead>Trigger</TableHead>
                  <TableHead>Formula</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredFlows.map((flow: ValueFlow) => {
                  const asset = getAssetById(flow.assetId);
                  const fromRole = flow.fromRoleId ? getRoleById(flow.fromRoleId) : null;
                  const toRole = flow.toRoleId ? getRoleById(flow.toRoleId) : null;
                  const fromPool = flow.fromPoolId ? getPoolById(flow.fromPoolId) : null;
                  const toPool = flow.toPoolId ? getPoolById(flow.toPoolId) : null;

                  return (
                    <TableRow key={flow.id}>
                      <TableCell className="font-medium">{flow.name}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{asset?.code || 'Unknown'}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 text-xs">
                          <span>{fromRole?.name || fromPool?.name || 'System'}</span>
                          <ArrowRight className="h-3 w-3" />
                          <span>{toRole?.name || toPool?.name || 'System'}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{flow.trigger}</Badge>
                      </TableCell>
                      <TableCell className="text-sm">{flow.formula}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(flow)}
                          >
                            Edit
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(flow)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
