'use client';

import { useState, useEffect } from 'react';
import type { NetworkGraph } from '@/types/economic-extended';
import { generateNetworkGraph } from '@/lib/network-graph';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Network, GitBranch } from 'lucide-react';

interface NetworkGraphViewerProps {
  scenarioId: string;
}

export function NetworkGraphViewer({ scenarioId }: NetworkGraphViewerProps) {
  const [graph, setGraph] = useState<NetworkGraph | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    try {
      const networkGraph = generateNetworkGraph(scenarioId);
      setGraph(networkGraph);
    } catch (error) {
      console.error('Network graph error:', error);
    } finally {
      setLoading(false);
    }
  }, [scenarioId]);

  if (loading) {
    return <div>Generating network graph...</div>;
  }

  if (!graph) {
    return <div>Unable to generate network graph</div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-5 w-5" />
            Network Graph Visualization
          </CardTitle>
          <CardDescription>
            Visual representation of economic relationships and flows
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-4 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold">{graph.statistics.totalNodes}</p>
              <p className="text-sm text-muted-foreground">Total Nodes</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold">{graph.statistics.totalEdges}</p>
              <p className="text-sm text-muted-foreground">Total Edges</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold">{graph.statistics.centralNodes.length}</p>
              <p className="text-sm text-muted-foreground">Central Nodes</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold">{graph.statistics.bottlenecks.length}</p>
              <p className="text-sm text-muted-foreground">Bottlenecks</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Graph Visualization</CardTitle>
          <CardDescription>
            Interactive network diagram showing all economic entities and their relationships
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="border-2 border-dashed rounded-lg p-8 bg-slate-50">
            <div className="space-y-4">
              <p className="text-center text-muted-foreground">
                📊 Visual network graph would be rendered here
              </p>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="font-semibold mb-2">Nodes ({graph.nodes.length}):</p>
                  <div className="space-y-1 max-h-64 overflow-y-auto">
                    {graph.nodes.map((node) => (
                      <div key={node.id} className="flex items-center gap-2">
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: node.color }}
                        />
                        <span className="text-xs">{node.name}</span>
                        <Badge variant="outline" className="text-xs">{node.type}</Badge>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="font-semibold mb-2">Edges ({graph.edges.length}):</p>
                  <div className="space-y-1 max-h-64 overflow-y-auto">
                    {graph.edges.map((edge) => (
                      <div key={edge.id} className="text-xs text-muted-foreground">
                        <GitBranch className="inline h-3 w-3 mr-1" />
                        {edge.label}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {graph.statistics.centralNodes.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Central Nodes</CardTitle>
            <CardDescription>
              High-degree nodes that are critical to the economic network
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {graph.statistics.centralNodes.map((nodeId: string) => {
                const node = graph.nodes.find((n) => n.id === nodeId);
                return node ? (
                  <Badge key={nodeId} variant="secondary">
                    {node.name}
                  </Badge>
                ) : null;
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {graph.statistics.bottlenecks.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Bottlenecks</CardTitle>
            <CardDescription>
              Nodes with asymmetric flow patterns (potential risk points)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {graph.statistics.bottlenecks.map((nodeId: string) => {
                const node = graph.nodes.find((n) => n.id === nodeId);
                return node ? (
                  <Badge key={nodeId} variant="destructive">
                    {node.name}
                  </Badge>
                ) : null;
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
