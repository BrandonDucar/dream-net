'use client';

import { useState, useEffect } from 'react';
import type { Asset, Pool, EconomicScenario } from '@/types/economic';
import { getAssets, getPools, getScenarios } from '@/lib/economic-storage';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Coins, Vault, LineChart, Plus, FileDown } from 'lucide-react';

interface OverviewProps {
  onCreateAsset: () => void;
  onCreatePool: () => void;
  onCreateScenario: () => void;
  onViewAsset: (asset: Asset) => void;
  onViewPool: (pool: Pool) => void;
  onViewScenario: (scenario: EconomicScenario) => void;
  onExportTokenomics: () => void;
}

export function Overview({
  onCreateAsset,
  onCreatePool,
  onCreateScenario,
  onViewAsset,
  onViewPool,
  onViewScenario,
  onExportTokenomics,
}: OverviewProps) {
  const [assets, setAssets] = useState<Asset[]>([]);
  const [pools, setPools] = useState<Pool[]>([]);
  const [scenarios, setScenarios] = useState<EconomicScenario[]>([]);

  const loadData = () => {
    setAssets(getAssets());
    setPools(getPools());
    setScenarios(getScenarios());
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">DreamNet Economic Engine</h1>
          <p className="text-gray-600 mt-1">
            Design tokenomics, map value flows, and architect your economic system
          </p>
        </div>
        <Button onClick={onExportTokenomics} variant="outline" size="lg">
          <FileDown className="mr-2 h-4 w-4" />
          Export Tokenomics Doc
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Assets</CardTitle>
            <Coins className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{assets.length}</div>
            <p className="text-xs text-gray-500">Tokens, points, badges</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pools</CardTitle>
            <Vault className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pools.length}</div>
            <p className="text-xs text-gray-500">Treasuries, rewards, reserves</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Scenarios</CardTitle>
            <LineChart className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{scenarios.length}</div>
            <p className="text-xs text-gray-500">Economic configurations</p>
          </CardContent>
        </Card>
      </div>

      {/* Assets */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Assets</CardTitle>
          <Button onClick={onCreateAsset} size="sm">
            <Plus className="mr-2 h-4 w-4" />
            Create Asset
          </Button>
        </CardHeader>
        <CardContent>
          {assets.length === 0 ? (
            <p className="text-gray-500 text-center py-8">
              No assets yet. Create your first asset to get started!
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Code</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Chain</TableHead>
                  <TableHead>Primary</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {assets.map((asset: Asset) => (
                  <TableRow key={asset.id}>
                    <TableCell className="font-medium">{asset.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{asset.code}</Badge>
                    </TableCell>
                    <TableCell className="capitalize">{asset.assetType}</TableCell>
                    <TableCell>{asset.chain || 'Off-chain'}</TableCell>
                    <TableCell>
                      {asset.isPrimary === 'yes' && (
                        <Badge variant="default">Primary</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onViewAsset(asset)}
                      >
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Pools */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Pools</CardTitle>
          <Button onClick={onCreatePool} size="sm">
            <Plus className="mr-2 h-4 w-4" />
            Create Pool
          </Button>
        </CardHeader>
        <CardContent>
          {pools.length === 0 ? (
            <p className="text-gray-500 text-center py-8">
              No pools yet. Create your first pool to define where value accumulates!
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Assets</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pools.map((pool: Pool) => (
                  <TableRow key={pool.id}>
                    <TableCell className="font-medium">{pool.name}</TableCell>
                    <TableCell className="capitalize">{pool.poolType}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{pool.assetIds.length} assets</Badge>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onViewPool(pool)}
                      >
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Scenarios */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Economic Scenarios</CardTitle>
          <Button onClick={onCreateScenario} size="sm">
            <Plus className="mr-2 h-4 w-4" />
            Create Scenario
          </Button>
        </CardHeader>
        <CardContent>
          {scenarios.length === 0 ? (
            <p className="text-gray-500 text-center py-8">
              No scenarios yet. Create your first scenario to design economic configurations!
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Active Flows</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {scenarios.map((scenario: EconomicScenario) => (
                  <TableRow key={scenario.id}>
                    <TableCell className="font-medium">{scenario.name}</TableCell>
                    <TableCell className="max-w-md truncate">{scenario.description}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{scenario.activeFlowIds.length} flows</Badge>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onViewScenario(scenario)}
                      >
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
