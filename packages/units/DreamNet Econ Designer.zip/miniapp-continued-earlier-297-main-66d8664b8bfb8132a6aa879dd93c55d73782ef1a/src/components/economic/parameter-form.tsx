'use client';

import { useState } from 'react';
import type { ParameterSet } from '@/types/economic';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { X, Plus } from 'lucide-react';

interface ParameterFormProps {
  parameterSet?: ParameterSet;
  onSave: (parameterSet: Partial<ParameterSet>) => void;
  onCancel: () => void;
}

export function ParameterForm({ parameterSet, onSave, onCancel }: ParameterFormProps) {
  const [name, setName] = useState(parameterSet?.name || '');
  const [description, setDescription] = useState(parameterSet?.description || '');
  const [values, setValues] = useState<Record<string, number | string>>(parameterSet?.values || {});
  const [paramKey, setParamKey] = useState('');
  const [paramValue, setParamValue] = useState('');
  const [tags, setTags] = useState<string[]>(parameterSet?.tags || []);
  const [tagInput, setTagInput] = useState('');
  const [notes, setNotes] = useState(parameterSet?.notes || '');

  const handleAddParameter = () => {
    if (paramKey.trim() && paramValue.trim()) {
      const parsedValue = isNaN(Number(paramValue)) ? paramValue : Number(paramValue);
      setValues({ ...values, [paramKey.trim()]: parsedValue });
      setParamKey('');
      setParamValue('');
    }
  };

  const handleRemoveParameter = (key: string) => {
    const newValues = { ...values };
    delete newValues[key];
    setValues(newValues);
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    setTags(tags.filter((t: string) => t !== tag));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name,
      description,
      values,
      tags,
      notes,
    });
  };

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle>{parameterSet ? 'Edit Parameter Set' : 'Create New Parameter Set'}</CardTitle>
        <CardDescription>
          Define configuration parameters for economic scenarios
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Parameter Set Name*</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Base Tokenomics v1, Launch Config"
              required
            />
          </div>

          <div>
            <Label htmlFor="description">Description*</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe this parameter configuration"
              required
              rows={2}
            />
          </div>

          <div>
            <Label>Parameters</Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={paramKey}
                onChange={(e) => setParamKey(e.target.value)}
                placeholder="Key (e.g., mint_fee_pct)"
                className="flex-1"
              />
              <Input
                value={paramValue}
                onChange={(e) => setParamValue(e.target.value)}
                placeholder="Value (e.g., 5 or high)"
                className="flex-1"
              />
              <Button type="button" onClick={handleAddParameter} variant="outline" size="icon">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <div className="border rounded-md p-3 space-y-2 max-h-60 overflow-y-auto">
              {Object.keys(values).length === 0 ? (
                <p className="text-sm text-gray-500">No parameters defined yet</p>
              ) : (
                Object.entries(values).map(([key, value]) => (
                  <div key={key} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                    <div className="flex-1">
                      <span className="font-mono text-sm font-semibold">{key}</span>
                      <span className="mx-2 text-gray-400">=</span>
                      <span className="font-mono text-sm">{String(value)}</span>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveParameter(key)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ))
              )}
            </div>
          </div>

          <div>
            <Label htmlFor="tags">Tags</Label>
            <div className="flex gap-2 mb-2">
              <Input
                id="tags"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                placeholder="Add a tag"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddTag();
                  }
                }}
              />
              <Button type="button" onClick={handleAddTag} variant="outline">
                Add
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {tags.map((tag: string) => (
                <Badge key={tag} variant="secondary">
                  {tag}
                  <X
                    className="ml-1 h-3 w-3 cursor-pointer"
                    onClick={() => handleRemoveTag(tag)}
                  />
                </Badge>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Additional notes or considerations"
              rows={2}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit">
              {parameterSet ? 'Update Parameter Set' : 'Create Parameter Set'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
