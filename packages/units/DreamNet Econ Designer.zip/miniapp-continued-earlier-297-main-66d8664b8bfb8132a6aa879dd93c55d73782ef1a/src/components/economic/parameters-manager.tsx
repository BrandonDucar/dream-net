'use client';

import { useState, useEffect } from 'react';
import type { ParameterSet } from '@/types/economic';
import { getParameterSets, saveParameterSets } from '@/lib/economic-storage';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, Trash2 } from 'lucide-react';
import { ParameterForm } from './parameter-form';
import { toast } from 'sonner';

export function ParametersManager() {
  const [parameterSets, setParameterSets] = useState<ParameterSet[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingSet, setEditingSet] = useState<ParameterSet | undefined>();

  const loadParameterSets = () => {
    setParameterSets(getParameterSets());
  };

  useEffect(() => {
    loadParameterSets();
  }, []);

  const handleSave = (setData: Partial<ParameterSet>) => {
    const now = Date.now();

    if (editingSet) {
      // Update existing set
      const updatedSets = parameterSets.map((s: ParameterSet) =>
        s.id === editingSet.id
          ? { ...s, ...setData, updatedAt: now }
          : s
      );
      saveParameterSets(updatedSets);
      toast.success('Parameter set updated successfully!');
    } else {
      // Create new set
      const newSet: ParameterSet = {
        id: `params_${now}`,
        name: setData.name || '',
        description: setData.description || '',
        values: setData.values || {},
        tags: setData.tags || [],
        notes: setData.notes || '',
        createdAt: now,
        updatedAt: now,
      };
      saveParameterSets([...parameterSets, newSet]);
      toast.success('Parameter set created successfully!');
    }

    setShowForm(false);
    setEditingSet(undefined);
    loadParameterSets();
  };

  const handleDelete = (set: ParameterSet) => {
    if (confirm(`Delete parameter set "${set.name}"?`)) {
      const updatedSets = parameterSets.filter((s: ParameterSet) => s.id !== set.id);
      saveParameterSets(updatedSets);
      toast.success('Parameter set deleted successfully!');
      loadParameterSets();
    }
  };

  const handleEdit = (set: ParameterSet) => {
    setEditingSet(set);
    setShowForm(true);
  };

  if (showForm) {
    return (
      <ParameterForm
        parameterSet={editingSet}
        onSave={handleSave}
        onCancel={() => {
          setShowForm(false);
          setEditingSet(undefined);
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Parameter Sets</h1>
          <p className="text-gray-600 mt-1">Configure economic parameters for scenarios</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Create Parameter Set
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          {parameterSets.length === 0 ? (
            <p className="text-gray-500 text-center py-8">
              No parameter sets yet. Create your first configuration!
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Parameters</TableHead>
                  <TableHead>Tags</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {parameterSets.map((set: ParameterSet) => (
                  <TableRow key={set.id}>
                    <TableCell className="font-medium">{set.name}</TableCell>
                    <TableCell className="max-w-md truncate">{set.description}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{Object.keys(set.values).length} params</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {set.tags.slice(0, 2).map((tag: string) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {set.tags.length > 2 && (
                          <Badge variant="outline" className="text-xs">
                            +{set.tags.length - 2}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(set)}
                        >
                          Edit
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(set)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
