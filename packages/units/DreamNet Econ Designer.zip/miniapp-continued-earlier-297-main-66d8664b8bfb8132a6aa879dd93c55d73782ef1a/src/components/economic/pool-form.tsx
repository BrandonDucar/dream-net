'use client';

import { useState } from 'react';
import type { Pool, PoolType } from '@/types/economic';
import { getAssets } from '@/lib/economic-storage';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { X, Plus } from 'lucide-react';

interface PoolFormProps {
  pool?: Pool;
  onSave: (pool: Partial<Pool>) => void;
  onCancel: () => void;
}

export function PoolForm({ pool, onSave, onCancel }: PoolFormProps) {
  const assets = getAssets();
  const [name, setName] = useState(pool?.name || '');
  const [description, setDescription] = useState(pool?.description || '');
  const [poolType, setPoolType] = useState<PoolType>(pool?.poolType || 'treasury');
  const [assetIds, setAssetIds] = useState<string[]>(pool?.assetIds || []);
  const [sourceOfFunds, setSourceOfFunds] = useState<string[]>(pool?.sourceOfFunds || []);
  const [sourceInput, setSourceInput] = useState('');
  const [usageOfFunds, setUsageOfFunds] = useState<string[]>(pool?.usageOfFunds || []);
  const [usageInput, setUsageInput] = useState('');
  const [tags, setTags] = useState<string[]>(pool?.tags || []);
  const [tagInput, setTagInput] = useState('');
  const [notes, setNotes] = useState(pool?.notes || '');

  const handleToggleAsset = (assetId: string) => {
    if (assetIds.includes(assetId)) {
      setAssetIds(assetIds.filter((id: string) => id !== assetId));
    } else {
      setAssetIds([...assetIds, assetId]);
    }
  };

  const handleAddSource = () => {
    if (sourceInput.trim() && !sourceOfFunds.includes(sourceInput.trim())) {
      setSourceOfFunds([...sourceOfFunds, sourceInput.trim()]);
      setSourceInput('');
    }
  };

  const handleRemoveSource = (source: string) => {
    setSourceOfFunds(sourceOfFunds.filter((s: string) => s !== source));
  };

  const handleAddUsage = () => {
    if (usageInput.trim() && !usageOfFunds.includes(usageInput.trim())) {
      setUsageOfFunds([...usageOfFunds, usageInput.trim()]);
      setUsageInput('');
    }
  };

  const handleRemoveUsage = (usage: string) => {
    setUsageOfFunds(usageOfFunds.filter((u: string) => u !== usage));
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    setTags(tags.filter((t: string) => t !== tag));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name,
      description,
      poolType,
      assetIds,
      sourceOfFunds,
      usageOfFunds,
      tags,
      notes,
    });
  };

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle>{pool ? 'Edit Pool' : 'Create New Pool'}</CardTitle>
        <CardDescription>
          Define pools where value accumulates (treasuries, rewards, reserves)
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Pool Name*</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Core Treasury, Rewards Pool"
              required
            />
          </div>

          <div>
            <Label htmlFor="poolType">Pool Type*</Label>
            <Select value={poolType} onValueChange={(value) => setPoolType(value as PoolType)}>
              <SelectTrigger id="poolType">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="treasury">Treasury</SelectItem>
                <SelectItem value="rewards">Rewards</SelectItem>
                <SelectItem value="fees">Fees</SelectItem>
                <SelectItem value="liquidity">Liquidity</SelectItem>
                <SelectItem value="reserve">Reserve</SelectItem>
                <SelectItem value="escrow">Escrow</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="description">Description*</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe this pool's purpose"
              required
              rows={3}
            />
          </div>

          <div>
            <Label>Assets in This Pool</Label>
            <div className="space-y-2 mt-2 max-h-40 overflow-y-auto border rounded-md p-3">
              {assets.length === 0 ? (
                <p className="text-sm text-gray-500">No assets available. Create assets first.</p>
              ) : (
                assets.map((asset) => (
                  <div key={asset.id} className="flex items-center gap-2">
                    <Checkbox
                      id={`asset-${asset.id}`}
                      checked={assetIds.includes(asset.id)}
                      onCheckedChange={() => handleToggleAsset(asset.id)}
                    />
                    <Label htmlFor={`asset-${asset.id}`} className="cursor-pointer flex-1">
                      {asset.name} ({asset.code})
                    </Label>
                  </div>
                ))
              )}
            </div>
          </div>

          <div>
            <Label htmlFor="sources">Source of Funds</Label>
            <div className="flex gap-2 mb-2">
              <Input
                id="sources"
                value={sourceInput}
                onChange={(e) => setSourceInput(e.target.value)}
                placeholder="e.g., 2% of mints, manual top-ups"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddSource();
                  }
                }}
              />
              <Button type="button" onClick={handleAddSource} variant="outline" size="icon">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <div className="space-y-1">
              {sourceOfFunds.map((source: string, index: number) => (
                <div key={index} className="flex items-center gap-2 text-sm">
                  <span className="flex-1">{source}</span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => handleRemoveSource(source)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="usage">Usage of Funds</Label>
            <div className="flex gap-2 mb-2">
              <Input
                id="usage"
                value={usageInput}
                onChange={(e) => setUsageInput(e.target.value)}
                placeholder="e.g., weekly rewards, ops funding"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddUsage();
                  }
                }}
              />
              <Button type="button" onClick={handleAddUsage} variant="outline" size="icon">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <div className="space-y-1">
              {usageOfFunds.map((usage: string, index: number) => (
                <div key={index} className="flex items-center gap-2 text-sm">
                  <span className="flex-1">{usage}</span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => handleRemoveUsage(usage)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="tags">Tags</Label>
            <div className="flex gap-2 mb-2">
              <Input
                id="tags"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                placeholder="Add a tag"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddTag();
                  }
                }}
              />
              <Button type="button" onClick={handleAddTag} variant="outline">
                Add
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {tags.map((tag: string) => (
                <Badge key={tag} variant="secondary">
                  {tag}
                  <X
                    className="ml-1 h-3 w-3 cursor-pointer"
                    onClick={() => handleRemoveTag(tag)}
                  />
                </Badge>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Additional notes or considerations"
              rows={2}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit">
              {pool ? 'Update Pool' : 'Create Pool'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
