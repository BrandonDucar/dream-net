'use client';

import { useState, useEffect } from 'react';
import type { Pool } from '@/types/economic';
import { getPools, savePools, getAssetById } from '@/lib/economic-storage';
import { generateSEO } from '@/lib/economic-utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, Trash2 } from 'lucide-react';
import { PoolForm } from './pool-form';
import { toast } from 'sonner';

export function PoolsManager() {
  const [pools, setPools] = useState<Pool[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingPool, setEditingPool] = useState<Pool | undefined>();

  const loadPools = () => {
    setPools(getPools());
  };

  useEffect(() => {
    loadPools();
  }, []);

  const handleSave = (poolData: Partial<Pool>) => {
    const now = Date.now();

    if (editingPool) {
      // Update existing pool
      const seoData = generateSEO(
        poolData.name || editingPool.name,
        poolData.description || editingPool.description,
        poolData.tags || editingPool.tags
      );

      const updatedPools = pools.map((p: Pool) =>
        p.id === editingPool.id
          ? { ...p, ...poolData, ...seoData, updatedAt: now }
          : p
      );
      savePools(updatedPools);
      toast.success('Pool updated successfully!');
    } else {
      // Create new pool
      const seoData = generateSEO(
        poolData.name || '',
        poolData.description || '',
        poolData.tags || []
      );

      const newPool: Pool = {
        id: `pool_${now}`,
        name: poolData.name || '',
        description: poolData.description || '',
        assetIds: poolData.assetIds || [],
        poolType: poolData.poolType || 'treasury',
        sourceOfFunds: poolData.sourceOfFunds || [],
        usageOfFunds: poolData.usageOfFunds || [],
        tags: poolData.tags || [],
        notes: poolData.notes || '',
        ...seoData,
        createdAt: now,
        updatedAt: now,
      };
      savePools([...pools, newPool]);
      toast.success('Pool created successfully!');
    }

    setShowForm(false);
    setEditingPool(undefined);
    loadPools();
  };

  const handleDelete = (pool: Pool) => {
    if (confirm(`Delete pool "${pool.name}"?`)) {
      const updatedPools = pools.filter((p: Pool) => p.id !== pool.id);
      savePools(updatedPools);
      toast.success('Pool deleted successfully!');
      loadPools();
    }
  };

  const handleEdit = (pool: Pool) => {
    setEditingPool(pool);
    setShowForm(true);
  };

  if (showForm) {
    return (
      <PoolForm
        pool={editingPool}
        onSave={handleSave}
        onCancel={() => {
          setShowForm(false);
          setEditingPool(undefined);
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Pools</h1>
          <p className="text-gray-600 mt-1">Manage treasuries, rewards pools, and reserves</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Create Pool
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          {pools.length === 0 ? (
            <p className="text-gray-500 text-center py-8">
              No pools yet. Create your first pool to define where value accumulates!
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Assets</TableHead>
                  <TableHead>Sources</TableHead>
                  <TableHead>Tags</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pools.map((pool: Pool) => (
                  <TableRow key={pool.id}>
                    <TableCell className="font-medium">{pool.name}</TableCell>
                    <TableCell className="capitalize">{pool.poolType}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {pool.assetIds.map((assetId: string) => {
                          const asset = getAssetById(assetId);
                          return asset ? (
                            <Badge key={assetId} variant="outline" className="text-xs">
                              {asset.code}
                            </Badge>
                          ) : null;
                        })}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{pool.sourceOfFunds.length} sources</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {pool.tags.slice(0, 2).map((tag: string) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {pool.tags.length > 2 && (
                          <Badge variant="outline" className="text-xs">
                            +{pool.tags.length - 2}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(pool)}
                        >
                          Edit
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(pool)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
