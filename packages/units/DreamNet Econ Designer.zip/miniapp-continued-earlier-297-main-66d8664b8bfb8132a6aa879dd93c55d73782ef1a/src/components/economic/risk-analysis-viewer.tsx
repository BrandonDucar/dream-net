'use client';

import { useState, useEffect } from 'react';
import type { RiskAnalysis } from '@/types/economic-extended';
import { analyzeScenarioRisks } from '@/lib/risk-analyzer';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { AlertTriangle, CheckCircle2, Shield, TrendingDown, CircleDot } from 'lucide-react';

interface RiskAnalysisViewerProps {
  scenarioId: string;
}

export function RiskAnalysisViewer({ scenarioId }: RiskAnalysisViewerProps) {
  const [analysis, setAnalysis] = useState<RiskAnalysis | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    try {
      const result = analyzeScenarioRisks(scenarioId);
      setAnalysis(result);
    } catch (error) {
      console.error('Risk analysis error:', error);
    } finally {
      setLoading(false);
    }
  }, [scenarioId]);

  if (loading) {
    return <div>Analyzing risks...</div>;
  }

  if (!analysis) {
    return <div>Unable to analyze scenario</div>;
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'destructive';
      case 'high': return 'destructive';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
      default: return 'outline';
    }
  };

  const getRiskScore = () => {
    const weights = { critical: 4, high: 3, medium: 2, low: 1 };
    const total = analysis.risks.reduce((sum, risk) => sum + (weights[risk.severity] || 0), 0);
    const max = analysis.risks.length * 4;
    return max > 0 ? (total / max) * 100 : 0;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Risk Overview
          </CardTitle>
          <CardDescription>
            Automated risk detection and analysis
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground mb-2">Overall Risk Score</p>
              <div className="space-y-2">
                <Progress value={getRiskScore()} className="h-3" />
                <p className="text-xs text-muted-foreground">
                  {getRiskScore().toFixed(0)}% - {getRiskScore() > 75 ? 'High Risk' : getRiskScore() > 50 ? 'Medium Risk' : 'Low Risk'}
                </p>
              </div>
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-2">Total Risks Detected</p>
              <p className="text-3xl font-bold">{analysis.risks.length}</p>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2">
            {['critical', 'high', 'medium', 'low'].map((severity) => {
              const count = analysis.risks.filter((r) => r.severity === severity).length;
              return (
                <div key={severity} className="text-center p-2 border rounded">
                  <p className="text-2xl font-bold">{count}</p>
                  <p className="text-xs capitalize text-muted-foreground">{severity}</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="risks" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="risks">Risks ({analysis.risks.length})</TabsTrigger>
          <TabsTrigger value="balance">Balance Check</TabsTrigger>
          <TabsTrigger value="loops">Feedback Loops ({analysis.feedbackLoops.length})</TabsTrigger>
          <TabsTrigger value="death-spiral">Death Spiral</TabsTrigger>
        </TabsList>

        <TabsContent value="risks" className="space-y-3">
          {analysis.risks.length === 0 ? (
            <Alert>
              <CheckCircle2 className="h-4 w-4" />
              <AlertDescription>
                No risks detected. Scenario appears well-designed.
              </AlertDescription>
            </Alert>
          ) : (
            analysis.risks.map((risk) => (
              <Alert key={risk.id} variant={risk.severity === 'critical' || risk.severity === 'high' ? 'destructive' : 'default'}>
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle className="flex items-center gap-2">
                  <Badge variant={getSeverityColor(risk.severity) as 'destructive' | 'secondary' | 'outline'}>
                    {risk.severity}
                  </Badge>
                  <span>{risk.title}</span>
                  {risk.autoDetected && <Badge variant="outline">Auto-detected</Badge>}
                </AlertTitle>
                <AlertDescription className="space-y-2 mt-2">
                  <p>{risk.description}</p>
                  <p className="text-sm font-semibold">💡 Mitigation:</p>
                  <p className="text-sm">{risk.mitigation}</p>
                  {risk.affectedEntities.length > 0 && (
                    <div className="text-sm">
                      <p className="font-semibold">Affected Entities:</p>
                      <ul className="list-disc list-inside">
                        {risk.affectedEntities.map((entity, idx) => (
                          <li key={idx}>{entity.name} ({entity.type})</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </AlertDescription>
              </Alert>
            ))
          )}
        </TabsContent>

        <TabsContent value="balance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {analysis.balanceCheck.isBalanced ? (
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                ) : (
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                )}
                Balance Validation
              </CardTitle>
              <CardDescription>
                {analysis.balanceCheck.isBalanced
                  ? 'All flows are balanced and properly configured'
                  : `${analysis.balanceCheck.issues.length} balance issues detected`}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {analysis.balanceCheck.issues.length === 0 ? (
                <Alert>
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertDescription>
                    No balance issues detected. All flows are properly configured.
                  </AlertDescription>
                </Alert>
              ) : (
                <div className="space-y-3">
                  {analysis.balanceCheck.issues.map((issue, idx) => (
                    <Alert key={idx} variant={issue.severity === 'high' ? 'destructive' : 'default'}>
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <Badge variant={getSeverityColor(issue.severity) as 'destructive' | 'secondary' | 'outline'}>
                              {issue.type}
                            </Badge>
                            <Badge variant="outline">{issue.severity}</Badge>
                          </div>
                          <p>{issue.description}</p>
                        </div>
                      </AlertDescription>
                    </Alert>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="loops" className="space-y-4">
          {analysis.feedbackLoops.length === 0 ? (
            <Alert>
              <CircleDot className="h-4 w-4" />
              <AlertDescription>
                No feedback loops detected in this scenario.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="space-y-3">
              {analysis.feedbackLoops.map((loop) => (
                <Card key={loop.id}>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Badge variant={loop.type === 'destabilizing' ? 'destructive' : 'secondary'}>
                        {loop.type}
                      </Badge>
                      Feedback Loop
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <p className="text-sm">{loop.description}</p>
                    <p className="text-sm">
                      <span className="font-semibold">Strength:</span> {(loop.strength * 100).toFixed(0)}%
                    </p>
                    <p className="text-sm">
                      <span className="font-semibold">Flows involved:</span> {loop.flows.length}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="death-spiral" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingDown className="h-5 w-5" />
                Death Spiral Analysis
              </CardTitle>
              <CardDescription>
                Potential cascading failure scenarios
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Badge variant={getSeverityColor(analysis.deathSpiralRisk.riskLevel) as 'destructive' | 'secondary' | 'outline'} className="text-lg">
                  {analysis.deathSpiralRisk.riskLevel} Risk
                </Badge>
              </div>

              <div>
                <p className="font-semibold mb-2">Potential Scenarios:</p>
                <div className="space-y-3">
                  {analysis.deathSpiralRisk.scenarios.map((scenario, idx) => (
                    <div key={idx} className="border-l-2 border-amber-500 pl-4 space-y-2">
                      <p className="font-semibold text-sm">⚠️ {scenario.trigger}</p>
                      <div className="text-sm text-muted-foreground">
                        <p className="font-semibold">Cascade:</p>
                        <ol className="list-decimal list-inside space-y-1">
                          {scenario.cascade.map((step: string, stepIdx: number) => (
                            <li key={stepIdx}>{step}</li>
                          ))}
                        </ol>
                      </div>
                      <p className="text-sm">
                        <span className="font-semibold">Mitigation:</span> {scenario.mitigation}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <p className="font-semibold mb-2">Circuit Breakers:</p>
                {analysis.deathSpiralRisk.circuitBreakers.length === 0 ? (
                  <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      No circuit breakers detected. Consider adding emergency controls.
                    </AlertDescription>
                  </Alert>
                ) : (
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    {analysis.deathSpiralRisk.circuitBreakers.map((breaker: string, idx: number) => (
                      <li key={idx} className="text-muted-foreground">{breaker}</li>
                    ))}
                  </ul>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
