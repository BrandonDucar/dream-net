'use client';

import { useState } from 'react';
import type { EconomicRole } from '@/types/economic';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { X, Plus } from 'lucide-react';

interface RoleFormProps {
  role?: EconomicRole;
  onSave: (role: Partial<EconomicRole>) => void;
  onCancel: () => void;
}

export function RoleForm({ role, onSave, onCancel }: RoleFormProps) {
  const [name, setName] = useState(role?.name || '');
  const [description, setDescription] = useState(role?.description || '');
  const [typicalActions, setTypicalActions] = useState<string[]>(role?.typicalActions || []);
  const [actionInput, setActionInput] = useState('');
  const [tags, setTags] = useState<string[]>(role?.tags || []);
  const [tagInput, setTagInput] = useState('');
  const [notes, setNotes] = useState(role?.notes || '');

  const handleAddAction = () => {
    if (actionInput.trim() && !typicalActions.includes(actionInput.trim())) {
      setTypicalActions([...typicalActions, actionInput.trim()]);
      setActionInput('');
    }
  };

  const handleRemoveAction = (action: string) => {
    setTypicalActions(typicalActions.filter((a: string) => a !== action));
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    setTags(tags.filter((t: string) => t !== tag));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name,
      description,
      typicalActions,
      tags,
      notes,
    });
  };

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle>{role ? 'Edit Economic Role' : 'Create New Economic Role'}</CardTitle>
        <CardDescription>
          Define who participates in the economy (players, creators, agents, sponsors)
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Role Name*</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Player, Creator, Sponsor"
              required
            />
          </div>

          <div>
            <Label htmlFor="description">Description*</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe this role's function in the economy"
              required
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="actions">Typical Actions</Label>
            <div className="flex gap-2 mb-2">
              <Input
                id="actions"
                value={actionInput}
                onChange={(e) => setActionInput(e.target.value)}
                placeholder="e.g., Mints NFTs, Earns rewards"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddAction();
                  }
                }}
              />
              <Button type="button" onClick={handleAddAction} variant="outline" size="icon">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <div className="space-y-1">
              {typicalActions.map((action: string, index: number) => (
                <div key={index} className="flex items-center gap-2 text-sm">
                  <span className="flex-1">{action}</span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => handleRemoveAction(action)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="tags">Tags</Label>
            <div className="flex gap-2 mb-2">
              <Input
                id="tags"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                placeholder="Add a tag"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddTag();
                  }
                }}
              />
              <Button type="button" onClick={handleAddTag} variant="outline">
                Add
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {tags.map((tag: string) => (
                <Badge key={tag} variant="secondary">
                  {tag}
                  <X
                    className="ml-1 h-3 w-3 cursor-pointer"
                    onClick={() => handleRemoveTag(tag)}
                  />
                </Badge>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Additional notes or considerations"
              rows={2}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit">
              {role ? 'Update Role' : 'Create Role'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
