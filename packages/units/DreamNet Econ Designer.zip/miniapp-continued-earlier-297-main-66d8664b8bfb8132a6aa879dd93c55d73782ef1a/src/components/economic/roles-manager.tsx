'use client';

import { useState, useEffect } from 'react';
import type { EconomicRole } from '@/types/economic';
import { getRoles, saveRoles } from '@/lib/economic-storage';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, Trash2 } from 'lucide-react';
import { RoleForm } from './role-form';
import { toast } from 'sonner';

export function RolesManager() {
  const [roles, setRoles] = useState<EconomicRole[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingRole, setEditingRole] = useState<EconomicRole | undefined>();

  const loadRoles = () => {
    setRoles(getRoles());
  };

  useEffect(() => {
    loadRoles();
  }, []);

  const handleSave = (roleData: Partial<EconomicRole>) => {
    const now = Date.now();

    if (editingRole) {
      // Update existing role
      const updatedRoles = roles.map((r: EconomicRole) =>
        r.id === editingRole.id
          ? { ...r, ...roleData, updatedAt: now }
          : r
      );
      saveRoles(updatedRoles);
      toast.success('Role updated successfully!');
    } else {
      // Create new role
      const newRole: EconomicRole = {
        id: `role_${now}`,
        name: roleData.name || '',
        description: roleData.description || '',
        typicalActions: roleData.typicalActions || [],
        tags: roleData.tags || [],
        notes: roleData.notes || '',
        createdAt: now,
        updatedAt: now,
      };
      saveRoles([...roles, newRole]);
      toast.success('Role created successfully!');
    }

    setShowForm(false);
    setEditingRole(undefined);
    loadRoles();
  };

  const handleDelete = (role: EconomicRole) => {
    if (confirm(`Delete role "${role.name}"?`)) {
      const updatedRoles = roles.filter((r: EconomicRole) => r.id !== role.id);
      saveRoles(updatedRoles);
      toast.success('Role deleted successfully!');
      loadRoles();
    }
  };

  const handleEdit = (role: EconomicRole) => {
    setEditingRole(role);
    setShowForm(true);
  };

  if (showForm) {
    return (
      <RoleForm
        role={editingRole}
        onSave={handleSave}
        onCancel={() => {
          setShowForm(false);
          setEditingRole(undefined);
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Economic Roles</h1>
          <p className="text-gray-600 mt-1">Define who participates in the economy</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Create Role
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          {roles.length === 0 ? (
            <p className="text-gray-500 text-center py-8">
              No roles yet. Create your first economic role!
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Actions</TableHead>
                  <TableHead>Tags</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {roles.map((role: EconomicRole) => (
                  <TableRow key={role.id}>
                    <TableCell className="font-medium">{role.name}</TableCell>
                    <TableCell className="max-w-md truncate">{role.description}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{role.typicalActions.length} actions</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {role.tags.slice(0, 2).map((tag: string) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {role.tags.length > 2 && (
                          <Badge variant="outline" className="text-xs">
                            +{role.tags.length - 2}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(role)}
                        >
                          Edit
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(role)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
