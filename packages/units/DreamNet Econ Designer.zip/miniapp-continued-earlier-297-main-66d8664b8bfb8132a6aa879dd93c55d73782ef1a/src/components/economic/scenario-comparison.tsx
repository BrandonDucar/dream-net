'use client';

import { useState } from 'react';
import { getScenarios, getParameterSetById } from '@/lib/economic-storage';
import type { EconomicScenario } from '@/types/economic';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { GitCompare, TrendingUp } from 'lucide-react';

export function ScenarioComparison() {
  const scenarios = getScenarios();
  const [scenario1Id, setScenario1Id] = useState<string>('');
  const [scenario2Id, setScenario2Id] = useState<string>('');

  const scenario1 = scenarios.find((s: EconomicScenario) => s.id === scenario1Id);
  const scenario2 = scenarios.find((s: EconomicScenario) => s.id === scenario2Id);

  const params1 = scenario1 ? getParameterSetById(scenario1.parameterSetId) : null;
  const params2 = scenario2 ? getParameterSetById(scenario2.parameterSetId) : null;

  const allParamKeys = new Set([
    ...Object.keys(params1?.values || {}),
    ...Object.keys(params2?.values || {}),
  ]);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GitCompare className="h-5 w-5" />
            Scenario Comparison
          </CardTitle>
          <CardDescription>
            Compare two economic scenarios side-by-side
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-semibold">Scenario 1</label>
              <Select value={scenario1Id} onValueChange={setScenario1Id}>
                <SelectTrigger>
                  <SelectValue placeholder="Select first scenario" />
                </SelectTrigger>
                <SelectContent>
                  {scenarios.map((s: EconomicScenario) => (
                    <SelectItem key={s.id} value={s.id}>
                      {s.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold">Scenario 2</label>
              <Select value={scenario2Id} onValueChange={setScenario2Id}>
                <SelectTrigger>
                  <SelectValue placeholder="Select second scenario" />
                </SelectTrigger>
                <SelectContent>
                  {scenarios.map((s: EconomicScenario) => (
                    <SelectItem key={s.id} value={s.id}>
                      {s.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {scenario1 && scenario2 && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Overview Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Attribute</TableHead>
                    <TableHead>{scenario1.name}</TableHead>
                    <TableHead>{scenario2.name}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="font-semibold">Description</TableCell>
                    <TableCell>{scenario1.description}</TableCell>
                    <TableCell>{scenario2.description}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-semibold">Active Flows</TableCell>
                    <TableCell>
                      <Badge>{scenario1.activeFlowIds.length}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge>{scenario2.activeFlowIds.length}</Badge>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-semibold">Parameter Set</TableCell>
                    <TableCell>{params1?.name || 'None'}</TableCell>
                    <TableCell>{params2?.name || 'None'}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-semibold">Created</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {new Date(scenario1.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {new Date(scenario2.createdAt).toLocaleDateString()}
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {params1 && params2 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Parameter Comparison
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Parameter</TableHead>
                      <TableHead>{scenario1.name}</TableHead>
                      <TableHead>{scenario2.name}</TableHead>
                      <TableHead>Difference</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Array.from(allParamKeys).map((key: string) => {
                      const val1 = params1.values[key];
                      const val2 = params2.values[key];
                      const isDifferent = val1 !== val2;

                      return (
                        <TableRow key={key} className={isDifferent ? 'bg-amber-50' : ''}>
                          <TableCell className="font-semibold">{key}</TableCell>
                          <TableCell>
                            <Badge variant={val1 === undefined ? 'outline' : 'secondary'}>
                              {val1 === undefined ? 'Not set' : String(val1)}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant={val2 === undefined ? 'outline' : 'secondary'}>
                              {val2 === undefined ? 'Not set' : String(val2)}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {isDifferent && val1 !== undefined && val2 !== undefined ? (
                              <Badge variant="destructive">Different</Badge>
                            ) : (
                              <Badge variant="outline">Same</Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Flow Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="font-semibold mb-2">{scenario1.name} Flows:</p>
                  <ul className="text-sm space-y-1">
                    {scenario1.activeFlowIds.map((flowId: string) => (
                      <li key={flowId} className="text-muted-foreground">
                        • {flowId.slice(-12)}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <p className="font-semibold mb-2">{scenario2.name} Flows:</p>
                  <ul className="text-sm space-y-1">
                    {scenario2.activeFlowIds.map((flowId: string) => (
                      <li key={flowId} className="text-muted-foreground">
                        • {flowId.slice(-12)}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
