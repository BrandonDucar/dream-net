'use client';

import { useState } from 'react';
import type { EconomicScenario } from '@/types/economic';
import { getParameterSetById, getFlowById, getAssetById, getRoleById, getPoolById } from '@/lib/economic-storage';
import { generateValueFlowDiagram, generateEconomicBrief } from '@/lib/economic-utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ArrowLeft, FileText, Network, Copy, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

interface ScenarioDetailProps {
  scenario: EconomicScenario;
  onBack: () => void;
  onEdit: () => void;
}

export function ScenarioDetail({ scenario, onBack, onEdit }: ScenarioDetailProps) {
  const [diagramOpen, setDiagramOpen] = useState(false);
  const [briefOpen, setBriefOpen] = useState(false);
  const [diagram, setDiagram] = useState('');
  const [brief, setBrief] = useState('');

  const paramSet = getParameterSetById(scenario.parameterSetId);
  const activeFlows = scenario.activeFlowIds
    .map((id: string) => getFlowById(id))
    .filter((flow) => flow !== undefined);

  const handleGenerateDiagram = () => {
    const generatedDiagram = generateValueFlowDiagram(scenario.id);
    setDiagram(generatedDiagram);
    setDiagramOpen(true);
  };

  const handleGenerateBrief = () => {
    const generatedBrief = generateEconomicBrief(scenario.id);
    setBrief(generatedBrief);
    setBriefOpen(true);
  };

  const handleCopyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard!`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">{scenario.name}</h1>
            <p className="text-gray-600 mt-1">{scenario.description}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleGenerateDiagram} variant="outline">
            <Network className="mr-2 h-4 w-4" />
            Generate Diagram
          </Button>
          <Button onClick={handleGenerateBrief} variant="outline">
            <FileText className="mr-2 h-4 w-4" />
            Generate Brief
          </Button>
          <Button onClick={onEdit}>
            Edit Scenario
          </Button>
        </div>
      </div>

      {/* SEO Info */}
      {scenario.seoTitle && (
        <Card>
          <CardHeader>
            <CardTitle>SEO Metadata</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div>
              <p className="text-sm font-semibold">Title</p>
              <p className="text-sm text-gray-600">{scenario.seoTitle}</p>
            </div>
            {scenario.seoDescription && (
              <div>
                <p className="text-sm font-semibold">Description</p>
                <p className="text-sm text-gray-600">{scenario.seoDescription}</p>
              </div>
            )}
            {scenario.seoKeywords && scenario.seoKeywords.length > 0 && (
              <div>
                <p className="text-sm font-semibold">Keywords</p>
                <div className="flex flex-wrap gap-2 mt-1">
                  {scenario.seoKeywords.map((keyword: string) => (
                    <Badge key={keyword} variant="outline">{keyword}</Badge>
                  ))}
                </div>
              </div>
            )}
            {scenario.seoHashtags && scenario.seoHashtags.length > 0 && (
              <div>
                <p className="text-sm font-semibold">Hashtags</p>
                <div className="flex flex-wrap gap-2 mt-1">
                  {scenario.seoHashtags.map((hashtag: string) => (
                    <Badge key={hashtag} variant="secondary">{hashtag}</Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Parameter Set */}
      <Card>
        <CardHeader>
          <CardTitle>Parameter Configuration</CardTitle>
          <CardDescription>{paramSet?.name || 'Unknown Parameter Set'}</CardDescription>
        </CardHeader>
        <CardContent>
          {paramSet ? (
            <>
              <p className="text-sm text-gray-600 mb-4">{paramSet.description}</p>
              <div className="grid grid-cols-2 gap-3">
                {Object.entries(paramSet.values).map(([key, value]) => (
                  <div key={key} className="bg-gray-50 p-3 rounded">
                    <p className="text-xs font-semibold text-gray-500 uppercase">{key}</p>
                    <p className="text-lg font-mono">{String(value)}</p>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <p className="text-gray-500">Parameter set not found</p>
          )}
        </CardContent>
      </Card>

      {/* Active Flows */}
      <Card>
        <CardHeader>
          <CardTitle>Active Value Flows ({activeFlows.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {activeFlows.length === 0 ? (
            <p className="text-gray-500">No active flows in this scenario</p>
          ) : (
            <div className="space-y-4">
              {activeFlows.map((flow) => {
                if (!flow) return null;
                const asset = getAssetById(flow.assetId);
                const fromRole = flow.fromRoleId ? getRoleById(flow.fromRoleId) : null;
                const toRole = flow.toRoleId ? getRoleById(flow.toRoleId) : null;
                const fromPool = flow.fromPoolId ? getPoolById(flow.fromPoolId) : null;
                const toPool = flow.toPoolId ? getPoolById(flow.toPoolId) : null;

                return (
                  <div key={flow.id} className="border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold">{flow.name}</h3>
                      <Badge variant="outline">{asset?.code || 'Unknown'}</Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">{flow.description}</p>
                    
                    <div className="flex items-center gap-2 text-sm mb-2">
                      <span className="font-medium">{fromRole?.name || fromPool?.name || 'System'}</span>
                      <span className="text-gray-400">→</span>
                      <Badge variant="secondary" className="text-xs">{flow.formula}</Badge>
                      <span className="text-gray-400">→</span>
                      <span className="font-medium">{toRole?.name || toPool?.name || 'System'}</span>
                    </div>
                    
                    <div className="flex gap-4 text-xs text-gray-500">
                      <span>Trigger: <span className="font-medium">{flow.trigger}</span></span>
                      <span>Frequency: <span className="font-medium">{flow.frequency}</span></span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Notes */}
      {scenario.notes && (
        <Card>
          <CardHeader>
            <CardTitle>Notes</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 whitespace-pre-wrap">{scenario.notes}</p>
          </CardContent>
        </Card>
      )}

      {/* Diagram Dialog */}
      <Dialog open={diagramOpen} onOpenChange={setDiagramOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              Value Flow Diagram
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleCopyToClipboard(diagram, 'Diagram')}
              >
                <Copy className="mr-2 h-4 w-4" />
                Copy
              </Button>
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[60vh]">
            <pre className="text-xs font-mono whitespace-pre p-4 bg-gray-50 rounded">
              {diagram}
            </pre>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* Brief Dialog */}
      <Dialog open={briefOpen} onOpenChange={setBriefOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              Economic Brief
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleCopyToClipboard(brief, 'Brief')}
              >
                <Copy className="mr-2 h-4 w-4" />
                Copy
              </Button>
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[60vh]">
            <pre className="text-xs font-mono whitespace-pre p-4 bg-gray-50 rounded">
              {brief}
            </pre>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
