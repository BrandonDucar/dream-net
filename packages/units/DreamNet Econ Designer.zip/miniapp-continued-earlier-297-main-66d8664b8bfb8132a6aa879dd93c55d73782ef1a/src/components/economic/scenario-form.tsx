'use client';

import { useState } from 'react';
import type { EconomicScenario } from '@/types/economic';
import { getParameterSets, getFlows } from '@/lib/economic-storage';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';

interface ScenarioFormProps {
  scenario?: EconomicScenario;
  onSave: (scenario: Partial<EconomicScenario>) => void;
  onCancel: () => void;
}

export function ScenarioForm({ scenario, onSave, onCancel }: ScenarioFormProps) {
  const parameterSets = getParameterSets();
  const allFlows = getFlows();

  const [name, setName] = useState(scenario?.name || '');
  const [description, setDescription] = useState(scenario?.description || '');
  const [parameterSetId, setParameterSetId] = useState(scenario?.parameterSetId || '');
  const [activeFlowIds, setActiveFlowIds] = useState<string[]>(scenario?.activeFlowIds || []);
  const [notes, setNotes] = useState(scenario?.notes || '');

  const handleToggleFlow = (flowId: string) => {
    if (activeFlowIds.includes(flowId)) {
      setActiveFlowIds(activeFlowIds.filter((id: string) => id !== flowId));
    } else {
      setActiveFlowIds([...activeFlowIds, flowId]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name,
      description,
      parameterSetId,
      activeFlowIds,
      notes,
    });
  };

  return (
    <Card className="w-full max-w-3xl">
      <CardHeader>
        <CardTitle>{scenario ? 'Edit Economic Scenario' : 'Create New Economic Scenario'}</CardTitle>
        <CardDescription>
          Define complete economic scenarios with parameters and active flows
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Scenario Name*</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Launch Mode, Steady State"
              required
            />
          </div>

          <div>
            <Label htmlFor="description">Description*</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe this economic scenario and when it applies"
              required
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="parameterSetId">Parameter Set*</Label>
            <Select value={parameterSetId} onValueChange={setParameterSetId}>
              <SelectTrigger id="parameterSetId">
                <SelectValue placeholder="Select parameter set" />
              </SelectTrigger>
              <SelectContent>
                {parameterSets.length === 0 ? (
                  <SelectItem value="none" disabled>
                    No parameter sets available
                  </SelectItem>
                ) : (
                  parameterSets.map((set) => (
                    <SelectItem key={set.id} value={set.id}>
                      {set.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Active Value Flows</Label>
            <p className="text-xs text-gray-600 mb-2">
              Select which value flows are active in this scenario
            </p>
            <ScrollArea className="h-60 border rounded-md p-3">
              {allFlows.length === 0 ? (
                <p className="text-sm text-gray-500">No flows available. Create flows first.</p>
              ) : (
                <div className="space-y-2">
                  {allFlows.map((flow) => (
                    <div key={flow.id} className="flex items-start gap-2 p-2 hover:bg-gray-50 rounded">
                      <Checkbox
                        id={`flow-${flow.id}`}
                        checked={activeFlowIds.includes(flow.id)}
                        onCheckedChange={() => handleToggleFlow(flow.id)}
                      />
                      <div className="flex-1">
                        <Label htmlFor={`flow-${flow.id}`} className="cursor-pointer font-semibold">
                          {flow.name}
                        </Label>
                        <p className="text-xs text-gray-600">{flow.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
            <p className="text-xs text-gray-500 mt-1">
              {activeFlowIds.length} flow(s) selected
            </p>
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Additional notes or considerations"
              rows={2}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit" disabled={!parameterSetId}>
              {scenario ? 'Update Scenario' : 'Create Scenario'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
