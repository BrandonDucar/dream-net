'use client';

import { useState, useEffect } from 'react';
import type { EconomicScenario } from '@/types/economic';
import { getScenarios, saveScenarios } from '@/lib/economic-storage';
import { generateSEO } from '@/lib/economic-utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, Trash2, Eye } from 'lucide-react';
import { ScenarioForm } from './scenario-form';
import { ScenarioDetail } from './scenario-detail';
import { toast } from 'sonner';

export function ScenariosManager() {
  const [scenarios, setScenarios] = useState<EconomicScenario[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingScenario, setEditingScenario] = useState<EconomicScenario | undefined>();
  const [viewingScenario, setViewingScenario] = useState<EconomicScenario | undefined>();

  const loadScenarios = () => {
    setScenarios(getScenarios());
  };

  useEffect(() => {
    loadScenarios();
  }, []);

  const handleSave = (scenarioData: Partial<EconomicScenario>) => {
    const now = Date.now();

    if (editingScenario) {
      // Update existing scenario
      const seoData = generateSEO(
        scenarioData.name || editingScenario.name,
        scenarioData.description || editingScenario.description,
        editingScenario.seoHashtags || []
      );

      const updatedScenarios = scenarios.map((s: EconomicScenario) =>
        s.id === editingScenario.id
          ? { ...s, ...scenarioData, ...seoData, updatedAt: now }
          : s
      );
      saveScenarios(updatedScenarios);
      toast.success('Scenario updated successfully!');
    } else {
      // Create new scenario
      const seoData = generateSEO(
        scenarioData.name || '',
        scenarioData.description || '',
        []
      );

      const newScenario: EconomicScenario = {
        id: `scenario_${now}`,
        name: scenarioData.name || '',
        description: scenarioData.description || '',
        parameterSetId: scenarioData.parameterSetId || '',
        activeFlowIds: scenarioData.activeFlowIds || [],
        notes: scenarioData.notes || '',
        ...seoData,
        createdAt: now,
        updatedAt: now,
      };
      saveScenarios([...scenarios, newScenario]);
      toast.success('Scenario created successfully!');
    }

    setShowForm(false);
    setEditingScenario(undefined);
    loadScenarios();
  };

  const handleDelete = (scenario: EconomicScenario) => {
    if (confirm(`Delete scenario "${scenario.name}"?`)) {
      const updatedScenarios = scenarios.filter((s: EconomicScenario) => s.id !== scenario.id);
      saveScenarios(updatedScenarios);
      toast.success('Scenario deleted successfully!');
      loadScenarios();
    }
  };

  const handleEdit = (scenario: EconomicScenario) => {
    setEditingScenario(scenario);
    setShowForm(true);
  };

  const handleView = (scenario: EconomicScenario) => {
    setViewingScenario(scenario);
  };

  if (viewingScenario) {
    return (
      <ScenarioDetail
        scenario={viewingScenario}
        onBack={() => setViewingScenario(undefined)}
        onEdit={() => {
          setEditingScenario(viewingScenario);
          setViewingScenario(undefined);
          setShowForm(true);
        }}
      />
    );
  }

  if (showForm) {
    return (
      <ScenarioForm
        scenario={editingScenario}
        onSave={handleSave}
        onCancel={() => {
          setShowForm(false);
          setEditingScenario(undefined);
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Economic Scenarios</h1>
          <p className="text-gray-600 mt-1">Design complete economic configurations</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Create Scenario
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          {scenarios.length === 0 ? (
            <p className="text-gray-500 text-center py-8">
              No scenarios yet. Create your first economic scenario!
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Active Flows</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {scenarios.map((scenario: EconomicScenario) => (
                  <TableRow key={scenario.id}>
                    <TableCell className="font-medium">{scenario.name}</TableCell>
                    <TableCell className="max-w-md truncate">{scenario.description}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{scenario.activeFlowIds.length} flows</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleView(scenario)}
                        >
                          <Eye className="mr-2 h-4 w-4" />
                          View
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(scenario)}
                        >
                          Edit
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(scenario)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
