'use client';

import { useState } from 'react';
import type { SimulationConfig, SimulationResult } from '@/types/economic-extended';
import { runSimulation } from '@/lib/simulation-engine';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Activity, TrendingUp, AlertTriangle, Info } from 'lucide-react';

interface SimulationRunnerProps {
  scenarioId: string;
}

export function SimulationRunner({ scenarioId }: SimulationRunnerProps) {
  const [duration, setDuration] = useState<number>(30);
  const [timeUnit, setTimeUnit] = useState<'day' | 'week' | 'month'>('day');
  const [startingBalance, setStartingBalance] = useState<number>(10000);
  const [result, setResult] = useState<SimulationResult | null>(null);
  const [running, setRunning] = useState<boolean>(false);

  const handleRunSimulation = () => {
    setRunning(true);
    
    const config: SimulationConfig = {
      scenarioId,
      timeUnit,
      duration,
      startingBalances: { default: startingBalance },
      kpiInputs: [],
      agentBehaviors: [],
    };

    try {
      const simResult = runSimulation(config);
      setResult(simResult);
    } catch (error) {
      console.error('Simulation error:', error);
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Simulation Configuration
          </CardTitle>
          <CardDescription>
            Run economic scenarios with real numbers over time
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Time Unit</Label>
              <Select value={timeUnit} onValueChange={(value: 'day' | 'week' | 'month') => setTimeUnit(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="day">Day</SelectItem>
                  <SelectItem value="week">Week</SelectItem>
                  <SelectItem value="month">Month</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Duration</Label>
              <Input
                type="number"
                value={duration}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setDuration(parseInt(e.target.value) || 30)}
                min={1}
                max={365}
              />
            </div>

            <div className="space-y-2">
              <Label>Starting Balance</Label>
              <Input
                type="number"
                value={startingBalance}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setStartingBalance(parseFloat(e.target.value) || 10000)}
                min={0}
              />
            </div>
          </div>

          <Button onClick={handleRunSimulation} disabled={running} className="w-full">
            {running ? 'Running Simulation...' : 'Run Simulation'}
          </Button>
        </CardContent>
      </Card>

      {result && (
        <Tabs defaultValue="summary" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="summary">Summary</TabsTrigger>
            <TabsTrigger value="timeline">Timeline</TabsTrigger>
            <TabsTrigger value="warnings">Warnings ({result.warnings.length})</TabsTrigger>
            <TabsTrigger value="charts">Charts</TabsTrigger>
          </TabsList>

          <TabsContent value="summary" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Simulation Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Steps</p>
                    <p className="text-2xl font-bold">{result.timeSteps.length}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Warnings</p>
                    <p className="text-2xl font-bold text-amber-600">{result.warnings.length}</p>
                  </div>
                </div>

                <div>
                  <p className="text-sm font-semibold mb-2">Final Pool Balances</p>
                  <div className="space-y-2">
                    {Object.entries(result.summary.finalPoolBalances).map(([poolId, balance]) => (
                      <div key={poolId} className="flex justify-between items-center">
                        <span className="text-sm">{poolId}</span>
                        <Badge variant={balance < 0 ? 'destructive' : 'secondary'}>
                          {balance.toFixed(2)}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <p className="text-sm font-semibold mb-2">Total Flow Volume</p>
                  <div className="space-y-2">
                    {Object.entries(result.summary.totalFlowVolume).map(([assetCode, volume]) => (
                      <div key={assetCode} className="flex justify-between items-center">
                        <span className="text-sm">{assetCode}</span>
                        <Badge variant="outline">{volume.toFixed(2)}</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="timeline" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Simulation Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {result.timeSteps.map((step, idx) => (
                    <div key={idx} className="border-l-2 border-primary pl-4 pb-2">
                      <p className="font-semibold">Step {step.step}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(step.timestamp).toLocaleString()}
                      </p>
                      {step.events.length > 0 && (
                        <ul className="text-sm mt-1 space-y-1">
                          {step.events.map((event: string, eventIdx: number) => (
                            <li key={eventIdx} className="text-muted-foreground">• {event}</li>
                          ))}
                        </ul>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="warnings" className="space-y-4">
            {result.warnings.length === 0 ? (
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  No warnings detected. Scenario appears balanced.
                </AlertDescription>
              </Alert>
            ) : (
              <div className="space-y-3">
                {result.warnings.map((warning, idx) => (
                  <Alert key={idx} variant={warning.severity === 'critical' ? 'destructive' : 'default'}>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Badge variant={warning.severity === 'critical' ? 'destructive' : 'secondary'}>
                            {warning.severity}
                          </Badge>
                          <span className="font-semibold">{warning.category}</span>
                        </div>
                        <p>{warning.message}</p>
                        <p className="text-sm text-muted-foreground">💡 {warning.suggestedAction}</p>
                      </div>
                    </AlertDescription>
                  </Alert>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="charts" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Pool Balance Over Time</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center border-2 border-dashed rounded-lg">
                  <p className="text-muted-foreground">Chart visualization placeholder</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
