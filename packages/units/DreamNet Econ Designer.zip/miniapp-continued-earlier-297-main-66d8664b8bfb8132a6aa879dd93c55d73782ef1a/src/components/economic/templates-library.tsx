'use client';

import { useState } from 'react';
import type { EconomicTemplate } from '@/types/economic-extended';
import { ECONOMIC_TEMPLATES, getAllTemplateCategories } from '@/lib/templates';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Package, Zap, Star } from 'lucide-react';
import { saveAssets, savePools, saveRoles, saveFlows, saveParameterSets, saveScenarios, getAssets, getPools, getRoles, getFlows, getParameterSets, getScenarios } from '@/lib/economic-storage';
import type { Asset, Pool, EconomicRole, ValueFlow, ParameterSet, EconomicScenario } from '@/types/economic';

export function TemplatesLibrary() {
  const [selectedTemplate, setSelectedTemplate] = useState<EconomicTemplate | null>(null);
  const categories = getAllTemplateCategories();

  const applyTemplate = (template: EconomicTemplate) => {
    // Generate IDs for all entities
    const timestamp = Date.now();
    
    // Create assets
    const newAssets: Asset[] = template.assets.map((asset, idx) => ({
      ...asset,
      id: `asset_${timestamp}_${idx}`,
      createdAt: timestamp,
      updatedAt: timestamp,
    }));

    // Create pools (reference asset IDs)
    const newPools: Pool[] = template.pools.map((pool, idx) => ({
      ...pool,
      id: `pool_${timestamp}_${idx}`,
      assetIds: pool.assetIds.length > 0 ? pool.assetIds : newAssets.map((a: Asset) => a.id),
      createdAt: timestamp,
      updatedAt: timestamp,
    }));

    // Create roles
    const newRoles: EconomicRole[] = template.roles.map((role, idx) => ({
      ...role,
      id: `role_${timestamp}_${idx}`,
      createdAt: timestamp,
      updatedAt: timestamp,
    }));

    // Create flows (map to new IDs)
    const newFlows: ValueFlow[] = template.flows.map((flow, idx) => {
      const fromRoleIndex = flow.fromRoleId !== null && template.roles[parseInt(flow.fromRoleId.toString()) || 0] 
        ? parseInt(flow.fromRoleId.toString()) 
        : null;
      const toRoleIndex = flow.toRoleId !== null && template.roles[parseInt(flow.toRoleId.toString()) || 0]
        ? parseInt(flow.toRoleId.toString())
        : null;

      return {
        ...flow,
        id: `flow_${timestamp}_${idx}`,
        assetId: newAssets[0]?.id || '',
        fromRoleId: fromRoleIndex !== null && newRoles[fromRoleIndex] ? newRoles[fromRoleIndex].id : null,
        toRoleId: toRoleIndex !== null && newRoles[toRoleIndex] ? newRoles[toRoleIndex].id : null,
        fromPoolId: flow.fromPoolId !== null && newPools[0] ? newPools[0].id : null,
        toPoolId: flow.toPoolId !== null && newPools[newPools.length > 1 ? 1 : 0] ? newPools[newPools.length > 1 ? 1 : 0].id : null,
        createdAt: timestamp,
        updatedAt: timestamp,
      };
    });

    // Create parameter set
    const newParamSet: ParameterSet = {
      ...template.parameterSet,
      id: `param_${timestamp}`,
      createdAt: timestamp,
      updatedAt: timestamp,
    };

    // Create scenario
    const newScenario: EconomicScenario = {
      ...template.scenario,
      id: `scenario_${timestamp}`,
      parameterSetId: newParamSet.id,
      activeFlowIds: newFlows.map((f: ValueFlow) => f.id),
      createdAt: timestamp,
      updatedAt: timestamp,
    };

    // Save to storage
    const existingAssets = getAssets();
    const existingPools = getPools();
    const existingRoles = getRoles();
    const existingFlows = getFlows();
    const existingParams = getParameterSets();
    const existingScenarios = getScenarios();

    saveAssets([...existingAssets, ...newAssets]);
    savePools([...existingPools, ...newPools]);
    saveRoles([...existingRoles, ...newRoles]);
    saveFlows([...existingFlows, ...newFlows]);
    saveParameterSets([...existingParams, newParamSet]);
    saveScenarios([...existingScenarios, newScenario]);

    alert(`Template "${template.name}" applied successfully!`);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Economic Templates Library
          </CardTitle>
          <CardDescription>
            Pre-built tokenomics patterns to kickstart your economic design
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue="all" className="w-full">
        <TabsList>
          <TabsTrigger value="all">All ({ECONOMIC_TEMPLATES.length})</TabsTrigger>
          {categories.map((category: string) => (
            <TabsTrigger key={category} value={category} className="capitalize">
              {category.replace(/-/g, ' ')}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {ECONOMIC_TEMPLATES.map((template: EconomicTemplate) => (
              <Card key={template.id} className="hover:border-primary transition-colors">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Zap className="h-4 w-4" />
                    {template.name}
                  </CardTitle>
                  <CardDescription>{template.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary">{template.category.replace(/-/g, ' ')}</Badge>
                    {template.tags.map((tag: string) => (
                      <Badge key={tag} variant="outline">{tag}</Badge>
                    ))}
                  </div>

                  <div className="grid grid-cols-4 gap-2 text-center text-sm">
                    <div>
                      <p className="font-bold">{template.assets.length}</p>
                      <p className="text-xs text-muted-foreground">Assets</p>
                    </div>
                    <div>
                      <p className="font-bold">{template.pools.length}</p>
                      <p className="text-xs text-muted-foreground">Pools</p>
                    </div>
                    <div>
                      <p className="font-bold">{template.roles.length}</p>
                      <p className="text-xs text-muted-foreground">Roles</p>
                    </div>
                    <div>
                      <p className="font-bold">{template.flows.length}</p>
                      <p className="text-xs text-muted-foreground">Flows</p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" className="flex-1" onClick={() => setSelectedTemplate(template)}>
                          Preview
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle>{template.name}</DialogTitle>
                          <DialogDescription>{template.description}</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <p className="font-semibold mb-2">Assets:</p>
                            <ul className="list-disc list-inside space-y-1 text-sm">
                              {template.assets.map((asset, idx) => (
                                <li key={idx}>{asset.name} ({asset.code}) - {asset.assetType}</li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <p className="font-semibold mb-2">Pools:</p>
                            <ul className="list-disc list-inside space-y-1 text-sm">
                              {template.pools.map((pool, idx) => (
                                <li key={idx}>{pool.name} - {pool.poolType}</li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <p className="font-semibold mb-2">Roles:</p>
                            <ul className="list-disc list-inside space-y-1 text-sm">
                              {template.roles.map((role, idx) => (
                                <li key={idx}>{role.name}</li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <p className="font-semibold mb-2">Value Flows:</p>
                            <ul className="list-disc list-inside space-y-1 text-sm">
                              {template.flows.map((flow, idx) => (
                                <li key={idx}>{flow.name} - {flow.formula}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                    
                    <Button className="flex-1" onClick={() => applyTemplate(template)}>
                      <Star className="h-4 w-4 mr-2" />
                      Apply Template
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {categories.map((category: string) => (
          <TabsContent key={category} value={category} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {ECONOMIC_TEMPLATES.filter((t: EconomicTemplate) => t.category === category).map((template: EconomicTemplate) => (
                <Card key={template.id} className="hover:border-primary transition-colors">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Zap className="h-4 w-4" />
                      {template.name}
                    </CardTitle>
                    <CardDescription>{template.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex flex-wrap gap-2">
                      {template.tags.map((tag: string) => (
                        <Badge key={tag} variant="outline">{tag}</Badge>
                      ))}
                    </div>
                    <Button className="w-full" onClick={() => applyTemplate(template)}>
                      Apply Template
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
