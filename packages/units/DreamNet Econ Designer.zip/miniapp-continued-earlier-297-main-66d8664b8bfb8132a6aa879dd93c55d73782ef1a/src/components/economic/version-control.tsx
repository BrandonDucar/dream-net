'use client';

import { useState, useEffect } from 'react';
import type { VersionSnapshot } from '@/types/economic-extended';
import { getSnapshots, createSnapshot, restoreSnapshot, deleteSnapshot, compareSnapshots } from '@/lib/version-control';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { GitBranch, Save, RotateCcw, Trash2, GitCompare, Clock } from 'lucide-react';

export function VersionControl() {
  const [snapshots, setSnapshots] = useState<VersionSnapshot[]>([]);
  const [newSnapshotDesc, setNewSnapshotDesc] = useState<string>('');
  const [comparing, setComparing] = useState<{ id1: string; id2: string } | null>(null);

  useEffect(() => {
    loadSnapshots();
  }, []);

  const loadSnapshots = () => {
    setSnapshots(getSnapshots().sort((a: VersionSnapshot, b: VersionSnapshot) => b.timestamp - a.timestamp));
  };

  const handleCreateSnapshot = () => {
    if (!newSnapshotDesc.trim()) {
      alert('Please enter a description');
      return;
    }

    createSnapshot(newSnapshotDesc, 'User');
    setNewSnapshotDesc('');
    loadSnapshots();
  };

  const handleRestore = (id: string) => {
    if (confirm('Are you sure you want to restore this snapshot? Current data will be overwritten.')) {
      restoreSnapshot(id);
      alert('Snapshot restored successfully!');
      window.location.reload();
    }
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this snapshot?')) {
      deleteSnapshot(id);
      loadSnapshots();
    }
  };

  const handleCompare = (id1: string, id2: string) => {
    const diff = compareSnapshots(id1, id2);
    setComparing({ id1, id2 });
    // Show comparison results
    alert(JSON.stringify(diff, null, 2));
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GitBranch className="h-5 w-5" />
            Version Control & History
          </CardTitle>
          <CardDescription>
            Track changes, create snapshots, and rollback to previous versions
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Create New Snapshot</Label>
            <div className="flex gap-2">
              <Input
                placeholder="Description (e.g., 'Before major changes')"
                value={newSnapshotDesc}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewSnapshotDesc(e.target.value)}
              />
              <Button onClick={handleCreateSnapshot}>
                <Save className="h-4 w-4 mr-2" />
                Save Snapshot
              </Button>
            </div>
          </div>

          <Alert>
            <Clock className="h-4 w-4" />
            <AlertDescription>
              {snapshots.length} snapshots saved. Snapshots allow you to save your current economic design and restore it later.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <div className="space-y-3">
        {snapshots.length === 0 ? (
          <Card>
            <CardContent className="py-8 text-center text-muted-foreground">
              No snapshots yet. Create your first snapshot to track changes.
            </CardContent>
          </Card>
        ) : (
          snapshots.map((snapshot: VersionSnapshot) => (
            <Card key={snapshot.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <CardTitle className="text-base">{snapshot.description}</CardTitle>
                    <CardDescription className="flex items-center gap-2">
                      <Clock className="h-3 w-3" />
                      {new Date(snapshot.timestamp).toLocaleString()}
                      <span>•</span>
                      <span>by {snapshot.author}</span>
                    </CardDescription>
                  </div>
                  <Badge variant="outline">{snapshot.id.slice(-8)}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-6 gap-2 text-center text-sm">
                  <div>
                    <p className="font-bold">{snapshot.assets.length}</p>
                    <p className="text-xs text-muted-foreground">Assets</p>
                  </div>
                  <div>
                    <p className="font-bold">{snapshot.pools.length}</p>
                    <p className="text-xs text-muted-foreground">Pools</p>
                  </div>
                  <div>
                    <p className="font-bold">{snapshot.roles.length}</p>
                    <p className="text-xs text-muted-foreground">Roles</p>
                  </div>
                  <div>
                    <p className="font-bold">{snapshot.flows.length}</p>
                    <p className="text-xs text-muted-foreground">Flows</p>
                  </div>
                  <div>
                    <p className="font-bold">{snapshot.parameterSets.length}</p>
                    <p className="text-xs text-muted-foreground">Params</p>
                  </div>
                  <div>
                    <p className="font-bold">{snapshot.scenarios.length}</p>
                    <p className="text-xs text-muted-foreground">Scenarios</p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleRestore(snapshot.id)}
                  >
                    <RotateCcw className="h-3 w-3 mr-1" />
                    Restore
                  </Button>
                  
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        <GitCompare className="h-3 w-3 mr-1" />
                        Compare
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Compare Snapshots</DialogTitle>
                        <DialogDescription>
                          Select another snapshot to compare with this one
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-2">
                        {snapshots
                          .filter((s: VersionSnapshot) => s.id !== snapshot.id)
                          .map((s: VersionSnapshot) => (
                            <Button
                              key={s.id}
                              variant="outline"
                              className="w-full justify-start"
                              onClick={() => handleCompare(snapshot.id, s.id)}
                            >
                              {s.description}
                            </Button>
                          ))}
                      </div>
                    </DialogContent>
                  </Dialog>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDelete(snapshot.id)}
                    className="ml-auto"
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
