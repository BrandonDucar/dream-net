// DreamNet Economic Engine Storage Layer
// All data persisted to localStorage

import type {
  Asset,
  EconomicRole,
  Pool,
  ValueFlow,
  ParameterSet,
  EconomicScenario,
  AssetFilter,
  PoolFilter,
  ValueFlowFilter,
  ScenarioFilter,
} from '@/types/economic';

const STORAGE_KEYS = {
  ASSETS: 'dreamnet_assets',
  ROLES: 'dreamnet_roles',
  POOLS: 'dreamnet_pools',
  FLOWS: 'dreamnet_flows',
  PARAMETER_SETS: 'dreamnet_parameter_sets',
  SCENARIOS: 'dreamnet_scenarios',
} as const;

// Generic storage functions
function getFromStorage<T>(key: string): T[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

function saveToStorage<T>(key: string, data: T[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(key, JSON.stringify(data));
}

// Assets
export function getAssets(): Asset[] {
  return getFromStorage<Asset>(STORAGE_KEYS.ASSETS);
}

export function saveAssets(assets: Asset[]): void {
  saveToStorage(STORAGE_KEYS.ASSETS, assets);
}

export function getAssetById(id: string): Asset | undefined {
  return getAssets().find((asset: Asset) => asset.id === id);
}

export function filterAssets(filter: AssetFilter): Asset[] {
  let assets = getAssets();
  
  if (filter.assetType) {
    assets = assets.filter((a: Asset) => a.assetType === filter.assetType);
  }
  if (filter.chain) {
    assets = assets.filter((a: Asset) => a.chain === filter.chain);
  }
  if (filter.tag) {
    assets = assets.filter((a: Asset) => a.tags.includes(filter.tag as string));
  }
  if (filter.isPrimary) {
    assets = assets.filter((a: Asset) => a.isPrimary === filter.isPrimary);
  }
  
  return assets;
}

// Economic Roles
export function getRoles(): EconomicRole[] {
  return getFromStorage<EconomicRole>(STORAGE_KEYS.ROLES);
}

export function saveRoles(roles: EconomicRole[]): void {
  saveToStorage(STORAGE_KEYS.ROLES, roles);
}

export function getRoleById(id: string): EconomicRole | undefined {
  return getRoles().find((role: EconomicRole) => role.id === id);
}

// Pools
export function getPools(): Pool[] {
  return getFromStorage<Pool>(STORAGE_KEYS.POOLS);
}

export function savePools(pools: Pool[]): void {
  saveToStorage(STORAGE_KEYS.POOLS, pools);
}

export function getPoolById(id: string): Pool | undefined {
  return getPools().find((pool: Pool) => pool.id === id);
}

export function filterPools(filter: PoolFilter): Pool[] {
  let pools = getPools();
  
  if (filter.poolType) {
    pools = pools.filter((p: Pool) => p.poolType === filter.poolType);
  }
  if (filter.tag) {
    pools = pools.filter((p: Pool) => p.tags.includes(filter.tag as string));
  }
  if (filter.assetId) {
    pools = pools.filter((p: Pool) => p.assetIds.includes(filter.assetId as string));
  }
  
  return pools;
}

// Value Flows
export function getFlows(): ValueFlow[] {
  return getFromStorage<ValueFlow>(STORAGE_KEYS.FLOWS);
}

export function saveFlows(flows: ValueFlow[]): void {
  saveToStorage(STORAGE_KEYS.FLOWS, flows);
}

export function getFlowById(id: string): ValueFlow | undefined {
  return getFlows().find((flow: ValueFlow) => flow.id === id);
}

export function filterFlows(filter: ValueFlowFilter): ValueFlow[] {
  let flows = getFlows();
  
  if (filter.assetId) {
    flows = flows.filter((f: ValueFlow) => f.assetId === filter.assetId);
  }
  if (filter.fromRoleId) {
    flows = flows.filter((f: ValueFlow) => f.fromRoleId === filter.fromRoleId);
  }
  if (filter.toRoleId) {
    flows = flows.filter((f: ValueFlow) => f.toRoleId === filter.toRoleId);
  }
  if (filter.fromPoolId) {
    flows = flows.filter((f: ValueFlow) => f.fromPoolId === filter.fromPoolId);
  }
  if (filter.toPoolId) {
    flows = flows.filter((f: ValueFlow) => f.toPoolId === filter.toPoolId);
  }
  if (filter.trigger) {
    flows = flows.filter((f: ValueFlow) => f.trigger === filter.trigger);
  }
  if (filter.frequency) {
    flows = flows.filter((f: ValueFlow) => f.frequency === filter.frequency);
  }
  
  return flows;
}

// Parameter Sets
export function getParameterSets(): ParameterSet[] {
  return getFromStorage<ParameterSet>(STORAGE_KEYS.PARAMETER_SETS);
}

export function saveParameterSets(sets: ParameterSet[]): void {
  saveToStorage(STORAGE_KEYS.PARAMETER_SETS, sets);
}

export function getParameterSetById(id: string): ParameterSet | undefined {
  return getParameterSets().find((set: ParameterSet) => set.id === id);
}

// Economic Scenarios
export function getScenarios(): EconomicScenario[] {
  return getFromStorage<EconomicScenario>(STORAGE_KEYS.SCENARIOS);
}

export function saveScenarios(scenarios: EconomicScenario[]): void {
  saveToStorage(STORAGE_KEYS.SCENARIOS, scenarios);
}

export function getScenarioById(id: string): EconomicScenario | undefined {
  return getScenarios().find((scenario: EconomicScenario) => scenario.id === id);
}

export function filterScenarios(filter: ScenarioFilter): EconomicScenario[] {
  let scenarios = getScenarios();
  
  if (filter.parameterSetId) {
    scenarios = scenarios.filter((s: EconomicScenario) => s.parameterSetId === filter.parameterSetId);
  }
  if (filter.tag) {
    scenarios = scenarios.filter((s: EconomicScenario) => 
      s.seoHashtags?.includes(filter.tag as string)
    );
  }
  
  return scenarios;
}
