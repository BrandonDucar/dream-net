// DreamNet Economic Engine Utilities
// Diagram generation, economic briefs, and export functions

import type {
  Asset,
  EconomicRole,
  Pool,
  ValueFlow,
  ParameterSet,
  EconomicScenario,
} from '@/types/economic';
import {
  getAssetById,
  getRoleById,
  getPoolById,
  getFlowById,
  getParameterSetById,
  getScenarioById,
  getAssets,
  getPools,
  getRoles,
  getFlows,
  getParameterSets,
  getScenarios,
} from './economic-storage';

// Generate SEO metadata from entity
export function generateSEO(name: string, description: string, tags: string[]) {
  return {
    seoTitle: `${name} | DreamNet Economics`,
    seoDescription: description.slice(0, 160),
    seoKeywords: tags.length > 0 ? tags : [name.toLowerCase()],
    seoHashtags: tags.map((tag: string) => `#${tag.replace(/\s+/g, '')}`),
    altText: name,
  };
}

// Generate Value Flow Diagram for a scenario
export function generateValueFlowDiagram(scenarioId: string): string {
  const scenario = getScenarioById(scenarioId);
  if (!scenario) return 'Scenario not found';

  const paramSet = getParameterSetById(scenario.parameterSetId);
  const activeFlows = scenario.activeFlowIds
    .map((id: string) => getFlowById(id))
    .filter((flow): flow is ValueFlow => flow !== undefined);

  let diagram = `╔════════════════════════════════════════════════════════════╗\n`;
  diagram += `║  DREAMNET VALUE FLOW DIAGRAM                               ║\n`;
  diagram += `║  Scenario: ${scenario.name.padEnd(48)}║\n`;
  diagram += `╚════════════════════════════════════════════════════════════╝\n\n`;

  diagram += `📋 Description: ${scenario.description}\n`;
  if (paramSet) {
    diagram += `⚙️  Parameter Set: ${paramSet.name}\n\n`;
  }

  // Group flows by asset
  const flowsByAsset = activeFlows.reduce((acc: Record<string, ValueFlow[]>, flow: ValueFlow) => {
    if (!acc[flow.assetId]) {
      acc[flow.assetId] = [];
    }
    acc[flow.assetId].push(flow);
    return acc;
  }, {});

  Object.entries(flowsByAsset).forEach(([assetId, flows]) => {
    const asset = getAssetById(assetId);
    if (!asset) return;

    diagram += `\n${'═'.repeat(60)}\n`;
    diagram += `💎 ASSET: ${asset.name} (${asset.code})\n`;
    diagram += `   Type: ${asset.assetType}${asset.chain ? ` | Chain: ${asset.chain}` : ''}\n`;
    diagram += `${'═'.repeat(60)}\n\n`;

    flows.forEach((flow: ValueFlow) => {
      const fromRole = flow.fromRoleId ? getRoleById(flow.fromRoleId) : null;
      const toRole = flow.toRoleId ? getRoleById(flow.toRoleId) : null;
      const fromPool = flow.fromPoolId ? getPoolById(flow.fromPoolId) : null;
      const toPool = flow.toPoolId ? getPoolById(flow.toPoolId) : null;

      diagram += `  🔄 ${flow.name}\n`;
      diagram += `     Trigger: ${flow.trigger} | Frequency: ${flow.frequency}\n`;
      
      // Build flow path
      const fromStr = fromRole?.name || fromPool?.name || 'System';
      const toStr = toRole?.name || toPool?.name || 'System';
      
      diagram += `     ${fromStr} ──[ ${flow.formula} ]──> ${toStr}\n`;
      
      if (flow.description) {
        diagram += `     📝 ${flow.description}\n`;
      }
      diagram += `\n`;
    });
  });

  diagram += `\n${'═'.repeat(60)}\n`;
  diagram += `Generated: ${new Date().toLocaleString()}\n`;

  return diagram;
}

// Generate Economic Brief for a scenario
export function generateEconomicBrief(scenarioId: string): string {
  const scenario = getScenarioById(scenarioId);
  if (!scenario) return 'Scenario not found';

  const paramSet = getParameterSetById(scenario.parameterSetId);
  const activeFlows = scenario.activeFlowIds
    .map((id: string) => getFlowById(id))
    .filter((flow): flow is ValueFlow => flow !== undefined);

  let brief = `╔════════════════════════════════════════════════════════════╗\n`;
  brief += `║  DREAMNET ECONOMIC BRIEF                                   ║\n`;
  brief += `║  ${scenario.name.padEnd(58)}║\n`;
  brief += `╚════════════════════════════════════════════════════════════╝\n\n`;

  // Executive Summary
  brief += `📊 EXECUTIVE SUMMARY\n`;
  brief += `${'─'.repeat(60)}\n`;
  brief += `${scenario.description}\n\n`;
  
  if (paramSet) {
    brief += `This scenario operates under the "${paramSet.name}" parameter configuration.\n\n`;
  }

  // Assets
  const assetIds = new Set(activeFlows.map((f: ValueFlow) => f.assetId));
  const assets = Array.from(assetIds).map((id: string) => getAssetById(id)).filter((a): a is Asset => a !== undefined);

  brief += `\n💎 ASSETS IN CIRCULATION\n`;
  brief += `${'─'.repeat(60)}\n`;
  assets.forEach((asset: Asset) => {
    brief += `  • ${asset.name} (${asset.code})\n`;
    brief += `    Type: ${asset.assetType}\n`;
    brief += `    ${asset.description}\n`;
    if (asset.chain) {
      brief += `    Chain: ${asset.chain}\n`;
    }
    brief += `\n`;
  });

  // Pools
  const poolIds = new Set([
    ...activeFlows.filter((f: ValueFlow) => f.fromPoolId).map((f: ValueFlow) => f.fromPoolId as string),
    ...activeFlows.filter((f: ValueFlow) => f.toPoolId).map((f: ValueFlow) => f.toPoolId as string),
  ]);
  const pools = Array.from(poolIds).map((id: string) => getPoolById(id)).filter((p): p is Pool => p !== undefined);

  brief += `\n🏦 ECONOMIC POOLS\n`;
  brief += `${'─'.repeat(60)}\n`;
  pools.forEach((pool: Pool) => {
    brief += `  • ${pool.name} [${pool.poolType}]\n`;
    brief += `    ${pool.description}\n`;
    if (pool.sourceOfFunds.length > 0) {
      brief += `    Sources: ${pool.sourceOfFunds.join(', ')}\n`;
    }
    if (pool.usageOfFunds.length > 0) {
      brief += `    Usage: ${pool.usageOfFunds.join(', ')}\n`;
    }
    brief += `\n`;
  });

  // Roles
  const roleIds = new Set([
    ...activeFlows.filter((f: ValueFlow) => f.fromRoleId).map((f: ValueFlow) => f.fromRoleId as string),
    ...activeFlows.filter((f: ValueFlow) => f.toRoleId).map((f: ValueFlow) => f.toRoleId as string),
  ]);
  const roles = Array.from(roleIds).map((id: string) => getRoleById(id)).filter((r): r is EconomicRole => r !== undefined);

  brief += `\n👥 ECONOMIC ROLES\n`;
  brief += `${'─'.repeat(60)}\n`;
  roles.forEach((role: EconomicRole) => {
    brief += `  • ${role.name}\n`;
    brief += `    ${role.description}\n`;
    if (role.typicalActions.length > 0) {
      brief += `    Actions: ${role.typicalActions.join('; ')}\n`;
    }
    brief += `\n`;
  });

  // Value Flow Summary
  brief += `\n🔄 VALUE FLOW MECHANICS\n`;
  brief += `${'─'.repeat(60)}\n`;
  brief += `This scenario defines ${activeFlows.length} active value flows:\n\n`;
  
  const triggerCounts: Record<string, number> = {};
  activeFlows.forEach((flow: ValueFlow) => {
    triggerCounts[flow.trigger] = (triggerCounts[flow.trigger] || 0) + 1;
  });
  
  Object.entries(triggerCounts).forEach(([trigger, count]) => {
    brief += `  • ${count} flows triggered by: ${trigger}\n`;
  });

  // Incentive Analysis
  brief += `\n\n🎯 INCENTIVE ANALYSIS\n`;
  brief += `${'─'.repeat(60)}\n`;
  brief += `Key Incentives:\n`;
  
  roles.forEach((role: EconomicRole) => {
    const incomingFlows = activeFlows.filter((f: ValueFlow) => f.toRoleId === role.id);
    const outgoingFlows = activeFlows.filter((f: ValueFlow) => f.fromRoleId === role.id);
    
    if (incomingFlows.length > 0 || outgoingFlows.length > 0) {
      brief += `\n  ${role.name}:\n`;
      if (incomingFlows.length > 0) {
        brief += `    ✅ Earns from: ${incomingFlows.map((f: ValueFlow) => f.trigger).join(', ')}\n`;
      }
      if (outgoingFlows.length > 0) {
        brief += `    💸 Pays for: ${outgoingFlows.map((f: ValueFlow) => f.trigger).join(', ')}\n`;
      }
    }
  });

  // Risk & Abuse Points
  brief += `\n\n⚠️  RISK & ABUSE CONSIDERATIONS\n`;
  brief += `${'─'.repeat(60)}\n`;
  brief += `Potential risks to monitor:\n\n`;
  
  // Check for high-frequency flows
  const perEventFlows = activeFlows.filter((f: ValueFlow) => f.frequency === 'per-event');
  if (perEventFlows.length > 0) {
    brief += `  • ${perEventFlows.length} per-event flows may enable spam or gaming\n`;
  }
  
  // Check for manual flows
  const manualFlows = activeFlows.filter((f: ValueFlow) => f.trigger === 'manual');
  if (manualFlows.length > 0) {
    brief += `  • ${manualFlows.length} manual flows require governance oversight\n`;
  }
  
  // Check for pools with no sources or usage
  const emptySourcePools = pools.filter((p: Pool) => p.sourceOfFunds.length === 0);
  if (emptySourcePools.length > 0) {
    brief += `  • ${emptySourcePools.length} pools have undefined funding sources\n`;
  }

  brief += `\n${'═'.repeat(60)}\n`;
  brief += `Generated: ${new Date().toLocaleString()}\n`;
  brief += `DreamNet Economic Engine v1.0\n`;

  return brief;
}

// Export complete tokenomics documentation
export function exportTokenomicsDoc(): string {
  const assets = getAssets();
  const pools = getPools();
  const roles = getRoles();
  const flows = getFlows();
  const paramSets = getParameterSets();
  const scenarios = getScenarios();

  let doc = `╔════════════════════════════════════════════════════════════╗\n`;
  doc += `║  DREAMNET ECONOMIC & TOKENOMICS DOCUMENTATION              ║\n`;
  doc += `║  Complete System Design                                    ║\n`;
  doc += `╚════════════════════════════════════════════════════════════╝\n\n`;

  doc += `Generated: ${new Date().toLocaleString()}\n`;
  doc += `Version: 1.0\n\n`;

  // Assets
  doc += `\n${'═'.repeat(60)}\n`;
  doc += `💎 ASSETS (${assets.length} total)\n`;
  doc += `${'═'.repeat(60)}\n\n`;
  
  assets.forEach((asset: Asset) => {
    doc += `${asset.name} (${asset.code})\n`;
    doc += `${'─'.repeat(60)}\n`;
    doc += `Type: ${asset.assetType}\n`;
    doc += `Chain: ${asset.chain || 'Off-chain'}\n`;
    doc += `Primary Asset: ${asset.isPrimary}\n`;
    doc += `Description: ${asset.description}\n`;
    doc += `Unit: ${asset.unitDescription}\n`;
    if (asset.tags.length > 0) {
      doc += `Tags: ${asset.tags.join(', ')}\n`;
    }
    if (asset.notes) {
      doc += `Notes: ${asset.notes}\n`;
    }
    doc += `\n`;
  });

  // Pools
  doc += `\n${'═'.repeat(60)}\n`;
  doc += `🏦 POOLS (${pools.length} total)\n`;
  doc += `${'═'.repeat(60)}\n\n`;
  
  pools.forEach((pool: Pool) => {
    doc += `${pool.name} [${pool.poolType}]\n`;
    doc += `${'─'.repeat(60)}\n`;
    doc += `Description: ${pool.description}\n`;
    doc += `Assets: ${pool.assetIds.map((id: string) => getAssetById(id)?.code || id).join(', ')}\n`;
    if (pool.sourceOfFunds.length > 0) {
      doc += `Funding Sources:\n`;
      pool.sourceOfFunds.forEach((source: string) => {
        doc += `  • ${source}\n`;
      });
    }
    if (pool.usageOfFunds.length > 0) {
      doc += `Fund Usage:\n`;
      pool.usageOfFunds.forEach((usage: string) => {
        doc += `  • ${usage}\n`;
      });
    }
    if (pool.tags.length > 0) {
      doc += `Tags: ${pool.tags.join(', ')}\n`;
    }
    doc += `\n`;
  });

  // Roles
  doc += `\n${'═'.repeat(60)}\n`;
  doc += `👥 ECONOMIC ROLES (${roles.length} total)\n`;
  doc += `${'═'.repeat(60)}\n\n`;
  
  roles.forEach((role: EconomicRole) => {
    doc += `${role.name}\n`;
    doc += `${'─'.repeat(60)}\n`;
    doc += `Description: ${role.description}\n`;
    if (role.typicalActions.length > 0) {
      doc += `Typical Actions:\n`;
      role.typicalActions.forEach((action: string) => {
        doc += `  • ${action}\n`;
      });
    }
    if (role.tags.length > 0) {
      doc += `Tags: ${role.tags.join(', ')}\n`;
    }
    doc += `\n`;
  });

  // Value Flows
  doc += `\n${'═'.repeat(60)}\n`;
  doc += `🔄 VALUE FLOWS (${flows.length} total)\n`;
  doc += `${'═'.repeat(60)}\n\n`;
  
  flows.forEach((flow: ValueFlow) => {
    const asset = getAssetById(flow.assetId);
    const fromRole = flow.fromRoleId ? getRoleById(flow.fromRoleId) : null;
    const toRole = flow.toRoleId ? getRoleById(flow.toRoleId) : null;
    const fromPool = flow.fromPoolId ? getPoolById(flow.fromPoolId) : null;
    const toPool = flow.toPoolId ? getPoolById(flow.toPoolId) : null;

    doc += `${flow.name}\n`;
    doc += `${'─'.repeat(60)}\n`;
    doc += `Asset: ${asset?.name || 'Unknown'} (${asset?.code || flow.assetId})\n`;
    doc += `Flow: ${fromRole?.name || fromPool?.name || 'System'} → ${toRole?.name || toPool?.name || 'System'}\n`;
    doc += `Trigger: ${flow.trigger} | Frequency: ${flow.frequency}\n`;
    doc += `Formula: ${flow.formula}\n`;
    doc += `Description: ${flow.description}\n`;
    if (flow.notes) {
      doc += `Notes: ${flow.notes}\n`;
    }
    doc += `\n`;
  });

  // Parameter Sets
  doc += `\n${'═'.repeat(60)}\n`;
  doc += `⚙️  PARAMETER SETS (${paramSets.length} total)\n`;
  doc += `${'═'.repeat(60)}\n\n`;
  
  paramSets.forEach((set: ParameterSet) => {
    doc += `${set.name}\n`;
    doc += `${'─'.repeat(60)}\n`;
    doc += `Description: ${set.description}\n`;
    doc += `Parameters:\n`;
    Object.entries(set.values).forEach(([key, value]) => {
      doc += `  ${key}: ${value}\n`;
    });
    if (set.tags.length > 0) {
      doc += `Tags: ${set.tags.join(', ')}\n`;
    }
    doc += `\n`;
  });

  // Scenarios
  doc += `\n${'═'.repeat(60)}\n`;
  doc += `📊 ECONOMIC SCENARIOS (${scenarios.length} total)\n`;
  doc += `${'═'.repeat(60)}\n\n`;
  
  scenarios.forEach((scenario: EconomicScenario) => {
    const paramSet = getParameterSetById(scenario.parameterSetId);
    
    doc += `${scenario.name}\n`;
    doc += `${'─'.repeat(60)}\n`;
    doc += `Description: ${scenario.description}\n`;
    doc += `Parameter Set: ${paramSet?.name || 'Unknown'}\n`;
    doc += `Active Flows: ${scenario.activeFlowIds.length}\n`;
    if (scenario.notes) {
      doc += `Notes: ${scenario.notes}\n`;
    }
    doc += `\n`;
  });

  doc += `\n${'═'.repeat(60)}\n`;
  doc += `END OF DOCUMENTATION\n`;
  doc += `DreamNet Economic Engine v1.0\n`;

  return doc;
}
