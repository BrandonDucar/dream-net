// Extended Storage for New Features
// Storage functions for comments, workflows, KPIs, agent behaviors, etc.

import type {
  Comment,
  ApprovalWorkflow,
  KPIInput,
  AgentBehavior,
  VestingSchedule,
  UnlockEvent,
  SeasonalEvent,
  AssetRelationship,
} from '@/types/economic-extended';

const STORAGE_KEYS = {
  COMMENTS: 'dreamnet_comments',
  WORKFLOWS: 'dreamnet_workflows',
  KPIS: 'dreamnet_kpis',
  AGENT_BEHAVIORS: 'dreamnet_agent_behaviors',
  VESTING: 'dreamnet_vesting',
  UNLOCKS: 'dreamnet_unlocks',
  SEASONAL: 'dreamnet_seasonal',
  RELATIONSHIPS: 'dreamnet_relationships',
} as const;

// Generic storage functions
function getFromStorage<T>(key: string): T[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

function saveToStorage<T>(key: string, data: T[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(key, JSON.stringify(data));
}

// ============================================================================
// COMMENTS (Feature 13)
// ============================================================================

export function getComments(): Comment[] {
  return getFromStorage<Comment>(STORAGE_KEYS.COMMENTS);
}

export function saveComments(comments: Comment[]): void {
  saveToStorage(STORAGE_KEYS.COMMENTS, comments);
}

export function addComment(comment: Omit<Comment, 'id'>): Comment {
  const newComment: Comment = {
    ...comment,
    id: `comment_${Date.now()}`,
  };
  
  const comments = getComments();
  comments.push(newComment);
  saveComments(comments);
  
  return newComment;
}

export function getCommentsByEntity(entityType: string, entityId: string): Comment[] {
  return getComments().filter((c: Comment) => 
    c.entityType === entityType && c.entityId === entityId
  );
}

export function resolveComment(commentId: string): void {
  const comments = getComments();
  const comment = comments.find((c: Comment) => c.id === commentId);
  if (comment) {
    comment.resolved = true;
    saveComments(comments);
  }
}

// ============================================================================
// APPROVAL WORKFLOWS (Feature 13)
// ============================================================================

export function getWorkflows(): ApprovalWorkflow[] {
  return getFromStorage<ApprovalWorkflow>(STORAGE_KEYS.WORKFLOWS);
}

export function saveWorkflows(workflows: ApprovalWorkflow[]): void {
  saveToStorage(STORAGE_KEYS.WORKFLOWS, workflows);
}

export function createWorkflow(workflow: Omit<ApprovalWorkflow, 'id' | 'createdAt' | 'updatedAt'>): ApprovalWorkflow {
  const newWorkflow: ApprovalWorkflow = {
    ...workflow,
    id: `workflow_${Date.now()}`,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  
  const workflows = getWorkflows();
  workflows.push(newWorkflow);
  saveWorkflows(workflows);
  
  return newWorkflow;
}

// ============================================================================
// KPI INPUTS (Feature 3)
// ============================================================================

export function getKPIs(): KPIInput[] {
  return getFromStorage<KPIInput>(STORAGE_KEYS.KPIS);
}

export function saveKPIs(kpis: KPIInput[]): void {
  saveToStorage(STORAGE_KEYS.KPIS, kpis);
}

export function addKPI(kpi: Omit<KPIInput, 'id'>): KPIInput {
  const newKPI: KPIInput = {
    ...kpi,
    id: `kpi_${Date.now()}`,
  };
  
  const kpis = getKPIs();
  kpis.push(newKPI);
  saveKPIs(kpis);
  
  return newKPI;
}

// ============================================================================
// AGENT BEHAVIORS (Feature 14)
// ============================================================================

export function getAgentBehaviors(): AgentBehavior[] {
  return getFromStorage<AgentBehavior>(STORAGE_KEYS.AGENT_BEHAVIORS);
}

export function saveAgentBehaviors(behaviors: AgentBehavior[]): void {
  saveToStorage(STORAGE_KEYS.AGENT_BEHAVIORS, behaviors);
}

export function addAgentBehavior(behavior: Omit<AgentBehavior, 'id'>): AgentBehavior {
  const newBehavior: AgentBehavior = {
    ...behavior,
    id: `behavior_${Date.now()}`,
  };
  
  const behaviors = getAgentBehaviors();
  behaviors.push(newBehavior);
  saveAgentBehaviors(behaviors);
  
  return newBehavior;
}

// ============================================================================
// VESTING SCHEDULES (Feature 9)
// ============================================================================

export function getVestingSchedules(): VestingSchedule[] {
  return getFromStorage<VestingSchedule>(STORAGE_KEYS.VESTING);
}

export function saveVestingSchedules(schedules: VestingSchedule[]): void {
  saveToStorage(STORAGE_KEYS.VESTING, schedules);
}

export function addVestingSchedule(schedule: Omit<VestingSchedule, 'id'>): VestingSchedule {
  const newSchedule: VestingSchedule = {
    ...schedule,
    id: `vesting_${Date.now()}`,
  };
  
  const schedules = getVestingSchedules();
  schedules.push(newSchedule);
  saveVestingSchedules(schedules);
  
  return newSchedule;
}

// ============================================================================
// UNLOCK EVENTS (Feature 9)
// ============================================================================

export function getUnlockEvents(): UnlockEvent[] {
  return getFromStorage<UnlockEvent>(STORAGE_KEYS.UNLOCKS);
}

export function saveUnlockEvents(events: UnlockEvent[]): void {
  saveToStorage(STORAGE_KEYS.UNLOCKS, events);
}

export function addUnlockEvent(event: Omit<UnlockEvent, 'id'>): UnlockEvent {
  const newEvent: UnlockEvent = {
    ...event,
    id: `unlock_${Date.now()}`,
  };
  
  const events = getUnlockEvents();
  events.push(newEvent);
  saveUnlockEvents(events);
  
  return newEvent;
}

// ============================================================================
// SEASONAL EVENTS (Feature 9)
// ============================================================================

export function getSeasonalEvents(): SeasonalEvent[] {
  return getFromStorage<SeasonalEvent>(STORAGE_KEYS.SEASONAL);
}

export function saveSeasonalEvents(events: SeasonalEvent[]): void {
  saveToStorage(STORAGE_KEYS.SEASONAL, events);
}

export function addSeasonalEvent(event: Omit<SeasonalEvent, 'id'>): SeasonalEvent {
  const newEvent: SeasonalEvent = {
    ...event,
    id: `seasonal_${Date.now()}`,
  };
  
  const events = getSeasonalEvents();
  events.push(newEvent);
  saveSeasonalEvents(events);
  
  return newEvent;
}

// ============================================================================
// ASSET RELATIONSHIPS (Feature 10)
// ============================================================================

export function getAssetRelationships(): AssetRelationship[] {
  return getFromStorage<AssetRelationship>(STORAGE_KEYS.RELATIONSHIPS);
}

export function saveAssetRelationships(relationships: AssetRelationship[]): void {
  saveToStorage(STORAGE_KEYS.RELATIONSHIPS, relationships);
}

export function addAssetRelationship(relationship: Omit<AssetRelationship, 'id'>): AssetRelationship {
  const newRelationship: AssetRelationship = {
    ...relationship,
    id: `relationship_${Date.now()}`,
  };
  
  const relationships = getAssetRelationships();
  relationships.push(newRelationship);
  saveAssetRelationships(relationships);
  
  return newRelationship;
}

export function getRelationshipsByAsset(assetId: string): AssetRelationship[] {
  return getAssetRelationships().filter((r: AssetRelationship) => 
    r.fromAssetId === assetId || r.toAssetId === assetId
  );
}
