// Math Expression Parser (Feature 15)
// Parse and evaluate mathematical formulas with variables

export function parseFormula(formula: string, variables: Record<string, number>): number {
  try {
    // Replace variables with their values
    let expression = formula.toLowerCase();
    
    // Handle percentage expressions (e.g., "10% of mint_price")
    expression = expression.replace(/(\d+\.?\d*)%\s*of\s*(\w+)/gi, (match, pct, varName) => {
      const value = variables[varName] || 0;
      return `(${parseFloat(pct)} / 100 * ${value})`;
    });

    // Replace variable names with their values
    Object.entries(variables).forEach(([key, value]) => {
      const regex = new RegExp(`\\b${key}\\b`, 'gi');
      expression = expression.replace(regex, value.toString());
    });

    // Clean up common text patterns
    expression = expression.replace(/\bper\b/gi, '/');
    expression = expression.replace(/\bflat\b/gi, '');
    expression = expression.replace(/\btokens?\b/gi, '');
    expression = expression.replace(/\bunits?\b/gi, '');

    // Extract mathematical expression
    const mathMatch = expression.match(/[\d\s+\-*/().]+/);
    if (!mathMatch) {
      // Try to extract just a number
      const numberMatch = formula.match(/(\d+\.?\d*)/);
      if (numberMatch) {
        return parseFloat(numberMatch[1]);
      }
      return 0;
    }

    // Evaluate the expression safely
    const result = evaluateMath(mathMatch[0]);
    return isNaN(result) ? 0 : result;
  } catch (error) {
    console.error('Formula parse error:', error);
    return 0;
  }
}

function evaluateMath(expression: string): number {
  // Remove spaces
  expression = expression.replace(/\s+/g, '');
  
  // Validate expression (only allow numbers, operators, parentheses)
  if (!/^[\d+\-*/().]+$/.test(expression)) {
    throw new Error('Invalid mathematical expression');
  }

  try {
    // Use Function constructor for safe evaluation
    // This is safer than eval() and still allows math operations
    const fn = new Function('return ' + expression);
    return fn();
  } catch {
    return 0;
  }
}

// Validate formula syntax
export function validateFormula(formula: string): { valid: boolean; error?: string } {
  try {
    parseFormula(formula, {});
    return { valid: true };
  } catch (error) {
    return {
      valid: false,
      error: error instanceof Error ? error.message : 'Invalid formula',
    };
  }
}

// Extract variables from formula
export function extractVariables(formula: string): string[] {
  const variables: Set<string> = new Set();
  
  // Match word characters that aren't numbers
  const matches = formula.match(/\b[a-z_]\w*\b/gi);
  if (matches) {
    matches.forEach((match: string) => {
      // Exclude common words
      if (!['of', 'per', 'flat', 'token', 'tokens', 'unit', 'units'].includes(match.toLowerCase())) {
        variables.add(match.toLowerCase());
      }
    });
  }
  
  return Array.from(variables);
}

// Format number as human-readable
export function formatNumber(value: number): string {
  if (value >= 1_000_000_000) {
    return `${(value / 1_000_000_000).toFixed(2)}B`;
  } else if (value >= 1_000_000) {
    return `${(value / 1_000_000).toFixed(2)}M`;
  } else if (value >= 1_000) {
    return `${(value / 1_000).toFixed(2)}K`;
  }
  return value.toFixed(2);
}
