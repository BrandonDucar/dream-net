// Network Graph Generator (Feature 19)
// Generate network visualization data from economic scenario

import type { NetworkGraph, NetworkNode, NetworkEdge } from '@/types/economic-extended';
import { getScenarioById, getFlowById, getAssetById, getPoolById, getRoleById } from './economic-storage';

export function generateNetworkGraph(scenarioId: string): NetworkGraph {
  const scenario = getScenarioById(scenarioId);
  if (!scenario) {
    throw new Error('Scenario not found');
  }

  const nodes: NetworkNode[] = [];
  const edges: NetworkEdge[] = [];
  const nodeIds = new Set<string>();

  const activeFlows = scenario.activeFlowIds
    .map((id: string) => getFlowById(id))
    .filter((flow) => flow !== undefined);

  // Collect all unique entities (pools and roles)
  activeFlows.forEach((flow) => {
    if (flow.fromPoolId && !nodeIds.has(flow.fromPoolId)) {
      const pool = getPoolById(flow.fromPoolId);
      if (pool) {
        nodes.push({
          id: pool.id,
          type: 'pool',
          name: pool.name,
          size: 50, // Base size
          color: getPoolColor(pool.poolType),
          metadata: {
            poolType: pool.poolType,
            assetCount: pool.assetIds.length,
          },
        });
        nodeIds.add(pool.id);
      }
    }

    if (flow.toPoolId && !nodeIds.has(flow.toPoolId)) {
      const pool = getPoolById(flow.toPoolId);
      if (pool) {
        nodes.push({
          id: pool.id,
          type: 'pool',
          name: pool.name,
          size: 50,
          color: getPoolColor(pool.poolType),
          metadata: {
            poolType: pool.poolType,
            assetCount: pool.assetIds.length,
          },
        });
        nodeIds.add(pool.id);
      }
    }

    if (flow.fromRoleId && !nodeIds.has(flow.fromRoleId)) {
      const role = getRoleById(flow.fromRoleId);
      if (role) {
        nodes.push({
          id: role.id,
          type: 'role',
          name: role.name,
          size: 40,
          color: '#3b82f6',
          metadata: {
            actions: role.typicalActions.length,
          },
        });
        nodeIds.add(role.id);
      }
    }

    if (flow.toRoleId && !nodeIds.has(flow.toRoleId)) {
      const role = getRoleById(flow.toRoleId);
      if (role) {
        nodes.push({
          id: role.id,
          type: 'role',
          name: role.name,
          size: 40,
          color: '#3b82f6',
          metadata: {
            actions: role.typicalActions.length,
          },
        });
        nodeIds.add(role.id);
      }
    }

    // Add asset nodes
    if (!nodeIds.has(flow.assetId)) {
      const asset = getAssetById(flow.assetId);
      if (asset) {
        nodes.push({
          id: asset.id,
          type: 'asset',
          name: asset.name,
          size: 30,
          color: '#10b981',
          metadata: {
            code: asset.code,
            assetType: asset.assetType,
          },
        });
        nodeIds.add(asset.id);
      }
    }
  });

  // Create edges from flows
  activeFlows.forEach((flow) => {
    const sourceId = flow.fromPoolId || flow.fromRoleId;
    const targetId = flow.toPoolId || flow.toRoleId;

    if (sourceId && targetId) {
      edges.push({
        id: flow.id,
        source: sourceId,
        target: targetId,
        label: flow.name,
        weight: getFlowWeight(flow.formula),
        color: getFlowColor(flow.trigger),
        metadata: {
          trigger: flow.trigger,
          frequency: flow.frequency,
          formula: flow.formula,
        },
      });
    }
  });

  // Calculate statistics
  const statistics = calculateNetworkStatistics(nodes, edges);

  return {
    nodes,
    edges,
    statistics,
  };
}

function getPoolColor(poolType: string): string {
  const colors: Record<string, string> = {
    treasury: '#eab308',
    rewards: '#22c55e',
    fees: '#ef4444',
    liquidity: '#3b82f6',
    reserve: '#8b5cf6',
    escrow: '#f97316',
    other: '#64748b',
  };
  return colors[poolType] || colors.other;
}

function getFlowColor(trigger: string): string {
  const colors: Record<string, string> = {
    mint: '#10b981',
    trade: '#3b82f6',
    'badge-earned': '#8b5cf6',
    participation: '#22c55e',
    donation: '#f59e0b',
    manual: '#6b7280',
    other: '#64748b',
  };
  return colors[trigger] || colors.other;
}

function getFlowWeight(formula: string): number {
  // Try to extract a number from the formula
  const match = formula.match(/(\d+\.?\d*)/);
  if (match) {
    const num = parseFloat(match[1]);
    return Math.min(num / 10, 10); // Normalize to 1-10 range
  }
  return 1;
}

function calculateNetworkStatistics(nodes: NetworkNode[], edges: NetworkEdge[]): {
  totalNodes: number;
  totalEdges: number;
  centralNodes: string[];
  bottlenecks: string[];
  isolatedNodes: string[];
} {
  const totalNodes = nodes.length;
  const totalEdges = edges.length;

  // Calculate degree (connections) for each node
  const degree: Record<string, number> = {};
  nodes.forEach((node: NetworkNode) => {
    degree[node.id] = 0;
  });

  edges.forEach((edge: NetworkEdge) => {
    degree[edge.source] = (degree[edge.source] || 0) + 1;
    degree[edge.target] = (degree[edge.target] || 0) + 1;
  });

  // Find central nodes (high degree)
  const avgDegree = totalEdges * 2 / totalNodes;
  const centralNodes = Object.entries(degree)
    .filter(([_, deg]) => deg > avgDegree * 1.5)
    .map(([id, _]) => id);

  // Find bottlenecks (nodes with high betweenness - simplified as high degree with asymmetric in/out)
  const inDegree: Record<string, number> = {};
  const outDegree: Record<string, number> = {};
  edges.forEach((edge: NetworkEdge) => {
    outDegree[edge.source] = (outDegree[edge.source] || 0) + 1;
    inDegree[edge.target] = (inDegree[edge.target] || 0) + 1;
  });

  const bottlenecks = Object.keys(degree).filter((id: string) => {
    const inD = inDegree[id] || 0;
    const outD = outDegree[id] || 0;
    return Math.abs(inD - outD) > 2 && degree[id] > 2;
  });

  // Find isolated nodes (degree 0)
  const isolatedNodes = Object.entries(degree)
    .filter(([_, deg]) => deg === 0)
    .map(([id, _]) => id);

  return {
    totalNodes,
    totalEdges,
    centralNodes,
    bottlenecks,
    isolatedNodes,
  };
}
