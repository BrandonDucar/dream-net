// Risk Analysis Engine (Features 4, 5, 16, 18)
// Detects risks, validates balance, finds feedback loops, analyzes death spirals

import type {
  RiskAnalysis,
  Risk,
  BalanceCheck,
  FeedbackLoop,
  DeathSpiralAnalysis,
} from '@/types/economic-extended';
import type { EconomicScenario, ValueFlow, Pool } from '@/types/economic';
import {
  getScenarioById,
  getFlowById,
  getPoolById,
  getAssetById,
  getRoleById,
} from './economic-storage';

export function analyzeScenarioRisks(scenarioId: string): RiskAnalysis {
  const scenario = getScenarioById(scenarioId);
  if (!scenario) {
    throw new Error('Scenario not found');
  }

  const activeFlows = scenario.activeFlowIds
    .map((id: string) => getFlowById(id))
    .filter((flow): flow is ValueFlow => flow !== undefined);

  const risks = detectRisks(scenario, activeFlows);
  const balanceCheck = validateBalance(activeFlows);
  const feedbackLoops = detectFeedbackLoops(activeFlows);
  const deathSpiralRisk = analyzeDeathSpiral(scenario, activeFlows);

  return {
    scenarioId,
    timestamp: Date.now(),
    risks,
    balanceCheck,
    feedbackLoops,
    deathSpiralRisk,
  };
}

// Feature 4: Risk Detection
function detectRisks(scenario: EconomicScenario, flows: ValueFlow[]): Risk[] {
  const risks: Risk[] = [];

  // Check for high-frequency per-event flows (spam risk)
  const perEventFlows = flows.filter((f: ValueFlow) => f.frequency === 'per-event');
  if (perEventFlows.length > 5) {
    risks.push({
      id: `risk_spam_${Date.now()}`,
      severity: 'medium',
      category: 'spam',
      title: 'High Spam/Gaming Risk',
      description: `${perEventFlows.length} flows trigger per-event, which may enable spam attacks or gaming behavior.`,
      affectedEntities: perEventFlows.map((f: ValueFlow) => ({
        type: 'flow',
        id: f.id,
        name: f.name,
      })),
      mitigation: 'Add rate limiting, cooldowns, or require staking to participate',
      autoDetected: true,
    });
  }

  // Check for manual flows (governance risk)
  const manualFlows = flows.filter((f: ValueFlow) => f.trigger === 'manual');
  if (manualFlows.length > 0) {
    risks.push({
      id: `risk_governance_${Date.now()}`,
      severity: 'low',
      category: 'governance',
      title: 'Manual Flow Governance',
      description: `${manualFlows.length} manual flows require ongoing governance oversight.`,
      affectedEntities: manualFlows.map((f: ValueFlow) => ({
        type: 'flow',
        id: f.id,
        name: f.name,
      })),
      mitigation: 'Establish clear governance processes and approval workflows',
      autoDetected: true,
    });
  }

  // Check for pools with no defined sources
  const poolIds = new Set([
    ...flows.filter((f: ValueFlow) => f.fromPoolId).map((f: ValueFlow) => f.fromPoolId as string),
    ...flows.filter((f: ValueFlow) => f.toPoolId).map((f: ValueFlow) => f.toPoolId as string),
  ]);

  const emptySourcePools: Pool[] = [];
  poolIds.forEach((poolId: string) => {
    const pool = getPoolById(poolId);
    if (pool && pool.sourceOfFunds.length === 0) {
      emptySourcePools.push(pool);
    }
  });

  if (emptySourcePools.length > 0) {
    risks.push({
      id: `risk_undefined_${Date.now()}`,
      severity: 'medium',
      category: 'undefined',
      title: 'Undefined Funding Sources',
      description: `${emptySourcePools.length} pools have no defined funding sources.`,
      affectedEntities: emptySourcePools.map((p: Pool) => ({
        type: 'pool',
        id: p.id,
        name: p.name,
      })),
      mitigation: 'Define clear funding sources for all pools',
      autoDetected: true,
    });
  }

  // Check for potential inflation (more inflows than outflows)
  const inflowCount = flows.filter((f: ValueFlow) => f.toPoolId !== null).length;
  const outflowCount = flows.filter((f: ValueFlow) => f.fromPoolId !== null).length;
  
  if (inflowCount > outflowCount * 2) {
    risks.push({
      id: `risk_inflation_${Date.now()}`,
      severity: 'high',
      category: 'inflation',
      title: 'Potential Inflation Risk',
      description: `System has ${inflowCount} inflows but only ${outflowCount} outflows, suggesting inflationary pressure.`,
      affectedEntities: [],
      mitigation: 'Add burn mechanisms, fees, or other value sinks',
      autoDetected: true,
    });
  }

  // Check for pools with only outflows (depletion risk)
  poolIds.forEach((poolId: string) => {
    const inflows = flows.filter((f: ValueFlow) => f.toPoolId === poolId);
    const outflows = flows.filter((f: ValueFlow) => f.fromPoolId === poolId);
    
    if (outflows.length > 0 && inflows.length === 0) {
      const pool = getPoolById(poolId);
      risks.push({
        id: `risk_depletion_${poolId}`,
        severity: 'critical',
        category: 'depletion',
        title: 'Pool Depletion Risk',
        description: `Pool "${pool?.name}" has outflows but no inflows and will eventually deplete.`,
        affectedEntities: [{
          type: 'pool',
          id: poolId,
          name: pool?.name || poolId,
        }],
        mitigation: 'Add funding sources or reduce/remove outflows',
        autoDetected: true,
      });
    }
  });

  return risks;
}

// Feature 5: Balance Validation
function validateBalance(flows: ValueFlow[]): BalanceCheck {
  const issues: Array<{
    type: 'leak' | 'source-missing' | 'sink-missing' | 'circular';
    severity: 'low' | 'medium' | 'high';
    description: string;
    affectedPools: string[];
  }> = [];

  // Build flow graph
  const poolIds = new Set<string>();
  flows.forEach((flow: ValueFlow) => {
    if (flow.fromPoolId) poolIds.add(flow.fromPoolId);
    if (flow.toPoolId) poolIds.add(flow.toPoolId);
  });

  // Check each pool
  poolIds.forEach((poolId: string) => {
    const inflows = flows.filter((f: ValueFlow) => f.toPoolId === poolId);
    const outflows = flows.filter((f: ValueFlow) => f.fromPoolId === poolId);
    const pool = getPoolById(poolId);

    // Leak detection: only outflows, no inflows
    if (outflows.length > 0 && inflows.length === 0) {
      issues.push({
        type: 'leak',
        severity: 'high',
        description: `Pool "${pool?.name}" has outflows but no inflows (will deplete)`,
        affectedPools: [poolId],
      });
    }

    // Source missing: no clear funding
    if (inflows.length === 0 && pool && pool.sourceOfFunds.length === 0) {
      issues.push({
        type: 'source-missing',
        severity: 'medium',
        description: `Pool "${pool.name}" has no defined funding sources`,
        affectedPools: [poolId],
      });
    }

    // Sink missing: only inflows, no outflows (accumulates forever)
    if (inflows.length > 0 && outflows.length === 0 && pool?.poolType !== 'treasury') {
      issues.push({
        type: 'sink-missing',
        severity: 'low',
        description: `Pool "${pool?.name}" accumulates value but has no outflows`,
        affectedPools: [poolId],
      });
    }
  });

  // Circular flow detection
  const circular = detectCircularFlows(flows);
  if (circular.length > 0) {
    issues.push({
      type: 'circular',
      severity: 'medium',
      description: `Detected ${circular.length} circular flow patterns`,
      affectedPools: circular.flat(),
    });
  }

  return {
    isBalanced: issues.length === 0,
    issues,
  };
}

function detectCircularFlows(flows: ValueFlow[]): string[][] {
  const circular: string[][] = [];
  const visited = new Set<string>();
  const recursionStack = new Set<string>();

  const poolIds = new Set<string>();
  flows.forEach((flow: ValueFlow) => {
    if (flow.fromPoolId) poolIds.add(flow.fromPoolId);
    if (flow.toPoolId) poolIds.add(flow.toPoolId);
  });

  function dfs(poolId: string, path: string[]): void {
    visited.add(poolId);
    recursionStack.add(poolId);
    path.push(poolId);

    const outflows = flows.filter((f: ValueFlow) => f.fromPoolId === poolId);
    outflows.forEach((flow: ValueFlow) => {
      if (flow.toPoolId) {
        if (recursionStack.has(flow.toPoolId)) {
          // Found circular path
          const circleStart = path.indexOf(flow.toPoolId);
          if (circleStart >= 0) {
            circular.push(path.slice(circleStart));
          }
        } else if (!visited.has(flow.toPoolId)) {
          dfs(flow.toPoolId, [...path]);
        }
      }
    });

    recursionStack.delete(poolId);
  }

  poolIds.forEach((poolId: string) => {
    if (!visited.has(poolId)) {
      dfs(poolId, []);
    }
  });

  return circular;
}

// Feature 16: Feedback Loop Detection
function detectFeedbackLoops(flows: ValueFlow[]): FeedbackLoop[] {
  const loops: FeedbackLoop[] = [];
  const circularPaths = detectCircularFlows(flows);

  circularPaths.forEach((path: string[], idx: number) => {
    const loopFlows = flows.filter((f: ValueFlow) => 
      path.includes(f.fromPoolId || '') && path.includes(f.toPoolId || '')
    );

    // Determine if stabilizing or destabilizing
    const type = loopFlows.length > 3 ? 'destabilizing' : 'stabilizing';
    
    loops.push({
      id: `loop_${idx}`,
      flows: loopFlows.map((f: ValueFlow) => f.id),
      type,
      strength: loopFlows.length / flows.length,
      description: `Circular flow through ${path.length} pools`,
    });
  });

  return loops;
}

// Feature 18: Death Spiral Detection
function analyzeDeathSpiral(scenario: EconomicScenario, flows: ValueFlow[]): DeathSpiralAnalysis {
  const scenarios: Array<{
    trigger: string;
    cascade: string[];
    mitigation: string;
  }> = [];

  // Scenario 1: User exodus
  scenarios.push({
    trigger: 'Major user exodus (50% drop in activity)',
    cascade: [
      'Reduced participation flows',
      'Rewards pool continues draining',
      'No new revenue to refill pools',
      'Remaining users see reduced rewards',
      'Further user churn',
    ],
    mitigation: 'Implement dynamic reward rates that adjust to activity levels',
  });

  // Scenario 2: Token price crash
  scenarios.push({
    trigger: 'Token price crash (80% decline)',
    cascade: [
      'Reduced staking incentive',
      'Mass unstaking',
      'Liquidity pool depletion',
      'Further price decline',
      'Platform revenue collapse',
    ],
    mitigation: 'Build non-token revenue streams and minimum liquidity requirements',
  });

  // Scenario 3: Governance attack
  scenarios.push({
    trigger: 'Governance capture or attack',
    cascade: [
      'Malicious proposals drain treasury',
      'Community loses trust',
      'Token dump',
      'Platform becomes unusable',
    ],
    mitigation: 'Implement timelocks, veto powers, and quorum requirements',
  });

  // Check for circuit breakers in the design
  const circuitBreakers: string[] = [];
  
  const manualFlows = flows.filter((f: ValueFlow) => f.trigger === 'manual');
  if (manualFlows.length > 0) {
    circuitBreakers.push('Manual flow controls for emergency shutdown');
  }

  // Assess overall risk level
  const criticalFlows = flows.filter((f: ValueFlow) => 
    f.fromPoolId && !flows.some((inflow: ValueFlow) => inflow.toPoolId === f.fromPoolId)
  );
  
  let riskLevel: 'low' | 'medium' | 'high' | 'critical' = 'low';
  if (criticalFlows.length > 3) {
    riskLevel = 'high';
  } else if (criticalFlows.length > 1) {
    riskLevel = 'medium';
  }

  if (circuitBreakers.length === 0) {
    riskLevel = 'high';
  }

  return {
    riskLevel,
    scenarios,
    circuitBreakers,
  };
}
