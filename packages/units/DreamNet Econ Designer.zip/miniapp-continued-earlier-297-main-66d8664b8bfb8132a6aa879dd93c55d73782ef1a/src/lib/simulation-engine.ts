// Simulation Engine (Features 2, 3, 14, 17)
// Runs economic scenarios with real numbers over time

import type {
  SimulationConfig,
  SimulationResult,
  SimulationTimeStep,
  SimulationSummary,
  SimulationWarning,
  KPIInput,
  AgentBehavior,
} from '@/types/economic-extended';
import type { ValueFlow, EconomicScenario } from '@/types/economic';
import {
  getScenarioById,
  getFlowById,
  getAssetById,
  getPoolById,
  getRoleById,
} from './economic-storage';
import { parseFormula } from './math-parser';

export function runSimulation(config: SimulationConfig): SimulationResult {
  const scenario = getScenarioById(config.scenarioId);
  if (!scenario) {
    throw new Error('Scenario not found');
  }

  const timeSteps: SimulationTimeStep[] = [];
  const warnings: SimulationWarning[] = [];
  
  // Initialize pool balances
  let poolBalances: Record<string, number> = { ...config.startingBalances };
  const flowVolumes: Record<string, number> = {};
  
  // Get active flows
  const activeFlows = scenario.activeFlowIds
    .map((id: string) => getFlowById(id))
    .filter((flow): flow is ValueFlow => flow !== undefined);

  // Run simulation for each time step
  for (let step = 0; step < config.duration; step++) {
    const timestamp = Date.now() + step * getTimeUnitMillis(config.timeUnit);
    const events: string[] = [];
    const stepFlowVolumes: Record<string, number> = {};
    const kpiValues: Record<string, number> = {};

    // Calculate KPI values for this step
    config.kpiInputs.forEach((kpi: KPIInput) => {
      const value = calculateKPIValue(kpi, step, config.duration);
      kpiValues[kpi.id] = value;
    });

    // Process each active flow
    activeFlows.forEach((flow: ValueFlow) => {
      if (shouldFlowTrigger(flow, step, config.timeUnit)) {
        const amount = calculateFlowAmount(flow, kpiValues, poolBalances, config);
        
        if (amount > 0) {
          // Deduct from source
          if (flow.fromPoolId) {
            poolBalances[flow.fromPoolId] = (poolBalances[flow.fromPoolId] || 0) - amount;
            if (poolBalances[flow.fromPoolId] < 0) {
              warnings.push({
                severity: 'high',
                category: 'depletion',
                message: `Pool ${getPoolById(flow.fromPoolId)?.name} depleted at step ${step}`,
                affectedEntities: [flow.fromPoolId],
                suggestedAction: 'Increase pool funding or reduce outflows',
              });
            }
          }

          // Add to destination
          if (flow.toPoolId) {
            poolBalances[flow.toPoolId] = (poolBalances[flow.toPoolId] || 0) + amount;
          }

          // Track flow volume
          stepFlowVolumes[flow.id] = (stepFlowVolumes[flow.id] || 0) + amount;
          flowVolumes[flow.id] = (flowVolumes[flow.id] || 0) + amount;

          events.push(`${flow.name}: ${amount} units`);
        }
      }
    });

    // Process agent behaviors
    config.agentBehaviors.forEach((behavior: AgentBehavior) => {
      behavior.actions.forEach((action) => {
        if (shouldBehaviorTrigger(action.trigger, step, config.timeUnit)) {
          if (Math.random() < action.probability) {
            const amount = typeof action.amount === 'number' 
              ? action.amount 
              : parseFormula(action.amount, kpiValues);
            
            const flow = getFlowById(action.flowId);
            if (flow) {
              if (flow.fromPoolId) {
                poolBalances[flow.fromPoolId] = (poolBalances[flow.fromPoolId] || 0) - amount;
              }
              if (flow.toPoolId) {
                poolBalances[flow.toPoolId] = (poolBalances[flow.toPoolId] || 0) + amount;
              }
              flowVolumes[flow.id] = (flowVolumes[flow.id] || 0) + amount;
              events.push(`Agent ${behavior.name}: ${flow.name} (${amount})`);
            }
          }
        }
      });
    });

    timeSteps.push({
      step,
      timestamp,
      poolBalances: { ...poolBalances },
      flowVolumes: stepFlowVolumes,
      kpiValues,
      events,
    });

    // Check for warnings
    checkForWarnings(poolBalances, flowVolumes, step, config, warnings);
  }

  // Calculate summary
  const summary = calculateSimulationSummary(timeSteps, activeFlows);

  return {
    scenarioId: config.scenarioId,
    timeSteps,
    summary,
    warnings,
  };
}

function getTimeUnitMillis(unit: 'day' | 'week' | 'month'): number {
  switch (unit) {
    case 'day': return 24 * 60 * 60 * 1000;
    case 'week': return 7 * 24 * 60 * 60 * 1000;
    case 'month': return 30 * 24 * 60 * 60 * 1000;
  }
}

function shouldFlowTrigger(flow: ValueFlow, step: number, timeUnit: 'day' | 'week' | 'month'): boolean {
  switch (flow.frequency) {
    case 'per-event':
      return true; // Simplified: always happens
    case 'daily':
      return timeUnit === 'day' || (timeUnit === 'week' && step % 7 === 0) || (timeUnit === 'month' && step % 30 === 0);
    case 'weekly':
      return timeUnit === 'week' || (timeUnit === 'month' && step % 4 === 0);
    case 'monthly':
      return timeUnit === 'month';
    case 'on-demand':
      return step % 10 === 0; // Simplified: every 10 steps
    default:
      return false;
  }
}

function shouldBehaviorTrigger(trigger: string, step: number, timeUnit: 'day' | 'week' | 'month'): boolean {
  switch (trigger) {
    case 'daily':
      return timeUnit === 'day';
    case 'weekly':
      return timeUnit === 'week' || (timeUnit === 'day' && step % 7 === 0);
    case 'monthly':
      return timeUnit === 'month' || (timeUnit === 'day' && step % 30 === 0);
    case 'event':
      return Math.random() < 0.1; // 10% chance per step
    default:
      return false;
  }
}

function calculateKPIValue(kpi: KPIInput, step: number, totalSteps: number): number {
  const progress = step / totalSteps;
  const range = kpi.endValue - kpi.startValue;

  switch (kpi.growthCurve) {
    case 'linear':
      return kpi.startValue + range * progress;
    case 'exponential':
      return kpi.startValue * Math.pow(kpi.endValue / kpi.startValue, progress);
    case 'sigmoid':
      const sigmoid = 1 / (1 + Math.exp(-10 * (progress - 0.5)));
      return kpi.startValue + range * sigmoid;
    case 'custom':
      return kpi.startValue + range * progress; // Default to linear
    default:
      return kpi.startValue;
  }
}

function calculateFlowAmount(
  flow: ValueFlow,
  kpiValues: Record<string, number>,
  poolBalances: Record<string, number>,
  config: SimulationConfig
): number {
  try {
    // Try to parse formula
    const amount = parseFormula(flow.formula, { ...kpiValues, ...poolBalances });
    return Math.max(0, amount);
  } catch {
    // If parsing fails, try to extract number from formula
    const match = flow.formula.match(/(\d+\.?\d*)/);
    if (match) {
      return parseFloat(match[1]);
    }
    return 100; // Default fallback
  }
}

function checkForWarnings(
  poolBalances: Record<string, number>,
  flowVolumes: Record<string, number>,
  step: number,
  config: SimulationConfig,
  warnings: SimulationWarning[]
): void {
  // Check for negative pool balances
  Object.entries(poolBalances).forEach(([poolId, balance]) => {
    if (balance < 0) {
      const pool = getPoolById(poolId);
      if (!warnings.some((w: SimulationWarning) => w.affectedEntities.includes(poolId) && w.category === 'depletion')) {
        warnings.push({
          severity: 'critical',
          category: 'depletion',
          message: `Pool "${pool?.name || poolId}" has negative balance: ${balance.toFixed(2)}`,
          affectedEntities: [poolId],
          suggestedAction: 'Increase funding sources or reduce outflows',
        });
      }
    }
  });

  // Check for very large balances (possible inflation)
  Object.entries(poolBalances).forEach(([poolId, balance]) => {
    if (balance > 1000000) {
      const pool = getPoolById(poolId);
      if (!warnings.some((w: SimulationWarning) => w.affectedEntities.includes(poolId) && w.category === 'inflation')) {
        warnings.push({
          severity: 'medium',
          category: 'inflation',
          message: `Pool "${pool?.name || poolId}" has very high balance: ${balance.toFixed(2)}`,
          affectedEntities: [poolId],
          suggestedAction: 'Consider adding burn mechanisms or reducing inflows',
        });
      }
    }
  });
}

function calculateSimulationSummary(timeSteps: SimulationTimeStep[], flows: ValueFlow[]): SimulationSummary {
  const finalStep = timeSteps[timeSteps.length - 1];
  const totalFlowVolume: Record<string, number> = {};
  const averagePoolBalances: Record<string, number> = {};
  const peakPoolBalances: Record<string, number> = {};

  // Calculate total flow volumes
  flows.forEach((flow: ValueFlow) => {
    const asset = getAssetById(flow.assetId);
    if (asset) {
      totalFlowVolume[asset.code] = 0;
    }
  });

  timeSteps.forEach((step: SimulationTimeStep) => {
    Object.entries(step.flowVolumes).forEach(([flowId, volume]) => {
      const flow = getFlowById(flowId);
      if (flow) {
        const asset = getAssetById(flow.assetId);
        if (asset) {
          totalFlowVolume[asset.code] = (totalFlowVolume[asset.code] || 0) + volume;
        }
      }
    });
  });

  // Calculate average and peak pool balances
  const poolIds = Object.keys(finalStep.poolBalances);
  poolIds.forEach((poolId: string) => {
    let sum = 0;
    let peak = 0;
    
    timeSteps.forEach((step: SimulationTimeStep) => {
      const balance = step.poolBalances[poolId] || 0;
      sum += balance;
      peak = Math.max(peak, balance);
    });
    
    averagePoolBalances[poolId] = sum / timeSteps.length;
    peakPoolBalances[poolId] = peak;
  });

  return {
    totalFlowVolume,
    finalPoolBalances: finalStep.poolBalances,
    averagePoolBalances,
    peakPoolBalances,
    inflationRate: {}, // Calculate if needed
    burnRate: {}, // Calculate if needed
  };
}

// Sensitivity Analysis (Feature 17)
export function runSensitivityAnalysis(
  scenarioId: string,
  parameter: string,
  range: { min: number; max: number; step: number }
): {
  parameter: string;
  range: { min: number; max: number; step: number };
  results: Array<{
    parameterValue: number;
    metrics: Record<string, number>;
    warnings: number;
  }>;
} {
  const results: Array<{
    parameterValue: number;
    metrics: Record<string, number>;
    warnings: number;
  }> = [];

  for (let value = range.min; value <= range.max; value += range.step) {
    // Create modified config with this parameter value
    const config: SimulationConfig = {
      scenarioId,
      timeUnit: 'day',
      duration: 30,
      startingBalances: { default: 10000 },
      kpiInputs: [],
      agentBehaviors: [],
    };

    try {
      const result = runSimulation(config);
      
      results.push({
        parameterValue: value,
        metrics: {
          finalBalance: Object.values(result.summary.finalPoolBalances).reduce((a: number, b: number) => a + b, 0),
          totalFlow: Object.values(result.summary.totalFlowVolume).reduce((a: number, b: number) => a + b, 0),
        },
        warnings: result.warnings.length,
      });
    } catch (error) {
      results.push({
        parameterValue: value,
        metrics: { error: 1 },
        warnings: 999,
      });
    }
  }

  return {
    parameter,
    range,
    results,
  };
}
