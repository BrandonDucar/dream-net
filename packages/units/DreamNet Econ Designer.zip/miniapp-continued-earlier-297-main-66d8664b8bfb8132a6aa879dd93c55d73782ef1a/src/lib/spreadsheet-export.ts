// Spreadsheet Import/Export (Feature 12)
// Export tokenomics to CSV/Excel format and import from spreadsheets

import type { Asset, Pool, EconomicRole, ValueFlow, ParameterSet, EconomicScenario } from '@/types/economic';
import {
  getAssets,
  getPools,
  getRoles,
  getFlows,
  getParameterSets,
  getScenarios,
  saveAssets,
  savePools,
  saveRoles,
  saveFlows,
  saveParameterSets,
  saveScenarios,
} from './economic-storage';

// Export to CSV format
export function exportToCSV(): { filename: string; content: string }[] {
  const files: { filename: string; content: string }[] = [];

  // Export Assets
  const assets = getAssets();
  let assetsCsv = 'ID,Name,Code,Type,Chain,Description,Unit,IsPrimary,Tags,Notes\n';
  assets.forEach((asset: Asset) => {
    assetsCsv += `"${asset.id}","${asset.name}","${asset.code}","${asset.assetType}","${asset.chain || ''}","${asset.description}","${asset.unitDescription}","${asset.isPrimary}","${asset.tags.join(';')}","${asset.notes}"\n`;
  });
  files.push({ filename: 'assets.csv', content: assetsCsv });

  // Export Pools
  const pools = getPools();
  let poolsCsv = 'ID,Name,Type,Description,AssetIDs,SourceOfFunds,UsageOfFunds,Tags,Notes\n';
  pools.forEach((pool: Pool) => {
    poolsCsv += `"${pool.id}","${pool.name}","${pool.poolType}","${pool.description}","${pool.assetIds.join(';')}","${pool.sourceOfFunds.join(';')}","${pool.usageOfFunds.join(';')}","${pool.tags.join(';')}","${pool.notes}"\n`;
  });
  files.push({ filename: 'pools.csv', content: poolsCsv });

  // Export Roles
  const roles = getRoles();
  let rolesCsv = 'ID,Name,Description,TypicalActions,Tags,Notes\n';
  roles.forEach((role: EconomicRole) => {
    rolesCsv += `"${role.id}","${role.name}","${role.description}","${role.typicalActions.join(';')}","${role.tags.join(';')}","${role.notes}"\n`;
  });
  files.push({ filename: 'roles.csv', content: rolesCsv });

  // Export Value Flows
  const flows = getFlows();
  let flowsCsv = 'ID,Name,Description,AssetID,FromRoleID,ToRoleID,FromPoolID,ToPoolID,Trigger,Formula,Frequency,Notes\n';
  flows.forEach((flow: ValueFlow) => {
    flowsCsv += `"${flow.id}","${flow.name}","${flow.description}","${flow.assetId}","${flow.fromRoleId || ''}","${flow.toRoleId || ''}","${flow.fromPoolId || ''}","${flow.toPoolId || ''}","${flow.trigger}","${flow.formula}","${flow.frequency}","${flow.notes}"\n`;
  });
  files.push({ filename: 'flows.csv', content: flowsCsv });

  // Export Parameter Sets
  const paramSets = getParameterSets();
  let paramsCsv = 'ID,Name,Description,Parameters,Tags,Notes\n';
  paramSets.forEach((set: ParameterSet) => {
    const paramsStr = JSON.stringify(set.values).replace(/"/g, '""');
    paramsCsv += `"${set.id}","${set.name}","${set.description}","${paramsStr}","${set.tags.join(';')}","${set.notes}"\n`;
  });
  files.push({ filename: 'parameters.csv', content: paramsCsv });

  // Export Scenarios
  const scenarios = getScenarios();
  let scenariosCsv = 'ID,Name,Description,ParameterSetID,ActiveFlowIDs,Notes\n';
  scenarios.forEach((scenario: EconomicScenario) => {
    scenariosCsv += `"${scenario.id}","${scenario.name}","${scenario.description}","${scenario.parameterSetId}","${scenario.activeFlowIds.join(';')}","${scenario.notes}"\n`;
  });
  files.push({ filename: 'scenarios.csv', content: scenariosCsv });

  return files;
}

// Download CSV file
export function downloadCSV(filename: string, content: string): void {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Download all CSVs as ZIP (simplified: download individually)
export function downloadAllCSVs(): void {
  const files = exportToCSV();
  files.forEach((file: { filename: string; content: string }) => {
    downloadCSV(file.filename, file.content);
  });
}

// Export to JSON format
export function exportToJSON(): string {
  return JSON.stringify({
    version: '1.0',
    timestamp: Date.now(),
    assets: getAssets(),
    pools: getPools(),
    roles: getRoles(),
    flows: getFlows(),
    parameterSets: getParameterSets(),
    scenarios: getScenarios(),
  }, null, 2);
}

// Download JSON file
export function downloadJSON(filename: string = 'dreamnet-economics.json'): void {
  const content = exportToJSON();
  const blob = new Blob([content], { type: 'application/json' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Import from JSON
export function importFromJSON(jsonString: string): { success: boolean; error?: string } {
  try {
    const data = JSON.parse(jsonString);
    
    if (!data.assets || !data.pools || !data.roles || !data.flows) {
      return {
        success: false,
        error: 'Invalid JSON format: missing required fields',
      };
    }

    saveAssets(data.assets);
    savePools(data.pools);
    saveRoles(data.roles);
    saveFlows(data.flows);
    
    if (data.parameterSets) {
      saveParameterSets(data.parameterSets);
    }
    
    if (data.scenarios) {
      saveScenarios(data.scenarios);
    }

    return { success: true };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

// Parse CSV line (handles quoted fields)
function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      result.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  
  result.push(current);
  return result;
}

// Import Assets from CSV
export function importAssetsFromCSV(csvContent: string): { success: boolean; count: number; error?: string } {
  try {
    const lines = csvContent.split('\n').filter((line: string) => line.trim());
    const headers = parseCSVLine(lines[0]);
    
    const assets: Asset[] = [];
    
    for (let i = 1; i < lines.length; i++) {
      const values = parseCSVLine(lines[i]);
      
      assets.push({
        id: values[0] || `asset_${Date.now()}_${i}`,
        name: values[1] || '',
        code: values[2] || '',
        assetType: (values[3] || 'other') as Asset['assetType'],
        chain: values[4] || null,
        description: values[5] || '',
        unitDescription: values[6] || '',
        isPrimary: (values[7] || 'no') as 'yes' | 'no',
        tags: values[8] ? values[8].split(';') : [],
        notes: values[9] || '',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
    }
    
    saveAssets(assets);
    
    return { success: true, count: assets.length };
  } catch (error) {
    return {
      success: false,
      count: 0,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

// Export summary report as text
export function exportSummaryReport(): string {
  const assets = getAssets();
  const pools = getPools();
  const roles = getRoles();
  const flows = getFlows();
  const paramSets = getParameterSets();
  const scenarios = getScenarios();

  let report = '╔════════════════════════════════════════════════════════════╗\n';
  report += '║  DREAMNET ECONOMICS - SUMMARY REPORT                      ║\n';
  report += '╚════════════════════════════════════════════════════════════╝\n\n';
  
  report += `Generated: ${new Date().toLocaleString()}\n\n`;
  
  report += `📊 OVERVIEW\n`;
  report += `${'─'.repeat(60)}\n`;
  report += `Total Assets: ${assets.length}\n`;
  report += `Total Pools: ${pools.length}\n`;
  report += `Total Roles: ${roles.length}\n`;
  report += `Total Value Flows: ${flows.length}\n`;
  report += `Total Parameter Sets: ${paramSets.length}\n`;
  report += `Total Scenarios: ${scenarios.length}\n\n`;
  
  report += `💎 ASSETS BREAKDOWN\n`;
  report += `${'─'.repeat(60)}\n`;
  const assetsByType: Record<string, number> = {};
  assets.forEach((asset: Asset) => {
    assetsByType[asset.assetType] = (assetsByType[asset.assetType] || 0) + 1;
  });
  Object.entries(assetsByType).forEach(([type, count]) => {
    report += `  ${type}: ${count}\n`;
  });
  report += '\n';
  
  report += `🏦 POOLS BREAKDOWN\n`;
  report += `${'─'.repeat(60)}\n`;
  const poolsByType: Record<string, number> = {};
  pools.forEach((pool: Pool) => {
    poolsByType[pool.poolType] = (poolsByType[pool.poolType] || 0) + 1;
  });
  Object.entries(poolsByType).forEach(([type, count]) => {
    report += `  ${type}: ${count}\n`;
  });
  report += '\n';
  
  report += `🔄 VALUE FLOWS BREAKDOWN\n`;
  report += `${'─'.repeat(60)}\n`;
  const flowsByTrigger: Record<string, number> = {};
  flows.forEach((flow: ValueFlow) => {
    flowsByTrigger[flow.trigger] = (flowsByTrigger[flow.trigger] || 0) + 1;
  });
  Object.entries(flowsByTrigger).forEach(([trigger, count]) => {
    report += `  ${trigger}: ${count}\n`;
  });
  
  return report;
}
