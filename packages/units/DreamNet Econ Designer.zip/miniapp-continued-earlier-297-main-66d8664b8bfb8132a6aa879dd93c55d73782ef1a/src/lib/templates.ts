// Pre-built Economic Templates (Feature 6)

import type { EconomicTemplate } from '@/types/economic-extended';

export const ECONOMIC_TEMPLATES: EconomicTemplate[] = [
  {
    id: 'nft-drop-creator-royalties',
    name: 'NFT Drop with Creator Royalties',
    description: 'Standard NFT drop economics with primary sales, secondary royalties, and platform fees',
    category: 'nft-drop',
    tags: ['nft', 'creator-economy', 'royalties'],
    assets: [
      {
        name: 'Platform Token',
        code: 'PLAT',
        assetType: 'token',
        chain: 'Base',
        description: 'Primary platform token for transactions',
        unitDescription: '1 PLAT',
        isPrimary: 'yes',
        tags: ['platform'],
        notes: '',
      },
    ],
    pools: [
      {
        name: 'Platform Treasury',
        description: 'Platform revenue collection',
        assetIds: [],
        poolType: 'treasury',
        sourceOfFunds: ['Platform fees from mints', 'Secondary sale fees'],
        usageOfFunds: ['Operations', 'Development', 'Marketing'],
        tags: ['platform'],
        notes: '',
      },
      {
        name: 'Creator Royalty Pool',
        description: 'Accumulated creator royalties',
        assetIds: [],
        poolType: 'rewards',
        sourceOfFunds: ['Primary mint revenue', 'Secondary sale royalties'],
        usageOfFunds: ['Direct creator payments'],
        tags: ['creator'],
        notes: '',
      },
    ],
    roles: [
      {
        name: 'Collector',
        description: 'NFT buyer and trader',
        typicalActions: ['Mint NFTs', 'Trade on secondary market', 'Hold for value'],
        tags: ['buyer'],
        notes: '',
      },
      {
        name: 'Creator',
        description: 'NFT creator earning from sales',
        typicalActions: ['Create NFT collections', 'Earn primary mint revenue', 'Earn royalties'],
        tags: ['seller', 'artist'],
        notes: '',
      },
    ],
    flows: [
      {
        name: 'Primary Mint → Creator',
        description: 'Creator earns from initial NFT sale',
        assetId: '',
        fromRoleId: null, // Collector
        toRoleId: null, // Creator
        fromPoolId: null,
        toPoolId: null, // Creator Royalty Pool
        trigger: 'mint',
        formula: '85% of mint price',
        frequency: 'per-event',
        notes: '',
      },
      {
        name: 'Primary Mint → Platform Fee',
        description: 'Platform takes fee on mint',
        assetId: '',
        fromRoleId: null, // Collector
        toRoleId: null,
        fromPoolId: null,
        toPoolId: null, // Platform Treasury
        trigger: 'mint',
        formula: '15% of mint price',
        frequency: 'per-event',
        notes: '',
      },
      {
        name: 'Secondary Sale → Creator Royalty',
        description: 'Creator earns royalty on resale',
        assetId: '',
        fromRoleId: null, // Buyer
        toRoleId: null,
        fromPoolId: null,
        toPoolId: null, // Creator Royalty Pool
        trigger: 'trade',
        formula: '5% of sale price',
        frequency: 'per-event',
        notes: '',
      },
      {
        name: 'Secondary Sale → Platform Fee',
        description: 'Platform fee on secondary sales',
        assetId: '',
        fromRoleId: null, // Buyer
        toRoleId: null,
        fromPoolId: null,
        toPoolId: null, // Platform Treasury
        trigger: 'trade',
        formula: '2.5% of sale price',
        frequency: 'per-event',
        notes: '',
      },
    ],
    parameterSet: {
      name: 'NFT Drop Standard Config',
      description: 'Standard parameters for NFT drops',
      values: {
        mint_fee_pct: 15,
        creator_mint_pct: 85,
        secondary_royalty_pct: 5,
        secondary_platform_fee_pct: 2.5,
      },
      tags: ['nft'],
      notes: '',
    },
    scenario: {
      name: 'NFT Drop Launch',
      description: 'Standard NFT drop with creator royalties and platform fees',
      notes: 'Optimized for creator earnings while maintaining platform sustainability',
    },
  },
  {
    id: 'staking-rewards',
    name: 'Staking Rewards Pool',
    description: 'Token staking with time-based rewards and early withdrawal penalties',
    category: 'staking',
    tags: ['staking', 'defi', 'rewards'],
    assets: [
      {
        name: 'Governance Token',
        code: 'GOV',
        assetType: 'token',
        chain: 'Base',
        description: 'Stakeable governance token',
        unitDescription: '1 GOV',
        isPrimary: 'yes',
        tags: ['governance'],
        notes: '',
      },
      {
        name: 'Reward Points',
        code: 'RWRD',
        assetType: 'offchain-points',
        chain: null,
        description: 'Off-chain points earned from staking',
        unitDescription: '1 RWRD',
        isPrimary: 'no',
        tags: ['rewards'],
        notes: '',
      },
    ],
    pools: [
      {
        name: 'Staking Pool',
        description: 'Locked staking tokens',
        assetIds: [],
        poolType: 'liquidity',
        sourceOfFunds: ['User stakes'],
        usageOfFunds: ['Unstaking withdrawals'],
        tags: ['staking'],
        notes: '',
      },
      {
        name: 'Rewards Pool',
        description: 'Allocated staking rewards',
        assetIds: [],
        poolType: 'rewards',
        sourceOfFunds: ['Protocol emissions', 'Fee revenue'],
        usageOfFunds: ['Staker rewards', 'Bonus campaigns'],
        tags: ['rewards'],
        notes: '',
      },
    ],
    roles: [
      {
        name: 'Staker',
        description: 'User who stakes tokens',
        typicalActions: ['Stake tokens', 'Earn rewards', 'Unstake'],
        tags: ['user'],
        notes: '',
      },
    ],
    flows: [
      {
        name: 'Stake Deposit',
        description: 'User deposits tokens into staking pool',
        assetId: '',
        fromRoleId: null, // Staker
        toRoleId: null,
        fromPoolId: null,
        toPoolId: null, // Staking Pool
        trigger: 'participation',
        formula: 'User-defined amount',
        frequency: 'per-event',
        notes: '',
      },
      {
        name: 'Daily Rewards',
        description: 'Daily reward distribution to stakers',
        assetId: '',
        fromRoleId: null,
        toRoleId: null, // Staker
        fromPoolId: null, // Rewards Pool
        toPoolId: null,
        trigger: 'participation',
        formula: '0.1% of staked amount per day',
        frequency: 'daily',
        notes: '',
      },
    ],
    parameterSet: {
      name: 'Staking Config',
      description: 'Staking reward parameters',
      values: {
        daily_reward_rate: 0.001,
        min_stake_period_days: 7,
        early_withdrawal_penalty_pct: 10,
      },
      tags: ['staking'],
      notes: '',
    },
    scenario: {
      name: 'Staking Launch',
      description: 'Initial staking program with daily rewards',
      notes: 'Conservative reward rate to ensure pool sustainability',
    },
  },
  {
    id: 'dual-token-game',
    name: 'Dual-Token Game Economy',
    description: 'Game with premium token (scarce) and soft currency (abundant)',
    category: 'dual-token',
    tags: ['game', 'dual-token', 'play-to-earn'],
    assets: [
      {
        name: 'Premium Token',
        code: 'PREM',
        assetType: 'token',
        chain: 'Base',
        description: 'Scarce tradeable token',
        unitDescription: '1 PREM',
        isPrimary: 'yes',
        tags: ['premium'],
        notes: '',
      },
      {
        name: 'Game Gold',
        code: 'GOLD',
        assetType: 'offchain-points',
        chain: null,
        description: 'Abundant in-game soft currency',
        unitDescription: '1 GOLD',
        isPrimary: 'no',
        tags: ['soft-currency'],
        notes: '',
      },
    ],
    pools: [
      {
        name: 'Premium Treasury',
        description: 'Premium token reserves',
        assetIds: [],
        poolType: 'treasury',
        sourceOfFunds: ['Token sales', 'In-game purchases'],
        usageOfFunds: ['Rewards', 'Liquidity'],
        tags: ['premium'],
        notes: '',
      },
      {
        name: 'Gold Sink',
        description: 'Gold burn mechanism',
        assetIds: [],
        poolType: 'fees',
        sourceOfFunds: ['Upgrade costs', 'Repair costs'],
        usageOfFunds: ['Burned (deflationary)'],
        tags: ['sink'],
        notes: '',
      },
    ],
    roles: [
      {
        name: 'Player',
        description: 'Game player earning and spending currency',
        typicalActions: ['Play games', 'Earn gold', 'Spend on upgrades', 'Trade premium tokens'],
        tags: ['player'],
        notes: '',
      },
    ],
    flows: [
      {
        name: 'Play → Earn Gold',
        description: 'Players earn gold from gameplay',
        assetId: '',
        fromRoleId: null,
        toRoleId: null, // Player
        fromPoolId: null,
        toPoolId: null,
        trigger: 'participation',
        formula: '100 GOLD per match',
        frequency: 'per-event',
        notes: '',
      },
      {
        name: 'Upgrade → Burn Gold',
        description: 'Players spend gold on upgrades (burned)',
        assetId: '',
        fromRoleId: null, // Player
        toRoleId: null,
        fromPoolId: null,
        toPoolId: null, // Gold Sink
        trigger: 'other',
        formula: 'Variable upgrade cost',
        frequency: 'per-event',
        notes: '',
      },
      {
        name: 'Gold → Premium Conversion',
        description: 'Players convert gold to premium token',
        assetId: '',
        fromRoleId: null, // Player
        toRoleId: null, // Player
        fromPoolId: null,
        toPoolId: null,
        trigger: 'other',
        formula: '1000 GOLD = 1 PREM',
        frequency: 'on-demand',
        notes: '',
      },
    ],
    parameterSet: {
      name: 'Game Economy Config',
      description: 'Dual-token game parameters',
      values: {
        gold_per_match: 100,
        gold_to_premium_rate: 1000,
        upgrade_cost_multiplier: 1.5,
      },
      tags: ['game'],
      notes: '',
    },
    scenario: {
      name: 'Game Economy Launch',
      description: 'Balanced dual-token game economy',
      notes: 'High gold emission balanced by strong sinks',
    },
  },
  {
    id: 'dao-treasury',
    name: 'DAO Treasury Management',
    description: 'DAO treasury with governance-controlled spending and revenue streams',
    category: 'dao-treasury',
    tags: ['dao', 'governance', 'treasury'],
    assets: [
      {
        name: 'DAO Token',
        code: 'DAO',
        assetType: 'token',
        chain: 'Base',
        description: 'Governance token',
        unitDescription: '1 DAO',
        isPrimary: 'yes',
        tags: ['governance'],
        notes: '',
      },
    ],
    pools: [
      {
        name: 'DAO Treasury',
        description: 'Main DAO treasury',
        assetIds: [],
        poolType: 'treasury',
        sourceOfFunds: ['Protocol fees', 'Grants', 'Investment returns'],
        usageOfFunds: ['Grants', 'Operations', 'Contributor rewards'],
        tags: ['treasury'],
        notes: '',
      },
      {
        name: 'Grants Pool',
        description: 'Allocated grants budget',
        assetIds: [],
        poolType: 'rewards',
        sourceOfFunds: ['Treasury allocations'],
        usageOfFunds: ['Project grants', 'Contributor bounties'],
        tags: ['grants'],
        notes: '',
      },
    ],
    roles: [
      {
        name: 'DAO Member',
        description: 'Token holder with governance rights',
        typicalActions: ['Vote on proposals', 'Submit proposals', 'Receive grants'],
        tags: ['governance'],
        notes: '',
      },
      {
        name: 'Contributor',
        description: 'Active DAO contributor',
        typicalActions: ['Complete bounties', 'Receive grants', 'Build projects'],
        tags: ['contributor'],
        notes: '',
      },
    ],
    flows: [
      {
        name: 'Protocol Fees → Treasury',
        description: 'Revenue flows into treasury',
        assetId: '',
        fromRoleId: null,
        toRoleId: null,
        fromPoolId: null,
        toPoolId: null, // DAO Treasury
        trigger: 'other',
        formula: '100% of protocol fees',
        frequency: 'daily',
        notes: '',
      },
      {
        name: 'Treasury → Grants Pool',
        description: 'Monthly grants allocation',
        assetId: '',
        fromRoleId: null,
        toRoleId: null,
        fromPoolId: null, // DAO Treasury
        toPoolId: null, // Grants Pool
        trigger: 'manual',
        formula: 'Governance-approved amount',
        frequency: 'monthly',
        notes: '',
      },
      {
        name: 'Grants → Contributors',
        description: 'Grant payouts to contributors',
        assetId: '',
        fromRoleId: null,
        toRoleId: null, // Contributor
        fromPoolId: null, // Grants Pool
        toPoolId: null,
        trigger: 'manual',
        formula: 'Proposal-specific amount',
        frequency: 'on-demand',
        notes: '',
      },
    ],
    parameterSet: {
      name: 'DAO Config',
      description: 'DAO treasury parameters',
      values: {
        monthly_grants_pct: 5,
        quorum_pct: 20,
        proposal_threshold: 1000,
      },
      tags: ['dao'],
      notes: '',
    },
    scenario: {
      name: 'DAO Treasury Operations',
      description: 'Standard DAO treasury management',
      notes: 'Conservative spending to ensure long-term sustainability',
    },
  },
];

export function getTemplateById(id: string): EconomicTemplate | undefined {
  return ECONOMIC_TEMPLATES.find((t: EconomicTemplate) => t.id === id);
}

export function getTemplatesByCategory(category: string): EconomicTemplate[] {
  return ECONOMIC_TEMPLATES.filter((t: EconomicTemplate) => t.category === category);
}

export function getAllTemplateCategories(): string[] {
  return Array.from(new Set(ECONOMIC_TEMPLATES.map((t: EconomicTemplate) => t.category)));
}
