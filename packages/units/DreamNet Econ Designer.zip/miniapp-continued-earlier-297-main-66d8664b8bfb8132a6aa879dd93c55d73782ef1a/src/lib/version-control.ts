// Version Control & History (Feature 7)
// Track changes, create snapshots, enable rollback

import type { VersionSnapshot, ChangeLogEntry } from '@/types/economic-extended';
import type { Asset, Pool, EconomicRole, ValueFlow, ParameterSet, EconomicScenario } from '@/types/economic';
import {
  getAssets,
  getPools,
  getRoles,
  getFlows,
  getParameterSets,
  getScenarios,
  saveAssets,
  savePools,
  saveRoles,
  saveFlows,
  saveParameterSets,
  saveScenarios,
} from './economic-storage';

const STORAGE_KEYS = {
  SNAPSHOTS: 'dreamnet_version_snapshots',
  CHANGELOG: 'dreamnet_changelog',
};

// Create snapshot of current state
export function createSnapshot(description: string, author: string = 'System'): VersionSnapshot {
  const snapshot: VersionSnapshot = {
    id: `snapshot_${Date.now()}`,
    timestamp: Date.now(),
    description,
    author,
    assets: getAssets(),
    pools: getPools(),
    roles: getRoles(),
    flows: getFlows(),
    parameterSets: getParameterSets(),
    scenarios: getScenarios(),
  };

  const snapshots = getSnapshots();
  snapshots.push(snapshot);
  saveSnapshots(snapshots);

  return snapshot;
}

// Restore from snapshot
export function restoreSnapshot(snapshotId: string): boolean {
  const snapshot = getSnapshotById(snapshotId);
  if (!snapshot) return false;

  saveAssets(snapshot.assets);
  savePools(snapshot.pools);
  saveRoles(snapshot.roles);
  saveFlows(snapshot.flows);
  saveParameterSets(snapshot.parameterSets);
  saveScenarios(snapshot.scenarios);

  logChange({
    id: `change_${Date.now()}`,
    timestamp: Date.now(),
    entityType: 'scenario',
    entityId: snapshotId,
    entityName: snapshot.description,
    action: 'updated',
    changes: {},
    author: 'System',
  });

  return true;
}

// Get all snapshots
export function getSnapshots(): VersionSnapshot[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(STORAGE_KEYS.SNAPSHOTS);
  return data ? JSON.parse(data) : [];
}

// Save snapshots
function saveSnapshots(snapshots: VersionSnapshot[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.SNAPSHOTS, JSON.stringify(snapshots));
}

// Get snapshot by ID
export function getSnapshotById(id: string): VersionSnapshot | undefined {
  return getSnapshots().find((s: VersionSnapshot) => s.id === id);
}

// Delete snapshot
export function deleteSnapshot(id: string): boolean {
  const snapshots = getSnapshots();
  const filtered = snapshots.filter((s: VersionSnapshot) => s.id !== id);
  
  if (filtered.length === snapshots.length) return false;
  
  saveSnapshots(filtered);
  return true;
}

// Compare two snapshots
export function compareSnapshots(id1: string, id2: string): {
  assetsAdded: number;
  assetsRemoved: number;
  assetsModified: number;
  poolsAdded: number;
  poolsRemoved: number;
  poolsModified: number;
  flowsAdded: number;
  flowsRemoved: number;
  flowsModified: number;
} {
  const snap1 = getSnapshotById(id1);
  const snap2 = getSnapshotById(id2);

  if (!snap1 || !snap2) {
    return {
      assetsAdded: 0,
      assetsRemoved: 0,
      assetsModified: 0,
      poolsAdded: 0,
      poolsRemoved: 0,
      poolsModified: 0,
      flowsAdded: 0,
      flowsRemoved: 0,
      flowsModified: 0,
    };
  }

  const asset1Ids = new Set(snap1.assets.map((a: Asset) => a.id));
  const asset2Ids = new Set(snap2.assets.map((a: Asset) => a.id));
  
  const assetsAdded = snap2.assets.filter((a: Asset) => !asset1Ids.has(a.id)).length;
  const assetsRemoved = snap1.assets.filter((a: Asset) => !asset2Ids.has(a.id)).length;
  const assetsModified = snap2.assets.filter((a: Asset) => {
    const oldAsset = snap1.assets.find((old: Asset) => old.id === a.id);
    return oldAsset && oldAsset.updatedAt !== a.updatedAt;
  }).length;

  const pool1Ids = new Set(snap1.pools.map((p: Pool) => p.id));
  const pool2Ids = new Set(snap2.pools.map((p: Pool) => p.id));
  
  const poolsAdded = snap2.pools.filter((p: Pool) => !pool1Ids.has(p.id)).length;
  const poolsRemoved = snap1.pools.filter((p: Pool) => !pool2Ids.has(p.id)).length;
  const poolsModified = snap2.pools.filter((p: Pool) => {
    const oldPool = snap1.pools.find((old: Pool) => old.id === p.id);
    return oldPool && oldPool.updatedAt !== p.updatedAt;
  }).length;

  const flow1Ids = new Set(snap1.flows.map((f: ValueFlow) => f.id));
  const flow2Ids = new Set(snap2.flows.map((f: ValueFlow) => f.id));
  
  const flowsAdded = snap2.flows.filter((f: ValueFlow) => !flow1Ids.has(f.id)).length;
  const flowsRemoved = snap1.flows.filter((f: ValueFlow) => !flow2Ids.has(f.id)).length;
  const flowsModified = snap2.flows.filter((f: ValueFlow) => {
    const oldFlow = snap1.flows.find((old: ValueFlow) => old.id === f.id);
    return oldFlow && oldFlow.updatedAt !== f.updatedAt;
  }).length;

  return {
    assetsAdded,
    assetsRemoved,
    assetsModified,
    poolsAdded,
    poolsRemoved,
    poolsModified,
    flowsAdded,
    flowsRemoved,
    flowsModified,
  };
}

// Change log functions
export function logChange(entry: ChangeLogEntry): void {
  const changelog = getChangelog();
  changelog.push(entry);
  saveChangelog(changelog);
}

export function getChangelog(): ChangeLogEntry[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(STORAGE_KEYS.CHANGELOG);
  return data ? JSON.parse(data) : [];
}

function saveChangelog(changelog: ChangeLogEntry[]): void {
  if (typeof window === 'undefined') return;
  // Keep only last 500 entries
  const trimmed = changelog.slice(-500);
  localStorage.setItem(STORAGE_KEYS.CHANGELOG, JSON.stringify(trimmed));
}

export function getChangelogByEntity(entityType: string, entityId: string): ChangeLogEntry[] {
  return getChangelog().filter((entry: ChangeLogEntry) => 
    entry.entityType === entityType && entry.entityId === entityId
  );
}

export function clearOldChangelog(daysToKeep: number = 30): void {
  const cutoff = Date.now() - daysToKeep * 24 * 60 * 60 * 1000;
  const changelog = getChangelog();
  const filtered = changelog.filter((entry: ChangeLogEntry) => entry.timestamp >= cutoff);
  saveChangelog(filtered);
}
