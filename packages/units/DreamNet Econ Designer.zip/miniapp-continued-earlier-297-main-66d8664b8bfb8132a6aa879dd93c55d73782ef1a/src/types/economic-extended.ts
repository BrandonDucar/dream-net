// Extended types for advanced features

import type { Asset, Pool, EconomicRole, ValueFlow, ParameterSet, EconomicScenario } from './economic';

// ============================================================================
// VERSION CONTROL (Feature 7)
// ============================================================================

export interface VersionSnapshot {
  id: string;
  timestamp: number;
  description: string;
  author: string;
  assets: Asset[];
  pools: Pool[];
  roles: EconomicRole[];
  flows: ValueFlow[];
  parameterSets: ParameterSet[];
  scenarios: EconomicScenario[];
}

export interface ChangeLogEntry {
  id: string;
  timestamp: number;
  entityType: 'asset' | 'pool' | 'role' | 'flow' | 'parameter' | 'scenario';
  entityId: string;
  entityName: string;
  action: 'created' | 'updated' | 'deleted';
  changes: Record<string, { old: unknown; new: unknown }>;
  author: string;
}

// ============================================================================
// TEMPLATES (Feature 6)
// ============================================================================

export interface EconomicTemplate {
  id: string;
  name: string;
  description: string;
  category: 'nft-drop' | 'staking' | 'dual-token' | 'dao-treasury' | 'game-economy' | 'other';
  tags: string[];
  assets: Omit<Asset, 'id' | 'createdAt' | 'updatedAt'>[];
  pools: Omit<Pool, 'id' | 'createdAt' | 'updatedAt'>[];
  roles: Omit<EconomicRole, 'id' | 'createdAt' | 'updatedAt'>[];
  flows: Omit<ValueFlow, 'id' | 'createdAt' | 'updatedAt'>[];
  parameterSet: Omit<ParameterSet, 'id' | 'createdAt' | 'updatedAt'>;
  scenario: Omit<EconomicScenario, 'id' | 'createdAt' | 'updatedAt' | 'parameterSetId' | 'activeFlowIds'>;
}

// ============================================================================
// SIMULATION (Features 2, 3, 17)
// ============================================================================

export interface SimulationConfig {
  scenarioId: string;
  timeUnit: 'day' | 'week' | 'month';
  duration: number; // number of time units
  startingBalances: Record<string, number>; // poolId -> balance
  kpiInputs: KPIInput[];
  agentBehaviors: AgentBehavior[];
}

export interface KPIInput {
  id: string;
  name: string;
  description: string;
  metric: 'dau' | 'mau' | 'tvl' | 'transactions' | 'custom';
  growthCurve: 'linear' | 'exponential' | 'sigmoid' | 'custom';
  startValue: number;
  endValue: number;
  linkedFlows: string[]; // flow IDs that depend on this KPI
  formula: string; // how this KPI affects flows
}

export interface AgentBehavior {
  id: string;
  roleId: string;
  name: string;
  description: string;
  actions: BehaviorAction[];
}

export interface BehaviorAction {
  trigger: 'daily' | 'weekly' | 'monthly' | 'event';
  flowId: string;
  amount: number | string; // number or expression
  probability: number; // 0-1
}

export interface SimulationResult {
  scenarioId: string;
  timeSteps: SimulationTimeStep[];
  summary: SimulationSummary;
  warnings: SimulationWarning[];
}

export interface SimulationTimeStep {
  step: number;
  timestamp: number;
  poolBalances: Record<string, number>;
  flowVolumes: Record<string, number>;
  kpiValues: Record<string, number>;
  events: string[];
}

export interface SimulationSummary {
  totalFlowVolume: Record<string, number>; // assetId -> volume
  finalPoolBalances: Record<string, number>;
  averagePoolBalances: Record<string, number>;
  peakPoolBalances: Record<string, number>;
  inflationRate: Record<string, number>; // assetId -> rate
  burnRate: Record<string, number>;
}

export interface SimulationWarning {
  severity: 'low' | 'medium' | 'high' | 'critical';
  category: 'inflation' | 'depletion' | 'imbalance' | 'circular' | 'exploit' | 'other';
  message: string;
  affectedEntities: string[];
  suggestedAction: string;
}

// ============================================================================
// RISK ANALYSIS (Features 4, 5, 16, 18)
// ============================================================================

export interface RiskAnalysis {
  scenarioId: string;
  timestamp: number;
  risks: Risk[];
  balanceCheck: BalanceCheck;
  feedbackLoops: FeedbackLoop[];
  deathSpiralRisk: DeathSpiralAnalysis;
}

export interface Risk {
  id: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  category: 'inflation' | 'depletion' | 'spam' | 'governance' | 'undefined' | 'imbalance' | 'exploit';
  title: string;
  description: string;
  affectedEntities: Array<{ type: string; id: string; name: string }>;
  mitigation: string;
  autoDetected: boolean;
}

export interface BalanceCheck {
  isBalanced: boolean;
  issues: Array<{
    type: 'leak' | 'source-missing' | 'sink-missing' | 'circular';
    severity: 'low' | 'medium' | 'high';
    description: string;
    affectedPools: string[];
  }>;
}

export interface FeedbackLoop {
  id: string;
  flows: string[]; // flow IDs in the loop
  type: 'stabilizing' | 'destabilizing' | 'neutral';
  strength: number; // 0-1
  description: string;
}

export interface DeathSpiralAnalysis {
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  scenarios: Array<{
    trigger: string;
    cascade: string[];
    mitigation: string;
  }>;
  circuitBreakers: string[];
}

// ============================================================================
// TIME-BASED MECHANICS (Feature 9)
// ============================================================================

export interface VestingSchedule {
  id: string;
  name: string;
  roleId: string;
  assetId: string;
  totalAmount: number;
  startDate: number; // timestamp
  cliff: number; // days
  duration: number; // days
  frequency: 'daily' | 'weekly' | 'monthly';
  description: string;
}

export interface UnlockEvent {
  id: string;
  name: string;
  date: number; // timestamp
  type: 'vesting' | 'airdrop' | 'emission' | 'other';
  assetId: string;
  amount: number;
  recipients: string[]; // roleIds or poolIds
  description: string;
}

export interface SeasonalEvent {
  id: string;
  name: string;
  startDate: number;
  endDate: number;
  type: 'boost' | 'airdrop' | 'special';
  affectedFlows: string[];
  multiplier: number;
  description: string;
}

// ============================================================================
// MULTI-ASSET RELATIONSHIPS (Feature 10)
// ============================================================================

export interface AssetRelationship {
  id: string;
  name: string;
  type: 'conversion' | 'swap' | 'liquidity-pair' | 'pegged' | 'derived';
  fromAssetId: string;
  toAssetId: string;
  rate: number | string; // number or formula
  bidirectional: boolean;
  description: string;
  constraints: string[];
}

// ============================================================================
// COLLABORATION (Feature 13)
// ============================================================================

export interface Comment {
  id: string;
  entityType: 'asset' | 'pool' | 'role' | 'flow' | 'parameter' | 'scenario';
  entityId: string;
  author: string;
  content: string;
  timestamp: number;
  resolved: boolean;
  replies: CommentReply[];
}

export interface CommentReply {
  id: string;
  author: string;
  content: string;
  timestamp: number;
}

export interface ApprovalWorkflow {
  id: string;
  entityType: string;
  entityId: string;
  status: 'pending' | 'approved' | 'rejected' | 'needs-review';
  requestedBy: string;
  reviewers: string[];
  approvals: Array<{
    reviewer: string;
    status: 'approved' | 'rejected' | 'pending';
    timestamp: number;
    comments: string;
  }>;
  createdAt: number;
  updatedAt: number;
}

// ============================================================================
// SMART CONTRACT EXPORT (Feature 11)
// ============================================================================

export interface ContractExport {
  scenarioId: string;
  timestamp: number;
  contracts: SmartContract[];
  configFiles: ConfigFile[];
}

export interface SmartContract {
  name: string;
  language: 'solidity' | 'rust' | 'move';
  version: string;
  code: string;
  description: string;
}

export interface ConfigFile {
  name: string;
  format: 'json' | 'yaml' | 'toml';
  content: string;
  description: string;
}

// ============================================================================
// SENSITIVITY ANALYSIS (Feature 17)
// ============================================================================

export interface SensitivityAnalysis {
  scenarioId: string;
  parameter: string;
  range: { min: number; max: number; step: number };
  results: SensitivityResult[];
  summary: {
    mostSensitiveMetric: string;
    leastSensitiveMetric: string;
    optimalValue: number;
  };
}

export interface SensitivityResult {
  parameterValue: number;
  metrics: Record<string, number>;
  warnings: number;
}

// ============================================================================
// NETWORK GRAPH (Feature 19)
// ============================================================================

export interface NetworkNode {
  id: string;
  type: 'asset' | 'pool' | 'role';
  name: string;
  size: number; // for visualization
  color: string;
  metadata: Record<string, unknown>;
}

export interface NetworkEdge {
  id: string;
  source: string;
  target: string;
  label: string;
  weight: number; // flow volume
  color: string;
  metadata: Record<string, unknown>;
}

export interface NetworkGraph {
  nodes: NetworkNode[];
  edges: NetworkEdge[];
  statistics: {
    totalNodes: number;
    totalEdges: number;
    centralNodes: string[];
    bottlenecks: string[];
    isolatedNodes: string[];
  };
}
