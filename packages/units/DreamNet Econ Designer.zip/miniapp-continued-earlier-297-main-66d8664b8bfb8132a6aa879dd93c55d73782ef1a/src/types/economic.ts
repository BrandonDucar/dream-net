// DreamNet Economic Engine Type Definitions

export type AssetType = 
  | "token"
  | "offchain-points"
  | "badge-score"
  | "voucher"
  | "credit"
  | "other";

export type PoolType = 
  | "treasury"
  | "rewards"
  | "fees"
  | "liquidity"
  | "reserve"
  | "escrow"
  | "other";

export type TriggerType = 
  | "mint"
  | "trade"
  | "badge-earned"
  | "participation"
  | "donation"
  | "manual"
  | "other";

export type FrequencyType = 
  | "per-event"
  | "daily"
  | "weekly"
  | "monthly"
  | "on-demand";

export interface SEOMetadata {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export interface Asset extends Partial<SEOMetadata> {
  id: string;
  name: string;
  code: string;
  assetType: AssetType;
  chain: string | null;
  description: string;
  unitDescription: string;
  isPrimary: "yes" | "no";
  tags: string[];
  notes: string;
  createdAt: number;
  updatedAt: number;
}

export interface EconomicRole {
  id: string;
  name: string;
  description: string;
  typicalActions: string[];
  tags: string[];
  notes: string;
  createdAt: number;
  updatedAt: number;
}

export interface Pool extends Partial<SEOMetadata> {
  id: string;
  name: string;
  description: string;
  assetIds: string[];
  poolType: PoolType;
  sourceOfFunds: string[];
  usageOfFunds: string[];
  tags: string[];
  notes: string;
  createdAt: number;
  updatedAt: number;
}

export interface ValueFlow {
  id: string;
  name: string;
  description: string;
  assetId: string;
  fromRoleId: string | null;
  toRoleId: string | null;
  fromPoolId: string | null;
  toPoolId: string | null;
  trigger: TriggerType;
  formula: string;
  frequency: FrequencyType;
  notes: string;
  createdAt: number;
  updatedAt: number;
}

export interface ParameterSet {
  id: string;
  name: string;
  description: string;
  values: Record<string, number | string>;
  tags: string[];
  notes: string;
  createdAt: number;
  updatedAt: number;
}

export interface EconomicScenario extends Partial<SEOMetadata> {
  id: string;
  name: string;
  description: string;
  parameterSetId: string;
  activeFlowIds: string[];
  notes: string;
  createdAt: number;
  updatedAt: number;
}

// Filter interfaces
export interface AssetFilter {
  assetType?: AssetType;
  chain?: string;
  tag?: string;
  isPrimary?: "yes" | "no";
}

export interface PoolFilter {
  poolType?: PoolType;
  tag?: string;
  assetId?: string;
}

export interface ValueFlowFilter {
  assetId?: string;
  fromRoleId?: string;
  toRoleId?: string;
  fromPoolId?: string;
  toPoolId?: string;
  trigger?: TriggerType;
  frequency?: FrequencyType;
}

export interface ScenarioFilter {
  tag?: string;
  parameterSetId?: string;
}
