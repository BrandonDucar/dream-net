'use client'
import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Activity, Database, HeartPulse, AlertCircle, FileCheck, FileText, Brain, Network, Bot, MessageSquare, BookOpen } from 'lucide-react';
import HealthOverview from '@/components/health-overview';
import DomainsSignals from '@/components/domains-signals';
import SamplesIncidents from '@/components/samples-incidents';
import CheckTemplatesRuns from '@/components/check-templates-runs';
import HealthSummaryReport from '@/components/health-summary-report';
import PredictiveForecasting from '@/components/predictive-forecasting';
import CorrelationEngine from '@/components/correlation-engine';
import SynthesisAgent from '@/components/synthesis-agent';
import SocialPulse from '@/components/social-pulse';
import PlaybookGenerator from '@/components/playbook-generator';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DreamNetHealthMonitor() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [activeTab, setActiveTab] = useState<string>('overview');

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <header className="mb-8 text-center">
          <div className="flex items-center justify-center gap-3 mb-2">
            <HeartPulse className="h-12 w-12 text-blue-600" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              DreamNet Diagnostics
            </h1>
          </div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Complete health monitoring and diagnostics system for DreamNet across Culture, Ops, Agents, Economics, Social, and Pickleball domains
          </p>
        </header>

        <Card className="shadow-xl">
          <CardContent className="p-6">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-5 lg:grid-cols-10 mb-6 h-auto">
                <TabsTrigger value="overview" className="flex items-center gap-2">
                  <Activity className="h-4 w-4" />
                  <span className="hidden sm:inline">Overview</span>
                </TabsTrigger>
                <TabsTrigger value="domains" className="flex items-center gap-2">
                  <Database className="h-4 w-4" />
                  <span className="hidden sm:inline">Domains</span>
                </TabsTrigger>
                <TabsTrigger value="samples" className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4" />
                  <span className="hidden sm:inline">Samples</span>
                </TabsTrigger>
                <TabsTrigger value="checks" className="flex items-center gap-2">
                  <FileCheck className="h-4 w-4" />
                  <span className="hidden sm:inline">Checks</span>
                </TabsTrigger>
                <TabsTrigger value="summaries" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  <span className="hidden sm:inline">Summaries</span>
                </TabsTrigger>
                <TabsTrigger value="predictions" className="flex items-center gap-2 bg-gradient-to-r from-purple-50 to-blue-50">
                  <Brain className="h-4 w-4" />
                  <span className="hidden sm:inline">Predictions</span>
                </TabsTrigger>
                <TabsTrigger value="correlations" className="flex items-center gap-2 bg-gradient-to-r from-purple-50 to-blue-50">
                  <Network className="h-4 w-4" />
                  <span className="hidden sm:inline">Correlations</span>
                </TabsTrigger>
                <TabsTrigger value="synthesis" className="flex items-center gap-2 bg-gradient-to-r from-purple-50 to-blue-50">
                  <Bot className="h-4 w-4" />
                  <span className="hidden sm:inline">Synthesis</span>
                </TabsTrigger>
                <TabsTrigger value="social" className="flex items-center gap-2 bg-gradient-to-r from-purple-50 to-blue-50">
                  <MessageSquare className="h-4 w-4" />
                  <span className="hidden sm:inline">Social</span>
                </TabsTrigger>
                <TabsTrigger value="playbooks" className="flex items-center gap-2 bg-gradient-to-r from-purple-50 to-blue-50">
                  <BookOpen className="h-4 w-4" />
                  <span className="hidden sm:inline">Playbooks</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="mt-0">
                <HealthOverview />
              </TabsContent>

              <TabsContent value="domains" className="mt-0">
                <DomainsSignals />
              </TabsContent>

              <TabsContent value="samples" className="mt-0">
                <SamplesIncidents />
              </TabsContent>

              <TabsContent value="checks" className="mt-0">
                <CheckTemplatesRuns />
              </TabsContent>

              <TabsContent value="summaries" className="mt-0">
                <HealthSummaryReport />
              </TabsContent>

              <TabsContent value="predictions" className="mt-0">
                <PredictiveForecasting />
              </TabsContent>

              <TabsContent value="correlations" className="mt-0">
                <CorrelationEngine />
              </TabsContent>

              <TabsContent value="synthesis" className="mt-0">
                <SynthesisAgent />
              </TabsContent>

              <TabsContent value="social" className="mt-0">
                <SocialPulse />
              </TabsContent>

              <TabsContent value="playbooks" className="mt-0">
                <PlaybookGenerator />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <div className="mt-8 bg-gradient-to-r from-purple-100 via-blue-100 to-purple-100 rounded-lg p-6 shadow-lg">
          <h2 className="text-2xl font-bold text-center mb-2 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            🚀 Advanced Features
          </h2>
          <p className="text-center text-gray-700 mb-4">
            5 revolutionary capabilities that make DreamNet Diagnostics truly stand out
          </p>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <button
              onClick={() => setActiveTab('predictions')}
              className="flex flex-col items-center p-4 bg-white rounded-lg shadow hover:shadow-lg transition-shadow"
            >
              <Brain className="h-8 w-8 text-purple-600 mb-2" />
              <p className="font-semibold text-sm text-center">Predictive Forecasting</p>
              <p className="text-xs text-gray-600 text-center mt-1">AI-powered health predictions</p>
            </button>
            <button
              onClick={() => setActiveTab('correlations')}
              className="flex flex-col items-center p-4 bg-white rounded-lg shadow hover:shadow-lg transition-shadow"
            >
              <Network className="h-8 w-8 text-blue-600 mb-2" />
              <p className="font-semibold text-sm text-center">Correlation Engine</p>
              <p className="text-xs text-gray-600 text-center mt-1">Discover hidden connections</p>
            </button>
            <button
              onClick={() => setActiveTab('synthesis')}
              className="flex flex-col items-center p-4 bg-white rounded-lg shadow hover:shadow-lg transition-shadow"
            >
              <Bot className="h-8 w-8 text-green-600 mb-2" />
              <p className="font-semibold text-sm text-center">Auto Synthesis</p>
              <p className="text-xs text-gray-600 text-center mt-1">Automated health detection</p>
            </button>
            <button
              onClick={() => setActiveTab('social')}
              className="flex flex-col items-center p-4 bg-white rounded-lg shadow hover:shadow-lg transition-shadow"
            >
              <MessageSquare className="h-8 w-8 text-orange-600 mb-2" />
              <p className="font-semibold text-sm text-center">Social Pulse</p>
              <p className="text-xs text-gray-600 text-center mt-1">Cultural sentiment tracking</p>
            </button>
            <button
              onClick={() => setActiveTab('playbooks')}
              className="flex flex-col items-center p-4 bg-white rounded-lg shadow hover:shadow-lg transition-shadow"
            >
              <BookOpen className="h-8 w-8 text-red-600 mb-2" />
              <p className="font-semibold text-sm text-center">Playbook Generator</p>
              <p className="text-xs text-gray-600 text-center mt-1">AI-generated fix plans</p>
            </button>
          </div>
        </div>

        <footer className="mt-8 text-center text-sm text-gray-600">
          <p>DreamNet Diagnostics & Health Monitor • Tracking system health across all domains</p>
          <p className="mt-1">Culture • Ops • Agents • Economics • Social • Pickleball</p>
        </footer>
      </div>
    </div>
  );
}
