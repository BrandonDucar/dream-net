'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, FileCheck, PlayCircle, CheckCircle } from 'lucide-react';
import type { CheckTemplate, CheckRun, HealthDomain, CheckFrequency } from '@/types/health';
import { getCheckTemplates, createCheckTemplate, getCheckRuns, startCheckRun, finalizeCheckRun, getHealthDomains, getHealthSignals } from '@/lib/healthLogic';

export default function CheckTemplatesRuns() {
  const [templates, setTemplates] = useState<CheckTemplate[]>([]);
  const [runs, setRuns] = useState<CheckRun[]>([]);
  const [domains, setDomains] = useState<HealthDomain[]>([]);
  
  const [isAddingTemplate, setIsAddingTemplate] = useState<boolean>(false);
  const [isStartingRun, setIsStartingRun] = useState<boolean>(false);
  const [finalizingRun, setFinalizingRun] = useState<CheckRun | null>(null);
  
  const [newTemplate, setNewTemplate] = useState({
    name: '',
    description: '',
    frequency: 'daily' as CheckFrequency,
    domainIds: [] as string[],
    signalIds: [] as string[],
    checklistItems: '',
    tags: ''
  });
  
  const [newRun, setNewRun] = useState({
    templateId: '',
    operatorName: '',
    periodLabel: ''
  });
  
  const [finalizeData, setFinalizeData] = useState({
    summary: '',
    notes: '',
    signalsReviewed: '',
    incidentsTouched: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setTemplates(getCheckTemplates());
    setRuns(getCheckRuns());
    setDomains(getHealthDomains());
  };

  const handleAddTemplate = () => {
    createCheckTemplate({
      name: newTemplate.name,
      description: newTemplate.description,
      frequency: newTemplate.frequency,
      domainIds: newTemplate.domainIds,
      signalIds: newTemplate.signalIds,
      checklistItems: newTemplate.checklistItems.split('\n').map((item: string) => item.trim()).filter((item: string) => item),
      tags: newTemplate.tags.split(',').map((t: string) => t.trim()).filter((t: string) => t)
    });
    
    setNewTemplate({
      name: '',
      description: '',
      frequency: 'daily',
      domainIds: [],
      signalIds: [],
      checklistItems: '',
      tags: ''
    });
    setIsAddingTemplate(false);
    loadData();
  };

  const handleStartRun = () => {
    startCheckRun({
      templateId: newRun.templateId,
      operatorName: newRun.operatorName,
      periodLabel: newRun.periodLabel
    });
    
    setNewRun({
      templateId: '',
      operatorName: '',
      periodLabel: ''
    });
    setIsStartingRun(false);
    loadData();
  };

  const handleFinalizeRun = () => {
    if (!finalizingRun) return;
    
    finalizeCheckRun({
      checkRunId: finalizingRun.id,
      summary: finalizeData.summary,
      notes: finalizeData.notes,
      signalsReviewedIds: finalizeData.signalsReviewed.split(',').map((s: string) => s.trim()).filter((s: string) => s),
      incidentsTouchedIds: finalizeData.incidentsTouched.split(',').map((i: string) => i.trim()).filter((i: string) => i)
    });
    
    setFinalizingRun(null);
    setFinalizeData({
      summary: '',
      notes: '',
      signalsReviewed: '',
      incidentsTouched: ''
    });
    loadData();
  };

  const toggleDomain = (domainId: string) => {
    setNewTemplate((prev) => ({
      ...prev,
      domainIds: prev.domainIds.includes(domainId)
        ? prev.domainIds.filter((id: string) => id !== domainId)
        : [...prev.domainIds, domainId]
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Check Templates & Runs</h2>
          <p className="text-gray-600">Manage health check procedures and execution</p>
        </div>
        <FileCheck className="h-8 w-8 text-blue-500" />
      </div>

      <Tabs defaultValue="templates" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="templates">Check Templates</TabsTrigger>
          <TabsTrigger value="runs">Check Runs</TabsTrigger>
        </TabsList>

        <TabsContent value="templates" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <FileCheck className="h-5 w-5" />
                    Check Templates
                  </CardTitle>
                  <CardDescription>Reusable health check procedures</CardDescription>
                </div>
                <Dialog open={isAddingTemplate} onOpenChange={setIsAddingTemplate}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus className="h-4 w-4 mr-2" />
                      Create Template
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Create Check Template</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="templateName">Name</Label>
                        <Input
                          id="templateName"
                          value={newTemplate.name}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewTemplate({ ...newTemplate, name: e.target.value })}
                          placeholder="e.g., Daily Health Sweep"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="templateDescription">Description</Label>
                        <Textarea
                          id="templateDescription"
                          value={newTemplate.description}
                          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNewTemplate({ ...newTemplate, description: e.target.value })}
                          placeholder="Describe this check template"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="templateFrequency">Frequency</Label>
                        <Select
                          value={newTemplate.frequency}
                          onValueChange={(value: CheckFrequency) => setNewTemplate({ ...newTemplate, frequency: value })}
                        >
                          <SelectTrigger id="templateFrequency">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="daily">Daily</SelectItem>
                            <SelectItem value="weekly">Weekly</SelectItem>
                            <SelectItem value="per-launch">Per Launch</SelectItem>
                            <SelectItem value="per-incident">Per Incident</SelectItem>
                            <SelectItem value="ad-hoc">Ad Hoc</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Domains</Label>
                        <div className="space-y-2">
                          {domains.map((domain: HealthDomain) => (
                            <div key={domain.id} className="flex items-center space-x-2">
                              <input
                                type="checkbox"
                                id={`domain-${domain.id}`}
                                checked={newTemplate.domainIds.includes(domain.id)}
                                onChange={() => toggleDomain(domain.id)}
                                className="h-4 w-4"
                              />
                              <label htmlFor={`domain-${domain.id}`} className="text-sm">
                                {domain.name}
                              </label>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="templateChecklist">Checklist Items (one per line)</Label>
                        <Textarea
                          id="templateChecklist"
                          value={newTemplate.checklistItems}
                          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNewTemplate({ ...newTemplate, checklistItems: e.target.value })}
                          placeholder="Enter checklist items, one per line"
                          rows={5}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="templateTags">Tags (comma-separated)</Label>
                        <Input
                          id="templateTags"
                          value={newTemplate.tags}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewTemplate({ ...newTemplate, tags: e.target.value })}
                          placeholder="e.g., critical, automated"
                        />
                      </div>
                      
                      <Button onClick={handleAddTemplate} className="w-full">Create Template</Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Frequency</TableHead>
                    <TableHead>Domains</TableHead>
                    <TableHead>Checklist Items</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {templates.map((template: CheckTemplate) => (
                    <TableRow key={template.id}>
                      <TableCell className="font-semibold">{template.name}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">{template.frequency}</Badge>
                      </TableCell>
                      <TableCell>{template.domainIds.length}</TableCell>
                      <TableCell>{template.checklistItems.length}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="runs" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <PlayCircle className="h-5 w-5" />
                    Check Runs
                  </CardTitle>
                  <CardDescription>Executed health check instances</CardDescription>
                </div>
                <Dialog open={isStartingRun} onOpenChange={setIsStartingRun}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <PlayCircle className="h-4 w-4 mr-2" />
                      Start Check Run
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Start Check Run</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="runTemplate">Template</Label>
                        <Select
                          value={newRun.templateId}
                          onValueChange={(value: string) => setNewRun({ ...newRun, templateId: value })}
                        >
                          <SelectTrigger id="runTemplate">
                            <SelectValue placeholder="Select template" />
                          </SelectTrigger>
                          <SelectContent>
                            {templates.map((template: CheckTemplate) => (
                              <SelectItem key={template.id} value={template.id}>
                                {template.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="runOperator">Operator Name</Label>
                        <Input
                          id="runOperator"
                          value={newRun.operatorName}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewRun({ ...newRun, operatorName: e.target.value })}
                          placeholder="Your name"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="runPeriod">Period Label</Label>
                        <Input
                          id="runPeriod"
                          value={newRun.periodLabel}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewRun({ ...newRun, periodLabel: e.target.value })}
                          placeholder="e.g., today, week-49"
                        />
                      </div>
                      
                      <Button onClick={handleStartRun} className="w-full">Start Check Run</Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Template</TableHead>
                    <TableHead>Operator</TableHead>
                    <TableHead>Period</TableHead>
                    <TableHead>Started</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {runs.map((run: CheckRun) => {
                    const template = templates.find((t: CheckTemplate) => t.id === run.templateId);
                    const isFinished = run.finishedAt !== null;
                    
                    return (
                      <TableRow key={run.id}>
                        <TableCell>{template?.name || 'Unknown'}</TableCell>
                        <TableCell>{run.operatorName}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{run.periodLabel}</Badge>
                        </TableCell>
                        <TableCell className="text-sm">
                          {new Date(run.startedAt).toLocaleString()}
                        </TableCell>
                        <TableCell>
                          {isFinished ? (
                            <Badge className="bg-green-100 text-green-800 border-green-300">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Finished
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">
                              In Progress
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          {!isFinished && (
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => setFinalizingRun(run)}
                            >
                              Finalize
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={finalizingRun !== null} onOpenChange={() => setFinalizingRun(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Finalize Check Run</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="finalizeSummary">Summary</Label>
              <Textarea
                id="finalizeSummary"
                value={finalizeData.summary}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setFinalizeData({ ...finalizeData, summary: e.target.value })}
                placeholder="Summary of findings"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="finalizeNotes">Notes</Label>
              <Textarea
                id="finalizeNotes"
                value={finalizeData.notes}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setFinalizeData({ ...finalizeData, notes: e.target.value })}
                placeholder="Additional notes"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="finalizeSignals">Signals Reviewed (IDs, comma-separated)</Label>
              <Input
                id="finalizeSignals"
                value={finalizeData.signalsReviewed}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFinalizeData({ ...finalizeData, signalsReviewed: e.target.value })}
                placeholder="signal-id-1, signal-id-2"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="finalizeIncidents">Incidents Touched (IDs, comma-separated)</Label>
              <Input
                id="finalizeIncidents"
                value={finalizeData.incidentsTouched}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFinalizeData({ ...finalizeData, incidentsTouched: e.target.value })}
                placeholder="incident-id-1, incident-id-2"
              />
            </div>
            
            <Button onClick={handleFinalizeRun} className="w-full">Complete Check Run</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
