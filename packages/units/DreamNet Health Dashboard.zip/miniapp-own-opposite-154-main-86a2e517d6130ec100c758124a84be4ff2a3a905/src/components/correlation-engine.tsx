'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Network, Zap, ArrowRight, Clock, TrendingUp } from 'lucide-react';
import { getHealthDomains } from '@/lib/healthLogic';
import { discoverHealthCorrelations, getHealthCorrelations } from '@/lib/advancedLogic';
import type { HealthCorrelation } from '@/types/advanced-features';
import type { HealthDomain } from '@/types/health';

export default function CorrelationEngine() {
  const [domains, setDomains] = useState<HealthDomain[]>([]);
  const [correlations, setCorrelations] = useState<HealthCorrelation[]>([]);
  const [discovering, setDiscovering] = useState<boolean>(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setDomains(getHealthDomains());
    setCorrelations(getHealthCorrelations());
  };

  const handleDiscover = () => {
    setDiscovering(true);
    setTimeout(() => {
      const newCorrelations = discoverHealthCorrelations();
      setCorrelations(getHealthCorrelations());
      setDiscovering(false);
    }, 1500);
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'positive':
        return 'bg-green-100 text-green-800';
      case 'negative':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getConfidenceBadge = (confidence: string) => {
    const colors: Record<string, string> = {
      'very-high': 'bg-purple-100 text-purple-800',
      'high': 'bg-blue-100 text-blue-800',
      'medium': 'bg-yellow-100 text-yellow-800',
      'low': 'bg-gray-100 text-gray-800'
    };
    return colors[confidence] || colors.low;
  };

  const getDomainName = (domainId: string) => {
    const domain = domains.find((d: HealthDomain) => d.id === domainId);
    return domain?.name || 'Unknown';
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-5 w-5" />
            Health Correlation Engine
          </CardTitle>
          <CardDescription>
            Discover hidden connections between health signals
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={handleDiscover} disabled={discovering} className="w-full">
            <Zap className="h-4 w-4 mr-2" />
            {discovering ? 'Analyzing patterns...' : 'Discover Correlations'}
          </Button>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-gray-600">Total Correlations</p>
            <p className="text-3xl font-bold">{correlations.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-gray-600">Strong Correlations</p>
            <p className="text-3xl font-bold">
              {correlations.filter((c: HealthCorrelation) => c.strength >= 80).length}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-gray-600">Cross-Domain Links</p>
            <p className="text-3xl font-bold">
              {correlations.filter((c: HealthCorrelation) => 
                c.signalA.domainId !== c.signalB.domainId
              ).length}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {correlations.map((correlation: HealthCorrelation) => (
          <Card key={correlation.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline">{getDomainName(correlation.signalA.domainId)}</Badge>
                    <span className="font-semibold">{correlation.signalA.name}</span>
                    <ArrowRight className="h-4 w-4 text-gray-400" />
                    <Badge variant="outline">{getDomainName(correlation.signalB.domainId)}</Badge>
                    <span className="font-semibold">{correlation.signalB.name}</span>
                  </div>
                  <CardDescription>{correlation.description}</CardDescription>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <Badge className={getTypeColor(correlation.correlationType)}>
                    {correlation.correlationType}
                  </Badge>
                  <Badge className={getConfidenceBadge(correlation.confidence)}>
                    {correlation.confidence}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Strength</p>
                  <div className="flex items-center gap-2">
                    <Progress value={correlation.strength} className="h-2" />
                    <span className="text-sm font-semibold">{correlation.strength}%</span>
                  </div>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Lag</p>
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4 text-gray-500" />
                    <span className="text-sm font-semibold">
                      {correlation.lag === 0 ? 'Immediate' : `${correlation.lag} days`}
                    </span>
                  </div>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Sample Size</p>
                  <span className="text-sm font-semibold">{correlation.sampleSize} samples</span>
                </div>
              </div>

              {correlation.implications.length > 0 && (
                <div>
                  <p className="font-semibold text-sm mb-2 flex items-center gap-2">
                    <TrendingUp className="h-4 w-4" />
                    Implications:
                  </p>
                  <ul className="space-y-1">
                    {correlation.implications.map((implication: string, idx: number) => (
                      <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
                        <span className="text-blue-600">→</span>
                        {implication}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <p className="text-xs text-gray-500">
                Discovered {new Date(correlation.discoveredAt).toLocaleString()}
              </p>
            </CardContent>
          </Card>
        ))}

        {correlations.length === 0 && (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Network className="h-12 w-12 text-gray-400 mb-4" />
              <p className="text-gray-600">No correlations discovered yet. Click "Discover Correlations" to start!</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
