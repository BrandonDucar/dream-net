'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Database, Signal } from 'lucide-react';
import type { HealthDomain, HealthSignalDefinition, ImportanceLevel, SignalType, RecommendedSampling } from '@/types/health';
import { getHealthDomains, createHealthDomain, getHealthSignals, createHealthSignalDefinition } from '@/lib/healthLogic';

export default function DomainsSignals() {
  const [domains, setDomains] = useState<HealthDomain[]>([]);
  const [signals, setSignals] = useState<HealthSignalDefinition[]>([]);
  const [selectedDomain, setSelectedDomain] = useState<string>('all');
  const [selectedSignalType, setSelectedSignalType] = useState<string>('all');
  const [selectedSampling, setSelectedSampling] = useState<string>('all');
  const [isAddingDomain, setIsAddingDomain] = useState<boolean>(false);
  const [isAddingSignal, setIsAddingSignal] = useState<boolean>(false);

  const [newDomain, setNewDomain] = useState({
    name: '',
    code: '',
    description: '',
    importanceLevel: 'medium' as ImportanceLevel,
    tags: ''
  });

  const [newSignal, setNewSignal] = useState({
    domainId: '',
    name: '',
    code: '',
    description: '',
    signalType: 'metric' as SignalType,
    expectedRange: '',
    interpretation: '',
    recommendedSampling: 'daily' as RecommendedSampling,
    tags: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setDomains(getHealthDomains());
    setSignals(getHealthSignals());
  };

  const handleAddDomain = () => {
    createHealthDomain({
      name: newDomain.name,
      code: newDomain.code,
      description: newDomain.description,
      importanceLevel: newDomain.importanceLevel,
      tags: newDomain.tags.split(',').map((t: string) => t.trim()).filter((t: string) => t)
    });
    
    setNewDomain({
      name: '',
      code: '',
      description: '',
      importanceLevel: 'medium',
      tags: ''
    });
    setIsAddingDomain(false);
    loadData();
  };

  const handleAddSignal = () => {
    createHealthSignalDefinition({
      domainId: newSignal.domainId,
      name: newSignal.name,
      code: newSignal.code,
      description: newSignal.description,
      signalType: newSignal.signalType,
      expectedRange: newSignal.expectedRange || null,
      interpretation: newSignal.interpretation,
      recommendedSampling: newSignal.recommendedSampling,
      tags: newSignal.tags.split(',').map((t: string) => t.trim()).filter((t: string) => t)
    });
    
    setNewSignal({
      domainId: '',
      name: '',
      code: '',
      description: '',
      signalType: 'metric',
      expectedRange: '',
      interpretation: '',
      recommendedSampling: 'daily',
      tags: ''
    });
    setIsAddingSignal(false);
    loadData();
  };

  const filteredSignals = signals.filter((signal: HealthSignalDefinition) => {
    if (selectedDomain !== 'all' && signal.domainId !== selectedDomain) return false;
    if (selectedSignalType !== 'all' && signal.signalType !== selectedSignalType) return false;
    if (selectedSampling !== 'all' && signal.recommendedSampling !== selectedSampling) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Domains & Signals</h2>
          <p className="text-gray-600">Manage health domains and signal definitions</p>
        </div>
        <Database className="h-8 w-8 text-blue-500" />
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Health Domains
              </CardTitle>
              <CardDescription>Core domains for health monitoring</CardDescription>
            </div>
            <Dialog open={isAddingDomain} onOpenChange={setIsAddingDomain}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Domain
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create Health Domain</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="domainName">Name</Label>
                    <Input
                      id="domainName"
                      value={newDomain.name}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewDomain({ ...newDomain, name: e.target.value })}
                      placeholder="e.g., Culture"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="domainCode">Code</Label>
                    <Input
                      id="domainCode"
                      value={newDomain.code}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewDomain({ ...newDomain, code: e.target.value })}
                      placeholder="e.g., CULTURE"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="domainDescription">Description</Label>
                    <Textarea
                      id="domainDescription"
                      value={newDomain.description}
                      onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNewDomain({ ...newDomain, description: e.target.value })}
                      placeholder="Describe this domain"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="domainImportance">Importance Level</Label>
                    <Select
                      value={newDomain.importanceLevel}
                      onValueChange={(value: ImportanceLevel) => setNewDomain({ ...newDomain, importanceLevel: value })}
                    >
                      <SelectTrigger id="domainImportance">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="domainTags">Tags (comma-separated)</Label>
                    <Input
                      id="domainTags"
                      value={newDomain.tags}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewDomain({ ...newDomain, tags: e.target.value })}
                      placeholder="e.g., memes, campaigns"
                    />
                  </div>
                  
                  <Button onClick={handleAddDomain} className="w-full">Create Domain</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Importance</TableHead>
                <TableHead>Tags</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {domains.map((domain: HealthDomain) => (
                <TableRow key={domain.id}>
                  <TableCell className="font-semibold">{domain.name}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{domain.code}</Badge>
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant={domain.importanceLevel === 'critical' ? 'destructive' : 'secondary'}
                    >
                      {domain.importanceLevel}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1 flex-wrap">
                      {domain.tags.map((tag: string, idx: number) => (
                        <Badge key={idx} variant="outline" className="text-xs">{tag}</Badge>
                      ))}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Signal className="h-5 w-5" />
                Health Signals
              </CardTitle>
              <CardDescription>Signal definitions for health monitoring</CardDescription>
            </div>
            <Dialog open={isAddingSignal} onOpenChange={setIsAddingSignal}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Signal
                </Button>
              </DialogTrigger>
              <DialogContent className="max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Create Health Signal</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="signalDomain">Domain</Label>
                    <Select
                      value={newSignal.domainId}
                      onValueChange={(value: string) => setNewSignal({ ...newSignal, domainId: value })}
                    >
                      <SelectTrigger id="signalDomain">
                        <SelectValue placeholder="Select domain" />
                      </SelectTrigger>
                      <SelectContent>
                        {domains.map((domain: HealthDomain) => (
                          <SelectItem key={domain.id} value={domain.id}>
                            {domain.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="signalName">Name</Label>
                    <Input
                      id="signalName"
                      value={newSignal.name}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewSignal({ ...newSignal, name: e.target.value })}
                      placeholder="e.g., Meme freshness"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="signalCode">Code</Label>
                    <Input
                      id="signalCode"
                      value={newSignal.code}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewSignal({ ...newSignal, code: e.target.value })}
                      placeholder="e.g., SIG_MEME_FRESH"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="signalDescription">Description</Label>
                    <Textarea
                      id="signalDescription"
                      value={newSignal.description}
                      onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNewSignal({ ...newSignal, description: e.target.value })}
                      placeholder="Describe this signal"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="signalType">Signal Type</Label>
                    <Select
                      value={newSignal.signalType}
                      onValueChange={(value: SignalType) => setNewSignal({ ...newSignal, signalType: value })}
                    >
                      <SelectTrigger id="signalType">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="metric">Metric</SelectItem>
                        <SelectItem value="boolean">Boolean</SelectItem>
                        <SelectItem value="score">Score</SelectItem>
                        <SelectItem value="status">Status</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="signalRange">Expected Range (optional)</Label>
                    <Input
                      id="signalRange"
                      value={newSignal.expectedRange}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewSignal({ ...newSignal, expectedRange: e.target.value })}
                      placeholder="e.g., 0-100"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="signalInterpretation">Interpretation</Label>
                    <Textarea
                      id="signalInterpretation"
                      value={newSignal.interpretation}
                      onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNewSignal({ ...newSignal, interpretation: e.target.value })}
                      placeholder="How to interpret this signal"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="signalSampling">Recommended Sampling</Label>
                    <Select
                      value={newSignal.recommendedSampling}
                      onValueChange={(value: RecommendedSampling) => setNewSignal({ ...newSignal, recommendedSampling: value })}
                    >
                      <SelectTrigger id="signalSampling">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="per-event">Per Event</SelectItem>
                        <SelectItem value="ad-hoc">Ad Hoc</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="signalTags">Tags (comma-separated)</Label>
                    <Input
                      id="signalTags"
                      value={newSignal.tags}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewSignal({ ...newSignal, tags: e.target.value })}
                      placeholder="e.g., critical, automated"
                    />
                  </div>
                  
                  <Button onClick={handleAddSignal} className="w-full">Create Signal</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-4">
            <div className="flex-1">
              <Label htmlFor="filterDomain">Filter by Domain</Label>
              <Select value={selectedDomain} onValueChange={setSelectedDomain}>
                <SelectTrigger id="filterDomain">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Domains</SelectItem>
                  {domains.map((domain: HealthDomain) => (
                    <SelectItem key={domain.id} value={domain.id}>
                      {domain.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex-1">
              <Label htmlFor="filterType">Filter by Type</Label>
              <Select value={selectedSignalType} onValueChange={setSelectedSignalType}>
                <SelectTrigger id="filterType">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="metric">Metric</SelectItem>
                  <SelectItem value="boolean">Boolean</SelectItem>
                  <SelectItem value="score">Score</SelectItem>
                  <SelectItem value="status">Status</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex-1">
              <Label htmlFor="filterSampling">Filter by Sampling</Label>
              <Select value={selectedSampling} onValueChange={setSelectedSampling}>
                <SelectTrigger id="filterSampling">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Sampling</SelectItem>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="per-event">Per Event</SelectItem>
                  <SelectItem value="ad-hoc">Ad Hoc</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Domain</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Sampling</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSignals.map((signal: HealthSignalDefinition) => {
                const domain = domains.find((d: HealthDomain) => d.id === signal.domainId);
                return (
                  <TableRow key={signal.id}>
                    <TableCell className="font-semibold">{signal.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{signal.code}</Badge>
                    </TableCell>
                    <TableCell>{domain?.name || 'Unknown'}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{signal.signalType}</Badge>
                    </TableCell>
                    <TableCell>{signal.recommendedSampling}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
