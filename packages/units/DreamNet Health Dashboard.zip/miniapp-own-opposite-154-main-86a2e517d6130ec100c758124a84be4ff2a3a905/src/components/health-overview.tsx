'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Activity, TrendingUp, AlertTriangle, CheckCircle, Download, FileText } from 'lucide-react';
import type { HealthDomain, HealthSummary, SampleStatus } from '@/types/health';
import { getHealthDomains, computeHealthSummary, generateHealthReport, exportDiagnosticsPlaybook, listHealthSummaries } from '@/lib/healthLogic';

export default function HealthOverview() {
  const [domains, setDomains] = useState<HealthDomain[]>([]);
  const [domainSummaries, setDomainSummaries] = useState<Map<string, HealthSummary>>(new Map());
  const [globalSummary, setGlobalSummary] = useState<HealthSummary | null>(null);
  const [periodLabel, setPeriodLabel] = useState<string>('today');
  const [report, setReport] = useState<string>('');
  const [playbook, setPlaybook] = useState<string>('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const loadedDomains = getHealthDomains();
    setDomains(loadedDomains);
    
    const summaries = listHealthSummaries();
    const summaryMap = new Map<string, HealthSummary>();
    
    loadedDomains.forEach((domain: HealthDomain) => {
      const domainSummaries = summaries.filter((s: HealthSummary) => s.domainId === domain.id);
      if (domainSummaries.length > 0) {
        summaryMap.set(domain.id, domainSummaries[0]);
      }
    });
    
    setDomainSummaries(summaryMap);
    
    const globalSummaries = summaries.filter((s: HealthSummary) => s.domainId === null);
    if (globalSummaries.length > 0) {
      setGlobalSummary(globalSummaries[0]);
    }
  };

  const handleComputeHealth = () => {
    domains.forEach((domain: HealthDomain) => {
      computeHealthSummary({
        domainId: domain.id,
        periodLabel
      });
    });
    
    const global = computeHealthSummary({
      domainId: null,
      periodLabel
    });
    
    setGlobalSummary(global);
    loadData();
  };

  const handleGenerateReport = () => {
    const generatedReport = generateHealthReport(periodLabel);
    setReport(generatedReport);
  };

  const handleExportPlaybook = () => {
    const generatedPlaybook = exportDiagnosticsPlaybook();
    setPlaybook(generatedPlaybook);
  };

  const getStatusIcon = (status: SampleStatus) => {
    switch (status) {
      case 'good':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'bad':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      default:
        return <Activity className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: SampleStatus) => {
    const variants: Record<SampleStatus, string> = {
      good: 'bg-green-100 text-green-800 border-green-300',
      warning: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      bad: 'bg-red-100 text-red-800 border-red-300',
      unknown: 'bg-gray-100 text-gray-800 border-gray-300'
    };
    
    return (
      <Badge variant="outline" className={variants[status]}>
        {status.toUpperCase()}
      </Badge>
    );
  };

  const getImportanceColor = (level: string) => {
    const colors: Record<string, string> = {
      low: 'text-gray-600',
      medium: 'text-blue-600',
      high: 'text-orange-600',
      critical: 'text-red-600'
    };
    return colors[level] || 'text-gray-600';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Health Overview</h2>
          <p className="text-gray-600">Monitor DreamNet system health across all domains</p>
        </div>
        <Activity className="h-8 w-8 text-blue-500" />
      </div>

      {globalSummary && (
        <Card className="border-2 border-blue-500">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Overall DreamNet Health</span>
              {getStatusIcon(globalSummary.status)}
            </CardTitle>
            <CardDescription>Global health across all domains</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-4xl font-bold">{globalSummary.healthScore}/100</div>
                  <div className="text-sm text-gray-600">Health Score</div>
                </div>
                {getStatusBadge(globalSummary.status)}
              </div>
              
              {globalSummary.keyFindings.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-2">Key Findings</h4>
                  <ul className="space-y-1">
                    {globalSummary.keyFindings.map((finding: string, idx: number) => (
                      <li key={idx} className="text-sm text-gray-700">• {finding}</li>
                    ))}
                  </ul>
                </div>
              )}
              
              {globalSummary.recommendedActions.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-2">Recommended Actions</h4>
                  <ul className="space-y-1">
                    {globalSummary.recommendedActions.map((action: string, idx: number) => (
                      <li key={idx} className="text-sm text-gray-700">• {action}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {domains.map((domain: HealthDomain) => {
          const summary = domainSummaries.get(domain.id);
          
          return (
            <Card key={domain.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center justify-between text-lg">
                  <span>{domain.name}</span>
                  {summary && getStatusIcon(summary.status)}
                </CardTitle>
                <CardDescription className="text-xs">
                  <span className={getImportanceColor(domain.importanceLevel)}>
                    {domain.importanceLevel.toUpperCase()}
                  </span>
                  {' • '}
                  <span className="text-gray-600">{domain.code}</span>
                </CardDescription>
              </CardHeader>
              <CardContent>
                {summary ? (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold">{summary.healthScore}/100</span>
                      {getStatusBadge(summary.status)}
                    </div>
                    <div className="text-xs text-gray-600">
                      Last updated: {new Date(summary.timestamp).toLocaleString()}
                    </div>
                  </div>
                ) : (
                  <div className="text-sm text-gray-500">No health data available</div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Health Actions
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="periodLabel">Period Label</Label>
            <Input
              id="periodLabel"
              value={periodLabel}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPeriodLabel(e.target.value)}
              placeholder="e.g., today, week-49, 2025-12-06"
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            <Button onClick={handleComputeHealth}>
              <Activity className="h-4 w-4 mr-2" />
              Compute Health Now
            </Button>
            
            <Button onClick={handleGenerateReport} variant="outline">
              <FileText className="h-4 w-4 mr-2" />
              Generate Health Report
            </Button>
            
            <Button onClick={handleExportPlaybook} variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export Diagnostics Playbook
            </Button>
          </div>
        </CardContent>
      </Card>

      {report && (
        <Card>
          <CardHeader>
            <CardTitle>Health Report</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-4 rounded-lg overflow-auto max-h-96">
              <pre className="text-xs whitespace-pre-wrap font-mono">{report}</pre>
            </div>
            <Button 
              className="mt-4" 
              onClick={() => navigator.clipboard.writeText(report)}
            >
              Copy Report
            </Button>
          </CardContent>
        </Card>
      )}

      {playbook && (
        <Card>
          <CardHeader>
            <CardTitle>Diagnostics Playbook</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-4 rounded-lg overflow-auto max-h-96">
              <pre className="text-xs whitespace-pre-wrap font-mono">{playbook}</pre>
            </div>
            <Button 
              className="mt-4" 
              onClick={() => navigator.clipboard.writeText(playbook)}
            >
              Copy Playbook
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
