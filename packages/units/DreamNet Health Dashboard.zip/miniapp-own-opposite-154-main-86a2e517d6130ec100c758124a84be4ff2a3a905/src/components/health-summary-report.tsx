'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { FileText, TrendingUp, Copy } from 'lucide-react';
import type { HealthSummary, HealthDomain, SampleStatus } from '@/types/health';
import { listHealthSummaries, computeHealthSummary, generateHealthReport, getHealthDomains } from '@/lib/healthLogic';

export default function HealthSummaryReport() {
  const [summaries, setSummaries] = useState<HealthSummary[]>([]);
  const [domains, setDomains] = useState<HealthDomain[]>([]);
  const [selectedDomain, setSelectedDomain] = useState<string>('all');
  const [periodLabel, setPeriodLabel] = useState<string>('today');
  const [report, setReport] = useState<string>('');
  const [selectedSummary, setSelectedSummary] = useState<HealthSummary | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setSummaries(listHealthSummaries());
    setDomains(getHealthDomains());
  };

  const handleComputeSummary = () => {
    const domainId = selectedDomain === 'all' ? null : selectedDomain;
    const summary = computeHealthSummary({
      domainId,
      periodLabel
    });
    setSelectedSummary(summary);
    loadData();
  };

  const handleGenerateReport = () => {
    const generatedReport = generateHealthReport(periodLabel);
    setReport(generatedReport);
  };

  const filteredSummaries = summaries.filter((summary: HealthSummary) => {
    if (selectedDomain === 'all') return true;
    if (selectedDomain === 'global') return summary.domainId === null;
    return summary.domainId === selectedDomain;
  });

  const getStatusBadge = (status: SampleStatus) => {
    const variants: Record<SampleStatus, string> = {
      good: 'bg-green-100 text-green-800 border-green-300',
      warning: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      bad: 'bg-red-100 text-red-800 border-red-300',
      unknown: 'bg-gray-100 text-gray-800 border-gray-300'
    };
    
    return (
      <Badge variant="outline" className={variants[status]}>
        {status.toUpperCase()}
      </Badge>
    );
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 50) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Health Summary & Reports</h2>
          <p className="text-gray-600">View detailed health summaries and generate reports</p>
        </div>
        <FileText className="h-8 w-8 text-blue-500" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Compute New Summary
          </CardTitle>
          <CardDescription>Generate a health summary for a specific domain and period</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="summaryDomain">Domain</Label>
              <Select value={selectedDomain} onValueChange={setSelectedDomain}>
                <SelectTrigger id="summaryDomain">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Overall (All Domains)</SelectItem>
                  {domains.map((domain: HealthDomain) => (
                    <SelectItem key={domain.id} value={domain.id}>
                      {domain.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="summaryPeriod">Period Label</Label>
              <Input
                id="summaryPeriod"
                value={periodLabel}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPeriodLabel(e.target.value)}
                placeholder="e.g., today, week-49, 2025-12-06"
              />
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button onClick={handleComputeSummary}>
              <TrendingUp className="h-4 w-4 mr-2" />
              Compute Summary
            </Button>
            
            <Button onClick={handleGenerateReport} variant="outline">
              <FileText className="h-4 w-4 mr-2" />
              Generate Full Report
            </Button>
          </div>
        </CardContent>
      </Card>

      {selectedSummary && (
        <Card className="border-2 border-blue-500">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Latest Computed Summary</CardTitle>
              {getStatusBadge(selectedSummary.status)}
            </div>
            <CardDescription>
              {selectedSummary.domainId 
                ? `Domain: ${domains.find((d: HealthDomain) => d.id === selectedSummary.domainId)?.name || 'Unknown'}`
                : 'Overall DreamNet Health'
              }
              {' • '}
              Period: {selectedSummary.periodLabel}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className={`text-4xl font-bold ${getScoreColor(selectedSummary.healthScore)}`}>
                  {selectedSummary.healthScore}/100
                </div>
                <div className="text-sm text-gray-600">Health Score</div>
              </div>
              <div className="text-right text-sm text-gray-600">
                Generated: {new Date(selectedSummary.timestamp).toLocaleString()}
              </div>
            </div>
            
            {selectedSummary.keyFindings.length > 0 && (
              <div>
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  Key Findings
                  <Badge variant="outline">{selectedSummary.keyFindings.length}</Badge>
                </h4>
                <ul className="space-y-1 bg-gray-50 p-4 rounded-lg">
                  {selectedSummary.keyFindings.map((finding: string, idx: number) => (
                    <li key={idx} className="text-sm text-gray-700">• {finding}</li>
                  ))}
                </ul>
              </div>
            )}
            
            {selectedSummary.recommendedActions.length > 0 && (
              <div>
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  Recommended Actions
                  <Badge variant="outline">{selectedSummary.recommendedActions.length}</Badge>
                </h4>
                <ul className="space-y-1 bg-blue-50 p-4 rounded-lg">
                  {selectedSummary.recommendedActions.map((action: string, idx: number) => (
                    <li key={idx} className="text-sm text-blue-800">• {action}</li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Historical Summaries</CardTitle>
          <CardDescription>Previously computed health summaries</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <Label htmlFor="filterSummaryDomain">Filter by Domain</Label>
            <Select value={selectedDomain} onValueChange={setSelectedDomain}>
              <SelectTrigger id="filterSummaryDomain">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="global">Global Only</SelectItem>
                {domains.map((domain: HealthDomain) => (
                  <SelectItem key={domain.id} value={domain.id}>
                    {domain.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-3">
            {filteredSummaries.map((summary: HealthSummary) => {
              const domain = summary.domainId 
                ? domains.find((d: HealthDomain) => d.id === summary.domainId)
                : null;
              
              return (
                <Card key={summary.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="font-semibold text-lg">
                          {domain?.name || 'Overall DreamNet Health'}
                        </div>
                        <div className="text-sm text-gray-600">
                          Period: {summary.periodLabel} • {new Date(summary.timestamp).toLocaleString()}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className={`text-2xl font-bold ${getScoreColor(summary.healthScore)}`}>
                          {summary.healthScore}
                        </div>
                        {getStatusBadge(summary.status)}
                      </div>
                    </div>
                    
                    {summary.keyFindings.length > 0 && (
                      <div className="mt-3">
                        <div className="text-sm font-semibold mb-1">Key Findings:</div>
                        <ul className="text-sm text-gray-700 space-y-1">
                          {summary.keyFindings.slice(0, 3).map((finding: string, idx: number) => (
                            <li key={idx}>• {finding}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
            
            {filteredSummaries.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                No health summaries found. Compute a new summary to get started.
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {report && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Full Health Report
              </CardTitle>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  navigator.clipboard.writeText(report);
                }}
              >
                <Copy className="h-4 w-4 mr-2" />
                Copy Report
              </Button>
            </div>
            <CardDescription>Comprehensive health report for period: {periodLabel}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-4 rounded-lg overflow-auto max-h-96 border border-gray-200">
              <pre className="text-xs whitespace-pre-wrap font-mono">{report}</pre>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
