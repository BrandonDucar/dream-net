'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { BookOpen, Sparkles, CheckCircle, Circle, Copy, User } from 'lucide-react';
import { getHealthDomains, getIncidents } from '@/lib/healthLogic';
import { generateHealthPlaybook, getGeneratedPlaybooks, updatePlaybookAction } from '@/lib/advancedLogic';
import type { GeneratedPlaybook, PlaybookAction } from '@/types/advanced-features';
import type { HealthDomain, Incident } from '@/types/health';

export default function PlaybookGenerator() {
  const [domains, setDomains] = useState<HealthDomain[]>([]);
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [playbooks, setPlaybooks] = useState<GeneratedPlaybook[]>([]);
  const [showNewPlaybook, setShowNewPlaybook] = useState<boolean>(false);
  const [selectedPlaybook, setSelectedPlaybook] = useState<GeneratedPlaybook | null>(null);

  const [newPlaybook, setNewPlaybook] = useState({
    title: '',
    description: '',
    domainId: '',
    incidentIds: [] as string[]
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setDomains(getHealthDomains());
    setIncidents(getIncidents({ status: 'open' }));
    setPlaybooks(getGeneratedPlaybooks());
  };

  const handleGeneratePlaybook = () => {
    if (!newPlaybook.title || !newPlaybook.description) return;

    const playbook = generateHealthPlaybook({
      title: newPlaybook.title,
      description: newPlaybook.description,
      domainId: newPlaybook.domainId || null,
      incidentIds: newPlaybook.incidentIds
    });

    setPlaybooks(getGeneratedPlaybooks());
    setSelectedPlaybook(playbook);
    setShowNewPlaybook(false);
    setNewPlaybook({
      title: '',
      description: '',
      domainId: '',
      incidentIds: []
    });
  };

  const handleToggleAction = (playbookId: string, sectionIndex: number, actionIndex: number, completed: boolean) => {
    updatePlaybookAction(playbookId, sectionIndex, actionIndex, { completed });
    setPlaybooks(getGeneratedPlaybooks());
    if (selectedPlaybook && selectedPlaybook.id === playbookId) {
      const updated = getGeneratedPlaybooks().find((p: GeneratedPlaybook) => p.id === playbookId);
      if (updated) setSelectedPlaybook(updated);
    }
  };

  const handleAssignAction = (playbookId: string, sectionIndex: number, actionIndex: number, assignee: string) => {
    updatePlaybookAction(playbookId, sectionIndex, actionIndex, { assignee });
    setPlaybooks(getGeneratedPlaybooks());
    if (selectedPlaybook && selectedPlaybook.id === playbookId) {
      const updated = getGeneratedPlaybooks().find((p: GeneratedPlaybook) => p.id === playbookId);
      if (updated) setSelectedPlaybook(updated);
    }
  };

  const copyPlaybook = (playbook: GeneratedPlaybook) => {
    let text = `${playbook.title}\n${'='.repeat(60)}\n\n`;
    text += `${playbook.description}\n\n`;
    text += `Priority: ${playbook.priority.toUpperCase()}\n`;
    text += `Health Score: ${playbook.context.healthScore}/100\n\n`;
    
    playbook.sections.forEach((section) => {
      text += `${section.title}\n${'-'.repeat(40)}\n`;
      text += `${section.content}\n\n`;
      
      if (section.actionItems.length > 0) {
        text += 'Action Items:\n';
        section.actionItems.forEach((action) => {
          const status = action.completed ? '✓' : '○';
          text += `${status} ${action.description} [${action.priority}] (${action.estimatedTime})\n`;
        });
        text += '\n';
      }
    });

    navigator.clipboard.writeText(text);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical':
        return 'bg-red-100 text-red-800';
      case 'high':
        return 'bg-orange-100 text-orange-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'draft':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const toggleIncident = (incidentId: string) => {
    setNewPlaybook({
      ...newPlaybook,
      incidentIds: newPlaybook.incidentIds.includes(incidentId)
        ? newPlaybook.incidentIds.filter((id: string) => id !== incidentId)
        : [...newPlaybook.incidentIds, incidentId]
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            Interactive Health Playbook Generator
          </CardTitle>
          <CardDescription>
            AI-generated fix playbooks based on your specific health patterns
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <p className="text-sm text-gray-600">Total Playbooks</p>
              <p className="text-2xl font-bold">{playbooks.length}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Active</p>
              <p className="text-2xl font-bold">
                {playbooks.filter((p: GeneratedPlaybook) => p.status === 'active').length}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Avg Success Rate</p>
              <p className="text-2xl font-bold">
                {playbooks.length > 0
                  ? Math.round(playbooks.reduce((sum: number, p: GeneratedPlaybook) => sum + p.successRate, 0) / playbooks.length)
                  : 0}%
              </p>
            </div>
          </div>

          <Button onClick={() => setShowNewPlaybook(!showNewPlaybook)} className="w-full">
            <Sparkles className="h-4 w-4 mr-2" />
            Generate New Playbook
          </Button>
        </CardContent>
      </Card>

      {showNewPlaybook && (
        <Card>
          <CardHeader>
            <CardTitle>Generate Health Playbook</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Playbook Title</Label>
              <Input
                value={newPlaybook.title}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewPlaybook({ ...newPlaybook, title: e.target.value })}
                placeholder="e.g., Ops Recovery Plan, Culture Reboot Playbook"
              />
            </div>

            <div>
              <Label>Description</Label>
              <Textarea
                value={newPlaybook.description}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNewPlaybook({ ...newPlaybook, description: e.target.value })}
                placeholder="What is this playbook addressing?"
                rows={3}
              />
            </div>

            <div>
              <Label>Target Domain (Optional)</Label>
              <Select value={newPlaybook.domainId} onValueChange={(value: string) => setNewPlaybook({ ...newPlaybook, domainId: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="All domains" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All domains</SelectItem>
                  {domains.map((domain: HealthDomain) => (
                    <SelectItem key={domain.id} value={domain.id}>
                      {domain.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {incidents.length > 0 && (
              <div>
                <Label>Related Incidents</Label>
                <div className="space-y-2 mt-2 max-h-48 overflow-y-auto">
                  {incidents.map((incident: Incident) => (
                    <div key={incident.id} className="flex items-start gap-2">
                      <Checkbox
                        checked={newPlaybook.incidentIds.includes(incident.id)}
                        onCheckedChange={() => toggleIncident(incident.id)}
                      />
                      <div className="flex-1">
                        <p className="text-sm font-medium">{incident.title}</p>
                        <p className="text-xs text-gray-600">
                          {incident.severity} • {new Date(incident.detectedAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex gap-2">
              <Button onClick={handleGeneratePlaybook} disabled={!newPlaybook.title || !newPlaybook.description}>
                <Sparkles className="h-4 w-4 mr-2" />
                Generate Playbook
              </Button>
              <Button variant="outline" onClick={() => setShowNewPlaybook(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-4">
          <h3 className="font-semibold">Playbook Library</h3>
          {playbooks.map((playbook: GeneratedPlaybook) => (
            <Card
              key={playbook.id}
              className={`cursor-pointer transition-colors ${
                selectedPlaybook?.id === playbook.id ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
              }`}
              onClick={() => setSelectedPlaybook(playbook)}
            >
              <CardHeader className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="text-sm">{playbook.title}</CardTitle>
                  <Badge className={getPriorityColor(playbook.priority)} >
                    {playbook.priority}
                  </Badge>
                </div>
                <CardDescription className="text-xs">
                  {new Date(playbook.timestamp).toLocaleDateString()}
                </CardDescription>
              </CardHeader>
            </Card>
          ))}

          {playbooks.length === 0 && (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-8">
                <BookOpen className="h-8 w-8 text-gray-400 mb-2" />
                <p className="text-sm text-gray-600">No playbooks yet</p>
              </CardContent>
            </Card>
          )}
        </div>

        <div className="lg:col-span-2">
          {selectedPlaybook ? (
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{selectedPlaybook.title}</CardTitle>
                    <CardDescription>{selectedPlaybook.description}</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => copyPlaybook(selectedPlaybook)}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-600">Priority:</span>{' '}
                    <Badge className={getPriorityColor(selectedPlaybook.priority)}>
                      {selectedPlaybook.priority}
                    </Badge>
                  </div>
                  <div>
                    <span className="text-gray-600">Status:</span>{' '}
                    <Badge className={getStatusColor(selectedPlaybook.status)}>
                      {selectedPlaybook.status}
                    </Badge>
                  </div>
                  <div>
                    <span className="text-gray-600">Health Score:</span>{' '}
                    <span className="font-semibold">{selectedPlaybook.context.healthScore}/100</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Generated By:</span> {selectedPlaybook.generatedBy}
                  </div>
                </div>

                <Separator />

                {selectedPlaybook.sections.map((section, sectionIdx: number) => (
                  <div key={sectionIdx} className="space-y-3">
                    <h3 className="font-semibold text-lg">{section.title}</h3>
                    <p className="text-sm text-gray-700 whitespace-pre-line">{section.content}</p>

                    {section.actionItems.length > 0 && (
                      <div className="space-y-2 pl-4 border-l-2 border-gray-200">
                        {section.actionItems.map((action: PlaybookAction, actionIdx: number) => (
                          <div key={actionIdx} className="flex items-start gap-3 p-2 rounded hover:bg-gray-50">
                            <button
                              onClick={() => handleToggleAction(selectedPlaybook.id, sectionIdx, actionIdx, !action.completed)}
                              className="mt-1"
                            >
                              {action.completed ? (
                                <CheckCircle className="h-5 w-5 text-green-600" />
                              ) : (
                                <Circle className="h-5 w-5 text-gray-400" />
                              )}
                            </button>
                            <div className="flex-1">
                              <p className={`text-sm ${action.completed ? 'line-through text-gray-500' : ''}`}>
                                {action.description}
                              </p>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge className={getPriorityColor(action.priority)} >
                                  {action.priority}
                                </Badge>
                                <span className="text-xs text-gray-600">{action.estimatedTime}</span>
                                {action.assignee && (
                                  <div className="flex items-center gap-1 text-xs text-gray-600">
                                    <User className="h-3 w-3" />
                                    {action.assignee}
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}

                <Separator />

                <div>
                  <p className="text-sm font-semibold mb-2">Estimated Impact</p>
                  <p className="text-sm text-gray-700">{selectedPlaybook.estimatedImpact}</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-24">
                <BookOpen className="h-16 w-16 text-gray-400 mb-4" />
                <p className="text-gray-600">Select a playbook to view details</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
