'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { TrendingUp, TrendingDown, Minus, AlertTriangle, Brain, Sparkles } from 'lucide-react';
import { getHealthDomains, getHealthSignals } from '@/lib/healthLogic';
import { generateHealthPrediction, getHealthPredictions } from '@/lib/advancedLogic';
import type { HealthPrediction } from '@/types/advanced-features';
import type { HealthDomain, HealthSignalDefinition } from '@/types/health';

export default function PredictiveForecasting() {
  const [domains, setDomains] = useState<HealthDomain[]>([]);
  const [signals, setSignals] = useState<HealthSignalDefinition[]>([]);
  const [predictions, setPredictions] = useState<HealthPrediction[]>([]);
  const [selectedDomain, setSelectedDomain] = useState<string>('');
  const [selectedSignal, setSelectedSignal] = useState<string>('');
  const [daysAhead, setDaysAhead] = useState<number>(7);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setDomains(getHealthDomains());
    setSignals(getHealthSignals());
    setPredictions(getHealthPredictions());
  };

  const handleGeneratePrediction = () => {
    if (!selectedDomain) return;

    const prediction = generateHealthPrediction({
      domainId: selectedDomain,
      signalId: selectedSignal || null,
      daysAhead
    });

    setPredictions([prediction, ...predictions]);
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'improving':
        return <TrendingUp className="h-4 w-4 text-green-600" />;
      case 'degrading':
        return <TrendingDown className="h-4 w-4 text-orange-600" />;
      case 'critical':
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      default:
        return <Minus className="h-4 w-4 text-gray-600" />;
    }
  };

  const getConfidenceBadge = (confidence: string) => {
    const colors: Record<string, string> = {
      'very-high': 'bg-green-100 text-green-800',
      'high': 'bg-blue-100 text-blue-800',
      'medium': 'bg-yellow-100 text-yellow-800',
      'low': 'bg-gray-100 text-gray-800'
    };
    return colors[confidence] || colors.low;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good':
        return 'bg-green-100 text-green-800';
      case 'warning':
        return 'bg-yellow-100 text-yellow-800';
      case 'bad':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const domainSignals = selectedDomain
    ? signals.filter((s: HealthSignalDefinition) => s.domainId === selectedDomain)
    : [];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Predictive Health Forecasting
          </CardTitle>
          <CardDescription>
            AI-powered predictions of future health trends
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label>Domain</Label>
              <Select value={selectedDomain} onValueChange={setSelectedDomain}>
                <SelectTrigger>
                  <SelectValue placeholder="Select domain" />
                </SelectTrigger>
                <SelectContent>
                  {domains.map((domain: HealthDomain) => (
                    <SelectItem key={domain.id} value={domain.id}>
                      {domain.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Signal (Optional)</Label>
              <Select value={selectedSignal} onValueChange={setSelectedSignal}>
                <SelectTrigger>
                  <SelectValue placeholder="All signals" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All signals</SelectItem>
                  {domainSignals.map((signal: HealthSignalDefinition) => (
                    <SelectItem key={signal.id} value={signal.id}>
                      {signal.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Days Ahead</Label>
              <Input
                type="number"
                value={daysAhead}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setDaysAhead(parseInt(e.target.value) || 7)}
                min={1}
                max={30}
              />
            </div>

            <div className="flex items-end">
              <Button onClick={handleGeneratePrediction} disabled={!selectedDomain} className="w-full">
                <Sparkles className="h-4 w-4 mr-2" />
                Generate Prediction
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-4">
        {predictions.map((prediction: HealthPrediction) => {
          const domain = domains.find((d: HealthDomain) => d.id === prediction.domainId);
          const signal = prediction.signalId
            ? signals.find((s: HealthSignalDefinition) => s.id === prediction.signalId)
            : null;

          return (
            <Card key={prediction.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">
                      {domain?.name || 'Unknown Domain'}
                      {signal && ` - ${signal.name}`}
                    </CardTitle>
                    <CardDescription>
                      Prediction for {new Date(prediction.predictionDate).toLocaleDateString()}
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    {getTrendIcon(prediction.trendDirection)}
                    <Badge className={getConfidenceBadge(prediction.confidence)}>
                      {prediction.confidence} confidence
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">Predicted Score</p>
                    <p className="text-2xl font-bold">{prediction.predictedScore}/100</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Predicted Status</p>
                    <Badge className={getStatusColor(prediction.predictedStatus)}>
                      {prediction.predictedStatus}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Trend</p>
                    <p className="text-lg font-semibold capitalize">{prediction.trendDirection}</p>
                  </div>
                </div>

                {prediction.riskFactors.length > 0 && (
                  <div>
                    <p className="font-semibold text-sm mb-2">Risk Factors:</p>
                    <ul className="space-y-1">
                      {prediction.riskFactors.map((risk: string, idx: number) => (
                        <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
                          <span className="text-red-600">•</span>
                          {risk}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {prediction.preventiveActions.length > 0 && (
                  <div>
                    <p className="font-semibold text-sm mb-2">Preventive Actions:</p>
                    <ul className="space-y-1">
                      {prediction.preventiveActions.map((action: string, idx: number) => (
                        <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
                          <span className="text-blue-600">→</span>
                          {action}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <p className="text-xs text-gray-500">
                  Generated {new Date(prediction.timestamp).toLocaleString()} • 
                  Based on {prediction.basedOnSamples.length} samples
                </p>
              </CardContent>
            </Card>
          );
        })}

        {predictions.length === 0 && (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Brain className="h-12 w-12 text-gray-400 mb-4" />
              <p className="text-gray-600">No predictions yet. Generate your first health forecast!</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
