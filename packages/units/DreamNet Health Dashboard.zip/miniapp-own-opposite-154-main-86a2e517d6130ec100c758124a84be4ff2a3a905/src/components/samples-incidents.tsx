'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Activity, AlertCircle } from 'lucide-react';
import type { HealthSample, Incident, HealthDomain, HealthSignalDefinition, SampleStatus, IncidentSeverity, IncidentStatus } from '@/types/health';
import { getHealthSamples, recordHealthSample, getIncidents, createIncident, getHealthDomains, getHealthSignals } from '@/lib/healthLogic';

export default function SamplesIncidents() {
  const [samples, setSamples] = useState<HealthSample[]>([]);
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [domains, setDomains] = useState<HealthDomain[]>([]);
  const [signals, setSignals] = useState<HealthSignalDefinition[]>([]);
  
  const [sampleFilters, setSampleFilters] = useState({
    domainId: 'all',
    signalId: 'all',
    status: 'all'
  });
  
  const [incidentFilters, setIncidentFilters] = useState({
    domainId: 'all',
    severity: 'all',
    status: 'all'
  });
  
  const [isAddingSample, setIsAddingSample] = useState<boolean>(false);
  const [isAddingIncident, setIsAddingIncident] = useState<boolean>(false);
  
  const [newSample, setNewSample] = useState({
    domainId: '',
    signalId: '',
    valueNumber: '',
    valueText: '',
    status: 'good' as SampleStatus,
    notes: ''
  });
  
  const [newIncident, setNewIncident] = useState({
    domainId: '',
    title: '',
    description: '',
    severity: 'medium' as IncidentSeverity,
    status: 'open' as IncidentStatus,
    relatedSignals: '',
    relatedObjects: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setSamples(getHealthSamples());
    setIncidents(getIncidents());
    setDomains(getHealthDomains());
    setSignals(getHealthSignals());
  };

  const handleAddSample = () => {
    recordHealthSample({
      domainId: newSample.domainId,
      signalId: newSample.signalId,
      valueNumber: newSample.valueNumber ? Number(newSample.valueNumber) : null,
      valueText: newSample.valueText || null,
      status: newSample.status,
      notes: newSample.notes
    });
    
    setNewSample({
      domainId: '',
      signalId: '',
      valueNumber: '',
      valueText: '',
      status: 'good',
      notes: ''
    });
    setIsAddingSample(false);
    loadData();
  };

  const handleAddIncident = () => {
    createIncident({
      domainId: newIncident.domainId,
      title: newIncident.title,
      description: newIncident.description,
      severity: newIncident.severity,
      status: newIncident.status,
      relatedSignals: newIncident.relatedSignals.split(',').map((s: string) => s.trim()).filter((s: string) => s),
      relatedObjects: newIncident.relatedObjects.split(',').map((o: string) => o.trim()).filter((o: string) => o)
    });
    
    setNewIncident({
      domainId: '',
      title: '',
      description: '',
      severity: 'medium',
      status: 'open',
      relatedSignals: '',
      relatedObjects: ''
    });
    setIsAddingIncident(false);
    loadData();
  };

  const filteredSamples = samples.filter((sample: HealthSample) => {
    if (sampleFilters.domainId !== 'all' && sample.domainId !== sampleFilters.domainId) return false;
    if (sampleFilters.signalId !== 'all' && sample.signalId !== sampleFilters.signalId) return false;
    if (sampleFilters.status !== 'all' && sample.status !== sampleFilters.status) return false;
    return true;
  });

  const filteredIncidents = incidents.filter((incident: Incident) => {
    if (incidentFilters.domainId !== 'all' && incident.domainId !== incidentFilters.domainId) return false;
    if (incidentFilters.severity !== 'all' && incident.severity !== incidentFilters.severity) return false;
    if (incidentFilters.status !== 'all' && incident.status !== incidentFilters.status) return false;
    return true;
  });

  const getStatusBadge = (status: SampleStatus) => {
    const variants: Record<SampleStatus, string> = {
      good: 'bg-green-100 text-green-800 border-green-300',
      warning: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      bad: 'bg-red-100 text-red-800 border-red-300',
      unknown: 'bg-gray-100 text-gray-800 border-gray-300'
    };
    
    return (
      <Badge variant="outline" className={variants[status]}>
        {status}
      </Badge>
    );
  };

  const getSeverityBadge = (severity: IncidentSeverity) => {
    const variants: Record<IncidentSeverity, string> = {
      low: 'bg-blue-100 text-blue-800 border-blue-300',
      medium: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      high: 'bg-orange-100 text-orange-800 border-orange-300',
      critical: 'bg-red-100 text-red-800 border-red-300'
    };
    
    return (
      <Badge variant="outline" className={variants[severity]}>
        {severity}
      </Badge>
    );
  };

  const getIncidentStatusBadge = (status: IncidentStatus) => {
    const variants: Record<IncidentStatus, string> = {
      open: 'bg-red-100 text-red-800 border-red-300',
      monitoring: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      resolved: 'bg-green-100 text-green-800 border-green-300',
      ignored: 'bg-gray-100 text-gray-800 border-gray-300'
    };
    
    return (
      <Badge variant="outline" className={variants[status]}>
        {status}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Samples & Incidents</h2>
          <p className="text-gray-600">Track health samples and system incidents</p>
        </div>
        <Activity className="h-8 w-8 text-blue-500" />
      </div>

      <Tabs defaultValue="samples" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="samples">Health Samples</TabsTrigger>
          <TabsTrigger value="incidents">Incidents</TabsTrigger>
        </TabsList>

        <TabsContent value="samples" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Health Samples
                  </CardTitle>
                  <CardDescription>Recorded health signal measurements</CardDescription>
                </div>
                <Dialog open={isAddingSample} onOpenChange={setIsAddingSample}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus className="h-4 w-4 mr-2" />
                      Record Sample
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Record Health Sample</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="sampleDomain">Domain</Label>
                        <Select
                          value={newSample.domainId}
                          onValueChange={(value: string) => setNewSample({ ...newSample, domainId: value })}
                        >
                          <SelectTrigger id="sampleDomain">
                            <SelectValue placeholder="Select domain" />
                          </SelectTrigger>
                          <SelectContent>
                            {domains.map((domain: HealthDomain) => (
                              <SelectItem key={domain.id} value={domain.id}>
                                {domain.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="sampleSignal">Signal</Label>
                        <Select
                          value={newSample.signalId}
                          onValueChange={(value: string) => setNewSample({ ...newSample, signalId: value })}
                        >
                          <SelectTrigger id="sampleSignal">
                            <SelectValue placeholder="Select signal" />
                          </SelectTrigger>
                          <SelectContent>
                            {signals
                              .filter((s: HealthSignalDefinition) => !newSample.domainId || s.domainId === newSample.domainId)
                              .map((signal: HealthSignalDefinition) => (
                                <SelectItem key={signal.id} value={signal.id}>
                                  {signal.name}
                                </SelectItem>
                              ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="sampleValueNumber">Value (Number)</Label>
                        <Input
                          id="sampleValueNumber"
                          type="number"
                          value={newSample.valueNumber}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewSample({ ...newSample, valueNumber: e.target.value })}
                          placeholder="Optional numeric value"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="sampleValueText">Value (Text)</Label>
                        <Input
                          id="sampleValueText"
                          value={newSample.valueText}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewSample({ ...newSample, valueText: e.target.value })}
                          placeholder="Optional text value"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="sampleStatus">Status</Label>
                        <Select
                          value={newSample.status}
                          onValueChange={(value: SampleStatus) => setNewSample({ ...newSample, status: value })}
                        >
                          <SelectTrigger id="sampleStatus">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="good">Good</SelectItem>
                            <SelectItem value="warning">Warning</SelectItem>
                            <SelectItem value="bad">Bad</SelectItem>
                            <SelectItem value="unknown">Unknown</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="sampleNotes">Notes</Label>
                        <Textarea
                          id="sampleNotes"
                          value={newSample.notes}
                          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNewSample({ ...newSample, notes: e.target.value })}
                          placeholder="Additional notes"
                        />
                      </div>
                      
                      <Button onClick={handleAddSample} className="w-full">Record Sample</Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 mb-4">
                <div className="flex-1">
                  <Label htmlFor="filterSampleDomain">Filter by Domain</Label>
                  <Select 
                    value={sampleFilters.domainId} 
                    onValueChange={(value: string) => setSampleFilters({ ...sampleFilters, domainId: value })}
                  >
                    <SelectTrigger id="filterSampleDomain">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Domains</SelectItem>
                      {domains.map((domain: HealthDomain) => (
                        <SelectItem key={domain.id} value={domain.id}>
                          {domain.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex-1">
                  <Label htmlFor="filterSampleStatus">Filter by Status</Label>
                  <Select 
                    value={sampleFilters.status} 
                    onValueChange={(value: string) => setSampleFilters({ ...sampleFilters, status: value })}
                  >
                    <SelectTrigger id="filterSampleStatus">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="good">Good</SelectItem>
                      <SelectItem value="warning">Warning</SelectItem>
                      <SelectItem value="bad">Bad</SelectItem>
                      <SelectItem value="unknown">Unknown</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>Domain</TableHead>
                    <TableHead>Signal</TableHead>
                    <TableHead>Value</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSamples.map((sample: HealthSample) => {
                    const domain = domains.find((d: HealthDomain) => d.id === sample.domainId);
                    const signal = signals.find((s: HealthSignalDefinition) => s.id === sample.signalId);
                    const value = sample.valueNumber !== null ? sample.valueNumber : sample.valueText || '-';
                    
                    return (
                      <TableRow key={sample.id}>
                        <TableCell className="text-sm">
                          {new Date(sample.timestamp).toLocaleString()}
                        </TableCell>
                        <TableCell>{domain?.name || 'Unknown'}</TableCell>
                        <TableCell>{signal?.name || 'Unknown'}</TableCell>
                        <TableCell>{value}</TableCell>
                        <TableCell>{getStatusBadge(sample.status)}</TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="incidents" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <AlertCircle className="h-5 w-5" />
                    Incidents
                  </CardTitle>
                  <CardDescription>System health incidents and issues</CardDescription>
                </div>
                <Dialog open={isAddingIncident} onOpenChange={setIsAddingIncident}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus className="h-4 w-4 mr-2" />
                      Create Incident
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Create Incident</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="incidentDomain">Domain</Label>
                        <Select
                          value={newIncident.domainId}
                          onValueChange={(value: string) => setNewIncident({ ...newIncident, domainId: value })}
                        >
                          <SelectTrigger id="incidentDomain">
                            <SelectValue placeholder="Select domain" />
                          </SelectTrigger>
                          <SelectContent>
                            {domains.map((domain: HealthDomain) => (
                              <SelectItem key={domain.id} value={domain.id}>
                                {domain.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="incidentTitle">Title</Label>
                        <Input
                          id="incidentTitle"
                          value={newIncident.title}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewIncident({ ...newIncident, title: e.target.value })}
                          placeholder="Brief incident title"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="incidentDescription">Description</Label>
                        <Textarea
                          id="incidentDescription"
                          value={newIncident.description}
                          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNewIncident({ ...newIncident, description: e.target.value })}
                          placeholder="Detailed description"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="incidentSeverity">Severity</Label>
                        <Select
                          value={newIncident.severity}
                          onValueChange={(value: IncidentSeverity) => setNewIncident({ ...newIncident, severity: value })}
                        >
                          <SelectTrigger id="incidentSeverity">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Low</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="critical">Critical</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="incidentStatus">Status</Label>
                        <Select
                          value={newIncident.status}
                          onValueChange={(value: IncidentStatus) => setNewIncident({ ...newIncident, status: value })}
                        >
                          <SelectTrigger id="incidentStatus">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="open">Open</SelectItem>
                            <SelectItem value="monitoring">Monitoring</SelectItem>
                            <SelectItem value="resolved">Resolved</SelectItem>
                            <SelectItem value="ignored">Ignored</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <Button onClick={handleAddIncident} className="w-full">Create Incident</Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 mb-4">
                <div className="flex-1">
                  <Label htmlFor="filterIncidentDomain">Filter by Domain</Label>
                  <Select 
                    value={incidentFilters.domainId} 
                    onValueChange={(value: string) => setIncidentFilters({ ...incidentFilters, domainId: value })}
                  >
                    <SelectTrigger id="filterIncidentDomain">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Domains</SelectItem>
                      {domains.map((domain: HealthDomain) => (
                        <SelectItem key={domain.id} value={domain.id}>
                          {domain.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex-1">
                  <Label htmlFor="filterIncidentSeverity">Filter by Severity</Label>
                  <Select 
                    value={incidentFilters.severity} 
                    onValueChange={(value: string) => setIncidentFilters({ ...incidentFilters, severity: value })}
                  >
                    <SelectTrigger id="filterIncidentSeverity">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Severities</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex-1">
                  <Label htmlFor="filterIncidentStatus">Filter by Status</Label>
                  <Select 
                    value={incidentFilters.status} 
                    onValueChange={(value: string) => setIncidentFilters({ ...incidentFilters, status: value })}
                  >
                    <SelectTrigger id="filterIncidentStatus">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="open">Open</SelectItem>
                      <SelectItem value="monitoring">Monitoring</SelectItem>
                      <SelectItem value="resolved">Resolved</SelectItem>
                      <SelectItem value="ignored">Ignored</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Domain</TableHead>
                    <TableHead>Severity</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Detected At</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredIncidents.map((incident: Incident) => {
                    const domain = domains.find((d: HealthDomain) => d.id === incident.domainId);
                    
                    return (
                      <TableRow key={incident.id}>
                        <TableCell className="font-semibold">{incident.title}</TableCell>
                        <TableCell>{domain?.name || 'Unknown'}</TableCell>
                        <TableCell>{getSeverityBadge(incident.severity)}</TableCell>
                        <TableCell>{getIncidentStatusBadge(incident.status)}</TableCell>
                        <TableCell className="text-sm">
                          {new Date(incident.detectedAt).toLocaleString()}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
