'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MessageSquare, Plus, TrendingUp, TrendingDown, Smile, Frown, Meh } from 'lucide-react';
import { getHealthDomains } from '@/lib/healthLogic';
import { createSocialChannel, recordSocialPulse, getSocialPulses, getSocialChannels } from '@/lib/advancedLogic';
import type { SocialPulse, SocialChannel } from '@/types/advanced-features';
import type { HealthDomain } from '@/types/health';

export default function SocialPulse() {
  const [domains, setDomains] = useState<HealthDomain[]>([]);
  const [channels, setChannels] = useState<SocialChannel[]>([]);
  const [pulses, setPulses] = useState<SocialPulse[]>([]);
  const [showNewChannel, setShowNewChannel] = useState<boolean>(false);
  const [showNewPulse, setShowNewPulse] = useState<boolean>(false);

  const [newChannel, setNewChannel] = useState({
    name: '',
    type: 'twitter',
    monitoredDomains: [] as string[],
    keywords: [] as string[]
  });

  const [newPulse, setNewPulse] = useState({
    domainId: '',
    channel: '',
    contentSample: '',
    keywords: '',
    mentions: 0,
    engagement: 0
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setDomains(getHealthDomains());
    setChannels(getSocialChannels());
    setPulses(getSocialPulses());
  };

  const handleCreateChannel = () => {
    if (!newChannel.name || !newChannel.type) return;

    createSocialChannel(newChannel);
    setChannels(getSocialChannels());
    setShowNewChannel(false);
    setNewChannel({
      name: '',
      type: 'twitter',
      monitoredDomains: [],
      keywords: []
    });
  };

  const handleRecordPulse = () => {
    if (!newPulse.domainId || !newPulse.channel || !newPulse.contentSample) return;

    recordSocialPulse({
      ...newPulse,
      keywords: newPulse.keywords.split(',').map((k: string) => k.trim()).filter(Boolean)
    });
    setPulses(getSocialPulses());
    setShowNewPulse(false);
    setNewPulse({
      domainId: '',
      channel: '',
      contentSample: '',
      keywords: '',
      mentions: 0,
      engagement: 0
    });
  };

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'positive':
        return <Smile className="h-4 w-4 text-green-600" />;
      case 'negative':
        return <Frown className="h-4 w-4 text-red-600" />;
      case 'mixed':
        return <Meh className="h-4 w-4 text-orange-600" />;
      default:
        return <Meh className="h-4 w-4 text-gray-600" />;
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive':
        return 'bg-green-100 text-green-800';
      case 'negative':
        return 'bg-red-100 text-red-800';
      case 'mixed':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'positive':
        return 'bg-green-100 text-green-800';
      case 'negative':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const avgSentiment = pulses.length > 0
    ? pulses.reduce((sum: number, p: SocialPulse) => sum + p.sentimentScore, 0) / pulses.length
    : 0;

  const positivePulses = pulses.filter((p: SocialPulse) => p.sentiment === 'positive').length;
  const negativePulses = pulses.filter((p: SocialPulse) => p.sentiment === 'negative').length;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Social Health Pulse
          </CardTitle>
          <CardDescription>
            Monitor cultural resonance and social sentiment
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
            <div>
              <p className="text-sm text-gray-600">Active Channels</p>
              <p className="text-2xl font-bold">
                {channels.filter((c: SocialChannel) => c.enabled).length}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Pulses</p>
              <p className="text-2xl font-bold">{pulses.length}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Avg Sentiment</p>
              <div className="flex items-center gap-2">
                <p className="text-2xl font-bold">{Math.round(avgSentiment)}</p>
                {avgSentiment > 0 ? (
                  <TrendingUp className="h-5 w-5 text-green-600" />
                ) : avgSentiment < 0 ? (
                  <TrendingDown className="h-5 w-5 text-red-600" />
                ) : null}
              </div>
            </div>
            <div>
              <p className="text-sm text-gray-600">Positive/Negative</p>
              <p className="text-2xl font-bold">
                {positivePulses}/{negativePulses}
              </p>
            </div>
          </div>

          <div className="flex gap-2">
            <Button onClick={() => setShowNewChannel(!showNewChannel)} variant="outline" className="flex-1">
              <Plus className="h-4 w-4 mr-2" />
              New Channel
            </Button>
            <Button onClick={() => setShowNewPulse(!showNewPulse)} className="flex-1">
              <Plus className="h-4 w-4 mr-2" />
              Record Pulse
            </Button>
          </div>
        </CardContent>
      </Card>

      {showNewChannel && (
        <Card>
          <CardHeader>
            <CardTitle>Create Social Channel</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Channel Name</Label>
                <Input
                  value={newChannel.name}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewChannel({ ...newChannel, name: e.target.value })}
                  placeholder="e.g., DreamNet Twitter"
                />
              </div>
              <div>
                <Label>Type</Label>
                <Select value={newChannel.type} onValueChange={(value: string) => setNewChannel({ ...newChannel, type: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="twitter">Twitter</SelectItem>
                    <SelectItem value="discord">Discord</SelectItem>
                    <SelectItem value="farcaster">Farcaster</SelectItem>
                    <SelectItem value="telegram">Telegram</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleCreateChannel} disabled={!newChannel.name}>
                Create Channel
              </Button>
              <Button variant="outline" onClick={() => setShowNewChannel(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {showNewPulse && (
        <Card>
          <CardHeader>
            <CardTitle>Record Social Pulse</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Domain</Label>
                <Select value={newPulse.domainId} onValueChange={(value: string) => setNewPulse({ ...newPulse, domainId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select domain" />
                  </SelectTrigger>
                  <SelectContent>
                    {domains.map((domain: HealthDomain) => (
                      <SelectItem key={domain.id} value={domain.id}>
                        {domain.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Channel</Label>
                <Select value={newPulse.channel} onValueChange={(value: string) => setNewPulse({ ...newPulse, channel: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select channel" />
                  </SelectTrigger>
                  <SelectContent>
                    {channels.map((channel: SocialChannel) => (
                      <SelectItem key={channel.id} value={channel.name}>
                        {channel.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Content Sample</Label>
              <Textarea
                value={newPulse.contentSample}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNewPulse({ ...newPulse, contentSample: e.target.value })}
                placeholder="Paste social content here..."
                rows={4}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label>Keywords (comma-separated)</Label>
                <Input
                  value={newPulse.keywords}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewPulse({ ...newPulse, keywords: e.target.value })}
                  placeholder="dreamnet, culture, meme"
                />
              </div>
              <div>
                <Label>Mentions</Label>
                <Input
                  type="number"
                  value={newPulse.mentions}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewPulse({ ...newPulse, mentions: parseInt(e.target.value) || 0 })}
                />
              </div>
              <div>
                <Label>Engagement</Label>
                <Input
                  type="number"
                  value={newPulse.engagement}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewPulse({ ...newPulse, engagement: parseInt(e.target.value) || 0 })}
                />
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleRecordPulse} disabled={!newPulse.domainId || !newPulse.channel || !newPulse.contentSample}>
                Record Pulse
              </Button>
              <Button variant="outline" onClick={() => setShowNewPulse(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="pulses">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="pulses">Pulses</TabsTrigger>
          <TabsTrigger value="channels">Channels</TabsTrigger>
        </TabsList>

        <TabsContent value="pulses" className="space-y-4">
          {pulses.map((pulse: SocialPulse) => {
            const domain = domains.find((d: HealthDomain) => d.id === pulse.domainId);

            return (
              <Card key={pulse.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg flex items-center gap-2">
                        {getSentimentIcon(pulse.sentiment)}
                        {domain?.name || 'Unknown Domain'}
                      </CardTitle>
                      <CardDescription>
                        {pulse.channel} • {new Date(pulse.timestamp).toLocaleString()}
                      </CardDescription>
                    </div>
                    <div className="flex flex-col gap-2 items-end">
                      <Badge className={getSentimentColor(pulse.sentiment)}>
                        {pulse.sentiment}
                      </Badge>
                      <Badge className={getImpactColor(pulse.healthImpact)}>
                        {pulse.healthImpact} impact
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <p className="text-sm font-medium mb-1">Content:</p>
                    <p className="text-sm bg-gray-50 p-3 rounded">
                      {pulse.contentSample}
                    </p>
                  </div>

                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Score:</span>{' '}
                      <span className={`font-semibold ${pulse.sentimentScore > 0 ? 'text-green-600' : pulse.sentimentScore < 0 ? 'text-red-600' : ''}`}>
                        {pulse.sentimentScore > 0 ? '+' : ''}{pulse.sentimentScore}
                      </span>
                    </div>
                    <div>
                      <span className="text-gray-600">Mentions:</span> {pulse.mentions}
                    </div>
                    <div>
                      <span className="text-gray-600">Engagement:</span> {pulse.engagement}
                    </div>
                  </div>

                  {pulse.keywords.length > 0 && (
                    <div className="flex gap-2 flex-wrap">
                      {pulse.keywords.map((keyword: string, idx: number) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {keyword}
                        </Badge>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}

          {pulses.length === 0 && (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <MessageSquare className="h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-600">No social pulses yet. Start recording social sentiment!</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="channels" className="space-y-4">
          {channels.map((channel: SocialChannel) => (
            <Card key={channel.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{channel.name}</CardTitle>
                    <CardDescription>Type: {channel.type}</CardDescription>
                  </div>
                  <Badge variant={channel.enabled ? 'default' : 'secondary'}>
                    {channel.enabled ? 'Active' : 'Inactive'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="text-gray-600">Pulses:</span> {channel.pulseCount}
                  </div>
                  <div>
                    <span className="text-gray-600">Avg Sentiment:</span>{' '}
                    <span className={channel.avgSentiment > 0 ? 'text-green-600' : channel.avgSentiment < 0 ? 'text-red-600' : ''}>
                      {Math.round(channel.avgSentiment)}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-600">Last Check:</span>{' '}
                    {channel.lastChecked ? new Date(channel.lastChecked).toLocaleString() : 'Never'}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {channels.length === 0 && (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <MessageSquare className="h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-600">No channels configured. Create your first social channel!</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
