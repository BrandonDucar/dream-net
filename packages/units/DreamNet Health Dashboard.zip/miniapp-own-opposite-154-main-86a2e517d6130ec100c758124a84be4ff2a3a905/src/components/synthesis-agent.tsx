'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Bot, Plus, CheckCircle, XCircle, Clock, Play } from 'lucide-react';
import { getHealthDomains, getHealthSignals } from '@/lib/healthLogic';
import { 
  createSynthesisRule, 
  getSynthesisRules, 
  getSynthesisEvents,
  triggerSynthesisRule,
  approveSynthesisEvent
} from '@/lib/advancedLogic';
import type { SynthesisRule, SynthesisEvent, SynthesisSource } from '@/types/advanced-features';
import type { HealthDomain, HealthSignalDefinition } from '@/types/health';

export default function SynthesisAgent() {
  const [domains, setDomains] = useState<HealthDomain[]>([]);
  const [signals, setSignals] = useState<HealthSignalDefinition[]>([]);
  const [rules, setRules] = useState<SynthesisRule[]>([]);
  const [events, setEvents] = useState<SynthesisEvent[]>([]);
  const [showNewRule, setShowNewRule] = useState<boolean>(false);

  const [newRule, setNewRule] = useState({
    name: '',
    description: '',
    domainId: '',
    signalId: '',
    triggerPattern: '',
    sourceType: 'auto-detected' as SynthesisSource,
    sourceIdentifier: '',
    autoApprove: false,
    statusMapping: [
      { pattern: 'error', status: 'bad' as const },
      { pattern: 'warning', status: 'warning' as const },
      { pattern: 'success', status: 'good' as const }
    ]
  });

  const [testData, setTestData] = useState<string>('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setDomains(getHealthDomains());
    setSignals(getHealthSignals());
    setRules(getSynthesisRules());
    setEvents(getSynthesisEvents());
  };

  const handleCreateRule = () => {
    if (!newRule.name || !newRule.domainId || !newRule.signalId) return;

    createSynthesisRule(newRule);
    setRules(getSynthesisRules());
    setShowNewRule(false);
    setNewRule({
      name: '',
      description: '',
      domainId: '',
      signalId: '',
      triggerPattern: '',
      sourceType: 'auto-detected',
      sourceIdentifier: '',
      autoApprove: false,
      statusMapping: [
        { pattern: 'error', status: 'bad' },
        { pattern: 'warning', status: 'warning' },
        { pattern: 'success', status: 'good' }
      ]
    });
  };

  const handleTestRule = (ruleId: string) => {
    if (!testData) return;
    
    const event = triggerSynthesisRule({
      ruleId,
      sourceData: testData
    });

    if (event) {
      setEvents(getSynthesisEvents());
      setTestData('');
    }
  };

  const handleApproveEvent = (eventId: string) => {
    approveSynthesisEvent(eventId, 'Manual Review');
    setEvents(getSynthesisEvents());
  };

  const domainSignals = newRule.domainId
    ? signals.filter((s: HealthSignalDefinition) => s.domainId === newRule.domainId)
    : [];

  const pendingEvents = events.filter((e: SynthesisEvent) => !e.approved);
  const approvedEvents = events.filter((e: SynthesisEvent) => e.approved);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot className="h-5 w-5" />
            Automated Health Synthesis Agent
          </CardTitle>
          <CardDescription>
            Auto-detect and log health signals from external sources
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <p className="text-sm text-gray-600">Active Rules</p>
              <p className="text-2xl font-bold">
                {rules.filter((r: SynthesisRule) => r.enabled).length}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Pending Events</p>
              <p className="text-2xl font-bold">{pendingEvents.length}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Auto-Applied</p>
              <p className="text-2xl font-bold">
                {events.filter((e: SynthesisEvent) => e.autoApplied).length}
              </p>
            </div>
          </div>

          <Button onClick={() => setShowNewRule(!showNewRule)} className="w-full">
            <Plus className="h-4 w-4 mr-2" />
            New Synthesis Rule
          </Button>
        </CardContent>
      </Card>

      {showNewRule && (
        <Card>
          <CardHeader>
            <CardTitle>Create Synthesis Rule</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Rule Name</Label>
                <Input
                  value={newRule.name}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewRule({ ...newRule, name: e.target.value })}
                  placeholder="e.g., Ops Error Detector"
                />
              </div>
              <div>
                <Label>Source Identifier</Label>
                <Input
                  value={newRule.sourceIdentifier}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewRule({ ...newRule, sourceIdentifier: e.target.value })}
                  placeholder="e.g., ops-app, log-file"
                />
              </div>
            </div>

            <div>
              <Label>Description</Label>
              <Textarea
                value={newRule.description}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNewRule({ ...newRule, description: e.target.value })}
                placeholder="What does this rule detect?"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Domain</Label>
                <Select value={newRule.domainId} onValueChange={(value: string) => setNewRule({ ...newRule, domainId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select domain" />
                  </SelectTrigger>
                  <SelectContent>
                    {domains.map((domain: HealthDomain) => (
                      <SelectItem key={domain.id} value={domain.id}>
                        {domain.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Signal</Label>
                <Select value={newRule.signalId} onValueChange={(value: string) => setNewRule({ ...newRule, signalId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select signal" />
                  </SelectTrigger>
                  <SelectContent>
                    {domainSignals.map((signal: HealthSignalDefinition) => (
                      <SelectItem key={signal.id} value={signal.id}>
                        {signal.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Trigger Pattern</Label>
              <Input
                value={newRule.triggerPattern}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewRule({ ...newRule, triggerPattern: e.target.value })}
                placeholder="Keywords to match (comma-separated)"
              />
            </div>

            <div className="flex items-center gap-2">
              <Switch
                checked={newRule.autoApprove}
                onCheckedChange={(checked: boolean) => setNewRule({ ...newRule, autoApprove: checked })}
              />
              <Label>Auto-approve detected events</Label>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleCreateRule} disabled={!newRule.name || !newRule.domainId || !newRule.signalId}>
                Create Rule
              </Button>
              <Button variant="outline" onClick={() => setShowNewRule(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="rules">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="rules">Rules</TabsTrigger>
          <TabsTrigger value="pending">Pending ({pendingEvents.length})</TabsTrigger>
          <TabsTrigger value="approved">Approved ({approvedEvents.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="rules" className="space-y-4">
          {rules.map((rule: SynthesisRule) => {
            const domain = domains.find((d: HealthDomain) => d.id === rule.domainId);
            const signal = signals.find((s: HealthSignalDefinition) => s.id === rule.signalId);

            return (
              <Card key={rule.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{rule.name}</CardTitle>
                      <CardDescription>{rule.description}</CardDescription>
                    </div>
                    <Badge variant={rule.enabled ? 'default' : 'secondary'}>
                      {rule.enabled ? 'Active' : 'Disabled'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                    <div>
                      <span className="text-gray-600">Domain:</span> {domain?.name}
                    </div>
                    <div>
                      <span className="text-gray-600">Signal:</span> {signal?.name}
                    </div>
                    <div>
                      <span className="text-gray-600">Source:</span> {rule.sourceIdentifier}
                    </div>
                    <div>
                      <span className="text-gray-600">Triggered:</span> {rule.timesTriggered}x
                    </div>
                  </div>

                  <div>
                    <Label className="text-xs">Test Rule</Label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Enter test data..."
                        value={testData}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTestData(e.target.value)}
                      />
                      <Button size="sm" onClick={() => handleTestRule(rule.id)}>
                        <Play className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}

          {rules.length === 0 && (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Bot className="h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-600">No synthesis rules yet. Create one to start auto-detecting health!</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="pending" className="space-y-4">
          {pendingEvents.map((event: SynthesisEvent) => {
            const rule = rules.find((r: SynthesisRule) => r.id === event.ruleId);

            return (
              <Card key={event.id}>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Clock className="h-4 w-4 text-orange-600" />
                    Pending Approval
                  </CardTitle>
                  <CardDescription>Detected by: {rule?.name}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <Label className="text-xs">Source Data</Label>
                    <p className="text-sm bg-gray-50 p-2 rounded">{event.sourceData}</p>
                  </div>
                  <div>
                    <Label className="text-xs">Suggested Sample</Label>
                    <div className="text-sm space-y-1">
                      <div>Status: <Badge>{event.suggestedSample.status}</Badge></div>
                      <div>Notes: {event.suggestedSample.notes}</div>
                    </div>
                  </div>
                  <Button onClick={() => handleApproveEvent(event.id)} size="sm">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Approve & Apply
                  </Button>
                </CardContent>
              </Card>
            );
          })}

          {pendingEvents.length === 0 && (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <CheckCircle className="h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-600">No pending events. All clear!</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="approved" className="space-y-4">
          {approvedEvents.map((event: SynthesisEvent) => {
            const rule = rules.find((r: SynthesisRule) => r.id === event.ruleId);

            return (
              <Card key={event.id}>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    {event.autoApplied ? 'Auto-Applied' : 'Approved'}
                  </CardTitle>
                  <CardDescription>
                    {rule?.name} • {new Date(event.timestamp).toLocaleString()}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-sm space-y-1">
                    <div>Pattern: <span className="font-mono">{event.detectedPattern}</span></div>
                    <div>Status: <Badge>{event.suggestedSample.status}</Badge></div>
                    {event.reviewedBy && (
                      <div className="text-xs text-gray-500">Reviewed by: {event.reviewedBy}</div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}

          {approvedEvents.length === 0 && (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <XCircle className="h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-600">No approved events yet.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
