import type {
  HealthPrediction,
  HealthCorrelation,
  SynthesisRule,
  SynthesisEvent,
  SocialPulse,
  SocialChannel,
  GeneratedPlaybook,
  PlaybookSection,
  PredictionConfidence,
  TrendDirection,
  CorrelationType,
  SynthesisSource,
  SentimentType
} from '@/types/advanced-features';
import { getAdvancedStore, saveAdvancedStore } from './advancedStore';
import { generateId } from './healthStore';
import { getHealthSamples, getHealthSignals, getIncidents, getHealthDomains } from './healthLogic';
import type { HealthSample } from '@/types/health';

// ==================== 1. PREDICTIVE HEALTH FORECASTING ====================

export function generateHealthPrediction(params: {
  domainId: string;
  signalId?: string | null;
  daysAhead: number;
}): HealthPrediction {
  const store = getAdvancedStore();
  
  // Get historical samples for this signal/domain
  const samples = getHealthSamples({
    domainId: params.domainId,
    signalId: params.signalId || undefined
  }).slice(0, 30); // last 30 samples
  
  // Simple trend analysis
  const recentScores = samples.map((s: HealthSample) => {
    if (s.status === 'good') return 100;
    if (s.status === 'warning') return 50;
    if (s.status === 'bad') return 0;
    return 25;
  });
  
  const avgScore = recentScores.length > 0 
    ? recentScores.reduce((a: number, b: number) => a + b, 0) / recentScores.length
    : 50;
  
  // Detect trend
  let trend: TrendDirection = 'stable';
  let predictedScore = avgScore;
  
  if (recentScores.length >= 3) {
    const recent = recentScores.slice(0, 3);
    const older = recentScores.slice(3, 6);
    const recentAvg = recent.reduce((a: number, b: number) => a + b, 0) / recent.length;
    const olderAvg = older.length > 0 ? older.reduce((a: number, b: number) => a + b, 0) / older.length : recentAvg;
    
    const delta = recentAvg - olderAvg;
    
    if (delta > 15) {
      trend = 'improving';
      predictedScore = Math.min(100, avgScore + delta * 0.5);
    } else if (delta < -15) {
      trend = 'degrading';
      predictedScore = Math.max(0, avgScore + delta * 0.5);
    } else if (recentAvg < 30) {
      trend = 'critical';
      predictedScore = Math.max(0, avgScore - 10);
    }
  }
  
  // Determine confidence
  const confidence: PredictionConfidence = 
    recentScores.length >= 20 ? 'very-high' :
    recentScores.length >= 10 ? 'high' :
    recentScores.length >= 5 ? 'medium' : 'low';
  
  // Generate risk factors and actions
  const riskFactors: string[] = [];
  const preventiveActions: string[] = [];
  
  if (trend === 'degrading' || trend === 'critical') {
    riskFactors.push('Declining trend detected in recent samples');
    riskFactors.push(`Health score projected to drop to ${Math.round(predictedScore)}/100`);
    preventiveActions.push('Increase monitoring frequency');
    preventiveActions.push('Review recent changes that may have caused degradation');
  }
  
  if (avgScore < 50) {
    riskFactors.push('Current health score below threshold');
    preventiveActions.push('Immediate investigation required');
  }
  
  if (samples.filter((s: HealthSample) => s.status === 'bad').length > 3) {
    riskFactors.push('Multiple bad status samples in recent history');
    preventiveActions.push('Address root causes of bad samples');
  }
  
  if (trend === 'improving') {
    preventiveActions.push('Continue current practices');
    preventiveActions.push('Document what is working well');
  }
  
  const predictionDate = new Date();
  predictionDate.setDate(predictionDate.getDate() + params.daysAhead);
  
  const prediction: HealthPrediction = {
    id: generateId(),
    domainId: params.domainId,
    signalId: params.signalId || null,
    timestamp: new Date().toISOString(),
    predictionDate: predictionDate.toISOString(),
    predictedScore: Math.round(predictedScore),
    predictedStatus: predictedScore >= 80 ? 'good' : predictedScore >= 50 ? 'warning' : 'bad',
    confidence,
    trendDirection: trend,
    riskFactors,
    preventiveActions,
    basedOnSamples: samples.map((s: HealthSample) => s.id),
    notes: ''
  };
  
  store.predictions.push(prediction);
  saveAdvancedStore(store);
  return prediction;
}

export function getHealthPredictions(filters?: {
  domainId?: string;
  signalId?: string;
  confidence?: PredictionConfidence;
}): HealthPrediction[] {
  const store = getAdvancedStore();
  let predictions = store.predictions;
  
  if (filters) {
    if (filters.domainId) {
      predictions = predictions.filter((p: HealthPrediction) => p.domainId === filters.domainId);
    }
    if (filters.signalId) {
      predictions = predictions.filter((p: HealthPrediction) => p.signalId === filters.signalId);
    }
    if (filters.confidence) {
      predictions = predictions.filter((p: HealthPrediction) => p.confidence === filters.confidence);
    }
  }
  
  return predictions.sort((a: HealthPrediction, b: HealthPrediction) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
}

// ==================== 2. HEALTH CORRELATION ENGINE ====================

export function discoverHealthCorrelations(): HealthCorrelation[] {
  const store = getAdvancedStore();
  const signals = getHealthSignals();
  const samples = getHealthSamples();
  const newCorrelations: HealthCorrelation[] = [];
  
  // Compare each pair of signals
  for (let i = 0; i < signals.length; i++) {
    for (let j = i + 1; j < signals.length; j++) {
      const signalA = signals[i];
      const signalB = signals[j];
      
      const samplesA = samples.filter((s: HealthSample) => s.signalId === signalA.id);
      const samplesB = samples.filter((s: HealthSample) => s.signalId === signalB.id);
      
      if (samplesA.length < 5 || samplesB.length < 5) continue;
      
      // Simple correlation detection
      const correlation = analyzeCorrelation(samplesA, samplesB);
      
      if (correlation.strength >= 60) {
        const newCorr: HealthCorrelation = {
          id: generateId(),
          timestamp: new Date().toISOString(),
          signalA: {
            id: signalA.id,
            name: signalA.name,
            domainId: signalA.domainId
          },
          signalB: {
            id: signalB.id,
            name: signalB.name,
            domainId: signalB.domainId
          },
          correlationType: correlation.type,
          strength: correlation.strength,
          lag: correlation.lag,
          sampleSize: Math.min(samplesA.length, samplesB.length),
          description: generateCorrelationDescription(signalA.name, signalB.name, correlation),
          implications: generateCorrelationImplications(signalA.name, signalB.name, correlation),
          discoveredAt: new Date().toISOString(),
          confidence: correlation.strength >= 80 ? 'very-high' : correlation.strength >= 70 ? 'high' : 'medium',
          notes: ''
        };
        
        newCorrelations.push(newCorr);
        store.correlations.push(newCorr);
      }
    }
  }
  
  saveAdvancedStore(store);
  return newCorrelations;
}

function analyzeCorrelation(samplesA: HealthSample[], samplesB: HealthSample[]): {
  type: CorrelationType;
  strength: number;
  lag: number;
} {
  const scoresA = samplesA.map(scoreFromStatus);
  const scoresB = samplesB.map(scoreFromStatus);
  
  let bestCorr = 0;
  let bestLag = 0;
  let bestType: CorrelationType = 'neutral';
  
  // Try different lags (0-7 days)
  for (let lag = 0; lag <= 7; lag++) {
    const corr = calculateCorrelation(scoresA, scoresB, lag);
    
    if (Math.abs(corr) > Math.abs(bestCorr)) {
      bestCorr = corr;
      bestLag = lag;
      bestType = corr > 0 ? 'positive' : corr < 0 ? 'negative' : 'neutral';
    }
  }
  
  return {
    type: bestType,
    strength: Math.round(Math.abs(bestCorr) * 100),
    lag: bestLag
  };
}

function calculateCorrelation(scoresA: number[], scoresB: number[], lag: number): number {
  if (scoresA.length < 2 || scoresB.length < 2) return 0;
  
  const n = Math.min(scoresA.length - lag, scoresB.length);
  if (n < 2) return 0;
  
  let sumA = 0, sumB = 0, sumAB = 0, sumA2 = 0, sumB2 = 0;
  
  for (let i = 0; i < n; i++) {
    const a = scoresA[i + lag] || 0;
    const b = scoresB[i] || 0;
    sumA += a;
    sumB += b;
    sumAB += a * b;
    sumA2 += a * a;
    sumB2 += b * b;
  }
  
  const numerator = n * sumAB - sumA * sumB;
  const denominator = Math.sqrt((n * sumA2 - sumA * sumA) * (n * sumB2 - sumB * sumB));
  
  return denominator === 0 ? 0 : numerator / denominator;
}

function scoreFromStatus(sample: HealthSample): number {
  if (sample.status === 'good') return 100;
  if (sample.status === 'warning') return 50;
  if (sample.status === 'bad') return 0;
  return 25;
}

function generateCorrelationDescription(nameA: string, nameB: string, corr: { type: CorrelationType; lag: number }): string {
  const lagText = corr.lag > 0 ? ` with ${corr.lag} day lag` : '';
  
  if (corr.type === 'positive') {
    return `When ${nameA} improves, ${nameB} tends to improve${lagText}`;
  } else if (corr.type === 'negative') {
    return `When ${nameA} declines, ${nameB} tends to improve${lagText}`;
  }
  return `${nameA} and ${nameB} show no significant correlation`;
}

function generateCorrelationImplications(nameA: string, nameB: string, corr: { type: CorrelationType; strength: number }): string[] {
  const implications: string[] = [];
  
  if (corr.strength >= 80) {
    implications.push(`Strong ${corr.type} relationship detected - monitor both signals together`);
  }
  
  if (corr.type === 'negative') {
    implications.push(`${nameA} may be a leading indicator for ${nameB}`);
    implications.push('Consider using this relationship for early warning');
  } else if (corr.type === 'positive') {
    implications.push('Improvements in one signal may benefit the other');
    implications.push('Consider coordinated interventions');
  }
  
  return implications;
}

export function getHealthCorrelations(filters?: {
  domainId?: string;
  minStrength?: number;
}): HealthCorrelation[] {
  const store = getAdvancedStore();
  let correlations = store.correlations;
  
  if (filters) {
    if (filters.domainId) {
      correlations = correlations.filter((c: HealthCorrelation) => 
        c.signalA.domainId === filters.domainId || c.signalB.domainId === filters.domainId
      );
    }
    if (filters.minStrength) {
      correlations = correlations.filter((c: HealthCorrelation) => c.strength >= filters.minStrength);
    }
  }
  
  return correlations.sort((a: HealthCorrelation, b: HealthCorrelation) => b.strength - a.strength);
}

// ==================== 3. AUTOMATED HEALTH SYNTHESIS AGENT ====================

export function createSynthesisRule(params: {
  name: string;
  description: string;
  domainId: string;
  signalId: string;
  triggerPattern: string;
  sourceType: SynthesisSource;
  sourceIdentifier: string;
  statusMapping: { pattern: string; status: 'good' | 'warning' | 'bad' }[];
  autoApprove?: boolean;
}): SynthesisRule {
  const store = getAdvancedStore();
  
  const rule: SynthesisRule = {
    id: generateId(),
    name: params.name,
    description: params.description,
    enabled: true,
    domainId: params.domainId,
    signalId: params.signalId,
    triggerPattern: params.triggerPattern,
    sourceType: params.sourceType,
    sourceIdentifier: params.sourceIdentifier,
    statusMapping: params.statusMapping,
    autoApprove: params.autoApprove || false,
    lastTriggered: null,
    timesTriggered: 0,
    notes: ''
  };
  
  store.synthesisRules.push(rule);
  saveAdvancedStore(store);
  return rule;
}

export function triggerSynthesisRule(params: {
  ruleId: string;
  sourceData: string;
}): SynthesisEvent | null {
  const store = getAdvancedStore();
  const rule = store.synthesisRules.find((r: SynthesisRule) => r.id === params.ruleId);
  
  if (!rule || !rule.enabled) return null;
  
  // Check if pattern matches
  const matchedPattern = rule.statusMapping.find((m: { pattern: string; status: string }) => 
    params.sourceData.toLowerCase().includes(m.pattern.toLowerCase())
  );
  
  if (!matchedPattern) return null;
  
  const event: SynthesisEvent = {
    id: generateId(),
    ruleId: rule.id,
    timestamp: new Date().toISOString(),
    sourceData: params.sourceData,
    detectedPattern: matchedPattern.pattern,
    suggestedSample: {
      domainId: rule.domainId,
      signalId: rule.signalId,
      status: matchedPattern.status as 'good' | 'warning' | 'bad',
      valueText: params.sourceData.substring(0, 100),
      notes: `Auto-detected via rule: ${rule.name}`
    },
    approved: rule.autoApprove,
    autoApplied: rule.autoApprove,
    appliedSampleId: null,
    reviewedBy: rule.autoApprove ? 'auto-system' : null,
    reviewedAt: rule.autoApprove ? new Date().toISOString() : null
  };
  
  // Update rule stats
  rule.lastTriggered = new Date().toISOString();
  rule.timesTriggered += 1;
  
  store.synthesisEvents.push(event);
  saveAdvancedStore(store);
  
  return event;
}

export function getSynthesisRules(): SynthesisRule[] {
  return getAdvancedStore().synthesisRules;
}

export function getSynthesisEvents(filters?: {
  ruleId?: string;
  approved?: boolean;
}): SynthesisEvent[] {
  const store = getAdvancedStore();
  let events = store.synthesisEvents;
  
  if (filters) {
    if (filters.ruleId) {
      events = events.filter((e: SynthesisEvent) => e.ruleId === filters.ruleId);
    }
    if (filters.approved !== undefined) {
      events = events.filter((e: SynthesisEvent) => e.approved === filters.approved);
    }
  }
  
  return events.sort((a: SynthesisEvent, b: SynthesisEvent) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
}

export function approveSynthesisEvent(eventId: string, reviewedBy: string): SynthesisEvent | null {
  const store = getAdvancedStore();
  const event = store.synthesisEvents.find((e: SynthesisEvent) => e.id === eventId);
  
  if (!event) return null;
  
  event.approved = true;
  event.reviewedBy = reviewedBy;
  event.reviewedAt = new Date().toISOString();
  
  saveAdvancedStore(store);
  return event;
}

// ==================== 4. SOCIAL HEALTH PULSE ====================

export function createSocialChannel(params: {
  name: string;
  type: string;
  monitoredDomains: string[];
  keywords: string[];
}): SocialChannel {
  const store = getAdvancedStore();
  
  const channel: SocialChannel = {
    id: generateId(),
    name: params.name,
    type: params.type,
    enabled: true,
    monitoredDomains: params.monitoredDomains,
    keywords: params.keywords,
    lastChecked: null,
    pulseCount: 0,
    avgSentiment: 0,
    notes: ''
  };
  
  store.socialChannels.push(channel);
  saveAdvancedStore(store);
  return channel;
}

export function recordSocialPulse(params: {
  domainId: string;
  channel: string;
  contentSample: string;
  keywords?: string[];
  mentions?: number;
  engagement?: number;
}): SocialPulse {
  const store = getAdvancedStore();
  
  // Simple sentiment analysis
  const sentiment = analyzeSentiment(params.contentSample);
  
  const pulse: SocialPulse = {
    id: generateId(),
    timestamp: new Date().toISOString(),
    domainId: params.domainId,
    channel: params.channel,
    contentSample: params.contentSample,
    sentiment: sentiment.type,
    sentimentScore: sentiment.score,
    keywords: params.keywords || [],
    mentions: params.mentions || 0,
    engagement: params.engagement || 0,
    healthImpact: sentiment.score > 30 ? 'positive' : sentiment.score < -30 ? 'negative' : 'neutral',
    relatedSignals: [],
    notes: ''
  };
  
  store.socialPulses.push(pulse);
  
  // Update channel stats
  const channel = store.socialChannels.find((c: SocialChannel) => c.name === params.channel);
  if (channel) {
    channel.pulseCount += 1;
    channel.lastChecked = new Date().toISOString();
    const allPulses = store.socialPulses.filter((p: SocialPulse) => p.channel === params.channel);
    channel.avgSentiment = allPulses.reduce((sum: number, p: SocialPulse) => sum + p.sentimentScore, 0) / allPulses.length;
  }
  
  saveAdvancedStore(store);
  return pulse;
}

function analyzeSentiment(text: string): { type: SentimentType; score: number } {
  const positiveWords = ['great', 'amazing', 'excellent', 'love', 'awesome', 'fantastic', 'good', 'nice', 'happy', 'best', 'perfect'];
  const negativeWords = ['bad', 'terrible', 'awful', 'hate', 'worst', 'poor', 'sad', 'angry', 'broken', 'fail', 'error'];
  
  const lowerText = text.toLowerCase();
  const positiveCount = positiveWords.filter((w: string) => lowerText.includes(w)).length;
  const negativeCount = negativeWords.filter((w: string) => lowerText.includes(w)).length;
  
  const score = (positiveCount - negativeCount) * 20;
  const clampedScore = Math.max(-100, Math.min(100, score));
  
  let type: SentimentType = 'neutral';
  if (positiveCount > 0 && negativeCount > 0) {
    type = 'mixed';
  } else if (clampedScore > 20) {
    type = 'positive';
  } else if (clampedScore < -20) {
    type = 'negative';
  }
  
  return { type, score: clampedScore };
}

export function getSocialPulses(filters?: {
  domainId?: string;
  channel?: string;
  sentiment?: SentimentType;
}): SocialPulse[] {
  const store = getAdvancedStore();
  let pulses = store.socialPulses;
  
  if (filters) {
    if (filters.domainId) {
      pulses = pulses.filter((p: SocialPulse) => p.domainId === filters.domainId);
    }
    if (filters.channel) {
      pulses = pulses.filter((p: SocialPulse) => p.channel === filters.channel);
    }
    if (filters.sentiment) {
      pulses = pulses.filter((p: SocialPulse) => p.sentiment === filters.sentiment);
    }
  }
  
  return pulses.sort((a: SocialPulse, b: SocialPulse) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
}

export function getSocialChannels(): SocialChannel[] {
  return getAdvancedStore().socialChannels;
}

// ==================== 5. INTERACTIVE HEALTH PLAYBOOK GENERATOR ====================

export function generateHealthPlaybook(params: {
  title: string;
  description: string;
  domainId?: string | null;
  incidentIds?: string[];
}): GeneratedPlaybook {
  const store = getAdvancedStore();
  const incidents = getIncidents({ status: 'open' });
  const domains = getHealthDomains();
  const correlations = getHealthCorrelations();
  
  const targetIncidents = params.incidentIds 
    ? incidents.filter((i) => params.incidentIds!.includes(i.id))
    : incidents.slice(0, 3);
  
  const domain = params.domainId 
    ? domains.find((d) => d.id === params.domainId)
    : null;
  
  // Generate context
  const healthScore = calculateQuickHealthScore(params.domainId || null);
  const keyIssues = targetIncidents.map((i) => i.title);
  const historicalPatterns = correlations.slice(0, 3).map((c) => c.description);
  
  // Generate sections
  const sections: PlaybookSection[] = [
    {
      title: '1. Situation Overview',
      order: 1,
      content: `Domain: ${domain?.name || 'Cross-Domain'}\nCurrent Health Score: ${healthScore}/100\nOpen Incidents: ${targetIncidents.length}\n\nThis playbook addresses the current health challenges in ${domain?.name || 'DreamNet'} with actionable steps to restore optimal performance.`,
      actionItems: [],
      resources: []
    },
    {
      title: '2. Immediate Actions',
      order: 2,
      content: 'Critical steps to stabilize the situation:',
      actionItems: targetIncidents.map((incident) => ({
        description: `Address: ${incident.title}`,
        priority: incident.severity as 'low' | 'medium' | 'high' | 'critical',
        estimatedTime: incident.severity === 'critical' ? '1-2 hours' : '2-4 hours',
        assignee: null,
        completed: false,
        completedAt: null
      })),
      resources: ['Incident logs', 'Health samples', 'Team communication channels']
    },
    {
      title: '3. Root Cause Analysis',
      order: 3,
      content: 'Investigate underlying patterns:\n\n' + (correlations.length > 0 
        ? correlations.slice(0, 3).map((c) => `• ${c.description}`).join('\n')
        : '• Review recent changes\n• Check signal correlations\n• Interview operators'),
      actionItems: [
        {
          description: 'Review health correlations for patterns',
          priority: 'medium',
          estimatedTime: '1 hour',
          assignee: null,
          completed: false,
          completedAt: null
        }
      ],
      resources: ['Correlation engine', 'Historical samples']
    },
    {
      title: '4. Recovery Plan',
      order: 4,
      content: 'Steps to restore full health:',
      actionItems: [
        {
          description: 'Implement fixes for identified issues',
          priority: 'high',
          estimatedTime: '4-6 hours',
          assignee: null,
          completed: false,
          completedAt: null
        },
        {
          description: 'Monitor recovery metrics',
          priority: 'high',
          estimatedTime: 'Ongoing',
          assignee: null,
          completed: false,
          completedAt: null
        }
      ],
      resources: ['Monitoring dashboard', 'Health checks']
    },
    {
      title: '5. Prevention Strategy',
      order: 5,
      content: 'Prevent recurrence:',
      actionItems: [
        {
          description: 'Set up automated health synthesis rules',
          priority: 'medium',
          estimatedTime: '2 hours',
          assignee: null,
          completed: false,
          completedAt: null
        },
        {
          description: 'Schedule regular health reviews',
          priority: 'medium',
          estimatedTime: '30 minutes',
          assignee: null,
          completed: false,
          completedAt: null
        }
      ],
      resources: ['Synthesis agent', 'Check templates']
    }
  ];
  
  const playbook: GeneratedPlaybook = {
    id: generateId(),
    timestamp: new Date().toISOString(),
    title: params.title,
    description: params.description,
    domainId: params.domainId || null,
    incidentIds: targetIncidents.map((i) => i.id),
    correlationIds: correlations.slice(0, 3).map((c) => c.id),
    context: {
      healthScore,
      keyIssues,
      historicalPatterns
    },
    sections,
    priority: targetIncidents.some((i) => i.severity === 'critical') ? 'critical' : 'high',
    estimatedImpact: 'High - Expected to improve health score by 20-40 points',
    generatedBy: 'ai',
    status: 'active',
    usageCount: 0,
    successRate: 0,
    notes: ''
  };
  
  store.generatedPlaybooks.push(playbook);
  saveAdvancedStore(store);
  return playbook;
}

function calculateQuickHealthScore(domainId: string | null): number {
  const samples = getHealthSamples({ domainId: domainId || undefined });
  const recentSamples = samples.slice(0, 20);
  
  if (recentSamples.length === 0) return 50;
  
  const scores = recentSamples.map(scoreFromStatus);
  return Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
}

export function getGeneratedPlaybooks(filters?: {
  domainId?: string | null;
  status?: 'draft' | 'active' | 'archived';
}): GeneratedPlaybook[] {
  const store = getAdvancedStore();
  let playbooks = store.generatedPlaybooks;
  
  if (filters) {
    if (filters.domainId !== undefined) {
      playbooks = playbooks.filter((p: GeneratedPlaybook) => p.domainId === filters.domainId);
    }
    if (filters.status) {
      playbooks = playbooks.filter((p: GeneratedPlaybook) => p.status === filters.status);
    }
  }
  
  return playbooks.sort((a: GeneratedPlaybook, b: GeneratedPlaybook) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
}

export function updatePlaybookAction(
  playbookId: string, 
  sectionIndex: number, 
  actionIndex: number, 
  updates: { completed?: boolean; assignee?: string }
): GeneratedPlaybook | null {
  const store = getAdvancedStore();
  const playbook = store.generatedPlaybooks.find((p: GeneratedPlaybook) => p.id === playbookId);
  
  if (!playbook || !playbook.sections[sectionIndex]?.actionItems[actionIndex]) {
    return null;
  }
  
  const action = playbook.sections[sectionIndex].actionItems[actionIndex];
  
  if (updates.completed !== undefined) {
    action.completed = updates.completed;
    action.completedAt = updates.completed ? new Date().toISOString() : null;
  }
  
  if (updates.assignee !== undefined) {
    action.assignee = updates.assignee;
  }
  
  saveAdvancedStore(store);
  return playbook;
}
