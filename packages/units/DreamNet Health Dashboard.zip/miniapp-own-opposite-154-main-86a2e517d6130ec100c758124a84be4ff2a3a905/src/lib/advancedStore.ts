import type { AdvancedHealthStore } from '@/types/advanced-features';

const ADVANCED_STORAGE_KEY = 'dreamnet-advanced-health-store';

const defaultAdvancedStore: AdvancedHealthStore = {
  predictions: [],
  correlations: [],
  synthesisRules: [],
  synthesisEvents: [],
  socialPulses: [],
  socialChannels: [],
  generatedPlaybooks: []
};

export function getAdvancedStore(): AdvancedHealthStore {
  if (typeof window === 'undefined') {
    return defaultAdvancedStore;
  }
  
  try {
    const stored = localStorage.getItem(ADVANCED_STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored) as AdvancedHealthStore;
    }
  } catch (error) {
    console.error('Error loading advanced health store:', error);
  }
  
  return defaultAdvancedStore;
}

export function saveAdvancedStore(store: AdvancedHealthStore): void {
  if (typeof window === 'undefined') {
    return;
  }
  
  try {
    localStorage.setItem(ADVANCED_STORAGE_KEY, JSON.stringify(store));
  } catch (error) {
    console.error('Error saving advanced health store:', error);
  }
}

export function clearAdvancedStore(): void {
  if (typeof window === 'undefined') {
    return;
  }
  
  localStorage.removeItem(ADVANCED_STORAGE_KEY);
}
