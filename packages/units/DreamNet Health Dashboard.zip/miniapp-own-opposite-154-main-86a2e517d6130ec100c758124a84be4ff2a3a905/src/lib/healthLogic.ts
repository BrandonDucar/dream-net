import type {
  HealthDomain,
  HealthSignalDefinition,
  HealthSample,
  Incident,
  HealthSummary,
  CheckTemplate,
  CheckRun,
  ImportanceLevel,
  SignalType,
  RecommendedSampling,
  SampleStatus,
  IncidentSeverity,
  IncidentStatus,
  CheckFrequency
} from '@/types/health';
import { getStore, saveStore, generateId } from './healthStore';

// ==================== HEALTH DOMAIN ====================

export function createHealthDomain(params: {
  name: string;
  code: string;
  description: string;
  importanceLevel: ImportanceLevel;
  tags?: string[];
}): HealthDomain {
  const store = getStore();
  
  const domain: HealthDomain = {
    id: generateId(),
    name: params.name,
    code: params.code,
    description: params.description,
    importanceLevel: params.importanceLevel,
    tags: params.tags || [],
    notes: '',
    seoTitle: `${params.name} - DreamNet Health Domain`,
    seoDescription: params.description,
    seoKeywords: [params.name, params.code, 'DreamNet', 'Health', 'Monitor'],
    seoHashtags: ['#DreamNet', `#${params.code}`, '#HealthMonitor'],
    altText: `${params.name} health domain monitoring dashboard`
  };
  
  store.domains.push(domain);
  saveStore(store);
  return domain;
}

export function updateHealthDomain(id: string, updates: Partial<Omit<HealthDomain, 'id'>>): HealthDomain | null {
  const store = getStore();
  const index = store.domains.findIndex((d: HealthDomain) => d.id === id);
  
  if (index === -1) return null;
  
  store.domains[index] = { ...store.domains[index], ...updates };
  saveStore(store);
  return store.domains[index];
}

export function getHealthDomains(): HealthDomain[] {
  return getStore().domains;
}

export function getHealthDomain(id: string): HealthDomain | null {
  return getStore().domains.find((d: HealthDomain) => d.id === id) || null;
}

// ==================== HEALTH SIGNAL DEFINITION ====================

export function createHealthSignalDefinition(params: {
  domainId: string;
  name: string;
  code: string;
  description: string;
  signalType: SignalType;
  expectedRange?: string | null;
  interpretation: string;
  recommendedSampling: RecommendedSampling;
  tags?: string[];
}): HealthSignalDefinition {
  const store = getStore();
  
  const signal: HealthSignalDefinition = {
    id: generateId(),
    domainId: params.domainId,
    name: params.name,
    code: params.code,
    description: params.description,
    signalType: params.signalType,
    expectedRange: params.expectedRange || null,
    interpretation: params.interpretation,
    recommendedSampling: params.recommendedSampling,
    tags: params.tags || [],
    notes: ''
  };
  
  store.signals.push(signal);
  saveStore(store);
  return signal;
}

export function updateHealthSignalDefinition(id: string, updates: Partial<Omit<HealthSignalDefinition, 'id'>>): HealthSignalDefinition | null {
  const store = getStore();
  const index = store.signals.findIndex((s: HealthSignalDefinition) => s.id === id);
  
  if (index === -1) return null;
  
  store.signals[index] = { ...store.signals[index], ...updates };
  saveStore(store);
  return store.signals[index];
}

export function getHealthSignals(domainId?: string): HealthSignalDefinition[] {
  const store = getStore();
  if (domainId) {
    return store.signals.filter((s: HealthSignalDefinition) => s.domainId === domainId);
  }
  return store.signals;
}

export function getHealthSignal(id: string): HealthSignalDefinition | null {
  return getStore().signals.find((s: HealthSignalDefinition) => s.id === id) || null;
}

// ==================== HEALTH SAMPLE ====================

export function recordHealthSample(params: {
  domainId: string;
  signalId: string;
  valueNumber?: number | null;
  valueText?: string | null;
  status: SampleStatus;
  notes?: string;
}): HealthSample {
  const store = getStore();
  
  const sample: HealthSample = {
    id: generateId(),
    domainId: params.domainId,
    signalId: params.signalId,
    timestamp: new Date().toISOString(),
    valueNumber: params.valueNumber || null,
    valueText: params.valueText || null,
    status: params.status,
    notes: params.notes || ''
  };
  
  store.samples.push(sample);
  saveStore(store);
  return sample;
}

export function updateHealthSample(id: string, updates: Partial<Omit<HealthSample, 'id' | 'timestamp'>>): HealthSample | null {
  const store = getStore();
  const index = store.samples.findIndex((s: HealthSample) => s.id === id);
  
  if (index === -1) return null;
  
  store.samples[index] = { ...store.samples[index], ...updates };
  saveStore(store);
  return store.samples[index];
}

export function getHealthSamples(filters?: {
  domainId?: string;
  signalId?: string;
  status?: SampleStatus;
  startDate?: string;
  endDate?: string;
}): HealthSample[] {
  const store = getStore();
  let samples = store.samples;
  
  if (filters) {
    if (filters.domainId) {
      samples = samples.filter((s: HealthSample) => s.domainId === filters.domainId);
    }
    if (filters.signalId) {
      samples = samples.filter((s: HealthSample) => s.signalId === filters.signalId);
    }
    if (filters.status) {
      samples = samples.filter((s: HealthSample) => s.status === filters.status);
    }
    if (filters.startDate) {
      samples = samples.filter((s: HealthSample) => s.timestamp >= filters.startDate!);
    }
    if (filters.endDate) {
      samples = samples.filter((s: HealthSample) => s.timestamp <= filters.endDate!);
    }
  }
  
  return samples.sort((a: HealthSample, b: HealthSample) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
}

// ==================== INCIDENT ====================

export function createIncident(params: {
  domainId: string;
  title: string;
  description: string;
  severity: IncidentSeverity;
  status?: IncidentStatus;
  relatedSignals?: string[];
  relatedObjects?: string[];
}): Incident {
  const store = getStore();
  
  const incident: Incident = {
    id: generateId(),
    domainId: params.domainId,
    title: params.title,
    description: params.description,
    severity: params.severity,
    status: params.status || 'open',
    detectedAt: new Date().toISOString(),
    resolvedAt: null,
    relatedSignals: params.relatedSignals || [],
    relatedObjects: params.relatedObjects || [],
    notes: ''
  };
  
  store.incidents.push(incident);
  saveStore(store);
  return incident;
}

export function updateIncident(id: string, updates: Partial<Omit<Incident, 'id' | 'detectedAt'>>): Incident | null {
  const store = getStore();
  const index = store.incidents.findIndex((i: Incident) => i.id === id);
  
  if (index === -1) return null;
  
  const incident = store.incidents[index];
  const updatedIncident = { ...incident, ...updates };
  
  if (updates.status === 'resolved' && incident.status !== 'resolved') {
    updatedIncident.resolvedAt = new Date().toISOString();
  }
  
  store.incidents[index] = updatedIncident;
  saveStore(store);
  return store.incidents[index];
}

export function getIncidents(filters?: {
  domainId?: string;
  severity?: IncidentSeverity;
  status?: IncidentStatus;
  startDate?: string;
  endDate?: string;
}): Incident[] {
  const store = getStore();
  let incidents = store.incidents;
  
  if (filters) {
    if (filters.domainId) {
      incidents = incidents.filter((i: Incident) => i.domainId === filters.domainId);
    }
    if (filters.severity) {
      incidents = incidents.filter((i: Incident) => i.severity === filters.severity);
    }
    if (filters.status) {
      incidents = incidents.filter((i: Incident) => i.status === filters.status);
    }
    if (filters.startDate) {
      incidents = incidents.filter((i: Incident) => i.detectedAt >= filters.startDate!);
    }
    if (filters.endDate) {
      incidents = incidents.filter((i: Incident) => i.detectedAt <= filters.endDate!);
    }
  }
  
  return incidents.sort((a: Incident, b: Incident) => 
    new Date(b.detectedAt).getTime() - new Date(a.detectedAt).getTime()
  );
}

export function getIncident(id: string): Incident | null {
  return getStore().incidents.find((i: Incident) => i.id === id) || null;
}

// ==================== CHECK TEMPLATE ====================

export function createCheckTemplate(params: {
  name: string;
  description: string;
  frequency: CheckFrequency;
  domainIds: string[];
  signalIds: string[];
  checklistItems: string[];
  tags?: string[];
}): CheckTemplate {
  const store = getStore();
  
  const template: CheckTemplate = {
    id: generateId(),
    name: params.name,
    description: params.description,
    frequency: params.frequency,
    domainIds: params.domainIds,
    signalIds: params.signalIds,
    checklistItems: params.checklistItems,
    tags: params.tags || [],
    notes: ''
  };
  
  store.checkTemplates.push(template);
  saveStore(store);
  return template;
}

export function updateCheckTemplate(id: string, updates: Partial<Omit<CheckTemplate, 'id'>>): CheckTemplate | null {
  const store = getStore();
  const index = store.checkTemplates.findIndex((t: CheckTemplate) => t.id === id);
  
  if (index === -1) return null;
  
  store.checkTemplates[index] = { ...store.checkTemplates[index], ...updates };
  saveStore(store);
  return store.checkTemplates[index];
}

export function getCheckTemplates(): CheckTemplate[] {
  return getStore().checkTemplates;
}

export function getCheckTemplate(id: string): CheckTemplate | null {
  return getStore().checkTemplates.find((t: CheckTemplate) => t.id === id) || null;
}

// ==================== CHECK RUN ====================

export function startCheckRun(params: {
  templateId: string;
  operatorName: string;
  periodLabel: string;
}): CheckRun | null {
  const store = getStore();
  const template = store.checkTemplates.find((t: CheckTemplate) => t.id === params.templateId);
  
  if (!template) return null;
  
  const checkRun: CheckRun = {
    id: generateId(),
    templateId: params.templateId,
    startedAt: new Date().toISOString(),
    finishedAt: null,
    operatorName: params.operatorName,
    periodLabel: params.periodLabel,
    domainIds: template.domainIds,
    signalsReviewed: [],
    incidentsTouched: [],
    summary: '',
    notes: ''
  };
  
  store.checkRuns.push(checkRun);
  saveStore(store);
  return checkRun;
}

export function finalizeCheckRun(params: {
  checkRunId: string;
  summary: string;
  notes: string;
  signalsReviewedIds: string[];
  incidentsTouchedIds: string[];
}): CheckRun | null {
  const store = getStore();
  const index = store.checkRuns.findIndex((r: CheckRun) => r.id === params.checkRunId);
  
  if (index === -1) return null;
  
  store.checkRuns[index] = {
    ...store.checkRuns[index],
    finishedAt: new Date().toISOString(),
    summary: params.summary,
    notes: params.notes,
    signalsReviewed: params.signalsReviewedIds,
    incidentsTouched: params.incidentsTouchedIds
  };
  
  saveStore(store);
  return store.checkRuns[index];
}

export function getCheckRuns(filters?: {
  templateId?: string;
  operatorName?: string;
  startDate?: string;
  endDate?: string;
}): CheckRun[] {
  const store = getStore();
  let runs = store.checkRuns;
  
  if (filters) {
    if (filters.templateId) {
      runs = runs.filter((r: CheckRun) => r.templateId === filters.templateId);
    }
    if (filters.operatorName) {
      runs = runs.filter((r: CheckRun) => r.operatorName === filters.operatorName);
    }
    if (filters.startDate) {
      runs = runs.filter((r: CheckRun) => r.startedAt >= filters.startDate!);
    }
    if (filters.endDate) {
      runs = runs.filter((r: CheckRun) => r.startedAt <= filters.endDate!);
    }
  }
  
  return runs.sort((a: CheckRun, b: CheckRun) => 
    new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime()
  );
}

export function getCheckRun(id: string): CheckRun | null {
  return getStore().checkRuns.find((r: CheckRun) => r.id === id) || null;
}

// ==================== HEALTH SUMMARY ====================

export function computeHealthSummary(params: {
  domainId: string | null;
  periodLabel: string;
  startDate?: string;
  endDate?: string;
}): HealthSummary {
  const store = getStore();
  
  const samples = getHealthSamples({
    domainId: params.domainId || undefined,
    startDate: params.startDate,
    endDate: params.endDate
  });
  
  const incidents = getIncidents({
    domainId: params.domainId || undefined,
    startDate: params.startDate,
    endDate: params.endDate
  });
  
  const goodCount = samples.filter((s: HealthSample) => s.status === 'good').length;
  const warningCount = samples.filter((s: HealthSample) => s.status === 'warning').length;
  const badCount = samples.filter((s: HealthSample) => s.status === 'bad').length;
  const totalSamples = samples.length;
  
  let healthScore = 0;
  let status: SampleStatus = 'unknown';
  
  if (totalSamples > 0) {
    healthScore = Math.round(
      (goodCount * 100 + warningCount * 50 + badCount * 0) / totalSamples
    );
    
    if (healthScore >= 80) {
      status = 'good';
    } else if (healthScore >= 50) {
      status = 'warning';
    } else {
      status = 'bad';
    }
  }
  
  const keyFindings: string[] = [];
  const recommendedActions: string[] = [];
  
  if (badCount > 0) {
    keyFindings.push(`${badCount} critical signal(s) in bad state`);
    recommendedActions.push('Investigate and address critical signals immediately');
  }
  
  if (warningCount > 0) {
    keyFindings.push(`${warningCount} signal(s) showing warning signs`);
    recommendedActions.push('Monitor warning signals closely and plan preventive actions');
  }
  
  const openIncidents = incidents.filter((i: Incident) => i.status === 'open');
  if (openIncidents.length > 0) {
    keyFindings.push(`${openIncidents.length} open incident(s) requiring attention`);
    recommendedActions.push('Review and triage open incidents');
  }
  
  if (totalSamples === 0) {
    keyFindings.push('No health data available for this period');
    recommendedActions.push('Begin recording health samples for this domain');
  }
  
  if (goodCount === totalSamples && totalSamples > 0) {
    keyFindings.push('All signals are healthy');
    recommendedActions.push('Continue monitoring and maintain current practices');
  }
  
  const summary: HealthSummary = {
    id: generateId(),
    timestamp: new Date().toISOString(),
    domainId: params.domainId,
    periodLabel: params.periodLabel,
    healthScore,
    status,
    keyFindings,
    recommendedActions,
    notes: ''
  };
  
  store.summaries.push(summary);
  saveStore(store);
  return summary;
}

export function listHealthSummaries(filters?: {
  domainId?: string | null;
  status?: SampleStatus;
  startDate?: string;
  endDate?: string;
}): HealthSummary[] {
  const store = getStore();
  let summaries = store.summaries;
  
  if (filters) {
    if (filters.domainId !== undefined) {
      summaries = summaries.filter((s: HealthSummary) => s.domainId === filters.domainId);
    }
    if (filters.status) {
      summaries = summaries.filter((s: HealthSummary) => s.status === filters.status);
    }
    if (filters.startDate) {
      summaries = summaries.filter((s: HealthSummary) => s.timestamp >= filters.startDate!);
    }
    if (filters.endDate) {
      summaries = summaries.filter((s: HealthSummary) => s.timestamp <= filters.endDate!);
    }
  }
  
  return summaries.sort((a: HealthSummary, b: HealthSummary) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
}

export function getHealthSummary(id: string): HealthSummary | null {
  return getStore().summaries.find((s: HealthSummary) => s.id === id) || null;
}

// ==================== HEALTH REPORT ====================

export function generateHealthReport(periodLabel: string): string {
  const store = getStore();
  const domains = store.domains;
  
  let report = `DreamNet Diagnostics & Health Report\n`;
  report += `Period: ${periodLabel}\n`;
  report += `Generated: ${new Date().toISOString()}\n`;
  report += `${'='.repeat(60)}\n\n`;
  
  const globalSummary = computeHealthSummary({
    domainId: null,
    periodLabel
  });
  
  report += `OVERALL HEALTH\n`;
  report += `Score: ${globalSummary.healthScore}/100\n`;
  report += `Status: ${globalSummary.status.toUpperCase()}\n\n`;
  
  report += `Key Findings:\n`;
  globalSummary.keyFindings.forEach((finding: string) => {
    report += `  • ${finding}\n`;
  });
  report += `\n`;
  
  report += `Recommended Actions:\n`;
  globalSummary.recommendedActions.forEach((action: string) => {
    report += `  • ${action}\n`;
  });
  report += `\n`;
  
  report += `${'='.repeat(60)}\n\n`;
  
  report += `DOMAIN-BY-DOMAIN ANALYSIS\n\n`;
  
  domains.forEach((domain: HealthDomain) => {
    const domainSummary = computeHealthSummary({
      domainId: domain.id,
      periodLabel
    });
    
    report += `${domain.name} (${domain.code})\n`;
    report += `Importance: ${domain.importanceLevel.toUpperCase()}\n`;
    report += `Score: ${domainSummary.healthScore}/100\n`;
    report += `Status: ${domainSummary.status.toUpperCase()}\n\n`;
    
    if (domainSummary.keyFindings.length > 0) {
      report += `Findings:\n`;
      domainSummary.keyFindings.forEach((finding: string) => {
        report += `  • ${finding}\n`;
      });
      report += `\n`;
    }
    
    if (domainSummary.recommendedActions.length > 0) {
      report += `Actions:\n`;
      domainSummary.recommendedActions.forEach((action: string) => {
        report += `  • ${action}\n`;
      });
      report += `\n`;
    }
    
    report += `${'-'.repeat(60)}\n\n`;
  });
  
  const openIncidents = getIncidents({ status: 'open' });
  if (openIncidents.length > 0) {
    report += `OPEN INCIDENTS (${openIncidents.length})\n\n`;
    openIncidents.forEach((incident: Incident) => {
      const domain = domains.find((d: HealthDomain) => d.id === incident.domainId);
      report += `${incident.title}\n`;
      report += `Domain: ${domain?.name || 'Unknown'}\n`;
      report += `Severity: ${incident.severity.toUpperCase()}\n`;
      report += `Detected: ${new Date(incident.detectedAt).toLocaleString()}\n`;
      report += `Description: ${incident.description}\n\n`;
    });
  }
  
  report += `${'='.repeat(60)}\n`;
  report += `End of Report\n`;
  
  return report;
}

// ==================== DIAGNOSTICS PLAYBOOK ====================

export function exportDiagnosticsPlaybook(): string {
  const store = getStore();
  
  let playbook = `DreamNet Diagnostics & Health Playbook v1\n`;
  playbook += `Generated: ${new Date().toISOString()}\n`;
  playbook += `${'='.repeat(60)}\n\n`;
  
  playbook += `INTRODUCTION\n`;
  playbook += `This playbook defines how to monitor and maintain the health of DreamNet\n`;
  playbook += `across all domains: Culture, Ops, Agents, Economics, Social, and Pickleball.\n\n`;
  
  playbook += `${'='.repeat(60)}\n\n`;
  
  playbook += `HEALTH DOMAINS\n\n`;
  store.domains.forEach((domain: HealthDomain) => {
    playbook += `${domain.name} (${domain.code})\n`;
    playbook += `Importance: ${domain.importanceLevel.toUpperCase()}\n`;
    playbook += `Description: ${domain.description}\n`;
    playbook += `Tags: ${domain.tags.join(', ')}\n\n`;
  });
  
  playbook += `${'='.repeat(60)}\n\n`;
  
  playbook += `HEALTH SIGNALS\n\n`;
  store.domains.forEach((domain: HealthDomain) => {
    const signals = getHealthSignals(domain.id);
    if (signals.length > 0) {
      playbook += `${domain.name} Signals:\n`;
      signals.forEach((signal: HealthSignalDefinition) => {
        playbook += `  • ${signal.name} (${signal.code})\n`;
        playbook += `    Type: ${signal.signalType}\n`;
        playbook += `    Sampling: ${signal.recommendedSampling}\n`;
        if (signal.expectedRange) {
          playbook += `    Expected Range: ${signal.expectedRange}\n`;
        }
        playbook += `    Interpretation: ${signal.interpretation}\n\n`;
      });
    }
  });
  
  playbook += `${'='.repeat(60)}\n\n`;
  
  playbook += `CHECK TEMPLATES\n\n`;
  store.checkTemplates.forEach((template: CheckTemplate) => {
    playbook += `${template.name}\n`;
    playbook += `Frequency: ${template.frequency}\n`;
    playbook += `Description: ${template.description}\n`;
    playbook += `Domains: ${template.domainIds.length}\n`;
    playbook += `Signals: ${template.signalIds.length}\n`;
    playbook += `Checklist Items:\n`;
    template.checklistItems.forEach((item: string) => {
      playbook += `  • ${item}\n`;
    });
    playbook += `\n`;
  });
  
  playbook += `${'='.repeat(60)}\n\n`;
  
  playbook += `EXAMPLE HEALTH SUMMARIES\n\n`;
  const recentSummaries = listHealthSummaries().slice(0, 5);
  recentSummaries.forEach((summary: HealthSummary) => {
    const domain = summary.domainId 
      ? store.domains.find((d: HealthDomain) => d.id === summary.domainId)
      : null;
    
    playbook += `Period: ${summary.periodLabel}\n`;
    playbook += `Domain: ${domain?.name || 'Overall'}\n`;
    playbook += `Score: ${summary.healthScore}/100\n`;
    playbook += `Status: ${summary.status.toUpperCase()}\n`;
    playbook += `Key Findings:\n`;
    summary.keyFindings.forEach((finding: string) => {
      playbook += `  • ${finding}\n`;
    });
    playbook += `Recommended Actions:\n`;
    summary.recommendedActions.forEach((action: string) => {
      playbook += `  • ${action}\n`;
    });
    playbook += `\n`;
  });
  
  playbook += `${'='.repeat(60)}\n`;
  playbook += `End of Playbook\n`;
  
  return playbook;
}
