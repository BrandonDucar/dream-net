import type { HealthStore } from '@/types/health';

const STORAGE_KEY = 'dreamnet-health-store';

const defaultStore: HealthStore = {
  domains: [],
  signals: [],
  samples: [],
  incidents: [],
  summaries: [],
  checkTemplates: [],
  checkRuns: []
};

export function getStore(): HealthStore {
  if (typeof window === 'undefined') {
    return defaultStore;
  }
  
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored) as HealthStore;
    }
  } catch (error) {
    console.error('Error loading health store:', error);
  }
  
  return defaultStore;
}

export function saveStore(store: HealthStore): void {
  if (typeof window === 'undefined') {
    return;
  }
  
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
  } catch (error) {
    console.error('Error saving health store:', error);
  }
}

export function clearStore(): void {
  if (typeof window === 'undefined') {
    return;
  }
  
  localStorage.removeItem(STORAGE_KEY);
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}
