// Advanced Features Types for DreamNet Diagnostics

export type PredictionConfidence = "low" | "medium" | "high" | "very-high";
export type TrendDirection = "improving" | "stable" | "degrading" | "critical";
export type CorrelationType = "positive" | "negative" | "neutral";
export type SynthesisSource = "manual" | "auto-detected" | "imported" | "ai-generated";
export type SentimentType = "positive" | "neutral" | "negative" | "mixed";

// 1. PREDICTIVE HEALTH FORECASTING
export interface HealthPrediction {
  id: string;
  domainId: string;
  signalId: string | null; // null for overall domain prediction
  timestamp: string;
  predictionDate: string; // future date being predicted
  predictedScore: number; // 0-100
  predictedStatus: "good" | "warning" | "bad" | "unknown";
  confidence: PredictionConfidence;
  trendDirection: TrendDirection;
  riskFactors: string[];
  preventiveActions: string[];
  basedOnSamples: string[]; // sample IDs used for prediction
  notes: string;
}

// 2. HEALTH CORRELATION ENGINE
export interface HealthCorrelation {
  id: string;
  timestamp: string;
  signalA: {
    id: string;
    name: string;
    domainId: string;
  };
  signalB: {
    id: string;
    name: string;
    domainId: string;
  };
  correlationType: CorrelationType;
  strength: number; // 0-100
  lag: number; // days lag (e.g., "when A drops, B spikes 3 days later")
  sampleSize: number;
  description: string;
  implications: string[];
  discoveredAt: string;
  confidence: PredictionConfidence;
  notes: string;
}

// 3. AUTOMATED HEALTH SYNTHESIS AGENT
export interface SynthesisRule {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  domainId: string;
  signalId: string;
  triggerPattern: string; // pattern to match (e.g., "error", "spike", "drop")
  sourceType: SynthesisSource;
  sourceIdentifier: string; // app name, log file, etc.
  statusMapping: {
    pattern: string;
    status: "good" | "warning" | "bad";
  }[];
  autoApprove: boolean;
  lastTriggered: string | null;
  timesTriggered: number;
  notes: string;
}

export interface SynthesisEvent {
  id: string;
  ruleId: string;
  timestamp: string;
  sourceData: string;
  detectedPattern: string;
  suggestedSample: {
    domainId: string;
    signalId: string;
    status: "good" | "warning" | "bad";
    valueText: string;
    notes: string;
  };
  approved: boolean;
  autoApplied: boolean;
  appliedSampleId: string | null;
  reviewedBy: string | null;
  reviewedAt: string | null;
}

// 4. SOCIAL HEALTH PULSE
export interface SocialPulse {
  id: string;
  timestamp: string;
  domainId: string;
  channel: string; // e.g., "twitter", "discord", "farcaster"
  contentSample: string;
  sentiment: SentimentType;
  sentimentScore: number; // -100 to 100
  keywords: string[];
  mentions: number;
  engagement: number;
  healthImpact: "positive" | "neutral" | "negative";
  relatedSignals: string[];
  notes: string;
}

export interface SocialChannel {
  id: string;
  name: string;
  type: string; // "twitter", "discord", "farcaster", etc.
  enabled: boolean;
  monitoredDomains: string[];
  keywords: string[];
  lastChecked: string | null;
  pulseCount: number;
  avgSentiment: number;
  notes: string;
}

// 5. INTERACTIVE HEALTH PLAYBOOK GENERATOR
export interface GeneratedPlaybook {
  id: string;
  timestamp: string;
  title: string;
  description: string;
  domainId: string | null; // null for cross-domain
  incidentIds: string[];
  correlationIds: string[];
  context: {
    healthScore: number;
    keyIssues: string[];
    historicalPatterns: string[];
  };
  sections: PlaybookSection[];
  priority: "low" | "medium" | "high" | "critical";
  estimatedImpact: string;
  generatedBy: "ai" | "manual" | "template";
  status: "draft" | "active" | "archived";
  usageCount: number;
  successRate: number; // 0-100
  notes: string;
}

export interface PlaybookSection {
  title: string;
  order: number;
  content: string;
  actionItems: PlaybookAction[];
  resources: string[];
}

export interface PlaybookAction {
  description: string;
  priority: "low" | "medium" | "high" | "critical";
  estimatedTime: string;
  assignee: string | null;
  completed: boolean;
  completedAt: string | null;
}

// Extended HealthStore
export interface AdvancedHealthStore {
  predictions: HealthPrediction[];
  correlations: HealthCorrelation[];
  synthesisRules: SynthesisRule[];
  synthesisEvents: SynthesisEvent[];
  socialPulses: SocialPulse[];
  socialChannels: SocialChannel[];
  generatedPlaybooks: GeneratedPlaybook[];
}
