export type ImportanceLevel = "low" | "medium" | "high" | "critical";
export type SignalType = "metric" | "boolean" | "score" | "status";
export type SampleStatus = "good" | "warning" | "bad" | "unknown";
export type IncidentSeverity = "low" | "medium" | "high" | "critical";
export type IncidentStatus = "open" | "monitoring" | "resolved" | "ignored";
export type RecommendedSampling = "daily" | "weekly" | "per-event" | "ad-hoc";
export type CheckFrequency = "daily" | "weekly" | "per-launch" | "per-incident" | "ad-hoc";

export interface HealthDomain {
  id: string;
  name: string;
  code: string;
  description: string;
  importanceLevel: ImportanceLevel;
  tags: string[];
  notes: string;
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export interface HealthSignalDefinition {
  id: string;
  domainId: string;
  name: string;
  code: string;
  description: string;
  signalType: SignalType;
  expectedRange: string | null;
  interpretation: string;
  recommendedSampling: RecommendedSampling;
  tags: string[];
  notes: string;
}

export interface HealthSample {
  id: string;
  domainId: string;
  signalId: string;
  timestamp: string;
  valueNumber: number | null;
  valueText: string | null;
  status: SampleStatus;
  notes: string;
}

export interface Incident {
  id: string;
  domainId: string;
  title: string;
  description: string;
  severity: IncidentSeverity;
  status: IncidentStatus;
  detectedAt: string;
  resolvedAt: string | null;
  relatedSignals: string[];
  relatedObjects: string[];
  notes: string;
}

export interface HealthSummary {
  id: string;
  timestamp: string;
  domainId: string | null;
  periodLabel: string;
  healthScore: number;
  status: SampleStatus;
  keyFindings: string[];
  recommendedActions: string[];
  notes: string;
}

export interface CheckTemplate {
  id: string;
  name: string;
  description: string;
  frequency: CheckFrequency;
  domainIds: string[];
  signalIds: string[];
  checklistItems: string[];
  tags: string[];
  notes: string;
}

export interface CheckRun {
  id: string;
  templateId: string;
  startedAt: string;
  finishedAt: string | null;
  operatorName: string;
  periodLabel: string;
  domainIds: string[];
  signalsReviewed: string[];
  incidentsTouched: string[];
  summary: string;
  notes: string;
}

export interface HealthStore {
  domains: HealthDomain[];
  signals: HealthSignalDefinition[];
  samples: HealthSample[];
  incidents: Incident[];
  summaries: HealthSummary[];
  checkTemplates: CheckTemplate[];
  checkRuns: CheckRun[];
}
