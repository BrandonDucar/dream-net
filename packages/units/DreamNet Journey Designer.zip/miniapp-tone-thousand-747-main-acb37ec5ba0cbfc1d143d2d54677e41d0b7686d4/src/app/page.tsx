'use client'
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { 
  Users, 
  Map, 
  Target, 
  BarChart, 
  Plus, 
  ArrowLeft, 
  FileDown,
  Trash2,
  Edit,
  Eye
} from 'lucide-react';
import { PersonaForm } from '@/components/persona-form';
import { JourneyForm } from '@/components/journey-form';
import { StepForm } from '@/components/step-form';
import { ExportDialog } from '@/components/export-dialog';
import { JourneyTemplates } from '@/components/JourneyTemplates';
import { FrictionAnalysisComponent } from '@/components/FrictionAnalysis';
import { EmotionalCurve } from '@/components/EmotionalCurve';
import { AIJourneyGenerator } from '@/components/AIJourneyGenerator';
import type { JourneyTemplate, AIGeneratedJourney } from '@/types/dreamnet-enhancements';
import { usePersonas } from '@/hooks/use-personas';
import { useJourneyStages } from '@/hooks/use-journey-stages';
import { useTouchpoints } from '@/hooks/use-touchpoints';
import { useExperienceJourneys } from '@/hooks/use-experience-journeys';
import { useJourneySteps } from '@/hooks/use-journey-steps';
import { useExperienceMetrics } from '@/hooks/use-experience-metrics';
import { getJourneyDetail, generateJourneyMap, generatePersonaBrief, generateExperiencePlaybook, exportExperienceAtlas } from '@/lib/journey-utils';
import type { 
  CreatePersonaInput, 
  CreateExperienceJourneyInput, 
  CreateJourneyStepInput,
  CreateTouchpointInput,
  CreateJourneyStageInput,
  CreateExperienceMetricInput,
  Persona,
  ExperienceJourney,
  JourneyDetail,
  JourneyStep,
  Touchpoint,
  JourneyStage,
  TouchpointType,
  MetricType
} from '@/types/experience-map';
import { toast } from 'sonner';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type Screen = 
  | 'overview'
  | 'create-persona'
  | 'persona-detail'
  | 'create-journey'
  | 'journey-detail'
  | 'touchpoints'
  | 'stages'
  | 'metrics'
  | 'templates'
  | 'ai-generator';

interface ScreenState {
  type: Screen;
  data?: Record<string, string>;
}

export default function DreamNetExperienceMap() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [screen, setScreen] = useState<ScreenState>({ type: 'overview' });
  const [exportDialog, setExportDialog] = useState<{ open: boolean; title: string; content: string }>({
    open: false,
    title: '',
    content: '',
  });

  const personas = usePersonas();
  const stages = useJourneyStages();
  const touchpoints = useTouchpoints();
  const journeys = useExperienceJourneys();
  const steps = useJourneySteps();
  const metrics = useExperienceMetrics();

  const [initialized, setInitialized] = useState<boolean>(false);

  useEffect(() => {
    if (!initialized && !personas.loading && !stages.loading) {
      if (stages.stages.length === 0) {
        initializeDefaultStages();
      }
      setInitialized(true);
    }
  }, [personas.loading, stages.loading, initialized]);

  const initializeDefaultStages = (): void => {
    const defaultStages: CreateJourneyStageInput[] = [
      { name: 'Discover', description: 'First encounter with DreamNet', order: 1, defaultEmotionalGoal: 'Curious' },
      { name: 'Explore', description: 'Learning what DreamNet offers', order: 2, defaultEmotionalGoal: 'Intrigued' },
      { name: 'Join', description: 'Taking first action', order: 3, defaultEmotionalGoal: 'Excited' },
      { name: 'Play', description: 'Active participation', order: 4, defaultEmotionalGoal: 'Engaged' },
      { name: 'Contribute', description: 'Creating value', order: 5, defaultEmotionalGoal: 'Empowered' },
      { name: 'Evangelize', description: 'Spreading the word', order: 6, defaultEmotionalGoal: 'Proud' },
    ];

    defaultStages.forEach((input: CreateJourneyStageInput) => {
      stages.createJourneyStage(input);
    });

    toast.success('Default journey stages initialized!');
  };

  const handleCreatePersona = (input: CreatePersonaInput): void => {
    personas.createPersona(input);
    setScreen({ type: 'overview' });
    toast.success('Persona created!');
  };

  const handleCreateJourney = (input: CreateExperienceJourneyInput): void => {
    const journey = journeys.createJourney(input);
    setScreen({ type: 'journey-detail', data: { journeyId: journey.id } });
    toast.success('Journey created!');
  };

  const handleCreateStep = (input: CreateJourneyStepInput): void => {
    steps.createStep(input);
    toast.success('Step added!');
  };

  const handleDeletePersona = (id: string): void => {
    personas.deletePersona(id);
    toast.success('Persona deleted');
  };

  const handleDeleteJourney = (id: string): void => {
    journeys.deleteJourney(id);
    steps.steps.filter((s: JourneyStep) => s.journeyId === id).forEach((s: JourneyStep) => steps.deleteStep(s.id));
    setScreen({ type: 'overview' });
    toast.success('Journey deleted');
  };

  const handleDeleteStep = (id: string): void => {
    steps.deleteStep(id);
    toast.success('Step deleted');
  };

  const showExportDialog = (title: string, content: string): void => {
    setExportDialog({ open: true, title, content });
  };

  const handleExportAtlas = (): void => {
    const content = exportExperienceAtlas(
      personas.personas,
      stages.stages,
      touchpoints.touchpoints,
      journeys.journeys,
      steps.steps,
      metrics.metrics
    );
    showExportDialog('DreamNet Experience Atlas', content);
  };

  if (personas.loading || stages.loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 to-blue-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
          <p className="mt-4 text-black">Loading DreamNet Experience Map...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-black mb-2">
                DreamNet Experience Map
              </h1>
              <p className="text-lg text-black">
                Design how real people move through your universe
              </p>
            </div>
            {screen.type !== 'overview' && (
              <Button variant="outline" onClick={() => setScreen({ type: 'overview' })}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Overview
              </Button>
            )}
          </div>
        </header>

        {screen.type === 'overview' && (
          <OverviewScreen
            personas={personas.personas}
            journeys={journeys.journeys}
            onCreatePersona={() => setScreen({ type: 'create-persona' })}
            onCreateJourney={() => setScreen({ type: 'create-journey' })}
            onViewPersona={(id: string) => setScreen({ type: 'persona-detail', data: { personaId: id } })}
            onViewJourney={(id: string) => setScreen({ type: 'journey-detail', data: { journeyId: id } })}
            onManageTouchpoints={() => setScreen({ type: 'touchpoints' })}
            onManageStages={() => setScreen({ type: 'stages' })}
            onManageMetrics={() => setScreen({ type: 'metrics' })}
            onExportAtlas={handleExportAtlas}
            onDeletePersona={handleDeletePersona}
            onDeleteJourney={handleDeleteJourney}
          />
        )}

        {screen.type === 'create-persona' && (
          <PersonaForm
            onSubmit={handleCreatePersona}
            onCancel={() => setScreen({ type: 'overview' })}
          />
        )}

        {screen.type === 'persona-detail' && screen.data?.personaId && (
          <PersonaDetailScreen
            personaId={screen.data.personaId}
            persona={personas.getPersonaById(screen.data.personaId)}
            journeys={journeys.filterJourneys({ personaId: screen.data.personaId })}
            onViewJourney={(id: string) => setScreen({ type: 'journey-detail', data: { journeyId: id } })}
            onGenerateBrief={(persona: Persona) => {
              const personaJourneys = journeys.filterJourneys({ personaId: persona.id });
              const brief = generatePersonaBrief(persona, personaJourneys);
              showExportDialog('Persona Brief', brief);
            }}
          />
        )}

        {screen.type === 'create-journey' && (
          <JourneyForm
            personas={personas.personas}
            onSubmit={handleCreateJourney}
            onCancel={() => setScreen({ type: 'overview' })}
          />
        )}

        {screen.type === 'journey-detail' && screen.data?.journeyId && (
          <JourneyDetailScreen
            journeyId={screen.data.journeyId}
            journey={journeys.getJourneyById(screen.data.journeyId)}
            persona={personas.getPersonaById(journeys.getJourneyById(screen.data.journeyId)?.personaId || '')}
            steps={steps.getStepsByJourneyId(screen.data.journeyId)}
            stages={stages.stages}
            touchpoints={touchpoints.touchpoints}
            metrics={metrics.getMetricsByJourneyId(screen.data.journeyId)}
            onCreateStep={handleCreateStep}
            onDeleteStep={handleDeleteStep}
            onDeleteJourney={handleDeleteJourney}
            onGenerateMap={() => {
              const journey = journeys.getJourneyById(screen.data?.journeyId || '');
              const persona = personas.getPersonaById(journey?.personaId || '');
              if (journey && persona) {
                const detail = getJourneyDetail(
                  journey,
                  persona,
                  steps.steps,
                  stages.stages,
                  touchpoints.touchpoints
                );
                if (detail) {
                  const map = generateJourneyMap(detail);
                  showExportDialog('Journey Map', map);
                }
              }
            }}
            onGeneratePlaybook={() => {
              const journey = journeys.getJourneyById(screen.data?.journeyId || '');
              const persona = personas.getPersonaById(journey?.personaId || '');
              if (journey && persona) {
                const detail = getJourneyDetail(
                  journey,
                  persona,
                  steps.steps,
                  stages.stages,
                  touchpoints.touchpoints
                );
                if (detail) {
                  const journeyMetrics = metrics.getMetricsByJourneyId(journey.id);
                  const playbook = generateExperiencePlaybook(detail, journeyMetrics);
                  showExportDialog('Experience Playbook', playbook);
                }
              }
            }}
          />
        )}

        {screen.type === 'touchpoints' && (
          <TouchpointsScreen
            touchpoints={touchpoints.touchpoints}
            onCreate={(input: CreateTouchpointInput) => {
              touchpoints.createTouchpoint(input);
              toast.success('Touchpoint created!');
            }}
            onDelete={(id: string) => {
              touchpoints.deleteTouchpoint(id);
              toast.success('Touchpoint deleted');
            }}
          />
        )}

        {screen.type === 'stages' && (
          <StagesScreen
            stages={stages.stages}
            onCreate={(input: CreateJourneyStageInput) => {
              stages.createJourneyStage(input);
              toast.success('Stage created!');
            }}
            onDelete={(id: string) => {
              stages.deleteJourneyStage(id);
              toast.success('Stage deleted');
            }}
          />
        )}

        {screen.type === 'metrics' && (
          <MetricsScreen
            metrics={metrics.metrics}
            journeys={journeys.journeys}
            onCreate={(input: CreateExperienceMetricInput) => {
              metrics.createMetric(input);
              toast.success('Metric created!');
            }}
            onDelete={(id: string) => {
              metrics.deleteMetric(id);
              toast.success('Metric deleted');
            }}
          />
        )}

        <ExportDialog
          open={exportDialog.open}
          onOpenChange={(open: boolean) => setExportDialog({ ...exportDialog, open })}
          title={exportDialog.title}
          content={exportDialog.content}
        />
      </div>
    </div>
  );
}

interface OverviewScreenProps {
  personas: Persona[];
  journeys: ExperienceJourney[];
  onCreatePersona: () => void;
  onCreateJourney: () => void;
  onViewPersona: (id: string) => void;
  onViewJourney: (id: string) => void;
  onManageTouchpoints: () => void;
  onManageStages: () => void;
  onManageMetrics: () => void;
  onExportAtlas: () => void;
  onDeletePersona: (id: string) => void;
  onDeleteJourney: (id: string) => void;
}

function OverviewScreen({
  personas,
  journeys,
  onCreatePersona,
  onCreateJourney,
  onViewPersona,
  onViewJourney,
  onManageTouchpoints,
  onManageStages,
  onManageMetrics,
  onExportAtlas,
  onDeletePersona,
  onDeleteJourney,
}: OverviewScreenProps) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Personas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black mb-2">{personas.length}</div>
            <Button onClick={onCreatePersona} className="w-full" size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Create Persona
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Map className="w-5 h-5" />
              Journeys
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black mb-2">{journeys.length}</div>
            <Button onClick={onCreateJourney} className="w-full" size="sm" disabled={personas.length === 0}>
              <Plus className="w-4 h-4 mr-2" />
              Create Journey
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="w-5 h-5" />
              Touchpoints
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Button onClick={onManageTouchpoints} className="w-full" size="sm">
              Manage
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart className="w-5 h-5" />
              Export
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Button onClick={onExportAtlas} className="w-full" size="sm">
              <FileDown className="w-4 h-4 mr-2" />
              Export Atlas
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Personas</CardTitle>
            <CardDescription>Define your audience segments</CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96">
              <div className="space-y-3">
                {personas.length === 0 ? (
                  <p className="text-sm text-black text-center py-8">No personas yet. Create your first one!</p>
                ) : (
                  personas.map((persona: Persona) => (
                    <Card key={persona.id} className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold text-black mb-1">{persona.name}</h3>
                          <Badge variant="outline" className="mb-2">{persona.experienceLevel}</Badge>
                          <p className="text-sm text-black line-clamp-2">{persona.description}</p>
                          <div className="flex gap-1 mt-2 flex-wrap">
                            {persona.tags.slice(0, 3).map((tag: string) => (
                              <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex gap-1 ml-2">
                          <Button size="sm" variant="ghost" onClick={() => onViewPersona(persona.id)}>
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => onDeletePersona(persona.id)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Experience Journeys</CardTitle>
            <CardDescription>Map user paths through DreamNet</CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96">
              <div className="space-y-3">
                {journeys.length === 0 ? (
                  <p className="text-sm text-black text-center py-8">No journeys yet. Create your first one!</p>
                ) : (
                  journeys.map((journey: ExperienceJourney) => {
                    const persona = personas.find((p: Persona) => p.id === journey.personaId);
                    return (
                      <Card key={journey.id} className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="font-semibold text-black mb-1">{journey.name}</h3>
                            <p className="text-xs text-black mb-1">Persona: {persona?.name || 'Unknown'}</p>
                            <div className="flex gap-2 mb-2">
                              <Badge variant="outline">{journey.status}</Badge>
                              <Badge variant={journey.importanceLevel === 'critical' ? 'destructive' : 'default'}>
                                {journey.importanceLevel}
                              </Badge>
                            </div>
                            <p className="text-sm text-black line-clamp-2">{journey.primaryGoal}</p>
                          </div>
                          <div className="flex gap-1 ml-2">
                            <Button size="sm" variant="ghost" onClick={() => onViewJourney(journey.id)}>
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => onDeleteJourney(journey.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </Card>
                    );
                  })
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-4">
        <Button onClick={onManageStages} variant="outline">
          Manage Journey Stages
        </Button>
        <Button onClick={onManageMetrics} variant="outline">
          Manage Metrics
        </Button>
      </div>
    </div>
  );
}

interface PersonaDetailScreenProps {
  personaId: string;
  persona?: Persona;
  journeys: ExperienceJourney[];
  onViewJourney: (id: string) => void;
  onGenerateBrief: (persona: Persona) => void;
}

function PersonaDetailScreen({ persona, journeys, onViewJourney, onGenerateBrief }: PersonaDetailScreenProps) {
  if (!persona) {
    return <div className="text-center py-12 text-black">Persona not found</div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-2xl mb-2">{persona.name}</CardTitle>
              <Badge>{persona.experienceLevel}</Badge>
            </div>
            <Button onClick={() => onGenerateBrief(persona)}>
              <FileDown className="w-4 h-4 mr-2" />
              Generate Brief
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-semibold mb-2 text-black">Description</h3>
            <p className="text-black">{persona.description}</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold mb-2 text-black">Motivations</h3>
              <ul className="space-y-1">
                {persona.motivations.map((m: string, i: number) => (
                  <li key={i} className="text-sm text-black">• {m}</li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-2 text-black">Fears</h3>
              <ul className="space-y-1">
                {persona.fears.map((f: string, i: number) => (
                  <li key={i} className="text-sm text-black">• {f}</li>
                ))}
              </ul>
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-2 text-black">Preferred Channels</h3>
            <div className="flex gap-2 flex-wrap">
              {persona.preferredChannels.map((channel: string) => (
                <Badge key={channel} variant="secondary">{channel}</Badge>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-2 text-black">Tags</h3>
            <div className="flex gap-2 flex-wrap">
              {persona.tags.map((tag: string) => (
                <Badge key={tag}>{tag}</Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Journeys for {persona.name}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {journeys.length === 0 ? (
              <p className="text-center py-8 text-black">No journeys yet</p>
            ) : (
              journeys.map((journey: ExperienceJourney) => (
                <Card key={journey.id} className="p-4 cursor-pointer hover:bg-gray-50" onClick={() => onViewJourney(journey.id)}>
                  <h3 className="font-semibold text-black mb-2">{journey.name}</h3>
                  <div className="flex gap-2 mb-2">
                    <Badge variant="outline">{journey.status}</Badge>
                    <Badge>{journey.importanceLevel}</Badge>
                  </div>
                  <p className="text-sm text-black">{journey.primaryGoal}</p>
                </Card>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

interface JourneyDetailScreenProps {
  journeyId: string;
  journey?: ExperienceJourney;
  persona?: Persona;
  steps: JourneyStep[];
  stages: JourneyStage[];
  touchpoints: Touchpoint[];
  metrics: import('@/types/experience-map').ExperienceMetric[];
  onCreateStep: (input: CreateJourneyStepInput) => void;
  onDeleteStep: (id: string) => void;
  onDeleteJourney: (id: string) => void;
  onGenerateMap: () => void;
  onGeneratePlaybook: () => void;
}

function JourneyDetailScreen({
  journey,
  persona,
  steps,
  stages,
  touchpoints,
  metrics,
  onCreateStep,
  onDeleteStep,
  onDeleteJourney,
  onGenerateMap,
  onGeneratePlaybook,
}: JourneyDetailScreenProps) {
  const [showStepForm, setShowStepForm] = useState<boolean>(false);
  const touchpointsHook = useTouchpoints();

  if (!journey || !persona) {
    return <div className="text-center py-12 text-black">Journey not found</div>;
  }

  const groupedSteps: Record<string, JourneyStep[]> = {};
  steps.forEach((step: JourneyStep) => {
    if (!groupedSteps[step.stageId]) {
      groupedSteps[step.stageId] = [];
    }
    groupedSteps[step.stageId].push(step);
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-2xl mb-2">{journey.name}</CardTitle>
              <p className="text-sm text-black mb-2">Persona: {persona.name}</p>
              <div className="flex gap-2">
                <Badge variant="outline">{journey.status}</Badge>
                <Badge>{journey.importanceLevel}</Badge>
              </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={onGenerateMap} variant="outline">
                <FileDown className="w-4 h-4 mr-2" />
                Journey Map
              </Button>
              <Button onClick={onGeneratePlaybook}>
                <FileDown className="w-4 h-4 mr-2" />
                Playbook
              </Button>
              <Button onClick={() => onDeleteJourney(journey.id)} variant="destructive" size="sm">
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2 text-black">Description</h3>
            <p className="text-black">{journey.description}</p>
          </div>
          <div>
            <h3 className="font-semibold mb-2 text-black">Primary Goal</h3>
            <p className="text-black">{journey.primaryGoal}</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Journey Steps ({steps.length})</CardTitle>
            <Button onClick={() => setShowStepForm(!showStepForm)}>
              <Plus className="w-4 h-4 mr-2" />
              {showStepForm ? 'Cancel' : 'Add Step'}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {showStepForm && (
            <div className="mb-6">
              <StepForm
                journeyId={journey.id}
                stages={stages}
                touchpoints={touchpoints}
                existingSteps={steps.length}
                onSubmit={(input: CreateJourneyStepInput) => {
                  onCreateStep(input);
                  setShowStepForm(false);
                }}
                onCancel={() => setShowStepForm(false)}
              />
            </div>
          )}

          <ScrollArea className="h-96">
            <div className="space-y-6">
              {stages.filter((stage: JourneyStage) => groupedSteps[stage.id]).map((stage: JourneyStage) => (
                <div key={stage.id} className="space-y-3">
                  <div className="bg-purple-100 p-3 rounded-md">
                    <h3 className="font-semibold text-black">
                      Stage {stage.order}: {stage.name}
                    </h3>
                    <p className="text-sm text-black">{stage.description}</p>
                    <p className="text-xs text-black mt-1">Emotional Goal: {stage.defaultEmotionalGoal}</p>
                  </div>

                  {groupedSteps[stage.id]?.map((step: JourneyStep) => {
                    const stepTouchpoints = touchpointsHook.getTouchpointsByIds(step.touchpointIds);
                    return (
                      <Card key={step.id} className="ml-4 p-4">
                        <div className="flex justify-between items-start mb-3">
                          <h4 className="font-semibold text-black">Step {step.order + 1}</h4>
                          <Button size="sm" variant="ghost" onClick={() => onDeleteStep(step.id)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>

                        <div className="space-y-2 text-sm">
                          <div>
                            <span className="font-medium text-black">Entry:</span> <span className="text-black">{step.entryCondition}</span>
                          </div>
                          <div>
                            <span className="font-medium text-black">Desired Outcome:</span> <span className="text-black">{step.desiredOutcome}</span>
                          </div>
                          <div className="grid grid-cols-2 gap-2 py-2">
                            <div>
                              <span className="font-medium text-black">Before:</span> <span className="text-black">{step.emotionalStateBefore}</span>
                            </div>
                            <div>
                              <span className="font-medium text-black">After:</span> <span className="text-black">{step.emotionalStateAfter}</span>
                            </div>
                          </div>

                          {stepTouchpoints.length > 0 && (
                            <div>
                              <span className="font-medium text-black">Touchpoints:</span>
                              <div className="flex gap-1 mt-1 flex-wrap">
                                {stepTouchpoints.map((tp: Touchpoint) => (
                                  <Badge key={tp.id} variant="secondary" className="text-xs">
                                    {tp.name}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}

                          {step.frictionPoints.length > 0 && (
                            <div>
                              <span className="font-medium text-black">Friction:</span>
                              <ul className="mt-1">
                                {step.frictionPoints.map((f: string, i: number) => (
                                  <li key={i} className="text-xs text-black">⚠ {f}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {step.boosters.length > 0 && (
                            <div>
                              <span className="font-medium text-black">Boosters:</span>
                              <ul className="mt-1">
                                {step.boosters.map((b: string, i: number) => (
                                  <li key={i} className="text-xs text-black">✨ {b}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      </Card>
                    );
                  })}
                </div>
              ))}

              {steps.length === 0 && (
                <p className="text-center py-8 text-black">No steps yet. Add your first step!</p>
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {metrics.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Metrics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {metrics.map((metric: import('@/types/experience-map').ExperienceMetric) => (
                <div key={metric.id} className="border-l-4 border-purple-500 pl-3 py-2">
                  <h4 className="font-semibold text-black">{metric.name}</h4>
                  <p className="text-sm text-black">{metric.description}</p>
                  <Badge variant="outline" className="mt-1">{metric.metricType}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

interface TouchpointsScreenProps {
  touchpoints: Touchpoint[];
  onCreate: (input: CreateTouchpointInput) => void;
  onDelete: (id: string) => void;
}

function TouchpointsScreen({ touchpoints, onCreate, onDelete }: TouchpointsScreenProps) {
  const [showForm, setShowForm] = useState<boolean>(false);
  const [name, setName] = useState<string>('');
  const [type, setType] = useState<TouchpointType>('social-post');
  const [description, setDescription] = useState<string>('');
  const [relatedApp, setRelatedApp] = useState<string>('');
  const [tags, setTags] = useState<string>('');

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    onCreate({
      name,
      type,
      description,
      relatedApp: relatedApp || null,
      tags: tags.split(',').map((t: string) => t.trim()).filter((t: string) => t !== ''),
    });
    setName('');
    setDescription('');
    setRelatedApp('');
    setTags('');
    setShowForm(false);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Touchpoints</CardTitle>
            <Button onClick={() => setShowForm(!showForm)}>
              <Plus className="w-4 h-4 mr-2" />
              {showForm ? 'Cancel' : 'Add Touchpoint'}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {showForm && (
            <form onSubmit={handleSubmit} className="space-y-4 mb-6 p-4 border rounded-md">
              <div>
                <Label htmlFor="tp-name">Name</Label>
                <Input
                  id="tp-name"
                  value={name}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="tp-type">Type</Label>
                <Select value={type} onValueChange={(v: string) => setType(v as TouchpointType)}>
                  <SelectTrigger id="tp-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="social-post">Social Post</SelectItem>
                    <SelectItem value="frame">Frame</SelectItem>
                    <SelectItem value="drop-page">Drop Page</SelectItem>
                    <SelectItem value="mini-app">Mini App</SelectItem>
                    <SelectItem value="agent-interaction">Agent Interaction</SelectItem>
                    <SelectItem value="email">Email</SelectItem>
                    <SelectItem value="irl-event">IRL Event</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="tp-description">Description</Label>
                <Input
                  id="tp-description"
                  value={description}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setDescription(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="tp-app">Related App</Label>
                <Input
                  id="tp-app"
                  value={relatedApp}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setRelatedApp(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="tp-tags">Tags (comma-separated)</Label>
                <Input
                  id="tp-tags"
                  value={tags}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTags(e.target.value)}
                />
              </div>
              <Button type="submit">Create Touchpoint</Button>
            </form>
          )}

          <ScrollArea className="h-96">
            <div className="space-y-3">
              {touchpoints.map((tp: Touchpoint) => (
                <Card key={tp.id} className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold text-black mb-1">{tp.name}</h3>
                      <Badge variant="outline" className="mb-2">{tp.type}</Badge>
                      <p className="text-sm text-black">{tp.description}</p>
                      {tp.relatedApp && <p className="text-xs text-black mt-1">App: {tp.relatedApp}</p>}
                    </div>
                    <Button size="sm" variant="ghost" onClick={() => onDelete(tp.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

interface StagesScreenProps {
  stages: JourneyStage[];
  onCreate: (input: CreateJourneyStageInput) => void;
  onDelete: (id: string) => void;
}

function StagesScreen({ stages, onCreate, onDelete }: StagesScreenProps) {
  const [showForm, setShowForm] = useState<boolean>(false);
  const [name, setName] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [order, setOrder] = useState<number>(stages.length + 1);
  const [emotionalGoal, setEmotionalGoal] = useState<string>('');

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    onCreate({ name, description, order, defaultEmotionalGoal: emotionalGoal });
    setName('');
    setDescription('');
    setEmotionalGoal('');
    setOrder(stages.length + 2);
    setShowForm(false);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Journey Stages</CardTitle>
            <Button onClick={() => setShowForm(!showForm)}>
              <Plus className="w-4 h-4 mr-2" />
              {showForm ? 'Cancel' : 'Add Stage'}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {showForm && (
            <form onSubmit={handleSubmit} className="space-y-4 mb-6 p-4 border rounded-md">
              <div>
                <Label htmlFor="stage-name">Name</Label>
                <Input
                  id="stage-name"
                  value={name}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="stage-description">Description</Label>
                <Input
                  id="stage-description"
                  value={description}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setDescription(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="stage-order">Order</Label>
                <Input
                  id="stage-order"
                  type="number"
                  value={order}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setOrder(parseInt(e.target.value, 10))}
                  required
                />
              </div>
              <div>
                <Label htmlFor="stage-goal">Default Emotional Goal</Label>
                <Input
                  id="stage-goal"
                  value={emotionalGoal}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEmotionalGoal(e.target.value)}
                  required
                />
              </div>
              <Button type="submit">Create Stage</Button>
            </form>
          )}

          <div className="space-y-3">
            {stages.map((stage: JourneyStage) => (
              <Card key={stage.id} className="p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold text-black mb-1">
                      {stage.order}. {stage.name}
                    </h3>
                    <p className="text-sm text-black mb-1">{stage.description}</p>
                    <p className="text-xs text-black">Goal: {stage.defaultEmotionalGoal}</p>
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => onDelete(stage.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

interface MetricsScreenProps {
  metrics: import('@/types/experience-map').ExperienceMetric[];
  journeys: ExperienceJourney[];
  onCreate: (input: CreateExperienceMetricInput) => void;
  onDelete: (id: string) => void;
}

function MetricsScreen({ metrics, journeys, onCreate, onDelete }: MetricsScreenProps) {
  const [showForm, setShowForm] = useState<boolean>(false);
  const [name, setName] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [metricType, setMetricType] = useState<MetricType>('count');
  const [calculation, setCalculation] = useState<string>('');
  const [selectedJourneys, setSelectedJourneys] = useState<string[]>([]);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    onCreate({
      name,
      description,
      metricType,
      suggestedCalculation: calculation,
      relatedJourneyIds: selectedJourneys,
    });
    setName('');
    setDescription('');
    setCalculation('');
    setSelectedJourneys([]);
    setShowForm(false);
  };

  const toggleJourney = (id: string): void => {
    if (selectedJourneys.includes(id)) {
      setSelectedJourneys(selectedJourneys.filter((jid: string) => jid !== id));
    } else {
      setSelectedJourneys([...selectedJourneys, id]);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Experience Metrics</CardTitle>
            <Button onClick={() => setShowForm(!showForm)}>
              <Plus className="w-4 h-4 mr-2" />
              {showForm ? 'Cancel' : 'Add Metric'}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {showForm && (
            <form onSubmit={handleSubmit} className="space-y-4 mb-6 p-4 border rounded-md">
              <div>
                <Label htmlFor="metric-name">Name</Label>
                <Input
                  id="metric-name"
                  value={name}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="metric-description">Description</Label>
                <Input
                  id="metric-description"
                  value={description}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setDescription(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="metric-type">Type</Label>
                <Select value={metricType} onValueChange={(v: string) => setMetricType(v as MetricType)}>
                  <SelectTrigger id="metric-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="time">Time</SelectItem>
                    <SelectItem value="count">Count</SelectItem>
                    <SelectItem value="ratio">Ratio</SelectItem>
                    <SelectItem value="score">Score</SelectItem>
                    <SelectItem value="boolean">Boolean</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="metric-calculation">Suggested Calculation</Label>
                <Input
                  id="metric-calculation"
                  value={calculation}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCalculation(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Related Journeys</Label>
                <div className="border rounded-md p-3 max-h-40 overflow-y-auto space-y-2">
                  {journeys.map((journey: ExperienceJourney) => (
                    <div key={journey.id} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={`journey-${journey.id}`}
                        checked={selectedJourneys.includes(journey.id)}
                        onChange={() => toggleJourney(journey.id)}
                        className="cursor-pointer"
                      />
                      <label htmlFor={`journey-${journey.id}`} className="text-sm cursor-pointer text-black">
                        {journey.name}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              <Button type="submit">Create Metric</Button>
            </form>
          )}

          <ScrollArea className="h-96">
            <div className="space-y-3">
              {metrics.map((metric: import('@/types/experience-map').ExperienceMetric) => (
                <Card key={metric.id} className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold text-black mb-1">{metric.name}</h3>
                      <Badge variant="outline" className="mb-2">{metric.metricType}</Badge>
                      <p className="text-sm text-black mb-1">{metric.description}</p>
                      <p className="text-xs text-black">Calculation: {metric.suggestedCalculation}</p>
                      <p className="text-xs text-black mt-1">Related Journeys: {metric.relatedJourneyIds.length}</p>
                    </div>
                    <Button size="sm" variant="ghost" onClick={() => onDelete(metric.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
