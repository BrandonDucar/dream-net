'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, Check, ArrowRight } from 'lucide-react';
import type { AIGeneratedJourney } from '@/types/dreamnet-enhancements';
import type { Persona } from '@/types/dreamnet';

interface AIJourneyGeneratorProps {
  personas: Persona[];
  onGenerate: (journey: AIGeneratedJourney) => void;
}

export function AIJourneyGenerator({ personas, onGenerate }: AIJourneyGeneratorProps): React.JSX.Element {
  const [selectedPersona, setSelectedPersona] = useState<string>('');
  const [primaryGoal, setPrimaryGoal] = useState<string>('');
  const [contextualInfo, setContextualInfo] = useState<string>('');
  const [focusAreas, setFocusAreas] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generatedJourney, setGeneratedJourney] = useState<AIGeneratedJourney | null>(null);

  const handleGenerate = async (): Promise<void> => {
    if (!selectedPersona || !primaryGoal) return;

    setIsGenerating(true);
    setGeneratedJourney(null);

    // Simulate AI generation (in production, this would call an AI API)
    await new Promise((resolve) => setTimeout(resolve, 2000));

    const persona = personas.find((p: Persona) => p.id === selectedPersona);
    if (!persona) return;

    const journey = generateJourneyFromInputs(persona, primaryGoal, contextualInfo, focusAreas);
    setGeneratedJourney(journey);
    setIsGenerating(false);
  };

  const handleUseJourney = (): void => {
    if (generatedJourney) {
      onGenerate(generatedJourney);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            AI Journey Generator
          </CardTitle>
          <CardDescription>
            Use AI to generate a complete user journey based on your persona and goals
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="persona-select">Select Persona</Label>
            <select
              id="persona-select"
              className="w-full rounded-md border border-input bg-background px-3 py-2"
              value={selectedPersona}
              onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setSelectedPersona(e.target.value)}
            >
              <option value="">Choose a persona...</option>
              {personas.map((persona: Persona) => (
                <option key={persona.id} value={persona.id}>
                  {persona.name} - {persona.experienceLevel}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="primary-goal">Primary Goal</Label>
            <Input
              id="primary-goal"
              placeholder="e.g., Get them to mint their first NFT"
              value={primaryGoal}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPrimaryGoal(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="contextual-info">Context & Background (optional)</Label>
            <Textarea
              id="contextual-info"
              placeholder="e.g., They discovered us through a Farcaster frame, they're excited about Base..."
              value={contextualInfo}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setContextualInfo(e.target.value)}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="focus-areas">Focus Areas (optional, comma-separated)</Label>
            <Input
              id="focus-areas"
              placeholder="e.g., wallet onboarding, first mint, community join"
              value={focusAreas}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFocusAreas(e.target.value)}
            />
          </div>

          <Button
            className="w-full"
            onClick={handleGenerate}
            disabled={!selectedPersona || !primaryGoal || isGenerating}
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating Journey...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Generate Journey
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {generatedJourney && (
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <CardTitle className="flex items-center gap-2">
                  <Check className="w-5 h-5 text-green-600" />
                  Generated Journey: {generatedJourney.suggestedName}
                </CardTitle>
                <CardDescription className="mt-2">
                  {generatedJourney.suggestedDescription}
                </CardDescription>
              </div>
              <Badge className="bg-purple-100 text-purple-800">
                Confidence: {(generatedJourney.confidenceScore * 100).toFixed(0)}%
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h4 className="font-semibold mb-3">Journey Steps ({generatedJourney.suggestedSteps.length})</h4>
              <div className="space-y-3">
                {generatedJourney.suggestedSteps.map((step: typeof generatedJourney.suggestedSteps[0]) => (
                  <div key={step.order} className="bg-white p-4 rounded-lg space-y-2">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline">{step.stageName}</Badge>
                          <h5 className="font-medium">{step.stepName}</h5>
                        </div>
                        <p className="text-sm text-muted-foreground italic">{step.reasoning}</p>
                      </div>
                      <Badge>{step.order}</Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <p className="text-muted-foreground">Entry:</p>
                        <p>{step.entryCondition}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Outcome:</p>
                        <p>{step.desiredOutcome}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <p className="text-muted-foreground">Before:</p>
                        <p className="font-medium">{step.emotionalBefore}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">After:</p>
                        <p className="font-medium">{step.emotionalAfter}</p>
                      </div>
                    </div>

                    {step.touchpointSuggestions.length > 0 && (
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Touchpoints:</p>
                        <div className="flex gap-1 flex-wrap">
                          {step.touchpointSuggestions.map((tp: string, idx: number) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {tp}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {step.frictionPoints.length > 0 && (
                      <div>
                        <p className="text-sm font-medium text-orange-700">Friction Points:</p>
                        <ul className="text-sm space-y-0.5 ml-4">
                          {step.frictionPoints.map((fp: string, idx: number) => (
                            <li key={idx} className="list-disc">{fp}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {step.boosters.length > 0 && (
                      <div>
                        <p className="text-sm font-medium text-green-700">Boosters:</p>
                        <ul className="text-sm space-y-0.5 ml-4">
                          {step.boosters.map((b: string, idx: number) => (
                            <li key={idx} className="list-disc">{b}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {generatedJourney.suggestedMetrics.length > 0 && (
              <div>
                <h4 className="font-semibold mb-3">Suggested Metrics</h4>
                <div className="space-y-2">
                  {generatedJourney.suggestedMetrics.map((metric: typeof generatedJourney.suggestedMetrics[0], idx: number) => (
                    <div key={idx} className="bg-white p-3 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{metric.metricType}</Badge>
                        <p className="font-medium">{metric.name}</p>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{metric.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <Button className="w-full" size="lg" onClick={handleUseJourney}>
              <Check className="w-4 h-4 mr-2" />
              Use This Journey
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// AI simulation function
function generateJourneyFromInputs(
  persona: Persona,
  primaryGoal: string,
  contextualInfo: string,
  focusAreas: string
): AIGeneratedJourney {
  const focusArray = focusAreas.split(',').map((f: string) => f.trim()).filter(Boolean);
  
  // Generate journey name
  const suggestedName = `${persona.name}'s Path to ${primaryGoal}`;
  
  // Generate description
  const suggestedDescription = `A tailored journey for ${persona.name} (${persona.experienceLevel}) designed to ${primaryGoal.toLowerCase()}. ${contextualInfo || 'This journey considers their unique motivations and potential friction points.'}`;
  
  // Generate steps based on persona and goal
  const steps = generateStepsForPersona(persona, primaryGoal, focusArray);
  
  // Generate metrics
  const metrics = [
    {
      name: 'Time to Goal Completion',
      description: `Time it takes for ${persona.name} to ${primaryGoal.toLowerCase()}`,
      metricType: 'time'
    },
    {
      name: 'Step Completion Rate',
      description: 'Percentage of users completing each step',
      metricType: 'ratio'
    },
    {
      name: 'Drop-off Points',
      description: 'Identify where users abandon the journey',
      metricType: 'count'
    }
  ];
  
  return {
    suggestedName,
    suggestedDescription,
    suggestedSteps: steps,
    suggestedMetrics: metrics,
    confidenceScore: 0.85
  };
}

function generateStepsForPersona(
  persona: Persona,
  goal: string,
  focusAreas: string[]
): AIGeneratedJourney['suggestedSteps'] {
  const isNewToCrypto = persona.experienceLevel === 'new-to-crypto';
  const steps: AIGeneratedJourney['suggestedSteps'] = [];
  
  // Step 1: Discovery
  steps.push({
    stageName: 'Discover',
    stepName: 'Initial Discovery',
    order: 1,
    touchpointSuggestions: persona.preferredChannels.slice(0, 2),
    entryCondition: `User encounters DreamNet through ${persona.preferredChannels[0] || 'social media'}`,
    desiredOutcome: 'User feels curious and wants to learn more',
    emotionalBefore: 'Unaware or casually browsing',
    emotionalAfter: 'Curious and intrigued',
    frictionPoints: [
      persona.fears[0] || 'Unclear value proposition',
      'Too much information at once'
    ],
    boosters: [
      'Clear, simple messaging',
      'Social proof from similar users',
      persona.motivations[0] || 'Immediate value visible'
    ],
    reasoning: `${persona.name} needs to quickly understand why DreamNet matters to them`
  });
  
  // Step 2: Exploration
  if (isNewToCrypto) {
    steps.push({
      stageName: 'Explore',
      stepName: 'Learn the Basics',
      order: 2,
      touchpointSuggestions: ['mini-app', 'agent-interaction'],
      entryCondition: 'User clicked through from initial discovery',
      desiredOutcome: 'User understands key concepts without feeling overwhelmed',
      emotionalBefore: 'Curious but uncertain',
      emotionalAfter: 'Informed and cautiously optimistic',
      frictionPoints: [
        'Crypto jargon and complexity',
        persona.fears[0] || 'Fear of making mistakes',
        'No clear next step'
      ],
      boosters: [
        'Plain language explanations',
        'Interactive tutorials',
        'No commitment required yet'
      ],
      reasoning: 'New users need education before action'
    });
  } else {
    steps.push({
      stageName: 'Explore',
      stepName: 'Explore Features',
      order: 2,
      touchpointSuggestions: ['mini-app', 'frame'],
      entryCondition: 'User clicked through from initial discovery',
      desiredOutcome: 'User sees how DreamNet aligns with their goals',
      emotionalBefore: 'Evaluating and comparing',
      emotionalAfter: 'Impressed and eager to try',
      frictionPoints: [
        'Unclear differentiation from competitors',
        'Too many options',
        persona.fears[1] || 'Time investment concerns'
      ],
      boosters: [
        'Clear unique value props',
        'Quick interactive demos',
        'Visible community activity'
      ],
      reasoning: `${persona.name} wants to see why DreamNet is different`
    });
  }
  
  // Step 3: First Action
  steps.push({
    stageName: 'Join',
    stepName: isNewToCrypto ? 'Create Account' : 'First Interaction',
    order: 3,
    touchpointSuggestions: isNewToCrypto ? ['mini-app', 'agent-interaction'] : ['frame', 'drop-page'],
    entryCondition: `User decided to ${goal.toLowerCase()}`,
    desiredOutcome: `User successfully completes first action toward ${goal}`,
    emotionalBefore: 'Excited but slightly nervous',
    emotionalAfter: 'Accomplished and validated',
    frictionPoints: isNewToCrypto ? [
      'Wallet creation overwhelm',
      persona.fears[0] || 'Fear of scams',
      'Complex interface'
    ] : [
      'Wallet signing friction',
      'Gas cost surprise',
      'Transaction delay'
    ],
    boosters: isNewToCrypto ? [
      'Social login / email option',
      'Step-by-step guided flow',
      'Immediate positive feedback'
    ] : [
      'Gasless first transaction',
      'Clear transaction preview',
      'Instant confirmation'
    ],
    reasoning: 'First action must feel easy and safe'
  });
  
  // Step 4: Engagement
  steps.push({
    stageName: 'Play',
    stepName: 'Continued Engagement',
    order: 4,
    touchpointSuggestions: ['mini-app', 'agent-interaction', 'drop-page'],
    entryCondition: 'User completed first action successfully',
    desiredOutcome: 'User explores more features and sees long-term value',
    emotionalBefore: 'Confident and curious',
    emotionalAfter: 'Invested and loyal',
    frictionPoints: [
      'Unclear what to do next',
      'No progression or feedback',
      persona.fears[1] || 'Losing interest'
    ],
    boosters: [
      'Clear next steps and recommendations',
      'Gamification and progress tracking',
      'Community engagement opportunities'
    ],
    reasoning: 'Keep momentum going with clear progression'
  });
  
  // Step 5: Contribution (if advanced user)
  if (persona.experienceLevel === 'advanced' || persona.experienceLevel === 'pro') {
    steps.push({
      stageName: 'Contribute',
      stepName: 'Give Back to Community',
      order: 5,
      touchpointSuggestions: ['social-post', 'agent-interaction', 'irl-event'],
      entryCondition: 'User is actively engaged and knowledgeable',
      desiredOutcome: 'User contributes value back to the ecosystem',
      emotionalBefore: 'Experienced and confident',
      emotionalAfter: 'Proud and deeply invested',
      frictionPoints: [
        'Unclear how to contribute',
        'No recognition for contributions',
        'High barrier to entry'
      ],
      boosters: [
        'Clear contribution pathways',
        'Public recognition',
        'Rewards and incentives'
      ],
      reasoning: 'Advanced users want to contribute and be recognized'
    });
  }
  
  return steps;
}
