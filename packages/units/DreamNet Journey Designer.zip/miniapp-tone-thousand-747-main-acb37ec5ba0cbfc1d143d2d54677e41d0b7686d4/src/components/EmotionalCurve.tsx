'use client';

import React, { useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Smile, Meh, Frown, TrendingUp, TrendingDown } from 'lucide-react';
import type { JourneyStep } from '@/types/dreamnet';

interface EmotionalCurveProps {
  steps: JourneyStep[];
}

export function EmotionalCurve({ steps }: EmotionalCurveProps): React.JSX.Element {
  const emotionalData = useMemo(() => {
    return steps.map((step: JourneyStep, idx: number) => {
      const beforeScore = emotionToScore(step.emotionalStateBefore);
      const afterScore = emotionToScore(step.emotionalStateAfter);
      return {
        stepOrder: step.order,
        stepName: step.desiredOutcome || `Step ${idx + 1}`,
        beforeScore,
        afterScore,
        delta: afterScore - beforeScore,
        emotionalBefore: step.emotionalStateBefore,
        emotionalAfter: step.emotionalStateAfter
      };
    });
  }, [steps]);

  const maxScore = 10;
  const minScore = -10;
  const range = maxScore - minScore;

  const overallTrend = useMemo(() => {
    if (emotionalData.length < 2) return 0;
    const firstAfter = emotionalData[0]?.afterScore || 0;
    const lastAfter = emotionalData[emotionalData.length - 1]?.afterScore || 0;
    return lastAfter - firstAfter;
  }, [emotionalData]);

  const averageScore = useMemo(() => {
    if (emotionalData.length === 0) return 0;
    const sum = emotionalData.reduce((acc: number, d: typeof emotionalData[0]) => acc + d.afterScore, 0);
    return sum / emotionalData.length;
  }, [emotionalData]);

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-purple-50 to-blue-50">
        <CardHeader>
          <CardTitle>Emotional Curve Analysis</CardTitle>
          <CardDescription>
            Track how users feel throughout their journey
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Overall Trend</p>
              <div className="flex items-center gap-2 mt-1">
                {overallTrend > 0 ? (
                  <>
                    <TrendingUp className="w-5 h-5 text-green-600" />
                    <span className="text-lg font-bold text-green-600">+{overallTrend.toFixed(1)}</span>
                  </>
                ) : overallTrend < 0 ? (
                  <>
                    <TrendingDown className="w-5 h-5 text-red-600" />
                    <span className="text-lg font-bold text-red-600">{overallTrend.toFixed(1)}</span>
                  </>
                ) : (
                  <>
                    <Meh className="w-5 h-5 text-gray-600" />
                    <span className="text-lg font-bold text-gray-600">0.0</span>
                  </>
                )}
              </div>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Average Emotion</p>
              <div className="flex items-center gap-2 mt-1">
                {getEmotionIcon(averageScore)}
                <span className="text-lg font-bold">{averageScore.toFixed(1)}</span>
              </div>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Journey Health</p>
              <Badge 
                variant={averageScore > 3 ? 'default' : averageScore > 0 ? 'secondary' : 'destructive'}
                className="mt-1"
              >
                {averageScore > 3 ? 'Excellent' : averageScore > 0 ? 'Good' : 'Needs Work'}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Step-by-Step Emotional Journey</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Visualization */}
            <div className="relative h-64 bg-gray-50 rounded-lg p-4">
              {/* Y-axis labels */}
              <div className="absolute left-2 top-0 bottom-0 flex flex-col justify-between text-xs text-muted-foreground">
                <span>+10 😊</span>
                <span>+5</span>
                <span>0 😐</span>
                <span>-5</span>
                <span>-10 ☹️</span>
              </div>

              {/* Grid and curve */}
              <div className="ml-12 h-full relative">
                {/* Zero line */}
                <div 
                  className="absolute w-full border-t-2 border-dashed border-gray-300"
                  style={{ top: '50%' }}
                />

                {/* Emotional curve */}
                <svg className="w-full h-full">
                  {/* Draw line connecting after-scores */}
                  {emotionalData.map((point: typeof emotionalData[0], idx: number) => {
                    if (idx === emotionalData.length - 1) return null;
                    const nextPoint = emotionalData[idx + 1];
                    if (!nextPoint) return null;

                    const x1 = (idx / (emotionalData.length - 1)) * 100;
                    const y1 = 50 - (point.afterScore / range) * 100;
                    const x2 = ((idx + 1) / (emotionalData.length - 1)) * 100;
                    const y2 = 50 - (nextPoint.afterScore / range) * 100;

                    return (
                      <line
                        key={`line-${idx}`}
                        x1={`${x1}%`}
                        y1={`${y1}%`}
                        x2={`${x2}%`}
                        y2={`${y2}%`}
                        stroke="#8b5cf6"
                        strokeWidth="3"
                        strokeLinecap="round"
                      />
                    );
                  })}

                  {/* Draw points */}
                  {emotionalData.map((point: typeof emotionalData[0], idx: number) => {
                    const x = (idx / (emotionalData.length - 1)) * 100;
                    const y = 50 - (point.afterScore / range) * 100;

                    return (
                      <g key={`point-${idx}`}>
                        <circle
                          cx={`${x}%`}
                          cy={`${y}%`}
                          r="6"
                          fill="#8b5cf6"
                          stroke="white"
                          strokeWidth="2"
                        />
                        <text
                          x={`${x}%`}
                          y={`${y + 8}%`}
                          textAnchor="middle"
                          fontSize="10"
                          fill="#666"
                        >
                          {point.stepOrder}
                        </text>
                      </g>
                    );
                  })}
                </svg>
              </div>

              {/* X-axis */}
              <div className="ml-12 mt-2 flex justify-between text-xs text-muted-foreground">
                <span>Start</span>
                <span>End</span>
              </div>
            </div>

            {/* Detailed step breakdown */}
            <div className="space-y-3">
              {emotionalData.map((point: typeof emotionalData[0]) => (
                <div key={point.stepOrder} className="border rounded-lg p-4 space-y-2">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Step {point.stepOrder}</Badge>
                        <h4 className="font-medium">{point.stepName}</h4>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {point.delta > 0 ? (
                        <Badge className="bg-green-100 text-green-800">
                          +{point.delta.toFixed(1)} 📈
                        </Badge>
                      ) : point.delta < 0 ? (
                        <Badge className="bg-red-100 text-red-800">
                          {point.delta.toFixed(1)} 📉
                        </Badge>
                      ) : (
                        <Badge variant="secondary">
                          No change
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Before:</p>
                      <div className="flex items-center gap-2 mt-1">
                        {getEmotionIcon(point.beforeScore)}
                        <span className="font-medium">{point.emotionalBefore}</span>
                        <span className="text-muted-foreground">({point.beforeScore.toFixed(1)})</span>
                      </div>
                    </div>
                    <div>
                      <p className="text-muted-foreground">After:</p>
                      <div className="flex items-center gap-2 mt-1">
                        {getEmotionIcon(point.afterScore)}
                        <span className="font-medium">{point.emotionalAfter}</span>
                        <span className="text-muted-foreground">({point.afterScore.toFixed(1)})</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Helper function to convert emotional state text to numerical score
function emotionToScore(emotion: string): number {
  const lower = emotion.toLowerCase();
  
  // Very positive (7-10)
  if (lower.includes('excited') || lower.includes('thrilled') || lower.includes('delighted')) return 9;
  if (lower.includes('happy') || lower.includes('satisfied') || lower.includes('accomplished')) return 8;
  if (lower.includes('confident') || lower.includes('empowered') || lower.includes('proud')) return 7;
  
  // Positive (3-6)
  if (lower.includes('optimistic') || lower.includes('hopeful') || lower.includes('engaged')) return 6;
  if (lower.includes('interested') || lower.includes('curious') || lower.includes('intrigued')) return 5;
  if (lower.includes('comfortable') || lower.includes('content')) return 4;
  if (lower.includes('okay') || lower.includes('fine')) return 3;
  
  // Neutral (0-2)
  if (lower.includes('neutral') || lower.includes('indifferent')) return 0;
  if (lower.includes('uncertain') || lower.includes('questioning')) return 1;
  if (lower.includes('cautious') || lower.includes('careful')) return 2;
  
  // Negative (-3 to -1)
  if (lower.includes('confused') || lower.includes('unclear')) return -2;
  if (lower.includes('bored') || lower.includes('uninterested')) return -3;
  if (lower.includes('frustrated') || lower.includes('annoyed')) return -4;
  
  // Very negative (-7 to -4)
  if (lower.includes('anxious') || lower.includes('nervous') || lower.includes('worried')) return -5;
  if (lower.includes('scared') || lower.includes('fearful')) return -7;
  if (lower.includes('angry') || lower.includes('upset')) return -8;
  if (lower.includes('devastated') || lower.includes('hopeless')) return -9;
  
  // Default neutral
  return 0;
}

function getEmotionIcon(score: number): React.ReactNode {
  if (score > 5) return <Smile className="w-5 h-5 text-green-600" />;
  if (score > 0) return <Smile className="w-5 h-5 text-blue-600" />;
  if (score === 0) return <Meh className="w-5 h-5 text-gray-600" />;
  if (score > -5) return <Frown className="w-5 h-5 text-orange-600" />;
  return <Frown className="w-5 h-5 text-red-600" />;
}
