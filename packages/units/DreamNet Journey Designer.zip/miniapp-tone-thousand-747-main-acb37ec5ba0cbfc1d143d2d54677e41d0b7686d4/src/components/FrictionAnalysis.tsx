'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { AlertTriangle, TrendingDown, Lightbulb, ArrowRight } from 'lucide-react';
import type { FrictionScore, FrictionAnalysis } from '@/types/dreamnet-enhancements';
import type { ExperienceJourney, JourneyStep } from '@/types/dreamnet';

interface FrictionAnalysisProps {
  journey: ExperienceJourney;
  steps: JourneyStep[];
}

export function FrictionAnalysisComponent({ journey, steps }: FrictionAnalysisProps): React.JSX.Element {
  const [analysis, setAnalysis] = useState<FrictionAnalysis | null>(null);

  useEffect(() => {
    // Generate friction analysis from journey steps
    const scores: FrictionScore[] = [];
    let totalFriction = 0;

    steps.forEach((step: JourneyStep) => {
      step.frictionPoints.forEach((friction: string, idx: number) => {
        // Simulate friction scoring based on keywords and step position
        const severity = calculateSeverity(friction, step.order);
        const score: FrictionScore = {
          id: `friction-${step.id}-${idx}`,
          stepId: step.id,
          frictionType: categorizeFriction(friction),
          severity,
          impactedUsers: estimateImpact(severity),
          description: friction,
          estimatedDropOffRate: severity * 5, // 5-25% drop-off
          fixPriority: severity >= 4 ? 'critical' : severity >= 3 ? 'high' : 'medium',
          fixEffort: estimateEffort(friction),
          fixIdeas: generateFixIdeas(friction)
        };
        scores.push(score);
        totalFriction += severity;
      });
    });

    const recommendations = generateRecommendations(scores, steps);
    const overallDropOff = Math.min(95, totalFriction * 2.5);

    setAnalysis({
      id: `analysis-${journey.id}`,
      journeyId: journey.id,
      totalFrictionScore: totalFriction,
      scores,
      recommendations,
      estimatedOverallDropOff: overallDropOff
    });
  }, [journey, steps]);

  if (!analysis) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <p className="text-muted-foreground">Analyzing friction points...</p>
        </CardContent>
      </Card>
    );
  }

  const severityColor = (severity: number): string => {
    if (severity >= 4) return 'bg-red-500';
    if (severity >= 3) return 'bg-orange-500';
    if (severity >= 2) return 'bg-yellow-500';
    return 'bg-blue-500';
  };

  const criticalFrictions = analysis.scores.filter((s: FrictionScore) => s.severity >= 4);
  const highFrictions = analysis.scores.filter((s: FrictionScore) => s.severity === 3);

  return (
    <div className="space-y-6">
      <Card className="border-orange-200 bg-orange-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-600" />
            Friction Analysis Overview
          </CardTitle>
          <CardDescription>
            Identified {analysis.scores.length} friction points across {steps.length} steps
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total Friction Score</p>
              <p className="text-3xl font-bold text-orange-600">{analysis.totalFrictionScore}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Estimated Drop-Off</p>
              <p className="text-3xl font-bold text-red-600">{analysis.estimatedOverallDropOff.toFixed(1)}%</p>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Critical Issues</p>
              <p className="text-3xl font-bold text-red-600">{criticalFrictions.length}</p>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium">Journey Health</p>
              <p className="text-sm text-muted-foreground">
                {100 - analysis.estimatedOverallDropOff > 70 ? 'Good' : 
                 100 - analysis.estimatedOverallDropOff > 50 ? 'Fair' : 'Needs Improvement'}
              </p>
            </div>
            <Progress 
              value={100 - analysis.estimatedOverallDropOff} 
              className="h-2"
            />
          </div>
        </CardContent>
      </Card>

      {criticalFrictions.length > 0 && (
        <Card className="border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-700">
              <TrendingDown className="w-5 h-5" />
              Critical Friction Points ({criticalFrictions.length})
            </CardTitle>
            <CardDescription>
              These issues are likely causing significant user drop-off
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {criticalFrictions.map((friction: FrictionScore) => {
              const step = steps.find((s: JourneyStep) => s.id === friction.stepId);
              return (
                <div key={friction.id} className="bg-white p-4 rounded-lg space-y-2">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="font-medium">{friction.description}</p>
                      {step && (
                        <p className="text-sm text-muted-foreground">
                          Step: {step.desiredOutcome || 'Unnamed step'}
                        </p>
                      )}
                    </div>
                    <Badge className={severityColor(friction.severity)}>
                      Severity {friction.severity}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-sm">
                    <div>
                      <p className="text-muted-foreground">Drop-off</p>
                      <p className="font-medium">{friction.estimatedDropOffRate}%</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Priority</p>
                      <Badge variant="outline">{friction.fixPriority}</Badge>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Effort</p>
                      <Badge variant="secondary">{friction.fixEffort}</Badge>
                    </div>
                  </div>
                  {friction.fixIdeas.length > 0 && (
                    <div className="mt-2 pt-2 border-t">
                      <p className="text-sm font-medium mb-1 flex items-center gap-1">
                        <Lightbulb className="w-4 h-4" />
                        Fix Ideas:
                      </p>
                      <ul className="text-sm space-y-1">
                        {friction.fixIdeas.map((idea: string, idx: number) => (
                          <li key={idx} className="flex items-start gap-2">
                            <ArrowRight className="w-4 h-4 mt-0.5 text-green-600 flex-shrink-0" />
                            <span>{idea}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      {highFrictions.length > 0 && (
        <Card className="border-orange-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              High Priority Friction Points ({highFrictions.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {highFrictions.map((friction: FrictionScore) => {
              const step = steps.find((s: JourneyStep) => s.id === friction.stepId);
              return (
                <div key={friction.id} className="border p-3 rounded-lg space-y-1">
                  <div className="flex items-start justify-between">
                    <p className="font-medium flex-1">{friction.description}</p>
                    <Badge className={severityColor(friction.severity)}>
                      Severity {friction.severity}
                    </Badge>
                  </div>
                  {step && (
                    <p className="text-sm text-muted-foreground">
                      Step: {step.desiredOutcome || 'Unnamed step'}
                    </p>
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-yellow-600" />
            Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {analysis.recommendations.map((rec: string, idx: number) => (
              <li key={idx} className="flex items-start gap-2">
                <ArrowRight className="w-5 h-5 mt-0.5 text-blue-600 flex-shrink-0" />
                <span>{rec}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}

// Helper functions
function calculateSeverity(friction: string, stepOrder: number): 1 | 2 | 3 | 4 | 5 {
  const lower = friction.toLowerCase();
  let severity = 2;

  // High severity keywords
  if (lower.includes('confusing') || lower.includes('unclear') || lower.includes('hard')) severity = 4;
  if (lower.includes('gas') || lower.includes('wallet') || lower.includes('transaction')) severity = 4;
  if (lower.includes('scam') || lower.includes('trust') || lower.includes('fear')) severity = 5;
  if (lower.includes('slow') || lower.includes('delay') || lower.includes('wait')) severity = 3;
  
  // Medium severity
  if (lower.includes('complex') || lower.includes('many')) severity = 3;
  if (lower.includes('missing') || lower.includes('no ')) severity = 3;
  
  // Early steps more critical
  if (stepOrder <= 2) severity = Math.min(5, severity + 1) as 1 | 2 | 3 | 4 | 5;
  
  return severity as 1 | 2 | 3 | 4 | 5;
}

function categorizeFriction(friction: string): 'technical' | 'cognitive' | 'emotional' | 'economic' | 'trust' | 'time' {
  const lower = friction.toLowerCase();
  if (lower.includes('scam') || lower.includes('trust') || lower.includes('fear')) return 'trust';
  if (lower.includes('gas') || lower.includes('cost') || lower.includes('expensive')) return 'economic';
  if (lower.includes('slow') || lower.includes('delay') || lower.includes('time')) return 'time';
  if (lower.includes('complex') || lower.includes('confusing') || lower.includes('understand')) return 'cognitive';
  if (lower.includes('error') || lower.includes('bug') || lower.includes('broken')) return 'technical';
  return 'emotional';
}

function estimateImpact(severity: number): number {
  return severity * 15 + 10; // 25-85% of users
}

function estimateEffort(friction: string): 'easy' | 'medium' | 'hard' | 'unknown' {
  const lower = friction.toLowerCase();
  if (lower.includes('wording') || lower.includes('text') || lower.includes('copy')) return 'easy';
  if (lower.includes('design') || lower.includes('layout') || lower.includes('ui')) return 'medium';
  if (lower.includes('wallet') || lower.includes('blockchain') || lower.includes('contract')) return 'hard';
  return 'medium';
}

function generateFixIdeas(friction: string): string[] {
  const ideas: string[] = [];
  const lower = friction.toLowerCase();
  
  if (lower.includes('gas') || lower.includes('cost')) {
    ideas.push('Implement gas sponsorship for first-time users');
    ideas.push('Show estimated cost upfront before transaction');
    ideas.push('Batch transactions to reduce gas fees');
  }
  
  if (lower.includes('wallet') || lower.includes('connect')) {
    ideas.push('Add social login / email wallet option');
    ideas.push('Provide step-by-step wallet connection guide');
    ideas.push('Show preview of what happens before wallet prompt');
  }
  
  if (lower.includes('confus') || lower.includes('unclear')) {
    ideas.push('Add tooltips explaining key terms');
    ideas.push('Simplify UI and reduce options');
    ideas.push('Add progress indicators showing what\'s next');
  }
  
  if (lower.includes('slow') || lower.includes('delay')) {
    ideas.push('Add loading states with progress feedback');
    ideas.push('Optimize backend performance');
    ideas.push('Show estimated wait time');
  }
  
  if (lower.includes('trust') || lower.includes('scam')) {
    ideas.push('Add security badges and verification');
    ideas.push('Show social proof (testimonials, user count)');
    ideas.push('Provide transparency about data usage');
  }
  
  if (ideas.length === 0) {
    ideas.push('Conduct user testing to identify specific issues');
    ideas.push('Add analytics to measure impact');
    ideas.push('Simplify and clarify the user interface');
  }
  
  return ideas;
}

function generateRecommendations(scores: FrictionScore[], steps: JourneyStep[]): string[] {
  const recommendations: string[] = [];
  
  const criticalCount = scores.filter((s: FrictionScore) => s.severity >= 4).length;
  const earlyFrictions = scores.filter((s: FrictionScore) => {
    const step = steps.find((st: JourneyStep) => st.id === s.stepId);
    return step && step.order <= 2;
  });
  
  const walletFrictions = scores.filter((s: FrictionScore) => 
    s.description.toLowerCase().includes('wallet')
  );
  const gasFrictions = scores.filter((s: FrictionScore) => 
    s.description.toLowerCase().includes('gas')
  );
  const trustFrictions = scores.filter((s: FrictionScore) => s.frictionType === 'trust');
  
  if (criticalCount > 3) {
    recommendations.push('🚨 Priority: Address critical friction points immediately - they\'re likely causing 40%+ drop-off');
  }
  
  if (earlyFrictions.length > 0) {
    recommendations.push('⚡ Focus on first 2 steps - early friction has compounding negative effects');
  }
  
  if (walletFrictions.length > 0) {
    recommendations.push('🔑 Implement progressive wallet onboarding - delay wallet connection until value is demonstrated');
    recommendations.push('Consider adding social login / custodial wallet option for beginners');
  }
  
  if (gasFrictions.length > 0) {
    recommendations.push('⛽ Implement gas sponsorship or batch transactions to reduce friction');
    recommendations.push('Always show estimated costs before requiring user action');
  }
  
  if (trustFrictions.length > 0) {
    recommendations.push('🛡️ Add trust signals: security badges, testimonials, transparent explanations');
    recommendations.push('Provide clear information about what happens with user data/funds');
  }
  
  recommendations.push('📊 Set up analytics to measure actual drop-off at each step');
  recommendations.push('🧪 A/B test solutions for high-severity friction points');
  recommendations.push('💬 Conduct user interviews to validate friction hypotheses');
  
  return recommendations;
}
