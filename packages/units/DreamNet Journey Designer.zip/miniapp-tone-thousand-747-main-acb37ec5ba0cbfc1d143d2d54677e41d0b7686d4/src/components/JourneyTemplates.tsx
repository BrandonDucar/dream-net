'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Rocket, Users, Heart, TrendingUp } from 'lucide-react';
import type { JourneyTemplate } from '@/types/dreamnet-enhancements';

const BUILT_IN_TEMPLATES: JourneyTemplate[] = [
  {
    id: 'template-1',
    name: 'Base Degen Discovery Journey',
    category: 'discovery',
    description: 'Path for crypto-native users discovering your project through Farcaster frames and mints',
    targetPersonaType: 'Base Degen',
    defaultStages: ['Discover', 'Explore', 'Join', 'Play'],
    defaultSteps: [
      {
        stageName: 'Discover',
        stepName: 'See Frame in Feed',
        touchpointTypes: ['frame', 'social-post'],
        emotionalBefore: 'Scrolling, bored',
        emotionalAfter: 'Curious, intrigued',
        commonFrictions: ['Too many frames competing', 'Unclear value prop'],
        commonBoosters: ['Eye-catching visual', 'Social proof (likes/recasts)', 'Clear reward']
      },
      {
        stageName: 'Explore',
        stepName: 'Click Frame CTA',
        touchpointTypes: ['frame', 'mini-app'],
        emotionalBefore: 'Curious, cautious',
        emotionalAfter: 'Engaged, wanting more',
        commonFrictions: ['Frame takes too long to load', 'Complex UI', 'Gas required immediately'],
        commonBoosters: ['Instant response', 'Gasless action', 'Preview of reward']
      },
      {
        stageName: 'Join',
        stepName: 'First Mint or Claim',
        touchpointTypes: ['drop-page', 'frame'],
        emotionalBefore: 'Excited, slightly nervous',
        emotionalAfter: 'Accomplished, part of something',
        commonFrictions: ['Wallet signing confusion', 'Gas cost surprise', 'Transaction delay'],
        commonBoosters: ['Clear instructions', 'Gas sponsorship', 'Immediate confirmation']
      },
      {
        stageName: 'Play',
        stepName: 'Explore More Drops',
        touchpointTypes: ['mini-app', 'agent-interaction'],
        emotionalBefore: 'Confident, curious',
        emotionalAfter: 'Invested, loyal',
        commonFrictions: ['Hard to find next action', 'Unclear progression'],
        commonBoosters: ['Clear next steps', 'Gamification', 'Community recognition']
      }
    ],
    estimatedCompletionTime: '5-15 minutes',
    difficulty: 'beginner',
    tags: ['web3', 'farcaster', 'mint', 'onboarding']
  },
  {
    id: 'template-2',
    name: 'Web2 Curious → Web3 Convert',
    category: 'onboarding',
    description: 'Journey for newcomers discovering crypto through your content or IRL events',
    targetPersonaType: 'New to Crypto',
    defaultStages: ['Discover', 'Explore', 'Join'],
    defaultSteps: [
      {
        stageName: 'Discover',
        stepName: 'See Social Content',
        touchpointTypes: ['social-post', 'other'],
        emotionalBefore: 'Unaware, neutral',
        emotionalAfter: 'Interested, questioning',
        commonFrictions: ['Crypto jargon', 'Seems complex', 'Trust concerns'],
        commonBoosters: ['Plain language', 'Familiar social platform', 'Friend recommendation']
      },
      {
        stageName: 'Explore',
        stepName: 'Click Learn More',
        touchpointTypes: ['mini-app', 'other'],
        emotionalBefore: 'Curious, uncertain',
        emotionalAfter: 'Informed, cautiously optimistic',
        commonFrictions: ['Too much information', 'No clear next step', 'Fear of losing money'],
        commonBoosters: ['Simple explainer', 'No wallet needed yet', 'Risk-free promise']
      },
      {
        stageName: 'Join',
        stepName: 'Create First Wallet',
        touchpointTypes: ['mini-app', 'agent-interaction'],
        emotionalBefore: 'Nervous, determined',
        emotionalAfter: 'Accomplished, empowered',
        commonFrictions: ['Seed phrase overwhelm', 'Fear of scams', 'Complex interface'],
        commonBoosters: ['Social login option', 'Hand-holding tutorial', 'Recovery guarantee']
      }
    ],
    estimatedCompletionTime: '20-45 minutes',
    difficulty: 'beginner',
    tags: ['onboarding', 'web2-to-web3', 'education', 'wallet']
  },
  {
    id: 'template-3',
    name: 'Builder Engagement Loop',
    category: 'retention',
    description: 'Journey for developers engaging with your tools, contributing, and becoming evangelists',
    targetPersonaType: 'Builder',
    defaultStages: ['Discover', 'Explore', 'Join', 'Contribute', 'Evangelize'],
    defaultSteps: [
      {
        stageName: 'Discover',
        stepName: 'Find Documentation',
        touchpointTypes: ['social-post', 'other'],
        emotionalBefore: 'Searching for solutions',
        emotionalAfter: 'Hopeful, evaluating',
        commonFrictions: ['Unclear differentiation', 'Missing key info', 'Dead links'],
        commonBoosters: ['Clear value prop', 'Quick start guide', 'Live examples']
      },
      {
        stageName: 'Explore',
        stepName: 'Try First Integration',
        touchpointTypes: ['mini-app', 'other'],
        emotionalBefore: 'Cautiously optimistic',
        emotionalAfter: 'Impressed or frustrated',
        commonFrictions: ['Complex setup', 'Missing dependencies', 'Poor error messages'],
        commonBoosters: ['One-click templates', 'Clear errors', 'Active community']
      },
      {
        stageName: 'Join',
        stepName: 'Join Dev Community',
        touchpointTypes: ['social-post', 'other'],
        emotionalBefore: 'Interested, seeking support',
        emotionalAfter: 'Welcomed, part of tribe',
        commonFrictions: ['Inactive community', 'Unwelcoming vibe', 'No responses'],
        commonBoosters: ['Quick responses', 'Helpful members', 'Recognition']
      },
      {
        stageName: 'Contribute',
        stepName: 'Submit First PR or Build',
        touchpointTypes: ['other', 'agent-interaction'],
        emotionalBefore: 'Excited, nervous',
        emotionalAfter: 'Proud, invested',
        commonFrictions: ['Unclear contribution guide', 'Slow review', 'Rejected work'],
        commonBoosters: ['Clear guidelines', 'Fast feedback', 'Public recognition']
      },
      {
        stageName: 'Evangelize',
        stepName: 'Share Their Build',
        touchpointTypes: ['social-post', 'frame'],
        emotionalBefore: 'Proud, eager to share',
        emotionalAfter: 'Validated, deeply loyal',
        commonFrictions: ['No shareables', 'Hard to explain', 'No recognition'],
        commonBoosters: ['Share templates', 'Amplification', 'Rewards/badges']
      }
    ],
    estimatedCompletionTime: '1-4 weeks',
    difficulty: 'advanced',
    tags: ['developer', 'community', 'contribution', 'retention']
  },
  {
    id: 'template-4',
    name: 'Pickleball Parent to Community Member',
    category: 'conversion',
    description: 'Journey for parents discovering pickleball lessons and joining the IRL community',
    targetPersonaType: 'Local Player',
    defaultStages: ['Discover', 'Explore', 'Join', 'Play', 'Evangelize'],
    defaultSteps: [
      {
        stageName: 'Discover',
        stepName: 'Hear About Lessons',
        touchpointTypes: ['social-post', 'irl-event', 'other'],
        emotionalBefore: 'Looking for kid activities',
        emotionalAfter: 'Interested, considering',
        commonFrictions: ['Skeptical of new sport', 'Cost concerns', 'Schedule conflicts'],
        commonBoosters: ['Friend referral', 'Free trial offer', 'Convenient location']
      },
      {
        stageName: 'Explore',
        stepName: 'Visit Landing Page',
        touchpointTypes: ['mini-app', 'other'],
        emotionalBefore: 'Researching, comparing',
        emotionalAfter: 'Convinced or moved on',
        commonFrictions: ['Unclear schedule', 'No pricing', 'Hard to book'],
        commonBoosters: ['Clear calendar', 'Transparent pricing', 'Easy booking']
      },
      {
        stageName: 'Join',
        stepName: 'Attend First Lesson',
        touchpointTypes: ['irl-event'],
        emotionalBefore: 'Nervous, hopeful',
        emotionalAfter: 'Relieved, excited',
        commonFrictions: ['Unwelcoming environment', 'Too advanced', 'Disorganized'],
        commonBoosters: ['Warm greeting', 'Age-appropriate groups', 'Clear structure']
      },
      {
        stageName: 'Play',
        stepName: 'Book Regular Sessions',
        touchpointTypes: ['mini-app', 'irl-event'],
        emotionalBefore: 'Satisfied, routine',
        emotionalAfter: 'Committed, loyal',
        commonFrictions: ['Hard to rebook', 'Inconsistent experience', 'No progress tracking'],
        commonBoosters: ['Auto-booking', 'Progress updates', 'Community events']
      },
      {
        stageName: 'Evangelize',
        stepName: 'Refer Other Parents',
        touchpointTypes: ['social-post', 'irl-event'],
        emotionalBefore: 'Happy, proud',
        emotionalAfter: 'Ambassador, deeply invested',
        commonFrictions: ['No referral program', 'Hard to explain value', 'No incentive'],
        commonBoosters: ['Referral rewards', 'Easy sharing', 'Recognition']
      }
    ],
    estimatedCompletionTime: '2-8 weeks',
    difficulty: 'intermediate',
    tags: ['irl', 'pickleball', 'community', 'family']
  }
];

interface JourneyTemplatesProps {
  onSelectTemplate: (template: JourneyTemplate) => void;
}

export function JourneyTemplates({ onSelectTemplate }: JourneyTemplatesProps): React.JSX.Element {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const categories = [
    { key: 'onboarding', label: 'Onboarding', icon: Rocket },
    { key: 'discovery', label: 'Discovery', icon: Sparkles },
    { key: 'conversion', label: 'Conversion', icon: TrendingUp },
    { key: 'retention', label: 'Retention', icon: Heart },
    { key: 'advocacy', label: 'Advocacy', icon: Users }
  ];

  const filteredTemplates = selectedCategory
    ? BUILT_IN_TEMPLATES.filter((t: JourneyTemplate) => t.category === selectedCategory)
    : BUILT_IN_TEMPLATES;

  const getDifficultyColor = (difficulty: string): string => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-100 text-green-800';
      case 'intermediate': return 'bg-yellow-100 text-yellow-800';
      case 'advanced': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Journey Templates</h2>
        <p className="text-muted-foreground">
          Pre-built journey maps for common DreamNet scenarios. Select a template to customize for your needs.
        </p>
      </div>

      <div className="flex gap-2 flex-wrap">
        <Button
          variant={selectedCategory === null ? 'default' : 'outline'}
          size="sm"
          onClick={() => setSelectedCategory(null)}
        >
          All Templates
        </Button>
        {categories.map((cat) => {
          const Icon = cat.icon;
          return (
            <Button
              key={cat.key}
              variant={selectedCategory === cat.key ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(cat.key)}
            >
              <Icon className="w-4 h-4 mr-1" />
              {cat.label}
            </Button>
          );
        })}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {filteredTemplates.map((template: JourneyTemplate) => (
          <Card key={template.id} className="hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg">{template.name}</CardTitle>
                  <CardDescription className="mt-1">
                    {template.description}
                  </CardDescription>
                </div>
              </div>
              <div className="flex gap-2 mt-3 flex-wrap">
                <Badge variant="secondary" className={getDifficultyColor(template.difficulty)}>
                  {template.difficulty}
                </Badge>
                <Badge variant="outline">
                  {template.defaultSteps.length} steps
                </Badge>
                <Badge variant="outline">
                  ⏱️ {template.estimatedCompletionTime}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-medium mb-1">Target Persona:</p>
                  <Badge>{template.targetPersonaType}</Badge>
                </div>
                <div>
                  <p className="text-sm font-medium mb-1">Journey Stages:</p>
                  <div className="flex gap-1 flex-wrap">
                    {template.defaultStages.map((stage: string, idx: number) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {idx + 1}. {stage}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium mb-1">Tags:</p>
                  <div className="flex gap-1 flex-wrap">
                    {template.tags.map((tag: string) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
                <Button
                  className="w-full mt-2"
                  onClick={() => onSelectTemplate(template)}
                >
                  Use This Template
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredTemplates.length === 0 && (
        <Card>
          <CardContent className="py-8 text-center text-muted-foreground">
            No templates found for this category.
          </CardContent>
        </Card>
      )}
    </div>
  );
}
