'use client';

import { useState } from 'react';
import type { CreateExperienceJourneyInput, ImportanceLevel, Persona } from '@/types/experience-map';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface JourneyFormProps {
  personas: Persona[];
  onSubmit: (input: CreateExperienceJourneyInput) => void;
  onCancel: () => void;
}

export function JourneyForm({ personas, onSubmit, onCancel }: JourneyFormProps) {
  const [personaId, setPersonaId] = useState<string>(personas[0]?.id || '');
  const [name, setName] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [primaryGoal, setPrimaryGoal] = useState<string>('');
  const [importanceLevel, setImportanceLevel] = useState<ImportanceLevel>('medium');
  const [tags, setTags] = useState<string>('');

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    
    const input: CreateExperienceJourneyInput = {
      personaId,
      name,
      description,
      primaryGoal,
      importanceLevel,
      tags: tags.split(',').map((t: string) => t.trim()).filter((t: string) => t !== ''),
    };

    onSubmit(input);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create New Journey</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="personaId">Persona</Label>
            <Select value={personaId} onValueChange={setPersonaId}>
              <SelectTrigger id="personaId">
                <SelectValue placeholder="Select a persona" />
              </SelectTrigger>
              <SelectContent>
                {personas.map((persona: Persona) => (
                  <SelectItem key={persona.id} value={persona.id}>
                    {persona.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="name">Journey Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
              required
              placeholder="e.g., Degen discovering DREAM"
            />
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
              required
              rows={3}
              placeholder="What is this journey about?"
            />
          </div>

          <div>
            <Label htmlFor="primaryGoal">Primary Goal</Label>
            <Input
              id="primaryGoal"
              value={primaryGoal}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPrimaryGoal(e.target.value)}
              required
              placeholder="e.g., Get them to mint, Join Telegram"
            />
          </div>

          <div>
            <Label htmlFor="importanceLevel">Importance Level</Label>
            <Select value={importanceLevel} onValueChange={(value: string) => setImportanceLevel(value as ImportanceLevel)}>
              <SelectTrigger id="importanceLevel">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="tags">Tags (comma-separated)</Label>
            <Input
              id="tags"
              value={tags}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTags(e.target.value)}
              placeholder="e.g., onboarding, core, experimental"
            />
          </div>

          <div className="flex gap-2">
            <Button type="submit" className="flex-1">
              Create Journey
            </Button>
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
