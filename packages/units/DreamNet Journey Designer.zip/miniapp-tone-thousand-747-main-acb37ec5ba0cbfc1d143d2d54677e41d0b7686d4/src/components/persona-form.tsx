'use client';

import { useState } from 'react';
import type { CreatePersonaInput, ExperienceLevel, Persona } from '@/types/experience-map';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { X, Plus } from 'lucide-react';

interface PersonaFormProps {
  persona?: Persona;
  onSubmit: (input: CreatePersonaInput) => void;
  onCancel: () => void;
}

export function PersonaForm({ persona, onSubmit, onCancel }: PersonaFormProps) {
  const [name, setName] = useState<string>(persona?.name || '');
  const [description, setDescription] = useState<string>(persona?.description || '');
  const [motivations, setMotivations] = useState<string[]>(persona?.motivations || ['']);
  const [fears, setFears] = useState<string[]>(persona?.fears || ['']);
  const [preferredChannels, setPreferredChannels] = useState<string[]>(persona?.preferredChannels || ['']);
  const [experienceLevel, setExperienceLevel] = useState<ExperienceLevel>(persona?.experienceLevel || 'new-to-crypto');
  const [tags, setTags] = useState<string>(persona?.tags.join(', ') || '');

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    
    const input: CreatePersonaInput = {
      name,
      description,
      motivations: motivations.filter((m: string) => m.trim() !== ''),
      fears: fears.filter((f: string) => f.trim() !== ''),
      preferredChannels: preferredChannels.filter((c: string) => c.trim() !== ''),
      experienceLevel,
      tags: tags.split(',').map((t: string) => t.trim()).filter((t: string) => t !== ''),
    };

    onSubmit(input);
  };

  const updateArrayItem = (
    arr: string[],
    setter: (arr: string[]) => void,
    index: number,
    value: string
  ): void => {
    const updated = [...arr];
    updated[index] = value;
    setter(updated);
  };

  const removeArrayItem = (
    arr: string[],
    setter: (arr: string[]) => void,
    index: number
  ): void => {
    setter(arr.filter((_: string, i: number) => i !== index));
  };

  const addArrayItem = (arr: string[], setter: (arr: string[]) => void): void => {
    setter([...arr, '']);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{persona ? 'Edit Persona' : 'Create New Persona'}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
              required
              placeholder="e.g., Base Degen, Builder, Pickle Parent"
            />
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
              required
              rows={3}
              placeholder="Who is this persona and what defines them?"
            />
          </div>

          <div>
            <Label htmlFor="experienceLevel">Experience Level</Label>
            <Select value={experienceLevel} onValueChange={(value: string) => setExperienceLevel(value as ExperienceLevel)}>
              <SelectTrigger id="experienceLevel">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="new-to-crypto">New to Crypto</SelectItem>
                <SelectItem value="intermediate">Intermediate</SelectItem>
                <SelectItem value="advanced">Advanced</SelectItem>
                <SelectItem value="pro">Pro</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Motivations</Label>
              <Button type="button" size="sm" variant="outline" onClick={() => addArrayItem(motivations, setMotivations)}>
                <Plus className="w-4 h-4 mr-1" />
                Add
              </Button>
            </div>
            {motivations.map((motivation: string, index: number) => (
              <div key={index} className="flex gap-2 mb-2">
                <Input
                  value={motivation}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    updateArrayItem(motivations, setMotivations, index, e.target.value)
                  }
                  placeholder="Why they come to DreamNet"
                />
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  onClick={() => removeArrayItem(motivations, setMotivations, index)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Fears</Label>
              <Button type="button" size="sm" variant="outline" onClick={() => addArrayItem(fears, setFears)}>
                <Plus className="w-4 h-4 mr-1" />
                Add
              </Button>
            </div>
            {fears.map((fear: string, index: number) => (
              <div key={index} className="flex gap-2 mb-2">
                <Input
                  value={fear}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    updateArrayItem(fears, setFears, index, e.target.value)
                  }
                  placeholder="What might scare them away"
                />
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  onClick={() => removeArrayItem(fears, setFears, index)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Preferred Channels</Label>
              <Button type="button" size="sm" variant="outline" onClick={() => addArrayItem(preferredChannels, setPreferredChannels)}>
                <Plus className="w-4 h-4 mr-1" />
                Add
              </Button>
            </div>
            {preferredChannels.map((channel: string, index: number) => (
              <div key={index} className="flex gap-2 mb-2">
                <Input
                  value={channel}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    updateArrayItem(preferredChannels, setPreferredChannels, index, e.target.value)
                  }
                  placeholder="e.g., farcaster, x, zora, irl-pickleball"
                />
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  onClick={() => removeArrayItem(preferredChannels, setPreferredChannels, index)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>

          <div>
            <Label htmlFor="tags">Tags (comma-separated)</Label>
            <Input
              id="tags"
              value={tags}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTags(e.target.value)}
              placeholder="e.g., gaming, social, collector"
            />
          </div>

          <div className="flex gap-2">
            <Button type="submit" className="flex-1">
              {persona ? 'Update' : 'Create'} Persona
            </Button>
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
