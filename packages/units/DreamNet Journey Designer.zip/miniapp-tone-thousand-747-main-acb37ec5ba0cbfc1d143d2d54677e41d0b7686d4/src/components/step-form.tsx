'use client';

import { useState } from 'react';
import type { CreateJourneyStepInput, JourneyStage, Touchpoint } from '@/types/experience-map';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { X, Plus } from 'lucide-react';

interface StepFormProps {
  journeyId: string;
  stages: JourneyStage[];
  touchpoints: Touchpoint[];
  existingSteps: number;
  onSubmit: (input: CreateJourneyStepInput) => void;
  onCancel: () => void;
}

export function StepForm({ journeyId, stages, touchpoints, existingSteps, onSubmit, onCancel }: StepFormProps) {
  const [stageId, setStageId] = useState<string>(stages[0]?.id || '');
  const [touchpointIds, setTouchpointIds] = useState<string[]>([]);
  const [entryCondition, setEntryCondition] = useState<string>('');
  const [desiredOutcome, setDesiredOutcome] = useState<string>('');
  const [emotionalStateBefore, setEmotionalStateBefore] = useState<string>('');
  const [emotionalStateAfter, setEmotionalStateAfter] = useState<string>('');
  const [frictionPoints, setFrictionPoints] = useState<string[]>(['']);
  const [boosters, setBoosters] = useState<string[]>(['']);
  const [notes, setNotes] = useState<string>('');

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    
    const input: CreateJourneyStepInput = {
      journeyId,
      stageId,
      order: existingSteps,
      touchpointIds,
      entryCondition,
      desiredOutcome,
      emotionalStateBefore,
      emotionalStateAfter,
      frictionPoints: frictionPoints.filter((f: string) => f.trim() !== ''),
      boosters: boosters.filter((b: string) => b.trim() !== ''),
      notes,
    };

    onSubmit(input);
  };

  const toggleTouchpoint = (id: string): void => {
    if (touchpointIds.includes(id)) {
      setTouchpointIds(touchpointIds.filter((tid: string) => tid !== id));
    } else {
      setTouchpointIds([...touchpointIds, id]);
    }
  };

  const updateArrayItem = (
    arr: string[],
    setter: (arr: string[]) => void,
    index: number,
    value: string
  ): void => {
    const updated = [...arr];
    updated[index] = value;
    setter(updated);
  };

  const removeArrayItem = (
    arr: string[],
    setter: (arr: string[]) => void,
    index: number
  ): void => {
    setter(arr.filter((_: string, i: number) => i !== index));
  };

  const addArrayItem = (arr: string[], setter: (arr: string[]) => void): void => {
    setter([...arr, '']);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add Journey Step</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="stageId">Journey Stage</Label>
            <Select value={stageId} onValueChange={setStageId}>
              <SelectTrigger id="stageId">
                <SelectValue placeholder="Select a stage" />
              </SelectTrigger>
              <SelectContent>
                {stages.map((stage: JourneyStage) => (
                  <SelectItem key={stage.id} value={stage.id}>
                    {stage.order}. {stage.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Touchpoints</Label>
            <div className="border rounded-md p-3 max-h-40 overflow-y-auto space-y-2">
              {touchpoints.map((touchpoint: Touchpoint) => (
                <div key={touchpoint.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={touchpoint.id}
                    checked={touchpointIds.includes(touchpoint.id)}
                    onCheckedChange={() => toggleTouchpoint(touchpoint.id)}
                  />
                  <label htmlFor={touchpoint.id} className="text-sm cursor-pointer">
                    {touchpoint.name} ({touchpoint.type})
                  </label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="entryCondition">Entry Condition</Label>
            <Input
              id="entryCondition"
              value={entryCondition}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEntryCondition(e.target.value)}
              required
              placeholder="When they arrive at this step"
            />
          </div>

          <div>
            <Label htmlFor="desiredOutcome">Desired Outcome</Label>
            <Input
              id="desiredOutcome"
              value={desiredOutcome}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setDesiredOutcome(e.target.value)}
              required
              placeholder="What we want them to feel/know/do"
            />
          </div>

          <div>
            <Label htmlFor="emotionalStateBefore">Emotional State Before</Label>
            <Input
              id="emotionalStateBefore"
              value={emotionalStateBefore}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEmotionalStateBefore(e.target.value)}
              required
              placeholder="Expected emotional state"
            />
          </div>

          <div>
            <Label htmlFor="emotionalStateAfter">Emotional State After</Label>
            <Input
              id="emotionalStateAfter"
              value={emotionalStateAfter}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEmotionalStateAfter(e.target.value)}
              required
              placeholder="Target emotional state"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Friction Points</Label>
              <Button type="button" size="sm" variant="outline" onClick={() => addArrayItem(frictionPoints, setFrictionPoints)}>
                <Plus className="w-4 h-4 mr-1" />
                Add
              </Button>
            </div>
            {frictionPoints.map((friction: string, index: number) => (
              <div key={index} className="flex gap-2 mb-2">
                <Input
                  value={friction}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    updateArrayItem(frictionPoints, setFrictionPoints, index, e.target.value)
                  }
                  placeholder="What could go wrong"
                />
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  onClick={() => removeArrayItem(frictionPoints, setFrictionPoints, index)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Boosters</Label>
              <Button type="button" size="sm" variant="outline" onClick={() => addArrayItem(boosters, setBoosters)}>
                <Plus className="w-4 h-4 mr-1" />
                Add
              </Button>
            </div>
            {boosters.map((booster: string, index: number) => (
              <div key={index} className="flex gap-2 mb-2">
                <Input
                  value={booster}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    updateArrayItem(boosters, setBoosters, index, e.target.value)
                  }
                  placeholder="What makes it delightful"
                />
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  onClick={() => removeArrayItem(boosters, setBoosters, index)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNotes(e.target.value)}
              rows={2}
              placeholder="Additional notes"
            />
          </div>

          <div className="flex gap-2">
            <Button type="submit" className="flex-1">
              Add Step
            </Button>
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
