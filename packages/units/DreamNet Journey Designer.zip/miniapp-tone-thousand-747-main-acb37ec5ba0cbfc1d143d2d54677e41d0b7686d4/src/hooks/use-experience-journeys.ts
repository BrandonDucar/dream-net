'use client';

import { useState, useEffect } from 'react';
import type { 
  ExperienceJourney, 
  CreateExperienceJourneyInput, 
  JourneyFilter 
} from '@/types/experience-map';
import { getExperienceJourneys, saveExperienceJourneys } from '@/lib/storage';
import { generateId, generateSEO, getCurrentTimestamp } from '@/lib/generators';

export function useExperienceJourneys() {
  const [journeys, setJourneys] = useState<ExperienceJourney[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    setJourneys(getExperienceJourneys());
    setLoading(false);
  }, []);

  const createJourney = (input: CreateExperienceJourneyInput): ExperienceJourney => {
    const now = getCurrentTimestamp();
    const seo = generateSEO(input.name, input.description, input.tags || []);
    
    const newJourney: ExperienceJourney = {
      id: generateId(),
      personaId: input.personaId,
      name: input.name,
      description: input.description,
      primaryGoal: input.primaryGoal,
      importanceLevel: input.importanceLevel,
      status: 'draft',
      tags: input.tags || [],
      notes: '',
      seo,
      createdAt: now,
      updatedAt: now,
    };

    const updated = [...journeys, newJourney];
    setJourneys(updated);
    saveExperienceJourneys(updated);
    return newJourney;
  };

  const updateJourney = (id: string, updates: Partial<ExperienceJourney>): ExperienceJourney | null => {
    const index = journeys.findIndex((j: ExperienceJourney) => j.id === id);
    if (index === -1) return null;

    const updated = [...journeys];
    updated[index] = {
      ...updated[index],
      ...updates,
      updatedAt: getCurrentTimestamp(),
    };

    setJourneys(updated);
    saveExperienceJourneys(updated);
    return updated[index];
  };

  const deleteJourney = (id: string): boolean => {
    const filtered = journeys.filter((j: ExperienceJourney) => j.id !== id);
    setJourneys(filtered);
    saveExperienceJourneys(filtered);
    return true;
  };

  const getJourneyById = (id: string): ExperienceJourney | undefined => {
    return journeys.find((j: ExperienceJourney) => j.id === id);
  };

  const filterJourneys = (filter: JourneyFilter): ExperienceJourney[] => {
    return journeys.filter((journey: ExperienceJourney) => {
      if (filter.personaId && journey.personaId !== filter.personaId) {
        return false;
      }
      if (filter.status && journey.status !== filter.status) {
        return false;
      }
      if (filter.importanceLevel && journey.importanceLevel !== filter.importanceLevel) {
        return false;
      }
      if (filter.tag && !journey.tags.includes(filter.tag)) {
        return false;
      }
      return true;
    });
  };

  return {
    journeys,
    loading,
    createJourney,
    updateJourney,
    deleteJourney,
    getJourneyById,
    filterJourneys,
  };
}
