'use client';

import { useState, useEffect } from 'react';
import type { ExperienceMetric, CreateExperienceMetricInput } from '@/types/experience-map';
import { getExperienceMetrics, saveExperienceMetrics } from '@/lib/storage';
import { generateId, getCurrentTimestamp } from '@/lib/generators';

export function useExperienceMetrics() {
  const [metrics, setMetrics] = useState<ExperienceMetric[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    setMetrics(getExperienceMetrics());
    setLoading(false);
  }, []);

  const createMetric = (input: CreateExperienceMetricInput): ExperienceMetric => {
    const now = getCurrentTimestamp();
    
    const newMetric: ExperienceMetric = {
      id: generateId(),
      name: input.name,
      description: input.description,
      metricType: input.metricType,
      suggestedCalculation: input.suggestedCalculation,
      relatedJourneyIds: input.relatedJourneyIds,
      tags: input.tags || [],
      notes: '',
      createdAt: now,
      updatedAt: now,
    };

    const updated = [...metrics, newMetric];
    setMetrics(updated);
    saveExperienceMetrics(updated);
    return newMetric;
  };

  const updateMetric = (id: string, updates: Partial<ExperienceMetric>): ExperienceMetric | null => {
    const index = metrics.findIndex((m: ExperienceMetric) => m.id === id);
    if (index === -1) return null;

    const updated = [...metrics];
    updated[index] = {
      ...updated[index],
      ...updates,
      updatedAt: getCurrentTimestamp(),
    };

    setMetrics(updated);
    saveExperienceMetrics(updated);
    return updated[index];
  };

  const deleteMetric = (id: string): boolean => {
    const filtered = metrics.filter((m: ExperienceMetric) => m.id !== id);
    setMetrics(filtered);
    saveExperienceMetrics(filtered);
    return true;
  };

  const getMetricById = (id: string): ExperienceMetric | undefined => {
    return metrics.find((m: ExperienceMetric) => m.id === id);
  };

  const getMetricsByJourneyId = (journeyId: string): ExperienceMetric[] => {
    return metrics.filter((m: ExperienceMetric) => 
      m.relatedJourneyIds.includes(journeyId)
    );
  };

  return {
    metrics,
    loading,
    createMetric,
    updateMetric,
    deleteMetric,
    getMetricById,
    getMetricsByJourneyId,
  };
}
