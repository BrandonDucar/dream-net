'use client';

import { useState, useEffect } from 'react';
import type { JourneyStage, CreateJourneyStageInput } from '@/types/experience-map';
import { getJourneyStages, saveJourneyStages } from '@/lib/storage';
import { generateId, getCurrentTimestamp } from '@/lib/generators';

export function useJourneyStages() {
  const [stages, setStages] = useState<JourneyStage[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const loaded = getJourneyStages();
    const sorted = loaded.sort((a: JourneyStage, b: JourneyStage) => a.order - b.order);
    setStages(sorted);
    setLoading(false);
  }, []);

  const createJourneyStage = (input: CreateJourneyStageInput): JourneyStage => {
    const now = getCurrentTimestamp();
    
    const newStage: JourneyStage = {
      id: generateId(),
      name: input.name,
      description: input.description,
      order: input.order,
      defaultEmotionalGoal: input.defaultEmotionalGoal,
      createdAt: now,
      updatedAt: now,
    };

    const updated = [...stages, newStage].sort((a: JourneyStage, b: JourneyStage) => a.order - b.order);
    setStages(updated);
    saveJourneyStages(updated);
    return newStage;
  };

  const updateJourneyStage = (id: string, updates: Partial<JourneyStage>): JourneyStage | null => {
    const index = stages.findIndex((s: JourneyStage) => s.id === id);
    if (index === -1) return null;

    const updated = [...stages];
    updated[index] = {
      ...updated[index],
      ...updates,
      updatedAt: getCurrentTimestamp(),
    };

    const sorted = updated.sort((a: JourneyStage, b: JourneyStage) => a.order - b.order);
    setStages(sorted);
    saveJourneyStages(sorted);
    return updated[index];
  };

  const deleteJourneyStage = (id: string): boolean => {
    const filtered = stages.filter((s: JourneyStage) => s.id !== id);
    setStages(filtered);
    saveJourneyStages(filtered);
    return true;
  };

  const getStageById = (id: string): JourneyStage | undefined => {
    return stages.find((s: JourneyStage) => s.id === id);
  };

  return {
    stages,
    loading,
    createJourneyStage,
    updateJourneyStage,
    deleteJourneyStage,
    getStageById,
  };
}
