'use client';

import { useState, useEffect } from 'react';
import type { JourneyStep, CreateJourneyStepInput } from '@/types/experience-map';
import { getJourneySteps, saveJourneySteps } from '@/lib/storage';
import { generateId, getCurrentTimestamp } from '@/lib/generators';

export function useJourneySteps() {
  const [steps, setSteps] = useState<JourneyStep[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    setSteps(getJourneySteps());
    setLoading(false);
  }, []);

  const createStep = (input: CreateJourneyStepInput): JourneyStep => {
    const now = getCurrentTimestamp();
    
    const newStep: JourneyStep = {
      id: generateId(),
      journeyId: input.journeyId,
      stageId: input.stageId,
      order: input.order,
      touchpointIds: input.touchpointIds,
      entryCondition: input.entryCondition,
      desiredOutcome: input.desiredOutcome,
      emotionalStateBefore: input.emotionalStateBefore,
      emotionalStateAfter: input.emotionalStateAfter,
      frictionPoints: input.frictionPoints,
      boosters: input.boosters,
      notes: input.notes || '',
      createdAt: now,
      updatedAt: now,
    };

    const updated = [...steps, newStep];
    setSteps(updated);
    saveJourneySteps(updated);
    return newStep;
  };

  const updateStep = (id: string, updates: Partial<JourneyStep>): JourneyStep | null => {
    const index = steps.findIndex((s: JourneyStep) => s.id === id);
    if (index === -1) return null;

    const updated = [...steps];
    updated[index] = {
      ...updated[index],
      ...updates,
      updatedAt: getCurrentTimestamp(),
    };

    setSteps(updated);
    saveJourneySteps(updated);
    return updated[index];
  };

  const deleteStep = (id: string): boolean => {
    const filtered = steps.filter((s: JourneyStep) => s.id !== id);
    setSteps(filtered);
    saveJourneySteps(filtered);
    return true;
  };

  const getStepById = (id: string): JourneyStep | undefined => {
    return steps.find((s: JourneyStep) => s.id === id);
  };

  const getStepsByJourneyId = (journeyId: string): JourneyStep[] => {
    return steps
      .filter((s: JourneyStep) => s.journeyId === journeyId)
      .sort((a: JourneyStep, b: JourneyStep) => a.order - b.order);
  };

  const reorderSteps = (journeyId: string, orderedStepIds: string[]): void => {
    const updated = steps.map((step: JourneyStep) => {
      if (step.journeyId !== journeyId) return step;
      
      const newOrder = orderedStepIds.indexOf(step.id);
      if (newOrder === -1) return step;
      
      return {
        ...step,
        order: newOrder,
        updatedAt: getCurrentTimestamp(),
      };
    });

    setSteps(updated);
    saveJourneySteps(updated);
  };

  return {
    steps,
    loading,
    createStep,
    updateStep,
    deleteStep,
    getStepById,
    getStepsByJourneyId,
    reorderSteps,
  };
}
