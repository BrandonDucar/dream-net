'use client';

import { useState, useEffect } from 'react';
import type { Persona, CreatePersonaInput, PersonaFilter } from '@/types/experience-map';
import { getPersonas, savePersonas } from '@/lib/storage';
import { generateId, generateSlug, generateSEO, getCurrentTimestamp } from '@/lib/generators';

export function usePersonas() {
  const [personas, setPersonas] = useState<Persona[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    setPersonas(getPersonas());
    setLoading(false);
  }, []);

  const createPersona = (input: CreatePersonaInput): Persona => {
    const now = getCurrentTimestamp();
    const seo = generateSEO(input.name, input.description, input.tags || []);
    
    const newPersona: Persona = {
      id: generateId(),
      name: input.name,
      slug: generateSlug(input.name),
      description: input.description,
      motivations: input.motivations,
      fears: input.fears,
      preferredChannels: input.preferredChannels,
      experienceLevel: input.experienceLevel,
      tags: input.tags || [],
      notes: '',
      seo,
      createdAt: now,
      updatedAt: now,
    };

    const updated = [...personas, newPersona];
    setPersonas(updated);
    savePersonas(updated);
    return newPersona;
  };

  const updatePersona = (id: string, updates: Partial<Persona>): Persona | null => {
    const index = personas.findIndex((p: Persona) => p.id === id);
    if (index === -1) return null;

    const updated = [...personas];
    updated[index] = {
      ...updated[index],
      ...updates,
      updatedAt: getCurrentTimestamp(),
    };

    setPersonas(updated);
    savePersonas(updated);
    return updated[index];
  };

  const deletePersona = (id: string): boolean => {
    const filtered = personas.filter((p: Persona) => p.id !== id);
    setPersonas(filtered);
    savePersonas(filtered);
    return true;
  };

  const getPersonaById = (id: string): Persona | undefined => {
    return personas.find((p: Persona) => p.id === id);
  };

  const filterPersonas = (filter: PersonaFilter): Persona[] => {
    return personas.filter((persona: Persona) => {
      if (filter.experienceLevel && persona.experienceLevel !== filter.experienceLevel) {
        return false;
      }
      if (filter.preferredChannel && !persona.preferredChannels.includes(filter.preferredChannel)) {
        return false;
      }
      if (filter.tag && !persona.tags.includes(filter.tag)) {
        return false;
      }
      if (filter.searchText) {
        const searchLower = filter.searchText.toLowerCase();
        return (
          persona.name.toLowerCase().includes(searchLower) ||
          persona.description.toLowerCase().includes(searchLower)
        );
      }
      return true;
    });
  };

  return {
    personas,
    loading,
    createPersona,
    updatePersona,
    deletePersona,
    getPersonaById,
    filterPersonas,
  };
}
