'use client';

import { useState, useEffect } from 'react';
import type { Touchpoint, CreateTouchpointInput } from '@/types/experience-map';
import { getTouchpoints, saveTouchpoints } from '@/lib/storage';
import { generateId, getCurrentTimestamp } from '@/lib/generators';

export function useTouchpoints() {
  const [touchpoints, setTouchpoints] = useState<Touchpoint[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    setTouchpoints(getTouchpoints());
    setLoading(false);
  }, []);

  const createTouchpoint = (input: CreateTouchpointInput): Touchpoint => {
    const now = getCurrentTimestamp();
    
    const newTouchpoint: Touchpoint = {
      id: generateId(),
      name: input.name,
      type: input.type,
      description: input.description,
      relatedApp: input.relatedApp || null,
      relatedObjectType: input.relatedObjectType || null,
      urlOrRef: input.urlOrRef || null,
      tags: input.tags || [],
      notes: '',
      createdAt: now,
      updatedAt: now,
    };

    const updated = [...touchpoints, newTouchpoint];
    setTouchpoints(updated);
    saveTouchpoints(updated);
    return newTouchpoint;
  };

  const updateTouchpoint = (id: string, updates: Partial<Touchpoint>): Touchpoint | null => {
    const index = touchpoints.findIndex((t: Touchpoint) => t.id === id);
    if (index === -1) return null;

    const updated = [...touchpoints];
    updated[index] = {
      ...updated[index],
      ...updates,
      updatedAt: getCurrentTimestamp(),
    };

    setTouchpoints(updated);
    saveTouchpoints(updated);
    return updated[index];
  };

  const deleteTouchpoint = (id: string): boolean => {
    const filtered = touchpoints.filter((t: Touchpoint) => t.id !== id);
    setTouchpoints(filtered);
    saveTouchpoints(filtered);
    return true;
  };

  const getTouchpointById = (id: string): Touchpoint | undefined => {
    return touchpoints.find((t: Touchpoint) => t.id === id);
  };

  const getTouchpointsByIds = (ids: string[]): Touchpoint[] => {
    return touchpoints.filter((t: Touchpoint) => ids.includes(t.id));
  };

  return {
    touchpoints,
    loading,
    createTouchpoint,
    updateTouchpoint,
    deleteTouchpoint,
    getTouchpointById,
    getTouchpointsByIds,
  };
}
