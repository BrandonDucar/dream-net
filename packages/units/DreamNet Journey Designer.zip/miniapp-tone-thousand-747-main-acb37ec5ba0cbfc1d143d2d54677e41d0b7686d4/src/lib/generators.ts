export function generateSlug(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

export function generateSEO(name: string, description: string, tags: string[]): {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
} {
  return {
    seoTitle: `${name} | DreamNet Experience`,
    seoDescription: description.slice(0, 160),
    seoKeywords: tags,
    seoHashtags: tags.map((tag: string) => `#${tag.replace(/\s+/g, '')}`),
    altText: `${name} - ${description.slice(0, 100)}`,
  };
}

export function generateId(): string {
  return `${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
}

export function getCurrentTimestamp(): string {
  return new Date().toISOString();
}
