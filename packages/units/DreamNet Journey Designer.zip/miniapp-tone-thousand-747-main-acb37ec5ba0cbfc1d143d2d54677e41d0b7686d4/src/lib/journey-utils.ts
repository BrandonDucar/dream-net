import type {
  Persona,
  ExperienceJourney,
  JourneyStep,
  JourneyStage,
  Touchpoint,
  ExperienceMetric,
  JourneyDetail,
} from '@/types/experience-map';

export function getJourneyDetail(
  journey: ExperienceJourney,
  persona: Persona | undefined,
  steps: JourneyStep[],
  allStages: JourneyStage[],
  allTouchpoints: Touchpoint[]
): JourneyDetail | null {
  if (!persona) return null;

  const journeySteps = steps
    .filter((s: JourneyStep) => s.journeyId === journey.id)
    .sort((a: JourneyStep, b: JourneyStep) => a.order - b.order);

  const stageIds = [...new Set(journeySteps.map((s: JourneyStep) => s.stageId))];
  const stages = allStages.filter((stage: JourneyStage) => stageIds.includes(stage.id));

  const touchpointIds = [...new Set(journeySteps.flatMap((s: JourneyStep) => s.touchpointIds))];
  const touchpoints = allTouchpoints.filter((t: Touchpoint) => touchpointIds.includes(t.id));

  return {
    journey,
    persona,
    steps: journeySteps,
    stages,
    touchpoints,
  };
}

export function generateJourneyMap(detail: JourneyDetail): string {
  const { journey, persona, steps, stages } = detail;

  let output = '';
  output += '═══════════════════════════════════════════════════════\n';
  output += '           DREAMNET EXPERIENCE JOURNEY MAP\n';
  output += '═══════════════════════════════════════════════════════\n\n';
  
  output += `Persona: ${persona.name}\n`;
  output += `Journey: ${journey.name}\n`;
  output += `Goal: ${journey.primaryGoal}\n`;
  output += `Status: ${journey.status.toUpperCase()}\n`;
  output += `Importance: ${journey.importanceLevel.toUpperCase()}\n\n`;
  
  output += `Description:\n${journey.description}\n\n`;
  output += '───────────────────────────────────────────────────────\n\n';

  const stagesUsed = [...new Set(steps.map((s: JourneyStep) => s.stageId))];
  const orderedStages = stages
    .filter((stage: JourneyStage) => stagesUsed.includes(stage.id))
    .sort((a: JourneyStage, b: JourneyStage) => a.order - b.order);

  orderedStages.forEach((stage: JourneyStage, stageIndex: number) => {
    output += `STAGE ${stageIndex + 1}: ${stage.name.toUpperCase()}\n`;
    output += `${stage.description}\n`;
    output += `Emotional Goal: ${stage.defaultEmotionalGoal}\n\n`;

    const stageSteps = steps.filter((s: JourneyStep) => s.stageId === stage.id);

    stageSteps.forEach((step: JourneyStep, stepIndex: number) => {
      output += `  Step ${stepIndex + 1}:\n`;
      output += `  Entry: ${step.entryCondition}\n`;
      output += `  Desired Outcome: ${step.desiredOutcome}\n\n`;
      
      output += `  Emotional Journey:\n`;
      output += `    Before: ${step.emotionalStateBefore}\n`;
      output += `    After: ${step.emotionalStateAfter}\n\n`;

      if (step.frictionPoints.length > 0) {
        output += `  Friction Points:\n`;
        step.frictionPoints.forEach((friction: string) => {
          output += `    ⚠ ${friction}\n`;
        });
        output += '\n';
      }

      if (step.boosters.length > 0) {
        output += `  Boosters:\n`;
        step.boosters.forEach((booster: string) => {
          output += `    ✨ ${booster}\n`;
        });
        output += '\n';
      }

      if (step.notes) {
        output += `  Notes: ${step.notes}\n\n`;
      }

      output += '  ─────────────────────────────────────────\n\n';
    });
  });

  return output;
}

export function generatePersonaBrief(
  persona: Persona,
  journeys: ExperienceJourney[]
): string {
  let output = '';
  output += '═══════════════════════════════════════════════════════\n';
  output += '              DREAMNET PERSONA BRIEF\n';
  output += '═══════════════════════════════════════════════════════\n\n';
  
  output += `PERSONA: ${persona.name}\n`;
  output += `Experience Level: ${persona.experienceLevel}\n`;
  output += `Tags: ${persona.tags.join(', ') || 'None'}\n\n`;
  
  output += `Description:\n${persona.description}\n\n`;
  
  output += `Motivations:\n`;
  persona.motivations.forEach((motivation: string) => {
    output += `  • ${motivation}\n`;
  });
  output += '\n';
  
  output += `Fears:\n`;
  persona.fears.forEach((fear: string) => {
    output += `  • ${fear}\n`;
  });
  output += '\n';
  
  output += `Preferred Channels:\n`;
  persona.preferredChannels.forEach((channel: string) => {
    output += `  • ${channel}\n`;
  });
  output += '\n';
  
  output += '───────────────────────────────────────────────────────\n\n';
  output += `EXPERIENCE JOURNEYS (${journeys.length}):\n\n`;
  
  if (journeys.length === 0) {
    output += 'No journeys defined yet.\n';
  } else {
    journeys.forEach((journey: ExperienceJourney, index: number) => {
      output += `${index + 1}. ${journey.name}\n`;
      output += `   Status: ${journey.status} | Importance: ${journey.importanceLevel}\n`;
      output += `   Goal: ${journey.primaryGoal}\n\n`;
    });
  }
  
  return output;
}

export function generateExperiencePlaybook(
  detail: JourneyDetail,
  metrics: ExperienceMetric[]
): string {
  const { journey, persona } = detail;
  
  let output = '';
  output += '═══════════════════════════════════════════════════════\n';
  output += '         DREAMNET EXPERIENCE PLAYBOOK\n';
  output += '═══════════════════════════════════════════════════════\n\n';
  
  output += generateJourneyMap(detail);
  
  output += '\n\n';
  output += '═══════════════════════════════════════════════════════\n';
  output += '                 KEY METRICS\n';
  output += '═══════════════════════════════════════════════════════\n\n';
  
  if (metrics.length === 0) {
    output += 'No metrics defined for this journey.\n\n';
  } else {
    metrics.forEach((metric: ExperienceMetric) => {
      output += `${metric.name} (${metric.metricType})\n`;
      output += `${metric.description}\n`;
      output += `Calculation: ${metric.suggestedCalculation}\n\n`;
    });
  }
  
  output += '═══════════════════════════════════════════════════════\n';
  output += '              RECOMMENDATIONS\n';
  output += '═══════════════════════════════════════════════════════\n\n';
  
  output += 'Content Style:\n';
  output += `  • Tailor content for ${persona.experienceLevel} experience level\n`;
  output += `  • Address key motivations: ${persona.motivations.slice(0, 2).join(', ')}\n`;
  output += `  • Avoid triggering fears: ${persona.fears.slice(0, 2).join(', ')}\n\n`;
  
  output += 'Agent Involvement:\n';
  output += '  • Deploy agents at high-friction points\n';
  output += '  • Use agents to reinforce positive emotional states\n';
  output += '  • Provide proactive guidance during transitions\n\n';
  
  output += 'Economic Hooks:\n';
  output += `  • Primary goal: ${journey.primaryGoal}\n`;
  output += '  • Align rewards with desired outcomes at each step\n';
  output += '  • Create micro-incentives for progress\n\n';
  
  output += 'What NOT to Do:\n';
  persona.fears.forEach((fear: string) => {
    output += `  ✗ ${fear}\n`;
  });
  output += '\n';
  
  return output;
}

export function exportExperienceAtlas(
  personas: Persona[],
  stages: JourneyStage[],
  touchpoints: Touchpoint[],
  journeys: ExperienceJourney[],
  steps: JourneyStep[],
  metrics: ExperienceMetric[]
): string {
  let output = '';
  output += '═══════════════════════════════════════════════════════\n';
  output += '         DREAMNET EXPERIENCE ATLAS v1.0\n';
  output += '═══════════════════════════════════════════════════════\n';
  output += `Generated: ${new Date().toLocaleString()}\n\n`;
  
  output += `Total Personas: ${personas.length}\n`;
  output += `Total Journey Stages: ${stages.length}\n`;
  output += `Total Touchpoints: ${touchpoints.length}\n`;
  output += `Total Experience Journeys: ${journeys.length}\n`;
  output += `Total Journey Steps: ${steps.length}\n`;
  output += `Total Experience Metrics: ${metrics.length}\n\n`;
  
  output += '═══════════════════════════════════════════════════════\n';
  output += '                    PERSONAS\n';
  output += '═══════════════════════════════════════════════════════\n\n';
  
  personas.forEach((persona: Persona) => {
    output += `${persona.name} (${persona.experienceLevel})\n`;
    output += `${persona.description}\n`;
    output += `Channels: ${persona.preferredChannels.join(', ')}\n`;
    output += `Tags: ${persona.tags.join(', ')}\n\n`;
  });
  
  output += '═══════════════════════════════════════════════════════\n';
  output += '                 JOURNEY STAGES\n';
  output += '═══════════════════════════════════════════════════════\n\n';
  
  stages
    .sort((a: JourneyStage, b: JourneyStage) => a.order - b.order)
    .forEach((stage: JourneyStage) => {
      output += `${stage.order}. ${stage.name}\n`;
      output += `   ${stage.description}\n`;
      output += `   Emotional Goal: ${stage.defaultEmotionalGoal}\n\n`;
    });
  
  output += '═══════════════════════════════════════════════════════\n';
  output += '                  TOUCHPOINTS\n';
  output += '═══════════════════════════════════════════════════════\n\n';
  
  touchpoints.forEach((touchpoint: Touchpoint) => {
    output += `${touchpoint.name} (${touchpoint.type})\n`;
    output += `${touchpoint.description}\n`;
    if (touchpoint.relatedApp) output += `Related App: ${touchpoint.relatedApp}\n`;
    output += `Tags: ${touchpoint.tags.join(', ')}\n\n`;
  });
  
  output += '═══════════════════════════════════════════════════════\n';
  output += '             EXPERIENCE JOURNEYS\n';
  output += '═══════════════════════════════════════════════════════\n\n';
  
  journeys.forEach((journey: ExperienceJourney) => {
    const persona = personas.find((p: Persona) => p.id === journey.personaId);
    output += `${journey.name}\n`;
    output += `Persona: ${persona?.name || 'Unknown'}\n`;
    output += `Status: ${journey.status} | Importance: ${journey.importanceLevel}\n`;
    output += `Goal: ${journey.primaryGoal}\n`;
    output += `${journey.description}\n\n`;
  });
  
  output += '═══════════════════════════════════════════════════════\n';
  output += '            EXPERIENCE METRICS\n';
  output += '═══════════════════════════════════════════════════════\n\n';
  
  metrics.forEach((metric: ExperienceMetric) => {
    output += `${metric.name} (${metric.metricType})\n`;
    output += `${metric.description}\n`;
    output += `Calculation: ${metric.suggestedCalculation}\n`;
    output += `Journeys: ${metric.relatedJourneyIds.length}\n\n`;
  });
  
  output += '═══════════════════════════════════════════════════════\n';
  output += '                  END OF ATLAS\n';
  output += '═══════════════════════════════════════════════════════\n';
  
  return output;
}
