import type {
  Persona,
  JourneyStage,
  Touchpoint,
  ExperienceJourney,
  JourneyStep,
  ExperienceMetric,
} from '@/types/experience-map';

const STORAGE_KEYS = {
  PERSONAS: 'dreamnet_personas',
  JOURNEY_STAGES: 'dreamnet_journey_stages',
  TOUCHPOINTS: 'dreamnet_touchpoints',
  JOURNEYS: 'dreamnet_journeys',
  JOURNEY_STEPS: 'dreamnet_journey_steps',
  METRICS: 'dreamnet_metrics',
} as const;

function safeGetStorage<T>(key: string, defaultValue: T[]): T[] {
  if (typeof window === 'undefined') return defaultValue;
  
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch (error) {
    console.error(`Error reading ${key} from localStorage:`, error);
    return defaultValue;
  }
}

function safeSetStorage<T>(key: string, value: T[]): void {
  if (typeof window === 'undefined') return;
  
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error(`Error writing ${key} to localStorage:`, error);
  }
}

// Personas
export function getPersonas(): Persona[] {
  return safeGetStorage<Persona>(STORAGE_KEYS.PERSONAS, []);
}

export function savePersonas(personas: Persona[]): void {
  safeSetStorage(STORAGE_KEYS.PERSONAS, personas);
}

// Journey Stages
export function getJourneyStages(): JourneyStage[] {
  return safeGetStorage<JourneyStage>(STORAGE_KEYS.JOURNEY_STAGES, []);
}

export function saveJourneyStages(stages: JourneyStage[]): void {
  safeSetStorage(STORAGE_KEYS.JOURNEY_STAGES, stages);
}

// Touchpoints
export function getTouchpoints(): Touchpoint[] {
  return safeGetStorage<Touchpoint>(STORAGE_KEYS.TOUCHPOINTS, []);
}

export function saveTouchpoints(touchpoints: Touchpoint[]): void {
  safeSetStorage(STORAGE_KEYS.TOUCHPOINTS, touchpoints);
}

// Experience Journeys
export function getExperienceJourneys(): ExperienceJourney[] {
  return safeGetStorage<ExperienceJourney>(STORAGE_KEYS.JOURNEYS, []);
}

export function saveExperienceJourneys(journeys: ExperienceJourney[]): void {
  safeSetStorage(STORAGE_KEYS.JOURNEYS, journeys);
}

// Journey Steps
export function getJourneySteps(): JourneyStep[] {
  return safeGetStorage<JourneyStep>(STORAGE_KEYS.JOURNEY_STEPS, []);
}

export function saveJourneySteps(steps: JourneyStep[]): void {
  safeSetStorage(STORAGE_KEYS.JOURNEY_STEPS, steps);
}

// Experience Metrics
export function getExperienceMetrics(): ExperienceMetric[] {
  return safeGetStorage<ExperienceMetric>(STORAGE_KEYS.METRICS, []);
}

export function saveExperienceMetrics(metrics: ExperienceMetric[]): void {
  safeSetStorage(STORAGE_KEYS.METRICS, metrics);
}

// Clear all data
export function clearAllData(): void {
  if (typeof window === 'undefined') return;
  
  Object.values(STORAGE_KEYS).forEach((key: string) => {
    localStorage.removeItem(key);
  });
}
