// Enhanced types for DreamNet Experience Map improvements

// Visual Journey Canvas
export interface CanvasNode {
  id: string;
  type: 'stage' | 'touchpoint' | 'decision' | 'emotion' | 'metric';
  x: number;
  y: number;
  width: number;
  height: number;
  data: any;
  color?: string;
}

export interface CanvasConnection {
  id: string;
  fromNodeId: string;
  toNodeId: string;
  label?: string;
  type: 'flow' | 'influence' | 'dependency';
  style?: 'solid' | 'dashed' | 'dotted';
}

export interface CanvasLayout {
  id: string;
  journeyId: string;
  name: string;
  nodes: CanvasNode[];
  connections: CanvasConnection[];
  zoom: number;
  centerX: number;
  centerY: number;
}

// Emotional Curve Visualization
export interface EmotionalDataPoint {
  stepId: string;
  stepOrder: number;
  stepName: string;
  emotionalScore: number; // -10 to +10
  confidence: number; // 0 to 1
  notes: string;
}

export interface EmotionalCurve {
  id: string;
  journeyId: string;
  dataPoints: EmotionalDataPoint[];
  targetCurve?: EmotionalDataPoint[]; // ideal emotional state
}

// Journey Templates
export interface JourneyTemplate {
  id: string;
  name: string;
  category: 'onboarding' | 'discovery' | 'conversion' | 'retention' | 'advocacy';
  description: string;
  targetPersonaType: string;
  defaultStages: string[]; // stage IDs or names
  defaultSteps: {
    stageName: string;
    stepName: string;
    touchpointTypes: string[];
    emotionalBefore: string;
    emotionalAfter: string;
    commonFrictions: string[];
    commonBoosters: string[];
  }[];
  estimatedCompletionTime: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  tags: string[];
}

// Friction Scoring
export interface FrictionScore {
  id: string;
  stepId: string;
  frictionType: 'technical' | 'cognitive' | 'emotional' | 'economic' | 'trust' | 'time';
  severity: 1 | 2 | 3 | 4 | 5; // 1 = minor, 5 = critical
  impactedUsers: number; // percentage or count
  description: string;
  estimatedDropOffRate: number; // percentage
  fixPriority: 'low' | 'medium' | 'high' | 'critical';
  fixEffort: 'easy' | 'medium' | 'hard' | 'unknown';
  fixIdeas: string[];
}

export interface FrictionAnalysis {
  id: string;
  journeyId: string;
  totalFrictionScore: number;
  scores: FrictionScore[];
  recommendations: string[];
  estimatedOverallDropOff: number;
}

// Journey Comparison
export interface JourneyComparison {
  id: string;
  name: string;
  journeyIds: string[];
  comparisonDimensions: {
    dimension: 'time' | 'steps' | 'friction' | 'emotion' | 'cost' | 'complexity';
    values: { journeyId: string; value: number }[];
  }[];
  winner?: string; // journeyId with best overall score
  notes: string;
}

// AI-Assisted Generation
export interface AIJourneyPrompt {
  personaDescription: string;
  primaryGoal: string;
  contextualInfo: string;
  preferredStageCount?: number;
  focusAreas?: string[]; // e.g., ["wallet onboarding", "first mint", "community join"]
}

export interface AIGeneratedJourney {
  suggestedName: string;
  suggestedDescription: string;
  suggestedSteps: {
    stageName: string;
    stepName: string;
    order: number;
    touchpointSuggestions: string[];
    entryCondition: string;
    desiredOutcome: string;
    emotionalBefore: string;
    emotionalAfter: string;
    frictionPoints: string[];
    boosters: string[];
    reasoning: string; // why this step matters
  }[];
  suggestedMetrics: {
    name: string;
    description: string;
    metricType: string;
  }[];
  confidenceScore: number; // 0 to 1
}

// Collaboration (for future implementation)
export interface JourneyComment {
  id: string;
  journeyId: string;
  stepId?: string;
  author: string;
  timestamp: Date;
  content: string;
  type: 'comment' | 'suggestion' | 'question' | 'approval';
  resolved: boolean;
}

export interface JourneyVersion {
  id: string;
  journeyId: string;
  versionNumber: number;
  timestamp: Date;
  author: string;
  changeDescription: string;
  snapshot: any; // full journey state
}

// Journey Health Score
export interface JourneyHealthMetrics {
  id: string;
  journeyId: string;
  overallScore: number; // 0 to 100
  dimensions: {
    clarity: number; // how clear/complete is the journey definition
    frictionLevel: number; // inverse of friction scores
    emotionalQuality: number; // how positive is the emotional curve
    completeness: number; // are all fields filled, touchpoints defined, etc.
    alignment: number; // how well does it match persona motivations/fears
  };
  recommendations: string[];
  lastUpdated: Date;
}

// Impact Calculator
export interface ImpactEstimate {
  id: string;
  frictionScoreId: string;
  estimatedTimeToFix: string; // e.g., "2 hours", "3 days", "2 weeks"
  estimatedCostToFix: number;
  estimatedUsersSaved: number;
  estimatedRevenueImpact: number;
  confidenceLevel: 'low' | 'medium' | 'high';
  dependencies: string[];
  notes: string;
}

// Web3-Specific Enhancements
export interface Web3JourneyContext {
  id: string;
  journeyId: string;
  walletRequirement: 'none' | 'optional' | 'required';
  chainRequirements: string[]; // e.g., ["base", "optimism"]
  gasRequirements: {
    stepId: string;
    estimatedGas: string;
    canSponsor: boolean;
  }[];
  tokenGates: {
    stepId: string;
    tokenAddress: string;
    minimumBalance: string;
  }[];
  onChainActions: {
    stepId: string;
    actionType: 'mint' | 'transfer' | 'swap' | 'stake' | 'vote' | 'claim';
    description: string;
  }[];
}
