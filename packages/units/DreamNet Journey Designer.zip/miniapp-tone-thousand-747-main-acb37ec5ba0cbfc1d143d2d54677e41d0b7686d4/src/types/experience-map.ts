export type ExperienceLevel = 'new-to-crypto' | 'intermediate' | 'advanced' | 'pro';

export type TouchpointType = 
  | 'social-post' 
  | 'frame' 
  | 'drop-page' 
  | 'mini-app' 
  | 'agent-interaction' 
  | 'email' 
  | 'irl-event' 
  | 'other';

export type ImportanceLevel = 'low' | 'medium' | 'high' | 'critical';

export type JourneyStatus = 'idea' | 'draft' | 'active' | 'retired';

export type MetricType = 'time' | 'count' | 'ratio' | 'score' | 'boolean' | 'other';

export interface SEOMetadata {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export interface Persona {
  id: string;
  name: string;
  slug: string;
  description: string;
  motivations: string[];
  fears: string[];
  preferredChannels: string[];
  experienceLevel: ExperienceLevel;
  tags: string[];
  notes: string;
  seo: SEOMetadata;
  createdAt: string;
  updatedAt: string;
}

export interface JourneyStage {
  id: string;
  name: string;
  description: string;
  order: number;
  defaultEmotionalGoal: string;
  createdAt: string;
  updatedAt: string;
}

export interface Touchpoint {
  id: string;
  name: string;
  type: TouchpointType;
  description: string;
  relatedApp: string | null;
  relatedObjectType: string | null;
  urlOrRef: string | null;
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface ExperienceJourney {
  id: string;
  personaId: string;
  name: string;
  description: string;
  primaryGoal: string;
  importanceLevel: ImportanceLevel;
  status: JourneyStatus;
  tags: string[];
  notes: string;
  seo: SEOMetadata;
  createdAt: string;
  updatedAt: string;
}

export interface JourneyStep {
  id: string;
  journeyId: string;
  stageId: string;
  order: number;
  touchpointIds: string[];
  entryCondition: string;
  desiredOutcome: string;
  emotionalStateBefore: string;
  emotionalStateAfter: string;
  frictionPoints: string[];
  boosters: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface ExperienceMetric {
  id: string;
  name: string;
  description: string;
  metricType: MetricType;
  suggestedCalculation: string;
  relatedJourneyIds: string[];
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreatePersonaInput {
  name: string;
  description: string;
  motivations: string[];
  fears: string[];
  preferredChannels: string[];
  experienceLevel: ExperienceLevel;
  tags?: string[];
}

export interface CreateJourneyStageInput {
  name: string;
  description: string;
  order: number;
  defaultEmotionalGoal: string;
}

export interface CreateTouchpointInput {
  name: string;
  type: TouchpointType;
  description: string;
  relatedApp?: string | null;
  relatedObjectType?: string | null;
  urlOrRef?: string | null;
  tags?: string[];
}

export interface CreateExperienceJourneyInput {
  personaId: string;
  name: string;
  description: string;
  primaryGoal: string;
  importanceLevel: ImportanceLevel;
  tags?: string[];
}

export interface CreateJourneyStepInput {
  journeyId: string;
  stageId: string;
  order: number;
  touchpointIds: string[];
  entryCondition: string;
  desiredOutcome: string;
  emotionalStateBefore: string;
  emotionalStateAfter: string;
  frictionPoints: string[];
  boosters: string[];
  notes?: string;
}

export interface CreateExperienceMetricInput {
  name: string;
  description: string;
  metricType: MetricType;
  suggestedCalculation: string;
  relatedJourneyIds: string[];
  tags?: string[];
}

export interface JourneyDetail {
  journey: ExperienceJourney;
  persona: Persona;
  steps: JourneyStep[];
  stages: JourneyStage[];
  touchpoints: Touchpoint[];
}

export interface PersonaFilter {
  experienceLevel?: ExperienceLevel;
  preferredChannel?: string;
  tag?: string;
  searchText?: string;
}

export interface JourneyFilter {
  personaId?: string;
  status?: JourneyStatus;
  importanceLevel?: ImportanceLevel;
  tag?: string;
}
