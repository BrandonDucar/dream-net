'use client'
import { useState, useEffect } from 'react';
import type { GovRule } from '@/types/governance';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RulesList } from '@/components/governance/rules-list';
import { RuleForm } from '@/components/governance/rule-form';
import { RuleDetail } from '@/components/governance/rule-detail';
import { AmendmentForm } from '@/components/governance/amendment-form';
import { AttachmentForm } from '@/components/governance/attachment-form';
import { EnforcementGroups } from '@/components/governance/enforcement-groups';
import { TagDefinitions } from '@/components/governance/tag-definitions';
import { AuditView } from '@/components/governance/audit-view';
import { ConstitutionView } from '@/components/governance/constitution-view';
import { MetricsDashboard } from '@/components/governance/metrics-dashboard';
import { RelationshipsManager } from '@/components/governance/relationships-manager';
import { ConflictDetector } from '@/components/governance/conflict-detector';
import { ImpactAnalyzer } from '@/components/governance/impact-analyzer';
import { TemplatesLibrary } from '@/components/governance/templates-library';
import { DiscussionThreads } from '@/components/governance/discussion-threads';
import { IncidentsLogger } from '@/components/governance/incidents-logger';
import { RuleChangelog } from '@/components/governance/rule-changelog';
import { GovernanceGraph } from '@/components/governance/governance-graph';
import { Toaster } from '@/components/ui/sonner';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type ViewMode = 'list' | 'create' | 'edit' | 'detail' | 'create-amendment' | 'attach-rule';

export default function GovernanceEnginePage(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [selectedRule, setSelectedRule] = useState<GovRule | null>(null);

  const handleSelectRule = (rule: GovRule): void => {
    setSelectedRule(rule);
    setViewMode('detail');
  };

  const handleCreateRule = (): void => {
    setSelectedRule(null);
    setViewMode('create');
  };

  const handleEditRule = (): void => {
    setViewMode('edit');
  };

  const handleBackToList = (): void => {
    setSelectedRule(null);
    setViewMode('list');
  };

  const handleRuleSuccess = (): void => {
    setViewMode('list');
    setSelectedRule(null);
  };

  const handleCreateAmendment = (): void => {
    setViewMode('create-amendment');
  };

  const handleAttachRule = (): void => {
    setViewMode('attach-rule');
  };

  const handleAmendmentSuccess = (): void => {
    setViewMode('detail');
  };

  const handleAttachmentSuccess = (): void => {
    setViewMode('detail');
  };

  return (
    <main className="min-h-screen bg-black text-white p-4 md:p-8 pt-16">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="text-center space-y-2 mb-8">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
            DreamNet Governance Engine
          </h1>
          <p className="text-gray-400 text-lg">
            Constitutional Framework & Rule Codex
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="mb-6 overflow-x-auto">
            <TabsList className="inline-flex w-auto min-w-full">
              <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
              <TabsTrigger value="rules">Rules</TabsTrigger>
              <TabsTrigger value="relationships">Relationships</TabsTrigger>
              <TabsTrigger value="conflicts">Conflicts</TabsTrigger>
              <TabsTrigger value="impact">Impact</TabsTrigger>
              <TabsTrigger value="templates">Templates</TabsTrigger>
              <TabsTrigger value="discussion">Discussion</TabsTrigger>
              <TabsTrigger value="incidents">Incidents</TabsTrigger>
              <TabsTrigger value="changelog">Changelog</TabsTrigger>
              <TabsTrigger value="graph">Graph</TabsTrigger>
              <TabsTrigger value="enforcement">Enforcement</TabsTrigger>
              <TabsTrigger value="tags">Tags</TabsTrigger>
              <TabsTrigger value="audit">Audit</TabsTrigger>
              <TabsTrigger value="constitution">Constitution</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="dashboard">
            <MetricsDashboard />
          </TabsContent>

          <TabsContent value="enforcement">
            <EnforcementGroups />
          </TabsContent>

          <TabsContent value="tags">
            <TagDefinitions />
          </TabsContent>

          <TabsContent value="audit">
            <AuditView />
          </TabsContent>

          <TabsContent value="constitution">
            <ConstitutionView />
          </TabsContent>

          <TabsContent value="rules">
            {viewMode === 'list' && (
              <RulesList 
                onSelectRule={handleSelectRule}
                onCreateRule={handleCreateRule}
              />
            )}
            
            {viewMode === 'create' && (
              <RuleForm 
                onSuccess={handleRuleSuccess}
                onCancel={handleBackToList}
              />
            )}
            
            {viewMode === 'edit' && selectedRule && (
              <RuleForm 
                rule={selectedRule}
                onSuccess={handleRuleSuccess}
                onCancel={() => setViewMode('detail')}
              />
            )}
            
            {viewMode === 'detail' && selectedRule && (
              <RuleDetail 
                rule={selectedRule}
                onEdit={handleEditRule}
                onBack={handleBackToList}
                onCreateAmendment={handleCreateAmendment}
                onAttachRule={handleAttachRule}
              />
            )}
            
            {viewMode === 'create-amendment' && selectedRule && (
              <AmendmentForm 
                rule={selectedRule}
                onSuccess={handleAmendmentSuccess}
                onCancel={() => setViewMode('detail')}
              />
            )}
            
            {viewMode === 'attach-rule' && selectedRule && (
              <AttachmentForm 
                rule={selectedRule}
                onSuccess={handleAttachmentSuccess}
                onCancel={() => setViewMode('detail')}
              />
            )}
          </TabsContent>

          <TabsContent value="relationships">
            <RelationshipsManager />
          </TabsContent>

          <TabsContent value="conflicts">
            <ConflictDetector />
          </TabsContent>

          <TabsContent value="impact">
            <ImpactAnalyzer />
          </TabsContent>

          <TabsContent value="templates">
            <TemplatesLibrary />
          </TabsContent>

          <TabsContent value="discussion">
            <DiscussionThreads />
          </TabsContent>

          <TabsContent value="incidents">
            <IncidentsLogger />
          </TabsContent>

          <TabsContent value="changelog">
            <RuleChangelog />
          </TabsContent>

          <TabsContent value="graph">
            <GovernanceGraph />
          </TabsContent>
        </Tabs>
      </div>

      <Toaster />
    </main>
  );
}
