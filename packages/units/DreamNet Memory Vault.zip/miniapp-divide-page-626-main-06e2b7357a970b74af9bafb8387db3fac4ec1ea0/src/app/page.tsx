'use client'
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { Dashboard } from '@/components/memory/dashboard';
import { EventLog } from '@/components/memory/event-log';
import { EventDetail } from '@/components/memory/event-detail';
import { EventForm } from '@/components/memory/event-form';
import { InsightsView } from '@/components/memory/insights-view';
import { SnapshotsView } from '@/components/memory/snapshots-view';
import { ThreadsView } from '@/components/memory/threads-view';
import { DailyLogsView } from '@/components/memory/daily-logs-view';
import { TimelineView } from '@/components/memory/timeline-view';
import { EnhancedDashboard } from '@/components/memory/enhanced-dashboard';
import { HabitTracker } from '@/components/memory/habit-tracker';
import { MoodTracker } from '@/components/memory/mood-tracker';
import { GoalTracker } from '@/components/memory/goal-tracker';
import { AnalyticsDashboard } from '@/components/memory/analytics-dashboard';
import { AdvancedExport } from '@/components/memory/advanced-export';
import { Settings } from '@/components/memory/settings';
import { Toaster } from '@/components/ui/sonner';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type Screen = 
  | 'dashboard'
  | 'events'
  | 'event-detail'
  | 'event-form'
  | 'insights'
  | 'snapshots'
  | 'threads'
  | 'daily-logs'
  | 'timeline'
  | 'habits'
  | 'mood'
  | 'goals'
  | 'analytics'
  | 'export'
  | 'settings';

export default function MemoryVaultPage() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [currentScreen, setCurrentScreen] = useState<Screen>('dashboard');
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [editEventId, setEditEventId] = useState<string | null>(null);
  const [highlightInsightId, setHighlightInsightId] = useState<string | undefined>(undefined);
  const [highlightThreadId, setHighlightThreadId] = useState<string | undefined>(undefined);
  const [highlightLogId, setHighlightLogId] = useState<string | undefined>(undefined);

  const handleNavigate = (screen: string, id?: string): void => {
    if (screen === 'event-detail' && id) {
      setSelectedEventId(id);
      setCurrentScreen('event-detail');
    } else if (screen === 'insights' && id) {
      setHighlightInsightId(id);
      setCurrentScreen('insights');
    } else if (screen === 'threads' && id) {
      setHighlightThreadId(id);
      setCurrentScreen('threads');
    } else if (screen === 'daily-logs' && id) {
      setHighlightLogId(id);
      setCurrentScreen('daily-logs');
    } else {
      setCurrentScreen(screen as Screen);
    }
  };

  const handleCreateEvent = (): void => {
    setEditEventId(null);
    setCurrentScreen('event-form');
  };

  const handleEditEvent = (eventId?: string): void => {
    setEditEventId(eventId || selectedEventId);
    setCurrentScreen('event-form');
  };

  const handleEventSaved = (): void => {
    setCurrentScreen('events');
    setEditEventId(null);
  };

  const handleEventClick = (eventId: string): void => {
    setSelectedEventId(eventId);
    setCurrentScreen('event-detail');
  };

  const handleBackToDashboard = (): void => {
    setCurrentScreen('dashboard');
    setSelectedEventId(null);
    setEditEventId(null);
    setHighlightInsightId(undefined);
    setHighlightThreadId(undefined);
    setHighlightLogId(undefined);
  };

  const handleBackToEvents = (): void => {
    setCurrentScreen('events');
    setSelectedEventId(null);
  };

  const renderBackButton = (): JSX.Element | null => {
    if (currentScreen === 'dashboard') return null;

    return (
      <Button 
        onClick={handleBackToDashboard} 
        variant="ghost" 
        className="mb-4"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Dashboard
      </Button>
    );
  };

  const renderScreen = (): JSX.Element => {
    switch (currentScreen) {
      case 'dashboard':
        return (
          <EnhancedDashboard
            onNavigate={handleNavigate}
            onCreateEvent={handleCreateEvent}
            onCreateInsight={() => setCurrentScreen('insights')}
            onCreateSnapshot={() => setCurrentScreen('snapshots')}
            onCreateDailyLog={() => setCurrentScreen('daily-logs')}
            onCreateThread={() => setCurrentScreen('threads')}
          />
        );

      case 'events':
        return <EventLog onEventClick={handleEventClick} />;

      case 'event-detail':
        return selectedEventId ? (
          <EventDetail
            eventId={selectedEventId}
            onBack={handleBackToEvents}
            onEdit={() => handleEditEvent(selectedEventId)}
          />
        ) : (
          <div className="text-center text-gray-500">No event selected</div>
        );

      case 'event-form':
        return (
          <EventForm
            eventId={editEventId || undefined}
            onSave={handleEventSaved}
            onCancel={() => setCurrentScreen(editEventId ? 'event-detail' : 'events')}
          />
        );

      case 'insights':
        return <InsightsView highlightInsightId={highlightInsightId} />;

      case 'snapshots':
        return <SnapshotsView />;

      case 'threads':
        return <ThreadsView highlightThreadId={highlightThreadId} />;

      case 'daily-logs':
        return <DailyLogsView highlightLogId={highlightLogId} />;

      case 'timeline':
        return <TimelineView />;

      case 'habits':
        return <HabitTracker />;

      case 'mood':
        return <MoodTracker />;

      case 'goals':
        return <GoalTracker />;

      case 'analytics':
        return <AnalyticsDashboard />;

      case 'export':
        return <AdvancedExport />;

      case 'settings':
        return <Settings />;

      default:
        return <div className="text-center text-gray-500">Screen not found</div>;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {renderBackButton()}
        {renderScreen()}
      </div>
      <Toaster />
    </div>
  );
}
