'use client'
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Download, FileJson, FileText, Table } from 'lucide-react';
import { memoryStore } from '@/lib/memory-store';
import { extendedStorage } from '@/lib/storage-extended';
import type { ExportFormat } from '@/types/memory-extended';
import { toast } from 'sonner';

export function AdvancedExport() {
  const [format, setFormat] = useState<ExportFormat>('json');
  const [includeEvents, setIncludeEvents] = useState(true);
  const [includeInsights, setIncludeInsights] = useState(true);
  const [includeThreads, setIncludeThreads] = useState(true);
  const [includeDailyLogs, setIncludeDailyLogs] = useState(true);
  const [includeSnapshots, setIncludeSnapshots] = useState(true);
  const [includeHabits, setIncludeHabits] = useState(false);
  const [includeMood, setIncludeMood] = useState(false);

  const handleExport = (): void => {
    try {
      let content = '';
      let filename = '';
      let mimeType = '';

      if (format === 'json') {
        const data: Record<string, unknown> = {
          version: 'DreamNet Memory Vault v2',
          exportDate: new Date().toISOString(),
        };

        if (includeEvents) data.events = memoryStore.getEvents();
        if (includeInsights) data.insights = memoryStore.getInsights();
        if (includeThreads) data.threads = memoryStore.getThreads();
        if (includeDailyLogs) data.dailyLogs = memoryStore.getDailyLogs();
        if (includeSnapshots) data.snapshots = memoryStore.getSnapshots();
        if (includeHabits) data.habits = extendedStorage.getHabits();
        if (includeMood) data.moodEntries = extendedStorage.getMoodEntries();

        content = JSON.stringify(data, null, 2);
        filename = `dreamnet-memory-${Date.now()}.json`;
        mimeType = 'application/json';
      } else if (format === 'csv') {
        // CSV export for events
        const events = includeEvents ? memoryStore.getEvents() : [];
        const headers = ['Timestamp', 'Type', 'Title', 'Description', 'Tags', 'Importance'];
        const rows = events.map((e) => [
          e.timestamp,
          e.eventType,
          e.title,
          e.description,
          e.tags.join(';'),
          e.importanceLevel,
        ]);

        content = [
          headers.join(','),
          ...rows.map((row) => row.map((cell) => `"${cell}"`).join(',')),
        ].join('\n');

        filename = `dreamnet-events-${Date.now()}.csv`;
        mimeType = 'text/csv';
      } else if (format === 'markdown') {
        // Markdown export
        let md = '# DreamNet Memory Vault Export\n\n';
        md += `**Export Date:** ${new Date().toISOString()}\n\n---\n\n`;

        if (includeEvents) {
          const events = memoryStore.getEvents();
          md += '## Events\n\n';
          events.forEach((e) => {
            md += `### ${e.title}\n\n`;
            md += `- **Type:** ${e.eventType}\n`;
            md += `- **Date:** ${new Date(e.timestamp).toLocaleString()}\n`;
            md += `- **Description:** ${e.description}\n`;
            if (e.tags.length > 0) md += `- **Tags:** ${e.tags.join(', ')}\n`;
            md += '\n---\n\n';
          });
        }

        if (includeInsights) {
          const insights = memoryStore.getInsights();
          md += '## Insights\n\n';
          insights.forEach((i) => {
            md += `### ${i.summary}\n\n`;
            md += `- **Context:** ${i.context}\n`;
            md += `- **Date:** ${new Date(i.timestamp).toLocaleString()}\n`;
            md += `- **Details:** ${i.details}\n`;
            if (i.recommendedActions.length > 0) {
              md += `- **Recommendations:**\n`;
              i.recommendedActions.forEach((action) => md += `  - ${action}\n`);
            }
            md += '\n---\n\n';
          });
        }

        if (includeDailyLogs) {
          const logs = memoryStore.getDailyLogs();
          md += '## Daily Logs\n\n';
          logs.forEach((log) => {
            md += `### ${log.date}\n\n`;
            md += `${log.summary}\n\n`;
            if (log.highlights.length > 0) {
              md += '**Highlights:**\n';
              log.highlights.forEach((h) => md += `- ${h}\n`);
              md += '\n';
            }
            md += '---\n\n';
          });
        }

        content = md;
        filename = `dreamnet-memory-${Date.now()}.md`;
        mimeType = 'text/markdown';
      }

      // Create download
      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.success(`Exported as ${format.toUpperCase()}!`);
    } catch (error) {
      console.error('Export failed:', error);
      toast.error('Export failed');
    }
  };

  const getFormatIcon = (fmt: ExportFormat): JSX.Element => {
    switch (fmt) {
      case 'json':
        return <FileJson className="h-4 w-4" />;
      case 'csv':
        return <Table className="h-4 w-4" />;
      case 'markdown':
        return <FileText className="h-4 w-4" />;
      default:
        return <Download className="h-4 w-4" />;
    }
  };

  const getItemCount = (): number => {
    let count = 0;
    if (includeEvents) count += memoryStore.getEvents().length;
    if (includeInsights) count += memoryStore.getInsights().length;
    if (includeThreads) count += memoryStore.getThreads().length;
    if (includeDailyLogs) count += memoryStore.getDailyLogs().length;
    if (includeSnapshots) count += memoryStore.getSnapshots().length;
    if (includeHabits) count += extendedStorage.getHabits().length;
    if (includeMood) count += extendedStorage.getMoodEntries().length;
    return count;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Download className="h-5 w-5 text-blue-500" />
          Advanced Export
        </CardTitle>
        <CardDescription>
          Export your memory vault in multiple formats
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <Label className="mb-3 block">Export Format</Label>
          <div className="grid grid-cols-3 gap-3">
            {(['json', 'csv', 'markdown'] as ExportFormat[]).map((fmt) => (
              <button
                key={fmt}
                onClick={() => setFormat(fmt)}
                className={`p-4 border rounded-lg flex flex-col items-center gap-2 transition-colors ${
                  format === fmt ? 'bg-blue-50 border-blue-500' : 'hover:bg-gray-50'
                }`}
              >
                {getFormatIcon(fmt)}
                <span className="text-sm font-medium uppercase">{fmt}</span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <Label className="mb-3 block">Include in Export</Label>
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Checkbox
                id="events"
                checked={includeEvents}
                onCheckedChange={(checked: boolean) => setIncludeEvents(checked)}
              />
              <Label htmlFor="events" className="cursor-pointer flex items-center gap-2">
                Events
                <Badge variant="secondary">{memoryStore.getEvents().length}</Badge>
              </Label>
            </div>

            <div className="flex items-center gap-2">
              <Checkbox
                id="insights"
                checked={includeInsights}
                onCheckedChange={(checked: boolean) => setIncludeInsights(checked)}
              />
              <Label htmlFor="insights" className="cursor-pointer flex items-center gap-2">
                Insights
                <Badge variant="secondary">{memoryStore.getInsights().length}</Badge>
              </Label>
            </div>

            <div className="flex items-center gap-2">
              <Checkbox
                id="threads"
                checked={includeThreads}
                onCheckedChange={(checked: boolean) => setIncludeThreads(checked)}
              />
              <Label htmlFor="threads" className="cursor-pointer flex items-center gap-2">
                Threads
                <Badge variant="secondary">{memoryStore.getThreads().length}</Badge>
              </Label>
            </div>

            <div className="flex items-center gap-2">
              <Checkbox
                id="dailyLogs"
                checked={includeDailyLogs}
                onCheckedChange={(checked: boolean) => setIncludeDailyLogs(checked)}
              />
              <Label htmlFor="dailyLogs" className="cursor-pointer flex items-center gap-2">
                Daily Logs
                <Badge variant="secondary">{memoryStore.getDailyLogs().length}</Badge>
              </Label>
            </div>

            <div className="flex items-center gap-2">
              <Checkbox
                id="snapshots"
                checked={includeSnapshots}
                onCheckedChange={(checked: boolean) => setIncludeSnapshots(checked)}
              />
              <Label htmlFor="snapshots" className="cursor-pointer flex items-center gap-2">
                State Snapshots
                <Badge variant="secondary">{memoryStore.getSnapshots().length}</Badge>
              </Label>
            </div>

            <div className="flex items-center gap-2">
              <Checkbox
                id="habits"
                checked={includeHabits}
                onCheckedChange={(checked: boolean) => setIncludeHabits(checked)}
              />
              <Label htmlFor="habits" className="cursor-pointer flex items-center gap-2">
                Habits
                <Badge variant="secondary">{extendedStorage.getHabits().length}</Badge>
              </Label>
            </div>

            <div className="flex items-center gap-2">
              <Checkbox
                id="mood"
                checked={includeMood}
                onCheckedChange={(checked: boolean) => setIncludeMood(checked)}
              />
              <Label htmlFor="mood" className="cursor-pointer flex items-center gap-2">
                Mood Entries
                <Badge variant="secondary">{extendedStorage.getMoodEntries().length}</Badge>
              </Label>
            </div>
          </div>
        </div>

        <div className="border-t pt-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm font-medium">Ready to export</p>
              <p className="text-xs text-gray-500">
                {getItemCount()} total items selected
              </p>
            </div>
            <Badge variant="default">{format.toUpperCase()}</Badge>
          </div>
          <Button onClick={handleExport} className="w-full">
            <Download className="h-4 w-4 mr-2" />
            Export Memory Vault
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
