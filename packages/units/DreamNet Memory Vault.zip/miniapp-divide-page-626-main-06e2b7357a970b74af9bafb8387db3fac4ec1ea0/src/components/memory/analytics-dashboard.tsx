'use client'
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  BarChart3, 
  TrendingUp, 
  Clock, 
  Tag, 
  Activity,
  Lightbulb
} from 'lucide-react';
import { memoryStore } from '@/lib/memory-store';
import { analyticsEngine } from '@/lib/analytics-engine';
import type { EventPattern, ActivityHeatmap, TagAnalytics } from '@/types/memory-extended';
import type { MemoryEvent, Insight } from '@/types/memory';

export function AnalyticsDashboard() {
  const [patterns, setPatterns] = useState<EventPattern[]>([]);
  const [heatmap, setHeatmap] = useState<ActivityHeatmap[]>([]);
  const [tagAnalytics, setTagAnalytics] = useState<TagAnalytics[]>([]);
  const [insights, setInsights] = useState<string[]>([]);
  const [recommendations, setRecommendations] = useState<string[]>([]);
  const [totalEvents, setTotalEvents] = useState(0);
  const [totalInsights, setTotalInsights] = useState(0);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = (): void => {
    const events = memoryStore.getEvents();
    const insightsData = memoryStore.getInsights();

    setTotalEvents(events.length);
    setTotalInsights(insightsData.length);

    // Event patterns
    const eventPatterns = analyticsEngine.analyzeEventPatterns(events);
    setPatterns(eventPatterns);

    // Activity heatmap (last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const recentEvents = events.filter(
      (e: MemoryEvent) => e.timestamp > thirtyDaysAgo.toISOString()
    );
    const recentInsights = insightsData.filter(
      (i: Insight) => i.timestamp > thirtyDaysAgo.toISOString()
    );
    const heatmapData = analyticsEngine.generateActivityHeatmap(recentEvents, recentInsights);
    setHeatmap(heatmapData);

    // Tag analytics
    const tagStats = analyticsEngine.analyzeTagUsage(events, insightsData);
    setTagAnalytics(tagStats.slice(0, 10)); // Top 10 tags

    // Productivity insights
    const productivityInsights = analyticsEngine.generateProductivityInsights(events);
    setInsights(productivityInsights);

    // Recommendations
    const recs = analyticsEngine.generateRecommendations(events, insightsData);
    setRecommendations(recs);
  };

  const getActivityColor = (activity: number): string => {
    if (activity === 0) return 'bg-gray-100';
    if (activity <= 2) return 'bg-green-200';
    if (activity <= 5) return 'bg-green-400';
    if (activity <= 10) return 'bg-green-600';
    return 'bg-green-800';
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-500">Total Events</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{totalEvents}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-500">Total Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{totalInsights}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-500">Event Types</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{patterns.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-500">Active Tags</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{tagAnalytics.length}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-blue-500" />
            Activity Heatmap (Last 30 Days)
          </CardTitle>
          <CardDescription>Green = more activity</CardDescription>
        </CardHeader>
        <CardContent>
          {heatmap.length === 0 ? (
            <p className="text-sm text-gray-500 text-center py-8">
              No activity data yet. Start logging events!
            </p>
          ) : (
            <div className="grid grid-cols-7 gap-2">
              {heatmap.slice(-28).map((day: ActivityHeatmap) => (
                <div
                  key={day.date}
                  className={`h-12 rounded flex flex-col items-center justify-center ${getActivityColor(day.totalActivity)}`}
                  title={`${day.date}: ${day.totalActivity} activities`}
                >
                  <div className="text-xs font-medium">
                    {new Date(day.date).getDate()}
                  </div>
                  <div className="text-xs text-gray-600">
                    {day.totalActivity}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-purple-500" />
              Event Patterns
            </CardTitle>
            <CardDescription>Distribution by event type</CardDescription>
          </CardHeader>
          <CardContent>
            {patterns.length === 0 ? (
              <p className="text-sm text-gray-500 text-center py-8">
                No patterns to analyze yet
              </p>
            ) : (
              <div className="space-y-3">
                {patterns.slice(0, 5).map((pattern: EventPattern) => (
                  <div key={pattern.eventType} className="space-y-1">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium">{pattern.eventType}</span>
                      <span className="text-gray-500">{pattern.count} events</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-purple-600 h-2 rounded-full"
                        style={{
                          width: `${(pattern.count / totalEvents) * 100}%`,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Tag className="h-5 w-5 text-orange-500" />
              Top Tags
            </CardTitle>
            <CardDescription>Most frequently used tags</CardDescription>
          </CardHeader>
          <CardContent>
            {tagAnalytics.length === 0 ? (
              <p className="text-sm text-gray-500 text-center py-8">
                No tags used yet
              </p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {tagAnalytics.slice(0, 10).map((tagStat: TagAnalytics) => (
                  <Badge
                    key={tagStat.tag}
                    variant={tagStat.trending ? 'default' : 'secondary'}
                    className="text-sm"
                  >
                    {tagStat.tag} ({tagStat.eventCount + tagStat.insightCount})
                  </Badge>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-green-500" />
            Productivity Insights
          </CardTitle>
          <CardDescription>Patterns in your activity</CardDescription>
        </CardHeader>
        <CardContent>
          {insights.length === 0 ? (
            <p className="text-sm text-gray-500 text-center py-8">
              Need more data to generate insights
            </p>
          ) : (
            <ul className="space-y-2">
              {insights.map((insight: string, index: number) => (
                <li key={index} className="flex items-start gap-2 text-sm">
                  <TrendingUp className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                  {insight}
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      {recommendations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lightbulb className="h-5 w-5 text-yellow-500" />
              Recommendations
            </CardTitle>
            <CardDescription>AI-powered suggestions</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {recommendations.map((rec: string, index: number) => (
                <li key={index} className="flex items-start gap-2 text-sm">
                  <span className="text-yellow-500">💡</span>
                  {rec}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
