'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Edit, Trash2, X, Calendar } from 'lucide-react';
import { memoryStore } from '@/lib/memory-store';
import type { DailyLog } from '@/types/memory';
import { toast } from 'sonner';

interface DailyLogsViewProps {
  highlightLogId?: string;
}

export function DailyLogsView({ highlightLogId }: DailyLogsViewProps) {
  const [logs, setLogs] = useState<DailyLog[]>([]);
  const [selectedLog, setSelectedLog] = useState<DailyLog | null>(null);
  const [showForm, setShowForm] = useState<boolean>(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<DailyLog>>({
    date: new Date().toISOString().split('T')[0],
    summary: '',
    highlights: [],
    tasksCompleted: [],
    tasksDeferred: [],
    insightsLogged: [],
    stateSnapshotId: null,
    notes: '',
  });
  const [highlightInput, setHighlightInput] = useState<string>('');
  const [taskCompletedInput, setTaskCompletedInput] = useState<string>('');
  const [taskDeferredInput, setTaskDeferredInput] = useState<string>('');
  const [insightInput, setInsightInput] = useState<string>('');

  useEffect(() => {
    loadLogs();
  }, []);

  useEffect(() => {
    if (highlightLogId) {
      const log = memoryStore.getDailyLog(highlightLogId);
      if (log) {
        setSelectedLog(log);
      }
    }
  }, [highlightLogId]);

  const loadLogs = (): void => {
    const allLogs = memoryStore.filterDailyLogs({});
    setLogs(allLogs);
  };

  const handleCreate = (): void => {
    const today = new Date().toISOString().split('T')[0];
    const existingLog = memoryStore.getDailyLogByDate(today);
    
    if (existingLog) {
      toast.info('A log already exists for today. Editing it instead.');
      handleEdit(existingLog);
      return;
    }

    setEditingId(null);
    setFormData({
      date: today,
      summary: '',
      highlights: [],
      tasksCompleted: [],
      tasksDeferred: [],
      insightsLogged: [],
      stateSnapshotId: null,
      notes: '',
    });
    setShowForm(true);
  };

  const handleEdit = (log: DailyLog): void => {
    setEditingId(log.id);
    setFormData(log);
    setShowForm(true);
  };

  const handleDelete = (id: string): void => {
    if (confirm('Are you sure you want to delete this daily log?')) {
      memoryStore.deleteDailyLog(id);
      loadLogs();
      if (selectedLog?.id === id) {
        setSelectedLog(null);
      }
      toast.success('Daily log deleted');
    }
  };

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();

    if (!formData.date || !formData.summary) {
      toast.error('Date and summary are required');
      return;
    }

    const log: DailyLog = {
      id: editingId || `daily-${Date.now()}`,
      date: formData.date,
      summary: formData.summary,
      highlights: formData.highlights || [],
      tasksCompleted: formData.tasksCompleted || [],
      tasksDeferred: formData.tasksDeferred || [],
      insightsLogged: formData.insightsLogged || [],
      stateSnapshotId: formData.stateSnapshotId || null,
      notes: formData.notes || '',
    };

    memoryStore.saveDailyLog(log);
    loadLogs();
    setShowForm(false);
    toast.success(editingId ? 'Daily log updated' : 'Daily log created');

    if (editingId && selectedLog?.id === editingId) {
      setSelectedLog(log);
    }
  };

  const handleAddHighlight = (): void => {
    if (highlightInput.trim() && !formData.highlights?.includes(highlightInput.trim())) {
      setFormData((prev) => ({
        ...prev,
        highlights: [...(prev.highlights || []), highlightInput.trim()],
      }));
      setHighlightInput('');
    }
  };

  const handleRemoveHighlight = (highlight: string): void => {
    setFormData((prev) => ({
      ...prev,
      highlights: (prev.highlights || []).filter((h) => h !== highlight),
    }));
  };

  const handleAddTaskCompleted = (): void => {
    if (taskCompletedInput.trim() && !formData.tasksCompleted?.includes(taskCompletedInput.trim())) {
      setFormData((prev) => ({
        ...prev,
        tasksCompleted: [...(prev.tasksCompleted || []), taskCompletedInput.trim()],
      }));
      setTaskCompletedInput('');
    }
  };

  const handleRemoveTaskCompleted = (task: string): void => {
    setFormData((prev) => ({
      ...prev,
      tasksCompleted: (prev.tasksCompleted || []).filter((t) => t !== task),
    }));
  };

  const handleAddTaskDeferred = (): void => {
    if (taskDeferredInput.trim() && !formData.tasksDeferred?.includes(taskDeferredInput.trim())) {
      setFormData((prev) => ({
        ...prev,
        tasksDeferred: [...(prev.tasksDeferred || []), taskDeferredInput.trim()],
      }));
      setTaskDeferredInput('');
    }
  };

  const handleRemoveTaskDeferred = (task: string): void => {
    setFormData((prev) => ({
      ...prev,
      tasksDeferred: (prev.tasksDeferred || []).filter((t) => t !== task),
    }));
  };

  const handleAddInsight = (): void => {
    if (insightInput.trim() && !formData.insightsLogged?.includes(insightInput.trim())) {
      setFormData((prev) => ({
        ...prev,
        insightsLogged: [...(prev.insightsLogged || []), insightInput.trim()],
      }));
      setInsightInput('');
    }
  };

  const handleRemoveInsight = (insight: string): void => {
    setFormData((prev) => ({
      ...prev,
      insightsLogged: (prev.insightsLogged || []).filter((i) => i !== insight),
    }));
  };

  const formatDate = (dateStr: string): string => {
    return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-black">Daily Logs</h2>
          <p className="text-gray-600">{logs.length} logs recorded</p>
        </div>
        <Button onClick={handleCreate}>
          <Plus className="mr-2 h-4 w-4" />
          Create Daily Log
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Logs List */}
        <div className="lg:col-span-1 space-y-2">
          {logs.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <p className="text-center text-gray-500">No daily logs yet. Create your first log to get started.</p>
              </CardContent>
            </Card>
          ) : (
            logs.map((log) => (
              <Card
                key={log.id}
                className={`cursor-pointer hover:shadow-md transition-shadow ${
                  selectedLog?.id === log.id ? 'ring-2 ring-blue-500' : ''
                }`}
                onClick={() => setSelectedLog(log)}
              >
                <CardContent className="pt-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="h-4 w-4 text-gray-600" />
                    <span className="font-semibold text-black">{log.date}</span>
                  </div>
                  <p className="text-sm text-gray-700 line-clamp-2">{log.summary}</p>
                  <div className="flex gap-2 mt-2">
                    <Badge variant="outline" className="text-xs">
                      {log.highlights.length} highlights
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {log.tasksCompleted.length} completed
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Log Detail */}
        <div className="lg:col-span-2">
          {selectedLog ? (
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-black">{formatDate(selectedLog.date)}</CardTitle>
                    <p className="text-sm text-gray-600 mt-1">{selectedLog.summary}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => handleEdit(selectedLog)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDelete(selectedLog.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {selectedLog.highlights.length > 0 && (
                  <div>
                    <h3 className="font-semibold text-black mb-2">Highlights</h3>
                    <ul className="list-disc list-inside space-y-1">
                      {selectedLog.highlights.map((highlight, index) => (
                        <li key={index} className="text-gray-700">
                          {highlight}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {selectedLog.tasksCompleted.length > 0 && (
                  <div>
                    <h3 className="font-semibold text-black mb-2">Tasks Completed</h3>
                    <ul className="list-disc list-inside space-y-1">
                      {selectedLog.tasksCompleted.map((task, index) => (
                        <li key={index} className="text-gray-700">
                          {task}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {selectedLog.tasksDeferred.length > 0 && (
                  <div>
                    <h3 className="font-semibold text-black mb-2">Tasks Deferred</h3>
                    <ul className="list-disc list-inside space-y-1">
                      {selectedLog.tasksDeferred.map((task, index) => (
                        <li key={index} className="text-gray-700">
                          {task}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {selectedLog.insightsLogged.length > 0 && (
                  <div>
                    <h3 className="font-semibold text-black mb-2">Insights Logged</h3>
                    <ul className="list-disc list-inside space-y-1">
                      {selectedLog.insightsLogged.map((insight, index) => (
                        <li key={index} className="text-gray-700">
                          {insight}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {selectedLog.stateSnapshotId && (
                  <div>
                    <h3 className="font-semibold text-black mb-2">State Snapshot</h3>
                    <Badge variant="secondary">{selectedLog.stateSnapshotId}</Badge>
                  </div>
                )}

                {selectedLog.notes && (
                  <div>
                    <h3 className="font-semibold text-black mb-2">Notes</h3>
                    <p className="text-gray-700 whitespace-pre-wrap">{selectedLog.notes}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="pt-6">
                <p className="text-center text-gray-500">Select a daily log to view details</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Create/Edit Form Dialog */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingId ? 'Edit Daily Log' : 'Create New Daily Log'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label htmlFor="date">Date *</Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="summary">Summary *</Label>
              <Textarea
                id="summary"
                value={formData.summary}
                onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
                placeholder="Brief summary of the day"
                rows={3}
                required
              />
            </div>

            <div className="space-y-2">
              <Label>Highlights</Label>
              <div className="flex gap-2">
                <Input
                  value={highlightInput}
                  onChange={(e) => setHighlightInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddHighlight())}
                  placeholder="Add highlight"
                />
                <Button type="button" onClick={handleAddHighlight} variant="outline">
                  Add
                </Button>
              </div>
              {formData.highlights && formData.highlights.length > 0 && (
                <div className="space-y-1">
                  {formData.highlights.map((highlight, index) => (
                    <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                      <span className="flex-1 text-sm text-black">{highlight}</span>
                      <X
                        className="h-4 w-4 cursor-pointer text-gray-500 hover:text-red-500"
                        onClick={() => handleRemoveHighlight(highlight)}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label>Tasks Completed</Label>
              <div className="flex gap-2">
                <Input
                  value={taskCompletedInput}
                  onChange={(e) => setTaskCompletedInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTaskCompleted())}
                  placeholder="Add completed task"
                />
                <Button type="button" onClick={handleAddTaskCompleted} variant="outline">
                  Add
                </Button>
              </div>
              {formData.tasksCompleted && formData.tasksCompleted.length > 0 && (
                <div className="space-y-1">
                  {formData.tasksCompleted.map((task, index) => (
                    <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                      <span className="flex-1 text-sm text-black">{task}</span>
                      <X
                        className="h-4 w-4 cursor-pointer text-gray-500 hover:text-red-500"
                        onClick={() => handleRemoveTaskCompleted(task)}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label>Tasks Deferred</Label>
              <div className="flex gap-2">
                <Input
                  value={taskDeferredInput}
                  onChange={(e) => setTaskDeferredInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTaskDeferred())}
                  placeholder="Add deferred task"
                />
                <Button type="button" onClick={handleAddTaskDeferred} variant="outline">
                  Add
                </Button>
              </div>
              {formData.tasksDeferred && formData.tasksDeferred.length > 0 && (
                <div className="space-y-1">
                  {formData.tasksDeferred.map((task, index) => (
                    <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                      <span className="flex-1 text-sm text-black">{task}</span>
                      <X
                        className="h-4 w-4 cursor-pointer text-gray-500 hover:text-red-500"
                        onClick={() => handleRemoveTaskDeferred(task)}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label>Insights Logged</Label>
              <div className="flex gap-2">
                <Input
                  value={insightInput}
                  onChange={(e) => setInsightInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddInsight())}
                  placeholder="Add insight"
                />
                <Button type="button" onClick={handleAddInsight} variant="outline">
                  Add
                </Button>
              </div>
              {formData.insightsLogged && formData.insightsLogged.length > 0 && (
                <div className="space-y-1">
                  {formData.insightsLogged.map((insight, index) => (
                    <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                      <span className="flex-1 text-sm text-black">{insight}</span>
                      <X
                        className="h-4 w-4 cursor-pointer text-gray-500 hover:text-red-500"
                        onClick={() => handleRemoveInsight(insight)}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="stateSnapshotId">State Snapshot ID (Optional)</Label>
              <Input
                id="stateSnapshotId"
                value={formData.stateSnapshotId || ''}
                onChange={(e) => setFormData({ ...formData, stateSnapshotId: e.target.value || null })}
                placeholder="Link to a state snapshot"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Additional notes"
                rows={3}
              />
            </div>

            <div className="flex gap-2 justify-end">
              <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                Cancel
              </Button>
              <Button type="submit">{editingId ? 'Update' : 'Create'}</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
