'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, Plus, Database, Calendar, Link2, Lightbulb, BookOpen, Download } from 'lucide-react';
import { memoryStore } from '@/lib/memory-store';
import type { SearchResult } from '@/types/memory';

interface DashboardProps {
  onNavigate: (screen: string, id?: string) => void;
  onCreateEvent: () => void;
  onCreateInsight: () => void;
  onCreateSnapshot: () => void;
  onCreateDailyLog: () => void;
  onCreateThread: () => void;
}

export function Dashboard({
  onNavigate,
  onCreateEvent,
  onCreateInsight,
  onCreateSnapshot,
  onCreateDailyLog,
  onCreateThread,
}: DashboardProps) {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [stats, setStats] = useState({
    eventsToday: 0,
    insightsThisWeek: 0,
    recentSnapshots: 0,
    totalThreads: 0,
  });

  useEffect(() => {
    updateStats();
  }, []);

  const updateStats = (): void => {
    const today = new Date().toISOString().split('T')[0];
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();

    const events = memoryStore.getEvents();
    const eventsToday = events.filter((e) => e.timestamp.startsWith(today)).length;

    const insights = memoryStore.getInsights();
    const insightsThisWeek = insights.filter((i) => i.timestamp >= weekAgo).length;

    const snapshots = memoryStore.getSnapshots();
    const recentSnapshots = snapshots.slice(0, 5).length;

    const threads = memoryStore.getThreads();
    const totalThreads = threads.length;

    setStats({
      eventsToday,
      insightsThisWeek,
      recentSnapshots,
      totalThreads,
    });
  };

  const handleSearch = (): void => {
    if (searchQuery.trim()) {
      const results = memoryStore.search(searchQuery);
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  };

  const handleExport = (): void => {
    const bundle = memoryStore.exportMemoryBundle();
    const blob = new Blob([bundle], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dreamnet-memory-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleResultClick = (result: SearchResult): void => {
    if (result.type === 'event') {
      onNavigate('event-detail', result.id);
    } else if (result.type === 'insight') {
      onNavigate('insights', result.id);
    } else if (result.type === 'thread') {
      onNavigate('threads', result.id);
    } else if (result.type === 'daily') {
      onNavigate('daily-logs', result.id);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold text-black">DreamNet Memory Vault</h1>
        <p className="text-gray-600">Central memory system for all DreamNet operations</p>
      </div>

      {/* Search Bar */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search events, insights, threads, daily logs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                className="pl-10"
              />
            </div>
            <Button onClick={handleSearch}>Search</Button>
          </div>

          {/* Search Results */}
          {searchResults.length > 0 && (
            <div className="mt-4 space-y-2">
              <p className="text-sm text-gray-600">{searchResults.length} results found</p>
              {searchResults.map((result) => (
                <div
                  key={`${result.type}-${result.id}`}
                  className="border rounded-lg p-3 hover:bg-gray-50 cursor-pointer"
                  onClick={() => handleResultClick(result)}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline">{result.type}</Badge>
                    <span className="font-medium text-black">{result.title}</span>
                  </div>
                  <p className="text-sm text-gray-600">{result.snippet}</p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate('events')}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-black">Events Today</CardTitle>
            <Calendar className="h-4 w-4 text-gray-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-black">{stats.eventsToday}</div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate('insights')}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-black">Insights This Week</CardTitle>
            <Lightbulb className="h-4 w-4 text-gray-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-black">{stats.insightsThisWeek}</div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate('snapshots')}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-black">Recent Snapshots</CardTitle>
            <Database className="h-4 w-4 text-gray-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-black">{stats.recentSnapshots}</div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate('threads')}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-black">Memory Threads</CardTitle>
            <Link2 className="h-4 w-4 text-gray-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-black">{stats.totalThreads}</div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-black">Quick Actions</CardTitle>
          <CardDescription>Create new records or export memory bundle</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            <Button onClick={onCreateEvent} variant="outline" className="justify-start">
              <Plus className="mr-2 h-4 w-4" />
              Record Event
            </Button>
            <Button onClick={onCreateInsight} variant="outline" className="justify-start">
              <Plus className="mr-2 h-4 w-4" />
              Record Insight
            </Button>
            <Button onClick={onCreateSnapshot} variant="outline" className="justify-start">
              <Plus className="mr-2 h-4 w-4" />
              Create Snapshot
            </Button>
            <Button onClick={onCreateDailyLog} variant="outline" className="justify-start">
              <Plus className="mr-2 h-4 w-4" />
              Create Daily Log
            </Button>
            <Button onClick={onCreateThread} variant="outline" className="justify-start">
              <Plus className="mr-2 h-4 w-4" />
              Create Thread
            </Button>
            <Button onClick={handleExport} variant="outline" className="justify-start">
              <Download className="mr-2 h-4 w-4" />
              Export Bundle
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Navigation Shortcuts */}
      <Card>
        <CardHeader>
          <CardTitle className="text-black">View All Records</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Button onClick={() => onNavigate('events')} variant="secondary">
              <BookOpen className="mr-2 h-4 w-4" />
              Event Log
            </Button>
            <Button onClick={() => onNavigate('snapshots')} variant="secondary">
              <Database className="mr-2 h-4 w-4" />
              State Snapshots
            </Button>
            <Button onClick={() => onNavigate('threads')} variant="secondary">
              <Link2 className="mr-2 h-4 w-4" />
              Memory Threads
            </Button>
            <Button onClick={() => onNavigate('timeline')} variant="secondary">
              <Calendar className="mr-2 h-4 w-4" />
              Timeline
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
