'use client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { QuickCapture } from './quick-capture';
import { OnThisDay } from './on-this-day';
import { NaturalLanguageInput } from './natural-language-input';

interface EnhancedDashboardProps {
  onNavigate: (screen: string, id?: string) => void;
  onCreateEvent: () => void;
  onCreateInsight: () => void;
  onCreateSnapshot: () => void;
  onCreateDailyLog: () => void;
  onCreateThread: () => void;
}

export function EnhancedDashboard({
  onNavigate,
  onCreateEvent,
  onCreateInsight,
  onCreateSnapshot,
  onCreateDailyLog,
  onCreateThread,
}: EnhancedDashboardProps) {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">DreamNet Memory Vault</h1>
        <p className="text-gray-600">
          Your central memory system — log, track, and analyze everything across DreamNet
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <QuickCapture />
        <NaturalLanguageInput />
      </div>

      <OnThisDay />

      <Card>
        <CardHeader>
          <CardTitle>🚀 Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            <button
              onClick={() => onNavigate('events')}
              className="p-4 border rounded-lg hover:bg-gray-50 transition-colors text-center"
            >
              <div className="text-2xl mb-2">📝</div>
              <div className="text-sm font-medium">Events</div>
            </button>

            <button
              onClick={() => onNavigate('insights')}
              className="p-4 border rounded-lg hover:bg-gray-50 transition-colors text-center"
            >
              <div className="text-2xl mb-2">💡</div>
              <div className="text-sm font-medium">Insights</div>
            </button>

            <button
              onClick={() => onNavigate('threads')}
              className="p-4 border rounded-lg hover:bg-gray-50 transition-colors text-center"
            >
              <div className="text-2xl mb-2">🧵</div>
              <div className="text-sm font-medium">Threads</div>
            </button>

            <button
              onClick={() => onNavigate('habits')}
              className="p-4 border rounded-lg hover:bg-gray-50 transition-colors text-center"
            >
              <div className="text-2xl mb-2">🎯</div>
              <div className="text-sm font-medium">Habits</div>
            </button>

            <button
              onClick={() => onNavigate('mood')}
              className="p-4 border rounded-lg hover:bg-gray-50 transition-colors text-center"
            >
              <div className="text-2xl mb-2">💜</div>
              <div className="text-sm font-medium">Mood</div>
            </button>

            <button
              onClick={() => onNavigate('goals')}
              className="p-4 border rounded-lg hover:bg-gray-50 transition-colors text-center"
            >
              <div className="text-2xl mb-2">🏆</div>
              <div className="text-sm font-medium">Goals</div>
            </button>

            <button
              onClick={() => onNavigate('analytics')}
              className="p-4 border rounded-lg hover:bg-gray-50 transition-colors text-center"
            >
              <div className="text-2xl mb-2">📊</div>
              <div className="text-sm font-medium">Analytics</div>
            </button>

            <button
              onClick={() => onNavigate('snapshots')}
              className="p-4 border rounded-lg hover:bg-gray-50 transition-colors text-center"
            >
              <div className="text-2xl mb-2">📸</div>
              <div className="text-sm font-medium">Snapshots</div>
            </button>

            <button
              onClick={() => onNavigate('daily-logs')}
              className="p-4 border rounded-lg hover:bg-gray-50 transition-colors text-center"
            >
              <div className="text-2xl mb-2">📅</div>
              <div className="text-sm font-medium">Daily Logs</div>
            </button>

            <button
              onClick={() => onNavigate('settings')}
              className="p-4 border rounded-lg hover:bg-gray-50 transition-colors text-center"
            >
              <div className="text-2xl mb-2">⚙️</div>
              <div className="text-sm font-medium">Settings</div>
            </button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium text-gray-500">🔥 Features</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="text-sm space-y-1">
              <li>✅ Quick Capture Buttons</li>
              <li>✅ Natural Language Input</li>
              <li>✅ Mood & Energy Tracking</li>
              <li>✅ Habit Streaks</li>
              <li>✅ Goal Milestones</li>
              <li>✅ On This Day Memories</li>
              <li>✅ Advanced Analytics</li>
              <li>✅ Multi-Format Export</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium text-gray-500">📈 Your Stats</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-sm space-y-1 text-gray-600">
              <p>Track events across all apps</p>
              <p>Build narrative threads</p>
              <p>Capture insights & learnings</p>
              <p>Log daily summaries</p>
              <p>Remember everything</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium text-gray-500">💡 Tips</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-sm space-y-1 text-gray-600">
              <p>🎯 Set up quick buttons</p>
              <p>📝 Use natural language</p>
              <p>🔗 Connect events to threads</p>
              <p>📊 Check analytics weekly</p>
              <p>💾 Export regularly</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
