'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Edit, Plus, Trash2 } from 'lucide-react';
import { memoryStore } from '@/lib/memory-store';
import type { MemoryEvent, MemoryThread } from '@/types/memory';
import { toast } from 'sonner';

interface EventDetailProps {
  eventId: string;
  onBack: () => void;
  onEdit: () => void;
}

export function EventDetail({ eventId, onBack, onEdit }: EventDetailProps) {
  const [event, setEvent] = useState<MemoryEvent | null>(null);
  const [threads, setThreads] = useState<MemoryThread[]>([]);
  const [allThreads, setAllThreads] = useState<MemoryThread[]>([]);
  const [selectedThreadId, setSelectedThreadId] = useState<string>('');
  const [showAddThread, setShowAddThread] = useState<boolean>(false);

  useEffect(() => {
    loadEvent();
  }, [eventId]);

  const loadEvent = (): void => {
    const loadedEvent = memoryStore.getEvent(eventId);
    setEvent(loadedEvent);

    if (loadedEvent) {
      const eventThreads = memoryStore.getThreadsForEvent(eventId);
      setThreads(eventThreads);
      setAllThreads(memoryStore.getThreads());
    }
  };

  const handleAddToThread = (): void => {
    if (selectedThreadId) {
      memoryStore.addEventToThread(selectedThreadId, eventId);
      loadEvent();
      setShowAddThread(false);
      setSelectedThreadId('');
      toast.success('Event added to thread');
    }
  };

  const handleRemoveFromThread = (threadId: string): void => {
    memoryStore.removeEventFromThread(threadId, eventId);
    loadEvent();
    toast.success('Event removed from thread');
  };

  const handleDelete = (): void => {
    if (confirm('Are you sure you want to delete this event?')) {
      memoryStore.deleteEvent(eventId);
      toast.success('Event deleted');
      onBack();
    }
  };

  if (!event) {
    return (
      <div className="space-y-4">
        <Button onClick={onBack} variant="ghost">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-gray-500">Event not found</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const formatTimestamp = (timestamp: string): string => {
    return new Date(timestamp).toLocaleString('en-US', {
      dateStyle: 'full',
      timeStyle: 'short',
    });
  };

  const availableThreads = allThreads.filter(
    (thread) => !threads.some((t) => t.id === thread.id)
  );

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <Button onClick={onBack} variant="ghost">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Event Log
        </Button>
        <div className="flex gap-2">
          <Button onClick={onEdit} variant="outline">
            <Edit className="mr-2 h-4 w-4" />
            Edit Event
          </Button>
          <Button onClick={handleDelete} variant="destructive">
            <Trash2 className="mr-2 h-4 w-4" />
            Delete
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-2xl text-black">{event.title}</CardTitle>
              <p className="text-sm text-gray-600 mt-1">{formatTimestamp(event.timestamp)}</p>
            </div>
            <Badge className={`
              ${event.importanceLevel === 'critical' ? 'bg-red-100 text-red-800' : ''}
              ${event.importanceLevel === 'high' ? 'bg-orange-100 text-orange-800' : ''}
              ${event.importanceLevel === 'medium' ? 'bg-blue-100 text-blue-800' : ''}
              ${event.importanceLevel === 'low' ? 'bg-gray-100 text-gray-800' : ''}
            `}>
              {event.importanceLevel}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold text-black mb-2">Event Type</h3>
            <Badge variant="outline">{event.eventType}</Badge>
          </div>

          <div>
            <h3 className="font-semibold text-black mb-2">Description</h3>
            <p className="text-gray-700">{event.description}</p>
          </div>

          {event.sourceApp && (
            <div>
              <h3 className="font-semibold text-black mb-2">Source App</h3>
              <Badge variant="secondary">{event.sourceApp}</Badge>
            </div>
          )}

          {event.relatedObjectType && (
            <div>
              <h3 className="font-semibold text-black mb-2">Related Object</h3>
              <p className="text-gray-700">
                <span className="font-medium">{event.relatedObjectType}</span>
                {event.relatedObjectId && ` (${event.relatedObjectId})`}
              </p>
            </div>
          )}

          {event.relatedAgentId && (
            <div>
              <h3 className="font-semibold text-black mb-2">Related Agent</h3>
              <Badge variant="secondary">{event.relatedAgentId}</Badge>
            </div>
          )}

          {event.tags.length > 0 && (
            <div>
              <h3 className="font-semibold text-black mb-2">Tags</h3>
              <div className="flex gap-2 flex-wrap">
                {event.tags.map((tag) => (
                  <Badge key={tag} variant="secondary">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {event.notes && (
            <div>
              <h3 className="font-semibold text-black mb-2">Notes</h3>
              <p className="text-gray-700 whitespace-pre-wrap">{event.notes}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Threads */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-black">Memory Threads</CardTitle>
            <Dialog open={showAddThread} onOpenChange={setShowAddThread}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="mr-2 h-4 w-4" />
                  Add to Thread
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Event to Thread</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <Select value={selectedThreadId} onValueChange={setSelectedThreadId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a thread" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableThreads.map((thread) => (
                        <SelectItem key={thread.id} value={thread.id}>
                          {thread.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button onClick={handleAddToThread} className="w-full">
                    Add to Thread
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {threads.length === 0 ? (
            <p className="text-gray-500 text-center py-4">
              This event is not part of any memory threads yet.
            </p>
          ) : (
            <div className="space-y-2">
              {threads.map((thread) => (
                <div
                  key={thread.id}
                  className="flex justify-between items-center p-3 border rounded-lg"
                >
                  <div>
                    <p className="font-medium text-black">{thread.name}</p>
                    <p className="text-sm text-gray-600">{thread.description}</p>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleRemoveFromThread(thread.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
