'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { X } from 'lucide-react';
import { memoryStore } from '@/lib/memory-store';
import type { MemoryEvent, EventType, ImportanceLevel } from '@/types/memory';
import { toast } from 'sonner';

interface EventFormProps {
  eventId?: string;
  onSave: () => void;
  onCancel: () => void;
}

export function EventForm({ eventId, onSave, onCancel }: EventFormProps) {
  const [formData, setFormData] = useState<Partial<MemoryEvent>>({
    eventType: 'note',
    title: '',
    description: '',
    sourceApp: null,
    relatedObjectType: null,
    relatedObjectId: null,
    relatedAgentId: null,
    tags: [],
    importanceLevel: 'medium',
    notes: '',
  });
  const [tagInput, setTagInput] = useState<string>('');

  useEffect(() => {
    if (eventId) {
      const event = memoryStore.getEvent(eventId);
      if (event) {
        setFormData(event);
      }
    }
  }, [eventId]);

  const handleChange = (field: keyof MemoryEvent, value: string | string[]): void => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleAddTag = (): void => {
    if (tagInput.trim() && !formData.tags?.includes(tagInput.trim())) {
      handleChange('tags', [...(formData.tags || []), tagInput.trim()]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tag: string): void => {
    handleChange('tags', (formData.tags || []).filter((t) => t !== tag));
  };

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();

    if (!formData.title || !formData.description) {
      toast.error('Title and description are required');
      return;
    }

    const event: MemoryEvent = {
      id: eventId || `event-${Date.now()}`,
      timestamp: eventId ? (formData.timestamp || new Date().toISOString()) : new Date().toISOString(),
      eventType: formData.eventType as EventType,
      title: formData.title,
      description: formData.description,
      sourceApp: formData.sourceApp || null,
      relatedObjectType: formData.relatedObjectType || null,
      relatedObjectId: formData.relatedObjectId || null,
      relatedAgentId: formData.relatedAgentId || null,
      tags: formData.tags || [],
      importanceLevel: formData.importanceLevel as ImportanceLevel,
      notes: formData.notes || '',
    };

    memoryStore.saveEvent(event);
    toast.success(eventId ? 'Event updated' : 'Event created');
    onSave();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-black">{eventId ? 'Edit Event' : 'Create New Event'}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="eventType">Event Type *</Label>
              <Select
                value={formData.eventType}
                onValueChange={(value) => handleChange('eventType', value)}
              >
                <SelectTrigger id="eventType">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="object-created">Object Created</SelectItem>
                  <SelectItem value="object-updated">Object Updated</SelectItem>
                  <SelectItem value="state-change">State Change</SelectItem>
                  <SelectItem value="flow-step-completed">Flow Step Completed</SelectItem>
                  <SelectItem value="scenario-run">Scenario Run</SelectItem>
                  <SelectItem value="agent-action">Agent Action</SelectItem>
                  <SelectItem value="decision">Decision</SelectItem>
                  <SelectItem value="insight">Insight</SelectItem>
                  <SelectItem value="note">Note</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="importanceLevel">Importance Level *</Label>
              <Select
                value={formData.importanceLevel}
                onValueChange={(value) => handleChange('importanceLevel', value)}
              >
                <SelectTrigger id="importanceLevel">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => handleChange('title', e.target.value)}
              placeholder="e.g., Created new Drop, Agent assigned"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleChange('description', e.target.value)}
              placeholder="Detailed description of what happened"
              rows={4}
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="sourceApp">Source App</Label>
              <Input
                id="sourceApp"
                value={formData.sourceApp || ''}
                onChange={(e) => handleChange('sourceApp', e.target.value)}
                placeholder="e.g., Drop Manager, Culture Tracker"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="relatedAgentId">Related Agent ID</Label>
              <Input
                id="relatedAgentId"
                value={formData.relatedAgentId || ''}
                onChange={(e) => handleChange('relatedAgentId', e.target.value)}
                placeholder="e.g., agent-123"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="relatedObjectType">Related Object Type</Label>
              <Input
                id="relatedObjectType"
                value={formData.relatedObjectType || ''}
                onChange={(e) => handleChange('relatedObjectType', e.target.value)}
                placeholder="e.g., drop, culture-coin"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="relatedObjectId">Related Object ID</Label>
              <Input
                id="relatedObjectId"
                value={formData.relatedObjectId || ''}
                onChange={(e) => handleChange('relatedObjectId', e.target.value)}
                placeholder="e.g., drop-456"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="tags">Tags</Label>
            <div className="flex gap-2">
              <Input
                id="tags"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                placeholder="Add tag and press Enter"
              />
              <Button type="button" onClick={handleAddTag} variant="outline">
                Add
              </Button>
            </div>
            {formData.tags && formData.tags.length > 0 && (
              <div className="flex gap-2 flex-wrap mt-2">
                {formData.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="cursor-pointer">
                    {tag}
                    <X
                      className="ml-1 h-3 w-3"
                      onClick={() => handleRemoveTag(tag)}
                    />
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Additional Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => handleChange('notes', e.target.value)}
              placeholder="Any additional context or notes"
              rows={3}
            />
          </div>

          <div className="flex gap-2 justify-end">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit">
              {eventId ? 'Update Event' : 'Create Event'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
