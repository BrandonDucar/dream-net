'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Filter, X } from 'lucide-react';
import { memoryStore } from '@/lib/memory-store';
import type { MemoryEvent, EventType, ImportanceLevel, EventFilter } from '@/types/memory';

interface EventLogProps {
  onEventClick: (eventId: string) => void;
}

export function EventLog({ onEventClick }: EventLogProps) {
  const [events, setEvents] = useState<MemoryEvent[]>([]);
  const [showFilters, setShowFilters] = useState<boolean>(false);
  const [filter, setFilter] = useState<EventFilter>({});
  const [sourceApps, setSourceApps] = useState<string[]>([]);
  const [tags, setTags] = useState<string[]>([]);

  useEffect(() => {
    loadEvents();
    setSourceApps(memoryStore.getAllSourceApps());
    setTags(memoryStore.getAllTags());
  }, []);

  const loadEvents = (): void => {
    const allEvents = memoryStore.filterEvents(filter);
    setEvents(allEvents);
  };

  const handleFilterChange = (key: keyof EventFilter, value: string): void => {
    setFilter((prev) => ({
      ...prev,
      [key]: value || undefined,
    }));
  };

  const applyFilters = (): void => {
    loadEvents();
  };

  const clearFilters = (): void => {
    setFilter({});
    const allEvents = memoryStore.filterEvents({});
    setEvents(allEvents);
  };

  const formatTimestamp = (timestamp: string): string => {
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getImportanceColor = (level: ImportanceLevel): string => {
    const colors: Record<ImportanceLevel, string> = {
      low: 'bg-gray-100 text-gray-800',
      medium: 'bg-blue-100 text-blue-800',
      high: 'bg-orange-100 text-orange-800',
      critical: 'bg-red-100 text-red-800',
    };
    return colors[level];
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-black">Event Log</h2>
          <p className="text-gray-600">{events.length} events found</p>
        </div>
        <Button onClick={() => setShowFilters(!showFilters)} variant="outline">
          <Filter className="mr-2 h-4 w-4" />
          {showFilters ? 'Hide Filters' : 'Show Filters'}
        </Button>
      </div>

      {/* Filters */}
      {showFilters && (
        <Card>
          <CardHeader>
            <CardTitle className="text-black">Filters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Event Type</Label>
                <Select
                  value={filter.eventType || ''}
                  onValueChange={(value) => handleFilterChange('eventType', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All types</SelectItem>
                    <SelectItem value="object-created">Object Created</SelectItem>
                    <SelectItem value="object-updated">Object Updated</SelectItem>
                    <SelectItem value="state-change">State Change</SelectItem>
                    <SelectItem value="flow-step-completed">Flow Step</SelectItem>
                    <SelectItem value="scenario-run">Scenario Run</SelectItem>
                    <SelectItem value="agent-action">Agent Action</SelectItem>
                    <SelectItem value="decision">Decision</SelectItem>
                    <SelectItem value="insight">Insight</SelectItem>
                    <SelectItem value="note">Note</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Source App</Label>
                <Select
                  value={filter.sourceApp || ''}
                  onValueChange={(value) => handleFilterChange('sourceApp', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All apps" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All apps</SelectItem>
                    {sourceApps.map((app) => (
                      <SelectItem key={app} value={app}>
                        {app}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Importance</Label>
                <Select
                  value={filter.importanceLevel || ''}
                  onValueChange={(value) => handleFilterChange('importanceLevel', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All levels" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All levels</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Tag</Label>
                <Select
                  value={filter.tag || ''}
                  onValueChange={(value) => handleFilterChange('tag', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All tags" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All tags</SelectItem>
                    {tags.map((tag) => (
                      <SelectItem key={tag} value={tag}>
                        {tag}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Date From</Label>
                <Input
                  type="date"
                  value={filter.dateFrom || ''}
                  onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>Date To</Label>
                <Input
                  type="date"
                  value={filter.dateTo || ''}
                  onChange={(e) => handleFilterChange('dateTo', e.target.value)}
                />
              </div>
            </div>

            <div className="flex gap-2 mt-4">
              <Button onClick={applyFilters}>Apply Filters</Button>
              <Button onClick={clearFilters} variant="outline">
                <X className="mr-2 h-4 w-4" />
                Clear All
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Event Table */}
      <Card>
        <CardContent className="pt-6">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-black">Timestamp</TableHead>
                <TableHead className="text-black">Title</TableHead>
                <TableHead className="text-black">Type</TableHead>
                <TableHead className="text-black">Source</TableHead>
                <TableHead className="text-black">Importance</TableHead>
                <TableHead className="text-black">Tags</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {events.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-gray-500 py-8">
                    No events found. Create your first event to get started.
                  </TableCell>
                </TableRow>
              ) : (
                events.map((event) => (
                  <TableRow
                    key={event.id}
                    className="cursor-pointer hover:bg-gray-50"
                    onClick={() => onEventClick(event.id)}
                  >
                    <TableCell className="text-black">{formatTimestamp(event.timestamp)}</TableCell>
                    <TableCell className="font-medium text-black">{event.title}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{event.eventType}</Badge>
                    </TableCell>
                    <TableCell className="text-black">{event.sourceApp || '-'}</TableCell>
                    <TableCell>
                      <Badge className={getImportanceColor(event.importanceLevel)}>
                        {event.importanceLevel}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1 flex-wrap">
                        {event.tags.slice(0, 2).map((tag) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {event.tags.length > 2 && (
                          <Badge variant="secondary" className="text-xs">
                            +{event.tags.length - 2}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
