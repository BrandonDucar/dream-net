'use client'
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { Target, Plus, CheckCircle2, Circle, X } from 'lucide-react';
import { extendedStorage } from '@/lib/storage-extended';
import type { Goal, GoalStatus, Milestone } from '@/types/memory-extended';
import { toast } from 'sonner';

export function GoalTracker() {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null);
  const [newGoal, setNewGoal] = useState<Partial<Goal>>({
    title: '',
    description: '',
    status: 'not-started',
    targetDate: '',
    tags: [],
    milestones: [],
    notes: '',
  });

  useEffect(() => {
    loadGoals();
  }, []);

  const loadGoals = (): void => {
    const allGoals = extendedStorage.getGoals();
    setGoals(allGoals);
  };

  const handleCreateGoal = (): void => {
    if (!newGoal.title) {
      toast.error('Please enter a goal title');
      return;
    }

    const goal: Goal = {
      id: `goal_${Date.now()}`,
      title: newGoal.title,
      description: newGoal.description || '',
      status: newGoal.status || 'not-started',
      targetDate: newGoal.targetDate || null,
      startDate: new Date().toISOString(),
      completedDate: null,
      tags: newGoal.tags || [],
      milestones: newGoal.milestones || [],
      relatedEventIds: [],
      notes: newGoal.notes || '',
    };

    extendedStorage.saveGoal(goal);
    toast.success('Goal created!');
    setShowCreateDialog(false);
    resetNewGoal();
    loadGoals();
  };

  const resetNewGoal = (): void => {
    setNewGoal({
      title: '',
      description: '',
      status: 'not-started',
      targetDate: '',
      tags: [],
      milestones: [],
      notes: '',
    });
  };

  const handleUpdateGoalStatus = (goalId: string, status: GoalStatus): void => {
    const goal = extendedStorage.getGoal(goalId);
    if (!goal) return;

    goal.status = status;
    if (status === 'completed') {
      goal.completedDate = new Date().toISOString();
    }

    extendedStorage.saveGoal(goal);
    toast.success(`Goal marked as ${status}`);
    loadGoals();
  };

  const handleToggleMilestone = (goalId: string, milestoneId: string): void => {
    const goal = extendedStorage.getGoal(goalId);
    if (!goal) return;

    const milestone = goal.milestones.find((m: Milestone) => m.id === milestoneId);
    if (!milestone) return;

    milestone.completed = !milestone.completed;
    milestone.completedDate = milestone.completed ? new Date().toISOString() : null;

    extendedStorage.saveGoal(goal);
    toast.success(milestone.completed ? 'Milestone completed!' : 'Milestone reopened');
    loadGoals();
  };

  const calculateProgress = (goal: Goal): number => {
    if (goal.milestones.length === 0) return 0;
    const completed = goal.milestones.filter((m: Milestone) => m.completed).length;
    return (completed / goal.milestones.length) * 100;
  };

  const getStatusColor = (status: GoalStatus): string => {
    switch (status) {
      case 'not-started':
        return 'bg-gray-200 text-gray-700';
      case 'in-progress':
        return 'bg-blue-200 text-blue-700';
      case 'completed':
        return 'bg-green-200 text-green-700';
      case 'abandoned':
        return 'bg-red-200 text-red-700';
      default:
        return 'bg-gray-200 text-gray-700';
    }
  };

  const addMilestone = (): void => {
    const milestoneTitle = prompt('Enter milestone title:');
    if (!milestoneTitle) return;

    const milestone: Milestone = {
      id: `milestone_${Date.now()}`,
      title: milestoneTitle,
      completed: false,
      completedDate: null,
      order: newGoal.milestones?.length || 0,
    };

    setNewGoal({
      ...newGoal,
      milestones: [...(newGoal.milestones || []), milestone],
    });
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-green-500" />
                Goal Tracker
              </CardTitle>
              <CardDescription>Track goals and milestones</CardDescription>
            </div>
            <Button onClick={() => setShowCreateDialog(true)}>
              <Plus className="h-4 w-4 mr-1" />
              New Goal
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {goals.length === 0 ? (
            <p className="text-sm text-gray-500 text-center py-8">
              No goals yet. Create one to start tracking!
            </p>
          ) : (
            <div className="space-y-4">
              {goals.map((goal: Goal) => {
                const progress = calculateProgress(goal);

                return (
                  <div
                    key={goal.id}
                    className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h4 className="font-medium mb-1">{goal.title}</h4>
                        {goal.description && (
                          <p className="text-sm text-gray-600 mb-2">{goal.description}</p>
                        )}
                        <div className="flex gap-2 items-center flex-wrap">
                          <Badge className={getStatusColor(goal.status)}>
                            {goal.status}
                          </Badge>
                          {goal.targetDate && (
                            <span className="text-xs text-gray-500">
                              Target: {new Date(goal.targetDate).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                      </div>
                      <select
                        className="text-sm border rounded px-2 py-1"
                        value={goal.status}
                        onChange={(e: React.ChangeEvent<HTMLSelectElement>) =>
                          handleUpdateGoalStatus(goal.id, e.target.value as GoalStatus)
                        }
                      >
                        <option value="not-started">Not Started</option>
                        <option value="in-progress">In Progress</option>
                        <option value="completed">Completed</option>
                        <option value="abandoned">Abandoned</option>
                      </select>
                    </div>

                    {goal.milestones.length > 0 && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm mb-2">
                          <span className="font-medium">Milestones</span>
                          <span className="text-gray-500">
                            {goal.milestones.filter((m: Milestone) => m.completed).length} /{' '}
                            {goal.milestones.length}
                          </span>
                        </div>
                        <Progress value={progress} className="mb-2" />
                        <div className="space-y-2">
                          {goal.milestones.map((milestone: Milestone) => (
                            <div
                              key={milestone.id}
                              className="flex items-center gap-2 text-sm"
                            >
                              <button
                                onClick={() =>
                                  handleToggleMilestone(goal.id, milestone.id)
                                }
                                className="flex-shrink-0"
                              >
                                {milestone.completed ? (
                                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                                ) : (
                                  <Circle className="h-4 w-4 text-gray-400" />
                                )}
                              </button>
                              <span
                                className={
                                  milestone.completed
                                    ? 'line-through text-gray-500'
                                    : ''
                                }
                              >
                                {milestone.title}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {goal.tags.length > 0 && (
                      <div className="flex gap-1 mt-3">
                        {goal.tags.map((tag: string) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Create New Goal</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Goal Title</Label>
              <Input
                value={newGoal.title}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setNewGoal({ ...newGoal, title: e.target.value })
                }
                placeholder="e.g., Launch DreamNet MVP"
              />
            </div>
            <div>
              <Label>Description</Label>
              <Textarea
                value={newGoal.description}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                  setNewGoal({ ...newGoal, description: e.target.value })
                }
                placeholder="Describe your goal"
                rows={3}
              />
            </div>
            <div>
              <Label>Target Date (optional)</Label>
              <Input
                type="date"
                value={newGoal.targetDate}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setNewGoal({ ...newGoal, targetDate: e.target.value })
                }
              />
            </div>
            <div>
              <Label>Tags (comma separated)</Label>
              <Input
                value={newGoal.tags?.join(', ')}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setNewGoal({
                    ...newGoal,
                    tags: e.target.value.split(',').map((t: string) => t.trim()).filter(Boolean),
                  })
                }
                placeholder="culture, ops, tech"
              />
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label>Milestones</Label>
                <Button size="sm" variant="outline" onClick={addMilestone}>
                  <Plus className="h-3 w-3 mr-1" />
                  Add
                </Button>
              </div>
              {newGoal.milestones && newGoal.milestones.length > 0 && (
                <div className="space-y-1">
                  {newGoal.milestones.map((milestone: Milestone, index: number) => (
                    <div key={milestone.id} className="flex items-center gap-2 text-sm">
                      <Circle className="h-3 w-3 text-gray-400" />
                      <span className="flex-1">{milestone.title}</span>
                      <button
                        onClick={() => {
                          setNewGoal({
                            ...newGoal,
                            milestones: newGoal.milestones?.filter(
                              (m: Milestone) => m.id !== milestone.id
                            ),
                          });
                        }}
                        className="text-red-500 hover:text-red-700"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <Button onClick={handleCreateGoal} className="w-full">
              Create Goal
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
