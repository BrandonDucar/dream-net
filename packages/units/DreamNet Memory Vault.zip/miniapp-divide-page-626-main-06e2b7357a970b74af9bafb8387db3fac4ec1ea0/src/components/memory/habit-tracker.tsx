'use client'
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { CheckCircle2, Circle, Plus, Flame, Target } from 'lucide-react';
import { extendedStorage } from '@/lib/storage-extended';
import { analyticsEngine } from '@/lib/analytics-engine';
import type { Habit, HabitLog, HabitStreak } from '@/types/memory-extended';
import { toast } from 'sonner';

export function HabitTracker() {
  const [habits, setHabits] = useState<Habit[]>([]);
  const [habitLogs, setHabitLogs] = useState<HabitLog[]>([]);
  const [streaks, setStreaks] = useState<Record<string, HabitStreak>>({});
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newHabit, setNewHabit] = useState<Partial<Habit>>({
    name: '',
    description: '',
    icon: '✅',
    color: '#3b82f6',
    frequency: 'daily',
    targetCount: 1,
    tags: [],
    notes: '',
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = (): void => {
    const allHabits = extendedStorage.getHabits();
    const allLogs = extendedStorage.getHabitLogs();
    setHabits(allHabits.filter((h: Habit) => !h.archived));
    setHabitLogs(allLogs);

    // Calculate streaks
    const newStreaks: Record<string, HabitStreak> = {};
    allHabits.forEach((habit: Habit) => {
      const habitLogsForThis = allLogs.filter((log: HabitLog) => log.habitId === habit.id);
      const dates = habitLogsForThis.map((log: HabitLog) => 
        new Date(log.timestamp).toISOString().split('T')[0]
      );
      const uniqueDates = Array.from(new Set(dates));
      const streakData = analyticsEngine.calculateStreak(uniqueDates);
      
      newStreaks[habit.id] = {
        habitId: habit.id,
        currentStreak: streakData.current,
        longestStreak: streakData.longest,
        lastLogDate: uniqueDates[uniqueDates.length - 1] || '',
      };
    });
    setStreaks(newStreaks);
  };

  const handleCreateHabit = (): void => {
    if (!newHabit.name) {
      toast.error('Please enter a habit name');
      return;
    }

    const habit: Habit = {
      id: `habit_${Date.now()}`,
      name: newHabit.name,
      description: newHabit.description || '',
      icon: newHabit.icon || '✅',
      color: newHabit.color || '#3b82f6',
      frequency: newHabit.frequency || 'daily',
      targetCount: newHabit.targetCount || 1,
      createdDate: new Date().toISOString(),
      archived: false,
      tags: newHabit.tags || [],
      notes: newHabit.notes || '',
    };

    extendedStorage.saveHabit(habit);
    toast.success('Habit created!');
    setShowCreateDialog(false);
    setNewHabit({
      name: '',
      description: '',
      icon: '✅',
      color: '#3b82f6',
      frequency: 'daily',
      targetCount: 1,
      tags: [],
      notes: '',
    });
    loadData();
  };

  const handleLogHabit = (habitId: string): void => {
    const today = new Date().toISOString().split('T')[0];
    const existingLog = habitLogs.find(
      (log: HabitLog) => 
        log.habitId === habitId && 
        new Date(log.timestamp).toISOString().split('T')[0] === today
    );

    if (existingLog) {
      toast.info('Already logged today!');
      return;
    }

    const log: HabitLog = {
      id: `log_${Date.now()}`,
      habitId,
      timestamp: new Date().toISOString(),
      value: 1,
      notes: '',
    };

    extendedStorage.saveHabitLog(log);
    toast.success('Habit logged! 🎉');
    loadData();
  };

  const isLoggedToday = (habitId: string): boolean => {
    const today = new Date().toISOString().split('T')[0];
    return habitLogs.some(
      (log: HabitLog) => 
        log.habitId === habitId && 
        new Date(log.timestamp).toISOString().split('T')[0] === today
    );
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-blue-500" />
                Habit Tracker
              </CardTitle>
              <CardDescription>Build streaks and track progress</CardDescription>
            </div>
            <Button onClick={() => setShowCreateDialog(true)}>
              <Plus className="h-4 w-4 mr-1" />
              New Habit
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {habits.length === 0 ? (
            <p className="text-sm text-gray-500 text-center py-8">
              No habits yet. Create one to start tracking!
            </p>
          ) : (
            <div className="space-y-3">
              {habits.map((habit: Habit) => {
                const streak = streaks[habit.id];
                const loggedToday = isLoggedToday(habit.id);
                
                return (
                  <div
                    key={habit.id}
                    className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{habit.icon}</span>
                        <div>
                          <h4 className="font-medium">{habit.name}</h4>
                          {habit.description && (
                            <p className="text-sm text-gray-500">{habit.description}</p>
                          )}
                        </div>
                      </div>
                      <Button
                        onClick={() => handleLogHabit(habit.id)}
                        variant={loggedToday ? 'secondary' : 'default'}
                        size="sm"
                        disabled={loggedToday}
                      >
                        {loggedToday ? (
                          <>
                            <CheckCircle2 className="h-4 w-4 mr-1" />
                            Done
                          </>
                        ) : (
                          <>
                            <Circle className="h-4 w-4 mr-1" />
                            Log
                          </>
                        )}
                      </Button>
                    </div>

                    {streak && (
                      <div className="flex gap-4 text-sm">
                        <div className="flex items-center gap-1">
                          <Flame className="h-4 w-4 text-orange-500" />
                          <span className="font-medium">{streak.currentStreak}</span>
                          <span className="text-gray-500">day streak</span>
                        </div>
                        <div className="text-gray-500">
                          Best: {streak.longestStreak} days
                        </div>
                      </div>
                    )}

                    {habit.tags.length > 0 && (
                      <div className="flex gap-1 mt-2">
                        {habit.tags.map((tag: string) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Habit</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Habit Name</Label>
              <Input
                value={newHabit.name}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setNewHabit({ ...newHabit, name: e.target.value })
                }
                placeholder="e.g., Morning meditation"
              />
            </div>
            <div>
              <Label>Icon (emoji)</Label>
              <Input
                value={newHabit.icon}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setNewHabit({ ...newHabit, icon: e.target.value })
                }
                placeholder="✅"
              />
            </div>
            <div>
              <Label>Description (optional)</Label>
              <Input
                value={newHabit.description}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setNewHabit({ ...newHabit, description: e.target.value })
                }
                placeholder="10 minutes of meditation"
              />
            </div>
            <div>
              <Label>Frequency</Label>
              <select
                className="w-full border rounded px-3 py-2"
                value={newHabit.frequency}
                onChange={(e: React.ChangeEvent<HTMLSelectElement>) =>
                  setNewHabit({ ...newHabit, frequency: e.target.value as 'daily' | 'weekly' | 'custom' })
                }
              >
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="custom">Custom</option>
              </select>
            </div>
            <div>
              <Label>Tags (comma separated)</Label>
              <Input
                value={newHabit.tags?.join(', ')}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setNewHabit({
                    ...newHabit,
                    tags: e.target.value.split(',').map((t: string) => t.trim()).filter(Boolean),
                  })
                }
                placeholder="health, morning, wellness"
              />
            </div>
            <Button onClick={handleCreateHabit} className="w-full">
              Create Habit
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
