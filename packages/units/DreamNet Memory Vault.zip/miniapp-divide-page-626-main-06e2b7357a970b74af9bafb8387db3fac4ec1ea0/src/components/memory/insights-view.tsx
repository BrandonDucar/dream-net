'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Edit, Trash2, X } from 'lucide-react';
import { memoryStore } from '@/lib/memory-store';
import type { Insight, ImpactLevel } from '@/types/memory';
import { toast } from 'sonner';

interface InsightsViewProps {
  highlightInsightId?: string;
}

export function InsightsView({ highlightInsightId }: InsightsViewProps) {
  const [insights, setInsights] = useState<Insight[]>([]);
  const [selectedInsight, setSelectedInsight] = useState<Insight | null>(null);
  const [showForm, setShowForm] = useState<boolean>(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<Insight>>({
    summary: '',
    context: '',
    details: '',
    relatedObjects: [],
    impactLevel: 'medium',
    recommendedActions: [],
    notes: '',
  });
  const [actionInput, setActionInput] = useState<string>('');
  const [objectInput, setObjectInput] = useState<string>('');

  useEffect(() => {
    loadInsights();
  }, []);

  useEffect(() => {
    if (highlightInsightId) {
      const insight = memoryStore.getInsight(highlightInsightId);
      if (insight) {
        setSelectedInsight(insight);
      }
    }
  }, [highlightInsightId]);

  const loadInsights = (): void => {
    const allInsights = memoryStore.filterInsights({});
    setInsights(allInsights);
  };

  const handleCreate = (): void => {
    setEditingId(null);
    setFormData({
      summary: '',
      context: '',
      details: '',
      relatedObjects: [],
      impactLevel: 'medium',
      recommendedActions: [],
      notes: '',
    });
    setShowForm(true);
  };

  const handleEdit = (insight: Insight): void => {
    setEditingId(insight.id);
    setFormData(insight);
    setShowForm(true);
  };

  const handleDelete = (id: string): void => {
    if (confirm('Are you sure you want to delete this insight?')) {
      memoryStore.deleteInsight(id);
      loadInsights();
      if (selectedInsight?.id === id) {
        setSelectedInsight(null);
      }
      toast.success('Insight deleted');
    }
  };

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();

    if (!formData.summary || !formData.context || !formData.details) {
      toast.error('Summary, context, and details are required');
      return;
    }

    const insight: Insight = {
      id: editingId || `insight-${Date.now()}`,
      timestamp: editingId ? (formData.timestamp || new Date().toISOString()) : new Date().toISOString(),
      summary: formData.summary,
      context: formData.context,
      details: formData.details,
      relatedObjects: formData.relatedObjects || [],
      impactLevel: formData.impactLevel as ImpactLevel,
      recommendedActions: formData.recommendedActions || [],
      notes: formData.notes || '',
    };

    memoryStore.saveInsight(insight);
    loadInsights();
    setShowForm(false);
    toast.success(editingId ? 'Insight updated' : 'Insight created');
  };

  const handleAddAction = (): void => {
    if (actionInput.trim() && !formData.recommendedActions?.includes(actionInput.trim())) {
      setFormData((prev) => ({
        ...prev,
        recommendedActions: [...(prev.recommendedActions || []), actionInput.trim()],
      }));
      setActionInput('');
    }
  };

  const handleRemoveAction = (action: string): void => {
    setFormData((prev) => ({
      ...prev,
      recommendedActions: (prev.recommendedActions || []).filter((a) => a !== action),
    }));
  };

  const handleAddObject = (): void => {
    if (objectInput.trim() && !formData.relatedObjects?.includes(objectInput.trim())) {
      setFormData((prev) => ({
        ...prev,
        relatedObjects: [...(prev.relatedObjects || []), objectInput.trim()],
      }));
      setObjectInput('');
    }
  };

  const handleRemoveObject = (obj: string): void => {
    setFormData((prev) => ({
      ...prev,
      relatedObjects: (prev.relatedObjects || []).filter((o) => o !== obj),
    }));
  };

  const formatTimestamp = (timestamp: string): string => {
    return new Date(timestamp).toLocaleString('en-US', {
      dateStyle: 'medium',
      timeStyle: 'short',
    });
  };

  const getImpactColor = (level: ImpactLevel): string => {
    const colors: Record<ImpactLevel, string> = {
      low: 'bg-gray-100 text-gray-800',
      medium: 'bg-blue-100 text-blue-800',
      high: 'bg-orange-100 text-orange-800',
      critical: 'bg-red-100 text-red-800',
    };
    return colors[level];
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-black">Insights</h2>
          <p className="text-gray-600">{insights.length} insights recorded</p>
        </div>
        <Button onClick={handleCreate}>
          <Plus className="mr-2 h-4 w-4" />
          Create Insight
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Insights List */}
        <div className="lg:col-span-1 space-y-2">
          {insights.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <p className="text-center text-gray-500">No insights yet. Create your first insight to get started.</p>
              </CardContent>
            </Card>
          ) : (
            insights.map((insight) => (
              <Card
                key={insight.id}
                className={`cursor-pointer hover:shadow-md transition-shadow ${
                  selectedInsight?.id === insight.id ? 'ring-2 ring-blue-500' : ''
                }`}
                onClick={() => setSelectedInsight(insight)}
              >
                <CardContent className="pt-4">
                  <div className="flex justify-between items-start mb-2">
                    <Badge className={getImpactColor(insight.impactLevel)}>
                      {insight.impactLevel}
                    </Badge>
                    <Badge variant="outline">{insight.context}</Badge>
                  </div>
                  <h3 className="font-semibold text-black mb-1">{insight.summary}</h3>
                  <p className="text-sm text-gray-600">{formatTimestamp(insight.timestamp)}</p>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Insight Detail */}
        <div className="lg:col-span-2">
          {selectedInsight ? (
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-black">{selectedInsight.summary}</CardTitle>
                    <p className="text-sm text-gray-600 mt-1">
                      {formatTimestamp(selectedInsight.timestamp)}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => handleEdit(selectedInsight)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDelete(selectedInsight.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-semibold text-black mb-2">Context</h3>
                  <Badge variant="secondary">{selectedInsight.context}</Badge>
                </div>

                <div>
                  <h3 className="font-semibold text-black mb-2">Impact Level</h3>
                  <Badge className={getImpactColor(selectedInsight.impactLevel)}>
                    {selectedInsight.impactLevel}
                  </Badge>
                </div>

                <div>
                  <h3 className="font-semibold text-black mb-2">Details</h3>
                  <p className="text-gray-700 whitespace-pre-wrap">{selectedInsight.details}</p>
                </div>

                {selectedInsight.relatedObjects.length > 0 && (
                  <div>
                    <h3 className="font-semibold text-black mb-2">Related Objects</h3>
                    <div className="flex gap-2 flex-wrap">
                      {selectedInsight.relatedObjects.map((obj) => (
                        <Badge key={obj} variant="outline">
                          {obj}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {selectedInsight.recommendedActions.length > 0 && (
                  <div>
                    <h3 className="font-semibold text-black mb-2">Recommended Actions</h3>
                    <ul className="list-disc list-inside space-y-1">
                      {selectedInsight.recommendedActions.map((action, index) => (
                        <li key={index} className="text-gray-700">
                          {action}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {selectedInsight.notes && (
                  <div>
                    <h3 className="font-semibold text-black mb-2">Notes</h3>
                    <p className="text-gray-700 whitespace-pre-wrap">{selectedInsight.notes}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="pt-6">
                <p className="text-center text-gray-500">Select an insight to view details</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Create/Edit Form Dialog */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingId ? 'Edit Insight' : 'Create New Insight'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label htmlFor="summary">Summary *</Label>
              <Input
                id="summary"
                value={formData.summary}
                onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
                placeholder="Brief summary of the insight"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="context">Context *</Label>
                <Input
                  id="context"
                  value={formData.context}
                  onChange={(e) => setFormData({ ...formData, context: e.target.value })}
                  placeholder="e.g., culture, ops, pickleball"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="impactLevel">Impact Level *</Label>
                <Select
                  value={formData.impactLevel}
                  onValueChange={(value) => setFormData({ ...formData, impactLevel: value as ImpactLevel })}
                >
                  <SelectTrigger id="impactLevel">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="details">Details *</Label>
              <Textarea
                id="details"
                value={formData.details}
                onChange={(e) => setFormData({ ...formData, details: e.target.value })}
                placeholder="Detailed description of the insight"
                rows={4}
                required
              />
            </div>

            <div className="space-y-2">
              <Label>Related Objects</Label>
              <div className="flex gap-2">
                <Input
                  value={objectInput}
                  onChange={(e) => setObjectInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddObject())}
                  placeholder="Add related object"
                />
                <Button type="button" onClick={handleAddObject} variant="outline">
                  Add
                </Button>
              </div>
              {formData.relatedObjects && formData.relatedObjects.length > 0 && (
                <div className="flex gap-2 flex-wrap">
                  {formData.relatedObjects.map((obj) => (
                    <Badge key={obj} variant="secondary" className="cursor-pointer">
                      {obj}
                      <X className="ml-1 h-3 w-3" onClick={() => handleRemoveObject(obj)} />
                    </Badge>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label>Recommended Actions</Label>
              <div className="flex gap-2">
                <Input
                  value={actionInput}
                  onChange={(e) => setActionInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddAction())}
                  placeholder="Add recommended action"
                />
                <Button type="button" onClick={handleAddAction} variant="outline">
                  Add
                </Button>
              </div>
              {formData.recommendedActions && formData.recommendedActions.length > 0 && (
                <div className="space-y-1">
                  {formData.recommendedActions.map((action, index) => (
                    <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                      <span className="flex-1 text-sm text-black">{action}</span>
                      <X
                        className="h-4 w-4 cursor-pointer text-gray-500 hover:text-red-500"
                        onClick={() => handleRemoveAction(action)}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Additional notes"
                rows={3}
              />
            </div>

            <div className="flex gap-2 justify-end">
              <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                Cancel
              </Button>
              <Button type="submit">{editingId ? 'Update' : 'Create'}</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
