'use client'
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Heart, Zap, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { extendedStorage } from '@/lib/storage-extended';
import { analyticsEngine } from '@/lib/analytics-engine';
import type { MoodEntry, MoodType, EnergyLevel } from '@/types/memory-extended';
import { toast } from 'sonner';

const MOOD_OPTIONS: { value: MoodType; emoji: string; label: string }[] = [
  { value: 'amazing', emoji: '🤩', label: 'Amazing' },
  { value: 'good', emoji: '😊', label: 'Good' },
  { value: 'neutral', emoji: '😐', label: 'Neutral' },
  { value: 'bad', emoji: '😕', label: 'Bad' },
  { value: 'terrible', emoji: '😢', label: 'Terrible' },
];

const ENERGY_OPTIONS: { value: EnergyLevel; emoji: string; label: string }[] = [
  { value: 'peak', emoji: '⚡', label: 'Peak' },
  { value: 'high', emoji: '💪', label: 'High' },
  { value: 'moderate', emoji: '🔋', label: 'Moderate' },
  { value: 'low', emoji: '🪫', label: 'Low' },
  { value: 'exhausted', emoji: '😴', label: 'Exhausted' },
];

export function MoodTracker() {
  const [selectedMood, setSelectedMood] = useState<MoodType | null>(null);
  const [selectedEnergy, setSelectedEnergy] = useState<EnergyLevel | null>(null);
  const [notes, setNotes] = useState('');
  const [entries, setEntries] = useState<MoodEntry[]>([]);
  const [analytics, setAnalytics] = useState<{
    averageMood: number;
    averageEnergy: number;
    moodTrend: 'improving' | 'stable' | 'declining';
    topActivities: string[];
  } | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = (): void => {
    const allEntries = extendedStorage.getMoodEntries();
    setEntries(allEntries.slice(-10)); // Show last 10
    
    if (allEntries.length > 0) {
      const analysis = analyticsEngine.analyzeMoodPatterns(allEntries);
      setAnalytics(analysis);
    }
  };

  const handleSave = (): void => {
    if (!selectedMood || !selectedEnergy) {
      toast.error('Please select both mood and energy level');
      return;
    }

    const entry: MoodEntry = {
      id: `mood_${Date.now()}`,
      timestamp: new Date().toISOString(),
      mood: selectedMood,
      energy: selectedEnergy,
      notes,
      activities: [],
      location: null,
      weather: null,
      relatedEventIds: [],
    };

    extendedStorage.saveMoodEntry(entry);
    toast.success('Mood logged!');
    
    setSelectedMood(null);
    setSelectedEnergy(null);
    setNotes('');
    loadData();
  };

  const getTrendIcon = (): JSX.Element | null => {
    if (!analytics) return null;
    if (analytics.moodTrend === 'improving') return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (analytics.moodTrend === 'declining') return <TrendingDown className="h-4 w-4 text-red-500" />;
    return <Minus className="h-4 w-4 text-gray-500" />;
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Heart className="h-5 w-5 text-red-500" />
            Mood & Energy Tracker
          </CardTitle>
          <CardDescription>Track your emotional state and energy levels</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <p className="text-sm font-medium mb-2">How are you feeling?</p>
            <div className="flex gap-2 flex-wrap">
              {MOOD_OPTIONS.map((option) => (
                <Button
                  key={option.value}
                  variant={selectedMood === option.value ? 'default' : 'outline'}
                  onClick={() => setSelectedMood(option.value)}
                  className="flex items-center gap-2"
                >
                  <span>{option.emoji}</span>
                  {option.label}
                </Button>
              ))}
            </div>
          </div>

          <div>
            <p className="text-sm font-medium mb-2">Energy level?</p>
            <div className="flex gap-2 flex-wrap">
              {ENERGY_OPTIONS.map((option) => (
                <Button
                  key={option.value}
                  variant={selectedEnergy === option.value ? 'default' : 'outline'}
                  onClick={() => setSelectedEnergy(option.value)}
                  className="flex items-center gap-2"
                >
                  <span>{option.emoji}</span>
                  {option.label}
                </Button>
              ))}
            </div>
          </div>

          <div>
            <p className="text-sm font-medium mb-2">Notes (optional)</p>
            <Textarea
              value={notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNotes(e.target.value)}
              placeholder="What's on your mind?"
              rows={3}
            />
          </div>

          <Button onClick={handleSave} className="w-full">
            Log Mood
          </Button>
        </CardContent>
      </Card>

      {analytics && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Mood Analytics
              {getTrendIcon()}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 p-3 rounded">
                <p className="text-xs text-gray-500">Average Mood</p>
                <p className="text-2xl font-bold">{analytics.averageMood.toFixed(1)}/5</p>
              </div>
              <div className="bg-gray-50 p-3 rounded">
                <p className="text-xs text-gray-500">Average Energy</p>
                <p className="text-2xl font-bold">{analytics.averageEnergy.toFixed(1)}/5</p>
              </div>
            </div>

            <div>
              <p className="text-sm font-medium mb-1">Trend</p>
              <Badge variant={analytics.moodTrend === 'improving' ? 'default' : 'secondary'}>
                {analytics.moodTrend}
              </Badge>
            </div>

            {entries.length > 0 && (
              <div>
                <p className="text-sm font-medium mb-2">Recent Entries</p>
                <div className="space-y-2">
                  {entries.slice(-5).reverse().map((entry: MoodEntry) => (
                    <div key={entry.id} className="flex items-center gap-2 text-sm">
                      <span>
                        {MOOD_OPTIONS.find((m) => m.value === entry.mood)?.emoji}
                      </span>
                      <span>
                        {ENERGY_OPTIONS.find((e) => e.value === entry.energy)?.emoji}
                      </span>
                      <span className="text-gray-500">
                        {new Date(entry.timestamp).toLocaleDateString()}
                      </span>
                      {entry.notes && (
                        <span className="text-gray-400 truncate flex-1">
                          {entry.notes}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
