'use client'
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Check } from 'lucide-react';
import { nlParser } from '@/lib/natural-language-parser';
import { memoryStore } from '@/lib/memory-store';
import type { ParsedInput } from '@/types/memory-extended';
import { toast } from 'sonner';

export function NaturalLanguageInput() {
  const [input, setInput] = useState('');
  const [parsed, setParsed] = useState<ParsedInput | null>(null);
  const [suggestions, setSuggestions] = useState<string[]>([]);

  const handleParse = (): void => {
    if (!input.trim()) {
      toast.error('Please enter some text');
      return;
    }

    const result = nlParser.parse(input);
    setParsed(result);
    
    const improvementSuggestions = nlParser.suggestImprovements(result);
    setSuggestions(improvementSuggestions);

    if (result.confidence < 0.5) {
      toast.warning('Low confidence - please review the parsed event');
    } else {
      toast.success('Event parsed successfully!');
    }
  };

  const handleSave = (): void => {
    if (!parsed) return;

    const event = {
      id: `event_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: parsed.timestamp || new Date().toISOString(),
      eventType: parsed.eventType,
      title: parsed.title,
      description: parsed.description,
      sourceApp: null,
      relatedObjectType: null,
      relatedObjectId: null,
      relatedAgentId: null,
      tags: parsed.tags,
      importanceLevel: 'medium' as const,
      notes: '',
    };

    memoryStore.saveEvent(event);
    toast.success('Event saved!');
    
    setInput('');
    setParsed(null);
    setSuggestions([]);
  };

  const handleTryExample = (example: string): void => {
    setInput(example);
    setParsed(null);
    setSuggestions([]);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-purple-500" />
          Natural Language Input
        </CardTitle>
        <CardDescription>
          Just type naturally - I'll figure out what type of event it is
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Textarea
            value={input}
            onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setInput(e.target.value)}
            placeholder="e.g., Created a new Drop for the culture expansion project today at 2pm"
            rows={4}
            className="mb-2"
          />
          <Button onClick={handleParse} className="w-full">
            <Sparkles className="h-4 w-4 mr-2" />
            Parse Event
          </Button>
        </div>

        {parsed && (
          <div className="border rounded-lg p-4 space-y-3 bg-gray-50">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="secondary">{parsed.eventType}</Badge>
                  <Badge 
                    variant={parsed.confidence > 0.7 ? 'default' : 'outline'}
                    className={parsed.confidence > 0.7 ? 'bg-green-500' : ''}
                  >
                    {Math.round(parsed.confidence * 100)}% confidence
                  </Badge>
                </div>
                <h4 className="font-medium mb-1">{parsed.title}</h4>
                <p className="text-sm text-gray-600 mb-2">{parsed.description}</p>
                {parsed.tags.length > 0 && (
                  <div className="flex gap-1 flex-wrap">
                    {parsed.tags.map((tag: string) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
              <Button onClick={handleSave} size="sm" className="ml-2">
                <Check className="h-4 w-4 mr-1" />
                Save
              </Button>
            </div>

            {suggestions.length > 0 && (
              <div className="border-t pt-3 mt-3">
                <p className="text-sm font-medium mb-2">💡 Suggestions:</p>
                <ul className="text-sm text-gray-600 space-y-1">
                  {suggestions.map((suggestion: string, index: number) => (
                    <li key={index}>• {suggestion}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}

        <div className="border-t pt-4">
          <p className="text-sm font-medium mb-2">Try these examples:</p>
          <div className="space-y-2">
            {nlParser.getExampleInputs().slice(0, 4).map((example: string, index: number) => (
              <button
                key={index}
                onClick={() => handleTryExample(example)}
                className="text-sm text-blue-600 hover:underline block text-left"
              >
                "{example}"
              </button>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
