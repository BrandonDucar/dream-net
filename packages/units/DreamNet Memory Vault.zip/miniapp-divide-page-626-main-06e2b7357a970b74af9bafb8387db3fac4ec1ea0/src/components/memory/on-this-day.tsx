'use client'
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock } from 'lucide-react';
import { memoryStore } from '@/lib/memory-store';
import type { MemoryEvent } from '@/types/memory';

export function OnThisDay() {
  const [memories, setMemories] = useState<MemoryEvent[]>([]);
  const [years, setYears] = useState<number[]>([]);

  useEffect(() => {
    loadMemories();
  }, []);

  const loadMemories = (): void => {
    const today = new Date();
    const currentMonth = today.getMonth() + 1;
    const currentDay = today.getDate();

    const allEvents = memoryStore.getEvents();
    const matchingEvents: MemoryEvent[] = [];
    const yearSet = new Set<number>();

    allEvents.forEach((event: MemoryEvent) => {
      const eventDate = new Date(event.timestamp);
      const eventMonth = eventDate.getMonth() + 1;
      const eventDay = eventDate.getDate();
      const eventYear = eventDate.getFullYear();

      // Match same month and day, but different year
      if (eventMonth === currentMonth && eventDay === currentDay && eventYear !== today.getFullYear()) {
        matchingEvents.push(event);
        yearSet.add(today.getFullYear() - eventYear);
      }
    });

    // Sort by most recent first
    matchingEvents.sort((a: MemoryEvent, b: MemoryEvent) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );

    setMemories(matchingEvents);
    setYears(Array.from(yearSet).sort((a: number, b: number) => a - b));
  };

  const getYearsAgo = (timestamp: string): number => {
    const eventDate = new Date(timestamp);
    const today = new Date();
    return today.getFullYear() - eventDate.getFullYear();
  };

  if (memories.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-purple-500" />
            On This Day
          </CardTitle>
          <CardDescription>Memories from previous years</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-500 text-center py-8">
            No memories from previous years on this day yet. Keep logging events to build your history! 📅
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5 text-purple-500" />
          On This Day
        </CardTitle>
        <CardDescription>
          {memories.length} {memories.length === 1 ? 'memory' : 'memories'} from{' '}
          {years.length === 1 ? `${years[0]} year` : `${years.join(', ')} years`} ago
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {memories.map((event: MemoryEvent) => {
            const yearsAgo = getYearsAgo(event.timestamp);
            const eventDate = new Date(event.timestamp);

            return (
              <div
                key={event.id}
                className="border rounded-lg p-4 hover:shadow-md transition-shadow bg-gradient-to-r from-purple-50 to-white"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="secondary">
                        {yearsAgo} {yearsAgo === 1 ? 'year' : 'years'} ago
                      </Badge>
                      <Badge variant="outline">{event.eventType}</Badge>
                    </div>
                    <h4 className="font-medium mb-1">{event.title}</h4>
                    <p className="text-sm text-gray-600 mb-2">{event.description}</p>
                  </div>
                  <div className="text-right text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {eventDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>

                {event.tags.length > 0 && (
                  <div className="flex gap-1 flex-wrap">
                    {event.tags.map((tag: string) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}

                {event.sourceApp && (
                  <p className="text-xs text-gray-500 mt-2">
                    From: {event.sourceApp}
                  </p>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-4 text-xs text-gray-500 text-center">
          💜 Relive your memories from the past
        </div>
      </CardContent>
    </Card>
  );
}
