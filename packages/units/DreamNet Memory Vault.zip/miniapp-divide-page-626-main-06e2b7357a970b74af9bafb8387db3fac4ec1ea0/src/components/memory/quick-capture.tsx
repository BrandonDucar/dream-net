'use client'
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Plus, Zap, Settings } from 'lucide-react';
import { extendedStorage } from '@/lib/storage-extended';
import { memoryStore } from '@/lib/memory-store';
import type { QuickButton } from '@/types/memory-extended';
import type { EventType } from '@/types/memory';
import { toast } from 'sonner';

export function QuickCapture() {
  const [buttons, setButtons] = useState<QuickButton[]>(extendedStorage.getQuickButtons());
  const [showConfig, setShowConfig] = useState(false);
  const [editingButton, setEditingButton] = useState<QuickButton | null>(null);

  const handleQuickLog = (button: QuickButton): void => {
    const event = {
      id: `event_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
      eventType: button.eventType,
      title: button.label,
      description: `Quick log: ${button.label}`,
      sourceApp: button.sourceApp,
      relatedObjectType: null,
      relatedObjectId: null,
      relatedAgentId: null,
      tags: button.tags,
      importanceLevel: "medium" as const,
      notes: "",
    };

    memoryStore.saveEvent(event);
    toast.success(`${button.emoji} ${button.label} logged!`);
  };

  const handleSaveButton = (button: QuickButton): void => {
    extendedStorage.saveQuickButton(button);
    setButtons(extendedStorage.getQuickButtons());
    setEditingButton(null);
    toast.success('Quick button saved!');
  };

  const handleDeleteButton = (id: string): void => {
    extendedStorage.deleteQuickButton(id);
    setButtons(extendedStorage.getQuickButtons());
    toast.success('Quick button deleted');
  };

  const createNewButton = (): void => {
    const newButton: QuickButton = {
      id: `btn_${Date.now()}`,
      label: 'New Button',
      emoji: '⭐',
      color: '#3b82f6',
      action: 'log-event',
      eventType: 'note',
      tags: [],
      sourceApp: null,
      order: buttons.length,
      archived: false,
    };
    setEditingButton(newButton);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-yellow-500" />
              Quick Capture
            </CardTitle>
            <CardDescription>One-tap event logging (Nomie-style)</CardDescription>
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => setShowConfig(!showConfig)}>
              <Settings className="h-4 w-4" />
            </Button>
            <Button size="sm" onClick={createNewButton}>
              <Plus className="h-4 w-4 mr-1" />
              Add Button
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          {buttons.filter((b: QuickButton) => !b.archived).length === 0 ? (
            <p className="text-sm text-gray-500">No quick buttons yet. Create one to get started!</p>
          ) : (
            buttons
              .filter((b: QuickButton) => !b.archived)
              .sort((a: QuickButton, b: QuickButton) => a.order - b.order)
              .map((button: QuickButton) => (
                <div key={button.id} className="relative group">
                  <Button
                    onClick={() => handleQuickLog(button)}
                    style={{ backgroundColor: button.color }}
                    className="text-white hover:opacity-90"
                  >
                    <span className="mr-2">{button.emoji}</span>
                    {button.label}
                  </Button>
                  {showConfig && (
                    <div className="absolute -top-2 -right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button
                        size="sm"
                        variant="secondary"
                        className="h-6 w-6 p-0 rounded-full"
                        onClick={(e: React.MouseEvent) => {
                          e.stopPropagation();
                          setEditingButton(button);
                        }}
                      >
                        ✏️
                      </Button>
                    </div>
                  )}
                </div>
              ))
          )}
        </div>

        {buttons.filter((b: QuickButton) => !b.archived).length > 0 && (
          <div className="mt-4 text-xs text-gray-500">
            💡 Tip: Click any button to instantly log that event
          </div>
        )}
      </CardContent>

      {editingButton && (
        <Dialog open={true} onOpenChange={() => setEditingButton(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Configure Quick Button</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Label</Label>
                <Input
                  value={editingButton.label}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setEditingButton({ ...editingButton, label: e.target.value })
                  }
                />
              </div>
              <div>
                <Label>Emoji</Label>
                <Input
                  value={editingButton.emoji}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setEditingButton({ ...editingButton, emoji: e.target.value })
                  }
                  placeholder="⭐"
                />
              </div>
              <div>
                <Label>Color</Label>
                <Input
                  type="color"
                  value={editingButton.color}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setEditingButton({ ...editingButton, color: e.target.value })
                  }
                />
              </div>
              <div>
                <Label>Event Type</Label>
                <select
                  className="w-full border rounded px-3 py-2"
                  value={editingButton.eventType}
                  onChange={(e: React.ChangeEvent<HTMLSelectElement>) =>
                    setEditingButton({ ...editingButton, eventType: e.target.value as EventType })
                  }
                >
                  <option value="object-created">Object Created</option>
                  <option value="object-updated">Object Updated</option>
                  <option value="state-change">State Change</option>
                  <option value="flow-step-completed">Flow Step Completed</option>
                  <option value="scenario-run">Scenario Run</option>
                  <option value="agent-action">Agent Action</option>
                  <option value="decision">Decision</option>
                  <option value="insight">Insight</option>
                  <option value="note">Note</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div>
                <Label>Tags (comma separated)</Label>
                <Input
                  value={editingButton.tags.join(', ')}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setEditingButton({
                      ...editingButton,
                      tags: e.target.value.split(',').map((t: string) => t.trim()).filter(Boolean),
                    })
                  }
                  placeholder="culture, ops, tech"
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={() => handleSaveButton(editingButton)} className="flex-1">
                  Save
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => {
                    if (editingButton.id.startsWith('btn_')) {
                      handleDeleteButton(editingButton.id);
                      setEditingButton(null);
                    }
                  }}
                >
                  Delete
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </Card>
  );
}
