'use client'
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Settings as SettingsIcon, Moon, Sun, Download, Upload, Trash2 } from 'lucide-react';
import { extendedStorage } from '@/lib/storage-extended';
import { memoryStore } from '@/lib/memory-store';
import type { UserPreferences } from '@/types/memory-extended';
import { toast } from 'sonner';

export function Settings() {
  const [prefs, setPrefs] = useState<UserPreferences>(extendedStorage.getUserPreferences());
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  useEffect(() => {
    loadPreferences();
  }, []);

  const loadPreferences = (): void => {
    const preferences = extendedStorage.getUserPreferences();
    setPrefs(preferences);
    setTheme(preferences.theme === 'dark' ? 'dark' : 'light');
  };

  const handleSavePreferences = (newPrefs: UserPreferences): void => {
    extendedStorage.saveUserPreferences(newPrefs);
    setPrefs(newPrefs);
    toast.success('Settings saved!');
  };

  const toggleTheme = (): void => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    handleSavePreferences({ ...prefs, theme: newTheme });
    
    // Apply theme to document
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const handleImportData = (): void => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    
    input.onchange = (e: Event) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event: ProgressEvent<FileReader>) => {
        try {
          const data = JSON.parse(event.target?.result as string);
          
          if (data.events) {
            data.events.forEach((event: unknown) => memoryStore.saveEvent(event as never));
          }
          if (data.insights) {
            data.insights.forEach((insight: unknown) => memoryStore.saveInsight(insight as never));
          }
          if (data.threads) {
            data.threads.forEach((thread: unknown) => memoryStore.saveThread(thread as never));
          }
          if (data.dailyLogs) {
            data.dailyLogs.forEach((log: unknown) => memoryStore.saveDailyLog(log as never));
          }
          if (data.snapshots) {
            data.snapshots.forEach((snapshot: unknown) => memoryStore.saveSnapshot(snapshot as never));
          }

          toast.success('Data imported successfully!');
        } catch (error) {
          console.error('Import failed:', error);
          toast.error('Failed to import data');
        }
      };

      reader.readAsText(file);
    };

    input.click();
  };

  const handleClearAllData = (): void => {
    const confirmed = window.confirm(
      'Are you sure you want to delete ALL data? This cannot be undone!'
    );

    if (!confirmed) return;

    const doubleConfirm = window.confirm(
      'This will permanently delete all events, insights, threads, logs, habits, mood entries, and goals. Continue?'
    );

    if (!doubleConfirm) return;

    try {
      // Clear all data
      localStorage.clear();
      toast.success('All data cleared');
      window.location.reload();
    } catch (error) {
      console.error('Clear failed:', error);
      toast.error('Failed to clear data');
    }
  };

  const getStorageSize = (): string => {
    try {
      let totalSize = 0;
      for (const key in localStorage) {
        if (localStorage.hasOwnProperty(key)) {
          totalSize += localStorage[key].length;
        }
      }
      const sizeInKB = (totalSize / 1024).toFixed(2);
      return `${sizeInKB} KB`;
    } catch {
      return 'Unknown';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <SettingsIcon className="h-5 w-5 text-blue-500" />
            Settings
          </CardTitle>
          <CardDescription>Customize your memory vault experience</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-medium mb-4">Appearance</h3>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {theme === 'light' ? (
                  <Sun className="h-5 w-5 text-yellow-500" />
                ) : (
                  <Moon className="h-5 w-5 text-blue-500" />
                )}
                <div>
                  <Label>Dark Mode</Label>
                  <p className="text-sm text-gray-500">Toggle dark theme</p>
                </div>
              </div>
              <Switch checked={theme === 'dark'} onCheckedChange={toggleTheme} />
            </div>
          </div>

          <div className="border-t pt-6">
            <h3 className="font-medium mb-4">Preferences</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Enable Notifications</Label>
                  <p className="text-sm text-gray-500">Get reminders and alerts</p>
                </div>
                <Switch
                  checked={prefs.enableNotifications}
                  onCheckedChange={(checked: boolean) =>
                    handleSavePreferences({ ...prefs, enableNotifications: checked })
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Enable Analytics</Label>
                  <p className="text-sm text-gray-500">Track usage patterns</p>
                </div>
                <Switch
                  checked={prefs.enableAnalytics}
                  onCheckedChange={(checked: boolean) =>
                    handleSavePreferences({ ...prefs, enableAnalytics: checked })
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Keyboard Shortcuts</Label>
                  <p className="text-sm text-gray-500">Enable hotkeys</p>
                </div>
                <Switch
                  checked={prefs.keyboardShortcutsEnabled}
                  onCheckedChange={(checked: boolean) =>
                    handleSavePreferences({ ...prefs, keyboardShortcutsEnabled: checked })
                  }
                />
              </div>

              <div>
                <Label>Time Format</Label>
                <select
                  className="w-full border rounded px-3 py-2 mt-1"
                  value={prefs.timeFormat}
                  onChange={(e: React.ChangeEvent<HTMLSelectElement>) =>
                    handleSavePreferences({
                      ...prefs,
                      timeFormat: e.target.value as '12h' | '24h',
                    })
                  }
                >
                  <option value="12h">12-hour (3:00 PM)</option>
                  <option value="24h">24-hour (15:00)</option>
                </select>
              </div>

              <div>
                <Label>Default Export Format</Label>
                <select
                  className="w-full border rounded px-3 py-2 mt-1"
                  value={prefs.exportFormat}
                  onChange={(e: React.ChangeEvent<HTMLSelectElement>) =>
                    handleSavePreferences({
                      ...prefs,
                      exportFormat: e.target.value as 'json' | 'csv' | 'markdown',
                    })
                  }
                >
                  <option value="json">JSON</option>
                  <option value="csv">CSV</option>
                  <option value="markdown">Markdown</option>
                </select>
              </div>
            </div>
          </div>

          <div className="border-t pt-6">
            <h3 className="font-medium mb-4">Data Management</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between bg-gray-50 p-3 rounded">
                <div>
                  <p className="text-sm font-medium">Storage Used</p>
                  <p className="text-xs text-gray-500">{getStorageSize()}</p>
                </div>
              </div>

              <Button onClick={handleImportData} variant="outline" className="w-full">
                <Upload className="h-4 w-4 mr-2" />
                Import Data
              </Button>

              <Button
                onClick={handleClearAllData}
                variant="destructive"
                className="w-full"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Clear All Data
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Keyboard Shortcuts</CardTitle>
          <CardDescription>Quick actions (when enabled)</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span>Create Event</span>
              <kbd className="px-2 py-1 bg-gray-100 rounded border">Ctrl + E</kbd>
            </div>
            <div className="flex items-center justify-between">
              <span>Search</span>
              <kbd className="px-2 py-1 bg-gray-100 rounded border">Ctrl + K</kbd>
            </div>
            <div className="flex items-center justify-between">
              <span>Go to Dashboard</span>
              <kbd className="px-2 py-1 bg-gray-100 rounded border">Ctrl + H</kbd>
            </div>
            <div className="flex items-center justify-between">
              <span>Export</span>
              <kbd className="px-2 py-1 bg-gray-100 rounded border">Ctrl + S</kbd>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
