'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Edit, Trash2, X, Eye } from 'lucide-react';
import { memoryStore } from '@/lib/memory-store';
import type { StateSnapshot } from '@/types/memory';
import { toast } from 'sonner';

export function SnapshotsView() {
  const [snapshots, setSnapshots] = useState<StateSnapshot[]>([]);
  const [selectedSnapshot, setSelectedSnapshot] = useState<StateSnapshot | null>(null);
  const [showForm, setShowForm] = useState<boolean>(false);
  const [showDetail, setShowDetail] = useState<boolean>(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<StateSnapshot>>({
    snapshotName: '',
    description: '',
    keyValues: {},
    tags: [],
    notes: '',
  });
  const [tagInput, setTagInput] = useState<string>('');
  const [kvKey, setKvKey] = useState<string>('');
  const [kvValue, setKvValue] = useState<string>('');

  useEffect(() => {
    loadSnapshots();
  }, []);

  const loadSnapshots = (): void => {
    const allSnapshots = memoryStore.filterSnapshots({});
    setSnapshots(allSnapshots);
  };

  const handleCreate = (): void => {
    setEditingId(null);
    setFormData({
      snapshotName: '',
      description: '',
      keyValues: {},
      tags: [],
      notes: '',
    });
    setShowForm(true);
  };

  const handleEdit = (snapshot: StateSnapshot): void => {
    setEditingId(snapshot.id);
    setFormData(snapshot);
    setShowForm(true);
  };

  const handleDelete = (id: string): void => {
    if (confirm('Are you sure you want to delete this snapshot?')) {
      memoryStore.deleteSnapshot(id);
      loadSnapshots();
      toast.success('Snapshot deleted');
    }
  };

  const handleView = (snapshot: StateSnapshot): void => {
    setSelectedSnapshot(snapshot);
    setShowDetail(true);
  };

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();

    if (!formData.snapshotName || !formData.description) {
      toast.error('Name and description are required');
      return;
    }

    const snapshot: StateSnapshot = {
      id: editingId || `snapshot-${Date.now()}`,
      timestamp: editingId ? (formData.timestamp || new Date().toISOString()) : new Date().toISOString(),
      snapshotName: formData.snapshotName,
      description: formData.description,
      keyValues: formData.keyValues || {},
      tags: formData.tags || [],
      notes: formData.notes || '',
    };

    memoryStore.saveSnapshot(snapshot);
    loadSnapshots();
    setShowForm(false);
    toast.success(editingId ? 'Snapshot updated' : 'Snapshot created');
  };

  const handleAddTag = (): void => {
    if (tagInput.trim() && !formData.tags?.includes(tagInput.trim())) {
      setFormData((prev) => ({
        ...prev,
        tags: [...(prev.tags || []), tagInput.trim()],
      }));
      setTagInput('');
    }
  };

  const handleRemoveTag = (tag: string): void => {
    setFormData((prev) => ({
      ...prev,
      tags: (prev.tags || []).filter((t) => t !== tag),
    }));
  };

  const handleAddKeyValue = (): void => {
    if (kvKey.trim()) {
      setFormData((prev) => ({
        ...prev,
        keyValues: {
          ...(prev.keyValues || {}),
          [kvKey.trim()]: kvValue || '',
        },
      }));
      setKvKey('');
      setKvValue('');
    }
  };

  const handleRemoveKeyValue = (key: string): void => {
    setFormData((prev) => {
      const newKeyValues = { ...(prev.keyValues || {}) };
      delete newKeyValues[key];
      return {
        ...prev,
        keyValues: newKeyValues,
      };
    });
  };

  const formatTimestamp = (timestamp: string): string => {
    return new Date(timestamp).toLocaleString('en-US', {
      dateStyle: 'medium',
      timeStyle: 'short',
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-black">State Snapshots</h2>
          <p className="text-gray-600">{snapshots.length} snapshots recorded</p>
        </div>
        <Button onClick={handleCreate}>
          <Plus className="mr-2 h-4 w-4" />
          Create Snapshot
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-black">Timestamp</TableHead>
                <TableHead className="text-black">Name</TableHead>
                <TableHead className="text-black">Description</TableHead>
                <TableHead className="text-black">Key-Values</TableHead>
                <TableHead className="text-black">Tags</TableHead>
                <TableHead className="text-black">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {snapshots.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-gray-500 py-8">
                    No snapshots yet. Create your first snapshot to get started.
                  </TableCell>
                </TableRow>
              ) : (
                snapshots.map((snapshot) => (
                  <TableRow key={snapshot.id}>
                    <TableCell className="text-black">{formatTimestamp(snapshot.timestamp)}</TableCell>
                    <TableCell className="font-medium text-black">{snapshot.snapshotName}</TableCell>
                    <TableCell className="text-black max-w-xs truncate">{snapshot.description}</TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {Object.keys(snapshot.keyValues).length} keys
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1 flex-wrap">
                        {snapshot.tags.slice(0, 2).map((tag) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {snapshot.tags.length > 2 && (
                          <Badge variant="secondary" className="text-xs">
                            +{snapshot.tags.length - 2}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleView(snapshot)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleEdit(snapshot)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDelete(snapshot.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Detail Dialog */}
      <Dialog open={showDetail} onOpenChange={setShowDetail}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedSnapshot?.snapshotName}</DialogTitle>
          </DialogHeader>
          {selectedSnapshot && (
            <div className="space-y-4 pt-4">
              <div>
                <Label className="text-black">Timestamp</Label>
                <p className="text-gray-700">{formatTimestamp(selectedSnapshot.timestamp)}</p>
              </div>
              <div>
                <Label className="text-black">Description</Label>
                <p className="text-gray-700">{selectedSnapshot.description}</p>
              </div>
              <div>
                <Label className="text-black">Key-Value Pairs</Label>
                <div className="border rounded-lg p-3 bg-gray-50 mt-2">
                  {Object.entries(selectedSnapshot.keyValues).length === 0 ? (
                    <p className="text-gray-500 text-sm">No key-value pairs</p>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="text-black">Key</TableHead>
                          <TableHead className="text-black">Value</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {Object.entries(selectedSnapshot.keyValues).map(([key, value]) => (
                          <TableRow key={key}>
                            <TableCell className="font-medium text-black">{key}</TableCell>
                            <TableCell className="text-black">{String(value)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </div>
              </div>
              {selectedSnapshot.tags.length > 0 && (
                <div>
                  <Label className="text-black">Tags</Label>
                  <div className="flex gap-2 flex-wrap mt-2">
                    {selectedSnapshot.tags.map((tag) => (
                      <Badge key={tag} variant="secondary">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
              {selectedSnapshot.notes && (
                <div>
                  <Label className="text-black">Notes</Label>
                  <p className="text-gray-700 whitespace-pre-wrap">{selectedSnapshot.notes}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Create/Edit Form Dialog */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingId ? 'Edit Snapshot' : 'Create New Snapshot'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label htmlFor="snapshotName">Snapshot Name *</Label>
              <Input
                id="snapshotName"
                value={formData.snapshotName}
                onChange={(e) => setFormData({ ...formData, snapshotName: e.target.value })}
                placeholder="e.g., Daily Ops, End of Week"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="What does this snapshot represent?"
                rows={3}
                required
              />
            </div>

            <div className="space-y-2">
              <Label>Key-Value Pairs</Label>
              <div className="flex gap-2">
                <Input
                  placeholder="Key"
                  value={kvKey}
                  onChange={(e) => setKvKey(e.target.value)}
                />
                <Input
                  placeholder="Value"
                  value={kvValue}
                  onChange={(e) => setKvValue(e.target.value)}
                />
                <Button type="button" onClick={handleAddKeyValue} variant="outline">
                  Add
                </Button>
              </div>
              {formData.keyValues && Object.keys(formData.keyValues).length > 0 && (
                <div className="border rounded-lg p-2 mt-2">
                  {Object.entries(formData.keyValues).map(([key, value]) => (
                    <div key={key} className="flex justify-between items-center p-2 border-b last:border-0">
                      <div className="flex-1">
                        <span className="font-medium text-black">{key}</span>
                        <span className="text-gray-600 ml-2">{String(value)}</span>
                      </div>
                      <X
                        className="h-4 w-4 cursor-pointer text-gray-500 hover:text-red-500"
                        onClick={() => handleRemoveKeyValue(key)}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label>Tags</Label>
              <div className="flex gap-2">
                <Input
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                  placeholder="Add tag"
                />
                <Button type="button" onClick={handleAddTag} variant="outline">
                  Add
                </Button>
              </div>
              {formData.tags && formData.tags.length > 0 && (
                <div className="flex gap-2 flex-wrap">
                  {formData.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="cursor-pointer">
                      {tag}
                      <X className="ml-1 h-3 w-3" onClick={() => handleRemoveTag(tag)} />
                    </Badge>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Additional notes"
                rows={3}
              />
            </div>

            <div className="flex gap-2 justify-end">
              <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                Cancel
              </Button>
              <Button type="submit">{editingId ? 'Update' : 'Create'}</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
