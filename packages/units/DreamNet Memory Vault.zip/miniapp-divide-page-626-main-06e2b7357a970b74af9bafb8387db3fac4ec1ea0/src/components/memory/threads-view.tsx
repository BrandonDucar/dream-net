'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Edit, Trash2, X, Link2 } from 'lucide-react';
import { memoryStore } from '@/lib/memory-store';
import type { MemoryThread, MemoryEvent } from '@/types/memory';
import { toast } from 'sonner';

interface ThreadsViewProps {
  highlightThreadId?: string;
}

export function ThreadsView({ highlightThreadId }: ThreadsViewProps) {
  const [threads, setThreads] = useState<MemoryThread[]>([]);
  const [selectedThread, setSelectedThread] = useState<MemoryThread | null>(null);
  const [threadEvents, setThreadEvents] = useState<MemoryEvent[]>([]);
  const [showForm, setShowForm] = useState<boolean>(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<MemoryThread>>({
    name: '',
    description: '',
    tags: [],
    eventIds: [],
    notes: '',
  });
  const [tagInput, setTagInput] = useState<string>('');

  useEffect(() => {
    loadThreads();
  }, []);

  useEffect(() => {
    if (highlightThreadId) {
      const thread = memoryStore.getThread(highlightThreadId);
      if (thread) {
        setSelectedThread(thread);
        loadThreadEvents(thread);
      }
    }
  }, [highlightThreadId]);

  const loadThreads = (): void => {
    const allThreads = memoryStore.filterThreads({});
    setThreads(allThreads);
  };

  const loadThreadEvents = (thread: MemoryThread): void => {
    const events = thread.eventIds
      .map((id) => memoryStore.getEvent(id))
      .filter((e): e is MemoryEvent => e !== null);
    setThreadEvents(events);
  };

  const handleSelectThread = (thread: MemoryThread): void => {
    setSelectedThread(thread);
    loadThreadEvents(thread);
  };

  const handleCreate = (): void => {
    setEditingId(null);
    setFormData({
      name: '',
      description: '',
      tags: [],
      eventIds: [],
      notes: '',
    });
    setShowForm(true);
  };

  const handleEdit = (thread: MemoryThread): void => {
    setEditingId(thread.id);
    setFormData(thread);
    setShowForm(true);
  };

  const handleDelete = (id: string): void => {
    if (confirm('Are you sure you want to delete this thread?')) {
      memoryStore.deleteThread(id);
      loadThreads();
      if (selectedThread?.id === id) {
        setSelectedThread(null);
        setThreadEvents([]);
      }
      toast.success('Thread deleted');
    }
  };

  const handleRemoveEvent = (eventId: string): void => {
    if (selectedThread) {
      memoryStore.removeEventFromThread(selectedThread.id, eventId);
      const updatedThread = memoryStore.getThread(selectedThread.id);
      if (updatedThread) {
        setSelectedThread(updatedThread);
        loadThreadEvents(updatedThread);
      }
      toast.success('Event removed from thread');
    }
  };

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();

    if (!formData.name || !formData.description) {
      toast.error('Name and description are required');
      return;
    }

    const thread: MemoryThread = {
      id: editingId || `thread-${Date.now()}`,
      name: formData.name,
      description: formData.description,
      tags: formData.tags || [],
      eventIds: formData.eventIds || [],
      notes: formData.notes || '',
    };

    memoryStore.saveThread(thread);
    loadThreads();
    setShowForm(false);
    toast.success(editingId ? 'Thread updated' : 'Thread created');

    if (editingId && selectedThread?.id === editingId) {
      setSelectedThread(thread);
      loadThreadEvents(thread);
    }
  };

  const handleAddTag = (): void => {
    if (tagInput.trim() && !formData.tags?.includes(tagInput.trim())) {
      setFormData((prev) => ({
        ...prev,
        tags: [...(prev.tags || []), tagInput.trim()],
      }));
      setTagInput('');
    }
  };

  const handleRemoveTag = (tag: string): void => {
    setFormData((prev) => ({
      ...prev,
      tags: (prev.tags || []).filter((t) => t !== tag),
    }));
  };

  const formatTimestamp = (timestamp: string): string => {
    return new Date(timestamp).toLocaleString('en-US', {
      dateStyle: 'medium',
      timeStyle: 'short',
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-black">Memory Threads</h2>
          <p className="text-gray-600">{threads.length} threads created</p>
        </div>
        <Button onClick={handleCreate}>
          <Plus className="mr-2 h-4 w-4" />
          Create Thread
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Threads List */}
        <div className="lg:col-span-1 space-y-2">
          {threads.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <p className="text-center text-gray-500">No threads yet. Create your first thread to get started.</p>
              </CardContent>
            </Card>
          ) : (
            threads.map((thread) => (
              <Card
                key={thread.id}
                className={`cursor-pointer hover:shadow-md transition-shadow ${
                  selectedThread?.id === thread.id ? 'ring-2 ring-blue-500' : ''
                }`}
                onClick={() => handleSelectThread(thread)}
              >
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Link2 className="h-4 w-4 text-gray-600" />
                      <h3 className="font-semibold text-black">{thread.name}</h3>
                    </div>
                    <Badge variant="outline">{thread.eventIds.length} events</Badge>
                  </div>
                  <p className="text-sm text-gray-600 line-clamp-2">{thread.description}</p>
                  {thread.tags.length > 0 && (
                    <div className="flex gap-1 mt-2 flex-wrap">
                      {thread.tags.slice(0, 3).map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Thread Detail */}
        <div className="lg:col-span-2">
          {selectedThread ? (
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-black">{selectedThread.name}</CardTitle>
                    <p className="text-sm text-gray-600 mt-1">{selectedThread.description}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => handleEdit(selectedThread)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDelete(selectedThread.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {selectedThread.tags.length > 0 && (
                  <div>
                    <h3 className="font-semibold text-black mb-2">Tags</h3>
                    <div className="flex gap-2 flex-wrap">
                      {selectedThread.tags.map((tag) => (
                        <Badge key={tag} variant="secondary">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {selectedThread.notes && (
                  <div>
                    <h3 className="font-semibold text-black mb-2">Notes</h3>
                    <p className="text-gray-700 whitespace-pre-wrap">{selectedThread.notes}</p>
                  </div>
                )}

                <div>
                  <h3 className="font-semibold text-black mb-2">
                    Events in Thread ({threadEvents.length})
                  </h3>
                  {threadEvents.length === 0 ? (
                    <p className="text-gray-500 text-sm">
                      No events in this thread yet. Add events from the Event Detail view.
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {threadEvents.map((event, index) => (
                        <div
                          key={event.id}
                          className="border rounded-lg p-3 hover:bg-gray-50"
                        >
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <Badge variant="outline" className="text-xs">
                                  #{index + 1}
                                </Badge>
                                <span className="font-medium text-black">{event.title}</span>
                              </div>
                              <p className="text-sm text-gray-600 line-clamp-2">
                                {event.description}
                              </p>
                              <p className="text-xs text-gray-500 mt-1">
                                {formatTimestamp(event.timestamp)}
                              </p>
                            </div>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleRemoveEvent(event.id)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="pt-6">
                <p className="text-center text-gray-500">Select a thread to view details</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Create/Edit Form Dialog */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingId ? 'Edit Thread' : 'Create New Thread'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label htmlFor="name">Thread Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Culture Expansion Thread, Pickleball Journey"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="What is this thread about?"
                rows={3}
                required
              />
            </div>

            <div className="space-y-2">
              <Label>Tags</Label>
              <div className="flex gap-2">
                <Input
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                  placeholder="Add tag"
                />
                <Button type="button" onClick={handleAddTag} variant="outline">
                  Add
                </Button>
              </div>
              {formData.tags && formData.tags.length > 0 && (
                <div className="flex gap-2 flex-wrap">
                  {formData.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="cursor-pointer">
                      {tag}
                      <X className="ml-1 h-3 w-3" onClick={() => handleRemoveTag(tag)} />
                    </Badge>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Additional notes"
                rows={3}
              />
            </div>

            <div className="flex gap-2 justify-end">
              <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                Cancel
              </Button>
              <Button type="submit">{editingId ? 'Update' : 'Create'}</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
