'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Copy, Download } from 'lucide-react';
import { memoryStore } from '@/lib/memory-store';
import type { GeneralFilter } from '@/types/memory';
import { toast } from 'sonner';

export function TimelineView() {
  const [filter, setFilter] = useState<GeneralFilter>({});
  const [timeline, setTimeline] = useState<string>('');
  const [tags] = useState<string[]>(memoryStore.getAllTags());

  const handleFilterChange = (key: keyof GeneralFilter, value: string): void => {
    setFilter((prev) => ({
      ...prev,
      [key]: value || undefined,
    }));
  };

  const handleGenerate = (): void => {
    const generatedTimeline = memoryStore.generateTimeline(filter);
    setTimeline(generatedTimeline);
    toast.success('Timeline generated');
  };

  const handleCopy = (): void => {
    navigator.clipboard.writeText(timeline);
    toast.success('Timeline copied to clipboard');
  };

  const handleDownload = (): void => {
    const blob = new Blob([timeline], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dreamnet-timeline-${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Timeline downloaded');
  };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-2xl font-bold text-black">Historical Timeline</h2>
        <p className="text-gray-600">Generate a chronological timeline of memory events</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-black">Timeline Filters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Tag Filter</Label>
              <Select
                value={filter.tag || ''}
                onValueChange={(value) => handleFilterChange('tag', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All tags" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All tags</SelectItem>
                  {tags.map((tag) => (
                    <SelectItem key={tag} value={tag}>
                      {tag}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Date From</Label>
              <Input
                type="date"
                value={filter.dateFrom || ''}
                onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>Date To</Label>
              <Input
                type="date"
                value={filter.dateTo || ''}
                onChange={(e) => handleFilterChange('dateTo', e.target.value)}
              />
            </div>
          </div>

          <div className="flex gap-2 mt-4">
            <Button onClick={handleGenerate} className="flex-1">
              <Calendar className="mr-2 h-4 w-4" />
              Generate Timeline
            </Button>
          </div>
        </CardContent>
      </Card>

      {timeline && (
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-black">Generated Timeline</CardTitle>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={handleCopy}>
                  <Copy className="mr-2 h-4 w-4" />
                  Copy
                </Button>
                <Button size="sm" variant="outline" onClick={handleDownload}>
                  <Download className="mr-2 h-4 w-4" />
                  Download
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Textarea
              value={timeline}
              readOnly
              rows={20}
              className="font-mono text-sm bg-gray-50 text-black"
            />
          </CardContent>
        </Card>
      )}

      {!timeline && (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-8 text-gray-500">
              <Calendar className="mx-auto h-12 w-12 mb-4 text-gray-400" />
              <p className="mb-2">No timeline generated yet</p>
              <p className="text-sm">Apply filters and click "Generate Timeline" to create a chronological view</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
