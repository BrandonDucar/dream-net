// Analytics Engine - Pattern detection, insights, and predictions

import type { MemoryEvent, Insight } from "@/types/memory";
import type { 
  EventPattern, 
  ActivityHeatmap, 
  TagAnalytics,
  MoodEntry 
} from "@/types/memory-extended";

export class AnalyticsEngine {
  // ============================================
  // EVENT PATTERN ANALYSIS
  // ============================================

  analyzeEventPatterns(events: MemoryEvent[]): EventPattern[] {
    const patterns: Record<string, EventPattern> = {};

    events.forEach((event: MemoryEvent) => {
      if (!patterns[event.eventType]) {
        patterns[event.eventType] = {
          eventType: event.eventType,
          count: 0,
          averageImportance: 0,
          topTags: [],
          topApps: [],
          timeDistribution: {},
        };
      }

      const pattern = patterns[event.eventType];
      pattern.count += 1;

      // Calculate importance
      const importanceValues: Record<string, number> = {
        low: 1,
        medium: 2,
        high: 3,
        critical: 4,
      };
      const currentAvg = pattern.averageImportance;
      pattern.averageImportance = 
        (currentAvg * (pattern.count - 1) + importanceValues[event.importanceLevel]) / pattern.count;

      // Track hour distribution
      const hour = new Date(event.timestamp).getHours();
      const hourKey = `${hour}:00`;
      pattern.timeDistribution[hourKey] = (pattern.timeDistribution[hourKey] || 0) + 1;
    });

    return Object.values(patterns);
  }

  // ============================================
  // ACTIVITY HEATMAP
  // ============================================

  generateActivityHeatmap(
    events: MemoryEvent[],
    insights: Insight[],
    habitLogs: { timestamp: string }[] = []
  ): ActivityHeatmap[] {
    const heatmap: Record<string, ActivityHeatmap> = {};

    events.forEach((event: MemoryEvent) => {
      const date = new Date(event.timestamp).toISOString().split("T")[0];
      if (!heatmap[date]) {
        heatmap[date] = {
          date,
          eventCount: 0,
          insightCount: 0,
          habitLogCount: 0,
          totalActivity: 0,
        };
      }
      heatmap[date].eventCount += 1;
      heatmap[date].totalActivity += 1;
    });

    insights.forEach((insight: Insight) => {
      const date = new Date(insight.timestamp).toISOString().split("T")[0];
      if (!heatmap[date]) {
        heatmap[date] = {
          date,
          eventCount: 0,
          insightCount: 0,
          habitLogCount: 0,
          totalActivity: 0,
        };
      }
      heatmap[date].insightCount += 1;
      heatmap[date].totalActivity += 1;
    });

    habitLogs.forEach((log: { timestamp: string }) => {
      const date = new Date(log.timestamp).toISOString().split("T")[0];
      if (!heatmap[date]) {
        heatmap[date] = {
          date,
          eventCount: 0,
          insightCount: 0,
          habitLogCount: 0,
          totalActivity: 0,
        };
      }
      heatmap[date].habitLogCount += 1;
      heatmap[date].totalActivity += 1;
    });

    return Object.values(heatmap).sort((a: ActivityHeatmap, b: ActivityHeatmap) => 
      a.date.localeCompare(b.date)
    );
  }

  // ============================================
  // TAG ANALYTICS
  // ============================================

  analyzeTagUsage(events: MemoryEvent[], insights: Insight[]): TagAnalytics[] {
    const tagStats: Record<string, TagAnalytics> = {};

    events.forEach((event: MemoryEvent) => {
      event.tags.forEach((tag: string) => {
        if (!tagStats[tag]) {
          tagStats[tag] = {
            tag,
            eventCount: 0,
            insightCount: 0,
            lastUsed: event.timestamp,
            trending: false,
          };
        }
        tagStats[tag].eventCount += 1;
        if (event.timestamp > tagStats[tag].lastUsed) {
          tagStats[tag].lastUsed = event.timestamp;
        }
      });
    });

    insights.forEach((insight: Insight) => {
      // Insights don't have direct tags, but we could extract from context
      const contextTag = insight.context.toLowerCase();
      if (tagStats[contextTag]) {
        tagStats[contextTag].insightCount += 1;
      }
    });

    // Mark trending tags (used in last 7 days)
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const sevenDaysTimestamp = sevenDaysAgo.toISOString();

    Object.values(tagStats).forEach((stat: TagAnalytics) => {
      stat.trending = stat.lastUsed > sevenDaysTimestamp;
    });

    return Object.values(tagStats).sort((a: TagAnalytics, b: TagAnalytics) => 
      (b.eventCount + b.insightCount) - (a.eventCount + a.insightCount)
    );
  }

  // ============================================
  // MOOD CORRELATIONS
  // ============================================

  analyzeMoodPatterns(moodEntries: MoodEntry[]): {
    averageMood: number;
    averageEnergy: number;
    moodTrend: "improving" | "stable" | "declining";
    topActivities: string[];
  } {
    if (moodEntries.length === 0) {
      return {
        averageMood: 0,
        averageEnergy: 0,
        moodTrend: "stable",
        topActivities: [],
      };
    }

    const moodValues: Record<string, number> = {
      terrible: 1,
      bad: 2,
      neutral: 3,
      good: 4,
      amazing: 5,
    };

    const energyValues: Record<string, number> = {
      exhausted: 1,
      low: 2,
      moderate: 3,
      high: 4,
      peak: 5,
    };

    let totalMood = 0;
    let totalEnergy = 0;
    const activityCount: Record<string, number> = {};

    moodEntries.forEach((entry: MoodEntry) => {
      totalMood += moodValues[entry.mood];
      totalEnergy += energyValues[entry.energy];
      entry.activities.forEach((activity: string) => {
        activityCount[activity] = (activityCount[activity] || 0) + 1;
      });
    });

    const averageMood = totalMood / moodEntries.length;
    const averageEnergy = totalEnergy / moodEntries.length;

    // Calculate trend (compare first half vs second half)
    const midpoint = Math.floor(moodEntries.length / 2);
    const firstHalf = moodEntries.slice(0, midpoint);
    const secondHalf = moodEntries.slice(midpoint);

    const firstHalfAvg = firstHalf.reduce(
      (sum: number, e: MoodEntry) => sum + moodValues[e.mood], 
      0
    ) / firstHalf.length;
    const secondHalfAvg = secondHalf.reduce(
      (sum: number, e: MoodEntry) => sum + moodValues[e.mood], 
      0
    ) / secondHalf.length;

    let moodTrend: "improving" | "stable" | "declining" = "stable";
    if (secondHalfAvg > firstHalfAvg + 0.3) moodTrend = "improving";
    else if (secondHalfAvg < firstHalfAvg - 0.3) moodTrend = "declining";

    const topActivities = Object.entries(activityCount)
      .sort((a: [string, number], b: [string, number]) => b[1] - a[1])
      .slice(0, 5)
      .map((entry: [string, number]) => entry[0]);

    return {
      averageMood,
      averageEnergy,
      moodTrend,
      topActivities,
    };
  }

  // ============================================
  // PRODUCTIVITY INSIGHTS
  // ============================================

  generateProductivityInsights(events: MemoryEvent[]): string[] {
    const insights: string[] = [];

    // Analyze by hour of day
    const hourCounts: Record<string, number> = {};
    events.forEach((event: MemoryEvent) => {
      const hour = new Date(event.timestamp).getHours();
      hourCounts[hour] = (hourCounts[hour] || 0) + 1;
    });

    const peakHour = Object.entries(hourCounts).sort(
      (a: [string, number], b: [string, number]) => b[1] - a[1]
    )[0];
    if (peakHour) {
      insights.push(`Most productive hour: ${peakHour[0]}:00 with ${peakHour[1]} events`);
    }

    // Analyze by day of week
    const dayCounts: Record<string, number> = {};
    const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    events.forEach((event: MemoryEvent) => {
      const day = new Date(event.timestamp).getDay();
      const dayName = dayNames[day];
      dayCounts[dayName] = (dayCounts[dayName] || 0) + 1;
    });

    const peakDay = Object.entries(dayCounts).sort(
      (a: [string, number], b: [string, number]) => b[1] - a[1]
    )[0];
    if (peakDay) {
      insights.push(`Most active day: ${peakDay[0]} with ${peakDay[1]} events`);
    }

    // Event type distribution
    const typeCounts: Record<string, number> = {};
    events.forEach((event: MemoryEvent) => {
      typeCounts[event.eventType] = (typeCounts[event.eventType] || 0) + 1;
    });

    const topType = Object.entries(typeCounts).sort(
      (a: [string, number], b: [string, number]) => b[1] - a[1]
    )[0];
    if (topType) {
      insights.push(`Most common event type: ${topType[0]} (${topType[1]} events)`);
    }

    return insights;
  }

  // ============================================
  // STREAK CALCULATION
  // ============================================

  calculateStreak(dates: string[]): {
    current: number;
    longest: number;
  } {
    if (dates.length === 0) return { current: 0, longest: 0 };

    const sortedDates = [...dates].sort((a: string, b: string) => a.localeCompare(b));
    let currentStreak = 1;
    let longestStreak = 1;
    let tempStreak = 1;

    for (let i = 1; i < sortedDates.length; i++) {
      const prevDate = new Date(sortedDates[i - 1]);
      const currDate = new Date(sortedDates[i]);
      const diffDays = Math.floor(
        (currDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24)
      );

      if (diffDays === 1) {
        tempStreak += 1;
        longestStreak = Math.max(longestStreak, tempStreak);
      } else if (diffDays > 1) {
        tempStreak = 1;
      }
    }

    // Check if streak continues to today
    const lastDate = new Date(sortedDates[sortedDates.length - 1]);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const diffDays = Math.floor(
      (today.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24)
    );

    currentStreak = diffDays <= 1 ? tempStreak : 0;

    return { current: currentStreak, longest: longestStreak };
  }

  // ============================================
  // PREDICTION & RECOMMENDATIONS
  // ============================================

  generateRecommendations(
    events: MemoryEvent[],
    insights: Insight[]
  ): string[] {
    const recommendations: string[] = [];

    // Check if user is logging regularly
    const last7Days = new Date();
    last7Days.setDate(last7Days.getDate() - 7);
    const recentEvents = events.filter(
      (e: MemoryEvent) => e.timestamp > last7Days.toISOString()
    );

    if (recentEvents.length < 7) {
      recommendations.push("Try logging at least one event per day to build a comprehensive memory vault");
    }

    // Check for insights
    const recentInsights = insights.filter(
      (i: Insight) => i.timestamp > last7Days.toISOString()
    );

    if (recentInsights.length === 0 && recentEvents.length > 10) {
      recommendations.push("You have many events but no insights - consider creating insights to capture learnings");
    }

    // Check for high-importance events
    const criticalEvents = events.filter(
      (e: MemoryEvent) => e.importanceLevel === "critical"
    );

    if (criticalEvents.length > 0) {
      recommendations.push(`${criticalEvents.length} critical events logged - consider creating a thread to track this narrative`);
    }

    // Check for unused tags
    const allTags = new Set<string>();
    events.forEach((e: MemoryEvent) => e.tags.forEach((t: string) => allTags.add(t)));

    if (allTags.size > 20) {
      recommendations.push("You have many tags - consider consolidating similar tags for better organization");
    }

    return recommendations;
  }
}

export const analyticsEngine = new AnalyticsEngine();
