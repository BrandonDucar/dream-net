import type {
  MemoryEvent,
  StateSnapshot,
  MemoryThread,
  Insight,
  DailyLog,
  EventFilter,
  GeneralFilter,
  SearchResult,
} from "@/types/memory";

const STORAGE_KEYS = {
  EVENTS: "dreamnet_memory_events",
  SNAPSHOTS: "dreamnet_memory_snapshots",
  THREADS: "dreamnet_memory_threads",
  INSIGHTS: "dreamnet_memory_insights",
  DAILY_LOGS: "dreamnet_memory_daily_logs",
} as const;

class MemoryStore {
  private getFromStorage<T>(key: string): T[] {
    if (typeof window === "undefined") return [];
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  private saveToStorage<T>(key: string, data: T[]): void {
    if (typeof window === "undefined") return;
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
      console.error(`Failed to save to ${key}:`, error);
    }
  }

  // ============================================
  // MEMORY EVENTS
  // ============================================

  getEvents(): MemoryEvent[] {
    return this.getFromStorage<MemoryEvent>(STORAGE_KEYS.EVENTS);
  }

  getEvent(id: string): MemoryEvent | null {
    const events = this.getEvents();
    return events.find((e: MemoryEvent) => e.id === id) || null;
  }

  saveEvent(event: MemoryEvent): void {
    const events = this.getEvents();
    const index = events.findIndex((e: MemoryEvent) => e.id === event.id);
    if (index >= 0) {
      events[index] = event;
    } else {
      events.push(event);
    }
    this.saveToStorage(STORAGE_KEYS.EVENTS, events);
  }

  deleteEvent(id: string): void {
    const events = this.getEvents().filter((e: MemoryEvent) => e.id !== id);
    this.saveToStorage(STORAGE_KEYS.EVENTS, events);
  }

  filterEvents(filter: EventFilter): MemoryEvent[] {
    let events = this.getEvents();

    if (filter.eventType) {
      events = events.filter((e: MemoryEvent) => e.eventType === filter.eventType);
    }
    if (filter.sourceApp) {
      events = events.filter((e: MemoryEvent) => e.sourceApp === filter.sourceApp);
    }
    if (filter.tag) {
      events = events.filter((e: MemoryEvent) => e.tags.includes(filter.tag!));
    }
    if (filter.importanceLevel) {
      events = events.filter((e: MemoryEvent) => e.importanceLevel === filter.importanceLevel);
    }
    if (filter.dateFrom) {
      events = events.filter((e: MemoryEvent) => e.timestamp >= filter.dateFrom!);
    }
    if (filter.dateTo) {
      events = events.filter((e: MemoryEvent) => e.timestamp <= filter.dateTo!);
    }

    return events.sort((a: MemoryEvent, b: MemoryEvent) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  // ============================================
  // STATE SNAPSHOTS
  // ============================================

  getSnapshots(): StateSnapshot[] {
    return this.getFromStorage<StateSnapshot>(STORAGE_KEYS.SNAPSHOTS);
  }

  getSnapshot(id: string): StateSnapshot | null {
    const snapshots = this.getSnapshots();
    return snapshots.find((s: StateSnapshot) => s.id === id) || null;
  }

  saveSnapshot(snapshot: StateSnapshot): void {
    const snapshots = this.getSnapshots();
    const index = snapshots.findIndex((s: StateSnapshot) => s.id === snapshot.id);
    if (index >= 0) {
      snapshots[index] = snapshot;
    } else {
      snapshots.push(snapshot);
    }
    this.saveToStorage(STORAGE_KEYS.SNAPSHOTS, snapshots);
  }

  deleteSnapshot(id: string): void {
    const snapshots = this.getSnapshots().filter((s: StateSnapshot) => s.id !== id);
    this.saveToStorage(STORAGE_KEYS.SNAPSHOTS, snapshots);
  }

  filterSnapshots(filter: GeneralFilter): StateSnapshot[] {
    let snapshots = this.getSnapshots();

    if (filter.tag) {
      snapshots = snapshots.filter((s: StateSnapshot) => s.tags.includes(filter.tag!));
    }
    if (filter.dateFrom) {
      snapshots = snapshots.filter((s: StateSnapshot) => s.timestamp >= filter.dateFrom!);
    }
    if (filter.dateTo) {
      snapshots = snapshots.filter((s: StateSnapshot) => s.timestamp <= filter.dateTo!);
    }

    return snapshots.sort((a: StateSnapshot, b: StateSnapshot) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  // ============================================
  // MEMORY THREADS
  // ============================================

  getThreads(): MemoryThread[] {
    return this.getFromStorage<MemoryThread>(STORAGE_KEYS.THREADS);
  }

  getThread(id: string): MemoryThread | null {
    const threads = this.getThreads();
    return threads.find((t: MemoryThread) => t.id === id) || null;
  }

  saveThread(thread: MemoryThread): void {
    const threads = this.getThreads();
    const index = threads.findIndex((t: MemoryThread) => t.id === thread.id);
    if (index >= 0) {
      threads[index] = thread;
    } else {
      threads.push(thread);
    }
    this.saveToStorage(STORAGE_KEYS.THREADS, threads);
  }

  deleteThread(id: string): void {
    const threads = this.getThreads().filter((t: MemoryThread) => t.id !== id);
    this.saveToStorage(STORAGE_KEYS.THREADS, threads);
  }

  addEventToThread(threadId: string, eventId: string): void {
    const thread = this.getThread(threadId);
    if (thread && !thread.eventIds.includes(eventId)) {
      thread.eventIds.push(eventId);
      this.saveThread(thread);
    }
  }

  removeEventFromThread(threadId: string, eventId: string): void {
    const thread = this.getThread(threadId);
    if (thread) {
      thread.eventIds = thread.eventIds.filter((id: string) => id !== eventId);
      this.saveThread(thread);
    }
  }

  filterThreads(filter: GeneralFilter): MemoryThread[] {
    let threads = this.getThreads();

    if (filter.tag) {
      threads = threads.filter((t: MemoryThread) => t.tags.includes(filter.tag!));
    }

    return threads;
  }

  // ============================================
  // INSIGHTS
  // ============================================

  getInsights(): Insight[] {
    return this.getFromStorage<Insight>(STORAGE_KEYS.INSIGHTS);
  }

  getInsight(id: string): Insight | null {
    const insights = this.getInsights();
    return insights.find((i: Insight) => i.id === id) || null;
  }

  saveInsight(insight: Insight): void {
    const insights = this.getInsights();
    const index = insights.findIndex((i: Insight) => i.id === insight.id);
    if (index >= 0) {
      insights[index] = insight;
    } else {
      insights.push(insight);
    }
    this.saveToStorage(STORAGE_KEYS.INSIGHTS, insights);
  }

  deleteInsight(id: string): void {
    const insights = this.getInsights().filter((i: Insight) => i.id !== id);
    this.saveToStorage(STORAGE_KEYS.INSIGHTS, insights);
  }

  filterInsights(filter: GeneralFilter): Insight[] {
    let insights = this.getInsights();

    if (filter.dateFrom) {
      insights = insights.filter((i: Insight) => i.timestamp >= filter.dateFrom!);
    }
    if (filter.dateTo) {
      insights = insights.filter((i: Insight) => i.timestamp <= filter.dateTo!);
    }

    return insights.sort((a: Insight, b: Insight) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  // ============================================
  // DAILY LOGS
  // ============================================

  getDailyLogs(): DailyLog[] {
    return this.getFromStorage<DailyLog>(STORAGE_KEYS.DAILY_LOGS);
  }

  getDailyLog(id: string): DailyLog | null {
    const logs = this.getDailyLogs();
    return logs.find((l: DailyLog) => l.id === id) || null;
  }

  getDailyLogByDate(date: string): DailyLog | null {
    const logs = this.getDailyLogs();
    return logs.find((l: DailyLog) => l.date === date) || null;
  }

  saveDailyLog(log: DailyLog): void {
    const logs = this.getDailyLogs();
    const index = logs.findIndex((l: DailyLog) => l.id === log.id);
    if (index >= 0) {
      logs[index] = log;
    } else {
      logs.push(log);
    }
    this.saveToStorage(STORAGE_KEYS.DAILY_LOGS, logs);
  }

  deleteDailyLog(id: string): void {
    const logs = this.getDailyLogs().filter((l: DailyLog) => l.id !== id);
    this.saveToStorage(STORAGE_KEYS.DAILY_LOGS, logs);
  }

  filterDailyLogs(filter: GeneralFilter): DailyLog[] {
    let logs = this.getDailyLogs();

    if (filter.dateFrom) {
      logs = logs.filter((l: DailyLog) => l.date >= filter.dateFrom!);
    }
    if (filter.dateTo) {
      logs = logs.filter((l: DailyLog) => l.date <= filter.dateTo!);
    }

    return logs.sort((a: DailyLog, b: DailyLog) => 
      b.date.localeCompare(a.date)
    );
  }

  // ============================================
  // SEARCH
  // ============================================

  search(queryText: string): SearchResult[] {
    const query = queryText.toLowerCase();
    const results: SearchResult[] = [];

    // Search events
    const events = this.getEvents();
    events.forEach((event: MemoryEvent) => {
      const matchTitle = event.title.toLowerCase().includes(query);
      const matchDesc = event.description.toLowerCase().includes(query);
      const matchTags = event.tags.some((tag: string) => tag.toLowerCase().includes(query));

      if (matchTitle || matchDesc || matchTags) {
        results.push({
          type: "event",
          id: event.id,
          title: event.title,
          snippet: event.description.substring(0, 100),
        });
      }
    });

    // Search insights
    const insights = this.getInsights();
    insights.forEach((insight: Insight) => {
      const matchSummary = insight.summary.toLowerCase().includes(query);
      const matchDetails = insight.details.toLowerCase().includes(query);

      if (matchSummary || matchDetails) {
        results.push({
          type: "insight",
          id: insight.id,
          title: insight.summary,
          snippet: insight.details.substring(0, 100),
        });
      }
    });

    // Search threads
    const threads = this.getThreads();
    threads.forEach((thread: MemoryThread) => {
      const matchName = thread.name.toLowerCase().includes(query);
      const matchDesc = thread.description.toLowerCase().includes(query);
      const matchTags = thread.tags.some((tag: string) => tag.toLowerCase().includes(query));

      if (matchName || matchDesc || matchTags) {
        results.push({
          type: "thread",
          id: thread.id,
          title: thread.name,
          snippet: thread.description.substring(0, 100),
        });
      }
    });

    // Search daily logs
    const logs = this.getDailyLogs();
    logs.forEach((log: DailyLog) => {
      const matchSummary = log.summary.toLowerCase().includes(query);
      const matchHighlights = log.highlights.some((h: string) => 
        h.toLowerCase().includes(query)
      );

      if (matchSummary || matchHighlights) {
        results.push({
          type: "daily",
          id: log.id,
          title: `Daily Log: ${log.date}`,
          snippet: log.summary.substring(0, 100),
        });
      }
    });

    return results;
  }

  // ============================================
  // TIMELINE GENERATION
  // ============================================

  generateTimeline(filter: GeneralFilter): string {
    const events = this.filterEvents(filter);
    let timeline = "=== DreamNet Memory Timeline ===\n\n";

    events.forEach((event: MemoryEvent) => {
      const date = new Date(event.timestamp).toISOString().split("T")[0];
      timeline += `[${date}] ${event.title}\n`;
      timeline += `  - ${event.description}\n`;
      if (event.relatedObjectType && event.relatedObjectId) {
        timeline += `  - Related: ${event.relatedObjectType} (${event.relatedObjectId})\n`;
      }
      if (event.tags.length > 0) {
        timeline += `  - Tags: ${event.tags.join(", ")}\n`;
      }
      timeline += "\n";
    });

    return timeline;
  }

  // ============================================
  // EXPORT
  // ============================================

  exportMemoryBundle(): string {
    const events = this.getEvents();
    const snapshots = this.getSnapshots();
    const threads = this.getThreads();
    const insights = this.getInsights();
    const logs = this.getDailyLogs();

    const bundle = {
      version: "DreamNet Memory Vault v1",
      exportDate: new Date().toISOString(),
      events,
      snapshots,
      threads,
      insights,
      dailyLogs: logs,
    };

    return JSON.stringify(bundle, null, 2);
  }

  // ============================================
  // UTILITY
  // ============================================

  getThreadsForEvent(eventId: string): MemoryThread[] {
    const threads = this.getThreads();
    return threads.filter((t: MemoryThread) => t.eventIds.includes(eventId));
  }

  getAllTags(): string[] {
    const tags = new Set<string>();
    
    this.getEvents().forEach((e: MemoryEvent) => e.tags.forEach((t: string) => tags.add(t)));
    this.getSnapshots().forEach((s: StateSnapshot) => s.tags.forEach((t: string) => tags.add(t)));
    this.getThreads().forEach((t: MemoryThread) => t.tags.forEach((tag: string) => tags.add(tag)));
    
    return Array.from(tags).sort();
  }

  getAllSourceApps(): string[] {
    const apps = new Set<string>();
    this.getEvents().forEach((e: MemoryEvent) => {
      if (e.sourceApp) apps.add(e.sourceApp);
    });
    return Array.from(apps).sort();
  }
}

export const memoryStore = new MemoryStore();
