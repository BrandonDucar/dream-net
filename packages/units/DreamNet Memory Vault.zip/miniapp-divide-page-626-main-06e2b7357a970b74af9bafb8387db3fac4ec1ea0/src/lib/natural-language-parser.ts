// Natural Language Parser - Convert conversational text to structured events

import type { EventType } from "@/types/memory";
import type { ParsedInput } from "@/types/memory-extended";

export class NaturalLanguageParser {
  // ============================================
  // KEYWORD PATTERNS
  // ============================================

  private eventTypeKeywords: Record<EventType, string[]> = {
    "object-created": ["created", "added", "made", "built", "generated", "new"],
    "object-updated": ["updated", "modified", "changed", "edited", "revised"],
    "state-change": ["changed to", "became", "transitioned", "moved to", "status"],
    "flow-step-completed": ["completed", "finished", "done with", "wrapped up"],
    "scenario-run": ["ran", "executed", "tested", "simulated"],
    "agent-action": ["agent", "bot", "automated", "processed"],
    "decision": ["decided", "chose", "selected", "picked", "went with"],
    "insight": ["realized", "learned", "discovered", "noticed", "observed"],
    "note": ["note", "remember", "reminder", "thought"],
    "other": [],
  };

  private tagKeywords: Record<string, string[]> = {
    culture: ["culture", "community", "social", "people"],
    ops: ["ops", "operations", "process", "workflow"],
    pickleball: ["pickleball", "sport", "game", "match"],
    distribution: ["distribution", "sharing", "spreading"],
    tech: ["tech", "technology", "code", "development"],
    personal: ["personal", "life", "self"],
  };

  // ============================================
  // PARSE INPUT
  // ============================================

  parse(input: string): ParsedInput {
    const lowerInput = input.toLowerCase();
    
    // Detect event type
    let detectedEventType: EventType = "note";
    let maxMatchCount = 0;

    Object.entries(this.eventTypeKeywords).forEach(
      ([eventType, keywords]: [string, string[]]) => {
        const matchCount = keywords.filter((keyword: string) => 
          lowerInput.includes(keyword.toLowerCase())
        ).length;

        if (matchCount > maxMatchCount) {
          maxMatchCount = matchCount;
          detectedEventType = eventType as EventType;
        }
      }
    );

    // Extract title (first sentence or up to 50 chars)
    let title = input.split(/[.!?]/)[0].trim();
    if (title.length > 50) {
      title = title.substring(0, 50).trim() + "...";
    }

    // Description is the full input
    const description = input;

    // Detect tags
    const detectedTags: string[] = [];
    Object.entries(this.tagKeywords).forEach(
      ([tag, keywords]: [string, string[]]) => {
        if (keywords.some((keyword: string) => lowerInput.includes(keyword))) {
          detectedTags.push(tag);
        }
      }
    );

    // Detect timestamp mentions
    const timestampMatch = this.extractTimestamp(input);

    // Calculate confidence
    let confidence = 0.5; // baseline
    if (maxMatchCount > 0) confidence += 0.2;
    if (detectedTags.length > 0) confidence += 0.2;
    if (timestampMatch) confidence += 0.1;
    confidence = Math.min(confidence, 1.0);

    return {
      eventType: detectedEventType,
      title,
      description,
      tags: detectedTags,
      timestamp: timestampMatch,
      confidence,
    };
  }

  // ============================================
  // EXTRACT TIMESTAMP
  // ============================================

  private extractTimestamp(input: string): string | null {
    const lowerInput = input.toLowerCase();

    // Check for "today"
    if (lowerInput.includes("today")) {
      return new Date().toISOString();
    }

    // Check for "yesterday"
    if (lowerInput.includes("yesterday")) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      return yesterday.toISOString();
    }

    // Check for "last week"
    if (lowerInput.includes("last week")) {
      const lastWeek = new Date();
      lastWeek.setDate(lastWeek.getDate() - 7);
      return lastWeek.toISOString();
    }

    // Check for specific time mentions (e.g., "at 3pm")
    const timeMatch = lowerInput.match(/at\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/);
    if (timeMatch) {
      const now = new Date();
      let hours = parseInt(timeMatch[1]);
      const minutes = timeMatch[2] ? parseInt(timeMatch[2]) : 0;
      const meridiem = timeMatch[3];

      if (meridiem === "pm" && hours < 12) hours += 12;
      if (meridiem === "am" && hours === 12) hours = 0;

      now.setHours(hours, minutes, 0, 0);
      return now.toISOString();
    }

    return null;
  }

  // ============================================
  // SUGGEST IMPROVEMENTS
  // ============================================

  suggestImprovements(parsed: ParsedInput): string[] {
    const suggestions: string[] = [];

    if (parsed.confidence < 0.7) {
      suggestions.push("Try adding more specific keywords to help me understand better");
    }

    if (parsed.tags.length === 0) {
      suggestions.push("Consider mentioning tags like 'culture', 'ops', or 'tech' to categorize this event");
    }

    if (!parsed.timestamp) {
      suggestions.push("You can mention 'today', 'yesterday', or a specific time like 'at 3pm'");
    }

    if (parsed.description.length < 20) {
      suggestions.push("Adding more details will make this memory more valuable later");
    }

    return suggestions;
  }

  // ============================================
  // EXAMPLE TEMPLATES
  // ============================================

  getExampleInputs(): string[] {
    return [
      "Created a new Drop for the culture expansion project",
      "Agent processed the pickleball signup flow at 2pm",
      "Realized that community engagement is highest on Thursdays",
      "Updated the ops dashboard with new metrics",
      "Decided to focus on distribution channels next week",
      "Made a note to review the tech stack decisions",
      "Completed the onboarding flow for new members",
      "Changed status to active for the campaign",
    ];
  }
}

export const nlParser = new NaturalLanguageParser();
