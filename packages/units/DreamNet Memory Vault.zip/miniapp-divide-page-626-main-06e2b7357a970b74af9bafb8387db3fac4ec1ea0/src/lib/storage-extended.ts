// Extended storage for new data types

import type {
  MoodEntry,
  Habit,
  HabitLog,
  QuickButton,
  Goal,
  Person,
  TimeSession,
  CustomDashboard,
  AutomationRule,
  UserPreferences,
} from "@/types/memory-extended";

const EXTENDED_STORAGE_KEYS = {
  MOOD_ENTRIES: "dreamnet_mood_entries",
  HABITS: "dreamnet_habits",
  HABIT_LOGS: "dreamnet_habit_logs",
  QUICK_BUTTONS: "dreamnet_quick_buttons",
  GOALS: "dreamnet_goals",
  PEOPLE: "dreamnet_people",
  TIME_SESSIONS: "dreamnet_time_sessions",
  DASHBOARDS: "dreamnet_dashboards",
  AUTOMATION_RULES: "dreamnet_automation_rules",
  USER_PREFERENCES: "dreamnet_user_preferences",
} as const;

class ExtendedStorage {
  private getFromStorage<T>(key: string): T[] {
    if (typeof window === "undefined") return [];
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  private saveToStorage<T>(key: string, data: T[]): void {
    if (typeof window === "undefined") return;
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
      console.error(`Failed to save to ${key}:`, error);
    }
  }

  private getSingleFromStorage<T>(key: string, defaultValue: T): T {
    if (typeof window === "undefined") return defaultValue;
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : defaultValue;
    } catch {
      return defaultValue;
    }
  }

  private saveSingleToStorage<T>(key: string, data: T): void {
    if (typeof window === "undefined") return;
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
      console.error(`Failed to save to ${key}:`, error);
    }
  }

  // ============================================
  // MOOD ENTRIES
  // ============================================

  getMoodEntries(): MoodEntry[] {
    return this.getFromStorage<MoodEntry>(EXTENDED_STORAGE_KEYS.MOOD_ENTRIES);
  }

  saveMoodEntry(entry: MoodEntry): void {
    const entries = this.getMoodEntries();
    const index = entries.findIndex((e: MoodEntry) => e.id === entry.id);
    if (index >= 0) {
      entries[index] = entry;
    } else {
      entries.push(entry);
    }
    this.saveToStorage(EXTENDED_STORAGE_KEYS.MOOD_ENTRIES, entries);
  }

  deleteMoodEntry(id: string): void {
    const entries = this.getMoodEntries().filter((e: MoodEntry) => e.id !== id);
    this.saveToStorage(EXTENDED_STORAGE_KEYS.MOOD_ENTRIES, entries);
  }

  // ============================================
  // HABITS
  // ============================================

  getHabits(): Habit[] {
    return this.getFromStorage<Habit>(EXTENDED_STORAGE_KEYS.HABITS);
  }

  getHabit(id: string): Habit | null {
    return this.getHabits().find((h: Habit) => h.id === id) || null;
  }

  saveHabit(habit: Habit): void {
    const habits = this.getHabits();
    const index = habits.findIndex((h: Habit) => h.id === habit.id);
    if (index >= 0) {
      habits[index] = habit;
    } else {
      habits.push(habit);
    }
    this.saveToStorage(EXTENDED_STORAGE_KEYS.HABITS, habits);
  }

  deleteHabit(id: string): void {
    const habits = this.getHabits().filter((h: Habit) => h.id !== id);
    this.saveToStorage(EXTENDED_STORAGE_KEYS.HABITS, habits);
  }

  // ============================================
  // HABIT LOGS
  // ============================================

  getHabitLogs(): HabitLog[] {
    return this.getFromStorage<HabitLog>(EXTENDED_STORAGE_KEYS.HABIT_LOGS);
  }

  getHabitLogsForHabit(habitId: string): HabitLog[] {
    return this.getHabitLogs().filter((log: HabitLog) => log.habitId === habitId);
  }

  saveHabitLog(log: HabitLog): void {
    const logs = this.getHabitLogs();
    const index = logs.findIndex((l: HabitLog) => l.id === log.id);
    if (index >= 0) {
      logs[index] = log;
    } else {
      logs.push(log);
    }
    this.saveToStorage(EXTENDED_STORAGE_KEYS.HABIT_LOGS, logs);
  }

  deleteHabitLog(id: string): void {
    const logs = this.getHabitLogs().filter((l: HabitLog) => l.id !== id);
    this.saveToStorage(EXTENDED_STORAGE_KEYS.HABIT_LOGS, logs);
  }

  // ============================================
  // QUICK BUTTONS
  // ============================================

  getQuickButtons(): QuickButton[] {
    return this.getFromStorage<QuickButton>(EXTENDED_STORAGE_KEYS.QUICK_BUTTONS);
  }

  saveQuickButton(button: QuickButton): void {
    const buttons = this.getQuickButtons();
    const index = buttons.findIndex((b: QuickButton) => b.id === button.id);
    if (index >= 0) {
      buttons[index] = button;
    } else {
      buttons.push(button);
    }
    this.saveToStorage(EXTENDED_STORAGE_KEYS.QUICK_BUTTONS, buttons);
  }

  deleteQuickButton(id: string): void {
    const buttons = this.getQuickButtons().filter((b: QuickButton) => b.id !== id);
    this.saveToStorage(EXTENDED_STORAGE_KEYS.QUICK_BUTTONS, buttons);
  }

  // ============================================
  // GOALS
  // ============================================

  getGoals(): Goal[] {
    return this.getFromStorage<Goal>(EXTENDED_STORAGE_KEYS.GOALS);
  }

  getGoal(id: string): Goal | null {
    return this.getGoals().find((g: Goal) => g.id === id) || null;
  }

  saveGoal(goal: Goal): void {
    const goals = this.getGoals();
    const index = goals.findIndex((g: Goal) => g.id === goal.id);
    if (index >= 0) {
      goals[index] = goal;
    } else {
      goals.push(goal);
    }
    this.saveToStorage(EXTENDED_STORAGE_KEYS.GOALS, goals);
  }

  deleteGoal(id: string): void {
    const goals = this.getGoals().filter((g: Goal) => g.id !== id);
    this.saveToStorage(EXTENDED_STORAGE_KEYS.GOALS, goals);
  }

  // ============================================
  // PEOPLE
  // ============================================

  getPeople(): Person[] {
    return this.getFromStorage<Person>(EXTENDED_STORAGE_KEYS.PEOPLE);
  }

  getPerson(id: string): Person | null {
    return this.getPeople().find((p: Person) => p.id === id) || null;
  }

  savePerson(person: Person): void {
    const people = this.getPeople();
    const index = people.findIndex((p: Person) => p.id === person.id);
    if (index >= 0) {
      people[index] = person;
    } else {
      people.push(person);
    }
    this.saveToStorage(EXTENDED_STORAGE_KEYS.PEOPLE, people);
  }

  deletePerson(id: string): void {
    const people = this.getPeople().filter((p: Person) => p.id !== id);
    this.saveToStorage(EXTENDED_STORAGE_KEYS.PEOPLE, people);
  }

  // ============================================
  // TIME SESSIONS
  // ============================================

  getTimeSessions(): TimeSession[] {
    return this.getFromStorage<TimeSession>(EXTENDED_STORAGE_KEYS.TIME_SESSIONS);
  }

  saveTimeSession(session: TimeSession): void {
    const sessions = this.getTimeSessions();
    const index = sessions.findIndex((s: TimeSession) => s.id === session.id);
    if (index >= 0) {
      sessions[index] = session;
    } else {
      sessions.push(session);
    }
    this.saveToStorage(EXTENDED_STORAGE_KEYS.TIME_SESSIONS, sessions);
  }

  deleteTimeSession(id: string): void {
    const sessions = this.getTimeSessions().filter((s: TimeSession) => s.id !== id);
    this.saveToStorage(EXTENDED_STORAGE_KEYS.TIME_SESSIONS, sessions);
  }

  getActiveTimeSession(): TimeSession | null {
    const sessions = this.getTimeSessions();
    return sessions.find((s: TimeSession) => s.endTime === null) || null;
  }

  // ============================================
  // CUSTOM DASHBOARDS
  // ============================================

  getDashboards(): CustomDashboard[] {
    return this.getFromStorage<CustomDashboard>(EXTENDED_STORAGE_KEYS.DASHBOARDS);
  }

  saveDashboard(dashboard: CustomDashboard): void {
    const dashboards = this.getDashboards();
    const index = dashboards.findIndex((d: CustomDashboard) => d.id === dashboard.id);
    if (index >= 0) {
      dashboards[index] = dashboard;
    } else {
      dashboards.push(dashboard);
    }
    this.saveToStorage(EXTENDED_STORAGE_KEYS.DASHBOARDS, dashboards);
  }

  deleteDashboard(id: string): void {
    const dashboards = this.getDashboards().filter((d: CustomDashboard) => d.id !== id);
    this.saveToStorage(EXTENDED_STORAGE_KEYS.DASHBOARDS, dashboards);
  }

  // ============================================
  // AUTOMATION RULES
  // ============================================

  getAutomationRules(): AutomationRule[] {
    return this.getFromStorage<AutomationRule>(EXTENDED_STORAGE_KEYS.AUTOMATION_RULES);
  }

  saveAutomationRule(rule: AutomationRule): void {
    const rules = this.getAutomationRules();
    const index = rules.findIndex((r: AutomationRule) => r.id === rule.id);
    if (index >= 0) {
      rules[index] = rule;
    } else {
      rules.push(rule);
    }
    this.saveToStorage(EXTENDED_STORAGE_KEYS.AUTOMATION_RULES, rules);
  }

  deleteAutomationRule(id: string): void {
    const rules = this.getAutomationRules().filter((r: AutomationRule) => r.id !== id);
    this.saveToStorage(EXTENDED_STORAGE_KEYS.AUTOMATION_RULES, rules);
  }

  // ============================================
  // USER PREFERENCES
  // ============================================

  getUserPreferences(): UserPreferences {
    return this.getSingleFromStorage<UserPreferences>(
      EXTENDED_STORAGE_KEYS.USER_PREFERENCES,
      {
        theme: "light",
        defaultView: "dashboard",
        dateFormat: "YYYY-MM-DD",
        timeFormat: "24h",
        enableNotifications: true,
        enableAnalytics: true,
        exportFormat: "json",
        keyboardShortcutsEnabled: true,
        autoBackup: false,
        backupFrequency: "weekly",
      }
    );
  }

  saveUserPreferences(prefs: UserPreferences): void {
    this.saveSingleToStorage(EXTENDED_STORAGE_KEYS.USER_PREFERENCES, prefs);
  }
}

export const extendedStorage = new ExtendedStorage();
