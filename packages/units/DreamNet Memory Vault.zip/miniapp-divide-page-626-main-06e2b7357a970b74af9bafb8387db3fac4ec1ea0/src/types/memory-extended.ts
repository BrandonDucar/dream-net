// Extended types for advanced features

import type { EventType, ImportanceLevel, ImpactLevel } from "./memory";

// ============================================
// MOOD & ENERGY TRACKING
// ============================================

export type MoodType = "amazing" | "good" | "neutral" | "bad" | "terrible";
export type EnergyLevel = "exhausted" | "low" | "moderate" | "high" | "peak";

export interface MoodEntry {
  id: string;
  timestamp: string;
  mood: MoodType;
  energy: EnergyLevel;
  notes: string;
  activities: string[]; // What were you doing?
  location: string | null; // Optional location context
  weather: string | null; // Optional weather
  relatedEventIds: string[]; // Link to events
}

// ============================================
// HABIT TRACKING
// ============================================

export type HabitFrequency = "daily" | "weekly" | "custom";

export interface Habit {
  id: string;
  name: string;
  description: string;
  icon: string; // emoji or icon name
  color: string; // hex color
  frequency: HabitFrequency;
  targetCount: number; // how many times per period
  createdDate: string;
  archived: boolean;
  tags: string[];
  notes: string;
}

export interface HabitLog {
  id: string;
  habitId: string;
  timestamp: string;
  value: number; // 1 for completion, or custom value
  notes: string;
}

export interface HabitStreak {
  habitId: string;
  currentStreak: number;
  longestStreak: number;
  lastLogDate: string;
}

// ============================================
// QUICK CAPTURE BUTTONS (Nomie-style)
// ============================================

export type QuickButtonAction = "increment" | "log-event" | "timer";

export interface QuickButton {
  id: string;
  label: string;
  emoji: string;
  color: string;
  action: QuickButtonAction;
  eventType: EventType;
  tags: string[];
  sourceApp: string | null;
  order: number; // for sorting
  archived: boolean;
}

// ============================================
// RICH MEDIA
// ============================================

export type MediaType = "image" | "audio" | "video" | "file";

export interface MediaAttachment {
  id: string;
  type: MediaType;
  url: string; // data URL or external URL
  filename: string;
  size: number; // bytes
  mimeType: string;
  uploadedAt: string;
  thumbnail: string | null; // for images/videos
}

// ============================================
// GOALS & MILESTONES
// ============================================

export type GoalStatus = "not-started" | "in-progress" | "completed" | "abandoned";

export interface Goal {
  id: string;
  title: string;
  description: string;
  status: GoalStatus;
  targetDate: string | null;
  startDate: string;
  completedDate: string | null;
  tags: string[];
  milestones: Milestone[];
  relatedEventIds: string[];
  notes: string;
}

export interface Milestone {
  id: string;
  title: string;
  completed: boolean;
  completedDate: string | null;
  order: number;
}

// ============================================
// RELATIONSHIPS & CONNECTIONS
// ============================================

export interface Person {
  id: string;
  name: string;
  description: string;
  tags: string[];
  relatedEventIds: string[];
  lastInteraction: string | null;
  notes: string;
}

// ============================================
// TIME TRACKING
// ============================================

export interface TimeSession {
  id: string;
  title: string;
  description: string;
  startTime: string;
  endTime: string | null; // null if still running
  duration: number; // minutes
  tags: string[];
  sourceApp: string | null;
  eventId: string | null; // link to created event
}

// ============================================
// ANALYTICS
// ============================================

export interface EventPattern {
  eventType: EventType;
  count: number;
  averageImportance: number;
  topTags: string[];
  topApps: string[];
  timeDistribution: Record<string, number>; // hour of day -> count
}

export interface ActivityHeatmap {
  date: string;
  eventCount: number;
  insightCount: number;
  habitLogCount: number;
  totalActivity: number;
}

export interface TagAnalytics {
  tag: string;
  eventCount: number;
  insightCount: number;
  lastUsed: string;
  trending: boolean; // used more recently
}

// ============================================
// CUSTOM DASHBOARDS
// ============================================

export type WidgetType = 
  | "event-count"
  | "recent-events"
  | "mood-chart"
  | "habit-streaks"
  | "tag-cloud"
  | "timeline"
  | "insights"
  | "quick-stats"
  | "heatmap"
  | "on-this-day";

export interface DashboardWidget {
  id: string;
  type: WidgetType;
  title: string;
  config: Record<string, unknown>; // widget-specific config
  position: { x: number; y: number };
  size: { width: number; height: number };
}

export interface CustomDashboard {
  id: string;
  name: string;
  description: string;
  widgets: DashboardWidget[];
  isDefault: boolean;
}

// ============================================
// AUTOMATION RULES
// ============================================

export type TriggerType = "event-created" | "tag-added" | "time-based" | "habit-completed";
export type ActionType = "create-insight" | "add-to-thread" | "send-notification" | "create-snapshot";

export interface AutomationRule {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  trigger: {
    type: TriggerType;
    config: Record<string, unknown>;
  };
  action: {
    type: ActionType;
    config: Record<string, unknown>;
  };
  createdDate: string;
}

// ============================================
// SETTINGS & PREFERENCES
// ============================================

export interface UserPreferences {
  theme: "light" | "dark" | "auto";
  defaultView: string; // dashboard, events, etc.
  dateFormat: string;
  timeFormat: "12h" | "24h";
  enableNotifications: boolean;
  enableAnalytics: boolean;
  exportFormat: "json" | "csv" | "markdown";
  keyboardShortcutsEnabled: boolean;
  autoBackup: boolean;
  backupFrequency: "daily" | "weekly" | "monthly";
}

// ============================================
// GRAPH NODES FOR VISUALIZATION
// ============================================

export type NodeType = "event" | "insight" | "thread" | "person" | "tag" | "goal" | "habit";

export interface GraphNode {
  id: string;
  type: NodeType;
  label: string;
  metadata: Record<string, unknown>;
  connections: string[]; // IDs of connected nodes
}

export interface GraphEdge {
  source: string;
  target: string;
  type: string; // "contains", "related-to", "triggered-by", etc.
  weight: number; // strength of connection
}

// ============================================
// SEARCH ENHANCEMENTS
// ============================================

export interface AdvancedSearchFilter {
  query: string;
  types: NodeType[];
  dateRange: { from: string; to: string } | null;
  tags: string[];
  apps: string[];
  importance: ImportanceLevel[];
  impact: ImpactLevel[];
  hasMood: boolean;
  hasMedia: boolean;
  personIds: string[];
}

// ============================================
// IMPORT/EXPORT
// ============================================

export type ExportFormat = "json" | "csv" | "markdown" | "pdf";

export interface ExportOptions {
  format: ExportFormat;
  includeEvents: boolean;
  includeInsights: boolean;
  includeThreads: boolean;
  includeDailyLogs: boolean;
  includeSnapshots: boolean;
  includeHabits: boolean;
  includeMood: boolean;
  includeGoals: boolean;
  dateRange: { from: string; to: string } | null;
  tags: string[];
}

// ============================================
// NATURAL LANGUAGE INPUT
// ============================================

export interface ParsedInput {
  eventType: EventType;
  title: string;
  description: string;
  tags: string[];
  timestamp: string | null;
  confidence: number; // 0-1
}
