export type EventType =
  | "object-created"
  | "object-updated"
  | "state-change"
  | "flow-step-completed"
  | "scenario-run"
  | "agent-action"
  | "decision"
  | "insight"
  | "note"
  | "other";

export type ImportanceLevel = "low" | "medium" | "high" | "critical";
export type ImpactLevel = "low" | "medium" | "high" | "critical";

export interface MemoryEvent {
  id: string;
  timestamp: string;
  eventType: EventType;
  title: string;
  description: string;
  sourceApp: string | null;
  relatedObjectType: string | null;
  relatedObjectId: string | null;
  relatedAgentId: string | null;
  tags: string[];
  importanceLevel: ImportanceLevel;
  notes: string;
}

export interface StateSnapshot {
  id: string;
  timestamp: string;
  snapshotName: string;
  description: string;
  keyValues: Record<string, string | number>;
  tags: string[];
  notes: string;
}

export interface MemoryThread {
  id: string;
  name: string;
  description: string;
  tags: string[];
  eventIds: string[];
  notes: string;
}

export interface Insight {
  id: string;
  timestamp: string;
  summary: string;
  context: string;
  details: string;
  relatedObjects: string[];
  impactLevel: ImpactLevel;
  recommendedActions: string[];
  notes: string;
}

export interface DailyLog {
  id: string;
  date: string;
  summary: string;
  highlights: string[];
  tasksCompleted: string[];
  tasksDeferred: string[];
  insightsLogged: string[];
  stateSnapshotId: string | null;
  notes: string;
}

export interface SEOMeta {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export type SearchResultType = "event" | "insight" | "thread" | "daily";

export interface SearchResult {
  type: SearchResultType;
  id: string;
  title: string;
  snippet: string;
}

export interface EventFilter {
  eventType?: EventType;
  dateFrom?: string;
  dateTo?: string;
  sourceApp?: string;
  tag?: string;
  importanceLevel?: ImportanceLevel;
}

export interface GeneralFilter {
  dateFrom?: string;
  dateTo?: string;
  tag?: string;
}
