"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { listOpsObjects } from "@/lib/ops-data-service";
import { calculateResonanceScore, calculateEcosystemHealth } from "@/lib/analytics-service";
import { EcosystemHealthWidget } from "@/components/EcosystemHealthWidget";
import { ResonanceBadge } from "@/components/ResonanceBadge";
import { Sparkline } from "@/components/Sparkline";
import { getOpsMetricsByObject } from "@/lib/ops-data-service";

export default function AnalyticsPage() {
  const [objects, setObjects] = useState<ReturnType<typeof listOpsObjects>>([]);
  const [resonanceScores, setResonanceScores] = useState<
    Record<string, ReturnType<typeof calculateResonanceScore>>
  >({});

  useEffect(() => {
    loadData();
  }, []);

  function loadData(): void {
    const allObjects = listOpsObjects();
    setObjects(allObjects);

    // Calculate resonance for each object
    const scores: Record<string, ReturnType<typeof calculateResonanceScore>> = {};
    allObjects.forEach((obj) => {
      scores[obj.id] = calculateResonanceScore(obj.id);
    });
    setResonanceScores(scores);
  }

  // Get sparkline data for each object
  function getSparklineData(objectId: string): number[] {
    const metrics = getOpsMetricsByObject(objectId).slice(0, 7).reverse();
    return metrics.map((m) =>
      Object.values(m.keyNumbers).reduce((sum, val) => sum + val, 0)
    );
  }

  // Sort objects by resonance score
  const sortedObjects = [...objects].sort((a, b) => {
    const scoreA = resonanceScores[a.id]?.score || 0;
    const scoreB = resonanceScores[b.id]?.score || 0;
    return scoreB - scoreA;
  });

  // Group by resonance level
  const groupedByLevel = sortedObjects.reduce((acc, obj) => {
    const level = resonanceScores[obj.id]?.level || "dead";
    if (!acc[level]) acc[level] = [];
    acc[level].push(obj);
    return acc;
  }, {} as Record<string, typeof objects>);

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-7xl space-y-8">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <Link href="/">
              <Button variant="ghost" size="sm" className="mb-2">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Overview
              </Button>
            </Link>
            <h1 className="text-3xl font-bold tracking-tight">📊 Analytics Dashboard</h1>
            <p className="text-muted-foreground">Resonance scores and ecosystem health</p>
          </div>
        </div>

        {/* Ecosystem Health */}
        <EcosystemHealthWidget />

        {/* Resonance Scores by Level */}
        <div className="space-y-6">
          <div>
            <h2 className="text-2xl font-semibold mb-4">🔍 Resonance Analysis</h2>
            <p className="text-sm text-muted-foreground mb-6">
              All objects ranked by their cultural momentum and operational health
            </p>
          </div>

          {["hot", "rising", "steady", "cooling", "dead"].map((level) => {
            const levelObjects = groupedByLevel[level] || [];
            if (levelObjects.length === 0) return null;

            return (
              <Card key={level} className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <ResonanceBadge
                    level={level as "hot" | "rising" | "steady" | "cooling" | "dead"}
                    score={0}
                    showScore={false}
                  />
                  <h3 className="text-lg font-semibold capitalize">{level}</h3>
                  <span className="text-sm text-muted-foreground">
                    ({levelObjects.length} {levelObjects.length === 1 ? "object" : "objects"})
                  </span>
                </div>

                <div className="space-y-3">
                  {levelObjects.map((obj) => {
                    const resonance = resonanceScores[obj.id];
                    const sparklineData = getSparklineData(obj.id);

                    return (
                      <Link key={obj.id} href={`/objects/${obj.id}`}>
                        <div className="border rounded-lg p-4 hover:bg-accent/50 transition-colors cursor-pointer">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-3">
                              <span className="text-2xl">{obj.primaryEmoji || "•"}</span>
                              <div>
                                <h4 className="font-medium">{obj.name}</h4>
                                <p className="text-xs text-muted-foreground">
                                  {obj.type} • {obj.category || "Uncategorized"}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-4">
                              {sparklineData.length > 1 && (
                                <Sparkline
                                  data={sparklineData}
                                  trend={resonance?.trend}
                                />
                              )}
                              <div className="text-right">
                                <p className="text-2xl font-bold">
                                  {resonance?.score || 0}
                                </p>
                                <p className="text-xs text-muted-foreground">Score</p>
                              </div>
                            </div>
                          </div>

                          {/* Component Scores */}
                          {resonance && (
                            <div className="grid grid-cols-4 gap-3 text-center">
                              <div>
                                <p className="text-xs text-muted-foreground mb-1">Recency</p>
                                <div className="h-1 bg-secondary rounded-full overflow-hidden">
                                  <div
                                    className="h-full bg-primary"
                                    style={{
                                      width: `${(resonance.components.recency / 25) * 100}%`,
                                    }}
                                  />
                                </div>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground mb-1">Velocity</p>
                                <div className="h-1 bg-secondary rounded-full overflow-hidden">
                                  <div
                                    className="h-full bg-primary"
                                    style={{
                                      width: `${(resonance.components.velocity / 25) * 100}%`,
                                    }}
                                  />
                                </div>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground mb-1">Engagement</p>
                                <div className="h-1 bg-secondary rounded-full overflow-hidden">
                                  <div
                                    className="h-full bg-primary"
                                    style={{
                                      width: `${(resonance.components.engagement / 25) * 100}%`,
                                    }}
                                  />
                                </div>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground mb-1">Consistency</p>
                                <div className="h-1 bg-secondary rounded-full overflow-hidden">
                                  <div
                                    className="h-full bg-primary"
                                    style={{
                                      width: `${(resonance.components.consistency / 25) * 100}%`,
                                    }}
                                  />
                                </div>
                              </div>
                            </div>
                          )}

                          {/* Recommendations */}
                          {resonance && resonance.recommendations.length > 0 && (
                            <div className="mt-3 pt-3 border-t">
                              <p className="text-xs font-medium mb-1">💡 Recommendations:</p>
                              <ul className="text-xs text-muted-foreground space-y-1">
                                {resonance.recommendations.slice(0, 2).map((rec, i) => (
                                  <li key={i}>• {rec}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      </Link>
                    );
                  })}
                </div>
              </Card>
            );
          })}
        </div>

        {objects.length === 0 && (
          <Card className="p-12">
            <div className="text-center">
              <p className="text-muted-foreground mb-4">
                No objects registered yet. Register your first object to see analytics.
              </p>
              <Link href="/">
                <Button>Go to Overview</Button>
              </Link>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
