"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft } from "lucide-react";
import { listRunbookSessions } from "@/lib/ops-data-service";
import { getOperatorStats, generateLeaderboard } from "@/lib/gamification-service";
import { OperatorStatsCard } from "@/components/OperatorStatsCard";
import type { OperatorStats } from "@/lib/gamification-service";

export default function LeaderboardPage() {
  const [period, setPeriod] = useState<"week" | "month" | "all-time">("week");
  const [leaderboard, setLeaderboard] = useState<ReturnType<typeof generateLeaderboard> | null>(null);
  const [allOperatorStats, setAllOperatorStats] = useState<OperatorStats[]>([]);
  const [selectedOperator, setSelectedOperator] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, [period]);

  function loadData(): void {
    const board = generateLeaderboard(period);
    setLeaderboard(board);

    // Get unique operators
    const sessions = listRunbookSessions();
    const uniqueOperators = Array.from(new Set(sessions.map((s) => s.operatorName)));

    // Get stats for all operators
    const stats = uniqueOperators.map((name) => getOperatorStats(name));
    setAllOperatorStats(stats.sort((a, b) => b.totalSessions - a.totalSessions));

    if (uniqueOperators.length > 0 && !selectedOperator) {
      setSelectedOperator(uniqueOperators[0]);
    }
  }

  const selectedStats = selectedOperator
    ? getOperatorStats(selectedOperator)
    : null;

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-7xl space-y-8">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <Link href="/">
              <Button variant="ghost" size="sm" className="mb-2">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Overview
              </Button>
            </Link>
            <h1 className="text-3xl font-bold tracking-tight">🏆 Operator Leaderboard</h1>
            <p className="text-muted-foreground">
              Stats, badges, and competitive rankings
            </p>
          </div>
        </div>

        <Tabs value={period} onValueChange={(v) => setPeriod(v as typeof period)}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="week">This Week</TabsTrigger>
            <TabsTrigger value="month">This Month</TabsTrigger>
            <TabsTrigger value="all-time">All Time</TabsTrigger>
          </TabsList>

          <TabsContent value={period} className="space-y-6 mt-6">
            {leaderboard && leaderboard.topOperators.length > 0 ? (
              <Card className="p-6">
                <h2 className="text-xl font-semibold mb-4">
                  🥇 Top Operators - {period === "week" ? "This Week" : period === "month" ? "This Month" : "All Time"}
                </h2>
                <div className="space-y-3">
                  {leaderboard.topOperators.map((entry, index) => (
                    <div
                      key={entry.operatorName}
                      className={`border rounded-lg p-4 hover:bg-accent/50 transition-colors ${
                        entry.operatorName === selectedOperator ? "bg-accent" : ""
                      }`}
                      onClick={() => setSelectedOperator(entry.operatorName)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="text-3xl font-bold text-muted-foreground w-8 text-center">
                            {index + 1}
                          </div>
                          {entry.badge && (
                            <span className="text-3xl">{entry.badge}</span>
                          )}
                          <div>
                            <h3 className="font-semibold text-lg">
                              {entry.operatorName}
                            </h3>
                            <p className="text-sm text-muted-foreground">
                              Click to view detailed stats
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-3xl font-bold">{entry.score}</p>
                          <p className="text-xs text-muted-foreground">Points</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            ) : (
              <Card className="p-12">
                <div className="text-center">
                  <p className="text-muted-foreground">
                    No sessions completed in this period yet.
                  </p>
                </div>
              </Card>
            )}
          </TabsContent>
        </Tabs>

        {/* Operator Selection */}
        {allOperatorStats.length > 0 && (
          <div>
            <h2 className="text-xl font-semibold mb-4">👥 All Operators</h2>
            <div className="flex flex-wrap gap-2 mb-6">
              {allOperatorStats.map((stat) => (
                <Button
                  key={stat.operatorName}
                  variant={selectedOperator === stat.operatorName ? "default" : "outline"}
                  onClick={() => setSelectedOperator(stat.operatorName)}
                  className="gap-2"
                >
                  {stat.operatorName}
                  {stat.currentStreak > 0 && (
                    <Badge variant="secondary" className="ml-1">
                      🔥 {stat.currentStreak}
                    </Badge>
                  )}
                </Button>
              ))}
            </div>

            {/* Selected Operator Stats */}
            {selectedStats && (
              <OperatorStatsCard stats={selectedStats} />
            )}
          </div>
        )}

        {/* Badge Gallery */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">🏅 Available Badges</h2>
          <p className="text-sm text-muted-foreground mb-4">
            Complete challenges to earn these badges
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {[
              { emoji: "🌅", name: "Early Bird", desc: "5 sessions before 8am" },
              { emoji: "⚔️", name: "Weekend Warrior", desc: "3 different weekends" },
              { emoji: "🎯", name: "Flag Hunter", desc: "20+ flags raised" },
              { emoji: "🔥", name: "Streak Master", desc: "7-day streak" },
              { emoji: "⚡", name: "Speed Runner", desc: "Under 15 minutes" },
              { emoji: "💯", name: "Completionist", desc: "50 sessions" },
              { emoji: "🦉", name: "Night Owl", desc: "5 sessions after 10pm" },
              { emoji: "👑", name: "Consistency King", desc: "5 days in a row" },
            ].map((badge) => (
              <div
                key={badge.name}
                className="border rounded-lg p-4 text-center hover:bg-accent/50 transition-colors"
              >
                <div className="text-4xl mb-2">{badge.emoji}</div>
                <h4 className="font-medium text-sm mb-1">{badge.name}</h4>
                <p className="text-xs text-muted-foreground">{badge.desc}</p>
              </div>
            ))}
          </div>
        </Card>

        {allOperatorStats.length === 0 && (
          <Card className="p-12">
            <div className="text-center">
              <p className="text-muted-foreground mb-4">
                No operators yet. Start your first runbook session to appear on the
                leaderboard!
              </p>
              <Link href="/sessions">
                <Button>Go to Sessions</Button>
              </Link>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
