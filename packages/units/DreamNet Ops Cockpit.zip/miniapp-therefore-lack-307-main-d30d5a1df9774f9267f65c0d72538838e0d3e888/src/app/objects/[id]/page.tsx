'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { ArrowLeft, Edit, Save, Plus, Trash2, Flag, TrendingUp } from 'lucide-react';
import type { OpsObjectRef, OpsMetricSnapshot, OpsObjectType, ImportanceLevel } from '@/types/ops';
import { getOpsObject, updateOpsObject, deleteOpsObject, getOpsMetricsByObject, addOpsMetricSnapshot, deleteOpsMetric } from '@/lib/ops-data-service';
import { calculateResonanceScore } from '@/lib/analytics-service';
import { ResonanceBadge } from '@/components/ResonanceBadge';
import { Sparkline } from '@/components/Sparkline';
import { TimelineView } from '@/components/TimelineView';
import { ComparisonView } from '@/components/ComparisonView';

interface PageProps {
  params: Promise<{ id: string }>;
}

export default function OpsObjectDetailPage({ params }: PageProps): JSX.Element {
  const router = useRouter();
  const [objectId, setObjectId] = useState<string | null>(null);
  const [object, setObject] = useState<OpsObjectRef | null>(null);
  const [metrics, setMetrics] = useState<OpsMetricSnapshot[]>([]);
  const [resonance, setResonance] = useState<ReturnType<typeof calculateResonanceScore> | null>(null);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [isAddMetricOpen, setIsAddMetricOpen] = useState<boolean>(false);
  const [showTimeline, setShowTimeline] = useState<boolean>(false);
  const [showComparison, setShowComparison] = useState<boolean>(false);

  // Edit form
  const [editName, setEditName] = useState<string>('');
  const [editType, setEditType] = useState<OpsObjectType>('token');
  const [editRefId, setEditRefId] = useState<string>('');
  const [editEmoji, setEditEmoji] = useState<string>('');
  const [editCategory, setEditCategory] = useState<string>('');
  const [editImportance, setEditImportance] = useState<ImportanceLevel>('medium');
  const [editNotes, setEditNotes] = useState<string>('');

  // New metric form
  const [newMetricPeriod, setNewMetricPeriod] = useState<string>('today');
  const [newMetricStatus, setNewMetricStatus] = useState<string>('');
  const [newMetricNumbers, setNewMetricNumbers] = useState<string>('');
  const [newMetricFlags, setNewMetricFlags] = useState<string>('');
  const [newMetricNotes, setNewMetricNotes] = useState<string>('');

  useEffect(() => {
    params.then((resolvedParams) => {
      setObjectId(resolvedParams.id);
    });
  }, [params]);

  useEffect(() => {
    if (objectId) {
      loadData();
    }
  }, [objectId]);

  function loadData(): void {
    if (!objectId) return;

    const loadedObject = getOpsObject(objectId);
    if (!loadedObject) {
      router.push('/');
      return;
    }

    setObject(loadedObject);
    setEditName(loadedObject.name);
    setEditType(loadedObject.type);
    setEditRefId(loadedObject.refId);
    setEditEmoji(loadedObject.primaryEmoji || '');
    setEditCategory(loadedObject.category);
    setEditImportance(loadedObject.importanceLevel);
    setEditNotes(loadedObject.notes);

    const loadedMetrics = getOpsMetricsByObject(objectId);
    setMetrics(loadedMetrics);

    // Calculate resonance score
    const score = calculateResonanceScore(objectId);
    setResonance(score);
  }

  function handleSave(): void {
    if (!objectId) return;

    updateOpsObject(objectId, {
      name: editName,
      type: editType,
      refId: editRefId,
      primaryEmoji: editEmoji,
      category: editCategory,
      importanceLevel: editImportance,
      notes: editNotes,
    });

    setIsEditing(false);
    loadData();
  }

  function handleDelete(): void {
    if (!objectId) return;
    deleteOpsObject(objectId);
    router.push('/');
  }

  function handleAddMetric(): void {
    if (!objectId || !newMetricStatus.trim()) return;

    const keyNumbers: Record<string, number> = {};
    if (newMetricNumbers.trim()) {
      newMetricNumbers.split(',').forEach((pair) => {
        const [key, value] = pair.split(':').map((s) => s.trim());
        if (key && value && !isNaN(Number(value))) {
          keyNumbers[key] = Number(value);
        }
      });
    }

    const keyFlags = newMetricFlags
      .split(',')
      .map((f) => f.trim())
      .filter((f) => f);

    addOpsMetricSnapshot({
      opsObjectId: objectId,
      periodLabel: newMetricPeriod,
      statusSummary: newMetricStatus,
      keyNumbers,
      keyFlags,
      notes: newMetricNotes,
    });

    setNewMetricPeriod('today');
    setNewMetricStatus('');
    setNewMetricNumbers('');
    setNewMetricFlags('');
    setNewMetricNotes('');
    setIsAddMetricOpen(false);
    loadData();
  }

  function handleDeleteMetric(metricId: string): void {
    deleteOpsMetric(metricId);
    loadData();
  }

  if (!object) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-5xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" size="icon">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h1 className="flex items-center gap-2 text-2xl font-bold">
                {object.primaryEmoji && <span className="text-3xl">{object.primaryEmoji}</span>}
                {object.name}
              </h1>
              <div className="flex items-center gap-2 flex-wrap">
                <p className="text-sm text-muted-foreground">
                  {object.type} • {object.refId || 'No Ref ID'}
                </p>
                {resonance && (
                  <ResonanceBadge
                    level={resonance.level}
                    score={resonance.score}
                    showScore={true}
                  />
                )}
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            {isEditing ? (
              <>
                <Button variant="outline" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSave}>
                  <Save className="mr-2 h-4 w-4" />
                  Save
                </Button>
              </>
            ) : (
              <>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" size="icon">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Object?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will permanently delete this object and all its metrics. This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
                <Button onClick={() => setIsEditing(true)}>
                  <Edit className="mr-2 h-4 w-4" />
                  Edit
                </Button>
              </>
            )}
          </div>
        </div>

        {/* Resonance & Analytics */}
        {resonance && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Resonance Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <div className="text-center">
                  <p className="text-3xl font-bold">{resonance.score}</p>
                  <p className="text-xs text-muted-foreground">Overall Score</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold">{Math.round(resonance.components.recency)}</p>
                  <p className="text-xs text-muted-foreground">Recency</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold">{Math.round(resonance.components.velocity)}</p>
                  <p className="text-xs text-muted-foreground">Velocity</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold">{Math.round(resonance.components.engagement)}</p>
                  <p className="text-xs text-muted-foreground">Engagement</p>
                </div>
              </div>
              {resonance.recommendations.length > 0 && (
                <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                  <p className="text-sm font-medium mb-2">💡 Recommendations:</p>
                  <ul className="space-y-1">
                    {resonance.recommendations.map((rec, i) => (
                      <li key={i} className="text-sm text-muted-foreground">• {rec}</li>
                    ))}
                  </ul>
                </div>
              )}
              {metrics.length > 1 && (
                <div className="mt-4 flex justify-center">
                  <Sparkline
                    data={metrics.slice(0, 7).reverse().map((m) =>
                      Object.values(m.keyNumbers).reduce((sum, val) => sum + val, 0)
                    )}
                    trend={resonance.trend}
                    width={200}
                    height={60}
                  />
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Identity Card */}
        <Card>
          <CardHeader>
            <CardTitle>Identity & Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {isEditing ? (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-name">Name</Label>
                    <Input
                      id="edit-name"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-type">Type</Label>
                    <Select value={editType} onValueChange={(v) => setEditType(v as OpsObjectType)}>
                      <SelectTrigger id="edit-type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="token">Token</SelectItem>
                        <SelectItem value="drop">Drop</SelectItem>
                        <SelectItem value="meme">Meme</SelectItem>
                        <SelectItem value="campaign">Campaign</SelectItem>
                        <SelectItem value="mini-app">Mini App</SelectItem>
                        <SelectItem value="agent">Agent</SelectItem>
                        <SelectItem value="content-stream">Content Stream</SelectItem>
                        <SelectItem value="segment">Segment</SelectItem>
                        <SelectItem value="audience">Audience</SelectItem>
                        <SelectItem value="pickleball">Pickleball</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-refid">Ref ID</Label>
                    <Input
                      id="edit-refid"
                      value={editRefId}
                      onChange={(e) => setEditRefId(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-emoji">Emoji</Label>
                    <Input
                      id="edit-emoji"
                      value={editEmoji}
                      onChange={(e) => setEditEmoji(e.target.value)}
                      maxLength={2}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-importance">Importance</Label>
                    <Select value={editImportance} onValueChange={(v) => setEditImportance(v as ImportanceLevel)}>
                      <SelectTrigger id="edit-importance">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-category">Category</Label>
                  <Input
                    id="edit-category"
                    value={editCategory}
                    onChange={(e) => setEditCategory(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-notes">Notes</Label>
                  <Textarea
                    id="edit-notes"
                    value={editNotes}
                    onChange={(e) => setEditNotes(e.target.value)}
                    rows={4}
                  />
                </div>
              </>
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Type</p>
                  <p className="capitalize">{object.type}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Ref ID</p>
                  <p>{object.refId || '—'}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Category</p>
                  <p>{object.category || '—'}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Importance</p>
                  <Badge className="capitalize">{object.importanceLevel}</Badge>
                </div>
                {object.notes && (
                  <div className="md:col-span-2">
                    <p className="text-sm font-medium text-muted-foreground">Notes</p>
                    <p className="whitespace-pre-wrap">{object.notes}</p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* View Options */}
        {metrics.length > 0 && (
          <div className="flex gap-2">
            <Button
              variant={showTimeline ? "default" : "outline"}
              onClick={() => {
                setShowTimeline(!showTimeline);
                setShowComparison(false);
              }}
            >
              Timeline View
            </Button>
            {metrics.length >= 2 && (
              <Button
                variant={showComparison ? "default" : "outline"}
                onClick={() => {
                  setShowComparison(!showComparison);
                  setShowTimeline(false);
                }}
              >
                Compare Snapshots
              </Button>
            )}
          </div>
        )}

        {/* Timeline View */}
        {showTimeline && metrics.length > 0 && (
          <TimelineView metrics={metrics} title={`${object.name} Timeline`} />
        )}

        {/* Comparison View */}
        {showComparison && metrics.length >= 2 && (
          <ComparisonView
            current={metrics[0]}
            previous={metrics[1]}
            objectName={object.name}
          />
        )}

        {/* Metrics Card */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Metrics Timeline</CardTitle>
                <CardDescription>Performance snapshots over time</CardDescription>
              </div>
              <Dialog open={isAddMetricOpen} onOpenChange={setIsAddMetricOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Snapshot
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-lg">
                  <DialogHeader>
                    <DialogTitle>Add Metric Snapshot</DialogTitle>
                    <DialogDescription>Record a new performance snapshot</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="metric-period">Period Label</Label>
                        <Input
                          id="metric-period"
                          value={newMetricPeriod}
                          onChange={(e) => setNewMetricPeriod(e.target.value)}
                          placeholder="today, 2025-12-06, week-49"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="metric-status">Status Summary *</Label>
                        <Input
                          id="metric-status"
                          value={newMetricStatus}
                          onChange={(e) => setNewMetricStatus(e.target.value)}
                          placeholder="healthy, lagging, paused"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="metric-numbers">Key Numbers</Label>
                      <Input
                        id="metric-numbers"
                        value={newMetricNumbers}
                        onChange={(e) => setNewMetricNumbers(e.target.value)}
                        placeholder="casts:12, mints:45, reach:1200"
                      />
                      <p className="text-xs text-muted-foreground">Format: key:value, key:value</p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="metric-flags">Flags</Label>
                      <Input
                        id="metric-flags"
                        value={newMetricFlags}
                        onChange={(e) => setNewMetricFlags(e.target.value)}
                        placeholder="needs-content, ready-to-push"
                      />
                      <p className="text-xs text-muted-foreground">Comma separated</p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="metric-notes">Notes</Label>
                      <Textarea
                        id="metric-notes"
                        value={newMetricNotes}
                        onChange={(e) => setNewMetricNotes(e.target.value)}
                        rows={3}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsAddMetricOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddMetric}>Add Snapshot</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            {metrics.length === 0 ? (
              <div className="rounded-lg border border-dashed p-8 text-center">
                <p className="text-muted-foreground">
                  No metrics recorded yet. Add your first snapshot.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {metrics.map((metric) => (
                  <Card key={metric.id} className="border-l-4 border-l-primary">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-base">
                            {metric.periodLabel}
                          </CardTitle>
                          <CardDescription>
                            {new Date(metric.timestamp).toLocaleString()}
                          </CardDescription>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge>{metric.statusSummary}</Badge>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete Snapshot?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will permanently delete this metric snapshot.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDeleteMetric(metric.id)}>
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {Object.keys(metric.keyNumbers).length > 0 && (
                        <div>
                          <p className="mb-2 text-sm font-medium">Key Numbers</p>
                          <div className="flex flex-wrap gap-2">
                            {Object.entries(metric.keyNumbers).map(([key, value]) => (
                              <Badge key={key} variant="secondary">
                                {key}: {value}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      {metric.keyFlags.length > 0 && (
                        <div>
                          <p className="mb-2 text-sm font-medium">Flags</p>
                          <div className="flex flex-wrap gap-2">
                            {metric.keyFlags.map((flag, i) => (
                              <Badge key={i} variant="outline">
                                <Flag className="mr-1 h-3 w-3" />
                                {flag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      {metric.notes && (
                        <div>
                          <p className="text-sm text-muted-foreground">{metric.notes}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
