'use client'
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Search, Filter, TrendingUp, BookOpen, BarChart3, Activity, Trophy } from 'lucide-react';
import { CommandPalette } from '@/components/CommandPalette';
import { StatusHeatMap } from '@/components/StatusHeatMap';
import { InsightsCard } from '@/components/InsightsCard';
import { EcosystemHealthWidget } from '@/components/EcosystemHealthWidget';
import { generateInsights } from '@/lib/ai-insights-service';
import type { OpsObjectRef, OpsView, OpsObjectType, ImportanceLevel, PriorityLevel } from '@/types/ops';
import { listOpsObjects, registerOpsObject, listOpsViews, createOpsView } from '@/lib/ops-data-service';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function OpsOverviewPage(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [objects, setObjects] = useState<Array<OpsObjectRef & { latestStatusSummary: string }>>([]);
  const [views, setViews] = useState<OpsView[]>([]);
  const [objectSearch, setObjectSearch] = useState<string>('');
  const [viewSearch, setViewSearch] = useState<string>('');
  const [objectTypeFilter, setObjectTypeFilter] = useState<string>('all');
  const [objectImportanceFilter, setObjectImportanceFilter] = useState<string>('all');
  const [viewPriorityFilter, setViewPriorityFilter] = useState<string>('all');
  const [isAddObjectOpen, setIsAddObjectOpen] = useState<boolean>(false);
  const [isAddViewOpen, setIsAddViewOpen] = useState<boolean>(false);

  // New object form
  const [newObjectName, setNewObjectName] = useState<string>('');
  const [newObjectType, setNewObjectType] = useState<OpsObjectType>('token');
  const [newObjectRefId, setNewObjectRefId] = useState<string>('');
  const [newObjectEmoji, setNewObjectEmoji] = useState<string>('');
  const [newObjectCategory, setNewObjectCategory] = useState<string>('');
  const [newObjectImportance, setNewObjectImportance] = useState<ImportanceLevel>('medium');

  // New view form
  const [newViewName, setNewViewName] = useState<string>('');
  const [newViewDescription, setNewViewDescription] = useState<string>('');
  const [newViewPriority, setNewViewPriority] = useState<PriorityLevel>('medium');
  const [newViewTimeframe, setNewViewTimeframe] = useState<'today' | 'yesterday' | 'last-7-days' | 'week-to-date'>('today');
  const [newViewObjectFilters, setNewViewObjectFilters] = useState<string>('');
  const [newViewActionFilters, setNewViewActionFilters] = useState<string>('');
  const [insights, setInsights] = useState<ReturnType<typeof generateInsights>>([]);
  const [showHeatMap, setShowHeatMap] = useState<boolean>(true);

  useEffect(() => {
    loadData();
    loadInsights();
  }, [objectTypeFilter, objectImportanceFilter, viewPriorityFilter]);

  function loadInsights(): void {
    const newInsights = generateInsights();
    setInsights(newInsights);
  }

  function loadData(): void {
    const objFilter: {
      type?: OpsObjectType;
      importanceLevel?: ImportanceLevel;
    } = {};

    if (objectTypeFilter !== 'all') {
      objFilter.type = objectTypeFilter as OpsObjectType;
    }

    if (objectImportanceFilter !== 'all') {
      objFilter.importanceLevel = objectImportanceFilter as ImportanceLevel;
    }

    const loadedObjects = listOpsObjects(objFilter);
    setObjects(loadedObjects);

    const viewFilter: {
      priorityLevel?: PriorityLevel;
      searchText?: string;
    } = {};

    if (viewPriorityFilter !== 'all') {
      viewFilter.priorityLevel = viewPriorityFilter as PriorityLevel;
    }

    if (viewSearch) {
      viewFilter.searchText = viewSearch;
    }

    const loadedViews = listOpsViews(viewFilter);
    setViews(loadedViews);
  }

  function handleAddObject(): void {
    if (!newObjectName.trim()) return;

    registerOpsObject({
      type: newObjectType,
      refId: newObjectRefId,
      name: newObjectName,
      primaryEmoji: newObjectEmoji,
      category: newObjectCategory,
      importanceLevel: newObjectImportance,
    });

    setNewObjectName('');
    setNewObjectRefId('');
    setNewObjectEmoji('');
    setNewObjectCategory('');
    setNewObjectType('token');
    setNewObjectImportance('medium');
    setIsAddObjectOpen(false);
    loadData();
  }

  function handleAddView(): void {
    if (!newViewName.trim() || !newViewDescription.trim()) return;

    const objectFilters = newViewObjectFilters
      .split(',')
      .map((f) => f.trim())
      .filter((f) => f);
    const actionFilters = newViewActionFilters
      .split(',')
      .map((f) => f.trim())
      .filter((f) => f);

    createOpsView({
      name: newViewName,
      description: newViewDescription,
      objectFilters,
      actionFilters,
      priorityLevel: newViewPriority,
      defaultTimeframe: newViewTimeframe,
    });

    setNewViewName('');
    setNewViewDescription('');
    setNewViewObjectFilters('');
    setNewViewActionFilters('');
    setNewViewPriority('medium');
    setNewViewTimeframe('today');
    setIsAddViewOpen(false);
    loadData();
  }

  const filteredObjects = objects.filter((obj) =>
    obj.name.toLowerCase().includes(objectSearch.toLowerCase())
  );

  const filteredViews = views.filter((view) =>
    view.name.toLowerCase().includes(viewSearch.toLowerCase())
  );

  function getImportanceBadge(level: ImportanceLevel): JSX.Element {
    const variants: Record<ImportanceLevel, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      low: 'secondary',
      medium: 'default',
      high: 'outline',
      critical: 'destructive',
    };

    return (
      <Badge variant={variants[level]} className="capitalize">
        {level}
      </Badge>
    );
  }

  function getPriorityBadge(level: PriorityLevel): JSX.Element {
    const variants: Record<PriorityLevel, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      low: 'secondary',
      medium: 'default',
      high: 'outline',
      critical: 'destructive',
    };

    return (
      <Badge variant={variants[level]} className="capitalize">
        {level}
      </Badge>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-7xl space-y-8">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">DreamNet Ops Console</h1>
            <p className="text-muted-foreground">Your daily operations cockpit</p>
          </div>
          <div className="flex gap-2">
            <Link href="/analytics">
              <Button variant="outline">
                <Activity className="mr-2 h-4 w-4" />
                Analytics
              </Button>
            </Link>
            <Link href="/leaderboard">
              <Button variant="outline">
                <Trophy className="mr-2 h-4 w-4" />
                Leaderboard
              </Button>
            </Link>
            <Link href="/sessions">
              <Button variant="outline">
                <BookOpen className="mr-2 h-4 w-4" />
                Sessions
              </Button>
            </Link>
          </div>
        </div>

        {/* AI Insights & Health */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <InsightsCard insights={insights} maxDisplay={3} />
          <EcosystemHealthWidget />
        </div>

        {/* Status Heat Map */}
        {showHeatMap && objects.length > 0 && (
          <StatusHeatMap objects={objects} />
        )}

        <Tabs defaultValue="objects" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="objects">
              <BarChart3 className="mr-2 h-4 w-4" />
              Key Objects
            </TabsTrigger>
            <TabsTrigger value="views">
              <TrendingUp className="mr-2 h-4 w-4" />
              Ops Views
            </TabsTrigger>
          </TabsList>

          {/* OBJECTS TAB */}
          <TabsContent value="objects" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div>
                    <CardTitle>Key Objects</CardTitle>
                    <CardDescription>
                      Tokens, drops, campaigns, and other DreamNet assets
                    </CardDescription>
                  </div>
                  <Dialog open={isAddObjectOpen} onOpenChange={setIsAddObjectOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="mr-2 h-4 w-4" />
                        Register Object
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-lg">
                      <DialogHeader>
                        <DialogTitle>Register Ops Object</DialogTitle>
                        <DialogDescription>Add a new object to track in DreamNet Ops</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div className="space-y-2">
                          <Label htmlFor="obj-name">Name *</Label>
                          <Input
                            id="obj-name"
                            value={newObjectName}
                            onChange={(e) => setNewObjectName(e.target.value)}
                            placeholder="e.g., $DREAM Token"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="obj-type">Type *</Label>
                            <Select value={newObjectType} onValueChange={(v) => setNewObjectType(v as OpsObjectType)}>
                              <SelectTrigger id="obj-type">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="token">Token</SelectItem>
                                <SelectItem value="drop">Drop</SelectItem>
                                <SelectItem value="meme">Meme</SelectItem>
                                <SelectItem value="campaign">Campaign</SelectItem>
                                <SelectItem value="mini-app">Mini App</SelectItem>
                                <SelectItem value="agent">Agent</SelectItem>
                                <SelectItem value="content-stream">Content Stream</SelectItem>
                                <SelectItem value="segment">Segment</SelectItem>
                                <SelectItem value="audience">Audience</SelectItem>
                                <SelectItem value="pickleball">Pickleball</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="obj-importance">Importance</Label>
                            <Select value={newObjectImportance} onValueChange={(v) => setNewObjectImportance(v as ImportanceLevel)}>
                              <SelectTrigger id="obj-importance">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="low">Low</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="high">High</SelectItem>
                                <SelectItem value="critical">Critical</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="obj-emoji">Emoji</Label>
                            <Input
                              id="obj-emoji"
                              value={newObjectEmoji}
                              onChange={(e) => setNewObjectEmoji(e.target.value)}
                              placeholder="💎"
                              maxLength={2}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="obj-refid">Ref ID</Label>
                            <Input
                              id="obj-refid"
                              value={newObjectRefId}
                              onChange={(e) => setNewObjectRefId(e.target.value)}
                              placeholder="TKN-001"
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="obj-category">Category</Label>
                          <Input
                            id="obj-category"
                            value={newObjectCategory}
                            onChange={(e) => setNewObjectCategory(e.target.value)}
                            placeholder="e.g., culture, distribution"
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setIsAddObjectOpen(false)}>
                          Cancel
                        </Button>
                        <Button onClick={handleAddObject}>Register</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Filters */}
                <div className="flex flex-col gap-4 md:flex-row md:items-center">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="Search objects..."
                      value={objectSearch}
                      onChange={(e) => setObjectSearch(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Select value={objectTypeFilter} onValueChange={setObjectTypeFilter}>
                      <SelectTrigger className="w-[160px]">
                        <Filter className="mr-2 h-4 w-4" />
                        <SelectValue placeholder="Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Types</SelectItem>
                        <SelectItem value="token">Token</SelectItem>
                        <SelectItem value="drop">Drop</SelectItem>
                        <SelectItem value="meme">Meme</SelectItem>
                        <SelectItem value="campaign">Campaign</SelectItem>
                        <SelectItem value="mini-app">Mini App</SelectItem>
                        <SelectItem value="agent">Agent</SelectItem>
                        <SelectItem value="content-stream">Content Stream</SelectItem>
                        <SelectItem value="segment">Segment</SelectItem>
                        <SelectItem value="audience">Audience</SelectItem>
                        <SelectItem value="pickleball">Pickleball</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={objectImportanceFilter} onValueChange={setObjectImportanceFilter}>
                      <SelectTrigger className="w-[160px]">
                        <SelectValue placeholder="Importance" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Levels</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Objects Table */}
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Importance</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredObjects.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center text-muted-foreground">
                            No objects found. Register your first object to get started.
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredObjects.map((obj) => (
                          <TableRow key={obj.id} className="cursor-pointer hover:bg-muted/50">
                            <TableCell>
                              <Link href={`/objects/${obj.id}`} className="flex items-center gap-2 font-medium hover:underline">
                                {obj.primaryEmoji && <span className="text-lg">{obj.primaryEmoji}</span>}
                                {obj.name}
                              </Link>
                            </TableCell>
                            <TableCell className="capitalize">{obj.type}</TableCell>
                            <TableCell>{obj.category || '—'}</TableCell>
                            <TableCell>{getImportanceBadge(obj.importanceLevel)}</TableCell>
                            <TableCell className="text-sm text-muted-foreground">
                              {obj.latestStatusSummary}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* VIEWS TAB */}
          <TabsContent value="views" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div>
                    <CardTitle>Ops Views</CardTitle>
                    <CardDescription>
                      Operational dashboards and runbook configurations
                    </CardDescription>
                  </div>
                  <Dialog open={isAddViewOpen} onOpenChange={setIsAddViewOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="mr-2 h-4 w-4" />
                        Create Ops View
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-lg">
                      <DialogHeader>
                        <DialogTitle>Create Ops View</DialogTitle>
                        <DialogDescription>Define a new operational view and runbook</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div className="space-y-2">
                          <Label htmlFor="view-name">Name *</Label>
                          <Input
                            id="view-name"
                            value={newViewName}
                            onChange={(e) => setNewViewName(e.target.value)}
                            placeholder="e.g., Daily Culture Ops"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="view-desc">Description *</Label>
                          <Input
                            id="view-desc"
                            value={newViewDescription}
                            onChange={(e) => setNewViewDescription(e.target.value)}
                            placeholder="What is this view for?"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="view-priority">Priority</Label>
                            <Select value={newViewPriority} onValueChange={(v) => setNewViewPriority(v as PriorityLevel)}>
                              <SelectTrigger id="view-priority">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="low">Low</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="high">High</SelectItem>
                                <SelectItem value="critical">Critical</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="view-timeframe">Timeframe</Label>
                            <Select value={newViewTimeframe} onValueChange={(v) => setNewViewTimeframe(v as 'today' | 'yesterday' | 'last-7-days' | 'week-to-date')}>
                              <SelectTrigger id="view-timeframe">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="today">Today</SelectItem>
                                <SelectItem value="yesterday">Yesterday</SelectItem>
                                <SelectItem value="last-7-days">Last 7 Days</SelectItem>
                                <SelectItem value="week-to-date">Week to Date</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="view-obj-filters">Object Filters</Label>
                          <Input
                            id="view-obj-filters"
                            value={newViewObjectFilters}
                            onChange={(e) => setNewViewObjectFilters(e.target.value)}
                            placeholder="e.g., culture, token, drop (comma separated)"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="view-action-filters">Action Filters</Label>
                          <Input
                            id="view-action-filters"
                            value={newViewActionFilters}
                            onChange={(e) => setNewViewActionFilters(e.target.value)}
                            placeholder="e.g., ANNOUNCE_DROP, POST_FC (comma separated)"
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setIsAddViewOpen(false)}>
                          Cancel
                        </Button>
                        <Button onClick={handleAddView}>Create View</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Filters */}
                <div className="flex flex-col gap-4 md:flex-row md:items-center">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="Search views..."
                      value={viewSearch}
                      onChange={(e) => setViewSearch(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Select value={viewPriorityFilter} onValueChange={setViewPriorityFilter}>
                    <SelectTrigger className="w-[160px]">
                      <Filter className="mr-2 h-4 w-4" />
                      <SelectValue placeholder="Priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Priorities</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Views Table */}
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Priority</TableHead>
                        <TableHead>Timeframe</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredViews.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center text-muted-foreground">
                            No views found. Create your first ops view to get started.
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredViews.map((view) => (
                          <TableRow key={view.id} className="cursor-pointer hover:bg-muted/50">
                            <TableCell>
                              <Link href={`/views/${view.id}`} className="font-medium hover:underline">
                                {view.name}
                              </Link>
                            </TableCell>
                            <TableCell className="max-w-md truncate text-sm text-muted-foreground">
                              {view.description}
                            </TableCell>
                            <TableCell>{getPriorityBadge(view.priorityLevel)}</TableCell>
                            <TableCell className="capitalize">{view.defaultTimeframe.replace(/-/g, ' ')}</TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Command Palette */}
      <CommandPalette />
    </div>
  );
}
