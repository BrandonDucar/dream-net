'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { ArrowLeft, Flag, Download, CheckCircle2, Circle, Trash2 } from 'lucide-react';
import type { RunbookSession, OpsView, RunbookStep } from '@/types/ops';
import { getRunbookSession, getOpsView, getRunbookStepsByView, markRunbookStepCompleted, markRunbookStepUncompleted, addRunbookFlag, removeRunbookFlag, finalizeRunbookSession, exportRunbookSessionReport, deleteRunbookSession } from '@/lib/ops-data-service';

interface PageProps {
  params: Promise<{ id: string }>;
}

export default function RunbookSessionDetailPage({ params }: PageProps): JSX.Element {
  const router = useRouter();
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [session, setSession] = useState<RunbookSession | null>(null);
  const [view, setView] = useState<OpsView | null>(null);
  const [steps, setSteps] = useState<RunbookStep[]>([]);
  const [summaryNotes, setSummaryNotes] = useState<string>('');
  const [newFlag, setNewFlag] = useState<string>('');
  const [exportedReport, setExportedReport] = useState<string>('');

  useEffect(() => {
    params.then((resolvedParams) => {
      setSessionId(resolvedParams.id);
    });
  }, [params]);

  useEffect(() => {
    if (sessionId) {
      loadData();
    }
  }, [sessionId]);

  function loadData(): void {
    if (!sessionId) return;

    const loadedSession = getRunbookSession(sessionId);
    if (!loadedSession) {
      router.push('/sessions');
      return;
    }

    setSession(loadedSession);
    setSummaryNotes(loadedSession.summaryNotes);

    const loadedView = getOpsView(loadedSession.viewId);
    setView(loadedView);

    if (loadedView) {
      const loadedSteps = getRunbookStepsByView(loadedView.id);
      setSteps(loadedSteps);
    }
  }

  function handleToggleStep(stepId: string, currentlyCompleted: boolean): void {
    if (!sessionId) return;

    if (currentlyCompleted) {
      markRunbookStepUncompleted(sessionId, stepId);
    } else {
      markRunbookStepCompleted(sessionId, stepId);
    }

    loadData();
  }

  function handleAddFlag(): void {
    if (!sessionId || !newFlag.trim()) return;

    addRunbookFlag(sessionId, newFlag);
    setNewFlag('');
    loadData();
  }

  function handleRemoveFlag(index: number): void {
    if (!sessionId) return;

    removeRunbookFlag(sessionId, index);
    loadData();
  }

  function handleFinalize(): void {
    if (!sessionId) return;

    finalizeRunbookSession(sessionId, summaryNotes);
    loadData();
  }

  function handleExportReport(): void {
    if (!sessionId) return;

    const report = exportRunbookSessionReport(sessionId);
    setExportedReport(report);
  }

  function handleDeleteSession(): void {
    if (!sessionId) return;
    deleteRunbookSession(sessionId);
    router.push('/sessions');
  }

  if (!session || !view) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }

  const isFinalized = session.finishedAt !== null;
  const completionPercentage = steps.length > 0
    ? Math.round((session.completedSteps.length / steps.length) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-5xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/sessions">
              <Button variant="outline" size="icon">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold">{view.name} Session</h1>
              <p className="text-sm text-muted-foreground">
                {session.operatorName} • {session.date}
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" size="icon">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete Session?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will permanently delete this runbook session and all its data.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDeleteSession}>Delete</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
            <Button variant="outline" onClick={handleExportReport}>
              <Download className="mr-2 h-4 w-4" />
              Export Report
            </Button>
          </div>
        </div>

        {/* Session Info */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Session Info</CardTitle>
              {isFinalized ? (
                <Badge variant="secondary">
                  <CheckCircle2 className="mr-1 h-4 w-4" />
                  Finalized
                </Badge>
              ) : (
                <Badge>
                  <Circle className="mr-1 h-4 w-4" />
                  In Progress
                </Badge>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Started</p>
                <p>{new Date(session.startedAt).toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Finished</p>
                <p>{session.finishedAt ? new Date(session.finishedAt).toLocaleString() : '—'}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Completion</p>
                <p className="text-2xl font-bold">{completionPercentage}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Runbook Steps */}
        <Card>
          <CardHeader>
            <CardTitle>Runbook Steps</CardTitle>
            <CardDescription>
              {session.completedSteps.length} of {steps.length} completed
            </CardDescription>
          </CardHeader>
          <CardContent>
            {steps.length === 0 ? (
              <div className="rounded-lg border border-dashed p-8 text-center">
                <p className="text-muted-foreground">No steps defined for this view.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {steps.map((step) => {
                  const isCompleted = session.completedSteps.includes(step.id);

                  return (
                    <Card key={step.id} className={isCompleted ? 'border-green-500' : ''}>
                      <CardHeader>
                        <div className="flex items-start gap-4">
                          <Checkbox
                            checked={isCompleted}
                            onCheckedChange={() => handleToggleStep(step.id, isCompleted)}
                            disabled={isFinalized}
                            className="mt-1"
                          />
                          <div className="flex-1">
                            <CardTitle className="text-base">
                              {step.stepOrder}. {step.stepName}
                            </CardTitle>
                            {step.stepDescription && (
                              <CardDescription className="mt-1">
                                {step.stepDescription}
                              </CardDescription>
                            )}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        {step.expectedOutcome && (
                          <div className="mb-3">
                            <p className="text-sm font-medium">Expected Outcome</p>
                            <p className="text-sm text-muted-foreground">{step.expectedOutcome}</p>
                          </div>
                        )}
                        {step.manualChecklist.length > 0 && (
                          <div>
                            <p className="mb-2 text-sm font-medium">Checklist</p>
                            <ul className="space-y-1">
                              {step.manualChecklist.map((item, i) => (
                                <li key={i} className="flex items-start gap-2 text-sm">
                                  <span className="text-muted-foreground">•</span>
                                  <span>{item}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Flags */}
        <Card>
          <CardHeader>
            <CardTitle>Flags Raised</CardTitle>
            <CardDescription>
              Issues, notes, or follow-ups identified during execution
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {!isFinalized && (
              <div className="flex gap-2">
                <Input
                  value={newFlag}
                  onChange={(e) => setNewFlag(e.target.value)}
                  placeholder="Add a new flag..."
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      handleAddFlag();
                    }
                  }}
                />
                <Button onClick={handleAddFlag} disabled={!newFlag.trim()}>
                  <Flag className="mr-2 h-4 w-4" />
                  Add
                </Button>
              </div>
            )}
            {session.flagsRaised.length === 0 ? (
              <div className="rounded-lg border border-dashed p-8 text-center">
                <p className="text-muted-foreground">No flags raised.</p>
              </div>
            ) : (
              <div className="space-y-2">
                {session.flagsRaised.map((flag, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between rounded-lg border border-orange-200 bg-orange-50 p-3 dark:border-orange-800 dark:bg-orange-950"
                  >
                    <div className="flex items-center gap-2">
                      <Flag className="h-4 w-4 text-orange-500" />
                      <span>{flag}</span>
                    </div>
                    {!isFinalized && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveFlag(index)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Summary Notes */}
        <Card>
          <CardHeader>
            <CardTitle>Summary Notes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              value={summaryNotes}
              onChange={(e) => setSummaryNotes(e.target.value)}
              rows={6}
              placeholder="Add notes about this session, key decisions, or follow-up actions..."
              disabled={isFinalized}
            />
            {!isFinalized && (
              <div className="flex justify-end">
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button>
                      <CheckCircle2 className="mr-2 h-4 w-4" />
                      Finalize Session
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Finalize Session?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will mark the session as complete. You won't be able to make changes after finalizing.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleFinalize}>Finalize</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Exported Report Dialog */}
        {exportedReport && (
          <Dialog open={!!exportedReport} onOpenChange={() => setExportedReport('')}>
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>Session Report</DialogTitle>
                <DialogDescription>
                  Copy this report for your records
                </DialogDescription>
              </DialogHeader>
              <Textarea
                value={exportedReport}
                readOnly
                rows={20}
                className="font-mono text-xs"
              />
              <DialogFooter>
                <Button variant="outline" onClick={() => setExportedReport('')}>
                  Close
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
}
