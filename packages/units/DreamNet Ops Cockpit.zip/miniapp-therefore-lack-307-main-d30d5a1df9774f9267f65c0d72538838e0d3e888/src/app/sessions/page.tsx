'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ArrowLeft, Plus, Clock, CheckCircle2, Flag, User } from 'lucide-react';
import type { RunbookSession, OpsView } from '@/types/ops';
import { listRunbookSessions, listOpsViews, startRunbookSession, getOpsView } from '@/lib/ops-data-service';

export default function RunbookSessionsPage(): JSX.Element {
  const [sessions, setSessions] = useState<RunbookSession[]>([]);
  const [views, setViews] = useState<OpsView[]>([]);
  const [viewFilter, setViewFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isStartSessionOpen, setIsStartSessionOpen] = useState<boolean>(false);

  // Start session form
  const [selectedViewId, setSelectedViewId] = useState<string>('');
  const [operatorName, setOperatorName] = useState<string>('');

  useEffect(() => {
    loadData();
  }, [viewFilter, statusFilter]);

  function loadData(): void {
    const filter: {
      viewId?: string;
      completed?: boolean;
    } = {};

    if (viewFilter !== 'all') {
      filter.viewId = viewFilter;
    }

    if (statusFilter === 'completed') {
      filter.completed = true;
    } else if (statusFilter === 'in-progress') {
      filter.completed = false;
    }

    const loadedSessions = listRunbookSessions(filter);
    setSessions(loadedSessions);

    const loadedViews = listOpsViews();
    setViews(loadedViews);
  }

  function handleStartSession(): void {
    if (!selectedViewId || !operatorName.trim()) return;

    const session = startRunbookSession(selectedViewId, operatorName);
    setSelectedViewId('');
    setOperatorName('');
    setIsStartSessionOpen(false);
    loadData();

    // Navigate to the new session
    window.location.href = `/sessions/${session.id}`;
  }

  function getSessionView(viewId: string): OpsView | null {
    return getOpsView(viewId);
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-6xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" size="icon">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold">Runbook Sessions</h1>
              <p className="text-sm text-muted-foreground">
                Track operational runbook executions
              </p>
            </div>
          </div>
          <Dialog open={isStartSessionOpen} onOpenChange={setIsStartSessionOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Start New Session
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Start Runbook Session</DialogTitle>
                <DialogDescription>Begin a new operational runbook execution</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="session-view">Select View *</Label>
                  <Select value={selectedViewId} onValueChange={setSelectedViewId}>
                    <SelectTrigger id="session-view">
                      <SelectValue placeholder="Choose an ops view" />
                    </SelectTrigger>
                    <SelectContent>
                      {views.map((view) => (
                        <SelectItem key={view.id} value={view.id}>
                          {view.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="operator-name">Operator Name *</Label>
                  <Input
                    id="operator-name"
                    value={operatorName}
                    onChange={(e) => setOperatorName(e.target.value)}
                    placeholder="Who is running this session?"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsStartSessionOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleStartSession} disabled={!selectedViewId || !operatorName.trim()}>
                  Start Session
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle>Filter Sessions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4 md:flex-row">
              <div className="flex-1 space-y-2">
                <Label htmlFor="view-filter">View</Label>
                <Select value={viewFilter} onValueChange={setViewFilter}>
                  <SelectTrigger id="view-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Views</SelectItem>
                    {views.map((view) => (
                      <SelectItem key={view.id} value={view.id}>
                        {view.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1 space-y-2">
                <Label htmlFor="status-filter">Status</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger id="status-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Sessions List */}
        <Card>
          <CardHeader>
            <CardTitle>Sessions</CardTitle>
            <CardDescription>
              {sessions.length} session{sessions.length !== 1 ? 's' : ''} found
            </CardDescription>
          </CardHeader>
          <CardContent>
            {sessions.length === 0 ? (
              <div className="rounded-lg border border-dashed p-8 text-center">
                <p className="text-muted-foreground">
                  No sessions found. Start your first runbook session.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {sessions.map((session) => {
                  const view = getSessionView(session.viewId);
                  const isInProgress = !session.finishedAt;
                  
                  return (
                    <Link key={session.id} href={`/sessions/${session.id}`}>
                      <Card className="cursor-pointer transition-colors hover:bg-muted/50">
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2">
                                <CardTitle className="text-base">
                                  {view?.name || 'Unknown View'}
                                </CardTitle>
                                {isInProgress ? (
                                  <Badge variant="default">
                                    <Clock className="mr-1 h-3 w-3" />
                                    In Progress
                                  </Badge>
                                ) : (
                                  <Badge variant="secondary">
                                    <CheckCircle2 className="mr-1 h-3 w-3" />
                                    Completed
                                  </Badge>
                                )}
                              </div>
                              <CardDescription className="mt-1">
                                <div className="flex flex-wrap items-center gap-3 text-xs">
                                  <span className="flex items-center gap-1">
                                    <User className="h-3 w-3" />
                                    {session.operatorName}
                                  </span>
                                  <span>•</span>
                                  <span>{session.date}</span>
                                  <span>•</span>
                                  <span>
                                    Started: {new Date(session.startedAt).toLocaleTimeString()}
                                  </span>
                                  {session.finishedAt && (
                                    <>
                                      <span>•</span>
                                      <span>
                                        Finished: {new Date(session.finishedAt).toLocaleTimeString()}
                                      </span>
                                    </>
                                  )}
                                </div>
                              </CardDescription>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="flex flex-wrap items-center gap-4 text-sm">
                            <div className="flex items-center gap-2">
                              <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
                              <span>{session.completedSteps.length} steps completed</span>
                            </div>
                            {session.flagsRaised.length > 0 && (
                              <div className="flex items-center gap-2">
                                <Flag className="h-4 w-4 text-orange-500" />
                                <span>{session.flagsRaised.length} flags raised</span>
                              </div>
                            )}
                            {session.summaryNotes && (
                              <Badge variant="outline">Has summary</Badge>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
