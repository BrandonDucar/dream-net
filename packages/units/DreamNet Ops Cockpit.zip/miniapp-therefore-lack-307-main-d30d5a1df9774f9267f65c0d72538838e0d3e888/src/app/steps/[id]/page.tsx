'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Save } from 'lucide-react';
import type { RunbookStep, OpsView } from '@/types/ops';
import { getRunbookStep, updateRunbookStep, getOpsView } from '@/lib/ops-data-service';

interface PageProps {
  params: Promise<{ id: string }>;
}

export default function RunbookStepDetailPage({ params }: PageProps): JSX.Element {
  const router = useRouter();
  const [stepId, setStepId] = useState<string | null>(null);
  const [step, setStep] = useState<RunbookStep | null>(null);
  const [view, setView] = useState<OpsView | null>(null);

  const [stepName, setStepName] = useState<string>('');
  const [stepOrder, setStepOrder] = useState<number>(1);
  const [stepDescription, setStepDescription] = useState<string>('');
  const [expectedOutcome, setExpectedOutcome] = useState<string>('');
  const [relatedObjects, setRelatedObjects] = useState<string>('');
  const [relatedActionTypes, setRelatedActionTypes] = useState<string>('');
  const [manualChecklist, setManualChecklist] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  useEffect(() => {
    params.then((resolvedParams) => {
      setStepId(resolvedParams.id);
    });
  }, [params]);

  useEffect(() => {
    if (stepId) {
      loadData();
    }
  }, [stepId]);

  function loadData(): void {
    if (!stepId) return;

    const loadedStep = getRunbookStep(stepId);
    if (!loadedStep) {
      router.push('/');
      return;
    }

    setStep(loadedStep);
    setStepName(loadedStep.stepName);
    setStepOrder(loadedStep.stepOrder);
    setStepDescription(loadedStep.stepDescription);
    setExpectedOutcome(loadedStep.expectedOutcome);
    setRelatedObjects(loadedStep.relatedObjects.join(', '));
    setRelatedActionTypes(loadedStep.relatedActionTypes.join(', '));
    setManualChecklist(loadedStep.manualChecklist.join('\n'));
    setNotes(loadedStep.notes);

    const loadedView = getOpsView(loadedStep.viewId);
    setView(loadedView);
  }

  function handleSave(): void {
    if (!stepId) return;

    const relatedObjArray = relatedObjects
      .split(',')
      .map((o) => o.trim())
      .filter((o) => o);

    const relatedActArray = relatedActionTypes
      .split(',')
      .map((a) => a.trim())
      .filter((a) => a);

    const checklistArray = manualChecklist
      .split('\n')
      .map((c) => c.trim())
      .filter((c) => c);

    updateRunbookStep(stepId, {
      stepName,
      stepOrder,
      stepDescription,
      expectedOutcome,
      relatedObjects: relatedObjArray,
      relatedActionTypes: relatedActArray,
      manualChecklist: checklistArray,
      notes,
    });

    if (step) {
      router.push(`/views/${step.viewId}`);
    }
  }

  if (!step) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-4xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href={view ? `/views/${view.id}` : '/'}>
              <Button variant="outline" size="icon">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold">Edit Runbook Step</h1>
              {view && (
                <p className="text-sm text-muted-foreground">
                  From: {view.name}
                </p>
              )}
            </div>
          </div>
          <Button onClick={handleSave}>
            <Save className="mr-2 h-4 w-4" />
            Save Changes
          </Button>
        </div>

        {/* Step Form */}
        <Card>
          <CardHeader>
            <CardTitle>Step Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-4 gap-4">
              <div className="col-span-3 space-y-2">
                <Label htmlFor="step-name">Step Name *</Label>
                <Input
                  id="step-name"
                  value={stepName}
                  onChange={(e) => setStepName(e.target.value)}
                  placeholder="e.g., Check pending actions"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="step-order">Order</Label>
                <Input
                  id="step-order"
                  type="number"
                  value={stepOrder}
                  onChange={(e) => setStepOrder(parseInt(e.target.value) || 1)}
                  min={1}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="step-desc">Description</Label>
              <Textarea
                id="step-desc"
                value={stepDescription}
                onChange={(e) => setStepDescription(e.target.value)}
                rows={4}
                placeholder="Detailed instructions for this step..."
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="expected-outcome">Expected Outcome</Label>
              <Input
                id="expected-outcome"
                value={expectedOutcome}
                onChange={(e) => setExpectedOutcome(e.target.value)}
                placeholder="What does success look like?"
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Related Resources</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="related-objects">Related Objects</Label>
              <Input
                id="related-objects"
                value={relatedObjects}
                onChange={(e) => setRelatedObjects(e.target.value)}
                placeholder="Object IDs or type tags (comma separated)"
              />
              <p className="text-xs text-muted-foreground">
                e.g., token, culture, $DREAM-Token
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="related-actions">Related Action Types</Label>
              <Input
                id="related-actions"
                value={relatedActionTypes}
                onChange={(e) => setRelatedActionTypes(e.target.value)}
                placeholder="Action codes from Action Router (comma separated)"
              />
              <p className="text-xs text-muted-foreground">
                e.g., ANNOUNCE_DROP, POST_FC, QUEUE_MEME
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Manual Checklist</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="checklist">Checklist Items</Label>
              <Textarea
                id="checklist"
                value={manualChecklist}
                onChange={(e) => setManualChecklist(e.target.value)}
                rows={8}
                placeholder="One item per line&#10;e.g.,&#10;Check all pending approvals&#10;Review top 3 metrics&#10;Confirm no critical flags"
              />
              <p className="text-xs text-muted-foreground">
                Each line becomes a checklist item in runbook sessions
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Additional Notes</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={4}
                placeholder="Any additional context or instructions..."
              />
            </div>
          </CardContent>
        </Card>

        {/* Preview */}
        <Card>
          <CardHeader>
            <CardTitle>Preview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div>
                <Badge>{stepOrder}</Badge>
                <h3 className="mt-2 text-lg font-semibold">{stepName || 'Untitled Step'}</h3>
                {stepDescription && (
                  <p className="mt-1 text-sm text-muted-foreground">{stepDescription}</p>
                )}
              </div>
              {expectedOutcome && (
                <div>
                  <p className="text-sm font-medium">Expected Outcome</p>
                  <p className="text-sm text-muted-foreground">{expectedOutcome}</p>
                </div>
              )}
              {manualChecklist && (
                <div>
                  <p className="text-sm font-medium">Checklist</p>
                  <ul className="mt-2 space-y-1">
                    {manualChecklist.split('\n').filter((item) => item.trim()).map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm">
                        <span className="text-muted-foreground">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
