'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { ArrowLeft, Edit, Save, Plus, Trash2, Download, RefreshCw, MapPin, ArrowUp, ArrowDown, Flag } from 'lucide-react';
import type { OpsView, OpsViewDashboard, RunbookStep, PriorityLevel, Timeframe, GeoTarget } from '@/types/ops';
import { getOpsView, updateOpsView, deleteOpsView, regenerateSEO, getOpsViewDashboard, exportOpsBrief, getRunbookStepsByView, createRunbookStep, deleteRunbookStep, updateRunbookStep, assignGeoTargetsToView, generateGeoVariantsForView } from '@/lib/ops-data-service';
import { ExportDialog } from '@/components/ExportDialog';
import { ResonanceBadge } from '@/components/ResonanceBadge';
import { calculateResonanceScore } from '@/lib/analytics-service';

interface PageProps {
  params: Promise<{ id: string }>;
}

export default function OpsViewDetailPage({ params }: PageProps): JSX.Element {
  const router = useRouter();
  const [viewId, setViewId] = useState<string | null>(null);
  const [view, setView] = useState<OpsView | null>(null);
  const [dashboard, setDashboard] = useState<OpsViewDashboard | null>(null);
  const [steps, setSteps] = useState<RunbookStep[]>([]);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [isAddStepOpen, setIsAddStepOpen] = useState<boolean>(false);
  const [exportedBrief, setExportedBrief] = useState<string>('');

  // Edit form
  const [editName, setEditName] = useState<string>('');
  const [editDescription, setEditDescription] = useState<string>('');
  const [editPriority, setEditPriority] = useState<PriorityLevel>('medium');
  const [editTimeframe, setEditTimeframe] = useState<Timeframe>('today');
  const [editObjectFilters, setEditObjectFilters] = useState<string>('');
  const [editActionFilters, setEditActionFilters] = useState<string>('');
  const [editNotes, setEditNotes] = useState<string>('');

  // SEO fields
  const [seoTitle, setSeoTitle] = useState<string>('');
  const [seoDescription, setSeoDescription] = useState<string>('');
  const [seoKeywords, setSeoKeywords] = useState<string>('');
  const [seoHashtags, setSeoHashtags] = useState<string>('');
  const [seoAltText, setSeoAltText] = useState<string>('');

  // New step form
  const [newStepName, setNewStepName] = useState<string>('');
  const [newStepDescription, setNewStepDescription] = useState<string>('');
  const [newStepExpected, setNewStepExpected] = useState<string>('');
  const [newStepRelatedObjects, setNewStepRelatedObjects] = useState<string>('');
  const [newStepRelatedActions, setNewStepRelatedActions] = useState<string>('');
  const [newStepChecklist, setNewStepChecklist] = useState<string>('');

  useEffect(() => {
    params.then((resolvedParams) => {
      setViewId(resolvedParams.id);
    });
  }, [params]);

  useEffect(() => {
    if (viewId) {
      loadData();
    }
  }, [viewId]);

  function loadData(): void {
    if (!viewId) return;

    const loadedView = getOpsView(viewId);
    if (!loadedView) {
      router.push('/');
      return;
    }

    setView(loadedView);
    setEditName(loadedView.name);
    setEditDescription(loadedView.description);
    setEditPriority(loadedView.priorityLevel);
    setEditTimeframe(loadedView.defaultTimeframe);
    setEditObjectFilters(loadedView.objectFilters.join(', '));
    setEditActionFilters(loadedView.actionFilters.join(', '));
    setEditNotes(loadedView.notes);

    setSeoTitle(loadedView.seoTitle);
    setSeoDescription(loadedView.seoDescription);
    setSeoKeywords(loadedView.seoKeywords.join(', '));
    setSeoHashtags(loadedView.seoHashtags.join(', '));
    setSeoAltText(loadedView.altText);

    const loadedDashboard = getOpsViewDashboard(viewId);
    setDashboard(loadedDashboard);

    const loadedSteps = getRunbookStepsByView(viewId);
    setSteps(loadedSteps);
  }

  function handleSave(): void {
    if (!viewId) return;

    updateOpsView(viewId, {
      name: editName,
      description: editDescription,
      priorityLevel: editPriority,
      defaultTimeframe: editTimeframe,
      objectFilters: editObjectFilters.split(',').map((f) => f.trim()).filter((f) => f),
      actionFilters: editActionFilters.split(',').map((f) => f.trim()).filter((f) => f),
      notes: editNotes,
      seoTitle,
      seoDescription,
      seoKeywords: seoKeywords.split(',').map((k) => k.trim()).filter((k) => k),
      seoHashtags: seoHashtags.split(',').map((h) => h.trim()).filter((h) => h),
      altText: seoAltText,
    });

    setIsEditing(false);
    loadData();
  }

  function handleDelete(): void {
    if (!viewId) return;
    deleteOpsView(viewId);
    router.push('/');
  }

  function handleRegenerateSEO(): void {
    if (!viewId) return;
    regenerateSEO(viewId);
    loadData();
  }

  function handleRefreshDashboard(): void {
    if (!viewId) return;
    const refreshed = getOpsViewDashboard(viewId);
    setDashboard(refreshed);
  }

  function handleExportBrief(): void {
    if (!viewId || !view) return;
    const brief = exportOpsBrief(viewId, view.defaultTimeframe);
    setExportedBrief(brief);
  }

  function handleAddStep(): void {
    if (!viewId || !newStepName.trim()) return;

    const relatedObjects = newStepRelatedObjects
      .split(',')
      .map((o) => o.trim())
      .filter((o) => o);
    const relatedActions = newStepRelatedActions
      .split(',')
      .map((a) => a.trim())
      .filter((a) => a);
    const checklist = newStepChecklist
      .split('\n')
      .map((c) => c.trim())
      .filter((c) => c);

    createRunbookStep({
      viewId,
      stepName: newStepName,
      stepOrder: steps.length + 1,
      stepDescription: newStepDescription,
      relatedObjects,
      relatedActionTypes: relatedActions,
      expectedOutcome: newStepExpected,
      manualChecklist: checklist,
    });

    setNewStepName('');
    setNewStepDescription('');
    setNewStepExpected('');
    setNewStepRelatedObjects('');
    setNewStepRelatedActions('');
    setNewStepChecklist('');
    setIsAddStepOpen(false);
    loadData();
  }

  function handleDeleteStep(stepId: string): void {
    deleteRunbookStep(stepId);
    loadData();
  }

  function handleMoveStepUp(index: number): void {
    if (index === 0) return;
    
    const step1 = steps[index];
    const step2 = steps[index - 1];
    
    updateRunbookStep(step1.id, { stepOrder: step2.stepOrder });
    updateRunbookStep(step2.id, { stepOrder: step1.stepOrder });
    
    loadData();
  }

  function handleMoveStepDown(index: number): void {
    if (index === steps.length - 1) return;
    
    const step1 = steps[index];
    const step2 = steps[index + 1];
    
    updateRunbookStep(step1.id, { stepOrder: step2.stepOrder });
    updateRunbookStep(step2.id, { stepOrder: step1.stepOrder });
    
    loadData();
  }

  if (!view) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-6xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" size="icon">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold">{view.name}</h1>
              <p className="text-sm text-muted-foreground">{view.description}</p>
            </div>
          </div>
          <div className="flex gap-2">
            {isEditing ? (
              <>
                <Button variant="outline" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSave}>
                  <Save className="mr-2 h-4 w-4" />
                  Save
                </Button>
              </>
            ) : (
              <>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" size="icon">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete View?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will permanently delete this view and all its runbook steps.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
                <Button onClick={() => setIsEditing(true)}>
                  <Edit className="mr-2 h-4 w-4" />
                  Edit
                </Button>
              </>
            )}
          </div>
        </div>

        <Tabs defaultValue="config" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="config">Configuration</TabsTrigger>
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="runbook">Runbook Steps</TabsTrigger>
            <TabsTrigger value="export">Export</TabsTrigger>
          </TabsList>

          {/* CONFIGURATION TAB */}
          <TabsContent value="config" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Identity & Scope</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {isEditing ? (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="edit-name">Name</Label>
                      <Input
                        id="edit-name"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-desc">Description</Label>
                      <Textarea
                        id="edit-desc"
                        value={editDescription}
                        onChange={(e) => setEditDescription(e.target.value)}
                        rows={3}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="edit-priority">Priority</Label>
                        <Select value={editPriority} onValueChange={(v) => setEditPriority(v as PriorityLevel)}>
                          <SelectTrigger id="edit-priority">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Low</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="critical">Critical</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="edit-timeframe">Default Timeframe</Label>
                        <Select value={editTimeframe} onValueChange={(v) => setEditTimeframe(v as Timeframe)}>
                          <SelectTrigger id="edit-timeframe">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="today">Today</SelectItem>
                            <SelectItem value="yesterday">Yesterday</SelectItem>
                            <SelectItem value="last-7-days">Last 7 Days</SelectItem>
                            <SelectItem value="week-to-date">Week to Date</SelectItem>
                            <SelectItem value="custom">Custom</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-obj-filters">Object Filters</Label>
                      <Input
                        id="edit-obj-filters"
                        value={editObjectFilters}
                        onChange={(e) => setEditObjectFilters(e.target.value)}
                        placeholder="culture, token, drop"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-action-filters">Action Filters</Label>
                      <Input
                        id="edit-action-filters"
                        value={editActionFilters}
                        onChange={(e) => setEditActionFilters(e.target.value)}
                        placeholder="ANNOUNCE_DROP, POST_FC"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-notes">Notes</Label>
                      <Textarea
                        id="edit-notes"
                        value={editNotes}
                        onChange={(e) => setEditNotes(e.target.value)}
                        rows={4}
                      />
                    </div>
                  </>
                ) : (
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Priority</p>
                      <Badge className="capitalize">{view.priorityLevel}</Badge>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Default Timeframe</p>
                      <p className="capitalize">{view.defaultTimeframe.replace(/-/g, ' ')}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Object Filters</p>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {view.objectFilters.map((filter, i) => (
                          <Badge key={i} variant="secondary">{filter}</Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Action Filters</p>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {view.actionFilters.map((filter, i) => (
                          <Badge key={i} variant="secondary">{filter}</Badge>
                        ))}
                      </div>
                    </div>
                    {view.notes && (
                      <div className="md:col-span-2">
                        <p className="text-sm font-medium text-muted-foreground">Notes</p>
                        <p className="whitespace-pre-wrap">{view.notes}</p>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>SEO & Metadata</CardTitle>
                  {!isEditing && (
                    <Button variant="outline" size="sm" onClick={handleRegenerateSEO}>
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Regenerate
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {isEditing ? (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="seo-title">SEO Title</Label>
                      <Input
                        id="seo-title"
                        value={seoTitle}
                        onChange={(e) => setSeoTitle(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="seo-desc">SEO Description</Label>
                      <Textarea
                        id="seo-desc"
                        value={seoDescription}
                        onChange={(e) => setSeoDescription(e.target.value)}
                        rows={2}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="seo-keywords">Keywords</Label>
                      <Input
                        id="seo-keywords"
                        value={seoKeywords}
                        onChange={(e) => setSeoKeywords(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="seo-hashtags">Hashtags</Label>
                      <Input
                        id="seo-hashtags"
                        value={seoHashtags}
                        onChange={(e) => setSeoHashtags(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="seo-alt">Alt Text</Label>
                      <Input
                        id="seo-alt"
                        value={seoAltText}
                        onChange={(e) => setSeoAltText(e.target.value)}
                      />
                    </div>
                  </>
                ) : (
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Title</p>
                      <p>{view.seoTitle}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Description</p>
                      <p className="text-sm">{view.seoDescription}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Keywords</p>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {view.seoKeywords.map((keyword, i) => (
                          <Badge key={i} variant="outline">{keyword}</Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Hashtags</p>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {view.seoHashtags.map((hashtag, i) => (
                          <Badge key={i} variant="outline">{hashtag}</Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* DASHBOARD TAB */}
          <TabsContent value="dashboard" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Dashboard Preview</CardTitle>
                    <CardDescription>
                      {dashboard?.period && `Showing data for: ${dashboard.period}`}
                    </CardDescription>
                  </div>
                  <Button variant="outline" onClick={handleRefreshDashboard}>
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Refresh
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {dashboard && dashboard.objects.length > 0 ? (
                  <div className="space-y-4">
                    {dashboard.allFlags.length > 0 && (
                      <div className="rounded-lg border border-orange-200 bg-orange-50 p-4 dark:border-orange-800 dark:bg-orange-950">
                        <p className="mb-2 text-sm font-medium">Active Flags</p>
                        <div className="flex flex-wrap gap-2">
                          {dashboard.allFlags.map((flag, i) => (
                            <Badge key={i} variant="destructive">
                              <Flag className="mr-1 h-3 w-3" />
                              {flag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    <div className="space-y-3">
                      {dashboard.objects.map(({ object, latestMetric }) => {
                        const resonance = calculateResonanceScore(object.id);
                        return (
                        <Card key={object.id}>
                          <CardHeader className="pb-3">
                            <div className="flex items-start justify-between">
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <CardTitle className="text-base">
                                    {object.primaryEmoji && <span className="mr-2">{object.primaryEmoji}</span>}
                                    {object.name}
                                  </CardTitle>
                                  <ResonanceBadge
                                    level={resonance.level}
                                    score={resonance.score}
                                    showScore={false}
                                  />
                                </div>
                                <CardDescription>
                                  {object.type} • {object.category || 'No category'}
                                </CardDescription>
                              </div>
                              <Badge className="capitalize">{object.importanceLevel}</Badge>
                            </div>
                          </CardHeader>
                          {latestMetric && (
                            <CardContent>
                              <div className="space-y-2">
                                <div>
                                  <p className="text-sm font-medium">Status</p>
                                  <Badge>{latestMetric.statusSummary}</Badge>
                                </div>
                                {Object.keys(latestMetric.keyNumbers).length > 0 && (
                                  <div>
                                    <p className="text-sm font-medium">Metrics</p>
                                    <div className="mt-1 flex flex-wrap gap-2">
                                      {Object.entries(latestMetric.keyNumbers).map(([key, value]) => (
                                        <Badge key={key} variant="secondary">
                                          {key}: {value}
                                        </Badge>
                                      ))}
                                    </div>
                                  </div>
                                )}
                              </div>
                            </CardContent>
                          )}
                        </Card>
                      );
                    })}
                    </div>
                  </div>
                ) : (
                  <div className="rounded-lg border border-dashed p-8 text-center">
                    <p className="text-muted-foreground">
                      No objects match this view's filters or no metrics exist yet.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* RUNBOOK STEPS TAB */}
          <TabsContent value="runbook" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Runbook Steps</CardTitle>
                    <CardDescription>Operational checklist and procedures</CardDescription>
                  </div>
                  <Dialog open={isAddStepOpen} onOpenChange={setIsAddStepOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="mr-2 h-4 w-4" />
                        Add Step
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Add Runbook Step</DialogTitle>
                        <DialogDescription>Define a new step in the operational runbook</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div className="space-y-2">
                          <Label htmlFor="step-name">Step Name *</Label>
                          <Input
                            id="step-name"
                            value={newStepName}
                            onChange={(e) => setNewStepName(e.target.value)}
                            placeholder="e.g., Check pending actions"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="step-desc">Description</Label>
                          <Textarea
                            id="step-desc"
                            value={newStepDescription}
                            onChange={(e) => setNewStepDescription(e.target.value)}
                            rows={3}
                            placeholder="What needs to be done?"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="step-expected">Expected Outcome</Label>
                          <Input
                            id="step-expected"
                            value={newStepExpected}
                            onChange={(e) => setNewStepExpected(e.target.value)}
                            placeholder="What does done look like?"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="step-objects">Related Objects</Label>
                            <Input
                              id="step-objects"
                              value={newStepRelatedObjects}
                              onChange={(e) => setNewStepRelatedObjects(e.target.value)}
                              placeholder="Object IDs or tags (comma separated)"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="step-actions">Related Action Types</Label>
                            <Input
                              id="step-actions"
                              value={newStepRelatedActions}
                              onChange={(e) => setNewStepRelatedActions(e.target.value)}
                              placeholder="Action codes (comma separated)"
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="step-checklist">Manual Checklist</Label>
                          <Textarea
                            id="step-checklist"
                            value={newStepChecklist}
                            onChange={(e) => setNewStepChecklist(e.target.value)}
                            rows={4}
                            placeholder="One item per line"
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setIsAddStepOpen(false)}>
                          Cancel
                        </Button>
                        <Button onClick={handleAddStep}>Add Step</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                {steps.length === 0 ? (
                  <div className="rounded-lg border border-dashed p-8 text-center">
                    <p className="text-muted-foreground">
                      No steps defined yet. Add your first runbook step.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {steps.map((step, index) => (
                      <Card key={step.id}>
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <CardTitle className="text-base">
                                {step.stepOrder}. {step.stepName}
                              </CardTitle>
                              {step.stepDescription && (
                                <CardDescription className="mt-1">
                                  {step.stepDescription}
                                </CardDescription>
                              )}
                            </div>
                            <div className="flex gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleMoveStepUp(index)}
                                disabled={index === 0}
                              >
                                <ArrowUp className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleMoveStepDown(index)}
                                disabled={index === steps.length - 1}
                              >
                                <ArrowDown className="h-4 w-4" />
                              </Button>
                                   <Link href={`/steps/${step.id}`}>
                                <Button variant="ghost" size="icon">
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </Link>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Delete Step?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      This will permanently delete this runbook step.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => handleDeleteStep(step.id)}>
                                      Delete
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </div>
                        </CardHeader>
                        {step.expectedOutcome && (
                          <CardContent>
                            <p className="text-sm">
                              <span className="font-medium">Expected: </span>
                              {step.expectedOutcome}
                            </p>
                          </CardContent>
                        )}
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* EXPORT TAB */}
          <TabsContent value="export" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Export Ops Brief</CardTitle>
                <CardDescription>
                  Generate and download operational briefs in multiple formats
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <ExportDialog
                    type="brief"
                    id={viewId!}
                    periodLabel={view.defaultTimeframe}
                    triggerLabel="Export Ops Brief"
                  />
                  <Button variant="outline" onClick={handleExportBrief}>
                    <Download className="mr-2 h-4 w-4" />
                    Preview Text Format
                  </Button>
                </div>
                {exportedBrief && (
                  <div>
                    <Label htmlFor="brief-output">Brief Preview (Text Format)</Label>
                    <Textarea
                      id="brief-output"
                      value={exportedBrief}
                      readOnly
                      rows={20}
                      className="font-mono text-xs"
                    />
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
