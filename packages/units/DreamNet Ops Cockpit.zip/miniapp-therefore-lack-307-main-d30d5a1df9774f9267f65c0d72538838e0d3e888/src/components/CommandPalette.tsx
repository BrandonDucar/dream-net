"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import {
  listOpsObjects,
  listOpsViews,
  listRunbookSessions,
  startRunbookSession,
} from "@/lib/ops-data-service";

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((open) => !open);
      }
    };

    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, []);

  const handleCommand = (command: string, id?: string) => {
    setOpen(false);

    switch (command) {
      case "home":
        router.push("/");
        break;
      case "object":
        if (id) router.push(`/objects/${id}`);
        break;
      case "view":
        if (id) router.push(`/views/${id}`);
        break;
      case "session":
        if (id) router.push(`/sessions/${id}`);
        break;
      case "sessions":
        router.push("/sessions");
        break;
      case "start-session":
        // This would open a dialog in a full implementation
        alert("Quick session start - select a view and operator name");
        break;
      default:
        break;
    }
  };

  const objects = listOpsObjects();
  const views = listOpsViews();
  const recentSessions = listRunbookSessions().slice(0, 5);

  return (
    <>
      {/* Trigger hint */}
      <div className="fixed bottom-4 right-4 z-50">
        <kbd className="pointer-events-none inline-flex h-7 select-none items-center gap-1 rounded border bg-muted px-2 font-mono text-[10px] font-medium text-muted-foreground opacity-100 hover:opacity-0 transition-opacity">
          <span className="text-xs">⌘</span>K
        </kbd>
      </div>

      <CommandDialog open={open} onOpenChange={setOpen}>
        <CommandInput placeholder="Type a command or search..." />
        <CommandList>
          <CommandEmpty>No results found.</CommandEmpty>

          <CommandGroup heading="Quick Actions">
            <CommandItem onSelect={() => handleCommand("home")}>
              <span className="mr-2">🏠</span>
              <span>Go to Overview</span>
            </CommandItem>
            <CommandItem onSelect={() => handleCommand("sessions")}>
              <span className="mr-2">📋</span>
              <span>View All Sessions</span>
            </CommandItem>
            <CommandItem onSelect={() => handleCommand("start-session")}>
              <span className="mr-2">▶️</span>
              <span>Start New Runbook Session</span>
            </CommandItem>
          </CommandGroup>

          {objects.length > 0 && (
            <>
              <CommandSeparator />
              <CommandGroup heading="Ops Objects">
                {objects.slice(0, 8).map((obj) => (
                  <CommandItem
                    key={obj.id}
                    onSelect={() => handleCommand("object", obj.id)}
                  >
                    <span className="mr-2">{obj.primaryEmoji || "•"}</span>
                    <span>{obj.name}</span>
                    <span className="ml-auto text-xs text-muted-foreground">
                      {obj.type}
                    </span>
                  </CommandItem>
                ))}
              </CommandGroup>
            </>
          )}

          {views.length > 0 && (
            <>
              <CommandSeparator />
              <CommandGroup heading="Ops Views">
                {views.slice(0, 5).map((view) => (
                  <CommandItem
                    key={view.id}
                    onSelect={() => handleCommand("view", view.id)}
                  >
                    <span className="mr-2">👁️</span>
                    <span>{view.name}</span>
                    <span className="ml-auto text-xs text-muted-foreground">
                      {view.priorityLevel}
                    </span>
                  </CommandItem>
                ))}
              </CommandGroup>
            </>
          )}

          {recentSessions.length > 0 && (
            <>
              <CommandSeparator />
              <CommandGroup heading="Recent Sessions">
                {recentSessions.map((session) => (
                  <CommandItem
                    key={session.id}
                    onSelect={() => handleCommand("session", session.id)}
                  >
                    <span className="mr-2">
                      {session.finishedAt ? "✅" : "⏳"}
                    </span>
                    <span>{session.operatorName}</span>
                    <span className="ml-auto text-xs text-muted-foreground">
                      {session.date}
                    </span>
                  </CommandItem>
                ))}
              </CommandGroup>
            </>
          )}
        </CommandList>
      </CommandDialog>
    </>
  );
}
