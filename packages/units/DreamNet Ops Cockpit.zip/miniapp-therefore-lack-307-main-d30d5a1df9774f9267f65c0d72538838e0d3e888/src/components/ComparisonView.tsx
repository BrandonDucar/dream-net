"use client";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { OpsMetricSnapshot } from "@/types/ops";

interface ComparisonViewProps {
  current: OpsMetricSnapshot;
  previous: OpsMetricSnapshot;
  objectName: string;
}

export function ComparisonView({
  current,
  previous,
  objectName,
}: ComparisonViewProps) {
  const calculateChange = (currentVal: number, previousVal: number): string => {
    if (previousVal === 0) return "+100%";
    const change = ((currentVal - previousVal) / previousVal) * 100;
    return `${change > 0 ? "+" : ""}${change.toFixed(1)}%`;
  };

  const getTrendIcon = (currentVal: number, previousVal: number): string => {
    if (currentVal > previousVal) return "📈";
    if (currentVal < previousVal) return "📉";
    return "➡️";
  };

  const getTrendColor = (currentVal: number, previousVal: number): string => {
    if (currentVal > previousVal) return "text-green-500";
    if (currentVal < previousVal) return "text-red-500";
    return "text-gray-500";
  };

  // Get all unique metric keys
  const allKeys = Array.from(
    new Set([
      ...Object.keys(current.keyNumbers),
      ...Object.keys(previous.keyNumbers),
    ])
  );

  return (
    <Card className="p-6">
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-semibold mb-1">📊 Snapshot Comparison</h3>
          <p className="text-sm text-muted-foreground">{objectName}</p>
        </div>

        {/* Period Labels */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Badge variant="default">{current.periodLabel}</Badge>
            <p className="text-xs text-muted-foreground mt-1">
              {new Date(current.timestamp).toLocaleDateString()}
            </p>
          </div>
          <div>
            <Badge variant="outline">{previous.periodLabel}</Badge>
            <p className="text-xs text-muted-foreground mt-1">
              {new Date(previous.timestamp).toLocaleDateString()}
            </p>
          </div>
        </div>

        {/* Status Comparison */}
        <div className="border rounded-lg p-3">
          <p className="text-xs text-muted-foreground mb-2">Status</p>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-medium">{current.statusSummary}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">
                {previous.statusSummary}
              </p>
            </div>
          </div>
        </div>

        {/* Metrics Comparison */}
        <div className="space-y-2">
          <p className="text-sm font-medium">Key Numbers</p>
          {allKeys.map((key) => {
            const currentVal = current.keyNumbers[key] || 0;
            const previousVal = previous.keyNumbers[key] || 0;
            const change = calculateChange(currentVal, previousVal);

            return (
              <div
                key={key}
                className="border rounded-lg p-3 hover:bg-accent/50 transition-colors"
              >
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm font-medium capitalize">{key}</p>
                  <span className={`text-xs font-bold ${getTrendColor(currentVal, previousVal)}`}>
                    {getTrendIcon(currentVal, previousVal)} {change}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-2xl font-bold">{currentVal}</p>
                    <p className="text-xs text-muted-foreground">Current</p>
                  </div>
                  <div>
                    <p className="text-xl text-muted-foreground">{previousVal}</p>
                    <p className="text-xs text-muted-foreground">Previous</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Flags Comparison */}
        <div className="border-t pt-4">
          <p className="text-sm font-medium mb-2">Flags</p>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-muted-foreground mb-1">Current</p>
              <div className="flex flex-wrap gap-1">
                {current.keyFlags.length > 0 ? (
                  current.keyFlags.map((flag, i) => (
                    <Badge key={i} variant="secondary" className="text-xs">
                      {flag}
                    </Badge>
                  ))
                ) : (
                  <span className="text-xs text-muted-foreground">None</span>
                )}
              </div>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Previous</p>
              <div className="flex flex-wrap gap-1">
                {previous.keyFlags.length > 0 ? (
                  previous.keyFlags.map((flag, i) => (
                    <Badge key={i} variant="outline" className="text-xs">
                      {flag}
                    </Badge>
                  ))
                ) : (
                  <span className="text-xs text-muted-foreground">None</span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
