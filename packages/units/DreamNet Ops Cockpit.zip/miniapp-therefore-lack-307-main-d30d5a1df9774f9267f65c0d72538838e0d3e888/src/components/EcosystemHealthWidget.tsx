"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { calculateEcosystemHealth } from "@/lib/analytics-service";
import type { EcosystemHealth } from "@/lib/analytics-service";

export function EcosystemHealthWidget() {
  const [health, setHealth] = useState<EcosystemHealth | null>(null);

  useEffect(() => {
    const updateHealth = () => {
      const newHealth = calculateEcosystemHealth();
      setHealth(newHealth);
    };

    updateHealth();
    const interval = setInterval(updateHealth, 30000); // Update every 30s

    return () => clearInterval(interval);
  }, []);

  if (!health) {
    return (
      <Card className="p-6">
        <p className="text-sm text-muted-foreground">Calculating health...</p>
      </Card>
    );
  }

  const getHealthColor = (score: number) => {
    if (score >= 80) return "text-green-500";
    if (score >= 60) return "text-yellow-500";
    if (score >= 40) return "text-orange-500";
    return "text-red-500";
  };

  const getTrendEmoji = (trend: "up" | "down" | "stable") => {
    if (trend === "up") return "📈";
    if (trend === "down") return "📉";
    return "➡️";
  };

  return (
    <Card className="p-6">
      <div className="space-y-6">
        {/* Overall Health */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-lg font-semibold">🌐 Ecosystem Health</h3>
            <Badge variant={health.overall >= 70 ? "default" : "destructive"}>
              {health.overall}%
            </Badge>
          </div>
          <Progress value={health.overall} className="h-3" />
        </div>

        {/* Component Scores */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Content Production */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">
                {getTrendEmoji(health.contentProduction.trend)} Content Production
              </span>
              <span className={`text-sm font-bold ${getHealthColor(health.contentProduction.score)}`}>
                {health.contentProduction.score}%
              </span>
            </div>
            <Progress value={health.contentProduction.score} className="h-2" />
            <p className="text-xs text-muted-foreground">
              {health.contentProduction.postsPerDay.toFixed(1)} posts/day
            </p>
          </div>

          {/* Distribution Efficiency */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">
                {getTrendEmoji(health.distributionEfficiency.trend)} Distribution
              </span>
              <span className={`text-sm font-bold ${getHealthColor(health.distributionEfficiency.score)}`}>
                {health.distributionEfficiency.score}%
              </span>
            </div>
            <Progress value={health.distributionEfficiency.score} className="h-2" />
            <p className="text-xs text-muted-foreground">
              {health.distributionEfficiency.reachPerEffort} avg reach
            </p>
          </div>

          {/* Operational Velocity */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">⚡ Operations</span>
              <span className={`text-sm font-bold ${getHealthColor(health.operationalVelocity.score)}`}>
                {health.operationalVelocity.score}%
              </span>
            </div>
            <Progress value={health.operationalVelocity.score} className="h-2" />
            <p className="text-xs text-muted-foreground">
              {health.operationalVelocity.actionsPerDay.toFixed(1)} actions/day
            </p>
          </div>

          {/* Community Engagement */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">
                {getTrendEmoji(health.communityEngagement.trend)} Community
              </span>
              <span className={`text-sm font-bold ${getHealthColor(health.communityEngagement.score)}`}>
                {health.communityEngagement.score}%
              </span>
            </div>
            <Progress value={health.communityEngagement.score} className="h-2" />
            <p className="text-xs text-muted-foreground">
              {health.communityEngagement.avgInteractions} avg interactions
            </p>
          </div>
        </div>

        {/* Timestamp */}
        <p className="text-xs text-muted-foreground text-center">
          Last updated: {new Date(health.timestamp).toLocaleTimeString()}
        </p>
      </div>
    </Card>
  );
}
