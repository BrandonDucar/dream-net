"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  exportOpsBriefMarkdown,
  exportOpsBriefJSON,
  exportSessionReportMarkdown,
  downloadFile,
} from "@/lib/export-service";
import { exportOpsBrief, exportRunbookSessionReport } from "@/lib/ops-data-service";

interface ExportDialogProps {
  type: "brief" | "session";
  id: string;
  periodLabel?: string;
  triggerLabel?: string;
}

export function ExportDialog({
  type,
  id,
  periodLabel = "today",
  triggerLabel = "Export",
}: ExportDialogProps) {
  const [activeTab, setActiveTab] = useState("text");

  const getTextExport = () => {
    if (type === "brief") {
      return exportOpsBrief(id, periodLabel);
    } else {
      return exportRunbookSessionReport(id);
    }
  };

  const getMarkdownExport = () => {
    if (type === "brief") {
      return exportOpsBriefMarkdown(id, periodLabel);
    } else {
      return exportSessionReportMarkdown(id);
    }
  };

  const getJSONExport = () => {
    if (type === "brief") {
      return exportOpsBriefJSON(id, periodLabel);
    } else {
      return JSON.stringify({ id, type: "session" }, null, 2);
    }
  };

  const handleDownload = (format: string) => {
    let content = "";
    let mimeType = "";
    let extension = "";

    switch (format) {
      case "text":
        content = getTextExport();
        mimeType = "text/plain";
        extension = "txt";
        break;
      case "markdown":
        content = getMarkdownExport();
        mimeType = "text/markdown";
        extension = "md";
        break;
      case "json":
        content = getJSONExport();
        mimeType = "application/json";
        extension = "json";
        break;
    }

    const filename = `dreamnet-${type}-${Date.now()}.${extension}`;
    downloadFile(content, filename, mimeType);
  };

  const handleCopy = (format: string) => {
    let content = "";

    switch (format) {
      case "text":
        content = getTextExport();
        break;
      case "markdown":
        content = getMarkdownExport();
        break;
      case "json":
        content = getJSONExport();
        break;
    }

    navigator.clipboard.writeText(content);
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline">
          📤 {triggerLabel}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            Export {type === "brief" ? "Ops Brief" : "Session Report"}
          </DialogTitle>
          <DialogDescription>
            Choose your export format and copy or download
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="text">Text</TabsTrigger>
            <TabsTrigger value="markdown">
              Markdown <Badge variant="secondary" className="ml-1 text-xs">Farcaster</Badge>
            </TabsTrigger>
            <TabsTrigger value="json">JSON</TabsTrigger>
          </TabsList>

          <TabsContent value="text" className="space-y-4">
            <Textarea
              readOnly
              value={getTextExport()}
              className="font-mono text-xs min-h-[400px]"
            />
            <div className="flex gap-2">
              <Button onClick={() => handleCopy("text")} variant="outline">
                📋 Copy
              </Button>
              <Button onClick={() => handleDownload("text")} variant="outline">
                ⬇️ Download
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="markdown" className="space-y-4">
            <Textarea
              readOnly
              value={getMarkdownExport()}
              className="font-mono text-xs min-h-[400px]"
            />
            <div className="flex gap-2">
              <Button onClick={() => handleCopy("markdown")} variant="outline">
                📋 Copy
              </Button>
              <Button onClick={() => handleDownload("markdown")} variant="outline">
                ⬇️ Download
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              ✨ Optimized for Farcaster, Discord, and other Markdown platforms
            </p>
          </TabsContent>

          <TabsContent value="json" className="space-y-4">
            <Textarea
              readOnly
              value={getJSONExport()}
              className="font-mono text-xs min-h-[400px]"
            />
            <div className="flex gap-2">
              <Button onClick={() => handleCopy("json")} variant="outline">
                📋 Copy
              </Button>
              <Button onClick={() => handleDownload("json")} variant="outline">
                ⬇️ Download
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              📊 Use this data in other DreamNet apps or external tools
            </p>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
