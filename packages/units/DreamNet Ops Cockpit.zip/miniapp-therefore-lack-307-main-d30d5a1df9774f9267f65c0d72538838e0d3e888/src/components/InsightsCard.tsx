"use client";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { AIInsight } from "@/lib/ai-insights-service";
import Link from "next/link";

interface InsightsCardProps {
  insights: AIInsight[];
  maxDisplay?: number;
}

export function InsightsCard({ insights, maxDisplay = 5 }: InsightsCardProps) {
  const displayedInsights = insights.slice(0, maxDisplay);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical":
        return "destructive";
      case "high":
        return "default";
      case "medium":
        return "secondary";
      case "low":
        return "outline";
      default:
        return "outline";
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "momentum":
        return "Momentum";
      case "alert":
        return "Alert";
      case "prediction":
        return "Prediction";
      case "anomaly":
        return "Anomaly";
      case "suggestion":
        return "Suggestion";
      default:
        return type;
    }
  };

  if (displayedInsights.length === 0) {
    return (
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <span className="text-2xl">🤖</span>
          <h3 className="text-lg font-semibold">AI Insights</h3>
        </div>
        <p className="text-sm text-muted-foreground">
          ✨ All systems nominal. Add more data to see intelligent insights.
        </p>
      </Card>
    );
  }

  return (
    <Card className="p-6">
      <div className="flex items-center gap-3 mb-4">
        <span className="text-2xl">🤖</span>
        <h3 className="text-lg font-semibold">AI Insights</h3>
        {insights.length > maxDisplay && (
          <Badge variant="secondary">{insights.length} total</Badge>
        )}
      </div>

      <div className="space-y-4">
        {displayedInsights.map((insight) => (
          <div
            key={insight.id}
            className="border rounded-lg p-4 hover:bg-accent/50 transition-colors"
          >
            <div className="flex items-start justify-between gap-2 mb-2">
              <div className="flex items-center gap-2">
                <span className="text-lg">{insight.icon}</span>
                <h4 className="font-medium text-sm">{insight.title}</h4>
              </div>
              <div className="flex gap-1 flex-shrink-0">
                <Badge variant={getPriorityColor(insight.priority)} className="text-xs">
                  {insight.priority}
                </Badge>
                <Badge variant="outline" className="text-xs">
                  {getTypeLabel(insight.type)}
                </Badge>
              </div>
            </div>

            <p className="text-sm text-muted-foreground mb-3">
              {insight.description}
            </p>

            {insight.actionable && insight.suggestedAction && (
              <div className="bg-primary/5 border border-primary/20 rounded p-2">
                <p className="text-xs font-medium text-primary">
                  💡 {insight.suggestedAction}
                </p>
              </div>
            )}

            {insight.relatedObjectIds.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1">
                {insight.relatedObjectIds.slice(0, 3).map((objectId) => (
                  <Link key={objectId} href={`/objects/${objectId}`}>
                    <Badge variant="outline" className="text-xs cursor-pointer hover:bg-accent">
                      View Object
                    </Badge>
                  </Link>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {insights.length > maxDisplay && (
        <div className="mt-4 pt-4 border-t">
          <p className="text-xs text-muted-foreground text-center">
            +{insights.length - maxDisplay} more insights available
          </p>
        </div>
      )}
    </Card>
  );
}
