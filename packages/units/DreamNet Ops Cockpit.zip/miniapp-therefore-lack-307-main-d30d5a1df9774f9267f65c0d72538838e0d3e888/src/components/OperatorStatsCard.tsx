"use client";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import type { OperatorStats } from "@/lib/gamification-service";

interface OperatorStatsCardProps {
  stats: OperatorStats;
}

export function OperatorStatsCard({ stats }: OperatorStatsCardProps) {
  const completionRate =
    stats.totalSessions > 0
      ? (stats.completedSessions / stats.totalSessions) * 100
      : 0;

  return (
    <Card className="p-6">
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h3 className="text-lg font-semibold mb-1">
            👤 {stats.operatorName}
          </h3>
          <p className="text-sm text-muted-foreground">
            Operator Performance Stats
          </p>
        </div>

        {/* Streak */}
        {stats.currentStreak > 0 && (
          <div className="bg-gradient-to-r from-orange-500/10 to-red-500/10 border border-orange-500/20 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">🔥 {stats.currentStreak}</p>
                <p className="text-xs text-muted-foreground">Day Streak</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium">
                  Longest: {stats.longestStreak} days
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Key Metrics */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-2xl font-bold">{stats.totalSessions}</p>
            <p className="text-xs text-muted-foreground">Total Sessions</p>
          </div>
          <div className="space-y-1">
            <p className="text-2xl font-bold">{stats.completedSessions}</p>
            <p className="text-xs text-muted-foreground">Completed</p>
          </div>
          <div className="space-y-1">
            <p className="text-2xl font-bold">{stats.totalSteps}</p>
            <p className="text-xs text-muted-foreground">Steps Done</p>
          </div>
          <div className="space-y-1">
            <p className="text-2xl font-bold">{stats.avgCompletionTime}m</p>
            <p className="text-xs text-muted-foreground">Avg Time</p>
          </div>
        </div>

        {/* Completion Rate */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Completion Rate</span>
            <span className="text-sm font-bold">{completionRate.toFixed(0)}%</span>
          </div>
          <Progress value={completionRate} className="h-2" />
        </div>

        {/* Flags */}
        <div className="grid grid-cols-2 gap-4 border-t pt-4">
          <div>
            <p className="text-lg font-bold text-orange-500">
              🚩 {stats.totalFlags}
            </p>
            <p className="text-xs text-muted-foreground">Flags Raised</p>
          </div>
          <div>
            <p className="text-lg font-bold text-green-500">
              ✅ {stats.flagsResolved}
            </p>
            <p className="text-xs text-muted-foreground">Flags Resolved</p>
          </div>
        </div>

        {/* Badges */}
        {stats.badges.length > 0 && (
          <div className="border-t pt-4">
            <h4 className="text-sm font-medium mb-3">🏆 Badges Earned</h4>
            <div className="grid grid-cols-3 gap-2">
              {stats.badges.map((badge) => (
                <div
                  key={badge.id}
                  className="flex flex-col items-center p-2 rounded border bg-accent/50 hover:bg-accent transition-colors"
                  title={badge.description}
                >
                  <span className="text-2xl mb-1">{badge.emoji}</span>
                  <span className="text-[10px] text-center leading-tight">
                    {badge.name}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {stats.badges.length === 0 && (
          <div className="border-t pt-4">
            <p className="text-sm text-muted-foreground text-center">
              Complete more sessions to earn badges! 🎯
            </p>
          </div>
        )}
      </div>
    </Card>
  );
}
