"use client";

import { Badge } from "@/components/ui/badge";
import {
  getResonanceLevelColor,
  getResonanceLevelEmoji,
} from "@/lib/analytics-service";
import type { ResonanceLevel } from "@/lib/analytics-service";

interface ResonanceBadgeProps {
  level: ResonanceLevel;
  score: number;
  showScore?: boolean;
}

export function ResonanceBadge({
  level,
  score,
  showScore = true,
}: ResonanceBadgeProps) {
  const emoji = getResonanceLevelEmoji(level);

  const getVariant = () => {
    if (level === "hot" || level === "rising") return "default";
    if (level === "steady") return "secondary";
    return "outline";
  };

  return (
    <Badge variant={getVariant()} className="gap-1">
      <span>{emoji}</span>
      <span className="capitalize">{level}</span>
      {showScore && <span className="font-mono">({score})</span>}
    </Badge>
  );
}
