"use client";

interface SparklineProps {
  data: number[];
  width?: number;
  height?: number;
  color?: string;
  trend?: "up" | "down" | "stable";
}

export function Sparkline({
  data,
  width = 60,
  height = 20,
  color = "#3b82f6",
  trend,
}: SparklineProps) {
  if (data.length < 2) {
    return (
      <div
        style={{ width, height }}
        className="flex items-center justify-center text-xs text-gray-400"
      >
        —
      </div>
    );
  }

  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;

  const points = data
    .map((value, index) => {
      const x = (index / (data.length - 1)) * width;
      const y = height - ((value - min) / range) * height;
      return `${x},${y}`;
    })
    .join(" ");

  // Determine color based on trend if provided
  let strokeColor = color;
  if (trend === "up") strokeColor = "#10b981"; // green
  if (trend === "down") strokeColor = "#ef4444"; // red
  if (trend === "stable") strokeColor = "#6b7280"; // gray

  return (
    <svg width={width} height={height} className="inline-block">
      <polyline
        points={points}
        fill="none"
        stroke={strokeColor}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Last point indicator */}
      {data.length > 0 && (
        <circle
          cx={(width * (data.length - 1)) / (data.length - 1)}
          cy={height - ((data[data.length - 1] - min) / range) * height}
          r="2"
          fill={strokeColor}
        />
      )}
    </svg>
  );
}
