"use client";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { calculateResonanceScore } from "@/lib/analytics-service";
import type { OpsObjectRef } from "@/types/ops";
import Link from "next/link";

interface StatusHeatMapProps {
  objects: OpsObjectRef[];
}

export function StatusHeatMap({ objects }: StatusHeatMapProps) {
  if (objects.length === 0) {
    return (
      <Card className="p-6">
        <p className="text-sm text-muted-foreground">No objects to display</p>
      </Card>
    );
  }

  // Calculate resonance for each object
  const objectsWithResonance = objects.map((obj) => ({
    ...obj,
    resonance: calculateResonanceScore(obj.id),
  }));

  // Group by type
  const groupedByType: Record<string, typeof objectsWithResonance> = {};
  objectsWithResonance.forEach((obj) => {
    if (!groupedByType[obj.type]) {
      groupedByType[obj.type] = [];
    }
    groupedByType[obj.type].push(obj);
  });

  const getColorClass = (level: string) => {
    switch (level) {
      case "hot":
        return "bg-red-500 hover:bg-red-600 border-red-600";
      case "rising":
        return "bg-orange-500 hover:bg-orange-600 border-orange-600";
      case "steady":
        return "bg-yellow-500 hover:bg-yellow-600 border-yellow-600";
      case "cooling":
        return "bg-blue-500 hover:bg-blue-600 border-blue-600";
      case "dead":
        return "bg-gray-500 hover:bg-gray-600 border-gray-600";
      default:
        return "bg-gray-400 hover:bg-gray-500 border-gray-500";
    }
  };

  return (
    <Card className="p-6">
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-semibold mb-2">🗺️ Status Heat Map</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Visual overview of all objects by resonance level
          </p>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-2 text-xs">
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 bg-red-500 rounded" />
            <span>🔥 Hot</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 bg-orange-500 rounded" />
            <span>⚡ Rising</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 bg-yellow-500 rounded" />
            <span>💫 Steady</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 bg-blue-500 rounded" />
            <span>💤 Cooling</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 bg-gray-500 rounded" />
            <span>💀 Dead</span>
          </div>
        </div>

        {/* Heat Map Grid */}
        <div className="space-y-4">
          {Object.entries(groupedByType).map(([type, objs]) => (
            <div key={type}>
              <h4 className="text-sm font-medium mb-2 capitalize">{type}s</h4>
              <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-2">
                {objs.map((obj) => (
                  <Link key={obj.id} href={`/objects/${obj.id}`}>
                    <div
                      className={`${getColorClass(obj.resonance.level)} aspect-square rounded border-2 flex items-center justify-center text-white text-2xl cursor-pointer transition-all hover:scale-110 shadow-sm`}
                      title={`${obj.name} - ${obj.resonance.level} (${obj.resonance.score})`}
                    >
                      {obj.primaryEmoji || "•"}
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}
