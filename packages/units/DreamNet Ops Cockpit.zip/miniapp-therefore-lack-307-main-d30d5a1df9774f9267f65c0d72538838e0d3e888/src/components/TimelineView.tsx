"use client";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { OpsMetricSnapshot } from "@/types/ops";

interface TimelineViewProps {
  metrics: OpsMetricSnapshot[];
  title?: string;
}

export function TimelineView({ metrics, title = "Timeline" }: TimelineViewProps) {
  if (metrics.length === 0) {
    return (
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-2">{title}</h3>
        <p className="text-sm text-muted-foreground">No timeline data yet</p>
      </Card>
    );
  }

  // Sort by timestamp (most recent first)
  const sortedMetrics = [...metrics].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  const getStatusColor = (status: string) => {
    const lower = status.toLowerCase();
    if (lower.includes("healthy") || lower.includes("good")) return "bg-green-500";
    if (lower.includes("warning") || lower.includes("lagging")) return "bg-yellow-500";
    if (lower.includes("critical") || lower.includes("down")) return "bg-red-500";
    return "bg-blue-500";
  };

  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4">📅 {title}</h3>

      <div className="relative space-y-4">
        {/* Timeline line */}
        <div className="absolute left-2 top-0 bottom-0 w-0.5 bg-border" />

        {sortedMetrics.map((metric, index) => (
          <div key={metric.id} className="relative pl-8">
            {/* Timeline dot */}
            <div
              className={`absolute left-0 w-4 h-4 rounded-full ${getStatusColor(metric.statusSummary)} border-4 border-background`}
            />

            {/* Content */}
            <div className="border rounded-lg p-3 hover:bg-accent/50 transition-colors">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <Badge variant="outline" className="mb-1">
                    {metric.periodLabel}
                  </Badge>
                  <p className="text-sm font-medium">{metric.statusSummary}</p>
                </div>
                <p className="text-xs text-muted-foreground">
                  {new Date(metric.timestamp).toLocaleDateString()}
                </p>
              </div>

              {/* Key Numbers */}
              {Object.keys(metric.keyNumbers).length > 0 && (
                <div className="flex flex-wrap gap-2 mb-2">
                  {Object.entries(metric.keyNumbers).map(([key, value]) => (
                    <div
                      key={key}
                      className="text-xs bg-secondary/50 px-2 py-1 rounded"
                    >
                      <span className="text-muted-foreground">{key}:</span>{" "}
                      <span className="font-mono font-medium">{value}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Flags */}
              {metric.keyFlags.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {metric.keyFlags.map((flag, i) => (
                    <Badge key={i} variant="secondary" className="text-xs">
                      🚩 {flag}
                    </Badge>
                  ))}
                </div>
              )}

              {/* Notes */}
              {metric.notes && (
                <p className="text-xs text-muted-foreground mt-2 italic">
                  {metric.notes}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
