import type {
  OpsObjectRef,
  OpsMetricSnapshot,
  OpsView,
  RunbookSession,
} from "@/types/ops";
import { listOpsObjects, getOpsMetricsByObject } from "./ops-data-service";

export interface AIInsight {
  id: string;
  type: "momentum" | "alert" | "prediction" | "anomaly" | "suggestion";
  priority: "low" | "medium" | "high" | "critical";
  title: string;
  description: string;
  relatedObjectIds: string[];
  actionable: boolean;
  suggestedAction?: string;
  timestamp: string;
  icon: string;
}

// Generate AI-powered insights from current data
export function generateInsights(): AIInsight[] {
  const insights: AIInsight[] = [];
  const objects = listOpsObjects();

  // Detect stale objects (no metrics in 48+ hours)
  const staleObjects = objects.filter((obj) => {
    const metrics = getOpsMetricsByObject(obj.id);
    if (metrics.length === 0) return false;

    const latestMetric = metrics[0];
    const hoursSinceUpdate =
      (Date.now() - new Date(latestMetric.timestamp).getTime()) / (1000 * 60 * 60);

    return hoursSinceUpdate > 48;
  });

  if (staleObjects.length > 0) {
    insights.push({
      id: `stale-${Date.now()}`,
      type: "alert",
      priority: "medium",
      title: `⚠️ ${staleObjects.length} object${staleObjects.length > 1 ? "s" : ""} going silent`,
      description: `No updates in 48+ hours - resonance risk detected`,
      relatedObjectIds: staleObjects.map((obj) => obj.id),
      actionable: true,
      suggestedAction: "Add metric snapshots to keep momentum visible",
      timestamp: new Date().toISOString(),
      icon: "⚠️",
    });
  }

  // Detect high momentum objects (multiple metrics recently)
  objects.forEach((obj) => {
    const metrics = getOpsMetricsByObject(obj.id);
    const recentMetrics = metrics.filter((m) => {
      const hoursSince =
        (Date.now() - new Date(m.timestamp).getTime()) / (1000 * 60 * 60);
      return hoursSince <= 168; // Last week
    });

    if (recentMetrics.length >= 5) {
      const avgEngagement = recentMetrics.reduce((sum, m) => {
        const engagement = Object.values(m.keyNumbers).reduce((a, b) => a + b, 0);
        return sum + engagement;
      }, 0) / recentMetrics.length;

      if (avgEngagement > 50) {
        insights.push({
          id: `momentum-${obj.id}`,
          type: "momentum",
          priority: "high",
          title: `🔥 ${obj.name} showing strong momentum`,
          description: `${recentMetrics.length} updates this week with high engagement`,
          relatedObjectIds: [obj.id],
          actionable: true,
          suggestedAction: "Consider scheduling a drop or campaign",
          timestamp: new Date().toISOString(),
          icon: "🔥",
        });
      }
    }
  });

  // Detect critical objects without recent activity
  const criticalObjects = objects.filter(
    (obj) => obj.importanceLevel === "critical"
  );

  criticalObjects.forEach((obj) => {
    const metrics = getOpsMetricsByObject(obj.id);
    const recentMetrics = metrics.filter((m) => {
      const hoursSince =
        (Date.now() - new Date(m.timestamp).getTime()) / (1000 * 60 * 60);
      return hoursSince <= 24;
    });

    if (recentMetrics.length === 0 && metrics.length > 0) {
      insights.push({
        id: `critical-stale-${obj.id}`,
        type: "alert",
        priority: "critical",
        title: `🚨 Critical object needs attention`,
        description: `${obj.name} has no updates today`,
        relatedObjectIds: [obj.id],
        actionable: true,
        suggestedAction: "Add status update or metric snapshot",
        timestamp: new Date().toISOString(),
        icon: "🚨",
      });
    }
  });

  // Predict content refresh needs (based on historical patterns)
  objects.forEach((obj) => {
    const metrics = getOpsMetricsByObject(obj.id);
    if (metrics.length < 3) return;

    const contentFlags = metrics.filter((m) =>
      m.keyFlags.some((f) => f.toLowerCase().includes("content"))
    );

    if (contentFlags.length >= 2) {
      const daysSinceLastContent = Math.floor(
        (Date.now() - new Date(contentFlags[0].timestamp).getTime()) /
          (1000 * 60 * 60 * 24)
      );

      if (daysSinceLastContent >= 2) {
        insights.push({
          id: `content-refresh-${obj.id}`,
          type: "prediction",
          priority: "medium",
          title: `✨ Content refresh window detected`,
          description: `${obj.name} typically needs content refresh every ${daysSinceLastContent} days`,
          relatedObjectIds: [obj.id],
          actionable: true,
          suggestedAction: "Queue content creation tasks",
          timestamp: new Date().toISOString(),
          icon: "✨",
        });
      }
    }
  });

  // Anomaly detection - sudden engagement spikes
  objects.forEach((obj) => {
    const metrics = getOpsMetricsByObject(obj.id);
    if (metrics.length < 4) return;

    const latest = metrics[0];
    const previous = metrics.slice(1, 4);

    const latestEngagement = Object.values(latest.keyNumbers).reduce(
      (a, b) => a + b,
      0
    );
    const avgPreviousEngagement =
      previous.reduce((sum, m) => {
        return sum + Object.values(m.keyNumbers).reduce((a, b) => a + b, 0);
      }, 0) / previous.length;

    if (latestEngagement > avgPreviousEngagement * 2) {
      insights.push({
        id: `spike-${obj.id}`,
        type: "anomaly",
        priority: "high",
        title: `📈 Unusual activity spike detected`,
        description: `${obj.name} showing 2x engagement increase - investigate opportunity`,
        relatedObjectIds: [obj.id],
        actionable: true,
        suggestedAction: "Capitalize on momentum with immediate actions",
        timestamp: new Date().toISOString(),
        icon: "📈",
      });
    }
  });

  // Sort by priority
  const priorityOrder: Record<string, number> = {
    critical: 0,
    high: 1,
    medium: 2,
    low: 3,
  };

  return insights.sort(
    (a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]
  );
}

// Predict next actions based on time patterns
export function predictNextActions(viewId: string): string[] {
  const now = new Date();
  const hour = now.getHours();
  const dayOfWeek = now.getDay();

  const suggestions: string[] = [];

  // Morning routines
  if (hour >= 6 && hour < 10) {
    suggestions.push("Review overnight metrics and flags");
    suggestions.push("Check critical objects for updates");
    suggestions.push("Queue content for peak engagement hours");
  }

  // Midday
  if (hour >= 10 && hour < 14) {
    suggestions.push("Execute scheduled campaigns");
    suggestions.push("Monitor real-time engagement");
    suggestions.push("Address any raised flags");
  }

  // Afternoon
  if (hour >= 14 && hour < 18) {
    suggestions.push("Prep tomorrow's ops brief");
    suggestions.push("Review today's completed actions");
    suggestions.push("Set up weekend coverage if needed");
  }

  // Friday specific
  if (dayOfWeek === 5) {
    suggestions.push("Prepare weekend coverage plan");
    suggestions.push("Schedule auto-posts for Saturday/Sunday");
    suggestions.push("Brief weekend operator");
  }

  return suggestions;
}

// Generate smart runbook from recent session patterns
export function generateSmartRunbook(
  sessions: RunbookSession[]
): Array<{ stepName: string; frequency: number }> {
  const stepCounts: Record<string, number> = {};

  sessions.forEach((session) => {
    session.completedSteps.forEach((stepId) => {
      stepCounts[stepId] = (stepCounts[stepId] || 0) + 1;
    });
  });

  const sortedSteps = Object.entries(stepCounts)
    .sort(([, a], [, b]) => b - a)
    .map(([stepId, count]) => ({
      stepName: stepId,
      frequency: count,
    }));

  return sortedSteps;
}
