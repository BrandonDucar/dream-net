import type {
  OpsObjectRef,
  OpsMetricSnapshot,
  RunbookSession,
} from "@/types/ops";
import {
  listOpsObjects,
  getOpsMetricsByObject,
  listRunbookSessions,
} from "./ops-data-service";

export type ResonanceLevel = "dead" | "cooling" | "steady" | "rising" | "hot";

export interface ResonanceScore {
  objectId: string;
  score: number; // 0-100
  level: ResonanceLevel;
  trend: "up" | "down" | "stable";
  components: {
    recency: number;
    velocity: number;
    engagement: number;
    consistency: number;
  };
  recommendations: string[];
}

export interface EcosystemHealth {
  overall: number; // 0-100
  contentProduction: {
    score: number;
    postsPerDay: number;
    trend: "up" | "down" | "stable";
  };
  distributionEfficiency: {
    score: number;
    reachPerEffort: number;
    trend: "up" | "down" | "stable";
  };
  operationalVelocity: {
    score: number;
    actionsPerDay: number;
    completionRate: number;
  };
  communityEngagement: {
    score: number;
    avgInteractions: number;
    trend: "up" | "down" | "stable";
  };
  timestamp: string;
}

// Calculate resonance score for an object
export function calculateResonanceScore(objectId: string): ResonanceScore {
  const metrics = getOpsMetricsByObject(objectId);

  if (metrics.length === 0) {
    return {
      objectId,
      score: 0,
      level: "dead",
      trend: "stable",
      components: { recency: 0, velocity: 0, engagement: 0, consistency: 0 },
      recommendations: ["Add initial metric snapshot to start tracking"],
    };
  }

  const latest = metrics[0];
  const recent = metrics.slice(0, 7); // Last 7 snapshots

  // Recency: How fresh is the latest data? (0-25)
  const hoursSinceUpdate =
    (Date.now() - new Date(latest.timestamp).getTime()) / (1000 * 60 * 60);
  const recency = Math.max(0, 25 - hoursSinceUpdate / 2);

  // Velocity: How frequently are updates happening? (0-25)
  const avgTimeBetween =
    recent.length > 1
      ? recent.reduce((sum, m, i) => {
          if (i === 0) return sum;
          const diff =
            (new Date(recent[i - 1].timestamp).getTime() -
              new Date(m.timestamp).getTime()) /
            (1000 * 60 * 60);
          return sum + diff;
        }, 0) /
        (recent.length - 1)
      : 168; // Default to weekly

  const velocity = Math.min(25, (168 / avgTimeBetween) * 5); // More frequent = higher score

  // Engagement: Total of key numbers (0-25)
  const avgEngagement =
    recent.reduce((sum, m) => {
      return sum + Object.values(m.keyNumbers).reduce((a, b) => a + b, 0);
    }, 0) / recent.length;

  const engagement = Math.min(25, avgEngagement / 4);

  // Consistency: Fewer "needs-attention" flags = better (0-25)
  const negativeFlags = recent.reduce(
    (sum, m) =>
      sum +
      m.keyFlags.filter((f) =>
        ["needs", "lagging", "paused", "stale"].some((keyword) =>
          f.toLowerCase().includes(keyword)
        )
      ).length,
    0
  );

  const consistency = Math.max(0, 25 - negativeFlags * 3);

  const score = Math.round(recency + velocity + engagement + consistency);

  // Determine level
  let level: ResonanceLevel;
  if (score >= 80) level = "hot";
  else if (score >= 60) level = "rising";
  else if (score >= 40) level = "steady";
  else if (score >= 20) level = "cooling";
  else level = "dead";

  // Determine trend
  let trend: "up" | "down" | "stable" = "stable";
  if (metrics.length >= 3) {
    const prev = metrics.slice(1, 3);
    const prevAvgEngagement =
      prev.reduce(
        (sum, m) => sum + Object.values(m.keyNumbers).reduce((a, b) => a + b, 0),
        0
      ) / prev.length;
    const latestEngagement = Object.values(latest.keyNumbers).reduce(
      (a, b) => a + b,
      0
    );

    if (latestEngagement > prevAvgEngagement * 1.2) trend = "up";
    else if (latestEngagement < prevAvgEngagement * 0.8) trend = "down";
  }

  // Generate recommendations
  const recommendations: string[] = [];
  if (recency < 15) recommendations.push("Add recent metric snapshot");
  if (velocity < 15) recommendations.push("Increase update frequency");
  if (engagement < 15)
    recommendations.push("Boost engagement with targeted actions");
  if (consistency < 15) recommendations.push("Address recurring flags");
  if (score >= 70 && trend === "up")
    recommendations.push("🔥 Momentum detected - capitalize now!");

  return {
    objectId,
    score,
    level,
    trend,
    components: { recency, velocity, engagement, consistency },
    recommendations,
  };
}

// Calculate overall ecosystem health
export function calculateEcosystemHealth(): EcosystemHealth {
  const objects = listOpsObjects();
  const allMetrics: OpsMetricSnapshot[] = [];

  objects.forEach((obj) => {
    allMetrics.push(...getOpsMetricsByObject(obj.id));
  });

  const recentMetrics = allMetrics.filter((m) => {
    const daysSince =
      (Date.now() - new Date(m.timestamp).getTime()) / (1000 * 60 * 60 * 24);
    return daysSince <= 7;
  });

  // Content Production
  const postsPerDay = recentMetrics.length / 7;
  const contentProductionScore = Math.min(100, postsPerDay * 10);

  // Distribution Efficiency (reach per effort - simulated from metrics)
  const avgReach =
    recentMetrics.reduce((sum, m) => {
      const reach = m.keyNumbers.reach || m.keyNumbers.views || 0;
      return sum + reach;
    }, 0) / Math.max(recentMetrics.length, 1);

  const distributionScore = Math.min(100, avgReach / 100);

  // Operational Velocity
  const sessions = listRunbookSessions({ completed: true });
  const recentSessions = sessions.filter((s) => {
    const daysSince =
      (Date.now() - new Date(s.startedAt).getTime()) / (1000 * 60 * 60 * 24);
    return daysSince <= 7;
  });

  const actionsPerDay = recentSessions.length / 7;
  const totalSteps = recentSessions.reduce(
    (sum, s) => sum + s.completedSteps.length,
    0
  );
  const completionRate = recentSessions.length > 0 ? totalSteps / recentSessions.length / 10 : 0;

  const operationalScore = Math.min(100, (actionsPerDay * 20 + completionRate * 50));

  // Community Engagement
  const avgInteractions =
    recentMetrics.reduce((sum, m) => {
      const interactions =
        (m.keyNumbers.likes || 0) +
        (m.keyNumbers.comments || 0) +
        (m.keyNumbers.shares || 0);
      return sum + interactions;
    }, 0) / Math.max(recentMetrics.length, 1);

  const engagementScore = Math.min(100, avgInteractions / 5);

  // Overall health (weighted average)
  const overall = Math.round(
    contentProductionScore * 0.25 +
      distributionScore * 0.25 +
      operationalScore * 0.25 +
      engagementScore * 0.25
  );

  return {
    overall,
    contentProduction: {
      score: Math.round(contentProductionScore),
      postsPerDay: Math.round(postsPerDay * 10) / 10,
      trend: postsPerDay > 3 ? "up" : postsPerDay < 1 ? "down" : "stable",
    },
    distributionEfficiency: {
      score: Math.round(distributionScore),
      reachPerEffort: Math.round(avgReach),
      trend: avgReach > 500 ? "up" : avgReach < 100 ? "down" : "stable",
    },
    operationalVelocity: {
      score: Math.round(operationalScore),
      actionsPerDay: Math.round(actionsPerDay * 10) / 10,
      completionRate: Math.round(completionRate * 100),
    },
    communityEngagement: {
      score: Math.round(engagementScore),
      avgInteractions: Math.round(avgInteractions),
      trend: avgInteractions > 20 ? "up" : avgInteractions < 5 ? "down" : "stable",
    },
    timestamp: new Date().toISOString(),
  };
}

// Get color for resonance level
export function getResonanceLevelColor(level: ResonanceLevel): string {
  const colors: Record<ResonanceLevel, string> = {
    hot: "text-red-500",
    rising: "text-orange-500",
    steady: "text-yellow-500",
    cooling: "text-blue-500",
    dead: "text-gray-500",
  };
  return colors[level];
}

// Get emoji for resonance level
export function getResonanceLevelEmoji(level: ResonanceLevel): string {
  const emojis: Record<ResonanceLevel, string> = {
    hot: "🔥",
    rising: "⚡",
    steady: "💫",
    cooling: "💤",
    dead: "💀",
  };
  return emojis[level];
}
