import type { OpsView, OpsViewDashboard, RunbookSession } from "@/types/ops";
import { getOpsViewDashboard, getRunbookSession, getOpsView } from "./ops-data-service";

export type ExportFormat = "markdown" | "json" | "calendar" | "text";

// Export ops brief as Markdown (for Farcaster/Discord)
export function exportOpsBriefMarkdown(viewId: string, periodLabel: string): string {
  const dashboard = getOpsViewDashboard(viewId, periodLabel);
  if (!dashboard) return "";

  let md = `# 📊 DreamNet Ops Brief\n\n`;
  md += `**View:** ${dashboard.view.name}\n`;
  md += `**Period:** ${periodLabel}\n`;
  md += `**Priority:** ${dashboard.view.priorityLevel.toUpperCase()}\n\n`;
  md += `---\n\n`;

  md += `## 🎯 Key Objects (${dashboard.objects.length})\n\n`;

  dashboard.objects.forEach(({ object, latestMetric }) => {
    md += `### ${object.primaryEmoji || "•"} ${object.name}\n`;
    md += `- **Type:** ${object.type}\n`;
    md += `- **Category:** ${object.category || "—"}\n`;
    md += `- **Importance:** ${object.importanceLevel.toUpperCase()}\n`;
    md += `- **Status:** ${latestMetric?.statusSummary || "No recent data"}\n`;

    if (latestMetric && Object.keys(latestMetric.keyNumbers).length > 0) {
      md += `- **Metrics:**\n`;
      Object.entries(latestMetric.keyNumbers).forEach(([key, value]) => {
        md += `  - ${key}: ${value}\n`;
      });
    }

    if (latestMetric && latestMetric.keyFlags.length > 0) {
      md += `- **Flags:** ${latestMetric.keyFlags.join(", ")}\n`;
    }

    md += `\n`;
  });

  if (dashboard.view.actionFilters.length > 0) {
    md += `## ✅ Actions to Check\n\n`;
    dashboard.view.actionFilters.forEach((action) => {
      md += `- [ ] ${action}\n`;
    });
    md += `\n`;
  }

  md += `---\n`;
  md += `*Generated: ${new Date().toLocaleString()}*\n`;

  return md;
}

// Export as JSON
export function exportOpsBriefJSON(viewId: string, periodLabel: string): string {
  const dashboard = getOpsViewDashboard(viewId, periodLabel);
  if (!dashboard) return "{}";

  return JSON.stringify(dashboard, null, 2);
}

// Export session report as Markdown
export function exportSessionReportMarkdown(sessionId: string): string {
  const session = getRunbookSession(sessionId);
  if (!session) return "";

  const view = getOpsView(session.viewId);
  if (!view) return "";

  let md = `# 📋 Runbook Session Report\n\n`;
  md += `**View:** ${view.name}\n`;
  md += `**Date:** ${session.date}\n`;
  md += `**Operator:** ${session.operatorName}\n`;
  md += `**Duration:** ${
    session.finishedAt
      ? `${Math.round((new Date(session.finishedAt).getTime() - new Date(session.startedAt).getTime()) / (1000 * 60))} minutes`
      : "In Progress"
  }\n\n`;

  md += `---\n\n`;

  md += `## ✅ Completed Steps\n\n`;
  md += `${session.completedSteps.length} steps completed\n\n`;

  if (session.flagsRaised.length > 0) {
    md += `## 🚩 Flags Raised\n\n`;
    session.flagsRaised.forEach((flag, i) => {
      md += `${i + 1}. ${flag}\n`;
    });
    md += `\n`;
  }

  if (session.summaryNotes) {
    md += `## 📝 Summary\n\n`;
    md += `${session.summaryNotes}\n\n`;
  }

  md += `---\n`;
  md += `*Generated: ${new Date().toLocaleString()}*\n`;

  return md;
}

// Generate calendar event format (ICS)
export function exportAsCalendarEvent(
  viewId: string,
  date: string,
  time: string
): string {
  const view = getOpsView(viewId);
  if (!view) return "";

  const eventDate = new Date(`${date}T${time}`);
  const endDate = new Date(eventDate.getTime() + 60 * 60 * 1000); // 1 hour later

  const formatDate = (d: Date) => {
    return d
      .toISOString()
      .replace(/[-:]/g, "")
      .replace(/\.\d{3}/, "");
  };

  let ics = `BEGIN:VCALENDAR\n`;
  ics += `VERSION:2.0\n`;
  ics += `PRODID:-//DreamNet Ops Console//EN\n`;
  ics += `BEGIN:VEVENT\n`;
  ics += `UID:${Date.now()}@dreamnet-ops\n`;
  ics += `DTSTAMP:${formatDate(new Date())}\n`;
  ics += `DTSTART:${formatDate(eventDate)}\n`;
  ics += `DTEND:${formatDate(endDate)}\n`;
  ics += `SUMMARY:DreamNet Ops: ${view.name}\n`;
  ics += `DESCRIPTION:${view.description.replace(/\n/g, "\\n")}\n`;
  ics += `END:VEVENT\n`;
  ics += `END:VCALENDAR\n`;

  return ics;
}

// Simulate webhook trigger
export function triggerWebhook(
  event: "session_completed" | "flag_raised" | "metric_added",
  payload: Record<string, unknown>
): Promise<{ success: boolean; message: string }> {
  // In a real implementation, this would POST to a configured webhook URL
  console.log(`[Webhook] ${event}:`, payload);

  return Promise.resolve({
    success: true,
    message: `Webhook triggered: ${event}`,
  });
}

// Download helper
export function downloadFile(content: string, filename: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
