import type { RunbookSession } from "@/types/ops";
import { listRunbookSessions } from "./ops-data-service";

const STORAGE_KEY = "dreamnet_gamification";

export interface Badge {
  id: string;
  name: string;
  description: string;
  emoji: string;
  earnedAt?: string;
}

export interface OperatorStats {
  operatorName: string;
  totalSessions: number;
  completedSessions: number;
  totalSteps: number;
  totalFlags: number;
  flagsResolved: number;
  currentStreak: number;
  longestStreak: number;
  avgCompletionTime: number; // minutes
  badges: Badge[];
  lastSessionDate: string;
}

export interface Leaderboard {
  topOperators: Array<{
    operatorName: string;
    score: number;
    badge: string;
  }>;
  period: "week" | "month" | "all-time";
}

// Available badges
const ALL_BADGES: Badge[] = [
  {
    id: "early-bird",
    name: "Early Bird",
    description: "Complete 5 sessions before 8am",
    emoji: "🌅",
  },
  {
    id: "weekend-warrior",
    name: "Weekend Warrior",
    description: "Complete sessions on 3 different weekends",
    emoji: "⚔️",
  },
  {
    id: "flag-hunter",
    name: "Flag Hunter",
    description: "Raise and resolve 20+ flags",
    emoji: "🎯",
  },
  {
    id: "streak-master",
    name: "Streak Master",
    description: "Maintain a 7-day streak",
    emoji: "🔥",
  },
  {
    id: "speed-runner",
    name: "Speed Runner",
    description: "Complete a full runbook in under 15 minutes",
    emoji: "⚡",
  },
  {
    id: "completionist",
    name: "Completionist",
    description: "Complete 50 sessions",
    emoji: "💯",
  },
  {
    id: "night-owl",
    name: "Night Owl",
    description: "Complete 5 sessions after 10pm",
    emoji: "🦉",
  },
  {
    id: "consistency-king",
    name: "Consistency King",
    description: "Complete sessions 5 days in a row",
    emoji: "👑",
  },
];

// Load gamification data
function loadGamificationData(): Record<string, OperatorStats> {
  if (typeof window === "undefined") return {};
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : {};
}

// Save gamification data
function saveGamificationData(data: Record<string, OperatorStats>): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

// Calculate operator stats
export function getOperatorStats(operatorName: string): OperatorStats {
  const sessions = listRunbookSessions();
  const operatorSessions = sessions.filter((s) => s.operatorName === operatorName);

  const completedSessions = operatorSessions.filter((s) => s.finishedAt !== null);

  const totalSteps = operatorSessions.reduce(
    (sum, s) => sum + s.completedSteps.length,
    0
  );

  const totalFlags = operatorSessions.reduce((sum, s) => sum + s.flagsRaised.length, 0);

  // Calculate completion times
  const completionTimes = completedSessions
    .map((s) => {
      if (!s.finishedAt) return 0;
      const start = new Date(s.startedAt).getTime();
      const end = new Date(s.finishedAt).getTime();
      return (end - start) / (1000 * 60); // minutes
    })
    .filter((t) => t > 0);

  const avgCompletionTime =
    completionTimes.length > 0
      ? completionTimes.reduce((a, b) => a + b, 0) / completionTimes.length
      : 0;

  // Calculate streak
  const { currentStreak, longestStreak } = calculateStreaks(operatorSessions);

  // Check for earned badges
  const badges = checkBadges(operatorSessions, completionTimes);

  const lastSessionDate =
    operatorSessions.length > 0
      ? operatorSessions[0].startedAt
      : new Date().toISOString();

  return {
    operatorName,
    totalSessions: operatorSessions.length,
    completedSessions: completedSessions.length,
    totalSteps,
    totalFlags,
    flagsResolved: Math.floor(totalFlags * 0.7), // Simulated
    currentStreak,
    longestStreak,
    avgCompletionTime: Math.round(avgCompletionTime),
    badges,
    lastSessionDate,
  };
}

// Calculate streaks
function calculateStreaks(sessions: RunbookSession[]): {
  currentStreak: number;
  longestStreak: number;
} {
  if (sessions.length === 0) return { currentStreak: 0, longestStreak: 0 };

  const dates = Array.from(
    new Set(sessions.map((s) => s.date))
  ).sort();

  let currentStreak = 1;
  let longestStreak = 1;
  let tempStreak = 1;

  for (let i = 1; i < dates.length; i++) {
    const prevDate = new Date(dates[i - 1]);
    const currDate = new Date(dates[i]);
    const dayDiff = Math.floor(
      (currDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24)
    );

    if (dayDiff === 1) {
      tempStreak++;
      longestStreak = Math.max(longestStreak, tempStreak);
    } else {
      tempStreak = 1;
    }
  }

  // Check if current streak is still active
  const lastDate = new Date(dates[dates.length - 1]);
  const today = new Date();
  const daysSinceLast = Math.floor(
    (today.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24)
  );

  if (daysSinceLast <= 1) {
    currentStreak = tempStreak;
  } else {
    currentStreak = 0;
  }

  return { currentStreak, longestStreak };
}

// Check which badges have been earned
function checkBadges(
  sessions: RunbookSession[],
  completionTimes: number[]
): Badge[] {
  const earned: Badge[] = [];

  // Early Bird
  const morningSessionsCount = sessions.filter((s) => {
    const hour = new Date(s.startedAt).getHours();
    return hour < 8;
  }).length;
  if (morningSessionsCount >= 5) {
    earned.push({ ...ALL_BADGES[0], earnedAt: new Date().toISOString() });
  }

  // Weekend Warrior
  const weekendSessions = sessions.filter((s) => {
    const day = new Date(s.startedAt).getDay();
    return day === 0 || day === 6;
  });
  const uniqueWeekends = new Set(
    weekendSessions.map((s) => {
      const date = new Date(s.startedAt);
      return `${date.getFullYear()}-${Math.floor(date.getDate() / 7)}`;
    })
  );
  if (uniqueWeekends.size >= 3) {
    earned.push({ ...ALL_BADGES[1], earnedAt: new Date().toISOString() });
  }

  // Flag Hunter
  const totalFlags = sessions.reduce((sum, s) => sum + s.flagsRaised.length, 0);
  if (totalFlags >= 20) {
    earned.push({ ...ALL_BADGES[2], earnedAt: new Date().toISOString() });
  }

  // Streak Master
  const { longestStreak } = calculateStreaks(sessions);
  if (longestStreak >= 7) {
    earned.push({ ...ALL_BADGES[3], earnedAt: new Date().toISOString() });
  }

  // Speed Runner
  if (completionTimes.some((t) => t <= 15)) {
    earned.push({ ...ALL_BADGES[4], earnedAt: new Date().toISOString() });
  }

  // Completionist
  const completedCount = sessions.filter((s) => s.finishedAt !== null).length;
  if (completedCount >= 50) {
    earned.push({ ...ALL_BADGES[5], earnedAt: new Date().toISOString() });
  }

  // Night Owl
  const nightSessionsCount = sessions.filter((s) => {
    const hour = new Date(s.startedAt).getHours();
    return hour >= 22;
  }).length;
  if (nightSessionsCount >= 5) {
    earned.push({ ...ALL_BADGES[6], earnedAt: new Date().toISOString() });
  }

  // Consistency King
  if (longestStreak >= 5) {
    earned.push({ ...ALL_BADGES[7], earnedAt: new Date().toISOString() });
  }

  return earned;
}

// Generate leaderboard
export function generateLeaderboard(period: "week" | "month" | "all-time"): Leaderboard {
  const sessions = listRunbookSessions();

  // Filter by period
  let filteredSessions = sessions;
  if (period === "week") {
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    filteredSessions = sessions.filter(
      (s) => new Date(s.startedAt) >= weekAgo
    );
  } else if (period === "month") {
    const monthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    filteredSessions = sessions.filter(
      (s) => new Date(s.startedAt) >= monthAgo
    );
  }

  // Calculate scores per operator
  const operatorScores: Record<string, number> = {};

  filteredSessions.forEach((session) => {
    if (!operatorScores[session.operatorName]) {
      operatorScores[session.operatorName] = 0;
    }

    // Points for completion
    if (session.finishedAt) {
      operatorScores[session.operatorName] += 10;
    }

    // Points for steps
    operatorScores[session.operatorName] += session.completedSteps.length * 2;

    // Points for flags
    operatorScores[session.operatorName] += session.flagsRaised.length;
  });

  // Sort and format
  const topOperators = Object.entries(operatorScores)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 10)
    .map(([operatorName, score], index) => ({
      operatorName,
      score,
      badge: index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : "",
    }));

  return {
    topOperators,
    period,
  };
}
