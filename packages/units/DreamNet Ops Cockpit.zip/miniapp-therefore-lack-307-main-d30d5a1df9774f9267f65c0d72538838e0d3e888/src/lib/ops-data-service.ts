import type {
  OpsObjectRef,
  OpsMetricSnapshot,
  OpsView,
  RunbookStep,
  RunbookSession,
  GeoTarget,
  OpsViewDashboard,
  OpsObjectType,
  ImportanceLevel,
  PriorityLevel,
  Timeframe,
} from "@/types/ops";

// Storage keys
const STORAGE_KEYS = {
  OPS_OBJECTS: "dreamnet_ops_objects",
  OPS_METRICS: "dreamnet_ops_metrics",
  OPS_VIEWS: "dreamnet_ops_views",
  RUNBOOK_STEPS: "dreamnet_runbook_steps",
  RUNBOOK_SESSIONS: "dreamnet_runbook_sessions",
} as const;

// Helper to generate IDs
function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

// Helper to get data from localStorage
function getStorageData<T>(key: string): T[] {
  if (typeof window === "undefined") return [];
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

// Helper to set data in localStorage
function setStorageData<T>(key: string, data: T[]): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(key, JSON.stringify(data));
}

// ===== OPS OBJECT FUNCTIONS =====

export function registerOpsObject(input: {
  type: OpsObjectType;
  refId?: string;
  name: string;
  primaryEmoji?: string;
  category?: string;
  importanceLevel?: ImportanceLevel;
}): OpsObjectRef {
  const object: OpsObjectRef = {
    id: generateId(),
    type: input.type,
    refId: input.refId || "",
    name: input.name,
    primaryEmoji: input.primaryEmoji,
    category: input.category || "",
    importanceLevel: input.importanceLevel || "medium",
    notes: "",
  };

  const objects = getStorageData<OpsObjectRef>(STORAGE_KEYS.OPS_OBJECTS);
  objects.push(object);
  setStorageData(STORAGE_KEYS.OPS_OBJECTS, objects);

  return object;
}

export function updateOpsObject(
  id: string,
  updates: Partial<Omit<OpsObjectRef, "id">>
): OpsObjectRef | null {
  const objects = getStorageData<OpsObjectRef>(STORAGE_KEYS.OPS_OBJECTS);
  const index = objects.findIndex((obj) => obj.id === id);

  if (index === -1) return null;

  objects[index] = { ...objects[index], ...updates };
  setStorageData(STORAGE_KEYS.OPS_OBJECTS, objects);

  return objects[index];
}

export function getOpsObject(id: string): OpsObjectRef | null {
  const objects = getStorageData<OpsObjectRef>(STORAGE_KEYS.OPS_OBJECTS);
  return objects.find((obj) => obj.id === id) || null;
}

export function deleteOpsObject(id: string): boolean {
  const objects = getStorageData<OpsObjectRef>(STORAGE_KEYS.OPS_OBJECTS);
  const filtered = objects.filter((obj) => obj.id !== id);

  if (filtered.length === objects.length) return false;

  setStorageData(STORAGE_KEYS.OPS_OBJECTS, filtered);

  // Also delete associated metrics
  const metrics = getStorageData<OpsMetricSnapshot>(STORAGE_KEYS.OPS_METRICS);
  const filteredMetrics = metrics.filter((m) => m.opsObjectId !== id);
  setStorageData(STORAGE_KEYS.OPS_METRICS, filteredMetrics);

  return true;
}

export function listOpsObjects(filter?: {
  type?: OpsObjectType;
  category?: string;
  importanceLevel?: ImportanceLevel;
}): Array<OpsObjectRef & { latestStatusSummary: string }> {
  let objects = getStorageData<OpsObjectRef>(STORAGE_KEYS.OPS_OBJECTS);

  if (filter?.type) {
    objects = objects.filter((obj) => obj.type === filter.type);
  }

  if (filter?.category) {
    objects = objects.filter((obj) => obj.category === filter.category);
  }

  if (filter?.importanceLevel) {
    objects = objects.filter((obj) => obj.importanceLevel === filter.importanceLevel);
  }

  const metrics = getStorageData<OpsMetricSnapshot>(STORAGE_KEYS.OPS_METRICS);

  return objects.map((obj) => {
    const objMetrics = metrics
      .filter((m) => m.opsObjectId === obj.id)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    return {
      ...obj,
      latestStatusSummary: objMetrics[0]?.statusSummary || "—",
    };
  });
}

// ===== OPS METRIC FUNCTIONS =====

export function addOpsMetricSnapshot(input: {
  opsObjectId: string;
  periodLabel: string;
  statusSummary: string;
  keyNumbers: Record<string, number>;
  keyFlags: string[];
  notes: string;
}): OpsMetricSnapshot {
  const snapshot: OpsMetricSnapshot = {
    id: generateId(),
    opsObjectId: input.opsObjectId,
    periodLabel: input.periodLabel,
    timestamp: new Date().toISOString(),
    statusSummary: input.statusSummary,
    keyNumbers: input.keyNumbers,
    keyFlags: input.keyFlags,
    notes: input.notes,
  };

  const metrics = getStorageData<OpsMetricSnapshot>(STORAGE_KEYS.OPS_METRICS);
  metrics.push(snapshot);
  setStorageData(STORAGE_KEYS.OPS_METRICS, metrics);

  return snapshot;
}

export function getOpsMetricsByObject(opsObjectId: string): OpsMetricSnapshot[] {
  const metrics = getStorageData<OpsMetricSnapshot>(STORAGE_KEYS.OPS_METRICS);
  return metrics
    .filter((m) => m.opsObjectId === opsObjectId)
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}

export function deleteOpsMetric(id: string): boolean {
  const metrics = getStorageData<OpsMetricSnapshot>(STORAGE_KEYS.OPS_METRICS);
  const filtered = metrics.filter((m) => m.id !== id);

  if (filtered.length === metrics.length) return false;

  setStorageData(STORAGE_KEYS.OPS_METRICS, filtered);
  return true;
}

// ===== OPS VIEW FUNCTIONS =====

function generateSEO(name: string, description: string): {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
} {
  return {
    seoTitle: `${name} | DreamNet Ops`,
    seoDescription: description.substring(0, 160) || `Operational view: ${name}`,
    seoKeywords: [
      "dreamnet",
      "ops",
      "operations",
      ...name.toLowerCase().split(" "),
    ],
    seoHashtags: ["#DreamNet", "#OpsConsole", "#" + name.replace(/\s+/g, "")],
    altText: `${name} operational view dashboard`,
  };
}

export function createOpsView(input: {
  name: string;
  description: string;
  objectFilters: string[];
  actionFilters: string[];
  priorityLevel: PriorityLevel;
  defaultTimeframe: Timeframe;
}): OpsView {
  const seo = generateSEO(input.name, input.description);

  const view: OpsView = {
    id: generateId(),
    name: input.name,
    description: input.description,
    objectFilters: input.objectFilters,
    actionFilters: input.actionFilters,
    priorityLevel: input.priorityLevel,
    defaultTimeframe: input.defaultTimeframe,
    notes: "",
    ...seo,
    primaryGeoTargets: [],
    viewIntroLocalized: {},
    tagsLocalized: {},
  };

  const views = getStorageData<OpsView>(STORAGE_KEYS.OPS_VIEWS);
  views.push(view);
  setStorageData(STORAGE_KEYS.OPS_VIEWS, views);

  return view;
}

export function updateOpsView(
  id: string,
  updates: Partial<Omit<OpsView, "id">>
): OpsView | null {
  const views = getStorageData<OpsView>(STORAGE_KEYS.OPS_VIEWS);
  const index = views.findIndex((v) => v.id === id);

  if (index === -1) return null;

  views[index] = { ...views[index], ...updates };
  setStorageData(STORAGE_KEYS.OPS_VIEWS, views);

  return views[index];
}

export function regenerateSEO(viewId: string): OpsView | null {
  const view = getOpsView(viewId);
  if (!view) return null;

  const seo = generateSEO(view.name, view.description);
  return updateOpsView(viewId, seo);
}

export function getOpsView(id: string): OpsView | null {
  const views = getStorageData<OpsView>(STORAGE_KEYS.OPS_VIEWS);
  return views.find((v) => v.id === id) || null;
}

export function deleteOpsView(id: string): boolean {
  const views = getStorageData<OpsView>(STORAGE_KEYS.OPS_VIEWS);
  const filtered = views.filter((v) => v.id !== id);

  if (filtered.length === views.length) return false;

  setStorageData(STORAGE_KEYS.OPS_VIEWS, filtered);

  // Also delete associated runbook steps
  const steps = getStorageData<RunbookStep>(STORAGE_KEYS.RUNBOOK_STEPS);
  const filteredSteps = steps.filter((s) => s.viewId !== id);
  setStorageData(STORAGE_KEYS.RUNBOOK_STEPS, filteredSteps);

  return true;
}

export function listOpsViews(filter?: {
  priorityLevel?: PriorityLevel;
  searchText?: string;
}): OpsView[] {
  let views = getStorageData<OpsView>(STORAGE_KEYS.OPS_VIEWS);

  if (filter?.priorityLevel) {
    views = views.filter((v) => v.priorityLevel === filter.priorityLevel);
  }

  if (filter?.searchText) {
    const search = filter.searchText.toLowerCase();
    views = views.filter(
      (v) =>
        v.name.toLowerCase().includes(search) ||
        v.description.toLowerCase().includes(search) ||
        v.objectFilters.some((f) => f.toLowerCase().includes(search)) ||
        v.actionFilters.some((f) => f.toLowerCase().includes(search))
    );
  }

  return views;
}

export function assignGeoTargetsToView(
  viewId: string,
  geoTargets: GeoTarget[]
): OpsView | null {
  return updateOpsView(viewId, { primaryGeoTargets: geoTargets });
}

export function generateGeoVariantsForView(viewId: string): OpsView | null {
  const view = getOpsView(viewId);
  if (!view) return null;

  const viewIntroLocalized: Record<string, string> = {};
  const tagsLocalized: Record<string, string[]> = {};

  view.primaryGeoTargets.forEach((target) => {
    const geoKey = target.id;
    viewIntroLocalized[geoKey] = `${view.description} (${target.region} - ${target.language})`;
    tagsLocalized[geoKey] = [
      ...view.seoHashtags,
      `#${target.region}`,
      `#${target.language}`,
    ];
  });

  return updateOpsView(viewId, { viewIntroLocalized, tagsLocalized });
}

export function getOpsViewDashboard(
  viewId: string,
  periodOverride?: string
): OpsViewDashboard | null {
  const view = getOpsView(viewId);
  if (!view) return null;

  const period = periodOverride || view.defaultTimeframe;
  let objects = getStorageData<OpsObjectRef>(STORAGE_KEYS.OPS_OBJECTS);

  // Filter by view's objectFilters
  if (view.objectFilters.length > 0) {
    objects = objects.filter((obj) =>
      view.objectFilters.some(
        (filter) =>
          obj.type === filter ||
          obj.category.toLowerCase().includes(filter.toLowerCase())
      )
    );
  }

  const metrics = getStorageData<OpsMetricSnapshot>(STORAGE_KEYS.OPS_METRICS);
  const allFlags: string[] = [];

  const objectsWithMetrics = objects.map((obj) => {
    const objMetrics = metrics
      .filter((m) => m.opsObjectId === obj.id && m.periodLabel === period)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    const latestMetric = objMetrics[0] || null;

    if (latestMetric) {
      allFlags.push(...latestMetric.keyFlags);
    }

    return {
      object: obj,
      latestMetric,
    };
  });

  return {
    view,
    objects: objectsWithMetrics,
    allFlags: Array.from(new Set(allFlags)),
    period,
  };
}

export function exportOpsBrief(viewId: string, periodLabel: string): string {
  const view = getOpsView(viewId);
  if (!view) return "";

  const dashboard = getOpsViewDashboard(viewId, periodLabel);
  if (!dashboard) return "";

  const steps = getRunbookStepsByView(viewId);

  let brief = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  brief += `  DREAMNET OPS BRIEF\n`;
  brief += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
  brief += `View: ${view.name}\n`;
  brief += `Description: ${view.description}\n`;
  brief += `Timeframe: ${periodLabel}\n`;
  brief += `Priority: ${view.priorityLevel.toUpperCase()}\n\n`;

  brief += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  brief += `  KEY OBJECTS (${dashboard.objects.length})\n`;
  brief += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

  dashboard.objects.forEach(({ object, latestMetric }) => {
    brief += `${object.primaryEmoji || "•"} ${object.name}\n`;
    brief += `  Type: ${object.type} | Category: ${object.category || "—"}\n`;
    brief += `  Importance: ${object.importanceLevel.toUpperCase()}\n`;
    brief += `  Status: ${latestMetric?.statusSummary || "No recent data"}\n`;

    if (latestMetric) {
      const numbers = Object.entries(latestMetric.keyNumbers);
      if (numbers.length > 0) {
        brief += `  Key Numbers:\n`;
        numbers.forEach(([key, value]) => {
          brief += `    - ${key}: ${value}\n`;
        });
      }

      if (latestMetric.keyFlags.length > 0) {
        brief += `  Flags: ${latestMetric.keyFlags.join(", ")}\n`;
      }
    }

    brief += `\n`;
  });

  if (view.actionFilters.length > 0) {
    brief += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    brief += `  ACTIONS TO CHECK\n`;
    brief += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    view.actionFilters.forEach((action) => {
      brief += `• ${action}\n`;
    });
    brief += `\n`;
  }

  if (steps.length > 0) {
    brief += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    brief += `  RUNBOOK STEPS (${steps.length})\n`;
    brief += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    steps.forEach((step) => {
      brief += `${step.stepOrder}. ${step.stepName}\n`;
      brief += `   Expected: ${step.expectedOutcome}\n\n`;
    });
  }

  brief += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  brief += `Generated: ${new Date().toISOString()}\n`;
  brief += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;

  return brief;
}

// ===== RUNBOOK STEP FUNCTIONS =====

export function createRunbookStep(input: {
  viewId: string;
  stepName: string;
  stepOrder: number;
  stepDescription: string;
  relatedObjects: string[];
  relatedActionTypes: string[];
  expectedOutcome: string;
  manualChecklist: string[];
}): RunbookStep {
  const step: RunbookStep = {
    id: generateId(),
    viewId: input.viewId,
    stepOrder: input.stepOrder,
    stepName: input.stepName,
    stepDescription: input.stepDescription,
    relatedObjects: input.relatedObjects,
    relatedActionTypes: input.relatedActionTypes,
    expectedOutcome: input.expectedOutcome,
    manualChecklist: input.manualChecklist,
    notes: "",
  };

  const steps = getStorageData<RunbookStep>(STORAGE_KEYS.RUNBOOK_STEPS);
  steps.push(step);
  setStorageData(STORAGE_KEYS.RUNBOOK_STEPS, steps);

  return step;
}

export function updateRunbookStep(
  id: string,
  updates: Partial<Omit<RunbookStep, "id">>
): RunbookStep | null {
  const steps = getStorageData<RunbookStep>(STORAGE_KEYS.RUNBOOK_STEPS);
  const index = steps.findIndex((s) => s.id === id);

  if (index === -1) return null;

  steps[index] = { ...steps[index], ...updates };
  setStorageData(STORAGE_KEYS.RUNBOOK_STEPS, steps);

  return steps[index];
}

export function getRunbookStep(id: string): RunbookStep | null {
  const steps = getStorageData<RunbookStep>(STORAGE_KEYS.RUNBOOK_STEPS);
  return steps.find((s) => s.id === id) || null;
}

export function deleteRunbookStep(id: string): boolean {
  const steps = getStorageData<RunbookStep>(STORAGE_KEYS.RUNBOOK_STEPS);
  const filtered = steps.filter((s) => s.id !== id);

  if (filtered.length === steps.length) return false;

  setStorageData(STORAGE_KEYS.RUNBOOK_STEPS, filtered);
  return true;
}

export function getRunbookStepsByView(viewId: string): RunbookStep[] {
  const steps = getStorageData<RunbookStep>(STORAGE_KEYS.RUNBOOK_STEPS);
  return steps.filter((s) => s.viewId === viewId).sort((a, b) => a.stepOrder - b.stepOrder);
}

// ===== RUNBOOK SESSION FUNCTIONS =====

export function startRunbookSession(
  viewId: string,
  operatorName: string
): RunbookSession {
  const session: RunbookSession = {
    id: generateId(),
    viewId,
    date: new Date().toISOString().split("T")[0],
    startedAt: new Date().toISOString(),
    finishedAt: null,
    operatorName,
    completedSteps: [],
    flagsRaised: [],
    summaryNotes: "",
  };

  const sessions = getStorageData<RunbookSession>(STORAGE_KEYS.RUNBOOK_SESSIONS);
  sessions.push(session);
  setStorageData(STORAGE_KEYS.RUNBOOK_SESSIONS, sessions);

  return session;
}

export function markRunbookStepCompleted(
  sessionId: string,
  stepId: string
): RunbookSession | null {
  const sessions = getStorageData<RunbookSession>(STORAGE_KEYS.RUNBOOK_SESSIONS);
  const index = sessions.findIndex((s) => s.id === sessionId);

  if (index === -1) return null;

  if (!sessions[index].completedSteps.includes(stepId)) {
    sessions[index].completedSteps.push(stepId);
  }

  setStorageData(STORAGE_KEYS.RUNBOOK_SESSIONS, sessions);
  return sessions[index];
}

export function markRunbookStepUncompleted(
  sessionId: string,
  stepId: string
): RunbookSession | null {
  const sessions = getStorageData<RunbookSession>(STORAGE_KEYS.RUNBOOK_SESSIONS);
  const index = sessions.findIndex((s) => s.id === sessionId);

  if (index === -1) return null;

  sessions[index].completedSteps = sessions[index].completedSteps.filter(
    (id) => id !== stepId
  );

  setStorageData(STORAGE_KEYS.RUNBOOK_SESSIONS, sessions);
  return sessions[index];
}

export function addRunbookFlag(sessionId: string, flagText: string): RunbookSession | null {
  const sessions = getStorageData<RunbookSession>(STORAGE_KEYS.RUNBOOK_SESSIONS);
  const index = sessions.findIndex((s) => s.id === sessionId);

  if (index === -1) return null;

  sessions[index].flagsRaised.push(flagText);
  setStorageData(STORAGE_KEYS.RUNBOOK_SESSIONS, sessions);

  return sessions[index];
}

export function removeRunbookFlag(
  sessionId: string,
  flagIndex: number
): RunbookSession | null {
  const sessions = getStorageData<RunbookSession>(STORAGE_KEYS.RUNBOOK_SESSIONS);
  const index = sessions.findIndex((s) => s.id === sessionId);

  if (index === -1) return null;

  sessions[index].flagsRaised.splice(flagIndex, 1);
  setStorageData(STORAGE_KEYS.RUNBOOK_SESSIONS, sessions);

  return sessions[index];
}

export function finalizeRunbookSession(
  sessionId: string,
  summaryNotes: string
): RunbookSession | null {
  const sessions = getStorageData<RunbookSession>(STORAGE_KEYS.RUNBOOK_SESSIONS);
  const index = sessions.findIndex((s) => s.id === sessionId);

  if (index === -1) return null;

  sessions[index].finishedAt = new Date().toISOString();
  sessions[index].summaryNotes = summaryNotes;
  setStorageData(STORAGE_KEYS.RUNBOOK_SESSIONS, sessions);

  return sessions[index];
}

export function getRunbookSession(id: string): RunbookSession | null {
  const sessions = getStorageData<RunbookSession>(STORAGE_KEYS.RUNBOOK_SESSIONS);
  return sessions.find((s) => s.id === id) || null;
}

export function deleteRunbookSession(id: string): boolean {
  const sessions = getStorageData<RunbookSession>(STORAGE_KEYS.RUNBOOK_SESSIONS);
  const filtered = sessions.filter((s) => s.id !== id);

  if (filtered.length === sessions.length) return false;

  setStorageData(STORAGE_KEYS.RUNBOOK_SESSIONS, filtered);
  return true;
}

export function listRunbookSessions(filter?: {
  viewId?: string;
  dateFrom?: string;
  dateTo?: string;
  completed?: boolean;
}): RunbookSession[] {
  let sessions = getStorageData<RunbookSession>(STORAGE_KEYS.RUNBOOK_SESSIONS);

  if (filter?.viewId) {
    sessions = sessions.filter((s) => s.viewId === filter.viewId);
  }

  if (filter?.dateFrom) {
    sessions = sessions.filter((s) => s.date >= filter.dateFrom);
  }

  if (filter?.dateTo) {
    sessions = sessions.filter((s) => s.date <= filter.dateTo);
  }

  if (filter?.completed !== undefined) {
    sessions = sessions.filter((s) =>
      filter.completed ? s.finishedAt !== null : s.finishedAt === null
    );
  }

  return sessions.sort(
    (a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime()
  );
}

export function exportRunbookSessionReport(sessionId: string): string {
  const session = getRunbookSession(sessionId);
  if (!session) return "";

  const view = getOpsView(session.viewId);
  if (!view) return "";

  const steps = getRunbookStepsByView(session.viewId);

  let report = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  report += `  RUNBOOK SESSION REPORT\n`;
  report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

  report += `View: ${view.name}\n`;
  report += `Date: ${session.date}\n`;
  report += `Operator: ${session.operatorName}\n`;
  report += `Started: ${new Date(session.startedAt).toLocaleString()}\n`;
  report += `Finished: ${
    session.finishedAt ? new Date(session.finishedAt).toLocaleString() : "In Progress"
  }\n\n`;

  report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  report += `  COMPLETED STEPS (${session.completedSteps.length}/${steps.length})\n`;
  report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

  steps.forEach((step) => {
    const completed = session.completedSteps.includes(step.id);
    report += `${completed ? "✓" : "○"} ${step.stepOrder}. ${step.stepName}\n`;
  });

  if (session.flagsRaised.length > 0) {
    report += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    report += `  FLAGS RAISED (${session.flagsRaised.length})\n`;
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

    session.flagsRaised.forEach((flag, i) => {
      report += `${i + 1}. ${flag}\n`;
    });
  }

  if (session.summaryNotes) {
    report += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    report += `  SUMMARY NOTES\n`;
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    report += session.summaryNotes + `\n`;
  }

  report += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  report += `Generated: ${new Date().toISOString()}\n`;
  report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;

  return report;
}
