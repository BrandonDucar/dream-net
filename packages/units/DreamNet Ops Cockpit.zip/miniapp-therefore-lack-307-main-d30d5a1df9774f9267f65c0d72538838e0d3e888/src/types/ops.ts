export type OpsObjectType =
  | "token"
  | "drop"
  | "meme"
  | "campaign"
  | "mini-app"
  | "agent"
  | "content-stream"
  | "segment"
  | "audience"
  | "pickleball"
  | "other";

export type ImportanceLevel = "low" | "medium" | "high" | "critical";

export type PriorityLevel = "low" | "medium" | "high" | "critical";

export type Timeframe = "today" | "yesterday" | "last-7-days" | "week-to-date" | "custom";

export interface OpsObjectRef {
  id: string;
  type: OpsObjectType;
  refId: string;
  name: string;
  primaryEmoji?: string;
  category: string;
  importanceLevel: ImportanceLevel;
  notes: string;
}

export interface OpsMetricSnapshot {
  id: string;
  opsObjectId: string;
  periodLabel: string;
  timestamp: string;
  statusSummary: string;
  keyNumbers: Record<string, number>;
  keyFlags: string[];
  notes: string;
}

export interface OpsView {
  id: string;
  name: string;
  description: string;
  objectFilters: string[];
  actionFilters: string[];
  priorityLevel: PriorityLevel;
  defaultTimeframe: Timeframe;
  notes: string;
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
  primaryGeoTargets: GeoTarget[];
  viewIntroLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
}

export interface RunbookStep {
  id: string;
  viewId: string;
  stepOrder: number;
  stepName: string;
  stepDescription: string;
  relatedObjects: string[];
  relatedActionTypes: string[];
  expectedOutcome: string;
  manualChecklist: string[];
  notes: string;
}

export interface RunbookSession {
  id: string;
  viewId: string;
  date: string;
  startedAt: string;
  finishedAt: string | null;
  operatorName: string;
  completedSteps: string[];
  flagsRaised: string[];
  summaryNotes: string;
}

export interface GeoTarget {
  id: string;
  region: string;
  country: string;
  cityOrMarket: string;
  language: string;
}

export interface OpsViewDashboard {
  view: OpsView;
  objects: Array<{
    object: OpsObjectRef;
    latestMetric: OpsMetricSnapshot | null;
  }>;
  allFlags: string[];
  period: string;
}
