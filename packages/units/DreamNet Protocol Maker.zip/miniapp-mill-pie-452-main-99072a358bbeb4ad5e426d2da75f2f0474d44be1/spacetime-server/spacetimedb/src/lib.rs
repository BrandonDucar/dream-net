use spacetimedb::{table, reducer, ReducerContext, Identity, Table, Timestamp, ScheduleAt, SpacetimeType};
use std::time::Duration;

/*
 * --------------------
 * Custom Types
 * --------------------
 */

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum QuestDifficulty {
    Easy,
    Medium,
    Hard,
    Legendary,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum QuestStatus {
    Draft,
    Published,
    InProgress,
    Completed,
    Archived,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum QuestProgressState {
    NotStarted,
    Active,
    Completed,
    Failed,
    Expired,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum TaskType {
    TwitterFollow,
    DiscordJoin,
    OnchainTransaction,
    Quiz,
    FileUpload,
    CreativeSubmission,
    Custom,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum VerificationMethod {
    Automatic,
    Manual,
    Hybrid,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum RewardAssetKind {
    Token,
    Nft,
    Xp,
    Badge,
    Access,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum LeaderboardScope {
    Global,
    Quest,
    TimeBound,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum ReviewStatus {
    Pending,
    Approved,
    Rejected,
}

/*
 * --------------------
 * Tables
 * --------------------
 */

#[table(name = user_profile, public)]
#[derive(Clone)]
pub struct UserProfile {
    #[primary_key]
    identity: Identity,
    handle: String,
    bio: String,
    avatar_url: String,
    wallet_address: String,
    xp: u64,
    level: u32,
    social_links: String,
    follower_count: u64,
    following_count: u64,
    created_at: Timestamp,
    updated_at: Timestamp,
}

#[table(name = user_setting, public)]
#[derive(Clone)]
pub struct UserSetting {
    #[primary_key]
    #[auto_inc]
    setting_id: u64,
    #[index(btree)]
    identity: Identity,
    locale: String,
    email_opt_in: bool,
    push_opt_in: bool,
    dark_mode: bool,
    preferences_json: String,
    updated_at: Timestamp,
}

#[table(name = social_connection, public)]
#[derive(Clone)]
pub struct SocialConnection {
    #[primary_key]
    #[auto_inc]
    connection_id: u64,
    #[index(btree)]
    follower: Identity,
    #[index(btree)]
    following: Identity,
    created_at: Timestamp,
}

#[table(name = achievement_definition, public)]
#[derive(Clone)]
pub struct AchievementDefinition {
    #[primary_key]
    achievement_id: String,
    name: String,
    description: String,
    badge_art_url: String,
    xp_reward: u64,
    criteria_json: String,
    created_at: Timestamp,
}

#[table(name = user_achievement, public)]
#[derive(Clone)]
pub struct UserAchievement {
    #[primary_key]
    #[auto_inc]
    record_id: u64,
    #[index(btree)]
    identity: Identity,
    #[index(btree)]
    achievement_id: String,
    earned_at: Timestamp,
    evidence: String,
}

#[table(name = quest_category, public)]
#[derive(Clone)]
pub struct QuestCategory {
    #[primary_key]
    category_id: String,
    name: String,
    description: String,
    icon_url: String,
    created_at: Timestamp,
}

#[table(name = quest_template, public)]
#[derive(Clone)]
pub struct QuestTemplate {
    #[primary_key]
    template_id: String,
    #[index(btree)]
    creator: Identity,
    title: String,
    description: String,
    difficulty: QuestDifficulty,
    estimated_minutes: u32,
    category_id: String,
    task_schema: String,
    is_public: bool,
    created_at: Timestamp,
}

#[table(name = quest, public)]
#[derive(Clone)]
pub struct Quest {
    #[primary_key]
    quest_id: String,
    #[index(btree)]
    creator: Identity,
    #[index(btree)]
    category_id: String,
    title: String,
    summary: String,
    difficulty: QuestDifficulty,
    status: QuestStatus,
    estimated_minutes: u32,
    reward_pool_id: String,
    metadata: String,
    starts_at: Timestamp,
    ends_at: Timestamp,
    created_at: Timestamp,
    updated_at: Timestamp,
}

#[table(name = quest_instance, public)]
#[derive(Clone)]
pub struct QuestInstance {
    #[primary_key]
    #[auto_inc]
    instance_id: u64,
    #[index(btree)]
    quest_id: String,
    #[index(btree)]
    identity: Identity,
    state: QuestProgressState,
    progress_pct: u32,
    started_at: Timestamp,
    updated_at: Timestamp,
    completed_at: Option<Timestamp>,
    guild_id: Option<String>,
}

#[table(name = task_definition, public)]
#[derive(Clone)]
pub struct TaskDefinition {
    #[primary_key]
    task_id: String,
    #[index(btree)]
    quest_id: String,
    template_task_id: Option<String>,
    task_type: TaskType,
    title: String,
    instructions: String,
    verification_method: VerificationMethod,
    metadata: String,
    order_index: u32,
    reward_asset_kind: RewardAssetKind,
    reward_amount: u64,
}

#[table(name = task_completion, public)]
#[derive(Clone)]
pub struct TaskCompletion {
    #[primary_key]
    #[auto_inc]
    completion_id: u64,
    #[index(btree)]
    task_id: String,
    #[index(btree)]
    instance_id: u64,
    #[index(btree)]
    identity: Identity,
    verification_method: VerificationMethod,
    review_status: ReviewStatus,
    submitted_payload: String,
    reviewer_notes: String,
    submitted_at: Timestamp,
    verified_at: Option<Timestamp>,
}

#[table(name = reward_pool, public)]
#[derive(Clone)]
pub struct RewardPool {
    #[primary_key]
    reward_pool_id: String,
    #[index(btree)]
    quest_id: Option<String>,
    asset_kind: RewardAssetKind,
    token_address: String,
    total_amount: u128,
    distributed_amount: u128,
    metadata: String,
    locked: bool,
    created_at: Timestamp,
}

#[table(name = reward_distribution, public)]
#[derive(Clone)]
pub struct RewardDistribution {
    #[primary_key]
    #[auto_inc]
    distribution_id: u64,
    #[index(btree)]
    reward_pool_id: String,
    #[index(btree)]
    identity: Identity,
    asset_kind: RewardAssetKind,
    amount: u128,
    executed: bool,
    scheduled_at: Timestamp,
    executed_at: Option<Timestamp>,
    tx_hash: String,
}

#[table(name = leaderboard_snapshot, public)]
#[derive(Clone)]
pub struct LeaderboardSnapshot {
    #[primary_key]
    #[auto_inc]
    snapshot_id: u64,
    scope: LeaderboardScope,
    quest_id: Option<String>,
    period_start: Timestamp,
    period_end: Timestamp,
    data: String,
    generated_at: Timestamp,
}

#[table(name = quest_like, public)]
#[derive(Clone)]
pub struct QuestLike {
    #[primary_key]
    #[auto_inc]
    like_id: u64,
    #[index(btree)]
    quest_id: String,
    #[index(btree)]
    identity: Identity,
    created_at: Timestamp,
}

#[table(name = quest_comment, public)]
#[derive(Clone)]
pub struct QuestComment {
    #[primary_key]
    comment_id: String,
    #[index(btree)]
    quest_id: String,
    #[index(btree)]
    identity: Identity,
    content: String,
    like_count: u32,
    created_at: Timestamp,
    updated_at: Timestamp,
}

#[table(name = completion_comment, public)]
#[derive(Clone)]
pub struct CompletionComment {
    #[primary_key]
    #[auto_inc]
    comment_id: u64,
    #[index(btree)]
    completion_id: u64,
    #[index(btree)]
    identity: Identity,
    message: String,
    created_at: Timestamp,
}

#[table(name = guild, public)]
#[derive(Clone)]
pub struct Guild {
    #[primary_key]
    guild_id: String,
    name: String,
    description: String,
    owner: Identity,
    crest_url: String,
    invite_code: String,
    created_at: Timestamp,
}

#[table(name = guild_membership, public)]
#[derive(Clone)]
pub struct GuildMembership {
    #[primary_key]
    #[auto_inc]
    membership_id: u64,
    #[index(btree)]
    guild_id: String,
    #[index(btree)]
    identity: Identity,
    role: String,
    joined_at: Timestamp,
}

#[table(name = guild_quest_participation, public)]
#[derive(Clone)]
pub struct GuildQuestParticipation {
    #[primary_key]
    #[auto_inc]
    participation_id: u64,
    #[index(btree)]
    guild_id: String,
    #[index(btree)]
    quest_id: String,
    progress_pct: u32,
    updated_at: Timestamp,
}

#[table(name = quest_performance_metric, public)]
#[derive(Clone)]
pub struct QuestPerformanceMetric {
    #[primary_key]
    #[auto_inc]
    metric_id: u64,
    #[index(btree)]
    quest_id: String,
    metric_type: String,
    metric_value: f64,
    recorded_at: Timestamp,
    metadata: String,
}

#[table(name = user_engagement_metric, public)]
#[derive(Clone)]
pub struct UserEngagementMetric {
    #[primary_key]
    #[auto_inc]
    metric_id: u64,
    #[index(btree)]
    identity: Identity,
    session_length_seconds: u32,
    quests_viewed: u32,
    quests_joined: u32,
    recorded_at: Timestamp,
}

#[table(name = creator_revenue_metric, public)]
#[derive(Clone)]
pub struct CreatorRevenueMetric {
    #[primary_key]
    #[auto_inc]
    metric_id: u64,
    #[index(btree)]
    quest_id: String,
    #[index(btree)]
    creator: Identity,
    spend_amount: u128,
    revenue_amount: u128,
    currency: String,
    recorded_at: Timestamp,
}

#[table(name = ab_test_variant, public)]
#[derive(Clone)]
pub struct AbTestVariant {
    #[primary_key]
    variant_id: String,
    #[index(btree)]
    quest_id: String,
    variant_key: String,
    traffic_split: f32,
    performance_json: String,
    created_at: Timestamp,
}

#[table(name = verification_job, public)]
#[derive(Clone)]
pub struct VerificationJob {
    #[primary_key]
    #[auto_inc]
    job_id: u64,
    #[index(btree)]
    task_id: String,
    completion_id: Option<u64>,
    provider: String,
    payload: String,
    status: ReviewStatus,
    result_metadata: String,
    created_at: Timestamp,
    completed_at: Option<Timestamp>,
}

#[table(name = manual_review, public)]
#[derive(Clone)]
pub struct ManualReview {
    #[primary_key]
    #[auto_inc]
    review_id: u64,
    #[index(btree)]
    completion_id: u64,
    reviewer: Option<Identity>,
    status: ReviewStatus,
    notes: String,
    assigned_at: Timestamp,
    resolved_at: Option<Timestamp>,
}

#[table(name = anti_sybil_report, public)]
#[derive(Clone)]
pub struct AntiSybilReport {
    #[primary_key]
    #[auto_inc]
    report_id: u64,
    #[index(btree)]
    identity: Identity,
    reason: String,
    score: f32,
    evidence: String,
    created_at: Timestamp,
    resolved_at: Option<Timestamp>,
}

#[table(name = external_integration, public)]
#[derive(Clone)]
pub struct ExternalIntegration {
    #[primary_key]
    integration_id: String,
    #[index(btree)]
    identity: Identity,
    provider: String,
    handle: String,
    access_token_ref: String,
    verified_at: Timestamp,
    revoked: bool,
}

#[table(name = quest_tick_schedule, scheduled(quest_tick))]
#[derive(Clone)]
pub struct QuestTickSchedule {
    #[primary_key]
    #[auto_inc]
    schedule_id: u64,
    scheduled_at: ScheduleAt,
}

/*
 * --------------------
 * Reducers - Lifecycle
 * --------------------
 */

#[reducer(init)]
pub fn init(ctx: &ReducerContext) -> Result<(), String> {
    spacetimedb::log::info!("Initializing quest platform module");
    if ctx.db.quest_tick_schedule().count() == 0 {
        let schedule = QuestTickSchedule {
            schedule_id: 0,
            scheduled_at: ScheduleAt::Interval(Duration::from_secs(30).into()),
        };
        ctx.db
            .quest_tick_schedule()
            .try_insert(schedule)
            .map(|_| ())
            .map_err(|e| format!("Failed to schedule quest tick: {}", e))
    } else {
        Ok(())
    }
}

/*
 * --------------------
 * Reducers - User Management
 * --------------------
 */

#[reducer]
pub fn register_user(
    ctx: &ReducerContext,
    handle: String,
    wallet_address: String,
    bio: String,
    avatar_url: String,
    social_links: String,
) -> Result<(), String> {
    if ctx.db.user_profile().identity().find(&ctx.sender).is_some() {
        return Err("Profile already exists for sender".to_string());
    }

    let now = ctx.timestamp;
    let profile = UserProfile {
        identity: ctx.sender,
        handle,
        bio,
        avatar_url,
        wallet_address,
        xp: 0,
        level: 1,
        social_links,
        follower_count: 0,
        following_count: 0,
        created_at: now,
        updated_at: now,
    };
    ctx.db.user_profile().insert(profile);

    let setting = UserSetting {
        setting_id: 0,
        identity: ctx.sender,
        locale: "en".to_string(),
        email_opt_in: true,
        push_opt_in: true,
        dark_mode: false,
        preferences_json: "{}".to_string(),
        updated_at: now,
    };
    ctx.db.user_setting().insert(setting);
    Ok(())
}

#[reducer]
pub fn update_user_profile(
    ctx: &ReducerContext,
    handle: String,
    bio: String,
    avatar_url: String,
    social_links: String,
) -> Result<(), String> {
    if let Some(mut profile) = ctx.db.user_profile().identity().find(&ctx.sender) {
        profile.handle = handle;
        profile.bio = bio;
        profile.avatar_url = avatar_url;
        profile.social_links = social_links;
        profile.updated_at = ctx.timestamp;
        ctx.db.user_profile().identity().update(profile);
        Ok(())
    } else {
        Err("Profile not found".to_string())
    }
}

#[reducer]
pub fn update_user_settings(
    ctx: &ReducerContext,
    locale: String,
    email_opt_in: bool,
    push_opt_in: bool,
    dark_mode: bool,
    preferences_json: String,
) -> Result<(), String> {
    let mut setting_id: Option<u64> = None;
    for setting in ctx.db.user_setting().iter() {
        if setting.identity == ctx.sender {
            setting_id = Some(setting.setting_id);
            break;
        }
    }

    if let Some(id) = setting_id {
        if let Some(mut setting) = ctx.db.user_setting().setting_id().find(id) {
            setting.locale = locale;
            setting.email_opt_in = email_opt_in;
            setting.push_opt_in = push_opt_in;
            setting.dark_mode = dark_mode;
            setting.preferences_json = preferences_json;
            setting.updated_at = ctx.timestamp;
            ctx.db.user_setting().setting_id().update(setting);
        }
    } else {
        let setting = UserSetting {
            setting_id: 0,
            identity: ctx.sender,
            locale,
            email_opt_in,
            push_opt_in,
            dark_mode,
            preferences_json,
            updated_at: ctx.timestamp,
        };
        ctx.db.user_setting().insert(setting);
    }
    Ok(())
}

#[reducer]
pub fn follow_user(ctx: &ReducerContext, target: Identity) -> Result<(), String> {
    if ctx.sender == target {
        return Err("Cannot follow yourself".to_string());
    }
    if ctx.db.user_profile().identity().find(&target).is_none() {
        return Err("Target user not found".to_string());
    }

    for connection in ctx.db.social_connection().iter() {
        if connection.follower == ctx.sender && connection.following == target {
            return Err("Already following".to_string());
        }
    }

    let row = SocialConnection {
        connection_id: 0,
        follower: ctx.sender,
        following: target,
        created_at: ctx.timestamp,
    };
    ctx.db.social_connection().insert(row);

    if let Some(mut follower_profile) = ctx.db.user_profile().identity().find(&ctx.sender) {
        let new_count = follower_profile.following_count + 1;
        follower_profile.following_count = new_count;
        follower_profile.updated_at = ctx.timestamp;
        ctx.db.user_profile().identity().update(follower_profile);
        spacetimedb::log::info!(
            "User {} is now following {} (following count {})",
            ctx.sender,
            target,
            new_count
        );
    }

    if let Some(mut target_profile) = ctx.db.user_profile().identity().find(&target) {
        let new_count = target_profile.follower_count + 1;
        target_profile.follower_count = new_count;
        target_profile.updated_at = ctx.timestamp;
        ctx.db.user_profile().identity().update(target_profile);
    }

    Ok(())
}

/*
 * --------------------
 * Reducers - Quest & Task Platform
 * --------------------
 */

#[reducer]
pub fn create_quest(
    ctx: &ReducerContext,
    quest_id: String,
    category_id: String,
    title: String,
    summary: String,
    difficulty: QuestDifficulty,
    estimated_minutes: u32,
    reward_pool_id: String,
    metadata: String,
    starts_at: Timestamp,
    ends_at: Timestamp,
) -> Result<(), String> {
    if ctx.db.quest().quest_id().find(&quest_id).is_some() {
        return Err("Quest already exists".to_string());
    }
    if ctx
        .db
        .quest_category()
        .category_id()
        .find(&category_id)
        .is_none()
    {
        return Err("Category not found".to_string());
    }
    if ctx
        .db
        .reward_pool()
        .reward_pool_id()
        .find(&reward_pool_id)
        .is_none()
    {
        return Err("Reward pool not found".to_string());
    }

    let quest = Quest {
        quest_id,
        creator: ctx.sender,
        category_id,
        title,
        summary,
        difficulty,
        status: QuestStatus::Draft,
        estimated_minutes,
        reward_pool_id,
        metadata,
        starts_at,
        ends_at,
        created_at: ctx.timestamp,
        updated_at: ctx.timestamp,
    };
    ctx.db.quest().insert(quest);
    Ok(())
}

#[reducer]
pub fn publish_quest(ctx: &ReducerContext, quest_id: String) -> Result<(), String> {
    if let Some(mut quest) = ctx.db.quest().quest_id().find(&quest_id) {
        if quest.creator != ctx.sender {
            return Err("Only the creator can publish the quest".to_string());
        }
        quest.status = QuestStatus::Published;
        quest.updated_at = ctx.timestamp;
        ctx.db.quest().quest_id().update(quest);
        Ok(())
    } else {
        Err("Quest not found".to_string())
    }
}

#[reducer]
pub fn join_quest(ctx: &ReducerContext, quest_id: String, guild_id: Option<String>) -> Result<(), String> {
    let quest = match ctx.db.quest().quest_id().find(&quest_id) {
        Some(q) => q,
        None => return Err("Quest not found".to_string()),
    };
    if quest.status != QuestStatus::Published {
        return Err("Quest is not open for participation".to_string());
    }
    if quest.starts_at > ctx.timestamp || quest.ends_at < ctx.timestamp {
        return Err("Quest is not active".to_string());
    }

    for instance in ctx.db.quest_instance().iter() {
        if instance.quest_id == quest_id && instance.identity == ctx.sender {
            return Err("Already participating in quest".to_string());
        }
    }

    if let Some(ref gid) = guild_id {
        if ctx.db.guild().guild_id().find(gid).is_none() {
            return Err("Guild not found".to_string());
        }
    }

    let instance = QuestInstance {
        instance_id: 0,
        quest_id: quest.quest_id.clone(),
        identity: ctx.sender,
        state: QuestProgressState::Active,
        progress_pct: 0,
        started_at: ctx.timestamp,
        updated_at: ctx.timestamp,
        completed_at: None,
        guild_id,
    };
    ctx.db.quest_instance().insert(instance);
    Ok(())
}

#[reducer]
pub fn submit_task_result(
    ctx: &ReducerContext,
    task_id: String,
    instance_id: u64,
    evidence_payload: String,
) -> Result<(), String> {
    let instance = match ctx.db.quest_instance().instance_id().find(instance_id) {
        Some(i) => i,
        None => return Err("Quest instance not found".to_string()),
    };
    if instance.identity != ctx.sender {
        return Err("Cannot submit for another user".to_string());
    }

    let task = match ctx.db.task_definition().task_id().find(&task_id) {
        Some(t) => t,
        None => return Err("Task not found".to_string()),
    };
    if task.quest_id != instance.quest_id {
        return Err("Task does not belong to quest instance".to_string());
    }

    for completion in ctx.db.task_completion().iter() {
        if completion.task_id == task_id
            && completion.instance_id == instance_id
            && completion.identity == ctx.sender
            && completion.review_status != ReviewStatus::Rejected
        {
            return Err("Task already submitted".to_string());
        }
    }

    let completion = TaskCompletion {
        completion_id: 0,
        task_id,
        instance_id,
        identity: ctx.sender,
        verification_method: task.verification_method.clone(),
        review_status: ReviewStatus::Pending,
        submitted_payload: evidence_payload,
        reviewer_notes: String::new(),
        submitted_at: ctx.timestamp,
        verified_at: None,
    };
    ctx.db.task_completion().insert(completion);
    Ok(())
}

#[reducer]
pub fn review_task_submission(
    ctx: &ReducerContext,
    completion_id: u64,
    status: ReviewStatus,
    reviewer_notes: String,
) -> Result<(), String> {
    let mut completion = match ctx.db.task_completion().completion_id().find(completion_id) {
        Some(c) => c,
        None => return Err("Completion not found".to_string()),
    };

    if completion.review_status == status && completion.reviewer_notes == reviewer_notes {
        return Ok(());
    }

    completion.review_status = status.clone();
    completion.reviewer_notes = reviewer_notes;
    if matches!(status, ReviewStatus::Approved) {
        completion.verified_at = Some(ctx.timestamp);
    }
    ctx.db.task_completion().completion_id().update(completion.clone());

    if matches!(status, ReviewStatus::Approved) {
        if let Some(task) = ctx.db.task_definition().task_id().find(&completion.task_id) {
            if let Some(mut profile) = ctx.db.user_profile().identity().find(&completion.identity) {
                let xp_gain = if task.reward_asset_kind == RewardAssetKind::Xp {
                    task.reward_amount as u64
                } else {
                    50
                };
                profile.xp = profile.xp.saturating_add(xp_gain);
                let new_level = (profile.xp / 1000) as u32 + 1;
                profile.level = new_level;
                profile.updated_at = ctx.timestamp;
                let level_after = profile.level;
                ctx.db.user_profile().identity().update(profile);
                spacetimedb::log::info!(
                    "User {} gained {} XP and is now level {}",
                    completion.identity,
                    xp_gain,
                    level_after
                );
            }
        }

        if let Some(mut instance) = ctx.db.quest_instance().instance_id().find(completion.instance_id) {
            let mut total_tasks: u32 = 0;
            for task in ctx.db.task_definition().iter() {
                if task.quest_id == instance.quest_id {
                    total_tasks += 1;
                }
            }
            let mut completed_tasks: u32 = 0;
            for record in ctx.db.task_completion().iter() {
                if record.instance_id == completion.instance_id
                    && matches!(record.review_status, ReviewStatus::Approved)
                {
                    completed_tasks += 1;
                }
            }
            if total_tasks > 0 {
                instance.progress_pct = (completed_tasks * 100 / total_tasks).min(100);
            }
            if instance.progress_pct >= 100 {
                instance.state = QuestProgressState::Completed;
                instance.completed_at = Some(ctx.timestamp);
            }
            instance.updated_at = ctx.timestamp;
            ctx.db.quest_instance().instance_id().update(instance);
        }
    }

    Ok(())
}

#[reducer]
pub fn record_reward_distribution(
    ctx: &ReducerContext,
    reward_pool_id: String,
    recipient: Identity,
    asset_kind: RewardAssetKind,
    amount: u128,
    executed: bool,
    tx_hash: String,
) -> Result<(), String> {
    if ctx
        .db
        .reward_pool()
        .reward_pool_id()
        .find(&reward_pool_id)
        .is_none()
    {
        return Err("Reward pool not found".to_string());
    }

    let distribution = RewardDistribution {
        distribution_id: 0,
        reward_pool_id: reward_pool_id.clone(),
        identity: recipient,
        asset_kind,
        amount,
        executed,
        scheduled_at: ctx.timestamp,
        executed_at: if executed { Some(ctx.timestamp) } else { None },
        tx_hash,
    };
    ctx.db.reward_distribution().insert(distribution);

    if executed {
        if let Some(mut pool) = ctx.db.reward_pool().reward_pool_id().find(&reward_pool_id) {
            let new_distributed = pool.distributed_amount.saturating_add(amount);
            pool.distributed_amount = new_distributed;
            pool.locked = new_distributed >= pool.total_amount;
            ctx.db.reward_pool().reward_pool_id().update(pool);
        }
    }

    Ok(())
}

/*
 * --------------------
 * Reducers - Community Features
 * --------------------
 */

#[reducer]
pub fn like_quest(ctx: &ReducerContext, quest_id: String) -> Result<(), String> {
    if ctx.db.quest().quest_id().find(&quest_id).is_none() {
        return Err("Quest not found".to_string());
    }
    for like in ctx.db.quest_like().iter() {
        if like.quest_id == quest_id && like.identity == ctx.sender {
            return Err("Already liked quest".to_string());
        }
    }
    let like = QuestLike {
        like_id: 0,
        quest_id,
        identity: ctx.sender,
        created_at: ctx.timestamp,
    };
    ctx.db.quest_like().insert(like);
    Ok(())
}

#[reducer]
pub fn comment_on_quest(
    ctx: &ReducerContext,
    comment_id: String,
    quest_id: String,
    content: String,
) -> Result<(), String> {
    if ctx.db.quest().quest_id().find(&quest_id).is_none() {
        return Err("Quest not found".to_string());
    }
    if ctx
        .db
        .quest_comment()
        .comment_id()
        .find(&comment_id)
        .is_some()
    {
        return Err("Comment ID already exists".to_string());
    }

    let comment = QuestComment {
        comment_id,
        quest_id,
        identity: ctx.sender,
        content,
        like_count: 0,
        created_at: ctx.timestamp,
        updated_at: ctx.timestamp,
    };
    ctx.db.quest_comment().insert(comment);
    Ok(())
}

#[reducer]
pub fn comment_on_completion(
    ctx: &ReducerContext,
    completion_id: u64,
    message: String,
) -> Result<(), String> {
    if ctx
        .db
        .task_completion()
        .completion_id()
        .find(completion_id)
        .is_none()
    {
        return Err("Completion not found".to_string());
    }
    let comment = CompletionComment {
        comment_id: 0,
        completion_id,
        identity: ctx.sender,
        message,
        created_at: ctx.timestamp,
    };
    ctx.db.completion_comment().insert(comment);
    Ok(())
}

#[reducer]
pub fn create_guild(
    ctx: &ReducerContext,
    guild_id: String,
    name: String,
    description: String,
    crest_url: String,
    invite_code: String,
) -> Result<(), String> {
    if ctx.db.guild().guild_id().find(&guild_id).is_some() {
        return Err("Guild already exists".to_string());
    }
    let guild = Guild {
        guild_id: guild_id.clone(),
        name,
        description,
        owner: ctx.sender,
        crest_url,
        invite_code,
        created_at: ctx.timestamp,
    };
    ctx.db.guild().insert(guild);

    let membership = GuildMembership {
        membership_id: 0,
        guild_id,
        identity: ctx.sender,
        role: "owner".to_string(),
        joined_at: ctx.timestamp,
    };
    ctx.db.guild_membership().insert(membership);
    Ok(())
}

#[reducer]
pub fn join_guild(ctx: &ReducerContext, guild_id: String) -> Result<(), String> {
    if ctx.db.guild().guild_id().find(&guild_id).is_none() {
        return Err("Guild not found".to_string());
    }
    for membership in ctx.db.guild_membership().iter() {
        if membership.guild_id == guild_id && membership.identity == ctx.sender {
            return Err("Already in guild".to_string());
        }
    }
    let membership = GuildMembership {
        membership_id: 0,
        guild_id,
        identity: ctx.sender,
        role: "member".to_string(),
        joined_at: ctx.timestamp,
    };
    ctx.db.guild_membership().insert(membership);
    Ok(())
}

/*
 * --------------------
 * Reducers - Analytics & Verification
 * --------------------
 */

#[reducer]
pub fn record_quest_metric(
    ctx: &ReducerContext,
    quest_id: String,
    metric_type: String,
    metric_value: f64,
    metadata: String,
) -> Result<(), String> {
    if ctx.db.quest().quest_id().find(&quest_id).is_none() {
        return Err("Quest not found".to_string());
    }
    let record = QuestPerformanceMetric {
        metric_id: 0,
        quest_id,
        metric_type,
        metric_value,
        recorded_at: ctx.timestamp,
        metadata,
    };
    ctx.db.quest_performance_metric().insert(record);
    Ok(())
}

#[reducer]
pub fn record_creator_revenue(
    ctx: &ReducerContext,
    quest_id: String,
    spend_amount: u128,
    revenue_amount: u128,
    currency: String,
) -> Result<(), String> {
    let quest = match ctx.db.quest().quest_id().find(&quest_id) {
        Some(q) => q,
        None => return Err("Quest not found".to_string()),
    };
    let record = CreatorRevenueMetric {
        metric_id: 0,
        quest_id,
        creator: quest.creator,
        spend_amount,
        revenue_amount,
        currency,
        recorded_at: ctx.timestamp,
    };
    ctx.db.creator_revenue_metric().insert(record);
    Ok(())
}

#[reducer]
pub fn record_ab_test_variant(
    ctx: &ReducerContext,
    variant_id: String,
    quest_id: String,
    variant_key: String,
    traffic_split: f32,
    performance_json: String,
) -> Result<(), String> {
    if ctx
        .db
        .ab_test_variant()
        .variant_id()
        .find(&variant_id)
        .is_some()
    {
        return Err("Variant already exists".to_string());
    }
    if ctx.db.quest().quest_id().find(&quest_id).is_none() {
        return Err("Quest not found".to_string());
    }
    let variant = AbTestVariant {
        variant_id,
        quest_id,
        variant_key,
        traffic_split,
        performance_json,
        created_at: ctx.timestamp,
    };
    ctx.db.ab_test_variant().insert(variant);
    Ok(())
}

#[reducer]
pub fn enqueue_verification_job(
    ctx: &ReducerContext,
    task_id: String,
    completion_id: Option<u64>,
    provider: String,
    payload: String,
) -> Result<(), String> {
    if ctx.db.task_definition().task_id().find(&task_id).is_none() {
        return Err("Task not found".to_string());
    }
    if let Some(id) = completion_id {
        if ctx.db.task_completion().completion_id().find(id).is_none() {
            return Err("Completion not found".to_string());
        }
    }
    let job = VerificationJob {
        job_id: 0,
        task_id,
        completion_id,
        provider,
        payload,
        status: ReviewStatus::Pending,
        result_metadata: String::new(),
        created_at: ctx.timestamp,
        completed_at: None,
    };
    ctx.db.verification_job().insert(job);
    Ok(())
}

#[reducer]
pub fn update_manual_review(
    ctx: &ReducerContext,
    review_id: u64,
    status: ReviewStatus,
    notes: String,
) -> Result<(), String> {
    if let Some(mut review) = ctx.db.manual_review().review_id().find(review_id) {
        review.status = status.clone();
        review.notes = notes;
        if matches!(status, ReviewStatus::Approved | ReviewStatus::Rejected) {
            review.resolved_at = Some(ctx.timestamp);
        }
        review.reviewer = Some(ctx.sender);
        ctx.db.manual_review().review_id().update(review);
        Ok(())
    } else {
        Err("Manual review not found".to_string())
    }
}

#[reducer]
pub fn file_sybil_report(
    ctx: &ReducerContext,
    suspect: Identity,
    reason: String,
    score: f32,
    evidence: String,
) -> Result<(), String> {
    let report = AntiSybilReport {
        report_id: 0,
        identity: suspect,
        reason,
        score,
        evidence,
        created_at: ctx.timestamp,
        resolved_at: None,
    };
    ctx.db.anti_sybil_report().insert(report);
    Ok(())
}

/*
 * --------------------
 * Reducers - Scheduled Logic
 * --------------------
 */

#[reducer]
pub fn quest_tick(ctx: &ReducerContext, _ticket: QuestTickSchedule) -> Result<(), String> {
    if ctx.sender != ctx.identity() {
        return Err("quest_tick can only be invoked by scheduler".to_string());
    }

    let mut to_update: Vec<u64> = Vec::new();
    for instance in ctx.db.quest_instance().iter() {
        if matches!(instance.state, QuestProgressState::Active) {
            if let Some(quest) = ctx.db.quest().quest_id().find(&instance.quest_id) {
                if quest.ends_at < ctx.timestamp {
                    to_update.push(instance.instance_id);
                }
            }
        }
    }

    for instance_id in to_update.iter() {
        if let Some(mut instance) = ctx.db.quest_instance().instance_id().find(*instance_id) {
            instance.state = QuestProgressState::Expired;
            instance.updated_at = ctx.timestamp;
            ctx.db.quest_instance().instance_id().update(instance);
        }
    }

    spacetimedb::log::debug!("quest_tick processed {} instances", to_update.len());
    Ok(())
}