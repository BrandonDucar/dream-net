'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { 
  Search,
  Trophy,
  Crown,
  Star,
  Zap,
  Target,
  Users,
  Calendar,
  Award,
  Medal,
  Shield,
  Sparkles,
  Lock,
  CheckCircle2,
  TrendingUp,
  Heart,
  Gift,
  Flame,
  BookOpen,
  Globe,
} from 'lucide-react';

interface Achievement {
  achievementId: string;
  name: string;
  description: string;
  badgeArtUrl: string;
  xpReward: number;
  criteria: {
    type: string;
    requirement: number;
    current: number;
  };
  rarity: 'Common' | 'Rare' | 'Epic' | 'Legendary' | 'Mythic';
  category: string;
  isUnlocked: boolean;
  unlockedAt?: string;
  completionRate: number; // Global completion rate
}

interface AchievementCategory {
  id: string;
  name: string;
  icon: JSX.Element;
  color: string;
  count: number;
  unlockedCount: number;
}

export default function AchievementsPage(): JSX.Element {
  const [activeTab, setActiveTab] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories: AchievementCategory[] = [
    {
      id: 'quests',
      name: 'Quest Master',
      icon: <Target className="h-5 w-5" />,
      color: 'text-blue-400',
      count: 15,
      unlockedCount: 8,
    },
    {
      id: 'social',
      name: 'Social Butterfly',
      icon: <Users className="h-5 w-5" />,
      color: 'text-pink-400',
      count: 12,
      unlockedCount: 6,
    },
    {
      id: 'defi',
      name: 'DeFi Pioneer',
      icon: <TrendingUp className="h-5 w-5" />,
      color: 'text-green-400',
      count: 18,
      unlockedCount: 4,
    },
    {
      id: 'gaming',
      name: 'Gaming Legend',
      icon: <Crown className="h-5 w-5" />,
      color: 'text-purple-400',
      count: 10,
      unlockedCount: 3,
    },
    {
      id: 'creative',
      name: 'Creator',
      icon: <Sparkles className="h-5 w-5" />,
      color: 'text-yellow-400',
      count: 8,
      unlockedCount: 2,
    },
    {
      id: 'special',
      name: 'Special Events',
      icon: <Star className="h-5 w-5" />,
      color: 'text-orange-400',
      count: 5,
      unlockedCount: 1,
    },
  ];

  const achievements: Achievement[] = [
    {
      achievementId: 'first_steps',
      name: 'First Steps',
      description: 'Complete your very first quest and begin your DreamNet journey.',
      badgeArtUrl: '🏆',
      xpReward: 500,
      criteria: {
        type: 'questsCompleted',
        requirement: 1,
        current: 1,
      },
      rarity: 'Common',
      category: 'quests',
      isUnlocked: true,
      unlockedAt: '2024-01-15T10:30:00Z',
      completionRate: 89.5,
    },
    {
      achievementId: 'quest_master',
      name: 'Quest Master',
      description: 'Complete 25 quests to prove your dedication and skill.',
      badgeArtUrl: '🎯',
      xpReward: 2500,
      criteria: {
        type: 'questsCompleted',
        requirement: 25,
        current: 12,
      },
      rarity: 'Epic',
      category: 'quests',
      isUnlocked: false,
      completionRate: 23.4,
    },
    {
      achievementId: 'social_butterfly',
      name: 'Social Butterfly',
      description: 'Connect with the community by completing 5 social quests.',
      badgeArtUrl: '🦋',
      xpReward: 1000,
      criteria: {
        type: 'socialQuestsCompleted',
        requirement: 5,
        current: 3,
      },
      rarity: 'Rare',
      category: 'social',
      isUnlocked: false,
      completionRate: 45.2,
    },
    {
      achievementId: 'defi_expert',
      name: 'DeFi Expert',
      description: 'Master decentralized finance by completing 10 DeFi quests.',
      badgeArtUrl: '💎',
      xpReward: 3000,
      criteria: {
        type: 'defiQuestsCompleted',
        requirement: 10,
        current: 2,
      },
      rarity: 'Legendary',
      category: 'defi',
      isUnlocked: false,
      completionRate: 8.7,
    },
    {
      achievementId: 'speed_runner',
      name: 'Speed Runner',
      description: 'Complete 3 quests in a single day.',
      badgeArtUrl: '⚡',
      xpReward: 1500,
      criteria: {
        type: 'questsInDay',
        requirement: 3,
        current: 1,
      },
      rarity: 'Rare',
      category: 'quests',
      isUnlocked: false,
      completionRate: 34.8,
    },
    {
      achievementId: 'community_leader',
      name: 'Community Leader',
      description: 'Reach level 25 and become a true leader in the community.',
      badgeArtUrl: '👑',
      xpReward: 5000,
      criteria: {
        type: 'levelReached',
        requirement: 25,
        current: 9,
      },
      rarity: 'Mythic',
      category: 'special',
      isUnlocked: false,
      completionRate: 2.1,
    },
    {
      achievementId: 'early_adopter',
      name: 'Early Adopter',
      description: 'Join DreamNet during the beta period and shape the future.',
      badgeArtUrl: '🚀',
      xpReward: 1000,
      criteria: {
        type: 'earlyAccess',
        requirement: 1,
        current: 1,
      },
      rarity: 'Epic',
      category: 'special',
      isUnlocked: true,
      unlockedAt: '2024-01-01T00:00:00Z',
      completionRate: 15.3,
    },
    {
      achievementId: 'guild_founder',
      name: 'Guild Founder',
      description: 'Create a guild and bring the community together.',
      badgeArtUrl: '🏛️',
      xpReward: 2000,
      criteria: {
        type: 'guildsCreated',
        requirement: 1,
        current: 0,
      },
      rarity: 'Epic',
      category: 'social',
      isUnlocked: false,
      completionRate: 12.6,
    },
    {
      achievementId: 'nft_creator',
      name: 'NFT Creator',
      description: 'Mint your first NFT and express your creativity.',
      badgeArtUrl: '🎨',
      xpReward: 1500,
      criteria: {
        type: 'nftsMinted',
        requirement: 1,
        current: 0,
      },
      rarity: 'Rare',
      category: 'creative',
      isUnlocked: false,
      completionRate: 28.9,
    },
    {
      achievementId: 'helping_hand',
      name: 'Helping Hand',
      description: 'Help 10 other community members with their quests.',
      badgeArtUrl: '🤝',
      xpReward: 2000,
      criteria: {
        type: 'membersHelped',
        requirement: 10,
        current: 3,
      },
      rarity: 'Epic',
      category: 'social',
      isUnlocked: false,
      completionRate: 18.4,
    },
  ];

  const filteredAchievements = achievements.filter(achievement => {
    const matchesSearch = achievement.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         achievement.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || achievement.category === selectedCategory;
    
    const matchesTab = 
      activeTab === 'all' ||
      (activeTab === 'unlocked' && achievement.isUnlocked) ||
      (activeTab === 'locked' && !achievement.isUnlocked) ||
      (activeTab === 'progress' && !achievement.isUnlocked && achievement.criteria.current > 0);
    
    return matchesSearch && matchesCategory && matchesTab;
  });

  const getRarityColor = (rarity: string): string => {
    switch (rarity) {
      case 'Common':
        return 'text-gray-400 border-gray-400';
      case 'Rare':
        return 'text-blue-400 border-blue-400';
      case 'Epic':
        return 'text-purple-400 border-purple-400';
      case 'Legendary':
        return 'text-yellow-400 border-yellow-400';
      case 'Mythic':
        return 'text-red-400 border-red-400';
      default:
        return 'text-gray-400 border-gray-400';
    }
  };

  const calculateStats = () => {
    const totalAchievements = achievements.length;
    const unlockedAchievements = achievements.filter(a => a.isUnlocked).length;
    const totalXpEarned = achievements.filter(a => a.isUnlocked).reduce((sum, a) => sum + a.xpReward, 0);
    const completionPercentage = Math.round((unlockedAchievements / totalAchievements) * 100);
    
    return {
      totalAchievements,
      unlockedAchievements,
      totalXpEarned,
      completionPercentage,
    };
  };

  const stats = calculateStats();

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Trophy className="h-8 w-8 text-yellow-400" />
              <div>
                <h1 className="text-2xl font-bold">Achievements</h1>
                <p className="text-gray-400 text-sm">Track your progress and unlock rewards</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-center">
                <p className="text-lg font-bold text-white">{stats.unlockedAchievements}/{stats.totalAchievements}</p>
                <p className="text-xs text-gray-400">Unlocked</p>
              </div>
              <div className="text-center">
                <p className="text-lg font-bold text-yellow-400">{stats.totalXpEarned.toLocaleString()}</p>
                <p className="text-xs text-gray-400">XP Earned</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Progress Overview */}
        <Card className="bg-gray-900 border-gray-700 mb-6">
          <CardHeader>
            <CardTitle className="text-white">Your Achievement Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Overall Completion</span>
                <span className="text-white font-bold">{stats.completionPercentage}%</span>
              </div>
              <Progress value={stats.completionPercentage} className="h-3" />
              
              <div className="grid grid-cols-3 md:grid-cols-6 gap-4 mt-6">
                {categories.map((category) => (
                  <div key={category.id} className="text-center">
                    <div className={`${category.color} mb-2 flex justify-center`}>
                      {category.icon}
                    </div>
                    <p className="text-xs text-gray-400">{category.name}</p>
                    <p className="text-sm font-bold text-white">{category.unlockedCount}/{category.count}</p>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Search and Filters */}
        <div className="flex flex-col lg:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search achievements..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-gray-900 border-gray-700 text-white"
            />
          </div>
          
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-4 py-2 bg-gray-900 border border-gray-700 rounded-md text-white min-w-[160px]"
          >
            <option value="all">All Categories</option>
            {categories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-gray-900">
            <TabsTrigger value="all">
              <Trophy className="h-4 w-4 mr-2" />
              All ({achievements.length})
            </TabsTrigger>
            <TabsTrigger value="unlocked">
              <CheckCircle2 className="h-4 w-4 mr-2" />
              Unlocked ({stats.unlockedAchievements})
            </TabsTrigger>
            <TabsTrigger value="progress">
              <Target className="h-4 w-4 mr-2" />
              In Progress
            </TabsTrigger>
            <TabsTrigger value="locked">
              <Lock className="h-4 w-4 mr-2" />
              Locked
            </TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="space-y-4 mt-6">
            {filteredAchievements.length === 0 ? (
              <Card className="bg-gray-900 border-gray-700">
                <CardContent className="p-8 text-center">
                  <Trophy className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">No achievements found</h3>
                  <p className="text-gray-400">Try adjusting your search or filters</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredAchievements.map((achievement) => (
                  <Card 
                    key={achievement.achievementId} 
                    className={`relative overflow-hidden transition-all duration-200 ${
                      achievement.isUnlocked 
                        ? 'bg-gradient-to-br from-yellow-900/20 to-yellow-700/10 border-yellow-600/50 shadow-lg shadow-yellow-600/10'
                        : 'bg-gray-900 border-gray-700 hover:border-gray-600'
                    } ${
                      !achievement.isUnlocked && achievement.criteria.current === 0 
                        ? 'opacity-60' 
                        : ''
                    }`}
                  >
                    {achievement.isUnlocked && (
                      <div className="absolute top-2 right-2">
                        <CheckCircle2 className="h-5 w-5 text-green-400" />
                      </div>
                    )}
                    
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="text-3xl">{achievement.badgeArtUrl}</div>
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-1">
                              <h4 className="font-bold text-white">{achievement.name}</h4>
                              {!achievement.isUnlocked && achievement.criteria.current === 0 && (
                                <Lock className="h-4 w-4 text-gray-400" />
                              )}
                            </div>
                            <div className="flex items-center space-x-2">
                              <Badge 
                                variant="outline" 
                                className={`text-xs ${getRarityColor(achievement.rarity)}`}
                              >
                                {achievement.rarity}
                              </Badge>
                              <Badge className="bg-yellow-600 text-white text-xs">
                                <Zap className="h-3 w-3 mr-1" />
                                {achievement.xpReward} XP
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      <p className="text-gray-300 text-sm leading-relaxed">
                        {achievement.description}
                      </p>
                      
                      {achievement.isUnlocked ? (
                        <div className="bg-green-900/30 border border-green-600/50 rounded-lg p-3">
                          <div className="flex items-center space-x-2 mb-2">
                            <Trophy className="h-4 w-4 text-yellow-400" />
                            <span className="text-green-400 font-medium text-sm">Achievement Unlocked!</span>
                          </div>
                          <p className="text-gray-400 text-xs">
                            Unlocked on {new Date(achievement.unlockedAt!).toLocaleDateString()}
                          </p>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-gray-400">Progress</span>
                            <span className="text-white">
                              {achievement.criteria.current}/{achievement.criteria.requirement}
                            </span>
                          </div>
                          <Progress 
                            value={(achievement.criteria.current / achievement.criteria.requirement) * 100} 
                            className="h-2" 
                          />
                          {achievement.criteria.current > 0 && (
                            <p className="text-blue-400 text-xs">
                              {achievement.criteria.requirement - achievement.criteria.current} more to unlock!
                            </p>
                          )}
                        </div>
                      )}
                      
                      <div className="flex items-center justify-between text-xs text-gray-500 pt-2 border-t border-gray-700">
                        <span>Global completion: {achievement.completionRate}%</span>
                        <div className="flex items-center space-x-1">
                          <Globe className="h-3 w-3" />
                          <span>
                            {achievement.completionRate > 50 ? 'Common' : 
                             achievement.completionRate > 25 ? 'Uncommon' : 
                             achievement.completionRate > 10 ? 'Rare' : 'Ultra Rare'}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}