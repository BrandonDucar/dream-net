'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { 
  TrendingUp,
  TrendingDown,
  BarChart3,
  PieChart,
  Calendar,
  Users,
  Target,
  Trophy,
  Zap,
  Clock,
  Star,
  Activity,
  DollarSign,
  Eye,
  MousePointer,
  Download,
  Share,
  Filter,
} from 'lucide-react';

interface MetricCard {
  title: string;
  value: string;
  change: number;
  changeType: 'positive' | 'negative' | 'neutral';
  icon: JSX.Element;
  description: string;
}

interface ChartData {
  name: string;
  value: number;
  change?: number;
}

export default function AnalyticsPage(): JSX.Element {
  const [timeframe, setTimeframe] = useState<string>('30d');
  const [selectedMetric, setSelectedMetric] = useState<string>('overview');

  // Mock analytics data
  const overviewMetrics: MetricCard[] = [
    {
      title: 'Total XP Earned',
      value: '125,430',
      change: 12.5,
      changeType: 'positive',
      icon: <Zap className="h-5 w-5 text-yellow-400" />,
      description: 'Experience points gained',
    },
    {
      title: 'Quests Completed',
      value: '47',
      change: 8.2,
      changeType: 'positive',
      icon: <Target className="h-5 w-5 text-green-400" />,
      description: 'Successfully finished quests',
    },
    {
      title: 'Current Level',
      value: '18',
      change: 5.3,
      changeType: 'positive',
      icon: <Trophy className="h-5 w-5 text-purple-400" />,
      description: 'Your progression level',
    },
    {
      title: 'Completion Rate',
      value: '87%',
      change: -2.1,
      changeType: 'negative',
      icon: <BarChart3 className="h-5 w-5 text-blue-400" />,
      description: 'Quest success percentage',
    },
    {
      title: 'Average Time',
      value: '24m',
      change: -15.6,
      changeType: 'positive',
      icon: <Clock className="h-5 w-5 text-orange-400" />,
      description: 'Per quest completion',
    },
    {
      title: 'Streak Days',
      value: '12',
      change: 100,
      changeType: 'positive',
      icon: <Activity className="h-5 w-5 text-red-400" />,
      description: 'Consecutive active days',
    },
  ];

  const categoryPerformance: ChartData[] = [
    { name: 'Social', value: 15, change: 12 },
    { name: 'DeFi', value: 8, change: -5 },
    { name: 'Gaming', value: 12, change: 23 },
    { name: 'NFT', value: 6, change: 8 },
    { name: 'Education', value: 6, change: 15 },
  ];

  const difficultyBreakdown: ChartData[] = [
    { name: 'Easy', value: 65 },
    { name: 'Medium', value: 25 },
    { name: 'Hard', value: 8 },
    { name: 'Legendary', value: 2 },
  ];

  const weeklyActivity: ChartData[] = [
    { name: 'Mon', value: 4200 },
    { name: 'Tue', value: 3800 },
    { name: 'Wed', value: 5200 },
    { name: 'Thu', value: 4600 },
    { name: 'Fri', value: 6100 },
    { name: 'Sat', value: 7300 },
    { name: 'Sun', value: 5800 },
  ];

  const recentAchievements = [
    {
      name: 'Speed Runner',
      description: 'Complete 3 quests in one day',
      unlockedAt: '2024-01-20',
      xp: 1500,
      rarity: 'Rare',
    },
    {
      name: 'Social Butterfly',
      description: 'Complete 5 social quests',
      unlockedAt: '2024-01-18',
      xp: 1000,
      rarity: 'Uncommon',
    },
    {
      name: 'First Steps',
      description: 'Complete your first quest',
      unlockedAt: '2024-01-15',
      xp: 500,
      rarity: 'Common',
    },
  ];

  const guildContribution = {
    totalContribution: 15600,
    guildRank: 3,
    memberRank: 8,
    guildName: 'DeFi Masters',
  };

  const getChangeIcon = (changeType: string): JSX.Element => {
    switch (changeType) {
      case 'positive':
        return <TrendingUp className="h-3 w-3 text-green-400" />;
      case 'negative':
        return <TrendingDown className="h-3 w-3 text-red-400" />;
      default:
        return <Activity className="h-3 w-3 text-gray-400" />;
    }
  };

  const getChangeColor = (changeType: string): string => {
    switch (changeType) {
      case 'positive':
        return 'text-green-400';
      case 'negative':
        return 'text-red-400';
      default:
        return 'text-gray-400';
    }
  };

  const getRarityColor = (rarity: string): string => {
    switch (rarity) {
      case 'Rare':
        return 'text-purple-400 border-purple-400';
      case 'Uncommon':
        return 'text-blue-400 border-blue-400';
      case 'Common':
        return 'text-gray-400 border-gray-400';
      default:
        return 'text-gray-400 border-gray-400';
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <TrendingUp className="h-8 w-8 text-blue-400" />
              <div>
                <h1 className="text-2xl font-bold">Analytics Dashboard</h1>
                <p className="text-gray-400 text-sm">Track your performance and progress</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Select value={timeframe} onValueChange={setTimeframe}>
                <SelectTrigger className="bg-gray-900 border-gray-700 text-white w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-gray-700">
                  <SelectItem value="7d" className="text-white">Last 7 days</SelectItem>
                  <SelectItem value="30d" className="text-white">Last 30 days</SelectItem>
                  <SelectItem value="90d" className="text-white">Last 3 months</SelectItem>
                  <SelectItem value="1y" className="text-white">Last year</SelectItem>
                </SelectContent>
              </Select>
              
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
                <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                  <Share className="h-4 w-4 mr-2" />
                  Share
                </Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs value={selectedMetric} onValueChange={setSelectedMetric} className="w-full">
          <TabsList className="grid w-full grid-cols-5 bg-gray-900 mb-6">
            <TabsTrigger value="overview">
              <Eye className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="performance">
              <BarChart3 className="h-4 w-4 mr-2" />
              Performance
            </TabsTrigger>
            <TabsTrigger value="achievements">
              <Trophy className="h-4 w-4 mr-2" />
              Achievements
            </TabsTrigger>
            <TabsTrigger value="social">
              <Users className="h-4 w-4 mr-2" />
              Social
            </TabsTrigger>
            <TabsTrigger value="trends">
              <TrendingUp className="h-4 w-4 mr-2" />
              Trends
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Metrics Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {overviewMetrics.map((metric, index) => (
                <Card key={index} className="bg-gray-900 border-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        {metric.icon}
                        <div>
                          <p className="text-sm text-gray-400">{metric.title}</p>
                          <p className="text-2xl font-bold text-white">{metric.value}</p>
                        </div>
                      </div>
                      <div className={`flex items-center space-x-1 ${getChangeColor(metric.changeType)}`}>
                        {getChangeIcon(metric.changeType)}
                        <span className="text-sm font-medium">
                          {Math.abs(metric.change)}%
                        </span>
                      </div>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">{metric.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gray-900 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Category Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {categoryPerformance.map((category, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-3 h-3 bg-purple-400 rounded-full"></div>
                          <span className="text-white">{category.name}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-white font-medium">{category.value}</span>
                          {category.change && (
                            <div className={`flex items-center space-x-1 ${
                              category.change > 0 ? 'text-green-400' : 'text-red-400'
                            }`}>
                              {category.change > 0 ? (
                                <TrendingUp className="h-3 w-3" />
                              ) : (
                                <TrendingDown className="h-3 w-3" />
                              )}
                              <span className="text-xs">{Math.abs(category.change)}%</span>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Weekly Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {weeklyActivity.map((day, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-gray-400 text-sm w-12">{day.name}</span>
                        <div className="flex-1 mx-3">
                          <Progress value={(day.value / 8000) * 100} className="h-2" />
                        </div>
                        <span className="text-white text-sm font-medium w-16 text-right">
                          {day.value.toLocaleString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Performance Tab */}
          <TabsContent value="performance" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gray-900 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Difficulty Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {difficultyBreakdown.map((difficulty, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-gray-300">{difficulty.name}</span>
                          <span className="text-white font-medium">{difficulty.value}%</span>
                        </div>
                        <Progress value={difficulty.value} className="h-2" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Performance Insights</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="bg-green-900/30 border border-green-600/50 rounded-lg p-4">
                      <div className="flex items-center space-x-2 mb-2">
                        <TrendingUp className="h-4 w-4 text-green-400" />
                        <span className="text-green-400 font-medium">Strong Performance</span>
                      </div>
                      <p className="text-gray-300 text-sm">
                        Your completion rate is 15% above average. Keep up the excellent work!
                      </p>
                    </div>

                    <div className="bg-blue-900/30 border border-blue-600/50 rounded-lg p-4">
                      <div className="flex items-center space-x-2 mb-2">
                        <Clock className="h-4 w-4 text-blue-400" />
                        <span className="text-blue-400 font-medium">Efficiency Boost</span>
                      </div>
                      <p className="text-gray-300 text-sm">
                        Your average completion time has improved by 15 minutes this month.
                      </p>
                    </div>

                    <div className="bg-purple-900/30 border border-purple-600/50 rounded-lg p-4">
                      <div className="flex items-center space-x-2 mb-2">
                        <Star className="h-4 w-4 text-purple-400" />
                        <span className="text-purple-400 font-medium">Streak Active</span>
                      </div>
                      <p className="text-gray-300 text-sm">
                        You're on a 12-day activity streak. Aim for 30 days to unlock a special badge!
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Progress Comparison</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <p className="text-3xl font-bold text-white">Top 15%</p>
                    <p className="text-gray-400 text-sm">Global Ranking</p>
                    <Badge className="bg-yellow-600 mt-2">Elite Performer</Badge>
                  </div>
                  <div className="text-center">
                    <p className="text-3xl font-bold text-white">2.3x</p>
                    <p className="text-gray-400 text-sm">Vs Average User</p>
                    <Badge className="bg-green-600 mt-2">High Achiever</Badge>
                  </div>
                  <div className="text-center">
                    <p className="text-3xl font-bold text-white">87%</p>
                    <p className="text-gray-400 text-sm">Success Rate</p>
                    <Badge className="bg-blue-600 mt-2">Consistent</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements" className="space-y-6">
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Recent Achievements</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentAchievements.map((achievement, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-800 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Trophy className="h-8 w-8 text-yellow-400" />
                        <div>
                          <h4 className="text-white font-medium">{achievement.name}</h4>
                          <p className="text-gray-400 text-sm">{achievement.description}</p>
                          <p className="text-gray-500 text-xs">
                            Unlocked {new Date(achievement.unlockedAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge 
                          variant="outline" 
                          className={`mb-2 ${getRarityColor(achievement.rarity)}`}
                        >
                          {achievement.rarity}
                        </Badge>
                        <p className="text-yellow-400 font-bold">+{achievement.xp} XP</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-gray-900 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Achievement Progress</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-300">Quest Master</span>
                        <span className="text-white">12/25</span>
                      </div>
                      <Progress value={48} className="h-2" />
                      <p className="text-xs text-gray-500 mt-1">13 more quests to unlock</p>
                    </div>
                    
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-300">DeFi Expert</span>
                        <span className="text-white">2/10</span>
                      </div>
                      <Progress value={20} className="h-2" />
                      <p className="text-xs text-gray-500 mt-1">8 more DeFi quests to unlock</p>
                    </div>
                    
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-300">Community Leader</span>
                        <span className="text-white">9/25</span>
                      </div>
                      <Progress value={36} className="h-2" />
                      <p className="text-xs text-gray-500 mt-1">Reach level 25 to unlock</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Achievement Stats</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <p className="text-2xl font-bold text-green-400">7</p>
                      <p className="text-gray-400 text-sm">Unlocked</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-blue-400">15</p>
                      <p className="text-gray-400 text-sm">In Progress</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-yellow-400">12,500</p>
                      <p className="text-gray-400 text-sm">XP from Achievements</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-purple-400">Top 8%</p>
                      <p className="text-gray-400 text-sm">Achievement Rank</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Social Tab */}
          <TabsContent value="social" className="space-y-6">
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Guild Contribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="text-white font-medium mb-4">Your Impact in {guildContribution.guildName}</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-400">XP Contributed</span>
                        <span className="text-white font-bold">{guildContribution.totalContribution.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-400">Guild Rank</span>
                        <Badge className="bg-yellow-600">#{guildContribution.guildRank}</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-400">Member Rank</span>
                        <Badge className="bg-blue-600">#{guildContribution.memberRank}</Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-white font-medium mb-4">Social Stats</h4>
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <p className="text-xl font-bold text-blue-400">23</p>
                        <p className="text-gray-400 text-sm">Quest Shares</p>
                      </div>
                      <div>
                        <p className="text-xl font-bold text-green-400">156</p>
                        <p className="text-gray-400 text-sm">Likes Received</p>
                      </div>
                      <div>
                        <p className="text-xl font-bold text-purple-400">89</p>
                        <p className="text-gray-400 text-sm">Comments Made</p>
                      </div>
                      <div>
                        <p className="text-xl font-bold text-yellow-400">12</p>
                        <p className="text-gray-400 text-sm">Friends Invited</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Trends Tab */}
          <TabsContent value="trends" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gray-900 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Growth Trends</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="bg-green-900/30 border border-green-600/50 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-green-400 font-medium">XP Growth Rate</p>
                          <p className="text-gray-300 text-sm">Monthly increase</p>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-green-400">+23%</p>
                          <div className="flex items-center space-x-1 text-green-400">
                            <TrendingUp className="h-3 w-3" />
                            <span className="text-xs">vs last month</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-blue-900/30 border border-blue-600/50 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-blue-400 font-medium">Quest Completion</p>
                          <p className="text-gray-300 text-sm">Weekly average</p>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-blue-400">8.2</p>
                          <div className="flex items-center space-x-1 text-blue-400">
                            <TrendingUp className="h-3 w-3" />
                            <span className="text-xs">quests/week</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-purple-900/30 border border-purple-600/50 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-purple-400 font-medium">Difficulty Progress</p>
                          <p className="text-gray-300 text-sm">Challenge advancement</p>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-purple-400">Hard+</p>
                          <div className="flex items-center space-x-1 text-purple-400">
                            <Star className="h-3 w-3" />
                            <span className="text-xs">level reached</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Predictions & Goals</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-300">Level 20 Target</span>
                        <span className="text-white">15 days</span>
                      </div>
                      <Progress value={78} className="h-2" />
                      <p className="text-xs text-gray-500 mt-1">Based on current pace</p>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-300">Next Achievement</span>
                        <span className="text-white">Quest Master</span>
                      </div>
                      <Progress value={48} className="h-2" />
                      <p className="text-xs text-gray-500 mt-1">13 more quests needed</p>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-300">100K XP Milestone</span>
                        <span className="text-white">3 weeks</span>
                      </div>
                      <Progress value={85} className="h-2" />
                      <p className="text-xs text-gray-500 mt-1">15,430 XP remaining</p>
                    </div>

                    <div className="mt-6 p-4 bg-yellow-900/30 border border-yellow-600/50 rounded-lg">
                      <div className="flex items-center space-x-2 mb-2">
                        <Trophy className="h-4 w-4 text-yellow-400" />
                        <span className="text-yellow-400 font-medium">Optimization Tip</span>
                      </div>
                      <p className="text-gray-300 text-sm">
                        Focus on Hard difficulty quests to maximize XP gain and reach your next level faster!
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}