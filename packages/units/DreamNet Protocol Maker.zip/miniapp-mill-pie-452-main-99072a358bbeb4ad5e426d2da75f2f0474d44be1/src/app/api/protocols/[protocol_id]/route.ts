import { NextRequest, NextResponse } from 'next/server';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ protocol_id: string }> }
) {
  const resolvedParams = await params;
  const protocolId = resolvedParams.protocol_id;

  try {
    const dbHost = "wss://maincloud.spacetimedb.com";
    const dbName = process.env.NEXT_PUBLIC_SPACETIME_MODULE_NAME || "default_module";

    const apiUrl = `https://maincloud.spacetimedb.com/database/sql/${dbName}`;

    const queryProtocol = `SELECT * FROM protocol WHERE protocol_id = '${protocolId}'`;
    const queryNodes = `SELECT * FROM node WHERE protocol_id = '${protocolId}'`;
    const queryEdges = `SELECT * FROM edge WHERE protocol_id = '${protocolId}'`;

    const [protocolRes, nodesRes, edgesRes] = await Promise.all([
      fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ sql_text: queryProtocol }),
      }),
      fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ sql_text: queryNodes }),
      }),
      fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ sql_text: queryEdges }),
      }),
    ]);

    if (!protocolRes.ok) {
      return NextResponse.json(
        { error: 'Failed to fetch protocol' },
        { status: 500 }
      );
    }

    const protocolData = await protocolRes.json();
    const nodesData = await nodesRes.json();
    const edgesData = await edgesRes.json();

    if (!protocolData.rows || protocolData.rows.length === 0) {
      return NextResponse.json(
        { error: 'Protocol not found' },
        { status: 404 }
      );
    }

    const protocol = protocolData.rows[0];
    const nodes = nodesData.rows || [];
    const edges = edgesData.rows || [];

    const statusMap: Record<string, string> = {
      Draft: 'draft',
      Active: 'active',
      Archived: 'archived',
    };

    const nodeTypeMap: Record<string, string> = {
      Entry: 'entry',
      Funnel: 'funnel',
      RitualRef: 'ritual_ref',
      Action: 'action',
      Reward: 'reward',
      Exit: 'exit',
    };

    const netProtocol = {
      protocol_id: protocol.protocol_id,
      name: protocol.name,
      description: protocol.description,
      version: protocol.version,
      status: statusMap[protocol.status] || 'draft',
      created_at: new Date(protocol.created_at / 1000).toISOString(),
      updated_at: new Date(protocol.updated_at / 1000).toISOString(),
      entry_points: JSON.parse(protocol.entry_points),
      nodes: nodes.map((node: { node_id: string; node_type: string; label: string; node_data: string }) => {
        const nodeData = JSON.parse(node.node_data);
        return {
          id: node.node_id,
          type: nodeTypeMap[node.node_type] || 'entry',
          label: node.label,
          ...nodeData,
        };
      }),
      edges: edges.map((edge: { from_node_id: string; to_node_id: string; condition: string; notes: string }) => ({
        from: edge.from_node_id,
        to: edge.to_node_id,
        condition: edge.condition,
        notes: edge.notes || undefined,
      })),
    };

    return NextResponse.json(netProtocol);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json(
      { error: `Failed to fetch protocol: ${errorMessage}` },
      { status: 500 }
    );
  }
}
