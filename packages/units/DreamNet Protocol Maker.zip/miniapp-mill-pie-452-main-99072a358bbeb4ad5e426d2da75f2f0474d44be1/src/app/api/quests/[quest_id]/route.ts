import { NextRequest, NextResponse } from 'next/server';

// Mock quest data for API endpoint
const mockQuests = {
  'quest_social_onboard_001': {
    questId: 'quest_social_onboard_001',
    creator: 'system',
    categoryId: 'social',
    title: 'Social Media Onboarding',
    summary: 'Join our community across social platforms and earn your first rewards!',
    difficulty: 'Easy',
    status: 'Published',
    estimatedMinutes: 15,
    rewardPoolId: 'pool_social_001',
    metadata: JSON.stringify({
      description: 'Welcome to DreamNet! This quest will help you get started by connecting with our community.',
      tasks: [
        { id: 'task_twitter_follow', title: 'Follow @DreamNet', xp: 100 },
        { id: 'task_discord_join', title: 'Join Discord', xp: 150 },
        { id: 'task_intro_post', title: 'Introduce Yourself', xp: 200 },
      ],
    }),
    startsAt: new Date('2024-01-01').toISOString(),
    endsAt: new Date('2025-12-31').toISOString(),
    createdAt: new Date('2024-01-01').toISOString(),
    updatedAt: new Date('2024-01-01').toISOString(),
  },
  'quest_defi_explorer_002': {
    questId: 'quest_defi_explorer_002',
    creator: 'system',
    categoryId: 'defi',
    title: 'DeFi Explorer Challenge',
    summary: 'Explore the world of decentralized finance and earn rewards for your first transactions.',
    difficulty: 'Medium',
    status: 'Published',
    estimatedMinutes: 45,
    rewardPoolId: 'pool_defi_002',
    metadata: JSON.stringify({
      description: 'Learn the basics of DeFi by completing real transactions on Base.',
      tasks: [
        { id: 'task_wallet_connect', title: 'Connect Wallet', xp: 150 },
        { id: 'task_swap_tokens', title: 'Make First Swap', xp: 300 },
        { id: 'task_provide_liquidity', title: 'Provide Liquidity', xp: 500 },
      ],
    }),
    startsAt: new Date('2024-01-01').toISOString(),
    endsAt: new Date('2025-12-31').toISOString(),
    createdAt: new Date('2024-01-01').toISOString(),
    updatedAt: new Date('2024-01-01').toISOString(),
  },
};

export async function GET(
  request: NextRequest,
  { params }: { params: { quest_id: string } }
): Promise<NextResponse> {
  try {
    const questId = params.quest_id;
    
    // Check if quest exists in mock data
    const quest = mockQuests[questId as keyof typeof mockQuests];
    
    if (!quest) {
      return NextResponse.json(
        { error: 'Quest not found' },
        { status: 404 }
      );
    }

    // Return quest data in NetProtocol-compatible format
    return NextResponse.json({
      protocol_id: quest.questId,
      name: quest.title,
      description: quest.summary,
      version: 1,
      status: quest.status.toLowerCase(),
      created_at: quest.createdAt,
      updated_at: quest.updatedAt,
      entry_points: ['entry_1'],
      nodes: [
        {
          id: 'entry_1',
          type: 'entry',
          label: 'Quest Start',
          entry_kind: 'direct_buy',
          chain: 'base',
          token: 'ETH',
          min_amount: '0',
        },
        ...JSON.parse(quest.metadata).tasks.map((task: any, index: number) => ({
          id: task.id,
          type: 'action',
          label: task.title,
          action_type: task.id.includes('twitter') ? 'post_on_x' : 
                      task.id.includes('discord') ? 'join_discord' :
                      task.id.includes('swap') ? 'lp_on_base' : 'custom',
          params: { xp_reward: task.xp },
        })),
        {
          id: 'reward_1',
          type: 'reward',
          label: 'Quest Completion Reward',
          reward_type: 'score_boost',
          amount: JSON.parse(quest.metadata).tasks.reduce((sum: number, task: any) => sum + task.xp, 0).toString(),
        },
        {
          id: 'exit_1',
          type: 'exit',
          label: 'Quest Complete',
          exit_kind: 'success',
        },
      ],
      edges: [
        { from: 'entry_1', to: JSON.parse(quest.metadata).tasks[0]?.id || 'exit_1', condition: 'always' },
        ...JSON.parse(quest.metadata).tasks.slice(1).map((task: any, index: number) => ({
          from: JSON.parse(quest.metadata).tasks[index].id,
          to: task.id,
          condition: 'requirements_met',
        })),
        {
          from: JSON.parse(quest.metadata).tasks[JSON.parse(quest.metadata).tasks.length - 1]?.id || 'entry_1',
          to: 'reward_1',
          condition: 'requirements_met',
        },
        { from: 'reward_1', to: 'exit_1', condition: 'always' },
      ],
    });
  } catch (error) {
    console.error('Error fetching quest:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { quest_id: string } }
): Promise<NextResponse> {
  return NextResponse.json(
    { message: 'Quest creation endpoint - feature coming soon' },
    { status: 501 }
  );
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { quest_id: string } }
): Promise<NextResponse> {
  return NextResponse.json(
    { message: 'Quest update endpoint - feature coming soon' },
    { status: 501 }
  );
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { quest_id: string } }
): Promise<NextResponse> {
  return NextResponse.json(
    { message: 'Quest deletion endpoint - feature coming soon' },
    { status: 501 }
  );
}