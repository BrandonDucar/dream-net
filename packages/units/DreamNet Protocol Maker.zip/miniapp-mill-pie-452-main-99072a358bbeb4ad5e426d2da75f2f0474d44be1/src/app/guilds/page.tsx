'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Search,
  Plus,
  Users,
  Crown,
  Shield,
  Star,
  Trophy,
  Target,
  Zap,
  Calendar,
  Globe,
  Lock,
  Settings,
  UserPlus,
  MessageCircle,
  TrendingUp,
  Award,
  Heart,
} from 'lucide-react';
import { useQuestPlatform } from '@/hooks/useQuestPlatform';

interface Guild {
  guildId: string;
  name: string;
  description: string;
  crestUrl: string;
  inviteCode: string;
  memberCount: number;
  maxMembers: number;
  isPublic: boolean;
  totalXp: number;
  rank: number;
  createdAt: string;
  leader: {
    handle: string;
    avatarUrl: string;
  };
  categories: string[];
  activeQuests: number;
  completedQuests: number;
}

interface GuildMember {
  identity: string;
  handle: string;
  avatarUrl: string;
  role: 'Leader' | 'Officer' | 'Member';
  xpContributed: number;
  joinedAt: string;
  lastActive: string;
  questsCompleted: number;
}

export default function GuildsPage(): JSX.Element {
  const { createGuild, joinGuild } = useQuestPlatform();
  
  const [activeTab, setActiveTab] = useState<string>('discover');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [showCreateGuild, setShowCreateGuild] = useState<boolean>(false);
  const [selectedGuild, setSelectedGuild] = useState<Guild | null>(null);
  const [isJoining, setIsJoining] = useState<boolean>(false);

  const [newGuildData, setNewGuildData] = useState({
    guildId: '',
    name: '',
    description: '',
    crestUrl: '',
    inviteCode: '',
    isPublic: true,
  });

  // Mock guild data
  const [guilds, setGuilds] = useState<Guild[]>([
    {
      guildId: 'guild_defi_masters',
      name: 'DeFi Masters',
      description: 'Elite group of DeFi experts helping newcomers navigate the decentralized finance world.',
      crestUrl: '🏆',
      inviteCode: 'DEFI2024',
      memberCount: 247,
      maxMembers: 500,
      isPublic: true,
      totalXp: 1250000,
      rank: 1,
      createdAt: '2024-01-01',
      leader: {
        handle: '@defi_whale',
        avatarUrl: '',
      },
      categories: ['defi', 'education'],
      activeQuests: 12,
      completedQuests: 156,
    },
    {
      guildId: 'guild_nft_creators',
      name: 'NFT Creators Collective',
      description: 'A community of artists, creators, and NFT enthusiasts building the future of digital art.',
      crestUrl: '🎨',
      inviteCode: 'CREATE2024',
      memberCount: 189,
      maxMembers: 300,
      isPublic: true,
      totalXp: 890000,
      rank: 2,
      createdAt: '2024-01-05',
      leader: {
        handle: '@nft_artist',
        avatarUrl: '',
      },
      categories: ['nft', 'creative'],
      activeQuests: 8,
      completedQuests: 98,
    },
    {
      guildId: 'guild_gaming_legends',
      name: 'Gaming Legends',
      description: 'Hardcore gamers dominating leaderboards and completing the most challenging quests.',
      crestUrl: '🎮',
      inviteCode: 'GAME2024',
      memberCount: 156,
      maxMembers: 200,
      isPublic: false,
      totalXp: 675000,
      rank: 3,
      createdAt: '2024-01-10',
      leader: {
        handle: '@game_master',
        avatarUrl: '',
      },
      categories: ['gaming'],
      activeQuests: 15,
      completedQuests: 203,
    },
    {
      guildId: 'guild_web3_builders',
      name: 'Web3 Builders',
      description: 'Developers, designers, and builders creating the next generation of decentralized applications.',
      crestUrl: '⚡',
      inviteCode: 'BUILD2024',
      memberCount: 98,
      maxMembers: 150,
      isPublic: true,
      totalXp: 456000,
      rank: 4,
      createdAt: '2024-01-15',
      leader: {
        handle: '@builder_dev',
        avatarUrl: '',
      },
      categories: ['education', 'defi'],
      activeQuests: 6,
      completedQuests: 45,
    },
  ]);

  // Mock current user's guild
  const [userGuild, setUserGuild] = useState<Guild | null>(guilds[0]);
  const [userRole, setUserRole] = useState<string>('Member');

  // Mock guild members for selected guild
  const [guildMembers, setGuildMembers] = useState<GuildMember[]>([
    {
      identity: 'user_1',
      handle: '@defi_whale',
      avatarUrl: '',
      role: 'Leader',
      xpContributed: 125000,
      joinedAt: '2024-01-01',
      lastActive: '2024-01-20',
      questsCompleted: 47,
    },
    {
      identity: 'user_2',
      handle: '@crypto_expert',
      avatarUrl: '',
      role: 'Officer',
      xpContributed: 89000,
      joinedAt: '2024-01-02',
      lastActive: '2024-01-19',
      questsCompleted: 35,
    },
    {
      identity: 'user_3',
      handle: '@yield_farmer',
      avatarUrl: '',
      role: 'Member',
      xpContributed: 67000,
      joinedAt: '2024-01-03',
      lastActive: '2024-01-18',
      questsCompleted: 28,
    },
  ]);

  const filteredGuilds = guilds.filter(guild =>
    guild.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    guild.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCreateGuild = async (): Promise<void> => {
    try {
      const guildData = {
        ...newGuildData,
        guildId: `guild_${Date.now()}`,
        inviteCode: newGuildData.inviteCode || Math.random().toString(36).substr(2, 8).toUpperCase(),
      };

      await createGuild(guildData);
      
      // Add to local state
      const newGuild: Guild = {
        ...guildData,
        memberCount: 1,
        maxMembers: 100,
        totalXp: 0,
        rank: guilds.length + 1,
        createdAt: new Date().toISOString().split('T')[0],
        leader: {
          handle: '@you',
          avatarUrl: '',
        },
        categories: [],
        activeQuests: 0,
        completedQuests: 0,
      };

      setGuilds(prev => [...prev, newGuild]);
      setUserGuild(newGuild);
      setUserRole('Leader');
      setShowCreateGuild(false);
      setActiveTab('my-guild');
      
      // Reset form
      setNewGuildData({
        guildId: '',
        name: '',
        description: '',
        crestUrl: '',
        inviteCode: '',
        isPublic: true,
      });

    } catch (error) {
      console.error('Failed to create guild:', error);
    }
  };

  const handleJoinGuild = async (guild: Guild): Promise<void> => {
    setIsJoining(true);
    try {
      await joinGuild(guild.guildId);
      setUserGuild(guild);
      setUserRole('Member');
      setActiveTab('my-guild');
    } catch (error) {
      console.error('Failed to join guild:', error);
    } finally {
      setIsJoining(false);
    }
  };

  const getRoleIcon = (role: string): JSX.Element => {
    switch (role) {
      case 'Leader':
        return <Crown className="h-4 w-4 text-yellow-400" />;
      case 'Officer':
        return <Shield className="h-4 w-4 text-blue-400" />;
      default:
        return <Users className="h-4 w-4 text-gray-400" />;
    }
  };

  const getRoleBadge = (role: string): JSX.Element => {
    const colors = {
      Leader: 'bg-yellow-600 text-white',
      Officer: 'bg-blue-600 text-white',
      Member: 'bg-gray-600 text-white',
    };
    
    return (
      <Badge className={colors[role as keyof typeof colors] || colors.Member}>
        {getRoleIcon(role)}
        <span className="ml-1">{role}</span>
      </Badge>
    );
  };

  if (showCreateGuild) {
    return (
      <div className="min-h-screen bg-black text-white p-4">
        <div className="container mx-auto max-w-2xl">
          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <Plus className="h-6 w-6 text-purple-400" />
                <span>Create New Guild</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-white">Guild Name</Label>
                  <Input
                    placeholder="Enter guild name..."
                    value={newGuildData.name}
                    onChange={(e) => setNewGuildData(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-white">Guild Crest (Emoji)</Label>
                  <Input
                    placeholder="🏆"
                    value={newGuildData.crestUrl}
                    onChange={(e) => setNewGuildData(prev => ({ ...prev, crestUrl: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
              </div>

              <div>
                <Label className="text-white">Description</Label>
                <Textarea
                  placeholder="Describe your guild's mission and goals..."
                  value={newGuildData.description}
                  onChange={(e) => setNewGuildData(prev => ({ ...prev, description: e.target.value }))}
                  className="bg-gray-800 border-gray-600 text-white"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-white">Invite Code (Optional)</Label>
                  <Input
                    placeholder="Leave empty to auto-generate"
                    value={newGuildData.inviteCode}
                    onChange={(e) => setNewGuildData(prev => ({ ...prev, inviteCode: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-white">Visibility</Label>
                  <select
                    value={newGuildData.isPublic ? 'public' : 'private'}
                    onChange={(e) => setNewGuildData(prev => ({ ...prev, isPublic: e.target.value === 'public' }))}
                    className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-md text-white"
                  >
                    <option value="public">Public (Anyone can join)</option>
                    <option value="private">Private (Invite only)</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-between pt-6 border-t border-gray-700">
                <Button
                  variant="outline"
                  onClick={() => setShowCreateGuild(false)}
                  className="border-gray-600 text-gray-300"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleCreateGuild}
                  disabled={!newGuildData.name || !newGuildData.description}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create Guild
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold">Guilds</h1>
              <Badge variant="outline" className="text-green-400 border-green-400">
                {guilds.length} Active Guilds
              </Badge>
            </div>
            <Button
              onClick={() => setShowCreateGuild(true)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Guild
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-gray-900">
            <TabsTrigger value="discover">
              <Search className="h-4 w-4 mr-2" />
              Discover Guilds
            </TabsTrigger>
            <TabsTrigger value="my-guild">
              <Users className="h-4 w-4 mr-2" />
              My Guild
            </TabsTrigger>
            <TabsTrigger value="leaderboard">
              <Trophy className="h-4 w-4 mr-2" />
              Leaderboard
            </TabsTrigger>
          </TabsList>

          {/* Discover Guilds Tab */}
          <TabsContent value="discover" className="space-y-6">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search guilds..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-gray-900 border-gray-700 text-white"
              />
            </div>

            {/* Featured Guild */}
            {filteredGuilds.length > 0 && (
              <Card className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 border-purple-600/50">
                <CardHeader>
                  <div className="flex items-center space-x-2 mb-2">
                    <Star className="h-5 w-5 text-yellow-400" />
                    <Badge className="bg-yellow-600 text-white">Featured Guild</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="text-4xl">{filteredGuilds[0].crestUrl}</div>
                      <div>
                        <h3 className="text-xl font-bold text-white">{filteredGuilds[0].name}</h3>
                        <p className="text-gray-400">{filteredGuilds[0].description}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-white">#{filteredGuilds[0].rank}</p>
                      <p className="text-gray-400 text-sm">Global Rank</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-6 text-sm">
                      <div className="flex items-center space-x-1">
                        <Users className="h-4 w-4 text-blue-400" />
                        <span>{filteredGuilds[0].memberCount}/{filteredGuilds[0].maxMembers}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Zap className="h-4 w-4 text-yellow-400" />
                        <span>{filteredGuilds[0].totalXp.toLocaleString()} XP</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Target className="h-4 w-4 text-green-400" />
                        <span>{filteredGuilds[0].activeQuests} active quests</span>
                      </div>
                    </div>
                    <Button
                      onClick={() => handleJoinGuild(filteredGuilds[0])}
                      disabled={isJoining || !!userGuild}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      {userGuild ? 'Already in Guild' : 'Join Guild'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Guild Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredGuilds.slice(1).map((guild) => (
                <Card key={guild.guildId} className="bg-gray-900 border-gray-700 hover:border-gray-600 transition-all">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="text-2xl">{guild.crestUrl}</div>
                        <div>
                          <h4 className="font-bold text-white">{guild.name}</h4>
                          <p className="text-gray-400 text-sm">Rank #{guild.rank}</p>
                        </div>
                      </div>
                      {!guild.isPublic && <Lock className="h-4 w-4 text-yellow-400" />}
                    </div>
                    <p className="text-gray-400 text-sm line-clamp-2">{guild.description}</p>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center space-x-1">
                        <Users className="h-4 w-4 text-blue-400" />
                        <span>{guild.memberCount}/{guild.maxMembers}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Zap className="h-4 w-4 text-yellow-400" />
                        <span>{(guild.totalXp / 1000).toFixed(0)}K XP</span>
                      </div>
                    </div>
                    
                    <Progress value={(guild.memberCount / guild.maxMembers) * 100} className="h-2" />
                    
                    <div className="flex items-center space-x-2">
                      <Button
                        onClick={() => handleJoinGuild(guild)}
                        disabled={isJoining || !!userGuild}
                        size="sm"
                        className="flex-1 bg-purple-600 hover:bg-purple-700 text-xs"
                      >
                        {userGuild ? 'In Guild' : guild.isPublic ? 'Join' : 'Request'}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedGuild(guild)}
                        className="border-gray-600 text-gray-300 text-xs"
                      >
                        View
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* My Guild Tab */}
          <TabsContent value="my-guild" className="space-y-6">
            {userGuild ? (
              <>
                {/* Guild Header */}
                <Card className="bg-gray-900 border-gray-700">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="text-4xl">{userGuild.crestUrl}</div>
                        <div>
                          <h2 className="text-2xl font-bold text-white">{userGuild.name}</h2>
                          <p className="text-gray-400">{userGuild.description}</p>
                          <div className="flex items-center space-x-2 mt-2">
                            {getRoleBadge(userRole)}
                            <Badge variant="outline" className="border-gray-600 text-gray-400">
                              Rank #{userGuild.rank}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      {userRole === 'Leader' && (
                        <Button
                          variant="outline"
                          className="border-gray-600 text-gray-300"
                        >
                          <Settings className="h-4 w-4 mr-2" />
                          Manage
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-blue-400">{userGuild.memberCount}</p>
                        <p className="text-sm text-gray-400">Members</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-yellow-400">{userGuild.totalXp.toLocaleString()}</p>
                        <p className="text-sm text-gray-400">Total XP</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-green-400">{userGuild.activeQuests}</p>
                        <p className="text-sm text-gray-400">Active Quests</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-purple-400">{userGuild.completedQuests}</p>
                        <p className="text-sm text-gray-400">Completed</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Guild Members */}
                <Card className="bg-gray-900 border-gray-700">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>Guild Members</span>
                      <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                        <UserPlus className="h-4 w-4 mr-2" />
                        Invite
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {guildMembers.map((member) => (
                        <div key={member.identity} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <Avatar className="h-8 w-8">
                              <AvatarImage src={member.avatarUrl} />
                              <AvatarFallback className="bg-purple-600 text-white text-xs">
                                {member.handle.slice(1, 3).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="flex items-center space-x-2">
                                <p className="text-white font-medium">{member.handle}</p>
                                {getRoleBadge(member.role)}
                              </div>
                              <p className="text-gray-400 text-sm">
                                {member.xpContributed.toLocaleString()} XP • {member.questsCompleted} quests
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-gray-400 text-xs">
                              Last active: {new Date(member.lastActive).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card className="bg-gray-900 border-gray-700">
                <CardContent className="p-8 text-center">
                  <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">No Guild Yet</h3>
                  <p className="text-gray-400 mb-6">Join a guild to collaborate with other players and earn bonus rewards!</p>
                  <div className="space-x-2">
                    <Button
                      onClick={() => setActiveTab('discover')}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      <Search className="h-4 w-4 mr-2" />
                      Find Guilds
                    </Button>
                    <Button
                      onClick={() => setShowCreateGuild(true)}
                      variant="outline"
                      className="border-gray-600 text-gray-300"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Create Guild
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Leaderboard Tab */}
          <TabsContent value="leaderboard" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {guilds.slice(0, 10).map((guild, index) => (
                <Card key={guild.guildId} className={`bg-gray-900 border-gray-700 ${
                  index < 3 ? 'ring-2 ring-yellow-600/50' : ''
                }`}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="flex-shrink-0 w-8 text-center">
                          {index === 0 && <Crown className="h-6 w-6 text-yellow-400 mx-auto" />}
                          {index === 1 && <span className="text-gray-300 font-bold text-lg">#2</span>}
                          {index === 2 && <span className="text-amber-600 font-bold text-lg">#3</span>}
                          {index > 2 && <span className="text-gray-400 font-bold text-lg">#{index + 1}</span>}
                        </div>
                        <div className="text-2xl">{guild.crestUrl}</div>
                        <div>
                          <h4 className="font-bold text-white">{guild.name}</h4>
                          <p className="text-gray-400 text-sm">{guild.memberCount} members</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold text-yellow-400">{guild.totalXp.toLocaleString()}</p>
                        <p className="text-gray-400 text-sm">Total XP</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}