'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Bell,
  BellOff,
  Check,
  CheckCheck,
  X,
  Trophy,
  Users,
  Target,
  Heart,
  MessageCircle,
  Star,
  Gift,
  Zap,
  Crown,
  Calendar,
  Settings,
  Filter,
  MoreHorizontal,
} from 'lucide-react';

interface Notification {
  id: string;
  type: 'achievement' | 'quest' | 'social' | 'guild' | 'system' | 'reward';
  title: string;
  message: string;
  timestamp: string;
  isRead: boolean;
  priority: 'low' | 'medium' | 'high';
  actionUrl?: string;
  data?: any;
}

export default function NotificationsPage(): JSX.Element {
  const [activeTab, setActiveTab] = useState<string>('all');
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'achievement',
      title: 'Achievement Unlocked!',
      message: 'You\'ve unlocked the "Speed Runner" achievement for completing 3 quests in one day.',
      timestamp: '2024-01-20T14:30:00Z',
      isRead: false,
      priority: 'high',
      actionUrl: '/achievements',
      data: { achievementId: 'speed_runner', xp: 1500 },
    },
    {
      id: '2',
      type: 'quest',
      title: 'Quest Completed',
      message: 'Congratulations! You\'ve completed the "DeFi Explorer Challenge" quest.',
      timestamp: '2024-01-20T12:15:00Z',
      isRead: false,
      priority: 'medium',
      actionUrl: '/quests/quest_defi_explorer_002',
      data: { questId: 'quest_defi_explorer_002', xp: 750 },
    },
    {
      id: '3',
      type: 'social',
      title: 'New Guild Invitation',
      message: 'DeFi Masters guild has invited you to join their community.',
      timestamp: '2024-01-20T10:45:00Z',
      isRead: false,
      priority: 'medium',
      actionUrl: '/guilds/guild_defi_masters',
      data: { guildId: 'guild_defi_masters', invitedBy: '@defi_whale' },
    },
    {
      id: '4',
      type: 'system',
      title: 'Weekly Report Ready',
      message: 'Your weekly performance report is now available. You earned 3,450 XP this week!',
      timestamp: '2024-01-20T09:00:00Z',
      isRead: true,
      priority: 'low',
      actionUrl: '/analytics',
      data: { weeklyXp: 3450, questsCompleted: 8 },
    },
    {
      id: '5',
      type: 'reward',
      title: 'Reward Claimed',
      message: 'You\'ve successfully claimed your 1,500 XP reward from the Social Media Onboarding quest.',
      timestamp: '2024-01-19T16:20:00Z',
      isRead: true,
      priority: 'medium',
      data: { questId: 'quest_social_onboard_001', xp: 1500 },
    },
    {
      id: '6',
      type: 'guild',
      title: 'Guild Level Up!',
      message: 'Your guild "DeFi Masters" has reached level 15! New perks are now available.',
      timestamp: '2024-01-19T14:30:00Z',
      isRead: true,
      priority: 'medium',
      actionUrl: '/guilds/guild_defi_masters',
      data: { guildId: 'guild_defi_masters', level: 15 },
    },
    {
      id: '7',
      type: 'social',
      title: 'New Follower',
      message: '@crypto_ninja started following you and liked your recent quest completion.',
      timestamp: '2024-01-19T11:45:00Z',
      isRead: true,
      priority: 'low',
      data: { followerId: 'crypto_ninja', action: 'follow' },
    },
    {
      id: '8',
      type: 'quest',
      title: 'New Quest Available',
      message: 'A new Hard difficulty quest "NFT Creator Journey" is now available in your preferred categories.',
      timestamp: '2024-01-19T08:00:00Z',
      isRead: true,
      priority: 'low',
      actionUrl: '/quests/quest_nft_creator_003',
      data: { questId: 'quest_nft_creator_003', difficulty: 'Hard' },
    },
  ]);

  const getNotificationIcon = (type: string): JSX.Element => {
    switch (type) {
      case 'achievement':
        return <Trophy className="h-5 w-5 text-yellow-400" />;
      case 'quest':
        return <Target className="h-5 w-5 text-blue-400" />;
      case 'social':
        return <Users className="h-5 w-5 text-pink-400" />;
      case 'guild':
        return <Crown className="h-5 w-5 text-purple-400" />;
      case 'system':
        return <Bell className="h-5 w-5 text-gray-400" />;
      case 'reward':
        return <Gift className="h-5 w-5 text-green-400" />;
      default:
        return <Bell className="h-5 w-5 text-gray-400" />;
    }
  };

  const getPriorityColor = (priority: string): string => {
    switch (priority) {
      case 'high':
        return 'border-l-red-400';
      case 'medium':
        return 'border-l-yellow-400';
      case 'low':
        return 'border-l-blue-400';
      default:
        return 'border-l-gray-400';
    }
  };

  const getRelativeTime = (timestamp: string): string => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffInSeconds = Math.floor((now.getTime() - time.getTime()) / 1000);
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    return `${Math.floor(diffInSeconds / 86400)}d ago`;
  };

  const markAsRead = (notificationId: string): void => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === notificationId 
          ? { ...notification, isRead: true }
          : notification
      )
    );
  };

  const markAllAsRead = (): void => {
    setNotifications(prev => 
      prev.map(notification => ({ ...notification, isRead: true }))
    );
  };

  const deleteNotification = (notificationId: string): void => {
    setNotifications(prev => prev.filter(notification => notification.id !== notificationId));
  };

  const filteredNotifications = notifications.filter(notification => {
    if (activeTab === 'all') return true;
    if (activeTab === 'unread') return !notification.isRead;
    return notification.type === activeTab;
  });

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Bell className="h-8 w-8 text-blue-400" />
              <div>
                <h1 className="text-2xl font-bold">Notifications</h1>
                <p className="text-gray-400 text-sm">Stay updated with your quest progress</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {unreadCount > 0 && (
                <Button
                  onClick={markAllAsRead}
                  variant="outline"
                  size="sm"
                  className="border-gray-600 text-gray-300"
                >
                  <CheckCheck className="h-4 w-4 mr-2" />
                  Mark All Read
                </Button>
              )}
              
              <Button
                variant="outline"
                size="sm"
                className="border-gray-600 text-gray-300"
              >
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="bg-gray-900 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <Bell className="h-8 w-8 text-blue-400" />
                <div>
                  <p className="text-sm text-gray-400">Total</p>
                  <p className="text-lg font-bold text-white">{notifications.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-900 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <BellOff className="h-8 w-8 text-red-400" />
                <div>
                  <p className="text-sm text-gray-400">Unread</p>
                  <p className="text-lg font-bold text-white">{unreadCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-900 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <Trophy className="h-8 w-8 text-yellow-400" />
                <div>
                  <p className="text-sm text-gray-400">Achievements</p>
                  <p className="text-lg font-bold text-white">
                    {notifications.filter(n => n.type === 'achievement').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-900 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <Heart className="h-8 w-8 text-pink-400" />
                <div>
                  <p className="text-sm text-gray-400">Social</p>
                  <p className="text-lg font-bold text-white">
                    {notifications.filter(n => n.type === 'social').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-7 bg-gray-900">
            <TabsTrigger value="all">
              All ({notifications.length})
            </TabsTrigger>
            <TabsTrigger value="unread">
              Unread ({unreadCount})
            </TabsTrigger>
            <TabsTrigger value="achievement">
              <Trophy className="h-4 w-4 mr-1" />
              Achievements
            </TabsTrigger>
            <TabsTrigger value="quest">
              <Target className="h-4 w-4 mr-1" />
              Quests
            </TabsTrigger>
            <TabsTrigger value="social">
              <Users className="h-4 w-4 mr-1" />
              Social
            </TabsTrigger>
            <TabsTrigger value="guild">
              <Crown className="h-4 w-4 mr-1" />
              Guild
            </TabsTrigger>
            <TabsTrigger value="system">
              <Bell className="h-4 w-4 mr-1" />
              System
            </TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="space-y-4 mt-6">
            {filteredNotifications.length === 0 ? (
              <Card className="bg-gray-900 border-gray-700">
                <CardContent className="p-8 text-center">
                  <Bell className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">No notifications</h3>
                  <p className="text-gray-400">
                    {activeTab === 'unread' 
                      ? 'All caught up! No unread notifications.'
                      : 'No notifications in this category yet.'}
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {filteredNotifications.map((notification) => (
                  <Card 
                    key={notification.id} 
                    className={`bg-gray-900 border-gray-700 border-l-4 ${getPriorityColor(notification.priority)} transition-all ${
                      !notification.isRead ? 'bg-gray-800/50' : ''
                    }`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-3 flex-1">
                          <div className={`mt-1 ${!notification.isRead ? 'opacity-100' : 'opacity-60'}`}>
                            {getNotificationIcon(notification.type)}
                          </div>
                          
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-1">
                              <h4 className={`font-semibold ${
                                !notification.isRead ? 'text-white' : 'text-gray-300'
                              }`}>
                                {notification.title}
                              </h4>
                              {!notification.isRead && (
                                <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                              )}
                              <Badge 
                                variant="outline" 
                                className={`text-xs ${
                                  notification.priority === 'high' ? 'border-red-400 text-red-400' :
                                  notification.priority === 'medium' ? 'border-yellow-400 text-yellow-400' :
                                  'border-blue-400 text-blue-400'
                                }`}
                              >
                                {notification.priority}
                              </Badge>
                            </div>
                            
                            <p className={`text-sm ${
                              !notification.isRead ? 'text-gray-300' : 'text-gray-400'
                            } mb-2`}>
                              {notification.message}
                            </p>
                            
                            <div className="flex items-center justify-between">
                              <p className="text-xs text-gray-500">
                                {getRelativeTime(notification.timestamp)}
                              </p>
                              
                              <div className="flex items-center space-x-2">
                                {notification.actionUrl && (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="text-xs border-gray-600 text-gray-300 h-6"
                                  >
                                    View
                                  </Button>
                                )}
                                
                                {!notification.isRead && (
                                  <Button
                                    onClick={() => markAsRead(notification.id)}
                                    variant="ghost"
                                    size="sm"
                                    className="text-xs text-blue-400 hover:text-blue-300 h-6 w-6 p-0"
                                  >
                                    <Check className="h-3 w-3" />
                                  </Button>
                                )}
                                
                                <Button
                                  onClick={() => deleteNotification(notification.id)}
                                  variant="ghost"
                                  size="sm"
                                  className="text-xs text-red-400 hover:text-red-300 h-6 w-6 p-0"
                                >
                                  <X className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                            
                            {/* Additional data display */}
                            {notification.data && (
                              <div className="mt-2 pt-2 border-t border-gray-700">
                                {notification.type === 'achievement' && notification.data.xp && (
                                  <div className="flex items-center space-x-2">
                                    <Zap className="h-3 w-3 text-yellow-400" />
                                    <span className="text-xs text-yellow-400 font-medium">
                                      +{notification.data.xp} XP
                                    </span>
                                  </div>
                                )}
                                
                                {notification.type === 'quest' && notification.data.xp && (
                                  <div className="flex items-center space-x-2">
                                    <Target className="h-3 w-3 text-blue-400" />
                                    <span className="text-xs text-blue-400 font-medium">
                                      +{notification.data.xp} XP earned
                                    </span>
                                  </div>
                                )}
                                
                                {notification.type === 'social' && notification.data.invitedBy && (
                                  <div className="flex items-center space-x-2">
                                    <Users className="h-3 w-3 text-pink-400" />
                                    <span className="text-xs text-pink-400 font-medium">
                                      Invited by {notification.data.invitedBy}
                                    </span>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}