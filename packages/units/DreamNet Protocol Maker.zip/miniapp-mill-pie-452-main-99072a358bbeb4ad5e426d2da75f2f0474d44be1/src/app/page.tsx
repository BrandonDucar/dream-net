'use client'
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Clock, Users, Star, Trophy, Search, Filter, Plus, Heart, MessageCircle, Zap, Crown, Award, Target, Sparkles } from 'lucide-react';
import { useQuestPlatform } from '@/hooks/useQuestPlatform';
import { UserOnboarding } from '@/components/user-onboarding';
import { QuestCard } from '@/components/quest-card';
import { CategoryFilter } from '@/components/category-filter';
import { QuestCreator } from '@/components/quest-creator';
import { UserProfile } from '@/components/user-profile';
import { Leaderboard } from '@/components/leaderboard';
import { MyQuests } from '@/components/my-quests';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function QuestPlatformApp(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const {
    isConnected,
    identity,
    userProfile,
    publishedQuests,
    userQuestInstances,
    questCategories,
    QuestDifficulty,
  } = useQuestPlatform();

  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  const [showOnboarding, setShowOnboarding] = useState<boolean>(false);
  const [showQuestCreator, setShowQuestCreator] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>('discover');

  // Check if user needs onboarding
  useEffect(() => {
    if (isConnected && identity && !userProfile) {
      setShowOnboarding(true);
    } else {
      setShowOnboarding(false);
    }
  }, [isConnected, identity, userProfile]);

  // Filter quests based on search and filters
  const filteredQuests = publishedQuests.filter(quest => {
    const matchesSearch = quest.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         quest.summary.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || quest.categoryId === selectedCategory;
    const matchesDifficulty = selectedDifficulty === 'all' || quest.difficulty === selectedDifficulty;
    return matchesSearch && matchesCategory && matchesDifficulty;
  });

  // Calculate user stats
  const userStats = {
    totalXp: userProfile?.xp || 0,
    level: userProfile?.level || 1,
    activeQuests: userQuestInstances.filter(qi => qi.state === 'Active').length,
    completedQuests: userQuestInstances.filter(qi => qi.state === 'Completed').length,
  };

  if (!isConnected) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-8 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400 mx-auto mb-4"></div>
            <h2 className="text-xl font-bold text-white mb-2">Connecting to DreamNet</h2>
            <p className="text-gray-400">Establishing secure connection...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (showOnboarding) {
    return <UserOnboarding onComplete={() => setShowOnboarding(false)} />;
  }

  if (showQuestCreator) {
    return <QuestCreator onClose={() => setShowQuestCreator(false)} />;
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Sparkles className="h-8 w-8 text-purple-400" />
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                  DreamNet Quests
                </h1>
              </div>
              <Badge variant="outline" className="text-green-400 border-green-400">
                {filteredQuests.length} Live Quests
              </Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button
                onClick={() => setShowQuestCreator(true)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Quest
              </Button>
              
              {userProfile && (
                <UserProfile userProfile={userProfile} userStats={userStats} />
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-gray-900">
            <TabsTrigger value="discover" className="flex items-center space-x-2">
              <Search className="h-4 w-4" />
              <span>Discover</span>
            </TabsTrigger>
            <TabsTrigger value="my-quests" className="flex items-center space-x-2">
              <Target className="h-4 w-4" />
              <span>My Quests</span>
            </TabsTrigger>
            <TabsTrigger value="leaderboard" className="flex items-center space-x-2">
              <Trophy className="h-4 w-4" />
              <span>Leaderboard</span>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center space-x-2">
              <Award className="h-4 w-4" />
              <span>Analytics</span>
            </TabsTrigger>
          </TabsList>

          {/* Discover Quests Tab */}
          <TabsContent value="discover" className="space-y-6">
            {/* Search and Filters */}
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search quests..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-gray-900 border-gray-700 text-white"
                />
              </div>
              
              <CategoryFilter
                categories={questCategories}
                selectedCategory={selectedCategory}
                onCategoryChange={setSelectedCategory}
              />

              <select
                value={selectedDifficulty}
                onChange={(e) => setSelectedDifficulty(e.target.value)}
                className="px-4 py-2 bg-gray-900 border border-gray-700 rounded-md text-white min-w-[140px]"
              >
                <option value="all">All Difficulties</option>
                <option value={QuestDifficulty.Easy}>Easy</option>
                <option value={QuestDifficulty.Medium}>Medium</option>
                <option value={QuestDifficulty.Hard}>Hard</option>
                <option value={QuestDifficulty.Legendary}>Legendary</option>
              </select>
            </div>

            {/* Stats Overview */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="bg-gray-900 border-gray-700">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <Zap className="h-8 w-8 text-yellow-400" />
                    <div>
                      <p className="text-sm text-gray-400">Total XP</p>
                      <p className="text-lg font-bold text-white">{userStats.totalXp.toLocaleString()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-900 border-gray-700">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <Crown className="h-8 w-8 text-purple-400" />
                    <div>
                      <p className="text-sm text-gray-400">Level</p>
                      <p className="text-lg font-bold text-white">{userStats.level}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-900 border-gray-700">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <Target className="h-8 w-8 text-blue-400" />
                    <div>
                      <p className="text-sm text-gray-400">Active</p>
                      <p className="text-lg font-bold text-white">{userStats.activeQuests}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-900 border-gray-700">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <Award className="h-8 w-8 text-green-400" />
                    <div>
                      <p className="text-sm text-gray-400">Completed</p>
                      <p className="text-lg font-bold text-white">{userStats.completedQuests}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quest Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredQuests.map((quest) => (
                <QuestCard key={quest.questId} quest={quest} />
              ))}
            </div>

            {filteredQuests.length === 0 && (
              <Card className="bg-gray-900 border-gray-700">
                <CardContent className="p-8 text-center">
                  <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">No quests found</h3>
                  <p className="text-gray-400">Try adjusting your search filters or create a new quest!</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* My Quests Tab */}
          <TabsContent value="my-quests">
            <MyQuests userQuestInstances={userQuestInstances} />
          </TabsContent>

          {/* Leaderboard Tab */}
          <TabsContent value="leaderboard">
            <Leaderboard />
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics">
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Platform Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-purple-400">{publishedQuests.length}</p>
                    <p className="text-sm text-gray-400">Total Quests</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-blue-400">{userQuestInstances.length}</p>
                    <p className="text-sm text-gray-400">Quest Instances</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-400">{questCategories.length}</p>
                    <p className="text-sm text-gray-400">Categories</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-yellow-400">{userStats.totalXp}</p>
                    <p className="text-sm text-gray-400">Total XP</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}