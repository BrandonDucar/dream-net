'use client';

import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { QuestCategoryRow } from '@/spacetime_module_bindings';

interface CategoryFilterProps {
  categories: QuestCategoryRow[];
  selectedCategory: string;
  onCategoryChange: (categoryId: string) => void;
}

export function CategoryFilter({ categories, selectedCategory, onCategoryChange }: CategoryFilterProps): JSX.Element {
  const allCategoriesCount = categories.reduce((sum, category) => sum + 1, 0); // Mock count
  
  return (
    <div className="flex items-center space-x-4">
      {/* Mobile/Tablet Select Dropdown */}
      <div className="block md:hidden min-w-[160px]">
        <Select value={selectedCategory} onValueChange={onCategoryChange}>
          <SelectTrigger className="bg-gray-900 border-gray-700 text-white">
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent className="bg-gray-900 border-gray-700">
            <SelectItem value="all" className="text-white">
              All Categories ({allCategoriesCount})
            </SelectItem>
            {categories.map((category) => (
              <SelectItem key={category.categoryId} value={category.categoryId} className="text-white">
                {category.iconUrl} {category.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Desktop Button Filter */}
      <div className="hidden md:flex items-center space-x-2 overflow-x-auto">
        <Button
          variant={selectedCategory === 'all' ? 'default' : 'outline'}
          onClick={() => onCategoryChange('all')}
          className={`flex-shrink-0 ${
            selectedCategory === 'all'
              ? 'bg-purple-600 border-purple-600 text-white'
              : 'border-gray-600 text-gray-300 hover:bg-gray-800'
          }`}
        >
          All
          <Badge 
            variant="outline" 
            className="ml-2 text-xs border-current"
          >
            {allCategoriesCount}
          </Badge>
        </Button>
        
        {categories.map((category) => (
          <Button
            key={category.categoryId}
            variant={selectedCategory === category.categoryId ? 'default' : 'outline'}
            onClick={() => onCategoryChange(category.categoryId)}
            className={`flex-shrink-0 ${
              selectedCategory === category.categoryId
                ? 'bg-purple-600 border-purple-600 text-white'
                : 'border-gray-600 text-gray-300 hover:bg-gray-800'
            }`}
          >
            <span className="mr-2">{category.iconUrl}</span>
            {category.name}
            <Badge 
              variant="outline" 
              className="ml-2 text-xs border-current"
            >
              {Math.floor(Math.random() * 20) + 1} {/* Mock quest count */}
            </Badge>
          </Button>
        ))}
      </div>
    </div>
  );
}