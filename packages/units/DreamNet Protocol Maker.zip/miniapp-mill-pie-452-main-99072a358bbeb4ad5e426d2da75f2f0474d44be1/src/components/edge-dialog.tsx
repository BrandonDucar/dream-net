'use client';

import { useState, useEffect } from 'react';
import type { NetNode, NetEdge } from '@/types/netprotocol';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';

interface EdgeDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (fromNodeId: string, toNodeId: string, condition: string, notes: string, id?: string) => void;
  edge: (NetEdge & { id: string }) | null;
  nodes: NetNode[];
}

export function EdgeDialog({ isOpen, onClose, onSave, edge, nodes }: EdgeDialogProps) {
  const [fromNodeId, setFromNodeId] = useState<string>('');
  const [toNodeId, setToNodeId] = useState<string>('');
  const [condition, setCondition] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  useEffect(() => {
    if (edge) {
      setFromNodeId(edge.from);
      setToNodeId(edge.to);
      setCondition(edge.condition);
      setNotes(edge.notes || '');
    } else {
      setFromNodeId('');
      setToNodeId('');
      setCondition('');
      setNotes('');
    }
  }, [edge]);

  const handleSave = () => {
    if (!fromNodeId || !toNodeId || !condition.trim()) return;
    onSave(fromNodeId, toNodeId, condition.trim(), notes.trim(), edge?.id);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-800 text-white max-w-xl">
        <DialogHeader>
          <DialogTitle className="text-white">{edge ? 'Edit Edge' : 'Add Edge'}</DialogTitle>
          <DialogDescription className="text-gray-400">
            Configure the edge connection
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label className="text-gray-300">From Node</Label>
            <Select value={fromNodeId} onValueChange={setFromNodeId}>
              <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                <SelectValue placeholder="Select source node" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700">
                {nodes.map((node) => (
                  <SelectItem key={node.id} value={node.id}>
                    {node.label} ({node.id})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-gray-300">To Node</Label>
            <Select value={toNodeId} onValueChange={setToNodeId}>
              <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                <SelectValue placeholder="Select target node" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700">
                {nodes.map((node) => (
                  <SelectItem key={node.id} value={node.id}>
                    {node.label} ({node.id})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-gray-300">Condition</Label>
            <Input
              value={condition}
              onChange={(e) => setCondition(e.target.value)}
              className="bg-gray-800 border-gray-700 text-white"
              placeholder="e.g., always, requirements_met, ritual_completed"
            />
          </div>
          <div>
            <Label className="text-gray-300">Notes</Label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="bg-gray-800 border-gray-700 text-white"
              placeholder="Optional notes about this edge"
              rows={3}
            />
          </div>
        </div>
        <DialogFooter>
          <Button
            variant="outline"
            onClick={onClose}
            className="border-gray-700 text-gray-300 hover:bg-gray-800"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            Save Edge
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
