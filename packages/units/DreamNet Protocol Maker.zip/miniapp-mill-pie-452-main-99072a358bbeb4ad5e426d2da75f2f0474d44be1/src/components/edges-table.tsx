'use client';

import type { NetNode, NetEdge } from '@/types/netprotocol';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Edit, Trash2 } from 'lucide-react';

interface EdgesTableProps {
  edges: NetEdge[];
  nodes: NetNode[];
  onEdit: (edge: NetEdge, id: string) => void;
  onDelete: (edgeId: string) => void;
  onAdd: () => void;
}

export function EdgesTable({ edges, nodes, onEdit, onDelete, onAdd }: EdgesTableProps) {
  const getNodeLabel = (nodeId: string): string => {
    const node = nodes.find((n) => n.id === nodeId);
    return node ? node.label : nodeId;
  };

  return (
    <div>
      <div className="flex justify-end mb-4">
        <Button onClick={onAdd} size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
          <Plus className="h-4 w-4 mr-2" />
          Add Edge
        </Button>
      </div>

      {edges.length === 0 ? (
        <div className="text-center py-8 text-gray-400">
          <p>No edges yet. Add an edge to connect nodes.</p>
        </div>
      ) : (
        <Table>
          <TableHeader>
            <TableRow className="border-gray-800">
              <TableHead className="text-gray-400">From</TableHead>
              <TableHead className="text-gray-400">To</TableHead>
              <TableHead className="text-gray-400">Condition</TableHead>
              <TableHead className="text-gray-400">Notes</TableHead>
              <TableHead className="text-gray-400 text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {edges.map((edge, index) => (
              <TableRow key={index} className="border-gray-800">
                <TableCell className="text-white">{getNodeLabel(edge.from)}</TableCell>
                <TableCell className="text-white">{getNodeLabel(edge.to)}</TableCell>
                <TableCell className="text-gray-400 text-sm">{edge.condition}</TableCell>
                <TableCell className="text-gray-400 text-sm">{edge.notes || '-'}</TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => onEdit(edge, index.toString())}
                      className="text-blue-400 hover:text-blue-300 hover:bg-gray-800"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => onDelete(index.toString())}
                      className="text-red-400 hover:text-red-300 hover:bg-gray-800"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  );
}
