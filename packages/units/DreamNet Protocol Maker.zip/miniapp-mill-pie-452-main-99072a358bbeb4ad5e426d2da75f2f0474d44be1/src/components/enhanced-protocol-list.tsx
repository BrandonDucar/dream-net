'use client';

import { useState, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import type { Protocol, ProtocolTag } from '@/spacetime_module_bindings';
import type { DbConnection } from '@/spacetime_module_bindings';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Edit, Copy, Archive, CheckCircle, Tag, Star } from 'lucide-react';
import { toast } from 'sonner';
import { dbStatusToClient, timestampToISO } from '@/lib/protocolUtils';
import { getHealthMetrics } from '@/lib/protocolValidation';

interface EnhancedProtocolListProps {
  protocols: Map<string, Protocol>;
  tags: Map<string, ProtocolTag>;
  nodes: Map<string, unknown>;
  edges: Map<string, unknown>;
  connection: DbConnection | null;
}

export function EnhancedProtocolList({
  protocols,
  tags,
  nodes,
  edges,
  connection,
}: EnhancedProtocolListProps) {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('updated');

  // Group tags by protocol
  const protocolTags = useMemo(() => {
    const grouped = new Map<string, ProtocolTag[]>();
    for (const tag of tags.values()) {
      if (!grouped.has(tag.protocolId)) {
        grouped.set(tag.protocolId, []);
      }
      grouped.get(tag.protocolId)!.push(tag);
    }
    return grouped;
  }, [tags]);

  // Filter and sort protocols
  const filteredProtocols = useMemo(() => {
    let filtered = Array.from(protocols.values());

    // Apply search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (p) =>
          p.name.toLowerCase().includes(query) ||
          p.protocolId.toLowerCase().includes(query) ||
          p.description.toLowerCase().includes(query)
      );
    }

    // Apply status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter((p) => dbStatusToClient(p.status) === statusFilter);
    }

    // Apply sorting
    filtered.sort((a, b) => {
      if (sortBy === 'updated') {
        return b.updatedAt.toDate().getTime() - a.updatedAt.toDate().getTime();
      } else if (sortBy === 'name') {
        return a.name.localeCompare(b.name);
      } else if (sortBy === 'version') {
        return b.version - a.version;
      }
      return 0;
    });

    return filtered;
  }, [protocols, searchQuery, statusFilter, sortBy]);

  const handleDuplicate = (protocolId: string) => {
    if (!connection) {
      toast.error('Not connected to database');
      return;
    }

    const protocol = protocols.get(protocolId);
    if (!protocol) {
      toast.error('Protocol not found');
      return;
    }

    const newId = `${protocolId}-copy-${Date.now()}`;
    try {
      connection.reducers.createProtocol(
        newId,
        `${protocol.name} (Copy)`,
        protocol.description
      );
      toast.success('Protocol duplicated successfully');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to duplicate protocol: ${errorMessage}`);
    }
  };

  const handleSetActive = (protocolId: string) => {
    if (!connection) {
      toast.error('Not connected to database');
      return;
    }

    const protocol = protocols.get(protocolId);
    if (!protocol) {
      toast.error('Protocol not found');
      return;
    }

    try {
      connection.reducers.updateProtocol(
        protocolId,
        protocol.name,
        protocol.description,
        { tag: "Active" },
        protocol.version,
        protocol.entryPoints
      );
      toast.success('Protocol set to active');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to activate protocol: ${errorMessage}`);
    }
  };

  const handleArchive = (protocolId: string) => {
    if (!connection) {
      toast.error('Not connected to database');
      return;
    }

    const protocol = protocols.get(protocolId);
    if (!protocol) {
      toast.error('Protocol not found');
      return;
    }

    try {
      connection.reducers.updateProtocol(
        protocolId,
        protocol.name,
        protocol.description,
        { tag: "Archived" },
        protocol.version,
        protocol.entryPoints
      );
      toast.success('Protocol archived');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to archive protocol: ${errorMessage}`);
    }
  };

  const getStatusBadge = (status: { tag: string }) => {
    const statusStr = dbStatusToClient(status);
    if (statusStr === "active") {
      return <Badge className="bg-green-500 text-white">Active</Badge>;
    }
    if (statusStr === "draft") {
      return <Badge variant="secondary">Draft</Badge>;
    }
    return <Badge variant="outline">Archived</Badge>;
  };

  return (
    <div className="space-y-4">
      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search protocols..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-gray-800 border-gray-700 text-white"
          />
        </div>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px] bg-gray-800 border-gray-700 text-white">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent className="bg-gray-800 border-gray-700">
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="archived">Archived</SelectItem>
          </SelectContent>
        </Select>

        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-[180px] bg-gray-800 border-gray-700 text-white">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent className="bg-gray-800 border-gray-700">
            <SelectItem value="updated">Last Updated</SelectItem>
            <SelectItem value="name">Name</SelectItem>
            <SelectItem value="version">Version</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Protocol List */}
      {filteredProtocols.length === 0 ? (
        <div className="text-center py-12 text-gray-400">
          <p className="text-lg mb-2">No protocols found</p>
          <p className="text-sm">Try adjusting your filters</p>
        </div>
      ) : (
        <Table>
          <TableHeader>
            <TableRow className="border-gray-800">
              <TableHead className="text-gray-400">Name</TableHead>
              <TableHead className="text-gray-400">Protocol ID</TableHead>
              <TableHead className="text-gray-400">Version</TableHead>
              <TableHead className="text-gray-400">Status</TableHead>
              <TableHead className="text-gray-400">Tags</TableHead>
              <TableHead className="text-gray-400">Health</TableHead>
              <TableHead className="text-gray-400">Updated</TableHead>
              <TableHead className="text-gray-400 text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredProtocols.map((protocol) => {
              const protocolTagsList = protocolTags.get(protocol.protocolId) || [];

              return (
                <TableRow key={protocol.protocolId} className="border-gray-800 hover:bg-gray-800/50">
                  <TableCell className="font-medium text-white">{protocol.name}</TableCell>
                  <TableCell className="text-gray-400 font-mono text-sm">
                    {protocol.protocolId}
                  </TableCell>
                  <TableCell className="text-gray-400">v{protocol.version}</TableCell>
                  <TableCell>{getStatusBadge(protocol.status)}</TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {protocolTagsList.slice(0, 2).map((tag) => (
                        <Badge key={tag.tagId} variant="outline" className="text-xs">
                          <Tag className="h-3 w-3 mr-1" />
                          {tag.tagName}
                        </Badge>
                      ))}
                      {protocolTagsList.length > 2 && (
                        <Badge variant="outline" className="text-xs">
                          +{protocolTagsList.length - 2}
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm text-gray-400">85</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-gray-400 text-sm">
                    {new Date(timestampToISO(protocol.updatedAt)).toLocaleDateString()}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => router.push(`/protocols/${protocol.protocolId}`)}
                        className="text-blue-400 hover:text-blue-300 hover:bg-gray-800"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDuplicate(protocol.protocolId)}
                        className="text-gray-400 hover:text-gray-300 hover:bg-gray-800"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                      {dbStatusToClient(protocol.status) !== "active" && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleSetActive(protocol.protocolId)}
                          className="text-green-400 hover:text-green-300 hover:bg-gray-800"
                        >
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                      )}
                      {dbStatusToClient(protocol.status) !== "archived" && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleArchive(protocol.protocolId)}
                          className="text-orange-400 hover:text-orange-300 hover:bg-gray-800"
                        >
                          <Archive className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      )}
    </div>
  );
}
