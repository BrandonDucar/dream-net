'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Trophy, 
  Crown, 
  Star, 
  Medal, 
  Zap, 
  Target, 
  Users, 
  TrendingUp,
  Calendar,
} from 'lucide-react';

interface LeaderboardEntry {
  rank: number;
  handle: string;
  avatarUrl: string;
  xp: number;
  level: number;
  completedQuests: number;
  weeklyXp?: number;
  isCurrentUser?: boolean;
}

export function Leaderboard(): JSX.Element {
  const [timeframe, setTimeframe] = useState<string>('all-time');
  const [category, setCategory] = useState<string>('overall');

  // Mock leaderboard data
  const leaderboardData: LeaderboardEntry[] = [
    {
      rank: 1,
      handle: '@questmaster_pro',
      avatarUrl: '',
      xp: 25680,
      level: 26,
      completedQuests: 47,
      weeklyXp: 2340,
    },
    {
      rank: 2,
      handle: '@crypto_ninja',
      avatarUrl: '',
      xp: 22450,
      level: 23,
      completedQuests: 41,
      weeklyXp: 1890,
    },
    {
      rank: 3,
      handle: '@defi_explorer',
      avatarUrl: '',
      xp: 19230,
      level: 20,
      completedQuests: 35,
      weeklyXp: 1560,
    },
    {
      rank: 4,
      handle: '@web3_builder',
      avatarUrl: '',
      xp: 17890,
      level: 18,
      completedQuests: 32,
      weeklyXp: 1440,
    },
    {
      rank: 5,
      handle: '@nft_collector',
      avatarUrl: '',
      xp: 16520,
      level: 17,
      completedQuests: 29,
      weeklyXp: 1320,
    },
    {
      rank: 15,
      handle: '@you',
      avatarUrl: '',
      xp: 8750,
      level: 9,
      completedQuests: 12,
      weeklyXp: 650,
      isCurrentUser: true,
    },
  ];

  const getRankIcon = (rank: number): JSX.Element => {
    if (rank === 1) return <Crown className="h-6 w-6 text-yellow-400" />;
    if (rank === 2) return <Medal className="h-6 w-6 text-gray-300" />;
    if (rank === 3) return <Medal className="h-6 w-6 text-amber-600" />;
    return <span className="text-lg font-bold text-gray-400">#{rank}</span>;
  };

  const getRankBadge = (rank: number): JSX.Element => {
    if (rank <= 3) {
      const colors = {
        1: 'bg-gradient-to-r from-yellow-400 to-yellow-600',
        2: 'bg-gradient-to-r from-gray-300 to-gray-500',
        3: 'bg-gradient-to-r from-amber-400 to-amber-600',
      };
      return (
        <Badge className={`${colors[rank as keyof typeof colors]} text-white border-none`}>
          Top {rank}
        </Badge>
      );
    }
    if (rank <= 10) {
      return <Badge className="bg-purple-600 text-white">Top 10</Badge>;
    }
    if (rank <= 100) {
      return <Badge className="bg-blue-600 text-white">Top 100</Badge>;
    }
    return <Badge variant="outline" className="border-gray-600 text-gray-400">#{rank}</Badge>;
  };

  const LeaderboardRow = ({ entry }: { entry: LeaderboardEntry }): JSX.Element => {
    return (
      <div className={`flex items-center space-x-4 p-4 rounded-lg transition-all duration-200 ${
        entry.isCurrentUser 
          ? 'bg-purple-900/30 border border-purple-600/50' 
          : 'bg-gray-800 hover:bg-gray-700'
      }`}>
        <div className="flex-shrink-0 w-12 flex justify-center">
          {getRankIcon(entry.rank)}
        </div>
        
        <Avatar className="h-10 w-10">
          <AvatarImage src={entry.avatarUrl} />
          <AvatarFallback className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
            {entry.handle.slice(1, 3).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2">
            <h4 className="font-semibold text-white truncate">{entry.handle}</h4>
            {entry.isCurrentUser && <Badge className="bg-blue-600 text-white text-xs">You</Badge>}
            {getRankBadge(entry.rank)}
          </div>
          <p className="text-sm text-gray-400">
            Level {entry.level} • {entry.completedQuests} quests completed
          </p>
        </div>
        
        <div className="text-right">
          <p className="text-lg font-bold text-white">{entry.xp.toLocaleString()}</p>
          <p className="text-sm text-gray-400">XP</p>
          {timeframe === 'weekly' && entry.weeklyXp && (
            <p className="text-xs text-green-400">+{entry.weeklyXp} this week</p>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <Select value={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="bg-gray-900 border-gray-700 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-gray-900 border-gray-700">
              <SelectItem value="all-time" className="text-white">All Time</SelectItem>
              <SelectItem value="monthly" className="text-white">This Month</SelectItem>
              <SelectItem value="weekly" className="text-white">This Week</SelectItem>
              <SelectItem value="daily" className="text-white">Today</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex-1">
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="bg-gray-900 border-gray-700 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-gray-900 border-gray-700">
              <SelectItem value="overall" className="text-white">Overall</SelectItem>
              <SelectItem value="social" className="text-white">Social Quests</SelectItem>
              <SelectItem value="defi" className="text-white">DeFi Quests</SelectItem>
              <SelectItem value="nft" className="text-white">NFT Quests</SelectItem>
              <SelectItem value="gaming" className="text-white">Gaming Quests</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue="leaderboard" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-gray-900">
          <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
          <TabsTrigger value="achievements">Top Achievers</TabsTrigger>
          <TabsTrigger value="stats">Statistics</TabsTrigger>
        </TabsList>

        {/* Main Leaderboard */}
        <TabsContent value="leaderboard" className="space-y-4">
          {/* Top 3 Podium */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            {leaderboardData.slice(0, 3).map((entry, index) => (
              <Card key={entry.rank} className={`relative overflow-hidden ${
                index === 0 ? 'bg-gradient-to-br from-yellow-900/30 to-yellow-700/20 border-yellow-600/30' :
                index === 1 ? 'bg-gradient-to-br from-gray-800/30 to-gray-600/20 border-gray-500/30' :
                'bg-gradient-to-br from-amber-900/30 to-amber-700/20 border-amber-600/30'
              }`}>
                <CardContent className="p-4 text-center">
                  <div className="mb-3">
                    {getRankIcon(entry.rank)}
                  </div>
                  <Avatar className="h-12 w-12 mx-auto mb-3">
                    <AvatarImage src={entry.avatarUrl} />
                    <AvatarFallback className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
                      {entry.handle.slice(1, 3).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <h4 className="font-bold text-white text-sm truncate">{entry.handle}</h4>
                  <p className="text-xs text-gray-400 mb-2">Level {entry.level}</p>
                  <p className="text-lg font-bold text-white">{entry.xp.toLocaleString()}</p>
                  <p className="text-xs text-gray-400">XP</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Rest of Leaderboard */}
          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Trophy className="h-5 w-5 text-yellow-400" />
                <span>Top Players</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="space-y-2">
                {leaderboardData.slice(3).map((entry) => (
                  <LeaderboardRow key={entry.rank} entry={entry} />
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Top Achievers */}
        <TabsContent value="achievements" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Zap className="h-5 w-5 text-yellow-400" />
                  <span>Most XP This Week</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {leaderboardData.slice(0, 3).map((entry) => (
                    <div key={entry.rank} className="flex items-center space-x-3">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="bg-purple-600 text-white text-xs">
                          {entry.handle.slice(1, 3).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="text-white text-sm font-medium">{entry.handle}</p>
                        <p className="text-xs text-gray-400">+{entry.weeklyXp} XP</p>
                      </div>
                      <Badge className="bg-yellow-600">{entry.rank}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Target className="h-5 w-5 text-green-400" />
                  <span>Quest Completionists</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {leaderboardData
                    .sort((a, b) => b.completedQuests - a.completedQuests)
                    .slice(0, 3)
                    .map((entry, index) => (
                      <div key={entry.rank} className="flex items-center space-x-3">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="bg-green-600 text-white text-xs">
                            {entry.handle.slice(1, 3).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <p className="text-white text-sm font-medium">{entry.handle}</p>
                          <p className="text-xs text-gray-400">{entry.completedQuests} quests</p>
                        </div>
                        <Badge className="bg-green-600">{index + 1}</Badge>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Statistics */}
        <TabsContent value="stats" className="space-y-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-gray-900 border-gray-700">
              <CardContent className="p-4 text-center">
                <Users className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                <p className="text-lg font-bold text-white">2,847</p>
                <p className="text-sm text-gray-400">Total Players</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-900 border-gray-700">
              <CardContent className="p-4 text-center">
                <Trophy className="h-8 w-8 text-yellow-400 mx-auto mb-2" />
                <p className="text-lg font-bold text-white">15,623</p>
                <p className="text-sm text-gray-400">Quests Completed</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-900 border-gray-700">
              <CardContent className="p-4 text-center">
                <Zap className="h-8 w-8 text-purple-400 mx-auto mb-2" />
                <p className="text-lg font-bold text-white">892K</p>
                <p className="text-sm text-gray-400">Total XP Earned</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-900 border-gray-700">
              <CardContent className="p-4 text-center">
                <TrendingUp className="h-8 w-8 text-green-400 mx-auto mb-2" />
                <p className="text-lg font-bold text-white">+23%</p>
                <p className="text-sm text-gray-400">Growth This Week</p>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Platform Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Daily Active Players</span>
                  <span className="text-white font-bold">847</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Quests Created Today</span>
                  <span className="text-white font-bold">12</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Average Session Time</span>
                  <span className="text-white font-bold">24m</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Most Popular Category</span>
                  <span className="text-white font-bold">DeFi</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}