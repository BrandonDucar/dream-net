'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { 
  Search,
  Filter,
  Calendar,
  Clock,
  Target,
  Trophy,
  Zap,
  Play,
  Pause,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Star,
  RotateCcw,
  Eye,
  Share,
  MoreHorizontal,
} from 'lucide-react';
import type { QuestInstanceRow } from '@/spacetime_module_bindings';
import { QuestDetails } from './quest-details';
import { TaskCompletion } from './task-completion';
import { useQuestPlatform } from '@/hooks/useQuestPlatform';

interface MyQuestsProps {
  userQuestInstances: QuestInstanceRow[];
}

interface EnhancedQuestInstance extends QuestInstanceRow {
  questData?: {
    title: string;
    summary: string;
    difficulty: string;
    categoryId: string;
    estimatedMinutes: number;
    rewardPoolId: string;
  };
}

export function MyQuests({ userQuestInstances }: MyQuestsProps): JSX.Element {
  const { getQuestById, getCategoryById } = useQuestPlatform();
  
  const [activeTab, setActiveTab] = useState<string>('active');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedQuest, setSelectedQuest] = useState<any>(null);
  const [showTaskCompletion, setShowTaskCompletion] = useState<boolean>(false);
  const [showQuestDetails, setShowQuestDetails] = useState<boolean>(false);

  // Mock enhanced quest instances with quest data
  const enhancedQuestInstances: EnhancedQuestInstance[] = [
    {
      instanceId: 1,
      questId: 'quest_social_onboard_001',
      participantIdentity: 'user_123',
      guildId: null,
      state: 'Active',
      progressPct: 60,
      startedAt: new Date('2024-01-15').getTime(),
      lastActiveAt: new Date('2024-01-16').getTime(),
      questData: {
        title: 'Welcome to DreamNet',
        summary: 'Get started by connecting with our community across social platforms.',
        difficulty: 'Easy',
        categoryId: 'social',
        estimatedMinutes: 15,
        rewardPoolId: 'pool_social_001',
      },
    },
    {
      instanceId: 2,
      questId: 'quest_defi_explorer_002',
      participantIdentity: 'user_123',
      guildId: null,
      state: 'Active',
      progressPct: 25,
      startedAt: new Date('2024-01-14').getTime(),
      lastActiveAt: new Date('2024-01-14').getTime(),
      questData: {
        title: 'DeFi Explorer Challenge',
        summary: 'Dive into decentralized finance! Learn by doing your first swap and LP.',
        difficulty: 'Medium',
        categoryId: 'defi',
        estimatedMinutes: 45,
        rewardPoolId: 'pool_defi_002',
      },
    },
    {
      instanceId: 3,
      questId: 'quest_nft_creator_003',
      participantIdentity: 'user_123',
      guildId: null,
      state: 'Completed',
      progressPct: 100,
      startedAt: new Date('2024-01-10').getTime(),
      lastActiveAt: new Date('2024-01-12').getTime(),
      questData: {
        title: 'Mint Your First NFT',
        summary: 'Create original artwork and mint it as an NFT on Base.',
        difficulty: 'Hard',
        categoryId: 'nft',
        estimatedMinutes: 120,
        rewardPoolId: 'pool_nft_003',
      },
    },
    {
      instanceId: 4,
      questId: 'quest_gaming_champion_004',
      participantIdentity: 'user_123',
      guildId: null,
      state: 'Failed',
      progressPct: 45,
      startedAt: new Date('2024-01-08').getTime(),
      lastActiveAt: new Date('2024-01-09').getTime(),
      questData: {
        title: 'Gaming Champion',
        summary: 'Master our mini-games and compete in tournaments.',
        difficulty: 'Medium',
        categoryId: 'gaming',
        estimatedMinutes: 60,
        rewardPoolId: 'pool_gaming_004',
      },
    },
    {
      instanceId: 5,
      questId: 'quest_education_master_005',
      participantIdentity: 'user_123',
      guildId: null,
      state: 'Paused',
      progressPct: 15,
      startedAt: new Date('2024-01-12').getTime(),
      lastActiveAt: new Date('2024-01-13').getTime(),
      questData: {
        title: 'Blockchain Education Master',
        summary: 'Complete our comprehensive Web3 education series.',
        difficulty: 'Legendary',
        categoryId: 'education',
        estimatedMinutes: 180,
        rewardPoolId: 'pool_education_005',
      },
    },
  ];

  // Filter quests based on tab and search
  const filteredQuests = enhancedQuestInstances.filter(questInstance => {
    const matchesSearch = questInstance.questData?.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         questInstance.questData?.summary.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesTab = 
      activeTab === 'active' && ['Active', 'Paused'].includes(questInstance.state) ||
      activeTab === 'completed' && questInstance.state === 'Completed' ||
      activeTab === 'failed' && questInstance.state === 'Failed' ||
      activeTab === 'all';
    
    return matchesSearch && matchesTab;
  });

  const getStateColor = (state: string): string => {
    switch (state) {
      case 'Active':
        return 'text-blue-400 bg-blue-400/20 border-blue-400';
      case 'Completed':
        return 'text-green-400 bg-green-400/20 border-green-400';
      case 'Failed':
        return 'text-red-400 bg-red-400/20 border-red-400';
      case 'Paused':
        return 'text-yellow-400 bg-yellow-400/20 border-yellow-400';
      default:
        return 'text-gray-400 bg-gray-400/20 border-gray-400';
    }
  };

  const getStateIcon = (state: string): JSX.Element => {
    switch (state) {
      case 'Active':
        return <Play className="h-4 w-4" />;
      case 'Completed':
        return <CheckCircle2 className="h-4 w-4" />;
      case 'Failed':
        return <XCircle className="h-4 w-4" />;
      case 'Paused':
        return <Pause className="h-4 w-4" />;
      default:
        return <AlertCircle className="h-4 w-4" />;
    }
  };

  const getDifficultyColor = (difficulty: string): string => {
    switch (difficulty) {
      case 'Easy':
        return 'text-green-400 bg-green-400/20';
      case 'Medium':
        return 'text-yellow-400 bg-yellow-400/20';
      case 'Hard':
        return 'text-red-400 bg-red-400/20';
      case 'Legendary':
        return 'text-purple-400 bg-purple-400/20';
      default:
        return 'text-gray-400 bg-gray-400/20';
    }
  };

  const handleContinueQuest = (questInstance: EnhancedQuestInstance): void => {
    const quest = getQuestById(questInstance.questId);
    if (quest) {
      setSelectedQuest(quest);
      setShowTaskCompletion(true);
    }
  };

  const handleViewQuest = (questInstance: EnhancedQuestInstance): void => {
    const quest = getQuestById(questInstance.questId);
    if (quest) {
      setSelectedQuest(quest);
      setShowQuestDetails(true);
    }
  };

  const calculateStats = () => {
    const active = enhancedQuestInstances.filter(q => q.state === 'Active').length;
    const completed = enhancedQuestInstances.filter(q => q.state === 'Completed').length;
    const totalXp = completed * 1000; // Mock XP calculation
    const avgProgress = enhancedQuestInstances
      .filter(q => q.state === 'Active')
      .reduce((sum, q) => sum + q.progressPct, 0) / 
      enhancedQuestInstances.filter(q => q.state === 'Active').length || 0;

    return { active, completed, totalXp, avgProgress };
  };

  const stats = calculateStats();

  if (showTaskCompletion && selectedQuest) {
    return (
      <TaskCompletion
        quest={selectedQuest}
        onClose={() => {
          setShowTaskCompletion(false);
          setSelectedQuest(null);
        }}
        onBack={() => {
          setShowTaskCompletion(false);
          setSelectedQuest(null);
        }}
      />
    );
  }

  if (showQuestDetails && selectedQuest) {
    return (
      <QuestDetails
        quest={selectedQuest}
        onClose={() => {
          setShowQuestDetails(false);
          setSelectedQuest(null);
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Target className="h-8 w-8 text-blue-400" />
              <div>
                <p className="text-sm text-gray-400">Active Quests</p>
                <p className="text-lg font-bold text-white">{stats.active}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Trophy className="h-8 w-8 text-green-400" />
              <div>
                <p className="text-sm text-gray-400">Completed</p>
                <p className="text-lg font-bold text-white">{stats.completed}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Zap className="h-8 w-8 text-yellow-400" />
              <div>
                <p className="text-sm text-gray-400">XP Earned</p>
                <p className="text-lg font-bold text-white">{stats.totalXp.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Star className="h-8 w-8 text-purple-400" />
              <div>
                <p className="text-sm text-gray-400">Avg Progress</p>
                <p className="text-lg font-bold text-white">{Math.round(stats.avgProgress)}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search your quests..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-gray-900 border-gray-700 text-white"
          />
        </div>
        
        <Button
          variant="outline"
          className="border-gray-600 text-gray-300 hover:bg-gray-800"
        >
          <Filter className="h-4 w-4 mr-2" />
          Filters
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-gray-900">
          <TabsTrigger value="active" className="flex items-center space-x-2">
            <Play className="h-4 w-4" />
            <span>Active ({stats.active})</span>
          </TabsTrigger>
          <TabsTrigger value="completed" className="flex items-center space-x-2">
            <CheckCircle2 className="h-4 w-4" />
            <span>Completed ({stats.completed})</span>
          </TabsTrigger>
          <TabsTrigger value="failed" className="flex items-center space-x-2">
            <XCircle className="h-4 w-4" />
            <span>Failed</span>
          </TabsTrigger>
          <TabsTrigger value="all" className="flex items-center space-x-2">
            <Target className="h-4 w-4" />
            <span>All</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="space-y-4 mt-6">
          {filteredQuests.length === 0 ? (
            <Card className="bg-gray-900 border-gray-700">
              <CardContent className="p-8 text-center">
                <Target className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">
                  {activeTab === 'active' && 'No active quests'}
                  {activeTab === 'completed' && 'No completed quests'}
                  {activeTab === 'failed' && 'No failed quests'}
                  {activeTab === 'all' && 'No quests found'}
                </h3>
                <p className="text-gray-400">
                  {activeTab === 'active' && 'Start a new quest from the Discover tab to begin your journey!'}
                  {activeTab === 'completed' && 'Complete some quests to see them here.'}
                  {activeTab === 'failed' && 'You haven\'t failed any quests yet. Keep going!'}
                  {activeTab === 'all' && 'Try adjusting your search or join some quests!'}
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {filteredQuests.map((questInstance) => {
                const category = getCategoryById(questInstance.questData?.categoryId || '');
                
                return (
                  <Card key={questInstance.instanceId} className="bg-gray-900 border-gray-700 hover:border-gray-600 transition-all">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <Badge className={`px-2 py-1 text-xs border ${getStateColor(questInstance.state)}`}>
                              {getStateIcon(questInstance.state)}
                              <span className="ml-1">{questInstance.state}</span>
                            </Badge>
                            
                            {questInstance.questData?.difficulty && (
                              <Badge className={`px-2 py-1 text-xs ${getDifficultyColor(questInstance.questData.difficulty)}`}>
                                {questInstance.questData.difficulty}
                              </Badge>
                            )}
                            
                            {category && (
                              <Badge variant="outline" className="text-gray-400 border-gray-600 text-xs">
                                {category.name}
                              </Badge>
                            )}
                          </div>
                          
                          <h3 className="text-lg font-bold text-white mb-1">
                            {questInstance.questData?.title || 'Unknown Quest'}
                          </h3>
                          
                          <p className="text-gray-400 text-sm line-clamp-2">
                            {questInstance.questData?.summary || 'No description available'}
                          </p>
                        </div>
                        
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0"
                        >
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      {/* Progress Bar */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-400">Progress</span>
                          <span className="text-white">{questInstance.progressPct}%</span>
                        </div>
                        <Progress value={questInstance.progressPct} className="h-2" />
                      </div>

                      {/* Quest Stats */}
                      <div className="flex items-center justify-between text-sm text-gray-400">
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center space-x-1">
                            <Clock className="h-4 w-4" />
                            <span>{questInstance.questData?.estimatedMinutes || 0}m</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Calendar className="h-4 w-4" />
                            <span>{new Date(questInstance.startedAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewQuest(questInstance)}
                            className="h-8 w-8 p-0 hover:bg-gray-800"
                          >
                            <Eye className="h-4 w-4 text-gray-400 hover:text-blue-400" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0 hover:bg-gray-800"
                          >
                            <Share className="h-4 w-4 text-gray-400 hover:text-green-400" />
                          </Button>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex space-x-2">
                        {questInstance.state === 'Active' && (
                          <Button
                            onClick={() => handleContinueQuest(questInstance)}
                            className="flex-1 bg-blue-600 hover:bg-blue-700"
                          >
                            <Play className="h-4 w-4 mr-2" />
                            Continue
                          </Button>
                        )}
                        
                        {questInstance.state === 'Paused' && (
                          <Button
                            onClick={() => handleContinueQuest(questInstance)}
                            className="flex-1 bg-green-600 hover:bg-green-700"
                          >
                            <Play className="h-4 w-4 mr-2" />
                            Resume
                          </Button>
                        )}
                        
                        {questInstance.state === 'Completed' && (
                          <>
                            <Button
                              onClick={() => handleViewQuest(questInstance)}
                              variant="outline"
                              className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-800"
                            >
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </Button>
                            <Button
                              variant="outline"
                              className="border-green-600 text-green-400 hover:bg-green-900"
                            >
                              <Trophy className="h-4 w-4 mr-2" />
                              Claim Rewards
                            </Button>
                          </>
                        )}
                        
                        {questInstance.state === 'Failed' && (
                          <>
                            <Button
                              onClick={() => handleViewQuest(questInstance)}
                              variant="outline"
                              className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-800"
                            >
                              <Eye className="h-4 w-4 mr-2" />
                              Review
                            </Button>
                            <Button
                              variant="outline"
                              className="border-yellow-600 text-yellow-400 hover:bg-yellow-900"
                            >
                              <RotateCcw className="h-4 w-4 mr-2" />
                              Retry
                            </Button>
                          </>
                        )}
                        
                        {questInstance.state === 'Active' && (
                          <Button
                            variant="outline"
                            className="border-gray-600 text-gray-300 hover:bg-gray-800"
                          >
                            <Pause className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}