'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Home,
  Search,
  Target,
  Trophy,
  Users,
  Award,
  Settings,
  Bell,
  MessageCircle,
  Sparkles,
  TrendingUp,
  Calendar,
  Zap,
  Crown,
  Shield,
  Heart,
  Plus,
  Menu,
  X,
} from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useQuestPlatform } from '@/hooks/useQuestPlatform';

interface NavigationProps {
  userProfile?: any;
  userStats?: any;
}

export function Navigation({ userProfile, userStats }: NavigationProps): JSX.Element {
  const pathname = usePathname();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  const [notifications] = useState<number>(3); // Mock notification count

  const navItems = [
    {
      href: '/',
      label: 'Discover',
      icon: <Search className="h-4 w-4" />,
      description: 'Find new quests',
    },
    {
      href: '/my-quests',
      label: 'My Quests',
      icon: <Target className="h-4 w-4" />,
      description: 'Track progress',
      badge: userStats?.activeQuests || 0,
    },
    {
      href: '/leaderboard',
      label: 'Leaderboard',
      icon: <Trophy className="h-4 w-4" />,
      description: 'Top players',
    },
    {
      href: '/guilds',
      label: 'Guilds',
      icon: <Users className="h-4 w-4" />,
      description: 'Join communities',
    },
    {
      href: '/achievements',
      label: 'Achievements',
      icon: <Award className="h-4 w-4" />,
      description: 'Unlock rewards',
      badge: userStats?.completedQuests || 0,
    },
    {
      href: '/analytics',
      label: 'Analytics',
      icon: <TrendingUp className="h-4 w-4" />,
      description: 'Performance insights',
    },
  ];

  const quickActions = [
    {
      href: '/create-quest',
      label: 'Create Quest',
      icon: <Plus className="h-4 w-4" />,
      variant: 'primary' as const,
    },
    {
      href: '/notifications',
      label: 'Notifications',
      icon: <Bell className="h-4 w-4" />,
      badge: notifications,
      variant: 'secondary' as const,
    },
    {
      href: '/messages',
      label: 'Messages',
      icon: <MessageCircle className="h-4 w-4" />,
      variant: 'secondary' as const,
    },
    {
      href: '/settings',
      label: 'Settings',
      icon: <Settings className="h-4 w-4" />,
      variant: 'secondary' as const,
    },
  ];

  const isActiveRoute = (href: string): boolean => {
    if (href === '/') {
      return pathname === '/';
    }
    return pathname?.startsWith(href) || false;
  };

  const getLevelIcon = (level: number): JSX.Element => {
    if (level >= 50) return <Crown className="h-3 w-3 text-purple-400" />;
    if (level >= 25) return <Trophy className="h-3 w-3 text-yellow-400" />;
    if (level >= 10) return <Shield className="h-3 w-3 text-blue-400" />;
    return <Sparkles className="h-3 w-3 text-green-400" />;
  };

  return (
    <>
      {/* Mobile Header */}
      <header className="lg:hidden bg-gray-900 border-b border-gray-700 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="h-8 w-8 p-0"
            >
              {isMobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </Button>
            <div className="flex items-center space-x-2">
              <Sparkles className="h-6 w-6 text-purple-400" />
              <h1 className="text-lg font-bold text-white">DreamNet</h1>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="relative h-8 w-8 p-0">
              <Bell className="h-4 w-4" />
              {notifications > 0 && (
                <Badge className="absolute -top-1 -right-1 h-4 w-4 p-0 bg-red-600 text-xs">
                  {notifications}
                </Badge>
              )}
            </Button>
            
            {userProfile && (
              <Avatar className="h-7 w-7">
                <AvatarImage src={userProfile.avatarUrl} />
                <AvatarFallback className="bg-purple-600 text-white text-xs">
                  {userProfile.handle?.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
            )}
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="absolute top-full left-0 right-0 bg-gray-900 border-b border-gray-700 z-50">
            <div className="px-4 py-4 space-y-2">
              {navItems.map((item) => (
                <Link key={item.href} href={item.href}>
                  <Button
                    variant={isActiveRoute(item.href) ? 'default' : 'ghost'}
                    className={`w-full justify-start ${
                      isActiveRoute(item.href) 
                        ? 'bg-purple-600 text-white' 
                        : 'text-gray-300 hover:bg-gray-800'
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {item.icon}
                    <span className="ml-2">{item.label}</span>
                    {item.badge && (
                      <Badge className="ml-auto bg-blue-600 text-white">
                        {item.badge}
                      </Badge>
                    )}
                  </Button>
                </Link>
              ))}
              
              <div className="border-t border-gray-700 pt-2">
                {quickActions.map((action) => (
                  <Link key={action.href} href={action.href}>
                    <Button
                      variant="ghost"
                      className="w-full justify-start text-gray-300 hover:bg-gray-800"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      {action.icon}
                      <span className="ml-2">{action.label}</span>
                      {action.badge && (
                        <Badge className="ml-auto bg-red-600 text-white">
                          {action.badge}
                        </Badge>
                      )}
                    </Button>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 bg-gray-900 border-r border-gray-700 h-screen fixed left-0 top-0">
        {/* Logo */}
        <div className="p-6 border-b border-gray-700">
          <div className="flex items-center space-x-3">
            <Sparkles className="h-8 w-8 text-purple-400" />
            <div>
              <h1 className="text-xl font-bold text-white">DreamNet</h1>
              <p className="text-xs text-gray-400">Quest Platform</p>
            </div>
          </div>
        </div>

        {/* User Profile */}
        {userProfile && (
          <div className="p-4 border-b border-gray-700">
            <div className="flex items-center space-x-3 mb-3">
              <Avatar className="h-10 w-10">
                <AvatarImage src={userProfile.avatarUrl} />
                <AvatarFallback className="bg-purple-600 text-white">
                  {userProfile.handle?.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <p className="text-white text-sm font-medium">{userProfile.handle}</p>
                  <Badge variant="outline" className="text-xs px-1 py-0">
                    {getLevelIcon(userStats?.level || 1)}
                    <span className="ml-1">{userStats?.level || 1}</span>
                  </Badge>
                </div>
                <p className="text-gray-400 text-xs">{(userStats?.totalXp || 0).toLocaleString()} XP</p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="text-center bg-gray-800 rounded p-2">
                <p className="text-blue-400 font-bold">{userStats?.activeQuests || 0}</p>
                <p className="text-gray-400">Active</p>
              </div>
              <div className="text-center bg-gray-800 rounded p-2">
                <p className="text-green-400 font-bold">{userStats?.completedQuests || 0}</p>
                <p className="text-gray-400">Done</p>
              </div>
            </div>
          </div>
        )}

        {/* Navigation */}
        <nav className="flex-1 p-4">
          <div className="space-y-2">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">
              Navigation
            </p>
            
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <Button
                  variant={isActiveRoute(item.href) ? 'default' : 'ghost'}
                  className={`w-full justify-start group ${
                    isActiveRoute(item.href) 
                      ? 'bg-purple-600 text-white' 
                      : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                  }`}
                >
                  {item.icon}
                  <div className="ml-2 flex-1 text-left">
                    <p className="text-sm font-medium">{item.label}</p>
                    <p className="text-xs opacity-70 group-hover:opacity-100">
                      {item.description}
                    </p>
                  </div>
                  {item.badge && (
                    <Badge className="bg-blue-600 text-white text-xs">
                      {item.badge}
                    </Badge>
                  )}
                </Button>
              </Link>
            ))}
          </div>
        </nav>

        {/* Quick Actions */}
        <div className="p-4 border-t border-gray-700">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">
            Quick Actions
          </p>
          <div className="space-y-2">
            {quickActions.map((action) => (
              <Link key={action.href} href={action.href}>
                <Button
                  variant={action.variant === 'primary' ? 'default' : 'ghost'}
                  size="sm"
                  className={`w-full justify-start relative ${
                    action.variant === 'primary' 
                      ? 'bg-purple-600 hover:bg-purple-700 text-white' 
                      : 'text-gray-300 hover:bg-gray-800'
                  }`}
                >
                  {action.icon}
                  <span className="ml-2">{action.label}</span>
                  {action.badge && (
                    <Badge className="ml-auto bg-red-600 text-white text-xs">
                      {action.badge}
                    </Badge>
                  )}
                </Button>
              </Link>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-700">
          <div className="text-center text-xs text-gray-500">
            <p>DreamNet v2.0</p>
            <div className="flex items-center justify-center space-x-1 mt-1">
              <Heart className="h-3 w-3 text-red-400" />
              <span>Made with love</span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}