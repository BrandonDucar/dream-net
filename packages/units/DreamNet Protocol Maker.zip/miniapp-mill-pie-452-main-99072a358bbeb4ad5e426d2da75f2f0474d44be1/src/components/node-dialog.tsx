'use client';

import { useState, useEffect } from 'react';
import type { NetNode, NodeType } from '@/types/netprotocol';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';

interface NodeDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (nodeId: string, type: NodeType, label: string, data: Record<string, unknown>) => void;
  node: NetNode | null;
}

export function NodeDialog({ isOpen, onClose, onSave, node }: NodeDialogProps) {
  const [nodeId, setNodeId] = useState<string>('');
  const [nodeType, setNodeType] = useState<NodeType>('entry');
  const [label, setLabel] = useState<string>('');
  const [nodeData, setNodeData] = useState<Record<string, unknown>>({});

  useEffect(() => {
    if (node) {
      setNodeId(node.id);
      setNodeType(node.type);
      setLabel(node.label);
      setNodeData(extractNodeData(node));
    } else {
      setNodeId('');
      setNodeType('entry');
      setLabel('');
      setNodeData({});
    }
  }, [node]);

  const extractNodeData = (n: NetNode): Record<string, unknown> => {
    const data: Record<string, unknown> = {};
    
    switch (n.type) {
      case 'entry':
        data.entry_kind = n.entry_kind;
        data.chain = n.chain;
        data.token = n.token;
        data.min_amount = n.min_amount;
        if (n.conditions) data.conditions = n.conditions;
        break;
      case 'funnel':
        data.funnel_type = n.funnel_type;
        data.requirements = n.requirements;
        break;
      case 'ritual_ref':
        data.ritual_id = n.ritual_id;
        data.required = n.required;
        if (n.max_attempts) data.max_attempts = n.max_attempts;
        if (n.weight) data.weight = n.weight;
        break;
      case 'action':
        data.action_type = n.action_type;
        data.params = n.params;
        if (n.instructions) data.instructions = n.instructions;
        break;
      case 'reward':
        data.reward_type = n.reward_type;
        if (n.amount) data.amount = n.amount;
        if (n.token) data.token = n.token;
        if (n.notes) data.notes = n.notes;
        break;
      case 'exit':
        data.exit_kind = n.exit_kind;
        if (n.redirect_protocol_id) data.redirect_protocol_id = n.redirect_protocol_id;
        if (n.notes) data.notes = n.notes;
        break;
    }
    
    if (n.metadata) data.metadata = n.metadata;
    return data;
  };

  const handleSave = () => {
    if (!nodeId.trim() || !label.trim()) return;
    onSave(nodeId.trim(), nodeType, label.trim(), nodeData);
  };

  const updateNodeData = (key: string, value: unknown) => {
    setNodeData((prev) => ({ ...prev, [key]: value }));
  };

  const renderFields = () => {
    switch (nodeType) {
      case 'entry':
        return (
          <>
            <div>
              <Label className="text-gray-300">Entry Kind</Label>
              <Select 
                value={nodeData.entry_kind as string} 
                onValueChange={(value) => updateNodeData('entry_kind', value)}
              >
                <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="mint">Mint</SelectItem>
                  <SelectItem value="airdrop">Airdrop</SelectItem>
                  <SelectItem value="quest">Quest</SelectItem>
                  <SelectItem value="direct_buy">Direct Buy</SelectItem>
                  <SelectItem value="invite">Invite</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-gray-300">Chain</Label>
              <Input
                value={nodeData.chain as string}
                onChange={(e) => updateNodeData('chain', e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
            <div>
              <Label className="text-gray-300">Token</Label>
              <Input
                value={nodeData.token as string}
                onChange={(e) => updateNodeData('token', e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
            <div>
              <Label className="text-gray-300">Min Amount</Label>
              <Input
                value={nodeData.min_amount as string}
                onChange={(e) => updateNodeData('min_amount', e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
            <div>
              <Label className="text-gray-300">Conditions</Label>
              <Input
                value={nodeData.conditions as string || ''}
                onChange={(e) => updateNodeData('conditions', e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
          </>
        );
      case 'funnel':
        return (
          <>
            <div>
              <Label className="text-gray-300">Funnel Type</Label>
              <Select 
                value={nodeData.funnel_type as string} 
                onValueChange={(value) => updateNodeData('funnel_type', value)}
              >
                <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="wolf_pack">Wolf Pack</SelectItem>
                  <SelectItem value="whale_pod">Whale Pod</SelectItem>
                  <SelectItem value="orca_ring">Orca Ring</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-gray-300">Requirements (JSON)</Label>
              <Textarea
                value={JSON.stringify(nodeData.requirements || {}, null, 2)}
                onChange={(e) => {
                  try {
                    updateNodeData('requirements', JSON.parse(e.target.value));
                  } catch {
                    // Invalid JSON
                  }
                }}
                className="bg-gray-800 border-gray-700 text-white font-mono text-sm"
                rows={4}
              />
            </div>
          </>
        );
      case 'ritual_ref':
        return (
          <>
            <div>
              <Label className="text-gray-300">Ritual ID</Label>
              <Input
                value={nodeData.ritual_id as string}
                onChange={(e) => updateNodeData('ritual_id', e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="required"
                checked={nodeData.required as boolean}
                onCheckedChange={(checked) => updateNodeData('required', checked)}
                className="border-gray-700"
              />
              <Label htmlFor="required" className="text-gray-300">Required</Label>
            </div>
            <div>
              <Label className="text-gray-300">Max Attempts</Label>
              <Input
                type="number"
                value={nodeData.max_attempts as number || ''}
                onChange={(e) => updateNodeData('max_attempts', parseInt(e.target.value) || undefined)}
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
            <div>
              <Label className="text-gray-300">Weight</Label>
              <Input
                type="number"
                value={nodeData.weight as number || ''}
                onChange={(e) => updateNodeData('weight', parseInt(e.target.value) || undefined)}
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
          </>
        );
      case 'action':
        return (
          <>
            <div>
              <Label className="text-gray-300">Action Type</Label>
              <Input
                value={nodeData.action_type as string}
                onChange={(e) => updateNodeData('action_type', e.target.value)}
                placeholder="e.g., join_discord, post_on_x"
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
            <div>
              <Label className="text-gray-300">Params (JSON)</Label>
              <Textarea
                value={JSON.stringify(nodeData.params || {}, null, 2)}
                onChange={(e) => {
                  try {
                    updateNodeData('params', JSON.parse(e.target.value));
                  } catch {
                    // Invalid JSON
                  }
                }}
                className="bg-gray-800 border-gray-700 text-white font-mono text-sm"
                rows={4}
              />
            </div>
            <div>
              <Label className="text-gray-300">Instructions</Label>
              <Textarea
                value={nodeData.instructions as string || ''}
                onChange={(e) => updateNodeData('instructions', e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
                rows={3}
              />
            </div>
          </>
        );
      case 'reward':
        return (
          <>
            <div>
              <Label className="text-gray-300">Reward Type</Label>
              <Select 
                value={nodeData.reward_type as string} 
                onValueChange={(value) => updateNodeData('reward_type', value)}
              >
                <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="token">Token</SelectItem>
                  <SelectItem value="role">Role</SelectItem>
                  <SelectItem value="score_boost">Score Boost</SelectItem>
                  <SelectItem value="whitelist">Whitelist</SelectItem>
                  <SelectItem value="unlock_app">Unlock App</SelectItem>
                  <SelectItem value="loot_box">Loot Box</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-gray-300">Amount</Label>
              <Input
                value={nodeData.amount as string || ''}
                onChange={(e) => updateNodeData('amount', e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
            <div>
              <Label className="text-gray-300">Token</Label>
              <Input
                value={nodeData.token as string || ''}
                onChange={(e) => updateNodeData('token', e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
            <div>
              <Label className="text-gray-300">Notes</Label>
              <Textarea
                value={nodeData.notes as string || ''}
                onChange={(e) => updateNodeData('notes', e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
                rows={2}
              />
            </div>
          </>
        );
      case 'exit':
        return (
          <>
            <div>
              <Label className="text-gray-300">Exit Kind</Label>
              <Select 
                value={nodeData.exit_kind as string} 
                onValueChange={(value) => updateNodeData('exit_kind', value)}
              >
                <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="success">Success</SelectItem>
                  <SelectItem value="fail">Fail</SelectItem>
                  <SelectItem value="parked">Parked</SelectItem>
                  <SelectItem value="recycle">Recycle</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-gray-300">Redirect Protocol ID</Label>
              <Input
                value={nodeData.redirect_protocol_id as string || ''}
                onChange={(e) => updateNodeData('redirect_protocol_id', e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
            <div>
              <Label className="text-gray-300">Notes</Label>
              <Textarea
                value={nodeData.notes as string || ''}
                onChange={(e) => updateNodeData('notes', e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
                rows={2}
              />
            </div>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-800 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white">{node ? 'Edit Node' : 'Add Node'}</DialogTitle>
          <DialogDescription className="text-gray-400">
            Configure the node properties
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label className="text-gray-300">Node ID</Label>
            <Input
              value={nodeId}
              onChange={(e) => setNodeId(e.target.value)}
              disabled={!!node}
              className="bg-gray-800 border-gray-700 text-white"
              placeholder="e.g., entry_1"
            />
          </div>
          <div>
            <Label className="text-gray-300">Type</Label>
            <Select value={nodeType} onValueChange={(value) => setNodeType(value as NodeType)}>
              <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700">
                <SelectItem value="entry">Entry</SelectItem>
                <SelectItem value="funnel">Funnel</SelectItem>
                <SelectItem value="ritual_ref">Ritual Reference</SelectItem>
                <SelectItem value="action">Action</SelectItem>
                <SelectItem value="reward">Reward</SelectItem>
                <SelectItem value="exit">Exit</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-gray-300">Label</Label>
            <Input
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              className="bg-gray-800 border-gray-700 text-white"
              placeholder="Human-readable label"
            />
          </div>
          {renderFields()}
        </div>
        <DialogFooter>
          <Button
            variant="outline"
            onClick={onClose}
            className="border-gray-700 text-gray-300 hover:bg-gray-800"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            Save Node
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
