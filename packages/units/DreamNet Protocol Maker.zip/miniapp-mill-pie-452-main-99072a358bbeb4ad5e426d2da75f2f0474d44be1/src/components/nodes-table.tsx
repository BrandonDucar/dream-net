'use client';

import type { NetNode } from '@/types/netprotocol';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit, Trash2 } from 'lucide-react';

interface NodesTableProps {
  nodes: NetNode[];
  onEdit: (node: NetNode) => void;
  onDelete: (nodeId: string) => void;
  onAdd: () => void;
}

export function NodesTable({ nodes, onEdit, onDelete, onAdd }: NodesTableProps) {
  const getNodeTypeBadge = (type: string) => {
    const colors: Record<string, string> = {
      entry: 'bg-green-500',
      funnel: 'bg-blue-500',
      ritual_ref: 'bg-purple-500',
      action: 'bg-orange-500',
      reward: 'bg-yellow-500',
      exit: 'bg-red-500',
    };

    return (
      <Badge className={`${colors[type] || 'bg-gray-500'} text-white`}>
        {type.replace('_', ' ')}
      </Badge>
    );
  };

  const getNodeInfo = (node: NetNode): string => {
    switch (node.type) {
      case 'entry':
        return `${node.entry_kind} - ${node.chain}`;
      case 'funnel':
        return node.funnel_type;
      case 'ritual_ref':
        return `Ritual: ${node.ritual_id}`;
      case 'action':
        return node.action_type;
      case 'reward':
        return node.reward_type;
      case 'exit':
        return node.exit_kind;
      default:
        return '';
    }
  };

  return (
    <div>
      <div className="flex justify-end mb-4">
        <Button onClick={onAdd} size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
          <Plus className="h-4 w-4 mr-2" />
          Add Node
        </Button>
      </div>

      {nodes.length === 0 ? (
        <div className="text-center py-8 text-gray-400">
          <p>No nodes yet. Add a node to get started.</p>
        </div>
      ) : (
        <Table>
          <TableHeader>
            <TableRow className="border-gray-800">
              <TableHead className="text-gray-400">ID</TableHead>
              <TableHead className="text-gray-400">Type</TableHead>
              <TableHead className="text-gray-400">Label</TableHead>
              <TableHead className="text-gray-400">Info</TableHead>
              <TableHead className="text-gray-400 text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {nodes.map((node) => (
              <TableRow key={node.id} className="border-gray-800">
                <TableCell className="font-mono text-sm text-gray-400">{node.id}</TableCell>
                <TableCell>{getNodeTypeBadge(node.type)}</TableCell>
                <TableCell className="text-white">{node.label}</TableCell>
                <TableCell className="text-gray-400 text-sm">{getNodeInfo(node)}</TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => onEdit(node)}
                      className="text-blue-400 hover:text-blue-300 hover:bg-gray-800"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => onDelete(node.id)}
                      className="text-red-400 hover:text-red-300 hover:bg-gray-800"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  );
}
