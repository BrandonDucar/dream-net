'use client';

import { useState } from 'react';
import type { NetProtocol, NetNode, NetEdge, NodeType } from '@/types/netprotocol';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ArrowLeft, Save, Copy, Download } from 'lucide-react';
import { toast } from 'sonner';
import { NodesTable } from '@/components/nodes-table';
import { EdgesTable } from '@/components/edges-table';
import { NodeDialog } from '@/components/node-dialog';
import { EdgeDialog } from '@/components/edge-dialog';

interface ProtocolEditorLayoutProps {
  protocol: NetProtocol;
  onUpdateProtocol: (name: string, description: string, status: string, version: number, entryPoints: string[]) => void;
  onAddNode: (nodeId: string, type: NodeType, label: string, data: Record<string, unknown>) => void;
  onUpdateNode: (nodeId: string, label: string, data: Record<string, unknown>) => void;
  onDeleteNode: (nodeId: string) => void;
  onAddEdge: (fromNodeId: string, toNodeId: string, condition: string, notes: string) => void;
  onUpdateEdge: (edgeId: string, condition: string, notes: string) => void;
  onDeleteEdge: (edgeId: string) => void;
  onBack: () => void;
}

export function ProtocolEditorLayout({
  protocol,
  onUpdateProtocol,
  onAddNode,
  onUpdateNode,
  onDeleteNode,
  onAddEdge,
  onUpdateEdge,
  onDeleteEdge,
  onBack,
}: ProtocolEditorLayoutProps) {
  const [name, setName] = useState<string>(protocol.name);
  const [description, setDescription] = useState<string>(protocol.description);
  const [status, setStatus] = useState<string>(protocol.status);
  const [version, setVersion] = useState<number>(protocol.version);
  const [entryPoints, setEntryPoints] = useState<string>(protocol.entry_points.join(', '));

  const [isNodeDialogOpen, setIsNodeDialogOpen] = useState<boolean>(false);
  const [editingNode, setEditingNode] = useState<NetNode | null>(null);

  const [isEdgeDialogOpen, setIsEdgeDialogOpen] = useState<boolean>(false);
  const [editingEdge, setEditingEdge] = useState<(NetEdge & { id: string }) | null>(null);

  const handleSave = () => {
    const entryPointsArray = entryPoints.split(',').map((s) => s.trim()).filter(Boolean);
    onUpdateProtocol(name, description, status, version, entryPointsArray);
    toast.success('Protocol saved successfully');
  };

  const handleCopyJSON = () => {
    const json = JSON.stringify(protocol, null, 2);
    navigator.clipboard.writeText(json);
    toast.success('JSON copied to clipboard');
  };

  const handleDownloadJSON = () => {
    const json = JSON.stringify(protocol, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${protocol.protocol_id}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('JSON downloaded');
  };

  const handleEditNode = (node: NetNode) => {
    setEditingNode(node);
    setIsNodeDialogOpen(true);
  };

  const handleSaveNode = (nodeId: string, type: NodeType, label: string, data: Record<string, unknown>) => {
    if (editingNode) {
      onUpdateNode(nodeId, label, data);
    } else {
      onAddNode(nodeId, type, label, data);
    }
    setIsNodeDialogOpen(false);
    setEditingNode(null);
  };

  const handleEditEdge = (edge: NetEdge, id: string) => {
    setEditingEdge({ ...edge, id });
    setIsEdgeDialogOpen(true);
  };

  const handleSaveEdge = (fromNodeId: string, toNodeId: string, condition: string, notes: string, id?: string) => {
    if (id) {
      onUpdateEdge(id, condition, notes);
    } else {
      onAddEdge(fromNodeId, toNodeId, condition, notes);
    }
    setIsEdgeDialogOpen(false);
    setEditingEdge(null);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="flex h-screen">
        {/* Left Panel - Metadata */}
        <div className="w-80 border-r border-gray-800 p-6 overflow-y-auto">
          <Button
            variant="ghost"
            onClick={onBack}
            className="mb-4 text-gray-400 hover:text-white hover:bg-gray-800"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>

          <h2 className="text-2xl font-bold mb-6 text-white">Protocol Metadata</h2>

          <div className="space-y-4">
            <div>
              <Label htmlFor="name" className="text-gray-300">Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>

            <div>
              <Label htmlFor="protocol-id" className="text-gray-300">Protocol ID</Label>
              <Input
                id="protocol-id"
                value={protocol.protocol_id}
                disabled
                className="bg-gray-800 border-gray-700 text-gray-500"
              />
            </div>

            <div>
              <Label htmlFor="description" className="text-gray-300">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
                rows={3}
              />
            </div>

            <div>
              <Label htmlFor="status" className="text-gray-300">Status</Label>
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="archived">Archived</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="version" className="text-gray-300">Version</Label>
              <Input
                id="version"
                type="number"
                value={version}
                onChange={(e) => setVersion(parseInt(e.target.value) || 1)}
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>

            <div>
              <Label htmlFor="entry-points" className="text-gray-300">Entry Points</Label>
              <Input
                id="entry-points"
                value={entryPoints}
                onChange={(e) => setEntryPoints(e.target.value)}
                placeholder="node_1, node_2"
                className="bg-gray-800 border-gray-700 text-white"
              />
              <p className="text-xs text-gray-500 mt-1">Comma-separated node IDs</p>
            </div>

            <Button onClick={handleSave} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              <Save className="h-4 w-4 mr-2" />
              Save
            </Button>
          </div>
        </div>

        {/* Center Panel - Editor */}
        <div className="flex-1 p-6 overflow-y-auto">
          <div className="space-y-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Nodes</CardTitle>
              </CardHeader>
              <CardContent>
                <NodesTable
                  nodes={protocol.nodes}
                  onEdit={handleEditNode}
                  onDelete={onDeleteNode}
                  onAdd={() => {
                    setEditingNode(null);
                    setIsNodeDialogOpen(true);
                  }}
                />
              </CardContent>
            </Card>

            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Edges</CardTitle>
              </CardHeader>
              <CardContent>
                <EdgesTable
                  edges={protocol.edges}
                  nodes={protocol.nodes}
                  onEdit={handleEditEdge}
                  onDelete={onDeleteEdge}
                  onAdd={() => {
                    setEditingEdge(null);
                    setIsEdgeDialogOpen(true);
                  }}
                />
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Right Panel - JSON Preview */}
        <div className="w-96 border-l border-gray-800 p-6 overflow-y-auto">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-white">JSON Preview</h2>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={handleCopyJSON}
                className="text-gray-400 hover:text-white hover:bg-gray-800"
              >
                <Copy className="h-4 w-4" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={handleDownloadJSON}
                className="text-gray-400 hover:text-white hover:bg-gray-800"
              >
                <Download className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <ScrollArea className="h-[calc(100vh-140px)]">
            <pre className="bg-gray-950 text-gray-300 p-4 rounded text-xs overflow-x-auto font-mono">
              {JSON.stringify(protocol, null, 2)}
            </pre>
          </ScrollArea>
        </div>
      </div>

      <NodeDialog
        isOpen={isNodeDialogOpen}
        onClose={() => {
          setIsNodeDialogOpen(false);
          setEditingNode(null);
        }}
        onSave={handleSaveNode}
        node={editingNode}
      />

      <EdgeDialog
        isOpen={isEdgeDialogOpen}
        onClose={() => {
          setIsEdgeDialogOpen(false);
          setEditingEdge(null);
        }}
        onSave={handleSaveEdge}
        edge={editingEdge}
        nodes={protocol.nodes}
      />
    </div>
  );
}
