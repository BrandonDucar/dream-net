'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { 
  Clock, 
  Users, 
  Star, 
  Heart, 
  MessageCircle, 
  Zap, 
  Crown, 
  Target,
  Trophy,
  Play,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import type { QuestRow } from '@/spacetime_module_bindings';
import { useQuestPlatform } from '@/hooks/useQuestPlatform';
import { QuestDetails } from './quest-details';

interface QuestCardProps {
  quest: QuestRow;
}

export function QuestCard({ quest }: QuestCardProps): JSX.Element {
  const { 
    joinQuest, 
    likeQuest, 
    isQuestJoined, 
    getUserQuestInstance, 
    getCategoryById,
    QuestDifficulty,
  } = useQuestPlatform();
  
  const [showDetails, setShowDetails] = useState<boolean>(false);
  const [isJoining, setIsJoining] = useState<boolean>(false);
  const [isLiking, setIsLiking] = useState<boolean>(false);

  const category = getCategoryById(quest.categoryId);
  const isJoined = isQuestJoined(quest.questId);
  const questInstance = getUserQuestInstance(quest.questId);
  
  const getDifficultyColor = (difficulty: string): string => {
    switch (difficulty) {
      case QuestDifficulty.Easy:
        return 'text-green-400 bg-green-400/20';
      case QuestDifficulty.Medium:
        return 'text-yellow-400 bg-yellow-400/20';
      case QuestDifficulty.Hard:
        return 'text-red-400 bg-red-400/20';
      case QuestDifficulty.Legendary:
        return 'text-purple-400 bg-purple-400/20';
      default:
        return 'text-gray-400 bg-gray-400/20';
    }
  };

  const getDifficultyIcon = (difficulty: string): JSX.Element => {
    switch (difficulty) {
      case QuestDifficulty.Easy:
        return <Star className="h-3 w-3" />;
      case QuestDifficulty.Medium:
        return <Target className="h-3 w-3" />;
      case QuestDifficulty.Hard:
        return <Zap className="h-3 w-3" />;
      case QuestDifficulty.Legendary:
        return <Crown className="h-3 w-3" />;
      default:
        return <Star className="h-3 w-3" />;
    }
  };

  const handleJoinQuest = async (): Promise<void> => {
    setIsJoining(true);
    try {
      await joinQuest(quest.questId);
    } catch (error) {
      console.error('Failed to join quest:', error);
    } finally {
      setIsJoining(false);
    }
  };

  const handleLikeQuest = async (): Promise<void> => {
    setIsLiking(true);
    try {
      await likeQuest(quest.questId);
    } catch (error) {
      console.error('Failed to like quest:', error);
    } finally {
      setIsLiking(false);
    }
  };

  const isActive = new Date(quest.startsAt) <= new Date() && new Date(quest.endsAt) >= new Date();
  const isExpired = new Date(quest.endsAt) < new Date();
  const isUpcoming = new Date(quest.startsAt) > new Date();

  const getStatusBadge = (): JSX.Element => {
    if (isExpired) {
      return (
        <Badge variant="outline" className="text-red-400 border-red-400">
          <AlertCircle className="h-3 w-3 mr-1" />
          Expired
        </Badge>
      );
    }
    if (isUpcoming) {
      return (
        <Badge variant="outline" className="text-blue-400 border-blue-400">
          <Clock className="h-3 w-3 mr-1" />
          Upcoming
        </Badge>
      );
    }
    if (isActive) {
      return (
        <Badge variant="outline" className="text-green-400 border-green-400">
          <Play className="h-3 w-3 mr-1" />
          Live
        </Badge>
      );
    }
    return (
      <Badge variant="outline" className="text-gray-400 border-gray-400">
        Draft
      </Badge>
    );
  };

  if (showDetails) {
    return <QuestDetails quest={quest} onClose={() => setShowDetails(false)} />;
  }

  return (
    <Card className="bg-gray-900 border-gray-700 hover:border-gray-600 transition-all duration-200 group">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              {getStatusBadge()}
              <Badge 
                className={`px-2 py-1 text-xs ${getDifficultyColor(quest.difficulty)}`}
              >
                {getDifficultyIcon(quest.difficulty)}
                <span className="ml-1">{quest.difficulty}</span>
              </Badge>
              {category && (
                <Badge variant="outline" className="text-gray-400 border-gray-600">
                  {category.name}
                </Badge>
              )}
            </div>
            
            <h3 className="text-lg font-bold text-white mb-1 group-hover:text-purple-400 transition-colors">
              {quest.title}
            </h3>
            
            <p className="text-gray-400 text-sm line-clamp-2">
              {quest.summary}
            </p>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Quest Progress (if joined) */}
        {isJoined && questInstance && (
          <div className="bg-gray-800 p-3 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">Your Progress</span>
              <span className="text-sm text-white">{questInstance.progressPct}%</span>
            </div>
            <Progress 
              value={questInstance.progressPct} 
              className="h-2"
            />
            <div className="flex items-center mt-2 space-x-2">
              {questInstance.state === 'Completed' && (
                <>
                  <CheckCircle2 className="h-4 w-4 text-green-400" />
                  <span className="text-sm text-green-400">Completed!</span>
                </>
              )}
              {questInstance.state === 'Active' && (
                <>
                  <Play className="h-4 w-4 text-blue-400" />
                  <span className="text-sm text-blue-400">In Progress</span>
                </>
              )}
              {questInstance.state === 'Failed' && (
                <>
                  <AlertCircle className="h-4 w-4 text-red-400" />
                  <span className="text-sm text-red-400">Failed</span>
                </>
              )}
            </div>
          </div>
        )}

        {/* Quest Stats */}
        <div className="flex items-center justify-between text-sm text-gray-400">
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-1">
              <Clock className="h-4 w-4" />
              <span>{quest.estimatedMinutes}m</span>
            </div>
            <div className="flex items-center space-x-1">
              <Users className="h-4 w-4" />
              <span>0</span> {/* TODO: Get participant count */}
            </div>
            <div className="flex items-center space-x-1">
              <Trophy className="h-4 w-4 text-yellow-400" />
              <span>Rewards</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLikeQuest}
              disabled={isLiking}
              className="h-8 w-8 p-0 hover:bg-gray-800"
            >
              <Heart className="h-4 w-4 text-gray-400 hover:text-red-400" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0 hover:bg-gray-800"
            >
              <MessageCircle className="h-4 w-4 text-gray-400 hover:text-blue-400" />
            </Button>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-2">
          <Button
            onClick={() => setShowDetails(true)}
            variant="outline"
            className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-800"
          >
            View Details
          </Button>
          
          {!isJoined && isActive && (
            <Button
              onClick={handleJoinQuest}
              disabled={isJoining}
              className="flex-1 bg-purple-600 hover:bg-purple-700"
            >
              {isJoining ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Joining...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Join Quest
                </>
              )}
            </Button>
          )}
          
          {isJoined && (
            <Button
              onClick={() => setShowDetails(true)}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              <Target className="h-4 w-4 mr-2" />
              Continue
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}