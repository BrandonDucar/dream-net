'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  X, 
  Plus, 
  Save, 
  Eye, 
  Sparkles, 
  Target, 
  Gift, 
  Clock,
  Users,
  Zap,
  Crown,
  Star,
  Trophy,
  Calendar,
} from 'lucide-react';
import { useQuestPlatform } from '@/hooks/useQuestPlatform';

interface QuestCreatorProps {
  onClose: () => void;
}

interface TaskData {
  id: string;
  title: string;
  instructions: string;
  taskType: string;
  verificationMethod: string;
  rewardAmount: number;
  orderIndex: number;
}

export function QuestCreator({ onClose }: QuestCreatorProps): JSX.Element {
  const { createQuest, questCategories, QuestDifficulty, TaskType, VerificationMethod, RewardAssetKind } = useQuestPlatform();
  
  const [activeTab, setActiveTab] = useState<string>('basic');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  
  const [questData, setQuestData] = useState({
    questId: `quest_${Date.now()}`,
    title: '',
    summary: '',
    categoryId: '',
    difficulty: QuestDifficulty.Easy,
    estimatedMinutes: 30,
    metadata: JSON.stringify({ description: '', instructions: '', rewards: [] }),
    startsAt: new Date(),
    endsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 1 week from now
  });
  
  const [rewardData, setRewardData] = useState({
    rewardPoolId: `pool_${Date.now()}`,
    assetKind: RewardAssetKind.Xp,
    tokenAddress: '',
    totalAmount: 1000,
    metadata: JSON.stringify({}),
  });
  
  const [tasks, setTasks] = useState<TaskData[]>([]);
  const [newTask, setNewTask] = useState<TaskData>({
    id: '',
    title: '',
    instructions: '',
    taskType: TaskType.TwitterFollow,
    verificationMethod: VerificationMethod.Automatic,
    rewardAmount: 100,
    orderIndex: 0,
  });

  const handleQuestDataChange = (field: string, value: any): void => {
    setQuestData(prev => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleRewardDataChange = (field: string, value: any): void => {
    setRewardData(prev => ({
      ...prev,
      [field]: value,
    }));
  };

  const addTask = (): void => {
    if (newTask.title && newTask.instructions) {
      const task: TaskData = {
        ...newTask,
        id: `task_${Date.now()}_${Math.random()}`,
        orderIndex: tasks.length,
      };
      setTasks(prev => [...prev, task]);
      setNewTask({
        id: '',
        title: '',
        instructions: '',
        taskType: TaskType.TwitterFollow,
        verificationMethod: VerificationMethod.Automatic,
        rewardAmount: 100,
        orderIndex: 0,
      });
    }
  };

  const removeTask = (taskId: string): void => {
    setTasks(prev => prev.filter(t => t.id !== taskId).map((t, i) => ({ ...t, orderIndex: i })));
  };

  const handleSubmit = async (): Promise<void> => {
    setIsSubmitting(true);
    try {
      // First create the quest
      await createQuest({
        ...questData,
        rewardPoolId: rewardData.rewardPoolId,
      });
      
      // TODO: Create reward pool and tasks via additional reducers
      console.log('Quest created successfully', { questData, rewardData, tasks });
      onClose();
    } catch (error) {
      console.error('Failed to create quest:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getDifficultyIcon = (difficulty: string): JSX.Element => {
    switch (difficulty) {
      case QuestDifficulty.Easy:
        return <Star className="h-4 w-4 text-green-400" />;
      case QuestDifficulty.Medium:
        return <Target className="h-4 w-4 text-yellow-400" />;
      case QuestDifficulty.Hard:
        return <Zap className="h-4 w-4 text-red-400" />;
      case QuestDifficulty.Legendary:
        return <Crown className="h-4 w-4 text-purple-400" />;
      default:
        return <Star className="h-4 w-4" />;
    }
  };

  const getTaskTypeIcon = (taskType: string): JSX.Element => {
    switch (taskType) {
      case TaskType.TwitterFollow:
        return <span className="text-blue-400">🐦</span>;
      case TaskType.DiscordJoin:
        return <span className="text-purple-400">💬</span>;
      case TaskType.OnchainTransaction:
        return <span className="text-green-400">⛓️</span>;
      case TaskType.Quiz:
        return <span className="text-yellow-400">🧠</span>;
      case TaskType.CreativeSubmission:
        return <span className="text-pink-400">🎨</span>;
      default:
        return <span className="text-gray-400">📋</span>;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-gray-900 border-gray-700">
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center space-x-3">
            <Sparkles className="h-6 w-6 text-purple-400" />
            <CardTitle className="text-xl text-white">Create New Quest</CardTitle>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-8 w-8 p-0"
          >
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>

        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800">
              <TabsTrigger value="basic" className="flex items-center space-x-2">
                <Target className="h-4 w-4" />
                <span>Basic Info</span>
              </TabsTrigger>
              <TabsTrigger value="tasks" className="flex items-center space-x-2">
                <Users className="h-4 w-4" />
                <span>Tasks</span>
              </TabsTrigger>
              <TabsTrigger value="rewards" className="flex items-center space-x-2">
                <Gift className="h-4 w-4" />
                <span>Rewards</span>
              </TabsTrigger>
              <TabsTrigger value="preview" className="flex items-center space-x-2">
                <Eye className="h-4 w-4" />
                <span>Preview</span>
              </TabsTrigger>
            </TabsList>

            {/* Basic Info Tab */}
            <TabsContent value="basic" className="space-y-6 mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title" className="text-white">Quest Title</Label>
                  <Input
                    id="title"
                    placeholder="Enter an exciting quest title..."
                    value={questData.title}
                    onChange={(e) => handleQuestDataChange('title', e.target.value)}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                
                <div>
                  <Label htmlFor="category" className="text-white">Category</Label>
                  <Select value={questData.categoryId} onValueChange={(value) => handleQuestDataChange('categoryId', value)}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      {questCategories.map((category) => (
                        <SelectItem key={category.categoryId} value={category.categoryId} className="text-white">
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="summary" className="text-white">Quest Summary</Label>
                <Textarea
                  id="summary"
                  placeholder="Describe what participants will do in this quest..."
                  value={questData.summary}
                  onChange={(e) => handleQuestDataChange('summary', e.target.value)}
                  className="bg-gray-800 border-gray-600 text-white"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="difficulty" className="text-white">Difficulty</Label>
                  <Select value={questData.difficulty} onValueChange={(value) => handleQuestDataChange('difficulty', value)}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value={QuestDifficulty.Easy} className="text-white">
                        <div className="flex items-center space-x-2">
                          <Star className="h-4 w-4 text-green-400" />
                          <span>Easy</span>
                        </div>
                      </SelectItem>
                      <SelectItem value={QuestDifficulty.Medium} className="text-white">
                        <div className="flex items-center space-x-2">
                          <Target className="h-4 w-4 text-yellow-400" />
                          <span>Medium</span>
                        </div>
                      </SelectItem>
                      <SelectItem value={QuestDifficulty.Hard} className="text-white">
                        <div className="flex items-center space-x-2">
                          <Zap className="h-4 w-4 text-red-400" />
                          <span>Hard</span>
                        </div>
                      </SelectItem>
                      <SelectItem value={QuestDifficulty.Legendary} className="text-white">
                        <div className="flex items-center space-x-2">
                          <Crown className="h-4 w-4 text-purple-400" />
                          <span>Legendary</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="estimatedMinutes" className="text-white">Estimated Time (minutes)</Label>
                  <Input
                    id="estimatedMinutes"
                    type="number"
                    min="1"
                    value={questData.estimatedMinutes}
                    onChange={(e) => handleQuestDataChange('estimatedMinutes', parseInt(e.target.value))}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                
                <div>
                  <Label htmlFor="questId" className="text-white">Quest ID</Label>
                  <Input
                    id="questId"
                    value={questData.questId}
                    onChange={(e) => handleQuestDataChange('questId', e.target.value)}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="startsAt" className="text-white">Start Date</Label>
                  <Input
                    id="startsAt"
                    type="datetime-local"
                    value={questData.startsAt.toISOString().slice(0, 16)}
                    onChange={(e) => handleQuestDataChange('startsAt', new Date(e.target.value))}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                
                <div>
                  <Label htmlFor="endsAt" className="text-white">End Date</Label>
                  <Input
                    id="endsAt"
                    type="datetime-local"
                    value={questData.endsAt.toISOString().slice(0, 16)}
                    onChange={(e) => handleQuestDataChange('endsAt', new Date(e.target.value))}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
              </div>
            </TabsContent>

            {/* Tasks Tab */}
            <TabsContent value="tasks" className="space-y-6 mt-6">
              {/* Add New Task */}
              <Card className="bg-gray-800 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white flex items-center space-x-2">
                    <Plus className="h-5 w-5" />
                    <span>Add New Task</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-white">Task Title</Label>
                      <Input
                        placeholder="e.g., Follow on Twitter"
                        value={newTask.title}
                        onChange={(e) => setNewTask(prev => ({ ...prev, title: e.target.value }))}
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                    
                    <div>
                      <Label className="text-white">Task Type</Label>
                      <Select value={newTask.taskType} onValueChange={(value) => setNewTask(prev => ({ ...prev, taskType: value }))}>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          {Object.values(TaskType).map((type) => (
                            <SelectItem key={type} value={type} className="text-white">
                              <div className="flex items-center space-x-2">
                                {getTaskTypeIcon(type)}
                                <span>{type}</span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-white">Instructions</Label>
                    <Textarea
                      placeholder="Detailed instructions for completing this task..."
                      value={newTask.instructions}
                      onChange={(e) => setNewTask(prev => ({ ...prev, instructions: e.target.value }))}
                      className="bg-gray-700 border-gray-600 text-white"
                      rows={2}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-white">Verification Method</Label>
                      <Select value={newTask.verificationMethod} onValueChange={(value) => setNewTask(prev => ({ ...prev, verificationMethod: value }))}>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          {Object.values(VerificationMethod).map((method) => (
                            <SelectItem key={method} value={method} className="text-white">
                              {method}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label className="text-white">XP Reward</Label>
                      <Input
                        type="number"
                        min="0"
                        value={newTask.rewardAmount}
                        onChange={(e) => setNewTask(prev => ({ ...prev, rewardAmount: parseInt(e.target.value) }))}
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                  </div>
                  
                  <Button
                    onClick={addTask}
                    disabled={!newTask.title || !newTask.instructions}
                    className="w-full bg-purple-600 hover:bg-purple-700"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Task
                  </Button>
                </CardContent>
              </Card>

              {/* Existing Tasks */}
              <div className="space-y-3">
                <h3 className="text-lg font-semibold text-white">Quest Tasks ({tasks.length})</h3>
                {tasks.length === 0 ? (
                  <Card className="bg-gray-800 border-gray-600">
                    <CardContent className="p-6 text-center">
                      <Target className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                      <p className="text-gray-400">No tasks added yet. Add your first task above!</p>
                    </CardContent>
                  </Card>
                ) : (
                  tasks.map((task, index) => (
                    <Card key={task.id} className="bg-gray-800 border-gray-600">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <Badge className="text-xs">{index + 1}</Badge>
                              {getTaskTypeIcon(task.taskType)}
                              <h4 className="font-semibold text-white">{task.title}</h4>
                            </div>
                            <p className="text-gray-400 text-sm mb-2">{task.instructions}</p>
                            <div className="flex items-center space-x-4 text-xs text-gray-500">
                              <span>{task.verificationMethod}</span>
                              <span>{task.rewardAmount} XP</span>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeTask(task.id)}
                            className="h-8 w-8 p-0 text-red-400 hover:text-red-300"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            {/* Rewards Tab */}
            <TabsContent value="rewards" className="space-y-6 mt-6">
              <Card className="bg-gray-800 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white flex items-center space-x-2">
                    <Trophy className="h-5 w-5 text-yellow-400" />
                    <span>Quest Rewards</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-white">Reward Type</Label>
                      <Select value={rewardData.assetKind} onValueChange={(value) => handleRewardDataChange('assetKind', value)}>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          {Object.values(RewardAssetKind).map((kind) => (
                            <SelectItem key={kind} value={kind} className="text-white">
                              {kind}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label className="text-white">Total Amount</Label>
                      <Input
                        type="number"
                        min="0"
                        value={rewardData.totalAmount}
                        onChange={(e) => handleRewardDataChange('totalAmount', parseInt(e.target.value))}
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                  </div>
                  
                  {rewardData.assetKind === RewardAssetKind.Token && (
                    <div>
                      <Label className="text-white">Token Contract Address</Label>
                      <Input
                        placeholder="0x..."
                        value={rewardData.tokenAddress}
                        onChange={(e) => handleRewardDataChange('tokenAddress', e.target.value)}
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                  )}
                  
                  <div className="bg-gray-700 p-4 rounded-lg">
                    <h4 className="text-white font-semibold mb-2">Reward Summary</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Type:</span>
                        <span className="text-white">{rewardData.assetKind}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Total Pool:</span>
                        <span className="text-white">{rewardData.totalAmount.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Per Task XP:</span>
                        <span className="text-white">{tasks.reduce((sum, task) => sum + task.rewardAmount, 0)} XP</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Preview Tab */}
            <TabsContent value="preview" className="space-y-6 mt-6">
              <Card className="bg-gray-800 border-gray-600">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center space-x-2">
                        {getDifficultyIcon(questData.difficulty)}
                        <Badge className="text-xs">{questData.difficulty}</Badge>
                      </div>
                      <h3 className="text-xl font-bold text-white">{questData.title || 'Untitled Quest'}</h3>
                    </div>
                    <Badge variant="outline" className="text-green-400 border-green-400">
                      <Calendar className="h-3 w-3 mr-1" />
                      Live
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-400">{questData.summary || 'No summary provided.'}</p>
                  
                  <div className="flex items-center justify-between text-sm text-gray-400">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-1">
                        <Clock className="h-4 w-4" />
                        <span>{questData.estimatedMinutes}m</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Users className="h-4 w-4" />
                        <span>0 participants</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Trophy className="h-4 w-4 text-yellow-400" />
                        <span>{rewardData.totalAmount} {rewardData.assetKind}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-semibold text-white">Tasks ({tasks.length})</h4>
                    {tasks.map((task, index) => (
                      <div key={task.id} className="flex items-center space-x-3 bg-gray-700 p-3 rounded-lg">
                        <Badge className="text-xs">{index + 1}</Badge>
                        {getTaskTypeIcon(task.taskType)}
                        <span className="text-white flex-1">{task.title}</span>
                        <span className="text-xs text-green-400">{task.rewardAmount} XP</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Action Buttons */}
          <div className="flex justify-between pt-6 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={onClose}
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              Cancel
            </Button>
            
            <div className="space-x-2">
              <Button
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-800"
              >
                <Save className="h-4 w-4 mr-2" />
                Save Draft
              </Button>
              
              <Button
                onClick={handleSubmit}
                disabled={isSubmitting || !questData.title || !questData.summary || tasks.length === 0}
                className="bg-purple-600 hover:bg-purple-700"
              >
                {isSubmitting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Creating...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Publish Quest
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}