'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { 
  X,
  Play,
  Heart,
  MessageCircle,
  Share,
  Trophy,
  Clock,
  Users,
  Zap,
  Crown,
  Star,
  Target,
  CheckCircle2,
  AlertCircle,
  BookOpen,
  Gift,
  TrendingUp,
  Calendar,
  Link,
  Flag,
  ThumbsUp,
} from 'lucide-react';
import type { QuestRow } from '@/spacetime_module_bindings';
import { useQuestPlatform } from '@/hooks/useQuestPlatform';
import { TaskCompletion } from './task-completion';

interface QuestDetailsProps {
  quest: QuestRow;
  onClose: () => void;
}

interface Comment {
  id: string;
  userId: string;
  username: string;
  avatarUrl: string;
  content: string;
  createdAt: string;
  likes: number;
  isLiked: boolean;
}

interface Participant {
  id: string;
  username: string;
  avatarUrl: string;
  progress: number;
  completedAt?: string;
  rank?: number;
}

export function QuestDetails({ quest, onClose }: QuestDetailsProps): JSX.Element {
  const { 
    joinQuest, 
    likeQuest, 
    commentOnQuest,
    isQuestJoined, 
    getUserQuestInstance, 
    getCategoryById,
    QuestDifficulty,
  } = useQuestPlatform();
  
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [isJoining, setIsJoining] = useState<boolean>(false);
  const [isLiking, setIsLiking] = useState<boolean>(false);
  const [newComment, setNewComment] = useState<string>('');
  const [isCommenting, setIsCommenting] = useState<boolean>(false);
  const [showTaskCompletion, setShowTaskCompletion] = useState<boolean>(false);

  const category = getCategoryById(quest.categoryId);
  const isJoined = isQuestJoined(quest.questId);
  const questInstance = getUserQuestInstance(quest.questId);

  // Mock data for demonstration
  const [comments, setComments] = useState<Comment[]>([
    {
      id: '1',
      userId: 'user1',
      username: '@crypto_explorer',
      avatarUrl: '',
      content: 'This quest is amazing! Really helped me understand DeFi basics.',
      createdAt: '2024-01-15T10:30:00Z',
      likes: 12,
      isLiked: false,
    },
    {
      id: '2',
      userId: 'user2',
      username: '@defi_newbie',
      avatarUrl: '',
      content: 'Thanks for the clear instructions! Finally made my first successful swap.',
      createdAt: '2024-01-14T15:45:00Z',
      likes: 8,
      isLiked: true,
    },
  ]);

  const [participants, setParticipants] = useState<Participant[]>([
    {
      id: '1',
      username: '@questmaster_pro',
      avatarUrl: '',
      progress: 100,
      completedAt: '2024-01-15T12:00:00Z',
      rank: 1,
    },
    {
      id: '2',
      username: '@crypto_ninja',
      avatarUrl: '',
      progress: 85,
      rank: 2,
    },
    {
      id: '3',
      username: '@defi_explorer',
      avatarUrl: '',
      progress: 60,
      rank: 3,
    },
  ]);

  const [questStats, setQuestStats] = useState({
    totalParticipants: 847,
    completionRate: 73,
    averageTime: 38,
    totalRewards: 125000,
    likes: 234,
    isLiked: false,
  });

  const getDifficultyColor = (difficulty: string): string => {
    switch (difficulty) {
      case QuestDifficulty.Easy:
        return 'text-green-400 bg-green-400/20 border-green-400/50';
      case QuestDifficulty.Medium:
        return 'text-yellow-400 bg-yellow-400/20 border-yellow-400/50';
      case QuestDifficulty.Hard:
        return 'text-red-400 bg-red-400/20 border-red-400/50';
      case QuestDifficulty.Legendary:
        return 'text-purple-400 bg-purple-400/20 border-purple-400/50';
      default:
        return 'text-gray-400 bg-gray-400/20 border-gray-400/50';
    }
  };

  const getDifficultyIcon = (difficulty: string): JSX.Element => {
    switch (difficulty) {
      case QuestDifficulty.Easy:
        return <Star className="h-4 w-4" />;
      case QuestDifficulty.Medium:
        return <Target className="h-4 w-4" />;
      case QuestDifficulty.Hard:
        return <Zap className="h-4 w-4" />;
      case QuestDifficulty.Legendary:
        return <Crown className="h-4 w-4" />;
      default:
        return <Star className="h-4 w-4" />;
    }
  };

  const handleJoinQuest = async (): Promise<void> => {
    setIsJoining(true);
    try {
      await joinQuest(quest.questId);
    } catch (error) {
      console.error('Failed to join quest:', error);
    } finally {
      setIsJoining(false);
    }
  };

  const handleLikeQuest = async (): Promise<void> => {
    setIsLiking(true);
    try {
      await likeQuest(quest.questId);
      setQuestStats(prev => ({
        ...prev,
        likes: prev.isLiked ? prev.likes - 1 : prev.likes + 1,
        isLiked: !prev.isLiked,
      }));
    } catch (error) {
      console.error('Failed to like quest:', error);
    } finally {
      setIsLiking(false);
    }
  };

  const handleAddComment = async (): Promise<void> => {
    if (!newComment.trim()) return;
    
    setIsCommenting(true);
    try {
      const commentId = `comment_${Date.now()}`;
      await commentOnQuest(commentId, quest.questId, newComment);
      
      const comment: Comment = {
        id: commentId,
        userId: 'current_user',
        username: '@you',
        avatarUrl: '',
        content: newComment,
        createdAt: new Date().toISOString(),
        likes: 0,
        isLiked: false,
      };
      
      setComments(prev => [comment, ...prev]);
      setNewComment('');
    } catch (error) {
      console.error('Failed to add comment:', error);
    } finally {
      setIsCommenting(false);
    }
  };

  const handleShareQuest = async (): Promise<void> => {
    try {
      await navigator.share({
        title: quest.title,
        text: quest.summary,
        url: window.location.href,
      });
    } catch (error) {
      // Fallback to clipboard
      await navigator.clipboard.writeText(window.location.href);
      console.log('Link copied to clipboard');
    }
  };

  const isActive = new Date(quest.startsAt) <= new Date() && new Date(quest.endsAt) >= new Date();
  const isExpired = new Date(quest.endsAt) < new Date();
  const isUpcoming = new Date(quest.startsAt) > new Date();

  if (showTaskCompletion && isJoined) {
    return <TaskCompletion quest={quest} onClose={() => setShowTaskCompletion(false)} onBack={() => setShowTaskCompletion(false)} />;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-6xl max-h-[90vh] overflow-y-auto bg-gray-900 border-gray-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-3">
                <Badge className={`px-3 py-1 border ${getDifficultyColor(quest.difficulty)}`}>
                  {getDifficultyIcon(quest.difficulty)}
                  <span className="ml-2">{quest.difficulty}</span>
                </Badge>
                
                {category && (
                  <Badge variant="outline" className="text-gray-400 border-gray-600">
                    {category.name}
                  </Badge>
                )}
                
                <Badge variant="outline" className={
                  isExpired ? 'text-red-400 border-red-400' :
                  isUpcoming ? 'text-blue-400 border-blue-400' :
                  isActive ? 'text-green-400 border-green-400' : 'text-gray-400 border-gray-400'
                }>
                  {isExpired ? 'Expired' : isUpcoming ? 'Upcoming' : isActive ? 'Live' : 'Draft'}
                </Badge>
              </div>
              
              <h1 className="text-2xl font-bold text-white mb-2">{quest.title}</h1>
              <p className="text-gray-400 mb-4">{quest.summary}</p>
              
              <div className="flex items-center space-x-6 text-sm text-gray-400">
                <div className="flex items-center space-x-1">
                  <Clock className="h-4 w-4" />
                  <span>{quest.estimatedMinutes}m</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Users className="h-4 w-4" />
                  <span>{questStats.totalParticipants} joined</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Trophy className="h-4 w-4 text-yellow-400" />
                  <span>{questStats.totalRewards.toLocaleString()} XP</span>
                </div>
                <div className="flex items-center space-x-1">
                  <TrendingUp className="h-4 w-4 text-green-400" />
                  <span>{questStats.completionRate}% completion</span>
                </div>
              </div>
            </div>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          
          {/* Quest Progress (if joined) */}
          {isJoined && questInstance && (
            <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-400">Your Progress</span>
                <span className="text-sm text-white">{questInstance.progressPct}%</span>
              </div>
              <Progress value={questInstance.progressPct} className="h-3 mb-3" />
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  {questInstance.state === 'Completed' && (
                    <>
                      <CheckCircle2 className="h-4 w-4 text-green-400" />
                      <span className="text-sm text-green-400">Completed!</span>
                    </>
                  )}
                  {questInstance.state === 'Active' && (
                    <>
                      <Play className="h-4 w-4 text-blue-400" />
                      <span className="text-sm text-blue-400">In Progress</span>
                    </>
                  )}
                  {questInstance.state === 'Failed' && (
                    <>
                      <AlertCircle className="h-4 w-4 text-red-400" />
                      <span className="text-sm text-red-400">Failed</span>
                    </>
                  )}
                </div>
                {questInstance.state === 'Active' && (
                  <Button
                    onClick={() => setShowTaskCompletion(true)}
                    size="sm"
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Continue Tasks
                  </Button>
                )}
              </div>
            </div>
          )}
          
          {/* Action Buttons */}
          <div className="flex items-center space-x-3">
            {!isJoined && isActive && (
              <Button
                onClick={handleJoinQuest}
                disabled={isJoining}
                className="bg-purple-600 hover:bg-purple-700 flex-1 max-w-xs"
              >
                {isJoining ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Joining...
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    Join Quest
                  </>
                )}
              </Button>
            )}
            
            {isJoined && (
              <Button
                onClick={() => setShowTaskCompletion(true)}
                className="bg-blue-600 hover:bg-blue-700 flex-1 max-w-xs"
              >
                <Target className="h-4 w-4 mr-2" />
                Continue Quest
              </Button>
            )}
            
            <Button
              variant="outline"
              onClick={handleLikeQuest}
              disabled={isLiking}
              className={`border-gray-600 ${questStats.isLiked ? 'text-red-400 border-red-400' : 'text-gray-300 hover:text-red-400'}`}
            >
              <Heart className={`h-4 w-4 mr-2 ${questStats.isLiked ? 'fill-red-400' : ''}`} />
              {questStats.likes}
            </Button>
            
            <Button
              variant="outline"
              onClick={handleShareQuest}
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              <Share className="h-4 w-4 mr-2" />
              Share
            </Button>
            
            <Button
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              <Flag className="h-4 w-4 mr-2" />
              Report
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-5 bg-gray-800">
              <TabsTrigger value="overview">
                <BookOpen className="h-4 w-4 mr-2" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="leaderboard">
                <Trophy className="h-4 w-4 mr-2" />
                Leaderboard
              </TabsTrigger>
              <TabsTrigger value="comments">
                <MessageCircle className="h-4 w-4 mr-2" />
                Comments
              </TabsTrigger>
              <TabsTrigger value="rewards">
                <Gift className="h-4 w-4 mr-2" />
                Rewards
              </TabsTrigger>
              <TabsTrigger value="stats">
                <TrendingUp className="h-4 w-4 mr-2" />
                Stats
              </TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6 mt-6">
              <Card className="bg-gray-800 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white">Quest Description</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300 leading-relaxed mb-4">
                    {quest.summary}
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-white mb-3">Requirements</h4>
                      <ul className="space-y-2 text-gray-400">
                        <li className="flex items-center space-x-2">
                          <CheckCircle2 className="h-4 w-4 text-green-400" />
                          <span>Have a wallet connected</span>
                        </li>
                        <li className="flex items-center space-x-2">
                          <CheckCircle2 className="h-4 w-4 text-green-400" />
                          <span>Basic understanding of DeFi</span>
                        </li>
                        <li className="flex items-center space-x-2">
                          <CheckCircle2 className="h-4 w-4 text-green-400" />
                          <span>Some ETH for gas fees</span>
                        </li>
                      </ul>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-white mb-3">Tips for Success</h4>
                      <ul className="space-y-2 text-gray-400">
                        <li className="flex items-center space-x-2">
                          <Star className="h-4 w-4 text-yellow-400" />
                          <span>Start with small amounts</span>
                        </li>
                        <li className="flex items-center space-x-2">
                          <Star className="h-4 w-4 text-yellow-400" />
                          <span>Read all instructions carefully</span>
                        </li>
                        <li className="flex items-center space-x-2">
                          <Star className="h-4 w-4 text-yellow-400" />
                          <span>Ask for help in Discord if stuck</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white">Quest Timeline</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4">
                      <Calendar className="h-5 w-5 text-green-400" />
                      <div>
                        <p className="text-white font-medium">Quest Started</p>
                        <p className="text-gray-400 text-sm">
                          {new Date(quest.startsAt).toLocaleDateString()} at{' '}
                          {new Date(quest.startsAt).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <Calendar className="h-5 w-5 text-red-400" />
                      <div>
                        <p className="text-white font-medium">Quest Ends</p>
                        <p className="text-gray-400 text-sm">
                          {new Date(quest.endsAt).toLocaleDateString()} at{' '}
                          {new Date(quest.endsAt).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Leaderboard Tab */}
            <TabsContent value="leaderboard" className="space-y-4 mt-6">
              <Card className="bg-gray-800 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white flex items-center space-x-2">
                    <Trophy className="h-5 w-5 text-yellow-400" />
                    <span>Quest Leaderboard</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {participants.map((participant, index) => (
                      <div key={participant.id} className="flex items-center space-x-4 p-3 bg-gray-700 rounded-lg">
                        <div className="flex-shrink-0 w-8 text-center">
                          {participant.rank === 1 && <Crown className="h-5 w-5 text-yellow-400 mx-auto" />}
                          {participant.rank === 2 && <span className="text-gray-300 font-bold">#2</span>}
                          {participant.rank === 3 && <span className="text-amber-600 font-bold">#3</span>}
                          {participant.rank && participant.rank > 3 && (
                            <span className="text-gray-400 font-bold">#{participant.rank}</span>
                          )}
                        </div>
                        
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={participant.avatarUrl} />
                          <AvatarFallback className="bg-purple-600 text-white text-xs">
                            {participant.username.slice(1, 3).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        
                        <div className="flex-1">
                          <p className="text-white font-medium">{participant.username}</p>
                          <div className="flex items-center space-x-2">
                            <Progress value={participant.progress} className="flex-1 h-2" />
                            <span className="text-sm text-gray-400">{participant.progress}%</span>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          {participant.completedAt ? (
                            <Badge className="bg-green-600 text-white">
                              <CheckCircle2 className="h-3 w-3 mr-1" />
                              Completed
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="border-blue-400 text-blue-400">
                              In Progress
                            </Badge>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Comments Tab */}
            <TabsContent value="comments" className="space-y-4 mt-6">
              <Card className="bg-gray-800 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white">Add Comment</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    placeholder="Share your thoughts, ask questions, or help others..."
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white"
                    rows={3}
                  />
                  <Button
                    onClick={handleAddComment}
                    disabled={isCommenting || !newComment.trim()}
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    {isCommenting ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Posting...
                      </>
                    ) : (
                      <>
                        <MessageCircle className="h-4 w-4 mr-2" />
                        Post Comment
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              <div className="space-y-4">
                {comments.map((comment) => (
                  <Card key={comment.id} className="bg-gray-800 border-gray-600">
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={comment.avatarUrl} />
                          <AvatarFallback className="bg-purple-600 text-white text-xs">
                            {comment.username.slice(1, 3).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <h4 className="font-medium text-white">{comment.username}</h4>
                            <span className="text-xs text-gray-400">
                              {new Date(comment.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="text-gray-300 mb-3">{comment.content}</p>
                          <div className="flex items-center space-x-4">
                            <Button
                              variant="ghost"
                              size="sm"
                              className={`h-6 text-xs ${comment.isLiked ? 'text-red-400' : 'text-gray-400 hover:text-red-400'}`}
                            >
                              <ThumbsUp className={`h-3 w-3 mr-1 ${comment.isLiked ? 'fill-red-400' : ''}`} />
                              {comment.likes}
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 text-xs text-gray-400 hover:text-blue-400"
                            >
                              <MessageCircle className="h-3 w-3 mr-1" />
                              Reply
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Rewards Tab */}
            <TabsContent value="rewards" className="space-y-4 mt-6">
              <Card className="bg-gray-800 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white flex items-center space-x-2">
                    <Gift className="h-5 w-5 text-yellow-400" />
                    <span>Quest Rewards</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="bg-gray-700 p-4 rounded-lg">
                        <div className="flex items-center space-x-3 mb-2">
                          <Zap className="h-6 w-6 text-yellow-400" />
                          <h4 className="text-white font-semibold">Experience Points</h4>
                        </div>
                        <p className="text-2xl font-bold text-white">{questStats.totalRewards.toLocaleString()} XP</p>
                        <p className="text-gray-400 text-sm">Total reward pool</p>
                      </div>
                      
                      <div className="bg-gray-700 p-4 rounded-lg">
                        <div className="flex items-center space-x-3 mb-2">
                          <Crown className="h-6 w-6 text-purple-400" />
                          <h4 className="text-white font-semibold">Level Progress</h4>
                        </div>
                        <p className="text-lg font-bold text-white">+2-3 Levels</p>
                        <p className="text-gray-400 text-sm">Estimated level gain</p>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="bg-gray-700 p-4 rounded-lg">
                        <div className="flex items-center space-x-3 mb-2">
                          <Trophy className="h-6 w-6 text-green-400" />
                          <h4 className="text-white font-semibold">Achievement Unlock</h4>
                        </div>
                        <p className="text-white font-medium">DeFi Explorer Badge</p>
                        <p className="text-gray-400 text-sm">For completing DeFi quests</p>
                      </div>
                      
                      <div className="bg-gray-700 p-4 rounded-lg">
                        <div className="flex items-center space-x-3 mb-2">
                          <Star className="h-6 w-6 text-blue-400" />
                          <h4 className="text-white font-semibold">Bonus Rewards</h4>
                        </div>
                        <p className="text-white font-medium">Early Completion Bonus</p>
                        <p className="text-gray-400 text-sm">Extra 25% XP for fast completion</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Stats Tab */}
            <TabsContent value="stats" className="space-y-4 mt-6">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <Card className="bg-gray-800 border-gray-600">
                  <CardContent className="p-4 text-center">
                    <Users className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                    <p className="text-lg font-bold text-white">{questStats.totalParticipants}</p>
                    <p className="text-sm text-gray-400">Total Participants</p>
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-800 border-gray-600">
                  <CardContent className="p-4 text-center">
                    <TrendingUp className="h-8 w-8 text-green-400 mx-auto mb-2" />
                    <p className="text-lg font-bold text-white">{questStats.completionRate}%</p>
                    <p className="text-sm text-gray-400">Completion Rate</p>
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-800 border-gray-600">
                  <CardContent className="p-4 text-center">
                    <Clock className="h-8 w-8 text-purple-400 mx-auto mb-2" />
                    <p className="text-lg font-bold text-white">{questStats.averageTime}m</p>
                    <p className="text-sm text-gray-400">Avg. Completion</p>
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-800 border-gray-600">
                  <CardContent className="p-4 text-center">
                    <Heart className="h-8 w-8 text-red-400 mx-auto mb-2" />
                    <p className="text-lg font-bold text-white">{questStats.likes}</p>
                    <p className="text-sm text-gray-400">Community Likes</p>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-gray-800 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white">Quest Analytics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Success Rate</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-32 h-2 bg-gray-700 rounded">
                          <div className="w-3/4 h-full bg-green-400 rounded"></div>
                        </div>
                        <span className="text-white font-medium">73%</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Average Rating</span>
                      <div className="flex items-center space-x-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star key={star} className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                        ))}
                        <span className="text-white font-medium ml-2">4.8</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Repeat Attempts</span>
                      <span className="text-white font-medium">12%</span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Social Shares</span>
                      <span className="text-white font-medium">156</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}