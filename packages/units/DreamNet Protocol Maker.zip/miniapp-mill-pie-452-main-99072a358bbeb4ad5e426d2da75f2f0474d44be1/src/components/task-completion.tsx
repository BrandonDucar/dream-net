'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { 
  ArrowLeft,
  CheckCircle2,
  Circle,
  Upload,
  ExternalLink,
  Twitter,
  MessageCircle,
  Link,
  Zap,
  Trophy,
  Clock,
  AlertCircle,
  Play,
  Pause,
  Camera,
  FileText,
  Globe,
} from 'lucide-react';
import type { QuestRow } from '@/spacetime_module_bindings';
import { useQuestPlatform } from '@/hooks/useQuestPlatform';

interface TaskCompletionProps {
  quest: QuestRow;
  onClose: () => void;
  onBack: () => void;
}

interface Task {
  id: string;
  title: string;
  description: string;
  type: string;
  instructions: string;
  verificationMethod: string;
  xpReward: number;
  isCompleted: boolean;
  isInProgress: boolean;
  completedAt?: string;
  evidenceRequired: boolean;
  externalUrl?: string;
  estimatedMinutes: number;
}

interface SubmissionData {
  taskId: string;
  evidenceType: string;
  evidenceData: string;
  notes: string;
}

export function TaskCompletion({ quest, onClose, onBack }: TaskCompletionProps): JSX.Element {
  const { submitTaskResult } = useQuestPlatform();
  
  const [currentTaskIndex, setCurrentTaskIndex] = useState<number>(0);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submissionData, setSubmissionData] = useState<SubmissionData>({
    taskId: '',
    evidenceType: 'text',
    evidenceData: '',
    notes: '',
  });

  // Mock tasks data - would come from quest metadata in real implementation
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: 'task_twitter_follow',
      title: 'Follow @DreamNet on Twitter',
      description: 'Follow our official Twitter account to stay updated with the latest news and announcements.',
      type: 'TwitterFollow',
      instructions: '1. Click the link below to open Twitter\n2. Click the Follow button\n3. Take a screenshot of your follow confirmation\n4. Upload the screenshot as evidence',
      verificationMethod: 'Manual',
      xpReward: 100,
      isCompleted: false,
      isInProgress: false,
      evidenceRequired: true,
      externalUrl: 'https://twitter.com/dreamnet',
      estimatedMinutes: 2,
    },
    {
      id: 'task_discord_join',
      title: 'Join Discord Community',
      description: 'Join our Discord server to connect with the community and get support.',
      type: 'DiscordJoin',
      instructions: '1. Click the Discord invite link\n2. Accept the invite and join the server\n3. Introduce yourself in the #introductions channel\n4. Copy your introduction message',
      verificationMethod: 'Manual',
      xpReward: 150,
      isCompleted: false,
      isInProgress: false,
      evidenceRequired: true,
      externalUrl: 'https://discord.gg/dreamnet',
      estimatedMinutes: 5,
    },
    {
      id: 'task_wallet_connect',
      title: 'Connect Your Wallet',
      description: 'Connect your wallet to start interacting with DeFi protocols.',
      type: 'OnchainTransaction',
      instructions: '1. Click "Connect Wallet" in the top right\n2. Select your preferred wallet\n3. Approve the connection\n4. Verify your wallet address is shown',
      verificationMethod: 'Automatic',
      xpReward: 200,
      isCompleted: false,
      isInProgress: false,
      evidenceRequired: false,
      estimatedMinutes: 3,
    },
    {
      id: 'task_first_swap',
      title: 'Make Your First Token Swap',
      description: 'Perform a token swap using a decentralized exchange.',
      type: 'OnchainTransaction',
      instructions: '1. Go to a DEX like Uniswap or SushiSwap\n2. Connect your wallet\n3. Swap a small amount of ETH for another token\n4. Confirm the transaction\n5. Submit your transaction hash',
      verificationMethod: 'Automatic',
      xpReward: 300,
      isCompleted: false,
      isInProgress: false,
      evidenceRequired: true,
      estimatedMinutes: 10,
    },
    {
      id: 'task_quiz_completion',
      title: 'Complete DeFi Knowledge Quiz',
      description: 'Test your understanding of DeFi concepts with our interactive quiz.',
      type: 'Quiz',
      instructions: 'Answer all questions correctly to complete this task. You have unlimited attempts.',
      verificationMethod: 'Automatic',
      xpReward: 250,
      isCompleted: false,
      isInProgress: false,
      evidenceRequired: false,
      estimatedMinutes: 15,
    },
  ]);

  const currentTask = tasks[currentTaskIndex];
  const completedTasks = tasks.filter(task => task.isCompleted).length;
  const totalTasks = tasks.length;
  const progressPercentage = Math.round((completedTasks / totalTasks) * 100);
  const totalXpEarned = tasks.filter(task => task.isCompleted).reduce((sum, task) => sum + task.xpReward, 0);

  useEffect(() => {
    setSubmissionData(prev => ({
      ...prev,
      taskId: currentTask?.id || '',
    }));
  }, [currentTask]);

  const handleStartTask = (): void => {
    setTasks(prev => prev.map((task, index) => 
      index === currentTaskIndex ? { ...task, isInProgress: true } : task
    ));
  };

  const handleSubmitTask = async (): Promise<void> => {
    if (!currentTask) return;

    setIsSubmitting(true);
    try {
      // Submit task completion evidence
      await submitTaskResult(
        currentTask.id,
        0, // instance ID - would be dynamic
        JSON.stringify({
          evidenceType: submissionData.evidenceType,
          evidenceData: submissionData.evidenceData,
          notes: submissionData.notes,
          submittedAt: new Date().toISOString(),
        })
      );

      // Mark task as completed
      setTasks(prev => prev.map((task, index) => 
        index === currentTaskIndex ? { 
          ...task, 
          isCompleted: true, 
          isInProgress: false,
          completedAt: new Date().toISOString(),
        } : task
      ));

      // Reset submission data
      setSubmissionData({
        taskId: '',
        evidenceType: 'text',
        evidenceData: '',
        notes: '',
      });

      // Move to next task if available
      if (currentTaskIndex < tasks.length - 1) {
        setTimeout(() => setCurrentTaskIndex(prev => prev + 1), 1000);
      }

    } catch (error) {
      console.error('Failed to submit task:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>): void => {
    const file = event.target.files?.[0];
    if (file) {
      // In a real app, you'd upload to a storage service
      const fakeUrl = `https://storage.dreamnet.com/evidence/${Date.now()}_${file.name}`;
      setSubmissionData(prev => ({
        ...prev,
        evidenceType: 'file',
        evidenceData: fakeUrl,
      }));
    }
  };

  const getTaskTypeIcon = (type: string): JSX.Element => {
    switch (type) {
      case 'TwitterFollow':
        return <Twitter className="h-5 w-5 text-blue-400" />;
      case 'DiscordJoin':
        return <MessageCircle className="h-5 w-5 text-purple-400" />;
      case 'OnchainTransaction':
        return <Link className="h-5 w-5 text-green-400" />;
      case 'Quiz':
        return <FileText className="h-5 w-5 text-yellow-400" />;
      default:
        return <Circle className="h-5 w-5 text-gray-400" />;
    }
  };

  const getVerificationBadge = (method: string): JSX.Element => {
    return (
      <Badge 
        variant="outline" 
        className={`text-xs ${
          method === 'Automatic' 
            ? 'text-green-400 border-green-400' 
            : 'text-blue-400 border-blue-400'
        }`}
      >
        {method === 'Automatic' ? 'Auto-verified' : 'Manual Review'}
      </Badge>
    );
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-gray-900 border-gray-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={onBack}
                className="h-8 w-8 p-0"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div>
                <h1 className="text-xl font-bold text-white">{quest.title}</h1>
                <p className="text-sm text-gray-400">Complete all tasks to earn rewards</p>
              </div>
            </div>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-8 w-8 p-0"
            >
              ×
            </Button>
          </div>
          
          {/* Overall Progress */}
          <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">Quest Progress</span>
              <span className="text-sm text-white">{completedTasks}/{totalTasks} tasks completed</span>
            </div>
            <Progress value={progressPercentage} className="h-3 mb-3" />
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center space-x-4">
                <span className="text-gray-400">
                  <Zap className="h-4 w-4 inline mr-1 text-yellow-400" />
                  {totalXpEarned} XP earned
                </span>
                <span className="text-gray-400">
                  <Clock className="h-4 w-4 inline mr-1" />
                  {tasks.reduce((sum, task) => sum + task.estimatedMinutes, 0)}m total
                </span>
              </div>
              {completedTasks === totalTasks && (
                <Badge className="bg-green-600 text-white">
                  <Trophy className="h-3 w-3 mr-1" />
                  Quest Complete!
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Task Navigation */}
          <div className="flex space-x-2 overflow-x-auto pb-2">
            {tasks.map((task, index) => (
              <Button
                key={task.id}
                variant={index === currentTaskIndex ? 'default' : 'outline'}
                size="sm"
                onClick={() => setCurrentTaskIndex(index)}
                className={`flex-shrink-0 ${
                  task.isCompleted 
                    ? 'bg-green-600 border-green-600 text-white' 
                    : index === currentTaskIndex 
                    ? 'bg-purple-600 border-purple-600' 
                    : 'border-gray-600 text-gray-300'
                }`}
                disabled={index > currentTaskIndex && !task.isCompleted}
              >
                {task.isCompleted ? (
                  <CheckCircle2 className="h-4 w-4 mr-1" />
                ) : task.isInProgress ? (
                  <Play className="h-4 w-4 mr-1" />
                ) : (
                  <Circle className="h-4 w-4 mr-1" />
                )}
                Task {index + 1}
              </Button>
            ))}
          </div>

          {/* Current Task */}
          {currentTask && (
            <Card className="bg-gray-800 border-gray-600">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {getTaskTypeIcon(currentTask.type)}
                    <div>
                      <h3 className="text-lg font-semibold text-white">{currentTask.title}</h3>
                      <p className="text-gray-400 text-sm">{currentTask.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getVerificationBadge(currentTask.verificationMethod)}
                    <Badge className="bg-yellow-600 text-white">
                      <Zap className="h-3 w-3 mr-1" />
                      {currentTask.xpReward} XP
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {currentTask.isCompleted ? (
                  <div className="text-center py-8">
                    <CheckCircle2 className="h-16 w-16 text-green-400 mx-auto mb-4" />
                    <h4 className="text-lg font-semibold text-white mb-2">Task Completed!</h4>
                    <p className="text-gray-400 mb-4">
                      Completed on {new Date(currentTask.completedAt!).toLocaleDateString()}
                    </p>
                    <Badge className="bg-green-600 text-white">
                      <Trophy className="h-3 w-3 mr-1" />
                      +{currentTask.xpReward} XP Earned
                    </Badge>
                  </div>
                ) : (
                  <>
                    {/* Task Instructions */}
                    <div className="bg-gray-700 p-4 rounded-lg">
                      <h4 className="font-semibold text-white mb-2">Instructions</h4>
                      <div className="whitespace-pre-wrap text-gray-300 text-sm">
                        {currentTask.instructions}
                      </div>
                      
                      {currentTask.externalUrl && (
                        <Button
                          className="mt-3 bg-blue-600 hover:bg-blue-700"
                          onClick={() => window.open(currentTask.externalUrl, '_blank')}
                        >
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Open Link
                        </Button>
                      )}
                    </div>

                    {/* Task Actions */}
                    {!currentTask.isInProgress ? (
                      <div className="text-center">
                        <Button
                          onClick={handleStartTask}
                          className="bg-purple-600 hover:bg-purple-700"
                        >
                          <Play className="h-4 w-4 mr-2" />
                          Start Task
                        </Button>
                      </div>
                    ) : (
                      <>
                        {/* Evidence Submission */}
                        {currentTask.evidenceRequired && (
                          <div className="space-y-4">
                            <h4 className="font-semibold text-white">Submit Evidence</h4>
                            
                            <div className="space-y-3">
                              <div>
                                <Label className="text-white">Evidence Type</Label>
                                <select
                                  value={submissionData.evidenceType}
                                  onChange={(e) => setSubmissionData(prev => ({ ...prev, evidenceType: e.target.value }))}
                                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white"
                                >
                                  <option value="text">Text/URL</option>
                                  <option value="file">File Upload</option>
                                  <option value="transaction">Transaction Hash</option>
                                </select>
                              </div>
                              
                              {submissionData.evidenceType === 'text' && (
                                <div>
                                  <Label className="text-white">Evidence Data</Label>
                                  <Input
                                    placeholder="Paste URL, text, or other evidence..."
                                    value={submissionData.evidenceData}
                                    onChange={(e) => setSubmissionData(prev => ({ ...prev, evidenceData: e.target.value }))}
                                    className="bg-gray-700 border-gray-600 text-white"
                                  />
                                </div>
                              )}
                              
                              {submissionData.evidenceType === 'file' && (
                                <div>
                                  <Label className="text-white">Upload File</Label>
                                  <div className="border border-gray-600 border-dashed rounded-lg p-4 text-center">
                                    <input
                                      type="file"
                                      onChange={handleFileUpload}
                                      className="hidden"
                                      id="file-upload"
                                      accept="image/*,.pdf,.txt"
                                    />
                                    <label htmlFor="file-upload" className="cursor-pointer">
                                      <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                                      <p className="text-gray-400">Click to upload or drag and drop</p>
                                      <p className="text-gray-500 text-xs">PNG, JPG, PDF up to 10MB</p>
                                    </label>
                                    {submissionData.evidenceData && (
                                      <p className="text-green-400 text-sm mt-2">File uploaded successfully!</p>
                                    )}
                                  </div>
                                </div>
                              )}
                              
                              {submissionData.evidenceType === 'transaction' && (
                                <div>
                                  <Label className="text-white">Transaction Hash</Label>
                                  <Input
                                    placeholder="0x..."
                                    value={submissionData.evidenceData}
                                    onChange={(e) => setSubmissionData(prev => ({ ...prev, evidenceData: e.target.value }))}
                                    className="bg-gray-700 border-gray-600 text-white"
                                  />
                                </div>
                              )}
                              
                              <div>
                                <Label className="text-white">Additional Notes (Optional)</Label>
                                <Textarea
                                  placeholder="Add any additional context or notes..."
                                  value={submissionData.notes}
                                  onChange={(e) => setSubmissionData(prev => ({ ...prev, notes: e.target.value }))}
                                  className="bg-gray-700 border-gray-600 text-white"
                                  rows={3}
                                />
                              </div>
                            </div>
                          </div>
                        )}
                        
                        {/* Submit Button */}
                        <div className="flex justify-between">
                          <Button
                            variant="outline"
                            onClick={() => setTasks(prev => prev.map((task, index) => 
                              index === currentTaskIndex ? { ...task, isInProgress: false } : task
                            ))}
                            className="border-gray-600 text-gray-300"
                          >
                            <Pause className="h-4 w-4 mr-2" />
                            Pause Task
                          </Button>
                          
                          <Button
                            onClick={handleSubmitTask}
                            disabled={isSubmitting || (currentTask.evidenceRequired && !submissionData.evidenceData.trim())}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            {isSubmitting ? (
                              <>
                                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                Submitting...
                              </>
                            ) : (
                              <>
                                <CheckCircle2 className="h-4 w-4 mr-2" />
                                Complete Task
                              </>
                            )}
                          </Button>
                        </div>
                      </>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          )}

          {/* Quick Quest Overview */}
          <Card className="bg-gray-800 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white text-sm">All Tasks Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {tasks.map((task, index) => (
                  <div key={task.id} className="flex items-center justify-between p-2 bg-gray-700 rounded">
                    <div className="flex items-center space-x-3">
                      {task.isCompleted ? (
                        <CheckCircle2 className="h-4 w-4 text-green-400" />
                      ) : task.isInProgress ? (
                        <Play className="h-4 w-4 text-blue-400" />
                      ) : (
                        <Circle className="h-4 w-4 text-gray-500" />
                      )}
                      <span className={`text-sm ${task.isCompleted ? 'text-green-400' : 'text-white'}`}>
                        {task.title}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs text-gray-400">{task.estimatedMinutes}m</span>
                      <Badge variant="outline" className="text-xs border-yellow-600 text-yellow-400">
                        {task.xpReward} XP
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
}