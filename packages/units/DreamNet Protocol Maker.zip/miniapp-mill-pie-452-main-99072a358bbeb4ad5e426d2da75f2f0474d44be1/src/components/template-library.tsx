'use client';

import { useState, useMemo } from 'react';
import type { ProtocolTemplate } from '@/spacetime_module_bindings';
import type { DbConnection } from '@/spacetime_module_bindings';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileCode, Plus, Download, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

interface TemplateLibraryProps {
  templates: Map<string, ProtocolTemplate>;
  connection: DbConnection | null;
  onUseTemplate: (template: ProtocolTemplate) => void;
}

const TEMPLATE_CATEGORIES = [
  'onboarding',
  'retention',
  'reactivation',
  'defi',
  'nft',
  'social',
  'gaming',
  'custom',
];

const DEFAULT_TEMPLATES = [
  {
    id: 'wolf-pack-onboard',
    name: 'Wolf Pack Onboarding',
    description: 'Standard onboarding flow for wolf pack members',
    category: 'onboarding',
    data: {
      nodes: [
        { id: 'entry_mint', type: 'entry', label: 'Mint Token' },
        { id: 'funnel_wolf', type: 'funnel', label: 'Wolf Pack Funnel' },
        { id: 'reward_welcome', type: 'reward', label: 'Welcome Reward' },
        { id: 'exit_success', type: 'exit', label: 'Success' },
      ],
      edges: [
        { from: 'entry_mint', to: 'funnel_wolf', condition: 'always' },
        { from: 'funnel_wolf', to: 'reward_welcome', condition: 'requirements_met' },
        { from: 'reward_welcome', to: 'exit_success', condition: 'always' },
      ],
    },
  },
  {
    id: 'whale-retention',
    name: 'Whale Retention Loop',
    description: 'Keep high-value users engaged with exclusive rewards',
    category: 'retention',
    data: {
      nodes: [
        { id: 'entry_whale', type: 'entry', label: 'Whale Entry' },
        { id: 'ritual_daily', type: 'ritual_ref', label: 'Daily Check-in' },
        { id: 'reward_exclusive', type: 'reward', label: 'Exclusive Reward' },
        { id: 'exit_retain', type: 'exit', label: 'Retained' },
      ],
      edges: [
        { from: 'entry_whale', to: 'ritual_daily', condition: 'always' },
        { from: 'ritual_daily', to: 'reward_exclusive', condition: 'ritual_completed' },
        { from: 'reward_exclusive', to: 'exit_retain', condition: 'always' },
      ],
    },
  },
  {
    id: 'quest-chain',
    name: 'Quest Chain',
    description: 'Multi-step quest flow with progressive rewards',
    category: 'gaming',
    data: {
      nodes: [
        { id: 'entry_quest', type: 'entry', label: 'Start Quest' },
        { id: 'action_1', type: 'action', label: 'Quest Step 1' },
        { id: 'action_2', type: 'action', label: 'Quest Step 2' },
        { id: 'action_3', type: 'action', label: 'Quest Step 3' },
        { id: 'reward_final', type: 'reward', label: 'Quest Reward' },
        { id: 'exit_complete', type: 'exit', label: 'Complete' },
      ],
      edges: [
        { from: 'entry_quest', to: 'action_1', condition: 'always' },
        { from: 'action_1', to: 'action_2', condition: 'always' },
        { from: 'action_2', to: 'action_3', condition: 'always' },
        { from: 'action_3', to: 'reward_final', condition: 'always' },
        { from: 'reward_final', to: 'exit_complete', condition: 'always' },
      ],
    },
  },
];

export function TemplateLibrary({ templates, connection, onUseTemplate }: TemplateLibraryProps) {
  const [isCreateOpen, setIsCreateOpen] = useState<boolean>(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [newTemplate, setNewTemplate] = useState({
    name: '',
    description: '',
    category: 'custom',
  });

  // Combine DB templates with default templates
  const allTemplates = useMemo(() => {
    const dbTemplates = Array.from(templates.values()).map((t) => ({
      id: t.templateId,
      name: t.name,
      description: t.description,
      category: t.category,
      isPublic: t.isPublic,
      data: JSON.parse(t.templateData),
      createdAt: t.createdAt,
    }));

    const defaultTemplatesWithMeta = DEFAULT_TEMPLATES.map((t) => ({
      ...t,
      isPublic: true,
      isDefault: true,
    }));

    return [...defaultTemplatesWithMeta, ...dbTemplates];
  }, [templates]);

  const filteredTemplates = useMemo(() => {
    if (selectedCategory === 'all') {
      return allTemplates;
    }
    return allTemplates.filter((t) => t.category === selectedCategory);
  }, [allTemplates, selectedCategory]);

  const handleCreateTemplate = () => {
    if (!connection) {
      toast.error('Not connected to database');
      return;
    }

    if (!newTemplate.name.trim()) {
      toast.error('Template name is required');
      return;
    }

    const templateId = `template-${Date.now()}`;
    const templateData = JSON.stringify({ nodes: [], edges: [] });

    try {
      connection.reducers.createProtocolTemplate(
        templateId,
        newTemplate.name,
        newTemplate.description,
        newTemplate.category,
        templateData,
        false
      );
      toast.success('Template created successfully');
      setIsCreateOpen(false);
      setNewTemplate({ name: '', description: '', category: 'custom' });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to create template: ${errorMessage}`);
    }
  };

  const handleDeleteTemplate = (templateId: string) => {
    if (!connection) {
      toast.error('Not connected to database');
      return;
    }

    try {
      connection.reducers.deleteProtocolTemplate(templateId);
      toast.success('Template deleted successfully');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to delete template: ${errorMessage}`);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Template Library</h2>
          <p className="text-gray-400 text-sm">Pre-built protocol patterns to get started faster</p>
        </div>
        <Button
          onClick={() => setIsCreateOpen(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white"
        >
          <Plus className="h-4 w-4 mr-2" />
          New Template
        </Button>
      </div>

      {/* Category Filter */}
      <Select value={selectedCategory} onValueChange={setSelectedCategory}>
        <SelectTrigger className="w-[200px] bg-gray-800 border-gray-700 text-white">
          <SelectValue />
        </SelectTrigger>
        <SelectContent className="bg-gray-800 border-gray-700">
          <SelectItem value="all">All Categories</SelectItem>
          {TEMPLATE_CATEGORIES.map((cat) => (
            <SelectItem key={cat} value={cat}>
              {cat.charAt(0).toUpperCase() + cat.slice(1)}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Template Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTemplates.map((template) => (
          <Card key={template.id} className="bg-gray-900 border-gray-800 hover:border-gray-700 transition">
            <CardHeader>
              <div className="flex items-start justify-between">
                <FileCode className="h-8 w-8 text-blue-400" />
                {template.isPublic && (
                  <Badge variant="outline" className="text-xs">Public</Badge>
                )}
              </div>
              <CardTitle className="text-white text-lg mt-2">{template.name}</CardTitle>
              <CardDescription className="text-gray-400 text-sm">{template.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <Badge className="bg-gray-800 text-gray-300">
                  {template.category}
                </Badge>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={() => onUseTemplate(template as ProtocolTemplate)}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    <Download className="h-3 w-3 mr-1" />
                    Use
                  </Button>
                  {!template.isDefault && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDeleteTemplate(template.id)}
                      className="text-red-400 hover:text-red-300 hover:bg-gray-800"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Create Template Dialog */}
      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
        <DialogContent className="bg-gray-900 border-gray-800 text-white">
          <DialogHeader>
            <DialogTitle className="text-white">Create New Template</DialogTitle>
            <DialogDescription className="text-gray-400">
              Create a reusable protocol template
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="template-name" className="text-gray-300">Name</Label>
              <Input
                id="template-name"
                value={newTemplate.name}
                onChange={(e) => setNewTemplate({ ...newTemplate, name: e.target.value })}
                placeholder="e.g., My Custom Template"
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
            <div>
              <Label htmlFor="template-description" className="text-gray-300">Description</Label>
              <Textarea
                id="template-description"
                value={newTemplate.description}
                onChange={(e) => setNewTemplate({ ...newTemplate, description: e.target.value })}
                placeholder="Describe the template..."
                className="bg-gray-800 border-gray-700 text-white"
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="template-category" className="text-gray-300">Category</Label>
              <Select
                value={newTemplate.category}
                onValueChange={(value) => setNewTemplate({ ...newTemplate, category: value })}
              >
                <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  {TEMPLATE_CATEGORIES.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat.charAt(0).toUpperCase() + cat.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsCreateOpen(false)}
              className="border-gray-700 text-gray-300 hover:bg-gray-800"
            >
              Cancel
            </Button>
            <Button
              onClick={handleCreateTemplate}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Create Template
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
