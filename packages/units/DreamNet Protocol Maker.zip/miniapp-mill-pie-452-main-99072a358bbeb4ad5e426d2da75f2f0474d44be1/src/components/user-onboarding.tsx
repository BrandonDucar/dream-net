'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { 
  ArrowLeft,
  ArrowRight,
  User,
  Wallet,
  Target,
  Trophy,
  Sparkles,
  Camera,
  Link,
  Twitter,
  Github,
  Globe,
  CheckCircle2,
  Star,
} from 'lucide-react';
import { useQuestPlatform } from '@/hooks/useQuestPlatform';

interface UserOnboardingProps {
  onComplete: () => void;
}

interface OnboardingData {
  handle: string;
  walletAddress: string;
  bio: string;
  avatarUrl: string;
  socialLinks: {
    twitter?: string;
    github?: string;
    website?: string;
  };
  preferences: {
    categories: string[];
    difficulty: string[];
    notifications: boolean;
  };
}

export function UserOnboarding({ onComplete }: UserOnboardingProps): JSX.Element {
  const { registerUser, questCategories, QuestDifficulty } = useQuestPlatform();
  
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [onboardingData, setOnboardingData] = useState<OnboardingData>({
    handle: '',
    walletAddress: '',
    bio: '',
    avatarUrl: '',
    socialLinks: {},
    preferences: {
      categories: [],
      difficulty: [],
      notifications: true,
    },
  });

  const totalSteps = 4;
  const progressPercentage = ((currentStep + 1) / totalSteps) * 100;

  const handleInputChange = (field: string, value: any): void => {
    setOnboardingData(prev => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSocialLinkChange = (platform: string, value: string): void => {
    setOnboardingData(prev => ({
      ...prev,
      socialLinks: {
        ...prev.socialLinks,
        [platform]: value,
      },
    }));
  };

  const handlePreferenceChange = (field: string, value: any): void => {
    setOnboardingData(prev => ({
      ...prev,
      preferences: {
        ...prev.preferences,
        [field]: value,
      },
    }));
  };

  const toggleCategory = (categoryId: string): void => {
    const currentCategories = onboardingData.preferences.categories;
    const newCategories = currentCategories.includes(categoryId)
      ? currentCategories.filter(id => id !== categoryId)
      : [...currentCategories, categoryId];
    
    handlePreferenceChange('categories', newCategories);
  };

  const toggleDifficulty = (difficulty: string): void => {
    const currentDifficulties = onboardingData.preferences.difficulty;
    const newDifficulties = currentDifficulties.includes(difficulty)
      ? currentDifficulties.filter(d => d !== difficulty)
      : [...currentDifficulties, difficulty];
    
    handlePreferenceChange('difficulty', newDifficulties);
  };

  const connectWallet = async (): Promise<void> => {
    try {
      // Mock wallet connection - would use real wallet connector
      const mockAddress = '0x' + Math.random().toString(16).substr(2, 40);
      handleInputChange('walletAddress', mockAddress);
    } catch (error) {
      console.error('Failed to connect wallet:', error);
    }
  };

  const generateAvatar = (): void => {
    // Generate a random avatar URL
    const avatarUrls = [
      'https://api.dicebear.com/7.x/avataaars/svg?seed=1',
      'https://api.dicebear.com/7.x/avataaars/svg?seed=2',
      'https://api.dicebear.com/7.x/avataaars/svg?seed=3',
      'https://api.dicebear.com/7.x/avataaars/svg?seed=4',
      'https://api.dicebear.com/7.x/avataaars/svg?seed=5',
    ];
    const randomUrl = avatarUrls[Math.floor(Math.random() * avatarUrls.length)];
    handleInputChange('avatarUrl', randomUrl);
  };

  const canProceed = (): boolean => {
    switch (currentStep) {
      case 0:
        return onboardingData.handle.length >= 3;
      case 1:
        return !!onboardingData.walletAddress;
      case 2:
        return onboardingData.preferences.categories.length > 0;
      case 3:
        return true;
      default:
        return false;
    }
  };

  const handleNext = (): void => {
    if (currentStep < totalSteps - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrevious = (): void => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleComplete = async (): Promise<void> => {
    setIsSubmitting(true);
    try {
      await registerUser({
        handle: onboardingData.handle,
        walletAddress: onboardingData.walletAddress,
        bio: onboardingData.bio,
        avatarUrl: onboardingData.avatarUrl,
        socialLinks: JSON.stringify(onboardingData.socialLinks),
      });
      
      // Save preferences to local storage for now
      localStorage.setItem('userPreferences', JSON.stringify(onboardingData.preferences));
      
      onComplete();
    } catch (error) {
      console.error('Failed to complete onboarding:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStep = (): JSX.Element => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <User className="h-16 w-16 text-purple-400 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-2">Create Your Profile</h2>
              <p className="text-gray-400">Let's get you set up with a unique profile in the DreamNet community</p>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="text-white">Choose a Handle</Label>
                <Input
                  placeholder="@your_handle"
                  value={onboardingData.handle}
                  onChange={(e) => handleInputChange('handle', e.target.value)}
                  className="bg-gray-800 border-gray-600 text-white"
                />
                <p className="text-xs text-gray-500">This will be your unique identifier. Choose wisely!</p>
              </div>
              
              <div className="space-y-2">
                <Label className="text-white">Tell us about yourself</Label>
                <Textarea
                  placeholder="I'm excited to explore Web3 and earn rewards..."
                  value={onboardingData.bio}
                  onChange={(e) => handleInputChange('bio', e.target.value)}
                  className="bg-gray-800 border-gray-600 text-white"
                  rows={3}
                />
              </div>
              
              <div className="space-y-2">
                <Label className="text-white">Profile Avatar</Label>
                <div className="flex items-center space-x-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={onboardingData.avatarUrl} />
                    <AvatarFallback className="bg-purple-600 text-white text-xl">
                      {onboardingData.handle.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="space-y-2">
                    <Button
                      onClick={generateAvatar}
                      variant="outline"
                      className="border-gray-600 text-gray-300"
                    >
                      <Sparkles className="h-4 w-4 mr-2" />
                      Generate Random
                    </Button>
                    <Input
                      placeholder="Or paste image URL"
                      value={onboardingData.avatarUrl}
                      onChange={(e) => handleInputChange('avatarUrl', e.target.value)}
                      className="bg-gray-800 border-gray-600 text-white text-sm"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-white">Social Links (Optional)</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Twitter className="h-4 w-4 text-blue-400" />
                    <Input
                      placeholder="twitter_username"
                      value={onboardingData.socialLinks.twitter || ''}
                      onChange={(e) => handleSocialLinkChange('twitter', e.target.value)}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <Github className="h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="github_username"
                      value={onboardingData.socialLinks.github || ''}
                      onChange={(e) => handleSocialLinkChange('github', e.target.value)}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <Globe className="h-4 w-4 text-green-400" />
                    <Input
                      placeholder="https://yourwebsite.com"
                      value={onboardingData.socialLinks.website || ''}
                      onChange={(e) => handleSocialLinkChange('website', e.target.value)}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <Wallet className="h-16 w-16 text-green-400 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-2">Connect Your Wallet</h2>
              <p className="text-gray-400">Connect your wallet to participate in quests and earn rewards</p>
            </div>
            
            {!onboardingData.walletAddress ? (
              <div className="space-y-4">
                <Button
                  onClick={connectWallet}
                  className="w-full bg-green-600 hover:bg-green-700 h-12"
                >
                  <Wallet className="h-5 w-5 mr-2" />
                  Connect Wallet
                </Button>
                
                <div className="text-center">
                  <p className="text-sm text-gray-500">
                    Don't have a wallet? We recommend MetaMask or Coinbase Wallet
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-green-900/30 border border-green-600/50 rounded-lg p-4">
                  <div className="flex items-center space-x-3">
                    <CheckCircle2 className="h-6 w-6 text-green-400" />
                    <div>
                      <p className="text-white font-medium">Wallet Connected!</p>
                      <p className="text-sm text-gray-400 font-mono">{onboardingData.walletAddress}</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-800 p-4 rounded-lg">
                  <h4 className="text-white font-medium mb-2">What's Next?</h4>
                  <ul className="space-y-1 text-sm text-gray-400">
                    <li>• Participate in quests and challenges</li>
                    <li>• Earn XP and unlock achievements</li>
                    <li>• Connect with the community</li>
                    <li>• Track your progress on leaderboards</li>
                  </ul>
                </div>
              </div>
            )}
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <Target className="h-16 w-16 text-blue-400 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-2">Choose Your Interests</h2>
              <p className="text-gray-400">Select the types of quests you're most interested in</p>
            </div>
            
            <div className="space-y-4">
              <div>
                <Label className="text-white text-base mb-3 block">Quest Categories</Label>
                <div className="grid grid-cols-2 gap-3">
                  {questCategories.map((category) => (
                    <Button
                      key={category.categoryId}
                      variant="outline"
                      onClick={() => toggleCategory(category.categoryId)}
                      className={`h-16 flex flex-col items-center justify-center space-y-1 ${
                        onboardingData.preferences.categories.includes(category.categoryId)
                          ? 'border-purple-600 bg-purple-900/30 text-purple-300'
                          : 'border-gray-600 text-gray-300 hover:bg-gray-800'
                      }`}
                    >
                      <span className="text-lg">{category.iconUrl}</span>
                      <span className="text-sm font-medium">{category.name}</span>
                    </Button>
                  ))}
                </div>
              </div>
              
              <div>
                <Label className="text-white text-base mb-3 block">Difficulty Preference</Label>
                <div className="grid grid-cols-2 gap-3">
                  {Object.values(QuestDifficulty).map((difficulty) => (
                    <Button
                      key={difficulty}
                      variant="outline"
                      onClick={() => toggleDifficulty(difficulty)}
                      className={`h-12 ${
                        onboardingData.preferences.difficulty.includes(difficulty)
                          ? 'border-purple-600 bg-purple-900/30 text-purple-300'
                          : 'border-gray-600 text-gray-300 hover:bg-gray-800'
                      }`}
                    >
                      <Star className="h-4 w-4 mr-2" />
                      {difficulty}
                    </Button>
                  ))}
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  Don't worry, you can change these preferences later
                </p>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <Trophy className="h-16 w-16 text-yellow-400 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-2">You're All Set!</h2>
              <p className="text-gray-400">Welcome to DreamNet! Here's what you can do now:</p>
            </div>
            
            <div className="space-y-4">
              <div className="bg-gray-800 p-4 rounded-lg">
                <h4 className="text-white font-semibold mb-3">Your Profile Summary</h4>
                <div className="flex items-center space-x-4 mb-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={onboardingData.avatarUrl} />
                    <AvatarFallback className="bg-purple-600 text-white">
                      {onboardingData.handle.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-white font-medium">{onboardingData.handle}</p>
                    <p className="text-gray-400 text-sm">{onboardingData.bio || 'Ready to explore DreamNet!'}</p>
                  </div>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Wallet:</span>
                    <span className="text-green-400 font-mono text-xs">
                      {onboardingData.walletAddress?.slice(0, 6)}...{onboardingData.walletAddress?.slice(-4)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Interests:</span>
                    <span className="text-white">
                      {onboardingData.preferences.categories.length} categories selected
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Difficulty:</span>
                    <span className="text-white">
                      {onboardingData.preferences.difficulty.join(', ')}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Card className="bg-blue-900/30 border-blue-600/50">
                  <CardContent className="p-4 text-center">
                    <Target className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                    <h4 className="text-white font-medium">Start Quests</h4>
                    <p className="text-gray-400 text-sm">Explore available quests and start earning XP</p>
                  </CardContent>
                </Card>
                
                <Card className="bg-green-900/30 border-green-600/50">
                  <CardContent className="p-4 text-center">
                    <Trophy className="h-8 w-8 text-green-400 mx-auto mb-2" />
                    <h4 className="text-white font-medium">Earn Rewards</h4>
                    <p className="text-gray-400 text-sm">Complete challenges and unlock achievements</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );

      default:
        return <div></div>;
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-gray-900 border-gray-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl text-white flex items-center space-x-2">
              <Sparkles className="h-6 w-6 text-purple-400" />
              <span>Welcome to DreamNet</span>
            </CardTitle>
            <Badge variant="outline" className="text-gray-400 border-gray-600">
              Step {currentStep + 1} of {totalSteps}
            </Badge>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Setup Progress</span>
              <span className="text-white">{Math.round(progressPercentage)}%</span>
            </div>
            <Progress value={progressPercentage} className="h-2" />
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {renderStep()}
          
          <div className="flex justify-between pt-6 border-t border-gray-700">
            <Button
              onClick={handlePrevious}
              disabled={currentStep === 0}
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Previous
            </Button>
            
            <div className="space-x-2">
              {currentStep < totalSteps - 1 ? (
                <Button
                  onClick={handleNext}
                  disabled={!canProceed()}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  Next
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              ) : (
                <Button
                  onClick={handleComplete}
                  disabled={isSubmitting}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {isSubmitting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Setting up...
                    </>
                  ) : (
                    <>
                      <Trophy className="h-4 w-4 mr-2" />
                      Complete Setup
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}