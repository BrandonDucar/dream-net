'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  User, 
  Settings, 
  Trophy, 
  Zap, 
  Crown, 
  Star, 
  Award,
  Target,
  Users,
  Calendar,
  ExternalLink,
} from 'lucide-react';
import type { UserProfileRow } from '@/spacetime_module_bindings';

interface UserProfileProps {
  userProfile: UserProfileRow;
  userStats: {
    totalXp: number;
    level: number;
    activeQuests: number;
    completedQuests: number;
  };
}

export function UserProfile({ userProfile, userStats }: UserProfileProps): JSX.Element {
  const [showDetails, setShowDetails] = useState<boolean>(false);

  const getLevelProgress = (): number => {
    const currentLevelXp = (userStats.level - 1) * 1000;
    const nextLevelXp = userStats.level * 1000;
    const progressXp = userStats.totalXp - currentLevelXp;
    const neededXp = nextLevelXp - currentLevelXp;
    return (progressXp / neededXp) * 100;
  };

  const getLevelIcon = (level: number): JSX.Element => {
    if (level >= 50) return <Crown className="h-4 w-4 text-purple-400" />;
    if (level >= 25) return <Trophy className="h-4 w-4 text-yellow-400" />;
    if (level >= 10) return <Award className="h-4 w-4 text-blue-400" />;
    return <Star className="h-4 w-4 text-green-400" />;
  };

  const socialLinks = userProfile.socialLinks ? JSON.parse(userProfile.socialLinks) : {};

  if (showDetails) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
        <Card className="w-full max-w-2xl bg-gray-900 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-white flex items-center space-x-3">
              <User className="h-6 w-6" />
              <span>Profile Details</span>
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowDetails(false)}
              className="h-8 w-8 p-0"
            >
              ×
            </Button>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {/* Profile Header */}
            <div className="flex items-center space-x-4">
              <Avatar className="h-20 w-20">
                <AvatarImage src={userProfile.avatarUrl} />
                <AvatarFallback className="bg-purple-600 text-white text-xl">
                  {userProfile.handle.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h2 className="text-2xl font-bold text-white">{userProfile.handle}</h2>
                  <Badge className="bg-purple-600">
                    {getLevelIcon(userStats.level)}
                    <span className="ml-1">Level {userStats.level}</span>
                  </Badge>
                </div>
                <p className="text-gray-400">{userProfile.bio}</p>
                <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                  <span>{userProfile.followerCount} followers</span>
                  <span>{userProfile.followingCount} following</span>
                  <span>Joined {new Date(userProfile.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </div>

            {/* Level Progress */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">Level Progress</span>
                <span className="text-sm text-white">
                  {userStats.totalXp.toLocaleString()} / {(userStats.level * 1000).toLocaleString()} XP
                </span>
              </div>
              <Progress value={getLevelProgress()} className="h-2" />
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-4">
              <Card className="bg-gray-800 border-gray-600">
                <CardContent className="p-4 text-center">
                  <Zap className="h-8 w-8 text-yellow-400 mx-auto mb-2" />
                  <p className="text-lg font-bold text-white">{userStats.totalXp.toLocaleString()}</p>
                  <p className="text-sm text-gray-400">Total XP</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-800 border-gray-600">
                <CardContent className="p-4 text-center">
                  <Crown className="h-8 w-8 text-purple-400 mx-auto mb-2" />
                  <p className="text-lg font-bold text-white">{userStats.level}</p>
                  <p className="text-sm text-gray-400">Level</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-800 border-gray-600">
                <CardContent className="p-4 text-center">
                  <Target className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                  <p className="text-lg font-bold text-white">{userStats.activeQuests}</p>
                  <p className="text-sm text-gray-400">Active Quests</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-800 border-gray-600">
                <CardContent className="p-4 text-center">
                  <Award className="h-8 w-8 text-green-400 mx-auto mb-2" />
                  <p className="text-lg font-bold text-white">{userStats.completedQuests}</p>
                  <p className="text-sm text-gray-400">Completed</p>
                </CardContent>
              </Card>
            </div>

            {/* Social Links */}
            {Object.keys(socialLinks).length > 0 && (
              <div>
                <h3 className="text-lg font-semibold text-white mb-3">Social Links</h3>
                <div className="space-y-2">
                  {socialLinks.twitter && (
                    <a 
                      href={`https://twitter.com/${socialLinks.twitter}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-2 text-blue-400 hover:text-blue-300"
                    >
                      <span>🐦</span>
                      <span>@{socialLinks.twitter}</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                  {socialLinks.github && (
                    <a 
                      href={`https://github.com/${socialLinks.github}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-2 text-gray-400 hover:text-gray-300"
                    >
                      <span>⚙️</span>
                      <span>{socialLinks.github}</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                  {socialLinks.website && (
                    <a 
                      href={socialLinks.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-2 text-green-400 hover:text-green-300"
                    >
                      <span>🌐</span>
                      <span>{socialLinks.website}</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex space-x-2">
              <Button className="flex-1 bg-purple-600 hover:bg-purple-700">
                <Settings className="h-4 w-4 mr-2" />
                Edit Profile
              </Button>
              <Button variant="outline" className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-800">
                <Users className="h-4 w-4 mr-2" />
                Find Friends
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <Button
      variant="ghost"
      onClick={() => setShowDetails(true)}
      className="h-auto p-2 hover:bg-gray-800"
    >
      <div className="flex items-center space-x-3">
        <Avatar className="h-8 w-8">
          <AvatarImage src={userProfile.avatarUrl} />
          <AvatarFallback className="bg-purple-600 text-white text-xs">
            {userProfile.handle.slice(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div className="text-left">
          <div className="flex items-center space-x-2">
            <span className="text-white text-sm font-medium">{userProfile.handle}</span>
            <Badge variant="outline" className="text-xs px-1 py-0">
              {getLevelIcon(userStats.level)}
              <span className="ml-1">{userStats.level}</span>
            </Badge>
          </div>
          <div className="flex items-center space-x-2 text-xs text-gray-400">
            <span>{userStats.totalXp.toLocaleString()} XP</span>
            <span>•</span>
            <span>{userStats.completedQuests} completed</span>
          </div>
        </div>
      </div>
    </Button>
  );
}