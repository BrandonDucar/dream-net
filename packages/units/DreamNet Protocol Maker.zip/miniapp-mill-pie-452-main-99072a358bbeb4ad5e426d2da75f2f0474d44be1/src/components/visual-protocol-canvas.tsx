'use client';

import { useCallback, useMemo } from 'react';
import ReactFlow, {
  Node,
  Edge,
  Controls,
  Background,
  BackgroundVariant,
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
  Panel,
  MiniMap,
} from 'reactflow';
import 'reactflow/dist/style.css';
import type { NetProtocol, NetNode as ProtocolNode, NetEdge as ProtocolEdge } from '@/types/netprotocol';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ZoomIn, ZoomOut, Maximize, LayoutGrid } from 'lucide-react';

interface VisualProtocolCanvasProps {
  protocol: NetProtocol;
  onNodeClick?: (node: ProtocolNode) => void;
  onEdgeClick?: (edge: ProtocolEdge, id: string) => void;
  onAddEdge?: (from: string, to: string) => void;
}

export function VisualProtocolCanvas({
  protocol,
  onNodeClick,
  onEdgeClick,
  onAddEdge,
}: VisualProtocolCanvasProps) {
  // Convert protocol nodes to React Flow nodes
  const initialNodes: Node[] = useMemo(() => {
    return protocol.nodes.map((node, index) => ({
      id: node.id,
      type: getNodeType(node.type),
      position: { x: (index % 4) * 250, y: Math.floor(index / 4) * 150 },
      data: { label: node.label, node },
      style: getNodeStyle(node.type, protocol.entry_points.includes(node.id)),
    }));
  }, [protocol.nodes, protocol.entry_points]);

  // Convert protocol edges to React Flow edges
  const initialEdges: Edge[] = useMemo(() => {
    return protocol.edges.map((edge, index) => ({
      id: `edge-${index}`,
      source: edge.from,
      target: edge.to,
      label: edge.condition !== 'always' ? edge.condition : '',
      type: 'smoothstep',
      animated: edge.condition !== 'always',
      style: { stroke: '#6b7280', strokeWidth: 2 },
    }));
  }, [protocol.edges]);

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  const onConnect = useCallback(
    (connection: Connection) => {
      if (connection.source && connection.target && onAddEdge) {
        onAddEdge(connection.source, connection.target);
      }
      setEdges((eds) => addEdge(connection, eds));
    },
    [setEdges, onAddEdge]
  );

  const onNodeClickHandler = useCallback(
    (_event: React.MouseEvent, node: Node) => {
      const protocolNode = protocol.nodes.find((n) => n.id === node.id);
      if (protocolNode && onNodeClick) {
        onNodeClick(protocolNode);
      }
    },
    [protocol.nodes, onNodeClick]
  );

  const onEdgeClickHandler = useCallback(
    (_event: React.MouseEvent, edge: Edge) => {
      const protocolEdge = protocol.edges.find(
        (e) => e.from === edge.source && e.to === edge.target
      );
      if (protocolEdge && onEdgeClick) {
        onEdgeClick(protocolEdge, edge.id);
      }
    },
    [protocol.edges, onEdgeClick]
  );

  return (
    <Card className="h-[600px] bg-gray-950 border-gray-800 overflow-hidden">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onNodeClick={onNodeClickHandler}
        onEdgeClick={onEdgeClickHandler}
        fitView
        className="bg-gray-950"
      >
        <Background variant={BackgroundVariant.Dots} gap={12} size={1} color="#374151" />
        <Controls className="bg-gray-800 border-gray-700" />
        <MiniMap
          nodeColor={(node) => {
            const protocolNode = protocol.nodes.find((n) => n.id === node.id);
            if (!protocolNode) return '#6b7280';
            return getNodeColor(protocolNode.type, protocol.entry_points.includes(node.id));
          }}
          className="bg-gray-800 border-gray-700"
          maskColor="rgba(0, 0, 0, 0.6)"
        />
        <Panel position="top-right" className="flex gap-2">
          <Button size="sm" variant="outline" className="bg-gray-800 border-gray-700 text-gray-300">
            <LayoutGrid className="h-4 w-4 mr-2" />
            Auto Layout
          </Button>
        </Panel>
      </ReactFlow>
    </Card>
  );
}

function getNodeType(protocolType: string): string {
  switch (protocolType) {
    case 'entry':
      return 'input';
    case 'exit':
      return 'output';
    default:
      return 'default';
  }
}

function getNodeStyle(type: string, isEntryPoint: boolean): Record<string, unknown> {
  const baseStyle = {
    padding: '10px 20px',
    borderRadius: '8px',
    border: '2px solid',
    fontSize: '14px',
    fontWeight: 500,
  };

  if (isEntryPoint) {
    return {
      ...baseStyle,
      backgroundColor: '#10b981',
      color: '#ffffff',
      borderColor: '#059669',
    };
  }

  switch (type) {
    case 'entry':
      return {
        ...baseStyle,
        backgroundColor: '#10b981',
        color: '#ffffff',
        borderColor: '#059669',
      };
    case 'funnel':
      return {
        ...baseStyle,
        backgroundColor: '#3b82f6',
        color: '#ffffff',
        borderColor: '#2563eb',
      };
    case 'ritual_ref':
      return {
        ...baseStyle,
        backgroundColor: '#8b5cf6',
        color: '#ffffff',
        borderColor: '#7c3aed',
      };
    case 'action':
      return {
        ...baseStyle,
        backgroundColor: '#f59e0b',
        color: '#ffffff',
        borderColor: '#d97706',
      };
    case 'reward':
      return {
        ...baseStyle,
        backgroundColor: '#ec4899',
        color: '#ffffff',
        borderColor: '#db2777',
      };
    case 'exit':
      return {
        ...baseStyle,
        backgroundColor: '#ef4444',
        color: '#ffffff',
        borderColor: '#dc2626',
      };
    default:
      return {
        ...baseStyle,
        backgroundColor: '#6b7280',
        color: '#ffffff',
        borderColor: '#4b5563',
      };
  }
}

function getNodeColor(type: string, isEntryPoint: boolean): string {
  if (isEntryPoint) return '#10b981';

  switch (type) {
    case 'entry':
      return '#10b981';
    case 'funnel':
      return '#3b82f6';
    case 'ritual_ref':
      return '#8b5cf6';
    case 'action':
      return '#f59e0b';
    case 'reward':
      return '#ec4899';
    case 'exit':
      return '#ef4444';
    default:
      return '#6b7280';
  }
}
