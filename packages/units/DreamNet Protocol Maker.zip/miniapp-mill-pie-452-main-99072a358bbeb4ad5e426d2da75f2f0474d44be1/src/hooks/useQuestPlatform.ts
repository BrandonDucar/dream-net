'use client';

import { useEffect, useState } from 'react';
import {
  DbConnection,
  tables,
  reducers,
  type QuestRow,
  type QuestInstanceRow,
  type UserProfileRow,
  type QuestCategoryRow,
  type TaskDefinitionRow,
  type RewardPoolRow,
  type QuestTemplateRow,
  QuestDifficulty,
  QuestStatus,
  QuestProgressState,
  RewardAssetKind,
  TaskType,
  VerificationMethod,
  ReviewStatus,
} from '../spacetime_module_bindings';

interface QuestPlatformState {
  isConnected: boolean;
  identity: string | null;
  userProfile: UserProfileRow | null;
  publishedQuests: QuestRow[];
  userQuestInstances: QuestInstanceRow[];
  questCategories: QuestCategoryRow[];
  questTemplates: QuestTemplateRow[];
  rewardPools: RewardPoolRow[];
}

export const useQuestPlatform = () => {
  const [db, setDb] = useState<DbConnection | null>(null);
  const [state, setState] = useState<QuestPlatformState>({
    isConnected: false,
    identity: null,
    userProfile: null,
    publishedQuests: [],
    userQuestInstances: [],
    questCategories: [],
    questTemplates: [],
    rewardPools: [],
  });

  useEffect(() => {
    const initDb = async () => {
      try {
        // For now, simulate database connection with local state
        // Real SpacetimeDB connection would be:
        // const connection = await DbConnection.builder()
        //   .withUri('wss://testnet.spacetimedb.com')
        //   .withModuleName('quest-platform-db')
        //   .build();

        // Import seed data for demonstration
        const { sampleQuests, questCategories, questTemplates, rewardPools } = await import('../lib/seedData');
        
        // Simulate successful connection
        const mockConnection = {
          identity: { toHexString: () => 'mock-identity-123', isEqual: (other: any) => other === 'mock-identity-123' }
        };
        
        setDb(mockConnection as any);

        // Load mock data
        setState((prev) => ({
          ...prev,
          publishedQuests: sampleQuests.filter((q: any) => q.status === 'Published') as any,
          questCategories: questCategories as any,
          questTemplates: questTemplates.filter((t: any) => t.isPublic) as any,
          rewardPools: rewardPools as any,
          userQuestInstances: [], // Empty initially - will be populated when user joins quests
          userProfile: null, // Will be set after onboarding
        }));

        // Update connection state
        setState((prev) => ({
          ...prev,
          isConnected: true,
          identity: mockConnection.identity.toHexString(),
        }));

      } catch (error) {
        console.error('Failed to connect to SpacetimeDB:', error);
      }
    };

    initDb();
  }, []);

  // User Management
  const registerUser = async (data: {
    handle: string;
    walletAddress: string;
    bio: string;
    avatarUrl: string;
    socialLinks: string;
  }) => {
    if (!db) throw new Error('Database not connected');
    return reducers.registerUser(db, data);
  };

  const updateUserProfile = async (data: {
    handle: string;
    bio: string;
    avatarUrl: string;
    socialLinks: string;
  }) => {
    if (!db) throw new Error('Database not connected');
    return reducers.updateUserProfile(db, data);
  };

  const followUser = async (targetIdentity: string) => {
    if (!db) throw new Error('Database not connected');
    return reducers.followUser(db, { target: targetIdentity });
  };

  // Quest Management
  const createQuest = async (data: {
    questId: string;
    categoryId: string;
    title: string;
    summary: string;
    difficulty: QuestDifficulty;
    estimatedMinutes: number;
    rewardPoolId: string;
    metadata: string;
    startsAt: Date;
    endsAt: Date;
  }) => {
    if (!db) throw new Error('Database not connected');
    return reducers.createQuest(db, {
      ...data,
      startsAt: data.startsAt.getTime(),
      endsAt: data.endsAt.getTime(),
    });
  };

  const publishQuest = async (questId: string) => {
    if (!db) throw new Error('Database not connected');
    return reducers.publishQuest(db, { questId });
  };

  const joinQuest = async (questId: string, guildId?: string) => {
    if (!db) throw new Error('Database not connected');
    return reducers.joinQuest(db, { questId, guildId: guildId || null });
  };

  const likeQuest = async (questId: string) => {
    if (!db) throw new Error('Database not connected');
    return reducers.likeQuest(db, { questId });
  };

  const commentOnQuest = async (commentId: string, questId: string, content: string) => {
    if (!db) throw new Error('Database not connected');
    return reducers.commentOnQuest(db, { commentId, questId, content });
  };

  // Task Management
  const submitTaskResult = async (taskId: string, instanceId: number, evidencePayload: string) => {
    if (!db) throw new Error('Database not connected');
    return reducers.submitTaskResult(db, { taskId, instanceId, evidencePayload });
  };

  const reviewTaskSubmission = async (completionId: number, status: ReviewStatus, reviewerNotes: string) => {
    if (!db) throw new Error('Database not connected');
    return reducers.reviewTaskSubmission(db, { completionId, status, reviewerNotes });
  };

  // Guild Management
  const createGuild = async (data: {
    guildId: string;
    name: string;
    description: string;
    crestUrl: string;
    inviteCode: string;
  }) => {
    if (!db) throw new Error('Database not connected');
    return reducers.createGuild(db, data);
  };

  const joinGuild = async (guildId: string) => {
    if (!db) throw new Error('Database not connected');
    return reducers.joinGuild(db, { guildId });
  };

  // Utilities
  const getQuestById = (questId: string): QuestRow | undefined => {
    return state.publishedQuests.find(q => q.questId === questId);
  };

  const getUserQuestInstance = (questId: string): QuestInstanceRow | undefined => {
    return state.userQuestInstances.find(qi => qi.questId === questId);
  };

  const isQuestJoined = (questId: string): boolean => {
    return state.userQuestInstances.some(qi => qi.questId === questId);
  };

  const getCategoryById = (categoryId: string): QuestCategoryRow | undefined => {
    return state.questCategories.find(c => c.categoryId === categoryId);
  };

  return {
    // State
    ...state,
    db,
    
    // User Management
    registerUser,
    updateUserProfile,
    followUser,
    
    // Quest Management
    createQuest,
    publishQuest,
    joinQuest,
    likeQuest,
    commentOnQuest,
    
    // Task Management
    submitTaskResult,
    reviewTaskSubmission,
    
    // Guild Management
    createGuild,
    joinGuild,
    
    // Utilities
    getQuestById,
    getUserQuestInstance,
    isQuestJoined,
    getCategoryById,
    
    // Enums for UI
    QuestDifficulty,
    QuestStatus,
    QuestProgressState,
    RewardAssetKind,
    TaskType,
    VerificationMethod,
    ReviewStatus,
  };
};