import { useEffect, useState, useCallback, useRef } from 'react';
import type { DbConnection } from '@/spacetime_module_bindings';
import type { Protocol, Node as DBNode, Edge as DBEdge, ProtocolTemplate, ProtocolVersion, ProtocolAnalytics, CustomNodeType, ProtocolComment, Webhook, ProtocolTag } from '@/spacetime_module_bindings';

interface UseSpacetimeDBReturn {
  connection: DbConnection | null;
  connected: boolean;
  statusMessage: string;
  protocols: Map<string, Protocol>;
  nodes: Map<string, DBNode>;
  edges: Map<string, DBEdge>;
  templates: Map<string, ProtocolTemplate>;
  versions: Map<string, ProtocolVersion>;
  analytics: Map<string, ProtocolAnalytics>;
  customNodeTypes: Map<string, CustomNodeType>;
  comments: Map<string, ProtocolComment>;
  webhooks: Map<string, Webhook>;
  tags: Map<string, ProtocolTag>;
}

export function useSpacetimeDB(): UseSpacetimeDBReturn {
  const [connection, setConnection] = useState<DbConnection | null>(null);
  const [connected, setConnected] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('Connecting to database...');
  
  const [protocols, setProtocols] = useState<Map<string, Protocol>>(new Map());
  const [nodes, setNodes] = useState<Map<string, DBNode>>(new Map());
  const [edges, setEdges] = useState<Map<string, DBEdge>>(new Map());
  const [templates, setTemplates] = useState<Map<string, ProtocolTemplate>>(new Map());
  const [versions, setVersions] = useState<Map<string, ProtocolVersion>>(new Map());
  const [analytics, setAnalytics] = useState<Map<string, ProtocolAnalytics>>(new Map());
  const [customNodeTypes, setCustomNodeTypes] = useState<Map<string, CustomNodeType>>(new Map());
  const [comments, setComments] = useState<Map<string, ProtocolComment>>(new Map());
  const [webhooks, setWebhooks] = useState<Map<string, Webhook>>(new Map());
  const [tags, setTags] = useState<Map<string, ProtocolTag>>(new Map());
  
  const hasInitialized = useRef<boolean>(false);

  const refreshProtocols = useCallback((conn: DbConnection) => {
    const newProtocols = new Map<string, Protocol>();
    for (const protocol of conn.db.protocolTable.iter()) {
      newProtocols.set(protocol.protocolId, protocol);
    }
    setProtocols(newProtocols);
  }, []);

  const refreshNodes = useCallback((conn: DbConnection) => {
    const newNodes = new Map<string, DBNode>();
    for (const node of conn.db.nodeTable.iter()) {
      newNodes.set(node.nodeId, node);
    }
    setNodes(newNodes);
  }, []);

  const refreshEdges = useCallback((conn: DbConnection) => {
    const newEdges = new Map<string, DBEdge>();
    for (const edge of conn.db.edgeTable.iter()) {
      newEdges.set(edge.edgeId.toString(), edge);
    }
    setEdges(newEdges);
  }, []);

  const refreshTemplates = useCallback((conn: DbConnection) => {
    const newTemplates = new Map<string, ProtocolTemplate>();
    for (const template of conn.db.protocolTemplateTable.iter()) {
      newTemplates.set(template.templateId, template);
    }
    setTemplates(newTemplates);
  }, []);

  const refreshVersions = useCallback((conn: DbConnection) => {
    const newVersions = new Map<string, ProtocolVersion>();
    for (const version of conn.db.protocolVersionTable.iter()) {
      newVersions.set(version.versionId, version);
    }
    setVersions(newVersions);
  }, []);

  const refreshAnalytics = useCallback((conn: DbConnection) => {
    const newAnalytics = new Map<string, ProtocolAnalytics>();
    for (const analytic of conn.db.protocolAnalyticsTable.iter()) {
      newAnalytics.set(analytic.analyticsId, analytic);
    }
    setAnalytics(newAnalytics);
  }, []);

  const refreshCustomNodeTypes = useCallback((conn: DbConnection) => {
    const newCustomNodeTypes = new Map<string, CustomNodeType>();
    for (const customNodeType of conn.db.customNodeTypeTable.iter()) {
      newCustomNodeTypes.set(customNodeType.customTypeId, customNodeType);
    }
    setCustomNodeTypes(newCustomNodeTypes);
  }, []);

  const refreshComments = useCallback((conn: DbConnection) => {
    const newComments = new Map<string, ProtocolComment>();
    for (const comment of conn.db.protocolCommentTable.iter()) {
      newComments.set(comment.commentId, comment);
    }
    setComments(newComments);
  }, []);

  const refreshWebhooks = useCallback((conn: DbConnection) => {
    const newWebhooks = new Map<string, Webhook>();
    for (const webhook of conn.db.webhookTable.iter()) {
      newWebhooks.set(webhook.webhookId, webhook);
    }
    setWebhooks(newWebhooks);
  }, []);

  const refreshTags = useCallback((conn: DbConnection) => {
    const newTags = new Map<string, ProtocolTag>();
    for (const tag of conn.db.protocolTagTable.iter()) {
      newTags.set(tag.tagId, tag);
    }
    setTags(newTags);
  }, []);

  useEffect(() => {
    if (hasInitialized.current) {
      return;
    }

    hasInitialized.current = true;

    const initializeConnection = async () => {
      try {
        const { DbConnection } = await import('@/spacetime_module_bindings');
        
        const newConnection = await DbConnection.builder()
          .withUri(process.env.NEXT_PUBLIC_SPACETIME_URL || '')
          .onConnect((conn, _identity, _token) => {
            setConnected(true);
            setStatusMessage('Connected to database');
            
            conn.db.protocolTable.onInsert(() => refreshProtocols(conn));
            conn.db.protocolTable.onUpdate(() => refreshProtocols(conn));
            conn.db.protocolTable.onDelete(() => refreshProtocols(conn));
            
            conn.db.nodeTable.onInsert(() => refreshNodes(conn));
            conn.db.nodeTable.onUpdate(() => refreshNodes(conn));
            conn.db.nodeTable.onDelete(() => refreshNodes(conn));
            
            conn.db.edgeTable.onInsert(() => refreshEdges(conn));
            conn.db.edgeTable.onUpdate(() => refreshEdges(conn));
            conn.db.edgeTable.onDelete(() => refreshEdges(conn));

            conn.db.protocolTemplateTable.onInsert(() => refreshTemplates(conn));
            conn.db.protocolTemplateTable.onUpdate(() => refreshTemplates(conn));
            conn.db.protocolTemplateTable.onDelete(() => refreshTemplates(conn));

            conn.db.protocolVersionTable.onInsert(() => refreshVersions(conn));
            conn.db.protocolVersionTable.onUpdate(() => refreshVersions(conn));
            conn.db.protocolVersionTable.onDelete(() => refreshVersions(conn));

            conn.db.protocolAnalyticsTable.onInsert(() => refreshAnalytics(conn));
            conn.db.protocolAnalyticsTable.onUpdate(() => refreshAnalytics(conn));
            conn.db.protocolAnalyticsTable.onDelete(() => refreshAnalytics(conn));

            conn.db.customNodeTypeTable.onInsert(() => refreshCustomNodeTypes(conn));
            conn.db.customNodeTypeTable.onUpdate(() => refreshCustomNodeTypes(conn));
            conn.db.customNodeTypeTable.onDelete(() => refreshCustomNodeTypes(conn));

            conn.db.protocolCommentTable.onInsert(() => refreshComments(conn));
            conn.db.protocolCommentTable.onUpdate(() => refreshComments(conn));
            conn.db.protocolCommentTable.onDelete(() => refreshComments(conn));

            conn.db.webhookTable.onInsert(() => refreshWebhooks(conn));
            conn.db.webhookTable.onUpdate(() => refreshWebhooks(conn));
            conn.db.webhookTable.onDelete(() => refreshWebhooks(conn));

            conn.db.protocolTagTable.onInsert(() => refreshTags(conn));
            conn.db.protocolTagTable.onUpdate(() => refreshTags(conn));
            conn.db.protocolTagTable.onDelete(() => refreshTags(conn));
            
            refreshProtocols(conn);
            refreshNodes(conn);
            refreshEdges(conn);
            refreshTemplates(conn);
            refreshVersions(conn);
            refreshAnalytics(conn);
            refreshCustomNodeTypes(conn);
            refreshComments(conn);
            refreshWebhooks(conn);
            refreshTags(conn);
          })
          .onError((err) => {
            setConnected(false);
            setStatusMessage(`Database error: ${err}`);
          })
          .build();

        setConnection(newConnection);
      } catch (error) {
        setConnected(false);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setStatusMessage(`Failed to initialize connection: ${errorMessage}`);
      }
    };

    initializeConnection();
  }, [refreshProtocols, refreshNodes, refreshEdges, refreshTemplates, refreshVersions, refreshAnalytics, refreshCustomNodeTypes, refreshComments, refreshWebhooks, refreshTags]);

  return {
    connection,
    connected,
    statusMessage,
    protocols,
    nodes,
    edges,
    templates,
    versions,
    analytics,
    customNodeTypes,
    comments,
    webhooks,
    tags,
  };
}
