import type { NetProtocol, NetNode, NetEdge } from '@/types/netprotocol';
import Papa from 'papaparse';

export interface ImportResult {
  success: boolean;
  protocol?: NetProtocol;
  error?: string;
}

export function exportToCSV(protocol: NetProtocol): { nodes: string; edges: string } {
  const nodesData = protocol.nodes.map((node) => ({
    id: node.id,
    type: node.type,
    label: node.label,
    ...node,
  }));

  const edgesData = protocol.edges.map((edge) => ({
    from: edge.from,
    to: edge.to,
    condition: edge.condition,
    notes: edge.notes || '',
  }));

  const nodesCsv = Papa.unparse(nodesData);
  const edgesCsv = Papa.unparse(edgesData);

  return { nodes: nodesCsv, edges: edgesCsv };
}

export function importFromCSV(nodesCSV: string, edgesCSV: string, protocolId: string, name: string): ImportResult {
  try {
    const nodesParsed = Papa.parse<Record<string, string>>(nodesCSV, { header: true });
    const edgesParsed = Papa.parse<Record<string, string>>(edgesCSV, { header: true });

    if (nodesParsed.errors.length > 0) {
      return {
        success: false,
        error: `Error parsing nodes CSV: ${nodesParsed.errors[0].message}`,
      };
    }

    if (edgesParsed.errors.length > 0) {
      return {
        success: false,
        error: `Error parsing edges CSV: ${edgesParsed.errors[0].message}`,
      };
    }

    const nodes: NetNode[] = nodesParsed.data
      .filter((row) => row.id && row.type)
      .map((row) => {
        const baseNode = {
          id: row.id,
          type: row.type as NetNode['type'],
          label: row.label || row.id,
        };

        // Parse type-specific data (simplified)
        return baseNode as NetNode;
      });

    const edges: NetEdge[] = edgesParsed.data
      .filter((row) => row.from && row.to)
      .map((row) => ({
        from: row.from,
        to: row.to,
        condition: row.condition || 'always',
        notes: row.notes,
      }));

    const protocol: NetProtocol = {
      protocol_id: protocolId,
      name,
      description: 'Imported from CSV',
      version: 1,
      status: 'draft',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      entry_points: [],
      nodes,
      edges,
    };

    return {
      success: true,
      protocol,
    };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

export function exportToMermaid(protocol: NetProtocol): string {
  let mermaid = 'graph TD\n';

  // Add nodes
  for (const node of protocol.nodes) {
    const shape = getNodeShape(node.type);
    mermaid += `  ${node.id}${shape.start}"${node.label}"${shape.end}\n`;
  }

  // Add edges
  for (const edge of protocol.edges) {
    const label = edge.condition !== 'always' ? `|${edge.condition}|` : '';
    mermaid += `  ${edge.from} -->${label} ${edge.to}\n`;
  }

  // Style entry nodes
  for (const entryId of protocol.entry_points) {
    mermaid += `  style ${entryId} fill:#4ade80\n`;
  }

  // Style exit nodes
  for (const node of protocol.nodes) {
    if (node.type === 'exit') {
      mermaid += `  style ${node.id} fill:#f87171\n`;
    }
  }

  return mermaid;
}

function getNodeShape(type: string): { start: string; end: string } {
  switch (type) {
    case 'entry':
      return { start: '([', end: '])' };
    case 'exit':
      return { start: '[[', end: ']]' };
    case 'funnel':
      return { start: '[/', end: '/]' };
    case 'ritual_ref':
      return { start: '{{', end: '}}' };
    case 'action':
      return { start: '[', end: ']' };
    case 'reward':
      return { start: '>', end: ']' };
    default:
      return { start: '[', end: ']' };
  }
}

export function downloadJSON(protocol: NetProtocol): void {
  const json = JSON.stringify(protocol, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${protocol.protocol_id}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

export function downloadCSV(protocol: NetProtocol): void {
  const { nodes, edges } = exportToCSV(protocol);

  const nodesBlob = new Blob([nodes], { type: 'text/csv' });
  const edgesBlob = new Blob([edges], { type: 'text/csv' });

  const nodesUrl = URL.createObjectURL(nodesBlob);
  const edgesUrl = URL.createObjectURL(edgesBlob);

  const nodesLink = document.createElement('a');
  nodesLink.href = nodesUrl;
  nodesLink.download = `${protocol.protocol_id}_nodes.csv`;
  nodesLink.click();

  const edgesLink = document.createElement('a');
  edgesLink.href = edgesUrl;
  edgesLink.download = `${protocol.protocol_id}_edges.csv`;
  edgesLink.click();

  URL.revokeObjectURL(nodesUrl);
  URL.revokeObjectURL(edgesUrl);
}

export function downloadMermaid(protocol: NetProtocol): void {
  const mermaid = exportToMermaid(protocol);
  const blob = new Blob([mermaid], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${protocol.protocol_id}.mmd`;
  a.click();
  URL.revokeObjectURL(url);
}
