import type { NetProtocol, NetNode, NetEdge } from '@/types/netprotocol';

export interface SimulationResult {
  success: boolean;
  path: string[];
  visitedNodes: string[];
  failureReason?: string;
  warnings: string[];
}

export interface SimulationMetrics {
  totalPaths: number;
  successfulPaths: number;
  averagePathLength: number;
  dropOffPoints: Record<string, number>;
  conversionRate: number;
}

export function simulateUserFlow(
  protocol: NetProtocol,
  startNodeId?: string,
  conditions: Record<string, boolean> = {}
): SimulationResult {
  const warnings: string[] = [];
  const path: string[] = [];
  const visitedNodes = new Set<string>();

  // Determine starting node
  let currentNodeId: string | null = null;

  if (startNodeId) {
    currentNodeId = startNodeId;
  } else if (protocol.entry_points.length > 0) {
    currentNodeId = protocol.entry_points[0];
  } else {
    return {
      success: false,
      path: [],
      visitedNodes: [],
      failureReason: 'No entry point available',
      warnings,
    };
  }

  const maxSteps = 100; // Prevent infinite loops
  let steps = 0;

  while (currentNodeId && steps < maxSteps) {
    steps++;

    // Add current node to path
    path.push(currentNodeId);
    visitedNodes.add(currentNodeId);

    // Find current node
    const currentNode = protocol.nodes.find((n) => n.id === currentNodeId);
    if (!currentNode) {
      return {
        success: false,
        path,
        visitedNodes: Array.from(visitedNodes),
        failureReason: `Node '${currentNodeId}' not found`,
        warnings,
      };
    }

    // Check if we reached an exit node
    if (currentNode.type === 'exit') {
      const exitNode = currentNode as Extract<NetNode, { type: 'exit' }>;
      const isSuccess = exitNode.exit_kind === 'success';
      return {
        success: isSuccess,
        path,
        visitedNodes: Array.from(visitedNodes),
        failureReason: isSuccess ? undefined : `Exited with status: ${exitNode.exit_kind}`,
        warnings,
      };
    }

    // Find outgoing edges
    const outgoingEdges = protocol.edges.filter((e) => e.from === currentNodeId);

    if (outgoingEdges.length === 0) {
      return {
        success: false,
        path,
        visitedNodes: Array.from(visitedNodes),
        failureReason: `Dead end at node '${currentNodeId}' (no outgoing edges)`,
        warnings,
      };
    }

    // Select next edge based on conditions
    let nextEdge: NetEdge | null = null;

    for (const edge of outgoingEdges) {
      if (evaluateCondition(edge.condition, conditions, currentNode)) {
        nextEdge = edge;
        break;
      }
    }

    // If no edge matches, try "always" condition
    if (!nextEdge) {
      nextEdge = outgoingEdges.find((e) => e.condition === 'always') || outgoingEdges[0];
    }

    if (!nextEdge) {
      return {
        success: false,
        path,
        visitedNodes: Array.from(visitedNodes),
        failureReason: `No valid edge from node '${currentNodeId}'`,
        warnings,
      };
    }

    currentNodeId = nextEdge.to;

    // Check for cycles
    if (visitedNodes.has(currentNodeId)) {
      warnings.push(`Cycle detected at node '${currentNodeId}'`);
    }
  }

  if (steps >= maxSteps) {
    return {
      success: false,
      path,
      visitedNodes: Array.from(visitedNodes),
      failureReason: 'Maximum steps exceeded (possible infinite loop)',
      warnings,
    };
  }

  return {
    success: false,
    path,
    visitedNodes: Array.from(visitedNodes),
    failureReason: 'Unexpected termination',
    warnings,
  };
}

function evaluateCondition(
  condition: string,
  userConditions: Record<string, boolean>,
  currentNode: NetNode
): boolean {
  // Simple condition evaluation
  if (condition === 'always') return true;

  // Check user-provided conditions
  if (condition in userConditions) {
    return userConditions[condition];
  }

  // Default condition matching
  if (condition === 'requirements_met' && currentNode.type === 'funnel') {
    return true; // Assume requirements are met for simulation
  }

  if (condition === 'ritual_completed' && currentNode.type === 'ritual_ref') {
    return true; // Assume ritual is completed for simulation
  }

  if (condition === 'failed') {
    return false; // Fail condition
  }

  // Default to true for unknown conditions
  return true;
}

export function calculateSimulationMetrics(
  protocol: NetProtocol,
  numSimulations: number = 100
): SimulationMetrics {
  const results: SimulationResult[] = [];
  const dropOffPoints: Record<string, number> = {};

  for (let i = 0; i < numSimulations; i++) {
    const result = simulateUserFlow(protocol);
    results.push(result);

    // Track drop-off points
    if (!result.success && result.path.length > 0) {
      const lastNode = result.path[result.path.length - 1];
      dropOffPoints[lastNode] = (dropOffPoints[lastNode] || 0) + 1;
    }
  }

  const successfulPaths = results.filter((r) => r.success).length;
  const totalPathLength = results.reduce((sum, r) => sum + r.path.length, 0);

  return {
    totalPaths: results.length,
    successfulPaths,
    averagePathLength: totalPathLength / results.length,
    dropOffPoints,
    conversionRate: (successfulPaths / results.length) * 100,
  };
}
