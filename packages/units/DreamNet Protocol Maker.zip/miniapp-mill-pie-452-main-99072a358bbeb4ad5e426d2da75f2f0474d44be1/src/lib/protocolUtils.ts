import type { Timestamp } from 'spacetimedb';
import type { NetProtocol, NetNode, NetEdge, NodeType as ClientNodeType, ProtocolStatus as ClientProtocolStatus } from '@/types/netprotocol';
import type { Protocol, Node, Edge, NodeType as DBNodeType, ProtocolStatus as DBProtocolStatus } from '@/spacetime_module_bindings';

// Convert DB status to client status
export function dbStatusToClient(status: DBProtocolStatus): ClientProtocolStatus {
  if (status.tag === "Draft") return "draft";
  if (status.tag === "Active") return "active";
  if (status.tag === "Archived") return "archived";
  return "draft";
}

// Convert client status to DB status
export function clientStatusToDB(status: ClientProtocolStatus): DBProtocolStatus {
  if (status === "draft") return { tag: "Draft" };
  if (status === "active") return { tag: "Active" };
  if (status === "archived") return { tag: "Archived" };
  return { tag: "Draft" };
}

// Convert DB node type to client node type
export function dbNodeTypeToClient(type: DBNodeType): ClientNodeType {
  if (type.tag === "Entry") return "entry";
  if (type.tag === "Funnel") return "funnel";
  if (type.tag === "RitualRef") return "ritual_ref";
  if (type.tag === "Action") return "action";
  if (type.tag === "Reward") return "reward";
  if (type.tag === "Exit") return "exit";
  return "entry";
}

// Convert client node type to DB node type
export function clientNodeTypeToDB(type: ClientNodeType): DBNodeType {
  if (type === "entry") return { tag: "Entry" };
  if (type === "funnel") return { tag: "Funnel" };
  if (type === "ritual_ref") return { tag: "RitualRef" };
  if (type === "action") return { tag: "Action" };
  if (type === "reward") return { tag: "Reward" };
  if (type === "exit") return { tag: "Exit" };
  return { tag: "Entry" };
}

// Convert Timestamp to ISO string
export function timestampToISO(timestamp: Timestamp): string {
  return timestamp.toDate().toISOString();
}

// Convert DB protocol to client protocol
export function dbProtocolToClient(
  protocol: Protocol,
  nodes: Node[],
  edges: Edge[]
): NetProtocol {
  const entryPoints: string[] = JSON.parse(protocol.entryPoints);

  const clientNodes: NetNode[] = nodes.map((node: Node) => {
    const baseNode = {
      id: node.nodeId,
      type: dbNodeTypeToClient(node.nodeType),
      label: node.label,
    };

    const nodeData = JSON.parse(node.nodeData);

    return {
      ...baseNode,
      ...nodeData,
    } as NetNode;
  });

  const clientEdges: NetEdge[] = edges.map((edge: Edge) => ({
    from: edge.fromNodeId,
    to: edge.toNodeId,
    condition: edge.condition,
    notes: edge.notes || undefined,
  }));

  return {
    protocol_id: protocol.protocolId,
    name: protocol.name,
    description: protocol.description,
    version: protocol.version,
    status: dbStatusToClient(protocol.status),
    created_at: timestampToISO(protocol.createdAt),
    updated_at: timestampToISO(protocol.updatedAt),
    entry_points: entryPoints,
    nodes: clientNodes,
    edges: clientEdges,
  };
}
