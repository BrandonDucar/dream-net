import type { NetProtocol, NetNode, NetEdge } from '@/types/netprotocol';

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  healthScore: number;
}

export interface HealthMetrics {
  score: number;
  hasEntryPoints: boolean;
  hasExitNodes: boolean;
  noOrphanNodes: boolean;
  noCycles: boolean;
  allEdgesValid: boolean;
}

export function validateProtocol(protocol: NetProtocol): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Check for protocol_id and name
  if (!protocol.protocol_id || !protocol.protocol_id.trim()) {
    errors.push('Protocol ID is required');
  }
  if (!protocol.name || !protocol.name.trim()) {
    errors.push('Protocol name is required');
  }

  // Check for entry points
  if (protocol.entry_points.length === 0) {
    warnings.push('No entry points defined');
  } else {
    // Validate entry points reference existing nodes
    for (const entryId of protocol.entry_points) {
      if (!protocol.nodes.find((n) => n.id === entryId)) {
        errors.push(`Entry point '${entryId}' references non-existent node`);
      }
    }
  }

  // Validate edges
  const nodeIds = new Set(protocol.nodes.map((n) => n.id));
  for (const edge of protocol.edges) {
    if (!nodeIds.has(edge.from)) {
      errors.push(`Edge references non-existent source node: ${edge.from}`);
    }
    if (!nodeIds.has(edge.to)) {
      errors.push(`Edge references non-existent target node: ${edge.to}`);
    }
  }

  // Check for orphan nodes (nodes with no incoming or outgoing edges, except entry nodes)
  const orphanNodes = findOrphanNodes(protocol);
  if (orphanNodes.length > 0) {
    warnings.push(`${orphanNodes.length} orphan node(s) detected: ${orphanNodes.join(', ')}`);
  }

  // Check for cycles
  const cycles = detectCycles(protocol);
  if (cycles.length > 0) {
    warnings.push(`${cycles.length} cycle(s) detected in protocol flow`);
  }

  // Check for exit nodes
  const hasExitNodes = protocol.nodes.some((n) => n.type === 'exit');
  if (!hasExitNodes) {
    warnings.push('No exit nodes defined');
  }

  // Calculate health score
  const healthScore = calculateHealthScore(protocol, errors, warnings);

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
    healthScore,
  };
}

export function calculateHealthScore(protocol: NetProtocol, errors: string[], warnings: string[]): number {
  let score = 100;

  // Deduct for errors
  score -= errors.length * 20;

  // Deduct for warnings
  score -= warnings.length * 5;

  // Bonus points for good practices
  if (protocol.entry_points.length > 0) score += 5;
  if (protocol.nodes.some((n) => n.type === 'exit')) score += 5;
  if (protocol.edges.length > 0) score += 5;
  if (protocol.nodes.length >= 3) score += 5;

  return Math.max(0, Math.min(100, score));
}

export function findOrphanNodes(protocol: NetProtocol): string[] {
  const orphans: string[] = [];
  const entryPointSet = new Set(protocol.entry_points);

  for (const node of protocol.nodes) {
    // Skip entry nodes
    if (entryPointSet.has(node.id)) continue;

    const hasIncoming = protocol.edges.some((e) => e.to === node.id);
    const hasOutgoing = protocol.edges.some((e) => e.from === node.id);

    if (!hasIncoming && !hasOutgoing) {
      orphans.push(node.id);
    }
  }

  return orphans;
}

export function detectCycles(protocol: NetProtocol): string[][] {
  const cycles: string[][] = [];
  const visited = new Set<string>();
  const recursionStack = new Set<string>();

  // Build adjacency list
  const graph = new Map<string, string[]>();
  for (const node of protocol.nodes) {
    graph.set(node.id, []);
  }
  for (const edge of protocol.edges) {
    const neighbors = graph.get(edge.from) || [];
    neighbors.push(edge.to);
    graph.set(edge.from, neighbors);
  }

  function dfs(nodeId: string, path: string[]): void {
    visited.add(nodeId);
    recursionStack.add(nodeId);
    path.push(nodeId);

    const neighbors = graph.get(nodeId) || [];
    for (const neighbor of neighbors) {
      if (!visited.has(neighbor)) {
        dfs(neighbor, [...path]);
      } else if (recursionStack.has(neighbor)) {
        // Cycle detected
        const cycleStart = path.indexOf(neighbor);
        if (cycleStart !== -1) {
          cycles.push(path.slice(cycleStart));
        }
      }
    }

    recursionStack.delete(nodeId);
  }

  for (const node of protocol.nodes) {
    if (!visited.has(node.id)) {
      dfs(node.id, []);
    }
  }

  return cycles;
}

export function getHealthMetrics(protocol: NetProtocol): HealthMetrics {
  const validation = validateProtocol(protocol);
  const orphans = findOrphanNodes(protocol);
  const cycles = detectCycles(protocol);

  return {
    score: validation.healthScore,
    hasEntryPoints: protocol.entry_points.length > 0,
    hasExitNodes: protocol.nodes.some((n) => n.type === 'exit'),
    noOrphanNodes: orphans.length === 0,
    noCycles: cycles.length === 0,
    allEdgesValid: validation.errors.filter((e) => e.includes('Edge references')).length === 0,
  };
}
