export type ProtocolStatus = "draft" | "active" | "archived";

export type NodeType = "entry" | "funnel" | "ritual_ref" | "action" | "reward" | "exit";

// Base node interface
export interface BaseNode {
  id: string;
  type: NodeType;
  label: string;
  metadata?: Record<string, unknown>;
}

// Entry node
export interface EntryNode extends BaseNode {
  type: "entry";
  entry_kind: "mint" | "airdrop" | "quest" | "direct_buy" | "invite";
  chain: string;
  token: string;
  min_amount: string;
  conditions?: string;
}

// Funnel node
export interface FunnelNode extends BaseNode {
  type: "funnel";
  funnel_type: "wolf_pack" | "whale_pod" | "orca_ring" | "custom";
  requirements: {
    min_wallets?: number;
    min_hold_time_days?: number;
    min_tvl?: string;
    custom_logic?: string;
  };
}

// Ritual reference node
export interface RitualRefNode extends BaseNode {
  type: "ritual_ref";
  ritual_id: string;
  required: boolean;
  max_attempts?: number;
  weight?: number;
}

// Action node
export interface ActionNode extends BaseNode {
  type: "action";
  action_type: string;
  params: Record<string, unknown>;
  instructions?: string;
}

// Reward node
export interface RewardNode extends BaseNode {
  type: "reward";
  reward_type: "token" | "role" | "score_boost" | "whitelist" | "unlock_app" | "loot_box";
  amount?: string;
  token?: string;
  notes?: string;
}

// Exit node
export interface ExitNode extends BaseNode {
  type: "exit";
  exit_kind: "success" | "fail" | "parked" | "recycle";
  redirect_protocol_id?: string;
  notes?: string;
}

// Union type for all nodes
export type NetNode =
  | EntryNode
  | FunnelNode
  | RitualRefNode
  | ActionNode
  | RewardNode
  | ExitNode;

// Edge interface
export interface NetEdge {
  from: string;
  to: string;
  condition: string;
  notes?: string;
}

// Complete protocol interface
export interface NetProtocol {
  protocol_id: string;
  name: string;
  description: string;
  version: number;
  status: ProtocolStatus;
  created_at: string;
  updated_at: string;
  entry_points: string[];
  nodes: NetNode[];
  edges: NetEdge[];
}
