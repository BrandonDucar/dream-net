'use client'
import { useState, useEffect } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ArchiveOverview } from '@/components/archive/archive-overview'
import { ArtifactDetail } from '@/components/archive/artifact-detail'
import { ChannelsPlans } from '@/components/archive/channels-plans'
import { PublicationEvents } from '@/components/archive/publication-events'
import { RoadmapView } from '@/components/archive/roadmap-view'
import { FileArchive, Sparkles, BookOpen, Radio, Calendar, Map } from 'lucide-react'
import { sdk } from "@farcaster/miniapp-sdk"
import { useAddMiniApp } from "@/hooks/useAddMiniApp"
import { useQuickAuth } from "@/hooks/useQuickAuth"
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster"

export default function Page() {
  const [isMounted, setIsMounted] = useState(false)
  const { addMiniApp } = useAddMiniApp()
  const isInFarcaster = useIsInFarcaster()
  useQuickAuth(isInFarcaster)
  
  useEffect(() => {
    setIsMounted(true)
  }, [])
  
  useEffect(() => {
    if (!isMounted) return
    
    const tryAddMiniApp = async () => {
      try {
        await addMiniApp()
      } catch (error) {
        console.error('Failed to add mini app:', error)
      }
    }
    tryAddMiniApp()
  }, [addMiniApp, isMounted])
  
  useEffect(() => {
    if (!isMounted) return
    
    const initializeFarcaster = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 100))
        
        if (document.readyState !== 'complete') {
          await new Promise<void>(resolve => {
            if (document.readyState === 'complete') {
              resolve()
            } else {
              window.addEventListener('load', () => resolve(), { once: true })
            }
          })
        }
        
        await sdk.actions.ready()
        console.log('Farcaster SDK initialized successfully - app fully loaded')
      } catch (error) {
        console.error('Failed to initialize Farcaster SDK:', error)
        
        setTimeout(async () => {
          try {
            await sdk.actions.ready()
            console.log('Farcaster SDK initialized on retry')
          } catch (retryError) {
            console.error('Farcaster SDK retry failed:', retryError)
          }
        }, 1000)
      }
    }
    
    initializeFarcaster()
  }, [isMounted])
  
  const [selectedArtifactId, setSelectedArtifactId] = useState<string | null>(null)
  const [refreshKey, setRefreshKey] = useState(0)
  const [activeTab, setActiveTab] = useState('overview')
  
  if (!isMounted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-900 flex items-center justify-center">
        <div className="text-center space-y-4">
          <Sparkles className="w-12 h-12 text-purple-400 animate-pulse mx-auto" />
          <p className="text-xl text-purple-200">Initializing Archive...</p>
        </div>
      </div>
    )
  }

  const handleSelectArtifact = (artifactId: string) => {
    setSelectedArtifactId(artifactId)
    setActiveTab('artifact-detail')
  }

  const handleBackToOverview = () => {
    setSelectedArtifactId(null)
    setActiveTab('overview')
  }

  const handleRefresh = () => {
    setRefreshKey((prev: number) => prev + 1)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-900">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS1vcGFjaXR5PSIwLjAzIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-40" />
      
      {/* Header */}
      <header className="relative border-b border-white/10 bg-black/20 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 via-pink-500 to-blue-500 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/25">
              <FileArchive className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-200 via-pink-200 to-blue-200">
                DreamNet Archive & Publishing Press
              </h1>
              <p className="text-sm text-purple-300/60">Your publishing house and content library</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-6 bg-white/5 backdrop-blur-sm p-1 shadow-lg border border-white/10">
            <TabsTrigger 
              value="overview" 
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600 data-[state=active]:text-white text-purple-300"
            >
              <BookOpen className="w-4 h-4 mr-2" />
              Archive
            </TabsTrigger>
            {selectedArtifactId && (
              <TabsTrigger 
                value="artifact-detail" 
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600 data-[state=active]:text-white text-purple-300"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Detail
              </TabsTrigger>
            )}
            <TabsTrigger 
              value="channels-plans" 
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-cyan-600 data-[state=active]:text-white text-purple-300"
            >
              <Radio className="w-4 h-4 mr-2" />
              Channels & Plans
            </TabsTrigger>
            <TabsTrigger 
              value="events" 
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-amber-600 data-[state=active]:to-orange-600 data-[state=active]:text-white text-purple-300"
            >
              <Calendar className="w-4 h-4 mr-2" />
              Events
            </TabsTrigger>
            <TabsTrigger 
              value="roadmap" 
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-emerald-600 data-[state=active]:to-teal-600 data-[state=active]:text-white text-purple-300"
            >
              <Map className="w-4 h-4 mr-2" />
              Roadmap
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" key={`overview-${refreshKey}`}>
            <ArchiveOverview onSelectArtifact={handleSelectArtifact} onRefresh={handleRefresh} />
          </TabsContent>

          {selectedArtifactId && (
            <TabsContent value="artifact-detail" key={`detail-${selectedArtifactId}-${refreshKey}`}>
              <ArtifactDetail
                artifactId={selectedArtifactId}
                onBack={handleBackToOverview}
                onRefresh={handleRefresh}
              />
            </TabsContent>
          )}

          <TabsContent value="channels-plans" key={`channels-${refreshKey}`}>
            <ChannelsPlans onRefresh={handleRefresh} />
          </TabsContent>

          <TabsContent value="events" key={`events-${refreshKey}`}>
            <PublicationEvents />
          </TabsContent>

          <TabsContent value="roadmap" key={`roadmap-${refreshKey}`}>
            <RoadmapView />
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="relative border-t border-white/10 bg-black/20 backdrop-blur-sm mt-12">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center text-sm text-purple-300/60">
            <p>Built for the DreamNet ecosystem</p>
            <p>All data stored locally in your browser</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
