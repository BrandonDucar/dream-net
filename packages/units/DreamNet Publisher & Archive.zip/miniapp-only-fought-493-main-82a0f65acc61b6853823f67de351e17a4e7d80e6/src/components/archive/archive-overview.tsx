'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Plus, FileText, Search, Download, Sparkles, TrendingUp, Layers, BookOpen, List } from 'lucide-react'
import { ArtifactFormDialog } from './artifact-form-dialog'
import { CollectionFormDialog } from './collection-form-dialog'
import { SeriesFormDialog } from './series-form-dialog'
import type { Artifact, Collection, Series, ArtifactType, ArtifactStatus } from '@/types/archive'
import {
  listArtifacts,
  listCollections,
  listSeries,
  createArtifact,
  createCollection,
  createSeries,
  exportPublishingCatalog,
} from '@/lib/archive-operations'

interface ArchiveOverviewProps {
  onSelectArtifact: (artifactId: string) => void
  onRefresh: () => void
}

export function ArchiveOverview({ onSelectArtifact, onRefresh }: ArchiveOverviewProps) {
  const [artifacts, setArtifacts] = useState<Artifact[]>([])
  const [collections, setCollections] = useState<Collection[]>([])
  const [series, setSeries] = useState<Series[]>([])
  const [isLoaded, setIsLoaded] = useState(false)
  
  const [searchQuery, setSearchQuery] = useState('')
  const [typeFilter, setTypeFilter] = useState<ArtifactType | 'all'>('all')
  const [statusFilter, setStatusFilter] = useState<ArtifactStatus | 'all'>('all')
  
  const [showArtifactDialog, setShowArtifactDialog] = useState(false)
  const [showCollectionDialog, setShowCollectionDialog] = useState(false)
  const [showSeriesDialog, setShowSeriesDialog] = useState(false)

  useEffect(() => {
    loadData()
  }, [typeFilter, statusFilter]) // eslint-disable-line react-hooks/exhaustive-deps

  const loadData = () => {
    try {
      const artifactFilter: { artifactType?: ArtifactType; status?: ArtifactStatus } = {}
      if (typeFilter !== 'all') artifactFilter.artifactType = typeFilter
      if (statusFilter !== 'all') artifactFilter.status = statusFilter
      
      setArtifacts(listArtifacts(artifactFilter))
      setCollections(listCollections())
      setSeries(listSeries())
      setIsLoaded(true)
      onRefresh()
    } catch (error) {
      console.error('Error loading archive data:', error)
      setIsLoaded(true)
    }
  }

  const filteredArtifacts = artifacts.filter((artifact: Artifact) =>
    artifact.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    artifact.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    artifact.tags.some((tag: string) => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  )

  const handleCreateArtifact = (data: Parameters<typeof createArtifact>[0]) => {
    createArtifact(data)
    loadData()
    setShowArtifactDialog(false)
  }

  const handleCreateCollection = (data: Parameters<typeof createCollection>[0]) => {
    createCollection(data)
    loadData()
    setShowCollectionDialog(false)
  }

  const handleCreateSeries = (data: Parameters<typeof createSeries>[0]) => {
    createSeries(data)
    loadData()
    setShowSeriesDialog(false)
  }

  const handleExportCatalog = () => {
    const catalog = exportPublishingCatalog()
    const blob = new Blob([catalog], { type: 'text/markdown' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'dreamnet-publishing-catalog.md'
    a.click()
    URL.revokeObjectURL(url)
  }

  const getStatusColor = (status: ArtifactStatus): string => {
    const colors: Record<ArtifactStatus, string> = {
      draft: 'bg-slate-500/20 text-slate-300 border-slate-500/30',
      ready: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
      published: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
      archived: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
    }
    return colors[status]
  }

  const getTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      lore: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
      documentation: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
      playbook: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
      report: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
      map: 'bg-teal-500/20 text-teal-300 border-teal-500/30',
      manual: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
      guide: 'bg-orange-500/20 text-orange-300 border-orange-500/30',
      codex: 'bg-pink-500/20 text-pink-300 border-pink-500/30',
      other: 'bg-slate-500/20 text-slate-300 border-slate-500/30',
    }
    return colors[type] || 'bg-slate-500/20 text-slate-300 border-slate-500/30'
  }

  if (!isLoaded) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="text-center space-y-4">
          <Sparkles className="w-12 h-12 text-purple-400 animate-pulse mx-auto" />
          <p className="text-xl text-purple-200">Loading Archive...</p>
        </div>
      </div>
    )
  }

  const stats = [
    {
      icon: FileText,
      label: 'Artifacts',
      value: artifacts.length,
      change: '+' + artifacts.filter((a: Artifact) => a.status === 'draft').length + ' draft',
      gradient: 'from-violet-500 to-purple-600',
    },
    {
      icon: Layers,
      label: 'Collections',
      value: collections.length,
      change: collections.filter(c => c.category === 'public').length + ' public',
      gradient: 'from-blue-500 to-cyan-600',
    },
    {
      icon: List,
      label: 'Series',
      value: series.length,
      change: series.reduce((acc, s) => acc + s.sequenceArtifactIds.length, 0) + ' items',
      gradient: 'from-emerald-500 to-teal-600',
    },
    {
      icon: TrendingUp,
      label: 'Published',
      value: artifacts.filter((a: Artifact) => a.status === 'published').length,
      change: artifacts.filter((a: Artifact) => a.status === 'ready').length + ' ready',
      gradient: 'from-amber-500 to-orange-600',
    },
  ]

  return (
    <div className="space-y-8">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon
          return (
            <div
              key={stat.label}
              className="group relative overflow-hidden rounded-xl bg-white/5 backdrop-blur-sm border border-white/10 p-6 hover:border-white/20 transition-all"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${stat.gradient} opacity-0 group-hover:opacity-10 transition-opacity`} />
              <div className="relative flex items-start justify-between">
                <div className="space-y-2">
                  <p className="text-sm text-purple-300/60">{stat.label}</p>
                  <p className="text-3xl font-bold text-white">{String(stat.value)}</p>
                  <p className="text-xs text-purple-400/60">{String(stat.change)}</p>
                </div>
                <div className={`p-3 rounded-lg bg-gradient-to-br ${stat.gradient} shadow-lg`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Actions */}
      <div className="flex flex-wrap gap-3">
        <Button
          onClick={() => setShowArtifactDialog(true)}
          className="bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white shadow-lg"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Artifact
        </Button>
        <Button
          onClick={() => setShowCollectionDialog(true)}
          className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white shadow-lg"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Collection
        </Button>
        <Button
          onClick={() => setShowSeriesDialog(true)}
          className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-lg"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Series
        </Button>
        <Button
          onClick={handleExportCatalog}
          variant="outline"
          className="border-white/10 text-purple-300 hover:bg-white/10"
        >
          <Download className="w-4 h-4 mr-2" />
          Export Catalog
        </Button>
      </div>

      {/* Artifacts Section */}
      <Card className="bg-white/5 backdrop-blur-sm border-white/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Artifacts
          </CardTitle>
          <CardDescription className="text-purple-300/60">
            All content pieces in your archive
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-purple-400" />
              <Input
                placeholder="Search artifacts..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-purple-400/40"
              />
            </div>
            <Select value={typeFilter} onValueChange={(value) => setTypeFilter(value as ArtifactType | 'all')}>
              <SelectTrigger className="bg-white/5 border-white/10 text-white">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="lore">Lore</SelectItem>
                <SelectItem value="documentation">Documentation</SelectItem>
                <SelectItem value="playbook">Playbook</SelectItem>
                <SelectItem value="report">Report</SelectItem>
                <SelectItem value="map">Map</SelectItem>
                <SelectItem value="manual">Manual</SelectItem>
                <SelectItem value="guide">Guide</SelectItem>
                <SelectItem value="codex">Codex</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as ArtifactStatus | 'all')}>
              <SelectTrigger className="bg-white/5 border-white/10 text-white">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="ready">Ready</SelectItem>
                <SelectItem value="published">Published</SelectItem>
                <SelectItem value="archived">Archived</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Artifacts List */}
          <div className="space-y-3">
            {filteredArtifacts.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-12 h-12 text-purple-400/40 mx-auto mb-4" />
                <p className="text-purple-300/60">No artifacts found</p>
                <p className="text-sm text-purple-400/40 mt-1">Create your first artifact to get started</p>
              </div>
            ) : (
              filteredArtifacts.map((artifact: Artifact) => (
                <button
                  key={artifact.id}
                  onClick={() => onSelectArtifact(artifact.id)}
                  className="w-full group relative overflow-hidden rounded-lg bg-white/5 border border-white/10 p-4 text-left hover:bg-white/10 hover:border-white/20 transition-all"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-lg font-semibold text-white group-hover:text-purple-200 transition-colors">
                          {artifact.title}
                        </h3>
                        <Badge className={`${getTypeColor(artifact.artifactType)} border`}>
                          {artifact.artifactType}
                        </Badge>
                        <Badge className={`${getStatusColor(artifact.status)} border`}>
                          {artifact.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-purple-300/60 line-clamp-2">{artifact.description}</p>
                      <div className="flex items-center gap-4 text-xs text-purple-400/60">
                        {artifact.sourceApp && <span>📦 {artifact.sourceApp}</span>}
                        <span>🏷️ {artifact.versionLabel}</span>
                        {artifact.tags.length > 0 && (
                          <span>• {artifact.tags.slice(0, 3).join(', ')}</span>
                        )}
                      </div>
                    </div>
                    <div className="text-white/20 group-hover:text-white/60 group-hover:translate-x-1 transition-all">
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </div>
                  </div>
                </button>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Collections Quick View */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-white/5 backdrop-blur-sm border-white/10">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5" />
              Collections ({collections.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {collections.slice(0, 5).map((collection: Collection) => (
                <div
                  key={collection.id}
                  className="p-3 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition-all"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-white">{collection.name}</p>
                      <p className="text-xs text-purple-400/60">{collection.artifactIds.length} artifacts</p>
                    </div>
                    <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30">
                      {collection.category}
                    </Badge>
                  </div>
                </div>
              ))}
              {collections.length === 0 && (
                <p className="text-center text-purple-400/60 py-8 text-sm">No collections yet</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/5 backdrop-blur-sm border-white/10">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <List className="w-5 h-5" />
              Series ({series.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {series.slice(0, 5).map((s: Series) => (
                <div
                  key={s.id}
                  className="p-3 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition-all"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-white">{s.name}</p>
                      <p className="text-xs text-purple-400/60">{s.sequenceArtifactIds.length} artifacts</p>
                    </div>
                  </div>
                </div>
              ))}
              {series.length === 0 && (
                <p className="text-center text-purple-400/60 py-8 text-sm">No series yet</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Dialogs */}
      <ArtifactFormDialog
        open={showArtifactDialog}
        onOpenChange={setShowArtifactDialog}
        onSave={handleCreateArtifact}
      />
      <CollectionFormDialog
        open={showCollectionDialog}
        onOpenChange={setShowCollectionDialog}
        onSave={handleCreateCollection}
        artifacts={artifacts}
      />
      <SeriesFormDialog
        open={showSeriesDialog}
        onOpenChange={setShowSeriesDialog}
        onSave={handleCreateSeries}
        artifacts={artifacts}
      />
    </div>
  )
}
