'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ArrowLeft, Edit, Trash2, Plus, Copy, FileText, Sparkles } from 'lucide-react';
import type {
  Artifact,
  ArtifactContentRef,
  Collection,
  Series,
  PublicationPlan,
  PublicationEvent,
  ContentType,
  ArtifactStatus,
  ImportanceLevel,
} from '@/types/archive';
import {
  getArtifactDetail,
  updateArtifact,
  deleteArtifact,
  addArtifactContentRef,
  deleteArtifactContentRef,
  generateArtifactPublishingBrief,
} from '@/lib/archive-operations';

interface ArtifactDetailProps {
  artifactId: string | null;
  onBack: () => void;
  onRefresh: () => void;
}

export function ArtifactDetail({ artifactId, onBack, onRefresh }: ArtifactDetailProps) {
  const [detail, setDetail] = useState<ReturnType<typeof getArtifactDetail> | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [showContentRefDialog, setShowContentRefDialog] = useState(false);
  const [showBriefDialog, setShowBriefDialog] = useState(false);
  const [publishingBrief, setPublishingBrief] = useState('');
  
  // Edit form state
  const [editTitle, setEditTitle] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editContentSummary, setEditContentSummary] = useState('');
  const [editVersionLabel, setEditVersionLabel] = useState('');
  const [editStatus, setEditStatus] = useState<ArtifactStatus>('draft');
  const [editImportanceLevel, setEditImportanceLevel] = useState<ImportanceLevel>('medium');
  const [editNotes, setEditNotes] = useState('');
  
  // Content ref form state
  const [contentType, setContentType] = useState<ContentType>('markdown');
  const [storageHint, setStorageHint] = useState('');
  const [contentExcerpt, setContentExcerpt] = useState('');
  const [contentNotes, setContentNotes] = useState('');

  useEffect(() => {
    if (artifactId) {
      loadDetail();
    }
  }, [artifactId]); // eslint-disable-line react-hooks/exhaustive-deps

  const loadDetail = () => {
    if (!artifactId) return;
    const data = getArtifactDetail(artifactId);
    setDetail(data);
    
    if (data) {
      setEditTitle(data.artifact.title);
      setEditDescription(data.artifact.description);
      setEditContentSummary(data.artifact.contentSummary);
      setEditVersionLabel(data.artifact.versionLabel);
      setEditStatus(data.artifact.status);
      setEditImportanceLevel(data.artifact.importanceLevel);
      setEditNotes(data.artifact.notes);
    }
  };

  const handleSaveEdit = () => {
    if (!artifactId) return;
    
    updateArtifact(artifactId, {
      title: editTitle,
      description: editDescription,
      contentSummary: editContentSummary,
      versionLabel: editVersionLabel,
      status: editStatus,
      importanceLevel: editImportanceLevel,
      notes: editNotes,
    });
    
    setIsEditing(false);
    loadDetail();
    onRefresh();
  };

  const handleDelete = () => {
    if (!artifactId) return;
    if (!confirm('Are you sure you want to delete this artifact? This cannot be undone.')) return;
    
    deleteArtifact(artifactId);
    onRefresh();
    onBack();
  };

  const handleAddContentRef = () => {
    if (!artifactId) return;
    
    addArtifactContentRef({
      artifactId,
      contentType,
      storageHint,
      contentExcerpt,
      notes: contentNotes,
    });
    
    setShowContentRefDialog(false);
    setContentType('markdown');
    setStorageHint('');
    setContentExcerpt('');
    setContentNotes('');
    loadDetail();
    onRefresh();
  };

  const handleDeleteContentRef = (refId: string) => {
    if (!confirm('Delete this content reference?')) return;
    deleteArtifactContentRef(refId);
    loadDetail();
    onRefresh();
  };

  const handleGenerateBrief = () => {
    if (!artifactId) return;
    const brief = generateArtifactPublishingBrief(artifactId);
    setPublishingBrief(brief);
    setShowBriefDialog(true);
  };

  const handleCopyBrief = () => {
    navigator.clipboard.writeText(publishingBrief);
  };

  if (!detail) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Loading artifact details...</p>
      </div>
    );
  }

  const { artifact, contentRefs, collections, series, publicationPlans, publicationEvents } = detail;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-4">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">{artifact.title}</h1>
            <p className="text-gray-600 mt-1">{artifact.artifactType} • {artifact.versionLabel}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleGenerateBrief}>
            <Sparkles className="w-4 h-4 mr-2" />
            Generate Brief
          </Button>
          <Button variant="outline" onClick={() => setIsEditing(!isEditing)}>
            <Edit className="w-4 h-4 mr-2" />
            {isEditing ? 'Cancel Edit' : 'Edit'}
          </Button>
          <Button variant="destructive" onClick={handleDelete}>
            <Trash2 className="w-4 h-4 mr-2" />
            Delete
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="content">Content Refs ({contentRefs.length})</TabsTrigger>
          <TabsTrigger value="usage">Usage</TabsTrigger>
          <TabsTrigger value="seo">SEO</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          {isEditing ? (
            <Card>
              <CardHeader>
                <CardTitle>Edit Artifact</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="edit-title">Title</Label>
                  <Input id="edit-title" value={editTitle} onChange={(e) => setEditTitle(e.target.value)} />
                </div>
                <div>
                  <Label htmlFor="edit-description">Description</Label>
                  <Textarea
                    id="edit-description"
                    value={editDescription}
                    onChange={(e) => setEditDescription(e.target.value)}
                    rows={3}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-summary">Content Summary</Label>
                  <Textarea
                    id="edit-summary"
                    value={editContentSummary}
                    onChange={(e) => setEditContentSummary(e.target.value)}
                    rows={3}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="edit-version">Version</Label>
                    <Input id="edit-version" value={editVersionLabel} onChange={(e) => setEditVersionLabel(e.target.value)} />
                  </div>
                  <div>
                    <Label htmlFor="edit-status">Status</Label>
                    <Select value={editStatus} onValueChange={(value) => setEditStatus(value as ArtifactStatus)}>
                      <SelectTrigger id="edit-status">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="ready">Ready</SelectItem>
                        <SelectItem value="published">Published</SelectItem>
                        <SelectItem value="archived">Archived</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="edit-importance">Importance</Label>
                  <Select value={editImportanceLevel} onValueChange={(value) => setEditImportanceLevel(value as ImportanceLevel)}>
                    <SelectTrigger id="edit-importance">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit-notes">Notes</Label>
                  <Textarea id="edit-notes" value={editNotes} onChange={(e) => setEditNotes(e.target.value)} rows={4} />
                </div>
                <Button onClick={handleSaveEdit}>Save Changes</Button>
              </CardContent>
            </Card>
          ) : (
            <>
              <Card>
                <CardHeader>
                  <CardTitle>Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Status</Label>
                      <div className="mt-1">
                        <Badge>{artifact.status}</Badge>
                      </div>
                    </div>
                    <div>
                      <Label>Importance</Label>
                      <div className="mt-1">
                        <Badge variant="outline">{artifact.importanceLevel}</Badge>
                      </div>
                    </div>
                    <div>
                      <Label>Source App</Label>
                      <p className="text-sm mt-1">{artifact.sourceApp || 'N/A'}</p>
                    </div>
                    <div>
                      <Label>Slug</Label>
                      <p className="text-sm mt-1 font-mono">{artifact.slug}</p>
                    </div>
                  </div>
                  <div>
                    <Label>Description</Label>
                    <p className="text-sm mt-1">{artifact.description}</p>
                  </div>
                  <div>
                    <Label>Content Summary</Label>
                    <p className="text-sm mt-1">{artifact.contentSummary}</p>
                  </div>
                  {artifact.tags.length > 0 && (
                    <div>
                      <Label>Tags</Label>
                      <div className="flex gap-2 mt-1 flex-wrap">
                        {artifact.tags.map((tag: string) => (
                          <Badge key={tag} variant="secondary">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  {artifact.notes && (
                    <div>
                      <Label>Notes</Label>
                      <p className="text-sm mt-1 whitespace-pre-wrap">{artifact.notes}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        <TabsContent value="content" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Content References</CardTitle>
                  <CardDescription>Links to actual content files and storage</CardDescription>
                </div>
                <Button onClick={() => setShowContentRefDialog(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Content Ref
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {contentRefs.length === 0 ? (
                <p className="text-sm text-gray-500 text-center py-8">No content references yet</p>
              ) : (
                <div className="space-y-4">
                  {contentRefs.map((ref: ArtifactContentRef) => (
                    <div key={ref.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-gray-400" />
                          <Badge variant="outline">{ref.contentType}</Badge>
                        </div>
                        <Button size="sm" variant="ghost" onClick={() => handleDeleteContentRef(ref.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="space-y-2">
                        <div>
                          <Label className="text-xs">Storage Hint</Label>
                          <p className="text-sm font-mono">{ref.storageHint}</p>
                        </div>
                        <div>
                          <Label className="text-xs">Excerpt</Label>
                          <p className="text-sm">{ref.contentExcerpt}</p>
                        </div>
                        {ref.notes && (
                          <div>
                            <Label className="text-xs">Notes</Label>
                            <p className="text-sm text-gray-600">{ref.notes}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="usage" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>In Collections ({collections.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {collections.length === 0 ? (
                  <p className="text-sm text-gray-500">Not in any collections</p>
                ) : (
                  <div className="space-y-2">
                    {collections.map((collection: Collection) => (
                      <div key={collection.id} className="p-2 border rounded">
                        <div className="font-medium text-sm">{collection.name}</div>
                        <div className="text-xs text-gray-500">{collection.category}</div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>In Series ({series.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {series.length === 0 ? (
                  <p className="text-sm text-gray-500">Not in any series</p>
                ) : (
                  <div className="space-y-2">
                    {series.map((s: Series) => (
                      <div key={s.id} className="p-2 border rounded">
                        <div className="font-medium text-sm">{s.name}</div>
                        <div className="text-xs text-gray-500">{s.sequenceArtifactIds.length} artifacts</div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>In Publication Plans ({publicationPlans.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {publicationPlans.length === 0 ? (
                  <p className="text-sm text-gray-500">Not in any plans</p>
                ) : (
                  <div className="space-y-2">
                    {publicationPlans.map((plan: PublicationPlan) => (
                      <div key={plan.id} className="p-2 border rounded">
                        <div className="font-medium text-sm">{plan.name}</div>
                        <Badge variant="outline" className="mt-1">{plan.status}</Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Publication Events ({publicationEvents.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {publicationEvents.length === 0 ? (
                  <p className="text-sm text-gray-500">No publication events</p>
                ) : (
                  <div className="space-y-2">
                    {publicationEvents.map((event: PublicationEvent) => (
                      <div key={event.id} className="p-2 border rounded">
                        <div className="font-medium text-sm">{event.title}</div>
                        <div className="text-xs text-gray-500">
                          {new Date(event.timestamp).toLocaleDateString()}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="seo" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>SEO & Metadata</CardTitle>
              <CardDescription>Auto-generated for publishing</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>SEO Title</Label>
                <p className="text-sm mt-1">{artifact.seoTitle}</p>
              </div>
              <div>
                <Label>SEO Description</Label>
                <p className="text-sm mt-1">{artifact.seoDescription}</p>
              </div>
              <div>
                <Label>Keywords</Label>
                <div className="flex gap-2 mt-1 flex-wrap">
                  {artifact.seoKeywords.map((keyword: string) => (
                    <Badge key={keyword} variant="secondary">
                      {keyword}
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <Label>Hashtags</Label>
                <div className="flex gap-2 mt-1 flex-wrap">
                  {artifact.seoHashtags.map((hashtag: string) => (
                    <Badge key={hashtag} variant="outline">
                      {hashtag}
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <Label>Alt Text</Label>
                <p className="text-sm mt-1">{artifact.altText}</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Content Ref Dialog */}
      <Dialog open={showContentRefDialog} onOpenChange={setShowContentRefDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Content Reference</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="contentType">Content Type</Label>
              <Select value={contentType} onValueChange={(value) => setContentType(value as ContentType)}>
                <SelectTrigger id="contentType">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="markdown">Markdown</SelectItem>
                  <SelectItem value="plain-text">Plain Text</SelectItem>
                  <SelectItem value="html">HTML</SelectItem>
                  <SelectItem value="pdf">PDF</SelectItem>
                  <SelectItem value="image">Image</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="storageHint">Storage Hint</Label>
              <Input
                id="storageHint"
                value={storageHint}
                onChange={(e) => setStorageHint(e.target.value)}
                placeholder="e.g., /docs/constitution.md, notion-link, google-drive-id"
              />
            </div>
            <div>
              <Label htmlFor="contentExcerpt">Content Excerpt</Label>
              <Textarea
                id="contentExcerpt"
                value={contentExcerpt}
                onChange={(e) => setContentExcerpt(e.target.value)}
                placeholder="Brief excerpt or summary of the content"
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="contentNotes">Notes</Label>
              <Textarea
                id="contentNotes"
                value={contentNotes}
                onChange={(e) => setContentNotes(e.target.value)}
                placeholder="Any additional notes"
                rows={2}
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowContentRefDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddContentRef} disabled={!storageHint || !contentExcerpt}>
              Add Reference
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Publishing Brief Dialog */}
      <Dialog open={showBriefDialog} onOpenChange={setShowBriefDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Publishing Brief</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="flex justify-end">
              <Button size="sm" variant="outline" onClick={handleCopyBrief}>
                <Copy className="w-4 h-4 mr-2" />
                Copy to Clipboard
              </Button>
            </div>
            <div className="border rounded-lg p-4 bg-gray-50 max-h-[60vh] overflow-y-auto">
              <pre className="text-sm whitespace-pre-wrap font-mono">{publishingBrief}</pre>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
