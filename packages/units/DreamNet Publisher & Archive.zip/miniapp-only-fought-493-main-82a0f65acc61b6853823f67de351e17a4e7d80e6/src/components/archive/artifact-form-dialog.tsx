'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { Artifact, ArtifactType, ImportanceLevel } from '@/types/archive';

interface ArtifactFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (data: {
    title: string;
    artifactType: ArtifactType;
    sourceApp: string | null;
    description: string;
    contentSummary: string;
    versionLabel: string;
    importanceLevel: ImportanceLevel;
    tags: string[];
  }) => void;
  initialData?: Artifact | null;
}

export function ArtifactFormDialog({ open, onOpenChange, onSave, initialData }: ArtifactFormDialogProps) {
  const [title, setTitle] = useState(initialData?.title || '');
  const [artifactType, setArtifactType] = useState<ArtifactType>(initialData?.artifactType || 'documentation');
  const [sourceApp, setSourceApp] = useState(initialData?.sourceApp || '');
  const [description, setDescription] = useState(initialData?.description || '');
  const [contentSummary, setContentSummary] = useState(initialData?.contentSummary || '');
  const [versionLabel, setVersionLabel] = useState(initialData?.versionLabel || 'v1.0');
  const [importanceLevel, setImportanceLevel] = useState<ImportanceLevel>(initialData?.importanceLevel || 'medium');
  const [tagsInput, setTagsInput] = useState(initialData?.tags?.join(', ') || '');

  const handleSave = () => {
    const tags = tagsInput.split(',').map((t: string) => t.trim()).filter((t: string) => t.length > 0);
    
    onSave({
      title,
      artifactType,
      sourceApp: sourceApp || null,
      description,
      contentSummary,
      versionLabel,
      importanceLevel,
      tags,
    });
    
    // Reset form
    setTitle('');
    setArtifactType('documentation');
    setSourceApp('');
    setDescription('');
    setContentSummary('');
    setVersionLabel('v1.0');
    setImportanceLevel('medium');
    setTagsInput('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{initialData ? 'Edit Artifact' : 'Create New Artifact'}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div>
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., DreamNet Constitution v1"
            />
          </div>
          
          <div>
            <Label htmlFor="artifactType">Type *</Label>
            <Select value={artifactType} onValueChange={(value) => setArtifactType(value as ArtifactType)}>
              <SelectTrigger id="artifactType">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="lore">Lore</SelectItem>
                <SelectItem value="documentation">Documentation</SelectItem>
                <SelectItem value="playbook">Playbook</SelectItem>
                <SelectItem value="report">Report</SelectItem>
                <SelectItem value="map">Map</SelectItem>
                <SelectItem value="manual">Manual</SelectItem>
                <SelectItem value="guide">Guide</SelectItem>
                <SelectItem value="codex">Codex</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="sourceApp">Source App</Label>
            <Input
              id="sourceApp"
              value={sourceApp}
              onChange={(e) => setSourceApp(e.target.value)}
              placeholder="e.g., Governance Engine, Ritual Engine"
            />
          </div>
          
          <div>
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief overview of this artifact"
              rows={3}
            />
          </div>
          
          <div>
            <Label htmlFor="contentSummary">Content Summary *</Label>
            <Textarea
              id="contentSummary"
              value={contentSummary}
              onChange={(e) => setContentSummary(e.target.value)}
              placeholder="High-level summary of the content"
              rows={3}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="versionLabel">Version *</Label>
              <Input
                id="versionLabel"
                value={versionLabel}
                onChange={(e) => setVersionLabel(e.target.value)}
                placeholder="e.g., v1.0, draft, beta"
              />
            </div>
            
            <div>
              <Label htmlFor="importanceLevel">Importance *</Label>
              <Select value={importanceLevel} onValueChange={(value) => setImportanceLevel(value as ImportanceLevel)}>
                <SelectTrigger id="importanceLevel">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <Label htmlFor="tags">Tags (comma-separated)</Label>
            <Input
              id="tags"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="e.g., core, governance, ritual"
            />
          </div>
        </div>
        
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave} disabled={!title || !description || !contentSummary}>
            {initialData ? 'Save Changes' : 'Create Artifact'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
