'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { PublicationChannel, ChannelType } from '@/types/archive';

interface ChannelFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (data: {
    name: string;
    channelType: ChannelType;
    description: string;
    urlOrRef: string | null;
    tags: string[];
  }) => void;
  initialData?: PublicationChannel | null;
}

export function ChannelFormDialog({ open, onOpenChange, onSave, initialData }: ChannelFormDialogProps) {
  const [name, setName] = useState(initialData?.name || '');
  const [channelType, setChannelType] = useState<ChannelType>(initialData?.channelType || 'website');
  const [description, setDescription] = useState(initialData?.description || '');
  const [urlOrRef, setUrlOrRef] = useState(initialData?.urlOrRef || '');
  const [tagsInput, setTagsInput] = useState(initialData?.tags?.join(', ') || '');

  const handleSave = () => {
    const tags = tagsInput.split(',').map((t: string) => t.trim()).filter((t: string) => t.length > 0);
    
    onSave({
      name,
      channelType,
      description,
      urlOrRef: urlOrRef || null,
      tags,
    });
    
    // Reset form
    setName('');
    setChannelType('website');
    setDescription('');
    setUrlOrRef('');
    setTagsInput('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{initialData ? 'Edit Channel' : 'Create New Publication Channel'}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div>
            <Label htmlFor="name">Name *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Main Website, Zora Collection"
            />
          </div>
          
          <div>
            <Label htmlFor="channelType">Type *</Label>
            <Select value={channelType} onValueChange={(value) => setChannelType(value as ChannelType)}>
              <SelectTrigger id="channelType">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="website">Website</SelectItem>
                <SelectItem value="zora">Zora</SelectItem>
                <SelectItem value="pdf-bundle">PDF Bundle</SelectItem>
                <SelectItem value="newsletter">Newsletter</SelectItem>
                <SelectItem value="blog">Blog</SelectItem>
                <SelectItem value="frame">Frame</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What is this channel used for?"
              rows={3}
            />
          </div>
          
          <div>
            <Label htmlFor="urlOrRef">URL / Reference</Label>
            <Input
              id="urlOrRef"
              value={urlOrRef}
              onChange={(e) => setUrlOrRef(e.target.value)}
              placeholder="e.g., https://dreamnet.io, notion-hub-link"
            />
          </div>
          
          <div>
            <Label htmlFor="tags">Tags (comma-separated)</Label>
            <Input
              id="tags"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="e.g., primary, high-reach, external"
            />
          </div>
        </div>
        
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave} disabled={!name || !description}>
            {initialData ? 'Save Changes' : 'Create Channel'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
