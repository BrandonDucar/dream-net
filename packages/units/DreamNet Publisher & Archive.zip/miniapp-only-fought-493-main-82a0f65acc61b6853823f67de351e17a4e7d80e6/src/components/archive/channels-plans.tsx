'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Edit, Trash2, Copy, Sparkles, CheckCircle } from 'lucide-react';
import { ChannelFormDialog } from './channel-form-dialog';
import { PlanFormDialog } from './plan-form-dialog';
import type {
  PublicationChannel,
  PublicationPlan,
  PlanStatus,
  ChannelType,
  Artifact,
  Collection,
  Series,
} from '@/types/archive';
import {
  listPublicationChannels,
  listPublicationPlans,
  listArtifacts,
  listCollections,
  listSeries,
  createPublicationChannel,
  createPublicationPlan,
  updatePublicationPlan,
  deletePublicationChannel,
  deletePublicationPlan,
  recordPublicationEvent,
  generatePublicationPlanBrief,
} from '@/lib/archive-operations';

interface ChannelsPlansProps {
  onRefresh: () => void;
}

export function ChannelsPlans({ onRefresh }: ChannelsPlansProps) {
  const [channels, setChannels] = useState<PublicationChannel[]>([]);
  const [plans, setPlans] = useState<PublicationPlan[]>([]);
  const [artifacts, setArtifacts] = useState<Artifact[]>([]);
  const [collections, setCollections] = useState<Collection[]>([]);
  const [series, setSeries] = useState<Series[]>([]);
  
  const [channelFilter, setChannelFilter] = useState<ChannelType | 'all'>('all');
  const [planStatusFilter, setPlanStatusFilter] = useState<PlanStatus | 'all'>('all');
  
  const [showChannelDialog, setShowChannelDialog] = useState(false);
  const [showPlanDialog, setShowPlanDialog] = useState(false);
  const [showEventDialog, setShowEventDialog] = useState(false);
  const [showBriefDialog, setShowBriefDialog] = useState(false);
  
  const [selectedPlan, setSelectedPlan] = useState<PublicationPlan | null>(null);
  const [planBrief, setPlanBrief] = useState('');
  
  // Event form state
  const [eventPlanId, setEventPlanId] = useState('');
  const [eventChannelId, setEventChannelId] = useState('');
  const [eventTitle, setEventTitle] = useState('');
  const [eventSummary, setEventSummary] = useState('');
  const [eventLink, setEventLink] = useState('');

  useEffect(() => {
    loadData();
  }, [channelFilter, planStatusFilter]); // eslint-disable-line react-hooks/exhaustive-deps

  const loadData = () => {
    const channelFilterObj = channelFilter !== 'all' ? { channelType: channelFilter } : undefined;
    const planFilterObj = planStatusFilter !== 'all' ? { status: planStatusFilter } : undefined;
    
    setChannels(listPublicationChannels(channelFilterObj));
    setPlans(listPublicationPlans(planFilterObj));
    setArtifacts(listArtifacts());
    setCollections(listCollections());
    setSeries(listSeries());
    onRefresh();
  };

  const handleCreateChannel = (data: Parameters<typeof createPublicationChannel>[0]) => {
    createPublicationChannel(data);
    loadData();
    setShowChannelDialog(false);
  };

  const handleCreatePlan = (data: Parameters<typeof createPublicationPlan>[0]) => {
    createPublicationPlan(data);
    loadData();
    setShowPlanDialog(false);
  };

  const handleDeleteChannel = (id: string) => {
    if (!confirm('Delete this channel?')) return;
    deletePublicationChannel(id);
    loadData();
  };

  const handleDeletePlan = (id: string) => {
    if (!confirm('Delete this publication plan?')) return;
    deletePublicationPlan(id);
    loadData();
  };

  const handleUpdatePlanStatus = (planId: string, status: PlanStatus) => {
    updatePublicationPlan(planId, { status });
    loadData();
  };

  const handleOpenEventDialog = (plan: PublicationPlan) => {
    setSelectedPlan(plan);
    setEventPlanId(plan.id);
    setEventChannelId(plan.channelIds[0] || '');
    setEventTitle(`${plan.name} Release`);
    setEventSummary(plan.description);
    setShowEventDialog(true);
  };

  const handleRecordEvent = () => {
    if (!selectedPlan) return;
    
    recordPublicationEvent({
      publicationPlanId: eventPlanId,
      channelId: eventChannelId,
      artifactIds: selectedPlan.artifactIds,
      title: eventTitle,
      summary: eventSummary,
      linkOrProof: eventLink || null,
    });
    
    // Update plan status to released
    updatePublicationPlan(eventPlanId, { status: 'released' });
    
    setShowEventDialog(false);
    setEventPlanId('');
    setEventChannelId('');
    setEventTitle('');
    setEventSummary('');
    setEventLink('');
    setSelectedPlan(null);
    loadData();
  };

  const handleGenerateBrief = (plan: PublicationPlan) => {
    const brief = generatePublicationPlanBrief(plan.id);
    setPlanBrief(brief);
    setShowBriefDialog(true);
  };

  const handleCopyBrief = () => {
    navigator.clipboard.writeText(planBrief);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Channels & Publication Plans</h1>
        <p className="text-gray-600">Manage where and how you publish</p>
      </div>

      <Tabs defaultValue="channels" className="w-full">
        <TabsList>
          <TabsTrigger value="channels">Channels ({channels.length})</TabsTrigger>
          <TabsTrigger value="plans">Publication Plans ({plans.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="channels" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Publication Channels</CardTitle>
                  <CardDescription>Where your content gets published</CardDescription>
                </div>
                <Button onClick={() => setShowChannelDialog(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Channel
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <Select value={channelFilter} onValueChange={(value) => setChannelFilter(value as ChannelType | 'all')}>
                  <SelectTrigger className="w-64">
                    <SelectValue placeholder="Filter by type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="website">Website</SelectItem>
                    <SelectItem value="zora">Zora</SelectItem>
                    <SelectItem value="pdf-bundle">PDF Bundle</SelectItem>
                    <SelectItem value="newsletter">Newsletter</SelectItem>
                    <SelectItem value="blog">Blog</SelectItem>
                    <SelectItem value="frame">Frame</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>URL / Reference</TableHead>
                      <TableHead>Tags</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {channels.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-gray-500">
                          No channels yet. Create your first channel.
                        </TableCell>
                      </TableRow>
                    ) : (
                      channels.map((channel: PublicationChannel) => (
                        <TableRow key={channel.id}>
                          <TableCell className="font-medium">{channel.name}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{channel.channelType}</Badge>
                          </TableCell>
                          <TableCell className="text-sm text-gray-600">
                            {channel.urlOrRef ? (
                              <a href={channel.urlOrRef} target="_blank" rel="noopener noreferrer" className="hover:underline">
                                {channel.urlOrRef}
                              </a>
                            ) : (
                              '—'
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1 flex-wrap">
                              {channel.tags.slice(0, 2).map((tag: string) => (
                                <Badge key={tag} variant="secondary" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Button size="sm" variant="ghost" onClick={() => handleDeleteChannel(channel.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="plans" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Publication Plans</CardTitle>
                  <CardDescription>Orchestrate your content releases</CardDescription>
                </div>
                <Button onClick={() => setShowPlanDialog(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Plan
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <Select value={planStatusFilter} onValueChange={(value) => setPlanStatusFilter(value as PlanStatus | 'all')}>
                  <SelectTrigger className="w-64">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="idea">Idea</SelectItem>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="scheduled">Scheduled</SelectItem>
                    <SelectItem value="released">Released</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {plans.length === 0 ? (
                <div className="text-center py-12 text-gray-500 border rounded-lg">
                  No publication plans yet. Create your first plan.
                </div>
              ) : (
                <div className="space-y-4">
                  {plans.map((plan: PublicationPlan) => (
                    <Card key={plan.id} className="border-2">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <CardTitle className="text-lg">{plan.name}</CardTitle>
                              <Badge>{plan.status}</Badge>
                            </div>
                            <CardDescription>{plan.description}</CardDescription>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" onClick={() => handleGenerateBrief(plan)}>
                              <Sparkles className="w-4 h-4" />
                            </Button>
                            {plan.status === 'scheduled' && (
                              <Button size="sm" variant="default" onClick={() => handleOpenEventDialog(plan)}>
                                <CheckCircle className="w-4 h-4 mr-1" />
                                Record Event
                              </Button>
                            )}
                            <Button size="sm" variant="ghost" onClick={() => handleDeletePlan(plan.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                          <div>
                            <Label className="text-xs text-gray-500">Artifacts</Label>
                            <p className="text-sm font-medium">{plan.artifactIds.length}</p>
                          </div>
                          <div>
                            <Label className="text-xs text-gray-500">Collections</Label>
                            <p className="text-sm font-medium">{plan.collectionIds.length}</p>
                          </div>
                          <div>
                            <Label className="text-xs text-gray-500">Series</Label>
                            <p className="text-sm font-medium">{plan.seriesIds.length}</p>
                          </div>
                          <div>
                            <Label className="text-xs text-gray-500">Channels</Label>
                            <p className="text-sm font-medium">{plan.channelIds.length}</p>
                          </div>
                        </div>
                        
                        <div className="space-y-2">
                          <div>
                            <Label className="text-xs text-gray-500">Target Audience</Label>
                            <p className="text-sm">{plan.targetAudience}</p>
                          </div>
                          <div>
                            <Label className="text-xs text-gray-500">Timing</Label>
                            <Badge variant="outline">{plan.timingHint}</Badge>
                          </div>
                          <div>
                            <Label className="text-xs text-gray-500">Goals</Label>
                            <div className="flex gap-2 flex-wrap mt-1">
                              {plan.goals.map((goal: string) => (
                                <Badge key={goal} variant="secondary" className="text-xs">
                                  {goal}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex gap-2 mt-4">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUpdatePlanStatus(plan.id, 'draft')}
                            disabled={plan.status === 'draft'}
                          >
                            Draft
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUpdatePlanStatus(plan.id, 'scheduled')}
                            disabled={plan.status === 'scheduled'}
                          >
                            Schedule
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUpdatePlanStatus(plan.id, 'released')}
                            disabled={plan.status === 'released'}
                          >
                            Mark Released
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Dialogs */}
      <ChannelFormDialog
        open={showChannelDialog}
        onOpenChange={setShowChannelDialog}
        onSave={handleCreateChannel}
      />
      
      <PlanFormDialog
        open={showPlanDialog}
        onOpenChange={setShowPlanDialog}
        onSave={handleCreatePlan}
        artifacts={artifacts}
        collections={collections}
        series={series}
        channels={channels}
      />

      {/* Record Event Dialog */}
      <Dialog open={showEventDialog} onOpenChange={setShowEventDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Record Publication Event</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="event-channel">Channel *</Label>
              <Select value={eventChannelId} onValueChange={setEventChannelId}>
                <SelectTrigger id="event-channel">
                  <SelectValue placeholder="Select channel" />
                </SelectTrigger>
                <SelectContent>
                  {channels
                    .filter((ch: PublicationChannel) => selectedPlan?.channelIds.includes(ch.id))
                    .map((ch: PublicationChannel) => (
                      <SelectItem key={ch.id} value={ch.id}>
                        {ch.name} ({ch.channelType})
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="event-title">Event Title *</Label>
              <Input
                id="event-title"
                value={eventTitle}
                onChange={(e) => setEventTitle(e.target.value)}
                placeholder="e.g., Core Docs Launch"
              />
            </div>
            <div>
              <Label htmlFor="event-summary">Summary *</Label>
              <Textarea
                id="event-summary"
                value={eventSummary}
                onChange={(e) => setEventSummary(e.target.value)}
                placeholder="Brief summary of this publication event"
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="event-link">Link / Proof</Label>
              <Input
                id="event-link"
                value={eventLink}
                onChange={(e) => setEventLink(e.target.value)}
                placeholder="https://... or reference"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowEventDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleRecordEvent} disabled={!eventChannelId || !eventTitle || !eventSummary}>
              Record Event
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Plan Brief Dialog */}
      <Dialog open={showBriefDialog} onOpenChange={setShowBriefDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Publication Plan Brief</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="flex justify-end">
              <Button size="sm" variant="outline" onClick={handleCopyBrief}>
                <Copy className="w-4 h-4 mr-2" />
                Copy to Clipboard
              </Button>
            </div>
            <div className="border rounded-lg p-4 bg-gray-50 max-h-[60vh] overflow-y-auto">
              <pre className="text-sm whitespace-pre-wrap font-mono">{planBrief}</pre>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
