'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import type { Collection, CollectionCategory, Artifact } from '@/types/archive';

interface CollectionFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (data: {
    name: string;
    description: string;
    category: CollectionCategory;
    artifactIds: string[];
    tags: string[];
  }) => void;
  initialData?: Collection | null;
  artifacts: Artifact[];
}

export function CollectionFormDialog({ open, onOpenChange, onSave, initialData, artifacts }: CollectionFormDialogProps) {
  const [name, setName] = useState(initialData?.name || '');
  const [description, setDescription] = useState(initialData?.description || '');
  const [category, setCategory] = useState<CollectionCategory>(initialData?.category || 'public');
  const [selectedArtifactIds, setSelectedArtifactIds] = useState<string[]>(initialData?.artifactIds || []);
  const [tagsInput, setTagsInput] = useState(initialData?.tags?.join(', ') || '');

  const handleArtifactToggle = (artifactId: string) => {
    setSelectedArtifactIds((prev: string[]) =>
      prev.includes(artifactId)
        ? prev.filter((id: string) => id !== artifactId)
        : [...prev, artifactId]
    );
  };

  const handleSave = () => {
    const tags = tagsInput.split(',').map((t: string) => t.trim()).filter((t: string) => t.length > 0);
    
    onSave({
      name,
      description,
      category,
      artifactIds: selectedArtifactIds,
      tags,
    });
    
    // Reset form
    setName('');
    setDescription('');
    setCategory('public');
    setSelectedArtifactIds([]);
    setTagsInput('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{initialData ? 'Edit Collection' : 'Create New Collection'}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div>
            <Label htmlFor="name">Name *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., DreamNet Core Documents"
            />
          </div>
          
          <div>
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What does this collection contain?"
              rows={3}
            />
          </div>
          
          <div>
            <Label htmlFor="category">Category *</Label>
            <Select value={category} onValueChange={(value) => setCategory(value as CollectionCategory)}>
              <SelectTrigger id="category">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="internal">Internal</SelectItem>
                <SelectItem value="public">Public</SelectItem>
                <SelectItem value="mixed">Mixed</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label>Select Artifacts</Label>
            <div className="border rounded-md p-4 max-h-60 overflow-y-auto space-y-2">
              {artifacts.length === 0 ? (
                <p className="text-sm text-gray-500">No artifacts available</p>
              ) : (
                artifacts.map((artifact: Artifact) => (
                  <div key={artifact.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={artifact.id}
                      checked={selectedArtifactIds.includes(artifact.id)}
                      onCheckedChange={() => handleArtifactToggle(artifact.id)}
                    />
                    <label
                      htmlFor={artifact.id}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                    >
                      {artifact.title} ({artifact.artifactType})
                    </label>
                  </div>
                ))
              )}
            </div>
            <p className="text-sm text-gray-500 mt-2">Selected: {selectedArtifactIds.length}</p>
          </div>
          
          <div>
            <Label htmlFor="tags">Tags (comma-separated)</Label>
            <Input
              id="tags"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="e.g., core, launch, season-1"
            />
          </div>
        </div>
        
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave} disabled={!name || !description}>
            {initialData ? 'Save Changes' : 'Create Collection'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
