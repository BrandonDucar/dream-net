'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import type {
  PublicationPlan,
  TimingHint,
  Artifact,
  Collection,
  Series,
  PublicationChannel,
} from '@/types/archive';

interface PlanFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (data: {
    name: string;
    description: string;
    artifactIds: string[];
    collectionIds: string[];
    seriesIds: string[];
    channelIds: string[];
    targetAudience: string;
    goals: string[];
    timingHint: TimingHint;
    tags: string[];
  }) => void;
  initialData?: PublicationPlan | null;
  artifacts: Artifact[];
  collections: Collection[];
  series: Series[];
  channels: PublicationChannel[];
}

export function PlanFormDialog({
  open,
  onOpenChange,
  onSave,
  initialData,
  artifacts,
  collections,
  series,
  channels,
}: PlanFormDialogProps) {
  const [name, setName] = useState(initialData?.name || '');
  const [description, setDescription] = useState(initialData?.description || '');
  const [targetAudience, setTargetAudience] = useState(initialData?.targetAudience || '');
  const [goalsInput, setGoalsInput] = useState(initialData?.goals?.join(', ') || '');
  const [timingHint, setTimingHint] = useState<TimingHint>(initialData?.timingHint || 'evergreen');
  const [tagsInput, setTagsInput] = useState(initialData?.tags?.join(', ') || '');
  
  const [selectedArtifactIds, setSelectedArtifactIds] = useState<string[]>(initialData?.artifactIds || []);
  const [selectedCollectionIds, setSelectedCollectionIds] = useState<string[]>(initialData?.collectionIds || []);
  const [selectedSeriesIds, setSelectedSeriesIds] = useState<string[]>(initialData?.seriesIds || []);
  const [selectedChannelIds, setSelectedChannelIds] = useState<string[]>(initialData?.channelIds || []);

  const handleSave = () => {
    const tags = tagsInput.split(',').map((t: string) => t.trim()).filter((t: string) => t.length > 0);
    const goals = goalsInput.split(',').map((g: string) => g.trim()).filter((g: string) => g.length > 0);
    
    onSave({
      name,
      description,
      artifactIds: selectedArtifactIds,
      collectionIds: selectedCollectionIds,
      seriesIds: selectedSeriesIds,
      channelIds: selectedChannelIds,
      targetAudience,
      goals,
      timingHint,
      tags,
    });
    
    // Reset form
    setName('');
    setDescription('');
    setTargetAudience('');
    setGoalsInput('');
    setTimingHint('evergreen');
    setTagsInput('');
    setSelectedArtifactIds([]);
    setSelectedCollectionIds([]);
    setSelectedSeriesIds([]);
    setSelectedChannelIds([]);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{initialData ? 'Edit Publication Plan' : 'Create New Publication Plan'}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div>
            <Label htmlFor="name">Name *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Launch Core Docs"
            />
          </div>
          
          <div>
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What is this publication plan about?"
              rows={3}
            />
          </div>
          
          <div>
            <Label htmlFor="targetAudience">Target Audience *</Label>
            <Input
              id="targetAudience"
              value={targetAudience}
              onChange={(e) => setTargetAudience(e.target.value)}
              placeholder="e.g., new users, developers, community members"
            />
          </div>
          
          <div>
            <Label htmlFor="goals">Goals (comma-separated) *</Label>
            <Input
              id="goals"
              value={goalsInput}
              onChange={(e) => setGoalsInput(e.target.value)}
              placeholder="e.g., educate new users, impress devs, signal culture"
            />
          </div>
          
          <div>
            <Label htmlFor="timingHint">Timing *</Label>
            <Select value={timingHint} onValueChange={(value) => setTimingHint(value as TimingHint)}>
              <SelectTrigger id="timingHint">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="asap">ASAP</SelectItem>
                <SelectItem value="coincide-with-drop">Coincide with Drop</SelectItem>
                <SelectItem value="seasonal">Seasonal</SelectItem>
                <SelectItem value="evergreen">Evergreen</SelectItem>
                <SelectItem value="custom">Custom</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label>Select Artifacts</Label>
            <div className="border rounded-md p-4 max-h-40 overflow-y-auto space-y-2">
              {artifacts.length === 0 ? (
                <p className="text-sm text-gray-500">No artifacts available</p>
              ) : (
                artifacts.map((artifact: Artifact) => (
                  <div key={artifact.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`artifact-${artifact.id}`}
                      checked={selectedArtifactIds.includes(artifact.id)}
                      onCheckedChange={() =>
                        setSelectedArtifactIds((prev: string[]) =>
                          prev.includes(artifact.id)
                            ? prev.filter((id: string) => id !== artifact.id)
                            : [...prev, artifact.id]
                        )
                      }
                    />
                    <label htmlFor={`artifact-${artifact.id}`} className="text-sm cursor-pointer">
                      {artifact.title}
                    </label>
                  </div>
                ))
              )}
            </div>
            <p className="text-sm text-gray-500 mt-1">Selected: {selectedArtifactIds.length}</p>
          </div>
          
          <div>
            <Label>Select Collections</Label>
            <div className="border rounded-md p-4 max-h-40 overflow-y-auto space-y-2">
              {collections.length === 0 ? (
                <p className="text-sm text-gray-500">No collections available</p>
              ) : (
                collections.map((collection: Collection) => (
                  <div key={collection.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`collection-${collection.id}`}
                      checked={selectedCollectionIds.includes(collection.id)}
                      onCheckedChange={() =>
                        setSelectedCollectionIds((prev: string[]) =>
                          prev.includes(collection.id)
                            ? prev.filter((id: string) => id !== collection.id)
                            : [...prev, collection.id]
                        )
                      }
                    />
                    <label htmlFor={`collection-${collection.id}`} className="text-sm cursor-pointer">
                      {collection.name}
                    </label>
                  </div>
                ))
              )}
            </div>
            <p className="text-sm text-gray-500 mt-1">Selected: {selectedCollectionIds.length}</p>
          </div>
          
          <div>
            <Label>Select Series</Label>
            <div className="border rounded-md p-4 max-h-40 overflow-y-auto space-y-2">
              {series.length === 0 ? (
                <p className="text-sm text-gray-500">No series available</p>
              ) : (
                series.map((s: Series) => (
                  <div key={s.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`series-${s.id}`}
                      checked={selectedSeriesIds.includes(s.id)}
                      onCheckedChange={() =>
                        setSelectedSeriesIds((prev: string[]) =>
                          prev.includes(s.id) ? prev.filter((id: string) => id !== s.id) : [...prev, s.id]
                        )
                      }
                    />
                    <label htmlFor={`series-${s.id}`} className="text-sm cursor-pointer">
                      {s.name}
                    </label>
                  </div>
                ))
              )}
            </div>
            <p className="text-sm text-gray-500 mt-1">Selected: {selectedSeriesIds.length}</p>
          </div>
          
          <div>
            <Label>Select Channels *</Label>
            <div className="border rounded-md p-4 max-h-40 overflow-y-auto space-y-2">
              {channels.length === 0 ? (
                <p className="text-sm text-gray-500">No channels available</p>
              ) : (
                channels.map((channel: PublicationChannel) => (
                  <div key={channel.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`channel-${channel.id}`}
                      checked={selectedChannelIds.includes(channel.id)}
                      onCheckedChange={() =>
                        setSelectedChannelIds((prev: string[]) =>
                          prev.includes(channel.id)
                            ? prev.filter((id: string) => id !== channel.id)
                            : [...prev, channel.id]
                        )
                      }
                    />
                    <label htmlFor={`channel-${channel.id}`} className="text-sm cursor-pointer">
                      {channel.name} ({channel.channelType})
                    </label>
                  </div>
                ))
              )}
            </div>
            <p className="text-sm text-gray-500 mt-1">Selected: {selectedChannelIds.length}</p>
          </div>
          
          <div>
            <Label htmlFor="tags">Tags (comma-separated)</Label>
            <Input
              id="tags"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="e.g., launch, priority, q1"
            />
          </div>
        </div>
        
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            onClick={handleSave}
            disabled={!name || !description || !targetAudience || !goalsInput || selectedChannelIds.length === 0}
          >
            {initialData ? 'Save Changes' : 'Create Plan'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
