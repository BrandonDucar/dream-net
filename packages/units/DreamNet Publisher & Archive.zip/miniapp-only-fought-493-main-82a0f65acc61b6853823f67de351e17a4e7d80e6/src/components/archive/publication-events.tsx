'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, ExternalLink, Search } from 'lucide-react';
import type { PublicationEvent, PublicationPlan, PublicationChannel } from '@/types/archive';
import {
  listPublicationEvents,
  listPublicationPlans,
  listPublicationChannels,
} from '@/lib/archive-operations';

export function PublicationEvents() {
  const [events, setEvents] = useState<PublicationEvent[]>([]);
  const [plans, setPlans] = useState<PublicationPlan[]>([]);
  const [channels, setChannels] = useState<PublicationChannel[]>([]);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [channelFilter, setChannelFilter] = useState<string>('all');
  const [planFilter, setPlanFilter] = useState<string>('all');

  useEffect(() => {
    loadData();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const loadData = () => {
    setEvents(listPublicationEvents());
    setPlans(listPublicationPlans());
    setChannels(listPublicationChannels());
  };

  const filteredEvents = events.filter((event: PublicationEvent) => {
    const matchesSearch =
      event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.summary.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesChannel = channelFilter === 'all' || event.channelId === channelFilter;
    const matchesPlan = planFilter === 'all' || event.publicationPlanId === planFilter;
    
    return matchesSearch && matchesChannel && matchesPlan;
  });

  const getPlanName = (planId: string): string => {
    return plans.find((p: PublicationPlan) => p.id === planId)?.name || 'Unknown Plan';
  };

  const getChannelName = (channelId: string): string => {
    return channels.find((c: PublicationChannel) => c.id === channelId)?.name || 'Unknown Channel';
  };

  const getChannelType = (channelId: string): string => {
    return channels.find((c: PublicationChannel) => c.id === channelId)?.channelType || 'other';
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Publication Events</h1>
        <p className="text-gray-600">Track all your content releases</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Total Events</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{events.length}</div>
            <p className="text-xs text-gray-500 mt-1">All-time publications</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">This Month</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {events.filter((e: PublicationEvent) => {
                const eventDate = new Date(e.timestamp);
                const now = new Date();
                return (
                  eventDate.getMonth() === now.getMonth() &&
                  eventDate.getFullYear() === now.getFullYear()
                );
              }).length}
            </div>
            <p className="text-xs text-gray-500 mt-1">Recent activity</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Active Channels</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {new Set(events.map((e: PublicationEvent) => e.channelId)).size}
            </div>
            <p className="text-xs text-gray-500 mt-1">Used for publishing</p>
          </CardContent>
        </Card>
      </div>

      {/* Events Table */}
      <Card>
        <CardHeader>
          <CardTitle>Event History</CardTitle>
          <CardDescription>All recorded publication events</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex gap-4 mb-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search events..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={channelFilter} onValueChange={setChannelFilter}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="Filter by channel" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Channels</SelectItem>
                {channels.map((channel: PublicationChannel) => (
                  <SelectItem key={channel.id} value={channel.id}>
                    {channel.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={planFilter} onValueChange={setPlanFilter}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="Filter by plan" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Plans</SelectItem>
                {plans.map((plan: PublicationPlan) => (
                  <SelectItem key={plan.id} value={plan.id}>
                    {plan.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Events Table */}
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Event Title</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Channel</TableHead>
                  <TableHead>Artifacts</TableHead>
                  <TableHead>Link</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEvents.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                      {events.length === 0
                        ? 'No publication events recorded yet.'
                        : 'No events match your filters.'}
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredEvents.map((event: PublicationEvent) => (
                    <TableRow key={event.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          <span className="text-sm">
                            {new Date(event.timestamp).toLocaleDateString()}
                          </span>
                        </div>
                        <div className="text-xs text-gray-500">
                          {new Date(event.timestamp).toLocaleTimeString()}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{event.title}</div>
                        <div className="text-sm text-gray-600 line-clamp-1">{event.summary}</div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">{getPlanName(event.publicationPlanId)}</div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{getChannelType(event.channelId)}</Badge>
                        <div className="text-sm text-gray-600 mt-1">{getChannelName(event.channelId)}</div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{event.artifactIds.length}</Badge>
                      </TableCell>
                      <TableCell>
                        {event.linkOrProof ? (
                          <a
                            href={event.linkOrProof}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1 text-sm text-blue-600 hover:underline"
                          >
                            View
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        ) : (
                          <span className="text-sm text-gray-400">—</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Timeline View (Optional Enhancement) */}
      {filteredEvents.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Timeline</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {filteredEvents.slice(0, 10).map((event: PublicationEvent) => (
                <div key={event.id} className="flex gap-4 border-l-2 border-blue-500 pl-4">
                  <div className="flex-shrink-0 w-24 text-sm text-gray-500">
                    {new Date(event.timestamp).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                    })}
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">{event.title}</div>
                    <div className="text-sm text-gray-600">
                      via <Badge variant="outline" className="ml-1">{getChannelName(event.channelId)}</Badge>
                    </div>
                    <div className="text-sm text-gray-500 mt-1">{event.summary}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
