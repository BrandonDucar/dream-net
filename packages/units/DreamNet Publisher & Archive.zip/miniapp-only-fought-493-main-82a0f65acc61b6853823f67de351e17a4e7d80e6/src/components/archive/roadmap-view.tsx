'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Copy, Sparkles } from 'lucide-react';
import type { PublicationPlan, Artifact, PlanStatus } from '@/types/archive';
import {
  listPublicationPlans,
  listArtifacts,
  generatePublishingRoadmap,
} from '@/lib/archive-operations';

export function RoadmapView() {
  const [roadmap, setRoadmap] = useState('');
  const [plans, setPlans] = useState<PublicationPlan[]>([]);
  const [artifacts, setArtifacts] = useState<Artifact[]>([]);

  useEffect(() => {
    loadData();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const loadData = () => {
    const allPlans = listPublicationPlans();
    const allArtifacts = listArtifacts();
    const generatedRoadmap = generatePublishingRoadmap();
    
    setPlans(allPlans);
    setArtifacts(allArtifacts);
    setRoadmap(generatedRoadmap);
  };

  const handleCopyRoadmap = () => {
    navigator.clipboard.writeText(roadmap);
  };

  const handleRefresh = () => {
    loadData();
  };

  const plansByStatus: Record<PlanStatus, PublicationPlan[]> = {
    idea: plans.filter((p: PublicationPlan) => p.status === 'idea'),
    draft: plans.filter((p: PublicationPlan) => p.status === 'draft'),
    scheduled: plans.filter((p: PublicationPlan) => p.status === 'scheduled'),
    released: plans.filter((p: PublicationPlan) => p.status === 'released'),
    cancelled: plans.filter((p: PublicationPlan) => p.status === 'cancelled'),
  };

  const readyArtifacts = artifacts.filter((a: Artifact) => a.status === 'ready');

  const getStatusColor = (status: PlanStatus): string => {
    const colors: Record<PlanStatus, string> = {
      idea: 'bg-purple-100 text-purple-800',
      draft: 'bg-yellow-100 text-yellow-800',
      scheduled: 'bg-blue-100 text-blue-800',
      released: 'bg-green-100 text-green-800',
      cancelled: 'bg-gray-100 text-gray-800',
    };
    return colors[status];
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Publishing Roadmap</h1>
          <p className="text-gray-600">Strategic overview of your publication pipeline</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleRefresh}>
            <Sparkles className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button onClick={handleCopyRoadmap}>
            <Copy className="w-4 h-4 mr-2" />
            Copy Roadmap
          </Button>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-purple-700">Ideas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{plansByStatus.idea.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-yellow-700">In Draft</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{plansByStatus.draft.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-blue-700">Scheduled</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{plansByStatus.scheduled.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-green-700">Released</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{plansByStatus.released.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-orange-700">Ready Assets</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{readyArtifacts.length}</div>
            <p className="text-xs text-gray-500 mt-1">Unpublished</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="visual" className="w-full">
        <TabsList>
          <TabsTrigger value="visual">Visual Roadmap</TabsTrigger>
          <TabsTrigger value="text">Text Export</TabsTrigger>
        </TabsList>

        <TabsContent value="visual" className="space-y-6">
          {/* Ready to Publish */}
          {readyArtifacts.length > 0 && (
            <Card className="border-2 border-orange-200 bg-orange-50">
              <CardHeader>
                <CardTitle className="text-orange-800">⚡ Ready to Publish</CardTitle>
                <CardDescription>Artifacts marked as ready but not yet published</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {readyArtifacts.map((artifact: Artifact) => (
                    <div key={artifact.id} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                      <div>
                        <div className="font-medium">{artifact.title}</div>
                        <div className="text-sm text-gray-600">
                          {artifact.artifactType} • {artifact.versionLabel}
                        </div>
                      </div>
                      <Badge className="bg-orange-500">{artifact.importanceLevel}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Ideas */}
          {plansByStatus.idea.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>💡 Ideas ({plansByStatus.idea.length})</CardTitle>
                <CardDescription>Potential publication plans</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {plansByStatus.idea.map((plan: PublicationPlan) => (
                    <div key={plan.id} className="p-4 border rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <div className="font-medium">{plan.name}</div>
                        <Badge className={getStatusColor(plan.status)}>{plan.status}</Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{plan.description}</p>
                      <div className="flex gap-2 text-xs text-gray-500">
                        <span>{plan.artifactIds.length} artifacts</span>
                        <span>•</span>
                        <span>{plan.channelIds.length} channels</span>
                        <span>•</span>
                        <Badge variant="outline" className="text-xs">{plan.timingHint}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* In Draft */}
          {plansByStatus.draft.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>📝 In Draft ({plansByStatus.draft.length})</CardTitle>
                <CardDescription>Plans being refined</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {plansByStatus.draft.map((plan: PublicationPlan) => (
                    <div key={plan.id} className="p-4 border rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <div className="font-medium">{plan.name}</div>
                        <Badge className={getStatusColor(plan.status)}>{plan.status}</Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{plan.description}</p>
                      <div className="flex gap-2 text-xs text-gray-500">
                        <span>{plan.artifactIds.length} artifacts</span>
                        <span>•</span>
                        <span>{plan.channelIds.length} channels</span>
                        <span>•</span>
                        <Badge variant="outline" className="text-xs">{plan.timingHint}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Scheduled */}
          {plansByStatus.scheduled.length > 0 && (
            <Card className="border-2 border-blue-200">
              <CardHeader>
                <CardTitle className="text-blue-800">📅 Scheduled ({plansByStatus.scheduled.length})</CardTitle>
                <CardDescription>Ready to execute</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {plansByStatus.scheduled.map((plan: PublicationPlan) => (
                    <div key={plan.id} className="p-4 border rounded-lg bg-blue-50">
                      <div className="flex items-start justify-between mb-2">
                        <div className="font-medium">{plan.name}</div>
                        <Badge className={getStatusColor(plan.status)}>{plan.status}</Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{plan.description}</p>
                      <div className="flex gap-2 text-xs text-gray-500">
                        <span>{plan.artifactIds.length} artifacts</span>
                        <span>•</span>
                        <span>{plan.channelIds.length} channels</span>
                        <span>•</span>
                        <Badge variant="outline" className="text-xs">{plan.timingHint}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Released */}
          {plansByStatus.released.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>✅ Released ({plansByStatus.released.length})</CardTitle>
                <CardDescription>Successfully published</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {plansByStatus.released.slice(0, 5).map((plan: PublicationPlan) => (
                    <div key={plan.id} className="p-4 border rounded-lg opacity-75">
                      <div className="flex items-start justify-between mb-2">
                        <div className="font-medium">{plan.name}</div>
                        <Badge className={getStatusColor(plan.status)}>{plan.status}</Badge>
                      </div>
                      <p className="text-sm text-gray-600">{plan.description}</p>
                    </div>
                  ))}
                  {plansByStatus.released.length > 5 && (
                    <p className="text-sm text-gray-500 text-center">
                      + {plansByStatus.released.length - 5} more released plans
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {plans.length === 0 && (
            <Card>
              <CardContent className="text-center py-12 text-gray-500">
                No publication plans yet. Create your first plan to see your roadmap.
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="text" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Text Roadmap Export</CardTitle>
                  <CardDescription>Copy this to share or use in documents</CardDescription>
                </div>
                <Button variant="outline" onClick={handleCopyRoadmap}>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy All
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg p-4 bg-gray-50 max-h-[600px] overflow-y-auto">
                <pre className="text-sm whitespace-pre-wrap font-mono">{roadmap}</pre>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
