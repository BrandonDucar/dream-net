'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { ArrowUp, ArrowDown } from 'lucide-react';
import type { Series, Artifact } from '@/types/archive';

interface SeriesFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (data: {
    name: string;
    description: string;
    sequenceArtifactIds: string[];
    tags: string[];
  }) => void;
  initialData?: Series | null;
  artifacts: Artifact[];
}

export function SeriesFormDialog({ open, onOpenChange, onSave, initialData, artifacts }: SeriesFormDialogProps) {
  const [name, setName] = useState(initialData?.name || '');
  const [description, setDescription] = useState(initialData?.description || '');
  const [selectedArtifactIds, setSelectedArtifactIds] = useState<string[]>(initialData?.sequenceArtifactIds || []);
  const [tagsInput, setTagsInput] = useState(initialData?.tags?.join(', ') || '');

  const handleArtifactToggle = (artifactId: string) => {
    setSelectedArtifactIds((prev: string[]) =>
      prev.includes(artifactId)
        ? prev.filter((id: string) => id !== artifactId)
        : [...prev, artifactId]
    );
  };

  const moveUp = (index: number) => {
    if (index === 0) return;
    const newOrder = [...selectedArtifactIds];
    [newOrder[index - 1], newOrder[index]] = [newOrder[index], newOrder[index - 1]];
    setSelectedArtifactIds(newOrder);
  };

  const moveDown = (index: number) => {
    if (index === selectedArtifactIds.length - 1) return;
    const newOrder = [...selectedArtifactIds];
    [newOrder[index], newOrder[index + 1]] = [newOrder[index + 1], newOrder[index]];
    setSelectedArtifactIds(newOrder);
  };

  const handleSave = () => {
    const tags = tagsInput.split(',').map((t: string) => t.trim()).filter((t: string) => t.length > 0);
    
    onSave({
      name,
      description,
      sequenceArtifactIds: selectedArtifactIds,
      tags,
    });
    
    // Reset form
    setName('');
    setDescription('');
    setSelectedArtifactIds([]);
    setTagsInput('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{initialData ? 'Edit Series' : 'Create New Series'}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div>
            <Label htmlFor="name">Name *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., DreamNet Books"
            />
          </div>
          
          <div>
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What is this series about?"
              rows={3}
            />
          </div>
          
          <div>
            <Label>Select & Order Artifacts</Label>
            <div className="border rounded-md p-4 max-h-60 overflow-y-auto space-y-2">
              {artifacts.length === 0 ? (
                <p className="text-sm text-gray-500">No artifacts available</p>
              ) : (
                artifacts.map((artifact: Artifact) => (
                  <div key={artifact.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={artifact.id}
                      checked={selectedArtifactIds.includes(artifact.id)}
                      onCheckedChange={() => handleArtifactToggle(artifact.id)}
                    />
                    <label
                      htmlFor={artifact.id}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer flex-1"
                    >
                      {artifact.title} ({artifact.artifactType})
                    </label>
                  </div>
                ))
              )}
            </div>
          </div>
          
          {selectedArtifactIds.length > 0 && (
            <div>
              <Label>Series Order (drag to reorder)</Label>
              <div className="border rounded-md p-4 space-y-2">
                {selectedArtifactIds.map((artifactId: string, index: number) => {
                  const artifact = artifacts.find((a: Artifact) => a.id === artifactId);
                  if (!artifact) return null;
                  
                  return (
                    <div key={artifactId} className="flex items-center gap-2 bg-gray-50 p-2 rounded">
                      <span className="text-sm font-bold w-8">{index + 1}.</span>
                      <span className="flex-1 text-sm">{artifact.title}</span>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => moveUp(index)}
                          disabled={index === 0}
                        >
                          <ArrowUp className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => moveDown(index)}
                          disabled={index === selectedArtifactIds.length - 1}
                        >
                          <ArrowDown className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
          
          <div>
            <Label htmlFor="tags">Tags (comma-separated)</Label>
            <Input
              id="tags"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="e.g., books, educational, season-1"
            />
          </div>
        </div>
        
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave} disabled={!name || !description}>
            {initialData ? 'Save Changes' : 'Create Series'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
