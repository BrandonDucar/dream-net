import type {
  Artifact,
  ArtifactContentRef,
  Collection,
  Series,
  PublicationChannel,
  PublicationPlan,
  PublicationEvent,
  ArtifactType,
  ImportanceLevel,
  CollectionCategory,
  ChannelType,
  TimingHint,
  ArtifactStatus,
  PlanStatus,
  ContentType,
  SEOMeta,
} from '@/types/archive';
import { loadArchiveData, saveArchiveData } from './storage';

// Utility functions
function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

function generateSEOMeta(title: string, description: string, tags: string[]): SEOMeta {
  const seoTitle = title.length > 60 ? `${title.substring(0, 57)}...` : title;
  const seoDescription = description.length > 160 ? `${description.substring(0, 157)}...` : description;
  const seoKeywords = tags.slice(0, 10);
  const seoHashtags = tags.slice(0, 5).map((tag: string) => `#${tag.replace(/\s+/g, '')}`);
  
  return {
    seoTitle,
    seoDescription,
    seoKeywords,
    seoHashtags,
    altText: title,
  };
}

// Artifact Operations
export function createArtifact(input: {
  title: string;
  artifactType: ArtifactType;
  sourceApp: string | null;
  description: string;
  contentSummary: string;
  versionLabel: string;
  importanceLevel: ImportanceLevel;
  tags?: string[];
}): Artifact {
  const data = loadArchiveData();
  const now = new Date().toISOString();
  const tags = input.tags || [];
  const seoMeta = generateSEOMeta(input.title, input.description, tags);
  
  const artifact: Artifact = {
    id: generateId(),
    title: input.title,
    slug: generateSlug(input.title),
    artifactType: input.artifactType,
    sourceApp: input.sourceApp,
    description: input.description,
    contentSummary: input.contentSummary,
    versionLabel: input.versionLabel,
    tags,
    importanceLevel: input.importanceLevel,
    status: 'draft',
    notes: '',
    createdAt: now,
    updatedAt: now,
    ...seoMeta,
  };
  
  data.artifacts.push(artifact);
  saveArchiveData(data);
  return artifact;
}

export function updateArtifact(id: string, updates: Partial<Omit<Artifact, 'id' | 'createdAt'>>): Artifact | null {
  const data = loadArchiveData();
  const index = data.artifacts.findIndex((a: Artifact) => a.id === id);
  
  if (index === -1) return null;
  
  const artifact = data.artifacts[index];
  const updated: Artifact = {
    ...artifact,
    ...updates,
    updatedAt: new Date().toISOString(),
  };
  
  data.artifacts[index] = updated;
  saveArchiveData(data);
  return updated;
}

export function deleteArtifact(id: string): boolean {
  const data = loadArchiveData();
  const index = data.artifacts.findIndex((a: Artifact) => a.id === id);
  
  if (index === -1) return false;
  
  data.artifacts.splice(index, 1);
  data.artifactContentRefs = data.artifactContentRefs.filter((ref: ArtifactContentRef) => ref.artifactId !== id);
  saveArchiveData(data);
  return true;
}

export function getArtifact(id: string): Artifact | null {
  const data = loadArchiveData();
  return data.artifacts.find((a: Artifact) => a.id === id) || null;
}

export function listArtifacts(filter?: {
  artifactType?: ArtifactType;
  sourceApp?: string;
  status?: ArtifactStatus;
  importanceLevel?: ImportanceLevel;
  tag?: string;
}): Artifact[] {
  const data = loadArchiveData();
  let artifacts = data.artifacts;
  
  if (filter?.artifactType) {
    artifacts = artifacts.filter((a: Artifact) => a.artifactType === filter.artifactType);
  }
  if (filter?.sourceApp) {
    artifacts = artifacts.filter((a: Artifact) => a.sourceApp === filter.sourceApp);
  }
  if (filter?.status) {
    artifacts = artifacts.filter((a: Artifact) => a.status === filter.status);
  }
  if (filter?.importanceLevel) {
    artifacts = artifacts.filter((a: Artifact) => a.importanceLevel === filter.importanceLevel);
  }
  if (filter?.tag) {
    artifacts = artifacts.filter((a: Artifact) => a.tags.includes(filter.tag as string));
  }
  
  return artifacts.sort((a: Artifact, b: Artifact) => 
    new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  );
}

// ArtifactContentRef Operations
export function addArtifactContentRef(input: {
  artifactId: string;
  contentType: ContentType;
  storageHint: string;
  contentExcerpt: string;
  notes?: string;
}): ArtifactContentRef | null {
  const data = loadArchiveData();
  const artifact = data.artifacts.find((a: Artifact) => a.id === input.artifactId);
  
  if (!artifact) return null;
  
  const contentRef: ArtifactContentRef = {
    id: generateId(),
    artifactId: input.artifactId,
    contentType: input.contentType,
    storageHint: input.storageHint,
    contentExcerpt: input.contentExcerpt,
    notes: input.notes || '',
    createdAt: new Date().toISOString(),
  };
  
  data.artifactContentRefs.push(contentRef);
  saveArchiveData(data);
  return contentRef;
}

export function updateArtifactContentRef(
  id: string,
  updates: Partial<Omit<ArtifactContentRef, 'id' | 'artifactId' | 'createdAt'>>
): ArtifactContentRef | null {
  const data = loadArchiveData();
  const index = data.artifactContentRefs.findIndex((ref: ArtifactContentRef) => ref.id === id);
  
  if (index === -1) return null;
  
  const updated: ArtifactContentRef = {
    ...data.artifactContentRefs[index],
    ...updates,
  };
  
  data.artifactContentRefs[index] = updated;
  saveArchiveData(data);
  return updated;
}

export function deleteArtifactContentRef(id: string): boolean {
  const data = loadArchiveData();
  const index = data.artifactContentRefs.findIndex((ref: ArtifactContentRef) => ref.id === id);
  
  if (index === -1) return false;
  
  data.artifactContentRefs.splice(index, 1);
  saveArchiveData(data);
  return true;
}

export function getArtifactContentRefs(artifactId: string): ArtifactContentRef[] {
  const data = loadArchiveData();
  return data.artifactContentRefs.filter((ref: ArtifactContentRef) => ref.artifactId === artifactId);
}

// Collection Operations
export function createCollection(input: {
  name: string;
  description: string;
  category: CollectionCategory;
  artifactIds?: string[];
  tags?: string[];
}): Collection {
  const data = loadArchiveData();
  const now = new Date().toISOString();
  const tags = input.tags || [];
  const seoMeta = generateSEOMeta(input.name, input.description, tags);
  
  const collection: Collection = {
    id: generateId(),
    name: input.name,
    slug: generateSlug(input.name),
    description: input.description,
    category: input.category,
    artifactIds: input.artifactIds || [],
    tags,
    notes: '',
    createdAt: now,
    updatedAt: now,
    ...seoMeta,
  };
  
  data.collections.push(collection);
  saveArchiveData(data);
  return collection;
}

export function updateCollection(id: string, updates: Partial<Omit<Collection, 'id' | 'createdAt'>>): Collection | null {
  const data = loadArchiveData();
  const index = data.collections.findIndex((c: Collection) => c.id === id);
  
  if (index === -1) return null;
  
  const updated: Collection = {
    ...data.collections[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };
  
  data.collections[index] = updated;
  saveArchiveData(data);
  return updated;
}

export function deleteCollection(id: string): boolean {
  const data = loadArchiveData();
  const index = data.collections.findIndex((c: Collection) => c.id === id);
  
  if (index === -1) return false;
  
  data.collections.splice(index, 1);
  saveArchiveData(data);
  return true;
}

export function getCollection(id: string): Collection | null {
  const data = loadArchiveData();
  return data.collections.find((c: Collection) => c.id === id) || null;
}

export function listCollections(filter?: { category?: CollectionCategory; tag?: string }): Collection[] {
  const data = loadArchiveData();
  let collections = data.collections;
  
  if (filter?.category) {
    collections = collections.filter((c: Collection) => c.category === filter.category);
  }
  if (filter?.tag) {
    collections = collections.filter((c: Collection) => c.tags.includes(filter.tag as string));
  }
  
  return collections.sort((a: Collection, b: Collection) => 
    new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  );
}

// Series Operations
export function createSeries(input: {
  name: string;
  description: string;
  sequenceArtifactIds: string[];
  tags?: string[];
}): Series {
  const data = loadArchiveData();
  const now = new Date().toISOString();
  const tags = input.tags || [];
  const seoMeta = generateSEOMeta(input.name, input.description, tags);
  
  const series: Series = {
    id: generateId(),
    name: input.name,
    slug: generateSlug(input.name),
    description: input.description,
    sequenceArtifactIds: input.sequenceArtifactIds,
    tags,
    notes: '',
    createdAt: now,
    updatedAt: now,
    ...seoMeta,
  };
  
  data.series.push(series);
  saveArchiveData(data);
  return series;
}

export function updateSeries(id: string, updates: Partial<Omit<Series, 'id' | 'createdAt'>>): Series | null {
  const data = loadArchiveData();
  const index = data.series.findIndex((s: Series) => s.id === id);
  
  if (index === -1) return null;
  
  const updated: Series = {
    ...data.series[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };
  
  data.series[index] = updated;
  saveArchiveData(data);
  return updated;
}

export function deleteSeries(id: string): boolean {
  const data = loadArchiveData();
  const index = data.series.findIndex((s: Series) => s.id === id);
  
  if (index === -1) return false;
  
  data.series.splice(index, 1);
  saveArchiveData(data);
  return true;
}

export function getSeries(id: string): Series | null {
  const data = loadArchiveData();
  return data.series.find((s: Series) => s.id === id) || null;
}

export function listSeries(filter?: { tag?: string }): Series[] {
  const data = loadArchiveData();
  let series = data.series;
  
  if (filter?.tag) {
    series = series.filter((s: Series) => s.tags.includes(filter.tag as string));
  }
  
  return series.sort((a: Series, b: Series) => 
    new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  );
}

// PublicationChannel Operations
export function createPublicationChannel(input: {
  name: string;
  channelType: ChannelType;
  description: string;
  urlOrRef?: string | null;
  tags?: string[];
}): PublicationChannel {
  const data = loadArchiveData();
  const now = new Date().toISOString();
  
  const channel: PublicationChannel = {
    id: generateId(),
    name: input.name,
    slug: generateSlug(input.name),
    description: input.description,
    channelType: input.channelType,
    urlOrRef: input.urlOrRef || null,
    tags: input.tags || [],
    notes: '',
    createdAt: now,
    updatedAt: now,
  };
  
  data.publicationChannels.push(channel);
  saveArchiveData(data);
  return channel;
}

export function updatePublicationChannel(
  id: string,
  updates: Partial<Omit<PublicationChannel, 'id' | 'createdAt'>>
): PublicationChannel | null {
  const data = loadArchiveData();
  const index = data.publicationChannels.findIndex((ch: PublicationChannel) => ch.id === id);
  
  if (index === -1) return null;
  
  const updated: PublicationChannel = {
    ...data.publicationChannels[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };
  
  data.publicationChannels[index] = updated;
  saveArchiveData(data);
  return updated;
}

export function deletePublicationChannel(id: string): boolean {
  const data = loadArchiveData();
  const index = data.publicationChannels.findIndex((ch: PublicationChannel) => ch.id === id);
  
  if (index === -1) return false;
  
  data.publicationChannels.splice(index, 1);
  saveArchiveData(data);
  return true;
}

export function getPublicationChannel(id: string): PublicationChannel | null {
  const data = loadArchiveData();
  return data.publicationChannels.find((ch: PublicationChannel) => ch.id === id) || null;
}

export function listPublicationChannels(filter?: { channelType?: ChannelType; tag?: string }): PublicationChannel[] {
  const data = loadArchiveData();
  let channels = data.publicationChannels;
  
  if (filter?.channelType) {
    channels = channels.filter((ch: PublicationChannel) => ch.channelType === filter.channelType);
  }
  if (filter?.tag) {
    channels = channels.filter((ch: PublicationChannel) => ch.tags.includes(filter.tag as string));
  }
  
  return channels.sort((a: PublicationChannel, b: PublicationChannel) => 
    new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  );
}

// PublicationPlan Operations
export function createPublicationPlan(input: {
  name: string;
  description: string;
  artifactIds: string[];
  collectionIds: string[];
  seriesIds: string[];
  channelIds: string[];
  targetAudience: string;
  goals: string[];
  timingHint: TimingHint;
  tags?: string[];
}): PublicationPlan {
  const data = loadArchiveData();
  const now = new Date().toISOString();
  const tags = input.tags || [];
  const seoMeta = generateSEOMeta(input.name, input.description, tags);
  
  const plan: PublicationPlan = {
    id: generateId(),
    name: input.name,
    description: input.description,
    artifactIds: input.artifactIds,
    collectionIds: input.collectionIds,
    seriesIds: input.seriesIds,
    channelIds: input.channelIds,
    targetAudience: input.targetAudience,
    goals: input.goals,
    timingHint: input.timingHint,
    status: 'idea',
    tags,
    notes: '',
    createdAt: now,
    updatedAt: now,
    ...seoMeta,
  };
  
  data.publicationPlans.push(plan);
  saveArchiveData(data);
  return plan;
}

export function updatePublicationPlan(
  id: string,
  updates: Partial<Omit<PublicationPlan, 'id' | 'createdAt'>>
): PublicationPlan | null {
  const data = loadArchiveData();
  const index = data.publicationPlans.findIndex((p: PublicationPlan) => p.id === id);
  
  if (index === -1) return null;
  
  const updated: PublicationPlan = {
    ...data.publicationPlans[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };
  
  data.publicationPlans[index] = updated;
  saveArchiveData(data);
  return updated;
}

export function deletePublicationPlan(id: string): boolean {
  const data = loadArchiveData();
  const index = data.publicationPlans.findIndex((p: PublicationPlan) => p.id === id);
  
  if (index === -1) return false;
  
  data.publicationPlans.splice(index, 1);
  saveArchiveData(data);
  return true;
}

export function getPublicationPlan(id: string): PublicationPlan | null {
  const data = loadArchiveData();
  return data.publicationPlans.find((p: PublicationPlan) => p.id === id) || null;
}

export function listPublicationPlans(filter?: { status?: PlanStatus; tag?: string }): PublicationPlan[] {
  const data = loadArchiveData();
  let plans = data.publicationPlans;
  
  if (filter?.status) {
    plans = plans.filter((p: PublicationPlan) => p.status === filter.status);
  }
  if (filter?.tag) {
    plans = plans.filter((p: PublicationPlan) => p.tags.includes(filter.tag as string));
  }
  
  return plans.sort((a: PublicationPlan, b: PublicationPlan) => 
    new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  );
}

// PublicationEvent Operations
export function recordPublicationEvent(input: {
  publicationPlanId: string;
  channelId: string;
  artifactIds: string[];
  title: string;
  summary: string;
  linkOrProof?: string | null;
  notes?: string;
}): PublicationEvent | null {
  const data = loadArchiveData();
  const plan = data.publicationPlans.find((p: PublicationPlan) => p.id === input.publicationPlanId);
  const channel = data.publicationChannels.find((ch: PublicationChannel) => ch.id === input.channelId);
  
  if (!plan || !channel) return null;
  
  const event: PublicationEvent = {
    id: generateId(),
    publicationPlanId: input.publicationPlanId,
    channelId: input.channelId,
    artifactIds: input.artifactIds,
    timestamp: new Date().toISOString(),
    title: input.title,
    summary: input.summary,
    linkOrProof: input.linkOrProof || null,
    notes: input.notes || '',
  };
  
  data.publicationEvents.push(event);
  saveArchiveData(data);
  return event;
}

export function updatePublicationEvent(
  id: string,
  updates: Partial<Omit<PublicationEvent, 'id' | 'timestamp'>>
): PublicationEvent | null {
  const data = loadArchiveData();
  const index = data.publicationEvents.findIndex((e: PublicationEvent) => e.id === id);
  
  if (index === -1) return null;
  
  const updated: PublicationEvent = {
    ...data.publicationEvents[index],
    ...updates,
  };
  
  data.publicationEvents[index] = updated;
  saveArchiveData(data);
  return updated;
}

export function deletePublicationEvent(id: string): boolean {
  const data = loadArchiveData();
  const index = data.publicationEvents.findIndex((e: PublicationEvent) => e.id === id);
  
  if (index === -1) return false;
  
  data.publicationEvents.splice(index, 1);
  saveArchiveData(data);
  return true;
}

export function listPublicationEvents(filter?: {
  channelId?: string;
  planId?: string;
  startDate?: string;
  endDate?: string;
}): PublicationEvent[] {
  const data = loadArchiveData();
  let events = data.publicationEvents;
  
  if (filter?.channelId) {
    events = events.filter((e: PublicationEvent) => e.channelId === filter.channelId);
  }
  if (filter?.planId) {
    events = events.filter((e: PublicationEvent) => e.publicationPlanId === filter.planId);
  }
  if (filter?.startDate) {
    events = events.filter((e: PublicationEvent) => e.timestamp >= (filter.startDate as string));
  }
  if (filter?.endDate) {
    events = events.filter((e: PublicationEvent) => e.timestamp <= (filter.endDate as string));
  }
  
  return events.sort((a: PublicationEvent, b: PublicationEvent) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
}

// Artifact Detail View
export function getArtifactDetail(id: string): {
  artifact: Artifact;
  contentRefs: ArtifactContentRef[];
  collections: Collection[];
  series: Series[];
  publicationPlans: PublicationPlan[];
  publicationEvents: PublicationEvent[];
} | null {
  const artifact = getArtifact(id);
  if (!artifact) return null;
  
  const data = loadArchiveData();
  const contentRefs = getArtifactContentRefs(id);
  const collections = data.collections.filter((c: Collection) => c.artifactIds.includes(id));
  const series = data.series.filter((s: Series) => s.sequenceArtifactIds.includes(id));
  const publicationPlans = data.publicationPlans.filter((p: PublicationPlan) => p.artifactIds.includes(id));
  const publicationEvents = data.publicationEvents.filter((e: PublicationEvent) => e.artifactIds.includes(id));
  
  return {
    artifact,
    contentRefs,
    collections,
    series,
    publicationPlans,
    publicationEvents,
  };
}

// Brief Generation
export function generateArtifactPublishingBrief(artifactId: string): string {
  const detail = getArtifactDetail(artifactId);
  if (!detail) return 'Artifact not found.';
  
  const { artifact, collections, series } = detail;
  
  let brief = `# Publishing Brief: ${artifact.title}\n\n`;
  brief += `## Overview\n`;
  brief += `**Type:** ${artifact.artifactType}\n`;
  brief += `**Version:** ${artifact.versionLabel}\n`;
  brief += `**Status:** ${artifact.status}\n`;
  brief += `**Importance:** ${artifact.importanceLevel}\n`;
  brief += `**Source:** ${artifact.sourceApp || 'N/A'}\n\n`;
  
  brief += `## What It Is\n${artifact.description}\n\n`;
  brief += `## Content Summary\n${artifact.contentSummary}\n\n`;
  
  brief += `## Target Audience\n`;
  const audienceMap: Record<ArtifactType, string> = {
    lore: 'Culture enthusiasts, community members, storytellers',
    documentation: 'Developers, technical users, implementers',
    playbook: 'Operators, team leads, practitioners',
    report: 'Stakeholders, decision makers, analysts',
    map: 'Navigators, strategists, planners',
    manual: 'End users, learners, educators',
    guide: 'New users, onboarding cohorts, explorers',
    codex: 'Deep divers, researchers, archivists',
    other: 'General audience',
  };
  brief += `${audienceMap[artifact.artifactType]}\n\n`;
  
  brief += `## Recommended Channels\n`;
  const channelMap: Record<ArtifactType, string[]> = {
    lore: ['website', 'blog', 'newsletter', 'frame'],
    documentation: ['website', 'blog', 'pdf-bundle'],
    playbook: ['pdf-bundle', 'website', 'newsletter'],
    report: ['pdf-bundle', 'newsletter', 'website'],
    map: ['website', 'frame', 'blog'],
    manual: ['pdf-bundle', 'website', 'zora'],
    guide: ['website', 'blog', 'newsletter'],
    codex: ['pdf-bundle', 'zora', 'website'],
    other: ['website', 'blog'],
  };
  channelMap[artifact.artifactType].forEach((ch: string) => {
    brief += `- ${ch}\n`;
  });
  brief += `\n`;
  
  brief += `## SEO & Messaging\n`;
  brief += `**Title:** ${artifact.seoTitle}\n`;
  brief += `**Description:** ${artifact.seoDescription}\n`;
  brief += `**Keywords:** ${artifact.seoKeywords.join(', ')}\n`;
  brief += `**Hashtags:** ${artifact.seoHashtags.join(' ')}\n\n`;
  
  if (collections.length > 0 || series.length > 0) {
    brief += `## Bundling Suggestions\n`;
    if (collections.length > 0) {
      brief += `**Already in Collections:**\n`;
      collections.forEach((c: Collection) => {
        brief += `- ${c.name} (${c.category})\n`;
      });
    }
    if (series.length > 0) {
      brief += `**Already in Series:**\n`;
      series.forEach((s: Series) => {
        brief += `- ${s.name}\n`;
      });
    }
  } else {
    brief += `## Bundling Suggestions\n`;
    brief += `Consider creating a collection or series to group this artifact with related content.\n`;
  }
  
  if (artifact.tags.length > 0) {
    brief += `\n**Tags:** ${artifact.tags.join(', ')}\n`;
  }
  
  return brief;
}

export function generatePublicationPlanBrief(planId: string): string {
  const plan = getPublicationPlan(planId);
  if (!plan) return 'Publication plan not found.';
  
  const data = loadArchiveData();
  const artifacts = data.artifacts.filter((a: Artifact) => plan.artifactIds.includes(a.id));
  const collections = data.collections.filter((c: Collection) => plan.collectionIds.includes(c.id));
  const series = data.series.filter((s: Series) => plan.seriesIds.includes(s.id));
  const channels = data.publicationChannels.filter((ch: PublicationChannel) => plan.channelIds.includes(ch.id));
  
  let brief = `# Publication Plan Brief: ${plan.name}\n\n`;
  brief += `## Status: ${plan.status.toUpperCase()}\n\n`;
  brief += `## Description\n${plan.description}\n\n`;
  
  brief += `## Target Audience\n${plan.targetAudience}\n\n`;
  
  brief += `## Goals\n`;
  plan.goals.forEach((goal: string) => {
    brief += `- ${goal}\n`;
  });
  brief += `\n`;
  
  brief += `## Timing\n${plan.timingHint}\n\n`;
  
  if (artifacts.length > 0) {
    brief += `## Artifacts (${artifacts.length})\n`;
    artifacts.forEach((a: Artifact) => {
      brief += `- ${a.title} (${a.artifactType}, ${a.status})\n`;
    });
    brief += `\n`;
  }
  
  if (collections.length > 0) {
    brief += `## Collections (${collections.length})\n`;
    collections.forEach((c: Collection) => {
      brief += `- ${c.name} (${c.artifactIds.length} artifacts)\n`;
    });
    brief += `\n`;
  }
  
  if (series.length > 0) {
    brief += `## Series (${series.length})\n`;
    series.forEach((s: Series) => {
      brief += `- ${s.name} (${s.sequenceArtifactIds.length} artifacts)\n`;
    });
    brief += `\n`;
  }
  
  if (channels.length > 0) {
    brief += `## Publication Channels (${channels.length})\n`;
    channels.forEach((ch: PublicationChannel) => {
      brief += `- ${ch.name} (${ch.channelType})`;
      if (ch.urlOrRef) brief += ` - ${ch.urlOrRef}`;
      brief += `\n`;
    });
    brief += `\n`;
  }
  
  brief += `## Prerequisites\n`;
  const notReadyArtifacts = artifacts.filter((a: Artifact) => a.status !== 'ready' && a.status !== 'published');
  if (notReadyArtifacts.length > 0) {
    brief += `⚠️ **${notReadyArtifacts.length} artifacts not yet ready:**\n`;
    notReadyArtifacts.forEach((a: Artifact) => {
      brief += `- ${a.title} (${a.status})\n`;
    });
  } else {
    brief += `✅ All artifacts are ready or published\n`;
  }
  
  brief += `\n## SEO & Messaging\n`;
  brief += `**Title:** ${plan.seoTitle}\n`;
  brief += `**Description:** ${plan.seoDescription}\n`;
  brief += `**Keywords:** ${plan.seoKeywords.join(', ')}\n`;
  brief += `**Hashtags:** ${plan.seoHashtags.join(' ')}\n`;
  
  if (plan.tags.length > 0) {
    brief += `\n**Tags:** ${plan.tags.join(', ')}\n`;
  }
  
  return brief;
}

export function generatePublishingRoadmap(): string {
  const data = loadArchiveData();
  const plans = data.publicationPlans;
  const artifacts = data.artifacts;
  const channels = data.publicationChannels;
  
  let roadmap = `# DreamNet Publishing Roadmap\n\n`;
  roadmap += `Generated: ${new Date().toLocaleDateString()}\n\n`;
  
  // Group plans by status
  const plansByStatus: Record<PlanStatus, PublicationPlan[]> = {
    idea: [],
    draft: [],
    scheduled: [],
    released: [],
    cancelled: [],
  };
  
  plans.forEach((plan: PublicationPlan) => {
    plansByStatus[plan.status].push(plan);
  });
  
  roadmap += `## Summary\n`;
  roadmap += `- **Ideas:** ${plansByStatus.idea.length}\n`;
  roadmap += `- **In Draft:** ${plansByStatus.draft.length}\n`;
  roadmap += `- **Scheduled:** ${plansByStatus.scheduled.length}\n`;
  roadmap += `- **Released:** ${plansByStatus.released.length}\n`;
  roadmap += `- **Cancelled:** ${plansByStatus.cancelled.length}\n\n`;
  
  // Ready but not released artifacts
  const readyArtifacts = artifacts.filter((a: Artifact) => a.status === 'ready');
  roadmap += `## Ready to Publish (${readyArtifacts.length} artifacts)\n`;
  if (readyArtifacts.length > 0) {
    readyArtifacts.forEach((a: Artifact) => {
      roadmap += `- ${a.title} (${a.artifactType})\n`;
    });
  } else {
    roadmap += `No artifacts marked as ready.\n`;
  }
  roadmap += `\n`;
  
  // Ideas
  if (plansByStatus.idea.length > 0) {
    roadmap += `## Ideas (${plansByStatus.idea.length})\n`;
    plansByStatus.idea.forEach((plan: PublicationPlan) => {
      roadmap += `### ${plan.name}\n`;
      roadmap += `${plan.description}\n`;
      roadmap += `- Artifacts: ${plan.artifactIds.length}\n`;
      roadmap += `- Channels: ${plan.channelIds.length}\n`;
      roadmap += `- Timing: ${plan.timingHint}\n\n`;
    });
  }
  
  // In Draft
  if (plansByStatus.draft.length > 0) {
    roadmap += `## In Draft (${plansByStatus.draft.length})\n`;
    plansByStatus.draft.forEach((plan: PublicationPlan) => {
      roadmap += `### ${plan.name}\n`;
      roadmap += `${plan.description}\n`;
      roadmap += `- Artifacts: ${plan.artifactIds.length}\n`;
      roadmap += `- Channels: ${plan.channelIds.length}\n`;
      roadmap += `- Timing: ${plan.timingHint}\n\n`;
    });
  }
  
  // Scheduled
  if (plansByStatus.scheduled.length > 0) {
    roadmap += `## Scheduled (${plansByStatus.scheduled.length})\n`;
    plansByStatus.scheduled.forEach((plan: PublicationPlan) => {
      roadmap += `### ${plan.name}\n`;
      roadmap += `${plan.description}\n`;
      roadmap += `- Artifacts: ${plan.artifactIds.length}\n`;
      roadmap += `- Channels: ${plan.channelIds.length}\n`;
      roadmap += `- Timing: ${plan.timingHint}\n\n`;
    });
  }
  
  // Recently Released
  if (plansByStatus.released.length > 0) {
    roadmap += `## Recently Released (${plansByStatus.released.length})\n`;
    plansByStatus.released.forEach((plan: PublicationPlan) => {
      roadmap += `### ${plan.name}\n`;
      roadmap += `${plan.description}\n`;
      roadmap += `- Artifacts: ${plan.artifactIds.length}\n`;
      roadmap += `- Channels: ${plan.channelIds.length}\n\n`;
    });
  }
  
  // Channel usage analysis
  roadmap += `## Channel Usage Analysis\n`;
  const channelUsage: Record<string, number> = {};
  channels.forEach((ch: PublicationChannel) => {
    const usageCount = plans.filter((p: PublicationPlan) => p.channelIds.includes(ch.id)).length;
    channelUsage[ch.name] = usageCount;
  });
  
  const sortedChannels = Object.entries(channelUsage).sort((a, b) => b[1] - a[1]);
  sortedChannels.forEach(([name, count]) => {
    roadmap += `- **${name}:** ${count} plan(s)\n`;
  });
  
  return roadmap;
}

export function exportPublishingCatalog(): string {
  const data = loadArchiveData();
  
  let catalog = `# DreamNet Archive & Publishing Catalog v1\n\n`;
  catalog += `Generated: ${new Date().toISOString()}\n\n`;
  
  catalog += `## Summary\n`;
  catalog += `- **Artifacts:** ${data.artifacts.length}\n`;
  catalog += `- **Content References:** ${data.artifactContentRefs.length}\n`;
  catalog += `- **Collections:** ${data.collections.length}\n`;
  catalog += `- **Series:** ${data.series.length}\n`;
  catalog += `- **Publication Channels:** ${data.publicationChannels.length}\n`;
  catalog += `- **Publication Plans:** ${data.publicationPlans.length}\n`;
  catalog += `- **Publication Events:** ${data.publicationEvents.length}\n\n`;
  
  catalog += `---\n\n`;
  catalog += `## Full Data Export\n\n`;
  catalog += `\`\`\`json\n`;
  catalog += JSON.stringify(data, null, 2);
  catalog += `\n\`\`\`\n`;
  
  return catalog;
}
