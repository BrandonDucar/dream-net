import type { ArchiveData } from '@/types/archive';

const STORAGE_KEY = 'dreamnet-archive-data';

const defaultData: ArchiveData = {
  artifacts: [],
  artifactContentRefs: [],
  collections: [],
  series: [],
  publicationChannels: [],
  publicationPlans: [],
  publicationEvents: [],
};

export function loadArchiveData(): ArchiveData {
  if (typeof window === 'undefined') return defaultData;
  
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return defaultData;
    return JSON.parse(stored) as ArchiveData;
  } catch (error) {
    console.error('Failed to load archive data:', error);
    return defaultData;
  }
}

export function saveArchiveData(data: ArchiveData): void {
  if (typeof window === 'undefined') return;
  
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Failed to save archive data:', error);
  }
}

export function exportArchiveData(): string {
  const data = loadArchiveData();
  return JSON.stringify(data, null, 2);
}

export function importArchiveData(jsonString: string): boolean {
  try {
    const data = JSON.parse(jsonString) as ArchiveData;
    saveArchiveData(data);
    return true;
  } catch (error) {
    console.error('Failed to import archive data:', error);
    return false;
  }
}
