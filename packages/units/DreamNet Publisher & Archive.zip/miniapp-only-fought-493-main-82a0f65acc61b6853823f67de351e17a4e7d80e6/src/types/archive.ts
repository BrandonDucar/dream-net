export type ArtifactType =
  | "lore"
  | "documentation"
  | "playbook"
  | "report"
  | "map"
  | "manual"
  | "guide"
  | "codex"
  | "other";

export type ImportanceLevel = "low" | "medium" | "high" | "critical";

export type ArtifactStatus = "draft" | "ready" | "published" | "archived";

export type ContentType =
  | "markdown"
  | "plain-text"
  | "html"
  | "pdf"
  | "image"
  | "other";

export type CollectionCategory = "internal" | "public" | "mixed";

export type ChannelType =
  | "website"
  | "zora"
  | "pdf-bundle"
  | "newsletter"
  | "blog"
  | "frame"
  | "other";

export type TimingHint =
  | "asap"
  | "coincide-with-drop"
  | "seasonal"
  | "evergreen"
  | "custom";

export type PlanStatus = "idea" | "draft" | "scheduled" | "released" | "cancelled";

export interface SEOMeta {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export interface Artifact extends SEOMeta {
  id: string;
  title: string;
  slug: string;
  artifactType: ArtifactType;
  sourceApp: string | null;
  description: string;
  contentSummary: string;
  versionLabel: string;
  tags: string[];
  importanceLevel: ImportanceLevel;
  status: ArtifactStatus;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface ArtifactContentRef {
  id: string;
  artifactId: string;
  contentType: ContentType;
  storageHint: string;
  contentExcerpt: string;
  notes: string;
  createdAt: string;
}

export interface Collection extends SEOMeta {
  id: string;
  name: string;
  slug: string;
  description: string;
  category: CollectionCategory;
  artifactIds: string[];
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface Series extends SEOMeta {
  id: string;
  name: string;
  slug: string;
  description: string;
  sequenceArtifactIds: string[];
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface PublicationChannel {
  id: string;
  name: string;
  slug: string;
  description: string;
  channelType: ChannelType;
  urlOrRef: string | null;
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface PublicationPlan extends SEOMeta {
  id: string;
  name: string;
  description: string;
  artifactIds: string[];
  collectionIds: string[];
  seriesIds: string[];
  channelIds: string[];
  targetAudience: string;
  goals: string[];
  timingHint: TimingHint;
  status: PlanStatus;
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface PublicationEvent {
  id: string;
  publicationPlanId: string;
  channelId: string;
  artifactIds: string[];
  timestamp: string;
  title: string;
  summary: string;
  linkOrProof: string | null;
  notes: string;
}

export interface ArchiveData {
  artifacts: Artifact[];
  artifactContentRefs: ArtifactContentRef[];
  collections: Collection[];
  series: Series[];
  publicationChannels: PublicationChannel[];
  publicationPlans: PublicationPlan[];
  publicationEvents: PublicationEvent[];
}
