'use client'
import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { AlertCircle, Download } from 'lucide-react';
import { useSafetyData } from '@/hooks/useSafetyData';
import RiskDashboard from '@/components/RiskDashboard';
import RiskScenariosScreen from '@/components/RiskScenariosScreen';
import RedTeamLabScreen from '@/components/RedTeamLabScreen';
import ControlsScreen from '@/components/ControlsScreen';
import IncidentsScreen from '@/components/IncidentsScreen';
import LaunchSafetyScreen from '@/components/LaunchSafetyScreen';
import { seedRiskDomains, seedRiskTypes } from '@/lib/seed-data';
import { exportSafetyPlaybook } from '@/lib/safety-reports';
import type { 
  RiskScenario, 
  RedTeamTest, 
  Control, 
  SafetyIncident,
  LaunchSafetyChecklist,
  LaunchSafetyReview,
} from '@/types/safety';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function SafetyLabPage() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const {
    riskDomains,
    setRiskDomains,
    riskTypes,
    setRiskTypes,
    riskScenarios,
    setRiskScenarios,
    redTeamTests,
    setRedTeamTests,
    controls,
    setControls,
    safetyIncidents,
    setSafetyIncidents,
    launchChecklists,
    setLaunchChecklists,
    launchReviews,
    setLaunchReviews,
  } = useSafetyData();

  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isInitialized, setIsInitialized] = useState<boolean>(false);

  useEffect(() => {
    if (riskDomains.length === 0 && !isInitialized) {
      setRiskDomains(seedRiskDomains);
      setRiskTypes(seedRiskTypes);
      setIsInitialized(true);
    }
  }, [riskDomains, setRiskDomains, setRiskTypes, isInitialized]);

  const handleSaveScenario = (scenario: RiskScenario): void => {
    const existingIndex = riskScenarios.findIndex((s: RiskScenario) => s.id === scenario.id);
    if (existingIndex >= 0) {
      const updated = [...riskScenarios];
      updated[existingIndex] = scenario;
      setRiskScenarios(updated);
    } else {
      setRiskScenarios([...riskScenarios, scenario]);
    }
  };

  const handleSaveRedTeamTest = (test: RedTeamTest): void => {
    const existingIndex = redTeamTests.findIndex((t: RedTeamTest) => t.id === test.id);
    if (existingIndex >= 0) {
      const updated = [...redTeamTests];
      updated[existingIndex] = test;
      setRedTeamTests(updated);
    } else {
      setRedTeamTests([...redTeamTests, test]);
    }
  };

  const handleSaveControl = (control: Control): void => {
    const existingIndex = controls.findIndex((c: Control) => c.id === control.id);
    if (existingIndex >= 0) {
      const updated = [...controls];
      updated[existingIndex] = control;
      setControls(updated);
    } else {
      setControls([...controls, control]);
    }
  };

  const handleSaveIncident = (incident: SafetyIncident): void => {
    const existingIndex = safetyIncidents.findIndex((i: SafetyIncident) => i.id === incident.id);
    if (existingIndex >= 0) {
      const updated = [...safetyIncidents];
      updated[existingIndex] = incident;
      setSafetyIncidents(updated);
    } else {
      setSafetyIncidents([...safetyIncidents, incident]);
    }
  };

  const handleSaveChecklist = (checklist: LaunchSafetyChecklist): void => {
    const existingIndex = launchChecklists.findIndex((c: LaunchSafetyChecklist) => c.id === checklist.id);
    if (existingIndex >= 0) {
      const updated = [...launchChecklists];
      updated[existingIndex] = checklist;
      setLaunchChecklists(updated);
    } else {
      setLaunchChecklists([...launchChecklists, checklist]);
    }
  };

  const handleSaveReview = (review: LaunchSafetyReview): void => {
    const existingIndex = launchReviews.findIndex((r: LaunchSafetyReview) => r.id === review.id);
    if (existingIndex >= 0) {
      const updated = [...launchReviews];
      updated[existingIndex] = review;
      setLaunchReviews(updated);
    } else {
      setLaunchReviews([...launchReviews, review]);
    }
  };

  const handleExportPlaybook = (): void => {
    const playbook = exportSafetyPlaybook(
      riskDomains,
      riskTypes,
      riskScenarios,
      controls,
      redTeamTests,
      launchChecklists,
      safetyIncidents
    );

    const blob = new Blob([playbook], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dreamnet-safety-playbook-${new Date().toISOString().split('T')[0]}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const openIncidents = safetyIncidents.filter((i: SafetyIncident) => i.status === 'open');
  const upcomingTests = redTeamTests.filter((t: RedTeamTest) => 
    t.testStatus === 'planned' || t.testStatus === 'in-progress'
  );

  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto px-4 py-8 md:py-12 pt-12 md:pt-16">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="mb-6 overflow-x-auto">
            <TabsList className="inline-flex w-full md:w-auto">
              <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
              <TabsTrigger value="scenarios">Risk Scenarios</TabsTrigger>
              <TabsTrigger value="redteam">Red Team Lab</TabsTrigger>
              <TabsTrigger value="controls">Controls</TabsTrigger>
              <TabsTrigger value="incidents">Incidents</TabsTrigger>
              <TabsTrigger value="launch">Launch Safety</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="dashboard">
            <RiskDashboard
              riskDomains={riskDomains}
              openIncidents={openIncidents}
              upcomingTests={upcomingTests}
              scenarioCount={riskScenarios.length}
              onCreateScenario={() => setActiveTab('scenarios')}
              onCreateTest={() => setActiveTab('redteam')}
              onCreateChecklist={() => setActiveTab('launch')}
              onExportPlaybook={handleExportPlaybook}
            />
          </TabsContent>

          <TabsContent value="scenarios">
            <RiskScenariosScreen
              scenarios={riskScenarios}
              domains={riskDomains}
              riskTypes={riskTypes}
              onSave={handleSaveScenario}
            />
          </TabsContent>

          <TabsContent value="redteam">
            <RedTeamLabScreen
              tests={redTeamTests}
              domains={riskDomains}
              riskTypes={riskTypes}
              onSave={handleSaveRedTeamTest}
            />
          </TabsContent>

          <TabsContent value="controls">
            <ControlsScreen
              controls={controls}
              domains={riskDomains}
              riskTypes={riskTypes}
              onSave={handleSaveControl}
            />
          </TabsContent>

          <TabsContent value="incidents">
            <IncidentsScreen
              incidents={safetyIncidents}
              domains={riskDomains}
              riskTypes={riskTypes}
              onSave={handleSaveIncident}
            />
          </TabsContent>

          <TabsContent value="launch">
            <LaunchSafetyScreen
              checklists={launchChecklists}
              reviews={launchReviews}
              domains={riskDomains}
              riskTypes={riskTypes}
              scenarios={riskScenarios}
              controls={controls}
              onSaveChecklist={handleSaveChecklist}
              onSaveReview={handleSaveReview}
            />
          </TabsContent>
        </Tabs>

        <footer className="mt-12 pt-6 border-t text-center text-gray-500 text-sm">
          <p>DreamNet Safety, Risk & Red Team Lab</p>
          <p className="mt-1">The safety + risk brain of DreamNet</p>
        </footer>
      </div>
    </div>
  );
}
