'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Shield, Plus, CheckCircle, AlertCircle } from 'lucide-react';
import type { Control, RiskDomain, RiskType, ControlType } from '@/types/safety';
import { generateId } from '@/lib/safety-storage';

interface ControlsScreenProps {
  controls: Control[];
  domains: RiskDomain[];
  riskTypes: RiskType[];
  onSave: (control: Control) => void;
}

export default function ControlsScreen({
  controls,
  domains,
  riskTypes,
  onSave,
}: ControlsScreenProps) {
  const [selectedControl, setSelectedControl] = useState<Control | null>(null);
  const [isCreating, setIsCreating] = useState<boolean>(false);
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    controlType: 'process' as ControlType,
    domainIds: [] as string[],
    riskTypeIds: [] as string[],
    strengths: [] as string[],
    weaknesses: [] as string[],
    implementationHints: [] as string[],
    tags: [] as string[],
    notes: '',
  });

  const [newStrength, setNewStrength] = useState<string>('');
  const [newWeakness, setNewWeakness] = useState<string>('');
  const [newHint, setNewHint] = useState<string>('');

  const handleCreateControl = (): void => {
    if (!formData.name) return;

    const newControl: Control = {
      id: generateId(),
      name: formData.name,
      description: formData.description,
      controlType: formData.controlType,
      domainIds: formData.domainIds,
      riskTypeIds: formData.riskTypeIds,
      strengths: formData.strengths,
      weaknesses: formData.weaknesses,
      implementationHints: formData.implementationHints,
      tags: formData.tags,
      notes: formData.notes,
    };

    onSave(newControl);
    setIsCreating(false);
    resetForm();
  };

  const resetForm = (): void => {
    setFormData({
      name: '',
      description: '',
      controlType: 'process',
      domainIds: [],
      riskTypeIds: [],
      strengths: [],
      weaknesses: [],
      implementationHints: [],
      tags: [],
      notes: '',
    });
    setNewStrength('');
    setNewWeakness('');
    setNewHint('');
  };

  const addStrength = (): void => {
    if (!newStrength.trim()) return;
    setFormData({
      ...formData,
      strengths: [...formData.strengths, newStrength.trim()],
    });
    setNewStrength('');
  };

  const addWeakness = (): void => {
    if (!newWeakness.trim()) return;
    setFormData({
      ...formData,
      weaknesses: [...formData.weaknesses, newWeakness.trim()],
    });
    setNewWeakness('');
  };

  const addHint = (): void => {
    if (!newHint.trim()) return;
    setFormData({
      ...formData,
      implementationHints: [...formData.implementationHints, newHint.trim()],
    });
    setNewHint('');
  };

  const controlTypeColors: Record<ControlType, string> = {
    process: 'bg-blue-100 text-blue-800',
    technical: 'bg-green-100 text-green-800',
    cultural: 'bg-purple-100 text-purple-800',
    economic: 'bg-yellow-100 text-yellow-800',
    legal: 'bg-red-100 text-red-800',
    other: 'bg-gray-100 text-gray-800',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-black">Controls</h1>
          <p className="text-gray-600 mt-1">Risk mitigation strategies and safeguards</p>
        </div>
        <Button onClick={() => setIsCreating(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Create Control
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Total Controls</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black">{controls.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Technical</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black">
              {controls.filter((c: Control) => c.controlType === 'technical').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Process</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black">
              {controls.filter((c: Control) => c.controlType === 'process').length}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {controls.length === 0 ? (
          <Card className="col-span-full">
            <CardContent className="py-12 text-center">
              <Shield className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-500 mb-4">No controls defined yet.</p>
              <Button onClick={() => setIsCreating(true)}>Create First Control</Button>
            </CardContent>
          </Card>
        ) : (
          controls.map((control: Control) => (
            <Card 
              key={control.id} 
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setSelectedControl(control)}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <CardTitle className="text-lg text-black">{control.name}</CardTitle>
                  <Badge className={controlTypeColors[control.controlType as ControlType]}>
                    {control.controlType}
                  </Badge>
                </div>
                <CardDescription>{control.description.substring(0, 100)}...</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-gray-600">{control.strengths.length} strengths</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <AlertCircle className="h-4 w-4 text-orange-600" />
                    <span className="text-gray-600">{control.weaknesses.length} weaknesses</span>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {control.domainIds.slice(0, 2).map((domainId: string) => {
                      const domain = domains.find((d: RiskDomain) => d.id === domainId);
                      return domain ? (
                        <Badge key={domainId} variant="outline" className="text-xs">
                          {domain.name}
                        </Badge>
                      ) : null;
                    })}
                    {control.domainIds.length > 2 && (
                      <Badge variant="outline" className="text-xs">
                        +{control.domainIds.length - 2}
                      </Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Create Dialog */}
      <Dialog open={isCreating} onOpenChange={setIsCreating}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-black">Create Control</DialogTitle>
            <DialogDescription>Define a new risk control or mitigation</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Control Name *</Label>
              <Input 
                value={formData.name}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                  setFormData({ ...formData, name: e.target.value })
                }
                placeholder="e.g., Manual review before posting"
              />
            </div>

            <div>
              <Label>Description</Label>
              <Textarea 
                value={formData.description}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => 
                  setFormData({ ...formData, description: e.target.value })
                }
                placeholder="How does this control work?"
                rows={3}
              />
            </div>

            <div>
              <Label>Control Type *</Label>
              <Select 
                value={formData.controlType}
                onValueChange={(value: ControlType) => 
                  setFormData({ ...formData, controlType: value })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="process">Process</SelectItem>
                  <SelectItem value="technical">Technical</SelectItem>
                  <SelectItem value="cultural">Cultural</SelectItem>
                  <SelectItem value="economic">Economic</SelectItem>
                  <SelectItem value="legal">Legal</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Strengths</Label>
              <div className="flex gap-2 mb-2">
                <Input 
                  value={newStrength}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    setNewStrength(e.target.value)
                  }
                  placeholder="What makes this control effective?"
                  onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addStrength();
                    }
                  }}
                />
                <Button onClick={addStrength} size="sm">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-1">
                {formData.strengths.map((strength: string, i: number) => (
                  <div key={i} className="text-sm flex items-center gap-2 text-black">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    {strength}
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label>Weaknesses</Label>
              <div className="flex gap-2 mb-2">
                <Input 
                  value={newWeakness}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    setNewWeakness(e.target.value)
                  }
                  placeholder="What are the limitations?"
                  onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addWeakness();
                    }
                  }}
                />
                <Button onClick={addWeakness} size="sm">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-1">
                {formData.weaknesses.map((weakness: string, i: number) => (
                  <div key={i} className="text-sm flex items-center gap-2 text-black">
                    <AlertCircle className="h-4 w-4 text-orange-600" />
                    {weakness}
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label>Implementation Hints</Label>
              <div className="flex gap-2 mb-2">
                <Input 
                  value={newHint}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    setNewHint(e.target.value)
                  }
                  placeholder="How to implement this?"
                  onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addHint();
                    }
                  }}
                />
                <Button onClick={addHint} size="sm">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-1">
                {formData.implementationHints.map((hint: string, i: number) => (
                  <div key={i} className="text-sm text-black">• {hint}</div>
                ))}
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleCreateControl}>Create Control</Button>
              <Button variant="outline" onClick={() => setIsCreating(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={!!selectedControl} onOpenChange={() => setSelectedControl(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-black">{selectedControl?.name}</DialogTitle>
          </DialogHeader>
          {selectedControl && (
            <ScrollArea className="h-[60vh]">
              <div className="space-y-4">
                <div>
                  <Badge className={controlTypeColors[selectedControl.controlType as ControlType]}>
                    {selectedControl.controlType}
                  </Badge>
                </div>

                <div>
                  <Label>Description</Label>
                  <p className="text-sm text-gray-700">{selectedControl.description}</p>
                </div>

                <div>
                  <Label>Strengths</Label>
                  <ul className="space-y-1">
                    {selectedControl.strengths.map((s: string, i: number) => (
                      <li key={i} className="text-sm flex items-center gap-2 text-black">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        {s}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <Label>Weaknesses</Label>
                  <ul className="space-y-1">
                    {selectedControl.weaknesses.map((w: string, i: number) => (
                      <li key={i} className="text-sm flex items-center gap-2 text-black">
                        <AlertCircle className="h-4 w-4 text-orange-600" />
                        {w}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <Label>Implementation Hints</Label>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    {selectedControl.implementationHints.map((h: string, i: number) => (
                      <li key={i}>{h}</li>
                    ))}
                  </ul>
                </div>

                <div>
                  <Label>Related Domains</Label>
                  <div className="flex flex-wrap gap-2">
                    {selectedControl.domainIds.map((domainId: string) => {
                      const domain = domains.find((d: RiskDomain) => d.id === domainId);
                      return domain ? (
                        <Badge key={domainId} variant="outline">
                          {domain.name}
                        </Badge>
                      ) : null;
                    })}
                  </div>
                </div>
              </div>
            </ScrollArea>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
