'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AlertTriangle, FileText, Plus, X } from 'lucide-react';
import type { SafetyIncident, RiskDomain, RiskType, SeverityLevel, IncidentStatus } from '@/types/safety';
import { generateId, generateSlug } from '@/lib/safety-storage';
import { generateIncidentPostmortem } from '@/lib/safety-reports';

interface IncidentsScreenProps {
  incidents: SafetyIncident[];
  domains: RiskDomain[];
  riskTypes: RiskType[];
  onSave: (incident: SafetyIncident) => void;
}

export default function IncidentsScreen({
  incidents,
  domains,
  riskTypes,
  onSave,
}: IncidentsScreenProps) {
  const [selectedIncident, setSelectedIncident] = useState<SafetyIncident | null>(null);
  const [isCreating, setIsCreating] = useState<boolean>(false);
  const [postmortem, setPostmortem] = useState<string>('');
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    domainId: '',
    riskTypeIds: [] as string[],
    severity: 'medium' as SeverityLevel,
    detectedBy: '',
    immediateActions: [] as string[],
    notes: '',
  });

  const [newAction, setNewAction] = useState<string>('');

  const handleCreateIncident = (): void => {
    if (!formData.title || !formData.domainId) return;

    const newIncident: SafetyIncident = {
      id: generateId(),
      title: formData.title,
      slug: generateSlug(formData.title),
      description: formData.description,
      domainId: formData.domainId,
      riskTypeIds: formData.riskTypeIds,
      severity: formData.severity,
      status: 'open',
      occurredAt: new Date().toISOString(),
      detectedBy: formData.detectedBy,
      immediateActions: formData.immediateActions,
      rootCauses: [],
      lessonsLearned: [],
      followUpTasks: [],
      linkedControls: [],
      linkedScenarios: [],
      notes: formData.notes,
    };

    onSave(newIncident);
    setIsCreating(false);
    resetForm();
  };

  const resetForm = (): void => {
    setFormData({
      title: '',
      description: '',
      domainId: '',
      riskTypeIds: [],
      severity: 'medium',
      detectedBy: '',
      immediateActions: [],
      notes: '',
    });
    setNewAction('');
  };

  const addAction = (): void => {
    if (!newAction.trim()) return;
    setFormData({
      ...formData,
      immediateActions: [...formData.immediateActions, newAction.trim()],
    });
    setNewAction('');
  };

  const removeAction = (index: number): void => {
    setFormData({
      ...formData,
      immediateActions: formData.immediateActions.filter((_: string, i: number) => i !== index),
    });
  };

  const generatePostmortem = (incident: SafetyIncident): void => {
    const domain = domains.find((d: RiskDomain) => d.id === incident.domainId);
    const incidentRiskTypes = riskTypes.filter((rt: RiskType) => 
      incident.riskTypeIds.includes(rt.id)
    );
    const pm = generateIncidentPostmortem(incident, domain, incidentRiskTypes);
    setPostmortem(pm);
  };

  const updateIncidentStatus = (incidentId: string, status: IncidentStatus): void => {
    const incident = incidents.find((i: SafetyIncident) => i.id === incidentId);
    if (incident) {
      onSave({ ...incident, status });
    }
  };

  const openIncidents = incidents.filter((i: SafetyIncident) => i.status === 'open');
  const monitoringIncidents = incidents.filter((i: SafetyIncident) => i.status === 'monitoring');
  const resolvedIncidents = incidents.filter((i: SafetyIncident) => i.status === 'resolved');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-black">Safety Incidents & Postmortems</h1>
          <p className="text-gray-600 mt-1">Track and learn from safety events</p>
        </div>
        <Button onClick={() => setIsCreating(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Report Incident
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Open</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black">{openIncidents.length}</div>
            <p className="text-xs text-gray-500 mt-1">Require immediate attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Monitoring</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black">{monitoringIncidents.length}</div>
            <p className="text-xs text-gray-500 mt-1">Under observation</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Resolved</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black">{resolvedIncidents.length}</div>
            <p className="text-xs text-gray-500 mt-1">Closed and documented</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-black">Incidents ({incidents.length})</CardTitle>
          <CardDescription>All safety incidents and near misses</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[500px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-black">Title</TableHead>
                  <TableHead className="text-black">Domain</TableHead>
                  <TableHead className="text-black">Severity</TableHead>
                  <TableHead className="text-black">Status</TableHead>
                  <TableHead className="text-black">Occurred</TableHead>
                  <TableHead className="text-black">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {incidents.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-gray-500">
                      No incidents reported. Great safety record!
                    </TableCell>
                  </TableRow>
                ) : (
                  incidents
                    .sort((a: SafetyIncident, b: SafetyIncident) => 
                      new Date(b.occurredAt).getTime() - new Date(a.occurredAt).getTime()
                    )
                    .map((incident: SafetyIncident) => {
                      const domain = domains.find((d: RiskDomain) => d.id === incident.domainId);
                      return (
                        <TableRow key={incident.id}>
                          <TableCell className="font-medium text-black">
                            <div className="flex items-center gap-2">
                              <AlertTriangle 
                                className={`h-4 w-4 ${
                                  incident.severity === 'critical' ? 'text-red-600' :
                                  incident.severity === 'high' ? 'text-orange-600' :
                                  'text-yellow-600'
                                }`}
                              />
                              {incident.title}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{domain?.name || 'Unknown'}</Badge>
                          </TableCell>
                          <TableCell>
                            <Badge 
                              variant={
                                incident.severity === 'critical' ? 'destructive' :
                                incident.severity === 'high' ? 'default' :
                                'outline'
                              }
                            >
                              {incident.severity}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Select 
                              value={incident.status}
                              onValueChange={(value: IncidentStatus) => 
                                updateIncidentStatus(incident.id, value)
                              }
                            >
                              <SelectTrigger className="w-[130px]">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="open">Open</SelectItem>
                                <SelectItem value="monitoring">Monitoring</SelectItem>
                                <SelectItem value="resolved">Resolved</SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell className="text-sm text-gray-600">
                            {new Date(incident.occurredAt).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => setSelectedIncident(incident)}
                              >
                                View
                              </Button>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => generatePostmortem(incident)}
                              >
                                <FileText className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })
                )}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Create Dialog */}
      <Dialog open={isCreating} onOpenChange={setIsCreating}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-black">Report Safety Incident</DialogTitle>
            <DialogDescription>Document a new safety incident or near miss</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Incident Title *</Label>
              <Input 
                value={formData.title}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                  setFormData({ ...formData, title: e.target.value })
                }
                placeholder="e.g., Unauthorized access attempt, Drop exploit"
              />
            </div>

            <div>
              <Label>Description</Label>
              <Textarea 
                value={formData.description}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => 
                  setFormData({ ...formData, description: e.target.value })
                }
                placeholder="What happened? Provide details..."
                rows={4}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Domain *</Label>
                <Select 
                  value={formData.domainId}
                  onValueChange={(value: string) => 
                    setFormData({ ...formData, domainId: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select domain" />
                  </SelectTrigger>
                  <SelectContent>
                    {domains.map((domain: RiskDomain) => (
                      <SelectItem key={domain.id} value={domain.id}>
                        {domain.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Severity *</Label>
                <Select 
                  value={formData.severity}
                  onValueChange={(value: SeverityLevel) => 
                    setFormData({ ...formData, severity: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Detected By</Label>
              <Input 
                value={formData.detectedBy}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                  setFormData({ ...formData, detectedBy: e.target.value })
                }
                placeholder="Name or identifier"
              />
            </div>

            <div>
              <Label>Immediate Actions Taken</Label>
              <div className="flex gap-2 mb-2">
                <Input 
                  value={newAction}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    setNewAction(e.target.value)
                  }
                  placeholder="What did you do immediately?"
                  onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addAction();
                    }
                  }}
                />
                <Button onClick={addAction} size="sm">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-2">
                {formData.immediateActions.map((action: string, i: number) => (
                  <div key={i} className="flex items-center gap-2 p-2 border rounded">
                    <span className="flex-1 text-sm text-black">{action}</span>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={() => removeAction(i)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleCreateIncident}>Report Incident</Button>
              <Button variant="outline" onClick={() => setIsCreating(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={!!selectedIncident} onOpenChange={() => setSelectedIncident(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-black">{selectedIncident?.title}</DialogTitle>
          </DialogHeader>
          {selectedIncident && (
            <ScrollArea className="h-[60vh]">
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Badge 
                    variant={
                      selectedIncident.severity === 'critical' ? 'destructive' :
                      selectedIncident.severity === 'high' ? 'default' :
                      'outline'
                    }
                  >
                    {selectedIncident.severity}
                  </Badge>
                  <Badge variant="outline">{selectedIncident.status}</Badge>
                </div>

                <div>
                  <Label>Description</Label>
                  <p className="text-sm text-gray-700">{selectedIncident.description}</p>
                </div>

                <div>
                  <Label>Occurred At</Label>
                  <p className="text-sm text-gray-700">
                    {new Date(selectedIncident.occurredAt).toLocaleString()}
                  </p>
                </div>

                <div>
                  <Label>Detected By</Label>
                  <p className="text-sm text-gray-700">{selectedIncident.detectedBy}</p>
                </div>

                <div>
                  <Label>Immediate Actions</Label>
                  {selectedIncident.immediateActions.length === 0 ? (
                    <p className="text-sm text-gray-500">None documented</p>
                  ) : (
                    <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                      {selectedIncident.immediateActions.map((a: string, i: number) => (
                        <li key={i}>{a}</li>
                      ))}
                    </ul>
                  )}
                </div>

                <div>
                  <Label>Root Causes</Label>
                  {selectedIncident.rootCauses.length === 0 ? (
                    <p className="text-sm text-gray-500">Under investigation</p>
                  ) : (
                    <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                      {selectedIncident.rootCauses.map((r: string, i: number) => (
                        <li key={i}>{r}</li>
                      ))}
                    </ul>
                  )}
                </div>

                <div>
                  <Label>Lessons Learned</Label>
                  {selectedIncident.lessonsLearned.length === 0 ? (
                    <p className="text-sm text-gray-500">To be documented</p>
                  ) : (
                    <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                      {selectedIncident.lessonsLearned.map((l: string, i: number) => (
                        <li key={i}>{l}</li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            </ScrollArea>
          )}
        </DialogContent>
      </Dialog>

      {/* Postmortem Dialog */}
      <Dialog open={!!postmortem} onOpenChange={() => setPostmortem('')}>
        <DialogContent className="max-w-3xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="text-black">Incident Postmortem</DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[70vh]">
            <pre className="text-sm whitespace-pre-wrap text-black">{postmortem}</pre>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
