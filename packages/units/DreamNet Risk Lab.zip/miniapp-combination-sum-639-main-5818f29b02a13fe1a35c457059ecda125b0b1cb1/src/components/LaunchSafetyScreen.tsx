'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle2, Plus, FileText, X } from 'lucide-react';
import type { 
  LaunchSafetyChecklist, 
  LaunchSafetyReview, 
  RiskDomain, 
  RiskType,
  TargetType,
  GoNoGoDecision,
  ImportanceLevel,
  RiskScenario,
  Control,
} from '@/types/safety';
import { generateId, generateSEOMeta } from '@/lib/safety-storage';
import { generateLaunchSafetyGateReport } from '@/lib/safety-reports';

interface LaunchSafetyScreenProps {
  checklists: LaunchSafetyChecklist[];
  reviews: LaunchSafetyReview[];
  domains: RiskDomain[];
  riskTypes: RiskType[];
  scenarios: RiskScenario[];
  controls: Control[];
  onSaveChecklist: (checklist: LaunchSafetyChecklist) => void;
  onSaveReview: (review: LaunchSafetyReview) => void;
}

export default function LaunchSafetyScreen({
  checklists,
  reviews,
  domains,
  riskTypes,
  scenarios,
  controls,
  onSaveChecklist,
  onSaveReview,
}: LaunchSafetyScreenProps) {
  const [isCreatingChecklist, setIsCreatingChecklist] = useState<boolean>(false);
  const [isCreatingReview, setIsCreatingReview] = useState<boolean>(false);
  const [selectedChecklist, setSelectedChecklist] = useState<LaunchSafetyChecklist | null>(null);
  const [gateReport, setGateReport] = useState<string>('');
  
  const [checklistForm, setChecklistForm] = useState({
    name: '',
    description: '',
    domainIds: [] as string[],
    riskTypeIds: [] as string[],
    checklistItems: [] as string[],
    tags: [] as string[],
    notes: '',
  });

  const [reviewForm, setReviewForm] = useState({
    checklistId: '',
    targetType: 'drop' as TargetType,
    targetRef: '',
    reviewerName: '',
    overallRiskLevel: 'medium' as ImportanceLevel,
    goNoGoDecision: 'hold' as GoNoGoDecision,
    rationale: '',
    notes: '',
  });

  const [newItem, setNewItem] = useState<string>('');
  const [reportTargetType, setReportTargetType] = useState<TargetType>('drop');
  const [reportTargetRef, setReportTargetRef] = useState<string>('');

  const handleCreateChecklist = (): void => {
    if (!checklistForm.name) return;

    const seoMeta = generateSEOMeta(checklistForm.name, checklistForm.description, checklistForm.tags);
    
    const newChecklist: LaunchSafetyChecklist = {
      id: generateId(),
      name: checklistForm.name,
      description: checklistForm.description,
      domainIds: checklistForm.domainIds,
      riskTypeIds: checklistForm.riskTypeIds,
      checklistItems: checklistForm.checklistItems,
      tags: checklistForm.tags,
      notes: checklistForm.notes,
      ...seoMeta,
    };

    onSaveChecklist(newChecklist);
    setIsCreatingChecklist(false);
    resetChecklistForm();
  };

  const handleCreateReview = (): void => {
    if (!reviewForm.checklistId || !reviewForm.targetRef) return;

    const newReview: LaunchSafetyReview = {
      id: generateId(),
      checklistId: reviewForm.checklistId,
      targetType: reviewForm.targetType,
      targetRef: reviewForm.targetRef,
      reviewerName: reviewForm.reviewerName,
      date: new Date().toISOString(),
      responses: {},
      overallRiskLevel: reviewForm.overallRiskLevel,
      goNoGoDecision: reviewForm.goNoGoDecision,
      rationale: reviewForm.rationale,
      notes: reviewForm.notes,
    };

    onSaveReview(newReview);
    setIsCreatingReview(false);
    resetReviewForm();
  };

  const resetChecklistForm = (): void => {
    setChecklistForm({
      name: '',
      description: '',
      domainIds: [],
      riskTypeIds: [],
      checklistItems: [],
      tags: [],
      notes: '',
    });
    setNewItem('');
  };

  const resetReviewForm = (): void => {
    setReviewForm({
      checklistId: '',
      targetType: 'drop',
      targetRef: '',
      reviewerName: '',
      overallRiskLevel: 'medium',
      goNoGoDecision: 'hold',
      rationale: '',
      notes: '',
    });
  };

  const addChecklistItem = (): void => {
    if (!newItem.trim()) return;
    setChecklistForm({
      ...checklistForm,
      checklistItems: [...checklistForm.checklistItems, newItem.trim()],
    });
    setNewItem('');
  };

  const removeChecklistItem = (index: number): void => {
    setChecklistForm({
      ...checklistForm,
      checklistItems: checklistForm.checklistItems.filter((_: string, i: number) => i !== index),
    });
  };

  const generateGateReport = (): void => {
    if (!reportTargetRef) return;
    
    const report = generateLaunchSafetyGateReport(
      reportTargetType,
      reportTargetRef,
      scenarios,
      controls,
      reviews,
      domains,
      riskTypes
    );
    setGateReport(report);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-black">Launch Safety</h1>
          <p className="text-gray-600 mt-1">Pre-launch checklists and go/no-go decisions</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setIsCreatingChecklist(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Create Checklist
          </Button>
          <Button onClick={() => setIsCreatingReview(true)} variant="outline">
            <CheckCircle2 className="mr-2 h-4 w-4" />
            Create Review
          </Button>
        </div>
      </div>

      <Tabs defaultValue="checklists" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="checklists">Checklists</TabsTrigger>
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
          <TabsTrigger value="gate-report">Gate Report</TabsTrigger>
        </TabsList>

        <TabsContent value="checklists" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-black">Safety Checklists ({checklists.length})</CardTitle>
              <CardDescription>Reusable pre-launch safety verification lists</CardDescription>
            </CardHeader>
            <CardContent>
              {checklists.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-500 mb-4">No checklists created yet.</p>
                  <Button onClick={() => setIsCreatingChecklist(true)}>Create First Checklist</Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {checklists.map((checklist: LaunchSafetyChecklist) => (
                    <Card 
                      key={checklist.id}
                      className="cursor-pointer hover:shadow-lg transition-shadow"
                      onClick={() => setSelectedChecklist(checklist)}
                    >
                      <CardHeader>
                        <CardTitle className="text-lg text-black">{checklist.name}</CardTitle>
                        <CardDescription>{checklist.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center gap-2 text-sm">
                          <CheckCircle2 className="h-4 w-4 text-green-600" />
                          <span className="text-gray-600">{checklist.checklistItems.length} items</span>
                        </div>
                        <div className="flex flex-wrap gap-1 mt-3">
                          {checklist.domainIds.slice(0, 3).map((domainId: string) => {
                            const domain = domains.find((d: RiskDomain) => d.id === domainId);
                            return domain ? (
                              <Badge key={domainId} variant="outline" className="text-xs">
                                {domain.name}
                              </Badge>
                            ) : null;
                          })}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reviews" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-black">Launch Safety Reviews ({reviews.length})</CardTitle>
              <CardDescription>Completed safety assessments and go/no-go decisions</CardDescription>
            </CardHeader>
            <CardContent>
              {reviews.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-500 mb-4">No reviews completed yet.</p>
                  <Button onClick={() => setIsCreatingReview(true)}>Create First Review</Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {reviews
                    .sort((a: LaunchSafetyReview, b: LaunchSafetyReview) => 
                      new Date(b.date).getTime() - new Date(a.date).getTime()
                    )
                    .map((review: LaunchSafetyReview) => {
                      const checklist = checklists.find((c: LaunchSafetyChecklist) => c.id === review.checklistId);
                      return (
                        <Card key={review.id}>
                          <CardContent className="pt-6">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-2">
                                  <Badge variant="outline">{review.targetType}</Badge>
                                  <span className="font-semibold text-black">{review.targetRef}</span>
                                </div>
                                <p className="text-sm text-gray-600 mb-2">
                                  Checklist: {checklist?.name || 'Unknown'}
                                </p>
                                <p className="text-sm text-gray-600">
                                  Reviewed by {review.reviewerName} on {new Date(review.date).toLocaleDateString()}
                                </p>
                              </div>
                              <div className="flex flex-col items-end gap-2">
                                <Badge 
                                  variant={
                                    review.goNoGoDecision === 'go' ? 'default' :
                                    review.goNoGoDecision === 'no-go' ? 'destructive' :
                                    'outline'
                                  }
                                >
                                  {review.goNoGoDecision.toUpperCase()}
                                </Badge>
                                <Badge 
                                  variant={
                                    review.overallRiskLevel === 'critical' ? 'destructive' :
                                    review.overallRiskLevel === 'high' ? 'default' :
                                    'outline'
                                  }
                                >
                                  {review.overallRiskLevel} risk
                                </Badge>
                              </div>
                            </div>
                            <div className="mt-3 pt-3 border-t">
                              <Label>Rationale</Label>
                              <p className="text-sm text-gray-700">{review.rationale}</p>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="gate-report" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-black">Generate Launch Safety Gate Report</CardTitle>
              <CardDescription>
                Comprehensive safety assessment for a specific target
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Target Type</Label>
                  <Select 
                    value={reportTargetType}
                    onValueChange={(value: TargetType) => setReportTargetType(value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="flow">Flow</SelectItem>
                      <SelectItem value="campaign">Campaign</SelectItem>
                      <SelectItem value="drop">Drop</SelectItem>
                      <SelectItem value="mini-app">Mini-app</SelectItem>
                      <SelectItem value="agent">Agent</SelectItem>
                      <SelectItem value="change-set">Change Set</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Target Reference</Label>
                  <Input 
                    value={reportTargetRef}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                      setReportTargetRef(e.target.value)
                    }
                    placeholder="e.g., Drop ID, Campaign name"
                  />
                </div>
              </div>

              <Button onClick={generateGateReport}>
                <FileText className="mr-2 h-4 w-4" />
                Generate Gate Report
              </Button>

              {gateReport && (
                <div className="mt-4">
                  <ScrollArea className="h-[400px] border rounded-lg p-4">
                    <pre className="text-sm whitespace-pre-wrap text-black">{gateReport}</pre>
                  </ScrollArea>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Create Checklist Dialog */}
      <Dialog open={isCreatingChecklist} onOpenChange={setIsCreatingChecklist}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-black">Create Launch Safety Checklist</DialogTitle>
            <DialogDescription>Define a reusable safety verification checklist</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Checklist Name *</Label>
              <Input 
                value={checklistForm.name}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                  setChecklistForm({ ...checklistForm, name: e.target.value })
                }
                placeholder="e.g., Drop Launch Safety Checklist"
              />
            </div>

            <div>
              <Label>Description</Label>
              <Textarea 
                value={checklistForm.description}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => 
                  setChecklistForm({ ...checklistForm, description: e.target.value })
                }
                placeholder="What is this checklist for?"
                rows={3}
              />
            </div>

            <div>
              <Label>Checklist Items</Label>
              <div className="flex gap-2 mb-2">
                <Input 
                  value={newItem}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    setNewItem(e.target.value)
                  }
                  placeholder="Add a checklist item..."
                  onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addChecklistItem();
                    }
                  }}
                />
                <Button onClick={addChecklistItem} size="sm">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-2">
                {checklistForm.checklistItems.map((item: string, i: number) => (
                  <div key={i} className="flex items-center gap-2 p-2 border rounded">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span className="flex-1 text-sm text-black">{item}</span>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={() => removeChecklistItem(i)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleCreateChecklist}>Create Checklist</Button>
              <Button variant="outline" onClick={() => setIsCreatingChecklist(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Create Review Dialog */}
      <Dialog open={isCreatingReview} onOpenChange={setIsCreatingReview}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-black">Create Launch Safety Review</DialogTitle>
            <DialogDescription>Conduct a safety assessment for a launch target</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Checklist *</Label>
              <Select 
                value={reviewForm.checklistId}
                onValueChange={(value: string) => 
                  setReviewForm({ ...reviewForm, checklistId: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select checklist" />
                </SelectTrigger>
                <SelectContent>
                  {checklists.map((checklist: LaunchSafetyChecklist) => (
                    <SelectItem key={checklist.id} value={checklist.id}>
                      {checklist.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Target Type *</Label>
                <Select 
                  value={reviewForm.targetType}
                  onValueChange={(value: TargetType) => 
                    setReviewForm({ ...reviewForm, targetType: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="flow">Flow</SelectItem>
                    <SelectItem value="campaign">Campaign</SelectItem>
                    <SelectItem value="drop">Drop</SelectItem>
                    <SelectItem value="mini-app">Mini-app</SelectItem>
                    <SelectItem value="agent">Agent</SelectItem>
                    <SelectItem value="change-set">Change Set</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Target Reference *</Label>
                <Input 
                  value={reviewForm.targetRef}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    setReviewForm({ ...reviewForm, targetRef: e.target.value })
                  }
                  placeholder="e.g., Drop ID, Campaign name"
                />
              </div>
            </div>

            <div>
              <Label>Reviewer Name</Label>
              <Input 
                value={reviewForm.reviewerName}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                  setReviewForm({ ...reviewForm, reviewerName: e.target.value })
                }
                placeholder="Your name"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Overall Risk Level *</Label>
                <Select 
                  value={reviewForm.overallRiskLevel}
                  onValueChange={(value: ImportanceLevel) => 
                    setReviewForm({ ...reviewForm, overallRiskLevel: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Go/No-Go Decision *</Label>
                <Select 
                  value={reviewForm.goNoGoDecision}
                  onValueChange={(value: GoNoGoDecision) => 
                    setReviewForm({ ...reviewForm, goNoGoDecision: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="go">GO</SelectItem>
                    <SelectItem value="hold">HOLD</SelectItem>
                    <SelectItem value="no-go">NO-GO</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Rationale *</Label>
              <Textarea 
                value={reviewForm.rationale}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => 
                  setReviewForm({ ...reviewForm, rationale: e.target.value })
                }
                placeholder="Explain your decision..."
                rows={4}
              />
            </div>

            <div className="flex gap-2">
              <Button onClick={handleCreateReview}>Create Review</Button>
              <Button variant="outline" onClick={() => setIsCreatingReview(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Checklist Detail Dialog */}
      <Dialog open={!!selectedChecklist} onOpenChange={() => setSelectedChecklist(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-black">{selectedChecklist?.name}</DialogTitle>
          </DialogHeader>
          {selectedChecklist && (
            <ScrollArea className="h-[60vh]">
              <div className="space-y-4">
                <div>
                  <Label>Description</Label>
                  <p className="text-sm text-gray-700">{selectedChecklist.description}</p>
                </div>

                <div>
                  <Label>Checklist Items ({selectedChecklist.checklistItems.length})</Label>
                  <div className="space-y-2 mt-2">
                    {selectedChecklist.checklistItems.map((item: string, i: number) => (
                      <div key={i} className="flex items-center gap-2 p-2 border rounded">
                        <CheckCircle2 className="h-4 w-4 text-green-600" />
                        <span className="text-sm text-black">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <Label>Related Domains</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {selectedChecklist.domainIds.map((domainId: string) => {
                      const domain = domains.find((d: RiskDomain) => d.id === domainId);
                      return domain ? (
                        <Badge key={domainId} variant="outline">
                          {domain.name}
                        </Badge>
                      ) : null;
                    })}
                  </div>
                </div>
              </div>
            </ScrollArea>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
