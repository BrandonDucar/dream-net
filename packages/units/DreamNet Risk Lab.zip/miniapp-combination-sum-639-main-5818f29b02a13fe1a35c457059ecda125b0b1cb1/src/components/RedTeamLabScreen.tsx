'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Target, FileText, Plus, X } from 'lucide-react';
import type { RedTeamTest, RiskDomain, RiskType, TargetType, TestStatus } from '@/types/safety';
import { generateId } from '@/lib/safety-storage';
import { generateRedTeamTestPlan } from '@/lib/safety-reports';

interface RedTeamLabScreenProps {
  tests: RedTeamTest[];
  domains: RiskDomain[];
  riskTypes: RiskType[];
  onSave: (test: RedTeamTest) => void;
}

export default function RedTeamLabScreen({
  tests,
  domains,
  riskTypes,
  onSave,
}: RedTeamLabScreenProps) {
  const [selectedTest, setSelectedTest] = useState<RedTeamTest | null>(null);
  const [isCreating, setIsCreating] = useState<boolean>(false);
  const [testPlan, setTestPlan] = useState<string>('');
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    targetType: 'drop' as TargetType,
    targetRef: '',
    domainId: '',
    riskTypeIds: [] as string[],
    testQuestions: [] as string[],
    notes: '',
  });

  const [newQuestion, setNewQuestion] = useState<string>('');

  const handleCreateTest = (): void => {
    if (!formData.name || !formData.domainId) return;

    const newTest: RedTeamTest = {
      id: generateId(),
      name: formData.name,
      description: formData.description,
      targetType: formData.targetType,
      targetRef: formData.targetRef,
      domainId: formData.domainId,
      riskTypeIds: formData.riskTypeIds,
      testQuestions: formData.testQuestions,
      testStatus: 'planned',
      findings: [],
      conclusions: '',
      recommendedChanges: [],
      notes: formData.notes,
    };

    onSave(newTest);
    setIsCreating(false);
    resetForm();
  };

  const resetForm = (): void => {
    setFormData({
      name: '',
      description: '',
      targetType: 'drop',
      targetRef: '',
      domainId: '',
      riskTypeIds: [],
      testQuestions: [],
      notes: '',
    });
    setNewQuestion('');
  };

  const addQuestion = (): void => {
    if (!newQuestion.trim()) return;
    setFormData({
      ...formData,
      testQuestions: [...formData.testQuestions, newQuestion.trim()],
    });
    setNewQuestion('');
  };

  const removeQuestion = (index: number): void => {
    setFormData({
      ...formData,
      testQuestions: formData.testQuestions.filter((_: string, i: number) => i !== index),
    });
  };

  const generatePlan = (test: RedTeamTest): void => {
    const domain = domains.find((d: RiskDomain) => d.id === test.domainId);
    const testRiskTypes = riskTypes.filter((rt: RiskType) => 
      test.riskTypeIds.includes(rt.id)
    );
    const plan = generateRedTeamTestPlan(test, domain, testRiskTypes);
    setTestPlan(plan);
  };

  const updateTestStatus = (testId: string, status: TestStatus): void => {
    const test = tests.find((t: RedTeamTest) => t.id === testId);
    if (test) {
      onSave({ ...test, testStatus: status });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-black">Red Team Lab</h1>
          <p className="text-gray-600 mt-1">Test, probe, and secure DreamNet</p>
        </div>
        <Button onClick={() => setIsCreating(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Create Red Team Test
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Planned</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black">
              {tests.filter((t: RedTeamTest) => t.testStatus === 'planned').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">In Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black">
              {tests.filter((t: RedTeamTest) => t.testStatus === 'in-progress').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Completed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black">
              {tests.filter((t: RedTeamTest) => t.testStatus === 'completed').length}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-black">Red Team Tests ({tests.length})</CardTitle>
          <CardDescription>Security tests and penetration exercises</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[500px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-black">Name</TableHead>
                  <TableHead className="text-black">Target</TableHead>
                  <TableHead className="text-black">Domain</TableHead>
                  <TableHead className="text-black">Status</TableHead>
                  <TableHead className="text-black">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {tests.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-gray-500">
                      No red team tests created. Start by creating your first test.
                    </TableCell>
                  </TableRow>
                ) : (
                  tests.map((test: RedTeamTest) => {
                    const domain = domains.find((d: RiskDomain) => d.id === test.domainId);
                    return (
                      <TableRow key={test.id}>
                        <TableCell className="font-medium text-black">{test.name}</TableCell>
                        <TableCell>
                          <div className="flex flex-col gap-1">
                            <Badge variant="outline">{test.targetType}</Badge>
                            <span className="text-xs text-gray-600">{test.targetRef}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{domain?.name || 'Unknown'}</Badge>
                        </TableCell>
                        <TableCell>
                          <Select 
                            value={test.testStatus}
                            onValueChange={(value: TestStatus) => updateTestStatus(test.id, value)}
                          >
                            <SelectTrigger className="w-[140px]">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="planned">Planned</SelectItem>
                              <SelectItem value="in-progress">In Progress</SelectItem>
                              <SelectItem value="completed">Completed</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => setSelectedTest(test)}
                            >
                              View
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => generatePlan(test)}
                            >
                              <FileText className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Create Dialog */}
      <Dialog open={isCreating} onOpenChange={setIsCreating}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-black">Create Red Team Test</DialogTitle>
            <DialogDescription>Define a new security test for DreamNet</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Test Name *</Label>
              <Input 
                value={formData.name}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                  setFormData({ ...formData, name: e.target.value })
                }
                placeholder="e.g., Attack drop tokenomics, Break meme campaign"
              />
            </div>

            <div>
              <Label>Description</Label>
              <Textarea 
                value={formData.description}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => 
                  setFormData({ ...formData, description: e.target.value })
                }
                placeholder="What are you testing and why?"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Target Type *</Label>
                <Select 
                  value={formData.targetType}
                  onValueChange={(value: TargetType) => 
                    setFormData({ ...formData, targetType: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="flow">Flow</SelectItem>
                    <SelectItem value="campaign">Campaign</SelectItem>
                    <SelectItem value="drop">Drop</SelectItem>
                    <SelectItem value="mini-app">Mini-app</SelectItem>
                    <SelectItem value="agent">Agent</SelectItem>
                    <SelectItem value="scenario">Scenario</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Target Reference</Label>
                <Input 
                  value={formData.targetRef}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    setFormData({ ...formData, targetRef: e.target.value })
                  }
                  placeholder="e.g., Drop ID, Campaign name"
                />
              </div>
            </div>

            <div>
              <Label>Domain *</Label>
              <Select 
                value={formData.domainId}
                onValueChange={(value: string) => 
                  setFormData({ ...formData, domainId: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select domain" />
                </SelectTrigger>
                <SelectContent>
                  {domains.map((domain: RiskDomain) => (
                    <SelectItem key={domain.id} value={domain.id}>
                      {domain.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Test Questions</Label>
              <div className="flex gap-2 mb-2">
                <Input 
                  value={newQuestion}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    setNewQuestion(e.target.value)
                  }
                  placeholder="How could this be abused?"
                  onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addQuestion();
                    }
                  }}
                />
                <Button onClick={addQuestion} size="sm">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-2">
                {formData.testQuestions.map((question: string, i: number) => (
                  <div key={i} className="flex items-center gap-2 p-2 border rounded">
                    <span className="flex-1 text-sm text-black">{question}</span>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={() => removeQuestion(i)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleCreateTest}>Create Test</Button>
              <Button variant="outline" onClick={() => setIsCreating(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={!!selectedTest} onOpenChange={() => setSelectedTest(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-black">{selectedTest?.name}</DialogTitle>
          </DialogHeader>
          {selectedTest && (
            <ScrollArea className="h-[60vh]">
              <div className="space-y-4">
                <div>
                  <Label>Description</Label>
                  <p className="text-sm text-gray-700">{selectedTest.description}</p>
                </div>
                
                <div>
                  <Label>Target</Label>
                  <div className="flex gap-2">
                    <Badge variant="outline">{selectedTest.targetType}</Badge>
                    <Badge variant="outline">{selectedTest.targetRef}</Badge>
                  </div>
                </div>

                <div>
                  <Label>Test Questions</Label>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    {selectedTest.testQuestions.map((q: string, i: number) => (
                      <li key={i}>{q}</li>
                    ))}
                  </ul>
                </div>

                <div>
                  <Label>Findings</Label>
                  {selectedTest.findings.length === 0 ? (
                    <p className="text-sm text-gray-500">No findings yet</p>
                  ) : (
                    <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                      {selectedTest.findings.map((f: string, i: number) => (
                        <li key={i}>{f}</li>
                      ))}
                    </ul>
                  )}
                </div>

                <div>
                  <Label>Conclusions</Label>
                  <p className="text-sm text-gray-700">
                    {selectedTest.conclusions || 'Pending test completion'}
                  </p>
                </div>
              </div>
            </ScrollArea>
          )}
        </DialogContent>
      </Dialog>

      {/* Test Plan Dialog */}
      <Dialog open={!!testPlan} onOpenChange={() => setTestPlan('')}>
        <DialogContent className="max-w-3xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="text-black">Red Team Test Plan</DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[70vh]">
            <pre className="text-sm whitespace-pre-wrap text-black">{testPlan}</pre>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
