'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';
import { AlertTriangle, Shield, Target, Download } from 'lucide-react';
import type { RiskDomain, SafetyIncident, RedTeamTest } from '@/types/safety';

interface RiskDashboardProps {
  riskDomains: RiskDomain[];
  openIncidents: SafetyIncident[];
  upcomingTests: RedTeamTest[];
  scenarioCount: number;
  onCreateScenario: () => void;
  onCreateTest: () => void;
  onCreateChecklist: () => void;
  onExportPlaybook: () => void;
}

export default function RiskDashboard({
  riskDomains,
  openIncidents,
  upcomingTests,
  scenarioCount,
  onCreateScenario,
  onCreateTest,
  onCreateChecklist,
  onExportPlaybook,
}: RiskDashboardProps) {
  const criticalIncidents = openIncidents.filter((i: SafetyIncident) => i.severity === 'critical');
  const highIncidents = openIncidents.filter((i: SafetyIncident) => i.severity === 'high');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-black">DreamNet Safety & Risk Lab</h1>
          <p className="text-gray-600 mt-1">The safety + risk brain of DreamNet</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={onCreateScenario} variant="default">
            <Target className="mr-2 h-4 w-4" />
            Create Risk Scenario
          </Button>
          <Button onClick={onExportPlaybook} variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export Playbook
          </Button>
        </div>
      </div>

      {(criticalIncidents.length > 0 || highIncidents.length > 0) && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            {criticalIncidents.length > 0 && (
              <span className="font-semibold">{criticalIncidents.length} CRITICAL incidents open. </span>
            )}
            {highIncidents.length > 0 && (
              <span>{highIncidents.length} high severity incidents require attention.</span>
            )}
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Risk Domains</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black">{riskDomains.length}</div>
            <p className="text-xs text-gray-500 mt-1">{scenarioCount} scenarios tracked</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Open Incidents</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black">{openIncidents.length}</div>
            <div className="flex gap-2 mt-2">
              {criticalIncidents.length > 0 && (
                <Badge variant="destructive">{criticalIncidents.length} critical</Badge>
              )}
              {highIncidents.length > 0 && (
                <Badge variant="outline">{highIncidents.length} high</Badge>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Red Team Tests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black">{upcomingTests.length}</div>
            <p className="text-xs text-gray-500 mt-1">Planned or in progress</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-black">Risk Domains</CardTitle>
            <CardDescription>Key areas of safety concern</CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[300px]">
              <div className="space-y-3">
                {riskDomains.length === 0 ? (
                  <p className="text-gray-500 text-sm">No risk domains defined yet.</p>
                ) : (
                  riskDomains.map((domain: RiskDomain) => (
                    <div key={domain.id} className="flex items-start justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <Shield className="h-4 w-4 text-gray-600" />
                          <span className="font-semibold text-black">{domain.name}</span>
                          <Badge 
                            variant={
                              domain.importanceLevel === 'critical' ? 'destructive' :
                              domain.importanceLevel === 'high' ? 'default' :
                              'outline'
                            }
                          >
                            {domain.importanceLevel}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{domain.description}</p>
                        <code className="text-xs text-gray-500 mt-1 block">{domain.code}</code>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-black">Open Safety Incidents</CardTitle>
            <CardDescription>Require immediate attention</CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[300px]">
              <div className="space-y-3">
                {openIncidents.length === 0 ? (
                  <p className="text-gray-500 text-sm">No open incidents. Great work!</p>
                ) : (
                  openIncidents.map((incident: SafetyIncident) => (
                    <div key={incident.id} className="p-3 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <AlertTriangle 
                          className={`h-4 w-4 ${
                            incident.severity === 'critical' ? 'text-red-600' :
                            incident.severity === 'high' ? 'text-orange-600' :
                            'text-yellow-600'
                          }`}
                        />
                        <span className="font-semibold text-black">{incident.title}</span>
                      </div>
                      <div className="flex gap-2 mb-2">
                        <Badge 
                          variant={
                            incident.severity === 'critical' ? 'destructive' :
                            incident.severity === 'high' ? 'default' :
                            'outline'
                          }
                        >
                          {incident.severity}
                        </Badge>
                        <Badge variant="outline">{incident.status}</Badge>
                      </div>
                      <p className="text-sm text-gray-600">{incident.description.substring(0, 100)}...</p>
                      <p className="text-xs text-gray-500 mt-1">
                        Detected by {incident.detectedBy}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-black">Upcoming Red Team Tests</CardTitle>
          <CardDescription>Planned and in-progress security tests</CardDescription>
        </CardHeader>
        <CardContent>
          {upcomingTests.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500 mb-4">No red team tests scheduled.</p>
              <Button onClick={onCreateTest} variant="outline">
                <Target className="mr-2 h-4 w-4" />
                Create Red Team Test
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {upcomingTests.slice(0, 5).map((test: RedTeamTest) => (
                <div key={test.id} className="flex items-start justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold text-black">{test.name}</span>
                      <Badge variant="outline">{test.testStatus}</Badge>
                    </div>
                    <p className="text-sm text-gray-600">{test.description.substring(0, 120)}...</p>
                    <p className="text-xs text-gray-500 mt-1">
                      Target: {test.targetType} - {test.targetRef}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="flex gap-3">
        <Button onClick={onCreateTest} variant="outline">
          <Target className="mr-2 h-4 w-4" />
          Create Red Team Test
        </Button>
        <Button onClick={onCreateChecklist} variant="outline">
          <Shield className="mr-2 h-4 w-4" />
          Create Launch Safety Checklist
        </Button>
      </div>
    </div>
  );
}
