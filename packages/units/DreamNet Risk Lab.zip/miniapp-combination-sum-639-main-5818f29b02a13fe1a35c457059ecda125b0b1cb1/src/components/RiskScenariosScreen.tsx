'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AlertTriangle, FileText, Plus, X } from 'lucide-react';
import type { 
  RiskScenario, 
  RiskDomain, 
  RiskType, 
  RiskScenarioFilter,
  LikelihoodLevel,
  ImpactLevel,
  RiskScenarioStatus,
} from '@/types/safety';
import { filterRiskScenarios, generateId, generateSlug, generateSEOMeta } from '@/lib/safety-storage';
import { generateRiskScenarioBrief } from '@/lib/safety-reports';

interface RiskScenariosScreenProps {
  scenarios: RiskScenario[];
  domains: RiskDomain[];
  riskTypes: RiskType[];
  onSave: (scenario: RiskScenario) => void;
}

export default function RiskScenariosScreen({
  scenarios,
  domains,
  riskTypes,
  onSave,
}: RiskScenariosScreenProps) {
  const [filter, setFilter] = useState<RiskScenarioFilter>({});
  const [selectedScenario, setSelectedScenario] = useState<RiskScenario | null>(null);
  const [isCreating, setIsCreating] = useState<boolean>(false);
  const [briefText, setBriefText] = useState<string>('');
  
  const [formData, setFormData] = useState({
    name: '',
    domainId: '',
    riskTypeIds: [] as string[],
    description: '',
    context: '',
    triggers: [] as string[],
    potentialImpacts: [] as string[],
    likelihoodLevel: 'medium' as LikelihoodLevel,
    impactLevel: 'medium' as ImpactLevel,
    existingControls: [] as string[],
    proposedMitigations: [] as string[],
    tags: [] as string[],
    notes: '',
  });

  const filteredScenarios = filterRiskScenarios(scenarios, filter);

  const handleCreateScenario = (): void => {
    if (!formData.name || !formData.domainId) return;

    const seoMeta = generateSEOMeta(formData.name, formData.description, formData.tags);
    
    const newScenario: RiskScenario = {
      id: generateId(),
      name: formData.name,
      slug: generateSlug(formData.name),
      domainId: formData.domainId,
      riskTypeIds: formData.riskTypeIds,
      description: formData.description,
      context: formData.context,
      triggers: formData.triggers,
      potentialImpacts: formData.potentialImpacts,
      likelihoodLevel: formData.likelihoodLevel,
      impactLevel: formData.impactLevel,
      existingControls: formData.existingControls,
      proposedMitigations: formData.proposedMitigations,
      status: 'idea',
      tags: formData.tags,
      notes: formData.notes,
      ...seoMeta,
    };

    onSave(newScenario);
    setIsCreating(false);
    resetForm();
  };

  const resetForm = (): void => {
    setFormData({
      name: '',
      domainId: '',
      riskTypeIds: [],
      description: '',
      context: '',
      triggers: [],
      potentialImpacts: [],
      likelihoodLevel: 'medium',
      impactLevel: 'medium',
      existingControls: [],
      proposedMitigations: [],
      tags: [],
      notes: '',
    });
  };

  const addToArray = (field: keyof typeof formData, value: string): void => {
    if (!value.trim()) return;
    const currentValue = formData[field as keyof typeof formData];
    if (Array.isArray(currentValue)) {
      setFormData({
        ...formData,
        [field]: [...currentValue, value.trim()],
      });
    }
  };

  const removeFromArray = (field: keyof typeof formData, index: number): void => {
    const currentValue = formData[field as keyof typeof formData];
    if (Array.isArray(currentValue)) {
      setFormData({
        ...formData,
        [field]: currentValue.filter((_: string, i: number) => i !== index),
      });
    }
  };

  const generateBrief = (scenario: RiskScenario): void => {
    const domain = domains.find((d: RiskDomain) => d.id === scenario.domainId);
    const scenarioRiskTypes = riskTypes.filter((rt: RiskType) => 
      scenario.riskTypeIds.includes(rt.id)
    );
    const brief = generateRiskScenarioBrief(scenario, domain, scenarioRiskTypes);
    setBriefText(brief);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-black">Risk Scenarios</h1>
          <p className="text-gray-600 mt-1">Identify and track potential risks</p>
        </div>
        <Button onClick={() => setIsCreating(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Create Risk Scenario
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-black">Filters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>Domain</Label>
              <Select 
                value={filter.domainId || 'all'}
                onValueChange={(value: string) => 
                  setFilter({ ...filter, domainId: value === 'all' ? undefined : value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="All domains" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All domains</SelectItem>
                  {domains.map((domain: RiskDomain) => (
                    <SelectItem key={domain.id} value={domain.id}>
                      {domain.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Status</Label>
              <Select 
                value={filter.status || 'all'}
                onValueChange={(value: string) => 
                  setFilter({ ...filter, status: value === 'all' ? undefined : value as RiskScenarioStatus })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="idea">Idea</SelectItem>
                  <SelectItem value="analyzed">Analyzed</SelectItem>
                  <SelectItem value="accepted">Accepted</SelectItem>
                  <SelectItem value="mitigation-needed">Mitigation Needed</SelectItem>
                  <SelectItem value="deprioritized">Deprioritized</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Impact Level</Label>
              <Select 
                value={filter.impactLevel || 'all'}
                onValueChange={(value: string) => 
                  setFilter({ ...filter, impactLevel: value === 'all' ? undefined : value as ImpactLevel })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="All levels" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All levels</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-black">Scenarios ({filteredScenarios.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[500px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-black">Name</TableHead>
                  <TableHead className="text-black">Domain</TableHead>
                  <TableHead className="text-black">Likelihood</TableHead>
                  <TableHead className="text-black">Impact</TableHead>
                  <TableHead className="text-black">Status</TableHead>
                  <TableHead className="text-black">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredScenarios.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-gray-500">
                      No risk scenarios found. Create one to get started.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredScenarios.map((scenario: RiskScenario) => {
                    const domain = domains.find((d: RiskDomain) => d.id === scenario.domainId);
                    return (
                      <TableRow key={scenario.id}>
                        <TableCell className="font-medium text-black">{scenario.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{domain?.name || 'Unknown'}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant={scenario.likelihoodLevel === 'high' ? 'destructive' : 'outline'}
                          >
                            {scenario.likelihoodLevel}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant={
                              scenario.impactLevel === 'critical' ? 'destructive' :
                              scenario.impactLevel === 'high' ? 'default' :
                              'outline'
                            }
                          >
                            {scenario.impactLevel}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{scenario.status}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => setSelectedScenario(scenario)}
                            >
                              View
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => generateBrief(scenario)}
                            >
                              <FileText className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Create Dialog */}
      <Dialog open={isCreating} onOpenChange={setIsCreating}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-black">Create Risk Scenario</DialogTitle>
            <DialogDescription>Define a new risk scenario for DreamNet</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Name *</Label>
              <Input 
                value={formData.name}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                  setFormData({ ...formData, name: e.target.value })
                }
                placeholder="e.g., Meme Backlash, Drop Exploit"
              />
            </div>

            <div>
              <Label>Domain *</Label>
              <Select 
                value={formData.domainId}
                onValueChange={(value: string) => 
                  setFormData({ ...formData, domainId: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select domain" />
                </SelectTrigger>
                <SelectContent>
                  {domains.map((domain: RiskDomain) => (
                    <SelectItem key={domain.id} value={domain.id}>
                      {domain.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Description</Label>
              <Textarea 
                value={formData.description}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => 
                  setFormData({ ...formData, description: e.target.value })
                }
                placeholder="Describe the risk scenario..."
                rows={3}
              />
            </div>

            <div>
              <Label>Context</Label>
              <Textarea 
                value={formData.context}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => 
                  setFormData({ ...formData, context: e.target.value })
                }
                placeholder="e.g., Farcaster launch, Zora drop, IRL league"
                rows={2}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Likelihood Level</Label>
                <Select 
                  value={formData.likelihoodLevel}
                  onValueChange={(value: LikelihoodLevel) => 
                    setFormData({ ...formData, likelihoodLevel: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="unknown">Unknown</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Impact Level</Label>
                <Select 
                  value={formData.impactLevel}
                  onValueChange={(value: ImpactLevel) => 
                    setFormData({ ...formData, impactLevel: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleCreateScenario}>Create Scenario</Button>
              <Button variant="outline" onClick={() => setIsCreating(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={!!selectedScenario} onOpenChange={() => setSelectedScenario(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-black">{selectedScenario?.name}</DialogTitle>
          </DialogHeader>
          {selectedScenario && (
            <div className="space-y-4">
              <div>
                <Label>Description</Label>
                <p className="text-sm text-gray-700">{selectedScenario.description}</p>
              </div>
              <div>
                <Label>Context</Label>
                <p className="text-sm text-gray-700">{selectedScenario.context}</p>
              </div>
              <div className="flex gap-2">
                <Badge variant="outline">{selectedScenario.likelihoodLevel} likelihood</Badge>
                <Badge variant="outline">{selectedScenario.impactLevel} impact</Badge>
                <Badge variant="outline">{selectedScenario.status}</Badge>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Brief Dialog */}
      <Dialog open={!!briefText} onOpenChange={() => setBriefText('')}>
        <DialogContent className="max-w-3xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="text-black">Risk Scenario Brief</DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[70vh]">
            <pre className="text-sm whitespace-pre-wrap text-black">{briefText}</pre>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
