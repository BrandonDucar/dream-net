'use client';

import { useLocalStorage } from './useLocalStorage';
import type {
  RiskDomain,
  RiskType,
  RiskScenario,
  RedTeamTest,
  Control,
  SafetyIncident,
  LaunchSafetyChecklist,
  LaunchSafetyReview,
} from '@/types/safety';
import { STORAGE_KEYS } from '@/lib/safety-storage';

export function useSafetyData() {
  const [riskDomains, setRiskDomains] = useLocalStorage<RiskDomain[]>(STORAGE_KEYS.RISK_DOMAINS, []);
  const [riskTypes, setRiskTypes] = useLocalStorage<RiskType[]>(STORAGE_KEYS.RISK_TYPES, []);
  const [riskScenarios, setRiskScenarios] = useLocalStorage<RiskScenario[]>(STORAGE_KEYS.RISK_SCENARIOS, []);
  const [redTeamTests, setRedTeamTests] = useLocalStorage<RedTeamTest[]>(STORAGE_KEYS.RED_TEAM_TESTS, []);
  const [controls, setControls] = useLocalStorage<Control[]>(STORAGE_KEYS.CONTROLS, []);
  const [safetyIncidents, setSafetyIncidents] = useLocalStorage<SafetyIncident[]>(STORAGE_KEYS.SAFETY_INCIDENTS, []);
  const [launchChecklists, setLaunchChecklists] = useLocalStorage<LaunchSafetyChecklist[]>(STORAGE_KEYS.LAUNCH_CHECKLISTS, []);
  const [launchReviews, setLaunchReviews] = useLocalStorage<LaunchSafetyReview[]>(STORAGE_KEYS.LAUNCH_REVIEWS, []);

  return {
    riskDomains,
    setRiskDomains,
    riskTypes,
    setRiskTypes,
    riskScenarios,
    setRiskScenarios,
    redTeamTests,
    setRedTeamTests,
    controls,
    setControls,
    safetyIncidents,
    setSafetyIncidents,
    launchChecklists,
    setLaunchChecklists,
    launchReviews,
    setLaunchReviews,
  };
}
