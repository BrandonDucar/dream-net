// DreamNet Safety Lab - Report Generation

import type {
  RiskScenario,
  RedTeamTest,
  SafetyIncident,
  Control,
  RiskDomain,
  RiskType,
  LaunchSafetyChecklist,
  LaunchSafetyReview,
  ImportanceLevel,
  TargetType,
} from '@/types/safety';

export function generateRiskScenarioBrief(
  scenario: RiskScenario,
  domain: RiskDomain | undefined,
  riskTypes: RiskType[]
): string {
  const riskTypeNames = riskTypes.map((rt: RiskType) => rt.name).join(', ');
  
  return `
# Risk Scenario Brief: ${scenario.name}

**Domain:** ${domain?.name || 'Unknown'}
**Risk Types:** ${riskTypeNames}
**Status:** ${scenario.status.toUpperCase()}

## Overview
${scenario.description}

## Context
${scenario.context}

## Triggers
${scenario.triggers.map((t: string, i: number) => `${i + 1}. ${t}`).join('\n')}

## Potential Impacts
${scenario.potentialImpacts.map((p: string, i: number) => `${i + 1}. ${p}`).join('\n')}

## Risk Assessment
- **Likelihood:** ${scenario.likelihoodLevel.toUpperCase()}
- **Impact:** ${scenario.impactLevel.toUpperCase()}

## Existing Controls
${scenario.existingControls.length > 0 
  ? scenario.existingControls.map((c: string, i: number) => `${i + 1}. ${c}`).join('\n')
  : 'None identified'}

## Proposed Mitigations
${scenario.proposedMitigations.length > 0
  ? scenario.proposedMitigations.map((m: string, i: number) => `${i + 1}. ${m}`).join('\n')
  : 'To be determined'}

## Notes
${scenario.notes || 'None'}

---
Generated: ${new Date().toISOString()}
  `.trim();
}

export function generateRedTeamTestPlan(
  test: RedTeamTest,
  domain: RiskDomain | undefined,
  riskTypes: RiskType[]
): string {
  const riskTypeNames = riskTypes.map((rt: RiskType) => rt.name).join(', ');
  
  return `
# Red Team Test Plan: ${test.name}

**Target Type:** ${test.targetType}
**Target Reference:** ${test.targetRef}
**Domain:** ${domain?.name || 'Unknown'}
**Risk Types:** ${riskTypeNames}
**Status:** ${test.testStatus.toUpperCase()}

## Test Objective
${test.description}

## Key Questions to Answer
${test.testQuestions.map((q: string, i: number) => `${i + 1}. ${q}`).join('\n')}

## Attack Angles to Explore
- Stress testing edge cases
- Attempting to bypass intended workflows
- Exploiting technical vulnerabilities
- Social engineering / manipulation tactics
- Economic incentive misalignments
- Reputational attack vectors

## Boundaries (What NOT to Break)
- Do not impact production systems without approval
- Do not expose real user data
- Do not create actual financial loss
- Document all findings for learning

## Data to Capture
- Steps taken to execute the test
- Vulnerabilities discovered
- Severity and exploitability assessment
- Recommended fixes or mitigations
- Proof of concept (if applicable)

## Current Findings
${test.findings.length > 0
  ? test.findings.map((f: string, i: number) => `${i + 1}. ${f}`).join('\n')
  : 'Test not yet executed'}

## Conclusions
${test.conclusions || 'Pending test completion'}

## Recommended Changes
${test.recommendedChanges.length > 0
  ? test.recommendedChanges.map((c: string, i: number) => `${i + 1}. ${c}`).join('\n')
  : 'To be determined after test'}

## Notes
${test.notes || 'None'}

---
Generated: ${new Date().toISOString()}
  `.trim();
}

export function generateIncidentPostmortem(
  incident: SafetyIncident,
  domain: RiskDomain | undefined,
  riskTypes: RiskType[]
): string {
  const riskTypeNames = riskTypes.map((rt: RiskType) => rt.name).join(', ');
  
  return `
# Incident Postmortem: ${incident.title}

**Domain:** ${domain?.name || 'Unknown'}
**Risk Types:** ${riskTypeNames}
**Severity:** ${incident.severity.toUpperCase()}
**Status:** ${incident.status.toUpperCase()}
**Occurred At:** ${new Date(incident.occurredAt).toLocaleString()}
**Detected By:** ${incident.detectedBy}

## What Happened
${incident.description}

## Immediate Actions Taken
${incident.immediateActions.length > 0
  ? incident.immediateActions.map((a: string, i: number) => `${i + 1}. ${a}`).join('\n')
  : 'None documented'}

## Root Causes
${incident.rootCauses.length > 0
  ? incident.rootCauses.map((r: string, i: number) => `${i + 1}. ${r}`).join('\n')
  : 'Under investigation'}

## Lessons Learned
${incident.lessonsLearned.length > 0
  ? incident.lessonsLearned.map((l: string, i: number) => `${i + 1}. ${l}`).join('\n')
  : 'To be documented'}

## Follow-Up Tasks
${incident.followUpTasks.length > 0
  ? incident.followUpTasks.map((t: string, i: number) => `${i + 1}. ${t}`).join('\n')
  : 'None identified'}

## Related Controls
${incident.linkedControls.length > 0
  ? `Control IDs: ${incident.linkedControls.join(', ')}`
  : 'None linked'}

## Related Risk Scenarios
${incident.linkedScenarios.length > 0
  ? `Scenario IDs: ${incident.linkedScenarios.join(', ')}`
  : 'None linked'}

## Additional Notes
${incident.notes || 'None'}

---
Generated: ${new Date().toISOString()}
  `.trim();
}

export function generateLaunchSafetyGateReport(
  targetType: TargetType,
  targetRef: string,
  scenarios: RiskScenario[],
  controls: Control[],
  reviews: LaunchSafetyReview[],
  domains: RiskDomain[],
  riskTypes: RiskType[]
): string {
  const relevantReviews = reviews.filter(
    (r: LaunchSafetyReview) => r.targetType === targetType && r.targetRef === targetRef
  );
  const latestReview = relevantReviews.sort(
    (a: LaunchSafetyReview, b: LaunchSafetyReview) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
  )[0];

  return `
# Launch Safety Gate Report

**Target Type:** ${targetType}
**Target Reference:** ${targetRef}
**Report Generated:** ${new Date().toISOString()}

## Executive Summary
This report assesses the safety and risk posture for ${targetType} "${targetRef}".

## Major Risks Identified
${scenarios.length > 0
  ? scenarios.map((s: RiskScenario, i: number) => {
      const domain = domains.find((d: RiskDomain) => d.id === s.domainId);
      return `${i + 1}. **${s.name}** (${domain?.name || 'Unknown Domain'})
   - Likelihood: ${s.likelihoodLevel}
   - Impact: ${s.impactLevel}
   - Status: ${s.status}`;
    }).join('\n\n')
  : 'No specific risk scenarios documented for this target.'}

## Mitigations in Place
${controls.length > 0
  ? controls.map((c: Control, i: number) => `${i + 1}. **${c.name}** (${c.controlType})
   - ${c.description}`).join('\n\n')
  : 'No controls explicitly documented.'}

## Remaining Concerns
${scenarios
    .filter((s: RiskScenario) => s.status === 'mitigation-needed' || s.status === 'idea')
    .map((s: RiskScenario) => `- ${s.name}: ${s.proposedMitigations.join('; ') || 'Needs mitigation plan'}`)
    .join('\n') || 'None identified'}

## Latest Go/No-Go Decision
${latestReview
  ? `**Decision:** ${latestReview.goNoGoDecision.toUpperCase()}
**Overall Risk Level:** ${latestReview.overallRiskLevel}
**Reviewer:** ${latestReview.reviewerName}
**Date:** ${new Date(latestReview.date).toLocaleString()}
**Rationale:** ${latestReview.rationale}`
  : 'No launch safety review conducted yet.'}

## Recommendation
${latestReview?.goNoGoDecision === 'go'
  ? '✅ PROCEED with monitored rollout'
  : latestReview?.goNoGoDecision === 'hold'
  ? '⏸️ HOLD until concerns addressed'
  : latestReview?.goNoGoDecision === 'no-go'
  ? '🛑 DO NOT PROCEED'
  : '⚠️ CONDUCT LAUNCH SAFETY REVIEW BEFORE PROCEEDING'}

---
Generated: ${new Date().toISOString()}
  `.trim();
}

export function exportSafetyPlaybook(
  domains: RiskDomain[],
  riskTypes: RiskType[],
  scenarios: RiskScenario[],
  controls: Control[],
  tests: RedTeamTest[],
  checklists: LaunchSafetyChecklist[],
  incidents: SafetyIncident[]
): string {
  return `
# DreamNet Safety & Risk Playbook v1

**Generated:** ${new Date().toISOString()}

---

## 1. Risk Domains

${domains.map((d: RiskDomain) => `### ${d.name} (${d.code})
**Importance:** ${d.importanceLevel}
${d.description}
${d.tags.length > 0 ? `**Tags:** ${d.tags.join(', ')}` : ''}`).join('\n\n')}

---

## 2. Risk Types

${riskTypes.map((rt: RiskType) => `### ${rt.name} (${rt.code})
${rt.description}
**Typical Impact:** ${rt.typicalImpact}
**Typical Likelihood:** ${rt.typicalLikelihood}`).join('\n\n')}

---

## 3. Risk Scenarios (${scenarios.length} total)

${scenarios.slice(0, 20).map((s: RiskScenario, i: number) => {
  const domain = domains.find((d: RiskDomain) => d.id === s.domainId);
  return `### ${i + 1}. ${s.name}
**Domain:** ${domain?.name || 'Unknown'}
**Likelihood:** ${s.likelihoodLevel} | **Impact:** ${s.impactLevel} | **Status:** ${s.status}
${s.description.substring(0, 200)}...`;
}).join('\n\n')}

${scenarios.length > 20 ? `\n... and ${scenarios.length - 20} more scenarios` : ''}

---

## 4. Controls (${controls.length} total)

${controls.slice(0, 15).map((c: Control, i: number) => `### ${i + 1}. ${c.name}
**Type:** ${c.controlType}
${c.description.substring(0, 200)}...`).join('\n\n')}

${controls.length > 15 ? `\n... and ${controls.length - 15} more controls` : ''}

---

## 5. Red Team Tests (${tests.length} total)

${tests.slice(0, 10).map((t: RedTeamTest, i: number) => `### ${i + 1}. ${t.name}
**Target:** ${t.targetType} - ${t.targetRef}
**Status:** ${t.testStatus}
${t.description.substring(0, 150)}...`).join('\n\n')}

${tests.length > 10 ? `\n... and ${tests.length - 10} more tests` : ''}

---

## 6. Launch Safety Checklists (${checklists.length} total)

${checklists.map((cl: LaunchSafetyChecklist, i: number) => `### ${i + 1}. ${cl.name}
**Items:** ${cl.checklistItems.length}
${cl.description}`).join('\n\n')}

---

## 7. Incident Summaries (${incidents.length} total)

${incidents.slice(0, 10).map((inc: SafetyIncident, i: number) => `### ${i + 1}. ${inc.title}
**Severity:** ${inc.severity} | **Status:** ${inc.status}
**Occurred:** ${new Date(inc.occurredAt).toLocaleDateString()}
**Detected By:** ${inc.detectedBy}
${inc.description.substring(0, 150)}...`).join('\n\n')}

${incidents.length > 10 ? `\n... and ${incidents.length - 10} more incidents` : ''}

---

## Summary

This playbook represents DreamNet's living knowledge base for safety, risk, and red team operations.

**Total Risk Scenarios:** ${scenarios.length}
**Total Controls:** ${controls.length}
**Total Red Team Tests:** ${tests.length}
**Total Incidents:** ${incidents.length}
**Total Checklists:** ${checklists.length}

Use this playbook to inform decision-making, guide red team exercises, and continuously improve DreamNet's risk posture.

---
*DreamNet Safety, Risk & Red Team Lab*
  `.trim();
}
