// DreamNet Safety Lab - Local Storage Management

import type {
  RiskDomain,
  RiskType,
  RiskScenario,
  RedTeamTest,
  Control,
  SafetyIncident,
  LaunchSafetyChecklist,
  LaunchSafetyReview,
  RiskScenarioFilter,
  RedTeamTestFilter,
  ControlFilter,
  SafetyIncidentFilter,
  LaunchSafetyChecklistFilter,
  LaunchSafetyReviewFilter,
} from '@/types/safety';

export const STORAGE_KEYS = {
  RISK_DOMAINS: 'dreamnet_risk_domains',
  RISK_TYPES: 'dreamnet_risk_types',
  RISK_SCENARIOS: 'dreamnet_risk_scenarios',
  RED_TEAM_TESTS: 'dreamnet_red_team_tests',
  CONTROLS: 'dreamnet_controls',
  SAFETY_INCIDENTS: 'dreamnet_safety_incidents',
  LAUNCH_CHECKLISTS: 'dreamnet_launch_checklists',
  LAUNCH_REVIEWS: 'dreamnet_launch_reviews',
} as const;

// Helper functions
export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

export function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

export function generateSEOMeta(name: string, description: string, tags: string[] = []) {
  return {
    seoTitle: name,
    seoDescription: description.substring(0, 160),
    seoKeywords: tags,
    seoHashtags: tags.map((tag: string) => `#${tag.replace(/\s+/g, '')}`),
    altText: name,
  };
}

// Filter functions
export function filterRiskScenarios(
  scenarios: RiskScenario[],
  filter: RiskScenarioFilter
): RiskScenario[] {
  return scenarios.filter((scenario: RiskScenario) => {
    if (filter.domainId && scenario.domainId !== filter.domainId) return false;
    if (filter.riskTypeId && !scenario.riskTypeIds.includes(filter.riskTypeId)) return false;
    if (filter.status && scenario.status !== filter.status) return false;
    if (filter.likelihoodLevel && scenario.likelihoodLevel !== filter.likelihoodLevel) return false;
    if (filter.impactLevel && scenario.impactLevel !== filter.impactLevel) return false;
    if (filter.tag && !scenario.tags.includes(filter.tag)) return false;
    return true;
  });
}

export function filterRedTeamTests(
  tests: RedTeamTest[],
  filter: RedTeamTestFilter
): RedTeamTest[] {
  return tests.filter((test: RedTeamTest) => {
    if (filter.targetType && test.targetType !== filter.targetType) return false;
    if (filter.testStatus && test.testStatus !== filter.testStatus) return false;
    if (filter.domainId && test.domainId !== filter.domainId) return false;
    if (filter.riskTypeId && !test.riskTypeIds.includes(filter.riskTypeId)) return false;
    return true;
  });
}

export function filterControls(
  controls: Control[],
  filter: ControlFilter
): Control[] {
  return controls.filter((control: Control) => {
    if (filter.controlType && control.controlType !== filter.controlType) return false;
    if (filter.domainId && !control.domainIds.includes(filter.domainId)) return false;
    if (filter.riskTypeId && !control.riskTypeIds.includes(filter.riskTypeId)) return false;
    if (filter.tag && !control.tags.includes(filter.tag)) return false;
    return true;
  });
}

export function filterSafetyIncidents(
  incidents: SafetyIncident[],
  filter: SafetyIncidentFilter
): SafetyIncident[] {
  return incidents.filter((incident: SafetyIncident) => {
    if (filter.domainId && incident.domainId !== filter.domainId) return false;
    if (filter.riskTypeId && !incident.riskTypeIds.includes(filter.riskTypeId)) return false;
    if (filter.severity && incident.severity !== filter.severity) return false;
    if (filter.status && incident.status !== filter.status) return false;
    return true;
  });
}

export function filterLaunchChecklists(
  checklists: LaunchSafetyChecklist[],
  filter: LaunchSafetyChecklistFilter
): LaunchSafetyChecklist[] {
  return checklists.filter((checklist: LaunchSafetyChecklist) => {
    if (filter.domainId && !checklist.domainIds.includes(filter.domainId)) return false;
    if (filter.riskTypeId && !checklist.riskTypeIds.includes(filter.riskTypeId)) return false;
    if (filter.tag && !checklist.tags.includes(filter.tag)) return false;
    return true;
  });
}

export function filterLaunchReviews(
  reviews: LaunchSafetyReview[],
  filter: LaunchSafetyReviewFilter
): LaunchSafetyReview[] {
  return reviews.filter((review: LaunchSafetyReview) => {
    if (filter.targetType && review.targetType !== filter.targetType) return false;
    if (filter.checklistId && review.checklistId !== filter.checklistId) return false;
    if (filter.overallRiskLevel && review.overallRiskLevel !== filter.overallRiskLevel) return false;
    if (filter.goNoGoDecision && review.goNoGoDecision !== filter.goNoGoDecision) return false;
    return true;
  });
}
