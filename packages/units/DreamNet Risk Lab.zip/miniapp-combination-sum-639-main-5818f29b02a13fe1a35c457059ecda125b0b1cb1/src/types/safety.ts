// DreamNet Safety, Risk & Red Team Lab - Type Definitions

export type ImportanceLevel = "low" | "medium" | "high" | "critical";
export type LikelihoodLevel = "low" | "medium" | "high" | "unknown";
export type ImpactLevel = "low" | "medium" | "high" | "critical";
export type SeverityLevel = "low" | "medium" | "high" | "critical";
export type RiskScenarioStatus = "idea" | "analyzed" | "accepted" | "mitigation-needed" | "deprioritized";
export type TestStatus = "planned" | "in-progress" | "completed";
export type IncidentStatus = "open" | "monitoring" | "resolved";
export type GoNoGoDecision = "go" | "hold" | "no-go";

export type TargetType = 
  | "flow" 
  | "campaign" 
  | "drop" 
  | "mini-app" 
  | "agent" 
  | "scenario" 
  | "other"
  | "change-set";

export type ControlType = 
  | "process" 
  | "technical" 
  | "cultural" 
  | "economic" 
  | "legal" 
  | "other";

export interface RiskDomain {
  id: string;
  name: string;
  code: string;
  description: string;
  importanceLevel: ImportanceLevel;
  tags: string[];
  notes: string;
}

export interface RiskType {
  id: string;
  name: string;
  code: string;
  description: string;
  typicalImpact: string;
  typicalLikelihood: string;
  tags: string[];
  notes: string;
}

export interface SEOMeta {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export interface RiskScenario extends SEOMeta {
  id: string;
  name: string;
  slug: string;
  domainId: string;
  riskTypeIds: string[];
  description: string;
  context: string;
  triggers: string[];
  potentialImpacts: string[];
  likelihoodLevel: LikelihoodLevel;
  impactLevel: ImpactLevel;
  existingControls: string[];
  proposedMitigations: string[];
  status: RiskScenarioStatus;
  tags: string[];
  notes: string;
}

export interface RedTeamTest {
  id: string;
  name: string;
  description: string;
  targetType: TargetType;
  targetRef: string;
  domainId: string;
  riskTypeIds: string[];
  testQuestions: string[];
  testStatus: TestStatus;
  findings: string[];
  conclusions: string;
  recommendedChanges: string[];
  notes: string;
}

export interface Control {
  id: string;
  name: string;
  description: string;
  controlType: ControlType;
  domainIds: string[];
  riskTypeIds: string[];
  strengths: string[];
  weaknesses: string[];
  implementationHints: string[];
  tags: string[];
  notes: string;
}

export interface SafetyIncident {
  id: string;
  title: string;
  slug: string;
  description: string;
  domainId: string;
  riskTypeIds: string[];
  severity: SeverityLevel;
  status: IncidentStatus;
  occurredAt: string;
  detectedBy: string;
  immediateActions: string[];
  rootCauses: string[];
  lessonsLearned: string[];
  followUpTasks: string[];
  linkedControls: string[];
  linkedScenarios: string[];
  notes: string;
}

export interface LaunchSafetyChecklist extends SEOMeta {
  id: string;
  name: string;
  description: string;
  domainIds: string[];
  riskTypeIds: string[];
  checklistItems: string[];
  tags: string[];
  notes: string;
}

export interface LaunchSafetyReview {
  id: string;
  checklistId: string;
  targetType: TargetType;
  targetRef: string;
  reviewerName: string;
  date: string;
  responses: Record<string, string>;
  overallRiskLevel: ImportanceLevel;
  goNoGoDecision: GoNoGoDecision;
  rationale: string;
  notes: string;
}

// Filter types
export interface RiskScenarioFilter {
  domainId?: string;
  riskTypeId?: string;
  status?: RiskScenarioStatus;
  likelihoodLevel?: LikelihoodLevel;
  impactLevel?: ImpactLevel;
  tag?: string;
}

export interface RedTeamTestFilter {
  targetType?: TargetType;
  testStatus?: TestStatus;
  domainId?: string;
  riskTypeId?: string;
}

export interface ControlFilter {
  controlType?: ControlType;
  domainId?: string;
  riskTypeId?: string;
  tag?: string;
}

export interface SafetyIncidentFilter {
  domainId?: string;
  riskTypeId?: string;
  severity?: SeverityLevel;
  status?: IncidentStatus;
}

export interface LaunchSafetyChecklistFilter {
  domainId?: string;
  riskTypeId?: string;
  tag?: string;
}

export interface LaunchSafetyReviewFilter {
  targetType?: TargetType;
  checklistId?: string;
  overallRiskLevel?: ImportanceLevel;
  goNoGoDecision?: GoNoGoDecision;
}
