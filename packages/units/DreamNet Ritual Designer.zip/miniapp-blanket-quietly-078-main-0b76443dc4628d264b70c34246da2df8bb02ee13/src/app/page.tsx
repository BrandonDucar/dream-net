'use client'
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Sparkles, Calendar, Repeat, TrendingUp, Gem, History, Plus, FileDown, FileText, Trash2, Edit, BarChart3, Bell, Wand2, Play } from 'lucide-react';
import type {
  Ritual,
  CeremonySequence,
  CycleDefinition,
  InitiationPath,
  SymbolicObject,
  RitualEventLog,
} from '@/types/ritual';
import {
  listRituals,
  listCeremonies,
  listCycles,
  listInitiationPaths,
  listSymbolicObjects,
  listRitualEvents,
  createRitual,
  updateRitual,
  deleteRitual,
  createCeremonySequence,
  updateCeremonySequence,
  deleteCeremonySequence,
  createCycleDefinition,
  updateCycleDefinition,
  deleteCycleDefinition,
  createInitiationPath,
  updateInitiationPath,
  deleteInitiationPath,
  createSymbolicObject,
  updateSymbolicObject,
  deleteSymbolicObject,
  recordRitualEvent,
  updateRitualEvent,
  deleteRitualEvent,
  getRitual,
} from '@/lib/ritual-store';
import {
  generateRitualGuide,
  generateCeremonyScript,
  generateCycleMap,
  generateInitiationGuide,
  exportRitualCodex,
} from '@/lib/ritual-generators';
import { RitualForm, type RitualFormData } from '@/components/ritual-form';
import { CeremonyForm, type CeremonyFormData } from '@/components/ceremony-form';
import { CycleForm, type CycleFormData } from '@/components/cycle-form';
import { InitiationForm, type InitiationFormData } from '@/components/initiation-form';
import { SymbolicObjectForm, type SymbolicObjectFormData } from '@/components/symbolic-object-form';
import { EventLogForm, type EventLogFormData } from '@/components/event-log-form';
import { toast } from 'sonner';
import { AnalyticsDashboard } from '@/components/analytics-dashboard';
import { CultureCalendar } from '@/components/culture-calendar';
import { AIDesignerPanel } from '@/components/ai-designer-panel';
import { NotificationsPanel } from '@/components/notifications-panel';
import { CeremonySimulationViewer } from '@/components/ceremony-simulation-viewer';
import { EnhancedExportDialog } from '@/components/enhanced-export-dialog';
import { generateCalendarEvents } from '@/lib/ritual-calendar';
import { addMonths } from 'date-fns';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type DialogMode = 'create' | 'edit' | 'view';

export default function DreamNetRitualsPage(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [rituals, setRituals] = useState<Ritual[]>([]);
  const [ceremonies, setCeremonies] = useState<CeremonySequence[]>([]);
  const [cycles, setCycles] = useState<CycleDefinition[]>([]);
  const [paths, setPaths] = useState<InitiationPath[]>([]);
  const [objects, setObjects] = useState<SymbolicObject[]>([]);
  const [events, setEvents] = useState<RitualEventLog[]>([]);

  const [activeTab, setActiveTab] = useState<string>('rituals');
  const [exportDialogOpen, setExportDialogOpen] = useState<boolean>(false);
  const [simulationCeremony, setSimulationCeremony] = useState<CeremonySequence | null>(null);
  
  const [ritualDialog, setRitualDialog] = useState<{ open: boolean; mode: DialogMode; item: Ritual | null }>({
    open: false,
    mode: 'create',
    item: null,
  });
  const [ceremonyDialog, setCeremonyDialog] = useState<{ open: boolean; mode: DialogMode; item: CeremonySequence | null }>({
    open: false,
    mode: 'create',
    item: null,
  });
  const [cycleDialog, setCycleDialog] = useState<{ open: boolean; mode: DialogMode; item: CycleDefinition | null }>({
    open: false,
    mode: 'create',
    item: null,
  });
  const [pathDialog, setPathDialog] = useState<{ open: boolean; mode: DialogMode; item: InitiationPath | null }>({
    open: false,
    mode: 'create',
    item: null,
  });
  const [objectDialog, setObjectDialog] = useState<{ open: boolean; mode: DialogMode; item: SymbolicObject | null }>({
    open: false,
    mode: 'create',
    item: null,
  });
  const [eventDialog, setEventDialog] = useState<{ open: boolean; mode: DialogMode; item: RitualEventLog | null }>({
    open: false,
    mode: 'create',
    item: null,
  });

  const [generatedText, setGeneratedText] = useState<{ open: boolean; title: string; content: string }>({
    open: false,
    title: '',
    content: '',
  });

  const [deleteDialog, setDeleteDialog] = useState<{
    open: boolean;
    type: 'ritual' | 'ceremony' | 'cycle' | 'path' | 'object' | 'event';
    id: string;
    name: string;
  }>({
    open: false,
    type: 'ritual',
    id: '',
    name: '',
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = (): void => {
    setRituals(listRituals());
    setCeremonies(listCeremonies());
    setCycles(listCycles());
    setPaths(listInitiationPaths());
    setObjects(listSymbolicObjects());
    setEvents(listRitualEvents());
  };

  const handleSaveRitual = (data: RitualFormData): void => {
    if (ritualDialog.mode === 'edit' && ritualDialog.item) {
      updateRitual(ritualDialog.item.id, data);
      toast.success('Ritual updated successfully');
    } else {
      createRitual(data);
      toast.success('Ritual created successfully');
    }
    setRitualDialog({ open: false, mode: 'create', item: null });
    loadData();
  };

  const handleSaveCeremony = (data: CeremonyFormData): void => {
    if (ceremonyDialog.mode === 'edit' && ceremonyDialog.item) {
      updateCeremonySequence(ceremonyDialog.item.id, data);
      toast.success('Ceremony updated successfully');
    } else {
      createCeremonySequence(data);
      toast.success('Ceremony created successfully');
    }
    setCeremonyDialog({ open: false, mode: 'create', item: null });
    loadData();
  };

  const handleSaveCycle = (data: CycleFormData): void => {
    if (cycleDialog.mode === 'edit' && cycleDialog.item) {
      updateCycleDefinition(cycleDialog.item.id, data);
      toast.success('Cycle updated successfully');
    } else {
      createCycleDefinition(data);
      toast.success('Cycle created successfully');
    }
    setCycleDialog({ open: false, mode: 'create', item: null });
    loadData();
  };

  const handleSavePath = (data: InitiationFormData): void => {
    if (pathDialog.mode === 'edit' && pathDialog.item) {
      updateInitiationPath(pathDialog.item.id, data);
      toast.success('Initiation path updated successfully');
    } else {
      createInitiationPath(data);
      toast.success('Initiation path created successfully');
    }
    setPathDialog({ open: false, mode: 'create', item: null });
    loadData();
  };

  const handleSaveObject = (data: SymbolicObjectFormData): void => {
    if (objectDialog.mode === 'edit' && objectDialog.item) {
      updateSymbolicObject(objectDialog.item.id, data);
      toast.success('Symbolic object updated successfully');
    } else {
      createSymbolicObject(data);
      toast.success('Symbolic object created successfully');
    }
    setObjectDialog({ open: false, mode: 'create', item: null });
    loadData();
  };

  const handleSaveEvent = (data: EventLogFormData): void => {
    if (eventDialog.mode === 'edit' && eventDialog.item) {
      updateRitualEvent(eventDialog.item.id, data);
      toast.success('Event updated successfully');
    } else {
      recordRitualEvent(data);
      toast.success('Event recorded successfully');
    }
    setEventDialog({ open: false, mode: 'create', item: null });
    loadData();
  };

  const handleDelete = (): void => {
    switch (deleteDialog.type) {
      case 'ritual':
        deleteRitual(deleteDialog.id);
        break;
      case 'ceremony':
        deleteCeremonySequence(deleteDialog.id);
        break;
      case 'cycle':
        deleteCycleDefinition(deleteDialog.id);
        break;
      case 'path':
        deleteInitiationPath(deleteDialog.id);
        break;
      case 'object':
        deleteSymbolicObject(deleteDialog.id);
        break;
      case 'event':
        deleteRitualEvent(deleteDialog.id);
        break;
    }
    toast.success(`${deleteDialog.type} deleted successfully`);
    setDeleteDialog({ open: false, type: 'ritual', id: '', name: '' });
    loadData();
  };

  const handleExportCodex = (): void => {
    setExportDialogOpen(true);
  };

  const calendarEvents = generateCalendarEvents(
    rituals,
    ceremonies,
    cycles,
    events,
    new Date(),
    addMonths(new Date(), 3)
  );

  const handleGenerateGuide = (ritualId: string): void => {
    const guide = generateRitualGuide(ritualId);
    const ritual = getRitual(ritualId);
    setGeneratedText({
      open: true,
      title: `Ritual Guide: ${ritual?.name || 'Unknown'}`,
      content: guide,
    });
  };

  const handleGenerateCeremonyScript = (ceremonyId: string): void => {
    const script = generateCeremonyScript(ceremonyId);
    const ceremony = ceremonies.find((c: CeremonySequence) => c.id === ceremonyId);
    setGeneratedText({
      open: true,
      title: `Ceremony Script: ${ceremony?.name || 'Unknown'}`,
      content: script,
    });
  };

  const handleGenerateCycleMap = (cycleId: string): void => {
    const map = generateCycleMap(cycleId);
    const cycle = cycles.find((c: CycleDefinition) => c.id === cycleId);
    setGeneratedText({
      open: true,
      title: `Cycle Map: ${cycle?.name || 'Unknown'}`,
      content: map,
    });
  };

  const handleGenerateInitiationGuide = (pathId: string): void => {
    const guide = generateInitiationGuide(pathId);
    const path = paths.find((p: InitiationPath) => p.id === pathId);
    setGeneratedText({
      open: true,
      title: `Initiation Guide: ${path?.name || 'Unknown'}`,
      content: guide,
    });
  };

  const downloadGeneratedText = (): void => {
    const blob = new Blob([generatedText.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${generatedText.title.toLowerCase().replace(/\s+/g, '-')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Guide downloaded successfully');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-purple-50 to-fuchsia-50 dark:from-gray-900 dark:via-purple-900 dark:to-violet-900 pt-12 px-4 pb-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-4">
            <Sparkles className="h-8 w-8 text-purple-600 dark:text-purple-400" />
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 to-fuchsia-600 dark:from-purple-400 dark:to-fuchsia-400 bg-clip-text text-transparent">
              DreamNet Rituals
            </h1>
            <Sparkles className="h-8 w-8 text-purple-600 dark:text-purple-400" />
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            The spiritual architecture of DreamNet — ceremonies, cycles, and sacred practices
            that give our world meaning, tradition, and cohesion.
          </p>
        </div>

        <div className="flex justify-center mb-6">
          <Button
            size="lg"
            onClick={handleExportCodex}
            className="bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-700 hover:to-fuchsia-700"
          >
            <FileDown className="h-5 w-5 mr-2" />
            Export Ritual Codex
          </Button>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-10 mb-6">
            <TabsTrigger value="rituals" className="flex items-center gap-2">
              <Sparkles className="h-4 w-4" />
              Rituals
            </TabsTrigger>
            <TabsTrigger value="ceremonies" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Ceremonies
            </TabsTrigger>
            <TabsTrigger value="cycles" className="flex items-center gap-2">
              <Repeat className="h-4 w-4" />
              Cycles
            </TabsTrigger>
            <TabsTrigger value="paths" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Paths
            </TabsTrigger>
            <TabsTrigger value="objects" className="flex items-center gap-2">
              <Gem className="h-4 w-4" />
              Objects
            </TabsTrigger>
            <TabsTrigger value="events" className="flex items-center gap-2">
              <History className="h-4 w-4" />
              Events
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="calendar" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Calendar
            </TabsTrigger>
            <TabsTrigger value="ai" className="flex items-center gap-2">
              <Wand2 className="h-4 w-4" />
              AI Designer
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center gap-2">
              <Bell className="h-4 w-4" />
              Notifications
            </TabsTrigger>
          </TabsList>

          <TabsContent value="rituals">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-semibold">Sacred Rituals ({rituals.length})</h2>
              <Button onClick={() => setRitualDialog({ open: true, mode: 'create', item: null })}>
                <Plus className="h-4 w-4 mr-2" />
                Create Ritual
              </Button>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {rituals.map((ritual: Ritual) => (
                <Card key={ritual.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start mb-2">
                      <CardTitle className="text-lg">{ritual.name}</CardTitle>
                      <div className="flex gap-1">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => setRitualDialog({ open: true, mode: 'edit', item: ritual })}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => setDeleteDialog({ open: true, type: 'ritual', id: ritual.id, name: ritual.name })}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                    <CardDescription className="line-clamp-2">{ritual.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex flex-wrap gap-2">
                        <Badge variant="secondary">{ritual.ritualType}</Badge>
                        <Badge variant="outline">{ritual.domain}</Badge>
                        <Badge>{ritual.frequency}</Badge>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {ritual.tags.slice(0, 3).map((tag: string) => (
                          <span key={tag} className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                            #{tag}
                          </span>
                        ))}
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        className="w-full"
                        onClick={() => handleGenerateGuide(ritual.id)}
                      >
                        <FileText className="h-4 w-4 mr-2" />
                        Generate Guide
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            {rituals.length === 0 && (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  No rituals created yet. Create your first ritual to begin building the spiritual layer of DreamNet.
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="ceremonies">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-semibold">Ceremony Sequences ({ceremonies.length})</h2>
              <Button onClick={() => setCeremonyDialog({ open: true, mode: 'create', item: null })}>
                <Plus className="h-4 w-4 mr-2" />
                Create Ceremony
              </Button>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              {ceremonies.map((ceremony: CeremonySequence) => (
                <Card key={ceremony.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start mb-2">
                      <CardTitle className="text-lg">{ceremony.name}</CardTitle>
                      <div className="flex gap-1">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => setCeremonyDialog({ open: true, mode: 'edit', item: ceremony })}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => setDeleteDialog({ open: true, type: 'ceremony', id: ceremony.id, name: ceremony.name })}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                    <CardDescription className="line-clamp-2">{ceremony.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="text-sm text-muted-foreground">
                        <strong>Timing:</strong> {ceremony.recommendedTiming}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        <strong>Rituals:</strong> {ceremony.ritualIds.length}
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {ceremony.tags.slice(0, 3).map((tag: string) => (
                          <span key={tag} className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                            #{tag}
                          </span>
                        ))}
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1"
                          onClick={() => handleGenerateCeremonyScript(ceremony.id)}
                        >
                          <FileText className="h-4 w-4 mr-2" />
                          Script
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1"
                          onClick={() => setSimulationCeremony(ceremony)}
                        >
                          <Play className="h-4 w-4 mr-2" />
                          Simulate
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            {ceremonies.length === 0 && (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  No ceremonies created yet. Combine rituals into ceremonial sequences.
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="cycles">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-semibold">Cycle Definitions ({cycles.length})</h2>
              <Button onClick={() => setCycleDialog({ open: true, mode: 'create', item: null })}>
                <Plus className="h-4 w-4 mr-2" />
                Create Cycle
              </Button>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              {cycles.map((cycle: CycleDefinition) => (
                <Card key={cycle.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start mb-2">
                      <CardTitle className="text-lg">{cycle.name}</CardTitle>
                      <div className="flex gap-1">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => setCycleDialog({ open: true, mode: 'edit', item: cycle })}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => setDeleteDialog({ open: true, type: 'cycle', id: cycle.id, name: cycle.name })}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                    <CardDescription className="line-clamp-2">{cycle.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="text-sm text-muted-foreground">
                        <strong>Phases:</strong> {cycle.phases.join(' → ')}
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {cycle.tags.slice(0, 3).map((tag: string) => (
                          <span key={tag} className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                            #{tag}
                          </span>
                        ))}
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        className="w-full"
                        onClick={() => handleGenerateCycleMap(cycle.id)}
                      >
                        <FileText className="h-4 w-4 mr-2" />
                        Generate Map
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            {cycles.length === 0 && (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  No cycles defined yet. Create cycles to govern the natural flow of energy and attention.
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="paths">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-semibold">Initiation Paths ({paths.length})</h2>
              <Button onClick={() => setPathDialog({ open: true, mode: 'create', item: null })}>
                <Plus className="h-4 w-4 mr-2" />
                Create Path
              </Button>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              {paths.map((path: InitiationPath) => (
                <Card key={path.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start mb-2">
                      <CardTitle className="text-lg">{path.name}</CardTitle>
                      <div className="flex gap-1">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => setPathDialog({ open: true, mode: 'edit', item: path })}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => setDeleteDialog({ open: true, type: 'path', id: path.id, name: path.name })}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                    <CardDescription className="line-clamp-2">{path.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="text-sm text-muted-foreground">
                        <strong>Personas:</strong> {path.personaArchetypes.join(', ')}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        <strong>Milestones:</strong> {path.milestones.length}
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {path.tags.slice(0, 3).map((tag: string) => (
                          <span key={tag} className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                            #{tag}
                          </span>
                        ))}
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        className="w-full"
                        onClick={() => handleGenerateInitiationGuide(path.id)}
                      >
                        <FileText className="h-4 w-4 mr-2" />
                        Generate Guide
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            {paths.length === 0 && (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  No initiation paths created yet. Map journeys of growth and transformation.
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="objects">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-semibold">Symbolic Objects ({objects.length})</h2>
              <Button onClick={() => setObjectDialog({ open: true, mode: 'create', item: null })}>
                <Plus className="h-4 w-4 mr-2" />
                Create Object
              </Button>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {objects.map((object: SymbolicObject) => (
                <Card key={object.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start mb-2">
                      <CardTitle className="text-lg">{object.name}</CardTitle>
                      <div className="flex gap-1">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => setObjectDialog({ open: true, mode: 'edit', item: object })}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => setDeleteDialog({ open: true, type: 'object', id: object.id, name: object.name })}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                    <CardDescription className="line-clamp-2">{object.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="text-sm text-muted-foreground">
                        <strong>Used in rituals:</strong> {object.usedInRitualIds.length}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        <strong>Used in cycles:</strong> {object.usedInCycleIds.length}
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {object.tags.slice(0, 3).map((tag: string) => (
                          <span key={tag} className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                            #{tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            {objects.length === 0 && (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  No symbolic objects defined yet. Create sacred relics that carry deep cultural resonance.
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="events">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-semibold">Ritual Event Logs ({events.length})</h2>
              <Button onClick={() => setEventDialog({ open: true, mode: 'create', item: null })}>
                <Plus className="h-4 w-4 mr-2" />
                Record Event
              </Button>
            </div>
            <div className="space-y-4">
              {events.map((event: RitualEventLog) => {
                const ritual = getRitual(event.ritualId);
                return (
                  <Card key={event.id}>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">
                            {ritual ? ritual.name : 'Unknown Ritual'}
                          </CardTitle>
                          <CardDescription>
                            {new Date(event.timestamp).toLocaleString()}
                          </CardDescription>
                        </div>
                        <div className="flex gap-1">
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => setEventDialog({ open: true, mode: 'edit', item: event })}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => setDeleteDialog({ open: true, type: 'event', id: event.id, name: ritual?.name || 'Event' })}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div>
                          <strong className="text-sm">Participants:</strong>
                          <div className="flex flex-wrap gap-2 mt-1">
                            {event.participants.map((p: string, i: number) => (
                              <Badge key={i} variant="secondary">{p}</Badge>
                            ))}
                          </div>
                        </div>
                        {event.notes && (
                          <div>
                            <strong className="text-sm">Notes:</strong>
                            <p className="text-sm text-muted-foreground mt-1">{event.notes}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
            {events.length === 0 && (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  No ritual events recorded yet. Log when rituals are performed to track your practices.
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="analytics">
            <AnalyticsDashboard rituals={rituals} events={events} />
          </TabsContent>

          <TabsContent value="calendar">
            <CultureCalendar
              rituals={rituals}
              ceremonies={ceremonies}
              cycles={cycles}
              events={events}
            />
          </TabsContent>

          <TabsContent value="ai">
            <AIDesignerPanel
              rituals={rituals}
              events={events}
              onCreateRitual={(template) => {
                setRitualDialog({ open: true, mode: 'create', item: null });
                toast.info('Template loaded - customize and save');
              }}
            />
          </TabsContent>

          <TabsContent value="notifications">
            <NotificationsPanel
              rituals={rituals}
              ceremonies={ceremonies}
              paths={paths}
              events={events}
            />
          </TabsContent>
        </Tabs>

        <Dialog open={ritualDialog.open} onOpenChange={(open: boolean) => setRitualDialog({ ...ritualDialog, open })}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
            <DialogHeader>
              <DialogTitle>
                {ritualDialog.mode === 'edit' ? 'Edit Ritual' : 'Create New Ritual'}
              </DialogTitle>
              <DialogDescription>
                Define a sacred practice that strengthens the fabric of DreamNet.
              </DialogDescription>
            </DialogHeader>
            <ScrollArea className="flex-1 pr-4">
              <RitualForm
                ritual={ritualDialog.item}
                onSave={handleSaveRitual}
                onCancel={() => setRitualDialog({ open: false, mode: 'create', item: null })}
              />
            </ScrollArea>
          </DialogContent>
        </Dialog>

        <Dialog open={ceremonyDialog.open} onOpenChange={(open: boolean) => setCeremonyDialog({ ...ceremonyDialog, open })}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
            <DialogHeader>
              <DialogTitle>
                {ceremonyDialog.mode === 'edit' ? 'Edit Ceremony' : 'Create New Ceremony'}
              </DialogTitle>
              <DialogDescription>
                Combine rituals into a ceremonial sequence.
              </DialogDescription>
            </DialogHeader>
            <ScrollArea className="flex-1 pr-4">
              <CeremonyForm
                ceremony={ceremonyDialog.item}
                onSave={handleSaveCeremony}
                onCancel={() => setCeremonyDialog({ open: false, mode: 'create', item: null })}
              />
            </ScrollArea>
          </DialogContent>
        </Dialog>

        <Dialog open={cycleDialog.open} onOpenChange={(open: boolean) => setCycleDialog({ ...cycleDialog, open })}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
            <DialogHeader>
              <DialogTitle>
                {cycleDialog.mode === 'edit' ? 'Edit Cycle' : 'Create New Cycle'}
              </DialogTitle>
              <DialogDescription>
                Define a natural cycle that governs energy flow.
              </DialogDescription>
            </DialogHeader>
            <ScrollArea className="flex-1 pr-4">
              <CycleForm
                cycle={cycleDialog.item}
                onSave={handleSaveCycle}
                onCancel={() => setCycleDialog({ open: false, mode: 'create', item: null })}
              />
            </ScrollArea>
          </DialogContent>
        </Dialog>

        <Dialog open={pathDialog.open} onOpenChange={(open: boolean) => setPathDialog({ ...pathDialog, open })}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
            <DialogHeader>
              <DialogTitle>
                {pathDialog.mode === 'edit' ? 'Edit Initiation Path' : 'Create New Initiation Path'}
              </DialogTitle>
              <DialogDescription>
                Map a journey of growth and transformation.
              </DialogDescription>
            </DialogHeader>
            <ScrollArea className="flex-1 pr-4">
              <InitiationForm
                path={pathDialog.item}
                onSave={handleSavePath}
                onCancel={() => setPathDialog({ open: false, mode: 'create', item: null })}
              />
            </ScrollArea>
          </DialogContent>
        </Dialog>

        <Dialog open={objectDialog.open} onOpenChange={(open: boolean) => setObjectDialog({ ...objectDialog, open })}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
            <DialogHeader>
              <DialogTitle>
                {objectDialog.mode === 'edit' ? 'Edit Symbolic Object' : 'Create New Symbolic Object'}
              </DialogTitle>
              <DialogDescription>
                Define a sacred relic that carries deep cultural resonance.
              </DialogDescription>
            </DialogHeader>
            <ScrollArea className="flex-1 pr-4">
              <SymbolicObjectForm
                object={objectDialog.item}
                onSave={handleSaveObject}
                onCancel={() => setObjectDialog({ open: false, mode: 'create', item: null })}
              />
            </ScrollArea>
          </DialogContent>
        </Dialog>

        <Dialog open={eventDialog.open} onOpenChange={(open: boolean) => setEventDialog({ ...eventDialog, open })}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {eventDialog.mode === 'edit' ? 'Edit Event' : 'Record New Event'}
              </DialogTitle>
              <DialogDescription>
                Log when a ritual is performed.
              </DialogDescription>
            </DialogHeader>
            <EventLogForm
              event={eventDialog.item}
              onSave={handleSaveEvent}
              onCancel={() => setEventDialog({ open: false, mode: 'create', item: null })}
            />
          </DialogContent>
        </Dialog>

        <Dialog open={generatedText.open} onOpenChange={(open: boolean) => setGeneratedText({ ...generatedText, open })}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
            <DialogHeader>
              <DialogTitle>{generatedText.title}</DialogTitle>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={downloadGeneratedText}>
                  <FileDown className="h-4 w-4 mr-2" />
                  Download
                </Button>
              </div>
            </DialogHeader>
            <ScrollArea className="flex-1">
              <pre className="whitespace-pre-wrap text-xs font-mono bg-muted p-4 rounded">
                {generatedText.content}
              </pre>
            </ScrollArea>
          </DialogContent>
        </Dialog>

        <AlertDialog open={deleteDialog.open} onOpenChange={(open: boolean) => setDeleteDialog({ ...deleteDialog, open })}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This will permanently delete &quot;{deleteDialog.name}&quot;. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        <EnhancedExportDialog
          open={exportDialogOpen}
          onOpenChange={setExportDialogOpen}
          rituals={rituals}
          ceremonies={ceremonies}
          cycles={cycles}
          paths={paths}
          objects={objects}
          events={events}
          calendarEvents={calendarEvents}
        />

        {simulationCeremony && (
          <Dialog open={!!simulationCeremony} onOpenChange={(open: boolean) => !open && setSimulationCeremony(null)}>
            <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
              <DialogHeader>
                <DialogTitle>Ceremony Simulation</DialogTitle>
              </DialogHeader>
              <ScrollArea className="flex-1">
                <CeremonySimulationViewer
                  ceremony={simulationCeremony}
                  onClose={() => setSimulationCeremony(null)}
                />
              </ScrollArea>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
}
