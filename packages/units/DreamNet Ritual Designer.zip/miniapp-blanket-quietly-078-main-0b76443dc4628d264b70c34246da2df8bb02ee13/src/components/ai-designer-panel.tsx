'use client'

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { Ritual, RitualEventLog, AIRitualSuggestion, RitualArchetype } from '@/types/ritual';
import {
  generateRitualSuggestions,
  generateRitualTemplate,
  validateRitualGrammar,
  improveRitualBasedOnFeedback,
} from '@/lib/ritual-ai-designer';
import { Sparkles, Lightbulb, Wand2, CheckCircle2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface AIDesignerPanelProps {
  rituals: Ritual[];
  events: RitualEventLog[];
  onCreateRitual?: (template: Partial<Ritual>) => void;
}

export function AIDesignerPanel({ rituals, events, onCreateRitual }: AIDesignerPanelProps): JSX.Element {
  const [suggestions, setSuggestions] = useState<AIRitualSuggestion[]>([]);
  const [selectedSuggestion, setSelectedSuggestion] = useState<AIRitualSuggestion | null>(null);
  const [templateDialog, setTemplateDialog] = useState<boolean>(false);
  const [selectedArchetype, setSelectedArchetype] = useState<RitualArchetype | null>(null);
  
  useEffect(() => {
    const newSuggestions = generateRitualSuggestions(rituals, events);
    setSuggestions(newSuggestions);
  }, [rituals, events]);
  
  const handleUseSuggestion = (suggestion: AIRitualSuggestion): void => {
    setSelectedSuggestion(suggestion);
  };
  
  const handleUseTemplate = (archetype: RitualArchetype): void => {
    const template = generateRitualTemplate(archetype, 'culture');
    setSelectedArchetype(archetype);
    
    if (onCreateRitual) {
      onCreateRitual(template);
    }
  };
  
  const archetypes: { type: RitualArchetype; label: string; description: string }[] = [
    { type: 'blessing', label: 'Blessing', description: 'Bestow positive energy and support' },
    { type: 'challenge', label: 'Challenge', description: 'Test and strengthen capabilities' },
    { type: 'transition', label: 'Transition', description: 'Mark and facilitate change' },
    { type: 'celebration', label: 'Celebration', description: 'Honor achievements' },
    { type: 'mourning', label: 'Mourning', description: 'Process loss and find closure' },
    { type: 'invocation', label: 'Invocation', description: 'Call upon wisdom or assistance' },
    { type: 'release', label: 'Release', description: 'Let go of what no longer serves' },
    { type: 'transformation', label: 'Transformation', description: 'Facilitate deep change' },
  ];
  
  // Calculate improvement suggestions for existing rituals
  const improvementSuggestions = rituals.slice(0, 5).map((ritual: Ritual) => ({
    ritual,
    suggestions: improveRitualBasedOnFeedback(ritual, events),
  })).filter((item) => item.suggestions.length > 0);
  
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <Wand2 className="h-8 w-8 text-purple-500" />
          AI Ritual Designer
        </h2>
        <p className="text-muted-foreground">
          Intelligent suggestions and templates to expand your ritual ecosystem
        </p>
      </div>
      
      {/* AI Suggestions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-amber-500" />
            Smart Suggestions
          </CardTitle>
          <CardDescription>
            Based on gaps and patterns in your ritual system
          </CardDescription>
        </CardHeader>
        <CardContent>
          {suggestions.length > 0 ? (
            <ScrollArea className="h-[300px]">
              <div className="space-y-4">
                {suggestions.map((suggestion: AIRitualSuggestion) => (
                  <div
                    key={suggestion.id}
                    className="p-4 border rounded-lg space-y-2 hover:bg-accent/50 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-semibold flex items-center gap-2">
                          {suggestion.suggestedName}
                          <Badge variant="secondary">Priority: {suggestion.priority}</Badge>
                        </h4>
                        <div className="flex gap-2 mt-1">
                          <Badge>{suggestion.suggestedType}</Badge>
                          <Badge variant="outline">{suggestion.suggestedDomain}</Badge>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => handleUseSuggestion(suggestion)}
                      >
                        Use
                      </Button>
                    </div>
                    <p className="text-sm text-muted-foreground">{suggestion.rationale}</p>
                  </div>
                ))}
              </div>
            </ScrollArea>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <CheckCircle2 className="h-12 w-12 mx-auto mb-2 text-green-500" />
              <p>Your ritual ecosystem looks complete! No gaps detected.</p>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Ritual Templates */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-blue-500" />
            Ritual Archetypes
          </CardTitle>
          <CardDescription>
            Pre-built templates for common ritual patterns
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {archetypes.map((archetype) => (
              <button
                key={archetype.type}
                onClick={() => {
                  setSelectedArchetype(archetype.type);
                  setTemplateDialog(true);
                }}
                className="p-4 border rounded-lg hover:border-primary hover:bg-accent transition-all text-left space-y-2"
              >
                <div className="font-semibold">{archetype.label}</div>
                <div className="text-xs text-muted-foreground">{archetype.description}</div>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Improvement Suggestions */}
      {improvementSuggestions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-500" />
              Improvement Suggestions
            </CardTitle>
            <CardDescription>
              Ways to enhance existing rituals based on performance data
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {improvementSuggestions.map((item) => (
                <div key={item.ritual.id} className="border rounded-lg p-4 space-y-2">
                  <h4 className="font-semibold">{item.ritual.name}</h4>
                  <ul className="space-y-1">
                    {item.suggestions.map((suggestion: string, index: number) => (
                      <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                        <span className="text-amber-500 mt-1">•</span>
                        <span>{suggestion}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Grammar Validation Results */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5" />
            Grammar Validation
          </CardTitle>
          <CardDescription>
            Checking ritual structure and flow
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {rituals.filter((r: Ritual) => r.grammar).slice(0, 5).map((ritual: Ritual) => {
              const validation = validateRitualGrammar(ritual);
              return (
                <div
                  key={ritual.id}
                  className={`p-3 rounded-lg border-l-4 ${
                    validation.valid ? 'border-green-500' : 'border-red-500'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{ritual.name}</span>
                    <Badge variant={validation.valid ? 'default' : 'destructive'}>
                      {validation.valid ? 'Valid' : 'Issues'}
                    </Badge>
                  </div>
                  {!validation.valid && validation.errors.length > 0 && (
                    <ul className="mt-2 space-y-1">
                      {validation.errors.map((error: string, index: number) => (
                        <li key={index} className="text-sm text-red-600">
                          • {error}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
      
      {/* Template Dialog */}
      <Dialog open={templateDialog} onOpenChange={setTemplateDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Use {selectedArchetype} Template?</DialogTitle>
            <DialogDescription>
              This will create a new ritual based on the {selectedArchetype} archetype.
              You can customize it after creation.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={() => setTemplateDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (selectedArchetype) {
                  handleUseTemplate(selectedArchetype);
                  setTemplateDialog(false);
                }
              }}
            >
              Create Ritual
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
