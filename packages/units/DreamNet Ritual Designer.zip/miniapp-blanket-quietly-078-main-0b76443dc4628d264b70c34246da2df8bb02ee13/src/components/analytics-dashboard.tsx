'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import type { Ritual, RitualEventLog, Domain } from '@/types/ritual';
import {
  calculateRitualHealth,
  calculateCulturalVitality,
  identifyRitualGaps,
  calculateParticipationTrends,
} from '@/lib/ritual-analytics';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { TrendingUp, TrendingDown, Minus, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

interface AnalyticsDashboardProps {
  rituals: Ritual[];
  events: RitualEventLog[];
}

export function AnalyticsDashboard({ rituals, events }: AnalyticsDashboardProps): JSX.Element {
  const domains: Domain[] = ['culture', 'drops', 'ops', 'social', 'pickleball', 'agents', 'identity', 'world'];
  
  const vitalityScores = domains.map((domain: Domain) => 
    calculateCulturalVitality(domain, rituals, events)
  );
  
  const gaps = identifyRitualGaps(rituals, events);
  
  const healthMetrics = rituals
    .map((ritual: Ritual) => calculateRitualHealth(ritual, events))
    .sort((a, b) => b.vitality - a.vitality);
  
  const participationTrends = calculateParticipationTrends(events, 30);
  
  const trendIcon = (trend: 'up' | 'down' | 'stable' | 'growing' | 'declining' | 'dead'): JSX.Element => {
    switch (trend) {
      case 'up':
      case 'growing':
        return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'down':
      case 'declining':
        return <TrendingDown className="h-4 w-4 text-red-500" />;
      case 'dead':
        return <XCircle className="h-4 w-4 text-gray-400" />;
      default:
        return <Minus className="h-4 w-4 text-blue-500" />;
    }
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold mb-2">Ritual Health Analytics</h2>
        <p className="text-muted-foreground">
          Comprehensive insights into your ritual ecosystem
        </p>
      </div>
      
      {/* Cultural Vitality by Domain */}
      <Card>
        <CardHeader>
          <CardTitle>Cultural Vitality by Domain</CardTitle>
          <CardDescription>Activity level across all domains (0-100 score)</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {vitalityScores.map((vitality) => (
              <div key={vitality.domain} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-medium capitalize">{vitality.domain}</span>
                    {trendIcon(vitality.trend)}
                    <Badge variant="outline">
                      {vitality.activeRituals}/{vitality.totalRituals} active
                    </Badge>
                  </div>
                  <span className="text-sm font-mono">{vitality.score}/100</span>
                </div>
                <Progress value={vitality.score} className="h-2" />
                <p className="text-xs text-muted-foreground">
                  {vitality.recentEvents} events in last 90 days
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Ritual Health Status */}
      <Card>
        <CardHeader>
          <CardTitle>Individual Ritual Health</CardTitle>
          <CardDescription>Top rituals by vitality score</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {healthMetrics.slice(0, 10).map((metric) => (
              <div key={metric.ritualId} className="border-l-4 pl-4 py-2" style={{
                borderColor: metric.vitality >= 70 ? '#10b981' : metric.vitality >= 40 ? '#f59e0b' : '#ef4444'
              }}>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium">{metric.ritualName}</h4>
                      {trendIcon(metric.trend)}
                      <Badge variant="secondary" className="text-xs">
                        {metric.domain}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{metric.recommendedAction}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold">{metric.vitality}</div>
                    <div className="text-xs text-muted-foreground">vitality</div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4 text-xs">
                  <div>
                    <span className="text-muted-foreground">Performances:</span>{' '}
                    <span className="font-medium">{metric.totalPerformances}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Avg Participants:</span>{' '}
                    <span className="font-medium">{metric.avgParticipants.toFixed(1)}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Last:</span>{' '}
                    <span className="font-medium">
                      {metric.daysSinceLastPerformance}d ago
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Participation Trends */}
      {participationTrends.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Participation Trends (Last 30 Days)</CardTitle>
            <CardDescription>Daily ritual activity and participant count</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={participationTrends}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" fontSize={12} />
                <YAxis fontSize={12} />
                <Tooltip />
                <Line type="monotone" dataKey="count" stroke="#8b5cf6" name="Rituals" />
                <Line type="monotone" dataKey="participants" stroke="#ec4899" name="Participants" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}
      
      {/* Domain Activity Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Ritual Distribution by Domain</CardTitle>
          <CardDescription>Total rituals per domain</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={vitalityScores}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="domain" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="totalRituals" fill="#8b5cf6" name="Total Rituals" />
              <Bar dataKey="activeRituals" fill="#10b981" name="Active Rituals" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
      
      {/* Identified Gaps */}
      {gaps.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-500" />
              Identified Gaps
            </CardTitle>
            <CardDescription>Areas that need attention</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {gaps.map((gap: string, index: number) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="text-amber-500 mt-1">•</span>
                  <span className="text-sm">{gap}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
      
      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Rituals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{rituals.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Events</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{events.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Rituals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">
              {healthMetrics.filter((m) => m.trend !== 'dead').length}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Avg Vitality</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {healthMetrics.length > 0
                ? Math.round(healthMetrics.reduce((sum, m) => sum + m.vitality, 0) / healthMetrics.length)
                : 0}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
