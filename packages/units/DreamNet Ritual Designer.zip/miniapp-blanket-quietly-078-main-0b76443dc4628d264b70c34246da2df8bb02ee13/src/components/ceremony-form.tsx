'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import type { CeremonySequence, Ritual } from '@/types/ritual';
import { listRituals } from '@/lib/ritual-store';
import { X, Plus } from 'lucide-react';

interface CeremonyFormProps {
  ceremony?: CeremonySequence | null;
  onSave: (data: CeremonyFormData) => void;
  onCancel: () => void;
}

export interface CeremonyFormData {
  name: string;
  description: string;
  ritualIds: string[];
  symbolism: string[];
  recommendedTiming: string;
  tags: string[];
  notes: string;
}

export function CeremonyForm({ ceremony, onSave, onCancel }: CeremonyFormProps): JSX.Element {
  const [formData, setFormData] = useState<CeremonyFormData>({
    name: ceremony?.name || '',
    description: ceremony?.description || '',
    ritualIds: ceremony?.ritualIds || [],
    symbolism: ceremony?.symbolism || [''],
    recommendedTiming: ceremony?.recommendedTiming || '',
    tags: ceremony?.tags || [],
    notes: ceremony?.notes || '',
  });

  const [currentTag, setCurrentTag] = useState<string>('');
  const [availableRituals, setAvailableRituals] = useState<Ritual[]>([]);

  useEffect(() => {
    setAvailableRituals(listRituals());
  }, []);

  const updateArrayField = (
    field: keyof CeremonyFormData,
    index: number,
    value: string
  ): void => {
    const array = [...(formData[field] as string[])];
    array[index] = value;
    setFormData({ ...formData, [field]: array });
  };

  const addArrayField = (field: keyof CeremonyFormData): void => {
    setFormData({
      ...formData,
      [field]: [...(formData[field] as string[]), ''],
    });
  };

  const removeArrayField = (field: keyof CeremonyFormData, index: number): void => {
    const array = [...(formData[field] as string[])];
    array.splice(index, 1);
    if (array.length === 0 && field === 'symbolism') array.push('');
    setFormData({ ...formData, [field]: array });
  };

  const toggleRitual = (ritualId: string): void => {
    const index = formData.ritualIds.indexOf(ritualId);
    if (index > -1) {
      const newIds = [...formData.ritualIds];
      newIds.splice(index, 1);
      setFormData({ ...formData, ritualIds: newIds });
    } else {
      setFormData({
        ...formData,
        ritualIds: [...formData.ritualIds, ritualId],
      });
    }
  };

  const addTag = (): void => {
    if (currentTag.trim() && !formData.tags.includes(currentTag.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, currentTag.trim()],
      });
      setCurrentTag('');
    }
  };

  const removeTag = (tag: string): void => {
    setFormData({
      ...formData,
      tags: formData.tags.filter((t: string) => t !== tag),
    });
  };

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    const cleanedData = {
      ...formData,
      symbolism: formData.symbolism.filter((s: string) => s.trim()),
    };
    onSave(cleanedData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="name">Ceremony Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setFormData({ ...formData, name: e.target.value })
              }
              required
            />
          </div>

          <div>
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, description: e.target.value })
              }
              rows={3}
              required
            />
          </div>

          <div>
            <Label htmlFor="recommendedTiming">Recommended Timing *</Label>
            <Input
              id="recommendedTiming"
              value={formData.recommendedTiming}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setFormData({ ...formData, recommendedTiming: e.target.value })
              }
              placeholder="e.g., At dawn, End of week, Full moon"
              required
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Select Rituals *</CardTitle>
        </CardHeader>
        <CardContent>
          {availableRituals.length === 0 ? (
            <p className="text-muted-foreground text-sm">
              No rituals available. Create some rituals first.
            </p>
          ) : (
            <div className="space-y-2">
              {availableRituals.map((ritual: Ritual) => (
                <div
                  key={ritual.id}
                  className="flex items-start space-x-3 p-3 border rounded-lg"
                >
                  <Checkbox
                    id={ritual.id}
                    checked={formData.ritualIds.includes(ritual.id)}
                    onCheckedChange={() => toggleRitual(ritual.id)}
                  />
                  <div className="flex-1">
                    <label
                      htmlFor={ritual.id}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                    >
                      {ritual.name}
                    </label>
                    <p className="text-sm text-muted-foreground mt-1">
                      {ritual.description.slice(0, 100)}
                      {ritual.description.length > 100 ? '...' : ''}
                    </p>
                    <div className="flex gap-2 mt-2">
                      <span className="text-xs bg-secondary px-2 py-1 rounded">
                        {ritual.ritualType}
                      </span>
                      <span className="text-xs bg-secondary px-2 py-1 rounded">
                        {ritual.domain}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
          <p className="text-sm text-muted-foreground mt-3">
            Selected: {formData.ritualIds.length} ritual(s)
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Ceremonial Symbolism *</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {formData.symbolism.map((symbol: string, index: number) => (
            <div key={index} className="flex gap-2">
              <Input
                value={symbol}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  updateArrayField('symbolism', index, e.target.value)
                }
                placeholder={`Symbolic meaning ${index + 1}`}
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => removeArrayField('symbolism', index)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            onClick={() => addArrayField('symbolism')}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Symbolism
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Tags & Notes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="tagInput">Tags</Label>
            <div className="flex gap-2 mt-2">
              <Input
                id="tagInput"
                value={currentTag}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setCurrentTag(e.target.value)
                }
                onKeyPress={(e: React.KeyboardEvent<HTMLInputElement>) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addTag();
                  }
                }}
                placeholder="Add a tag"
              />
              <Button type="button" variant="outline" onClick={addTag}>
                Add
              </Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {formData.tags.map((tag: string) => (
                <div
                  key={tag}
                  className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm flex items-center gap-2"
                >
                  #{tag}
                  <button
                    type="button"
                    onClick={() => removeTag(tag)}
                    className="hover:text-destructive"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, notes: e.target.value })
              }
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-3 justify-end">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {ceremony ? 'Update Ceremony' : 'Create Ceremony'}
        </Button>
      </div>
    </form>
  );
}
