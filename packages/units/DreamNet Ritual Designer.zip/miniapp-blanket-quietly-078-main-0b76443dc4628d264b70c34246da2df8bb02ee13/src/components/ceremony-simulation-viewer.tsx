'use client'

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import type { CeremonySequence } from '@/types/ritual';
import {
  generateCeremonySimulation,
  validateCeremonyReadiness,
} from '@/lib/ritual-simulation';
import { Play, CheckCircle, AlertTriangle, Clock, Users, ListChecks, FileText } from 'lucide-react';
import { toast } from 'sonner';

interface CeremonySimulationViewerProps {
  ceremony: CeremonySequence;
  onClose?: () => void;
}

export function CeremonySimulationViewer({ ceremony, onClose }: CeremonySimulationViewerProps): JSX.Element {
  const [simulation] = useState(() => generateCeremonySimulation(ceremony));
  const [readiness] = useState(() => validateCeremonyReadiness(ceremony));
  
  const handleDownloadScript = (): void => {
    let script = `# ${ceremony.name} - Ceremony Script\n\n`;
    script += `**Description:** ${ceremony.description}\n\n`;
    script += `**Duration:** ${simulation.estimatedDuration}\n\n`;
    script += `**Total Steps:** ${simulation.totalSteps}\n\n`;
    
    script += `## Preparations\n\n`;
    simulation.preparations.forEach((prep: string, i: number) => {
      script += `${i + 1}. ${prep}\n`;
    });
    
    script += `\n## Ritual Sequence\n\n`;
    simulation.ritualSequence.forEach((ritual, i: number) => {
      script += `### ${i + 1}. ${ritual.ritualName}\n\n`;
      ritual.steps.forEach((step) => {
        script += `**Step ${step.stepNumber}:** ${step.title} (${step.duration})\n`;
      });
      script += '\n';
    });
    
    const blob = new Blob([script], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${ceremony.slug}-script.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast.success('Script downloaded');
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <Play className="h-8 w-8 text-purple-500" />
            Ceremony Dry Run
          </h2>
          <p className="text-muted-foreground">
            {ceremony.name}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleDownloadScript}>
            <FileText className="h-4 w-4 mr-2" />
            Download Script
          </Button>
          {onClose && (
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          )}
        </div>
      </div>
      
      {/* Readiness Check */}
      <Card className={`border-l-4 ${readiness.ready ? 'border-green-500' : 'border-amber-500'}`}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {readiness.ready ? (
              <CheckCircle className="h-5 w-5 text-green-500" />
            ) : (
              <AlertTriangle className="h-5 w-5 text-amber-500" />
            )}
            Readiness Check
          </CardTitle>
        </CardHeader>
        <CardContent>
          {readiness.ready ? (
            <p className="text-green-600 font-medium">✓ Ceremony is ready to perform</p>
          ) : (
            <div className="space-y-2">
              <p className="font-medium text-amber-600">Issues to resolve:</p>
              <ul className="space-y-1">
                {readiness.issues.map((issue: string, index: number) => (
                  <li key={index} className="text-sm">• {issue}</li>
                ))}
              </ul>
            </div>
          )}
          {readiness.warnings.length > 0 && (
            <div className="mt-4 space-y-2">
              <p className="font-medium text-muted-foreground">Warnings:</p>
              <ul className="space-y-1">
                {readiness.warnings.map((warning: string, index: number) => (
                  <li key={index} className="text-sm text-muted-foreground">⚠ {warning}</li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Overview */}
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Duration
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{simulation.estimatedDuration}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <ListChecks className="h-4 w-4" />
              Total Steps
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{simulation.totalSteps}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Users className="h-4 w-4" />
              Participants
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {simulation.participants.reduce((sum, p) => sum + p.count, 0)}
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Preparations */}
      <Card>
        <CardHeader>
          <CardTitle>Pre-Ceremony Preparations</CardTitle>
          <CardDescription>Complete these before the ceremony begins</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {simulation.preparations.map((prep: string, index: number) => (
              <li key={index} className="flex items-start gap-2">
                <CheckCircle className="h-4 w-4 mt-1 text-muted-foreground" />
                <span className="text-sm">{prep}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
      
      {/* Ritual Sequence */}
      <Card>
        <CardHeader>
          <CardTitle>Ritual Sequence</CardTitle>
          <CardDescription>Step-by-step walkthrough</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px]">
            <Accordion type="single" collapsible className="w-full">
              {simulation.ritualSequence.map((ritual, index: number) => (
                <AccordionItem key={ritual.ritualId} value={`ritual-${index}`}>
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline">{index + 1}</Badge>
                      <span className="font-semibold">{ritual.ritualName}</span>
                      <Badge variant="secondary">{ritual.steps.length} steps</Badge>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-3 pt-2">
                      {ritual.steps.map((step) => (
                        <div key={step.stepNumber} className="pl-4 border-l-2 border-muted">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant="outline" className="text-xs">
                              Step {step.stepNumber}
                            </Badge>
                            <Badge className="text-xs">{step.duration}</Badge>
                          </div>
                          <p className="text-sm font-medium">{step.title}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {step.description}
                          </p>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </ScrollArea>
        </CardContent>
      </Card>
      
      {/* Participant Roles */}
      <Card>
        <CardHeader>
          <CardTitle>Participant Structure</CardTitle>
          <CardDescription>Roles and responsibilities</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {simulation.participants.map((participant, index: number) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold">{participant.role}</h4>
                  <Badge>{participant.count} person{participant.count > 1 ? 's' : ''}</Badge>
                </div>
                <ul className="space-y-1">
                  {participant.responsibilities.map((resp: string, i: number) => (
                    <li key={i} className="text-sm text-muted-foreground">
                      • {resp}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Checklist */}
      <Card>
        <CardHeader>
          <CardTitle>Pre-Ceremony Checklist</CardTitle>
          <CardDescription>Verify all requirements are met</CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {simulation.checklist.map((category, index: number) => (
              <AccordionItem key={index} value={`checklist-${index}`}>
                <AccordionTrigger>{category.category}</AccordionTrigger>
                <AccordionContent>
                  <ul className="space-y-2">
                    {category.items.map((item: string, i: number) => (
                      <li key={i} className="flex items-center gap-2">
                        <input type="checkbox" className="rounded" />
                        <span className="text-sm">{item}</span>
                      </li>
                    ))}
                  </ul>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
}
