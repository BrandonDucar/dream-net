'use client'

import { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { Ritual, CeremonySequence, CycleDefinition, RitualEventLog, CalendarEvent, Domain } from '@/types/ritual';
import { generateCalendarEvents, getDomainColor, getEventsForDate } from '@/lib/ritual-calendar';
import { addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, format, isSameDay, startOfWeek, endOfWeek } from 'date-fns';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from 'lucide-react';

interface CultureCalendarProps {
  rituals: Ritual[];
  ceremonies: CeremonySequence[];
  cycles: CycleDefinition[];
  events: RitualEventLog[];
}

export function CultureCalendar({ rituals, ceremonies, cycles, events }: CultureCalendarProps): JSX.Element {
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [selectedDomain, setSelectedDomain] = useState<Domain | 'all'>('all');
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  
  const calendarEvents = useMemo(() => {
    const start = startOfMonth(currentDate);
    const end = endOfMonth(currentDate);
    const allEvents = generateCalendarEvents(rituals, ceremonies, cycles, events, start, end);
    
    if (selectedDomain === 'all') {
      return allEvents;
    }
    
    return allEvents.filter((e: CalendarEvent) => e.domain === selectedDomain);
  }, [currentDate, rituals, ceremonies, cycles, events, selectedDomain]);
  
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const calendarStart = startOfWeek(monthStart);
  const calendarEnd = endOfWeek(monthEnd);
  
  const days = eachDayOfInterval({ start: calendarStart, end: calendarEnd });
  
  const eventsForSelectedDate = selectedDate ? getEventsForDate(calendarEvents, selectedDate) : [];
  
  const getEventsForDay = (day: Date): CalendarEvent[] => {
    return getEventsForDate(calendarEvents, day);
  };
  
  const handlePrevMonth = (): void => {
    setCurrentDate(subMonths(currentDate, 1));
  };
  
  const handleNextMonth = (): void => {
    setCurrentDate(addMonths(currentDate, 1));
  };
  
  const handleToday = (): void => {
    setCurrentDate(new Date());
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold mb-2">Culture Calendar</h2>
        <p className="text-muted-foreground">
          Visual timeline of rituals, ceremonies, and cycles across DreamNet
        </p>
      </div>
      
      {/* Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="outline" size="icon" onClick={handlePrevMonth}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <h3 className="text-xl font-semibold min-w-[200px] text-center">
                {format(currentDate, 'MMMM yyyy')}
              </h3>
              <Button variant="outline" size="icon" onClick={handleNextMonth}>
                <ChevronRight className="h-4 w-4" />
              </Button>
              <Button variant="outline" onClick={handleToday}>
                Today
              </Button>
            </div>
            
            <Select value={selectedDomain} onValueChange={(value: string) => setSelectedDomain(value as Domain | 'all')}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by domain" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Domains</SelectItem>
                <SelectItem value="culture">Culture</SelectItem>
                <SelectItem value="drops">Drops</SelectItem>
                <SelectItem value="ops">Ops</SelectItem>
                <SelectItem value="social">Social</SelectItem>
                <SelectItem value="pickleball">Pickleball</SelectItem>
                <SelectItem value="agents">Agents</SelectItem>
                <SelectItem value="identity">Identity</SelectItem>
                <SelectItem value="world">World</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-2">
            {/* Day headers */}
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day: string) => (
              <div key={day} className="text-center font-semibold text-sm py-2">
                {day}
              </div>
            ))}
            
            {/* Calendar days */}
            {days.map((day: Date) => {
              const dayEvents = getEventsForDay(day);
              const isCurrentMonth = day.getMonth() === currentDate.getMonth();
              const isToday = isSameDay(day, new Date());
              const isSelected = selectedDate ? isSameDay(day, selectedDate) : false;
              
              return (
                <button
                  key={day.toISOString()}
                  onClick={() => setSelectedDate(day)}
                  className={`
                    min-h-[100px] p-2 border rounded-lg text-left hover:bg-accent transition-colors
                    ${!isCurrentMonth ? 'opacity-40' : ''}
                    ${isToday ? 'ring-2 ring-primary' : ''}
                    ${isSelected ? 'bg-accent' : ''}
                  `}
                >
                  <div className="font-semibold text-sm mb-1">
                    {format(day, 'd')}
                  </div>
                  <div className="space-y-1">
                    {dayEvents.slice(0, 3).map((event: CalendarEvent) => (
                      <div
                        key={event.id}
                        className="text-xs px-1 py-0.5 rounded truncate"
                        style={{
                          backgroundColor: event.color + '20',
                          borderLeft: `3px solid ${event.color}`,
                        }}
                      >
                        {event.title}
                      </div>
                    ))}
                    {dayEvents.length > 3 && (
                      <div className="text-xs text-muted-foreground">
                        +{dayEvents.length - 3} more
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>
      
      {/* Selected Date Details */}
      {selectedDate && eventsForSelectedDate.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CalendarIcon className="h-5 w-5" />
              {format(selectedDate, 'EEEE, MMMM d, yyyy')}
            </CardTitle>
            <CardDescription>{eventsForSelectedDate.length} events scheduled</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {eventsForSelectedDate.map((event: CalendarEvent) => (
                <div
                  key={event.id}
                  className="p-3 rounded-lg border-l-4"
                  style={{ borderColor: event.color }}
                >
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-semibold">{event.title}</h4>
                    <Badge variant="secondary">{event.type}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{event.description}</p>
                  <Badge style={{ backgroundColor: event.color + '20', color: event.color }}>
                    {event.domain}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Legend */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Event Types</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-purple-500" />
              <span className="text-sm">Ritual</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-pink-500" />
              <span className="text-sm">Ceremony</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-blue-500" />
              <span className="text-sm">Cycle Phase</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-amber-500" />
              <span className="text-sm">Anniversary</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
