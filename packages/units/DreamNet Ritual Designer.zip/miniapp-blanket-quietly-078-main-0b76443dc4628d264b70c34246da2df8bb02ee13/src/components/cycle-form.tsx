'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { CycleDefinition, Ritual } from '@/types/ritual';
import { listRituals } from '@/lib/ritual-store';
import { X, Plus } from 'lucide-react';

interface CycleFormProps {
  cycle?: CycleDefinition | null;
  onSave: (data: CycleFormData) => void;
  onCancel: () => void;
}

export interface CycleFormData {
  name: string;
  description: string;
  phases: string[];
  phaseLengthHints: string[];
  recommendedRitualIds: string[];
  tags: string[];
  notes: string;
}

export function CycleForm({ cycle, onSave, onCancel }: CycleFormProps): JSX.Element {
  const [formData, setFormData] = useState<CycleFormData>({
    name: cycle?.name || '',
    description: cycle?.description || '',
    phases: cycle?.phases || [''],
    phaseLengthHints: cycle?.phaseLengthHints || [''],
    recommendedRitualIds: cycle?.recommendedRitualIds || [],
    tags: cycle?.tags || [],
    notes: cycle?.notes || '',
  });

  const [currentTag, setCurrentTag] = useState<string>('');
  const [availableRituals, setAvailableRituals] = useState<Ritual[]>([]);

  useEffect(() => {
    setAvailableRituals(listRituals());
  }, []);

  const updatePhase = (index: number, value: string): void => {
    const phases = [...formData.phases];
    phases[index] = value;
    setFormData({ ...formData, phases });
  };

  const updatePhaseLength = (index: number, value: string): void => {
    const lengths = [...formData.phaseLengthHints];
    lengths[index] = value;
    setFormData({ ...formData, phaseLengthHints: lengths });
  };

  const updatePhaseRitual = (index: number, ritualId: string): void => {
    const rituals = [...formData.recommendedRitualIds];
    rituals[index] = ritualId;
    setFormData({ ...formData, recommendedRitualIds: rituals });
  };

  const addPhase = (): void => {
    setFormData({
      ...formData,
      phases: [...formData.phases, ''],
      phaseLengthHints: [...formData.phaseLengthHints, ''],
      recommendedRitualIds: [...formData.recommendedRitualIds, ''],
    });
  };

  const removePhase = (index: number): void => {
    const phases = [...formData.phases];
    const lengths = [...formData.phaseLengthHints];
    const rituals = [...formData.recommendedRitualIds];
    
    phases.splice(index, 1);
    lengths.splice(index, 1);
    rituals.splice(index, 1);
    
    if (phases.length === 0) {
      phases.push('');
      lengths.push('');
      rituals.push('');
    }
    
    setFormData({
      ...formData,
      phases,
      phaseLengthHints: lengths,
      recommendedRitualIds: rituals,
    });
  };

  const addTag = (): void => {
    if (currentTag.trim() && !formData.tags.includes(currentTag.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, currentTag.trim()],
      });
      setCurrentTag('');
    }
  };

  const removeTag = (tag: string): void => {
    setFormData({
      ...formData,
      tags: formData.tags.filter((t: string) => t !== tag),
    });
  };

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    const cleanedData = {
      ...formData,
      phases: formData.phases.filter((p: string) => p.trim()),
      phaseLengthHints: formData.phaseLengthHints.slice(
        0,
        formData.phases.filter((p: string) => p.trim()).length
      ),
      recommendedRitualIds: formData.recommendedRitualIds.slice(
        0,
        formData.phases.filter((p: string) => p.trim()).length
      ),
    };
    onSave(cleanedData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="name">Cycle Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setFormData({ ...formData, name: e.target.value })
              }
              required
            />
          </div>

          <div>
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, description: e.target.value })
              }
              rows={3}
              required
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Cycle Phases *</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {formData.phases.map((phase: string, index: number) => (
            <div key={index} className="border p-4 rounded-lg space-y-3">
              <div className="flex justify-between items-center">
                <h4 className="font-medium">Phase {index + 1}</h4>
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => removePhase(index)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              
              <div>
                <Label>Phase Name *</Label>
                <Input
                  value={phase}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    updatePhase(index, e.target.value)
                  }
                  placeholder="e.g., seed, grow, peak, decay, rest"
                />
              </div>

              <div>
                <Label>Duration Hint</Label>
                <Input
                  value={formData.phaseLengthHints[index] || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    updatePhaseLength(index, e.target.value)
                  }
                  placeholder="e.g., 1 day, 3 days, 1 week"
                />
              </div>

              <div>
                <Label>Recommended Ritual</Label>
                <Select
                  value={formData.recommendedRitualIds[index] || ''}
                  onValueChange={(value: string) => updatePhaseRitual(index, value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a ritual (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">None</SelectItem>
                    {availableRituals.map((ritual: Ritual) => (
                      <SelectItem key={ritual.id} value={ritual.id}>
                        {ritual.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          ))}
          
          <Button type="button" variant="outline" onClick={addPhase}>
            <Plus className="h-4 w-4 mr-2" />
            Add Phase
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Tags & Notes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="tagInput">Tags</Label>
            <div className="flex gap-2 mt-2">
              <Input
                id="tagInput"
                value={currentTag}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setCurrentTag(e.target.value)
                }
                onKeyPress={(e: React.KeyboardEvent<HTMLInputElement>) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addTag();
                  }
                }}
                placeholder="Add a tag"
              />
              <Button type="button" variant="outline" onClick={addTag}>
                Add
              </Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {formData.tags.map((tag: string) => (
                <div
                  key={tag}
                  className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm flex items-center gap-2"
                >
                  #{tag}
                  <button
                    type="button"
                    onClick={() => removeTag(tag)}
                    className="hover:text-destructive"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, notes: e.target.value })
              }
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-3 justify-end">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {cycle ? 'Update Cycle' : 'Create Cycle'}
        </Button>
      </div>
    </form>
  );
}
