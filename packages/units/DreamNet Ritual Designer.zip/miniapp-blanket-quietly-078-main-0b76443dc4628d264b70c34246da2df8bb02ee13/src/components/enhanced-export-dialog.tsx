'use client'

import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import type { Ritual, CeremonySequence, CycleDefinition, InitiationPath, SymbolicObject, RitualEventLog, CalendarEvent, ExportFormat } from '@/types/ritual';
import { exportByFormat, downloadFile } from '@/lib/ritual-exports';
import { FileJson, FileText, FileSpreadsheet, Calendar, FileCode } from 'lucide-react';
import { toast } from 'sonner';

interface EnhancedExportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  rituals: Ritual[];
  ceremonies: CeremonySequence[];
  cycles: CycleDefinition[];
  paths: InitiationPath[];
  objects: SymbolicObject[];
  events: RitualEventLog[];
  calendarEvents: CalendarEvent[];
}

export function EnhancedExportDialog({
  open,
  onOpenChange,
  rituals,
  ceremonies,
  cycles,
  paths,
  objects,
  events,
  calendarEvents,
}: EnhancedExportDialogProps): JSX.Element {
  const [selectedFormat, setSelectedFormat] = useState<ExportFormat>('json');
  const [isExporting, setIsExporting] = useState<boolean>(false);
  
  const formats: {
    value: ExportFormat;
    label: string;
    description: string;
    icon: JSX.Element;
  }[] = [
    {
      value: 'json',
      label: 'JSON',
      description: 'Complete data export with all fields',
      icon: <FileJson className="h-5 w-5 text-blue-500" />,
    },
    {
      value: 'markdown',
      label: 'Markdown',
      description: 'Beautiful formatted documentation',
      icon: <FileText className="h-5 w-5 text-purple-500" />,
    },
    {
      value: 'csv',
      label: 'CSV',
      description: 'Spreadsheet-friendly table format',
      icon: <FileSpreadsheet className="h-5 w-5 text-green-500" />,
    },
    {
      value: 'notion',
      label: 'Notion',
      description: 'Import-ready for Notion databases',
      icon: <FileCode className="h-5 w-5 text-amber-500" />,
    },
    {
      value: 'ics',
      label: 'Calendar (ICS)',
      description: 'Import into Google Calendar, Apple Calendar, etc.',
      icon: <Calendar className="h-5 w-5 text-pink-500" />,
    },
    {
      value: 'txt',
      label: 'Text',
      description: 'Simple plain text format',
      icon: <FileText className="h-5 w-5 text-gray-500" />,
    },
  ];
  
  const handleExport = (): void => {
    setIsExporting(true);
    
    try {
      const { content, filename, mimeType } = exportByFormat(
        selectedFormat,
        rituals,
        ceremonies,
        cycles,
        paths,
        objects,
        events,
        calendarEvents
      );
      
      downloadFile(content, filename, mimeType);
      toast.success(`Exported as ${filename}`);
      onOpenChange(false);
    } catch (error) {
      toast.error('Export failed');
      console.error('Export error:', error);
    } finally {
      setIsExporting(false);
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Export Ritual Codex</DialogTitle>
          <DialogDescription>
            Choose your export format. Each format is optimized for different use cases.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <RadioGroup value={selectedFormat} onValueChange={(value: string) => setSelectedFormat(value as ExportFormat)}>
            <div className="space-y-3">
              {formats.map((format) => (
                <label
                  key={format.value}
                  className={`
                    flex items-start gap-4 p-4 border rounded-lg cursor-pointer transition-all
                    hover:bg-accent
                    ${selectedFormat === format.value ? 'border-primary bg-accent' : ''}
                  `}
                >
                  <RadioGroupItem value={format.value} id={format.value} />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      {format.icon}
                      <span className="font-semibold">{format.label}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{format.description}</p>
                  </div>
                </label>
              ))}
            </div>
          </RadioGroup>
          
          <div className="flex items-center justify-between pt-4 border-t">
            <div className="text-sm text-muted-foreground">
              Exporting: {rituals.length} rituals, {ceremonies.length} ceremonies,{' '}
              {cycles.length} cycles, {paths.length} paths, {objects.length} objects
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button onClick={handleExport} disabled={isExporting}>
                {isExporting ? 'Exporting...' : 'Export'}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
