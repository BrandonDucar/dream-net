'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { RitualEventLog, Ritual } from '@/types/ritual';
import { listRituals } from '@/lib/ritual-store';
import { X, Plus } from 'lucide-react';

interface EventLogFormProps {
  event?: RitualEventLog | null;
  onSave: (data: EventLogFormData) => void;
  onCancel: () => void;
}

export interface EventLogFormData {
  ritualId: string;
  participants: string[];
  notes: string;
}

export function EventLogForm({ event, onSave, onCancel }: EventLogFormProps): JSX.Element {
  const [formData, setFormData] = useState<EventLogFormData>({
    ritualId: event?.ritualId || '',
    participants: event?.participants || [''],
    notes: event?.notes || '',
  });

  const [availableRituals, setAvailableRituals] = useState<Ritual[]>([]);

  useEffect(() => {
    setAvailableRituals(listRituals());
  }, []);

  const updateParticipant = (index: number, value: string): void => {
    const participants = [...formData.participants];
    participants[index] = value;
    setFormData({ ...formData, participants });
  };

  const addParticipant = (): void => {
    setFormData({
      ...formData,
      participants: [...formData.participants, ''],
    });
  };

  const removeParticipant = (index: number): void => {
    const participants = [...formData.participants];
    participants.splice(index, 1);
    if (participants.length === 0) participants.push('');
    setFormData({ ...formData, participants });
  };

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    const cleanedData = {
      ...formData,
      participants: formData.participants.filter((p: string) => p.trim()),
    };
    onSave(cleanedData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Event Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="ritualId">Ritual *</Label>
            <Select
              value={formData.ritualId}
              onValueChange={(value: string) =>
                setFormData({ ...formData, ritualId: value })
              }
            >
              <SelectTrigger id="ritualId">
                <SelectValue placeholder="Select a ritual" />
              </SelectTrigger>
              <SelectContent>
                {availableRituals.length === 0 ? (
                  <SelectItem value="none" disabled>
                    No rituals available
                  </SelectItem>
                ) : (
                  availableRituals.map((ritual: Ritual) => (
                    <SelectItem key={ritual.id} value={ritual.id}>
                      {ritual.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Participants</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {formData.participants.map((participant: string, index: number) => (
            <div key={index} className="flex gap-2">
              <Input
                value={participant}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  updateParticipant(index, e.target.value)
                }
                placeholder={`Participant ${index + 1}`}
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => removeParticipant(index)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            onClick={addParticipant}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Participant
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Notes</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            value={formData.notes}
            onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
              setFormData({ ...formData, notes: e.target.value })
            }
            rows={4}
            placeholder="Notes about this ritual event..."
          />
        </CardContent>
      </Card>

      <div className="flex gap-3 justify-end">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {event ? 'Update Event' : 'Record Event'}
        </Button>
      </div>
    </form>
  );
}
