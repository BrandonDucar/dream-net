'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { InitiationPath, Ritual } from '@/types/ritual';
import { listRituals } from '@/lib/ritual-store';
import { X, Plus } from 'lucide-react';

interface InitiationFormProps {
  path?: InitiationPath | null;
  onSave: (data: InitiationFormData) => void;
  onCancel: () => void;
}

export interface InitiationFormData {
  name: string;
  description: string;
  personaArchetypes: string[];
  milestones: string[];
  ritualIds: string[];
  symbolicRewards: string[];
  recommendedNextPaths: string[];
  tags: string[];
  notes: string;
}

export function InitiationForm({ path, onSave, onCancel }: InitiationFormProps): JSX.Element {
  const [formData, setFormData] = useState<InitiationFormData>({
    name: path?.name || '',
    description: path?.description || '',
    personaArchetypes: path?.personaArchetypes || [''],
    milestones: path?.milestones || [''],
    ritualIds: path?.ritualIds || [''],
    symbolicRewards: path?.symbolicRewards || [''],
    recommendedNextPaths: path?.recommendedNextPaths || [],
    tags: path?.tags || [],
    notes: path?.notes || '',
  });

  const [currentTag, setCurrentTag] = useState<string>('');
  const [availableRituals, setAvailableRituals] = useState<Ritual[]>([]);

  useEffect(() => {
    setAvailableRituals(listRituals());
  }, []);

  const updateArrayField = (
    field: keyof InitiationFormData,
    index: number,
    value: string
  ): void => {
    const array = [...(formData[field] as string[])];
    array[index] = value;
    setFormData({ ...formData, [field]: array });
  };

  const addArrayField = (field: keyof InitiationFormData): void => {
    setFormData({
      ...formData,
      [field]: [...(formData[field] as string[]), ''],
    });
  };

  const removeArrayField = (field: keyof InitiationFormData, index: number): void => {
    const array = [...(formData[field] as string[])];
    array.splice(index, 1);
    if (array.length === 0) array.push('');
    setFormData({ ...formData, [field]: array });
  };

  const updateMilestoneRitual = (index: number, ritualId: string): void => {
    const rituals = [...formData.ritualIds];
    rituals[index] = ritualId;
    setFormData({ ...formData, ritualIds: rituals });
  };

  const addMilestone = (): void => {
    setFormData({
      ...formData,
      milestones: [...formData.milestones, ''],
      ritualIds: [...formData.ritualIds, ''],
      symbolicRewards: [...formData.symbolicRewards, ''],
    });
  };

  const removeMilestone = (index: number): void => {
    const milestones = [...formData.milestones];
    const rituals = [...formData.ritualIds];
    const rewards = [...formData.symbolicRewards];
    
    milestones.splice(index, 1);
    rituals.splice(index, 1);
    rewards.splice(index, 1);
    
    if (milestones.length === 0) {
      milestones.push('');
      rituals.push('');
      rewards.push('');
    }
    
    setFormData({
      ...formData,
      milestones,
      ritualIds: rituals,
      symbolicRewards: rewards,
    });
  };

  const addTag = (): void => {
    if (currentTag.trim() && !formData.tags.includes(currentTag.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, currentTag.trim()],
      });
      setCurrentTag('');
    }
  };

  const removeTag = (tag: string): void => {
    setFormData({
      ...formData,
      tags: formData.tags.filter((t: string) => t !== tag),
    });
  };

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    const cleanedData = {
      ...formData,
      personaArchetypes: formData.personaArchetypes.filter((p: string) => p.trim()),
      milestones: formData.milestones.filter((m: string) => m.trim()),
      ritualIds: formData.ritualIds.slice(
        0,
        formData.milestones.filter((m: string) => m.trim()).length
      ),
      symbolicRewards: formData.symbolicRewards.slice(
        0,
        formData.milestones.filter((m: string) => m.trim()).length
      ),
      recommendedNextPaths: formData.recommendedNextPaths.filter((p: string) => p.trim()),
    };
    onSave(cleanedData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="name">Initiation Path Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setFormData({ ...formData, name: e.target.value })
              }
              required
            />
          </div>

          <div>
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, description: e.target.value })
              }
              rows={3}
              required
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Persona Archetypes *</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {formData.personaArchetypes.map((archetype: string, index: number) => (
            <div key={index} className="flex gap-2">
              <Input
                value={archetype}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  updateArrayField('personaArchetypes', index, e.target.value)
                }
                placeholder="e.g., Beginner, Contributor, Student, Player"
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => removeArrayField('personaArchetypes', index)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            onClick={() => addArrayField('personaArchetypes')}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Archetype
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Milestones & Rituals *</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {formData.milestones.map((milestone: string, index: number) => (
            <div key={index} className="border p-4 rounded-lg space-y-3">
              <div className="flex justify-between items-center">
                <h4 className="font-medium">Milestone {index + 1}</h4>
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => removeMilestone(index)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              
              <div>
                <Label>Milestone Description *</Label>
                <Input
                  value={milestone}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    updateArrayField('milestones', index, e.target.value)
                  }
                  placeholder="Describe this milestone"
                />
              </div>

              <div>
                <Label>Ritual to Unlock</Label>
                <Select
                  value={formData.ritualIds[index] || ''}
                  onValueChange={(value: string) => updateMilestoneRitual(index, value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a ritual (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">None</SelectItem>
                    {availableRituals.map((ritual: Ritual) => (
                      <SelectItem key={ritual.id} value={ritual.id}>
                        {ritual.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Symbolic Reward</Label>
                <Input
                  value={formData.symbolicRewards[index] || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    updateArrayField('symbolicRewards', index, e.target.value)
                  }
                  placeholder="What is earned upon completion?"
                />
              </div>
            </div>
          ))}
          
          <Button type="button" variant="outline" onClick={addMilestone}>
            <Plus className="h-4 w-4 mr-2" />
            Add Milestone
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recommended Next Paths</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {formData.recommendedNextPaths.map((nextPath: string, index: number) => (
            <div key={index} className="flex gap-2">
              <Input
                value={nextPath}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  updateArrayField('recommendedNextPaths', index, e.target.value)
                }
                placeholder="Next path name"
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => removeArrayField('recommendedNextPaths', index)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            onClick={() => addArrayField('recommendedNextPaths')}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Next Path
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Tags & Notes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="tagInput">Tags</Label>
            <div className="flex gap-2 mt-2">
              <Input
                id="tagInput"
                value={currentTag}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setCurrentTag(e.target.value)
                }
                onKeyPress={(e: React.KeyboardEvent<HTMLInputElement>) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addTag();
                  }
                }}
                placeholder="Add a tag"
              />
              <Button type="button" variant="outline" onClick={addTag}>
                Add
              </Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {formData.tags.map((tag: string) => (
                <div
                  key={tag}
                  className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm flex items-center gap-2"
                >
                  #{tag}
                  <button
                    type="button"
                    onClick={() => removeTag(tag)}
                    className="hover:text-destructive"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, notes: e.target.value })
              }
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-3 justify-end">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {path ? 'Update Path' : 'Create Path'}
        </Button>
      </div>
    </form>
  );
}
