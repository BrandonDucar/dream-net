'use client'

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { Ritual, CeremonySequence, InitiationPath, RitualEventLog, RitualNotification } from '@/types/ritual';
import {
  generateNotifications,
  dismissNotification,
  getNotificationsForToday,
} from '@/lib/ritual-notifications';
import { Bell, BellOff, Calendar, Trophy, TrendingUp, X } from 'lucide-react';

interface NotificationsPanelProps {
  rituals: Ritual[];
  ceremonies: CeremonySequence[];
  paths: InitiationPath[];
  events: RitualEventLog[];
}

export function NotificationsPanel({ rituals, ceremonies, paths, events }: NotificationsPanelProps): JSX.Element {
  const [notifications, setNotifications] = useState<RitualNotification[]>([]);
  const [showAll, setShowAll] = useState<boolean>(false);
  
  useEffect(() => {
    const allNotifications = generateNotifications(rituals, ceremonies, paths, events);
    setNotifications(allNotifications);
  }, [rituals, ceremonies, paths, events]);
  
  const handleDismiss = (id: string): void => {
    dismissNotification(id);
    setNotifications((prev: RitualNotification[]) => prev.filter((n: RitualNotification) => n.id !== id));
  };
  
  const todayNotifications = getNotificationsForToday();
  const displayNotifications = showAll ? notifications : todayNotifications;
  
  const getNotificationIcon = (type: RitualNotification['type']): JSX.Element => {
    switch (type) {
      case 'upcoming':
        return <Bell className="h-4 w-4 text-blue-500" />;
      case 'reminder':
        return <Calendar className="h-4 w-4 text-amber-500" />;
      case 'milestone':
        return <TrendingUp className="h-4 w-4 text-purple-500" />;
      case 'invitation':
        return <Bell className="h-4 w-4 text-pink-500" />;
      case 'anniversary':
        return <Trophy className="h-4 w-4 text-green-500" />;
      default:
        return <Bell className="h-4 w-4" />;
    }
  };
  
  const getPriorityColor = (priority: RitualNotification['priority']): string => {
    switch (priority) {
      case 'high':
        return 'border-red-500';
      case 'medium':
        return 'border-amber-500';
      case 'low':
        return 'border-blue-500';
      default:
        return 'border-gray-300';
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <Bell className="h-8 w-8 text-blue-500" />
            Ritual Notifications
          </h2>
          <p className="text-muted-foreground">
            Stay aligned with your ritual practice
          </p>
        </div>
        <Button
          variant={showAll ? 'default' : 'outline'}
          onClick={() => setShowAll(!showAll)}
        >
          {showAll ? 'Show Today' : 'Show All'}
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>{showAll ? 'All Notifications' : "Today's Notifications"}</span>
            <Badge variant="secondary">{displayNotifications.length}</Badge>
          </CardTitle>
          <CardDescription>
            {showAll
              ? 'All active notifications and reminders'
              : 'Rituals and events scheduled for today'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {displayNotifications.length > 0 ? (
            <ScrollArea className="h-[500px]">
              <div className="space-y-3">
                {displayNotifications.map((notification: RitualNotification) => (
                  <div
                    key={notification.id}
                    className={`p-4 rounded-lg border-l-4 ${getPriorityColor(notification.priority)} bg-accent/50`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3 flex-1">
                        <div className="mt-1">
                          {getNotificationIcon(notification.type)}
                        </div>
                        <div className="flex-1 space-y-2">
                          <p className="text-sm">{notification.message}</p>
                          <div className="flex gap-2">
                            <Badge variant="secondary" className="text-xs">
                              {notification.type}
                            </Badge>
                            <Badge
                              variant={
                                notification.priority === 'high'
                                  ? 'destructive'
                                  : notification.priority === 'medium'
                                  ? 'default'
                                  : 'outline'
                              }
                              className="text-xs"
                            >
                              {notification.priority}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => handleDismiss(notification.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <BellOff className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No notifications at this time.</p>
              <p className="text-sm mt-2">You're all caught up with your ritual practice!</p>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Bell className="h-4 w-4 text-red-500" />
              High Priority
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {notifications.filter((n: RitualNotification) => n.priority === 'high').length}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Calendar className="h-4 w-4 text-amber-500" />
              Medium Priority
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {notifications.filter((n: RitualNotification) => n.priority === 'medium').length}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Trophy className="h-4 w-4 text-blue-500" />
              Milestones
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {notifications.filter((n: RitualNotification) => n.type === 'milestone' || n.type === 'anniversary').length}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
