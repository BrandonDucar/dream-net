'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { Ritual, RitualType, Domain, Frequency } from '@/types/ritual';
import { X } from 'lucide-react';

interface RitualFormProps {
  ritual?: Ritual | null;
  onSave: (data: RitualFormData) => void;
  onCancel: () => void;
}

export interface RitualFormData {
  name: string;
  ritualType: RitualType;
  domain: Domain;
  description: string;
  steps: string[];
  purpose: string;
  symbolism: string[];
  frequency: Frequency;
  conditions: string[];
  relatedLore: string[];
  relatedObjects: string[];
  recommendedApps: string[];
  recommendedAgents: string[];
  tags: string[];
  notes: string;
}

export function RitualForm({ ritual, onSave, onCancel }: RitualFormProps): JSX.Element {
  const [formData, setFormData] = useState<RitualFormData>({
    name: ritual?.name || '',
    ritualType: ritual?.ritualType || 'ceremony',
    domain: ritual?.domain || 'culture',
    description: ritual?.description || '',
    steps: ritual?.steps || [''],
    purpose: ritual?.purpose || '',
    symbolism: ritual?.symbolism || [''],
    frequency: ritual?.frequency || 'weekly',
    conditions: ritual?.conditions || [''],
    relatedLore: ritual?.relatedLore || [],
    relatedObjects: ritual?.relatedObjects || [],
    recommendedApps: ritual?.recommendedApps || [],
    recommendedAgents: ritual?.recommendedAgents || [],
    tags: ritual?.tags || [],
    notes: ritual?.notes || '',
  });

  const [currentTag, setCurrentTag] = useState<string>('');

  const updateArrayField = (
    field: keyof RitualFormData,
    index: number,
    value: string
  ): void => {
    const array = [...(formData[field] as string[])];
    array[index] = value;
    setFormData({ ...formData, [field]: array });
  };

  const addArrayField = (field: keyof RitualFormData): void => {
    setFormData({
      ...formData,
      [field]: [...(formData[field] as string[]), ''],
    });
  };

  const removeArrayField = (field: keyof RitualFormData, index: number): void => {
    const array = [...(formData[field] as string[])];
    array.splice(index, 1);
    if (array.length === 0) array.push('');
    setFormData({ ...formData, [field]: array });
  };

  const addTag = (): void => {
    if (currentTag.trim() && !formData.tags.includes(currentTag.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, currentTag.trim()],
      });
      setCurrentTag('');
    }
  };

  const removeTag = (tag: string): void => {
    setFormData({
      ...formData,
      tags: formData.tags.filter((t: string) => t !== tag),
    });
  };

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    const cleanedData = {
      ...formData,
      steps: formData.steps.filter((s: string) => s.trim()),
      symbolism: formData.symbolism.filter((s: string) => s.trim()),
      conditions: formData.conditions.filter((c: string) => c.trim()),
      relatedLore: formData.relatedLore.filter((l: string) => l.trim()),
      relatedObjects: formData.relatedObjects.filter((o: string) => o.trim()),
      recommendedApps: formData.recommendedApps.filter((a: string) => a.trim()),
      recommendedAgents: formData.recommendedAgents.filter((a: string) => a.trim()),
    };
    onSave(cleanedData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="name">Ritual Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setFormData({ ...formData, name: e.target.value })
              }
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="ritualType">Type *</Label>
              <Select
                value={formData.ritualType}
                onValueChange={(value: RitualType) =>
                  setFormData({ ...formData, ritualType: value })
                }
              >
                <SelectTrigger id="ritualType">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ceremony">Ceremony</SelectItem>
                  <SelectItem value="practice">Practice</SelectItem>
                  <SelectItem value="signal">Signal</SelectItem>
                  <SelectItem value="celebration">Celebration</SelectItem>
                  <SelectItem value="transition">Transition</SelectItem>
                  <SelectItem value="reset">Reset</SelectItem>
                  <SelectItem value="initiation">Initiation</SelectItem>
                  <SelectItem value="completion">Completion</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="domain">Domain *</Label>
              <Select
                value={formData.domain}
                onValueChange={(value: Domain) =>
                  setFormData({ ...formData, domain: value })
                }
              >
                <SelectTrigger id="domain">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="culture">Culture</SelectItem>
                  <SelectItem value="drops">Drops</SelectItem>
                  <SelectItem value="ops">Ops</SelectItem>
                  <SelectItem value="social">Social</SelectItem>
                  <SelectItem value="pickleball">Pickleball</SelectItem>
                  <SelectItem value="agents">Agents</SelectItem>
                  <SelectItem value="identity">Identity</SelectItem>
                  <SelectItem value="world">World</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="frequency">Frequency *</Label>
              <Select
                value={formData.frequency}
                onValueChange={(value: Frequency) =>
                  setFormData({ ...formData, frequency: value })
                }
              >
                <SelectTrigger id="frequency">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="seasonal">Seasonal</SelectItem>
                  <SelectItem value="per-event">Per Event</SelectItem>
                  <SelectItem value="rare">Rare</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, description: e.target.value })
              }
              rows={3}
              required
            />
          </div>

          <div>
            <Label htmlFor="purpose">Purpose *</Label>
            <Textarea
              id="purpose"
              value={formData.purpose}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, purpose: e.target.value })
              }
              rows={2}
              required
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Ritual Steps *</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {formData.steps.map((step: string, index: number) => (
            <div key={index} className="flex gap-2">
              <Input
                value={step}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  updateArrayField('steps', index, e.target.value)
                }
                placeholder={`Step ${index + 1}`}
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => removeArrayField('steps', index)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            onClick={() => addArrayField('steps')}
          >
            Add Step
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Symbolism *</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {formData.symbolism.map((symbol: string, index: number) => (
            <div key={index} className="flex gap-2">
              <Input
                value={symbol}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  updateArrayField('symbolism', index, e.target.value)
                }
                placeholder={`Symbolic meaning ${index + 1}`}
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => removeArrayField('symbolism', index)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            onClick={() => addArrayField('symbolism')}
          >
            Add Symbolism
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Conditions for Practice *</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {formData.conditions.map((condition: string, index: number) => (
            <div key={index} className="flex gap-2">
              <Input
                value={condition}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  updateArrayField('conditions', index, e.target.value)
                }
                placeholder={`Condition ${index + 1}`}
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => removeArrayField('conditions', index)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            onClick={() => addArrayField('conditions')}
          >
            Add Condition
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Related Elements</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Related Lore</Label>
            <div className="space-y-2 mt-2">
              {formData.relatedLore.map((lore: string, index: number) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={lore}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      updateArrayField('relatedLore', index, e.target.value)
                    }
                    placeholder="Lore reference"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={() => removeArrayField('relatedLore', index)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => addArrayField('relatedLore')}
              >
                Add Lore
              </Button>
            </div>
          </div>

          <div>
            <Label>Related Objects</Label>
            <div className="space-y-2 mt-2">
              {formData.relatedObjects.map((obj: string, index: number) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={obj}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      updateArrayField('relatedObjects', index, e.target.value)
                    }
                    placeholder="Object name"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={() => removeArrayField('relatedObjects', index)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => addArrayField('relatedObjects')}
              >
                Add Object
              </Button>
            </div>
          </div>

          <div>
            <Label>Recommended Apps</Label>
            <div className="space-y-2 mt-2">
              {formData.recommendedApps.map((app: string, index: number) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={app}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      updateArrayField('recommendedApps', index, e.target.value)
                    }
                    placeholder="App name"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={() => removeArrayField('recommendedApps', index)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => addArrayField('recommendedApps')}
              >
                Add App
              </Button>
            </div>
          </div>

          <div>
            <Label>Recommended Agents</Label>
            <div className="space-y-2 mt-2">
              {formData.recommendedAgents.map((agent: string, index: number) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={agent}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      updateArrayField('recommendedAgents', index, e.target.value)
                    }
                    placeholder="Agent name"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={() => removeArrayField('recommendedAgents', index)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => addArrayField('recommendedAgents')}
              >
                Add Agent
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Tags & Notes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="tagInput">Tags</Label>
            <div className="flex gap-2 mt-2">
              <Input
                id="tagInput"
                value={currentTag}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setCurrentTag(e.target.value)
                }
                onKeyPress={(e: React.KeyboardEvent<HTMLInputElement>) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addTag();
                  }
                }}
                placeholder="Add a tag"
              />
              <Button type="button" variant="outline" onClick={addTag}>
                Add
              </Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {formData.tags.map((tag: string) => (
                <div
                  key={tag}
                  className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm flex items-center gap-2"
                >
                  #{tag}
                  <button
                    type="button"
                    onClick={() => removeTag(tag)}
                    className="hover:text-destructive"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, notes: e.target.value })
              }
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-3 justify-end">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {ritual ? 'Update Ritual' : 'Create Ritual'}
        </Button>
      </div>
    </form>
  );
}
