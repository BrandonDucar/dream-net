'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import type { SymbolicObject, Ritual, CycleDefinition } from '@/types/ritual';
import { listRituals, listCycles } from '@/lib/ritual-store';
import { X, Plus } from 'lucide-react';

interface SymbolicObjectFormProps {
  object?: SymbolicObject | null;
  onSave: (data: SymbolicObjectFormData) => void;
  onCancel: () => void;
}

export interface SymbolicObjectFormData {
  name: string;
  description: string;
  meaning: string[];
  usedInRitualIds: string[];
  usedInCycleIds: string[];
  tags: string[];
  notes: string;
}

export function SymbolicObjectForm({ object, onSave, onCancel }: SymbolicObjectFormProps): JSX.Element {
  const [formData, setFormData] = useState<SymbolicObjectFormData>({
    name: object?.name || '',
    description: object?.description || '',
    meaning: object?.meaning || [''],
    usedInRitualIds: object?.usedInRitualIds || [],
    usedInCycleIds: object?.usedInCycleIds || [],
    tags: object?.tags || [],
    notes: object?.notes || '',
  });

  const [currentTag, setCurrentTag] = useState<string>('');
  const [availableRituals, setAvailableRituals] = useState<Ritual[]>([]);
  const [availableCycles, setAvailableCycles] = useState<CycleDefinition[]>([]);

  useEffect(() => {
    setAvailableRituals(listRituals());
    setAvailableCycles(listCycles());
  }, []);

  const updateArrayField = (
    field: keyof SymbolicObjectFormData,
    index: number,
    value: string
  ): void => {
    const array = [...(formData[field] as string[])];
    array[index] = value;
    setFormData({ ...formData, [field]: array });
  };

  const addArrayField = (field: keyof SymbolicObjectFormData): void => {
    setFormData({
      ...formData,
      [field]: [...(formData[field] as string[]), ''],
    });
  };

  const removeArrayField = (field: keyof SymbolicObjectFormData, index: number): void => {
    const array = [...(formData[field] as string[])];
    array.splice(index, 1);
    if (array.length === 0 && field === 'meaning') array.push('');
    setFormData({ ...formData, [field]: array });
  };

  const toggleRitual = (ritualId: string): void => {
    const index = formData.usedInRitualIds.indexOf(ritualId);
    if (index > -1) {
      const newIds = [...formData.usedInRitualIds];
      newIds.splice(index, 1);
      setFormData({ ...formData, usedInRitualIds: newIds });
    } else {
      setFormData({
        ...formData,
        usedInRitualIds: [...formData.usedInRitualIds, ritualId],
      });
    }
  };

  const toggleCycle = (cycleId: string): void => {
    const index = formData.usedInCycleIds.indexOf(cycleId);
    if (index > -1) {
      const newIds = [...formData.usedInCycleIds];
      newIds.splice(index, 1);
      setFormData({ ...formData, usedInCycleIds: newIds });
    } else {
      setFormData({
        ...formData,
        usedInCycleIds: [...formData.usedInCycleIds, cycleId],
      });
    }
  };

  const addTag = (): void => {
    if (currentTag.trim() && !formData.tags.includes(currentTag.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, currentTag.trim()],
      });
      setCurrentTag('');
    }
  };

  const removeTag = (tag: string): void => {
    setFormData({
      ...formData,
      tags: formData.tags.filter((t: string) => t !== tag),
    });
  };

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    const cleanedData = {
      ...formData,
      meaning: formData.meaning.filter((m: string) => m.trim()),
    };
    onSave(cleanedData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="name">Object Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setFormData({ ...formData, name: e.target.value })
              }
              placeholder="e.g., The Dream Tree, The Snail Shell"
              required
            />
          </div>

          <div>
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, description: e.target.value })
              }
              rows={3}
              required
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Symbolic Meaning *</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {formData.meaning.map((meaning: string, index: number) => (
            <div key={index} className="flex gap-2">
              <Input
                value={meaning}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  updateArrayField('meaning', index, e.target.value)
                }
                placeholder={`Meaning ${index + 1}`}
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => removeArrayField('meaning', index)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            onClick={() => addArrayField('meaning')}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Meaning
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Used in Rituals</CardTitle>
        </CardHeader>
        <CardContent>
          {availableRituals.length === 0 ? (
            <p className="text-muted-foreground text-sm">
              No rituals available.
            </p>
          ) : (
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {availableRituals.map((ritual: Ritual) => (
                <div key={ritual.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={`ritual-${ritual.id}`}
                    checked={formData.usedInRitualIds.includes(ritual.id)}
                    onCheckedChange={() => toggleRitual(ritual.id)}
                  />
                  <label
                    htmlFor={`ritual-${ritual.id}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                  >
                    {ritual.name}
                  </label>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Used in Cycles</CardTitle>
        </CardHeader>
        <CardContent>
          {availableCycles.length === 0 ? (
            <p className="text-muted-foreground text-sm">
              No cycles available.
            </p>
          ) : (
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {availableCycles.map((cycle: CycleDefinition) => (
                <div key={cycle.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={`cycle-${cycle.id}`}
                    checked={formData.usedInCycleIds.includes(cycle.id)}
                    onCheckedChange={() => toggleCycle(cycle.id)}
                  />
                  <label
                    htmlFor={`cycle-${cycle.id}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                  >
                    {cycle.name}
                  </label>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Tags & Notes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="tagInput">Tags</Label>
            <div className="flex gap-2 mt-2">
              <Input
                id="tagInput"
                value={currentTag}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setCurrentTag(e.target.value)
                }
                onKeyPress={(e: React.KeyboardEvent<HTMLInputElement>) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addTag();
                  }
                }}
                placeholder="Add a tag"
              />
              <Button type="button" variant="outline" onClick={addTag}>
                Add
              </Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {formData.tags.map((tag: string) => (
                <div
                  key={tag}
                  className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm flex items-center gap-2"
                >
                  #{tag}
                  <button
                    type="button"
                    onClick={() => removeTag(tag)}
                    className="hover:text-destructive"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, notes: e.target.value })
              }
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-3 justify-end">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {object ? 'Update Object' : 'Create Object'}
        </Button>
      </div>
    </form>
  );
}
