// Enhancement #10: AI Ritual Designer

import type {
  Ritual,
  RitualEventLog,
  AIRitualSuggestion,
  Domain,
  RitualType,
  RitualArchetype,
  RitualBlock,
} from '@/types/ritual';

export function generateRitualSuggestions(
  rituals: Ritual[],
  events: RitualEventLog[]
): AIRitualSuggestion[] {
  const suggestions: AIRitualSuggestion[] = [];
  
  // Analyze gaps and suggest rituals to fill them
  const domainGaps = analyzeDomainGaps(rituals);
  const frequencyGaps = analyzeFrequencyGaps(rituals);
  const typeGaps = analyzeTypeGaps(rituals);
  
  // Generate suggestions for domain gaps
  domainGaps.forEach((domain: Domain, index: number) => {
    suggestions.push({
      id: `suggestion-domain-${domain}-${Date.now()}-${index}`,
      suggestedName: `${domain.charAt(0).toUpperCase() + domain.slice(1)} Foundation Ritual`,
      suggestedType: 'practice',
      suggestedDomain: domain,
      rationale: `No rituals exist for ${domain} domain. This foundational ritual would establish core practices.`,
      priority: 10,
      basedOn: ['domain-gap-analysis'],
    });
  });
  
  // Generate suggestions for frequency gaps
  if (!rituals.some((r: Ritual) => r.frequency === 'daily')) {
    suggestions.push({
      id: `suggestion-daily-${Date.now()}`,
      suggestedName: 'Daily Alignment Check',
      suggestedType: 'practice',
      suggestedDomain: 'culture',
      rationale: 'No daily rituals exist. Daily practices help maintain cultural momentum.',
      priority: 8,
      basedOn: ['frequency-gap-analysis'],
    });
  }
  
  // Generate suggestions for underperforming rituals
  const inactiveRituals = rituals.filter((r: Ritual) => {
    const ritualEvents = events.filter((e: RitualEventLog) => e.ritualId === r.id);
    return ritualEvents.length === 0;
  });
  
  if (inactiveRituals.length > 0) {
    suggestions.push({
      id: `suggestion-revival-${Date.now()}`,
      suggestedName: 'Ritual Revival Ceremony',
      suggestedType: 'celebration',
      suggestedDomain: 'culture',
      rationale: `${inactiveRituals.length} rituals have never been performed. A revival ceremony could bring them to life.`,
      priority: 7,
      basedOn: inactiveRituals.map((r: Ritual) => r.id),
    });
  }
  
  // Generate suggestions for complementary rituals
  const celebrationRituals = rituals.filter((r: Ritual) => r.ritualType === 'celebration');
  const transitionRituals = rituals.filter((r: Ritual) => r.ritualType === 'transition');
  
  if (celebrationRituals.length > 0 && transitionRituals.length === 0) {
    suggestions.push({
      id: `suggestion-transition-${Date.now()}`,
      suggestedName: 'Phase Transition Ceremony',
      suggestedType: 'transition',
      suggestedDomain: 'culture',
      rationale: 'You have celebrations but no transition rituals. Transitions help mark important moments of change.',
      priority: 6,
      basedOn: celebrationRituals.map((r: Ritual) => r.id),
    });
  }
  
  // Sort by priority
  return suggestions.sort((a, b) => b.priority - a.priority);
}

function analyzeDomainGaps(rituals: Ritual[]): Domain[] {
  const domains: Domain[] = ['culture', 'drops', 'ops', 'social', 'pickleball', 'agents', 'identity', 'world'];
  const gaps: Domain[] = [];
  
  domains.forEach((domain: Domain) => {
    const domainRituals = rituals.filter((r: Ritual) => r.domain === domain);
    if (domainRituals.length === 0) {
      gaps.push(domain);
    }
  });
  
  return gaps;
}

function analyzeFrequencyGaps(rituals: Ritual[]): string[] {
  const gaps: string[] = [];
  
  if (!rituals.some((r: Ritual) => r.frequency === 'daily')) gaps.push('daily');
  if (!rituals.some((r: Ritual) => r.frequency === 'weekly')) gaps.push('weekly');
  if (!rituals.some((r: Ritual) => r.frequency === 'monthly')) gaps.push('monthly');
  
  return gaps;
}

function analyzeTypeGaps(rituals: Ritual[]): RitualType[] {
  const types: RitualType[] = [
    'ceremony',
    'practice',
    'signal',
    'celebration',
    'transition',
    'reset',
    'initiation',
    'completion',
  ];
  const gaps: RitualType[] = [];
  
  types.forEach((type: RitualType) => {
    if (!rituals.some((r: Ritual) => r.ritualType === type)) {
      gaps.push(type);
    }
  });
  
  return gaps;
}

export function generateRitualTemplate(
  archetype: RitualArchetype,
  domain: Domain
): Partial<Ritual> {
  const templates: Record<RitualArchetype, {
    blocks: RitualBlock[];
    steps: string[];
    symbolism: string[];
    purpose: string;
  }> = {
    blessing: {
      blocks: ['opening', 'invocation', 'witness', 'closing'],
      steps: [
        'Gather participants in circle',
        'State intention for blessing',
        'Each person shares a hope or wish',
        'Collective affirmation',
        'Close with gratitude',
      ],
      symbolism: ['Circle of unity', 'Shared intention', 'Collective power'],
      purpose: 'To bestow positive energy and support',
    },
    challenge: {
      blocks: ['opening', 'invocation', 'transformation', 'witness', 'closing'],
      steps: [
        'Set the challenge parameters',
        'Participants declare commitment',
        'Undertake the challenge',
        'Share experiences',
        'Acknowledge growth',
      ],
      symbolism: ['Trial by fire', 'Growth through difficulty', 'Earned wisdom'],
      purpose: 'To test and strengthen capabilities',
    },
    transition: {
      blocks: ['opening', 'release', 'transformation', 'witness', 'closing'],
      steps: [
        'Acknowledge what is ending',
        'Release old patterns',
        'Cross the threshold',
        'Welcome new state',
        'Integrate change',
      ],
      symbolism: ['Death and rebirth', 'Threshold crossing', 'Metamorphosis'],
      purpose: 'To mark and facilitate significant change',
    },
    celebration: {
      blocks: ['opening', 'witness', 'exchange', 'closing'],
      steps: [
        'Gather in festive spirit',
        'Recount achievements',
        'Share joy and gratitude',
        'Dance/play/celebrate',
        'Close with reflection',
      ],
      symbolism: ['Joy', 'Achievement', 'Collective pride'],
      purpose: 'To honor accomplishments and create positive momentum',
    },
    mourning: {
      blocks: ['opening', 'witness', 'release', 'closing'],
      steps: [
        'Create sacred space',
        'Share what was lost',
        'Express grief together',
        'Release attachment',
        'Honor memory and move forward',
      ],
      symbolism: ['Loss', 'Grief', 'Healing', 'Continuity'],
      purpose: 'To process loss and find closure',
    },
    invocation: {
      blocks: ['opening', 'invocation', 'witness', 'closing'],
      steps: [
        'Prepare the space',
        'Call upon higher powers/energies',
        'State what is needed',
        'Listen for response',
        'Give thanks',
      ],
      symbolism: ['Connection to greater forces', 'Asking for help', 'Humility'],
      purpose: 'To call upon wisdom, energy, or assistance',
    },
    release: {
      blocks: ['opening', 'release', 'witness', 'closing'],
      steps: [
        'Identify what must be released',
        'Symbolically let go (burn, bury, etc.)',
        'Witness the release',
        'Clear the space',
        'Move forward unburdened',
      ],
      symbolism: ['Letting go', 'Cleansing', 'Freedom'],
      purpose: 'To consciously release what no longer serves',
    },
    transformation: {
      blocks: ['opening', 'invocation', 'transformation', 'witness', 'closing'],
      steps: [
        'Define current state',
        'State intention for transformation',
        'Undergo symbolic transformation',
        'Emerge in new form',
        'Integrate new identity',
      ],
      symbolism: ['Alchemy', 'Becoming', 'Evolution'],
      purpose: 'To facilitate deep personal or collective change',
    },
  };
  
  const template = templates[archetype];
  
  return {
    ritualType: archetypeToType(archetype),
    domain,
    steps: template.steps,
    symbolism: template.symbolism,
    purpose: template.purpose,
    grammar: {
      archetype,
      blocks: template.blocks,
      allowedDomainMix: false,
    },
  };
}

function archetypeToType(archetype: RitualArchetype): RitualType {
  const mapping: Record<RitualArchetype, RitualType> = {
    blessing: 'ceremony',
    challenge: 'practice',
    transition: 'transition',
    celebration: 'celebration',
    mourning: 'ceremony',
    invocation: 'practice',
    release: 'reset',
    transformation: 'transition',
  };
  
  return mapping[archetype];
}

export function validateRitualGrammar(ritual: Ritual): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (!ritual.grammar) {
    return { valid: true, errors: [] }; // Optional field
  }
  
  // Check if blocks are in valid order
  const validSequences: Record<string, string[]> = {
    opening: ['invocation', 'exchange', 'transformation', 'witness', 'release'],
    invocation: ['exchange', 'transformation', 'witness', 'release', 'closing'],
    exchange: ['transformation', 'witness', 'closing'],
    transformation: ['witness', 'closing'],
    witness: ['release', 'closing'],
    release: ['closing'],
  };
  
  for (let i = 0; i < ritual.grammar.blocks.length - 1; i++) {
    const current = ritual.grammar.blocks[i];
    const next = ritual.grammar.blocks[i + 1];
    
    if (validSequences[current] && !validSequences[current].includes(next)) {
      errors.push(`Invalid sequence: ${current} → ${next}`);
    }
  }
  
  // Must start with opening and end with closing
  if (ritual.grammar.blocks[0] !== 'opening') {
    errors.push('Ritual must begin with opening block');
  }
  
  if (ritual.grammar.blocks[ritual.grammar.blocks.length - 1] !== 'closing') {
    errors.push('Ritual must end with closing block');
  }
  
  return { valid: errors.length === 0, errors };
}

export function improveRitualBasedOnFeedback(
  ritual: Ritual,
  events: RitualEventLog[]
): string[] {
  const suggestions: string[] = [];
  
  const ritualEvents = events.filter((e: RitualEventLog) => e.ritualId === ritual.id);
  
  if (ritualEvents.length === 0) {
    suggestions.push('This ritual has never been performed. Consider scheduling a first performance.');
    return suggestions;
  }
  
  // Analyze sentiment
  const avgSentiment = ritualEvents
    .filter((e: RitualEventLog) => e.sentiment)
    .reduce((sum: number, e: RitualEventLog) => sum + (e.sentiment || 0), 0) / 
    ritualEvents.filter((e: RitualEventLog) => e.sentiment).length;
  
  if (avgSentiment < 3) {
    suggestions.push('Sentiment is low. Consider revising steps or adding more engaging elements.');
  }
  
  // Analyze participation
  const avgParticipants = ritualEvents.reduce((sum: number, e: RitualEventLog) => sum + e.participants.length, 0) / ritualEvents.length;
  
  if (avgParticipants < 2) {
    suggestions.push('Low participation. Consider making this a group activity or promoting it more.');
  }
  
  // Analyze duration
  const withDuration = ritualEvents.filter((e: RitualEventLog) => e.duration);
  if (withDuration.length > 0) {
    suggestions.push('Duration data available. Use this to optimize timing.');
  }
  
  return suggestions;
}
