// Enhancement #4: Ritual Health Analytics

import type {
  Ritual,
  RitualEventLog,
  RitualHealthMetrics,
  CulturalVitalityScore,
  Domain,
  Frequency,
} from '@/types/ritual';

export function calculateRitualHealth(
  ritual: Ritual,
  events: RitualEventLog[]
): RitualHealthMetrics {
  const ritualEvents = events.filter((e: RitualEventLog) => e.ritualId === ritual.id);
  
  const lastEvent = ritualEvents[0]; // Already sorted by timestamp desc
  const lastPerformed = lastEvent ? lastEvent.timestamp : null;
  
  const daysSince = lastPerformed
    ? Math.floor((Date.now() - new Date(lastPerformed).getTime()) / (1000 * 60 * 60 * 24))
    : 999;
  
  const totalPerformances = ritualEvents.length;
  
  const avgParticipants = ritualEvents.length > 0
    ? ritualEvents.reduce((sum: number, e: RitualEventLog) => sum + e.participants.length, 0) / ritualEvents.length
    : 0;
  
  const avgSentiment = ritualEvents.length > 0
    ? ritualEvents
        .filter((e: RitualEventLog) => e.sentiment !== undefined)
        .reduce((sum: number, e: RitualEventLog) => sum + (e.sentiment || 0), 0) / 
        ritualEvents.filter((e: RitualEventLog) => e.sentiment !== undefined).length
    : 0;
  
  // Calculate vitality score (0-100)
  let vitality = 0;
  
  // Recent activity (40 points)
  if (daysSince <= 7) vitality += 40;
  else if (daysSince <= 30) vitality += 30;
  else if (daysSince <= 90) vitality += 15;
  else if (daysSince <= 180) vitality += 5;
  
  // Total performances (30 points)
  if (totalPerformances >= 20) vitality += 30;
  else if (totalPerformances >= 10) vitality += 20;
  else if (totalPerformances >= 5) vitality += 10;
  else if (totalPerformances >= 1) vitality += 5;
  
  // Participation (15 points)
  if (avgParticipants >= 10) vitality += 15;
  else if (avgParticipants >= 5) vitality += 10;
  else if (avgParticipants >= 2) vitality += 5;
  
  // Sentiment (15 points)
  if (avgSentiment >= 4.5) vitality += 15;
  else if (avgSentiment >= 4) vitality += 10;
  else if (avgSentiment >= 3) vitality += 5;
  
  // Determine trend
  let trend: 'growing' | 'stable' | 'declining' | 'dead' = 'dead';
  
  if (ritualEvents.length >= 2) {
    const recentEvents = ritualEvents.slice(0, 3);
    const olderEvents = ritualEvents.slice(3, 6);
    
    const recentAvg = recentEvents.length > 0
      ? recentEvents.reduce((sum: number, e: RitualEventLog) => sum + e.participants.length, 0) / recentEvents.length
      : 0;
    
    const olderAvg = olderEvents.length > 0
      ? olderEvents.reduce((sum: number, e: RitualEventLog) => sum + e.participants.length, 0) / olderEvents.length
      : 0;
    
    if (daysSince > 180) trend = 'dead';
    else if (recentAvg > olderAvg * 1.2) trend = 'growing';
    else if (recentAvg < olderAvg * 0.8) trend = 'declining';
    else trend = 'stable';
  } else if (totalPerformances > 0 && daysSince <= 30) {
    trend = 'stable';
  }
  
  // Recommended action
  let recommendedAction = '';
  if (trend === 'dead') {
    recommendedAction = '💀 Consider archiving or reviving this ritual';
  } else if (trend === 'declining') {
    recommendedAction = '⚠️ Schedule a performance soon to maintain momentum';
  } else if (trend === 'stable') {
    recommendedAction = '✅ Maintain current frequency';
  } else if (trend === 'growing') {
    recommendedAction = '🚀 Consider increasing frequency or forking variations';
  }
  
  return {
    ritualId: ritual.id,
    ritualName: ritual.name,
    domain: ritual.domain,
    vitality,
    trend,
    lastPerformed,
    daysSinceLastPerformance: daysSince,
    totalPerformances,
    avgParticipants,
    avgSentiment,
    frequency: ritual.frequency,
    recommendedAction,
  };
}

export function calculateCulturalVitality(
  domain: Domain,
  rituals: Ritual[],
  events: RitualEventLog[]
): CulturalVitalityScore {
  const domainRituals = rituals.filter((r: Ritual) => r.domain === domain);
  const totalRituals = domainRituals.length;
  
  if (totalRituals === 0) {
    return {
      domain,
      score: 0,
      activeRituals: 0,
      totalRituals: 0,
      recentEvents: 0,
      trend: 'stable',
    };
  }
  
  // Count rituals performed in last 90 days
  const ninetyDaysAgo = new Date();
  ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
  
  const recentEvents = events.filter((e: RitualEventLog) => {
    const ritual = domainRituals.find((r: Ritual) => r.id === e.ritualId);
    return ritual && new Date(e.timestamp) >= ninetyDaysAgo;
  });
  
  const activeRitualIds = new Set(recentEvents.map((e: RitualEventLog) => e.ritualId));
  const activeRituals = activeRitualIds.size;
  
  // Calculate score (0-100)
  const activityRatio = activeRituals / totalRituals;
  const eventsPerRitual = recentEvents.length / totalRituals;
  
  let score = 0;
  score += activityRatio * 50; // 50 points for having active rituals
  score += Math.min(eventsPerRitual * 10, 50); // Up to 50 points for event frequency
  
  // Determine trend by comparing last 30 days vs previous 30 days
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  
  const sixtyDaysAgo = new Date();
  sixtyDaysAgo.setDate(sixtyDaysAgo.getDate() - 60);
  
  const recent30 = events.filter((e: RitualEventLog) => {
    const ritual = domainRituals.find((r: Ritual) => r.id === e.ritualId);
    return ritual && new Date(e.timestamp) >= thirtyDaysAgo;
  }).length;
  
  const previous30 = events.filter((e: RitualEventLog) => {
    const ritual = domainRituals.find((r: Ritual) => r.id === e.ritualId);
    const timestamp = new Date(e.timestamp);
    return ritual && timestamp >= sixtyDaysAgo && timestamp < thirtyDaysAgo;
  }).length;
  
  let trend: 'up' | 'down' | 'stable' = 'stable';
  if (recent30 > previous30 * 1.2) trend = 'up';
  else if (recent30 < previous30 * 0.8) trend = 'down';
  
  return {
    domain,
    score: Math.round(score),
    activeRituals,
    totalRituals,
    recentEvents: recentEvents.length,
    trend,
  };
}

export function identifyRitualGaps(
  rituals: Ritual[],
  events: RitualEventLog[]
): string[] {
  const gaps: string[] = [];
  
  // Check each domain for activity
  const domains: Domain[] = ['culture', 'drops', 'ops', 'social', 'pickleball', 'agents', 'identity', 'world'];
  
  for (const domain of domains) {
    const domainRituals = rituals.filter((r: Ritual) => r.domain === domain);
    
    if (domainRituals.length === 0) {
      gaps.push(`No rituals defined for ${domain} domain`);
    } else {
      const recentEvents = events.filter((e: RitualEventLog) => {
        const ritual = domainRituals.find((r: Ritual) => r.id === e.ritualId);
        const daysSince = Math.floor((Date.now() - new Date(e.timestamp).getTime()) / (1000 * 60 * 60 * 24));
        return ritual && daysSince <= 90;
      });
      
      if (recentEvents.length === 0) {
        gaps.push(`${domain} domain has no ritual activity in last 90 days`);
      }
    }
  }
  
  // Check for missing ritual types
  const frequencies: Frequency[] = ['daily', 'weekly', 'monthly'];
  for (const freq of frequencies) {
    const hasFreq = rituals.some((r: Ritual) => r.frequency === freq);
    if (!hasFreq) {
      gaps.push(`No ${freq} rituals defined`);
    }
  }
  
  return gaps;
}

export function calculateParticipationTrends(
  events: RitualEventLog[],
  days: number = 30
): { date: string; count: number; participants: number }[] {
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - days);
  
  const recentEvents = events.filter((e: RitualEventLog) => new Date(e.timestamp) >= cutoff);
  
  // Group by date
  const dateMap: Record<string, { count: number; participants: Set<string> }> = {};
  
  recentEvents.forEach((e: RitualEventLog) => {
    const date = new Date(e.timestamp).toISOString().split('T')[0];
    
    if (!dateMap[date]) {
      dateMap[date] = { count: 0, participants: new Set() };
    }
    
    dateMap[date].count++;
    e.participants.forEach((p: string) => dateMap[date].participants.add(p));
  });
  
  // Convert to array and sort
  return Object.entries(dateMap)
    .map(([date, data]) => ({
      date,
      count: data.count,
      participants: data.participants.size,
    }))
    .sort((a, b) => a.date.localeCompare(b.date));
}
