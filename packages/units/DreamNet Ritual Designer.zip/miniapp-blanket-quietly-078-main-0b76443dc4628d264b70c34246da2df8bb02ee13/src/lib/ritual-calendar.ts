// Enhancement #1: Visual Ritual Timeline / Culture Calendar

import type {
  Ritual,
  CeremonySequence,
  CycleDefinition,
  CalendarEvent,
  RitualEventLog,
  Domain,
} from '@/types/ritual';
import { addDays, addWeeks, addMonths, startOfDay, format } from 'date-fns';

const DOMAIN_COLORS: Record<Domain, string> = {
  culture: '#8b5cf6', // violet
  drops: '#ec4899', // pink
  ops: '#10b981', // emerald
  social: '#3b82f6', // blue
  pickleball: '#f59e0b', // amber
  agents: '#6366f1', // indigo
  identity: '#a855f7', // purple
  world: '#14b8a6', // teal
};

export function generateCalendarEvents(
  rituals: Ritual[],
  ceremonies: CeremonySequence[],
  cycles: CycleDefinition[],
  events: RitualEventLog[],
  startDate: Date,
  endDate: Date
): CalendarEvent[] {
  const calendarEvents: CalendarEvent[] = [];
  
  // Generate ritual events based on frequency
  rituals.forEach((ritual: Ritual) => {
    const ritualEvents = generateRitualRecurrences(ritual, startDate, endDate);
    calendarEvents.push(...ritualEvents);
  });
  
  // Add ceremony events (manual scheduling based on recommendedTiming)
  ceremonies.forEach((ceremony: CeremonySequence) => {
    const ceremonyEvent = generateCeremonyEvent(ceremony, startDate);
    if (ceremonyEvent) {
      calendarEvents.push(ceremonyEvent);
    }
  });
  
  // Add cycle phase transitions
  cycles.forEach((cycle: CycleDefinition) => {
    const cycleEvents = generateCyclePhaseEvents(cycle, startDate, endDate);
    calendarEvents.push(...cycleEvents);
  });
  
  // Add historical event anniversaries
  events.forEach((event: RitualEventLog) => {
    const anniversary = generateAnniversaryEvent(event, rituals, startDate, endDate);
    if (anniversary) {
      calendarEvents.push(anniversary);
    }
  });
  
  return calendarEvents.sort((a, b) => a.date.localeCompare(b.date));
}

function generateRitualRecurrences(
  ritual: Ritual,
  startDate: Date,
  endDate: Date
): CalendarEvent[] {
  const events: CalendarEvent[] = [];
  let currentDate = startOfDay(startDate);
  
  while (currentDate <= endDate) {
    let shouldAdd = false;
    let nextDate = currentDate;
    
    switch (ritual.frequency) {
      case 'daily':
        shouldAdd = true;
        nextDate = addDays(currentDate, 1);
        break;
      case 'weekly':
        shouldAdd = true;
        nextDate = addWeeks(currentDate, 1);
        break;
      case 'monthly':
        shouldAdd = true;
        nextDate = addMonths(currentDate, 1);
        break;
      case 'seasonal':
        // Every 3 months
        shouldAdd = true;
        nextDate = addMonths(currentDate, 3);
        break;
      default:
        // For per-event, rare, custom - don't auto-generate
        nextDate = endDate;
        break;
    }
    
    if (shouldAdd && currentDate >= startDate) {
      events.push({
        id: `${ritual.id}-${currentDate.toISOString()}`,
        ritualId: ritual.id,
        date: currentDate.toISOString(),
        title: ritual.name,
        description: ritual.purpose,
        domain: ritual.domain,
        type: 'ritual',
        color: DOMAIN_COLORS[ritual.domain],
      });
    }
    
    currentDate = nextDate;
    
    // Safety: prevent infinite loops
    if (events.length > 1000) break;
  }
  
  return events;
}

function generateCeremonyEvent(
  ceremony: CeremonySequence,
  startDate: Date
): CalendarEvent | null {
  // Parse recommendedTiming to determine date
  // For now, just add it 7 days from start
  const ceremonyDate = addDays(startDate, 7);
  
  return {
    id: `ceremony-${ceremony.id}`,
    ceremonyId: ceremony.id,
    date: ceremonyDate.toISOString(),
    title: ceremony.name,
    description: ceremony.description,
    domain: 'culture', // Default to culture
    type: 'ceremony',
    color: DOMAIN_COLORS.culture,
  };
}

function generateCyclePhaseEvents(
  cycle: CycleDefinition,
  startDate: Date,
  endDate: Date
): CalendarEvent[] {
  const events: CalendarEvent[] = [];
  
  let currentDate = startOfDay(startDate);
  let phaseIndex = 0;
  
  while (currentDate <= endDate && phaseIndex < cycle.phases.length) {
    const phase = cycle.phases[phaseIndex];
    const lengthHint = cycle.phaseLengthHints[phaseIndex] || '7 days';
    
    events.push({
      id: `cycle-${cycle.id}-phase-${phaseIndex}-${currentDate.toISOString()}`,
      cycleId: cycle.id,
      date: currentDate.toISOString(),
      title: `${cycle.name}: ${phase}`,
      description: `Phase ${phaseIndex + 1} of ${cycle.phases.length}`,
      domain: cycle.cycleDomain || 'culture',
      type: 'cycle-phase',
      color: DOMAIN_COLORS[cycle.cycleDomain || 'culture'],
    });
    
    // Parse length hint (simplified)
    const days = parseLengthHint(lengthHint);
    currentDate = addDays(currentDate, days);
    phaseIndex++;
    
    // Loop back to first phase after completing cycle
    if (phaseIndex >= cycle.phases.length) {
      phaseIndex = 0;
    }
    
    // Safety
    if (events.length > 100) break;
  }
  
  return events;
}

function generateAnniversaryEvent(
  event: RitualEventLog,
  rituals: Ritual[],
  startDate: Date,
  endDate: Date
): CalendarEvent | null {
  const eventDate = new Date(event.timestamp);
  const ritual = rituals.find((r: Ritual) => r.id === event.ritualId);
  
  if (!ritual) return null;
  
  // Check if anniversary falls within range
  const yearsAgo = Math.floor((startDate.getTime() - eventDate.getTime()) / (1000 * 60 * 60 * 24 * 365));
  
  if (yearsAgo < 1) return null; // Only show anniversaries from previous years
  
  // Create anniversary date in the target year
  const anniversaryDate = new Date(startDate.getFullYear(), eventDate.getMonth(), eventDate.getDate());
  
  if (anniversaryDate >= startDate && anniversaryDate <= endDate) {
    return {
      id: `anniversary-${event.id}`,
      ritualId: event.ritualId,
      date: anniversaryDate.toISOString(),
      title: `🎂 ${yearsAgo} year anniversary: ${ritual.name}`,
      description: `${yearsAgo} years since ${ritual.name} was performed`,
      domain: ritual.domain,
      type: 'anniversary',
      color: DOMAIN_COLORS[ritual.domain],
    };
  }
  
  return null;
}

function parseLengthHint(hint: string): number {
  const match = hint.match(/(\d+)\s*(day|week|month)/i);
  
  if (!match) return 7; // Default to 7 days
  
  const value = parseInt(match[1], 10);
  const unit = match[2].toLowerCase();
  
  switch (unit) {
    case 'day':
      return value;
    case 'week':
      return value * 7;
    case 'month':
      return value * 30;
    default:
      return 7;
  }
}

export function exportToICS(events: CalendarEvent[]): string {
  let ics = 'BEGIN:VCALENDAR\n';
  ics += 'VERSION:2.0\n';
  ics += 'PRODID:-//DreamNet//Rituals Calendar//EN\n';
  ics += 'CALSCALE:GREGORIAN\n';
  
  events.forEach((event: CalendarEvent) => {
    const date = new Date(event.date);
    const dateStr = format(date, "yyyyMMdd'T'HHmmss");
    
    ics += 'BEGIN:VEVENT\n';
    ics += `UID:${event.id}@dreamnet-rituals\n`;
    ics += `DTSTAMP:${dateStr}\n`;
    ics += `DTSTART:${dateStr}\n`;
    ics += `SUMMARY:${event.title}\n`;
    ics += `DESCRIPTION:${event.description}\n`;
    ics += `CATEGORIES:${event.domain}\n`;
    ics += `COLOR:${event.color}\n`;
    ics += 'END:VEVENT\n';
  });
  
  ics += 'END:VCALENDAR\n';
  
  return ics;
}

export function getDomainColor(domain: Domain): string {
  return DOMAIN_COLORS[domain];
}

export function getEventsForDate(events: CalendarEvent[], date: Date): CalendarEvent[] {
  const dateStr = format(startOfDay(date), 'yyyy-MM-dd');
  return events.filter((e: CalendarEvent) => e.date.startsWith(dateStr));
}

export function getEventsByDomain(events: CalendarEvent[], domain: Domain): CalendarEvent[] {
  return events.filter((e: CalendarEvent) => e.domain === domain);
}
