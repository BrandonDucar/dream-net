// Enhancement #11: Export to Multiple Formats

import type {
  Ritual,
  CeremonySequence,
  CycleDefinition,
  InitiationPath,
  SymbolicObject,
  RitualEventLog,
  ExportFormat,
} from '@/types/ritual';
import { exportToICS } from './ritual-calendar';
import type { CalendarEvent } from '@/types/ritual';

export function exportRitualsToJSON(
  rituals: Ritual[],
  ceremonies: CeremonySequence[],
  cycles: CycleDefinition[],
  paths: InitiationPath[],
  objects: SymbolicObject[],
  events: RitualEventLog[]
): string {
  return JSON.stringify(
    {
      version: '1.0',
      exportDate: new Date().toISOString(),
      rituals,
      ceremonies,
      cycles,
      initiationPaths: paths,
      symbolicObjects: objects,
      eventLogs: events,
    },
    null,
    2
  );
}

export function exportRitualsToMarkdown(
  rituals: Ritual[],
  ceremonies: CeremonySequence[],
  cycles: CycleDefinition[],
  paths: InitiationPath[],
  objects: SymbolicObject[]
): string {
  let md = '# DreamNet Ritual Codex\n\n';
  md += `Generated: ${new Date().toLocaleDateString()}\n\n`;
  md += '---\n\n';
  
  // Table of Contents
  md += '## Table of Contents\n\n';
  md += '- [Rituals](#rituals)\n';
  md += '- [Ceremonies](#ceremonies)\n';
  md += '- [Cycles](#cycles)\n';
  md += '- [Initiation Paths](#initiation-paths)\n';
  md += '- [Symbolic Objects](#symbolic-objects)\n\n';
  md += '---\n\n';
  
  // Rituals
  md += '## Rituals\n\n';
  rituals.forEach((ritual: Ritual) => {
    md += `### ${ritual.name}\n\n`;
    md += `**Domain:** ${ritual.domain} | **Type:** ${ritual.ritualType} | **Frequency:** ${ritual.frequency}\n\n`;
    md += `**Purpose:** ${ritual.purpose}\n\n`;
    md += `**Description:** ${ritual.description}\n\n`;
    
    if (ritual.steps.length > 0) {
      md += '**Steps:**\n\n';
      ritual.steps.forEach((step: string, i: number) => {
        md += `${i + 1}. ${step}\n`;
      });
      md += '\n';
    }
    
    if (ritual.symbolism.length > 0) {
      md += '**Symbolism:**\n\n';
      ritual.symbolism.forEach((s: string) => {
        md += `- ${s}\n`;
      });
      md += '\n';
    }
    
    if (ritual.tags.length > 0) {
      md += `**Tags:** ${ritual.tags.map((t: string) => `#${t}`).join(', ')}\n\n`;
    }
    
    md += '---\n\n';
  });
  
  // Ceremonies
  md += '## Ceremonies\n\n';
  ceremonies.forEach((ceremony: CeremonySequence) => {
    md += `### ${ceremony.name}\n\n`;
    md += `**Description:** ${ceremony.description}\n\n`;
    md += `**Timing:** ${ceremony.recommendedTiming}\n\n`;
    md += `**Ritual Count:** ${ceremony.ritualIds.length}\n\n`;
    md += '---\n\n';
  });
  
  // Cycles
  md += '## Cycles\n\n';
  cycles.forEach((cycle: CycleDefinition) => {
    md += `### ${cycle.name}\n\n`;
    md += `**Description:** ${cycle.description}\n\n`;
    md += `**Phases:** ${cycle.phases.join(' → ')}\n\n`;
    md += '---\n\n';
  });
  
  // Initiation Paths
  md += '## Initiation Paths\n\n';
  paths.forEach((path: InitiationPath) => {
    md += `### ${path.name}\n\n`;
    md += `**Description:** ${path.description}\n\n`;
    md += `**Personas:** ${path.personaArchetypes.join(', ')}\n\n`;
    md += `**Milestones:** ${path.milestones.length}\n\n`;
    md += '---\n\n';
  });
  
  // Symbolic Objects
  md += '## Symbolic Objects\n\n';
  objects.forEach((obj: SymbolicObject) => {
    md += `### ${obj.name}\n\n`;
    md += `**Description:** ${obj.description}\n\n`;
    
    if (obj.meaning.length > 0) {
      md += '**Meaning:**\n\n';
      obj.meaning.forEach((m: string) => {
        md += `- ${m}\n`;
      });
      md += '\n';
    }
    
    md += '---\n\n';
  });
  
  return md;
}

export function exportRitualsToCSV(rituals: Ritual[]): string {
  const headers = ['Name', 'Domain', 'Type', 'Frequency', 'Purpose', 'Tags'];
  const rows = rituals.map((r: Ritual) => [
    r.name,
    r.domain,
    r.ritualType,
    r.frequency,
    r.purpose.replace(/,/g, ';'),
    r.tags.join('; '),
  ]);
  
  let csv = headers.join(',') + '\n';
  rows.forEach((row: string[]) => {
    csv += row.map((cell: string) => `"${cell}"`).join(',') + '\n';
  });
  
  return csv;
}

export function exportToNotion(
  rituals: Ritual[],
  ceremonies: CeremonySequence[],
  cycles: CycleDefinition[]
): string {
  // Generate Notion-compatible markdown
  let notion = '# 🌟 DreamNet Ritual Codex\n\n';
  
  notion += '## 📋 Rituals Database\n\n';
  notion += '| Name | Domain | Type | Frequency | Status |\n';
  notion += '|------|--------|------|-----------|--------|\n';
  
  rituals.forEach((r: Ritual) => {
    const status = r.lastPerformed ? '✅ Active' : '⚪ Pending';
    notion += `| ${r.name} | ${r.domain} | ${r.ritualType} | ${r.frequency} | ${status} |\n`;
  });
  
  notion += '\n## 🎭 Ceremonies\n\n';
  ceremonies.forEach((c: CeremonySequence) => {
    notion += `### ${c.name}\n\n`;
    notion += `> ${c.description}\n\n`;
    notion += `**Timing:** ${c.recommendedTiming}\n\n`;
  });
  
  notion += '\n## 🔄 Cycles\n\n';
  cycles.forEach((c: CycleDefinition) => {
    notion += `### ${c.name}\n\n`;
    notion += `**Phases:** ${c.phases.join(' → ')}\n\n`;
  });
  
  return notion;
}

export function exportCalendarToICS(events: CalendarEvent[]): string {
  return exportToICS(events);
}

export function downloadFile(content: string, filename: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function exportByFormat(
  format: ExportFormat,
  rituals: Ritual[],
  ceremonies: CeremonySequence[],
  cycles: CycleDefinition[],
  paths: InitiationPath[],
  objects: SymbolicObject[],
  events: RitualEventLog[],
  calendarEvents: CalendarEvent[]
): { content: string; filename: string; mimeType: string } {
  const date = new Date().toISOString().split('T')[0];
  
  switch (format) {
    case 'json':
      return {
        content: exportRitualsToJSON(rituals, ceremonies, cycles, paths, objects, events),
        filename: `dreamnet-rituals-${date}.json`,
        mimeType: 'application/json',
      };
    
    case 'markdown':
      return {
        content: exportRitualsToMarkdown(rituals, ceremonies, cycles, paths, objects),
        filename: `dreamnet-rituals-${date}.md`,
        mimeType: 'text/markdown',
      };
    
    case 'csv':
      return {
        content: exportRitualsToCSV(rituals),
        filename: `dreamnet-rituals-${date}.csv`,
        mimeType: 'text/csv',
      };
    
    case 'notion':
      return {
        content: exportToNotion(rituals, ceremonies, cycles),
        filename: `dreamnet-rituals-notion-${date}.md`,
        mimeType: 'text/markdown',
      };
    
    case 'ics':
      return {
        content: exportCalendarToICS(calendarEvents),
        filename: `dreamnet-rituals-calendar-${date}.ics`,
        mimeType: 'text/calendar',
      };
    
    case 'txt':
    default:
      // Use the original codex export
      return {
        content: exportRitualsToMarkdown(rituals, ceremonies, cycles, paths, objects),
        filename: `dreamnet-rituals-${date}.txt`,
        mimeType: 'text/plain',
      };
  }
}
