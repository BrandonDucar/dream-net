// Enhancement #6: Ritual Forking & Remixing

import type { Ritual, CeremonySequence } from '@/types/ritual';
import { createRitual, createCeremonySequence, getRitual, getCeremonySequence } from './ritual-store';

export interface ForkOptions {
  keepSteps?: boolean;
  keepSymbolism?: boolean;
  keepRoles?: boolean;
  keepSensoryElements?: boolean;
  addVariationNote?: string;
}

export function forkRitual(
  originalId: string,
  newName: string,
  options: ForkOptions = {}
): Ritual | null {
  const original = getRitual(originalId);
  if (!original) return null;
  
  // Create fork with modified data
  const forked = createRitual({
    name: newName,
    ritualType: original.ritualType,
    domain: original.domain,
    description: `${original.description} (Forked variant)`,
    purpose: original.purpose,
    steps: options.keepSteps !== false ? [...original.steps] : [],
    symbolism: options.keepSymbolism !== false ? [...original.symbolism] : [],
    frequency: original.frequency,
    conditions: [...original.conditions],
    relatedLore: [...original.relatedLore],
    relatedObjects: [...original.relatedObjects],
    recommendedApps: [...original.recommendedApps],
    recommendedAgents: [...original.recommendedAgents],
    tags: [...original.tags, 'forked'],
    notes: options.addVariationNote || `Forked from: ${original.name}`,
  });
  
  // Update fork metadata
  const updatedFork: Partial<Ritual> = {
    forkedFrom: originalId,
    version: 1,
    isCanonical: false,
  };
  
  // Copy optional enhanced fields if requested
  if (options.keepRoles !== false && original.roles) {
    updatedFork.roles = original.roles;
  }
  
  if (options.keepSensoryElements !== false && original.sensoryElements) {
    updatedFork.sensoryElements = original.sensoryElements;
  }
  
  // Increment fork count on original
  const originalForkCount = original.forkCount || 0;
  
  // Note: In a real implementation, you'd update both the forked ritual
  // and increment the original's fork count. For now, return the forked ritual.
  
  return { ...forked, ...updatedFork };
}

export function forkCeremony(
  originalId: string,
  newName: string
): CeremonySequence | null {
  const original = getCeremonySequence(originalId);
  if (!original) return null;
  
  const forked = createCeremonySequence({
    name: newName,
    description: `${original.description} (Forked variant)`,
    ritualIds: [...original.ritualIds],
    symbolism: [...original.symbolism],
    recommendedTiming: original.recommendedTiming,
    tags: [...original.tags, 'forked'],
    notes: `Forked from: ${original.name}`,
  });
  
  // Add fork metadata (would need to update the store in real implementation)
  return {
    ...forked,
    forkedFrom: originalId,
    version: 1,
  };
}

export function compareRitualVersions(
  ritualId1: string,
  ritualId2: string
): {
  differences: string[];
  similarities: string[];
} {
  const ritual1 = getRitual(ritualId1);
  const ritual2 = getRitual(ritualId2);
  
  if (!ritual1 || !ritual2) {
    return { differences: ['One or both rituals not found'], similarities: [] };
  }
  
  const differences: string[] = [];
  const similarities: string[] = [];
  
  // Compare basic fields
  if (ritual1.name !== ritual2.name) {
    differences.push(`Name: "${ritual1.name}" vs "${ritual2.name}"`);
  } else {
    similarities.push(`Same name: ${ritual1.name}`);
  }
  
  if (ritual1.ritualType !== ritual2.ritualType) {
    differences.push(`Type: ${ritual1.ritualType} vs ${ritual2.ritualType}`);
  } else {
    similarities.push(`Same type: ${ritual1.ritualType}`);
  }
  
  if (ritual1.domain !== ritual2.domain) {
    differences.push(`Domain: ${ritual1.domain} vs ${ritual2.domain}`);
  } else {
    similarities.push(`Same domain: ${ritual1.domain}`);
  }
  
  if (ritual1.frequency !== ritual2.frequency) {
    differences.push(`Frequency: ${ritual1.frequency} vs ${ritual2.frequency}`);
  }
  
  // Compare steps
  if (ritual1.steps.length !== ritual2.steps.length) {
    differences.push(`Different number of steps: ${ritual1.steps.length} vs ${ritual2.steps.length}`);
  } else {
    const stepsMatch = ritual1.steps.every((step: string, i: number) => step === ritual2.steps[i]);
    if (stepsMatch) {
      similarities.push(`Identical ${ritual1.steps.length} steps`);
    } else {
      differences.push('Steps differ in content');
    }
  }
  
  // Compare symbolism
  const commonSymbols = ritual1.symbolism.filter((s: string) => ritual2.symbolism.includes(s));
  if (commonSymbols.length > 0) {
    similarities.push(`Shared symbolism: ${commonSymbols.join(', ')}`);
  }
  
  const uniqueTo1 = ritual1.symbolism.filter((s: string) => !ritual2.symbolism.includes(s));
  const uniqueTo2 = ritual2.symbolism.filter((s: string) => !ritual1.symbolism.includes(s));
  
  if (uniqueTo1.length > 0) {
    differences.push(`Unique to ${ritual1.name}: ${uniqueTo1.join(', ')}`);
  }
  
  if (uniqueTo2.length > 0) {
    differences.push(`Unique to ${ritual2.name}: ${uniqueTo2.join(', ')}`);
  }
  
  return { differences, similarities };
}

export function getRitualLineage(ritualId: string): Ritual[] {
  const lineage: Ritual[] = [];
  let current = getRitual(ritualId);
  
  while (current) {
    lineage.unshift(current);
    
    if (current.forkedFrom) {
      current = getRitual(current.forkedFrom);
    } else {
      current = null;
    }
  }
  
  return lineage;
}

export function getRitualVariants(ritualId: string): Ritual[] {
  // In a real implementation, you'd query all rituals where forkedFrom === ritualId
  // For now, return empty array as placeholder
  return [];
}

export function suggestRitualModifications(ritual: Ritual): string[] {
  const suggestions: string[] = [];
  
  // Based on ritual type, suggest modifications
  switch (ritual.ritualType) {
    case 'practice':
      suggestions.push('Add a reflection step at the end');
      suggestions.push('Consider making it a group activity');
      break;
    case 'celebration':
      suggestions.push('Add a feast or shared meal');
      suggestions.push('Include music or dancing');
      break;
    case 'transition':
      suggestions.push('Add a symbolic crossing of threshold');
      suggestions.push('Include a "letting go" phase');
      break;
    case 'initiation':
      suggestions.push('Add a challenge or test');
      suggestions.push('Include witness statements from elders');
      break;
  }
  
  // Domain-specific suggestions
  switch (ritual.domain) {
    case 'social':
      suggestions.push('Make it more interactive');
      suggestions.push('Include storytelling elements');
      break;
    case 'ops':
      suggestions.push('Add a checklist or procedure review');
      suggestions.push('Include retrospective discussion');
      break;
    case 'culture':
      suggestions.push('Connect to existing lore');
      suggestions.push('Add symbolic objects');
      break;
  }
  
  // If no sensory elements, suggest adding them
  if (!ritual.sensoryElements) {
    suggestions.push('Add sensory elements (sound, lighting, scent)');
  }
  
  // If no roles defined, suggest adding them
  if (!ritual.roles || ritual.roles.length === 0) {
    suggestions.push('Define participant roles');
  }
  
  return suggestions;
}

export function markRitualAsCanonical(ritualId: string): boolean {
  // In a real implementation, this would update the ritual's isCanonical flag
  // and potentially unset it on other variants
  return true;
}

export interface ForkSuggestion {
  type: 'domain-shift' | 'frequency-adjust' | 'scale-up' | 'scale-down' | 'remix';
  description: string;
  suggestedName: string;
}

export function suggestForks(ritual: Ritual): ForkSuggestion[] {
  const suggestions: ForkSuggestion[] = [];
  
  // Domain shift suggestions
  if (ritual.domain !== 'social') {
    suggestions.push({
      type: 'domain-shift',
      description: `Adapt ${ritual.name} for social gatherings`,
      suggestedName: `${ritual.name} (Social Variant)`,
    });
  }
  
  // Frequency adjustments
  if (ritual.frequency !== 'weekly') {
    suggestions.push({
      type: 'frequency-adjust',
      description: `Create a weekly version of ${ritual.name}`,
      suggestedName: `Weekly ${ritual.name}`,
    });
  }
  
  // Scale variations
  suggestions.push({
    type: 'scale-up',
    description: `Expand ${ritual.name} into a full ceremony`,
    suggestedName: `Grand ${ritual.name}`,
  });
  
  suggestions.push({
    type: 'scale-down',
    description: `Create a quick/minimal version of ${ritual.name}`,
    suggestedName: `Mini ${ritual.name}`,
  });
  
  return suggestions;
}
