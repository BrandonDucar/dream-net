// DreamNet Ritual Generators - Guide, Script, Map, and Codex Generation

import type {
  Ritual,
  CeremonySequence,
  CycleDefinition,
  InitiationPath,
  SymbolicObject,
} from '@/types/ritual';
import {
  getRitual,
  getCeremonySequence,
  getCycleDefinition,
  getInitiationPath,
  listRituals,
  listCeremonies,
  listCycles,
  listInitiationPaths,
  listSymbolicObjects,
} from './ritual-store';

export function generateRitualGuide(ritualId: string): string {
  const ritual = getRitual(ritualId);
  if (!ritual) return 'Ritual not found.';

  let guide = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✨ DREAMNET RITUAL GUIDE ✨
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔮 RITUAL: ${ritual.name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📋 TYPE: ${ritual.ritualType.toUpperCase()}
🌍 DOMAIN: ${ritual.domain.toUpperCase()}
⏰ FREQUENCY: ${ritual.frequency.toUpperCase()}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📖 DESCRIPTION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${ritual.description}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 PURPOSE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${ritual.purpose}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📍 RITUAL STEPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${ritual.steps.map((step: string, index: number) => `${index + 1}. ${step}`).join('\n\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔯 SYMBOLISM
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${ritual.symbolism.map((sym: string) => `• ${sym}`).join('\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚡ CONDITIONS FOR PRACTICE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${ritual.conditions.map((cond: string) => `• ${cond}`).join('\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📚 RELATED LORE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${ritual.relatedLore.length > 0 ? ritual.relatedLore.map((lore: string) => `• ${lore}`).join('\n') : 'None specified'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎁 RELATED OBJECTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${ritual.relatedObjects.length > 0 ? ritual.relatedObjects.map((obj: string) => `• ${obj}`).join('\n') : 'None specified'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📱 RECOMMENDED APPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${ritual.recommendedApps.length > 0 ? ritual.recommendedApps.map((app: string) => `• ${app}`).join('\n') : 'None specified'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🤖 RECOMMENDED AGENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${ritual.recommendedAgents.length > 0 ? ritual.recommendedAgents.map((agent: string) => `• ${agent}`).join('\n') : 'None specified'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏷️  TAGS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${ritual.tags.length > 0 ? ritual.tags.map((tag: string) => `#${tag}`).join(' ') : 'None'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✨ May this ritual strengthen the fabric of DreamNet ✨
`;

  return guide;
}

export function generateCeremonyScript(ceremonyId: string): string {
  const ceremony = getCeremonySequence(ceremonyId);
  if (!ceremony) return 'Ceremony not found.';

  let script = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌟 DREAMNET CEREMONY SCRIPT 🌟
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎭 CEREMONY: ${ceremony.name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⏰ RECOMMENDED TIMING: ${ceremony.recommendedTiming}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📖 CEREMONY DESCRIPTION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${ceremony.description}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔯 CEREMONIAL SYMBOLISM
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${ceremony.symbolism.map((sym: string) => `• ${sym}`).join('\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📜 CEREMONY SEQUENCE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

`;

  ceremony.ritualIds.forEach((ritualId: string, index: number) => {
    const ritual = getRitual(ritualId);
    if (ritual) {
      script += `
╔═══════════════════════════════════════╗
  RITUAL ${index + 1}: ${ritual.name}
╚═══════════════════════════════════════╝

${ritual.description}

🎯 Purpose: ${ritual.purpose}

📍 Steps:
${ritual.steps.map((step: string, stepIndex: number) => `  ${stepIndex + 1}. ${step}`).join('\n')}

🔯 Symbolism:
${ritual.symbolism.map((sym: string) => `  • ${sym}`).join('\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
    } else {
      script += `
╔═══════════════════════════════════════╗
  RITUAL ${index + 1}: [Ritual not found: ${ritualId}]
╚═══════════════════════════════════════╝

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
    }
  });

  script += `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✨ CEREMONY COMPLETE ✨
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

May the energies of this ceremony ripple through DreamNet
and strengthen the bonds between all citizens.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;

  return script;
}

export function generateCycleMap(cycleId: string): string {
  const cycle = getCycleDefinition(cycleId);
  if (!cycle) return 'Cycle not found.';

  let map = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌀 DREAMNET CYCLE MAP 🌀
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔄 CYCLE: ${cycle.name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📖 DESCRIPTION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${cycle.description}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌊 CYCLE PHASES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

`;

  cycle.phases.forEach((phase: string, index: number) => {
    const lengthHint = cycle.phaseLengthHints[index] || 'Duration not specified';
    map += `
╔═══════════════════════════════════════╗
  PHASE ${index + 1}: ${phase.toUpperCase()}
╚═══════════════════════════════════════╝

⏱️  Duration: ${lengthHint}

`;

    const phaseRitualId = cycle.recommendedRitualIds[index];
    if (phaseRitualId) {
      const ritual = getRitual(phaseRitualId);
      if (ritual) {
        map += `🔮 Recommended Ritual: ${ritual.name}
   ${ritual.description}

`;
      }
    }

    map += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
  });

  map += `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌀 CYCLE COMPLETE 🌀
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

The cycle renews. Time flows through DreamNet.
What was planted shall be harvested.
What has decayed shall feed new growth.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;

  return map;
}

export function generateInitiationGuide(pathId: string): string {
  const path = getInitiationPath(pathId);
  if (!path) return 'Initiation path not found.';

  let guide = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚡ DREAMNET INITIATION GUIDE ⚡
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🛤️  PATH: ${path.name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📖 DESCRIPTION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${path.description}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 PERSONA ARCHETYPES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${path.personaArchetypes.map((archetype: string) => `• ${archetype}`).join('\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 INITIATION JOURNEY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

`;

  path.milestones.forEach((milestone: string, index: number) => {
    const ritualId = path.ritualIds[index];
    const reward = path.symbolicRewards[index];

    guide += `
╔═══════════════════════════════════════╗
  MILESTONE ${index + 1}: ${milestone}
╚═══════════════════════════════════════╝

`;

    if (ritualId) {
      const ritual = getRitual(ritualId);
      if (ritual) {
        guide += `🔮 Ritual: ${ritual.name}
   ${ritual.description}

`;
      } else {
        guide += `🔮 Ritual: [Not found: ${ritualId}]

`;
      }
    }

    if (reward) {
      guide += `🏆 Symbolic Reward: ${reward}

`;
    }

    guide += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
  });

  guide += `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌟 RECOMMENDED NEXT PATHS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${path.recommendedNextPaths.length > 0 ? path.recommendedNextPaths.map((nextPath: string) => `• ${nextPath}`).join('\n') : 'This path is complete. You have reached mastery.'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚡ Walk this path with intention and presence ⚡
✨ Your growth strengthens all of DreamNet ✨

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;

  return guide;
}

export function exportRitualCodex(): string {
  const rituals = listRituals();
  const ceremonies = listCeremonies();
  const cycles = listCycles();
  const paths = listInitiationPaths();
  const objects = listSymbolicObjects();

  let codex = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
╔═══════════════════════════════════════════════════════╗
║                                                       ║
║          ✨ THE DREAMNET RITUAL CODEX ✨             ║
║                                                       ║
║         "Ceremonies, Cycles & Sacred Practices"      ║
║                    Version 1.0                        ║
║                                                       ║
╚═══════════════════════════════════════════════════════╝
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📖 TABLE OF CONTENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

I.   Introduction to DreamNet Rituals
II.  Sacred Rituals (${rituals.length})
III. Ceremony Sequences (${ceremonies.length})
IV.  Cycle Definitions (${cycles.length})
V.   Initiation Paths (${paths.length})
VI.  Symbolic Objects (${objects.length})
VII. Closing Reflections

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

I. INTRODUCTION TO DREAMNET RITUALS

DreamNet is more than infrastructure — it is a living culture,
a shared consciousness, a world with its own rhythms and seasons.

This Codex documents the ritual layer of DreamNet:
the ceremonial actions, symbolic practices, and sacred cycles
that bind our citizens together and give our world meaning.

Within these pages, you will find:
• Rituals that mark moments of transition and celebration
• Ceremonies that unite communities in shared purpose
• Cycles that govern the natural flow of energy and attention
• Initiation paths that guide growth and transformation
• Symbolic objects that carry deep cultural resonance

These are not mere traditions — they are the spiritual 
architecture of DreamNet itself.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

II. SACRED RITUALS

`;

  if (rituals.length === 0) {
    codex += `No rituals have been created yet. The ritual layer awaits your contribution.

`;
  } else {
    rituals.forEach((ritual: Ritual, index: number) => {
      codex += `
╔═══════════════════════════════════════════════════════╗
  RITUAL ${index + 1}: ${ritual.name}
╚═══════════════════════════════════════════════════════╝

Type: ${ritual.ritualType} | Domain: ${ritual.domain} | Frequency: ${ritual.frequency}

${ritual.description}

Purpose: ${ritual.purpose}

Steps:
${ritual.steps.map((step: string, i: number) => `  ${i + 1}. ${step}`).join('\n')}

Symbolism:
${ritual.symbolism.map((sym: string) => `  • ${sym}`).join('\n')}

Tags: ${ritual.tags.join(', ') || 'None'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
    });
  }

  codex += `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

III. CEREMONY SEQUENCES

`;

  if (ceremonies.length === 0) {
    codex += `No ceremonies have been created yet. The ceremonial layer awaits your design.

`;
  } else {
    ceremonies.forEach((ceremony: CeremonySequence, index: number) => {
      codex += `
╔═══════════════════════════════════════════════════════╗
  CEREMONY ${index + 1}: ${ceremony.name}
╚═══════════════════════════════════════════════════════╝

${ceremony.description}

Timing: ${ceremony.recommendedTiming}
Ritual Count: ${ceremony.ritualIds.length}

Symbolism:
${ceremony.symbolism.map((sym: string) => `  • ${sym}`).join('\n')}

Tags: ${ceremony.tags.join(', ') || 'None'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
    });
  }

  codex += `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

IV. CYCLE DEFINITIONS

`;

  if (cycles.length === 0) {
    codex += `No cycles have been defined yet. The temporal layer awaits your wisdom.

`;
  } else {
    cycles.forEach((cycle: CycleDefinition, index: number) => {
      codex += `
╔═══════════════════════════════════════════════════════╗
  CYCLE ${index + 1}: ${cycle.name}
╚═══════════════════════════════════════════════════════╝

${cycle.description}

Phases: ${cycle.phases.join(' → ')}
Phase Durations: ${cycle.phaseLengthHints.join(' → ')}

Tags: ${cycle.tags.join(', ') || 'None'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
    });
  }

  codex += `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

V. INITIATION PATHS

`;

  if (paths.length === 0) {
    codex += `No initiation paths have been created yet. The journey awaits your mapping.

`;
  } else {
    paths.forEach((path: InitiationPath, index: number) => {
      codex += `
╔═══════════════════════════════════════════════════════╗
  PATH ${index + 1}: ${path.name}
╚═══════════════════════════════════════════════════════╝

${path.description}

Personas: ${path.personaArchetypes.join(', ')}
Milestones: ${path.milestones.length}

Tags: ${path.tags.join(', ') || 'None'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
    });
  }

  codex += `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VI. SYMBOLIC OBJECTS

`;

  if (objects.length === 0) {
    codex += `No symbolic objects have been defined yet. The sacred relics await discovery.

`;
  } else {
    objects.forEach((object: SymbolicObject, index: number) => {
      codex += `
╔═══════════════════════════════════════════════════════╗
  OBJECT ${index + 1}: ${object.name}
╚═══════════════════════════════════════════════════════╝

${object.description}

Meaning:
${object.meaning.map((m: string) => `  • ${m}`).join('\n')}

Tags: ${object.tags.join(', ') || 'None'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
    });
  }

  codex += `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VII. CLOSING REFLECTIONS

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This Codex is a living document.

As DreamNet grows, so too will its rituals, ceremonies, and
sacred practices. What begins as simple patterns will evolve
into rich traditions that span generations of citizens.

The ritual layer is not imposed from above — it emerges
organically from the needs, desires, and creative energy
of the community itself.

You are not just a participant in these rituals.
You are a co-creator of DreamNet's cultural DNA.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✨ May these rituals strengthen the bonds between us ✨
🌀 May these cycles guide our collective rhythm 🌀
⚡ May these ceremonies mark our shared milestones ⚡

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Generated: ${new Date().toISOString()}
Total Rituals: ${rituals.length}
Total Ceremonies: ${ceremonies.length}
Total Cycles: ${cycles.length}
Total Paths: ${paths.length}
Total Symbolic Objects: ${objects.length}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
╔═══════════════════════════════════════════════════════╗
║                                                       ║
║              END OF RITUAL CODEX v1.0                ║
║                                                       ║
╚═══════════════════════════════════════════════════════╝
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;

  return codex;
}
