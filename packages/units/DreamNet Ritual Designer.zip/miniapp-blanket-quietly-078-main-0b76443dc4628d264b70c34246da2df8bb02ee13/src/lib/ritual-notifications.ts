// Enhancement #9: Ritual Notifications & Nudges

import type {
  Ritual,
  CeremonySequence,
  RitualEventLog,
  RitualNotification,
  InitiationPath,
} from '@/types/ritual';
import { addDays, addWeeks, addMonths, differenceInDays } from 'date-fns';

const STORAGE_KEY = 'dreamnet_notifications';

export function generateNotifications(
  rituals: Ritual[],
  ceremonies: CeremonySequence[],
  paths: InitiationPath[],
  events: RitualEventLog[]
): RitualNotification[] {
  const notifications: RitualNotification[] = [];
  const now = new Date();
  
  // Upcoming ritual notifications
  rituals.forEach((ritual: Ritual) => {
    const lastEvent = events
      .filter((e: RitualEventLog) => e.ritualId === ritual.id)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())[0];
    
    if (lastEvent) {
      const daysSince = differenceInDays(now, new Date(lastEvent.timestamp));
      let shouldNotify = false;
      let daysUntil = 0;
      
      switch (ritual.frequency) {
        case 'daily':
          if (daysSince >= 1) {
            shouldNotify = true;
            daysUntil = 0;
          }
          break;
        case 'weekly':
          if (daysSince >= 7) {
            shouldNotify = true;
            daysUntil = 0;
          }
          break;
        case 'monthly':
          if (daysSince >= 30) {
            shouldNotify = true;
            daysUntil = 0;
          }
          break;
      }
      
      if (shouldNotify) {
        notifications.push({
          id: `upcoming-${ritual.id}-${Date.now()}`,
          type: 'upcoming',
          ritualId: ritual.id,
          message: `🔔 ${ritual.name} is due! Last performed ${daysSince} days ago.`,
          scheduledFor: now.toISOString(),
          sent: false,
          priority: daysSince > 60 ? 'high' : daysSince > 30 ? 'medium' : 'low',
        });
      }
    } else {
      // Never performed
      const daysSinceCreated = differenceInDays(now, new Date(ritual.createdAt));
      
      if (daysSinceCreated >= 7) {
        notifications.push({
          id: `never-performed-${ritual.id}-${Date.now()}`,
          type: 'reminder',
          ritualId: ritual.id,
          message: `✨ ${ritual.name} has never been performed. Ready to bring it to life?`,
          scheduledFor: now.toISOString(),
          sent: false,
          priority: 'medium',
        });
      }
    }
  });
  
  // Inactivity notifications (domain-level)
  const domains = ['culture', 'drops', 'ops', 'social', 'pickleball', 'agents', 'identity', 'world'] as const;
  
  domains.forEach((domain) => {
    const domainRituals = rituals.filter((r: Ritual) => r.domain === domain);
    const recentEvents = events.filter((e: RitualEventLog) => {
      const ritual = domainRituals.find((r: Ritual) => r.id === e.ritualId);
      const daysSince = differenceInDays(now, new Date(e.timestamp));
      return ritual && daysSince <= 21;
    });
    
    if (domainRituals.length > 0 && recentEvents.length === 0) {
      notifications.push({
        id: `domain-inactive-${domain}-${Date.now()}`,
        type: 'reminder',
        message: `⚠️ No ${domain} ritual activity for 3 weeks. Time to reconnect with ${domain} practices?`,
        scheduledFor: now.toISOString(),
        sent: false,
        priority: 'low',
      });
    }
  });
  
  // Milestone notifications
  events.forEach((event: RitualEventLog) => {
    const daysSince = differenceInDays(now, new Date(event.timestamp));
    const ritual = rituals.find((r: Ritual) => r.id === event.ritualId);
    
    // Anniversary notifications (yearly)
    if (daysSince % 365 === 0 && daysSince > 0 && ritual) {
      const years = daysSince / 365;
      notifications.push({
        id: `anniversary-${event.id}-${Date.now()}`,
        type: 'anniversary',
        ritualId: event.ritualId,
        message: `🎂 ${years} year${years > 1 ? 's' : ''} since ${ritual.name}! Time to celebrate this milestone.`,
        scheduledFor: now.toISOString(),
        sent: false,
        priority: 'high',
      });
    }
  });
  
  // Initiation path progress notifications
  paths.forEach((path: InitiationPath) => {
    const pathRituals = rituals.filter((r: Ritual) => path.ritualIds.includes(r.id));
    const completedRituals = pathRituals.filter((r: Ritual) => {
      const ritualEvents = events.filter((e: RitualEventLog) => e.ritualId === r.id);
      return ritualEvents.length > 0;
    });
    
    const progress = pathRituals.length > 0 ? completedRituals.length / pathRituals.length : 0;
    
    if (progress > 0 && progress < 1) {
      notifications.push({
        id: `path-progress-${path.id}-${Date.now()}`,
        type: 'milestone',
        message: `🎯 ${Math.round(progress * 100)}% complete on "${path.name}" path. Keep going!`,
        scheduledFor: now.toISOString(),
        sent: false,
        priority: 'low',
      });
    } else if (progress === 1) {
      notifications.push({
        id: `path-complete-${path.id}-${Date.now()}`,
        type: 'milestone',
        message: `🏆 Congratulations! You've completed the "${path.name}" initiation path!`,
        scheduledFor: now.toISOString(),
        sent: false,
        priority: 'high',
      });
    }
  });
  
  return notifications.sort((a, b) => {
    const priorityWeight = { high: 3, medium: 2, low: 1 };
    return priorityWeight[b.priority] - priorityWeight[a.priority];
  });
}

export function saveNotifications(notifications: RitualNotification[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(notifications));
}

export function loadNotifications(): RitualNotification[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : [];
}

export function markNotificationSent(id: string): void {
  const notifications = loadNotifications();
  const updated = notifications.map((n: RitualNotification) =>
    n.id === id ? { ...n, sent: true } : n
  );
  saveNotifications(updated);
}

export function dismissNotification(id: string): void {
  const notifications = loadNotifications();
  const filtered = notifications.filter((n: RitualNotification) => n.id !== id);
  saveNotifications(filtered);
}

export function getUnsentNotifications(): RitualNotification[] {
  return loadNotifications().filter((n: RitualNotification) => !n.sent);
}

export function scheduleRitualReminder(
  ritual: Ritual,
  date: Date
): RitualNotification {
  const notification: RitualNotification = {
    id: `scheduled-${ritual.id}-${date.toISOString()}`,
    type: 'reminder',
    ritualId: ritual.id,
    message: `📅 Scheduled reminder: ${ritual.name}`,
    scheduledFor: date.toISOString(),
    sent: false,
    priority: 'medium',
  };
  
  const notifications = loadNotifications();
  notifications.push(notification);
  saveNotifications(notifications);
  
  return notification;
}

export function getNotificationsForToday(): RitualNotification[] {
  const notifications = loadNotifications();
  const today = new Date().toISOString().split('T')[0];
  
  return notifications.filter((n: RitualNotification) => {
    const notifDate = new Date(n.scheduledFor).toISOString().split('T')[0];
    return notifDate === today && !n.sent;
  });
}
