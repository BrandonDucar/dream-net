// Enhancement #5: Ritual Simulation / Dry Run Mode

import type {
  Ritual,
  CeremonySequence,
  ParticipantRole,
} from '@/types/ritual';
import { getRitual } from './ritual-store';

export interface SimulationStep {
  stepNumber: number;
  title: string;
  description: string;
  duration: string;
  role?: string; // Which role performs this step
  materials?: string[];
  notes?: string[];
}

export interface CeremonySimulation {
  ceremonyName: string;
  totalSteps: number;
  estimatedDuration: string;
  preparations: string[];
  ritualSequence: {
    ritualName: string;
    ritualId: string;
    steps: SimulationStep[];
  }[];
  participants: {
    role: string;
    count: number;
    responsibilities: string[];
  }[];
  checklist: {
    category: string;
    items: string[];
  }[];
}

export function generateCeremonySimulation(
  ceremony: CeremonySequence
): CeremonySimulation {
  const ritualSequence: CeremonySimulation['ritualSequence'] = [];
  let totalSteps = 0;
  let totalMinutes = 0;
  
  ceremony.ritualIds.forEach((ritualId: string) => {
    const ritual = getRitual(ritualId);
    if (!ritual) return;
    
    const ritualSteps: SimulationStep[] = ritual.steps.map((step: string, index: number) => {
      // Estimate 5 minutes per step
      const stepDuration = '5 min';
      totalMinutes += 5;
      
      return {
        stepNumber: totalSteps + index + 1,
        title: step,
        description: step,
        duration: stepDuration,
        materials: [],
        notes: [],
      };
    });
    
    totalSteps += ritual.steps.length;
    
    ritualSequence.push({
      ritualName: ritual.name,
      ritualId: ritual.id,
      steps: ritualSteps,
    });
  });
  
  // Generate preparations
  const preparations = [
    'Prepare space: clean, arrange seating, set atmosphere',
    'Gather materials: check all symbolic objects are present',
    'Brief participants: review roles and responsibilities',
    'Time management: allocate time blocks for each ritual',
    'Emergency plan: have backup plan if timing shifts',
  ];
  
  if (ceremony.preparationChecklist) {
    preparations.push(...ceremony.preparationChecklist);
  }
  
  // Generate participant structure
  const participants: CeremonySimulation['participants'] = [
    {
      role: 'Host / Facilitator',
      count: 1,
      responsibilities: [
        'Open and close ceremony',
        'Guide transitions between rituals',
        'Maintain sacred space',
        'Keep time',
      ],
    },
    {
      role: 'Participants',
      count: 5,
      responsibilities: [
        'Engage fully in each ritual',
        'Respect the process',
        'Support fellow participants',
      ],
    },
  ];
  
  // Generate checklist
  const checklist: CeremonySimulation['checklist'] = [
    {
      category: 'Physical Space',
      items: [
        'Room cleaned and organized',
        'Seating arranged',
        'Lighting adjusted',
        'Temperature comfortable',
        'Distractions minimized',
      ],
    },
    {
      category: 'Materials',
      items: [
        'All symbolic objects present',
        'Writing materials if needed',
        'Audio equipment tested',
        'Props/tools prepared',
      ],
    },
    {
      category: 'Participants',
      items: [
        'All participants confirmed',
        'Roles assigned',
        'Instructions sent',
        'Questions answered',
      ],
    },
    {
      category: 'Timing',
      items: [
        'Start time confirmed',
        'Break times planned',
        'End time estimated',
        'Buffer time allocated',
      ],
    },
  ];
  
  return {
    ceremonyName: ceremony.name,
    totalSteps,
    estimatedDuration: ceremony.estimatedDuration || formatDuration(totalMinutes),
    preparations,
    ritualSequence,
    participants,
    checklist,
  };
}

export function generateRitualRundown(ritual: Ritual): SimulationStep[] {
  const steps: SimulationStep[] = [];
  
  // Opening
  steps.push({
    stepNumber: 1,
    title: 'Opening / Preparation',
    description: 'Create sacred space, gather participants, set intention',
    duration: '5 min',
    materials: ['Space cleared', 'Participants gathered'],
    notes: ['Center yourself before beginning', 'Welcome all participants'],
  });
  
  // Main steps
  ritual.steps.forEach((step: string, index: number) => {
    const roleForStep = ritual.roles && ritual.roles.length > 0
      ? ritual.roles[index % ritual.roles.length].name
      : undefined;
    
    steps.push({
      stepNumber: index + 2,
      title: step,
      description: step,
      duration: '5-10 min',
      role: roleForStep,
      materials: [],
      notes: [],
    });
  });
  
  // Closing
  steps.push({
    stepNumber: ritual.steps.length + 2,
    title: 'Closing / Integration',
    description: 'Reflect on experience, give thanks, release the space',
    duration: '5 min',
    materials: [],
    notes: ['Allow silence for integration', 'Thank all participants', 'Close sacred space'],
  });
  
  return steps;
}

export function validateCeremonyReadiness(
  ceremony: CeremonySequence
): { ready: boolean; issues: string[]; warnings: string[] } {
  const issues: string[] = [];
  const warnings: string[] = [];
  
  // Check if all rituals exist
  ceremony.ritualIds.forEach((ritualId: string) => {
    const ritual = getRitual(ritualId);
    if (!ritual) {
      issues.push(`Ritual ${ritualId} not found`);
    }
  });
  
  // Check if ceremony has rituals
  if (ceremony.ritualIds.length === 0) {
    issues.push('Ceremony has no rituals');
  }
  
  // Warnings
  if (!ceremony.estimatedDuration) {
    warnings.push('No estimated duration set');
  }
  
  if (!ceremony.preparationChecklist || ceremony.preparationChecklist.length === 0) {
    warnings.push('No preparation checklist defined');
  }
  
  if (ceremony.ritualIds.length > 5) {
    warnings.push('Ceremony has many rituals - consider breaking into smaller ceremonies');
  }
  
  return {
    ready: issues.length === 0,
    issues,
    warnings,
  };
}

export function generateParticipantScript(
  ritual: Ritual,
  roleName: string
): string {
  let script = `# ${ritual.name} - ${roleName} Script\n\n`;
  script += `**Purpose:** ${ritual.purpose}\n\n`;
  script += `**Your Role:** ${roleName}\n\n`;
  
  const role = ritual.roles?.find((r: ParticipantRole) => r.name === roleName);
  
  if (role) {
    script += '## Your Responsibilities:\n\n';
    role.responsibilities.forEach((resp: string) => {
      script += `- ${resp}\n`;
    });
    script += '\n';
  }
  
  script += '## Ritual Steps:\n\n';
  ritual.steps.forEach((step: string, index: number) => {
    script += `### Step ${index + 1}: ${step}\n\n`;
    script += `*Duration: ~5-10 minutes*\n\n`;
    
    if (role && index % 2 === 0) {
      script += `**Your action:** ${role.responsibilities[0] || 'Participate actively'}\n\n`;
    }
  });
  
  script += '## Notes:\n\n';
  script += `- ${ritual.notes || 'Stay present and engaged'}\n`;
  
  return script;
}

function formatDuration(minutes: number): string {
  if (minutes < 60) {
    return `${minutes} minutes`;
  }
  
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  
  if (mins === 0) {
    return `${hours} hour${hours > 1 ? 's' : ''}`;
  }
  
  return `${hours} hour${hours > 1 ? 's' : ''} ${mins} minutes`;
}

export function estimateRitualDuration(ritual: Ritual): string {
  // Base calculation: 5 min opening + 5-10 min per step + 5 min closing
  const baseMinutes = 10 + (ritual.steps.length * 7.5) + 5;
  
  // Adjust based on ritual type
  let multiplier = 1;
  
  switch (ritual.ritualType) {
    case 'ceremony':
      multiplier = 1.3; // Ceremonies tend to be more elaborate
      break;
    case 'celebration':
      multiplier = 1.5; // Celebrations take longer
      break;
    case 'initiation':
      multiplier = 1.4;
      break;
    default:
      multiplier = 1;
  }
  
  const totalMinutes = Math.round(baseMinutes * multiplier);
  return formatDuration(totalMinutes);
}
