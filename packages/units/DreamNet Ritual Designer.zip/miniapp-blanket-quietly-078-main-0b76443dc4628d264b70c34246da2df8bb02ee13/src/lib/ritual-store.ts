// DreamNet Rituals Store - Local Data Management

import type {
  Ritual,
  CeremonySequence,
  CycleDefinition,
  InitiationPath,
  SymbolicObject,
  RitualEventLog,
  RitualFilters,
  CeremonyFilters,
  CycleFilters,
  InitiationFilters,
  SymbolicObjectFilters,
  RitualEventFilters,
  SEOMeta,
} from '@/types/ritual';

const STORAGE_KEYS = {
  RITUALS: 'dreamnet_rituals',
  CEREMONIES: 'dreamnet_ceremonies',
  CYCLES: 'dreamnet_cycles',
  INITIATIONS: 'dreamnet_initiations',
  SYMBOLIC_OBJECTS: 'dreamnet_symbolic_objects',
  EVENT_LOGS: 'dreamnet_event_logs',
};

// Utility functions
function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

function generateSlug(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function generateSEOMeta(name: string, description: string, tags: string[]): SEOMeta {
  return {
    seoTitle: `${name} | DreamNet Ritual`,
    seoDescription: description.slice(0, 160),
    seoKeywords: tags,
    seoHashtags: tags.map((tag: string) => `#${tag.replace(/\s+/g, '')}`),
    altText: name,
  };
}

// Storage helpers
function getFromStorage<T>(key: string): T[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

function saveToStorage<T>(key: string, data: T[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(key, JSON.stringify(data));
}

// Ritual CRUD
export function createRitual(input: {
  name: string;
  ritualType: Ritual['ritualType'];
  domain: Ritual['domain'];
  description: string;
  steps: string[];
  purpose: string;
  symbolism: string[];
  frequency: Ritual['frequency'];
  conditions: string[];
  relatedLore: string[];
  relatedObjects: string[];
  recommendedApps: string[];
  recommendedAgents: string[];
  tags?: string[];
  notes?: string;
}): Ritual {
  const now = new Date().toISOString();
  const ritual: Ritual = {
    id: generateId(),
    name: input.name,
    slug: generateSlug(input.name),
    description: input.description,
    ritualType: input.ritualType,
    domain: input.domain,
    purpose: input.purpose,
    steps: input.steps,
    symbolism: input.symbolism,
    frequency: input.frequency,
    conditions: input.conditions,
    relatedLore: input.relatedLore,
    relatedObjects: input.relatedObjects,
    recommendedApps: input.recommendedApps,
    recommendedAgents: input.recommendedAgents,
    tags: input.tags || [],
    notes: input.notes || '',
    seo: generateSEOMeta(input.name, input.description, input.tags || []),
    createdAt: now,
    updatedAt: now,
  };

  const rituals = getFromStorage<Ritual>(STORAGE_KEYS.RITUALS);
  rituals.push(ritual);
  saveToStorage(STORAGE_KEYS.RITUALS, rituals);

  return ritual;
}

export function updateRitual(id: string, updates: Partial<Omit<Ritual, 'id' | 'createdAt'>>): Ritual | null {
  const rituals = getFromStorage<Ritual>(STORAGE_KEYS.RITUALS);
  const index = rituals.findIndex((r: Ritual) => r.id === id);
  
  if (index === -1) return null;

  const updated: Ritual = {
    ...rituals[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };

  if (updates.name && updates.name !== rituals[index].name) {
    updated.slug = generateSlug(updates.name);
  }

  if (updates.name || updates.description || updates.tags) {
    updated.seo = generateSEOMeta(
      updated.name,
      updated.description,
      updated.tags
    );
  }

  rituals[index] = updated;
  saveToStorage(STORAGE_KEYS.RITUALS, rituals);

  return updated;
}

export function deleteRitual(id: string): boolean {
  const rituals = getFromStorage<Ritual>(STORAGE_KEYS.RITUALS);
  const filtered = rituals.filter((r: Ritual) => r.id !== id);
  
  if (filtered.length === rituals.length) return false;
  
  saveToStorage(STORAGE_KEYS.RITUALS, filtered);
  return true;
}

export function getRitual(id: string): Ritual | null {
  const rituals = getFromStorage<Ritual>(STORAGE_KEYS.RITUALS);
  return rituals.find((r: Ritual) => r.id === id) || null;
}

export function listRituals(filters?: RitualFilters): Ritual[] {
  let rituals = getFromStorage<Ritual>(STORAGE_KEYS.RITUALS);

  if (filters?.domain) {
    rituals = rituals.filter((r: Ritual) => r.domain === filters.domain);
  }

  if (filters?.ritualType) {
    rituals = rituals.filter((r: Ritual) => r.ritualType === filters.ritualType);
  }

  if (filters?.frequency) {
    rituals = rituals.filter((r: Ritual) => r.frequency === filters.frequency);
  }

  if (filters?.tag) {
    rituals = rituals.filter((r: Ritual) => r.tags.includes(filters.tag as string));
  }

  if (filters?.search) {
    const search = filters.search.toLowerCase();
    rituals = rituals.filter((r: Ritual) =>
      r.name.toLowerCase().includes(search) ||
      r.description.toLowerCase().includes(search) ||
      r.purpose.toLowerCase().includes(search)
    );
  }

  return rituals.sort((a: Ritual, b: Ritual) => b.createdAt.localeCompare(a.createdAt));
}

// Ceremony CRUD
export function createCeremonySequence(input: {
  name: string;
  description: string;
  ritualIds: string[];
  symbolism: string[];
  recommendedTiming: string;
  tags?: string[];
  notes?: string;
}): CeremonySequence {
  const now = new Date().toISOString();
  const ceremony: CeremonySequence = {
    id: generateId(),
    name: input.name,
    slug: generateSlug(input.name),
    description: input.description,
    ritualIds: input.ritualIds,
    symbolism: input.symbolism,
    recommendedTiming: input.recommendedTiming,
    tags: input.tags || [],
    notes: input.notes || '',
    seo: generateSEOMeta(input.name, input.description, input.tags || []),
    createdAt: now,
    updatedAt: now,
  };

  const ceremonies = getFromStorage<CeremonySequence>(STORAGE_KEYS.CEREMONIES);
  ceremonies.push(ceremony);
  saveToStorage(STORAGE_KEYS.CEREMONIES, ceremonies);

  return ceremony;
}

export function updateCeremonySequence(id: string, updates: Partial<Omit<CeremonySequence, 'id' | 'createdAt'>>): CeremonySequence | null {
  const ceremonies = getFromStorage<CeremonySequence>(STORAGE_KEYS.CEREMONIES);
  const index = ceremonies.findIndex((c: CeremonySequence) => c.id === id);
  
  if (index === -1) return null;

  const updated: CeremonySequence = {
    ...ceremonies[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };

  if (updates.name && updates.name !== ceremonies[index].name) {
    updated.slug = generateSlug(updates.name);
  }

  if (updates.name || updates.description || updates.tags) {
    updated.seo = generateSEOMeta(
      updated.name,
      updated.description,
      updated.tags
    );
  }

  ceremonies[index] = updated;
  saveToStorage(STORAGE_KEYS.CEREMONIES, ceremonies);

  return updated;
}

export function deleteCeremonySequence(id: string): boolean {
  const ceremonies = getFromStorage<CeremonySequence>(STORAGE_KEYS.CEREMONIES);
  const filtered = ceremonies.filter((c: CeremonySequence) => c.id !== id);
  
  if (filtered.length === ceremonies.length) return false;
  
  saveToStorage(STORAGE_KEYS.CEREMONIES, filtered);
  return true;
}

export function getCeremonySequence(id: string): CeremonySequence | null {
  const ceremonies = getFromStorage<CeremonySequence>(STORAGE_KEYS.CEREMONIES);
  return ceremonies.find((c: CeremonySequence) => c.id === id) || null;
}

export function listCeremonies(filters?: CeremonyFilters): CeremonySequence[] {
  let ceremonies = getFromStorage<CeremonySequence>(STORAGE_KEYS.CEREMONIES);

  if (filters?.tag) {
    ceremonies = ceremonies.filter((c: CeremonySequence) => c.tags.includes(filters.tag as string));
  }

  if (filters?.search) {
    const search = filters.search.toLowerCase();
    ceremonies = ceremonies.filter((c: CeremonySequence) =>
      c.name.toLowerCase().includes(search) ||
      c.description.toLowerCase().includes(search)
    );
  }

  return ceremonies.sort((a: CeremonySequence, b: CeremonySequence) => b.createdAt.localeCompare(a.createdAt));
}

// Cycle CRUD
export function createCycleDefinition(input: {
  name: string;
  description: string;
  phases: string[];
  phaseLengthHints: string[];
  recommendedRitualIds: string[];
  tags?: string[];
  notes?: string;
}): CycleDefinition {
  const now = new Date().toISOString();
  const cycle: CycleDefinition = {
    id: generateId(),
    name: input.name,
    slug: generateSlug(input.name),
    description: input.description,
    phases: input.phases,
    phaseLengthHints: input.phaseLengthHints,
    recommendedRitualIds: input.recommendedRitualIds,
    tags: input.tags || [],
    notes: input.notes || '',
    createdAt: now,
    updatedAt: now,
  };

  const cycles = getFromStorage<CycleDefinition>(STORAGE_KEYS.CYCLES);
  cycles.push(cycle);
  saveToStorage(STORAGE_KEYS.CYCLES, cycles);

  return cycle;
}

export function updateCycleDefinition(id: string, updates: Partial<Omit<CycleDefinition, 'id' | 'createdAt'>>): CycleDefinition | null {
  const cycles = getFromStorage<CycleDefinition>(STORAGE_KEYS.CYCLES);
  const index = cycles.findIndex((c: CycleDefinition) => c.id === id);
  
  if (index === -1) return null;

  const updated: CycleDefinition = {
    ...cycles[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };

  if (updates.name && updates.name !== cycles[index].name) {
    updated.slug = generateSlug(updates.name);
  }

  cycles[index] = updated;
  saveToStorage(STORAGE_KEYS.CYCLES, cycles);

  return updated;
}

export function deleteCycleDefinition(id: string): boolean {
  const cycles = getFromStorage<CycleDefinition>(STORAGE_KEYS.CYCLES);
  const filtered = cycles.filter((c: CycleDefinition) => c.id !== id);
  
  if (filtered.length === cycles.length) return false;
  
  saveToStorage(STORAGE_KEYS.CYCLES, filtered);
  return true;
}

export function getCycleDefinition(id: string): CycleDefinition | null {
  const cycles = getFromStorage<CycleDefinition>(STORAGE_KEYS.CYCLES);
  return cycles.find((c: CycleDefinition) => c.id === id) || null;
}

export function listCycles(filters?: CycleFilters): CycleDefinition[] {
  let cycles = getFromStorage<CycleDefinition>(STORAGE_KEYS.CYCLES);

  if (filters?.tag) {
    cycles = cycles.filter((c: CycleDefinition) => c.tags.includes(filters.tag as string));
  }

  if (filters?.search) {
    const search = filters.search.toLowerCase();
    cycles = cycles.filter((c: CycleDefinition) =>
      c.name.toLowerCase().includes(search) ||
      c.description.toLowerCase().includes(search)
    );
  }

  return cycles.sort((a: CycleDefinition, b: CycleDefinition) => b.createdAt.localeCompare(a.createdAt));
}

// Initiation Path CRUD
export function createInitiationPath(input: {
  name: string;
  description: string;
  personaArchetypes: string[];
  milestones: string[];
  ritualIds: string[];
  symbolicRewards: string[];
  recommendedNextPaths: string[];
  tags?: string[];
  notes?: string;
}): InitiationPath {
  const now = new Date().toISOString();
  const path: InitiationPath = {
    id: generateId(),
    name: input.name,
    slug: generateSlug(input.name),
    description: input.description,
    personaArchetypes: input.personaArchetypes,
    milestones: input.milestones,
    ritualIds: input.ritualIds,
    symbolicRewards: input.symbolicRewards,
    recommendedNextPaths: input.recommendedNextPaths,
    tags: input.tags || [],
    notes: input.notes || '',
    createdAt: now,
    updatedAt: now,
  };

  const paths = getFromStorage<InitiationPath>(STORAGE_KEYS.INITIATIONS);
  paths.push(path);
  saveToStorage(STORAGE_KEYS.INITIATIONS, paths);

  return path;
}

export function updateInitiationPath(id: string, updates: Partial<Omit<InitiationPath, 'id' | 'createdAt'>>): InitiationPath | null {
  const paths = getFromStorage<InitiationPath>(STORAGE_KEYS.INITIATIONS);
  const index = paths.findIndex((p: InitiationPath) => p.id === id);
  
  if (index === -1) return null;

  const updated: InitiationPath = {
    ...paths[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };

  if (updates.name && updates.name !== paths[index].name) {
    updated.slug = generateSlug(updates.name);
  }

  paths[index] = updated;
  saveToStorage(STORAGE_KEYS.INITIATIONS, paths);

  return updated;
}

export function deleteInitiationPath(id: string): boolean {
  const paths = getFromStorage<InitiationPath>(STORAGE_KEYS.INITIATIONS);
  const filtered = paths.filter((p: InitiationPath) => p.id !== id);
  
  if (filtered.length === paths.length) return false;
  
  saveToStorage(STORAGE_KEYS.INITIATIONS, filtered);
  return true;
}

export function getInitiationPath(id: string): InitiationPath | null {
  const paths = getFromStorage<InitiationPath>(STORAGE_KEYS.INITIATIONS);
  return paths.find((p: InitiationPath) => p.id === id) || null;
}

export function listInitiationPaths(filters?: InitiationFilters): InitiationPath[] {
  let paths = getFromStorage<InitiationPath>(STORAGE_KEYS.INITIATIONS);

  if (filters?.personaArchetype) {
    paths = paths.filter((p: InitiationPath) => 
      p.personaArchetypes.includes(filters.personaArchetype as string)
    );
  }

  if (filters?.tag) {
    paths = paths.filter((p: InitiationPath) => p.tags.includes(filters.tag as string));
  }

  if (filters?.search) {
    const search = filters.search.toLowerCase();
    paths = paths.filter((p: InitiationPath) =>
      p.name.toLowerCase().includes(search) ||
      p.description.toLowerCase().includes(search)
    );
  }

  return paths.sort((a: InitiationPath, b: InitiationPath) => b.createdAt.localeCompare(a.createdAt));
}

// Symbolic Object CRUD
export function createSymbolicObject(input: {
  name: string;
  description: string;
  meaning: string[];
  usedInRitualIds: string[];
  usedInCycleIds: string[];
  tags?: string[];
  notes?: string;
}): SymbolicObject {
  const now = new Date().toISOString();
  const object: SymbolicObject = {
    id: generateId(),
    name: input.name,
    slug: generateSlug(input.name),
    description: input.description,
    meaning: input.meaning,
    usedInRitualIds: input.usedInRitualIds,
    usedInCycleIds: input.usedInCycleIds,
    tags: input.tags || [],
    notes: input.notes || '',
    createdAt: now,
    updatedAt: now,
  };

  const objects = getFromStorage<SymbolicObject>(STORAGE_KEYS.SYMBOLIC_OBJECTS);
  objects.push(object);
  saveToStorage(STORAGE_KEYS.SYMBOLIC_OBJECTS, objects);

  return object;
}

export function updateSymbolicObject(id: string, updates: Partial<Omit<SymbolicObject, 'id' | 'createdAt'>>): SymbolicObject | null {
  const objects = getFromStorage<SymbolicObject>(STORAGE_KEYS.SYMBOLIC_OBJECTS);
  const index = objects.findIndex((o: SymbolicObject) => o.id === id);
  
  if (index === -1) return null;

  const updated: SymbolicObject = {
    ...objects[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };

  if (updates.name && updates.name !== objects[index].name) {
    updated.slug = generateSlug(updates.name);
  }

  objects[index] = updated;
  saveToStorage(STORAGE_KEYS.SYMBOLIC_OBJECTS, objects);

  return updated;
}

export function deleteSymbolicObject(id: string): boolean {
  const objects = getFromStorage<SymbolicObject>(STORAGE_KEYS.SYMBOLIC_OBJECTS);
  const filtered = objects.filter((o: SymbolicObject) => o.id !== id);
  
  if (filtered.length === objects.length) return false;
  
  saveToStorage(STORAGE_KEYS.SYMBOLIC_OBJECTS, filtered);
  return true;
}

export function getSymbolicObject(id: string): SymbolicObject | null {
  const objects = getFromStorage<SymbolicObject>(STORAGE_KEYS.SYMBOLIC_OBJECTS);
  return objects.find((o: SymbolicObject) => o.id === id) || null;
}

export function listSymbolicObjects(filters?: SymbolicObjectFilters): SymbolicObject[] {
  let objects = getFromStorage<SymbolicObject>(STORAGE_KEYS.SYMBOLIC_OBJECTS);

  if (filters?.tag) {
    objects = objects.filter((o: SymbolicObject) => o.tags.includes(filters.tag as string));
  }

  if (filters?.search) {
    const search = filters.search.toLowerCase();
    objects = objects.filter((o: SymbolicObject) =>
      o.name.toLowerCase().includes(search) ||
      o.description.toLowerCase().includes(search)
    );
  }

  return objects.sort((a: SymbolicObject, b: SymbolicObject) => b.createdAt.localeCompare(a.createdAt));
}

// Ritual Event Log CRUD
export function recordRitualEvent(input: {
  ritualId: string;
  participants: string[];
  notes: string;
}): RitualEventLog {
  const now = new Date().toISOString();
  const event: RitualEventLog = {
    id: generateId(),
    ritualId: input.ritualId,
    timestamp: now,
    participants: input.participants,
    notes: input.notes,
    createdAt: now,
  };

  const events = getFromStorage<RitualEventLog>(STORAGE_KEYS.EVENT_LOGS);
  events.push(event);
  saveToStorage(STORAGE_KEYS.EVENT_LOGS, events);

  return event;
}

export function updateRitualEvent(id: string, updates: Partial<Omit<RitualEventLog, 'id' | 'createdAt' | 'timestamp'>>): RitualEventLog | null {
  const events = getFromStorage<RitualEventLog>(STORAGE_KEYS.EVENT_LOGS);
  const index = events.findIndex((e: RitualEventLog) => e.id === id);
  
  if (index === -1) return null;

  const updated: RitualEventLog = {
    ...events[index],
    ...updates,
  };

  events[index] = updated;
  saveToStorage(STORAGE_KEYS.EVENT_LOGS, events);

  return updated;
}

export function deleteRitualEvent(id: string): boolean {
  const events = getFromStorage<RitualEventLog>(STORAGE_KEYS.EVENT_LOGS);
  const filtered = events.filter((e: RitualEventLog) => e.id !== id);
  
  if (filtered.length === events.length) return false;
  
  saveToStorage(STORAGE_KEYS.EVENT_LOGS, filtered);
  return true;
}

export function getRitualEvent(id: string): RitualEventLog | null {
  const events = getFromStorage<RitualEventLog>(STORAGE_KEYS.EVENT_LOGS);
  return events.find((e: RitualEventLog) => e.id === id) || null;
}

export function listRitualEvents(filters?: RitualEventFilters): RitualEventLog[] {
  let events = getFromStorage<RitualEventLog>(STORAGE_KEYS.EVENT_LOGS);

  if (filters?.ritualId) {
    events = events.filter((e: RitualEventLog) => e.ritualId === filters.ritualId);
  }

  if (filters?.participant) {
    events = events.filter((e: RitualEventLog) => 
      e.participants.some((p: string) => p.toLowerCase().includes(filters.participant?.toLowerCase() as string))
    );
  }

  if (filters?.dateFrom) {
    events = events.filter((e: RitualEventLog) => e.timestamp >= (filters.dateFrom as string));
  }

  if (filters?.dateTo) {
    events = events.filter((e: RitualEventLog) => e.timestamp <= (filters.dateTo as string));
  }

  return events.sort((a: RitualEventLog, b: RitualEventLog) => b.timestamp.localeCompare(a.timestamp));
}
