// DreamNet Rituals, Cycles & Ceremonies Engine - Enhanced Type Definitions

export type RitualType = 
  | "ceremony"
  | "practice"
  | "signal"
  | "celebration"
  | "transition"
  | "reset"
  | "initiation"
  | "completion"
  | "other";

export type Domain =
  | "culture"
  | "drops"
  | "ops"
  | "social"
  | "pickleball"
  | "agents"
  | "identity"
  | "world";

export type Frequency =
  | "daily"
  | "weekly"
  | "monthly"
  | "seasonal"
  | "per-event"
  | "rare"
  | "custom";

// Enhancement #2: Ritual Grammar / Pattern Language
export type RitualArchetype =
  | "blessing"
  | "challenge"
  | "transition"
  | "celebration"
  | "mourning"
  | "invocation"
  | "release"
  | "transformation";

export type RitualBlock =
  | "opening"
  | "invocation"
  | "exchange"
  | "transformation"
  | "witness"
  | "release"
  | "closing";

export interface RitualGrammar {
  archetype: RitualArchetype;
  blocks: RitualBlock[];
  allowedDomainMix: boolean; // Can mix domains?
}

// Enhancement #3: Participant Roles & Permissions
export interface ParticipantRole {
  name: string; // "Host", "Witness", "Initiate", "Guardian"
  responsibilities: string[];
  requiredInitiations: string[]; // IDs of initiation paths required
  maxParticipants: number;
  minParticipants: number;
}

// Enhancement #8: Sensory Ritual Templates
export interface SensoryElements {
  soundscape?: string; // URL or description
  lighting?: string; // "candlelight", "sunrise", "strobe"
  scent?: string; // "incense", "coffee", "fresh air"
  tactile?: string; // "hold stones", "pass object"
  taste?: string; // "shared meal", "ceremonial drink"
}

export interface SEOMeta {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export interface Ritual {
  id: string;
  name: string;
  slug: string;
  description: string;
  ritualType: RitualType;
  domain: Domain;
  purpose: string;
  steps: string[];
  symbolism: string[];
  frequency: Frequency;
  conditions: string[];
  relatedLore: string[];
  relatedObjects: string[];
  recommendedApps: string[];
  recommendedAgents: string[];
  tags: string[];
  notes: string;
  seo: SEOMeta;
  createdAt: string;
  updatedAt: string;
  
  // Enhancement #2: Ritual Grammar
  grammar?: RitualGrammar;
  
  // Enhancement #3: Participant Roles
  roles?: ParticipantRole[];
  
  // Enhancement #7: Cross-Ritual Dependencies
  prerequisites?: string[]; // Ritual IDs that must be completed first
  unlocks?: string[]; // Ritual IDs that this unlocks
  
  // Enhancement #8: Sensory Elements
  sensoryElements?: SensoryElements;
  
  // Enhancement #6: Ritual Forking & Remixing
  forkedFrom?: string; // ID of original ritual
  forkCount?: number; // Number of times this has been forked
  isCanonical?: boolean; // Is this the canonical version?
  version?: number;
  
  // Enhancement #9: Scheduling
  nextScheduledDate?: string; // When this ritual should occur next
  
  // Enhancement #4: Analytics
  participationCount?: number; // Total times performed
  lastPerformed?: string; // Last event timestamp
  avgParticipants?: number; // Average number of participants
  sentiment?: number; // 1-5 rating from events
}

export interface CeremonySequence {
  id: string;
  name: string;
  slug: string;
  description: string;
  ritualIds: string[];
  symbolism: string[];
  recommendedTiming: string;
  tags: string[];
  notes: string;
  seo: SEOMeta;
  createdAt: string;
  updatedAt: string;
  
  // Enhancement #5: Simulation
  estimatedDuration?: string; // "2 hours", "30 minutes"
  preparationChecklist?: string[]; // What to prepare before ceremony
  
  // Enhancement #6: Forking
  forkedFrom?: string;
  version?: number;
}

export interface CycleDefinition {
  id: string;
  name: string;
  slug: string;
  description: string;
  phases: string[];
  phaseLengthHints: string[];
  recommendedRitualIds: string[];
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
  
  // Enhancement #1: Calendar Integration
  currentPhase?: string; // Which phase are we in now?
  phaseStartDate?: string; // When current phase started
  cycleDomain?: Domain; // Primary domain for this cycle
}

export interface InitiationPath {
  id: string;
  name: string;
  slug: string;
  description: string;
  personaArchetypes: string[];
  milestones: string[];
  ritualIds: string[];
  symbolicRewards: string[];
  recommendedNextPaths: string[];
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
  
  // Enhancement #4: Analytics
  completionRate?: number; // % of people who complete this path
  avgTimeToComplete?: string; // "3 weeks"
}

export interface SymbolicObject {
  id: string;
  name: string;
  slug: string;
  description: string;
  meaning: string[];
  usedInRitualIds: string[];
  usedInCycleIds: string[];
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
  
  // Enhancement #12: Memory Palace
  imageUrl?: string; // Visual representation
  historicalSignificance?: string; // Why this object matters
}

export interface RitualEventLog {
  id: string;
  ritualId: string;
  timestamp: string;
  participants: string[];
  notes: string;
  createdAt: string;
  
  // Enhancement #4: Analytics
  sentiment?: number; // 1-5 rating
  duration?: string; // How long it took
  
  // Enhancement #12: Archive / Memory Palace
  mediaUrls?: string[]; // Photos, videos, recordings
  location?: string; // Where it happened
  weather?: string; // Atmospheric notes
  specialMoments?: string[]; // Memorable highlights
  artifactsCreated?: string[]; // What was produced/created
}

export interface RitualFilters {
  domain?: Domain;
  ritualType?: RitualType;
  frequency?: Frequency;
  tag?: string;
  search?: string;
  archetype?: RitualArchetype;
  hasPrerequisites?: boolean;
}

export interface CeremonyFilters {
  tag?: string;
  search?: string;
}

export interface CycleFilters {
  tag?: string;
  search?: string;
  domain?: Domain;
  currentPhase?: string;
}

export interface InitiationFilters {
  personaArchetype?: string;
  tag?: string;
  search?: string;
}

export interface SymbolicObjectFilters {
  tag?: string;
  search?: string;
}

export interface RitualEventFilters {
  ritualId?: string;
  participant?: string;
  dateFrom?: string;
  dateTo?: string;
  minSentiment?: number;
}

// Enhancement #4: Ritual Health Analytics
export interface RitualHealthMetrics {
  ritualId: string;
  ritualName: string;
  domain: Domain;
  vitality: number; // 0-100 score
  trend: 'growing' | 'stable' | 'declining' | 'dead';
  lastPerformed: string | null;
  daysSinceLastPerformance: number;
  totalPerformances: number;
  avgParticipants: number;
  avgSentiment: number;
  frequency: Frequency;
  recommendedAction: string;
}

export interface CulturalVitalityScore {
  domain: Domain;
  score: number; // 0-100
  activeRituals: number;
  totalRituals: number;
  recentEvents: number;
  trend: 'up' | 'down' | 'stable';
}

// Enhancement #9: Notifications
export interface RitualNotification {
  id: string;
  type: 'upcoming' | 'reminder' | 'milestone' | 'invitation' | 'anniversary';
  ritualId?: string;
  message: string;
  scheduledFor: string;
  sent: boolean;
  priority: 'low' | 'medium' | 'high';
}

// Enhancement #10: AI Suggestions
export interface AIRitualSuggestion {
  id: string;
  suggestedName: string;
  suggestedType: RitualType;
  suggestedDomain: Domain;
  rationale: string;
  priority: number;
  basedOn: string[]; // IDs of rituals/gaps that informed this
}

// Enhancement #11: Export Formats
export type ExportFormat = 
  | "json"
  | "txt"
  | "markdown"
  | "ics" // Calendar
  | "notion"
  | "csv";

// Enhancement #1: Calendar Event
export interface CalendarEvent {
  id: string;
  ritualId?: string;
  ceremonyId?: string;
  cycleId?: string;
  date: string; // ISO date
  title: string;
  description: string;
  domain: Domain;
  type: 'ritual' | 'ceremony' | 'cycle-phase' | 'anniversary';
  color: string; // Hex color
}
