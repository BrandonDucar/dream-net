use spacetimedb::{table, reducer, ReducerContext, Table};

// --- Table Definitions ---

#[table(name = content_ref, public)]
#[derive(Clone)]
pub struct ContentRef {
    #[primary_key]
    id: String,
    content_type: String,
    ref_id: Option<String>,
    name: String,
    primary_emoji: Option<String>,
    chain: Option<String>,
    category: String,
}

#[table(name = script_variant, public)]
#[derive(Clone)]
pub struct ScriptVariant {
    #[primary_key]
    id: String,
    #[index(btree)]
    content_ref_id: String,
    channel: String,
    style: String,
    length: String,
    body: String,
    thread_parts: String,
    call_to_action: Option<String>,
    notes: String,
    status: String,
    seo_title: String,
    seo_description: String,
    seo_keywords: String,
    seo_hashtags: String,
    alt_text: String,
    primary_geo_targets: String,
    body_localized: String,
    tags_localized: String,
    // crypto-native optional fields
    vibe_mode: Option<String>,
    frame_button_text: Option<String>,
    frame_aspect_ratio: Option<String>,
    onchain_stats: Option<String>,
    market_timing_hint: Option<String>,
}

#[table(name = crypto_template, public)]
#[derive(Clone)]
pub struct CryptoTemplate {
    #[primary_key]
    id: String,
    name: String,
    template_type: String,
    vibe_mode: String,
    template_body: String,
    suggested_channels: String,
}

#[table(name = performance_metric, public)]
#[derive(Clone)]
pub struct PerformanceMetric {
    #[primary_key]
    id: String,
    #[index(btree)]
    script_variant_id: String,
    engagement_score: i64,
    best_channel: String,
    notes: String,
}

// --- Reducers: ContentRef ---

#[reducer]
pub fn create_content_ref(
    ctx: &ReducerContext,
    id: String,
    content_type: String,
    ref_id: Option<String>,
    name: String,
    primary_emoji: Option<String>,
    chain: Option<String>,
    category: String,
) -> Result<(), String> {
    if ctx.db.content_ref().id().find(&id).is_some() {
        let msg = format!("ContentRef with id '{}' already exists", id);
        spacetimedb::log::warn!("{}", msg);
        return Err(msg);
    }

    let row = ContentRef {
        id: id.clone(),
        content_type,
        ref_id,
        name,
        primary_emoji,
        chain,
        category,
    };

    match ctx.db.content_ref().try_insert(row) {
        Ok(_) => {
            spacetimedb::log::info!("Created ContentRef '{}'", id);
            Ok(())
        }
        Err(e) => {
            let msg = format!("Failed to insert ContentRef '{}': {}", id, e);
            spacetimedb::log::error!("{}", msg);
            Err(msg)
        }
    }
}

#[reducer]
pub fn update_content_ref(
    ctx: &ReducerContext,
    id: String,
    content_type: String,
    ref_id: Option<String>,
    name: String,
    primary_emoji: Option<String>,
    chain: Option<String>,
    category: String,
) -> Result<(), String> {
    if let Some(mut row) = ctx.db.content_ref().id().find(&id) {
        row.content_type = content_type;
        row.ref_id = ref_id;
        row.name = name;
        row.primary_emoji = primary_emoji;
        row.chain = chain;
        row.category = category;

        let log_id = row.id.clone();
        ctx.db.content_ref().id().update(row);
        spacetimedb::log::info!("Updated ContentRef '{}'", log_id);
        Ok(())
    } else {
        let msg = format!("ContentRef with id '{}' not found", id);
        spacetimedb::log::warn!("{}", msg);
        Err(msg)
    }
}

#[reducer]
pub fn delete_content_ref(ctx: &ReducerContext, id: String) -> Result<(), String> {
    if ctx.db.content_ref().id().find(&id).is_some() {
        ctx.db.content_ref().id().delete(&id);
        spacetimedb::log::info!("Deleted ContentRef '{}'", id);
        Ok(())
    } else {
        let msg = format!("ContentRef with id '{}' not found", id);
        spacetimedb::log::warn!("{}", msg);
        Err(msg)
    }
}

// --- Reducers: ScriptVariant ---

#[reducer]
pub fn create_script_variant(
    ctx: &ReducerContext,
    id: String,
    content_ref_id: String,
    channel: String,
    style: String,
    length: String,
    body: String,
    thread_parts: String,
    call_to_action: Option<String>,
    notes: String,
    status: String,
    seo_title: String,
    seo_description: String,
    seo_keywords: String,
    seo_hashtags: String,
    alt_text: String,
    primary_geo_targets: String,
    body_localized: String,
    tags_localized: String,
    vibe_mode: Option<String>,
    frame_button_text: Option<String>,
    frame_aspect_ratio: Option<String>,
    onchain_stats: Option<String>,
    market_timing_hint: Option<String>,
) -> Result<(), String> {
    if ctx.db.script_variant().id().find(&id).is_some() {
        let msg = format!("ScriptVariant with id '{}' already exists", id);
        spacetimedb::log::warn!("{}", msg);
        return Err(msg);
    }

    if ctx.db.content_ref().id().find(&content_ref_id).is_none() {
        let msg = format!("ContentRef '{}' not found for ScriptVariant '{}'", content_ref_id, id);
        spacetimedb::log::warn!("{}", msg);
        return Err(msg);
    }

    let row = ScriptVariant {
        id: id.clone(),
        content_ref_id,
        channel,
        style,
        length,
        body,
        thread_parts,
        call_to_action,
        notes,
        status,
        seo_title,
        seo_description,
        seo_keywords,
        seo_hashtags,
        alt_text,
        primary_geo_targets,
        body_localized,
        tags_localized,
        vibe_mode,
        frame_button_text,
        frame_aspect_ratio,
        onchain_stats,
        market_timing_hint,
    };

    match ctx.db.script_variant().try_insert(row) {
        Ok(_) => {
            spacetimedb::log::info!("Created ScriptVariant '{}'", id);
            Ok(())
        }
        Err(e) => {
            let msg = format!("Failed to insert ScriptVariant '{}': {}", id, e);
            spacetimedb::log::error!("{}", msg);
            Err(msg)
        }
    }
}

#[reducer]
pub fn update_script_variant(
    ctx: &ReducerContext,
    id: String,
    content_ref_id: String,
    channel: String,
    style: String,
    length: String,
    body: String,
    thread_parts: String,
    call_to_action: Option<String>,
    notes: String,
    status: String,
    seo_title: String,
    seo_description: String,
    seo_keywords: String,
    seo_hashtags: String,
    alt_text: String,
    primary_geo_targets: String,
    body_localized: String,
    tags_localized: String,
    vibe_mode: Option<String>,
    frame_button_text: Option<String>,
    frame_aspect_ratio: Option<String>,
    onchain_stats: Option<String>,
    market_timing_hint: Option<String>,
) -> Result<(), String> {
    if ctx.db.content_ref().id().find(&content_ref_id).is_none() {
        let msg = format!("ContentRef '{}' not found for ScriptVariant '{}'", content_ref_id, id);
        spacetimedb::log::warn!("{}", msg);
        return Err(msg);
    }

    if let Some(mut row) = ctx.db.script_variant().id().find(&id) {
        row.content_ref_id = content_ref_id;
        row.channel = channel;
        row.style = style;
        row.length = length;
        row.body = body;
        row.thread_parts = thread_parts;
        row.call_to_action = call_to_action;
        row.notes = notes;
        row.status = status;
        row.seo_title = seo_title;
        row.seo_description = seo_description;
        row.seo_keywords = seo_keywords;
        row.seo_hashtags = seo_hashtags;
        row.alt_text = alt_text;
        row.primary_geo_targets = primary_geo_targets;
        row.body_localized = body_localized;
        row.tags_localized = tags_localized;
        row.vibe_mode = vibe_mode;
        row.frame_button_text = frame_button_text;
        row.frame_aspect_ratio = frame_aspect_ratio;
        row.onchain_stats = onchain_stats;
        row.market_timing_hint = market_timing_hint;

        let log_id = row.id.clone();
        ctx.db.script_variant().id().update(row);
        spacetimedb::log::info!("Updated ScriptVariant '{}'", log_id);
        Ok(())
    } else {
        let msg = format!("ScriptVariant with id '{}' not found", id);
        spacetimedb::log::warn!("{}", msg);
        Err(msg)
    }
}

#[reducer]
pub fn delete_script_variant(ctx: &ReducerContext, id: String) -> Result<(), String> {
    if ctx.db.script_variant().id().find(&id).is_some() {
        ctx.db.script_variant().id().delete(&id);
        spacetimedb::log::info!("Deleted ScriptVariant '{}'", id);
        Ok(())
    } else {
        let msg = format!("ScriptVariant with id '{}' not found", id);
        spacetimedb::log::warn!("{}", msg);
        Err(msg)
    }
}

#[reducer]
pub fn update_script_status(ctx: &ReducerContext, id: String, status: String) -> Result<(), String> {
    if let Some(mut row) = ctx.db.script_variant().id().find(&id) {
        row.status = status.clone();
        let log_id = row.id.clone();
        ctx.db.script_variant().id().update(row);
        spacetimedb::log::info!("Updated ScriptVariant '{}' status to '{}'", log_id, status);
        Ok(())
    } else {
        let msg = format!("ScriptVariant with id '{}' not found", id);
        spacetimedb::log::warn!("{}", msg);
        Err(msg)
    }
}

// Update only crypto-specific fields if provided; leave others unchanged
#[reducer]
pub fn update_script_variant_crypto_fields(
    ctx: &ReducerContext,
    id: String,
    vibe_mode: Option<String>,
    frame_button_text: Option<String>,
    frame_aspect_ratio: Option<String>,
    onchain_stats: Option<String>,
    market_timing_hint: Option<String>,
) -> Result<(), String> {
    if let Some(mut row) = ctx.db.script_variant().id().find(&id) {
        if let Some(v) = vibe_mode {
            row.vibe_mode = Some(v);
        }
        if let Some(v) = frame_button_text {
            row.frame_button_text = Some(v);
        }
        if let Some(v) = frame_aspect_ratio {
            row.frame_aspect_ratio = Some(v);
        }
        if let Some(v) = onchain_stats {
            row.onchain_stats = Some(v);
        }
        if let Some(v) = market_timing_hint {
            row.market_timing_hint = Some(v);
        }

        let log_id = row.id.clone();
        ctx.db.script_variant().id().update(row);
        spacetimedb::log::info!("Updated ScriptVariant '{}' crypto fields", log_id);
        Ok(())
    } else {
        let msg = format!("ScriptVariant with id '{}' not found", id);
        spacetimedb::log::warn!("{}", msg);
        Err(msg)
    }
}

// --- Reducers: CryptoTemplate ---

#[reducer]
pub fn create_crypto_template(
    ctx: &ReducerContext,
    id: String,
    name: String,
    template_type: String,
    vibe_mode: String,
    template_body: String,
    suggested_channels: String,
) -> Result<(), String> {
    if ctx.db.crypto_template().id().find(&id).is_some() {
        let msg = format!("CryptoTemplate with id '{}' already exists", id);
        spacetimedb::log::warn!("{}", msg);
        return Err(msg);
    }

    let row = CryptoTemplate {
        id: id.clone(),
        name,
        template_type,
        vibe_mode,
        template_body,
        suggested_channels,
    };

    match ctx.db.crypto_template().try_insert(row) {
        Ok(_) => {
            spacetimedb::log::info!("Created CryptoTemplate '{}'", id);
            Ok(())
        }
        Err(e) => {
            let msg = format!("Failed to insert CryptoTemplate '{}': {}", id, e);
            spacetimedb::log::error!("{}", msg);
            Err(msg)
        }
    }
}

#[reducer]
pub fn update_crypto_template(
    ctx: &ReducerContext,
    id: String,
    name: String,
    template_type: String,
    vibe_mode: String,
    template_body: String,
    suggested_channels: String,
) -> Result<(), String> {
    if let Some(mut row) = ctx.db.crypto_template().id().find(&id) {
        row.name = name;
        row.template_type = template_type;
        row.vibe_mode = vibe_mode;
        row.template_body = template_body;
        row.suggested_channels = suggested_channels;

        let log_id = row.id.clone();
        ctx.db.crypto_template().id().update(row);
        spacetimedb::log::info!("Updated CryptoTemplate '{}'", log_id);
        Ok(())
    } else {
        let msg = format!("CryptoTemplate with id '{}' not found", id);
        spacetimedb::log::warn!("{}", msg);
        Err(msg)
    }
}

#[reducer]
pub fn delete_crypto_template(ctx: &ReducerContext, id: String) -> Result<(), String> {
    if ctx.db.crypto_template().id().find(&id).is_some() {
        ctx.db.crypto_template().id().delete(&id);
        spacetimedb::log::info!("Deleted CryptoTemplate '{}'", id);
        Ok(())
    } else {
        let msg = format!("CryptoTemplate with id '{}' not found", id);
        spacetimedb::log::warn!("{}", msg);
        Err(msg)
    }
}

// --- Reducers: PerformanceMetric ---

#[reducer]
pub fn create_performance_metric(
    ctx: &ReducerContext,
    id: String,
    script_variant_id: String,
    engagement_score: i64,
    best_channel: String,
    notes: String,
) -> Result<(), String> {
    if ctx.db.performance_metric().id().find(&id).is_some() {
        let msg = format!("PerformanceMetric with id '{}' already exists", id);
        spacetimedb::log::warn!("{}", msg);
        return Err(msg);
    }

    if ctx.db.script_variant().id().find(&script_variant_id).is_none() {
        let msg = format!(
            "ScriptVariant '{}' not found for PerformanceMetric '{}'",
            script_variant_id, id
        );
        spacetimedb::log::warn!("{}", msg);
        return Err(msg);
    }

    let row = PerformanceMetric {
        id: id.clone(),
        script_variant_id,
        engagement_score,
        best_channel,
        notes,
    };

    match ctx.db.performance_metric().try_insert(row) {
        Ok(_) => {
            spacetimedb::log::info!("Created PerformanceMetric '{}'", id);
            Ok(())
        }
        Err(e) => {
            let msg = format!("Failed to insert PerformanceMetric '{}': {}", id, e);
            spacetimedb::log::error!("{}", msg);
            Err(msg)
        }
    }
}

#[reducer]
pub fn update_performance_metric(
    ctx: &ReducerContext,
    id: String,
    script_variant_id: String,
    engagement_score: i64,
    best_channel: String,
    notes: String,
) -> Result<(), String> {
    if ctx.db.script_variant().id().find(&script_variant_id).is_none() {
        let msg = format!(
            "ScriptVariant '{}' not found for PerformanceMetric '{}'",
            script_variant_id, id
        );
        spacetimedb::log::warn!("{}", msg);
        return Err(msg);
    }

    if let Some(mut row) = ctx.db.performance_metric().id().find(&id) {
        row.script_variant_id = script_variant_id;
        row.engagement_score = engagement_score;
        row.best_channel = best_channel;
        row.notes = notes;

        let log_id = row.id.clone();
        ctx.db.performance_metric().id().update(row);
        spacetimedb::log::info!("Updated PerformanceMetric '{}'", log_id);
        Ok(())
    } else {
        let msg = format!("PerformanceMetric with id '{}' not found", id);
        spacetimedb::log::warn!("{}", msg);
        Err(msg)
    }
}

#[reducer]
pub fn delete_performance_metric(ctx: &ReducerContext, id: String) -> Result<(), String> {
    if ctx.db.performance_metric().id().find(&id).is_some() {
        ctx.db.performance_metric().id().delete(&id);
        spacetimedb::log::info!("Deleted PerformanceMetric '{}'", id);
        Ok(())
    } else {
        let msg = format!("PerformanceMetric with id '{}' not found", id);
        spacetimedb::log::warn!("{}", msg);
        Err(msg)
    }
}