'use client'
import { useState, useEffect } from 'react';
import { useLocalData } from '../hooks/useLocalData';
import { ContentRefDashboardEnhanced } from '../components/ContentRefDashboardEnhanced';
import { ContentRefDetail } from '../components/ContentRefDetail';
import { ScriptDetail } from '../components/ScriptDetail';
import { ExportScriptBundle } from '../components/ExportScriptBundle';
import { Toaster } from '../components/ui/sonner';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Home(): JSX.Element {
  const { addMiniApp } = useAddMiniApp();
  const isInFarcaster = useIsInFarcaster()
  useQuickAuth(isInFarcaster)
  useEffect(() => {
    const tryAddMiniApp = async () => {
      try {
        await addMiniApp()
      } catch (error) {
        console.error('Failed to add mini app:', error)
      }
    }

    tryAddMiniApp()
  }, [addMiniApp])
  
  useEffect(() => {
    const initializeFarcaster = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 100))
        
        if (document.readyState !== 'complete') {
          await new Promise<void>(resolve => {
            if (document.readyState === 'complete') {
              resolve()
            } else {
              window.addEventListener('load', () => resolve(), { once: true })
            }
          })
        }

        await sdk.actions.ready()
        console.log('Farcaster SDK initialized successfully - app fully loaded')
      } catch (error) {
        console.error('Failed to initialize Farcaster SDK:', error)
        
        setTimeout(async () => {
          try {
            await sdk.actions.ready()
            console.log('Farcaster SDK initialized on retry')
          } catch (retryError) {
            console.error('Farcaster SDK retry failed:', retryError)
          }
        }, 1000)
      }
    }

    initializeFarcaster()
  }, [])

  const dataState = useLocalData();
  const [selectedContentRefId, setSelectedContentRefId] = useState<string | null>(null);
  const [selectedScriptId, setSelectedScriptId] = useState<string | null>(null);
  const [exportContentRefId, setExportContentRefId] = useState<string | null>(null);

  const handleBack = (): void => {
    if (selectedScriptId) {
      setSelectedScriptId(null);
    } else if (selectedContentRefId) {
      setSelectedContentRefId(null);
    } else if (exportContentRefId) {
      setExportContentRefId(null);
    }
  };

  if (exportContentRefId) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
        <ExportScriptBundle
          contentRefId={exportContentRefId}
          contentRefs={dataState.contentRefs}
          scriptVariants={dataState.scriptVariants}
          onBack={handleBack}
        />
        <Toaster />
      </div>
    );
  }

  if (selectedScriptId) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
        <ScriptDetail
          scriptId={selectedScriptId}
          contentRefs={dataState.contentRefs}
          scriptVariants={dataState.scriptVariants}
          dataState={dataState}
          onBack={handleBack}
        />
        <Toaster />
      </div>
    );
  }

  if (selectedContentRefId) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
        <ContentRefDetail
          contentRefId={selectedContentRefId}
          contentRefs={dataState.contentRefs}
          scriptVariants={dataState.scriptVariants}
          dataState={dataState}
          onBack={handleBack}
          onSelectScript={(scriptId: string) => setSelectedScriptId(scriptId)}
        />
        <Toaster />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <ContentRefDashboardEnhanced
        contentRefs={dataState.contentRefs}
        scriptVariants={dataState.scriptVariants}
        onSelectContentRef={(id: string) => setSelectedContentRefId(id)}
        onExportBundle={(id: string) => setExportContentRefId(id)}
        dataState={dataState}
      />
      <Toaster />
    </div>
  );
}
