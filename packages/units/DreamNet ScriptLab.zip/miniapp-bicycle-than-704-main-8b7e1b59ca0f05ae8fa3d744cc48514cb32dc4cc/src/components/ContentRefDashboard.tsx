'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Plus, FileText, Download } from 'lucide-react';
import type { ContentRef } from '../spacetime_module_bindings/content_ref_type';
import type { ScriptVariant } from '../spacetime_module_bindings/script_variant_type';
import type { DbConnection } from '../spacetime_module_bindings';

const CONTENT_TYPES = [
  'token',
  'drop',
  'meme',
  'campaign',
  'agent',
  'mini-app',
  'content-stream',
  'culture-coin',
  'pickleball',
  'other',
] as const;

interface ContentRefDashboardProps {
  contentRefs: ReadonlyMap<string, ContentRef>;
  scriptVariants: ReadonlyMap<string, ScriptVariant>;
  onSelectContentRef: (id: string) => void;
  onExportBundle: (id: string) => void;
  connection: DbConnection | null;
}

export function ContentRefDashboard({
  contentRefs,
  scriptVariants,
  onSelectContentRef,
  onExportBundle,
  connection,
}: ContentRefDashboardProps): JSX.Element {
  const [filterType, setFilterType] = useState<string>('all');
  const [filterCategory, setFilterCategory] = useState<string>('');
  const [filterChain, setFilterChain] = useState<string>('');
  const [showCreateDialog, setShowCreateDialog] = useState<boolean>(false);

  const [newRef, setNewRef] = useState<{
    name: string;
    type: string;
    refId: string;
    primaryEmoji: string;
    chain: string;
    category: string;
  }>({
    name: '',
    type: 'token',
    refId: '',
    primaryEmoji: '✨',
    chain: 'Base',
    category: 'culture',
  });

  const handleCreateContentRef = (): void => {
    if (!connection || !newRef.name) return;

    const id = `ref-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    connection.reducers.createContentRef(
      id,
      newRef.type,
      newRef.refId,
      newRef.name,
      newRef.primaryEmoji,
      newRef.chain,
      newRef.category
    );

    setShowCreateDialog(false);
    setNewRef({
      name: '',
      type: 'token',
      refId: '',
      primaryEmoji: '✨',
      chain: 'Base',
      category: 'culture',
    });
  };

  const filteredRefs = Array.from(contentRefs.values()).filter((ref: ContentRef) => {
    if (filterType !== 'all' && ref.contentType !== filterType) return false;
    if (filterCategory && !ref.category.toLowerCase().includes(filterCategory.toLowerCase())) return false;
    if (filterChain && !ref.chain.toLowerCase().includes(filterChain.toLowerCase())) return false;
    return true;
  });

  const getScriptCount = (refId: string): number => {
    return Array.from(scriptVariants.values()).filter((s: ScriptVariant) => s.contentRefId === refId).length;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-black">Content References</CardTitle>
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button className="bg-black text-white hover:bg-black/90">
                  <Plus className="h-4 w-4 mr-2" />
                  New ContentRef
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-white">
                <DialogHeader>
                  <DialogTitle className="text-black">Create New ContentRef</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div>
                    <Label htmlFor="name" className="text-black">Name</Label>
                    <Input
                      id="name"
                      value={newRef.name}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewRef({ ...newRef, name: e.target.value })}
                      placeholder="My Token"
                      className="text-black"
                    />
                  </div>
                  <div>
                    <Label htmlFor="type" className="text-black">Type</Label>
                    <Select value={newRef.type} onValueChange={(value: string) => setNewRef({ ...newRef, type: value })}>
                      <SelectTrigger className="text-black">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-white">
                        {CONTENT_TYPES.map((type: string) => (
                          <SelectItem key={type} value={type} className="text-black">{type}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="category" className="text-black">Category</Label>
                    <Input
                      id="category"
                      value={newRef.category}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewRef({ ...newRef, category: e.target.value })}
                      placeholder="culture"
                      className="text-black"
                    />
                  </div>
                  <div>
                    <Label htmlFor="chain" className="text-black">Chain</Label>
                    <Input
                      id="chain"
                      value={newRef.chain}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewRef({ ...newRef, chain: e.target.value })}
                      placeholder="Base"
                      className="text-black"
                    />
                  </div>
                  <div>
                    <Label htmlFor="emoji" className="text-black">Emoji</Label>
                    <Input
                      id="emoji"
                      value={newRef.primaryEmoji}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewRef({ ...newRef, primaryEmoji: e.target.value })}
                      placeholder="✨"
                      className="text-black"
                    />
                  </div>
                  <div>
                    <Label htmlFor="refId" className="text-black">Reference ID (optional)</Label>
                    <Input
                      id="refId"
                      value={newRef.refId}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewRef({ ...newRef, refId: e.target.value })}
                      placeholder="external-id-123"
                      className="text-black"
                    />
                  </div>
                  <Button onClick={handleCreateContentRef} className="w-full bg-black text-white hover:bg-black/90">
                    Create
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div>
              <Label htmlFor="filterType" className="text-black">Filter by Type</Label>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="text-black">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white">
                  <SelectItem value="all" className="text-black">All Types</SelectItem>
                  {CONTENT_TYPES.map((type: string) => (
                    <SelectItem key={type} value={type} className="text-black">{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="filterCategory" className="text-black">Filter by Category</Label>
              <Input
                id="filterCategory"
                value={filterCategory}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFilterCategory(e.target.value)}
                placeholder="culture, prediction..."
                className="text-black"
              />
            </div>
            <div>
              <Label htmlFor="filterChain" className="text-black">Filter by Chain</Label>
              <Input
                id="filterChain"
                value={filterChain}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFilterChain(e.target.value)}
                placeholder="Base, Ethereum..."
                className="text-black"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredRefs.map((ref: ContentRef) => (
              <Card key={ref.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader>
                  <CardTitle className="text-lg text-black flex items-center gap-2">
                    <span>{ref.primaryEmoji}</span>
                    <span className="truncate">{ref.name}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline" className="text-black">{ref.contentType}</Badge>
                    <Badge variant="outline" className="text-black">{ref.category}</Badge>
                    {ref.chain && <Badge variant="outline" className="text-black">{ref.chain}</Badge>}
                  </div>
                  <p className="text-sm text-black">
                    <FileText className="h-4 w-4 inline mr-1" />
                    {getScriptCount(ref.id)} scripts
                  </p>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => onSelectContentRef(ref.id)}
                      className="flex-1 bg-black text-white hover:bg-black/90"
                    >
                      View Scripts
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onExportBundle(ref.id)}
                      className="text-black"
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredRefs.length === 0 && (
            <div className="text-center py-12 text-black">
              <p className="text-lg mb-4">No content references found</p>
              <Button onClick={() => setShowCreateDialog(true)} className="bg-black text-white hover:bg-black/90">
                <Plus className="h-4 w-4 mr-2" />
                Create Your First ContentRef
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
