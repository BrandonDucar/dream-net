'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Sparkles, Plus, FileText, Download, Filter, TrendingUp, Rocket } from 'lucide-react';
import type { ContentRef } from '../hooks/useLocalData';

const CONTENT_TYPES = [
  'token',
  'drop',
  'meme',
  'campaign',
  'agent',
  'mini-app',
  'content-stream',
  'culture-coin',
  'pickleball',
  'other',
] as const;

interface ContentRefDashboardEnhancedProps {
  contentRefs: ContentRef[];
  scriptVariants: Array<{ id: string; contentRefId: string }>;
  onSelectContentRef: (id: string) => void;
  onExportBundle: (id: string) => void;
  dataState: {
    createContentRef: (data: Omit<ContentRef, 'id' | 'createdAt'>) => ContentRef;
  };
}

export function ContentRefDashboardEnhanced({
  contentRefs,
  scriptVariants,
  onSelectContentRef,
  onExportBundle,
  dataState,
}: ContentRefDashboardEnhancedProps): JSX.Element {
  const [filterType, setFilterType] = useState<string>('all');
  const [filterCategory, setFilterCategory] = useState<string>('');
  const [filterChain, setFilterChain] = useState<string>('');
  const [showCreateDialog, setShowCreateDialog] = useState<boolean>(false);

  const [newRef, setNewRef] = useState<{
    name: string;
    type: ContentRef['type'];
    refId: string;
    primaryEmoji: string;
    chain: string;
    category: string;
  }>({
    name: '',
    type: 'token',
    refId: '',
    primaryEmoji: '✨',
    chain: 'Base',
    category: 'culture',
  });

  const handleCreateContentRef = (): void => {
    if (!newRef.name) return;

    dataState.createContentRef({
      type: newRef.type,
      refId: newRef.refId,
      name: newRef.name,
      primaryEmoji: newRef.primaryEmoji,
      chain: newRef.chain || null,
      category: newRef.category,
    });

    setShowCreateDialog(false);
    setNewRef({
      name: '',
      type: 'token',
      refId: '',
      primaryEmoji: '✨',
      chain: 'Base',
      category: 'culture',
    });
  };

  const filteredRefs = contentRefs.filter((ref: ContentRef) => {
    if (filterType !== 'all' && ref.type !== filterType) return false;
    if (filterCategory && !ref.category.toLowerCase().includes(filterCategory.toLowerCase())) return false;
    if (filterChain && ref.chain && !ref.chain.toLowerCase().includes(filterChain.toLowerCase())) return false;
    return true;
  });

  const getScriptCount = (refId: string): number => {
    return scriptVariants.filter((s) => s.contentRefId === refId).length;
  };

  const gradientColors = [
    'from-purple-100 to-pink-100',
    'from-blue-100 to-cyan-100',
    'from-green-100 to-emerald-100',
    'from-orange-100 to-red-100',
    'from-yellow-100 to-orange-100',
  ];

  return (
    <div className="space-y-6 p-6">
      <div className="bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 rounded-2xl p-8 text-white shadow-2xl">
        <div className="flex items-center gap-3 mb-2">
          <Sparkles className="w-8 h-8 animate-pulse" />
          <h1 className="text-4xl font-bold">DreamNet Threadsmith</h1>
        </div>
        <p className="text-purple-100 text-lg mb-4">Your crypto-native content lab for X, Farcaster, Zora & beyond</p>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button size="lg" className="bg-white text-purple-700 hover:bg-purple-50 shadow-lg">
              <Plus className="w-4 h-4 mr-2" />
              New Content Reference
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-purple-900">
                <Rocket className="w-5 h-5" />
                Create New Content Reference
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name" className="text-black">Name</Label>
                  <Input
                    id="name"
                    value={newRef.name}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewRef({ ...newRef, name: e.target.value })}
                    placeholder="My Token Launch"
                    className="text-black"
                  />
                </div>
                <div>
                  <Label htmlFor="emoji" className="text-black">Emoji</Label>
                  <Input
                    id="emoji"
                    value={newRef.primaryEmoji}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewRef({ ...newRef, primaryEmoji: e.target.value })}
                    placeholder="✨"
                    className="text-black text-2xl"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="type" className="text-black">Type</Label>
                  <Select value={newRef.type} onValueChange={(value: string) => setNewRef({ ...newRef, type: value as ContentRef['type'] })}>
                    <SelectTrigger className="text-black">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      {CONTENT_TYPES.map((type: string) => (
                        <SelectItem key={type} value={type} className="text-black capitalize">{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="category" className="text-black">Category</Label>
                  <Input
                    id="category"
                    value={newRef.category}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewRef({ ...newRef, category: e.target.value })}
                    placeholder="culture, DeFi, NFT..."
                    className="text-black"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="chain" className="text-black">Chain</Label>
                  <Input
                    id="chain"
                    value={newRef.chain}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewRef({ ...newRef, chain: e.target.value })}
                    placeholder="Base"
                    className="text-black"
                  />
                </div>
                <div>
                  <Label htmlFor="refId" className="text-black">Reference ID (optional)</Label>
                  <Input
                    id="refId"
                    value={newRef.refId}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewRef({ ...newRef, refId: e.target.value })}
                    placeholder="external-id-123"
                    className="text-black"
                  />
                </div>
              </div>
              <Button onClick={handleCreateContentRef} className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700">
                Create Content Reference
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-2 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-gray-800">
            <Filter className="w-5 h-5 text-purple-600" />
            Filter Content
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="filterType" className="text-black">Filter by Type</Label>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="text-black">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white">
                  <SelectItem value="all" className="text-black">All Types</SelectItem>
                  {CONTENT_TYPES.map((type: string) => (
                    <SelectItem key={type} value={type} className="text-black capitalize">{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="filterCategory" className="text-black">Filter by Category</Label>
              <Input
                id="filterCategory"
                value={filterCategory}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFilterCategory(e.target.value)}
                placeholder="culture, prediction..."
                className="text-black"
              />
            </div>
            <div>
              <Label htmlFor="filterChain" className="text-black">Filter by Chain</Label>
              <Input
                id="filterChain"
                value={filterChain}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFilterChain(e.target.value)}
                placeholder="Base, Ethereum..."
                className="text-black"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRefs.map((ref: ContentRef) => {
          const scriptCount = getScriptCount(ref.id);
          const gradient = gradientColors[ref.name.length % gradientColors.length];

          return (
            <Card
              key={ref.id}
              className="cursor-pointer hover:shadow-2xl hover:scale-105 transition-all duration-300 border-2 hover:border-purple-400 overflow-hidden group"
              onClick={() => onSelectContentRef(ref.id)}
            >
              <div className={`h-2 bg-gradient-to-r ${gradient}`} />
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-3xl group-hover:scale-110 transition-transform">{ref.primaryEmoji}</span>
                      <CardTitle className="text-xl group-hover:text-purple-700 transition-colors">{ref.name}</CardTitle>
                    </div>
                    <p className="text-sm text-gray-600 font-medium capitalize">{ref.type}</p>
                  </div>
                  <Badge className="bg-purple-100 text-purple-700 hover:bg-purple-200 border border-purple-300 flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    {scriptCount}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-300">
                      {ref.category}
                    </Badge>
                    {ref.chain && (
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300">
                        {ref.chain}
                      </Badge>
                    )}
                  </div>
                  {ref.refId && (
                    <div className="text-xs text-gray-500 truncate bg-gray-50 px-2 py-1 rounded">
                      ID: {ref.refId}
                    </div>
                  )}
                  <div className="flex gap-2 pt-2">
                    <Button
                      size="sm"
                      onClick={(e: React.MouseEvent) => {
                        e.stopPropagation();
                        onSelectContentRef(ref.id);
                      }}
                      className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700"
                    >
                      <FileText className="h-4 w-4 mr-1" />
                      Scripts
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={(e: React.MouseEvent) => {
                        e.stopPropagation();
                        onExportBundle(ref.id);
                      }}
                      className="border-purple-300 text-purple-700 hover:bg-purple-50"
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredRefs.length === 0 && (
        <div className="text-center py-20">
          <div className="text-gray-400 mb-6">
            <FileText className="w-16 h-16 mx-auto mb-4" />
            <p className="text-xl font-medium text-gray-600">No content references found</p>
            <p className="text-gray-500 mt-2">Create your first content reference to start generating scripts</p>
          </div>
          <Button onClick={() => setShowCreateDialog(true)} size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700">
            <Plus className="h-4 w-4 mr-2" />
            Create Your First ContentRef
          </Button>
        </div>
      )}
    </div>
  );
}
