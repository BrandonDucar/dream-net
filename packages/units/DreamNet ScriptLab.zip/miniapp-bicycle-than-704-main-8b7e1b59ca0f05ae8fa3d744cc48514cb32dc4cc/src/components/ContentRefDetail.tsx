'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { ArrowLeft, Sparkles, Edit2, Save, X } from 'lucide-react';
import type { ContentRef, ScriptVariant } from '../hooks/useLocalData';
import { generateEnhancedScriptVariants, type EnhancedGenerateOptions } from '../lib/enhancedScriptGenerator';
import { VibeModeSelector } from './VibeModeSelector';
import { TemplateSelector } from './TemplateSelector';

const CONTENT_TYPES = [
  'token',
  'drop',
  'meme',
  'campaign',
  'agent',
  'mini-app',
  'content-stream',
  'culture-coin',
  'pickleball',
  'other',
] as const;

interface ContentRefDetailProps {
  contentRefId: string;
  contentRefs: ContentRef[];
  scriptVariants: ScriptVariant[];
  onBack: () => void;
  onSelectScript: (scriptId: string) => void;
  dataState: {
    updateContentRef: (id: string, data: Partial<ContentRef>) => void;
    createScriptVariant: (data: Omit<ScriptVariant, 'id' | 'createdAt'>) => ScriptVariant;
  };
}

export function ContentRefDetail({
  contentRefId,
  contentRefs,
  scriptVariants,
  onBack,
  onSelectScript,
  dataState,
}: ContentRefDetailProps): JSX.Element {
  const contentRef = contentRefs.find((ref: ContentRef) => ref.id === contentRefId);
  
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editedRef, setEditedRef] = useState<{
    name: string;
    type: string;
    refId: string;
    primaryEmoji: string;
    chain: string;
    category: string;
  }>({
    name: contentRef?.name || '',
    type: contentRef?.type || 'token',
    refId: contentRef?.refId || '',
    primaryEmoji: contentRef?.primaryEmoji || '✨',
    chain: contentRef?.chain || 'Base',
    category: contentRef?.category || 'culture',
  });

  const [generateOptions, setGenerateOptions] = useState<EnhancedGenerateOptions>({
    keyAngle: '',
    priorityChannel: 'x',
    toneHints: '',
    vibeMode: 'builder',
    includeOnchainStats: false,
  });

  const [filterChannel, setFilterChannel] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  if (!contentRef) {
    return (
      <div className="text-center py-12">
        <p className="text-black">ContentRef not found</p>
        <Button onClick={onBack} className="mt-4 bg-black text-white hover:bg-black/90">
          Go Back
        </Button>
      </div>
    );
  }

  const handleSaveEdit = (): void => {
    dataState.updateContentRef(contentRefId, {
      type: editedRef.type as ContentRef['type'],
      refId: editedRef.refId,
      name: editedRef.name,
      primaryEmoji: editedRef.primaryEmoji,
      chain: editedRef.chain || null,
      category: editedRef.category,
    });

    setIsEditing(false);
  };

  const handleGenerateScripts = (): void => {
    if (!contentRef) return;

    const generated = generateEnhancedScriptVariants(contentRef, generateOptions);

    for (const script of generated) {
      dataState.createScriptVariant(script);
    }
  };

  const scriptsForRef = scriptVariants.filter((s: ScriptVariant) => s.contentRefId === contentRefId);

  const filteredScripts = scriptsForRef.filter((script: ScriptVariant) => {
    if (filterChannel !== 'all' && script.channel !== filterChannel) return false;
    if (filterStatus !== 'all' && script.status !== filterStatus) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" onClick={onBack} className="text-black">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-black flex items-center gap-2">
              <span>{contentRef.primaryEmoji}</span>
              <span>{contentRef.name}</span>
            </CardTitle>
            {!isEditing && (
              <Button variant="outline" onClick={() => setIsEditing(true)} className="text-black">
                <Edit2 className="h-4 w-4 mr-2" />
                Edit
              </Button>
            )}
            {isEditing && (
              <div className="flex gap-2">
                <Button onClick={handleSaveEdit} className="bg-black text-white hover:bg-black/90">
                  <Save className="h-4 w-4 mr-2" />
                  Save
                </Button>
                <Button variant="outline" onClick={() => setIsEditing(false)} className="text-black">
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </Button>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {!isEditing ? (
            <div className="space-y-3">
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="text-black">{contentRef.type}</Badge>
                <Badge variant="outline" className="text-black">{contentRef.category}</Badge>
                {contentRef.chain && <Badge variant="outline" className="text-black">{contentRef.chain}</Badge>}
              </div>
              {contentRef.refId && (
                <p className="text-sm text-black">Reference ID: {contentRef.refId}</p>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="editName" className="text-black">Name</Label>
                <Input
                  id="editName"
                  value={editedRef.name}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditedRef({ ...editedRef, name: e.target.value })}
                  className="text-black"
                />
              </div>
              <div>
                <Label htmlFor="editType" className="text-black">Type</Label>
                <Select value={editedRef.type} onValueChange={(value: string) => setEditedRef({ ...editedRef, type: value })}>
                  <SelectTrigger className="text-black">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white">
                    {CONTENT_TYPES.map((type: string) => (
                      <SelectItem key={type} value={type} className="text-black capitalize">{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="editCategory" className="text-black">Category</Label>
                <Input
                  id="editCategory"
                  value={editedRef.category}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditedRef({ ...editedRef, category: e.target.value })}
                  className="text-black"
                />
              </div>
              <div>
                <Label htmlFor="editChain" className="text-black">Chain</Label>
                <Input
                  id="editChain"
                  value={editedRef.chain}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditedRef({ ...editedRef, chain: e.target.value })}
                  className="text-black"
                />
              </div>
              <div>
                <Label htmlFor="editEmoji" className="text-black">Emoji</Label>
                <Input
                  id="editEmoji"
                  value={editedRef.primaryEmoji}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditedRef({ ...editedRef, primaryEmoji: e.target.value })}
                  className="text-black"
                />
              </div>
              <div>
                <Label htmlFor="editRefId" className="text-black">Reference ID</Label>
                <Input
                  id="editRefId"
                  value={editedRef.refId}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditedRef({ ...editedRef, refId: e.target.value })}
                  className="text-black"
                />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-black">Generate Script Variants</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="keyAngle" className="text-black">Key Angle (optional)</Label>
            <Input
              id="keyAngle"
              value={generateOptions.keyAngle}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setGenerateOptions({ ...generateOptions, keyAngle: e.target.value })}
              placeholder="e.g., introduce, hard shill, educational"
              className="text-black"
            />
          </div>
          <div>
            <Label htmlFor="priorityChannel" className="text-black">Priority Channel</Label>
            <Select
              value={generateOptions.priorityChannel}
              onValueChange={(value: string) => setGenerateOptions({ ...generateOptions, priorityChannel: value })}
            >
              <SelectTrigger className="text-black">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-white">
                <SelectItem value="x" className="text-black">X (Twitter)</SelectItem>
                <SelectItem value="farcaster" className="text-black">Farcaster</SelectItem>
                <SelectItem value="zora" className="text-black">Zora</SelectItem>
                <SelectItem value="base-feed" className="text-black">Base Feed</SelectItem>
                <SelectItem value="site-copy" className="text-black">Site Copy</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="toneHints" className="text-black">Tone Hints (optional)</Label>
            <Textarea
              id="toneHints"
              value={generateOptions.toneHints || ''}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setGenerateOptions({ ...generateOptions, toneHints: e.target.value })}
              placeholder="e.g., more serious, more degen, for devs"
              className="text-black"
              rows={3}
            />
          </div>
          <div>
            <Label className="text-black mb-2 block">Vibe Mode</Label>
            <VibeModeSelector
              selectedVibe={generateOptions.vibeMode || 'builder'}
              onSelectVibe={(vibe: string) => setGenerateOptions({ ...generateOptions, vibeMode: vibe as 'degen' | 'builder' | 'culture' | 'normie' | 'shitpost' })}
            />
          </div>
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="includeStats"
              checked={generateOptions.includeOnchainStats || false}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setGenerateOptions({ ...generateOptions, includeOnchainStats: e.target.checked })}
              className="rounded"
            />
            <Label htmlFor="includeStats" className="text-black cursor-pointer">Include onchain stats (simulated)</Label>
          </div>
          <Button onClick={handleGenerateScripts} className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700">
            <Sparkles className="h-4 w-4 mr-2" />
            Generate Script Variants
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-black">Script Variants ({scriptsForRef.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <Label htmlFor="filterChannelSelect" className="text-black">Filter by Channel</Label>
              <Select value={filterChannel} onValueChange={setFilterChannel}>
                <SelectTrigger className="text-black">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white">
                  <SelectItem value="all" className="text-black">All Channels</SelectItem>
                  <SelectItem value="x" className="text-black">X</SelectItem>
                  <SelectItem value="farcaster" className="text-black">Farcaster</SelectItem>
                  <SelectItem value="zora" className="text-black">Zora</SelectItem>
                  <SelectItem value="base-feed" className="text-black">Base Feed</SelectItem>
                  <SelectItem value="site-copy" className="text-black">Site Copy</SelectItem>
                  <SelectItem value="other" className="text-black">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="filterStatusSelect" className="text-black">Filter by Status</Label>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="text-black">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white">
                  <SelectItem value="all" className="text-black">All Statuses</SelectItem>
                  <SelectItem value="draft" className="text-black">Draft</SelectItem>
                  <SelectItem value="ready" className="text-black">Ready</SelectItem>
                  <SelectItem value="used" className="text-black">Used</SelectItem>
                  <SelectItem value="archived" className="text-black">Archived</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {filteredScripts.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-black">Channel</TableHead>
                  <TableHead className="text-black">Style</TableHead>
                  <TableHead className="text-black">Length</TableHead>
                  <TableHead className="text-black">Status</TableHead>
                  <TableHead className="text-black">Preview</TableHead>
                  <TableHead className="text-black">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredScripts.map((script: ScriptVariant) => (
                  <TableRow key={script.id} className="cursor-pointer hover:bg-gray-50">
                    <TableCell className="text-black">{script.channel}</TableCell>
                    <TableCell className="text-black">{script.style}</TableCell>
                    <TableCell className="text-black">{script.length}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-black">{script.status}</Badge>
                    </TableCell>
                    <TableCell className="text-black max-w-xs truncate">
                      {script.body.substring(0, 80)}...
                    </TableCell>
                    <TableCell>
                      <Button
                        size="sm"
                        onClick={() => onSelectScript(script.id)}
                        className="bg-black text-white hover:bg-black/90"
                      >
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8 text-black">
              <p>No scripts found. Generate some scripts above!</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
