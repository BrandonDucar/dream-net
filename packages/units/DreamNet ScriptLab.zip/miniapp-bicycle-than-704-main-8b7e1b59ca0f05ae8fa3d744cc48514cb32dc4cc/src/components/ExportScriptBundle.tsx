'use client';

import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { ArrowLeft, Copy, CheckCircle2 } from 'lucide-react';
import type { ContentRef, ScriptVariant } from '../hooks/useLocalData';
import { exportScriptBundle } from '../lib/scriptGenerator';
import { toast } from 'sonner';

interface ExportScriptBundleProps {
  contentRefId: string;
  contentRefs: ContentRef[];
  scriptVariants: ScriptVariant[];
  onBack: () => void;
}

export function ExportScriptBundle({
  contentRefId,
  contentRefs,
  scriptVariants,
  onBack,
}: ExportScriptBundleProps): JSX.Element {
  const contentRef = contentRefs.find((ref: ContentRef) => ref.id === contentRefId);
  const [copied, setCopied] = useState<boolean>(false);

  const scriptsForRef = useMemo(() => {
    return scriptVariants.filter((s: ScriptVariant) => s.contentRefId === contentRefId);
  }, [scriptVariants, contentRefId]);

  const exportText = useMemo(() => {
    if (!contentRef) return '';
    return exportScriptBundle(contentRef, scriptsForRef);
  }, [contentRef, scriptsForRef]);

  if (!contentRef) {
    return (
      <div className="text-center py-12">
        <p className="text-black">ContentRef not found</p>
        <Button onClick={onBack} className="mt-4 bg-black text-white hover:bg-black/90">
          Go Back
        </Button>
      </div>
    );
  }

  const handleCopyAll = (): void => {
    navigator.clipboard.writeText(exportText);
    setCopied(true);
    toast.success('Copied to clipboard');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={onBack} className="text-black">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <Button
          onClick={handleCopyAll}
          className={`${
            copied ? 'bg-green-600' : 'bg-black'
          } text-white hover:bg-black/90`}
        >
          {copied ? (
            <>
              <CheckCircle2 className="h-4 w-4 mr-2" />
              Copied!
            </>
          ) : (
            <>
              <Copy className="h-4 w-4 mr-2" />
              Copy All
            </>
          )}
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-black">
            {contentRef.primaryEmoji} Export Script Bundle: {contentRef.name}
          </CardTitle>
          <p className="text-sm text-black mt-2">
            {scriptsForRef.length} scripts ready to export
          </p>
        </CardHeader>
        <CardContent>
          <Textarea
            value={exportText}
            readOnly
            rows={30}
            className="text-black font-mono text-xs"
          />
          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
            <h4 className="font-semibold text-black mb-2">Export Instructions</h4>
            <ul className="text-sm text-black space-y-1 list-disc list-inside">
              <li>Copy the entire bundle above</li>
              <li>Paste into your content management system or docs</li>
              <li>Scripts are grouped by channel for easy reference</li>
              <li>Each script includes body, CTA, SEO metadata, and geo variants</li>
              <li>Use status field to track which scripts have been used</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
