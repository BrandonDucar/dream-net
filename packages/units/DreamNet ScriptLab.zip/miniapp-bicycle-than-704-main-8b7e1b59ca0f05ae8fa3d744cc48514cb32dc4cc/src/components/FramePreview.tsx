'use client';

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Frame } from 'lucide-react';

interface FramePreviewProps {
  body: string;
  buttonText?: string;
  aspectRatio?: string;
}

export function FramePreview({ body, buttonText, aspectRatio }: FramePreviewProps): JSX.Element {
  return (
    <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Frame className="w-5 h-5 text-purple-600" />
            <CardTitle className="text-base text-purple-900">Farcaster Frame Preview</CardTitle>
          </div>
          {aspectRatio && (
            <Badge variant="outline" className="bg-white border-purple-300 text-purple-700">
              {aspectRatio}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="bg-white p-4 rounded-lg border-2 border-purple-200 min-h-32 flex items-center justify-center text-center">
          <div className="text-sm text-gray-700 whitespace-pre-wrap">{body}</div>
        </div>
        {buttonText && (
          <div className="flex justify-center">
            <button className="bg-purple-600 hover:bg-purple-700 text-white font-medium px-6 py-2 rounded-lg transition-colors">
              {buttonText}
            </button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
