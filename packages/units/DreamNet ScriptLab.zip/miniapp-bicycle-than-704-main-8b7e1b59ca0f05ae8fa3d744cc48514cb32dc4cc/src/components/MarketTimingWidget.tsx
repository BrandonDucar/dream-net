'use client';

import React from 'react';
import { Clock, Zap, Moon, Sun } from 'lucide-react';
import { Badge } from './ui/badge';

interface MarketTimingWidgetProps {
  hint: string;
}

export function MarketTimingWidget({ hint }: MarketTimingWidgetProps): JSX.Element {
  const getIcon = (): JSX.Element => {
    if (hint.includes('🌅') || hint.includes('morning')) {
      return <Sun className="w-4 h-4 text-orange-500" />;
    } else if (hint.includes('☀️') || hint.includes('Midday')) {
      return <Sun className="w-4 h-4 text-yellow-500" />;
    } else if (hint.includes('🌆') || hint.includes('Prime')) {
      return <Zap className="w-4 h-4 text-purple-500" />;
    } else if (hint.includes('🌙') || hint.includes('night')) {
      return <Moon className="w-4 h-4 text-blue-500" />;
    } else {
      return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const getColor = (): string => {
    if (hint.includes('Prime')) {
      return 'bg-purple-100 text-purple-800 border-purple-300';
    } else if (hint.includes('Great')) {
      return 'bg-green-100 text-green-800 border-green-300';
    } else if (hint.includes('Good')) {
      return 'bg-blue-100 text-blue-800 border-blue-300';
    } else if (hint.includes('Off-peak')) {
      return 'bg-gray-100 text-gray-800 border-gray-300';
    } else {
      return 'bg-yellow-100 text-yellow-800 border-yellow-300';
    }
  };

  return (
    <div className={`flex items-center gap-2 px-3 py-2 rounded-lg border ${getColor()}`}>
      {getIcon()}
      <span className="text-sm font-medium">{hint}</span>
    </div>
  );
}
