'use client';

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { TrendingUp, Users, DollarSign, Activity } from 'lucide-react';

interface OnchainStatsWidgetProps {
  stats: string;
}

export function OnchainStatsWidget({ stats }: OnchainStatsWidgetProps): JSX.Element {
  let parsedStats: Record<string, string | number> = {};
  
  try {
    parsedStats = JSON.parse(stats);
  } catch {
    return <div className="text-xs text-gray-400">No stats available</div>;
  }

  const statItems = [
    {
      key: 'price',
      label: 'Price',
      icon: DollarSign,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      prefix: '$',
    },
    {
      key: 'volume24h',
      label: '24h Volume',
      icon: TrendingUp,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      prefix: '$',
    },
    {
      key: 'holders',
      label: 'Holders',
      icon: Users,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      prefix: '',
    },
    {
      key: 'mints',
      label: 'Mints',
      icon: Activity,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      prefix: '',
    },
    {
      key: 'priceChange24h',
      label: '24h Change',
      icon: TrendingUp,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      suffix: '%',
    },
    {
      key: 'floorPrice',
      label: 'Floor',
      icon: DollarSign,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      prefix: 'Ξ',
    },
    {
      key: 'uniqueHolders',
      label: 'Unique Holders',
      icon: Users,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      prefix: '',
    },
    {
      key: 'engagement',
      label: 'Engagement',
      icon: Activity,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      prefix: '',
    },
    {
      key: 'activity',
      label: 'Activity',
      icon: Activity,
      color: 'text-pink-600',
      bgColor: 'bg-pink-50',
      prefix: '',
    },
  ];

  const availableStats = statItems.filter((item) => parsedStats[item.key] !== undefined);

  if (availableStats.length === 0) {
    return <div className="text-xs text-gray-400">No stats available</div>;
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
      {availableStats.map((item) => {
        const Icon = item.icon;
        const value = parsedStats[item.key];
        return (
          <div
            key={item.key}
            className={`flex items-center gap-2 p-3 rounded-lg ${item.bgColor} border border-gray-200`}
          >
            <Icon className={`w-4 h-4 ${item.color}`} />
            <div>
              <div className="text-xs text-gray-600">{item.label}</div>
              <div className={`text-sm font-bold ${item.color}`}>
                {item.prefix || ''}
                {typeof value === 'number' && value > 1000
                  ? value.toLocaleString()
                  : value}
                {item.suffix || ''}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
