'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { ArrowLeft, Copy, Sparkles, Globe, CheckCircle2 } from 'lucide-react';
import type { ContentRef, ScriptVariant, GeoTarget } from '../hooks/useLocalData';
import { regenerateScript, generateGeoVariants } from '../lib/scriptGenerator';
import { toast } from 'sonner';

interface ScriptDetailProps {
  scriptId: string;
  scriptVariants: ScriptVariant[];
  contentRefs: ContentRef[];
  onBack: () => void;
  dataState: {
    updateScriptVariant: (id: string, data: Partial<ScriptVariant>) => void;
    updateScriptStatus: (id: string, status: ScriptVariant['status']) => void;
  };
}

const PREDEFINED_GEO_TARGETS: GeoTarget[] = [
  { id: 'us-en', region: 'US', language: 'en', country: 'US', cityOrMarket: 'United States' },
  { id: 'latam-es', region: 'LATAM', language: 'es', country: 'MX', cityOrMarket: 'Latin America' },
  { id: 'brasil-pt', region: 'LATAM', language: 'pt-BR', country: 'BR', cityOrMarket: 'Brazil' },
  { id: 'eu-en', region: 'EU', language: 'en', country: 'GB', cityOrMarket: 'Europe' },
];

export function ScriptDetail({
  scriptId,
  scriptVariants,
  contentRefs,
  onBack,
  dataState,
}: ScriptDetailProps): JSX.Element {
  const script = scriptVariants.find((s: ScriptVariant) => s.id === scriptId);
  const contentRef = script ? contentRefs.find((ref: ContentRef) => ref.id === script.contentRefId) : null;

  const [editedScript, setEditedScript] = useState<{
    body: string;
    threadParts: string[];
    callToAction: string;
  }>({
    body: script?.body || '',
    threadParts: script?.threadParts || [],
    callToAction: script?.callToAction || '',
  });

  const [editedSEO, setEditedSEO] = useState<{
    seoTitle: string;
    seoDescription: string;
    seoKeywords: string[];
    seoHashtags: string[];
    altText: string;
  }>({
    seoTitle: script?.seoTitle || '',
    seoDescription: script?.seoDescription || '',
    seoKeywords: script?.seoKeywords || [],
    seoHashtags: script?.seoHashtags || [],
    altText: script?.altText || '',
  });

  const [regenerateInstructions, setRegenerateInstructions] = useState<string>('');
  const [showRegenerateDialog, setShowRegenerateDialog] = useState<boolean>(false);
  const [selectedGeoTargets, setSelectedGeoTargets] = useState<string[]>([]);

  if (!script || !contentRef) {
    return (
      <div className="text-center py-12">
        <p className="text-black">Script not found</p>
        <Button onClick={onBack} className="mt-4 bg-black text-white hover:bg-black/90">
          Go Back
        </Button>
      </div>
    );
  }

  const handleSaveScript = (): void => {
    dataState.updateScriptVariant(scriptId, {
      body: editedScript.body,
      threadParts: editedScript.threadParts,
      callToAction: editedScript.callToAction,
      seoTitle: editedSEO.seoTitle,
      seoDescription: editedSEO.seoDescription,
      seoKeywords: editedSEO.seoKeywords,
      seoHashtags: editedSEO.seoHashtags,
      altText: editedSEO.altText,
    });

    toast.success('Script updated successfully');
  };

  const handleRegenerateScript = (): void => {
    if (!contentRef) return;

    const regenerated = regenerateScript(
      {
        channel: script.channel,
        style: script.style,
        length: script.length,
        body: editedScript.body,
        threadParts: editedScript.threadParts,
        callToAction: editedScript.callToAction,
        seoTitle: editedSEO.seoTitle,
        seoDescription: editedSEO.seoDescription,
        seoKeywords: editedSEO.seoKeywords,
        seoHashtags: editedSEO.seoHashtags,
        altText: editedSEO.altText,
        notes: script.notes,
      },
      regenerateInstructions,
      contentRef
    );

    setEditedScript({
      body: regenerated.body,
      threadParts: regenerated.threadParts || [],
      callToAction: regenerated.callToAction || '',
    });

    setEditedSEO({
      seoTitle: regenerated.seoTitle,
      seoDescription: regenerated.seoDescription,
      seoKeywords: regenerated.seoKeywords,
      seoHashtags: regenerated.seoHashtags,
      altText: regenerated.altText,
    });

    setShowRegenerateDialog(false);
    setRegenerateInstructions('');
    toast.success('Script regenerated');
  };

  const handleGenerateGeoVariants = (): void => {
    if (selectedGeoTargets.length === 0 || !contentRef) return;

    const targets = PREDEFINED_GEO_TARGETS.filter((t: GeoTarget) => selectedGeoTargets.includes(t.id));
    const variants = generateGeoVariants(
      {
        channel: script.channel,
        style: script.style,
        length: script.length,
        body: editedScript.body,
        threadParts: editedScript.threadParts,
        callToAction: editedScript.callToAction,
        seoTitle: editedSEO.seoTitle,
        seoDescription: editedSEO.seoDescription,
        seoKeywords: editedSEO.seoKeywords,
        seoHashtags: editedSEO.seoHashtags,
        altText: editedSEO.altText,
        notes: script.notes,
      },
      targets,
      contentRef
    );

    dataState.updateScriptVariant(scriptId, {
      primaryGeoTargets: targets,
      bodyLocalized: variants.bodyLocalized,
      tagsLocalized: variants.tagsLocalized,
    });

    toast.success('Geo variants generated');
  };

  const handleUpdateStatus = (newStatus: string): void => {
    dataState.updateScriptStatus(scriptId, newStatus as ScriptVariant['status']);
    toast.success(`Status updated to ${newStatus}`);
  };

  const handleCopyText = (text: string): void => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };

  const threadParts = editedScript.threadParts || [];
  const hasThread = threadParts.length > 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={onBack} className="text-black">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <div className="flex gap-2">
          <Select value={script.status} onValueChange={handleUpdateStatus}>
            <SelectTrigger className="w-32 text-black">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-white">
              <SelectItem value="draft" className="text-black">Draft</SelectItem>
              <SelectItem value="ready" className="text-black">Ready</SelectItem>
              <SelectItem value="used" className="text-black">Used</SelectItem>
              <SelectItem value="archived" className="text-black">Archived</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-black">
              {contentRef.primaryEmoji} {contentRef.name} - {script.channel}
            </CardTitle>
            <div className="flex gap-2">
              <Badge variant="outline" className="text-black">{script.style}</Badge>
              <Badge variant="outline" className="text-black">{script.length}</Badge>
              <Badge variant="outline" className="text-black">{script.status}</Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {!hasThread && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label htmlFor="body" className="text-black">Body</Label>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleCopyText(editedScript.body)}
                  className="text-black"
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              <Textarea
                id="body"
                value={editedScript.body}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                  setEditedScript({ ...editedScript, body: e.target.value })
                }
                rows={8}
                className="text-black font-mono"
              />
            </div>
          )}

          {hasThread && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label className="text-black">Thread Parts</Label>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleCopyText(threadParts.join('\n\n'))}
                  className="text-black"
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy Thread
                </Button>
              </div>
              <div className="space-y-3">
                {threadParts.map((part: string, index: number) => (
                  <div key={index}>
                    <Label className="text-sm text-black">Part {index + 1}</Label>
                    <Textarea
                      value={part}
                      onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => {
                        const newParts = [...threadParts];
                        newParts[index] = e.target.value;
                        setEditedScript({ ...editedScript, threadParts: newParts });
                      }}
                      rows={3}
                      className="text-black font-mono"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          <div>
            <Label htmlFor="cta" className="text-black">Call to Action</Label>
            <Input
              id="cta"
              value={editedScript.callToAction}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setEditedScript({ ...editedScript, callToAction: e.target.value })
              }
              placeholder="Optional CTA"
              className="text-black"
            />
          </div>

          <div className="flex gap-2">
            <Button onClick={handleSaveScript} className="flex-1 bg-black text-white hover:bg-black/90">
              <CheckCircle2 className="h-4 w-4 mr-2" />
              Save Changes
            </Button>
            <Dialog open={showRegenerateDialog} onOpenChange={setShowRegenerateDialog}>
              <DialogTrigger asChild>
                <Button variant="outline" className="text-black">
                  <Sparkles className="h-4 w-4 mr-2" />
                  Regenerate
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-white">
                <DialogHeader>
                  <DialogTitle className="text-black">Regenerate Script</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div>
                    <Label htmlFor="regenerateInstructions" className="text-black">Instructions</Label>
                    <Textarea
                      id="regenerateInstructions"
                      value={regenerateInstructions}
                      onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setRegenerateInstructions(e.target.value)}
                      placeholder="e.g., shorter, more aggressive, for builders only"
                      rows={4}
                      className="text-black"
                    />
                  </div>
                  <Button onClick={handleRegenerateScript} className="w-full bg-black text-white hover:bg-black/90">
                    Regenerate
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <p className="text-sm text-black">Notes: {script.notes}</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-black">SEO & Meta</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="seoTitle" className="text-black">SEO Title</Label>
            <Input
              id="seoTitle"
              value={editedSEO.seoTitle}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditedSEO({ ...editedSEO, seoTitle: e.target.value })}
              className="text-black"
            />
          </div>
          <div>
            <Label htmlFor="seoDescription" className="text-black">SEO Description</Label>
            <Textarea
              id="seoDescription"
              value={editedSEO.seoDescription}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setEditedSEO({ ...editedSEO, seoDescription: e.target.value })}
              rows={3}
              className="text-black"
            />
          </div>
          <div>
            <Label htmlFor="seoKeywords" className="text-black">Keywords (comma-separated)</Label>
            <Input
              id="seoKeywords"
              value={editedSEO.seoKeywords.join(', ')}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setEditedSEO({ ...editedSEO, seoKeywords: e.target.value.split(',').map((k: string) => k.trim()) })
              }
              className="text-black"
            />
          </div>
          <div>
            <Label htmlFor="seoHashtags" className="text-black">Hashtags (comma-separated)</Label>
            <Input
              id="seoHashtags"
              value={editedSEO.seoHashtags.join(', ')}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setEditedSEO({ ...editedSEO, seoHashtags: e.target.value.split(',').map((h: string) => h.trim()) })
              }
              className="text-black"
            />
          </div>
          <div>
            <Label htmlFor="altText" className="text-black">Alt Text</Label>
            <Input
              id="altText"
              value={editedSEO.altText}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditedSEO({ ...editedSEO, altText: e.target.value })}
              className="text-black"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-black flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Geo Targeting
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-black mb-2 block">Select Regions</Label>
            <div className="grid grid-cols-2 gap-2">
              {PREDEFINED_GEO_TARGETS.map((target: GeoTarget) => (
                <label key={target.id} className="flex items-center gap-2 text-black">
                  <input
                    type="checkbox"
                    checked={selectedGeoTargets.includes(target.id)}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                      if (e.target.checked) {
                        setSelectedGeoTargets([...selectedGeoTargets, target.id]);
                      } else {
                        setSelectedGeoTargets(selectedGeoTargets.filter((id: string) => id !== target.id));
                      }
                    }}
                    className="rounded"
                  />
                  {target.cityOrMarket} ({target.language})
                </label>
              ))}
            </div>
          </div>
          <Button
            onClick={handleGenerateGeoVariants}
            disabled={selectedGeoTargets.length === 0}
            className="w-full bg-black text-white hover:bg-black/90 disabled:bg-gray-400"
          >
            Generate Geo Variants
          </Button>

          {script.bodyLocalized && Object.keys(script.bodyLocalized).length > 0 && (
            <div className="mt-4">
              <Separator className="my-4" />
              <h4 className="font-semibold text-black mb-2">Generated Variants</h4>
              <div className="space-y-3">
                {Object.entries(script.bodyLocalized).map(([geoKey, body]: [string, string]) => (
                  <Card key={geoKey}>
                    <CardHeader>
                      <CardTitle className="text-sm text-black">{geoKey}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-black whitespace-pre-wrap">{body as string}</p>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleCopyText(body as string)}
                        className="mt-2 text-black"
                      >
                        <Copy className="h-4 w-4 mr-2" />
                        Copy
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
