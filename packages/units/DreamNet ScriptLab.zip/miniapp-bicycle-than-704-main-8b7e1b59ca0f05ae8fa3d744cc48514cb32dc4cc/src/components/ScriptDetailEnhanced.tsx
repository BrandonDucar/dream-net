'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { ArrowLeft, Copy, Sparkles, Zap, FileText, Edit, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import type { SpacetimeDBState } from '../hooks/useSpacetimeDB';
import * as moduleBindings from '../spacetime_module_bindings';
import { OnchainStatsWidget } from './OnchainStatsWidget';
import { MarketTimingWidget } from './MarketTimingWidget';
import { FramePreview } from './FramePreview';
import { VibeModeSelector } from './VibeModeSelector';
import { regenerateScript, generateGeoVariants } from '../lib/enhancedScriptGenerator';
import type { GeoTarget } from '../lib/enhancedScriptGenerator';

interface ScriptDetailEnhancedProps {
  scriptId: string;
  dbState: SpacetimeDBState;
  onBack: () => void;
}

const GEO_TARGETS: GeoTarget[] = [
  { id: 'us-en', region: 'US', language: 'en' },
  { id: 'latam-es', region: 'LATAM', language: 'es', country: 'MX' },
  { id: 'brasil-pt', region: 'LATAM', language: 'pt-BR', country: 'BR' },
  { id: 'eu-en', region: 'EU', language: 'en', country: 'GB' },
];

export function ScriptDetailEnhanced({ scriptId, dbState, onBack }: ScriptDetailEnhancedProps): JSX.Element {
  const script = dbState.scriptVariants.get(scriptId);
  const contentRef = script ? dbState.contentRefs.get(script.contentRefId) : undefined;

  const [editMode, setEditMode] = useState<boolean>(false);
  const [regeneratePrompt, setRegeneratePrompt] = useState<string>('');
  const [showRegenerateDialog, setShowRegenerateDialog] = useState<boolean>(false);

  const [editForm, setEditForm] = useState({
    body: script?.body || '',
    callToAction: script?.callToAction || '',
    seoTitle: script?.seoTitle || '',
    seoDescription: script?.seoDescription || '',
  });

  if (!script || !contentRef) {
    return <div className="p-6">Script not found</div>;
  }

  let threadParts: string[] = [];
  try {
    threadParts = JSON.parse(script.threadParts);
  } catch {
    // Ignore parsing error
  }

  const hasThread = threadParts.length > 0;

  const handleUpdate = (): void => {
    if (!dbState.connection) return;
    dbState.connection.reducers.updateScriptVariant(
      scriptId,
      script.contentRefId,
      script.channel,
      script.style,
      script.length,
      editForm.body,
      script.threadParts,
      editForm.callToAction,
      script.notes,
      script.status,
      editForm.seoTitle,
      editForm.seoDescription,
      script.seoKeywords,
      script.seoHashtags,
      script.altText,
      script.primaryGeoTargets,
      script.bodyLocalized,
      script.tagsLocalized
    );
    setEditMode(false);
    toast.success('Script updated successfully!');
  };

  const handleRegenerate = (): void => {
    if (!dbState.connection || !regeneratePrompt) return;

    const regenerated = regenerateScript(
      {
        channel: script.channel,
        style: script.style,
        length: script.length,
        body: script.body,
        threadParts,
        callToAction: script.callToAction,
        seoTitle: script.seoTitle,
        seoDescription: script.seoDescription,
        seoKeywords: JSON.parse(script.seoKeywords || '[]'),
        seoHashtags: JSON.parse(script.seoHashtags || '[]'),
        altText: script.altText,
        notes: script.notes,
      },
      regeneratePrompt,
      contentRef
    );

    dbState.connection.reducers.updateScriptVariant(
      scriptId,
      script.contentRefId,
      script.channel,
      script.style,
      script.length,
      regenerated.body,
      JSON.stringify(regenerated.threadParts || []),
      regenerated.callToAction || '',
      regenerated.notes,
      script.status,
      regenerated.seoTitle,
      regenerated.seoDescription,
      JSON.stringify(regenerated.seoKeywords),
      JSON.stringify(regenerated.seoHashtags),
      regenerated.altText,
      script.primaryGeoTargets,
      script.bodyLocalized,
      script.tagsLocalized
    );

    // Update crypto fields
    if (regenerated.onchainStats || regenerated.marketTimingHint) {
      setTimeout(() => {
        dbState.connection?.reducers.updateScriptVariantCryptoFields(
          scriptId,
          regenerated.vibeMode,
          undefined,
          undefined,
          undefined,
          regenerated.onchainStats,
          regenerated.marketTimingHint
        );
      }, 100);
    }

    setShowRegenerateDialog(false);
    setRegeneratePrompt('');
    toast.success('Script regenerated!');
  };

  const handleStatusChange = (status: string): void => {
    if (!dbState.connection) return;
    dbState.connection.reducers.updateScriptStatus(scriptId, status);
    toast.success(`Status changed to ${status}!`);
  };

  const handleGenerateGeoVariants = (): void => {
    if (!dbState.connection) return;

    const geoVariants = generateGeoVariants(
      {
        channel: script.channel,
        style: script.style,
        length: script.length,
        body: script.body,
        seoTitle: script.seoTitle,
        seoDescription: script.seoDescription,
        seoKeywords: JSON.parse(script.seoKeywords || '[]'),
        seoHashtags: JSON.parse(script.seoHashtags || '[]'),
        altText: script.altText,
        notes: script.notes,
      },
      GEO_TARGETS,
      contentRef
    );

    dbState.connection.reducers.updateScriptVariant(
      scriptId,
      script.contentRefId,
      script.channel,
      script.style,
      script.length,
      script.body,
      script.threadParts,
      script.callToAction,
      script.notes,
      script.status,
      script.seoTitle,
      script.seoDescription,
      script.seoKeywords,
      script.seoHashtags,
      script.altText,
      JSON.stringify(GEO_TARGETS),
      JSON.stringify(geoVariants.bodyLocalized),
      JSON.stringify(geoVariants.tagsLocalized)
    );

    toast.success('Geo variants generated!');
  };

  const copyToClipboard = (text: string, label: string): void => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard!`);
  };

  const getStatusColor = (status: string): string => {
    const colors: Record<string, string> = {
      draft: 'bg-gray-100 text-gray-700 border-gray-300',
      ready: 'bg-green-100 text-green-700 border-green-300',
      used: 'bg-blue-100 text-blue-700 border-blue-300',
      archived: 'bg-orange-100 text-orange-700 border-orange-300',
    };
    return colors[status] || 'bg-gray-100 text-gray-700 border-gray-300';
  };

  const getChannelIcon = (channel: string): string => {
    const icons: Record<string, string> = {
      x: '𝕏',
      farcaster: '🟣',
      zora: '⚡',
      'base-feed': '🔵',
      'site-copy': '📄',
    };
    return icons[channel] || '📝';
  };

  return (
    <div className="space-y-6 p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setEditMode(!editMode)}>
            <Edit className="w-4 h-4 mr-2" />
            {editMode ? 'Cancel Edit' : 'Edit'}
          </Button>
          <Button onClick={() => setShowRegenerateDialog(true)} className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
            <Sparkles className="w-4 h-4 mr-2" />
            Regenerate
          </Button>
        </div>
      </div>

      <Card className="border-2 border-purple-200 overflow-hidden">
        <div className="h-2 bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400" />
        <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className="text-4xl">{getChannelIcon(script.channel)}</span>
                <div>
                  <CardTitle className="text-2xl capitalize">{script.channel.replace(/-/g, ' ')}</CardTitle>
                  <p className="text-gray-600">{contentRef.primaryEmoji} {contentRef.name}</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-300">
                  {script.style}
                </Badge>
                <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-300">
                  {script.length}
                </Badge>
                {script.vibeMode && (
                  <Badge variant="outline" className="bg-pink-50 text-pink-700 border-pink-300">
                    {script.vibeMode} mode
                  </Badge>
                )}
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <Badge className={`${getStatusColor(script.status)} border text-sm px-4 py-1`}>
                {script.status}
              </Badge>
              <select
                value={script.status}
                onChange={(e) => handleStatusChange(e.target.value)}
                className="text-xs border rounded px-2 py-1"
              >
                <option value="draft">Draft</option>
                <option value="ready">Ready</option>
                <option value="used">Used</option>
                <option value="archived">Archived</option>
              </select>
            </div>
          </div>
        </CardHeader>
      </Card>

      {script.onchainStats && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Zap className="w-5 h-5 text-orange-600" />
              Onchain Stats
            </CardTitle>
          </CardHeader>
          <CardContent>
            <OnchainStatsWidget stats={script.onchainStats} />
          </CardContent>
        </Card>
      )}

      {script.marketTimingHint && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Market Timing</CardTitle>
          </CardHeader>
          <CardContent>
            <MarketTimingWidget hint={script.marketTimingHint} />
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="main" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="main">
            <FileText className="w-4 h-4 mr-2" />
            Main Content
          </TabsTrigger>
          <TabsTrigger value="seo">SEO & Meta</TabsTrigger>
          <TabsTrigger value="geo">Geo Variants</TabsTrigger>
        </TabsList>

        <TabsContent value="main" className="space-y-4">
          {script.channel === 'farcaster' && script.frameButtonText && (
            <FramePreview
              body={script.body}
              buttonText={script.frameButtonText}
              aspectRatio={script.frameAspectRatio}
            />
          )}

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Script Body</CardTitle>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(script.body, 'Body')}
                >
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {editMode ? (
                <Textarea
                  value={editForm.body}
                  onChange={(e) => setEditForm({ ...editForm, body: e.target.value })}
                  rows={8}
                  className="font-mono"
                />
              ) : (
                <div className="bg-gray-50 p-4 rounded border whitespace-pre-wrap font-mono text-sm">
                  {script.body}
                </div>
              )}
            </CardContent>
          </Card>

          {hasThread && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Thread Parts ({threadParts.length})</CardTitle>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      copyToClipboard(threadParts.map((p, i) => `${i + 1}. ${p}`).join('\n\n'), 'Thread')
                    }
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy Thread
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {threadParts.map((part, index) => (
                  <div key={index} className="bg-gray-50 p-3 rounded border">
                    <div className="text-xs font-bold text-purple-700 mb-1">Part {index + 1}</div>
                    <div className="text-sm whitespace-pre-wrap">{part}</div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {script.callToAction && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Call to Action</CardTitle>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => copyToClipboard(script.callToAction, 'CTA')}
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {editMode ? (
                  <Input
                    value={editForm.callToAction}
                    onChange={(e) => setEditForm({ ...editForm, callToAction: e.target.value })}
                  />
                ) : (
                  <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-3 rounded border border-purple-200 font-medium">
                    {script.callToAction}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {editMode && (
            <div className="flex gap-2">
              <Button onClick={handleUpdate} className="flex-1">
                <CheckCircle2 className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
              <Button variant="outline" onClick={() => setEditMode(false)}>
                Cancel
              </Button>
            </div>
          )}
        </TabsContent>

        <TabsContent value="seo" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>SEO Metadata</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>SEO Title</Label>
                {editMode ? (
                  <Input
                    value={editForm.seoTitle}
                    onChange={(e) => setEditForm({ ...editForm, seoTitle: e.target.value })}
                  />
                ) : (
                  <div className="bg-gray-50 p-2 rounded border text-sm">{script.seoTitle}</div>
                )}
              </div>
              <div>
                <Label>SEO Description</Label>
                {editMode ? (
                  <Textarea
                    value={editForm.seoDescription}
                    onChange={(e) => setEditForm({ ...editForm, seoDescription: e.target.value })}
                    rows={3}
                  />
                ) : (
                  <div className="bg-gray-50 p-2 rounded border text-sm">{script.seoDescription}</div>
                )}
              </div>
              <div>
                <Label>Keywords</Label>
                <div className="flex flex-wrap gap-2">
                  {JSON.parse(script.seoKeywords || '[]').map((keyword: string, i: number) => (
                    <Badge key={i} variant="outline" className="bg-blue-50 text-blue-700 border-blue-300">
                      {keyword}
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <Label>Hashtags</Label>
                <div className="flex flex-wrap gap-2">
                  {JSON.parse(script.seoHashtags || '[]').map((tag: string, i: number) => (
                    <Badge key={i} variant="outline" className="bg-purple-50 text-purple-700 border-purple-300">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="geo" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Geo-Targeted Variants</CardTitle>
                <Button onClick={handleGenerateGeoVariants} variant="outline">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate Variants
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {script.bodyLocalized && script.bodyLocalized !== '{}' ? (
                <div className="space-y-4">
                  {Object.entries(JSON.parse(script.bodyLocalized)).map(([geoKey, body]) => (
                    <div key={geoKey} className="border rounded p-4">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="outline">{geoKey}</Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(body as string, `${geoKey} variant`)}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="text-sm bg-gray-50 p-3 rounded">{body as string}</div>
                      {script.tagsLocalized && script.tagsLocalized !== '{}' && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {(JSON.parse(script.tagsLocalized)[geoKey] || []).map((tag: string, i: number) => (
                            <Badge key={i} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <p>No geo variants yet. Click Generate Variants to create localized versions.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={showRegenerateDialog} onOpenChange={setShowRegenerateDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-600" />
              Regenerate Script
            </DialogTitle>
            <DialogDescription>
              Provide instructions on how to modify this script
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              placeholder="e.g., 'Make it shorter', 'More aggressive', 'For developers only'"
              value={regeneratePrompt}
              onChange={(e) => setRegeneratePrompt(e.target.value)}
              rows={4}
            />
            <Button onClick={handleRegenerate} className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white">
              Regenerate
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
