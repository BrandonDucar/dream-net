'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { CRYPTO_TEMPLATES, getTemplatesByType, getTemplatesByVibe, type CryptoTemplate } from '../lib/cryptoTemplates';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Sparkles, Rocket, FileText, Megaphone, Frame } from 'lucide-react';

interface TemplateSelectorProps {
  onSelect: (template: CryptoTemplate) => void;
}

export function TemplateSelector({ onSelect }: TemplateSelectorProps): JSX.Element {
  const [selectedType, setSelectedType] = useState<string>('all');

  const templateTypes = [
    { id: 'all', name: 'All Templates', icon: Sparkles },
    { id: 'token-launch', name: 'Token Launch', icon: Rocket },
    { id: 'nft-drop', name: 'NFT Drop', icon: FileText },
    { id: 'dao-proposal', name: 'DAO Proposal', icon: Megaphone },
    { id: 'frame', name: 'Farcaster Frame', icon: Frame },
  ];

  const templates = selectedType === 'all' ? CRYPTO_TEMPLATES : getTemplatesByType(selectedType);

  const getVibeColor = (vibe: string): string => {
    const colors: Record<string, string> = {
      degen: 'bg-purple-100 text-purple-700 border-purple-300',
      builder: 'bg-blue-100 text-blue-700 border-blue-300',
      culture: 'bg-pink-100 text-pink-700 border-pink-300',
      normie: 'bg-green-100 text-green-700 border-green-300',
      shitpost: 'bg-yellow-100 text-yellow-700 border-yellow-300',
    };
    return colors[vibe] || 'bg-gray-100 text-gray-700 border-gray-300';
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2 overflow-x-auto pb-2">
        {templateTypes.map((type) => {
          const Icon = type.icon;
          return (
            <Button
              key={type.id}
              variant={selectedType === type.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedType(type.id)}
              className="flex items-center gap-2 whitespace-nowrap"
            >
              <Icon className="w-4 h-4" />
              {type.name}
            </Button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
        {templates.map((template) => (
          <Card
            key={template.id}
            className="hover:shadow-lg transition-all cursor-pointer hover:border-purple-300"
            onClick={() => onSelect(template)}
          >
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <CardTitle className="text-base">{template.templateType.replace(/-/g, ' ').toUpperCase()}</CardTitle>
                <Badge className={`${getVibeColor(template.vibeMode)} border`} variant="outline">
                  {template.vibeMode}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-xs text-gray-600 mb-2">
                Channel: <span className="font-medium">{template.channel}</span>
              </div>
              <div className="text-sm text-gray-700 bg-gray-50 p-2 rounded border border-gray-200 line-clamp-3">
                {template.templateBody}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
