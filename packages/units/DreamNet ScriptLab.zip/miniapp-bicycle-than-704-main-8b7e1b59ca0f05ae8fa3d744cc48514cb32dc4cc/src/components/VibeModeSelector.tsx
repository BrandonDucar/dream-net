'use client';

import React from 'react';
import { Card } from './ui/card';
import { VIBE_MODES } from '../lib/cryptoTemplates';

interface VibeModeSelectorProps {
  selectedVibe: string;
  onSelect: (vibe: string) => void;
}

export function VibeModeSelector({ selectedVibe, onSelect }: VibeModeSelectorProps): JSX.Element {
  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
      {Object.entries(VIBE_MODES).map(([key, vibe]) => {
        const isSelected = selectedVibe === key;
        return (
          <Card
            key={key}
            className={`p-4 cursor-pointer transition-all hover:scale-105 border-2 ${
              isSelected
                ? 'border-purple-500 bg-purple-50 shadow-lg shadow-purple-200'
                : 'border-gray-200 hover:border-purple-300'
            }`}
            onClick={() => onSelect(key)}
          >
            <div className="text-center">
              <div className="text-3xl mb-2">{vibe.emoji}</div>
              <div className={`font-bold text-sm mb-1 ${isSelected ? 'text-purple-700' : 'text-gray-700'}`}>
                {vibe.name}
              </div>
              <div className="text-xs text-gray-500">{vibe.description}</div>
            </div>
          </Card>
        );
      })}
    </div>
  );
}
