'use client'
import { useState, useEffect, useCallback } from 'react';

export interface ContentRef {
  id: string;
  type: 'token' | 'drop' | 'meme' | 'campaign' | 'agent' | 'mini-app' | 'content-stream' | 'culture-coin' | 'pickleball' | 'other';
  refId: string;
  name: string;
  primaryEmoji: string;
  chain: string | null;
  category: string;
  createdAt: number;
}

export interface GeoTarget {
  id: string;
  region: string;
  country: string;
  cityOrMarket: string;
  language: string;
}

export interface ScriptVariant {
  id: string;
  contentRefId: string;
  channel: 'x' | 'farcaster' | 'zora' | 'base-feed' | 'site-copy' | 'other';
  style: 'hype' | 'informational' | 'story' | 'deadpan' | 'bullet' | 'short-caption';
  length: 'short' | 'medium' | 'long';
  body: string;
  threadParts: string[];
  callToAction: string;
  notes: string;
  status: 'draft' | 'ready' | 'used' | 'archived';
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
  primaryGeoTargets: GeoTarget[];
  bodyLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
  vibeMode?: string;
  frameButtonText?: string;
  frameAspectRatio?: string;
  onchainStats?: {
    price?: string;
    volume?: string;
    holders?: number;
    mints?: number;
  };
  marketTiming?: string;
  createdAt: number;
}

interface LocalDataState {
  contentRefs: ContentRef[];
  scriptVariants: ScriptVariant[];
  createContentRef: (data: Omit<ContentRef, 'id' | 'createdAt'>) => ContentRef;
  updateContentRef: (id: string, data: Partial<ContentRef>) => void;
  deleteContentRef: (id: string) => void;
  createScriptVariant: (data: Omit<ScriptVariant, 'id' | 'createdAt'>) => ScriptVariant;
  updateScriptVariant: (id: string, data: Partial<ScriptVariant>) => void;
  deleteScriptVariant: (id: string) => void;
  updateScriptStatus: (id: string, status: ScriptVariant['status']) => void;
}

const STORAGE_KEYS = {
  CONTENT_REFS: 'dreamnet-content-refs',
  SCRIPT_VARIANTS: 'dreamnet-script-variants',
};

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

export function useLocalData(): LocalDataState {
  const [contentRefs, setContentRefs] = useState<ContentRef[]>([]);
  const [scriptVariants, setScriptVariants] = useState<ScriptVariant[]>([]);
  const [loaded, setLoaded] = useState<boolean>(false);

  // Load data from localStorage on mount
  useEffect(() => {
    try {
      const storedRefs = localStorage.getItem(STORAGE_KEYS.CONTENT_REFS);
      const storedVariants = localStorage.getItem(STORAGE_KEYS.SCRIPT_VARIANTS);

      if (storedRefs) {
        setContentRefs(JSON.parse(storedRefs));
      }
      if (storedVariants) {
        setScriptVariants(JSON.parse(storedVariants));
      }
    } catch (error) {
      console.error('Error loading data from localStorage:', error);
    }
    setLoaded(true);
  }, []);

  // Save contentRefs to localStorage whenever they change
  useEffect(() => {
    if (loaded) {
      localStorage.setItem(STORAGE_KEYS.CONTENT_REFS, JSON.stringify(contentRefs));
    }
  }, [contentRefs, loaded]);

  // Save scriptVariants to localStorage whenever they change
  useEffect(() => {
    if (loaded) {
      localStorage.setItem(STORAGE_KEYS.SCRIPT_VARIANTS, JSON.stringify(scriptVariants));
    }
  }, [scriptVariants, loaded]);

  const createContentRef = useCallback((data: Omit<ContentRef, 'id' | 'createdAt'>): ContentRef => {
    const newRef: ContentRef = {
      ...data,
      id: generateId(),
      createdAt: Date.now(),
    };
    setContentRefs(prev => [...prev, newRef]);
    return newRef;
  }, []);

  const updateContentRef = useCallback((id: string, data: Partial<ContentRef>): void => {
    setContentRefs(prev =>
      prev.map(ref => (ref.id === id ? { ...ref, ...data } : ref))
    );
  }, []);

  const deleteContentRef = useCallback((id: string): void => {
    setContentRefs(prev => prev.filter(ref => ref.id !== id));
    // Also delete associated script variants
    setScriptVariants(prev => prev.filter(variant => variant.contentRefId !== id));
  }, []);

  const createScriptVariant = useCallback((data: Omit<ScriptVariant, 'id' | 'createdAt'>): ScriptVariant => {
    const newVariant: ScriptVariant = {
      ...data,
      id: generateId(),
      createdAt: Date.now(),
    };
    setScriptVariants(prev => [...prev, newVariant]);
    return newVariant;
  }, []);

  const updateScriptVariant = useCallback((id: string, data: Partial<ScriptVariant>): void => {
    setScriptVariants(prev =>
      prev.map(variant => (variant.id === id ? { ...variant, ...data } : variant))
    );
  }, []);

  const deleteScriptVariant = useCallback((id: string): void => {
    setScriptVariants(prev => prev.filter(variant => variant.id !== id));
  }, []);

  const updateScriptStatus = useCallback((id: string, status: ScriptVariant['status']): void => {
    setScriptVariants(prev =>
      prev.map(variant => (variant.id === id ? { ...variant, status } : variant))
    );
  }, []);

  return {
    contentRefs,
    scriptVariants,
    createContentRef,
    updateContentRef,
    deleteContentRef,
    createScriptVariant,
    updateScriptVariant,
    deleteScriptVariant,
    updateScriptStatus,
  };
}
