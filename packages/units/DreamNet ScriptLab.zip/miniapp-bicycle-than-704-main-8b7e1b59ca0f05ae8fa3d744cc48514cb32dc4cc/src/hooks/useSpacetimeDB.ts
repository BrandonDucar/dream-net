'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import type { Identity } from 'spacetimedb';
import * as moduleBindings from '../spacetime_module_bindings';

type DbConnection = moduleBindings.DbConnection;
type EventContext = moduleBindings.EventContext;
type ErrorContext = moduleBindings.ErrorContext;
type ContentRef = moduleBindings.ContentRef;
type ScriptVariant = moduleBindings.ScriptVariant;

export interface SpacetimeDBState {
  connected: boolean;
  identity: Identity | null;
  statusMessage: string;
  contentRefs: ReadonlyMap<string, ContentRef>;
  scriptVariants: ReadonlyMap<string, ScriptVariant>;
  connection: DbConnection | null;
}

export function useSpacetimeDB(): SpacetimeDBState {
  const [connected, setConnected] = useState<boolean>(false);
  const [identity, setIdentity] = useState<Identity | null>(null);
  const [statusMessage, setStatusMessage] = useState<string>('Connecting...');
  const [contentRefs, setContentRefs] = useState<ReadonlyMap<string, ContentRef>>(new Map());
  const [scriptVariants, setScriptVariants] = useState<ReadonlyMap<string, ScriptVariant>>(new Map());
  
  const connectionRef = useRef<DbConnection | null>(null);

  const subscribeToTables = useCallback(() => {
    if (!connectionRef.current) return;
    
    console.log('Subscribing to tables...');
    
    const queries = ['SELECT * FROM content_ref', 'SELECT * FROM script_variant'];
    
    connectionRef.current
      .subscriptionBuilder()
      .onApplied(() => {
        console.log('Subscription applied');
        processInitialCache();
      })
      .onError((error: Error) => {
        console.error('Subscription error:', error);
        setStatusMessage(`Subscription Error: ${error.message}`);
      })
      .subscribe(queries);
  }, []);

  const processInitialCache = useCallback(() => {
    if (!connectionRef.current) return;
    console.log('Processing initial cache...');
    
    const currentContentRefs = new Map<string, ContentRef>();
    for (const ref of connectionRef.current.db.contentRef.iter()) {
      currentContentRefs.set(ref.id, ref);
    }
    setContentRefs(currentContentRefs);

    const currentScripts = new Map<string, ScriptVariant>();
    for (const script of connectionRef.current.db.scriptVariant.iter()) {
      currentScripts.set(script.id, script);
    }
    setScriptVariants(currentScripts);
  }, []);

  const registerTableCallbacks = useCallback((currentIdentity: Identity) => {
    if (!connectionRef.current) return;
    
    console.log('Registering table callbacks...');

    connectionRef.current.db.contentRef.onInsert((_ctx: EventContext | undefined, ref: ContentRef) => {
      setContentRefs((prev: ReadonlyMap<string, ContentRef>) =>
        new Map(prev).set(ref.id, ref)
      );
    });

    connectionRef.current.db.contentRef.onUpdate((_ctx: EventContext | undefined, _oldRef: ContentRef, newRef: ContentRef) => {
      setContentRefs((prev: ReadonlyMap<string, ContentRef>) => {
        const newMap = new Map(prev);
        newMap.set(newRef.id, newRef);
        return newMap;
      });
    });

    connectionRef.current.db.contentRef.onDelete((_ctx: EventContext, ref: ContentRef) => {
      setContentRefs((prev: ReadonlyMap<string, ContentRef>) => {
        const newMap = new Map(prev);
        newMap.delete(ref.id);
        return newMap;
      });
    });

    connectionRef.current.db.scriptVariant.onInsert((_ctx: EventContext | undefined, script: ScriptVariant) => {
      setScriptVariants((prev: ReadonlyMap<string, ScriptVariant>) =>
        new Map(prev).set(script.id, script)
      );
    });

    connectionRef.current.db.scriptVariant.onUpdate((_ctx: EventContext | undefined, _oldScript: ScriptVariant, newScript: ScriptVariant) => {
      setScriptVariants((prev: ReadonlyMap<string, ScriptVariant>) => {
        const newMap = new Map(prev);
        newMap.set(newScript.id, newScript);
        return newMap;
      });
    });

    connectionRef.current.db.scriptVariant.onDelete((_ctx: EventContext, script: ScriptVariant) => {
      setScriptVariants((prev: ReadonlyMap<string, ScriptVariant>) => {
        const newMap = new Map(prev);
        newMap.delete(script.id);
        return newMap;
      });
    });
  }, []);

  useEffect(() => {
    if (connectionRef.current) {
      console.log('Connection already established, skipping setup.');
      return;
    }

    const dbHost = 'wss://maincloud.spacetimedb.com';
    const dbName = process.env.NEXT_PUBLIC_SPACETIME_MODULE_NAME || 'default_module';

    const onConnect = (connection: DbConnection, id: Identity, _token: string) => {
      console.log('Connected!');
      connectionRef.current = connection;
      setIdentity(id);
      setConnected(true);
      setStatusMessage(`Connected as ${id.toHexString().substring(0, 8)}...`);
      
      subscribeToTables();
      registerTableCallbacks(id);
    };

    const onDisconnect = (_ctx: ErrorContext, reason?: Error | null) => {
      const reasonStr = reason ? reason.message : 'No reason given';
      console.log('Disconnected:', reasonStr);
      setStatusMessage(`Disconnected: ${reasonStr}`);
      connectionRef.current = null;
      setIdentity(null);
      setConnected(false);
    };

    moduleBindings.DbConnection.builder()
      .withUri(dbHost)
      .withModuleName(dbName)
      .onConnect(onConnect)
      .onDisconnect(onDisconnect)
      .build();
  }, []);

  return {
    connected,
    identity,
    statusMessage,
    contentRefs,
    scriptVariants,
    connection: connectionRef.current,
  };
}
