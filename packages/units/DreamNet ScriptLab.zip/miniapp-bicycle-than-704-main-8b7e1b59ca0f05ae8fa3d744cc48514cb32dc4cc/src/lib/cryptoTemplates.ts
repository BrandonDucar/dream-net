// Crypto-native templates for different scenarios

export interface CryptoTemplate {
  id: string;
  templateType: string;
  vibeMode: string;
  channel: string;
  templateBody: string;
  variables: string[];
  popularityScore: number;
}

export const VIBE_MODES = {
  degen: {
    name: 'Degen Mode',
    emoji: '🦍',
    description: 'Ape in, number go up, full send',
    keywords: ['LFG', 'wagmi', 'gm', 'ape in', 'moon', 'ser', 'anon'],
  },
  builder: {
    name: 'Builder Mode',
    emoji: '🛠️',
    description: 'Technical, composable, permissionless',
    keywords: ['composable', 'permissionless', 'open source', 'modular', 'infrastructure'],
  },
  culture: {
    name: 'Culture Mode',
    emoji: '🎨',
    description: 'Storytelling, lore, community vibes',
    keywords: ['vibes', 'community', 'culture', 'movement', 'together'],
  },
  normie: {
    name: 'Normie Bridge',
    emoji: '🌉',
    description: 'Explain crypto to newcomers',
    keywords: ['simple', 'easy', 'beginner-friendly', 'accessible', 'no jargon'],
  },
  shitpost: {
    name: 'Shitpost Mode',
    emoji: '😂',
    description: 'Memes, jokes, pure chaos',
    keywords: ['lol', 'meme', 'joke', 'chaos', 'unhinged'],
  },
};

export const CRYPTO_TEMPLATES: CryptoTemplate[] = [
  // TOKEN LAUNCH TEMPLATES
  {
    id: 'token-fair-launch-degen',
    templateType: 'token-launch',
    vibeMode: 'degen',
    channel: 'x',
    templateBody: `🚀 {{NAME}} FAIR LAUNCH NOW LIVE

No presale. No VC allocation. Pure community play.

CA: {{CONTRACT_ADDRESS}}
Chain: {{CHAIN}}
LP: Locked forever 🔒

Don't fade this ser. Number go up only. 📈

#DeFi #{{CHAIN}} #FairLaunch`,
    variables: ['NAME', 'CONTRACT_ADDRESS', 'CHAIN'],
    popularityScore: 0,
  },
  {
    id: 'token-builder-launch',
    templateType: 'token-launch',
    vibeMode: 'builder',
    channel: 'x',
    templateBody: `Introducing {{NAME}} 🛠️

A composable token built for the {{CHAIN}} ecosystem.

Key features:
• Open source contracts
• Permissionless minting
• Modular architecture
• Community governance

Built by devs, for devs.

Docs: {{DOCS_URL}}
Contract: {{CONTRACT_ADDRESS}}`,
    variables: ['NAME', 'CHAIN', 'DOCS_URL', 'CONTRACT_ADDRESS'],
    popularityScore: 0,
  },

  // NFT DROP TEMPLATES
  {
    id: 'nft-drop-culture',
    templateType: 'nft-drop',
    vibeMode: 'culture',
    channel: 'zora',
    templateBody: `{{NAME}} - A Cultural Moment

This collection represents {{DESCRIPTION}}.

Supply: {{SUPPLY}}
Price: {{PRICE}} ETH
Chain: {{CHAIN}}

Every mint is a vote for the culture we want to see onchain.

Join us in building something beautiful together. ✨`,
    variables: ['NAME', 'DESCRIPTION', 'SUPPLY', 'PRICE', 'CHAIN'],
    popularityScore: 0,
  },
  {
    id: 'nft-drop-hype',
    templateType: 'nft-drop',
    vibeMode: 'degen',
    channel: 'farcaster',
    templateBody: `🔥 {{NAME}} DROPPING NOW

{{SUPPLY}} pieces of pure alpha
{{PRICE}} ETH on {{CHAIN}}

Floor gonna be crazy. Don't sleep on this.

Mint: {{MINT_URL}}

LFG! 🚀`,
    variables: ['NAME', 'SUPPLY', 'PRICE', 'CHAIN', 'MINT_URL'],
    popularityScore: 0,
  },

  // DAO PROPOSAL TEMPLATES
  {
    id: 'dao-proposal-builder',
    templateType: 'dao-proposal',
    vibeMode: 'builder',
    channel: 'x',
    templateBody: `📜 DAO Proposal: {{TITLE}}

Summary:
{{SUMMARY}}

Implementation:
• {{STEP_1}}
• {{STEP_2}}
• {{STEP_3}}

Timeline: {{TIMELINE}}
Required votes: {{QUORUM}}

Vote now: {{VOTE_URL}}

Let's build together. 🛠️`,
    variables: ['TITLE', 'SUMMARY', 'STEP_1', 'STEP_2', 'STEP_3', 'TIMELINE', 'QUORUM', 'VOTE_URL'],
    popularityScore: 0,
  },

  // CAMPAIGN TEMPLATES
  {
    id: 'campaign-announcement',
    templateType: 'campaign',
    vibeMode: 'culture',
    channel: 'farcaster',
    templateBody: `✨ Announcing: {{CAMPAIGN_NAME}}

{{DESCRIPTION}}

Dates: {{DATES}}
How to participate: {{HOW_TO}}

This is about more than just {{TOPIC}} - it's about bringing our community together and creating something meaningful.

Ready to join? {{CTA}}`,
    variables: ['CAMPAIGN_NAME', 'DESCRIPTION', 'DATES', 'HOW_TO', 'TOPIC', 'CTA'],
    popularityScore: 0,
  },

  // FARCASTER FRAME TEMPLATES
  {
    id: 'frame-mint',
    templateType: 'frame',
    vibeMode: 'degen',
    channel: 'farcaster',
    templateBody: `🎨 {{NAME}}

{{SHORT_DESCRIPTION}}

Mint directly from this frame!
{{PRICE}} on {{CHAIN}}

[MINT NOW]`,
    variables: ['NAME', 'SHORT_DESCRIPTION', 'PRICE', 'CHAIN'],
    popularityScore: 0,
  },
];

export function getTemplatesByType(type: string): CryptoTemplate[] {
  return CRYPTO_TEMPLATES.filter((t: CryptoTemplate) => t.templateType === type);
}

export function getTemplatesByVibe(vibe: string): CryptoTemplate[] {
  return CRYPTO_TEMPLATES.filter((t: CryptoTemplate) => t.vibeMode === vibe);
}

export function fillTemplate(template: CryptoTemplate, values: Record<string, string>): string {
  let result = template.templateBody;
  for (const [key, value] of Object.entries(values)) {
    result = result.replace(new RegExp(`{{${key}}}`, 'g'), value);
  }
  return result;
}

// Simulated onchain data
export function generateOnchainStats(contentType: string) {
  const random = Math.random();
  
  if (contentType === 'token') {
    return {
      price: (random * 0.01).toFixed(6),
      volume24h: Math.floor(random * 100000),
      holders: Math.floor(random * 10000),
      priceChange24h: ((random - 0.5) * 20).toFixed(2),
    };
  }
  
  if (contentType === 'drop' || contentType === 'meme') {
    return {
      mints: Math.floor(random * 5000),
      uniqueHolders: Math.floor(random * 2000),
      floorPrice: (random * 0.1).toFixed(4),
      volume24h: Math.floor(random * 50),
    };
  }
  
  return {
    activity: Math.floor(random * 1000),
    engagement: Math.floor(random * 100),
  };
}

// Market timing suggestions
export function getMarketTimingHint(): string {
  const hour = new Date().getHours();
  
  if (hour >= 8 && hour <= 11) {
    return '🌅 Great time! US morning - high crypto Twitter activity';
  } else if (hour >= 12 && hour <= 16) {
    return '☀️ Good time! Midday - steady engagement';
  } else if (hour >= 17 && hour <= 21) {
    return '🌆 Prime time! Evening peak - maximum visibility';
  } else if (hour >= 22 || hour <= 2) {
    return '🌙 Late night - degen hours, lower volume but engaged audience';
  } else {
    return '😴 Off-peak hours - consider scheduling for later';
  }
}
