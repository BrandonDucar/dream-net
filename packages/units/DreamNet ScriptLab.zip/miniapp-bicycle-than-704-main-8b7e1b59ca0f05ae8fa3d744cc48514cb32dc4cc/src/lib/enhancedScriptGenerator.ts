import type { ContentRef, ScriptVariant } from '../hooks/useLocalData';

const VIBE_MODES = {
  degen: {
    emoji: '🦍',
    keywords: ['ape in', 'wagmi', 'gm', 'number go up', 'send it', 'bullish', 'moon', 'bags'],
    tone: 'high energy, meme-heavy, crypto twitter native',
  },
  builder: {
    emoji: '🛠️',
    keywords: ['composable', 'permissionless', 'open source', 'decentralized', 'onchain', 'protocol', 'infrastructure'],
    tone: 'technical, forward-thinking, developer-focused',
  },
  culture: {
    emoji: '🎨',
    keywords: ['community', 'storytelling', 'lore', 'culture', 'movement', 'vibe', 'magic'],
    tone: 'narrative-driven, emotional, community-focused',
  },
  normie: {
    emoji: '🌉',
    keywords: ['easy', 'simple', 'accessible', 'friendly', 'beginner', 'introduction', 'explained'],
    tone: 'clear, educational, bridge to mainstream',
  },
  shitpost: {
    emoji: '😂',
    keywords: ['lol', 'chaos', 'meme', 'joke', 'wild', 'unhinged', 'based'],
    tone: 'chaotic, humorous, meme-maximalist',
  },
};

export interface EnhancedGenerateOptions {
  keyAngle?: string;
  priorityChannel?: string;
  toneHints?: string;
  vibeMode?: keyof typeof VIBE_MODES;
  templateType?: string;
  includeOnchainStats?: boolean;
}

export function generateEnhancedScriptVariants(
  contentRef: ContentRef,
  options: EnhancedGenerateOptions = {}
): Omit<ScriptVariant, 'id' | 'createdAt'>[] {
  const vibeMode = options.vibeMode || 'builder';
  const vibe = VIBE_MODES[vibeMode];
  
  const scripts: Omit<ScriptVariant, 'id' | 'createdAt'>[] = [];

  // X Short Post (Hype)
  scripts.push({
    contentRefId: contentRef.id,
    channel: 'x',
    style: 'hype',
    length: 'short',
    body: `${vibe.emoji} ${contentRef.primaryEmoji} ${contentRef.name} is ${vibeMode === 'degen' ? 'mooning' : 'live'} on ${contentRef.chain || 'Base'}!\n\n${options.keyAngle || `Building the future of ${contentRef.category}`} ${vibe.keywords.slice(0, 2).join(', ')}\n\n${vibeMode === 'degen' ? 'LFG! 🚀' : vibeMode === 'shitpost' ? 'This is the way 😂' : 'Check it out 👇'}`,
    threadParts: [],
    callToAction: vibeMode === 'degen' ? 'Ape in now!' : 'Learn more',
    notes: `Auto-generated v1 - ${vibeMode} vibe`,
    status: 'draft',
    seoTitle: `${contentRef.name} - ${contentRef.category} on ${contentRef.chain || 'Base'}`,
    seoDescription: `${contentRef.name}: ${options.keyAngle || `The next generation of ${contentRef.category}`}`,
    seoKeywords: [contentRef.category, contentRef.chain || 'Base', contentRef.type, ...vibe.keywords.slice(0, 3)],
    seoHashtags: [`#${contentRef.chain || 'Base'}`, `#${contentRef.category}`, `#${contentRef.type}`, `#crypto`],
    altText: `${contentRef.name} ${contentRef.type} on ${contentRef.chain || 'Base'}`,
    primaryGeoTargets: [],
    bodyLocalized: {},
    tagsLocalized: {},
    vibeMode,
    onchainStats: options.includeOnchainStats ? {
      price: '$0.42',
      volume: '$125K',
      holders: 1337,
      mints: 5000,
    } : undefined,
  });

  // X Thread (Story)
  const threadParts = [
    `${vibe.emoji} Thread: Everything you need to know about ${contentRef.name}`,
    `${contentRef.name} is ${options.keyAngle || `revolutionizing ${contentRef.category}`}. Here's why it matters 👇`,
    vibeMode === 'builder' 
      ? `Built on ${contentRef.chain || 'Base'}, it's composable, permissionless, and open source.`
      : vibeMode === 'degen'
      ? `This thing is gonna moon harder than anything you've seen. Trust me bro 🚀`
      : `The ${contentRef.category} space needed this. The community is already vibing.`,
    vibeMode === 'culture'
      ? `The lore is deep. The community is strong. This is more than just a ${contentRef.type}.`
      : vibeMode === 'normie'
      ? `Don't worry if you're new to crypto - this is designed to be easy and accessible for everyone.`
      : `${vibe.keywords[0]}, ${vibe.keywords[1]}, ${vibe.keywords[2]}. That's all you need to know.`,
    `Ready to join? ${vibeMode === 'degen' ? 'LFG! 🦍' : vibeMode === 'shitpost' ? 'YOLO 😂' : 'Check it out! ✨'}`,
  ];

  scripts.push({
    contentRefId: contentRef.id,
    channel: 'x',
    style: 'story',
    length: 'long',
    body: threadParts.join('\n\n'),
    threadParts,
    callToAction: vibeMode === 'degen' ? 'Ape in' : 'Learn more',
    notes: `Auto-generated thread v1 - ${vibeMode} vibe`,
    status: 'draft',
    seoTitle: `${contentRef.name} Thread - Complete Guide`,
    seoDescription: `Deep dive into ${contentRef.name} on ${contentRef.chain || 'Base'}`,
    seoKeywords: [contentRef.category, 'thread', contentRef.chain || 'Base', ...vibe.keywords.slice(0, 3)],
    seoHashtags: [`#${contentRef.chain || 'Base'}Thread`, `#${contentRef.category}`, `#crypto`],
    altText: `${contentRef.name} complete guide thread`,
    primaryGeoTargets: [],
    bodyLocalized: {},
    tagsLocalized: {},
    vibeMode,
  });

  // Farcaster Cast
  scripts.push({
    contentRefId: contentRef.id,
    channel: 'farcaster',
    style: 'hype',
    length: 'short',
    body: `${contentRef.primaryEmoji} ${contentRef.name} just dropped on ${contentRef.chain || 'Base'}!\n\n${vibeMode === 'builder' ? 'Built different.' : vibeMode === 'degen' ? 'This is gonna print!' : 'The vibes are immaculate.'}\n\n${options.keyAngle || `The ${contentRef.category} you've been waiting for.`}`,
    threadParts: [],
    callToAction: 'Check it out',
    notes: `Auto-generated Farcaster cast - ${vibeMode} vibe`,
    status: 'draft',
    seoTitle: `${contentRef.name} on Farcaster`,
    seoDescription: `${contentRef.name} announcement on Farcaster`,
    seoKeywords: ['farcaster', contentRef.category, contentRef.chain || 'Base'],
    seoHashtags: [`#farcaster`, `#${contentRef.chain || 'Base'}`, `#${contentRef.category}`],
    altText: `${contentRef.name} Farcaster announcement`,
    primaryGeoTargets: [],
    bodyLocalized: {},
    tagsLocalized: {},
    vibeMode,
  });

  // Farcaster Frame
  scripts.push({
    contentRefId: contentRef.id,
    channel: 'farcaster',
    style: 'hype',
    length: 'short',
    body: `Frame: ${contentRef.name}\n\n${options.keyAngle || `Explore ${contentRef.category} on ${contentRef.chain || 'Base'}`}`,
    threadParts: [],
    callToAction: 'Open Frame',
    notes: `Frame copy - ${vibeMode} vibe`,
    status: 'draft',
    seoTitle: `${contentRef.name} Frame`,
    seoDescription: `Interactive ${contentRef.name} frame on Farcaster`,
    seoKeywords: ['frame', 'farcaster', contentRef.category],
    seoHashtags: [`#frames`, `#farcaster`],
    altText: `${contentRef.name} interactive frame`,
    primaryGeoTargets: [],
    bodyLocalized: {},
    tagsLocalized: {},
    vibeMode,
    frameButtonText: vibeMode === 'degen' ? 'LFG' : vibeMode === 'shitpost' ? 'Send It' : 'Explore',
    frameAspectRatio: '1.91:1',
  });

  // Zora Description
  scripts.push({
    contentRefId: contentRef.id,
    channel: 'zora',
    style: vibeMode === 'culture' ? 'story' : 'informational',
    length: 'medium',
    body: vibeMode === 'culture'
      ? `${contentRef.primaryEmoji} ${contentRef.name}\n\nEvery great movement starts with a story. This is ours.\n\n${options.keyAngle || `Born from the ${contentRef.category} community on ${contentRef.chain || 'Base'}, ${contentRef.name} represents more than just a ${contentRef.type}. It's a cultural artifact, a shared dream, a piece of the onchain future we're building together.`}\n\nMint yours and become part of the lore.`
      : `${contentRef.name}\n\n${options.keyAngle || `A ${contentRef.category} ${contentRef.type} on ${contentRef.chain || 'Base'}.`}\n\n${vibeMode === 'builder' ? 'Built with composability and openness at its core.' : vibeMode === 'degen' ? 'This is your ticket to the moon. NFA.' : `Join the ${contentRef.category} movement.`}\n\n${vibeMode === 'normie' ? 'Easy to mint, easy to love.' : 'Mint now while supply lasts.'}`,
    threadParts: [],
    callToAction: 'Mint on Zora',
    notes: `Zora description - ${vibeMode} vibe`,
    status: 'draft',
    seoTitle: `Mint ${contentRef.name} on Zora`,
    seoDescription: `${contentRef.name} - ${contentRef.category} ${contentRef.type} available on Zora`,
    seoKeywords: ['zora', 'mint', contentRef.category, contentRef.chain || 'Base', 'nft'],
    seoHashtags: [`#Zora`, `#${contentRef.chain || 'Base'}`, `#mint`, `#${contentRef.category}`],
    altText: `${contentRef.name} available to mint on Zora`,
    primaryGeoTargets: [],
    bodyLocalized: {},
    tagsLocalized: {},
    vibeMode,
  });

  // Base Feed Blurb
  scripts.push({
    contentRefId: contentRef.id,
    channel: 'base-feed',
    style: vibeMode === 'builder' ? 'informational' : 'hype',
    length: 'short',
    body: vibeMode === 'builder'
      ? `${contentRef.primaryEmoji} ${contentRef.name}\n\nNew ${contentRef.category} infrastructure on Base.\n\n${options.keyAngle || 'Composable, permissionless, and open source.'}\n\nBuilt for builders. 🛠️`
      : `${contentRef.primaryEmoji} ${contentRef.name} is live on Base!\n\n${options.keyAngle || `The ${contentRef.category} revolution starts now.`}\n\n${vibeMode === 'degen' ? 'Ape in before its too late! 🦍' : 'Join the movement! ✨'}`,
    threadParts: [],
    callToAction: 'Explore',
    notes: `Base feed post - ${vibeMode} vibe`,
    status: 'draft',
    seoTitle: `${contentRef.name} on Base`,
    seoDescription: `${contentRef.name} - ${contentRef.category} on the Base network`,
    seoKeywords: ['Base', contentRef.category, contentRef.type, 'onchain'],
    seoHashtags: [`#Base`, `#${contentRef.category}`, `#onchain`],
    altText: `${contentRef.name} announcement on Base`,
    primaryGeoTargets: [],
    bodyLocalized: {},
    tagsLocalized: {},
    vibeMode,
  });

  // Site Copy
  scripts.push({
    contentRefId: contentRef.id,
    channel: 'site-copy',
    style: vibeMode === 'normie' ? 'informational' : vibeMode === 'culture' ? 'story' : 'bullet',
    length: 'medium',
    body: vibeMode === 'normie'
      ? `Welcome to ${contentRef.name}\n\n${contentRef.name} is ${options.keyAngle || `making ${contentRef.category} accessible to everyone`}. Built on ${contentRef.chain || 'Base'}, it's designed to be simple, secure, and fun to use.\n\nWhether you're new to crypto or a seasoned pro, ${contentRef.name} has something for you. Join thousands of users already exploring the future of ${contentRef.category}.\n\nGet started in minutes.`
      : vibeMode === 'culture'
      ? `${contentRef.name}: A Cultural Movement\n\nIn the beginning, there was an idea. A vision of what ${contentRef.category} could be if we built it together, onchain, on ${contentRef.chain || 'Base'}.\n\n${contentRef.name} isn't just a ${contentRef.type}—it's a community, a vibe, a shared dream made real. Every interaction, every mint, every moment adds to the lore.\n\nThis is your invitation to be part of something bigger. Join us.`
      : `${contentRef.name}\n\n${options.keyAngle || `The ${contentRef.category} protocol built for the onchain future.`}\n\n• ${vibeMode === 'builder' ? 'Composable architecture' : 'Revolutionary approach'}\n• ${vibeMode === 'builder' ? 'Permissionless access' : 'Community-driven'}\n• ${vibeMode === 'builder' ? 'Open source' : 'Built on Base'}\n• ${vibeMode === 'builder' ? 'Built for builders' : 'Ready to launch'}\n\n${vibeMode === 'degen' ? 'Join the movement. LFG! 🚀' : 'Start building today.'}`,
    threadParts: [],
    callToAction: 'Get Started',
    notes: `Site copy - ${vibeMode} vibe`,
    status: 'draft',
    seoTitle: `${contentRef.name} - ${contentRef.category} on ${contentRef.chain || 'Base'}`,
    seoDescription: `${contentRef.name}: ${options.keyAngle || `The future of ${contentRef.category}, built on ${contentRef.chain || 'Base'}`}`,
    seoKeywords: [contentRef.name, contentRef.category, contentRef.chain || 'Base', contentRef.type, ...vibe.keywords.slice(0, 3)],
    seoHashtags: [`#${contentRef.name}`, `#${contentRef.category}`, `#${contentRef.chain || 'Base'}`],
    altText: `${contentRef.name} homepage`,
    primaryGeoTargets: [],
    bodyLocalized: {},
    tagsLocalized: {},
    vibeMode,
  });

  return scripts;
}
