import type { ContentRef } from '../spacetime_module_bindings/content_ref_type';

export interface GenerateScriptOptions {
  keyAngle?: string;
  priorityChannel?: string;
  toneHints?: string;
}

export interface GeneratedScript {
  channel: string;
  style: string;
  length: string;
  body: string;
  threadParts?: string[];
  callToAction?: string;
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
  notes: string;
}

export function generateScriptVariants(
  contentRef: ContentRef,
  options: GenerateScriptOptions = {}
): GeneratedScript[] {
  const scripts: GeneratedScript[] = [];
  const emoji = contentRef.primaryEmoji || '✨';
  const chain = contentRef.chain || 'Base';

  const xShortHype: GeneratedScript = {
    channel: 'x',
    style: 'hype',
    length: 'short',
    body: `${emoji} Just dropped: ${contentRef.name}!\n\n${options.keyAngle || 'The future of onchain culture'} is here on ${chain}.\n\n${options.toneHints || "Don't fade this"} 🚀`,
    callToAction: 'Check it out and join the movement',
    seoTitle: `${contentRef.name} - ${contentRef.category}`,
    seoDescription: `Discover ${contentRef.name}, a ${contentRef.contentType} on ${chain}`,
    seoKeywords: [contentRef.name, contentRef.category, chain, contentRef.contentType],
    seoHashtags: [`#${contentRef.category}`, `#${chain}`, '#crypto', '#web3'],
    altText: `${contentRef.name} promotional image`,
    notes: 'auto-generated v1 - short hype post',
  };

  const xThread: GeneratedScript = {
    channel: 'x',
    style: 'story',
    length: 'long',
    body: 'Thread explaining the vision and impact',
    threadParts: [
      `1/ ${emoji} Introducing ${contentRef.name}\n\nA new ${contentRef.contentType} that's changing the game on ${chain}.`,
      `2/ ${options.keyAngle || 'The vision is simple'}: bring culture onchain and empower creators.\n\nNo gatekeepers. Just pure vibes.`,
      `3/ Built on ${chain}, ${contentRef.name} leverages fast transactions and low fees to make participation accessible to everyone.`,
      `4/ Whether you're a builder, creator, or just vibing - there's a place for you here.\n\nThe community is growing fast.`,
      `5/ Ready to dive in?\n\n${options.toneHints || 'This is your moment'}. Join us and shape the future.\n\n${contentRef.name} 🚀`,
    ],
    callToAction: 'Join the community and start building',
    seoTitle: `${contentRef.name} Thread - Deep Dive`,
    seoDescription: `Complete guide to ${contentRef.name}: what it is, why it matters, and how to get involved`,
    seoKeywords: [contentRef.name, 'thread', contentRef.category, chain, 'guide'],
    seoHashtags: [`#${contentRef.category}`, `#${chain}`, '#thread', '#web3'],
    altText: `${contentRef.name} detailed explanation thread`,
    notes: 'auto-generated v1 - 5-part thread',
  };

  const farcasterCast: GeneratedScript = {
    channel: 'farcaster',
    style: 'informational',
    length: 'medium',
    body: `${emoji} ${contentRef.name}\n\nA ${contentRef.contentType} for ${options.keyAngle || 'the onchain community'}.\n\nBuilt on ${chain} with love ❤️\n\n${options.toneHints || 'LFG'}`,
    callToAction: 'Cast your thoughts and join the conversation',
    seoTitle: `${contentRef.name} on Farcaster`,
    seoDescription: `${contentRef.name} announcement on Farcaster - ${contentRef.category}`,
    seoKeywords: [contentRef.name, 'farcaster', contentRef.category, chain],
    seoHashtags: [`#${contentRef.category}`, '#farcaster', `#${chain}`],
    altText: `${contentRef.name} Farcaster announcement`,
    notes: 'auto-generated v1 - farcaster cast',
  };

  const zoraDescription: GeneratedScript = {
    channel: 'zora',
    style: 'informational',
    length: 'medium',
    body: `${contentRef.name}\n\n${options.keyAngle || 'A cultural artifact for the onchain generation'}\n\nCategory: ${contentRef.category}\nChain: ${chain}\n\nThis ${contentRef.contentType} represents ${options.toneHints || 'a new era of creative expression'}. Mint to support the vision and become part of the story.\n\nJoin us in building the future of digital culture.`,
    callToAction: 'Mint now and own a piece of history',
    seoTitle: `${contentRef.name} - Zora Drop`,
    seoDescription: `Mint ${contentRef.name} on Zora - ${contentRef.category} ${contentRef.contentType}`,
    seoKeywords: [contentRef.name, 'zora', 'mint', contentRef.category, chain, 'nft'],
    seoHashtags: ['#zora', `#${chain}`, '#mint', `#${contentRef.category}`],
    altText: `${contentRef.name} Zora minting page`,
    notes: 'auto-generated v1 - zora description',
  };

  const baseFeedBlurb: GeneratedScript = {
    channel: 'base-feed',
    style: 'informational',
    length: 'short',
    body: `${emoji} ${contentRef.name}\n\n${options.keyAngle || 'Onchain culture meets innovation'}\n\nA ${contentRef.contentType} in the ${contentRef.category} space.\n\nBuilt on ${chain} 🔵`,
    callToAction: 'Explore and engage',
    seoTitle: `${contentRef.name} | ${chain}`,
    seoDescription: `${contentRef.name} - ${contentRef.category} ${contentRef.contentType} on ${chain}`,
    seoKeywords: [contentRef.name, 'base', chain, contentRef.category],
    seoHashtags: [`#${chain}`, `#${contentRef.category}`, '#onchain'],
    altText: `${contentRef.name} Base feed post`,
    notes: 'auto-generated v1 - base feed blurb',
  };

  const siteCopy: GeneratedScript = {
    channel: 'site-copy',
    style: 'informational',
    length: 'medium',
    body: `${contentRef.name}\n\n${contentRef.name} is a ${contentRef.contentType} designed for ${options.keyAngle || 'the next generation of onchain creators and communities'}.\n\nBuilt on ${chain}, it combines cutting-edge technology with cultural relevance to deliver ${options.toneHints || 'an unparalleled experience'}.\n\nWhether you're here to explore, create, or connect - ${contentRef.name} provides the tools and community to make it happen.\n\nCategory: ${contentRef.category}\nChain: ${chain}`,
    callToAction: 'Get started today',
    seoTitle: `${contentRef.name} - ${contentRef.category} on ${chain}`,
    seoDescription: `${contentRef.name} is a ${contentRef.contentType} for ${contentRef.category}. Built on ${chain} for creators and communities.`,
    seoKeywords: [
      contentRef.name,
      contentRef.category,
      contentRef.contentType,
      chain,
      'onchain',
      'web3',
      'crypto',
    ],
    seoHashtags: [`#${contentRef.category}`, `#${chain}`, '#web3', '#crypto'],
    altText: `${contentRef.name} website hero image`,
    notes: 'auto-generated v1 - neutral site copy',
  };

  scripts.push(xShortHype, xThread, farcasterCast, zoraDescription, baseFeedBlurb, siteCopy);

  return scripts;
}

export function regenerateScript(
  originalScript: GeneratedScript,
  instructions: string,
  contentRef: ContentRef
): GeneratedScript {
  const emoji = contentRef.primaryEmoji || '✨';
  const chain = contentRef.chain || 'Base';

  let modifiedBody = originalScript.body;
  let modifiedThreadParts = originalScript.threadParts;

  if (instructions.toLowerCase().includes('shorter')) {
    modifiedBody = modifiedBody.split('\n').slice(0, 3).join('\n');
    if (modifiedThreadParts) {
      modifiedThreadParts = modifiedThreadParts.slice(0, 3);
    }
  }

  if (instructions.toLowerCase().includes('aggressive') || instructions.toLowerCase().includes('more hype')) {
    modifiedBody = modifiedBody + '\n\nLFG! 🚀🔥';
  }

  if (instructions.toLowerCase().includes('professional') || instructions.toLowerCase().includes('builders')) {
    modifiedBody = modifiedBody.replace(/LFG|🚀|🔥|vibes/gi, '').trim();
    modifiedBody = `${emoji} ${contentRef.name}\n\nA technical ${contentRef.contentType} for developers and builders.\n\nBuilt on ${chain} with a focus on performance and scalability.`;
  }

  return {
    ...originalScript,
    body: modifiedBody,
    threadParts: modifiedThreadParts,
    notes: `${originalScript.notes} (regenerated: ${instructions})`,
  };
}

export interface GeoTarget {
  id: string;
  region: string;
  country?: string;
  cityOrMarket?: string;
  language: string;
}

export function generateGeoVariants(
  script: GeneratedScript,
  geoTargets: GeoTarget[],
  contentRef: ContentRef
): {
  bodyLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
} {
  const bodyLocalized: Record<string, string> = {};
  const tagsLocalized: Record<string, string[]> = {};
  const emoji = contentRef.primaryEmoji || '✨';

  for (const geo of geoTargets) {
    const geoKey = geo.id;

    if (geo.language === 'es') {
      bodyLocalized[geoKey] = `${emoji} ${contentRef.name}\n\n¡Únete a la revolución onchain en ${contentRef.chain || 'Base'}!\n\nCategoría: ${contentRef.category}\n\n¡Vamos! 🚀`;
      tagsLocalized[geoKey] = ['#crypto', '#web3', '#latam', `#${contentRef.category}`];
    } else if (geo.language === 'pt-BR') {
      bodyLocalized[geoKey] = `${emoji} ${contentRef.name}\n\nJunte-se à revolução onchain em ${contentRef.chain || 'Base'}!\n\nCategoria: ${contentRef.category}\n\nVamos lá! 🚀`;
      tagsLocalized[geoKey] = ['#crypto', '#web3', '#brasil', `#${contentRef.category}`];
    } else {
      bodyLocalized[geoKey] = script.body;
      tagsLocalized[geoKey] = script.seoHashtags;
    }
  }

  return { bodyLocalized, tagsLocalized };
}

export function exportScriptBundle(
  contentRef: ContentRef,
  scripts: Array<{
    channel: string;
    style: string;
    length: string;
    status: string;
    body: string;
    threadParts: string;
    callToAction: string;
    seoTitle: string;
    seoDescription: string;
    seoHashtags: string;
    notes: string;
    bodyLocalized: string;
  }>
): string {
  const emoji = contentRef.primaryEmoji || '✨';
  let output = `${emoji} SCRIPT BUNDLE: ${contentRef.name}\n`;
  output += `Type: ${contentRef.contentType}\n`;
  output += `Category: ${contentRef.category}\n`;
  output += `Chain: ${contentRef.chain || 'N/A'}\n`;
  output += `\n${'='.repeat(60)}\n\n`;

  const groupedByChannel: Record<string, typeof scripts> = {};
  for (const script of scripts) {
    if (!groupedByChannel[script.channel]) {
      groupedByChannel[script.channel] = [];
    }
    groupedByChannel[script.channel].push(script);
  }

  for (const [channel, channelScripts] of Object.entries(groupedByChannel)) {
    output += `📱 ${channel.toUpperCase()}\n`;
    output += `${'-'.repeat(60)}\n\n`;

    for (const script of channelScripts) {
      output += `[${script.style} / ${script.length} / ${script.status}]\n\n`;

      if (script.threadParts && script.threadParts !== '[]') {
        try {
          const parts = JSON.parse(script.threadParts);
          if (Array.isArray(parts) && parts.length > 0) {
            for (const part of parts) {
              output += `${part}\n\n`;
            }
          } else {
            output += `${script.body}\n\n`;
          }
        } catch {
          output += `${script.body}\n\n`;
        }
      } else {
        output += `${script.body}\n\n`;
      }

      if (script.callToAction) {
        output += `CTA: ${script.callToAction}\n\n`;
      }

      output += `SEO Title: ${script.seoTitle}\n`;
      output += `SEO Description: ${script.seoDescription}\n`;
      output += `Hashtags: ${script.seoHashtags}\n`;

      if (script.bodyLocalized && script.bodyLocalized !== '{}') {
        try {
          const localized = JSON.parse(script.bodyLocalized);
          const geoKeys = Object.keys(localized);
          if (geoKeys.length > 0) {
            output += `\nGeo Variants: ${geoKeys.join(', ')}\n`;
          }
        } catch {
          // Ignore parsing errors
        }
      }

      output += `\nNotes: ${script.notes}\n`;
      output += `\n${'-'.repeat(60)}\n\n`;
    }
  }

  return output;
}
