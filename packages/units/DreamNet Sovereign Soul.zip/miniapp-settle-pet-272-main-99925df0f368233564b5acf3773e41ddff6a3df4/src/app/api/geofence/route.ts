import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const lat = parseFloat(searchParams.get('lat') || '0');
    const lng = parseFloat(searchParams.get('lng') || '0');
    
    if (isNaN(lat) || isNaN(lng)) {
      return NextResponse.json({ error: 'Invalid coordinates' }, { status: 400 });
    }

    // Determine region and calculate memetic data
    const regionData = getRegionalData(lat, lng);
    
    return NextResponse.json({
      ...regionData,
      coordinates: { lat, lng },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Geofence error:', error);
    return NextResponse.json({ error: 'Geofence lookup failed' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const { coordinates, action } = await request.json();
    
    if (!coordinates || !coordinates.lat || !coordinates.lng) {
      return NextResponse.json({ error: 'Invalid coordinates' }, { status: 400 });
    }

    const { lat, lng } = coordinates;
    const regionData = getRegionalData(lat, lng);
    
    // Simulate geofence event logging
    const event = {
      id: generateEventId(),
      action: action || 'location_update',
      region: regionData.region,
      coordinates: { lat, lng },
      timestamp: new Date().toISOString(),
      memeticImpact: calculateMemeticImpact(regionData),
    };
    
    return NextResponse.json({
      success: true,
      event,
      regionData,
    });
  } catch (error) {
    console.error('Geofence event error:', error);
    return NextResponse.json({ error: 'Event processing failed' }, { status: 500 });
  }
}

function getRegionalData(lat: number, lng: number) {
  // North America
  if (lat >= 25 && lat <= 70 && lng >= -170 && lng <= -50) {
    return {
      region: 'North America',
      resonanceModifier: 1.2,
      memeticVelocity: Math.floor(Math.random() * 10) + 90, // 90-99
      activeSeedsCount: Math.floor(Math.random() * 5) + 10, // 10-14
      networkNodes: 847,
      propagationRate: 0.94,
    };
  }
  
  // Europe
  if (lat >= 35 && lat <= 70 && lng >= -15 && lng <= 60) {
    return {
      region: 'Europe',
      resonanceModifier: 1.1,
      memeticVelocity: Math.floor(Math.random() * 8) + 85, // 85-92
      activeSeedsCount: Math.floor(Math.random() * 4) + 8, // 8-11
      networkNodes: 623,
      propagationRate: 0.87,
    };
  }
  
  // Asia-Pacific
  if (lat >= -10 && lat <= 70 && lng >= 60 && lng <= 180) {
    return {
      region: 'Asia-Pacific',
      resonanceModifier: 1.3,
      memeticVelocity: Math.floor(Math.random() * 12) + 88, // 88-99
      activeSeedsCount: Math.floor(Math.random() * 6) + 12, // 12-17
      networkNodes: 1156,
      propagationRate: 0.96,
    };
  }
  
  // South America
  if (lat >= -60 && lat <= 15 && lng >= -90 && lng <= -30) {
    return {
      region: 'South America',
      resonanceModifier: 1.0,
      memeticVelocity: Math.floor(Math.random() * 6) + 75, // 75-80
      activeSeedsCount: Math.floor(Math.random() * 3) + 6, // 6-8
      networkNodes: 234,
      propagationRate: 0.76,
    };
  }
  
  // Africa
  if (lat >= -35 && lat <= 35 && lng >= -20 && lng <= 50) {
    return {
      region: 'Africa',
      resonanceModifier: 1.1,
      memeticVelocity: Math.floor(Math.random() * 7) + 78, // 78-84
      activeSeedsCount: Math.floor(Math.random() * 4) + 7, // 7-10
      networkNodes: 189,
      propagationRate: 0.81,
    };
  }
  
  // Default/Ocean/Antarctica
  return {
    region: 'Global Network',
    resonanceModifier: 1.0,
    memeticVelocity: Math.floor(Math.random() * 5) + 70, // 70-74
    activeSeedsCount: Math.floor(Math.random() * 3) + 5, // 5-7
    networkNodes: 45,
    propagationRate: 0.72,
  };
}

function calculateMemeticImpact(regionData: any) {
  const baseImpact = regionData.memeticVelocity * regionData.propagationRate;
  const nodeBonus = Math.log10(regionData.networkNodes) * 10;
  return Math.round(baseImpact + nodeBonus);
}

function generateEventId(): string {
  return `geo_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}