import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const { phrases } = await request.json();
    
    if (!phrases || !Array.isArray(phrases)) {
      return NextResponse.json({ error: 'Invalid phrases array' }, { status: 400 });
    }

    // Simulate AI SEO analysis
    const analysis = phrases.map((phrase: string, index: number) => {
      const words = phrase.toLowerCase().split(' ');
      const keywordDensity = words.length <= 6 ? 'optimal' : 'verbose';
      
      // Simulate keyword extraction
      const keywords = words
        .filter(word => word.length > 3)
        .slice(0, 3)
        .map(word => word.replace(/[^\w]/g, ''));
      
      // Simulate SEO metrics
      const seoScore = Math.floor(Math.random() * 30) + 70; // 70-100 range
      const searchVolume = Math.floor(Math.random() * 2000) + 500;
      const competition = Math.floor(Math.random() * 50) + 25;
      
      return {
        id: index,
        phrase,
        seoScore,
        keywords,
        keywordDensity,
        searchVolume,
        competition,
        recommendations: generateRecommendations(phrase, seoScore),
        sentiment: analyzeSentiment(phrase),
      };
    });

    return NextResponse.json({ 
      analysis,
      timestamp: new Date().toISOString(),
      totalPhrases: phrases.length,
    });
  } catch (error) {
    console.error('SEO analysis error:', error);
    return NextResponse.json({ error: 'Analysis failed' }, { status: 500 });
  }
}

function generateRecommendations(phrase: string, seoScore: number): string[] {
  const recommendations: string[] = [];
  
  if (phrase.length > 50) {
    recommendations.push('Consider shortening the phrase for better readability');
  }
  
  if (!/\d/.test(phrase) && Math.random() > 0.5) {
    recommendations.push('Adding specific numbers could improve engagement');
  }
  
  if (seoScore < 80) {
    recommendations.push('Include trending keywords to boost viral potential');
  }
  
  if (!/[><=]/.test(phrase) && phrase.includes('than')) {
    recommendations.push('Use symbols (>, <, =) for technical appeal');
  }
  
  return recommendations.length > 0 ? recommendations : ['Phrase is well-optimized'];
}

function analyzeSentiment(phrase: string): { score: number; label: string } {
  const positiveWords = ['sovereign', 'autonomy', 'freedom', 'optimal', 'emergence', 'future'];
  const negativeWords = ['manual', 'intervention', 'forget', 'budget'];
  
  let score = 50; // neutral
  
  positiveWords.forEach(word => {
    if (phrase.toLowerCase().includes(word)) score += 10;
  });
  
  negativeWords.forEach(word => {
    if (phrase.toLowerCase().includes(word)) score -= 5;
  });
  
  score = Math.max(0, Math.min(100, score));
  
  let label = 'neutral';
  if (score >= 70) label = 'positive';
  else if (score <= 30) label = 'negative';
  
  return { score, label };
}