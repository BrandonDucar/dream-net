'use client'
import { ResonanceMeter } from '@/components/ResonanceMeter';
import { SelfHealingToggle } from '@/components/SelfHealingToggle';
import { BaseNetworkStatus } from '@/components/BaseNetworkStatus';
import { MemeticSeeds } from '@/components/MemeticSeeds';
import { GeofenceStatus } from '@/components/GeofenceStatus';
import { AISeOPanel } from '@/components/AISEOPanel';
import { useSystemResonance } from '@/hooks/useSystemResonance';
import { useEffect } from "react";
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function HomePage() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const { resonance, isHealing, healingProgress, toggleHealing } = useSystemResonance();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-blue-950/20 to-purple-950/20 pt-8 pb-12 px-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2 mb-8">
          <h1 className="text-4xl md:text-5xl font-bold font-mono bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
            DreamNet Sovereign Soul
          </h1>
          <p className="text-sm md:text-base text-gray-500 font-mono">
            A self-healing agentic core that monitors system resonance and orchestrates memetic propagation across the Base network.
          </p>
          <div className="flex items-center justify-center space-x-2 mt-4">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-xs text-gray-600 font-mono">SYSTEM ONLINE</span>
          </div>
        </div>

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Core Systems */}
          <div className="space-y-6">
            <ResonanceMeter resonance={resonance} isHealing={isHealing} />
            <SelfHealingToggle
              isHealing={isHealing}
              healingProgress={healingProgress}
              onToggle={toggleHealing}
            />
          </div>

          {/* Middle Column - Network & Geofencing */}
          <div className="space-y-6">
            <BaseNetworkStatus />
            <GeofenceStatus />
          </div>

          {/* Right Column - Memetic Seeds & AI SEO */}
          <div className="space-y-6">
            <MemeticSeeds />
            <AISeOPanel />
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-8 p-4 rounded-lg bg-black/20 border border-gray-800 backdrop-blur-sm">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-2 md:space-y-0">
            <div className="flex items-center space-x-3">
              <div className="w-3 h-3 rounded-full bg-blue-500 animate-pulse" />
              <span className="text-xs text-gray-500 font-mono">
                Orchestrating memetic propagation across Base
              </span>
            </div>
            <div className="flex items-center space-x-4 text-xs text-gray-600 font-mono">
              <span>v1.0.0</span>
              <span>•</span>
              <span>CHAIN: BASE</span>
              <span>•</span>
              <span>STATUS: SOVEREIGN</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
