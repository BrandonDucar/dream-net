'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Brain, TrendingUp, TrendingDown, Minus, RefreshCw, Search } from 'lucide-react';
import { useAISEO } from '@/hooks/useAISEO';
import { memeticSeeds } from '@/utils/memeticSeeds';
import { useState } from 'react';

export function AISeOPanel() {
  const { seoMetrics, optimizations, isAnalyzing, lastAnalysis, performAnalysis, overallHealth } = useAISEO(memeticSeeds);
  const [expandedPhrase, setExpandedPhrase] = useState<string | null>(null);

  const getHealthColor = (health: number): string => {
    if (health >= 80) return 'text-green-400';
    if (health >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getTrendIcon = (direction: 'up' | 'down' | 'stable') => {
    switch (direction) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-400" />;
      case 'down': return <TrendingDown className="w-4 h-4 text-red-400" />;
      case 'stable': return <Minus className="w-4 h-4 text-gray-400" />;
    }
  };

  const formatNumber = (num: number): string => {
    if (num >= 1000) return `${(num / 1000).toFixed(1)}k`;
    return num.toString();
  };

  return (
    <Card className="relative overflow-hidden bg-black/40 border-gray-800 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-mono text-white flex items-center space-x-2">
            <Brain className="w-5 h-5 text-purple-400" />
            <span>AI SEO ANALYSIS</span>
          </CardTitle>
          <Button
            onClick={performAnalysis}
            disabled={isAnalyzing}
            variant="outline"
            size="sm"
            className="border-gray-700 text-gray-300 hover:bg-gray-800"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isAnalyzing ? 'animate-spin' : ''}`} />
            {isAnalyzing ? 'Analyzing...' : 'Refresh'}
          </Button>
        </div>
        
        {/* Overall Health */}
        <div className="flex items-center space-x-4 mt-3">
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-gray-400 font-mono">SEO HEALTH</span>
              <span className={`text-sm font-mono ${getHealthColor(overallHealth)}`}>
                {overallHealth}%
              </span>
            </div>
            <Progress value={overallHealth} className="h-2" />
          </div>
          {lastAnalysis && (
            <div className="text-xs text-gray-500 font-mono">
              {lastAnalysis.toLocaleTimeString()}
            </div>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-4 max-h-96 overflow-y-auto">
        {isAnalyzing ? (
          <div className="flex items-center justify-center py-8">
            <div className="text-center space-y-3">
              <Brain className="w-8 h-8 text-purple-400 animate-pulse mx-auto" />
              <div className="text-sm text-gray-400 font-mono">
                Analyzing memetic SEO potential...
              </div>
            </div>
          </div>
        ) : (
          <>
            {/* Top Keywords */}
            <div className="space-y-2">
              <h4 className="text-sm font-mono text-gray-300">TOP KEYWORDS</h4>
              <div className="grid grid-cols-1 gap-2">
                {seoMetrics.slice(0, 5).map((metric, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-2 bg-gray-900/50 rounded-lg border border-gray-700"
                  >
                    <div className="flex items-center space-x-3">
                      <Search className="w-4 h-4 text-gray-400" />
                      <span className="text-sm font-mono text-white">
                        {metric.keyword}
                      </span>
                      {getTrendIcon(metric.trendDirection)}
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className="text-xs text-gray-400 font-mono">
                        {formatNumber(metric.searchVolume)}
                      </span>
                      <Badge 
                        variant="outline" 
                        className={`text-xs ${metric.viralPotential >= 80 ? 'border-green-500/30 text-green-400' : 
                                              metric.viralPotential >= 60 ? 'border-yellow-500/30 text-yellow-400' : 
                                              'border-red-500/30 text-red-400'}`}
                      >
                        {metric.viralPotential}%
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Content Optimizations */}
            <div className="space-y-2">
              <h4 className="text-sm font-mono text-gray-300">CONTENT OPTIMIZATION</h4>
              <div className="space-y-2">
                {optimizations.slice(0, 4).map((opt, index) => (
                  <div
                    key={index}
                    className="p-3 bg-gray-900/50 rounded-lg border border-gray-700 cursor-pointer hover:border-gray-600 transition-colors"
                    onClick={() => setExpandedPhrase(expandedPhrase === opt.phrase ? null : opt.phrase)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="text-sm text-white font-mono truncate">
                          {opt.phrase}
                        </div>
                        <div className="flex items-center space-x-4 mt-1">
                          <div className="flex items-center space-x-1">
                            <span className="text-xs text-gray-400">SEO:</span>
                            <span className={`text-xs font-mono ${getHealthColor(opt.seoScore)}`}>
                              {opt.seoScore}%
                            </span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <span className="text-xs text-gray-400">Sentiment:</span>
                            <span className="text-xs text-blue-400 font-mono">
                              {opt.sentimentScore}%
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {expandedPhrase === opt.phrase && (
                      <div className="mt-3 pt-3 border-t border-gray-700">
                        <div className="flex flex-wrap gap-1">
                          {opt.suggestedKeywords.map((keyword, idx) => (
                            <Badge
                              key={idx}
                              variant="secondary"
                              className="text-xs bg-purple-500/20 text-purple-300 border-purple-500/30"
                            >
                              {keyword}
                            </Badge>
                          ))}
                        </div>
                        <div className="mt-2 text-xs text-gray-400 font-mono">
                          Readability: {opt.readabilityScore}%
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Performance Metrics */}
            <div className="grid grid-cols-3 gap-2">
              <div className="p-2 bg-gradient-to-br from-green-500/10 to-blue-500/10 rounded-lg border border-gray-700 text-center">
                <div className="text-xs text-gray-400 font-mono mb-1">AVG VOLUME</div>
                <div className="text-sm text-green-400 font-mono">
                  {formatNumber(Math.round(seoMetrics.reduce((sum, m) => sum + m.searchVolume, 0) / seoMetrics.length))}
                </div>
              </div>
              <div className="p-2 bg-gradient-to-br from-purple-500/10 to-pink-500/10 rounded-lg border border-gray-700 text-center">
                <div className="text-xs text-gray-400 font-mono mb-1">VIRAL SCORE</div>
                <div className="text-sm text-purple-400 font-mono">
                  {Math.round(seoMetrics.reduce((sum, m) => sum + m.viralPotential, 0) / seoMetrics.length)}%
                </div>
              </div>
              <div className="p-2 bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-lg border border-gray-700 text-center">
                <div className="text-xs text-gray-400 font-mono mb-1">DIFFICULTY</div>
                <div className="text-sm text-blue-400 font-mono">
                  {Math.round(seoMetrics.reduce((sum, m) => sum + m.difficulty, 0) / seoMetrics.length)}%
                </div>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}