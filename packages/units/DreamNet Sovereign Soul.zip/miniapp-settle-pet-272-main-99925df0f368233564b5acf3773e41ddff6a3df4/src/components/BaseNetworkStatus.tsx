'use client';

import type { FC } from 'react';
import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';

type NetworkStatus = 'optimal' | 'syncing' | 'active';

export const BaseNetworkStatus: FC = () => {
  const [status, setStatus] = useState<NetworkStatus>('optimal');
  const [blockHeight, setBlockHeight] = useState<number>(12847392);
  const [latency, setLatency] = useState<number>(12);

  useEffect(() => {
    const statusInterval = setInterval(() => {
      const statuses: NetworkStatus[] = ['optimal', 'syncing', 'active'];
      const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
      setStatus(randomStatus);
    }, 8000);

    const blockInterval = setInterval(() => {
      setBlockHeight((prev: number) => prev + 1);
    }, 2000);

    const latencyInterval = setInterval(() => {
      setLatency(Math.floor(Math.random() * 20) + 8);
    }, 3000);

    return () => {
      clearInterval(statusInterval);
      clearInterval(blockInterval);
      clearInterval(latencyInterval);
    };
  }, []);

  const getStatusColor = (networkStatus: NetworkStatus): string => {
    switch (networkStatus) {
      case 'optimal':
        return 'bg-green-500';
      case 'syncing':
        return 'bg-yellow-500';
      case 'active':
        return 'bg-blue-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusText = (networkStatus: NetworkStatus): string => {
    switch (networkStatus) {
      case 'optimal':
        return 'OPTIMAL';
      case 'syncing':
        return 'SYNCING';
      case 'active':
        return 'ACTIVE';
      default:
        return 'UNKNOWN';
    }
  };

  return (
    <Card className="p-6 bg-black/40 border-blue-600/30 backdrop-blur-sm">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-mono text-gray-400 uppercase tracking-wider">
            Base Network
          </h2>
          <Badge 
            variant="outline" 
            className={`${getStatusColor(status)} text-black font-mono text-xs border-none`}
          >
            {getStatusText(status)}
          </Badge>
        </div>

        <div className="flex items-center space-x-3">
          <div className={`w-4 h-4 rounded-full ${getStatusColor(status)} ${status === 'optimal' ? 'animate-pulse' : ''} shadow-lg`} 
               style={{
                 boxShadow: `0 0 20px ${status === 'optimal' ? '#10b981' : status === 'syncing' ? '#eab308' : '#3b82f6'}`,
               }}
          />
          <div className="flex-1">
            <p className="text-xs text-gray-500 font-mono">CHAIN ID: 8453</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 pt-2">
          <div>
            <p className="text-xs text-gray-600 font-mono mb-1">Block Height</p>
            <p className="text-lg font-mono text-blue-400">{blockHeight.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-xs text-gray-600 font-mono mb-1">Latency</p>
            <p className="text-lg font-mono text-green-400">{latency}ms</p>
          </div>
        </div>

        <div className="pt-2 border-t border-gray-800">
          <div className="flex justify-between items-center">
            <span className="text-xs font-mono text-gray-600">Network Health</span>
            <span className="text-xs font-mono text-green-400">99.8%</span>
          </div>
        </div>
      </div>
    </Card>
  );
};
