'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Globe, TrendingUp, Zap } from 'lucide-react';
import { useGeofencing } from '@/hooks/useGeofencing';
import { useEffect, useState } from 'react';

export function GeofenceStatus() {
  const { geofenceData, isLocationEnabled, locationError, requestLocation } = useGeofencing();
  const [pulseKey, setPulseKey] = useState<number>(0);

  // Trigger pulse animation when data updates
  useEffect(() => {
    setPulseKey(prev => prev + 1);
  }, [geofenceData.region, geofenceData.memeticVelocity]);

  const getRegionColor = (region: string): string => {
    switch (region) {
      case 'North America': return 'bg-blue-500/20 border-blue-500/30';
      case 'Europe': return 'bg-purple-500/20 border-purple-500/30';
      case 'Asia-Pacific': return 'bg-pink-500/20 border-pink-500/30';
      default: return 'bg-gray-500/20 border-gray-500/30';
    }
  };

  const getVelocityLevel = (velocity: number): { label: string; color: string } => {
    if (velocity >= 90) return { label: 'HYPERSONIC', color: 'text-pink-400' };
    if (velocity >= 80) return { label: 'VIRAL', color: 'text-purple-400' };
    if (velocity >= 70) return { label: 'SPREADING', color: 'text-blue-400' };
    return { label: 'EMERGING', color: 'text-gray-400' };
  };

  const velocityLevel = getVelocityLevel(geofenceData.memeticVelocity);

  return (
    <Card className="relative overflow-hidden bg-black/40 border-gray-800 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-mono text-white flex items-center space-x-2">
          <MapPin className="w-5 h-5 text-blue-400" />
          <span>GEOFENCE STATUS</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {locationError ? (
          <div className="text-center space-y-3">
            <div className="text-red-400 text-sm font-mono">
              LOCATION ACCESS DENIED
            </div>
            <Button 
              onClick={requestLocation}
              variant="outline"
              size="sm"
              className="border-gray-700 text-gray-300 hover:bg-gray-800"
            >
              <Globe className="w-4 h-4 mr-2" />
              Enable Location
            </Button>
          </div>
        ) : (
          <>
            {/* Regional Info */}
            <div className={`p-3 rounded-lg border ${getRegionColor(geofenceData.region)}`}>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-white font-mono text-sm">
                    {geofenceData.region}
                  </div>
                  {geofenceData.coordinates && (
                    <div className="text-xs text-gray-400 font-mono mt-1">
                      {geofenceData.coordinates.lat.toFixed(2)}°, {geofenceData.coordinates.lng.toFixed(2)}°
                    </div>
                  )}
                </div>
                {isLocationEnabled && (
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                )}
              </div>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 gap-3">
              {/* Resonance Modifier */}
              <div className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 p-3 rounded-lg border border-gray-700">
                <div className="text-xs text-gray-400 font-mono mb-1">RESONANCE MOD</div>
                <div className="text-xl font-mono text-blue-400">
                  {geofenceData.resonanceModifier.toFixed(1)}x
                </div>
              </div>

              {/* Active Seeds */}
              <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 p-3 rounded-lg border border-gray-700">
                <div className="text-xs text-gray-400 font-mono mb-1">ACTIVE SEEDS</div>
                <div className="text-xl font-mono text-purple-400">
                  {geofenceData.activeSeedsCount}
                </div>
              </div>
            </div>

            {/* Memetic Velocity */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-400 font-mono">MEMETIC VELOCITY</span>
                <Badge variant="outline" className={`${velocityLevel.color} border-current`}>
                  {velocityLevel.label}
                </Badge>
              </div>
              
              <div className="relative">
                <div className="w-full bg-gray-800 rounded-full h-2">
                  <div 
                    key={pulseKey}
                    className="h-2 rounded-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 transition-all duration-1000 ease-out relative overflow-hidden"
                    style={{ width: `${geofenceData.memeticVelocity}%` }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer" />
                  </div>
                </div>
                <div className="flex justify-between text-xs text-gray-500 font-mono mt-1">
                  <span>0%</span>
                  <span className={velocityLevel.color}>
                    {geofenceData.memeticVelocity}%
                  </span>
                  <span>100%</span>
                </div>
              </div>
            </div>

            {/* Network Effect Indicator */}
            <div className="flex items-center justify-center space-x-2 p-2 bg-gray-900/50 rounded-lg">
              <TrendingUp className="w-4 h-4 text-green-400" />
              <span className="text-xs text-gray-400 font-mono">
                PROPAGATING ACROSS {geofenceData.region.toUpperCase()}
              </span>
              <Zap className="w-4 h-4 text-yellow-400 animate-pulse" />
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}