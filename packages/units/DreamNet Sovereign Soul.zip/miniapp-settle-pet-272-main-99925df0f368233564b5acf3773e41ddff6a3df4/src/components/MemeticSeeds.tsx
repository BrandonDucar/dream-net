'use client';

import type { FC } from 'react';
import { useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { memeticSeeds } from '@/utils/memeticSeeds';
import type { MemeticSeed } from '@/utils/memeticSeeds';

export const MemeticSeeds: FC = () => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = async (seed: MemeticSeed): Promise<void> => {
    await navigator.clipboard.writeText(seed.phrase);
    setCopiedId(seed.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getCategoryColor = (category: string): string => {
    switch (category) {
      case 'quantum':
        return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case 'sovereign':
        return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'network':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'agentic':
        return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      default:
        return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  return (
    <Card className="p-6 bg-black/40 border-purple-500/30 backdrop-blur-sm">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-mono text-gray-400 uppercase tracking-wider">
            Memetic Seeds
          </h2>
          <Badge variant="outline" className="bg-purple-500/20 text-purple-400 border-purple-500/30 font-mono text-xs">
            {memeticSeeds.length} ACTIVE
          </Badge>
        </div>

        <p className="text-xs text-gray-600 font-mono">
          Viral phrases propagating across the network
        </p>

        <div className="space-y-2 max-h-96 overflow-y-auto pr-2 custom-scrollbar">
          {memeticSeeds.map((seed: MemeticSeed) => (
            <div
              key={seed.id}
              onClick={() => handleCopy(seed)}
              className="p-3 rounded-lg bg-gray-900/50 border border-gray-800 hover:border-purple-500/50 transition-all cursor-pointer group"
            >
              <div className="flex items-start justify-between mb-2">
                <Badge 
                  variant="outline" 
                  className={`${getCategoryColor(seed.category)} font-mono text-[10px] uppercase`}
                >
                  {seed.category}
                </Badge>
                {copiedId === seed.id ? (
                  <span className="text-[10px] text-green-400 font-mono">COPIED!</span>
                ) : (
                  <span className="text-[10px] text-gray-600 font-mono opacity-0 group-hover:opacity-100 transition-opacity">
                    TAP TO COPY
                  </span>
                )}
              </div>

              <p className="text-sm text-gray-300 font-mono mb-2 leading-relaxed">
                "{seed.phrase}"
              </p>

              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-600 font-mono">Propagation</span>
                <div className="flex items-center space-x-2">
                  <div className="w-24 h-1.5 bg-gray-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-300"
                      style={{ width: `${seed.propagation}%` }}
                    />
                  </div>
                  <span className="text-xs text-purple-400 font-mono font-bold">
                    {seed.propagation}%
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <style jsx>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(17, 24, 39, 0.5);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(139, 92, 246, 0.3);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(139, 92, 246, 0.5);
        }
      `}</style>
    </Card>
  );
};
