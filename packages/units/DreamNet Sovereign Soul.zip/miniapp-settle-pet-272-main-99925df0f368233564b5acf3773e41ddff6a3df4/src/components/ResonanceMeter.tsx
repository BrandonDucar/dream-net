'use client';

import type { FC } from 'react';
import { Card } from './ui/card';
import { Progress } from './ui/progress';

interface ResonanceMeterProps {
  resonance: number;
  isHealing: boolean;
}

export const ResonanceMeter: FC<ResonanceMeterProps> = ({ resonance, isHealing }) => {
  const getResonanceColor = (value: number): string => {
    if (value >= 85) return 'text-green-400';
    if (value >= 70) return 'text-blue-400';
    if (value >= 55) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getResonanceStatus = (value: number): string => {
    if (value >= 85) return 'OPTIMAL';
    if (value >= 70) return 'STABLE';
    if (value >= 55) return 'FLUCTUATING';
    return 'CRITICAL';
  };

  return (
    <Card className="p-6 bg-black/40 border-blue-500/30 backdrop-blur-sm">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-mono text-gray-400 uppercase tracking-wider">
            System Resonance
          </h2>
          <span className={`text-xs font-mono ${getResonanceColor(resonance)}`}>
            {getResonanceStatus(resonance)}
          </span>
        </div>

        <div className="relative">
          <div className="flex items-end justify-center space-x-1 mb-3">
            <span className={`text-6xl font-bold font-mono ${getResonanceColor(resonance)} ${isHealing ? 'animate-pulse' : ''}`}>
              {Math.round(resonance)}
            </span>
            <span className="text-2xl font-mono text-gray-500 mb-2">%</span>
          </div>

          <Progress 
            value={resonance} 
            className="h-3 bg-gray-800/50"
          />

          {isHealing && (
            <div className="absolute inset-0 pointer-events-none">
              <div className="w-full h-full bg-gradient-to-r from-transparent via-blue-400/20 to-transparent animate-pulse" />
            </div>
          )}
        </div>

        <div className="flex justify-between text-xs font-mono text-gray-600">
          <span>0%</span>
          <span>50%</span>
          <span>100%</span>
        </div>
      </div>
    </Card>
  );
};
