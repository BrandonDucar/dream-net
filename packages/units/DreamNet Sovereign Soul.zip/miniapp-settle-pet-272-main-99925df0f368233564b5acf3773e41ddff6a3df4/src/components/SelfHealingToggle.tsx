'use client';

import type { FC } from 'react';
import { Card } from './ui/card';
import { Switch } from './ui/switch';
import { Progress } from './ui/progress';

interface SelfHealingToggleProps {
  isHealing: boolean;
  healingProgress: number;
  onToggle: () => void;
}

export const SelfHealingToggle: FC<SelfHealingToggleProps> = ({
  isHealing,
  healingProgress,
  onToggle,
}) => {
  return (
    <Card className="p-6 bg-black/40 border-green-500/30 backdrop-blur-sm">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-mono text-gray-400 uppercase tracking-wider">
              Self-Healing Protocol
            </h2>
            <p className="text-xs text-gray-600 mt-1 font-mono">
              {isHealing ? 'REPAIRING SYSTEM INTEGRITY...' : 'STANDBY MODE'}
            </p>
          </div>
          <Switch
            checked={isHealing}
            onCheckedChange={onToggle}
            className="data-[state=checked]:bg-green-500"
          />
        </div>

        {isHealing && (
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono text-gray-500">
              <span>Repair Progress</span>
              <span className="text-green-400">{Math.round(healingProgress)}%</span>
            </div>
            <Progress 
              value={healingProgress} 
              className="h-2 bg-gray-800/50"
            />
            
            <div className="mt-4 space-y-1">
              <div className="flex items-center space-x-2 text-xs font-mono">
                <div className={`w-2 h-2 rounded-full ${healingProgress > 20 ? 'bg-green-400' : 'bg-gray-700'} ${healingProgress > 20 ? 'animate-pulse' : ''}`} />
                <span className={healingProgress > 20 ? 'text-green-400' : 'text-gray-600'}>
                  Scanning anomalies...
                </span>
              </div>
              <div className="flex items-center space-x-2 text-xs font-mono">
                <div className={`w-2 h-2 rounded-full ${healingProgress > 50 ? 'bg-green-400' : 'bg-gray-700'} ${healingProgress > 50 ? 'animate-pulse' : ''}`} />
                <span className={healingProgress > 50 ? 'text-green-400' : 'text-gray-600'}>
                  Rebalancing nodes...
                </span>
              </div>
              <div className="flex items-center space-x-2 text-xs font-mono">
                <div className={`w-2 h-2 rounded-full ${healingProgress > 80 ? 'bg-green-400' : 'bg-gray-700'} ${healingProgress > 80 ? 'animate-pulse' : ''}`} />
                <span className={healingProgress > 80 ? 'text-green-400' : 'text-gray-600'}>
                  Optimizing resonance...
                </span>
              </div>
            </div>
          </div>
        )}

        {!isHealing && (
          <div className="flex items-center space-x-2 text-xs font-mono text-gray-600">
            <div className="w-2 h-2 rounded-full bg-gray-700" />
            <span>Tap to initiate repair sequence</span>
          </div>
        )}
      </div>
    </Card>
  );
};
