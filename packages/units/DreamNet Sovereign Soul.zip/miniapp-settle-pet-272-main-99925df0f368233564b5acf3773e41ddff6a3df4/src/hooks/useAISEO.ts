'use client';

import { useState, useEffect, useCallback } from 'react';
import type { MemeticSeed } from '@/utils/memeticSeeds';

export interface SEOMetrics {
  keyword: string;
  searchVolume: number;
  difficulty: number;
  viralPotential: number;
  trendDirection: 'up' | 'down' | 'stable';
}

export interface ContentOptimization {
  phrase: string;
  seoScore: number;
  suggestedKeywords: string[];
  sentimentScore: number;
  readabilityScore: number;
}

export function useAISEO(memeticSeeds: MemeticSeed[]) {
  const [seoMetrics, setSeoMetrics] = useState<SEOMetrics[]>([]);
  const [optimizations, setOptimizations] = useState<ContentOptimization[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [lastAnalysis, setLastAnalysis] = useState<Date | null>(null);

  // Simulate AI SEO analysis
  const analyzeMemeticSEO = useCallback((seeds: MemeticSeed[]): SEOMetrics[] => {
    return seeds.map(seed => {
      // Extract key terms from memetic phrases
      const words = seed.phrase.toLowerCase().split(' ').filter(w => w.length > 3);
      const keyword = words[0] || seed.category;
      
      // Simulate SEO metrics based on category and propagation
      const baseVolume = seed.category === 'network' ? 1200 : 
                       seed.category === 'sovereign' ? 800 :
                       seed.category === 'agentic' ? 600 : 400;
      
      const searchVolume = baseVolume + (seed.propagation * 10);
      const difficulty = Math.max(20, Math.min(80, 100 - seed.propagation + Math.random() * 20));
      const viralPotential = Math.min(100, seed.propagation + Math.random() * 15);
      
      const trends: Array<'up' | 'down' | 'stable'> = ['up', 'down', 'stable'];
      const trendDirection = trends[Math.floor(Math.random() * trends.length)];

      return {
        keyword,
        searchVolume: Math.round(searchVolume),
        difficulty: Math.round(difficulty),
        viralPotential: Math.round(viralPotential),
        trendDirection,
      };
    });
  }, []);

  // Generate content optimizations
  const generateOptimizations = useCallback((seeds: MemeticSeed[]): ContentOptimization[] => {
    return seeds.map(seed => {
      // Analyze phrase characteristics
      const wordCount = seed.phrase.split(' ').length;
      const hasNumbers = /\d/.test(seed.phrase);
      const hasSymbols = /[><=]/.test(seed.phrase);
      
      // Calculate scores
      const seoScore = Math.min(100, seed.propagation + 
        (wordCount <= 6 ? 10 : 0) + 
        (hasSymbols ? 5 : 0) + 
        Math.random() * 10);
      
      const sentimentScore = seed.category === 'sovereign' ? 85 + Math.random() * 10 :
                           seed.category === 'agentic' ? 75 + Math.random() * 15 :
                           seed.category === 'network' ? 70 + Math.random() * 20 :
                           60 + Math.random() * 25;
      
      const readabilityScore = 100 - (wordCount * 5) + (hasSymbols ? -5 : 5) + Math.random() * 10;
      
      // Generate relevant keywords
      const categoryKeywords = {
        sovereign: ['autonomy', 'decentralized', 'freedom', 'sovereignty'],
        network: ['blockchain', 'base', 'connection', 'protocol'],
        agentic: ['AI', 'agent', 'automation', 'intelligence'],
        quantum: ['quantum', 'emergence', 'resonance', 'entanglement'],
      };
      
      const suggestedKeywords = categoryKeywords[seed.category] || [];
      
      return {
        phrase: seed.phrase,
        seoScore: Math.round(seoScore),
        suggestedKeywords,
        sentimentScore: Math.round(sentimentScore),
        readabilityScore: Math.round(Math.max(0, readabilityScore)),
      };
    });
  }, []);

  // Perform AI SEO analysis
  const performAnalysis = useCallback(async () => {
    setIsAnalyzing(true);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const metrics = analyzeMemeticSEO(memeticSeeds);
    const optimizations = generateOptimizations(memeticSeeds);
    
    setSeoMetrics(metrics);
    setOptimizations(optimizations);
    setLastAnalysis(new Date());
    setIsAnalyzing(false);
  }, [memeticSeeds, analyzeMemeticSEO, generateOptimizations]);

  // Auto-analyze on mount and when seeds change
  useEffect(() => {
    if (memeticSeeds.length > 0) {
      performAnalysis();
    }
  }, [memeticSeeds, performAnalysis]);

  // Get overall SEO health
  const getOverallHealth = useCallback((): number => {
    if (optimizations.length === 0) return 0;
    
    const avgScore = optimizations.reduce((sum, opt) => sum + opt.seoScore, 0) / optimizations.length;
    return Math.round(avgScore);
  }, [optimizations]);

  return {
    seoMetrics,
    optimizations,
    isAnalyzing,
    lastAnalysis,
    performAnalysis,
    overallHealth: getOverallHealth(),
  };
}