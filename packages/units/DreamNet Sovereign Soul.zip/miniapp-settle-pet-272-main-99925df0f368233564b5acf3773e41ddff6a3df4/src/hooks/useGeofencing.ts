'use client';

import { useState, useEffect, useCallback } from 'react';

export interface GeofenceData {
  region: string;
  resonanceModifier: number;
  memeticVelocity: number;
  activeSeedsCount: number;
  coordinates: {
    lat: number;
    lng: number;
  } | null;
}

export function useGeofencing() {
  const [geofenceData, setGeofenceData] = useState<GeofenceData>({
    region: 'Unknown',
    resonanceModifier: 1.0,
    memeticVelocity: 0,
    activeSeedsCount: 0,
    coordinates: null,
  });
  const [isLocationEnabled, setIsLocationEnabled] = useState<boolean>(false);
  const [locationError, setLocationError] = useState<string | null>(null);

  // Regional data mapping
  const getRegionalData = useCallback((lat: number, lng: number): Omit<GeofenceData, 'coordinates'> => {
    // North America
    if (lat >= 25 && lat <= 70 && lng >= -170 && lng <= -50) {
      return {
        region: 'North America',
        resonanceModifier: 1.2,
        memeticVelocity: 94,
        activeSeedsCount: 12,
      };
    }
    // Europe
    if (lat >= 35 && lat <= 70 && lng >= -15 && lng <= 60) {
      return {
        region: 'Europe',
        resonanceModifier: 1.1,
        memeticVelocity: 87,
        activeSeedsCount: 9,
      };
    }
    // Asia
    if (lat >= -10 && lat <= 70 && lng >= 60 && lng <= 180) {
      return {
        region: 'Asia-Pacific',
        resonanceModifier: 1.3,
        memeticVelocity: 98,
        activeSeedsCount: 15,
      };
    }
    // Default/Other
    return {
      region: 'Global Network',
      resonanceModifier: 1.0,
      memeticVelocity: 78,
      activeSeedsCount: 8,
    };
  }, []);

  // Request location access
  const requestLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setLocationError('Geolocation not supported');
      return;
    }

    setLocationError(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        const regionalData = getRegionalData(latitude, longitude);
        
        setGeofenceData({
          ...regionalData,
          coordinates: { lat: latitude, lng: longitude },
        });
        setIsLocationEnabled(true);
      },
      (error) => {
        setLocationError(error.message);
        // Use default global data on error
        const defaultData = getRegionalData(0, 0);
        setGeofenceData({
          ...defaultData,
          coordinates: null,
        });
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000, // 5 minutes
      }
    );
  }, [getRegionalData]);

  // Auto-request location on mount
  useEffect(() => {
    requestLocation();
  }, [requestLocation]);

  // Periodic location updates for dynamic geofencing
  useEffect(() => {
    if (!isLocationEnabled) return;

    const interval = setInterval(() => {
      navigator.geolocation?.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          const regionalData = getRegionalData(latitude, longitude);
          
          setGeofenceData(prev => ({
            ...regionalData,
            coordinates: { lat: latitude, lng: longitude },
          }));
        },
        (error) => {
          console.warn('Geofence update failed:', error);
        },
        { enableHighAccuracy: false, timeout: 5000, maximumAge: 300000 }
      );
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, [isLocationEnabled, getRegionalData]);

  return {
    geofenceData,
    isLocationEnabled,
    locationError,
    requestLocation,
  };
}