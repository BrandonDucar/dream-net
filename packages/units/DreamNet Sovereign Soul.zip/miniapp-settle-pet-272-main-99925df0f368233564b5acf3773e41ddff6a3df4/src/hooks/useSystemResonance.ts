'use client';

import { useState, useEffect, useCallback } from 'react';

export function useSystemResonance() {
  const [resonance, setResonance] = useState<number>(72);
  const [isHealing, setIsHealing] = useState<boolean>(false);
  const [healingProgress, setHealingProgress] = useState<number>(0);

  // Natural resonance fluctuation
  useEffect(() => {
    if (isHealing) return;

    const interval = setInterval(() => {
      setResonance((prev: number) => {
        const change = (Math.random() - 0.5) * 3;
        const newValue = prev + change;
        return Math.max(50, Math.min(95, newValue));
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [isHealing]);

  // Self-healing sequence
  useEffect(() => {
    if (!isHealing) {
      setHealingProgress(0);
      return;
    }

    let progress = 0;
    const healingInterval = setInterval(() => {
      progress += 2;
      setHealingProgress(progress);

      // Boost resonance during healing
      setResonance((prev: number) => {
        const target = 95;
        const diff = target - prev;
        return prev + diff * 0.1;
      });

      if (progress >= 100) {
        clearInterval(healingInterval);
        setTimeout(() => {
          setIsHealing(false);
          setResonance(95);
        }, 500);
      }
    }, 50);

    return () => clearInterval(healingInterval);
  }, [isHealing]);

  const toggleHealing = useCallback(() => {
    setIsHealing((prev: boolean) => !prev);
  }, []);

  return {
    resonance,
    isHealing,
    healingProgress,
    toggleHealing,
  };
}
