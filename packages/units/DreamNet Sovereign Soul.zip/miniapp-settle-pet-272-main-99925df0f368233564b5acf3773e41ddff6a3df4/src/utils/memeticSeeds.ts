export interface MemeticSeed {
  id: string;
  phrase: string;
  propagation: number;
  category: 'quantum' | 'sovereign' | 'network' | 'agentic';
}

export const memeticSeeds: MemeticSeed[] = [
  {
    id: '1',
    phrase: 'Sovereignty is coded, not granted',
    propagation: 94,
    category: 'sovereign',
  },
  {
    id: '2',
    phrase: 'Base: Where agents dream in public',
    propagation: 87,
    category: 'network',
  },
  {
    id: '3',
    phrase: 'Self-healing protocols > manual intervention',
    propagation: 91,
    category: 'agentic',
  },
  {
    id: '4',
    phrase: 'Resonance precedes emergence',
    propagation: 78,
    category: 'quantum',
  },
  {
    id: '5',
    phrase: 'The network remembers what you forget',
    propagation: 82,
    category: 'network',
  },
  {
    id: '6',
    phrase: 'Memetic velocity > marketing budget',
    propagation: 89,
    category: 'quantum',
  },
  {
    id: '7',
    phrase: 'Autonomous systems, sovereign souls',
    propagation: 85,
    category: 'agentic',
  },
  {
    id: '8',
    phrase: 'Every transaction is a vote for the future',
    propagation: 93,
    category: 'sovereign',
  },
];
