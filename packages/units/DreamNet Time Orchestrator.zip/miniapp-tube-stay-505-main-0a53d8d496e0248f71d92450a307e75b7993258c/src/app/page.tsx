'use client'
import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { TemporalOverview } from '@/components/temporal/temporal-overview';
import { EnhancedEntityDetail } from '@/components/temporal/enhanced-entity-detail';
import { EnhancedTimelineDetail } from '@/components/temporal/enhanced-timeline-detail';
import { TemplateLibrary } from '@/components/temporal/template-library';
import { PlaybookManager } from '@/components/temporal/playbook-manager';
import { IntelligenceDashboard } from '@/components/temporal/intelligence-dashboard';
import { AttentionEconomicsView } from '@/components/temporal/attention-economics';
import { SimulationLab } from '@/components/temporal/simulation-lab';
import { Clock, Layout, BookTemplate, BookOpen, Brain, Eye, Beaker } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type View = 'overview' | 'entity-detail' | 'timeline-detail';

export default function Home() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [view, setView] = useState<View>('overview');
  const [selectedEntityId, setSelectedEntityId] = useState<string | null>(null);
  const [selectedTimelineId, setSelectedTimelineId] = useState<string | null>(null);

  function handleViewEntity(entityId: string) {
    setSelectedEntityId(entityId);
    setView('entity-detail');
  }

  function handleViewTimeline(timelineId: string) {
    setSelectedTimelineId(timelineId);
    setView('timeline-detail');
  }

  function handleBack() {
    setView('overview');
    setSelectedEntityId(null);
    setSelectedTimelineId(null);
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      <div className="container mx-auto p-6 md:p-8 space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="p-3 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl">
              <Clock className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              DreamNet Temporal Orchestrator
            </h1>
          </div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            AI-powered temporal coordination — pattern recognition, predictive analytics, attention economics, and ecosystem simulation
          </p>
        </div>

        {/* Main Content */}
        {view === 'overview' && (
          <Tabs defaultValue="orchestrator" className="w-full">
            <TabsList className="grid w-full grid-cols-7 mb-8">
              <TabsTrigger value="orchestrator" className="flex items-center gap-2">
                <Layout className="w-4 h-4" />
                Orchestrator
              </TabsTrigger>
              <TabsTrigger value="ai-intelligence" className="flex items-center gap-2">
                <Brain className="w-4 h-4" />
                AI Intelligence
              </TabsTrigger>
              <TabsTrigger value="attention" className="flex items-center gap-2">
                <Eye className="w-4 h-4" />
                Attention
              </TabsTrigger>
              <TabsTrigger value="simulation" className="flex items-center gap-2">
                <Beaker className="w-4 h-4" />
                Simulation
              </TabsTrigger>
              <TabsTrigger value="templates" className="flex items-center gap-2">
                <BookTemplate className="w-4 h-4" />
                Templates
              </TabsTrigger>
              <TabsTrigger value="playbooks" className="flex items-center gap-2">
                <BookOpen className="w-4 h-4" />
                Playbooks
              </TabsTrigger>
              <TabsTrigger value="about" className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                About
              </TabsTrigger>
            </TabsList>

            <TabsContent value="orchestrator" className="space-y-6">
              <TemporalOverview 
                onViewEntity={handleViewEntity}
                onViewTimeline={handleViewTimeline}
              />
            </TabsContent>

            <TabsContent value="ai-intelligence" className="space-y-6">
              <IntelligenceDashboard />
            </TabsContent>

            <TabsContent value="attention" className="space-y-6">
              <AttentionEconomicsView />
            </TabsContent>

            <TabsContent value="simulation" className="space-y-6">
              <SimulationLab />
            </TabsContent>

            <TabsContent value="templates" className="space-y-6">
              <TemplateLibrary />
            </TabsContent>

            <TabsContent value="playbooks" className="space-y-6">
              <PlaybookManager />
            </TabsContent>

            <TabsContent value="about" className="space-y-6">
              <Card>
                <CardContent className="pt-6 space-y-6">
                  <div>
                    <h3 className="text-xl font-bold mb-3">What is DreamNet Temporal Orchestrator?</h3>
                    <p className="text-gray-600">
                      The world&apos;s most advanced <strong>temporal coordination platform</strong> — combining enterprise-grade project management with revolutionary AI-powered intelligence that learns from your patterns, predicts outcomes, and optimizes timelines in real-time.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold mb-2">🎯 Core Capabilities</h4>
                      <ul className="space-y-2 text-sm text-gray-600">
                        <li>• Design timelines, seasons, and epochs</li>
                        <li>• Track time-based events across your ecosystem</li>
                        <li>• Define scheduled states and temporal rules</li>
                        <li>• Coordinate multi-app behavior during time windows</li>
                        <li>• Generate timeline briefs and seasonal calendars</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">⚡ Advanced Features</h4>
                      <ul className="space-y-2 text-sm text-gray-600">
                        <li>• Task dependencies & critical path analysis</li>
                        <li>• Temporal momentum tracking (hot/cold periods)</li>
                        <li>• Conflict detection & optimization</li>
                        <li>• Reusable templates & execution playbooks</li>
                        <li>• Timeline snapshots & version control</li>
                        <li>• Multi-timeline coordination</li>
                        <li>• Resource allocation & budget tracking</li>
                        <li>• Content orchestration across channels</li>
                      </ul>
                    </div>
                  </div>

                  <div className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border-2 border-purple-200">
                    <h4 className="font-semibold mb-3 text-purple-900">🚀 Revolutionary AI Features (Nobody Else Has This)</h4>
                    <div className="space-y-3 text-sm text-gray-700">
                      <div>
                        <strong className="text-purple-700">Temporal DNA & Pattern Recognition:</strong>
                        <p className="text-gray-600 mt-1">AI learns your unique success patterns — "Your launches work best on Tuesdays with 3-week lead time." Discovers optimal spacing, sequencing, and timing from your historical data.</p>
                      </div>
                      <div>
                        <strong className="text-blue-700">Predictive Analytics & Forecasting:</strong>
                        <p className="text-gray-600 mt-1">Predict completion probability for any timeline. AI identifies at-risk entities before they become problems. Monte Carlo simulation forecasts best/worst case scenarios.</p>
                      </div>
                      <div>
                        <strong className="text-cyan-700">Attention Economics Tracker:</strong>
                        <p className="text-gray-600 mt-1">Track audience "attention budget" — prevent fatigue by balancing high-intensity launches with recovery periods. Visual heatmap shows when you&apos;re asking too much from your community.</p>
                      </div>
                      <div>
                        <strong className="text-indigo-700">Ecosystem Simulator:</strong>
                        <p className="text-gray-600 mt-1">Test what-if scenarios before making changes. Move events, see cascading impacts in real-time. Monte Carlo risk analysis with probability distributions.</p>
                      </div>
                      <div>
                        <strong className="text-green-700">Cross-Timeline Intelligence:</strong>
                        <p className="text-gray-600 mt-1">Portfolio-level insights — "Drops succeed when preceded by 2 weeks of culture content." AI identifies patterns across ALL your timelines.</p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">🌟 What Makes This Different</h4>
                    <p className="text-sm text-gray-600 mb-3">
                      Most tools help you work WITHIN time. DreamNet Temporal Orchestrator helps you ARCHITECT time itself:
                    </p>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li><strong>AI That Learns:</strong> Pattern recognition from your history, not generic best practices</li>
                      <li><strong>Temporal Rules Engine:</strong> Define ecosystem-wide behaviors that activate during specific periods</li>
                      <li><strong>Narrative Architecture:</strong> Generate season arcs with intro, escalation, and climax structures</li>
                      <li><strong>Predictive Intelligence:</strong> Know what will happen before it does</li>
                      <li><strong>Simulation-First:</strong> Test before you commit — see cascading effects instantly</li>
                      <li><strong>Attention-Aware:</strong> Balance engagement with audience well-being</li>
                    </ul>
                  </div>

                  <div className="p-4 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg">
                    <h4 className="font-semibold mb-2">💡 Example Workflows</h4>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• AI discovers your launches succeed best on Wednesdays → Auto-suggests optimal launch dates</li>
                      <li>• Attention tracker warns of overload → You space events for better community health</li>
                      <li>• Simulation shows moving event X causes 3 downstream conflicts → You adjust before problems occur</li>
                      <li>• Cross-timeline insight: "Culture content → Drop" sequence has 85% success rate → You replicate the pattern</li>
                      <li>• Predictive analytics flags at-risk entity 2 weeks early → You intervene and save the timeline</li>
                    </ul>
                  </div>

                  <div className="text-center pt-4 border-t border-gray-200">
                    <p className="text-sm text-gray-500">
                      Everything is stored locally. No external APIs. This is your temporal operating system with AI brain.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        )}

        {view === 'entity-detail' && selectedEntityId && (
          <EnhancedEntityDetail 
            entityId={selectedEntityId}
            onBack={handleBack}
          />
        )}

        {view === 'timeline-detail' && selectedTimelineId && (
          <EnhancedTimelineDetail 
            timelineId={selectedTimelineId}
            onBack={handleBack}
            onEditEntity={handleViewEntity}
          />
        )}
      </div>
    </main>
  );
}
