'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import type { ScheduledAction, TemporalEntity } from '@/types/temporal';
import { getScheduledAction, updateScheduledAction, deleteScheduledAction, getTemporalEntity } from '@/lib/temporal-storage';
import { ArrowLeft, Save, Trash2, Clock } from 'lucide-react';
import { toast } from 'sonner';

interface ActionDetailProps {
  actionId: string;
  onBack: () => void;
  onViewEntity: (entityId: string) => void;
}

export function ActionDetail({ actionId, onBack, onViewEntity }: ActionDetailProps): JSX.Element {
  const [action, setAction] = useState<ScheduledAction | null>(null);
  const [entity, setEntity] = useState<TemporalEntity | null>(null);
  const [isEditing, setIsEditing] = useState<boolean>(false);

  useEffect(() => {
    loadAction();
  }, [actionId]);

  function loadAction(): void {
    const a = getScheduledAction(actionId);
    setAction(a);
    if (a) {
      setEntity(getTemporalEntity(a.temporalEntityId));
    }
  }

  function handleSave(): void {
    if (!action) return;

    updateScheduledAction(actionId, action);
    toast.success('Action updated');
    setIsEditing(false);
    loadAction();
  }

  function handleDelete(): void {
    if (confirm('Are you sure you want to delete this scheduled action?')) {
      deleteScheduledAction(actionId);
      toast.success('Action deleted');
      onBack();
    }
  }

  if (!action) {
    return (
      <div className="min-h-screen bg-black text-white p-8 flex items-center justify-center">
        <p className="text-gray-500">Action not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6 flex items-center justify-between">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div className="flex gap-2">
            {isEditing ? (
              <>
                <Button onClick={() => setIsEditing(false)} variant="outline">
                  Cancel
                </Button>
                <Button onClick={handleSave}>
                  <Save className="w-4 h-4 mr-2" />
                  Save Changes
                </Button>
              </>
            ) : (
              <>
                <Button onClick={() => setIsEditing(true)} variant="outline">
                  Edit
                </Button>
                <Button onClick={handleDelete} variant="destructive">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
              </>
            )}
          </div>
        </div>

        <Card className="bg-gray-900 border-gray-800 mb-6">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Clock className="w-8 h-8 text-blue-400" />
              <div>
                <CardTitle className="text-2xl">{action.name}</CardTitle>
                <p className="text-sm text-gray-400 mt-1">
                  Scheduled: {new Date(action.scheduledAt).toLocaleString()}
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {isEditing ? (
              <>
                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input
                    value={action.name}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAction({ ...action, name: e.target.value })}
                    className="bg-gray-800 border-gray-700"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea
                    value={action.description}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setAction({ ...action, description: e.target.value })}
                    className="bg-gray-800 border-gray-700 min-h-[100px]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Scheduled At</Label>
                    <Input
                      type="datetime-local"
                      value={action.scheduledAt}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAction({ ...action, scheduledAt: e.target.value })}
                      className="bg-gray-800 border-gray-700"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Optional Deadline</Label>
                    <Input
                      type="datetime-local"
                      value={action.optionalDeadline || ''}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAction({ ...action, optionalDeadline: e.target.value || null })}
                      className="bg-gray-800 border-gray-700"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Notes</Label>
                  <Textarea
                    value={action.notes}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setAction({ ...action, notes: e.target.value })}
                    className="bg-gray-800 border-gray-700"
                  />
                </div>
              </>
            ) : (
              <>
                <div>
                  <Label className="text-gray-500">Description</Label>
                  <p className="text-gray-300">{action.description}</p>
                </div>

                {action.optionalDeadline && (
                  <div>
                    <Label className="text-gray-500">Deadline</Label>
                    <p className="text-gray-300">{new Date(action.optionalDeadline).toLocaleString()}</p>
                  </div>
                )}

                {action.recommendedActionTypeCodes.length > 0 && (
                  <div>
                    <Label className="text-gray-500">Action Type Codes</Label>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {action.recommendedActionTypeCodes.map((code: string) => (
                        <Badge key={code} variant="secondary">{code}</Badge>
                      ))}
                    </div>
                  </div>
                )}

                {action.recommendedAccounts.length > 0 && (
                  <div>
                    <Label className="text-gray-500">Recommended Accounts</Label>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {action.recommendedAccounts.map((account: string) => (
                        <Badge key={account} variant="outline">{account}</Badge>
                      ))}
                    </div>
                  </div>
                )}

                {action.notes && (
                  <div>
                    <Label className="text-gray-500">Notes</Label>
                    <p className="text-sm text-gray-400 whitespace-pre-wrap">{action.notes}</p>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {entity && (
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle>Temporal Entity</CardTitle>
            </CardHeader>
            <CardContent>
              <Card
                className="bg-gray-800 border-gray-700 cursor-pointer hover:bg-gray-750"
                onClick={() => onViewEntity(entity.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{entity.primaryEmoji}</span>
                    <div className="flex-1">
                      <p className="font-medium">{entity.name}</p>
                      <p className="text-xs text-gray-400">{entity.type} • {entity.importanceLevel}</p>
                      {(entity.startAt || entity.endAt) && (
                        <p className="text-xs text-gray-500 mt-1">
                          {entity.startAt && new Date(entity.startAt).toLocaleDateString()}
                          {entity.startAt && entity.endAt && ' → '}
                          {entity.endAt && new Date(entity.endAt).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
