'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Eye, AlertTriangle, TrendingDown, TrendingUp, Activity } from 'lucide-react';
import { listTimelines } from '@/lib/temporal-storage';
import { calculateAttentionEconomics, type AttentionEconomics } from '@/lib/temporal-intelligence';

export function AttentionEconomicsView() {
  const [selectedTimeline, setSelectedTimeline] = useState<string>('');
  const [economics, setEconomics] = useState<AttentionEconomics | null>(null);

  const timelines = listTimelines();

  const loadEconomics = (timelineId: string) => {
    try {
      const data = calculateAttentionEconomics(timelineId);
      setEconomics(data);
      setSelectedTimeline(timelineId);
    } catch (error) {
      console.error('Economics error:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyan-500/10 rounded-lg">
            <Eye className="w-6 h-6 text-cyan-500" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Attention Economics</h2>
            <p className="text-sm text-gray-400">
              Track audience attention budget and prevent fatigue
            </p>
          </div>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Select Timeline</CardTitle>
          <CardDescription>
            Analyze attention demand across your timeline
          </CardDescription>
        </CardHeader>
        <CardContent>
          <select
            value={selectedTimeline}
            onChange={(e) => loadEconomics(e.target.value)}
            className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2"
          >
            <option value="">-- Select Timeline --</option>
            {timelines.map(t => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
        </CardContent>
      </Card>

      {economics && (
        <div className="space-y-6">
          {/* Overview Cards */}
          <div className="grid grid-cols-3 gap-4">
            <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/20">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-2">
                  <Activity className="w-5 h-5 text-cyan-500" />
                  <div className="text-sm text-gray-400">Total Budget</div>
                </div>
                <div className="text-3xl font-bold">{economics.totalBudget}</div>
                <div className="text-xs text-gray-500 mt-1">Attention Units</div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-orange-500/10 to-red-500/10 border-orange-500/20">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-2">
                  <TrendingUp className="w-5 h-5 text-orange-500" />
                  <div className="text-sm text-gray-400">Spent</div>
                </div>
                <div className="text-3xl font-bold">{economics.spentBudget}</div>
                <div className="text-xs text-gray-500 mt-1">
                  {((economics.spentBudget / economics.totalBudget) * 100).toFixed(1)}% of budget
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-green-500/20">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-2">
                  <TrendingDown className="w-5 h-5 text-green-500" />
                  <div className="text-sm text-gray-400">Remaining</div>
                </div>
                <div className="text-3xl font-bold">{economics.remainingBudget}</div>
                <div className="text-xs text-gray-500 mt-1">Available Units</div>
              </CardContent>
            </Card>
          </div>

          {/* Overload Warnings */}
          {economics.overloadWarnings.length > 0 && (
            <Card className="bg-red-500/10 border-red-500/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-500">
                  <AlertTriangle className="w-5 h-5" />
                  Attention Overload Warnings ({economics.overloadWarnings.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {economics.overloadWarnings.map((warning, idx) => (
                    <div key={idx} className="p-3 bg-red-500/10 border border-red-500/20 rounded text-sm">
                      ⚠️ {warning}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recommendations */}
          {economics.recommendations.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {economics.recommendations.map((rec, idx) => (
                    <div key={idx} className="p-3 bg-blue-500/10 border border-blue-500/20 rounded text-sm">
                      💡 {rec}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Attention Heatmap */}
          <Card>
            <CardHeader>
              <CardTitle>Attention Heatmap</CardTitle>
              <CardDescription>
                Visual representation of attention demand over time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {economics.heatmap.map((entry, idx) => {
                  const maxScore = Math.max(...economics.heatmap.map(e => e.score));
                  const widthPercent = (entry.score / maxScore) * 100;
                  
                  let color = 'bg-green-500';
                  if (entry.score > 150) color = 'bg-red-500';
                  else if (entry.score > 100) color = 'bg-orange-500';
                  else if (entry.score > 50) color = 'bg-yellow-500';
                  
                  return (
                    <div key={idx} className="flex items-center gap-3">
                      <div className="text-xs text-gray-500 w-24">
                        {new Date(entry.week).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      </div>
                      <div className="flex-1 bg-gray-800 rounded-full h-6 overflow-hidden relative">
                        <div 
                          className={`${color} h-full transition-all duration-300 flex items-center justify-end pr-2`}
                          style={{ width: `${widthPercent}%` }}
                        >
                          {entry.score > 20 && (
                            <span className="text-xs font-semibold text-white">
                              {Math.round(entry.score)}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Period Details */}
          <Card>
            <CardHeader>
              <CardTitle>Period Analysis</CardTitle>
              <CardDescription>
                Week-by-week attention breakdown
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {economics.periods.map((period, idx) => (
                  <Card key={idx} className="bg-gray-800/50">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="text-sm text-gray-400">
                            {new Date(period.startDate).toLocaleDateString()} - {new Date(period.endDate).toLocaleDateString()}
                          </div>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge 
                              variant={
                                period.intensity === 'extreme' ? 'destructive' :
                                period.intensity === 'high' ? 'default' :
                                'secondary'
                              }
                              className="capitalize"
                            >
                              {period.intensity}
                            </Badge>
                            {period.recovery && (
                              <Badge variant="outline" className="text-green-500">
                                Recovery Period
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold">{Math.round(period.attentionScore)}</div>
                          <div className="text-xs text-gray-500">attention points</div>
                        </div>
                      </div>

                      {period.events.length > 0 && (
                        <div className="space-y-1 mt-3 pt-3 border-t border-gray-700">
                          <div className="text-xs font-semibold text-gray-400 mb-2">Events:</div>
                          {period.events.map((event, eventIdx) => (
                            <div key={eventIdx} className="flex items-center justify-between text-sm">
                              <span className="text-gray-300">{event.name}</span>
                              <Badge variant="outline" className="text-xs">
                                {Math.round(event.attentionWeight)} pts
                              </Badge>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
