'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import type { CreateScheduledActionInput } from '@/types/temporal';
import { createScheduledAction } from '@/lib/temporal-storage';
import { toast } from 'sonner';

interface CreateActionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreated: () => void;
  entityId: string;
}

export function CreateActionDialog({ open, onOpenChange, onCreated, entityId }: CreateActionDialogProps): JSX.Element {
  const [formData, setFormData] = useState<CreateScheduledActionInput>({
    temporalEntityId: entityId,
    name: '',
    description: '',
    scheduledAt: '',
    optionalDeadline: null,
    recommendedActionTypeCodes: [],
    recommendedAccounts: [],
  });

  const [typeCodeInput, setTypeCodeInput] = useState<string>('');
  const [accountInput, setAccountInput] = useState<string>('');

  function handleSubmit(e: React.FormEvent<HTMLFormElement>): void {
    e.preventDefault();

    if (!formData.name.trim()) {
      toast.error('Name is required');
      return;
    }

    if (!formData.scheduledAt) {
      toast.error('Scheduled time is required');
      return;
    }

    createScheduledAction(formData);
    toast.success('Scheduled action created');

    setFormData({
      temporalEntityId: entityId,
      name: '',
      description: '',
      scheduledAt: '',
      optionalDeadline: null,
      recommendedActionTypeCodes: [],
      recommendedAccounts: [],
    });
    setTypeCodeInput('');
    setAccountInput('');
    onCreated();
    onOpenChange(false);
  }

  function addTypeCode(): void {
    if (typeCodeInput.trim() && !formData.recommendedActionTypeCodes!.includes(typeCodeInput.trim())) {
      setFormData((prev: CreateScheduledActionInput) => ({
        ...prev,
        recommendedActionTypeCodes: [...(prev.recommendedActionTypeCodes || []), typeCodeInput.trim()],
      }));
      setTypeCodeInput('');
    }
  }

  function removeTypeCode(code: string): void {
    setFormData((prev: CreateScheduledActionInput) => ({
      ...prev,
      recommendedActionTypeCodes: (prev.recommendedActionTypeCodes || []).filter((c: string) => c !== code),
    }));
  }

  function addAccount(): void {
    if (accountInput.trim() && !formData.recommendedAccounts!.includes(accountInput.trim())) {
      setFormData((prev: CreateScheduledActionInput) => ({
        ...prev,
        recommendedAccounts: [...(prev.recommendedAccounts || []), accountInput.trim()],
      }));
      setAccountInput('');
    }
  }

  function removeAccount(account: string): void {
    setFormData((prev: CreateScheduledActionInput) => ({
      ...prev,
      recommendedAccounts: (prev.recommendedAccounts || []).filter((a: string) => a !== account),
    }));
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-gray-900 border-gray-800 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Scheduled Action</DialogTitle>
          <DialogDescription>Plan a specific action during this temporal entity</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Name</Label>
            <Input
              value={formData.name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g. Announce CultureCoin, Push Drop Teaser"
              className="bg-gray-800 border-gray-700"
            />
          </div>

          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea
              value={formData.description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe this action..."
              className="bg-gray-800 border-gray-700 min-h-[100px]"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Scheduled At</Label>
              <Input
                type="datetime-local"
                value={formData.scheduledAt}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, scheduledAt: e.target.value })}
                className="bg-gray-800 border-gray-700"
              />
            </div>

            <div className="space-y-2">
              <Label>Optional Deadline</Label>
              <Input
                type="datetime-local"
                value={formData.optionalDeadline || ''}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, optionalDeadline: e.target.value || null })}
                className="bg-gray-800 border-gray-700"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Action Type Codes</Label>
            <div className="flex gap-2">
              <Input
                value={typeCodeInput}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTypeCodeInput(e.target.value)}
                onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addTypeCode();
                  }
                }}
                placeholder="Add type code..."
                className="bg-gray-800 border-gray-700"
              />
              <Button type="button" onClick={addTypeCode} variant="outline">
                Add
              </Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {formData.recommendedActionTypeCodes?.map((code: string) => (
                <span
                  key={code}
                  className="bg-gray-800 px-3 py-1 rounded-full text-sm flex items-center gap-2 cursor-pointer hover:bg-gray-700"
                  onClick={() => removeTypeCode(code)}
                >
                  {code}
                  <span className="text-gray-500">×</span>
                </span>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Recommended Accounts</Label>
            <div className="flex gap-2">
              <Input
                value={accountInput}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAccountInput(e.target.value)}
                onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addAccount();
                  }
                }}
                placeholder="Add account..."
                className="bg-gray-800 border-gray-700"
              />
              <Button type="button" onClick={addAccount} variant="outline">
                Add
              </Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {formData.recommendedAccounts?.map((account: string) => (
                <span
                  key={account}
                  className="bg-gray-800 px-3 py-1 rounded-full text-sm flex items-center gap-2 cursor-pointer hover:bg-gray-700"
                  onClick={() => removeAccount(account)}
                >
                  {account}
                  <span className="text-gray-500">×</span>
                </span>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">Create Action</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
