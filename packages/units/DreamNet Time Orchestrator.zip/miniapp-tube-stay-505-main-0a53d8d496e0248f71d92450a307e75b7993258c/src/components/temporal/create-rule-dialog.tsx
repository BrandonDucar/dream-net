'use client';

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import type { CreateTemporalRuleInput, RuleType, TemporalEntity } from '@/types/temporal';
import { createTemporalRule, listTemporalEntities } from '@/lib/temporal-storage';
import { toast } from 'sonner';

interface CreateRuleDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreated: () => void;
  preselectedEntityId?: string;
}

export function CreateRuleDialog({ open, onOpenChange, onCreated, preselectedEntityId }: CreateRuleDialogProps): JSX.Element {
  const [entities, setEntities] = useState<TemporalEntity[]>([]);
  const [formData, setFormData] = useState<CreateTemporalRuleInput>({
    name: '',
    description: '',
    appliesToEntityIds: preselectedEntityId ? [preselectedEntityId] : [],
    ruleType: 'behavior-shift',
    effectSummary: '',
    detailedBehavior: '',
    recommendedApps: [],
  });

  const [appInput, setAppInput] = useState<string>('');

  useEffect(() => {
    setEntities(listTemporalEntities());
  }, []);

  useEffect(() => {
    if (preselectedEntityId) {
      setFormData((prev: CreateTemporalRuleInput) => ({
        ...prev,
        appliesToEntityIds: [preselectedEntityId],
      }));
    }
  }, [preselectedEntityId]);

  function handleSubmit(e: React.FormEvent<HTMLFormElement>): void {
    e.preventDefault();

    if (!formData.name.trim()) {
      toast.error('Name is required');
      return;
    }

    if (formData.appliesToEntityIds.length === 0) {
      toast.error('Select at least one entity');
      return;
    }

    createTemporalRule(formData);
    toast.success('Temporal rule created');

    setFormData({
      name: '',
      description: '',
      appliesToEntityIds: preselectedEntityId ? [preselectedEntityId] : [],
      ruleType: 'behavior-shift',
      effectSummary: '',
      detailedBehavior: '',
      recommendedApps: [],
    });
    setAppInput('');
    onCreated();
    onOpenChange(false);
  }

  function toggleEntity(entityId: string): void {
    setFormData((prev: CreateTemporalRuleInput) => ({
      ...prev,
      appliesToEntityIds: prev.appliesToEntityIds.includes(entityId)
        ? prev.appliesToEntityIds.filter((id: string) => id !== entityId)
        : [...prev.appliesToEntityIds, entityId],
    }));
  }

  function addApp(): void {
    if (appInput.trim() && !formData.recommendedApps.includes(appInput.trim())) {
      setFormData((prev: CreateTemporalRuleInput) => ({
        ...prev,
        recommendedApps: [...prev.recommendedApps, appInput.trim()],
      }));
      setAppInput('');
    }
  }

  function removeApp(app: string): void {
    setFormData((prev: CreateTemporalRuleInput) => ({
      ...prev,
      recommendedApps: prev.recommendedApps.filter((a: string) => a !== app),
    }));
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-gray-900 border-gray-800 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Temporal Rule</DialogTitle>
          <DialogDescription>Define behavior shifts, priorities, or triggers during temporal entities</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Name</Label>
            <Input
              value={formData.name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g. Boost MemeEngine, Pause Drops During Epoch X"
              className="bg-gray-800 border-gray-700"
            />
          </div>

          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea
              value={formData.description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe this rule..."
              className="bg-gray-800 border-gray-700"
            />
          </div>

          <div className="space-y-2">
            <Label>Rule Type</Label>
            <Select value={formData.ruleType} onValueChange={(value: string) => setFormData({ ...formData, ruleType: value as RuleType })}>
              <SelectTrigger className="bg-gray-800 border-gray-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="behavior-shift">Behavior Shift</SelectItem>
                <SelectItem value="priority-shift">Priority Shift</SelectItem>
                <SelectItem value="content-shift">Content Shift</SelectItem>
                <SelectItem value="limit">Limit</SelectItem>
                <SelectItem value="boost">Boost</SelectItem>
                <SelectItem value="trigger">Trigger</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Effect Summary</Label>
            <Input
              value={formData.effectSummary}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, effectSummary: e.target.value })}
              placeholder="e.g. Increase daily memes by 50%"
              className="bg-gray-800 border-gray-700"
            />
          </div>

          <div className="space-y-2">
            <Label>Detailed Behavior</Label>
            <Textarea
              value={formData.detailedBehavior}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setFormData({ ...formData, detailedBehavior: e.target.value })}
              placeholder="Describe the detailed behavior change..."
              className="bg-gray-800 border-gray-700 min-h-[100px]"
            />
          </div>

          <div className="space-y-2">
            <Label>Applies to Entities</Label>
            <div className="max-h-[200px] overflow-y-auto border border-gray-700 rounded-md p-3 bg-gray-800 space-y-2">
              {entities.map((entity: TemporalEntity) => (
                <div key={entity.id} className="flex items-center gap-2">
                  <Checkbox
                    checked={formData.appliesToEntityIds.includes(entity.id)}
                    onCheckedChange={() => toggleEntity(entity.id)}
                  />
                  <span className="text-sm">
                    {entity.primaryEmoji} {entity.name} ({entity.type})
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Recommended Apps</Label>
            <div className="flex gap-2">
              <Input
                value={appInput}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAppInput(e.target.value)}
                onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addApp();
                  }
                }}
                placeholder="Add app name..."
                className="bg-gray-800 border-gray-700"
              />
              <Button type="button" onClick={addApp} variant="outline">
                Add
              </Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {formData.recommendedApps.map((app: string) => (
                <span
                  key={app}
                  className="bg-gray-800 px-3 py-1 rounded-full text-sm flex items-center gap-2 cursor-pointer hover:bg-gray-700"
                  onClick={() => removeApp(app)}
                >
                  {app}
                  <span className="text-gray-500">×</span>
                </span>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">Create Rule</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
