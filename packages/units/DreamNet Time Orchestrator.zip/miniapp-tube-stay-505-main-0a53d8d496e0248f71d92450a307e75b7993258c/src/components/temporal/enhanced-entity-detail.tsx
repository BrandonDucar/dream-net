'use client';

import { useState, useEffect } from 'react';
import type { TemporalEntity, ScheduledAction, TemporalRule, ChecklistItem, Blocker, Assignee, ChannelSlot } from '@/types/temporal';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';
import { AlertCircle, CheckCircle2, Clock, Users, Link2, Play, Pause, Ban, CheckCircleIcon, Calendar, TrendingUp, Zap, DollarSign, Hash } from 'lucide-react';
import { 
  getTemporalEntity, 
  updateTemporalEntity, 
  regenerateEntitySEO,
  getActionsForEntity,
  getRulesForEntity,
  getDependenciesForEntity,
  getPlaybooksForEntity
} from '@/lib/temporal-storage';

interface EnhancedEntityDetailProps {
  entityId: string;
  onBack: () => void;
}

export function EnhancedEntityDetail({ entityId, onBack }: EnhancedEntityDetailProps) {
  const [entity, setEntity] = useState<TemporalEntity | null>(null);
  const [actions, setActions] = useState<ScheduledAction[]>([]);
  const [rules, setRules] = useState<TemporalRule[]>([]);
  const [dependencies, setDependencies] = useState<any[]>([]);
  const [playbooks, setPlaybooks] = useState<any[]>([]);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    loadEntity();
  }, [entityId]);

  function loadEntity() {
    const e = getTemporalEntity(entityId);
    setEntity(e);
    if (e) {
      setActions(getActionsForEntity(e.id));
      setRules(getRulesForEntity(e.id));
      setDependencies(getDependenciesForEntity(e.id));
      setPlaybooks(getPlaybooksForEntity(e.id));
    }
  }

  function handleUpdate(updates: Partial<TemporalEntity>) {
    if (!entity) return;
    const updated = updateTemporalEntity(entity.id, updates);
    if (updated) {
      setEntity(updated);
    }
  }

  function handleRegenerateSEO() {
    if (!entity) return;
    const updated = regenerateEntitySEO(entity.id);
    if (updated) {
      setEntity(updated);
    }
  }

  function toggleChecklistItem(itemId: string) {
    if (!entity) return;
    const updated = entity.checklist.map(item =>
      item.id === itemId ? { ...item, completed: !item.completed } : item
    );
    handleUpdate({ checklist: updated });
  }

  function addChecklistItem(text: string) {
    if (!entity || !text.trim()) return;
    const newItem: ChecklistItem = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      text: text.trim(),
      completed: false,
    };
    handleUpdate({ checklist: [...entity.checklist, newItem] });
  }

  function updateStatus(status: typeof entity.status) {
    if (!entity) return;
    let progress = entity.progress;
    if (status === 'completed') progress = 100;
    else if (status === 'in-progress' && progress === 0) progress = 50;
    else if (status === 'not-started') progress = 0;
    handleUpdate({ status, progress });
  }

  if (!entity) {
    return (
      <Card className="max-w-4xl mx-auto">
        <CardContent className="pt-6">
          <p className="text-center text-gray-500">Entity not found</p>
          <Button onClick={onBack} className="mt-4">Back</Button>
        </CardContent>
      </Card>
    );
  }

  const statusIcon = {
    'not-started': <Clock className="w-4 h-4" />,
    'in-progress': <Play className="w-4 h-4" />,
    'blocked': <Ban className="w-4 h-4" />,
    'completed': <CheckCircle2 className="w-4 h-4" />,
    'on-hold': <Pause className="w-4 h-4" />,
  };

  const importanceColor = {
    low: 'bg-gray-500',
    medium: 'bg-blue-500',
    high: 'bg-orange-500',
    critical: 'bg-red-500',
  };

  const completedChecklist = entity.checklist.filter(i => i.completed).length;
  const totalChecklist = entity.checklist.length;

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <Button onClick={onBack} variant="outline">← Back</Button>
        <div className="flex gap-2">
          <Button onClick={() => setIsEditing(!isEditing)} variant="outline">
            {isEditing ? 'Done Editing' : 'Edit'}
          </Button>
          <Button onClick={handleRegenerateSEO} variant="outline">
            Regenerate SEO
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <span className="text-4xl">{entity.primaryEmoji}</span>
                {isEditing ? (
                  <Input
                    value={entity.name}
                    onChange={(e) => handleUpdate({ name: e.target.value })}
                    className="text-2xl font-bold"
                  />
                ) : (
                  <CardTitle className="text-3xl">{entity.name}</CardTitle>
                )}
              </div>
              {isEditing ? (
                <Textarea
                  value={entity.description}
                  onChange={(e) => handleUpdate({ description: e.target.value })}
                  className="min-h-[100px]"
                />
              ) : (
                <CardDescription className="text-base">{entity.description}</CardDescription>
              )}
            </div>
            <div className="flex flex-col gap-2 items-end">
              <Badge className={`${importanceColor[entity.importanceLevel]} text-white`}>
                {entity.importanceLevel}
              </Badge>
              <Badge variant="outline" className="flex items-center gap-1">
                {statusIcon[entity.status]}
                {entity.status}
              </Badge>
              {entity.momentumLevel && (
                <Badge variant="outline" className="flex items-center gap-1">
                  <Zap className="w-3 h-3" />
                  {entity.momentumLevel}
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Type</Label>
              <Select
                value={entity.type}
                onValueChange={(value: any) => handleUpdate({ type: value })}
                disabled={!isEditing}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="event">Event</SelectItem>
                  <SelectItem value="season">Season</SelectItem>
                  <SelectItem value="epoch">Epoch</SelectItem>
                  <SelectItem value="milestone">Milestone</SelectItem>
                  <SelectItem value="deadline">Deadline</SelectItem>
                  <SelectItem value="campaign-window">Campaign Window</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Category</Label>
              <Input
                value={entity.category}
                onChange={(e) => handleUpdate({ category: e.target.value })}
                disabled={!isEditing}
                placeholder="e.g., culture, pickleball, launch"
              />
            </div>

            <div className="space-y-2">
              <Label>Start Date</Label>
              <Input
                type="datetime-local"
                value={entity.startAt?.slice(0, 16) ?? ''}
                onChange={(e) => handleUpdate({ startAt: e.target.value ? new Date(e.target.value).toISOString() : null })}
                disabled={!isEditing}
              />
            </div>

            <div className="space-y-2">
              <Label>End Date</Label>
              <Input
                type="datetime-local"
                value={entity.endAt?.slice(0, 16) ?? ''}
                onChange={(e) => handleUpdate({ endAt: e.target.value ? new Date(e.target.value).toISOString() : null })}
                disabled={!isEditing}
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Progress: {entity.progress}%</Label>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => updateStatus('not-started')}>
                  Not Started
                </Button>
                <Button size="sm" variant="outline" onClick={() => updateStatus('in-progress')}>
                  In Progress
                </Button>
                <Button size="sm" variant="outline" onClick={() => updateStatus('blocked')}>
                  Blocked
                </Button>
                <Button size="sm" variant="outline" onClick={() => updateStatus('completed')}>
                  Completed
                </Button>
              </div>
            </div>
            <Progress value={entity.progress} className="h-2" />
            {isEditing && (
              <Input
                type="number"
                min="0"
                max="100"
                value={entity.progress}
                onChange={(e) => handleUpdate({ progress: parseInt(e.target.value) || 0 })}
              />
            )}
          </div>

          <Tabs defaultValue="details" className="w-full">
            <TabsList className="grid w-full grid-cols-7">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="checklist">Checklist</TabsTrigger>
              <TabsTrigger value="resources">Resources</TabsTrigger>
              <TabsTrigger value="content">Content</TabsTrigger>
              <TabsTrigger value="dependencies">Dependencies</TabsTrigger>
              <TabsTrigger value="actions">Actions ({actions.length})</TabsTrigger>
              <TabsTrigger value="rules">Rules ({rules.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="details" className="space-y-4">
              <div className="space-y-2">
                <Label>Tags</Label>
                <Input
                  value={entity.tags.join(', ')}
                  onChange={(e) => handleUpdate({ tags: e.target.value.split(',').map(t => t.trim()).filter(Boolean) })}
                  placeholder="tag1, tag2, tag3"
                  disabled={!isEditing}
                />
              </div>

              <div className="space-y-2">
                <Label>Notes</Label>
                <Textarea
                  value={entity.notes}
                  onChange={(e) => handleUpdate({ notes: e.target.value })}
                  disabled={!isEditing}
                  rows={4}
                  placeholder="Additional notes..."
                />
              </div>

              <Separator />

              <div className="space-y-2">
                <h3 className="font-semibold">SEO Metadata</h3>
                <div className="space-y-2 pl-4">
                  <div>
                    <Label className="text-xs">Title</Label>
                    <Input value={entity.seoTitle} disabled className="text-sm" />
                  </div>
                  <div>
                    <Label className="text-xs">Description</Label>
                    <Textarea value={entity.seoDescription} disabled className="text-sm" rows={2} />
                  </div>
                  <div>
                    <Label className="text-xs">Keywords</Label>
                    <Input value={entity.seoKeywords.join(', ')} disabled className="text-sm" />
                  </div>
                  <div>
                    <Label className="text-xs">Hashtags</Label>
                    <Input value={entity.seoHashtags.join(' ')} disabled className="text-sm" />
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="checklist" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Pre-Launch Checklist</h3>
                <Badge variant="outline">
                  {completedChecklist}/{totalChecklist} completed
                </Badge>
              </div>

              {entity.checklist.length > 0 ? (
                <div className="space-y-2">
                  {entity.checklist.map((item) => (
                    <div key={item.id} className="flex items-center gap-3 p-2 rounded hover:bg-gray-50">
                      <Checkbox
                        checked={item.completed}
                        onCheckedChange={() => toggleChecklistItem(item.id)}
                      />
                      <span className={item.completed ? 'line-through text-gray-500' : ''}>
                        {item.text}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500">No checklist items yet</p>
              )}

              {isEditing && (
                <div className="flex gap-2">
                  <Input
                    placeholder="Add checklist item..."
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        addChecklistItem((e.target as HTMLInputElement).value);
                        (e.target as HTMLInputElement).value = '';
                      }
                    }}
                  />
                  <Button onClick={(e) => {
                    const input = (e.target as HTMLElement).previousElementSibling as HTMLInputElement;
                    addChecklistItem(input.value);
                    input.value = '';
                  }}>
                    Add
                  </Button>
                </div>
              )}
            </TabsContent>

            <TabsContent value="resources" className="space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                Resource Allocation
              </h3>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Budget</Label>
                  <Input
                    type="number"
                    value={entity.resources.budget ?? ''}
                    onChange={(e) => handleUpdate({
                      resources: { ...entity.resources, budget: parseFloat(e.target.value) || undefined }
                    })}
                    placeholder="0.00"
                    disabled={!isEditing}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Currency</Label>
                  <Input
                    value={entity.resources.budgetCurrency ?? ''}
                    onChange={(e) => handleUpdate({
                      resources: { ...entity.resources, budgetCurrency: e.target.value }
                    })}
                    placeholder="USD, ETH, etc."
                    disabled={!isEditing}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Team Capacity (people)</Label>
                <Input
                  type="number"
                  value={entity.resources.teamCapacity ?? ''}
                  onChange={(e) => handleUpdate({
                    resources: { ...entity.resources, teamCapacity: parseInt(e.target.value) || undefined }
                  })}
                  placeholder="3"
                  disabled={!isEditing}
                />
              </div>

              <div className="space-y-2">
                <Label>Required Assets</Label>
                <Textarea
                  value={entity.resources.requiredAssets?.join('\n') ?? ''}
                  onChange={(e) => handleUpdate({
                    resources: { 
                      ...entity.resources, 
                      requiredAssets: e.target.value.split('\n').filter(Boolean) 
                    }
                  })}
                  placeholder="List required assets, one per line..."
                  disabled={!isEditing}
                  rows={4}
                />
              </div>
            </TabsContent>

            <TabsContent value="content" className="space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <Hash className="w-4 h-4" />
                Content Orchestration
              </h3>

              <p className="text-sm text-gray-600">
                Define content distribution across channels for this temporal entity
              </p>

              {entity.contentSlots.length > 0 ? (
                <div className="space-y-3">
                  {entity.contentSlots.map((slot, idx) => (
                    <Card key={idx}>
                      <CardContent className="pt-4">
                        <div className="grid grid-cols-3 gap-2 text-sm">
                          <div>
                            <Label className="text-xs">Channel</Label>
                            <p className="font-medium">{slot.channel}</p>
                          </div>
                          <div>
                            <Label className="text-xs">Content Type</Label>
                            <p className="font-medium">{slot.contentType}</p>
                          </div>
                          <div>
                            <Label className="text-xs">Frequency</Label>
                            <p className="font-medium">{slot.frequency}</p>
                          </div>
                        </div>
                        {slot.notes && (
                          <p className="text-xs text-gray-600 mt-2">{slot.notes}</p>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500">No content slots defined</p>
              )}
            </TabsContent>

            <TabsContent value="dependencies" className="space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <Link2 className="w-4 h-4" />
                Dependencies
              </h3>

              {entity.dependsOn.length > 0 ? (
                <div className="space-y-2">
                  <Label>This entity depends on:</Label>
                  {entity.dependsOn.map((depId) => {
                    const depEntity = getTemporalEntity(depId);
                    return depEntity ? (
                      <div key={depId} className="p-3 bg-gray-50 rounded flex items-center gap-2">
                        <span>{depEntity.primaryEmoji}</span>
                        <span className="font-medium">{depEntity.name}</span>
                        <Badge variant="outline" className="ml-auto">{depEntity.status}</Badge>
                      </div>
                    ) : null;
                  })}
                </div>
              ) : (
                <p className="text-sm text-gray-500">No dependencies</p>
              )}

              {entity.blockedBy.length > 0 && (
                <div className="space-y-2 mt-4">
                  <Label className="text-red-600 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4" />
                    Blockers
                  </Label>
                  {entity.blockedBy.map((blocker) => (
                    <Card key={blocker.id} className="border-red-200">
                      <CardContent className="pt-4">
                        <div className="flex items-start justify-between">
                          <p className="text-sm">{blocker.description}</p>
                          <Badge className="bg-red-500">{blocker.severity}</Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {playbooks.length > 0 && (
                <div className="space-y-2 mt-4">
                  <Label>Available Playbooks</Label>
                  {playbooks.map((playbook: any) => (
                    <Card key={playbook.id}>
                      <CardContent className="pt-4">
                        <h4 className="font-semibold">{playbook.name}</h4>
                        <p className="text-sm text-gray-600">{playbook.description}</p>
                        <Badge variant="outline" className="mt-2">{playbook.playbookType}</Badge>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="actions" className="space-y-4">
              {actions.length > 0 ? (
                <div className="space-y-3">
                  {actions.map((action) => (
                    <Card key={action.id}>
                      <CardContent className="pt-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="font-semibold">{action.name}</h4>
                            <p className="text-sm text-gray-600">{action.description}</p>
                            <div className="flex items-center gap-2 mt-2 text-xs text-gray-500">
                              <Calendar className="w-3 h-3" />
                              {new Date(action.scheduledAt).toLocaleString()}
                            </div>
                          </div>
                          <Badge variant="outline">{action.status}</Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500">No scheduled actions</p>
              )}
            </TabsContent>

            <TabsContent value="rules" className="space-y-4">
              {rules.length > 0 ? (
                <div className="space-y-3">
                  {rules.map((rule) => (
                    <Card key={rule.id}>
                      <CardContent className="pt-4">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="font-semibold">{rule.name}</h4>
                          <Badge>{rule.ruleType}</Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{rule.description}</p>
                        <div className="flex items-center gap-2">
                          <TrendingUp className="w-3 h-3 text-blue-600" />
                          <span className="text-xs font-medium text-blue-600">{rule.effectSummary}</span>
                        </div>
                        {rule.recommendedApps.length > 0 && (
                          <div className="mt-2 flex gap-1">
                            {rule.recommendedApps.map((app, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">{app}</Badge>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500">No rules applied</p>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
