'use client';

import { useState, useEffect } from 'react';
import type { Timeline, TemporalEntity, TemporalRule, ScheduledAction, ViewMode } from '@/types/temporal';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { AlertCircle, TrendingUp, Zap, Activity, BarChart3, Download, Camera, AlertTriangle, CheckCircle2, Clock } from 'lucide-react';
import { 
  getTimelineDetail,
  updateTimeline,
  regenerateTimelineSEO,
  generateTimelineSummary,
  exportTemporalCalendar,
  generateSeasonArc,
  exportTemporalSpec,
  calculateTimelineAnalytics,
  detectConflicts,
  calculateMomentum,
  createSnapshot,
  listSnapshots
} from '@/lib/temporal-storage';

interface EnhancedTimelineDetailProps {
  timelineId: string;
  onBack: () => void;
  onEditEntity: (entityId: string) => void;
}

export function EnhancedTimelineDetail({ timelineId, onBack, onEditEntity }: EnhancedTimelineDetailProps) {
  const [timeline, setTimeline] = useState<Timeline | null>(null);
  const [entities, setEntities] = useState<TemporalEntity[]>([]);
  const [rules, setRules] = useState<TemporalRule[]>([]);
  const [actions, setActions] = useState<ScheduledAction[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [generatedText, setGeneratedText] = useState('');
  const [showGenerated, setShowGenerated] = useState(false);
  const [analytics, setAnalytics] = useState<any>(null);
  const [conflicts, setConflicts] = useState<any[]>([]);
  const [momentum, setMomentum] = useState<any>(null);
  const [snapshots, setSnapshots] = useState<any[]>([]);

  useEffect(() => {
    loadTimeline();
  }, [timelineId]);

  function loadTimeline() {
    const detail = getTimelineDetail(timelineId);
    setTimeline(detail.timeline);
    setEntities(detail.entities);
    setRules(detail.rules);
    setActions(detail.actions);

    if (detail.timeline) {
      try {
        setAnalytics(calculateTimelineAnalytics(timelineId));
        setConflicts(detectConflicts(timelineId));
        setMomentum(calculateMomentum(timelineId));
        setSnapshots(listSnapshots(timelineId));
      } catch (error) {
        console.error('Error calculating analytics:', error);
      }
    }
  }

  function handleUpdate(updates: Partial<Timeline>) {
    if (!timeline) return;
    const updated = updateTimeline(timeline.id, updates);
    if (updated) {
      setTimeline(updated);
    }
  }

  function handleGenerateSummary() {
    const summary = generateTimelineSummary(timelineId);
    setGeneratedText(summary);
    setShowGenerated(true);
  }

  function handleExportCalendar() {
    const calendar = exportTemporalCalendar(timelineId);
    setGeneratedText(calendar);
    setShowGenerated(true);
  }

  function handleGenerateSeasonArc() {
    const arc = generateSeasonArc(timelineId);
    setGeneratedText(arc);
    setShowGenerated(true);
  }

  function handleExportSpec() {
    const spec = exportTemporalSpec(timelineId);
    setGeneratedText(spec);
    setShowGenerated(true);
  }

  function handleCreateSnapshot() {
    const name = prompt('Snapshot name:');
    if (!name) return;
    const description = prompt('Snapshot description:') || '';
    const snapshot = createSnapshot(timelineId, name, description);
    setSnapshots([...snapshots, snapshot]);
  }

  function copyToClipboard() {
    navigator.clipboard.writeText(generatedText);
    alert('Copied to clipboard!');
  }

  if (!timeline) {
    return (
      <Card className="max-w-4xl mx-auto">
        <CardContent className="pt-6">
          <p className="text-center text-gray-500">Timeline not found</p>
          <Button onClick={onBack} className="mt-4">Back</Button>
        </CardContent>
      </Card>
    );
  }

  const importanceColor = {
    low: 'bg-gray-500',
    medium: 'bg-blue-500',
    high: 'bg-orange-500',
    critical: 'bg-red-500',
  };

  const statusColor = {
    draft: 'bg-gray-500',
    active: 'bg-green-500',
    archived: 'bg-gray-400',
  };

  const momentumColor = {
    cold: 'text-gray-500',
    warming: 'text-yellow-500',
    hot: 'text-orange-500',
    explosive: 'text-red-500',
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <Button onClick={onBack} variant="outline">← Back</Button>
        <div className="flex gap-2">
          <Button onClick={() => setIsEditing(!isEditing)} variant="outline">
            {isEditing ? 'Done Editing' : 'Edit'}
          </Button>
          <Button onClick={() => handleUpdate({ status: timeline.status === 'active' ? 'archived' : 'active' })} variant="outline">
            {timeline.status === 'active' ? 'Archive' : 'Activate'}
          </Button>
          <Button onClick={handleCreateSnapshot} variant="outline">
            <Camera className="w-4 h-4 mr-2" />
            Snapshot
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex-1">
              {isEditing ? (
                <Input
                  value={timeline.name}
                  onChange={(e) => handleUpdate({ name: e.target.value })}
                  className="text-2xl font-bold mb-2"
                />
              ) : (
                <CardTitle className="text-3xl mb-2">{timeline.name}</CardTitle>
              )}
              {isEditing ? (
                <Textarea
                  value={timeline.description}
                  onChange={(e) => handleUpdate({ description: e.target.value })}
                  className="min-h-[80px]"
                />
              ) : (
                <CardDescription className="text-base">{timeline.description}</CardDescription>
              )}
            </div>
            <div className="flex flex-col gap-2 items-end">
              <Badge className={`${importanceColor[timeline.importanceLevel]} text-white`}>
                {timeline.importanceLevel}
              </Badge>
              <Badge className={`${statusColor[timeline.status]} text-white`}>
                {timeline.status}
              </Badge>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Analytics Dashboard */}
          {analytics && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">{analytics.completionRate.toFixed(0)}%</p>
                <p className="text-xs text-gray-600">Completion Rate</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">{analytics.completedEntities}/{analytics.totalEntities}</p>
                <p className="text-xs text-gray-600">Completed</p>
              </div>
              <div className="text-center">
                <p className={`text-2xl font-bold ${momentumColor[analytics.overallMomentum]}`}>
                  {analytics.overallMomentum.toUpperCase()}
                </p>
                <p className="text-xs text-gray-600">Momentum</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-orange-600">{analytics.atRiskCount}</p>
                <p className="text-xs text-gray-600">At Risk</p>
              </div>
            </div>
          )}

          {/* Conflicts Alert */}
          {conflicts.length > 0 && (
            <Card className="border-orange-200 bg-orange-50">
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2 text-orange-700">
                  <AlertTriangle className="w-4 h-4" />
                  {conflicts.length} Conflict{conflicts.length > 1 ? 's' : ''} Detected
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {conflicts.slice(0, 3).map((conflict) => (
                  <div key={conflict.id} className="text-sm">
                    <p className="font-medium">[{conflict.severity}] {conflict.conflictType}</p>
                    <p className="text-xs text-gray-600">{conflict.description}</p>
                    {conflict.suggestedResolution && (
                      <p className="text-xs text-blue-600 mt-1">→ {conflict.suggestedResolution}</p>
                    )}
                  </div>
                ))}
                {conflicts.length > 3 && (
                  <p className="text-xs text-gray-500">+ {conflicts.length - 3} more conflicts</p>
                )}
              </CardContent>
            </Card>
          )}

          <Tabs defaultValue="entities" className="w-full">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="entities">Entities</TabsTrigger>
              <TabsTrigger value="rules">Rules</TabsTrigger>
              <TabsTrigger value="actions">Actions</TabsTrigger>
              <TabsTrigger value="momentum">Momentum</TabsTrigger>
              <TabsTrigger value="snapshots">Snapshots</TabsTrigger>
              <TabsTrigger value="exports">Exports</TabsTrigger>
            </TabsList>

            <TabsContent value="entities" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Temporal Entities ({entities.length})</h3>
                <Select
                  value={timeline.defaultViewMode}
                  onValueChange={(value: ViewMode) => handleUpdate({ defaultViewMode: value })}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="timeline">Timeline</SelectItem>
                    <SelectItem value="calendar">Calendar</SelectItem>
                    <SelectItem value="kanban">Kanban</SelectItem>
                    <SelectItem value="list">List</SelectItem>
                    <SelectItem value="agenda">Agenda</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <ScrollArea className="h-[500px] pr-4">
                <div className="space-y-3">
                  {entities.map((entity) => {
                    const statusIcon = {
                      'not-started': <Clock className="w-4 h-4 text-gray-500" />,
                      'in-progress': <Activity className="w-4 h-4 text-blue-500" />,
                      'blocked': <AlertCircle className="w-4 h-4 text-red-500" />,
                      'completed': <CheckCircle2 className="w-4 h-4 text-green-500" />,
                      'on-hold': <Clock className="w-4 h-4 text-yellow-500" />,
                    };

                    return (
                      <Card 
                        key={entity.id} 
                        className="cursor-pointer hover:shadow-md transition-shadow"
                        onClick={() => onEditEntity(entity.id)}
                      >
                        <CardContent className="pt-4">
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-3 flex-1">
                              <span className="text-2xl">{entity.primaryEmoji}</span>
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  <h4 className="font-semibold">{entity.name}</h4>
                                  <Badge variant="outline" className="text-xs">{entity.type}</Badge>
                                  {statusIcon[entity.status]}
                                </div>
                                <p className="text-sm text-gray-600">{entity.description}</p>
                                
                                {(entity.startAt || entity.endAt) && (
                                  <div className="flex items-center gap-2 mt-2 text-xs text-gray-500">
                                    {entity.startAt && (
                                      <span>{new Date(entity.startAt).toLocaleDateString()}</span>
                                    )}
                                    {entity.startAt && entity.endAt && <span>→</span>}
                                    {entity.endAt && (
                                      <span>{new Date(entity.endAt).toLocaleDateString()}</span>
                                    )}
                                  </div>
                                )}

                                {entity.progress > 0 && (
                                  <div className="mt-2">
                                    <Progress value={entity.progress} className="h-1" />
                                  </div>
                                )}

                                {entity.assignees.length > 0 && (
                                  <div className="flex items-center gap-1 mt-2">
                                    {entity.assignees.slice(0, 3).map((assignee, idx) => (
                                      <Badge key={idx} variant="outline" className="text-xs">
                                        {assignee.name}
                                      </Badge>
                                    ))}
                                    {entity.assignees.length > 3 && (
                                      <span className="text-xs text-gray-500">+{entity.assignees.length - 3}</span>
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>
                            <div className="flex flex-col gap-1 items-end">
                              <Badge className={`${importanceColor[entity.importanceLevel]} text-white text-xs`}>
                                {entity.importanceLevel}
                              </Badge>
                              {entity.momentumLevel && (
                                <Badge variant="outline" className="text-xs flex items-center gap-1">
                                  <Zap className="w-3 h-3" />
                                  {entity.momentumLevel}
                                </Badge>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="rules" className="space-y-4">
              <h3 className="font-semibold">Temporal Rules ({rules.length})</h3>
              
              {rules.length > 0 ? (
                <div className="space-y-3">
                  {rules.map((rule) => (
                    <Card key={rule.id}>
                      <CardContent className="pt-4">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="font-semibold">{rule.name}</h4>
                          <div className="flex gap-2">
                            <Badge>{rule.ruleType}</Badge>
                            <Badge variant={rule.isActive ? "default" : "outline"}>
                              {rule.isActive ? 'Active' : 'Inactive'}
                            </Badge>
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{rule.description}</p>
                        <div className="flex items-center gap-2">
                          <TrendingUp className="w-3 h-3 text-blue-600" />
                          <span className="text-xs font-medium text-blue-600">{rule.effectSummary}</span>
                        </div>
                        {rule.recommendedApps.length > 0 && (
                          <div className="mt-2 flex gap-1 flex-wrap">
                            {rule.recommendedApps.map((app, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">{app}</Badge>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500">No rules defined</p>
              )}
            </TabsContent>

            <TabsContent value="actions" className="space-y-4">
              <h3 className="font-semibold">Scheduled Actions ({actions.length})</h3>
              
              {actions.length > 0 ? (
                <div className="space-y-3">
                  {actions
                    .sort((a, b) => new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime())
                    .map((action) => (
                      <Card key={action.id}>
                        <CardContent className="pt-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h4 className="font-semibold">{action.name}</h4>
                              <p className="text-sm text-gray-600">{action.description}</p>
                              <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                                <span>📅 {new Date(action.scheduledAt).toLocaleString()}</span>
                                {action.channels.length > 0 && (
                                  <span>📢 {action.channels.join(', ')}</span>
                                )}
                              </div>
                            </div>
                            <Badge variant="outline">{action.status}</Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500">No scheduled actions</p>
              )}
            </TabsContent>

            <TabsContent value="momentum" className="space-y-4">
              {momentum && (
                <>
                  <div className="grid grid-cols-3 gap-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-sm">Momentum Level</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className={`text-3xl font-bold ${momentumColor[momentum.momentumLevel]}`}>
                          {momentum.momentumLevel.toUpperCase()}
                        </p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-sm">Velocity Score</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-3xl font-bold text-blue-600">
                          {momentum.velocityScore.toFixed(0)}%
                        </p>
                        <Progress value={momentum.velocityScore} className="mt-2" />
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-sm">Energy Score</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-3xl font-bold text-orange-600">
                          {momentum.energyScore.toFixed(0)}%
                        </p>
                        <Progress value={momentum.energyScore} className="mt-2" />
                      </CardContent>
                    </Card>
                  </div>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center gap-2">
                        <BarChart3 className="w-4 h-4" />
                        Trend Analysis
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Trend:</span>
                          <Badge>{momentum.trend}</Badge>
                        </div>
                        <div className="mt-4">
                          <Label className="text-xs">Recommendation</Label>
                          <p className="text-sm text-gray-600 mt-1">{momentum.recommendation}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </TabsContent>

            <TabsContent value="snapshots" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Timeline Snapshots ({snapshots.length})</h3>
                <Button onClick={handleCreateSnapshot} size="sm">
                  <Camera className="w-4 h-4 mr-2" />
                  Create Snapshot
                </Button>
              </div>

              {snapshots.length > 0 ? (
                <div className="space-y-3">
                  {snapshots.map((snapshot) => (
                    <Card key={snapshot.id}>
                      <CardContent className="pt-4">
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-semibold">{snapshot.name}</h4>
                            <p className="text-sm text-gray-600">{snapshot.description}</p>
                            <p className="text-xs text-gray-500 mt-1">
                              Created {new Date(snapshot.createdAt).toLocaleString()}
                            </p>
                          </div>
                          <Button variant="outline" size="sm">Restore</Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500">No snapshots yet. Create one to save the current timeline state.</p>
              )}
            </TabsContent>

            <TabsContent value="exports" className="space-y-4">
              <h3 className="font-semibold">Export & Generation Tools</h3>

              <div className="grid grid-cols-2 gap-4">
                <Button onClick={handleGenerateSummary} variant="outline" className="h-20 flex-col">
                  <Download className="w-5 h-5 mb-2" />
                  <span>Generate Timeline Summary</span>
                </Button>

                <Button onClick={handleExportCalendar} variant="outline" className="h-20 flex-col">
                  <Download className="w-5 h-5 mb-2" />
                  <span>Export Temporal Calendar</span>
                </Button>

                <Button onClick={handleGenerateSeasonArc} variant="outline" className="h-20 flex-col">
                  <Download className="w-5 h-5 mb-2" />
                  <span>Generate Season Arc</span>
                </Button>

                <Button onClick={handleExportSpec} variant="outline" className="h-20 flex-col">
                  <Download className="w-5 h-5 mb-2" />
                  <span>Export Complete Spec</span>
                </Button>
              </div>

              {showGenerated && (
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm">Generated Output</CardTitle>
                      <Button onClick={copyToClipboard} size="sm" variant="outline">
                        Copy to Clipboard
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[400px] w-full rounded border p-4">
                      <pre className="text-xs whitespace-pre-wrap font-mono">{generatedText}</pre>
                    </ScrollArea>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
