'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { TemporalEntity, TemporalRule, ScheduledAction } from '@/types/temporal';
import { 
  getTemporalEntity, 
  updateTemporalEntity, 
  regenerateEntitySEO,
  getRulesForEntity,
  getActionsForEntity,
  deleteTemporalEntity
} from '@/lib/temporal-storage';
import { ArrowLeft, Save, RefreshCw, Trash2, Plus } from 'lucide-react';
import { toast } from 'sonner';

interface EntityDetailProps {
  entityId: string;
  onBack: () => void;
  onCreateRule: (entityId: string) => void;
  onCreateAction: (entityId: string) => void;
  onViewRule: (ruleId: string) => void;
  onViewAction: (actionId: string) => void;
}

export function EntityDetail({
  entityId,
  onBack,
  onCreateRule,
  onCreateAction,
  onViewRule,
  onViewAction,
}: EntityDetailProps): JSX.Element {
  const [entity, setEntity] = useState<TemporalEntity | null>(null);
  const [rules, setRules] = useState<TemporalRule[]>([]);
  const [actions, setActions] = useState<ScheduledAction[]>([]);
  const [isEditing, setIsEditing] = useState<boolean>(false);

  useEffect(() => {
    loadEntity();
  }, [entityId]);

  function loadEntity(): void {
    const e = getTemporalEntity(entityId);
    setEntity(e);
    if (e) {
      setRules(getRulesForEntity(entityId));
      setActions(getActionsForEntity(entityId));
    }
  }

  function handleSave(): void {
    if (!entity) return;

    updateTemporalEntity(entityId, entity);
    toast.success('Entity updated');
    setIsEditing(false);
    loadEntity();
  }

  function handleRegenerateSEO(): void {
    regenerateEntitySEO(entityId);
    toast.success('SEO regenerated');
    loadEntity();
  }

  function handleDelete(): void {
    if (confirm('Are you sure you want to delete this temporal entity?')) {
      deleteTemporalEntity(entityId);
      toast.success('Entity deleted');
      onBack();
    }
  }

  if (!entity) {
    return (
      <div className="min-h-screen bg-black text-white p-8 flex items-center justify-center">
        <p className="text-gray-500">Entity not found</p>
      </div>
    );
  }

  function getImportanceColor(level: string): string {
    const colors: Record<string, string> = {
      critical: 'bg-red-500',
      high: 'bg-orange-500',
      medium: 'bg-blue-500',
      low: 'bg-gray-500',
    };
    return colors[level] || 'bg-gray-500';
  }

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6 flex items-center justify-between">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Overview
          </Button>
          <div className="flex gap-2">
            {isEditing ? (
              <>
                <Button onClick={() => setIsEditing(false)} variant="outline">
                  Cancel
                </Button>
                <Button onClick={handleSave}>
                  <Save className="w-4 h-4 mr-2" />
                  Save Changes
                </Button>
              </>
            ) : (
              <>
                <Button onClick={() => setIsEditing(true)} variant="outline">
                  Edit
                </Button>
                <Button onClick={handleDelete} variant="destructive">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
              </>
            )}
          </div>
        </div>

        {/* Identity Section */}
        <Card className="bg-gray-900 border-gray-800 mb-6">
          <CardHeader>
            <div className="flex items-center gap-3">
              <span className="text-4xl">{entity.primaryEmoji}</span>
              <div className="flex-1">
                <CardTitle className="text-2xl">{entity.name}</CardTitle>
                <div className="flex gap-2 mt-2">
                  <Badge variant="outline">{entity.type}</Badge>
                  <Badge className={`${getImportanceColor(entity.importanceLevel)} text-white`}>
                    {entity.importanceLevel}
                  </Badge>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {isEditing ? (
              <>
                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input
                    value={entity.name}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEntity({ ...entity, name: e.target.value })}
                    className="bg-gray-800 border-gray-700"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea
                    value={entity.description}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setEntity({ ...entity, description: e.target.value })}
                    className="bg-gray-800 border-gray-700 min-h-[100px]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Start Date</Label>
                    <Input
                      type="datetime-local"
                      value={entity.startAt || ''}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEntity({ ...entity, startAt: e.target.value || null })}
                      className="bg-gray-800 border-gray-700"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>End Date</Label>
                    <Input
                      type="datetime-local"
                      value={entity.endAt || ''}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEntity({ ...entity, endAt: e.target.value || null })}
                      className="bg-gray-800 border-gray-700"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Input
                      value={entity.category}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEntity({ ...entity, category: e.target.value })}
                      className="bg-gray-800 border-gray-700"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Emoji</Label>
                    <Input
                      value={entity.primaryEmoji}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEntity({ ...entity, primaryEmoji: e.target.value })}
                      className="bg-gray-800 border-gray-700"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Notes</Label>
                  <Textarea
                    value={entity.notes}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setEntity({ ...entity, notes: e.target.value })}
                    className="bg-gray-800 border-gray-700"
                  />
                </div>
              </>
            ) : (
              <>
                <p className="text-gray-300">{entity.description}</p>

                {(entity.startAt || entity.endAt) && (
                  <div className="text-sm text-gray-400">
                    {entity.startAt && <p>Start: {new Date(entity.startAt).toLocaleString()}</p>}
                    {entity.endAt && <p>End: {new Date(entity.endAt).toLocaleString()}</p>}
                  </div>
                )}

                {entity.category && (
                  <div>
                    <Label className="text-gray-500">Category</Label>
                    <p>{entity.category}</p>
                  </div>
                )}

                {entity.tags.length > 0 && (
                  <div>
                    <Label className="text-gray-500">Tags</Label>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {entity.tags.map((tag: string) => (
                        <Badge key={tag} variant="outline">{tag}</Badge>
                      ))}
                    </div>
                  </div>
                )}

                {entity.notes && (
                  <div>
                    <Label className="text-gray-500">Notes</Label>
                    <p className="text-sm text-gray-400 whitespace-pre-wrap">{entity.notes}</p>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* SEO Section */}
        <Card className="bg-gray-900 border-gray-800 mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>SEO Metadata</CardTitle>
              <Button onClick={handleRegenerateSEO} size="sm" variant="outline">
                <RefreshCw className="w-4 h-4 mr-2" />
                Regenerate
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <Label className="text-gray-500">Title</Label>
              <p className="text-sm">{entity.seoTitle}</p>
            </div>
            <div>
              <Label className="text-gray-500">Description</Label>
              <p className="text-sm text-gray-400">{entity.seoDescription}</p>
            </div>
            <div>
              <Label className="text-gray-500">Keywords</Label>
              <div className="flex flex-wrap gap-2 mt-1">
                {entity.seoKeywords.map((kw: string) => (
                  <Badge key={kw} variant="secondary" className="text-xs">{kw}</Badge>
                ))}
              </div>
            </div>
            <div>
              <Label className="text-gray-500">Hashtags</Label>
              <p className="text-sm text-gray-400">{entity.seoHashtags.join(' ')}</p>
            </div>
          </CardContent>
        </Card>

        {/* Related Section */}
        <Card className="bg-gray-900 border-gray-800 mb-6">
          <CardHeader>
            <CardTitle>Related</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Temporal Rules */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold">Temporal Rules</h3>
                <Button onClick={() => onCreateRule(entityId)} size="sm">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Rule
                </Button>
              </div>
              {rules.length === 0 ? (
                <p className="text-sm text-gray-500">No rules yet</p>
              ) : (
                <div className="space-y-2">
                  {rules.map((rule: TemporalRule) => (
                    <Card
                      key={rule.id}
                      className="bg-gray-800 border-gray-700 cursor-pointer hover:bg-gray-750"
                      onClick={() => onViewRule(rule.id)}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-start justify-between">
                          <div>
                            <p className="font-medium">{rule.name}</p>
                            <p className="text-xs text-gray-400">{rule.effectSummary}</p>
                          </div>
                          <Badge variant="outline">{rule.ruleType}</Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>

            <Separator className="bg-gray-800" />

            {/* Scheduled Actions */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold">Scheduled Actions</h3>
                <Button onClick={() => onCreateAction(entityId)} size="sm">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Action
                </Button>
              </div>
              {actions.length === 0 ? (
                <p className="text-sm text-gray-500">No scheduled actions yet</p>
              ) : (
                <div className="space-y-2">
                  {actions.map((action: ScheduledAction) => (
                    <Card
                      key={action.id}
                      className="bg-gray-800 border-gray-700 cursor-pointer hover:bg-gray-750"
                      onClick={() => onViewAction(action.id)}
                    >
                      <CardContent className="p-3">
                        <p className="font-medium">{action.name}</p>
                        <p className="text-xs text-gray-400">
                          {new Date(action.scheduledAt).toLocaleString()}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
