'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Brain, 
  TrendingUp, 
  AlertTriangle, 
  Lightbulb,
  Calendar,
  Target,
  Zap,
  Eye,
} from 'lucide-react';
import { listTimelines } from '@/lib/temporal-storage';
import { 
  analyzeTemporalDNA, 
  predictTimelineCompletion,
  analyzeCrossTimelinePatterns,
  type TemporalDNA,
  type CrossTimelineInsight,
} from '@/lib/temporal-intelligence';

export function IntelligenceDashboard() {
  const [dna, setDNA] = useState<TemporalDNA | null>(null);
  const [insights, setInsights] = useState<CrossTimelineInsight[]>([]);
  const [selectedTimeline, setSelectedTimeline] = useState<string>('');
  const [forecast, setForecast] = useState<ReturnType<typeof predictTimelineCompletion> | null>(null);

  useEffect(() => {
    loadIntelligence();
  }, []);

  const loadIntelligence = () => {
    const temporalDNA = analyzeTemporalDNA();
    setDNA(temporalDNA);
    
    const crossInsights = analyzeCrossTimelinePatterns();
    setInsights(crossInsights);
  };

  const loadForecast = (timelineId: string) => {
    try {
      const prediction = predictTimelineCompletion(timelineId);
      setForecast(prediction);
      setSelectedTimeline(timelineId);
    } catch (error) {
      console.error('Forecast error:', error);
    }
  };

  const timelines = listTimelines();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-500/10 rounded-lg">
            <Brain className="w-6 h-6 text-purple-500" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">AI Temporal Intelligence</h2>
            <p className="text-sm text-gray-400">
              Pattern recognition, predictive analytics, and strategic recommendations
            </p>
          </div>
        </div>
        <Button onClick={loadIntelligence} variant="outline">
          <Zap className="w-4 h-4 mr-2" />
          Refresh Intelligence
        </Button>
      </div>

      <Tabs defaultValue="dna" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="dna">
            <Target className="w-4 h-4 mr-2" />
            Temporal DNA
          </TabsTrigger>
          <TabsTrigger value="predictions">
            <TrendingUp className="w-4 h-4 mr-2" />
            Predictions
          </TabsTrigger>
          <TabsTrigger value="insights">
            <Lightbulb className="w-4 h-4 mr-2" />
            Cross-Timeline
          </TabsTrigger>
          <TabsTrigger value="patterns">
            <Eye className="w-4 h-4 mr-2" />
            Patterns
          </TabsTrigger>
        </TabsList>

        {/* Temporal DNA Tab */}
        <TabsContent value="dna" className="space-y-4">
          {dna ? (
            <>
              <Card>
                <CardHeader>
                  <CardTitle>Your Temporal DNA</CardTitle>
                  <CardDescription>
                    Learned patterns from your historical timelines
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Optimal Days */}
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-blue-500" />
                      Optimal Days
                    </h4>
                    {dna.optimalDays.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {dna.optimalDays.map(day => (
                          <Badge key={day} variant="secondary" className="capitalize">
                            {day}
                          </Badge>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-gray-400">
                        Not enough data yet. Complete more timelines to discover patterns.
                      </p>
                    )}
                  </div>

                  {/* Optimal Spacing */}
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <Target className="w-4 h-4 text-green-500" />
                      Optimal Spacing
                    </h4>
                    {Object.keys(dna.optimalSpacing).length > 0 ? (
                      <div className="space-y-2">
                        {Object.entries(dna.optimalSpacing).map(([type, days]) => (
                          <div key={type} className="flex items-center justify-between p-2 bg-gray-800/50 rounded">
                            <span className="capitalize text-sm">{type} events</span>
                            <Badge variant="outline">{days} days apart</Badge>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-gray-400">
                        Not enough data yet. Complete more timelines to discover patterns.
                      </p>
                    )}
                  </div>

                  {/* Success Factors */}
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-purple-500" />
                      Success Factors
                    </h4>
                    <div className="space-y-2">
                      {dna.successFactors.map((factor, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-sm">
                          <span className="text-green-500">✓</span>
                          <span>{factor}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Avoidance Patterns */}
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-orange-500" />
                      Avoid These
                    </h4>
                    <div className="space-y-2">
                      {dna.avoidancePatterns.map((pattern, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-sm text-orange-400">
                          <span>⚠</span>
                          <span>{pattern}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Key Insights */}
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <Lightbulb className="w-4 h-4 text-yellow-500" />
                      Key Insights
                    </h4>
                    <div className="space-y-2">
                      {dna.insights.map((insight, idx) => (
                        <div key={idx} className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded text-sm">
                          {insight}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Discovered Patterns */}
                  {dna.patterns.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-3">Discovered Patterns</h4>
                      <div className="space-y-3">
                        {dna.patterns.map(pattern => (
                          <Card key={pattern.id} className="bg-gray-800/50">
                            <CardContent className="p-4">
                              <div className="flex items-start justify-between mb-2">
                                <div>
                                  <Badge variant="outline" className="mb-2 capitalize">
                                    {pattern.patternType}
                                  </Badge>
                                  <p className="font-medium">{pattern.description}</p>
                                </div>
                                <Badge variant="secondary">{pattern.confidence}% confident</Badge>
                              </div>
                              <p className="text-sm text-gray-400 mb-3">
                                Seen {pattern.occurrences} times
                              </p>
                              <div className="space-y-1">
                                {pattern.recommendations.map((rec, idx) => (
                                  <div key={idx} className="text-sm text-green-400 flex items-center gap-2">
                                    <span>→</span>
                                    <span>{rec}</span>
                                  </div>
                                ))}
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Brain className="w-12 h-12 mx-auto mb-4 text-gray-500" />
                <p className="text-gray-400">Loading temporal intelligence...</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Predictions Tab */}
        <TabsContent value="predictions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Completion Forecasting</CardTitle>
              <CardDescription>
                AI-powered predictions for timeline completion
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Select Timeline</label>
                <select
                  value={selectedTimeline}
                  onChange={(e) => loadForecast(e.target.value)}
                  className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2"
                >
                  <option value="">-- Select Timeline --</option>
                  {timelines.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>

              {forecast && (
                <div className="space-y-4 mt-6">
                  <div className="grid grid-cols-2 gap-4">
                    <Card className="bg-gray-800/50">
                      <CardContent className="p-4">
                        <div className="text-sm text-gray-400 mb-1">Confidence</div>
                        <div className="text-2xl font-bold">{forecast.confidence.toFixed(0)}%</div>
                      </CardContent>
                    </Card>
                    <Card className="bg-gray-800/50">
                      <CardContent className="p-4">
                        <div className="text-sm text-gray-400 mb-1">Risk Level</div>
                        <Badge 
                          variant="outline" 
                          className={
                            forecast.overallRisk === 'critical' ? 'border-red-500 text-red-500' :
                            forecast.overallRisk === 'high' ? 'border-orange-500 text-orange-500' :
                            forecast.overallRisk === 'medium' ? 'border-yellow-500 text-yellow-500' :
                            'border-green-500 text-green-500'
                          }
                        >
                          {forecast.overallRisk}
                        </Badge>
                      </CardContent>
                    </Card>
                  </div>

                  {forecast.predictedCompletionDate && (
                    <Card className="bg-blue-500/10 border-blue-500/20">
                      <CardContent className="p-4">
                        <div className="text-sm text-gray-400 mb-1">Predicted Completion</div>
                        <div className="text-lg font-semibold">
                          {new Date(forecast.predictedCompletionDate).toLocaleDateString()}
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {forecast.atRiskEntities.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-3 flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-orange-500" />
                        At-Risk Entities ({forecast.atRiskEntities.length})
                      </h4>
                      <div className="space-y-2">
                        {forecast.atRiskEntities.map(entity => (
                          <Card key={entity.entityId} className="bg-orange-500/10 border-orange-500/20">
                            <CardContent className="p-3">
                              <div className="flex items-start justify-between mb-2">
                                <div>
                                  <div className="font-medium">{entity.entityName}</div>
                                  <Badge variant="outline" className="mt-1 text-xs">
                                    {entity.confidence}% confidence
                                  </Badge>
                                </div>
                                <Badge variant="destructive">{entity.riskLevel}</Badge>
                              </div>
                              {entity.riskFactors.length > 0 && (
                                <div className="space-y-1 mb-2">
                                  {entity.riskFactors.map((risk, idx) => (
                                    <div key={idx} className="text-sm text-orange-400 flex items-center gap-2">
                                      <span>⚠</span>
                                      <span>{risk}</span>
                                    </div>
                                  ))}
                                </div>
                              )}
                              {entity.recommendations.length > 0 && (
                                <div className="space-y-1 mt-2 pt-2 border-t border-orange-500/20">
                                  {entity.recommendations.map((rec, idx) => (
                                    <div key={idx} className="text-sm text-green-400 flex items-center gap-2">
                                      <span>→</span>
                                      <span>{rec}</span>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}

                  {forecast.recommendations.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-3">Recommendations</h4>
                      <div className="space-y-2">
                        {forecast.recommendations.map((rec, idx) => (
                          <div key={idx} className="p-3 bg-green-500/10 border border-green-500/20 rounded text-sm">
                            {rec}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Cross-Timeline Insights Tab */}
        <TabsContent value="insights" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Cross-Timeline Intelligence</CardTitle>
              <CardDescription>
                Portfolio-level insights and optimization opportunities
              </CardDescription>
            </CardHeader>
            <CardContent>
              {insights.length > 0 ? (
                <div className="space-y-4">
                  {insights.map((insight, idx) => (
                    <Card key={idx} className="bg-gray-800/50">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <Badge variant="outline" className="mb-2 capitalize">
                              {insight.insightType}
                            </Badge>
                            <h4 className="font-semibold">{insight.title}</h4>
                          </div>
                          <Badge 
                            variant={insight.priority === 'critical' || insight.priority === 'high' ? 'destructive' : 'secondary'}
                          >
                            {insight.priority}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-400 mb-3">{insight.description}</p>
                        <div className="flex items-center gap-2 mb-3">
                          <span className="text-xs text-gray-500">Confidence:</span>
                          <Badge variant="secondary">{insight.confidence}%</Badge>
                        </div>
                        <div className="space-y-1">
                          {insight.actionableRecommendations.map((rec, recIdx) => (
                            <div key={recIdx} className="text-sm text-blue-400 flex items-center gap-2">
                              <span>→</span>
                              <span>{rec}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Lightbulb className="w-12 h-12 mx-auto mb-4 text-gray-500" />
                  <p className="text-gray-400">No cross-timeline insights yet.</p>
                  <p className="text-sm text-gray-500 mt-2">
                    Create multiple timelines to discover portfolio-level patterns.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Patterns Tab */}
        <TabsContent value="patterns" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Pattern Library</CardTitle>
              <CardDescription>
                All discovered patterns and success factors
              </CardDescription>
            </CardHeader>
            <CardContent>
              {dna && dna.patterns.length > 0 ? (
                <div className="grid gap-4">
                  {dna.patterns.map(pattern => (
                    <Card key={pattern.id} className="bg-gray-800/50">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge variant="outline" className="capitalize">
                                {pattern.patternType}
                              </Badge>
                              <Badge variant="secondary">{pattern.confidence}% confidence</Badge>
                            </div>
                            <h4 className="font-semibold mb-1">{pattern.description}</h4>
                            <p className="text-xs text-gray-500">
                              Observed {pattern.occurrences} times
                            </p>
                          </div>
                        </div>

                        <div className="grid grid-cols-3 gap-4 mb-4 p-3 bg-gray-900/50 rounded">
                          <div>
                            <div className="text-xs text-gray-500 mb-1">Success Rate</div>
                            <div className="font-semibold text-green-400">
                              {pattern.outcomes.successRate.toFixed(0)}%
                            </div>
                          </div>
                          <div>
                            <div className="text-xs text-gray-500 mb-1">Avg Completion</div>
                            <div className="font-semibold">
                              {pattern.outcomes.averageCompletion.toFixed(0)}%
                            </div>
                          </div>
                          <div>
                            <div className="text-xs text-gray-500 mb-1">Momentum</div>
                            <Badge variant="secondary" className="capitalize">
                              {pattern.outcomes.momentum}
                            </Badge>
                          </div>
                        </div>

                        {pattern.recommendations.length > 0 && (
                          <div className="space-y-1">
                            <div className="text-xs font-semibold text-gray-400 mb-2">
                              Recommendations:
                            </div>
                            {pattern.recommendations.map((rec, idx) => (
                              <div key={idx} className="text-sm text-green-400 flex items-center gap-2">
                                <span>✓</span>
                                <span>{rec}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Eye className="w-12 h-12 mx-auto mb-4 text-gray-500" />
                  <p className="text-gray-400">No patterns discovered yet.</p>
                  <p className="text-sm text-gray-500 mt-2">
                    Complete more timelines to discover your unique temporal patterns.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
