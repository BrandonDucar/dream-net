'use client';

import { useState, useEffect } from 'react';
import type { TemporalPlaybook } from '@/types/temporal';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { BookOpen, Rocket, AlertTriangle, RefreshCw, Plus, CheckCircle2 } from 'lucide-react';
import { listPlaybooks, createPlaybook, updatePlaybook } from '@/lib/temporal-storage';

export function PlaybookManager() {
  const [playbooks, setPlaybooks] = useState<TemporalPlaybook[]>([]);
  const [selectedPlaybook, setSelectedPlaybook] = useState<TemporalPlaybook | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [newPlaybook, setNewPlaybook] = useState({
    name: '',
    description: '',
    playbookType: 'custom' as const,
  });

  useEffect(() => {
    loadPlaybooks();
  }, []);

  function loadPlaybooks() {
    setPlaybooks(listPlaybooks());
  }

  function handleCreatePlaybook() {
    if (!newPlaybook.name || !newPlaybook.description) return;
    createPlaybook(newPlaybook);
    loadPlaybooks();
    setShowCreateDialog(false);
    setNewPlaybook({
      name: '',
      description: '',
      playbookType: 'custom',
    });
  }

  function handleAddStep() {
    if (!selectedPlaybook) return;
    const newStep = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      order: selectedPlaybook.steps.length + 1,
      title: 'New Step',
      description: 'Step description',
      estimatedDuration: 30,
      checklist: [],
    };
    const updated = updatePlaybook(selectedPlaybook.id, {
      steps: [...selectedPlaybook.steps, newStep]
    });
    if (updated) {
      setSelectedPlaybook(updated);
      loadPlaybooks();
    }
  }

  const playbookIcons = {
    launch: <Rocket className="w-5 h-5" />,
    crisis: <AlertTriangle className="w-5 h-5" />,
    recurring: <RefreshCw className="w-5 h-5" />,
    custom: <BookOpen className="w-5 h-5" />,
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Playbook Manager</h2>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button>
              <BookOpen className="w-4 h-4 mr-2" />
              Create Playbook
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Playbook</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Playbook Name</Label>
                <Input
                  value={newPlaybook.name}
                  onChange={(e) => setNewPlaybook({ ...newPlaybook, name: e.target.value })}
                  placeholder="e.g., Product Launch Playbook"
                />
              </div>

              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  value={newPlaybook.description}
                  onChange={(e) => setNewPlaybook({ ...newPlaybook, description: e.target.value })}
                  placeholder="Describe this playbook..."
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label>Playbook Type</Label>
                <Select
                  value={newPlaybook.playbookType}
                  onValueChange={(value: any) => setNewPlaybook({ ...newPlaybook, playbookType: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="launch">Launch</SelectItem>
                    <SelectItem value="crisis">Crisis</SelectItem>
                    <SelectItem value="recurring">Recurring</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button onClick={handleCreatePlaybook} className="w-full">
                Create Playbook
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {playbooks.length === 0 ? (
        <Card>
          <CardContent className="pt-6 text-center">
            <BookOpen className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-500 mb-4">No playbooks yet. Create your first playbook to standardize execution processes.</p>
            <Button onClick={() => setShowCreateDialog(true)}>Create First Playbook</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {playbooks.map((playbook) => (
            <Card key={playbook.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    {playbookIcons[playbook.playbookType]}
                    <CardTitle className="text-lg">{playbook.name}</CardTitle>
                  </div>
                  <Badge variant="outline">{playbook.playbookType}</Badge>
                </div>
                <CardDescription>{playbook.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Steps:</span>
                    <span className="font-medium">{playbook.steps.length}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Used:</span>
                    <span className="font-medium">{playbook.usageCount} times</span>
                  </div>

                  {playbook.steps.length > 0 && (
                    <div className="pt-2 border-t">
                      <p className="text-xs text-gray-600 mb-2">Steps:</p>
                      <div className="space-y-1">
                        {playbook.steps.slice(0, 3).map((step) => (
                          <div key={step.id} className="flex items-center gap-2 text-xs">
                            <CheckCircle2 className="w-3 h-3 text-gray-400" />
                            <span className="truncate">{step.title}</span>
                          </div>
                        ))}
                        {playbook.steps.length > 3 && (
                          <p className="text-xs text-gray-500">+{playbook.steps.length - 3} more</p>
                        )}
                      </div>
                    </div>
                  )}

                  <Button 
                    className="w-full mt-4" 
                    variant="outline"
                    onClick={() => {
                      setSelectedPlaybook(playbook);
                      setShowDetailDialog(true);
                    }}
                  >
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedPlaybook && playbookIcons[selectedPlaybook.playbookType]}
              {selectedPlaybook?.name}
            </DialogTitle>
          </DialogHeader>
          
          {selectedPlaybook && (
            <div className="space-y-4">
              <div>
                <Label>Description</Label>
                <p className="text-sm text-gray-600">{selectedPlaybook.description}</p>
              </div>

              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Execution Steps ({selectedPlaybook.steps.length})</h3>
                <Button size="sm" onClick={handleAddStep}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Step
                </Button>
              </div>

              {selectedPlaybook.steps.length > 0 ? (
                <Accordion type="single" collapsible className="w-full">
                  {selectedPlaybook.steps
                    .sort((a, b) => a.order - b.order)
                    .map((step) => (
                      <AccordionItem key={step.id} value={step.id}>
                        <AccordionTrigger>
                          <div className="flex items-center gap-3">
                            <Badge variant="outline">{step.order}</Badge>
                            <span>{step.title}</span>
                            <span className="text-xs text-gray-500 ml-auto mr-4">
                              ~{step.estimatedDuration} min
                            </span>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent>
                          <div className="space-y-3 pt-2">
                            <p className="text-sm text-gray-600">{step.description}</p>
                            
                            {step.assignedRole && (
                              <div className="flex items-center gap-2 text-sm">
                                <span className="text-gray-600">Assigned Role:</span>
                                <Badge variant="outline">{step.assignedRole}</Badge>
                              </div>
                            )}

                            {step.checklist && step.checklist.length > 0 && (
                              <div>
                                <Label className="text-xs">Checklist:</Label>
                                <ul className="list-disc list-inside text-sm text-gray-600 mt-1 space-y-1">
                                  {step.checklist.map((item, idx) => (
                                    <li key={idx}>{item.text}</li>
                                  ))}
                                </ul>
                              </div>
                            )}

                            {step.resources && step.resources.length > 0 && (
                              <div>
                                <Label className="text-xs">Resources:</Label>
                                <ul className="list-disc list-inside text-sm text-gray-600 mt-1 space-y-1">
                                  {step.resources.map((resource, idx) => (
                                    <li key={idx}>{resource}</li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                </Accordion>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <p className="text-sm">No steps defined yet.</p>
                  <Button onClick={handleAddStep} variant="outline" size="sm" className="mt-2">
                    Add First Step
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
