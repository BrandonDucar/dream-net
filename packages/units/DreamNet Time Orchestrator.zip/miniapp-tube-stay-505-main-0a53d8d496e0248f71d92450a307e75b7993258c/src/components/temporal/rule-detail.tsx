'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { TemporalRule, RuleType, TemporalEntity } from '@/types/temporal';
import { getTemporalRule, updateTemporalRule, deleteTemporalRule, getTemporalEntity } from '@/lib/temporal-storage';
import { ArrowLeft, Save, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

interface RuleDetailProps {
  ruleId: string;
  onBack: () => void;
  onViewEntity: (entityId: string) => void;
}

export function RuleDetail({ ruleId, onBack, onViewEntity }: RuleDetailProps): JSX.Element {
  const [rule, setRule] = useState<TemporalRule | null>(null);
  const [entities, setEntities] = useState<TemporalEntity[]>([]);
  const [isEditing, setIsEditing] = useState<boolean>(false);

  useEffect(() => {
    loadRule();
  }, [ruleId]);

  function loadRule(): void {
    const r = getTemporalRule(ruleId);
    setRule(r);
    if (r) {
      const loadedEntities = r.appliesToEntityIds
        .map((id: string) => getTemporalEntity(id))
        .filter((e: TemporalEntity | null): e is TemporalEntity => e !== null);
      setEntities(loadedEntities);
    }
  }

  function handleSave(): void {
    if (!rule) return;

    updateTemporalRule(ruleId, rule);
    toast.success('Rule updated');
    setIsEditing(false);
    loadRule();
  }

  function handleDelete(): void {
    if (confirm('Are you sure you want to delete this temporal rule?')) {
      deleteTemporalRule(ruleId);
      toast.success('Rule deleted');
      onBack();
    }
  }

  if (!rule) {
    return (
      <div className="min-h-screen bg-black text-white p-8 flex items-center justify-center">
        <p className="text-gray-500">Rule not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6 flex items-center justify-between">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div className="flex gap-2">
            {isEditing ? (
              <>
                <Button onClick={() => setIsEditing(false)} variant="outline">
                  Cancel
                </Button>
                <Button onClick={handleSave}>
                  <Save className="w-4 h-4 mr-2" />
                  Save Changes
                </Button>
              </>
            ) : (
              <>
                <Button onClick={() => setIsEditing(true)} variant="outline">
                  Edit
                </Button>
                <Button onClick={handleDelete} variant="destructive">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
              </>
            )}
          </div>
        </div>

        <Card className="bg-gray-900 border-gray-800 mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl">{rule.name}</CardTitle>
                <Badge variant="outline" className="mt-2">{rule.ruleType}</Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {isEditing ? (
              <>
                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input
                    value={rule.name}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setRule({ ...rule, name: e.target.value })}
                    className="bg-gray-800 border-gray-700"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea
                    value={rule.description}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setRule({ ...rule, description: e.target.value })}
                    className="bg-gray-800 border-gray-700 min-h-[80px]"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Rule Type</Label>
                  <Select value={rule.ruleType} onValueChange={(value: string) => setRule({ ...rule, ruleType: value as RuleType })}>
                    <SelectTrigger className="bg-gray-800 border-gray-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="behavior-shift">Behavior Shift</SelectItem>
                      <SelectItem value="priority-shift">Priority Shift</SelectItem>
                      <SelectItem value="content-shift">Content Shift</SelectItem>
                      <SelectItem value="limit">Limit</SelectItem>
                      <SelectItem value="boost">Boost</SelectItem>
                      <SelectItem value="trigger">Trigger</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Effect Summary</Label>
                  <Input
                    value={rule.effectSummary}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setRule({ ...rule, effectSummary: e.target.value })}
                    className="bg-gray-800 border-gray-700"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Detailed Behavior</Label>
                  <Textarea
                    value={rule.detailedBehavior}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setRule({ ...rule, detailedBehavior: e.target.value })}
                    className="bg-gray-800 border-gray-700 min-h-[120px]"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Notes</Label>
                  <Textarea
                    value={rule.notes}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setRule({ ...rule, notes: e.target.value })}
                    className="bg-gray-800 border-gray-700"
                  />
                </div>
              </>
            ) : (
              <>
                <div>
                  <Label className="text-gray-500">Description</Label>
                  <p className="text-gray-300">{rule.description}</p>
                </div>

                <div>
                  <Label className="text-gray-500">Effect Summary</Label>
                  <p className="text-gray-300">{rule.effectSummary}</p>
                </div>

                <div>
                  <Label className="text-gray-500">Detailed Behavior</Label>
                  <p className="text-sm text-gray-400 whitespace-pre-wrap">{rule.detailedBehavior}</p>
                </div>

                {rule.recommendedApps.length > 0 && (
                  <div>
                    <Label className="text-gray-500">Recommended Apps</Label>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {rule.recommendedApps.map((app: string) => (
                        <Badge key={app} variant="secondary">{app}</Badge>
                      ))}
                    </div>
                  </div>
                )}

                {rule.notes && (
                  <div>
                    <Label className="text-gray-500">Notes</Label>
                    <p className="text-sm text-gray-400 whitespace-pre-wrap">{rule.notes}</p>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle>Applies to Entities</CardTitle>
          </CardHeader>
          <CardContent>
            {entities.length === 0 ? (
              <p className="text-center text-gray-500 py-4">No entities found</p>
            ) : (
              <div className="space-y-2">
                {entities.map((entity: TemporalEntity) => (
                  <Card
                    key={entity.id}
                    className="bg-gray-800 border-gray-700 cursor-pointer hover:bg-gray-750"
                    onClick={() => onViewEntity(entity.id)}
                  >
                    <CardContent className="p-3">
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{entity.primaryEmoji}</span>
                        <div className="flex-1">
                          <p className="font-medium">{entity.name}</p>
                          <p className="text-xs text-gray-400">{entity.type} • {entity.importanceLevel}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
