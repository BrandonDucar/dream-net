'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Beaker, 
  Play, 
  ArrowRight, 
  AlertTriangle, 
  CheckCircle,
  TrendingUp,
  TrendingDown,
  Activity,
} from 'lucide-react';
import { listTimelines, listTemporalEntities } from '@/lib/temporal-storage';
import { 
  runSimulation, 
  runMonteCarloSimulation,
  type SimulationChange,
  type SimulationResult,
} from '@/lib/temporal-simulation';

export function SimulationLab() {
  const [selectedTimeline, setSelectedTimeline] = useState<string>('');
  const [changes, setChanges] = useState<SimulationChange[]>([]);
  const [result, setResult] = useState<SimulationResult | null>(null);
  const [monteCarloResult, setMonteCarloResult] = useState<ReturnType<typeof runMonteCarloSimulation> | null>(null);

  const timelines = listTimelines();
  const entities = listTemporalEntities();

  const addMoveChange = () => {
    const change: SimulationChange = {
      type: 'move-entity',
      entityId: '',
      newStartDate: new Date().toISOString().split('T')[0],
    };
    setChanges([...changes, change]);
  };

  const updateChange = (index: number, updated: SimulationChange) => {
    const newChanges = [...changes];
    newChanges[index] = updated;
    setChanges(newChanges);
  };

  const removeChange = (index: number) => {
    setChanges(changes.filter((_, i) => i !== index));
  };

  const runSim = () => {
    if (!selectedTimeline) return;
    
    try {
      const simResult = runSimulation(selectedTimeline, changes);
      setResult(simResult);
    } catch (error) {
      console.error('Simulation error:', error);
    }
  };

  const runMonteCarlo = () => {
    if (!selectedTimeline) return;
    
    try {
      const mcResult = runMonteCarloSimulation(selectedTimeline, 100);
      setMonteCarloResult(mcResult);
    } catch (error) {
      console.error('Monte Carlo error:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-500/10 rounded-lg">
            <Beaker className="w-6 h-6 text-purple-500" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Simulation Lab</h2>
            <p className="text-sm text-gray-400">
              Test what-if scenarios before making changes
            </p>
          </div>
        </div>
      </div>

      <Tabs defaultValue="scenario" className="w-full">
        <TabsList>
          <TabsTrigger value="scenario">Scenario Testing</TabsTrigger>
          <TabsTrigger value="montecarlo">Monte Carlo Analysis</TabsTrigger>
        </TabsList>

        {/* Scenario Testing */}
        <TabsContent value="scenario" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Setup Simulation</CardTitle>
              <CardDescription>
                Select a timeline and define changes to simulate
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Timeline</Label>
                <select
                  value={selectedTimeline}
                  onChange={(e) => setSelectedTimeline(e.target.value)}
                  className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 mt-1"
                >
                  <option value="">-- Select Timeline --</option>
                  {timelines.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-3">
                  <Label>Changes to Simulate</Label>
                  <Button onClick={addMoveChange} size="sm" variant="outline">
                    + Add Change
                  </Button>
                </div>
                
                <div className="space-y-3">
                  {changes.map((change, idx) => (
                    <Card key={idx} className="bg-gray-800/50">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className="flex-1 space-y-3">
                            <div>
                              <Label className="text-xs">Change Type</Label>
                              <select
                                value={change.type}
                                onChange={(e) => updateChange(idx, { ...change, type: e.target.value as SimulationChange['type'] })}
                                className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1 text-sm mt-1"
                              >
                                <option value="move-entity">Move Entity</option>
                                <option value="delete-entity">Delete Entity</option>
                                <option value="change-importance">Change Importance</option>
                                <option value="change-duration">Change Duration</option>
                              </select>
                            </div>

                            {change.type === 'move-entity' && (
                              <>
                                <div>
                                  <Label className="text-xs">Entity</Label>
                                  <select
                                    value={change.entityId}
                                    onChange={(e) => updateChange(idx, { ...change, entityId: e.target.value })}
                                    className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1 text-sm mt-1"
                                  >
                                    <option value="">-- Select Entity --</option>
                                    {entities.map(e => (
                                      <option key={e.id} value={e.id}>
                                        {e.name}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                                <div>
                                  <Label className="text-xs">New Start Date</Label>
                                  <Input
                                    type="date"
                                    value={change.newStartDate?.split('T')[0]}
                                    onChange={(e) => updateChange(idx, { ...change, newStartDate: e.target.value })}
                                    className="mt-1"
                                  />
                                </div>
                              </>
                            )}

                            {change.type === 'delete-entity' && (
                              <div>
                                <Label className="text-xs">Entity to Delete</Label>
                                <select
                                  value={change.entityId}
                                  onChange={(e) => updateChange(idx, { ...change, entityId: e.target.value })}
                                  className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1 text-sm mt-1"
                                >
                                  <option value="">-- Select Entity --</option>
                                  {entities.map(e => (
                                    <option key={e.id} value={e.id}>
                                      {e.name}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            )}

                            {change.type === 'change-importance' && (
                              <>
                                <div>
                                  <Label className="text-xs">Entity</Label>
                                  <select
                                    value={change.entityId}
                                    onChange={(e) => updateChange(idx, { ...change, entityId: e.target.value })}
                                    className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1 text-sm mt-1"
                                  >
                                    <option value="">-- Select Entity --</option>
                                    {entities.map(e => (
                                      <option key={e.id} value={e.id}>
                                        {e.name}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                                <div>
                                  <Label className="text-xs">New Importance</Label>
                                  <select
                                    value={change.newImportance}
                                    onChange={(e) => updateChange(idx, { ...change, newImportance: e.target.value as any })}
                                    className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1 text-sm mt-1"
                                  >
                                    <option value="low">Low</option>
                                    <option value="medium">Medium</option>
                                    <option value="high">High</option>
                                    <option value="critical">Critical</option>
                                  </select>
                                </div>
                              </>
                            )}

                            {change.type === 'change-duration' && (
                              <>
                                <div>
                                  <Label className="text-xs">Entity</Label>
                                  <select
                                    value={change.entityId}
                                    onChange={(e) => updateChange(idx, { ...change, entityId: e.target.value })}
                                    className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1 text-sm mt-1"
                                  >
                                    <option value="">-- Select Entity --</option>
                                    {entities.map(e => (
                                      <option key={e.id} value={e.id}>
                                        {e.name}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                                <div>
                                  <Label className="text-xs">New Duration (days)</Label>
                                  <Input
                                    type="number"
                                    value={change.newDuration}
                                    onChange={(e) => updateChange(idx, { ...change, newDuration: parseInt(e.target.value) })}
                                    className="mt-1"
                                  />
                                </div>
                              </>
                            )}
                          </div>

                          <Button
                            onClick={() => removeChange(idx)}
                            size="sm"
                            variant="ghost"
                            className="text-red-500"
                          >
                            ✕
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              <Button 
                onClick={runSim} 
                disabled={!selectedTimeline || changes.length === 0}
                className="w-full"
              >
                <Play className="w-4 h-4 mr-2" />
                Run Simulation
              </Button>
            </CardContent>
          </Card>

          {/* Simulation Results */}
          {result && (
            <div className="space-y-6">
              <Card className={
                result.riskLevel === 'critical' || result.riskLevel === 'high' 
                  ? 'bg-red-500/10 border-red-500/20'
                  : 'bg-green-500/10 border-green-500/20'
              }>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {result.riskLevel === 'low' ? (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-orange-500" />
                    )}
                    Simulation Results
                  </CardTitle>
                  <CardDescription>
                    Impact analysis of proposed changes
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Impact Metrics */}
                  <div className="grid grid-cols-2 gap-4">
                    <Card className="bg-gray-800/50">
                      <CardContent className="p-4">
                        <div className="text-xs text-gray-400 mb-1">Completion Rate Change</div>
                        <div className="flex items-center gap-2">
                          {result.impact.completionRateChange > 0 ? (
                            <TrendingUp className="w-4 h-4 text-green-500" />
                          ) : result.impact.completionRateChange < 0 ? (
                            <TrendingDown className="w-4 h-4 text-red-500" />
                          ) : (
                            <Activity className="w-4 h-4 text-gray-500" />
                          )}
                          <span className={`font-bold ${
                            result.impact.completionRateChange > 0 ? 'text-green-500' :
                            result.impact.completionRateChange < 0 ? 'text-red-500' :
                            'text-gray-500'
                          }`}>
                            {result.impact.completionRateChange > 0 ? '+' : ''}
                            {result.impact.completionRateChange.toFixed(1)}%
                          </span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="bg-gray-800/50">
                      <CardContent className="p-4">
                        <div className="text-xs text-gray-400 mb-1">Conflicts</div>
                        <div className="flex items-center gap-2">
                          {result.impact.conflictCountChange < 0 ? (
                            <TrendingDown className="w-4 h-4 text-green-500" />
                          ) : result.impact.conflictCountChange > 0 ? (
                            <TrendingUp className="w-4 h-4 text-red-500" />
                          ) : (
                            <Activity className="w-4 h-4 text-gray-500" />
                          )}
                          <span className={`font-bold ${
                            result.impact.conflictCountChange < 0 ? 'text-green-500' :
                            result.impact.conflictCountChange > 0 ? 'text-red-500' :
                            'text-gray-500'
                          }`}>
                            {result.impact.conflictCountChange > 0 ? '+' : ''}
                            {result.impact.conflictCountChange}
                          </span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="bg-gray-800/50">
                      <CardContent className="p-4">
                        <div className="text-xs text-gray-400 mb-1">At-Risk Entities</div>
                        <div className="flex items-center gap-2">
                          {result.impact.atRiskCountChange < 0 ? (
                            <TrendingDown className="w-4 h-4 text-green-500" />
                          ) : result.impact.atRiskCountChange > 0 ? (
                            <TrendingUp className="w-4 h-4 text-red-500" />
                          ) : (
                            <Activity className="w-4 h-4 text-gray-500" />
                          )}
                          <span className={`font-bold ${
                            result.impact.atRiskCountChange < 0 ? 'text-green-500' :
                            result.impact.atRiskCountChange > 0 ? 'text-red-500' :
                            'text-gray-500'
                          }`}>
                            {result.impact.atRiskCountChange > 0 ? '+' : ''}
                            {result.impact.atRiskCountChange}
                          </span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="bg-gray-800/50">
                      <CardContent className="p-4">
                        <div className="text-xs text-gray-400 mb-1">Momentum</div>
                        <div className="text-sm font-medium">
                          {result.impact.momentumChange}
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Cascading Effects */}
                  {result.cascadingEffects.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-3 flex items-center gap-2">
                        <ArrowRight className="w-4 h-4 text-blue-500" />
                        Cascading Effects ({result.cascadingEffects.length})
                      </h4>
                      <div className="space-y-2">
                        {result.cascadingEffects.map((effect, idx) => (
                          <div key={idx} className="p-3 bg-blue-500/10 border border-blue-500/20 rounded text-sm">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant="outline" className="capitalize">
                                {effect.effectType}
                              </Badge>
                              <span className="font-medium">{effect.entityName}</span>
                            </div>
                            <p className="text-gray-400">{effect.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Recommendations */}
                  {result.recommendations.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-3">Recommendations</h4>
                      <div className="space-y-2">
                        {result.recommendations.map((rec, idx) => (
                          <div key={idx} className="p-3 bg-gray-800/50 rounded text-sm">
                            {rec}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        {/* Monte Carlo Tab */}
        <TabsContent value="montecarlo" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Monte Carlo Risk Analysis</CardTitle>
              <CardDescription>
                Run 100 simulations to forecast completion probability
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Timeline</Label>
                <select
                  value={selectedTimeline}
                  onChange={(e) => setSelectedTimeline(e.target.value)}
                  className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 mt-1"
                >
                  <option value="">-- Select Timeline --</option>
                  {timelines.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>

              <Button onClick={runMonteCarlo} disabled={!selectedTimeline} className="w-full">
                <Play className="w-4 h-4 mr-2" />
                Run Monte Carlo (100 iterations)
              </Button>
            </CardContent>
          </Card>

          {monteCarloResult && (
            <Card>
              <CardHeader>
                <CardTitle>Monte Carlo Results</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <Card className="bg-blue-500/10 border-blue-500/20">
                    <CardContent className="p-4">
                      <div className="text-sm text-gray-400 mb-1">Completion Probability</div>
                      <div className="text-3xl font-bold">
                        {monteCarloResult.completionProbability.toFixed(0)}%
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-purple-500/10 border-purple-500/20">
                    <CardContent className="p-4">
                      <div className="text-sm text-gray-400 mb-1">Confidence Level</div>
                      <div className="text-3xl font-bold">
                        {monteCarloResult.confidence}%
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <Card className="bg-gray-800/50">
                    <CardContent className="p-4">
                      <div className="text-xs text-gray-400 mb-1">Best Case</div>
                      <div className="text-sm font-semibold">
                        {new Date(monteCarloResult.bestCase).toLocaleDateString()}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800/50">
                    <CardContent className="p-4">
                      <div className="text-xs text-gray-400 mb-1">Most Likely</div>
                      <div className="text-sm font-semibold">
                        {new Date(monteCarloResult.averageCompletionDate).toLocaleDateString()}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800/50">
                    <CardContent className="p-4">
                      <div className="text-xs text-gray-400 mb-1">Worst Case</div>
                      <div className="text-sm font-semibold">
                        {new Date(monteCarloResult.worstCase).toLocaleDateString()}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div>
                  <h4 className="font-semibold mb-3">Risk Distribution</h4>
                  <div className="space-y-2">
                    {monteCarloResult.riskDistribution.slice(0, 10).map((point, idx) => (
                      <div key={idx} className="flex items-center gap-3">
                        <div className="text-xs text-gray-500 w-24">
                          {new Date(point.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                        </div>
                        <div className="flex-1 bg-gray-800 rounded-full h-4 overflow-hidden">
                          <div 
                            className="bg-blue-500 h-full"
                            style={{ width: `${point.probability}%` }}
                          />
                        </div>
                        <div className="text-xs text-gray-400 w-12 text-right">
                          {point.probability.toFixed(0)}%
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
