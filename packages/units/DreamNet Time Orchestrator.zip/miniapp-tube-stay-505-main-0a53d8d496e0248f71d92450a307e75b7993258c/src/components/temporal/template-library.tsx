'use client';

import { useState, useEffect } from 'react';
import type { TemporalTemplate } from '@/types/temporal';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { BookTemplate, Rocket, Trophy, Sparkles, Copy } from 'lucide-react';
import { listTemplates, createTemplate, applyTemplate, listTimelines } from '@/lib/temporal-storage';

export function TemplateLibrary() {
  const [templates, setTemplates] = useState<TemporalTemplate[]>([]);
  const [timelines, setTimelines] = useState<any[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<TemporalTemplate | null>(null);
  const [selectedTimeline, setSelectedTimeline] = useState('');
  const [startDate, setStartDate] = useState('');
  const [showApplyDialog, setShowApplyDialog] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newTemplate, setNewTemplate] = useState({
    name: '',
    description: '',
    category: '',
    templateType: 'custom' as const,
  });

  useEffect(() => {
    loadTemplates();
    setTimelines(listTimelines());
  }, []);

  function loadTemplates() {
    setTemplates(listTemplates());
  }

  function handleCreateTemplate() {
    if (!newTemplate.name || !newTemplate.description) return;
    createTemplate(newTemplate);
    loadTemplates();
    setShowCreateDialog(false);
    setNewTemplate({
      name: '',
      description: '',
      category: '',
      templateType: 'custom',
    });
  }

  function handleApplyTemplate() {
    if (!selectedTemplate || !selectedTimeline || !startDate) return;
    const success = applyTemplate(selectedTemplate.id, selectedTimeline, startDate);
    if (success) {
      alert('Template applied successfully!');
      setShowApplyDialog(false);
      loadTemplates();
    }
  }

  const templateIcons = {
    season: <Sparkles className="w-5 h-5" />,
    launch: <Rocket className="w-5 h-5" />,
    campaign: <BookTemplate className="w-5 h-5" />,
    tournament: <Trophy className="w-5 h-5" />,
    custom: <Copy className="w-5 h-5" />,
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Template Library</h2>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button>
              <BookTemplate className="w-4 h-4 mr-2" />
              Create Template
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Template</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Template Name</Label>
                <Input
                  value={newTemplate.name}
                  onChange={(e) => setNewTemplate({ ...newTemplate, name: e.target.value })}
                  placeholder="e.g., Product Launch Season"
                />
              </div>

              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  value={newTemplate.description}
                  onChange={(e) => setNewTemplate({ ...newTemplate, description: e.target.value })}
                  placeholder="Describe this template..."
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label>Category</Label>
                <Input
                  value={newTemplate.category}
                  onChange={(e) => setNewTemplate({ ...newTemplate, category: e.target.value })}
                  placeholder="e.g., launch, culture, ops"
                />
              </div>

              <div className="space-y-2">
                <Label>Template Type</Label>
                <Select
                  value={newTemplate.templateType}
                  onValueChange={(value: any) => setNewTemplate({ ...newTemplate, templateType: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="season">Season</SelectItem>
                    <SelectItem value="launch">Launch</SelectItem>
                    <SelectItem value="campaign">Campaign</SelectItem>
                    <SelectItem value="tournament">Tournament</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button onClick={handleCreateTemplate} className="w-full">
                Create Template
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {templates.length === 0 ? (
        <Card>
          <CardContent className="pt-6 text-center">
            <BookTemplate className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-500 mb-4">No templates yet. Create your first template to reuse timeline structures.</p>
            <Button onClick={() => setShowCreateDialog(true)}>Create First Template</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {templates.map((template) => (
            <Card key={template.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    {templateIcons[template.templateType]}
                    <CardTitle className="text-lg">{template.name}</CardTitle>
                  </div>
                  <Badge variant="outline">{template.templateType}</Badge>
                </div>
                <CardDescription>{template.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Category:</span>
                    <Badge variant="outline">{template.category || 'None'}</Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Used:</span>
                    <span className="font-medium">{template.usageCount} times</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Entities:</span>
                    <span className="font-medium">{template.entityTemplates.length}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Rules:</span>
                    <span className="font-medium">{template.ruleTemplates.length}</span>
                  </div>

                  <Button 
                    className="w-full mt-4" 
                    variant="outline"
                    onClick={() => {
                      setSelectedTemplate(template);
                      setShowApplyDialog(true);
                    }}
                  >
                    Apply Template
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={showApplyDialog} onOpenChange={setShowApplyDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Apply Template: {selectedTemplate?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Select Timeline</Label>
              <Select value={selectedTimeline} onValueChange={setSelectedTimeline}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a timeline..." />
                </SelectTrigger>
                <SelectContent>
                  {timelines.map((timeline) => (
                    <SelectItem key={timeline.id} value={timeline.id}>
                      {timeline.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Start Date</Label>
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>

            <div className="p-4 bg-blue-50 rounded text-sm">
              <p className="font-medium text-blue-900 mb-2">This will create:</p>
              <ul className="list-disc list-inside text-blue-700 space-y-1">
                <li>{selectedTemplate?.entityTemplates.length} temporal entities</li>
                <li>{selectedTemplate?.ruleTemplates.length} temporal rules</li>
              </ul>
            </div>

            <Button onClick={handleApplyTemplate} className="w-full" disabled={!selectedTimeline || !startDate}>
              Apply Template
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
