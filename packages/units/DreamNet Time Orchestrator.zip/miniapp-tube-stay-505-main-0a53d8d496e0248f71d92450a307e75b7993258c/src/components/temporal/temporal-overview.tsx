'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import type { TemporalEntity, Timeline, TemporalEntityFilter, TimelineFilter, CreateTemporalEntityInput, CreateTimelineInput } from '@/types/temporal';
import { listTemporalEntities, listTimelines, createTemporalEntity, createTimeline } from '@/lib/temporal-storage';
import { Clock, Calendar, Plus, Activity, CheckCircle2, AlertCircle, Zap } from 'lucide-react';

interface TemporalOverviewProps {
  onViewEntity: (id: string) => void;
  onViewTimeline: (id: string) => void;
}

export function TemporalOverview({
  onViewEntity,
  onViewTimeline,
}: TemporalOverviewProps): JSX.Element {
  const [entities, setEntities] = useState<TemporalEntity[]>([]);
  const [timelines, setTimelines] = useState<Timeline[]>([]);
  const [entityFilter, setEntityFilter] = useState<TemporalEntityFilter>({});
  const [timelineFilter, setTimelineFilter] = useState<TimelineFilter>({});
  const [entitySearch, setEntitySearch] = useState<string>('');
  const [timelineSearch, setTimelineSearch] = useState<string>('');
  const [showCreateEntity, setShowCreateEntity] = useState(false);
  const [showCreateTimeline, setShowCreateTimeline] = useState(false);
  const [newEntity, setNewEntity] = useState<CreateTemporalEntityInput>({
    type: 'event',
    name: '',
    description: '',
  });
  const [newTimeline, setNewTimeline] = useState<CreateTimelineInput>({
    name: '',
    description: '',
    category: '',
    importanceLevel: 'medium',
  });

  useEffect(() => {
    loadData();
  }, [entityFilter, timelineFilter]);

  function loadData(): void {
    setEntities(listTemporalEntities(entityFilter));
    setTimelines(listTimelines(timelineFilter));
  }

  function handleCreateEntity() {
    if (!newEntity.name || !newEntity.description) return;
    createTemporalEntity(newEntity);
    loadData();
    setShowCreateEntity(false);
    setNewEntity({
      type: 'event',
      name: '',
      description: '',
    });
  }

  function handleCreateTimeline() {
    if (!newTimeline.name || !newTimeline.description) return;
    createTimeline(newTimeline);
    loadData();
    setShowCreateTimeline(false);
    setNewTimeline({
      name: '',
      description: '',
      category: '',
      importanceLevel: 'medium',
    });
  }

  const filteredEntities = entities.filter((e: TemporalEntity) =>
    e.name.toLowerCase().includes(entitySearch.toLowerCase()) ||
    e.description.toLowerCase().includes(entitySearch.toLowerCase())
  );

  const filteredTimelines = timelines.filter((t: Timeline) =>
    t.name.toLowerCase().includes(timelineSearch.toLowerCase()) ||
    t.description.toLowerCase().includes(timelineSearch.toLowerCase())
  );

  function getImportanceColor(level: string): string {
    const colors: Record<string, string> = {
      critical: 'bg-red-500',
      high: 'bg-orange-500',
      medium: 'bg-blue-500',
      low: 'bg-gray-500',
    };
    return colors[level] || 'bg-gray-500';
  }

  function getStatusColor(status: string): string {
    const colors: Record<string, string> = {
      active: 'bg-green-500',
      draft: 'bg-yellow-500',
      archived: 'bg-gray-500',
      'not-started': 'bg-gray-400',
      'in-progress': 'bg-blue-500',
      blocked: 'bg-red-500',
      completed: 'bg-green-500',
      'on-hold': 'bg-yellow-500',
    };
    return colors[status] || 'bg-gray-500';
  }

  function formatDateRange(startAt: string | null, endAt: string | null): string {
    if (!startAt && !endAt) return 'No dates';
    if (startAt && !endAt) return `From ${new Date(startAt).toLocaleDateString()}`;
    if (!startAt && endAt) return `Until ${new Date(endAt).toLocaleDateString()}`;
    return `${new Date(startAt!).toLocaleDateString()} - ${new Date(endAt!).toLocaleDateString()}`;
  }

  const statusIcons = {
    'not-started': <Clock className="w-3 h-3" />,
    'in-progress': <Activity className="w-3 h-3" />,
    'completed': <CheckCircle2 className="w-3 h-3" />,
    'blocked': <AlertCircle className="w-3 h-3" />,
    'on-hold': <Clock className="w-3 h-3" />,
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Temporal Entities Panel */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-purple-600" />
                <CardTitle>Temporal Entities</CardTitle>
              </div>
              <Dialog open={showCreateEntity} onOpenChange={setShowCreateEntity}>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Create
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create Temporal Entity</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Name</Label>
                      <Input
                        value={newEntity.name}
                        onChange={(e) => setNewEntity({ ...newEntity, name: e.target.value })}
                        placeholder="e.g., Culture Season 2"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Description</Label>
                      <Textarea
                        value={newEntity.description}
                        onChange={(e) => setNewEntity({ ...newEntity, description: e.target.value })}
                        placeholder="Describe this entity..."
                        rows={3}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Type</Label>
                      <Select
                        value={newEntity.type}
                        onValueChange={(value: any) => setNewEntity({ ...newEntity, type: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="event">Event</SelectItem>
                          <SelectItem value="season">Season</SelectItem>
                          <SelectItem value="epoch">Epoch</SelectItem>
                          <SelectItem value="milestone">Milestone</SelectItem>
                          <SelectItem value="deadline">Deadline</SelectItem>
                          <SelectItem value="campaign-window">Campaign Window</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button onClick={handleCreateEntity} className="w-full">
                      Create Entity
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
            <CardDescription>Events, seasons, epochs, milestones, and more</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              placeholder="Search entities..."
              value={entitySearch}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEntitySearch(e.target.value)}
            />

            <div className="grid grid-cols-3 gap-2">
              <Select value={entityFilter.type || 'all'} onValueChange={(value: string) => setEntityFilter({ ...entityFilter, type: value === 'all' ? undefined : value as TemporalEntity['type'] })}>
                <SelectTrigger>
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="event">Event</SelectItem>
                  <SelectItem value="season">Season</SelectItem>
                  <SelectItem value="epoch">Epoch</SelectItem>
                  <SelectItem value="milestone">Milestone</SelectItem>
                  <SelectItem value="deadline">Deadline</SelectItem>
                  <SelectItem value="campaign-window">Campaign</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>

              <Select value={entityFilter.importanceLevel || 'all'} onValueChange={(value: string) => setEntityFilter({ ...entityFilter, importanceLevel: value === 'all' ? undefined : value as TemporalEntity['importanceLevel'] })}>
                <SelectTrigger>
                  <SelectValue placeholder="Importance" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>

              <Select value={entityFilter.status || 'all'} onValueChange={(value: string) => setEntityFilter({ ...entityFilter, status: value === 'all' ? undefined : value as any })}>
                <SelectTrigger>
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="not-started">Not Started</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="blocked">Blocked</SelectItem>
                  <SelectItem value="on-hold">On Hold</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <ScrollArea className="h-[500px] pr-4">
              <div className="space-y-3">
                {filteredEntities.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>No temporal entities yet</p>
                    <p className="text-sm">Create one to begin orchestrating time</p>
                  </div>
                ) : (
                  filteredEntities.map((entity: TemporalEntity) => (
                    <Card
                      key={entity.id}
                      className="cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => onViewEntity(entity.id)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-2xl">{entity.primaryEmoji}</span>
                            <div>
                              <div className="flex items-center gap-2">
                                <h3 className="font-semibold">{entity.name}</h3>
                                {statusIcons[entity.status as keyof typeof statusIcons]}
                              </div>
                              <p className="text-xs text-gray-500">{entity.type}</p>
                            </div>
                          </div>
                          <div className="flex flex-col gap-1 items-end">
                            <Badge className={`${getImportanceColor(entity.importanceLevel)} text-white text-xs`}>
                              {entity.importanceLevel}
                            </Badge>
                            {entity.momentumLevel && (
                              <Badge variant="outline" className="text-xs flex items-center gap-1">
                                <Zap className="w-3 h-3" />
                                {entity.momentumLevel}
                              </Badge>
                            )}
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 mb-2 line-clamp-2">{entity.description}</p>
                        <div className="flex items-center gap-2 text-xs text-gray-500">
                          <Calendar className="w-3 h-3" />
                          {formatDateRange(entity.startAt, entity.endAt)}
                        </div>
                        {entity.category && (
                          <Badge variant="outline" className="mt-2 text-xs">
                            {entity.category}
                          </Badge>
                        )}
                        {entity.progress > 0 && (
                          <div className="mt-2">
                            <div className="h-1 bg-gray-200 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-blue-500 transition-all"
                                style={{ width: `${entity.progress}%` }}
                              />
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Timelines Panel */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-600" />
                <CardTitle>Timelines</CardTitle>
              </div>
              <Dialog open={showCreateTimeline} onOpenChange={setShowCreateTimeline}>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Create
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create Timeline</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Name</Label>
                      <Input
                        value={newTimeline.name}
                        onChange={(e) => setNewTimeline({ ...newTimeline, name: e.target.value })}
                        placeholder="e.g., DreamNet Master Timeline"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Description</Label>
                      <Textarea
                        value={newTimeline.description}
                        onChange={(e) => setNewTimeline({ ...newTimeline, description: e.target.value })}
                        placeholder="Describe this timeline..."
                        rows={3}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Category</Label>
                      <Input
                        value={newTimeline.category}
                        onChange={(e) => setNewTimeline({ ...newTimeline, category: e.target.value })}
                        placeholder="e.g., culture, launch, ops"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Importance Level</Label>
                      <Select
                        value={newTimeline.importanceLevel}
                        onValueChange={(value: any) => setNewTimeline({ ...newTimeline, importanceLevel: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="critical">Critical</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button onClick={handleCreateTimeline} className="w-full">
                      Create Timeline
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
            <CardDescription>Orchestrate sequences and seasonal arcs</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              placeholder="Search timelines..."
              value={timelineSearch}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTimelineSearch(e.target.value)}
            />

            <div className="grid grid-cols-2 gap-2">
              <Select value={timelineFilter.status || 'all'} onValueChange={(value: string) => setTimelineFilter({ ...timelineFilter, status: value === 'all' ? undefined : value as Timeline['status'] })}>
                <SelectTrigger>
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="archived">Archived</SelectItem>
                </SelectContent>
              </Select>

              <Select value={timelineFilter.importanceLevel || 'all'} onValueChange={(value: string) => setTimelineFilter({ ...timelineFilter, importanceLevel: value === 'all' ? undefined : value as Timeline['importanceLevel'] })}>
                <SelectTrigger>
                  <SelectValue placeholder="Importance" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <ScrollArea className="h-[500px] pr-4">
              <div className="space-y-3">
                {filteredTimelines.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    <Calendar className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>No timelines yet</p>
                    <p className="text-sm">Create one to sequence your entities</p>
                  </div>
                ) : (
                  filteredTimelines.map((timeline: Timeline) => (
                    <Card
                      key={timeline.id}
                      className="cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => onViewTimeline(timeline.id)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <h3 className="font-semibold">{timeline.name}</h3>
                            <p className="text-xs text-gray-500">{timeline.category}</p>
                          </div>
                          <div className="flex gap-2">
                            <Badge className={`${getStatusColor(timeline.status)} text-white text-xs`}>
                              {timeline.status}
                            </Badge>
                            <Badge className={`${getImportanceColor(timeline.importanceLevel)} text-white text-xs`}>
                              {timeline.importanceLevel}
                            </Badge>
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 mb-2 line-clamp-2">{timeline.description}</p>
                        <div className="text-xs text-gray-500">
                          {timeline.temporalEntityIds.length} entities
                        </div>
                        {timeline.completionRate !== undefined && (
                          <div className="mt-2">
                            <div className="flex items-center justify-between text-xs mb-1">
                              <span className="text-gray-500">Completion</span>
                              <span className="font-medium">{timeline.completionRate.toFixed(0)}%</span>
                            </div>
                            <div className="h-1 bg-gray-200 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-green-500 transition-all"
                                style={{ width: `${timeline.completionRate}%` }}
                              />
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
