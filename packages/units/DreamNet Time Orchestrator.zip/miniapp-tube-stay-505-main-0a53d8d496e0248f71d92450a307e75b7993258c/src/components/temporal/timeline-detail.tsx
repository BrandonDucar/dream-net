'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { Timeline, TemporalEntity, TemporalRule, ScheduledAction } from '@/types/temporal';
import { 
  getTimelineDetail,
  updateTimeline,
  regenerateTimelineSEO,
  attachTemporalEntity,
  detachTemporalEntity,
  reorderTemporalEntities,
  listTemporalEntities,
  generateTimelineSummary,
  exportTemporalCalendar,
  generateSeasonArc,
  exportTemporalSpec,
  deleteTimeline
} from '@/lib/temporal-storage';
import { ArrowLeft, Save, RefreshCw, Trash2, Plus, FileText, Calendar, Sparkles, Download, GripVertical } from 'lucide-react';
import { toast } from 'sonner';

interface TimelineDetailProps {
  timelineId: string;
  onBack: () => void;
  onViewEntity: (entityId: string) => void;
  onViewRule: (ruleId: string) => void;
  onViewAction: (actionId: string) => void;
  onCreateRule: (timelineId: string) => void;
}

export function TimelineDetail({
  timelineId,
  onBack,
  onViewEntity,
  onViewRule,
  onViewAction,
  onCreateRule,
}: TimelineDetailProps): JSX.Element {
  const [timeline, setTimeline] = useState<Timeline | null>(null);
  const [entities, setEntities] = useState<TemporalEntity[]>([]);
  const [rules, setRules] = useState<TemporalRule[]>([]);
  const [actions, setActions] = useState<ScheduledAction[]>([]);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [showAttachDialog, setShowAttachDialog] = useState<boolean>(false);
  const [showOutputDialog, setShowOutputDialog] = useState<boolean>(false);
  const [outputContent, setOutputContent] = useState<string>('');
  const [outputTitle, setOutputTitle] = useState<string>('');

  useEffect(() => {
    loadTimeline();
  }, [timelineId]);

  function loadTimeline(): void {
    const detail = getTimelineDetail(timelineId);
    setTimeline(detail.timeline);
    setEntities(detail.entities);
    setRules(detail.rules);
    setActions(detail.actions);
  }

  function handleSave(): void {
    if (!timeline) return;

    updateTimeline(timelineId, timeline);
    toast.success('Timeline updated');
    setIsEditing(false);
    loadTimeline();
  }

  function handleRegenerateSEO(): void {
    regenerateTimelineSEO(timelineId);
    toast.success('SEO regenerated');
    loadTimeline();
  }

  function handleDelete(): void {
    if (confirm('Are you sure you want to delete this timeline?')) {
      deleteTimeline(timelineId);
      toast.success('Timeline deleted');
      onBack();
    }
  }

  function handleDetachEntity(entityId: string): void {
    detachTemporalEntity(timelineId, entityId);
    toast.success('Entity removed from timeline');
    loadTimeline();
  }

  function handleAttachEntity(entityId: string): void {
    attachTemporalEntity(timelineId, entityId);
    toast.success('Entity attached to timeline');
    setShowAttachDialog(false);
    loadTimeline();
  }

  function handleMoveEntity(entityId: string, direction: 'up' | 'down'): void {
    if (!timeline) return;

    const currentIndex = timeline.temporalEntityIds.indexOf(entityId);
    if (currentIndex === -1) return;

    const newIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    if (newIndex < 0 || newIndex >= timeline.temporalEntityIds.length) return;

    const newOrder = [...timeline.temporalEntityIds];
    const temp = newOrder[currentIndex];
    newOrder[currentIndex] = newOrder[newIndex];
    newOrder[newIndex] = temp;

    reorderTemporalEntities(timelineId, newOrder);
    loadTimeline();
  }

  function showOutput(title: string, content: string): void {
    setOutputTitle(title);
    setOutputContent(content);
    setShowOutputDialog(true);
  }

  function handleGenerateSummary(): void {
    const summary = generateTimelineSummary(timelineId);
    showOutput('Timeline Summary', summary);
  }

  function handleExportCalendar(): void {
    const calendar = exportTemporalCalendar(timelineId);
    showOutput('Temporal Calendar', calendar);
  }

  function handleGenerateSeasonArc(): void {
    const arc = generateSeasonArc(timelineId);
    showOutput('Season Arc', arc);
  }

  function handleExportSpec(): void {
    const spec = exportTemporalSpec(timelineId);
    showOutput('Temporal Specification', spec);
  }

  if (!timeline) {
    return (
      <div className="min-h-screen bg-black text-white p-8 flex items-center justify-center">
        <p className="text-gray-500">Timeline not found</p>
      </div>
    );
  }

  const availableEntities = listTemporalEntities().filter(
    (e: TemporalEntity) => !timeline.temporalEntityIds.includes(e.id)
  );

  function getImportanceColor(level: string): string {
    const colors: Record<string, string> = {
      critical: 'bg-red-500',
      high: 'bg-orange-500',
      medium: 'bg-blue-500',
      low: 'bg-gray-500',
    };
    return colors[level] || 'bg-gray-500';
  }

  function getStatusColor(status: string): string {
    const colors: Record<string, string> = {
      active: 'bg-green-500',
      draft: 'bg-yellow-500',
      archived: 'bg-gray-500',
    };
    return colors[status] || 'bg-gray-500';
  }

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <div className="max-w-5xl mx-auto">
        <div className="mb-6 flex items-center justify-between">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Overview
          </Button>
          <div className="flex gap-2">
            {isEditing ? (
              <>
                <Button onClick={() => setIsEditing(false)} variant="outline">
                  Cancel
                </Button>
                <Button onClick={handleSave}>
                  <Save className="w-4 h-4 mr-2" />
                  Save Changes
                </Button>
              </>
            ) : (
              <>
                <Button onClick={() => setIsEditing(true)} variant="outline">
                  Edit
                </Button>
                <Button onClick={handleDelete} variant="destructive">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
              </>
            )}
          </div>
        </div>

        {/* Timeline Info */}
        <Card className="bg-gray-900 border-gray-800 mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <CardTitle className="text-2xl">{timeline.name}</CardTitle>
                <div className="flex gap-2 mt-2">
                  <Badge className={`${getStatusColor(timeline.status)} text-white`}>
                    {timeline.status}
                  </Badge>
                  <Badge className={`${getImportanceColor(timeline.importanceLevel)} text-white`}>
                    {timeline.importanceLevel}
                  </Badge>
                  <Badge variant="outline">{timeline.category}</Badge>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {isEditing ? (
              <>
                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input
                    value={timeline.name}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTimeline({ ...timeline, name: e.target.value })}
                    className="bg-gray-800 border-gray-700"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea
                    value={timeline.description}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setTimeline({ ...timeline, description: e.target.value })}
                    className="bg-gray-800 border-gray-700 min-h-[100px]"
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Input
                      value={timeline.category}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTimeline({ ...timeline, category: e.target.value })}
                      className="bg-gray-800 border-gray-700"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Status</Label>
                    <Select value={timeline.status} onValueChange={(value: string) => setTimeline({ ...timeline, status: value as Timeline['status'] })}>
                      <SelectTrigger className="bg-gray-800 border-gray-700">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="archived">Archived</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Importance</Label>
                    <Select value={timeline.importanceLevel} onValueChange={(value: string) => setTimeline({ ...timeline, importanceLevel: value as Timeline['importanceLevel'] })}>
                      <SelectTrigger className="bg-gray-800 border-gray-700">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </>
            ) : (
              <>
                <p className="text-gray-300">{timeline.description}</p>
              </>
            )}
          </CardContent>
        </Card>

        {/* SEO Section */}
        {!isEditing && (
          <Card className="bg-gray-900 border-gray-800 mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>SEO Metadata</CardTitle>
                <Button onClick={handleRegenerateSEO} size="sm" variant="outline">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Regenerate
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label className="text-gray-500">Title</Label>
                <p className="text-sm">{timeline.seoTitle}</p>
              </div>
              <div>
                <Label className="text-gray-500">Description</Label>
                <p className="text-sm text-gray-400">{timeline.seoDescription}</p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Entities in Timeline */}
        <Card className="bg-gray-900 border-gray-800 mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Temporal Entities ({entities.length})</CardTitle>
              <Button onClick={() => setShowAttachDialog(true)} size="sm">
                <Plus className="w-4 h-4 mr-2" />
                Attach Entity
              </Button>
            </div>
            <CardDescription>Ordered sequence of events, seasons, and milestones</CardDescription>
          </CardHeader>
          <CardContent>
            {entities.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <p>No entities in this timeline yet</p>
                <p className="text-sm">Attach temporal entities to build your sequence</p>
              </div>
            ) : (
              <div className="space-y-2">
                {entities.map((entity: TemporalEntity, idx: number) => (
                  <Card
                    key={entity.id}
                    className="bg-gray-800 border-gray-700"
                  >
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className="flex flex-col gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleMoveEntity(entity.id, 'up')}
                          disabled={idx === 0}
                        >
                          ▲
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleMoveEntity(entity.id, 'down')}
                          disabled={idx === entities.length - 1}
                        >
                          ▼
                        </Button>
                      </div>
                      
                      <div 
                        className="flex-1 cursor-pointer"
                        onClick={() => onViewEntity(entity.id)}
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{entity.primaryEmoji}</span>
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold">{entity.name}</h3>
                              <Badge variant="outline" className="text-xs">{entity.type}</Badge>
                              <Badge className={`${getImportanceColor(entity.importanceLevel)} text-white text-xs`}>
                                {entity.importanceLevel}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-400 line-clamp-1">{entity.description}</p>
                            {(entity.startAt || entity.endAt) && (
                              <p className="text-xs text-gray-500 mt-1">
                                {entity.startAt && new Date(entity.startAt).toLocaleDateString()}
                                {entity.startAt && entity.endAt && ' → '}
                                {entity.endAt && new Date(entity.endAt).toLocaleDateString()}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>

                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDetachEntity(entity.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Rules */}
        <Card className="bg-gray-900 border-gray-800 mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Temporal Rules ({rules.length})</CardTitle>
              <Button onClick={() => onCreateRule(timelineId)} size="sm">
                <Plus className="w-4 h-4 mr-2" />
                Create Rule
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {rules.length === 0 ? (
              <p className="text-sm text-gray-500 text-center py-8">No rules for this timeline yet</p>
            ) : (
              <div className="space-y-2">
                {rules.map((rule: TemporalRule) => (
                  <Card
                    key={rule.id}
                    className="bg-gray-800 border-gray-700 cursor-pointer hover:bg-gray-750"
                    onClick={() => onViewRule(rule.id)}
                  >
                    <CardContent className="p-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="font-medium">{rule.name}</p>
                          <p className="text-xs text-gray-400">{rule.effectSummary}</p>
                        </div>
                        <Badge variant="outline">{rule.ruleType}</Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Scheduled Actions */}
        <Card className="bg-gray-900 border-gray-800 mb-6">
          <CardHeader>
            <CardTitle>Scheduled Actions ({actions.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {actions.length === 0 ? (
              <p className="text-sm text-gray-500 text-center py-8">No scheduled actions yet</p>
            ) : (
              <div className="space-y-2">
                {actions.map((action: ScheduledAction) => (
                  <Card
                    key={action.id}
                    className="bg-gray-800 border-gray-700 cursor-pointer hover:bg-gray-750"
                    onClick={() => onViewAction(action.id)}
                  >
                    <CardContent className="p-3">
                      <p className="font-medium">{action.name}</p>
                      <p className="text-xs text-gray-400">
                        {new Date(action.scheduledAt).toLocaleString()}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Summaries */}
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle>Generate & Export</CardTitle>
            <CardDescription>Create summaries, calendars, and seasonal narratives</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              <Button onClick={handleGenerateSummary} variant="outline" className="h-auto py-4 flex-col">
                <FileText className="w-6 h-6 mb-2" />
                <span>Timeline Summary</span>
              </Button>
              
              <Button onClick={handleExportCalendar} variant="outline" className="h-auto py-4 flex-col">
                <Calendar className="w-6 h-6 mb-2" />
                <span>Temporal Calendar</span>
              </Button>
              
              <Button onClick={handleGenerateSeasonArc} variant="outline" className="h-auto py-4 flex-col">
                <Sparkles className="w-6 h-6 mb-2" />
                <span>Season Arc</span>
              </Button>
              
              <Button onClick={handleExportSpec} variant="outline" className="h-auto py-4 flex-col">
                <Download className="w-6 h-6 mb-2" />
                <span>Full Specification</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Attach Entity Dialog */}
      <Dialog open={showAttachDialog} onOpenChange={setShowAttachDialog}>
        <DialogContent className="bg-gray-900 border-gray-800 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle>Attach Temporal Entity</DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[400px]">
            <div className="space-y-2">
              {availableEntities.length === 0 ? (
                <p className="text-center text-gray-500 py-8">All entities are already attached</p>
              ) : (
                availableEntities.map((entity: TemporalEntity) => (
                  <Card
                    key={entity.id}
                    className="bg-gray-800 border-gray-700 cursor-pointer hover:bg-gray-750"
                    onClick={() => handleAttachEntity(entity.id)}
                  >
                    <CardContent className="p-3">
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{entity.primaryEmoji}</span>
                        <div className="flex-1">
                          <p className="font-medium">{entity.name}</p>
                          <p className="text-xs text-gray-400">{entity.type} • {entity.importanceLevel}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* Output Dialog */}
      <Dialog open={showOutputDialog} onOpenChange={setShowOutputDialog}>
        <DialogContent className="bg-gray-900 border-gray-800 text-white max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>{outputTitle}</DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[70vh]">
            <pre className="text-sm whitespace-pre-wrap font-mono bg-gray-800 p-4 rounded">{outputContent}</pre>
          </ScrollArea>
          <div className="flex justify-end">
            <Button onClick={() => {
              navigator.clipboard.writeText(outputContent);
              toast.success('Copied to clipboard');
            }}>
              Copy to Clipboard
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
