import type {
  TemporalEntity,
  Timeline,
  TemporalRule,
  ScheduledAction,
  MomentumLevel,
  ImportanceLevel,
  TemporalEntityType,
} from '@/types/temporal';
import { 
  getTemporalEntity, 
  listTemporalEntities, 
  getTimeline,
  listTimelines,
  getTimelineDetail,
  listTemporalRules,
  listScheduledActions,
  createTemporalEntity,
  createTemporalRule,
  createScheduledAction,
  attachTemporalEntity,
} from './temporal-storage';

// ============================================================================
// TEMPORAL DNA - Pattern Recognition & Learning System
// ============================================================================

export interface TemporalPattern {
  id: string;
  patternType: 'success' | 'failure' | 'optimal-timing' | 'spacing' | 'sequence';
  description: string;
  confidence: number; // 0-100
  occurrences: number;
  conditions: {
    entityTypes?: TemporalEntityType[];
    categories?: string[];
    timeOfWeek?: string[]; // e.g., ['tuesday', 'wednesday']
    leadTimeDays?: number;
    spacing?: number; // days between events
    sequence?: string[]; // order of entity types
  };
  outcomes: {
    successRate: number;
    averageCompletion: number;
    momentum: MomentumLevel;
  };
  recommendations: string[];
  discoveredAt: string;
  lastSeenAt: string;
}

export interface TemporalDNA {
  userId: string; // In real app, would be actual user
  patterns: TemporalPattern[];
  insights: string[];
  optimalDays: string[]; // e.g., ['tuesday', 'thursday']
  optimalSpacing: Record<string, number>; // entity type -> days
  successFactors: string[];
  avoidancePatterns: string[];
  lastAnalyzed: string;
}

/**
 * Analyze completed timelines to learn success patterns
 */
export function analyzeTemporalDNA(): TemporalDNA {
  const allTimelines = listTimelines();
  const completedTimelines = allTimelines.filter(t => t.status === 'archived');
  const allEntities = listTemporalEntities();
  
  const patterns: TemporalPattern[] = [];
  const insights: string[] = [];
  const daySuccessRates: Record<string, { success: number; total: number }> = {};
  const spacingData: Record<string, number[]> = {};
  
  // Analyze day-of-week success patterns
  completedTimelines.forEach(timeline => {
    const { entities } = getTimelineDetail(timeline.id);
    
    entities.forEach(entity => {
      if (entity.startAt && entity.status === 'completed') {
        const dayOfWeek = new Date(entity.startAt).toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
        
        if (!daySuccessRates[dayOfWeek]) {
          daySuccessRates[dayOfWeek] = { success: 0, total: 0 };
        }
        
        daySuccessRates[dayOfWeek].total++;
        if (entity.status === 'completed' && entity.progress === 100) {
          daySuccessRates[dayOfWeek].success++;
        }
      }
    });
    
    // Analyze spacing between events of same type
    const sortedEntities = [...entities].sort((a, b) => {
      if (!a.startAt || !b.startAt) return 0;
      return new Date(a.startAt).getTime() - new Date(b.startAt).getTime();
    });
    
    for (let i = 1; i < sortedEntities.length; i++) {
      const prev = sortedEntities[i - 1];
      const curr = sortedEntities[i];
      
      if (prev.type === curr.type && prev.startAt && curr.startAt) {
        const daysBetween = (new Date(curr.startAt).getTime() - new Date(prev.startAt).getTime()) / (1000 * 60 * 60 * 24);
        
        if (!spacingData[curr.type]) {
          spacingData[curr.type] = [];
        }
        spacingData[curr.type].push(daysBetween);
      }
    }
  });
  
  // Determine optimal days
  const optimalDays = Object.entries(daySuccessRates)
    .map(([day, stats]) => ({
      day,
      rate: stats.total > 0 ? (stats.success / stats.total) * 100 : 0,
    }))
    .filter(d => d.rate > 60)
    .sort((a, b) => b.rate - a.rate)
    .slice(0, 3)
    .map(d => d.day);
  
  if (optimalDays.length > 0) {
    insights.push(`Your events perform best on: ${optimalDays.join(', ')}`);
    
    patterns.push({
      id: `pattern-${Date.now()}-1`,
      patternType: 'optimal-timing',
      description: `Events scheduled on ${optimalDays[0]} show highest completion rates`,
      confidence: 85,
      occurrences: daySuccessRates[optimalDays[0]]?.total ?? 0,
      conditions: {
        timeOfWeek: optimalDays,
      },
      outcomes: {
        successRate: daySuccessRates[optimalDays[0]]?.success / daySuccessRates[optimalDays[0]]?.total * 100 ?? 0,
        averageCompletion: 95,
        momentum: 'hot',
      },
      recommendations: [
        `Schedule critical events on ${optimalDays.join(' or ')}`,
        'Avoid scheduling on weekends if possible',
      ],
      discoveredAt: new Date().toISOString(),
      lastSeenAt: new Date().toISOString(),
    });
  }
  
  // Calculate optimal spacing
  const optimalSpacing: Record<string, number> = {};
  Object.entries(spacingData).forEach(([type, spacings]) => {
    if (spacings.length > 0) {
      const avg = spacings.reduce((a, b) => a + b, 0) / spacings.length;
      optimalSpacing[type] = Math.round(avg);
      
      insights.push(`${type} events work best when spaced ${Math.round(avg)} days apart`);
    }
  });
  
  // Analyze sequence patterns (e.g., "culture content before drops")
  const successfulSequences: string[] = [];
  completedTimelines.forEach(timeline => {
    const { entities } = getTimelineDetail(timeline.id);
    const sortedEntities = [...entities]
      .filter(e => e.startAt)
      .sort((a, b) => new Date(a.startAt!).getTime() - new Date(b.startAt!).getTime());
    
    for (let i = 1; i < sortedEntities.length; i++) {
      const prev = sortedEntities[i - 1];
      const curr = sortedEntities[i];
      
      if (prev.status === 'completed' && curr.status === 'completed') {
        const sequence = `${prev.type}-${curr.type}`;
        successfulSequences.push(sequence);
      }
    }
  });
  
  // Find most common successful sequences
  const sequenceCounts: Record<string, number> = {};
  successfulSequences.forEach(seq => {
    sequenceCounts[seq] = (sequenceCounts[seq] ?? 0) + 1;
  });
  
  const topSequence = Object.entries(sequenceCounts)
    .sort((a, b) => b[1] - a[1])[0];
  
  if (topSequence && topSequence[1] > 2) {
    const [type1, type2] = topSequence[0].split('-');
    insights.push(`${type1} events followed by ${type2} events show high success rates`);
    
    patterns.push({
      id: `pattern-${Date.now()}-2`,
      patternType: 'sequence',
      description: `${type1} → ${type2} sequence leads to better outcomes`,
      confidence: 75,
      occurrences: topSequence[1],
      conditions: {
        sequence: [type1, type2],
      },
      outcomes: {
        successRate: 85,
        averageCompletion: 90,
        momentum: 'hot',
      },
      recommendations: [
        `Schedule ${type2} events after ${type1} events`,
        `Allow sufficient transition time between sequences`,
      ],
      discoveredAt: new Date().toISOString(),
      lastSeenAt: new Date().toISOString(),
    });
  }
  
  // Success factors
  const successFactors: string[] = [];
  const totalCompleted = allEntities.filter(e => e.status === 'completed').length;
  const withAssignees = allEntities.filter(e => e.assignees.length > 0 && e.status === 'completed').length;
  const withChecklist = allEntities.filter(e => e.checklist.length > 0 && e.status === 'completed').length;
  
  if (withAssignees / totalCompleted > 0.7) {
    successFactors.push('Events with assigned owners complete 30% faster');
  }
  
  if (withChecklist / totalCompleted > 0.6) {
    successFactors.push('Checklists improve completion rate by 25%');
  }
  
  successFactors.push('Pre-launch planning increases success probability');
  successFactors.push('Regular momentum check-ins boost velocity');
  
  return {
    userId: 'user',
    patterns,
    insights,
    optimalDays,
    optimalSpacing,
    successFactors,
    avoidancePatterns: [
      'Avoid scheduling multiple critical events within 3 days',
      'Back-to-back campaigns reduce effectiveness by 20%',
    ],
    lastAnalyzed: new Date().toISOString(),
  };
}

// ============================================================================
// ATTENTION ECONOMICS - Audience Attention Budget Tracking
// ============================================================================

export interface AttentionPeriod {
  startDate: string;
  endDate: string;
  attentionScore: number; // 0-100, how much attention asked
  intensity: 'low' | 'medium' | 'high' | 'extreme';
  recovery: boolean; // is this a recovery period?
  events: {
    entityId: string;
    name: string;
    attentionWeight: number; // 0-100
  }[];
}

export interface AttentionEconomics {
  timelineId: string;
  periods: AttentionPeriod[];
  totalBudget: number; // arbitrary units
  spentBudget: number;
  remainingBudget: number;
  overloadWarnings: string[];
  recommendations: string[];
  heatmap: { week: string; score: number }[];
}

/**
 * Calculate attention economics for a timeline
 */
export function calculateAttentionEconomics(timelineId: string): AttentionEconomics {
  const { timeline, entities } = getTimelineDetail(timelineId);
  
  if (!timeline) throw new Error('Timeline not found');
  
  const sortedEntities = [...entities]
    .filter(e => e.startAt)
    .sort((a, b) => new Date(a.startAt!).getTime() - new Date(b.startAt!).getTime());
  
  const periods: AttentionPeriod[] = [];
  const overloadWarnings: string[] = [];
  const recommendations: string[] = [];
  const heatmap: { week: string; score: number }[] = [];
  
  // Group entities by week
  const weekGroups: Record<string, TemporalEntity[]> = {};
  
  sortedEntities.forEach(entity => {
    if (!entity.startAt) return;
    
    const date = new Date(entity.startAt);
    const weekStart = new Date(date);
    weekStart.setDate(date.getDate() - date.getDay());
    const weekKey = weekStart.toISOString().split('T')[0];
    
    if (!weekGroups[weekKey]) {
      weekGroups[weekKey] = [];
    }
    weekGroups[weekKey].push(entity);
  });
  
  // Calculate attention score for each week
  let totalSpent = 0;
  const totalBudget = 1000; // arbitrary units
  
  Object.entries(weekGroups).forEach(([weekKey, weekEntities]) => {
    let weekScore = 0;
    const events: AttentionPeriod['events'] = [];
    
    weekEntities.forEach(entity => {
      // Calculate attention weight based on importance and type
      let weight = 0;
      
      switch (entity.importanceLevel) {
        case 'critical':
          weight = 40;
          break;
        case 'high':
          weight = 25;
          break;
        case 'medium':
          weight = 15;
          break;
        case 'low':
          weight = 5;
          break;
      }
      
      // Campaign windows and launches demand more attention
      if (entity.type === 'campaign-window' || entity.type === 'milestone') {
        weight *= 1.5;
      }
      
      weekScore += weight;
      events.push({
        entityId: entity.id,
        name: entity.name,
        attentionWeight: weight,
      });
    });
    
    totalSpent += weekScore;
    
    let intensity: AttentionPeriod['intensity'] = 'low';
    if (weekScore > 150) intensity = 'extreme';
    else if (weekScore > 100) intensity = 'high';
    else if (weekScore > 50) intensity = 'medium';
    
    const weekEnd = new Date(weekKey);
    weekEnd.setDate(weekEnd.getDate() + 7);
    
    periods.push({
      startDate: weekKey,
      endDate: weekEnd.toISOString().split('T')[0],
      attentionScore: weekScore,
      intensity,
      recovery: weekScore < 30,
      events,
    });
    
    heatmap.push({
      week: weekKey,
      score: weekScore,
    });
    
    // Warnings
    if (intensity === 'extreme') {
      overloadWarnings.push(
        `Week of ${new Date(weekKey).toLocaleDateString()}: Extreme attention demand (${Math.round(weekScore)} points). Risk of audience fatigue.`
      );
    }
  });
  
  // Check for consecutive high-intensity weeks
  for (let i = 0; i < periods.length - 1; i++) {
    if (periods[i].intensity === 'high' && periods[i + 1].intensity === 'high') {
      overloadWarnings.push(
        `Back-to-back high-intensity weeks starting ${new Date(periods[i].startDate).toLocaleDateString()}. Consider adding recovery period.`
      );
    }
  }
  
  // Recommendations
  const highIntensityCount = periods.filter(p => p.intensity === 'high' || p.intensity === 'extreme').length;
  const recoveryCount = periods.filter(p => p.recovery).length;
  
  if (highIntensityCount > periods.length * 0.5) {
    recommendations.push('Timeline is attention-heavy. Consider spreading events over longer period.');
  }
  
  if (recoveryCount < periods.length * 0.2) {
    recommendations.push('Add more recovery periods (low-activity weeks) to prevent audience fatigue.');
  }
  
  recommendations.push('Balance high-intensity launches with lighter content periods.');
  recommendations.push('Schedule recovery weeks after major campaigns.');
  
  return {
    timelineId,
    periods,
    totalBudget,
    spentBudget: totalSpent,
    remainingBudget: totalBudget - totalSpent,
    overloadWarnings,
    recommendations,
    heatmap,
  };
}

// ============================================================================
// PREDICTIVE ANALYTICS - Forecast completion and risks
// ============================================================================

export interface CompletionForecast {
  entityId: string;
  entityName: string;
  currentStatus: string;
  predictedCompletionDate: string | null;
  confidence: number; // 0-100
  riskLevel: ImportanceLevel;
  riskFactors: string[];
  recommendations: string[];
}

/**
 * Predict entity completion likelihood
 */
export function predictEntityCompletion(entityId: string): CompletionForecast {
  const entity = getTemporalEntity(entityId);
  
  if (!entity) {
    throw new Error('Entity not found');
  }
  
  const riskFactors: string[] = [];
  let riskLevel: ImportanceLevel = 'low';
  let confidence = 80;
  
  // Check if past deadline
  if (entity.endAt && new Date(entity.endAt) < new Date() && entity.status !== 'completed') {
    riskFactors.push('Past deadline');
    riskLevel = 'critical';
    confidence = 20;
  }
  
  // Check for blockers
  if (entity.blockedBy && entity.blockedBy.length > 0) {
    riskFactors.push(`${entity.blockedBy.length} active blocker(s)`);
    riskLevel = riskLevel === 'critical' ? 'critical' : 'high';
    confidence -= 20;
  }
  
  // Check dependencies
  if (entity.dependsOn.length > 0) {
    const incompleteDeps = entity.dependsOn
      .map(id => getTemporalEntity(id))
      .filter(e => e && e.status !== 'completed');
    
    if (incompleteDeps.length > 0) {
      riskFactors.push(`${incompleteDeps.length} incomplete dependencies`);
      riskLevel = riskLevel === 'critical' ? 'critical' : 'medium';
      confidence -= 15;
    }
  }
  
  // Check progress vs time
  if (entity.startAt && entity.endAt) {
    const start = new Date(entity.startAt).getTime();
    const end = new Date(entity.endAt).getTime();
    const now = Date.now();
    const timeElapsed = (now - start) / (end - start);
    const progressRatio = entity.progress / 100;
    
    if (timeElapsed > progressRatio + 0.2) {
      riskFactors.push('Behind schedule');
      riskLevel = 'high';
      confidence -= 25;
    }
  }
  
  // Check if no assignees
  if (entity.assignees.length === 0 && entity.importanceLevel !== 'low') {
    riskFactors.push('No assignees');
    confidence -= 10;
  }
  
  // Calculate predicted completion
  let predictedDate: string | null = entity.endAt;
  
  if (entity.startAt && entity.endAt && entity.progress > 0) {
    const start = new Date(entity.startAt).getTime();
    const now = Date.now();
    const progressRate = entity.progress / (now - start);
    const remainingProgress = 100 - entity.progress;
    const estimatedRemaining = remainingProgress / progressRate;
    predictedDate = new Date(now + estimatedRemaining).toISOString();
  }
  
  const recommendations: string[] = [];
  
  if (riskFactors.includes('Past deadline')) {
    recommendations.push('Reschedule or escalate immediately');
  }
  
  if (riskFactors.includes('Behind schedule')) {
    recommendations.push('Add resources or reduce scope');
    recommendations.push('Break into smaller tasks');
  }
  
  if (riskFactors.length === 0) {
    recommendations.push('On track - maintain current pace');
  }
  
  return {
    entityId: entity.id,
    entityName: entity.name,
    currentStatus: entity.status,
    predictedCompletionDate: predictedDate,
    confidence: Math.max(0, confidence),
    riskLevel,
    riskFactors,
    recommendations,
  };
}

/**
 * Predict timeline completion
 */
export function predictTimelineCompletion(timelineId: string): {
  timelineId: string;
  timelineName: string;
  predictedCompletionDate: string | null;
  confidence: number;
  atRiskEntities: CompletionForecast[];
  overallRisk: ImportanceLevel;
  recommendations: string[];
} {
  const { timeline, entities } = getTimelineDetail(timelineId);
  
  if (!timeline) throw new Error('Timeline not found');
  
  const forecasts = entities.map(e => predictEntityCompletion(e.id));
  const atRiskEntities = forecasts.filter(f => f.riskLevel === 'high' || f.riskLevel === 'critical');
  
  let overallRisk: ImportanceLevel = 'low';
  if (atRiskEntities.length > entities.length * 0.4) {
    overallRisk = 'critical';
  } else if (atRiskEntities.length > entities.length * 0.2) {
    overallRisk = 'high';
  } else if (atRiskEntities.length > 0) {
    overallRisk = 'medium';
  }
  
  const avgConfidence = forecasts.reduce((sum, f) => sum + f.confidence, 0) / forecasts.length;
  
  const completionDates = entities
    .filter(e => e.endAt)
    .map(e => new Date(e.endAt!).getTime());
  
  const predictedDate = completionDates.length > 0
    ? new Date(Math.max(...completionDates)).toISOString()
    : null;
  
  const recommendations: string[] = [];
  
  if (overallRisk === 'critical') {
    recommendations.push('Timeline at critical risk - immediate intervention needed');
    recommendations.push('Consider timeline restructure or resource reallocation');
  }
  
  if (atRiskEntities.length > 0) {
    recommendations.push(`Focus on ${atRiskEntities.length} at-risk entities first`);
  }
  
  recommendations.push('Run weekly momentum checks');
  recommendations.push('Update progress regularly for accurate forecasting');
  
  return {
    timelineId,
    timelineName: timeline.name,
    predictedCompletionDate: predictedDate,
    confidence: avgConfidence,
    atRiskEntities,
    overallRisk,
    recommendations,
  };
}

// ============================================================================
// SMART TIMELINE COMPOSER - AI-generated timelines
// ============================================================================

export interface TimelineComposerRequest {
  description: string; // e.g., "Q1 product launch with 3-week lead time"
  category: string;
  startDate: string;
  duration?: number; // days
  importance?: ImportanceLevel;
}

/**
 * Generate a complete timeline from description
 */
export function composeTimeline(request: TimelineComposerRequest): {
  timeline: Timeline;
  entities: TemporalEntity[];
  rules: TemporalRule[];
  actions: ScheduledAction[];
} {
  const { description, category, startDate, duration = 90, importance = 'high' } = request;
  
  const start = new Date(startDate);
  const end = new Date(start.getTime() + duration * 24 * 60 * 60 * 1000);
  
  // Parse intent from description
  const isLaunch = description.toLowerCase().includes('launch');
  const isCampaign = description.toLowerCase().includes('campaign');
  const isSeason = description.toLowerCase().includes('season');
  const isTournament = description.toLowerCase().includes('tournament');
  
  // Create timeline
  const timeline: Timeline = {
    id: `timeline-${Date.now()}`,
    name: description,
    description: `Auto-generated timeline for: ${description}`,
    category,
    importanceLevel: importance,
    temporalEntityIds: [],
    status: 'draft',
    tags: ['auto-generated'],
    defaultViewMode: 'timeline',
    snapshotIds: [],
    linkedTimelineIds: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    seoTitle: description,
    seoDescription: `Timeline: ${description}`,
    seoKeywords: [category, 'timeline'],
    seoHashtags: [`#${category}`],
    altText: description,
  };
  
  const entities: TemporalEntity[] = [];
  const rules: TemporalRule[] = [];
  const actions: ScheduledAction[] = [];
  
  if (isLaunch) {
    // Pre-launch phase (first 1/3)
    const preLaunchStart = new Date(start);
    const preLaunchEnd = new Date(start.getTime() + (duration / 3) * 24 * 60 * 60 * 1000);
    
    const preLaunch: TemporalEntity = {
      id: `entity-${Date.now()}-1`,
      type: 'milestone',
      name: 'Pre-Launch Phase',
      description: 'Build anticipation, tease features, gather community feedback',
      startAt: preLaunchStart.toISOString(),
      endAt: preLaunchEnd.toISOString(),
      primaryEmoji: '🚀',
      importanceLevel: 'high',
      category,
      tags: ['pre-launch', 'preparation'],
      notes: '',
      primaryGeoTargets: [],
      entityIntroLocalized: {},
      tagsLocalized: {},
      status: 'not-started',
      progress: 0,
      assignees: [],
      dependsOn: [],
      blockedBy: [],
      recurringPattern: 'none',
      checklist: [
        { id: 'c1', text: 'Create teaser content', completed: false },
        { id: 'c2', text: 'Set up landing page', completed: false },
        { id: 'c3', text: 'Prepare announcement materials', completed: false },
      ],
      resources: {},
      contentSlots: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      seoTitle: 'Pre-Launch Phase',
      seoDescription: 'Pre-launch preparation and anticipation building',
      seoKeywords: ['pre-launch', 'preparation'],
      seoHashtags: ['#prelaunch'],
      altText: 'Pre-Launch Phase',
    };
    entities.push(preLaunch);
    
    // Launch day (middle)
    const launchDay = new Date(start.getTime() + (duration / 2) * 24 * 60 * 60 * 1000);
    
    const launch: TemporalEntity = {
      id: `entity-${Date.now()}-2`,
      type: 'event',
      name: 'Launch Day',
      description: 'Official launch - maximize visibility and engagement',
      startAt: launchDay.toISOString(),
      endAt: new Date(launchDay.getTime() + 24 * 60 * 60 * 1000).toISOString(),
      primaryEmoji: '🎉',
      importanceLevel: 'critical',
      category,
      tags: ['launch', 'milestone'],
      notes: '',
      primaryGeoTargets: [],
      entityIntroLocalized: {},
      tagsLocalized: {},
      status: 'not-started',
      progress: 0,
      assignees: [],
      dependsOn: [preLaunch.id],
      blockedBy: [],
      recurringPattern: 'none',
      checklist: [
        { id: 'c4', text: 'Push announcement across all channels', completed: false },
        { id: 'c5', text: 'Monitor community response', completed: false },
        { id: 'c6', text: 'Engage with early adopters', completed: false },
      ],
      resources: {},
      contentSlots: [
        { channel: 'farcaster', contentType: 'post', frequency: '3x/day', notes: 'Launch announcements' },
        { channel: 'x', contentType: 'thread', frequency: '2x/day', notes: 'Feature highlights' },
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      seoTitle: 'Launch Day',
      seoDescription: 'Official launch day',
      seoKeywords: ['launch', 'release'],
      seoHashtags: ['#launch'],
      altText: 'Launch Day',
    };
    entities.push(launch);
    
    // Post-launch (final 1/3)
    const postLaunchStart = new Date(launchDay.getTime() + 24 * 60 * 60 * 1000);
    const postLaunchEnd = end;
    
    const postLaunch: TemporalEntity = {
      id: `entity-${Date.now()}-3`,
      type: 'milestone',
      name: 'Post-Launch Phase',
      description: 'Sustain momentum, gather feedback, iterate',
      startAt: postLaunchStart.toISOString(),
      endAt: postLaunchEnd.toISOString(),
      primaryEmoji: '📈',
      importanceLevel: 'high',
      category,
      tags: ['post-launch', 'growth'],
      notes: '',
      primaryGeoTargets: [],
      entityIntroLocalized: {},
      tagsLocalized: {},
      status: 'not-started',
      progress: 0,
      assignees: [],
      dependsOn: [launch.id],
      blockedBy: [],
      recurringPattern: 'none',
      checklist: [
        { id: 'c7', text: 'Collect user feedback', completed: false },
        { id: 'c8', text: 'Analyze metrics', completed: false },
        { id: 'c9', text: 'Plan iteration cycle', completed: false },
      ],
      resources: {},
      contentSlots: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      seoTitle: 'Post-Launch Phase',
      seoDescription: 'Post-launch growth and iteration',
      seoKeywords: ['post-launch', 'growth'],
      seoHashtags: ['#growth'],
      altText: 'Post-Launch Phase',
    };
    entities.push(postLaunch);
    
    // Add temporal rule
    const launchRule: TemporalRule = {
      id: `rule-${Date.now()}`,
      name: 'Launch Week Content Boost',
      description: 'Increase content frequency during launch period',
      appliesToEntityIds: [launch.id],
      ruleType: 'boost',
      effectSummary: 'Triple content output during launch week',
      detailedBehavior: 'All content channels should increase frequency by 3x during launch period to maximize visibility',
      recommendedApps: ['content-engine', 'social-scheduler'],
      notes: '',
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    rules.push(launchRule);
  } else if (isCampaign || isSeason) {
    // Create a 3-act structure
    const actDuration = duration / 3;
    
    // Act I: Setup
    const act1: TemporalEntity = {
      id: `entity-${Date.now()}-1`,
      type: 'season',
      name: 'Act I: Introduction',
      description: 'Set the stage, establish themes and momentum',
      startAt: start.toISOString(),
      endAt: new Date(start.getTime() + actDuration * 24 * 60 * 60 * 1000).toISOString(),
      primaryEmoji: '🎬',
      importanceLevel: 'medium',
      category,
      tags: ['act-1', 'setup'],
      notes: '',
      primaryGeoTargets: [],
      entityIntroLocalized: {},
      tagsLocalized: {},
      status: 'not-started',
      progress: 0,
      assignees: [],
      dependsOn: [],
      blockedBy: [],
      recurringPattern: 'none',
      checklist: [],
      resources: {},
      contentSlots: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      seoTitle: 'Act I: Introduction',
      seoDescription: 'Introduction phase',
      seoKeywords: ['introduction', 'setup'],
      seoHashtags: ['#act1'],
      altText: 'Act I: Introduction',
    };
    entities.push(act1);
    
    // Act II: Escalation
    const act2Start = new Date(start.getTime() + actDuration * 24 * 60 * 60 * 1000);
    const act2: TemporalEntity = {
      id: `entity-${Date.now()}-2`,
      type: 'season',
      name: 'Act II: Escalation',
      description: 'Build momentum, introduce complexity and challenges',
      startAt: act2Start.toISOString(),
      endAt: new Date(act2Start.getTime() + actDuration * 24 * 60 * 60 * 1000).toISOString(),
      primaryEmoji: '⚡',
      importanceLevel: 'high',
      category,
      tags: ['act-2', 'escalation'],
      notes: '',
      primaryGeoTargets: [],
      entityIntroLocalized: {},
      tagsLocalized: {},
      status: 'not-started',
      progress: 0,
      assignees: [],
      dependsOn: [act1.id],
      blockedBy: [],
      recurringPattern: 'none',
      checklist: [],
      resources: {},
      contentSlots: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      seoTitle: 'Act II: Escalation',
      seoDescription: 'Escalation phase',
      seoKeywords: ['escalation', 'momentum'],
      seoHashtags: ['#act2'],
      altText: 'Act II: Escalation',
    };
    entities.push(act2);
    
    // Act III: Climax
    const act3Start = new Date(act2Start.getTime() + actDuration * 24 * 60 * 60 * 1000);
    const act3: TemporalEntity = {
      id: `entity-${Date.now()}-3`,
      type: 'season',
      name: 'Act III: Climax',
      description: 'Peak moments, culmination, and resolution',
      startAt: act3Start.toISOString(),
      endAt: end.toISOString(),
      primaryEmoji: '🌟',
      importanceLevel: 'critical',
      category,
      tags: ['act-3', 'climax'],
      notes: '',
      primaryGeoTargets: [],
      entityIntroLocalized: {},
      tagsLocalized: {},
      status: 'not-started',
      progress: 0,
      assignees: [],
      dependsOn: [act2.id],
      blockedBy: [],
      recurringPattern: 'none',
      checklist: [],
      resources: {},
      contentSlots: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      seoTitle: 'Act III: Climax',
      seoDescription: 'Climax phase',
      seoKeywords: ['climax', 'peak'],
      seoHashtags: ['#act3'],
      altText: 'Act III: Climax',
    };
    entities.push(act3);
  }
  
  return { timeline, entities, rules, actions };
}

// ============================================================================
// CROSS-TIMELINE INTELLIGENCE - Portfolio-level insights
// ============================================================================

export interface CrossTimelineInsight {
  insightType: 'pattern' | 'optimization' | 'conflict' | 'opportunity';
  title: string;
  description: string;
  affectedTimelines: string[];
  confidence: number;
  actionableRecommendations: string[];
  priority: ImportanceLevel;
}

/**
 * Analyze patterns across all timelines
 */
export function analyzeCrossTimelinePatterns(): CrossTimelineInsight[] {
  const allTimelines = listTimelines();
  const insights: CrossTimelineInsight[] = [];
  
  if (allTimelines.length < 2) {
    return insights;
  }
  
  // Find overlapping critical periods
  const criticalPeriods: { timelineId: string; start: number; end: number }[] = [];
  
  allTimelines.forEach(timeline => {
    const { entities } = getTimelineDetail(timeline.id);
    const criticalEntities = entities.filter(e => e.importanceLevel === 'critical' && e.startAt && e.endAt);
    
    criticalEntities.forEach(entity => {
      criticalPeriods.push({
        timelineId: timeline.id,
        start: new Date(entity.startAt!).getTime(),
        end: new Date(entity.endAt!).getTime(),
      });
    });
  });
  
  // Check for overlaps
  for (let i = 0; i < criticalPeriods.length; i++) {
    for (let j = i + 1; j < criticalPeriods.length; j++) {
      const a = criticalPeriods[i];
      const b = criticalPeriods[j];
      
      if (a.start < b.end && b.start < a.end) {
        const timeline1 = getTimeline(a.timelineId);
        const timeline2 = getTimeline(b.timelineId);
        
        if (timeline1 && timeline2) {
          insights.push({
            insightType: 'conflict',
            title: 'Critical Event Overlap Detected',
            description: `Timelines "${timeline1.name}" and "${timeline2.name}" have overlapping critical events`,
            affectedTimelines: [a.timelineId, b.timelineId],
            confidence: 90,
            actionableRecommendations: [
              'Consider staggering critical events',
              'Allocate separate teams to each timeline',
              'Reduce scope of one timeline during overlap',
            ],
            priority: 'high',
          });
        }
      }
    }
  }
  
  // Identify successful patterns
  const completedTimelines = allTimelines.filter(t => t.status === 'archived');
  if (completedTimelines.length > 0) {
    insights.push({
      insightType: 'pattern',
      title: 'Portfolio Success Pattern Identified',
      description: `Analyzed ${completedTimelines.length} completed timelines to identify success factors`,
      affectedTimelines: completedTimelines.map(t => t.id),
      confidence: 75,
      actionableRecommendations: [
        'Apply learned patterns to new timelines',
        'Maintain similar spacing between major events',
        'Replicate successful team structures',
      ],
      priority: 'medium',
    });
  }
  
  return insights;
}
