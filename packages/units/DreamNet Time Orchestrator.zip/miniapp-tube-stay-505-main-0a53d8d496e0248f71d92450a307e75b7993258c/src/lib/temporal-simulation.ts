import type {
  TemporalEntity,
  Timeline,
  TemporalDependency,
  ImportanceLevel,
} from '@/types/temporal';
import {
  getTimeline,
  getTimelineDetail,
  getTemporalEntity,
  getDependenciesForEntity,
  calculateTimelineAnalytics,
  detectConflicts,
} from './temporal-storage';

// ============================================================================
// ECOSYSTEM SIMULATOR - What-if scenario modeling
// ============================================================================

export interface SimulationScenario {
  id: string;
  name: string;
  description: string;
  baseTimelineId: string;
  changes: SimulationChange[];
  createdAt: string;
}

export type SimulationChange =
  | { type: 'move-entity'; entityId: string; newStartDate: string; newEndDate?: string }
  | { type: 'delete-entity'; entityId: string }
  | { type: 'add-entity'; entityData: Partial<TemporalEntity> }
  | { type: 'change-importance'; entityId: string; newImportance: ImportanceLevel }
  | { type: 'change-duration'; entityId: string; newDuration: number };

export interface SimulationResult {
  scenarioId: string;
  timelineId: string;
  originalState: {
    entities: TemporalEntity[];
    analytics: ReturnType<typeof calculateTimelineAnalytics>;
    conflicts: ReturnType<typeof detectConflicts>;
  };
  simulatedState: {
    entities: TemporalEntity[];
    analytics: ReturnType<typeof calculateTimelineAnalytics>;
    conflicts: ReturnType<typeof detectConflicts>;
  };
  impact: {
    completionRateChange: number; // percentage points
    conflictCountChange: number;
    atRiskCountChange: number;
    criticalPathChange: number;
    momentumChange: string; // e.g., "hot -> warming"
  };
  cascadingEffects: {
    entityId: string;
    entityName: string;
    effectType: 'shifted' | 'blocked' | 'unblocked' | 'rescheduled';
    description: string;
  }[];
  recommendations: string[];
  riskLevel: ImportanceLevel;
}

/**
 * Run a simulation to test timeline changes
 */
export function runSimulation(
  timelineId: string,
  changes: SimulationChange[]
): SimulationResult {
  const { timeline, entities: originalEntities } = getTimelineDetail(timelineId);
  
  if (!timeline) {
    throw new Error('Timeline not found');
  }
  
  // Clone entities for simulation
  let simulatedEntities = JSON.parse(JSON.stringify(originalEntities)) as TemporalEntity[];
  
  const cascadingEffects: SimulationResult['cascadingEffects'] = [];
  
  // Apply changes
  changes.forEach(change => {
    switch (change.type) {
      case 'move-entity': {
        const entityIndex = simulatedEntities.findIndex(e => e.id === change.entityId);
        if (entityIndex !== -1) {
          const oldStart = simulatedEntities[entityIndex].startAt;
          simulatedEntities[entityIndex].startAt = change.newStartDate;
          
          if (change.newEndDate) {
            simulatedEntities[entityIndex].endAt = change.newEndDate;
          }
          
          // Check for dependent entities
          const dependents = simulatedEntities.filter(e => 
            e.dependsOn.includes(change.entityId)
          );
          
          // Shift dependents
          if (oldStart && change.newStartDate) {
            const shift = new Date(change.newStartDate).getTime() - new Date(oldStart).getTime();
            
            dependents.forEach(dep => {
              if (dep.startAt) {
                const newStart = new Date(new Date(dep.startAt).getTime() + shift);
                cascadingEffects.push({
                  entityId: dep.id,
                  entityName: dep.name,
                  effectType: 'shifted',
                  description: `Shifted by ${Math.round(shift / (1000 * 60 * 60 * 24))} days due to dependency`,
                });
                dep.startAt = newStart.toISOString();
                
                if (dep.endAt) {
                  dep.endAt = new Date(new Date(dep.endAt).getTime() + shift).toISOString();
                }
              }
            });
          }
        }
        break;
      }
      
      case 'delete-entity': {
        const deletedEntity = simulatedEntities.find(e => e.id === change.entityId);
        simulatedEntities = simulatedEntities.filter(e => e.id !== change.entityId);
        
        // Check if any entities depended on this
        const affectedEntities = simulatedEntities.filter(e => 
          e.dependsOn.includes(change.entityId)
        );
        
        affectedEntities.forEach(entity => {
          cascadingEffects.push({
            entityId: entity.id,
            entityName: entity.name,
            effectType: 'unblocked',
            description: `Dependency on "${deletedEntity?.name}" removed`,
          });
          entity.dependsOn = entity.dependsOn.filter(id => id !== change.entityId);
        });
        break;
      }
      
      case 'add-entity': {
        const newEntity = {
          id: `sim-entity-${Date.now()}`,
          type: change.entityData.type ?? 'event',
          name: change.entityData.name ?? 'New Entity',
          description: change.entityData.description ?? '',
          startAt: change.entityData.startAt ?? new Date().toISOString(),
          endAt: change.entityData.endAt ?? null,
          primaryEmoji: change.entityData.primaryEmoji ?? '⚡',
          importanceLevel: change.entityData.importanceLevel ?? 'medium',
          category: change.entityData.category ?? '',
          tags: change.entityData.tags ?? [],
          notes: '',
          primaryGeoTargets: [],
          entityIntroLocalized: {},
          tagsLocalized: {},
          status: 'not-started' as const,
          progress: 0,
          assignees: [],
          dependsOn: [],
          blockedBy: [],
          recurringPattern: 'none' as const,
          checklist: [],
          resources: {},
          contentSlots: [],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          seoTitle: '',
          seoDescription: '',
          seoKeywords: [],
          seoHashtags: [],
          altText: '',
        } as TemporalEntity;
        
        simulatedEntities.push(newEntity);
        break;
      }
      
      case 'change-importance': {
        const entityIndex = simulatedEntities.findIndex(e => e.id === change.entityId);
        if (entityIndex !== -1) {
          simulatedEntities[entityIndex].importanceLevel = change.newImportance;
        }
        break;
      }
      
      case 'change-duration': {
        const entityIndex = simulatedEntities.findIndex(e => e.id === change.entityId);
        if (entityIndex !== -1 && simulatedEntities[entityIndex].startAt) {
          const start = new Date(simulatedEntities[entityIndex].startAt!);
          const newEnd = new Date(start.getTime() + change.newDuration * 24 * 60 * 60 * 1000);
          simulatedEntities[entityIndex].endAt = newEnd.toISOString();
        }
        break;
      }
    }
  });
  
  // Create mock timeline details for analytics
  const mockTimelineId = `${timelineId}-sim`;
  
  // Calculate original state
  const originalAnalytics = calculateTimelineAnalytics(timelineId);
  const originalConflicts = detectConflicts(timelineId);
  
  // For simulated state, we need to temporarily inject the simulated entities
  // This is a simplified approach - in production you'd use a proper state management
  const simulatedAnalytics = {
    timelineId: mockTimelineId,
    totalEntities: simulatedEntities.length,
    completedEntities: simulatedEntities.filter(e => e.status === 'completed').length,
    inProgressEntities: simulatedEntities.filter(e => e.status === 'in-progress').length,
    blockedEntities: simulatedEntities.filter(e => e.status === 'blocked').length,
    completionRate: simulatedEntities.length > 0 
      ? (simulatedEntities.filter(e => e.status === 'completed').length / simulatedEntities.length) * 100 
      : 0,
    onTrackCount: simulatedEntities.filter(e => {
      if (!e.endAt) return true;
      return new Date(e.endAt) > new Date();
    }).length,
    atRiskCount: 0,
    overallMomentum: 'warming' as const,
    criticalPathLength: simulatedEntities.filter(e => e.dependsOn.length > 0).length,
    budgetUtilization: undefined,
  };
  
  simulatedAnalytics.atRiskCount = simulatedAnalytics.totalEntities - simulatedAnalytics.onTrackCount;
  
  // Detect conflicts in simulated state (simplified)
  const simulatedConflicts: ReturnType<typeof detectConflicts> = [];
  
  // Check for overlaps
  for (let i = 0; i < simulatedEntities.length; i++) {
    for (let j = i + 1; j < simulatedEntities.length; j++) {
      const a = simulatedEntities[i];
      const b = simulatedEntities[j];
      
      if (a.startAt && a.endAt && b.startAt && b.endAt) {
        const aStart = new Date(a.startAt).getTime();
        const aEnd = new Date(a.endAt).getTime();
        const bStart = new Date(b.startAt).getTime();
        const bEnd = new Date(b.endAt).getTime();
        
        if (aStart < bEnd && bStart < aEnd) {
          if (a.importanceLevel === 'critical' && b.importanceLevel === 'critical') {
            simulatedConflicts.push({
              id: `sim-conflict-${Date.now()}-${i}-${j}`,
              conflictType: 'overlap',
              severity: 'high',
              description: `Critical events overlap: ${a.name} and ${b.name}`,
              affectedEntityIds: [a.id, b.id],
              suggestedResolution: 'Consider rescheduling one event',
            });
          }
        }
      }
    }
  }
  
  // Calculate impact
  const impact = {
    completionRateChange: simulatedAnalytics.completionRate - originalAnalytics.completionRate,
    conflictCountChange: simulatedConflicts.length - originalConflicts.length,
    atRiskCountChange: simulatedAnalytics.atRiskCount - originalAnalytics.atRiskCount,
    criticalPathChange: simulatedAnalytics.criticalPathLength - originalAnalytics.criticalPathLength,
    momentumChange: `${originalAnalytics.overallMomentum} -> ${simulatedAnalytics.overallMomentum}`,
  };
  
  // Generate recommendations
  const recommendations: string[] = [];
  
  if (impact.conflictCountChange < 0) {
    recommendations.push('✅ Conflicts reduced - this change improves timeline health');
  } else if (impact.conflictCountChange > 0) {
    recommendations.push('⚠️ New conflicts introduced - review affected entities');
  }
  
  if (impact.atRiskCountChange < 0) {
    recommendations.push('✅ Fewer entities at risk - timeline resilience improved');
  } else if (impact.atRiskCountChange > 0) {
    recommendations.push('⚠️ More entities at risk - consider additional adjustments');
  }
  
  if (cascadingEffects.length > 0) {
    recommendations.push(`⚡ ${cascadingEffects.length} entities affected by cascading changes`);
  }
  
  if (cascadingEffects.length > 5) {
    recommendations.push('⚠️ High number of cascading effects - verify all dependencies');
  }
  
  // Determine risk level
  let riskLevel: ImportanceLevel = 'low';
  if (impact.conflictCountChange > 2 || impact.atRiskCountChange > 3) {
    riskLevel = 'high';
  } else if (impact.conflictCountChange > 0 || impact.atRiskCountChange > 0) {
    riskLevel = 'medium';
  }
  
  return {
    scenarioId: `scenario-${Date.now()}`,
    timelineId,
    originalState: {
      entities: originalEntities,
      analytics: originalAnalytics,
      conflicts: originalConflicts,
    },
    simulatedState: {
      entities: simulatedEntities,
      analytics: simulatedAnalytics,
      conflicts: simulatedConflicts,
    },
    impact,
    cascadingEffects,
    recommendations,
    riskLevel,
  };
}

/**
 * Monte Carlo simulation for risk assessment
 */
export function runMonteCarloSimulation(
  timelineId: string,
  iterations: number = 100
): {
  completionProbability: number;
  averageCompletionDate: string;
  bestCase: string;
  worstCase: string;
  confidence: number;
  riskDistribution: { date: string; probability: number }[];
} {
  const { entities } = getTimelineDetail(timelineId);
  
  const results: Date[] = [];
  
  // Run simulations
  for (let i = 0; i < iterations; i++) {
    let latestDate = new Date();
    
    entities.forEach(entity => {
      if (entity.endAt) {
        const baseDate = new Date(entity.endAt);
        
        // Add random variance based on risk factors
        const variance = Math.random() * 10 - 5; // -5 to +5 days
        const adjustedDate = new Date(baseDate.getTime() + variance * 24 * 60 * 60 * 1000);
        
        if (adjustedDate > latestDate) {
          latestDate = adjustedDate;
        }
      }
    });
    
    results.push(latestDate);
  }
  
  results.sort((a, b) => a.getTime() - b.getTime());
  
  const avgTimestamp = results.reduce((sum, d) => sum + d.getTime(), 0) / results.length;
  const avgDate = new Date(avgTimestamp);
  
  const bestCase = results[Math.floor(results.length * 0.1)]; // 10th percentile
  const worstCase = results[Math.floor(results.length * 0.9)]; // 90th percentile
  
  // Calculate probability of on-time completion
  const now = Date.now();
  const onTimeCount = results.filter(d => d.getTime() <= now + 30 * 24 * 60 * 60 * 1000).length;
  const completionProbability = (onTimeCount / results.length) * 100;
  
  // Create risk distribution
  const riskDistribution: { date: string; probability: number }[] = [];
  const bucketSize = 7; // weekly buckets
  const minTime = results[0].getTime();
  const maxTime = results[results.length - 1].getTime();
  const range = maxTime - minTime;
  const bucketCount = Math.ceil(range / (bucketSize * 24 * 60 * 60 * 1000));
  
  for (let i = 0; i < bucketCount; i++) {
    const bucketStart = minTime + i * bucketSize * 24 * 60 * 60 * 1000;
    const bucketEnd = bucketStart + bucketSize * 24 * 60 * 60 * 1000;
    
    const count = results.filter(d => {
      const t = d.getTime();
      return t >= bucketStart && t < bucketEnd;
    }).length;
    
    riskDistribution.push({
      date: new Date(bucketStart).toISOString().split('T')[0],
      probability: (count / results.length) * 100,
    });
  }
  
  return {
    completionProbability,
    averageCompletionDate: avgDate.toISOString(),
    bestCase: bestCase.toISOString(),
    worstCase: worstCase.toISOString(),
    confidence: 75, // Based on sample size
    riskDistribution,
  };
}

// ============================================================================
// TEMPORAL FLOWS - Visual automation system
// ============================================================================

export interface TemporalFlow {
  id: string;
  name: string;
  description: string;
  trigger: FlowTrigger;
  conditions: FlowCondition[];
  actions: FlowAction[];
  isActive: boolean;
  executionCount: number;
  lastExecuted?: string;
  createdAt: string;
  updatedAt: string;
}

export type FlowTrigger =
  | { type: 'entity-completed'; entityId: string }
  | { type: 'entity-started'; entityId: string }
  | { type: 'date-reached'; date: string }
  | { type: 'milestone-achieved'; milestoneId: string }
  | { type: 'manual' };

export type FlowCondition =
  | { type: 'if-status'; entityId: string; status: string }
  | { type: 'if-progress-above'; entityId: string; threshold: number }
  | { type: 'if-date-before'; date: string }
  | { type: 'if-date-after'; date: string };

export type FlowAction =
  | { type: 'create-entity'; entityData: Partial<TemporalEntity> }
  | { type: 'update-entity'; entityId: string; updates: Partial<TemporalEntity> }
  | { type: 'create-action'; actionData: Partial<TemporalEntity> }
  | { type: 'send-notification'; message: string }
  | { type: 'activate-rule'; ruleId: string }
  | { type: 'create-snapshot'; timelineId: string; name: string };

/**
 * Evaluate if flow should execute
 */
export function evaluateFlow(flow: TemporalFlow, context: { entityId?: string }): boolean {
  if (!flow.isActive) return false;
  
  // Check trigger (simplified - would need event system in production)
  // For now, we'll just check conditions
  
  // Evaluate conditions
  for (const condition of flow.conditions) {
    switch (condition.type) {
      case 'if-status': {
        const entity = getTemporalEntity(condition.entityId);
        if (!entity || entity.status !== condition.status) {
          return false;
        }
        break;
      }
      
      case 'if-progress-above': {
        const entity = getTemporalEntity(condition.entityId);
        if (!entity || entity.progress <= condition.threshold) {
          return false;
        }
        break;
      }
      
      case 'if-date-before': {
        if (new Date() >= new Date(condition.date)) {
          return false;
        }
        break;
      }
      
      case 'if-date-after': {
        if (new Date() < new Date(condition.date)) {
          return false;
        }
        break;
      }
    }
  }
  
  return true;
}

/**
 * Execute flow actions
 */
export function executeFlow(flow: TemporalFlow): {
  success: boolean;
  executedActions: number;
  errors: string[];
} {
  const errors: string[] = [];
  let executedActions = 0;
  
  for (const action of flow.actions) {
    try {
      switch (action.type) {
        case 'create-entity':
          // Would call createTemporalEntity in production
          executedActions++;
          break;
        
        case 'update-entity':
          // Would call updateTemporalEntity in production
          executedActions++;
          break;
        
        case 'create-action':
          // Would call createScheduledAction in production
          executedActions++;
          break;
        
        case 'send-notification':
          // Would send actual notification in production
          console.log('Notification:', action.message);
          executedActions++;
          break;
        
        case 'activate-rule':
          // Would activate rule in production
          executedActions++;
          break;
        
        case 'create-snapshot':
          // Would create snapshot in production
          executedActions++;
          break;
      }
    } catch (error) {
      errors.push(`Failed to execute ${action.type}: ${error}`);
    }
  }
  
  return {
    success: errors.length === 0,
    executedActions,
    errors,
  };
}
