import type {
  TemporalEntity,
  Timeline,
  TemporalRule,
  ScheduledAction,
  TemporalDependency,
  TemporalTemplate,
  TemporalSnapshot,
  TemporalPlaybook,
  TemporalConflict,
  TemporalMomentum,
  CreateTemporalEntityInput,
  CreateTimelineInput,
  CreateTemporalRuleInput,
  CreateScheduledActionInput,
  CreateDependencyInput,
  CreateTemplateInput,
  CreatePlaybookInput,
  TemporalEntityFilter,
  TimelineFilter,
  GeoTarget,
  TimelineAnalytics,
  EntityStatus,
  MomentumLevel
} from '@/types/temporal';

const STORAGE_KEYS = {
  ENTITIES: 'dreamnet_temporal_entities',
  TIMELINES: 'dreamnet_temporal_timelines',
  RULES: 'dreamnet_temporal_rules',
  ACTIONS: 'dreamnet_temporal_actions',
  DEPENDENCIES: 'dreamnet_temporal_dependencies',
  TEMPLATES: 'dreamnet_temporal_templates',
  SNAPSHOTS: 'dreamnet_temporal_snapshots',
  PLAYBOOKS: 'dreamnet_temporal_playbooks',
  CONFLICTS: 'dreamnet_temporal_conflicts',
  MOMENTUM: 'dreamnet_temporal_momentum',
} as const;

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

function generateSEO(name: string, description: string): {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
} {
  const words = name.toLowerCase().split(' ');
  const keywords = [...words, ...description.toLowerCase().split(' ').slice(0, 5)];
  const hashtags = words.map((w: string) => `#${w.replace(/[^a-z0-9]/g, '')}`);
  
  return {
    seoTitle: name,
    seoDescription: description.slice(0, 160),
    seoKeywords: [...new Set(keywords)].slice(0, 10),
    seoHashtags: hashtags.slice(0, 5),
    altText: `${name} - ${description.slice(0, 100)}`,
  };
}

// Storage helpers
function getFromStorage<T>(key: string): T[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

function saveToStorage<T>(key: string, data: T[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(key, JSON.stringify(data));
}

// Temporal Entity operations
export function createTemporalEntity(input: CreateTemporalEntityInput): TemporalEntity {
  const entities = getFromStorage<TemporalEntity>(STORAGE_KEYS.ENTITIES);
  const now = new Date().toISOString();
  
  const entity: TemporalEntity = {
    id: generateId(),
    type: input.type,
    name: input.name,
    description: input.description,
    startAt: input.startAt ?? null,
    endAt: input.endAt ?? null,
    importanceLevel: input.importanceLevel ?? 'medium',
    category: input.category ?? '',
    primaryEmoji: input.primaryEmoji ?? '⏰',
    tags: input.tags ?? [],
    notes: '',
    primaryGeoTargets: [],
    entityIntroLocalized: {},
    tagsLocalized: {},
    status: input.status ?? 'not-started',
    progress: 0,
    assignees: input.assignees ?? [],
    dependsOn: [],
    blockedBy: [],
    recurringPattern: input.recurringPattern ?? 'none',
    checklist: [],
    resources: {},
    contentSlots: input.contentSlots ?? [],
    createdAt: now,
    updatedAt: now,
    ...generateSEO(input.name, input.description),
  };
  
  entities.push(entity);
  saveToStorage(STORAGE_KEYS.ENTITIES, entities);
  
  return entity;
}

export function updateTemporalEntity(id: string, updates: Partial<TemporalEntity>): TemporalEntity | null {
  const entities = getFromStorage<TemporalEntity>(STORAGE_KEYS.ENTITIES);
  const index = entities.findIndex((e: TemporalEntity) => e.id === id);
  
  if (index === -1) return null;
  
  entities[index] = { 
    ...entities[index], 
    ...updates,
    updatedAt: new Date().toISOString()
  };
  saveToStorage(STORAGE_KEYS.ENTITIES, entities);
  
  return entities[index];
}

export function deleteTemporalEntity(id: string): boolean {
  const entities = getFromStorage<TemporalEntity>(STORAGE_KEYS.ENTITIES);
  const filtered = entities.filter((e: TemporalEntity) => e.id !== id);
  
  if (filtered.length === entities.length) return false;
  
  saveToStorage(STORAGE_KEYS.ENTITIES, filtered);
  
  // Clean up dependencies
  const deps = getFromStorage<TemporalDependency>(STORAGE_KEYS.DEPENDENCIES);
  const filteredDeps = deps.filter((d: TemporalDependency) => 
    d.sourceEntityId !== id && d.targetEntityId !== id
  );
  saveToStorage(STORAGE_KEYS.DEPENDENCIES, filteredDeps);
  
  return true;
}

export function getTemporalEntity(id: string): TemporalEntity | null {
  const entities = getFromStorage<TemporalEntity>(STORAGE_KEYS.ENTITIES);
  return entities.find((e: TemporalEntity) => e.id === id) ?? null;
}

export function listTemporalEntities(filter?: TemporalEntityFilter): TemporalEntity[] {
  let entities = getFromStorage<TemporalEntity>(STORAGE_KEYS.ENTITIES);
  
  if (!filter) return entities;
  
  if (filter.type) {
    entities = entities.filter((e: TemporalEntity) => e.type === filter.type);
  }
  
  if (filter.importanceLevel) {
    entities = entities.filter((e: TemporalEntity) => e.importanceLevel === filter.importanceLevel);
  }
  
  if (filter.category) {
    entities = entities.filter((e: TemporalEntity) => e.category === filter.category);
  }
  
  if (filter.status) {
    entities = entities.filter((e: TemporalEntity) => e.status === filter.status);
  }
  
  if (filter.assigneeId) {
    entities = entities.filter((e: TemporalEntity) => 
      e.assignees.some(a => a.id === filter.assigneeId)
    );
  }
  
  if (filter.tag) {
    entities = entities.filter((e: TemporalEntity) => 
      e.tags.some((t: string) => t.toLowerCase().includes(filter.tag!.toLowerCase()))
    );
  }
  
  return entities;
}

export function assignGeoTargetsToTemporalEntity(entityId: string, geoTargets: GeoTarget[]): TemporalEntity | null {
  return updateTemporalEntity(entityId, { primaryGeoTargets: geoTargets });
}

export function generateGeoVariantsForTemporalEntity(entityId: string): TemporalEntity | null {
  const entity = getTemporalEntity(entityId);
  if (!entity) return null;
  
  const entityIntroLocalized: Record<string, string> = {};
  const tagsLocalized: Record<string, string[]> = {};
  
  entity.primaryGeoTargets.forEach((geo: GeoTarget) => {
    entityIntroLocalized[geo.id] = `[${geo.language.toUpperCase()}] ${entity.description}`;
    tagsLocalized[geo.id] = entity.tags.map((tag: string) => `${tag}_${geo.language}`);
  });
  
  return updateTemporalEntity(entityId, { entityIntroLocalized, tagsLocalized });
}

export function regenerateEntitySEO(entityId: string): TemporalEntity | null {
  const entity = getTemporalEntity(entityId);
  if (!entity) return null;
  
  const seo = generateSEO(entity.name, entity.description);
  return updateTemporalEntity(entityId, seo);
}

// Timeline operations
export function createTimeline(input: CreateTimelineInput): Timeline {
  const timelines = getFromStorage<Timeline>(STORAGE_KEYS.TIMELINES);
  const now = new Date().toISOString();
  
  const timeline: Timeline = {
    id: generateId(),
    name: input.name,
    description: input.description,
    category: input.category,
    importanceLevel: input.importanceLevel,
    temporalEntityIds: [],
    status: 'draft',
    tags: [],
    defaultViewMode: input.defaultViewMode ?? 'timeline',
    snapshotIds: [],
    linkedTimelineIds: [],
    totalBudget: input.totalBudget,
    budgetCurrency: input.budgetCurrency,
    createdAt: now,
    updatedAt: now,
    ...generateSEO(input.name, input.description),
  };
  
  timelines.push(timeline);
  saveToStorage(STORAGE_KEYS.TIMELINES, timelines);
  
  return timeline;
}

export function updateTimeline(id: string, updates: Partial<Timeline>): Timeline | null {
  const timelines = getFromStorage<Timeline>(STORAGE_KEYS.TIMELINES);
  const index = timelines.findIndex((t: Timeline) => t.id === id);
  
  if (index === -1) return null;
  
  timelines[index] = { 
    ...timelines[index], 
    ...updates,
    updatedAt: new Date().toISOString()
  };
  saveToStorage(STORAGE_KEYS.TIMELINES, timelines);
  
  return timelines[index];
}

export function deleteTimeline(id: string): boolean {
  const timelines = getFromStorage<Timeline>(STORAGE_KEYS.TIMELINES);
  const filtered = timelines.filter((t: Timeline) => t.id !== id);
  
  if (filtered.length === timelines.length) return false;
  
  saveToStorage(STORAGE_KEYS.TIMELINES, filtered);
  return true;
}

export function getTimeline(id: string): Timeline | null {
  const timelines = getFromStorage<Timeline>(STORAGE_KEYS.TIMELINES);
  return timelines.find((t: Timeline) => t.id === id) ?? null;
}

export function listTimelines(filter?: TimelineFilter): Timeline[] {
  let timelines = getFromStorage<Timeline>(STORAGE_KEYS.TIMELINES);
  
  if (!filter) return timelines;
  
  if (filter.category) {
    timelines = timelines.filter((t: Timeline) => t.category === filter.category);
  }
  
  if (filter.importanceLevel) {
    timelines = timelines.filter((t: Timeline) => t.importanceLevel === filter.importanceLevel);
  }
  
  if (filter.status) {
    timelines = timelines.filter((t: Timeline) => t.status === filter.status);
  }
  
  if (filter.viewMode) {
    timelines = timelines.filter((t: Timeline) => t.defaultViewMode === filter.viewMode);
  }
  
  return timelines;
}

export function attachTemporalEntity(timelineId: string, entityId: string): Timeline | null {
  const timeline = getTimeline(timelineId);
  if (!timeline) return null;
  
  if (!timeline.temporalEntityIds.includes(entityId)) {
    timeline.temporalEntityIds.push(entityId);
    return updateTimeline(timelineId, { temporalEntityIds: timeline.temporalEntityIds });
  }
  
  return timeline;
}

export function detachTemporalEntity(timelineId: string, entityId: string): Timeline | null {
  const timeline = getTimeline(timelineId);
  if (!timeline) return null;
  
  const filtered = timeline.temporalEntityIds.filter((id: string) => id !== entityId);
  return updateTimeline(timelineId, { temporalEntityIds: filtered });
}

export function reorderTemporalEntities(timelineId: string, orderedEntityIds: string[]): Timeline | null {
  return updateTimeline(timelineId, { temporalEntityIds: orderedEntityIds });
}

export function regenerateTimelineSEO(timelineId: string): Timeline | null {
  const timeline = getTimeline(timelineId);
  if (!timeline) return null;
  
  const seo = generateSEO(timeline.name, timeline.description);
  return updateTimeline(timelineId, seo);
}

// Temporal Rule operations
export function createTemporalRule(input: CreateTemporalRuleInput): TemporalRule {
  const rules = getFromStorage<TemporalRule>(STORAGE_KEYS.RULES);
  const now = new Date().toISOString();
  
  const rule: TemporalRule = {
    id: generateId(),
    name: input.name,
    description: input.description,
    appliesToEntityIds: input.appliesToEntityIds,
    ruleType: input.ruleType,
    effectSummary: input.effectSummary,
    detailedBehavior: input.detailedBehavior,
    recommendedApps: input.recommendedApps,
    notes: '',
    isActive: true,
    activatesAt: input.activatesAt,
    deactivatesAt: input.deactivatesAt,
    createdAt: now,
    updatedAt: now,
  };
  
  rules.push(rule);
  saveToStorage(STORAGE_KEYS.RULES, rules);
  
  return rule;
}

export function updateTemporalRule(id: string, updates: Partial<TemporalRule>): TemporalRule | null {
  const rules = getFromStorage<TemporalRule>(STORAGE_KEYS.RULES);
  const index = rules.findIndex((r: TemporalRule) => r.id === id);
  
  if (index === -1) return null;
  
  rules[index] = { 
    ...rules[index], 
    ...updates,
    updatedAt: new Date().toISOString()
  };
  saveToStorage(STORAGE_KEYS.RULES, rules);
  
  return rules[index];
}

export function deleteTemporalRule(id: string): boolean {
  const rules = getFromStorage<TemporalRule>(STORAGE_KEYS.RULES);
  const filtered = rules.filter((r: TemporalRule) => r.id !== id);
  
  if (filtered.length === rules.length) return false;
  
  saveToStorage(STORAGE_KEYS.RULES, filtered);
  return true;
}

export function getTemporalRule(id: string): TemporalRule | null {
  const rules = getFromStorage<TemporalRule>(STORAGE_KEYS.RULES);
  return rules.find((r: TemporalRule) => r.id === id) ?? null;
}

export function listTemporalRules(): TemporalRule[] {
  return getFromStorage<TemporalRule>(STORAGE_KEYS.RULES);
}

export function getRulesForEntity(entityId: string): TemporalRule[] {
  const rules = getFromStorage<TemporalRule>(STORAGE_KEYS.RULES);
  return rules.filter((r: TemporalRule) => r.appliesToEntityIds.includes(entityId));
}

export function getRulesForTimeline(timelineId: string): TemporalRule[] {
  const timeline = getTimeline(timelineId);
  if (!timeline) return [];
  
  const rules = getFromStorage<TemporalRule>(STORAGE_KEYS.RULES);
  return rules.filter((r: TemporalRule) => 
    r.appliesToEntityIds.some((id: string) => timeline.temporalEntityIds.includes(id))
  );
}

// Scheduled Action operations
export function createScheduledAction(input: CreateScheduledActionInput): ScheduledAction {
  const actions = getFromStorage<ScheduledAction>(STORAGE_KEYS.ACTIONS);
  const now = new Date().toISOString();
  
  const action: ScheduledAction = {
    id: generateId(),
    temporalEntityId: input.temporalEntityId,
    name: input.name,
    description: input.description,
    scheduledAt: input.scheduledAt,
    optionalDeadline: input.optionalDeadline ?? null,
    recommendedActionTypeCodes: input.recommendedActionTypeCodes ?? [],
    recommendedAccounts: input.recommendedAccounts ?? [],
    notes: '',
    status: input.status ?? 'not-started',
    assignees: input.assignees ?? [],
    prerequisiteActionIds: [],
    channels: input.channels ?? [],
    createdAt: now,
    updatedAt: now,
  };
  
  actions.push(action);
  saveToStorage(STORAGE_KEYS.ACTIONS, actions);
  
  return action;
}

export function updateScheduledAction(id: string, updates: Partial<ScheduledAction>): ScheduledAction | null {
  const actions = getFromStorage<ScheduledAction>(STORAGE_KEYS.ACTIONS);
  const index = actions.findIndex((a: ScheduledAction) => a.id === id);
  
  if (index === -1) return null;
  
  actions[index] = { 
    ...actions[index], 
    ...updates,
    updatedAt: new Date().toISOString()
  };
  saveToStorage(STORAGE_KEYS.ACTIONS, actions);
  
  return actions[index];
}

export function deleteScheduledAction(id: string): boolean {
  const actions = getFromStorage<ScheduledAction>(STORAGE_KEYS.ACTIONS);
  const filtered = actions.filter((a: ScheduledAction) => a.id !== id);
  
  if (filtered.length === actions.length) return false;
  
  saveToStorage(STORAGE_KEYS.ACTIONS, filtered);
  return true;
}

export function getScheduledAction(id: string): ScheduledAction | null {
  const actions = getFromStorage<ScheduledAction>(STORAGE_KEYS.ACTIONS);
  return actions.find((a: ScheduledAction) => a.id === id) ?? null;
}

export function listScheduledActions(): ScheduledAction[] {
  return getFromStorage<ScheduledAction>(STORAGE_KEYS.ACTIONS);
}

export function getActionsForEntity(entityId: string): ScheduledAction[] {
  const actions = getFromStorage<ScheduledAction>(STORAGE_KEYS.ACTIONS);
  return actions.filter((a: ScheduledAction) => a.temporalEntityId === entityId);
}

export function getActionsForTimeline(timelineId: string): ScheduledAction[] {
  const timeline = getTimeline(timelineId);
  if (!timeline) return [];
  
  const actions = getFromStorage<ScheduledAction>(STORAGE_KEYS.ACTIONS);
  return actions.filter((a: ScheduledAction) => timeline.temporalEntityIds.includes(a.temporalEntityId));
}

// NEW: Dependency operations
export function createDependency(input: CreateDependencyInput): TemporalDependency {
  const dependencies = getFromStorage<TemporalDependency>(STORAGE_KEYS.DEPENDENCIES);
  
  const dependency: TemporalDependency = {
    id: generateId(),
    sourceEntityId: input.sourceEntityId,
    targetEntityId: input.targetEntityId,
    dependencyType: input.dependencyType,
    lagDays: input.lagDays ?? 0,
    notes: '',
  };
  
  dependencies.push(dependency);
  saveToStorage(STORAGE_KEYS.DEPENDENCIES, dependencies);
  
  // Update target entity's dependsOn
  const target = getTemporalEntity(input.targetEntityId);
  if (target && !target.dependsOn.includes(input.sourceEntityId)) {
    updateTemporalEntity(input.targetEntityId, {
      dependsOn: [...target.dependsOn, input.sourceEntityId]
    });
  }
  
  return dependency;
}

export function deleteDependency(id: string): boolean {
  const dependencies = getFromStorage<TemporalDependency>(STORAGE_KEYS.DEPENDENCIES);
  const dep = dependencies.find((d: TemporalDependency) => d.id === id);
  
  if (!dep) return false;
  
  const filtered = dependencies.filter((d: TemporalDependency) => d.id !== id);
  saveToStorage(STORAGE_KEYS.DEPENDENCIES, filtered);
  
  // Update target entity
  const target = getTemporalEntity(dep.targetEntityId);
  if (target) {
    updateTemporalEntity(dep.targetEntityId, {
      dependsOn: target.dependsOn.filter(id => id !== dep.sourceEntityId)
    });
  }
  
  return true;
}

export function getDependenciesForEntity(entityId: string): TemporalDependency[] {
  const dependencies = getFromStorage<TemporalDependency>(STORAGE_KEYS.DEPENDENCIES);
  return dependencies.filter((d: TemporalDependency) => 
    d.sourceEntityId === entityId || d.targetEntityId === entityId
  );
}

export function detectDependencyCycles(entityId: string): string[] {
  const visited = new Set<string>();
  const recStack = new Set<string>();
  const cycle: string[] = [];
  
  function dfs(id: string): boolean {
    visited.add(id);
    recStack.add(id);
    cycle.push(id);
    
    const entity = getTemporalEntity(id);
    if (!entity) return false;
    
    for (const depId of entity.dependsOn) {
      if (!visited.has(depId)) {
        if (dfs(depId)) return true;
      } else if (recStack.has(depId)) {
        return true;
      }
    }
    
    recStack.delete(id);
    cycle.pop();
    return false;
  }
  
  if (dfs(entityId)) {
    return cycle;
  }
  
  return [];
}

// NEW: Template operations
export function createTemplate(input: CreateTemplateInput): TemporalTemplate {
  const templates = getFromStorage<TemporalTemplate>(STORAGE_KEYS.TEMPLATES);
  const now = new Date().toISOString();
  
  const template: TemporalTemplate = {
    id: generateId(),
    name: input.name,
    description: input.description,
    category: input.category,
    templateType: input.templateType,
    entityTemplates: [],
    ruleTemplates: [],
    usageCount: 0,
    createdAt: now,
    updatedAt: now,
  };
  
  templates.push(template);
  saveToStorage(STORAGE_KEYS.TEMPLATES, templates);
  
  return template;
}

export function updateTemplate(id: string, updates: Partial<TemporalTemplate>): TemporalTemplate | null {
  const templates = getFromStorage<TemporalTemplate>(STORAGE_KEYS.TEMPLATES);
  const index = templates.findIndex((t: TemporalTemplate) => t.id === id);
  
  if (index === -1) return null;
  
  templates[index] = { 
    ...templates[index], 
    ...updates,
    updatedAt: new Date().toISOString()
  };
  saveToStorage(STORAGE_KEYS.TEMPLATES, templates);
  
  return templates[index];
}

export function listTemplates(): TemporalTemplate[] {
  return getFromStorage<TemporalTemplate>(STORAGE_KEYS.TEMPLATES);
}

export function applyTemplate(templateId: string, timelineId: string, startDate: string): boolean {
  const template = listTemplates().find(t => t.id === templateId);
  const timeline = getTimeline(timelineId);
  
  if (!template || !timeline) return false;
  
  const startTime = new Date(startDate).getTime();
  
  // Create entities from template
  const createdEntities: string[] = [];
  
  template.entityTemplates.forEach(et => {
    const entity = createTemporalEntity({
      type: et.type,
      name: et.name,
      description: et.description,
      startAt: new Date(startTime + et.relativeStartDays * 24 * 60 * 60 * 1000).toISOString(),
      endAt: new Date(startTime + (et.relativeStartDays + et.relativeDurationDays) * 24 * 60 * 60 * 1000).toISOString(),
      importanceLevel: et.importanceLevel,
      category: et.category,
      tags: et.tags,
    });
    
    // Add checklist
    if (et.checklist.length > 0) {
      updateTemporalEntity(entity.id, {
        checklist: et.checklist.map(c => ({
          id: generateId(),
          text: c.text,
          completed: false,
        }))
      });
    }
    
    createdEntities.push(entity.id);
    attachTemporalEntity(timelineId, entity.id);
  });
  
  // Create rules from template
  template.ruleTemplates.forEach(rt => {
    createTemporalRule({
      name: rt.name,
      description: rt.description,
      appliesToEntityIds: createdEntities,
      ruleType: rt.ruleType,
      effectSummary: rt.effectSummary,
      detailedBehavior: rt.description,
      recommendedApps: rt.recommendedApps,
    });
  });
  
  // Increment usage count
  updateTemplate(templateId, { 
    usageCount: template.usageCount + 1 
  });
  
  return true;
}

// NEW: Snapshot operations
export function createSnapshot(timelineId: string, name: string, description: string): TemporalSnapshot {
  const snapshots = getFromStorage<TemporalSnapshot>(STORAGE_KEYS.SNAPSHOTS);
  const timeline = getTimeline(timelineId);
  
  if (!timeline) throw new Error('Timeline not found');
  
  const { entities, rules, actions } = getTimelineDetail(timelineId);
  
  const snapshot: TemporalSnapshot = {
    id: generateId(),
    timelineId,
    name,
    description,
    snapshotData: {
      timeline,
      entities,
      rules,
      actions,
    },
    createdAt: new Date().toISOString(),
    createdBy: 'user', // In real app, would be actual user
  };
  
  snapshots.push(snapshot);
  saveToStorage(STORAGE_KEYS.SNAPSHOTS, snapshots);
  
  // Update timeline's snapshot list
  updateTimeline(timelineId, {
    snapshotIds: [...timeline.snapshotIds, snapshot.id],
    currentSnapshotId: snapshot.id,
  });
  
  return snapshot;
}

export function listSnapshots(timelineId: string): TemporalSnapshot[] {
  const snapshots = getFromStorage<TemporalSnapshot>(STORAGE_KEYS.SNAPSHOTS);
  return snapshots.filter((s: TemporalSnapshot) => s.timelineId === timelineId);
}

export function restoreSnapshot(snapshotId: string): boolean {
  const snapshot = getFromStorage<TemporalSnapshot>(STORAGE_KEYS.SNAPSHOTS)
    .find((s: TemporalSnapshot) => s.id === snapshotId);
  
  if (!snapshot) return false;
  
  // This is a simplified restore - in production you'd want more sophisticated merging
  // For now, we'll just update the current state
  
  updateTimeline(snapshot.timelineId, {
    currentSnapshotId: snapshotId,
  });
  
  return true;
}

// NEW: Playbook operations
export function createPlaybook(input: CreatePlaybookInput): TemporalPlaybook {
  const playbooks = getFromStorage<TemporalPlaybook>(STORAGE_KEYS.PLAYBOOKS);
  const now = new Date().toISOString();
  
  const playbook: TemporalPlaybook = {
    id: generateId(),
    name: input.name,
    description: input.description,
    playbookType: input.playbookType,
    steps: [],
    appliesToEntityTypes: input.appliesToEntityTypes ?? [],
    appliesToCategories: input.appliesToCategories ?? [],
    usageCount: 0,
    createdAt: now,
    updatedAt: now,
  };
  
  playbooks.push(playbook);
  saveToStorage(STORAGE_KEYS.PLAYBOOKS, playbooks);
  
  return playbook;
}

export function updatePlaybook(id: string, updates: Partial<TemporalPlaybook>): TemporalPlaybook | null {
  const playbooks = getFromStorage<TemporalPlaybook>(STORAGE_KEYS.PLAYBOOKS);
  const index = playbooks.findIndex((p: TemporalPlaybook) => p.id === id);
  
  if (index === -1) return null;
  
  playbooks[index] = { 
    ...playbooks[index], 
    ...updates,
    updatedAt: new Date().toISOString()
  };
  saveToStorage(STORAGE_KEYS.PLAYBOOKS, playbooks);
  
  return playbooks[index];
}

export function listPlaybooks(): TemporalPlaybook[] {
  return getFromStorage<TemporalPlaybook>(STORAGE_KEYS.PLAYBOOKS);
}

export function getPlaybooksForEntity(entityId: string): TemporalPlaybook[] {
  const entity = getTemporalEntity(entityId);
  if (!entity) return [];
  
  const playbooks = getFromStorage<TemporalPlaybook>(STORAGE_KEYS.PLAYBOOKS);
  return playbooks.filter((p: TemporalPlaybook) => 
    p.appliesToEntityTypes.includes(entity.type) || 
    p.appliesToCategories.includes(entity.category)
  );
}

// NEW: Conflict detection
export function detectConflicts(timelineId: string): TemporalConflict[] {
  const conflicts: TemporalConflict[] = [];
  const { timeline, entities } = getTimelineDetail(timelineId);
  
  if (!timeline) return conflicts;
  
  // Detect overlapping high-priority events
  const sortedEntities = [...entities].sort((a, b) => {
    if (!a.startAt || !b.startAt) return 0;
    return new Date(a.startAt).getTime() - new Date(b.startAt).getTime();
  });
  
  for (let i = 0; i < sortedEntities.length; i++) {
    const entityA = sortedEntities[i];
    if (!entityA.startAt || !entityA.endAt) continue;
    
    const aStart = new Date(entityA.startAt).getTime();
    const aEnd = new Date(entityA.endAt).getTime();
    
    for (let j = i + 1; j < sortedEntities.length; j++) {
      const entityB = sortedEntities[j];
      if (!entityB.startAt || !entityB.endAt) continue;
      
      const bStart = new Date(entityB.startAt).getTime();
      const bEnd = new Date(entityB.endAt).getTime();
      
      // Check for overlap
      if (aStart < bEnd && bStart < aEnd) {
        if (entityA.importanceLevel === 'critical' && entityB.importanceLevel === 'critical') {
          conflicts.push({
            id: generateId(),
            conflictType: 'overlap',
            severity: 'high',
            description: `Critical events overlap: ${entityA.name} and ${entityB.name}`,
            affectedEntityIds: [entityA.id, entityB.id],
            suggestedResolution: 'Consider rescheduling one event or adjusting priorities',
          });
        }
      }
    }
    
    // Check for overload (too many events in short period)
    const oneWeekLater = aStart + (7 * 24 * 60 * 60 * 1000);
    const eventsInWeek = sortedEntities.filter(e => {
      if (!e.startAt) return false;
      const start = new Date(e.startAt).getTime();
      return start >= aStart && start <= oneWeekLater;
    });
    
    if (eventsInWeek.length > 5) {
      conflicts.push({
        id: generateId(),
        conflictType: 'overload',
        severity: 'medium',
        description: `High activity period: ${eventsInWeek.length} events in one week starting ${new Date(aStart).toLocaleDateString()}`,
        affectedEntityIds: eventsInWeek.map(e => e.id),
        suggestedResolution: 'Consider spreading events across a longer timeframe',
      });
    }
  }
  
  // Detect dependency cycles
  entities.forEach(entity => {
    const cycle = detectDependencyCycles(entity.id);
    if (cycle.length > 0) {
      conflicts.push({
        id: generateId(),
        conflictType: 'dependency-cycle',
        severity: 'critical',
        description: `Dependency cycle detected involving: ${cycle.map(id => getTemporalEntity(id)?.name).join(' → ')}`,
        affectedEntityIds: cycle,
        suggestedResolution: 'Remove one or more dependencies to break the cycle',
      });
    }
  });
  
  return conflicts;
}

// NEW: Momentum tracking
export function calculateMomentum(timelineId: string): TemporalMomentum {
  const { timeline, entities } = getTimelineDetail(timelineId);
  
  if (!timeline) throw new Error('Timeline not found');
  
  const completedCount = entities.filter(e => e.status === 'completed').length;
  const inProgressCount = entities.filter(e => e.status === 'in-progress').length;
  const totalCount = entities.length;
  
  const velocityScore = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;
  const energyScore = totalCount > 0 ? ((completedCount + inProgressCount * 0.5) / totalCount) * 100 : 0;
  
  let momentumLevel: MomentumLevel = 'cold';
  if (energyScore > 75) momentumLevel = 'explosive';
  else if (energyScore > 50) momentumLevel = 'hot';
  else if (energyScore > 25) momentumLevel = 'warming';
  
  let trend: "rising" | "stable" | "falling" = 'stable';
  let recommendation = 'Maintain current pace';
  
  if (momentumLevel === 'explosive') {
    recommendation = 'High momentum! Consider capitalizing with additional initiatives';
  } else if (momentumLevel === 'cold') {
    recommendation = 'Low momentum. Focus on quick wins to build energy';
    trend = 'falling';
  }
  
  const momentum: TemporalMomentum = {
    timelineId,
    momentumLevel,
    velocityScore,
    energyScore,
    weeklyVelocity: [velocityScore], // In real app, track historical
    weeklyEnergy: [energyScore],
    trend,
    recommendation,
    calculatedAt: new Date().toISOString(),
  };
  
  return momentum;
}

// Timeline detail
export function getTimelineDetail(timelineId: string): {
  timeline: Timeline | null;
  entities: TemporalEntity[];
  rules: TemporalRule[];
  actions: ScheduledAction[];
} {
  const timeline = getTimeline(timelineId);
  
  if (!timeline) {
    return { timeline: null, entities: [], rules: [], actions: [] };
  }
  
  const entities = timeline.temporalEntityIds
    .map((id: string) => getTemporalEntity(id))
    .filter((e: TemporalEntity | null): e is TemporalEntity => e !== null);
  
  const rules = getRulesForTimeline(timelineId);
  const actions = getActionsForTimeline(timelineId);
  
  return { timeline, entities, rules, actions };
}

// NEW: Analytics
export function calculateTimelineAnalytics(timelineId: string): TimelineAnalytics {
  const { timeline, entities } = getTimelineDetail(timelineId);
  
  if (!timeline) throw new Error('Timeline not found');
  
  const totalEntities = entities.length;
  const completedEntities = entities.filter(e => e.status === 'completed').length;
  const inProgressEntities = entities.filter(e => e.status === 'in-progress').length;
  const blockedEntities = entities.filter(e => e.status === 'blocked').length;
  
  const completionRate = totalEntities > 0 ? (completedEntities / totalEntities) * 100 : 0;
  
  const now = Date.now();
  const onTrackCount = entities.filter(e => {
    if (!e.endAt) return true;
    const endTime = new Date(e.endAt).getTime();
    if (e.status === 'completed') return true;
    return endTime > now;
  }).length;
  
  const atRiskCount = totalEntities - onTrackCount;
  
  const momentum = calculateMomentum(timelineId);
  
  // Calculate critical path (simplified)
  const entitiesWithDeps = entities.filter(e => e.dependsOn.length > 0);
  const criticalPathLength = entitiesWithDeps.length;
  
  // Calculate budget utilization
  let budgetUtilization: number | undefined;
  if (timeline.totalBudget) {
    const totalAllocated = entities.reduce((sum, e) => 
      sum + (e.resources.budget ?? 0), 0
    );
    budgetUtilization = (totalAllocated / timeline.totalBudget) * 100;
  }
  
  return {
    timelineId,
    totalEntities,
    completedEntities,
    inProgressEntities,
    blockedEntities,
    completionRate,
    onTrackCount,
    atRiskCount,
    overallMomentum: momentum.momentumLevel,
    criticalPathLength,
    budgetUtilization,
  };
}

// Summary generation
export function generateTimelineSummary(timelineId: string): string {
  const { timeline, entities, rules, actions } = getTimelineDetail(timelineId);
  
  if (!timeline) return 'Timeline not found';
  
  let summary = `Timeline: ${timeline.name}\n`;
  summary += `Category: ${timeline.category} | Importance: ${timeline.importanceLevel}\n`;
  summary += `Status: ${timeline.status}\n\n`;
  summary += `${timeline.description}\n\n`;
  summary += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
  
  summary += `TEMPORAL ENTITIES (${entities.length}):\n\n`;
  
  entities.forEach((entity: TemporalEntity, idx: number) => {
    summary += `${idx + 1}. ${entity.primaryEmoji} ${entity.name}\n`;
    summary += `   Type: ${entity.type} | Importance: ${entity.importanceLevel} | Status: ${entity.status}\n`;
    
    if (entity.startAt || entity.endAt) {
      summary += `   Timeline: `;
      if (entity.startAt) summary += `${new Date(entity.startAt).toLocaleDateString()}`;
      if (entity.startAt && entity.endAt) summary += ` → `;
      if (entity.endAt) summary += `${new Date(entity.endAt).toLocaleDateString()}`;
      summary += `\n`;
    }
    
    summary += `   ${entity.description}\n`;
    
    if (entity.assignees.length > 0) {
      summary += `   Assignees: ${entity.assignees.map(a => a.name).join(', ')}\n`;
    }
    
    if (entity.dependsOn.length > 0) {
      const depNames = entity.dependsOn.map(id => getTemporalEntity(id)?.name ?? 'Unknown');
      summary += `   Depends on: ${depNames.join(', ')}\n`;
    }
    
    const entityRules = rules.filter((r: TemporalRule) => r.appliesToEntityIds.includes(entity.id));
    if (entityRules.length > 0) {
      summary += `   Rules: ${entityRules.map((r: TemporalRule) => r.name).join(', ')}\n`;
    }
    
    const entityActions = actions.filter((a: ScheduledAction) => a.temporalEntityId === entity.id);
    if (entityActions.length > 0) {
      summary += `   Scheduled Actions: ${entityActions.length}\n`;
    }
    
    summary += `\n`;
  });
  
  if (rules.length > 0) {
    summary += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    summary += `TEMPORAL RULES (${rules.length}):\n\n`;
    
    rules.forEach((rule: TemporalRule, idx: number) => {
      summary += `${idx + 1}. ${rule.name}\n`;
      summary += `   Type: ${rule.ruleType} | Active: ${rule.isActive ? 'Yes' : 'No'}\n`;
      summary += `   Effect: ${rule.effectSummary}\n`;
      summary += `   Apps: ${rule.recommendedApps.join(', ')}\n\n`;
    });
  }
  
  if (actions.length > 0) {
    summary += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    summary += `SCHEDULED ACTIONS (${actions.length}):\n\n`;
    
    const sortedActions = [...actions].sort((a: ScheduledAction, b: ScheduledAction) => 
      new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime()
    );
    
    sortedActions.forEach((action: ScheduledAction, idx: number) => {
      summary += `${idx + 1}. ${action.name}\n`;
      summary += `   Scheduled: ${new Date(action.scheduledAt).toLocaleString()} | Status: ${action.status}\n`;
      summary += `   ${action.description}\n\n`;
    });
  }
  
  return summary;
}

export function exportTemporalCalendar(timelineId: string): string {
  const { timeline, entities, actions } = getTimelineDetail(timelineId);
  
  if (!timeline) return 'Timeline not found';
  
  let calendar = `TEMPORAL CALENDAR: ${timeline.name}\n`;
  calendar += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
  
  const events: Array<{ date: Date; type: string; name: string; importance: string; status?: EntityStatus }> = [];
  
  entities.forEach((entity: TemporalEntity) => {
    if (entity.startAt) {
      events.push({
        date: new Date(entity.startAt),
        type: `${entity.type} START`,
        name: `${entity.primaryEmoji} ${entity.name}`,
        importance: entity.importanceLevel,
        status: entity.status,
      });
    }
    
    if (entity.endAt) {
      events.push({
        date: new Date(entity.endAt),
        type: `${entity.type} END`,
        name: `${entity.primaryEmoji} ${entity.name}`,
        importance: entity.importanceLevel,
        status: entity.status,
      });
    }
  });
  
  actions.forEach((action: ScheduledAction) => {
    events.push({
      date: new Date(action.scheduledAt),
      type: 'ACTION',
      name: action.name,
      importance: 'medium',
      status: action.status,
    });
  });
  
  events.sort((a, b) => a.date.getTime() - b.date.getTime());
  
  let currentMonth = '';
  
  events.forEach((event) => {
    const monthYear = event.date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    
    if (monthYear !== currentMonth) {
      calendar += `\n${monthYear.toUpperCase()}\n`;
      calendar += `${'─'.repeat(40)}\n`;
      currentMonth = monthYear;
    }
    
    const importanceMarker = event.importance === 'critical' ? '🔴' : event.importance === 'high' ? '🟠' : '⚪';
    const statusMarker = event.status === 'completed' ? '✅' : event.status === 'blocked' ? '🚫' : '';
    calendar += `${event.date.toLocaleDateString('en-US', { day: 'numeric', weekday: 'short' })} | ${importanceMarker} ${statusMarker} ${event.type}: ${event.name}\n`;
  });
  
  return calendar;
}

export function generateSeasonArc(timelineId: string): string {
  const { timeline, entities } = getTimelineDetail(timelineId);
  
  if (!timeline) return 'Timeline not found';
  
  let arc = `SEASON ARC: ${timeline.name}\n`;
  arc += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
  
  arc += `OVERVIEW\n`;
  arc += `${timeline.description}\n\n`;
  
  const seasons = entities.filter((e: TemporalEntity) => e.type === 'season');
  const epochs = entities.filter((e: TemporalEntity) => e.type === 'epoch');
  const milestones = entities.filter((e: TemporalEntity) => e.type === 'milestone');
  
  if (seasons.length > 0) {
    arc += `SEASONAL STRUCTURE\n`;
    seasons.forEach((season: TemporalEntity, idx: number) => {
      arc += `\nSeason ${idx + 1}: ${season.primaryEmoji} ${season.name}\n`;
      arc += `${season.description}\n`;
    });
    arc += `\n`;
  }
  
  arc += `NARRATIVE BEATS\n\n`;
  
  const third = Math.ceil(entities.length / 3);
  
  arc += `ACT I: INTRODUCTION\n`;
  arc += `Setting the stage, establishing themes\n`;
  entities.slice(0, third).forEach((e: TemporalEntity) => {
    arc += `- ${e.primaryEmoji} ${e.name}\n`;
  });
  
  arc += `\nACT II: ESCALATION\n`;
  arc += `Building momentum, introducing complexity\n`;
  entities.slice(third, third * 2).forEach((e: TemporalEntity) => {
    arc += `- ${e.primaryEmoji} ${e.name}\n`;
  });
  
  arc += `\nACT III: CLIMAX & RESOLUTION\n`;
  arc += `Peak moments, culmination, transitions\n`;
  entities.slice(third * 2).forEach((e: TemporalEntity) => {
    arc += `- ${e.primaryEmoji} ${e.name}\n`;
  });
  
  if (milestones.length > 0) {
    arc += `\nKEY MILESTONES\n`;
    milestones.forEach((milestone: TemporalEntity) => {
      arc += `🎯 ${milestone.name}\n`;
      arc += `   ${milestone.description}\n`;
    });
  }
  
  arc += `\nRECOMMENDED APPROACH\n`;
  arc += `- Maintain consistent themes throughout the timeline\n`;
  arc += `- Build anticipation before major events\n`;
  arc += `- Use quiet periods for reflection and setup\n`;
  arc += `- Create callbacks and references between entities\n`;
  arc += `- Plan for transitions between seasons/epochs\n`;
  
  return arc;
}

export function exportTemporalSpec(timelineId: string): string {
  const summary = generateTimelineSummary(timelineId);
  const calendar = exportTemporalCalendar(timelineId);
  const arc = generateSeasonArc(timelineId);
  const analytics = calculateTimelineAnalytics(timelineId);
  const conflicts = detectConflicts(timelineId);
  
  let spec = `DREAMNET TEMPORAL ORCHESTRATOR\n`;
  spec += `TIMELINE SPECIFICATION\n`;
  spec += `${'═'.repeat(60)}\n\n`;
  
  spec += summary;
  
  spec += `\n\n${'═'.repeat(60)}\n\n`;
  spec += `ANALYTICS\n\n`;
  spec += `Completion Rate: ${analytics.completionRate.toFixed(1)}%\n`;
  spec += `Entities: ${analytics.totalEntities} total | ${analytics.completedEntities} completed | ${analytics.inProgressEntities} in progress | ${analytics.blockedEntities} blocked\n`;
  spec += `Status: ${analytics.onTrackCount} on track | ${analytics.atRiskCount} at risk\n`;
  spec += `Momentum: ${analytics.overallMomentum}\n`;
  spec += `Critical Path Length: ${analytics.criticalPathLength}\n`;
  if (analytics.budgetUtilization !== undefined) {
    spec += `Budget Utilization: ${analytics.budgetUtilization.toFixed(1)}%\n`;
  }
  
  if (conflicts.length > 0) {
    spec += `\n\n${'═'.repeat(60)}\n\n`;
    spec += `CONFLICTS DETECTED (${conflicts.length})\n\n`;
    conflicts.forEach((conflict, idx) => {
      spec += `${idx + 1}. [${conflict.severity.toUpperCase()}] ${conflict.conflictType}\n`;
      spec += `   ${conflict.description}\n`;
      if (conflict.suggestedResolution) {
        spec += `   → ${conflict.suggestedResolution}\n`;
      }
      spec += `\n`;
    });
  }
  
  spec += `\n\n${'═'.repeat(60)}\n\n`;
  spec += calendar;
  spec += `\n\n${'═'.repeat(60)}\n\n`;
  spec += arc;
  
  return spec;
}
