// Core enums
export type TemporalEntityType = 
  | "event" 
  | "season" 
  | "epoch" 
  | "milestone" 
  | "deadline" 
  | "campaign-window" 
  | "other";

export type ImportanceLevel = "low" | "medium" | "high" | "critical";

export type TimelineStatus = "draft" | "active" | "archived";

export type EntityStatus = "not-started" | "in-progress" | "blocked" | "completed" | "on-hold";

export type RuleType = 
  | "behavior-shift" 
  | "priority-shift" 
  | "content-shift" 
  | "limit" 
  | "boost" 
  | "trigger";

export type ViewMode = "timeline" | "calendar" | "kanban" | "list" | "agenda";

export type RecurringPattern = "none" | "daily" | "weekly" | "monthly" | "yearly" | "custom";

export type MomentumLevel = "cold" | "warming" | "hot" | "explosive";

export type WorkspaceMode = "planning" | "execution" | "retrospective";

// Supporting interfaces
export interface GeoTarget {
  id: string;
  region: string;
  country: string;
  cityOrMarket: string;
  language: string;
}

export interface SEOMetadata {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export interface Assignee {
  id: string;
  name: string;
  role: string;
  avatar?: string;
}

export interface ChecklistItem {
  id: string;
  text: string;
  completed: boolean;
  assigneeId?: string;
}

export interface Blocker {
  id: string;
  description: string;
  severity: ImportanceLevel;
  resolvedAt?: string;
}

export interface ResourceAllocation {
  budget?: number;
  budgetCurrency?: string;
  teamCapacity?: number;
  requiredAssets?: string[];
  notes?: string;
}

export interface ChannelSlot {
  channel: string; // "farcaster" | "x" | "instagram" | "tiktok" | etc.
  contentType: string; // "post" | "video" | "story" | "thread"
  frequency: string; // "daily" | "2x/day" | "weekly"
  notes: string;
}

// Enhanced core entities
export interface TemporalEntity extends SEOMetadata {
  id: string;
  type: TemporalEntityType;
  name: string;
  description: string;
  startAt: string | null;
  endAt: string | null;
  primaryEmoji: string;
  importanceLevel: ImportanceLevel;
  category: string;
  tags: string[];
  notes: string;
  
  // Geo targeting
  primaryGeoTargets: GeoTarget[];
  entityIntroLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
  
  // Status & workflow
  status: EntityStatus;
  progress: number; // 0-100
  assignees: Assignee[];
  
  // Dependencies & blockers
  dependsOn: string[]; // entity IDs that must complete first
  blockedBy: Blocker[];
  
  // Recurring patterns
  recurringPattern: RecurringPattern;
  recurringConfig?: {
    interval?: number;
    until?: string;
    customCron?: string;
  };
  
  // Checklist
  checklist: ChecklistItem[];
  
  // Resources
  resources: ResourceAllocation;
  
  // Content orchestration
  contentSlots: ChannelSlot[];
  
  // Momentum tracking
  momentumLevel?: MomentumLevel;
  energyScore?: number; // 0-100
  
  // Risk tracking
  risks?: Array<{
    id: string;
    description: string;
    probability: ImportanceLevel;
    impact: ImportanceLevel;
    mitigation: string;
  }>;
  
  // Timestamps
  createdAt: string;
  updatedAt: string;
}

export interface Timeline extends SEOMetadata {
  id: string;
  name: string;
  description: string;
  category: string;
  importanceLevel: ImportanceLevel;
  temporalEntityIds: string[];
  status: TimelineStatus;
  tags: string[];
  
  // View preferences
  defaultViewMode: ViewMode;
  
  // Version control
  snapshotIds: string[];
  currentSnapshotId?: string;
  
  // Multi-timeline coordination
  linkedTimelineIds: string[]; // other timelines to coordinate with
  
  // Resources
  totalBudget?: number;
  budgetCurrency?: string;
  
  // Analytics
  completionRate?: number; // 0-100
  onTrackStatus?: "ahead" | "on-track" | "at-risk" | "behind";
  
  // Timestamps
  createdAt: string;
  updatedAt: string;
}

export interface TemporalRule {
  id: string;
  name: string;
  description: string;
  appliesToEntityIds: string[];
  ruleType: RuleType;
  effectSummary: string;
  detailedBehavior: string;
  recommendedApps: string[];
  notes: string;
  
  // Activation conditions
  isActive: boolean;
  activatesAt?: string;
  deactivatesAt?: string;
  
  // Metadata
  createdAt: string;
  updatedAt: string;
}

export interface ScheduledAction {
  id: string;
  temporalEntityId: string;
  name: string;
  description: string;
  scheduledAt: string;
  optionalDeadline: string | null;
  recommendedActionTypeCodes: string[];
  recommendedAccounts: string[];
  notes: string;
  
  // Status & workflow
  status: EntityStatus;
  assignees: Assignee[];
  
  // Dependencies
  prerequisiteActionIds: string[];
  
  // Channel targeting
  channels: string[];
  
  // Execution tracking
  completedAt?: string;
  actualDuration?: number; // minutes
  
  // Timestamps
  createdAt: string;
  updatedAt: string;
}

// NEW: Temporal Dependencies
export interface TemporalDependency {
  id: string;
  sourceEntityId: string;
  targetEntityId: string;
  dependencyType: "finish-to-start" | "start-to-start" | "finish-to-finish" | "start-to-finish";
  lagDays?: number; // delay between source and target
  notes: string;
}

// NEW: Temporal Templates
export interface TemporalTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  templateType: "season" | "launch" | "campaign" | "tournament" | "custom";
  
  // Template structure
  entityTemplates: Array<{
    type: TemporalEntityType;
    name: string;
    description: string;
    relativeStartDays: number; // days from timeline start
    relativeDurationDays: number;
    importanceLevel: ImportanceLevel;
    category: string;
    tags: string[];
    checklist: Array<{ text: string }>;
  }>;
  
  ruleTemplates: Array<{
    name: string;
    description: string;
    ruleType: RuleType;
    effectSummary: string;
    recommendedApps: string[];
  }>;
  
  // Metadata
  usageCount: number;
  createdAt: string;
  updatedAt: string;
}

// NEW: Temporal Snapshots (version control)
export interface TemporalSnapshot {
  id: string;
  timelineId: string;
  name: string;
  description: string;
  
  // Snapshot data
  snapshotData: {
    timeline: Timeline;
    entities: TemporalEntity[];
    rules: TemporalRule[];
    actions: ScheduledAction[];
  };
  
  // Metadata
  createdAt: string;
  createdBy: string;
}

// NEW: Temporal Playbooks
export interface TemporalPlaybook {
  id: string;
  name: string;
  description: string;
  playbookType: "launch" | "crisis" | "recurring" | "custom";
  
  // Playbook steps
  steps: Array<{
    id: string;
    order: number;
    title: string;
    description: string;
    estimatedDuration: number; // minutes
    assignedRole?: string;
    checklist: Array<{ text: string }>;
    resources?: string[];
  }>;
  
  // Applicable to
  appliesToEntityTypes: TemporalEntityType[];
  appliesToCategories: string[];
  
  // Metadata
  usageCount: number;
  createdAt: string;
  updatedAt: string;
}

// NEW: Temporal Conflicts
export interface TemporalConflict {
  id: string;
  conflictType: "overlap" | "overload" | "dependency-cycle" | "resource-conflict";
  severity: ImportanceLevel;
  description: string;
  affectedEntityIds: string[];
  suggestedResolution?: string;
  resolvedAt?: string;
}

// NEW: Temporal Momentum
export interface TemporalMomentum {
  timelineId: string;
  entityId?: string; // optional, for entity-specific momentum
  
  // Momentum metrics
  momentumLevel: MomentumLevel;
  velocityScore: number; // 0-100, completion rate
  energyScore: number; // 0-100, activity intensity
  
  // Historical data
  weeklyVelocity: number[];
  weeklyEnergy: number[];
  
  // Analysis
  trend: "rising" | "stable" | "falling";
  recommendation: string;
  
  // Timestamps
  calculatedAt: string;
}

// Input types
export interface CreateTemporalEntityInput {
  type: TemporalEntityType;
  name: string;
  description: string;
  startAt?: string | null;
  endAt?: string | null;
  importanceLevel?: ImportanceLevel;
  category?: string;
  primaryEmoji?: string;
  tags?: string[];
  status?: EntityStatus;
  assignees?: Assignee[];
  recurringPattern?: RecurringPattern;
  contentSlots?: ChannelSlot[];
}

export interface CreateTimelineInput {
  name: string;
  description: string;
  category: string;
  importanceLevel: ImportanceLevel;
  defaultViewMode?: ViewMode;
  totalBudget?: number;
  budgetCurrency?: string;
}

export interface CreateTemporalRuleInput {
  name: string;
  description: string;
  appliesToEntityIds: string[];
  ruleType: RuleType;
  effectSummary: string;
  detailedBehavior: string;
  recommendedApps: string[];
  activatesAt?: string;
  deactivatesAt?: string;
}

export interface CreateScheduledActionInput {
  temporalEntityId: string;
  name: string;
  description: string;
  scheduledAt: string;
  optionalDeadline?: string | null;
  recommendedActionTypeCodes?: string[];
  recommendedAccounts?: string[];
  status?: EntityStatus;
  assignees?: Assignee[];
  channels?: string[];
}

export interface CreateDependencyInput {
  sourceEntityId: string;
  targetEntityId: string;
  dependencyType: "finish-to-start" | "start-to-start" | "finish-to-finish" | "start-to-finish";
  lagDays?: number;
}

export interface CreateTemplateInput {
  name: string;
  description: string;
  category: string;
  templateType: "season" | "launch" | "campaign" | "tournament" | "custom";
}

export interface CreatePlaybookInput {
  name: string;
  description: string;
  playbookType: "launch" | "crisis" | "recurring" | "custom";
  appliesToEntityTypes?: TemporalEntityType[];
  appliesToCategories?: string[];
}

// Filter types
export interface TemporalEntityFilter {
  type?: TemporalEntityType;
  importanceLevel?: ImportanceLevel;
  category?: string;
  tag?: string;
  status?: EntityStatus;
  assigneeId?: string;
}

export interface TimelineFilter {
  category?: string;
  importanceLevel?: ImportanceLevel;
  status?: TimelineStatus;
  viewMode?: ViewMode;
}

// Analytics types
export interface TimelineAnalytics {
  timelineId: string;
  totalEntities: number;
  completedEntities: number;
  inProgressEntities: number;
  blockedEntities: number;
  completionRate: number;
  onTrackCount: number;
  atRiskCount: number;
  overallMomentum: MomentumLevel;
  criticalPathLength: number;
  estimatedCompletionDate?: string;
  budgetUtilization?: number;
}
