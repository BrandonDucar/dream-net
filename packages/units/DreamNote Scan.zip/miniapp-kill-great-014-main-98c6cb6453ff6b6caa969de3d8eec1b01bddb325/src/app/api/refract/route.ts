import { NextRequest, NextResponse } from 'next/server';
import { openaiChatCompletion } from '@/openai-api';
import type { OpenAIChatMessage } from '@/openai-api';

type RefinementLevel = 'light' | 'medium' | 'heavy';

interface RefractRequestBody {
  text?: string;
  texts?: string[];
  level: RefinementLevel;
  batch?: boolean;
}

function getSystemPrompt(level: RefinementLevel): string {
  const basePrompt = `You are DreamNote Scan, an advanced text refinement system. Your task is to transform messy, scattered, or unorganized text into clean, optimized, high-clarity versions.`;

  const levelGuidelines: Record<RefinementLevel, string> = {
    light: `
Refinement Level: LIGHT - Subtle Polish
- Fix only obvious grammar, spelling, and punctuation errors
- Make minimal changes to sentence structure
- Preserve the original writing style and voice
- Remove only critical redundancies
- Keep the text close to its original form
- Focus on correctness without major restructuring`,
    
    medium: `
Refinement Level: MEDIUM - Balanced Enhancement
- Fix grammar, spelling, and punctuation errors
- Improve sentence structure and flow
- Organize information logically
- Remove redundancy and filler
- Enhance readability without losing meaning
- Maintain the original intent and key information
- Use clear, concise language
- Format with proper paragraphs and structure`,
    
    heavy: `
Refinement Level: HEAVY - Deep Transformation
- Completely restructure text for maximum clarity
- Aggressively eliminate redundancy and filler
- Reorganize content with optimal logical flow
- Enhance vocabulary and precision
- Create professional, polished formatting
- Maximize information density
- Transform informal language into formal, clear expression
- Add proper headings, bullets, or structure where beneficial`
  };

  return `${basePrompt}

${levelGuidelines[level]}

Core Rules:
- Do NOT add new information or change the core message
- Output only the refined text, no explanations or meta-commentary
- Maintain factual accuracy

Transform the input into its best, most polished version according to the refinement level.`;
}

async function refractSingleText(text: string, level: RefinementLevel): Promise<string> {
  const messages: OpenAIChatMessage[] = [
    {
      role: 'system',
      content: getSystemPrompt(level)
    },
    {
      role: 'user',
      content: text
    }
  ];

  const completion = await openaiChatCompletion({
    model: 'gpt-4o',
    messages
  });

  return completion.choices[0].message.content;
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body: RefractRequestBody = await request.json();
    const { text, texts, level = 'medium', batch = false } = body;

    // Validation
    if (batch && texts) {
      if (!Array.isArray(texts) || texts.length === 0) {
        return NextResponse.json(
          { error: 'Invalid texts array for batch processing' },
          { status: 400 }
        );
      }

      if (texts.some(t => !t || typeof t !== 'string')) {
        return NextResponse.json(
          { error: 'All texts must be non-empty strings' },
          { status: 400 }
        );
      }

      // Batch processing
      const refinedTexts = await Promise.all(
        texts.map(t => refractSingleText(t, level))
      );

      return NextResponse.json({
        refined: refinedTexts,
        count: refinedTexts.length,
        level: level,
        originalLengths: texts.map(t => t.length),
        refinedLengths: refinedTexts.map(t => t.length)
      });
    } else {
      // Single processing
      if (!text || typeof text !== 'string') {
        return NextResponse.json(
          { error: 'Invalid text input' },
          { status: 400 }
        );
      }

      const refinedText = await refractSingleText(text, level);

      return NextResponse.json({
        refined: refinedText,
        level: level,
        originalLength: text.length,
        refinedLength: refinedText.length
      });
    }

  } catch (error) {
    console.error('Refraction error:', error);
    return NextResponse.json(
      { error: 'Failed to refract text' },
      { status: 500 }
    );
  }
}
