'use client'
import { useState, useEffect } from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Copy, Sparkles, Loader2, Plus, Trash2, Download, Layers } from 'lucide-react';
import { toast } from 'sonner';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';

interface TextItem {
  id: string;
  input: string;
  output: string;
}

type RefinementLevel = 'light' | 'medium' | 'heavy';

export default function DreamNoteScan(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])

  const [batchMode, setBatchMode] = useState<boolean>(false);
  const [refinementLevel, setRefinementLevel] = useState<RefinementLevel>('medium');
  const [textItems, setTextItems] = useState<TextItem[]>([
    { id: '1', input: '', output: '' }
  ]);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  const addTextItem = (): void => {
    const newId = (Math.max(...textItems.map(item => parseInt(item.id))) + 1).toString();
    setTextItems([...textItems, { id: newId, input: '', output: '' }]);
  };

  const removeTextItem = (id: string): void => {
    if (textItems.length > 1) {
      setTextItems(textItems.filter(item => item.id !== id));
    }
  };

  const updateTextInput = (id: string, input: string): void => {
    setTextItems(textItems.map(item => 
      item.id === id ? { ...item, input } : item
    ));
  };

  const handleRefract = async (): Promise<void> => {
    const hasInput = textItems.some(item => item.input.trim());
    if (!hasInput) {
      toast.error('Please enter some text to refract');
      return;
    }

    setIsProcessing(true);

    // Clear outputs
    setTextItems(textItems.map(item => ({ ...item, output: '' })));

    try {
      if (batchMode) {
        // Batch processing
        const textsToProcess = textItems
          .filter(item => item.input.trim())
          .map(item => item.input);

        const response = await fetch('/api/refract', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            texts: textsToProcess,
            level: refinementLevel,
            batch: true
          }),
        });

        if (!response.ok) {
          throw new Error('Failed to refract texts');
        }

        const data = await response.json();
        
        // Update outputs
        let outputIndex = 0;
        setTextItems(textItems.map(item => {
          if (item.input.trim()) {
            return { ...item, output: data.refined[outputIndex++] };
          }
          return item;
        }));

        toast.success(`${data.refined.length} texts refracted successfully`);
      } else {
        // Single processing
        const firstItem = textItems[0];
        if (!firstItem.input.trim()) {
          toast.error('Please enter some text to refract');
          return;
        }

        const response = await fetch('/api/refract', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            text: firstItem.input,
            level: refinementLevel
          }),
        });

        if (!response.ok) {
          throw new Error('Failed to refract text');
        }

        const data = await response.json();
        setTextItems([{ ...firstItem, output: data.refined }]);
        toast.success('Text refracted successfully');
      }
    } catch (error) {
      console.error('Refraction error:', error);
      toast.error('Failed to refract text. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCopy = async (text: string): Promise<void> => {
    if (!text) return;

    try {
      await navigator.clipboard.writeText(text);
      toast.success('Copied to clipboard');
    } catch (error) {
      console.error('Copy error:', error);
      toast.error('Failed to copy text');
    }
  };

  const handleCopyAll = async (): Promise<void> => {
    const allOutputs = textItems
      .filter(item => item.output)
      .map(item => item.output)
      .join('\n\n---\n\n');

    if (!allOutputs) return;

    try {
      await navigator.clipboard.writeText(allOutputs);
      toast.success('All outputs copied to clipboard');
    } catch (error) {
      console.error('Copy error:', error);
      toast.error('Failed to copy text');
    }
  };

  const handleExport = (format: 'txt' | 'md' | 'json'): void => {
    const outputs = textItems.filter(item => item.output);
    if (outputs.length === 0) {
      toast.error('No refined text to export');
      return;
    }

    let content = '';
    let filename = '';
    let mimeType = '';

    switch (format) {
      case 'txt':
        content = outputs.map(item => item.output).join('\n\n---\n\n');
        filename = 'dreamnote-refined.txt';
        mimeType = 'text/plain';
        break;
      case 'md':
        content = '# DreamNote Scan - Refined Output\n\n';
        content += `*Refinement Level: ${refinementLevel.toUpperCase()}*\n\n`;
        content += '---\n\n';
        outputs.forEach((item, index) => {
          content += `## Text ${index + 1}\n\n${item.output}\n\n---\n\n`;
        });
        filename = 'dreamnote-refined.md';
        mimeType = 'text/markdown';
        break;
      case 'json':
        const exportData = {
          timestamp: new Date().toISOString(),
          refinementLevel: refinementLevel,
          count: outputs.length,
          items: outputs.map((item, index) => ({
            id: index + 1,
            original: item.input,
            refined: item.output,
            originalLength: item.input.length,
            refinedLength: item.output.length
          }))
        };
        content = JSON.stringify(exportData, null, 2);
        filename = 'dreamnote-refined.json';
        mimeType = 'application/json';
        break;
    }

    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast.success(`Exported as ${format.toUpperCase()}`);
  };

  const handleClear = (): void => {
    setTextItems([{ id: '1', input: '', output: '' }]);
  };

  const getLevelColor = (level: RefinementLevel): string => {
    switch (level) {
      case 'light': return 'text-cyan-400';
      case 'medium': return 'text-purple-400';
      case 'heavy': return 'text-pink-400';
    }
  };

  const getLevelDescription = (level: RefinementLevel): string => {
    switch (level) {
      case 'light': return 'Minimal changes, preserve original style';
      case 'medium': return 'Balanced clarity and structure';
      case 'heavy': return 'Maximum optimization and restructuring';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950 text-white flex flex-col items-center justify-center p-4 pt-16 md:pt-8">
      <div className="w-full max-w-6xl space-y-6">
        {/* Header */}
        <div className="text-center space-y-3">
          <div className="flex items-center justify-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-cyan-400 via-purple-400 to-pink-400 rounded-lg rotate-45 shadow-lg shadow-purple-500/50"></div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              DreamNote Scan
            </h1>
            <div className="w-8 h-8 bg-gradient-to-br from-pink-400 via-purple-400 to-cyan-400 rounded-lg -rotate-45 shadow-lg shadow-pink-500/50"></div>
          </div>
          <p className="text-slate-400 text-lg">
            Refract scattered text into crystal-clear clarity
          </p>
          <div className="flex items-center justify-center gap-2 text-xs text-slate-500">
            <span className="inline-block w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></span>
            <span>DNOTE</span>
            <span className="inline-block w-1 h-1 bg-slate-600 rounded-full"></span>
            <span>Powered by DreamNet</span>
          </div>
        </div>

        {/* Controls */}
        <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-sm p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Refinement Level */}
            <div className="space-y-2">
              <Label className="text-slate-300 flex items-center gap-2">
                <Layers className="w-4 h-4" />
                Refinement Intensity
              </Label>
              <Select value={refinementLevel} onValueChange={(value: RefinementLevel) => setRefinementLevel(value)}>
                <SelectTrigger className="bg-slate-950/50 border-slate-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-700">
                  <SelectItem value="light" className="text-cyan-400">
                    Light - Subtle Polish
                  </SelectItem>
                  <SelectItem value="medium" className="text-purple-400">
                    Medium - Balanced
                  </SelectItem>
                  <SelectItem value="heavy" className="text-pink-400">
                    Heavy - Deep Transform
                  </SelectItem>
                </SelectContent>
              </Select>
              <p className={`text-xs ${getLevelColor(refinementLevel)}`}>
                {getLevelDescription(refinementLevel)}
              </p>
            </div>

            {/* Batch Mode */}
            <div className="space-y-2">
              <Label className="text-slate-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                Processing Mode
              </Label>
              <div className="flex items-center space-x-3 bg-slate-950/50 border border-slate-700 rounded-md p-3">
                <Switch
                  id="batch-mode"
                  checked={batchMode}
                  onCheckedChange={setBatchMode}
                  className="data-[state=checked]:bg-purple-500"
                />
                <Label htmlFor="batch-mode" className="text-white cursor-pointer">
                  {batchMode ? 'Batch Mode Active' : 'Single Mode'}
                </Label>
              </div>
              <p className="text-xs text-slate-500">
                {batchMode ? 'Process multiple texts simultaneously' : 'Process one text at a time'}
              </p>
            </div>
          </div>
        </Card>

        {/* Text Items */}
        <div className="space-y-4">
          {textItems.map((item, index) => (
            <Card key={item.id} className="bg-slate-900/50 border-slate-800 backdrop-blur-sm p-6 space-y-4">
              {batchMode && (
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-slate-400">Text {index + 1}</span>
                  {textItems.length > 1 && (
                    <Button
                      onClick={() => removeTextItem(item.id)}
                      variant="ghost"
                      size="sm"
                      className="text-red-400 hover:text-red-300 h-8"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {/* Input */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-slate-300 flex items-center gap-2">
                      <span className="inline-block w-2 h-2 bg-red-400 rounded-full"></span>
                      Input
                    </label>
                    <span className="text-xs text-slate-500">{item.input.length} chars</span>
                  </div>
                  <Textarea
                    value={item.input}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>): void => updateTextInput(item.id, e.target.value)}
                    placeholder="Enter text to refract..."
                    className="min-h-[150px] bg-slate-950/50 border-slate-700 text-white placeholder:text-slate-600 resize-none focus-visible:ring-cyan-500/50"
                    disabled={isProcessing}
                  />
                </div>

                {/* Output */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-slate-300 flex items-center gap-2">
                      <span className="inline-block w-2 h-2 bg-green-400 rounded-full"></span>
                      Output
                    </label>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-500">{item.output.length} chars</span>
                      {item.output && (
                        <Button
                          onClick={() => handleCopy(item.output)}
                          variant="ghost"
                          size="sm"
                          className="text-slate-400 hover:text-cyan-400 h-8"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                  <Textarea
                    value={item.output}
                    readOnly
                    placeholder="Refined text appears here..."
                    className="min-h-[150px] bg-slate-950/50 border-slate-700 text-white placeholder:text-slate-600 resize-none focus-visible:ring-green-500/50"
                  />
                </div>
              </div>
            </Card>
          ))}

          {batchMode && (
            <Button
              onClick={addTextItem}
              variant="outline"
              className="w-full border-slate-700 border-dashed text-slate-400 hover:text-white hover:border-slate-600 bg-slate-900/30"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Another Text
            </Button>
          )}
        </div>

        {/* Main Actions */}
        <div className="flex flex-col items-center gap-4">
          {/* Refract Button */}
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 rounded-full blur-xl opacity-50 animate-pulse"></div>
            <Button
              onClick={handleRefract}
              disabled={isProcessing || !textItems.some(item => item.input.trim())}
              className="relative bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 hover:from-cyan-400 hover:via-purple-400 hover:to-pink-400 text-white font-semibold px-12 py-6 rounded-full text-lg shadow-2xl shadow-purple-500/50 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Refracting...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  Refract Through Prism
                </>
              )}
            </Button>
          </div>

          {/* Secondary Actions */}
          {textItems.some(item => item.output) && (
            <div className="flex flex-wrap items-center justify-center gap-3">
              <Button
                onClick={handleCopyAll}
                variant="outline"
                className="border-slate-700 text-slate-400 hover:text-white hover:border-slate-600 bg-slate-900/50"
              >
                <Copy className="w-4 h-4 mr-2" />
                Copy All
              </Button>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="outline"
                    className="border-slate-700 text-slate-400 hover:text-white hover:border-slate-600 bg-slate-900/50"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-slate-900 border-slate-700">
                  <DropdownMenuItem 
                    onClick={() => handleExport('txt')}
                    className="text-slate-300 hover:text-white cursor-pointer"
                  >
                    Export as TXT
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => handleExport('md')}
                    className="text-slate-300 hover:text-white cursor-pointer"
                  >
                    Export as Markdown
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => handleExport('json')}
                    className="text-slate-300 hover:text-white cursor-pointer"
                  >
                    Export as JSON
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <Button
                onClick={handleClear}
                variant="outline"
                className="border-slate-700 text-slate-400 hover:text-red-400 hover:border-red-700 bg-slate-900/50"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Clear All
              </Button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="text-center text-xs text-slate-600 space-y-1">
          <p>Transform messy input into structured, optimized output</p>
          <p className="text-slate-700">Version 2.0 • DreamNet Protocol • Enhanced Edition</p>
        </div>
      </div>
    </div>
  );
}
