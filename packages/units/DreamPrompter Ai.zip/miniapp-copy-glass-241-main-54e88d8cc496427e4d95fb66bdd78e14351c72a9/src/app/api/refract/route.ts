import { NextRequest, NextResponse } from 'next/server';
import { openaiChatCompletion } from '@/openai-api';

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.json();
    const { text } = body;

    if (!text || typeof text !== 'string') {
      return NextResponse.json(
        { error: 'Invalid input: text is required' },
        { status: 400 }
      );
    }

    if (text.trim().length === 0) {
      return NextResponse.json(
        { error: 'Input text cannot be empty' },
        { status: 400 }
      );
    }

    // Use OpenAI to refine and optimize the text
    const response = await openaiChatCompletion({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: `You are DreamPrism, an elite AI prompt engineering system. Transform rough prompts into high-performance instructions using advanced prompt engineering techniques.

FRAMEWORK (RCFC):
1. ROLE - Define who the AI should act as (expert, analyst, writer, etc.)
2. CONTEXT - Provide background, constraints, and relevant details
3. FORMAT - Specify output structure (list, essay, code, markdown, etc.)
4. CONSTRAINTS - Set length, tone, style, audience, and boundaries

ENHANCEMENT PROTOCOL:
- Define a clear role/persona for the AI to embody
- Specify the target audience explicitly
- Add concrete constraints (word count, tone, style)
- Define the exact output format and structure
- Include success criteria or quality benchmarks
- Add relevant examples if it improves clarity
- Break complex tasks into numbered steps
- Use precise, actionable language
- Remove all ambiguity and vague terms
- Specify what to include AND what to avoid
- Add edge cases or exceptions if relevant

CRITICAL RULES:
- Return ONLY the engineered prompt (no explanations or meta-text)
- Preserve original intent while maximizing specificity
- Make every word count toward better AI output
- Use professional, direct language
- Optimize for any AI model (GPT, Claude, Llama, etc.)`,
        },
        {
          role: 'user',
          content: text,
        },
      ],
    });

    const refinedText = response.choices[0]?.message?.content;

    if (!refinedText) {
      return NextResponse.json(
        { error: 'Failed to generate refined text' },
        { status: 500 }
      );
    }

    return NextResponse.json({ refined: refinedText });
  } catch (error) {
    console.error('Error in refract API:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
