'use client'
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Sparkles, ArrowRight, Copy, Check, Lightbulb } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DreamPrismClean(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [inputText, setInputText] = useState<string>('');
  const [outputText, setOutputText] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  const handleRefract = async (): Promise<void> => {
    if (!inputText.trim()) return;
    
    setIsProcessing(true);
    setOutputText('');
    
    try {
      const response = await fetch('/api/refract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: inputText }),
      });
      
      const data = await response.json();
      
      if (data.error) {
        setOutputText(`Error: ${data.error}`);
      } else {
        setOutputText(data.refined || '');
      }
    } catch (error) {
      setOutputText('Failed to process text. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCopy = async (): Promise<void> => {
    if (!outputText) return;
    
    await navigator.clipboard.writeText(outputText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleClear = (): void => {
    setInputText('');
    setOutputText('');
  };

  return (
    <div className="min-h-screen bg-black text-white pt-16 px-4 pb-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 mb-4">
            <Sparkles className="w-8 h-8 text-cyan-400" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              DreamPrism
            </h1>
            <Sparkles className="w-8 h-8 text-pink-400" />
          </div>
          <p className="text-gray-400 text-lg">
            Transform rough ideas into engineered prompts using RCFC framework
          </p>
          <p className="text-xs text-gray-500 mt-2">
            Role • Context • Format • Constraints
          </p>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Input Panel */}
          <Card className="bg-gray-900/50 border-cyan-500/30 backdrop-blur-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-cyan-400">Input</h2>
              {inputText && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleClear}
                  className="text-gray-400 hover:text-white"
                >
                  Clear
                </Button>
              )}
            </div>
            <Textarea
              value={inputText}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setInputText(e.target.value)}
              placeholder="Enter your rough prompt...\n\nExample:\n'write about blockchain'\n\n→ Missing: role, audience, format, length, tone"
              className="min-h-[400px] bg-black/50 border-cyan-500/20 text-white placeholder:text-gray-500 resize-none focus:border-cyan-500/50 focus:ring-cyan-500/50"
            />
            <div className="mt-4 text-sm text-gray-500">
              {inputText.length} characters
            </div>
          </Card>

          {/* Output Panel */}
          <Card className="bg-gray-900/50 border-purple-500/30 backdrop-blur-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-purple-400">Output</h2>
              {outputText && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleCopy}
                  className="text-gray-400 hover:text-white"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 mr-2" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 mr-2" />
                      Copy
                    </>
                  )}
                </Button>
              )}
            </div>
            <Textarea
              value={outputText}
              readOnly
              placeholder="Engineered prompt with:\n\n✓ Clear role & persona\n✓ Specific context & constraints\n✓ Defined format & structure\n✓ Success criteria\n✓ Audience specification\n✓ Output requirements"
              className="min-h-[400px] bg-black/50 border-purple-500/20 text-white placeholder:text-gray-500 resize-none cursor-default"
            />
            <div className="mt-4 text-sm text-gray-500">
              {outputText.length} characters
            </div>
          </Card>
        </div>

        {/* Refract Button */}
        <div className="flex justify-center">
          <Button
            onClick={handleRefract}
            disabled={!inputText.trim() || isProcessing}
            className="bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 hover:from-cyan-600 hover:via-purple-600 hover:to-pink-600 text-white font-semibold px-12 py-6 text-lg rounded-full shadow-lg shadow-purple-500/50 hover:shadow-purple-500/70 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isProcessing ? (
              <>
                <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                Refracting...
              </>
            ) : (
              <>
                Refract
                <ArrowRight className="w-5 h-5 ml-2" />
              </>
            )}
          </Button>
        </div>

        {/* Framework Info */}
        <div className="mt-12">
          <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <Lightbulb className="w-5 h-5 text-yellow-400" />
              <h3 className="text-lg font-semibold text-white">Prompt Engineering Framework</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="border-l-2 border-cyan-500 pl-4">
                <div className="text-cyan-400 font-semibold mb-1">Role</div>
                <div className="text-xs text-gray-400">Defines who the AI should act as</div>
              </div>
              <div className="border-l-2 border-purple-500 pl-4">
                <div className="text-purple-400 font-semibold mb-1">Context</div>
                <div className="text-xs text-gray-400">Background info & constraints</div>
              </div>
              <div className="border-l-2 border-pink-500 pl-4">
                <div className="text-pink-400 font-semibold mb-1">Format</div>
                <div className="text-xs text-gray-400">Output structure & style</div>
              </div>
              <div className="border-l-2 border-yellow-500 pl-4">
                <div className="text-yellow-400 font-semibold mb-1">Constraints</div>
                <div className="text-xs text-gray-400">Length, tone, audience limits</div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-8 text-center">
          <div className="inline-block bg-gray-900/50 border border-gray-700 rounded-lg px-6 py-4">
            <p className="text-sm text-gray-400">
              <span className="text-cyan-400 font-semibold">DreamNet Prompt Engineering</span>
              {' • '}
              Turn vague ideas into high-performance AI instructions
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
