'use client'
import type { FC, useEffect } from 'react';
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Sparkles, Copy, Check, Heart, Clock, BookmarkPlus, TrendingUp } from 'lucide-react';
import { openaiChatCompletion } from '@/openai-api';
import { saveFavorite, saveToHistory, type HistoryItem } from '@/lib/storage';
import { TrendingTemplates } from '@/components/TrendingTemplates';
import { FavoritesPanel } from '@/components/FavoritesPanel';
import { HistoryPanel } from '@/components/HistoryPanel';
import { SocialShareButtons } from '@/components/SocialShareButtons';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type ContentType = 'post' | 'caption' | 'idea' | 'headline' | 'video-concept' | 'product-description' | 'bio' | 'script';
type View = 'main' | 'favorites' | 'history' | 'templates';

interface ImprovedVersions {
  cleaner: string;
  highEngagement: string;
  emotional: string;
  boldViral: string;
  shortPunchy: string;
  instagram: string;
  tiktok: string;
  youtubeShorts: string;
  x: string;
  hooks: string[];
  cta: string;
  hashtags: string[];
  postingTime: string;
}

const contentTypes: { value: ContentType; label: string; icon: string }[] = [
  { value: 'post', label: 'Social Post', icon: '📱' },
  { value: 'caption', label: 'Caption', icon: '💬' },
  { value: 'idea', label: 'Idea', icon: '💡' },
  { value: 'headline', label: 'Headline', icon: '📰' },
  { value: 'video-concept', label: 'Video Concept', icon: '🎬' },
  { value: 'product-description', label: 'Product Description', icon: '🛍️' },
  { value: 'bio', label: 'Bio', icon: '👤' },
  { value: 'script', label: 'Script', icon: '📝' },
];

const toneOptions = [
  { label: 'Funny', emoji: '😂' },
  { label: 'Serious', emoji: '🎯' },
  { label: 'Inspirational', emoji: '✨' },
  { label: 'Mysterious', emoji: '🔮' },
];

export default function DreamRankEngine(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [view, setView] = useState<View>('main');
  const [step, setStep] = useState<number>(1);
  const [contentType, setContentType] = useState<ContentType | null>(null);
  const [originalText, setOriginalText] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [results, setResults] = useState<ImprovedVersions | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(new Set());
  const [toneSliders, setToneSliders] = useState<Record<string, number>>({
    Funny: 50,
    Serious: 50,
    Inspirational: 50,
    Mysterious: 50,
  });

  const handleContentTypeSelect = (type: ContentType): void => {
    setContentType(type);
    setStep(2);
  };

  const handleBack = (): void => {
    setStep(1);
    setContentType(null);
    setResults(null);
  };

  const copyToClipboard = async (text: string, id: string): Promise<void> => {
    await navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const toggleFavorite = (id: string, title: string, content: string, versionType: string): void => {
    const newFavorites = new Set(favoriteIds);
    
    if (newFavorites.has(id)) {
      newFavorites.delete(id);
    } else {
      newFavorites.add(id);
      saveFavorite({
        id,
        title,
        content,
        contentType: contentType || 'post',
        versionType,
        timestamp: Date.now(),
        isFavorite: true,
      });
    }
    
    setFavoriteIds(newFavorites);
  };

  const handleRestoreFromHistory = (item: HistoryItem): void => {
    setView('main');
    setStep(2);
    setContentType(item.contentType as ContentType);
    setOriginalText(item.originalText);
    setResults(item.results);
  };

  const handleUseTemplate = (template: string): void => {
    setView('main');
    setStep(2);
    setOriginalText(template);
  };

  const generateImprovedVersions = async (): Promise<void> => {
    if (!originalText.trim() || !contentType) return;

    setLoading(true);
    try {
      const toneContext = Object.entries(toneSliders)
        .map(([tone, value]) => `${tone}: ${value}%`)
        .join(', ');

      const prompt = `You are a content optimization expert. The user wants to improve their ${contentType} for better reach and engagement.

IMPORTANT RULES:
- Never mention AI, algorithms, SEO, or technical terms
- Use consumer-friendly language like "visibility boost", "reach enhancer", "optimized version"
- Keep the voice authentic and human
- Tone preferences: ${toneContext}

Original ${contentType}:
"${originalText}"

Generate the following improved versions in JSON format:

{
  "cleaner": "A polished, clear version that removes fluff and tightens the message",
  "highEngagement": "A version optimized for maximum audience interaction and shares",
  "emotional": "A version that connects emotionally and resonates deeply",
  "boldViral": "A bold, attention-grabbing version designed to go viral",
  "shortPunchy": "An ultra-concise, punchy version that hits hard in few words",
  "instagram": "Optimized for Instagram (visual focus, emojis, hashtags at end)",
  "tiktok": "Optimized for TikTok (hook first, trend-friendly, relatable)",
  "youtubeShorts": "Optimized for YouTube Shorts (strong opening, retention focus)",
  "x": "Optimized for X/Twitter (concise, thread-ready, conversation starter)",
  "hooks": ["Hook suggestion 1", "Hook suggestion 2", "Hook suggestion 3"],
  "cta": "A strong call-to-action that drives engagement",
  "hashtags": ["hashtag1", "hashtag2", "hashtag3", "hashtag4", "hashtag5"],
  "postingTime": "Friendly suggestion for ideal posting time (e.g., 'Tuesday morning when people check their feeds')"
}

Return ONLY valid JSON, no other text.`;

      const response = await openaiChatCompletion({
        model: 'gpt-4o',
        messages: [
          { role: 'system', content: 'You are a content optimization expert focused on reach and engagement.' },
          { role: 'user', content: prompt },
        ],
      });

      const content = response.choices[0]?.message?.content || '';
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]) as ImprovedVersions;
        setResults(parsed);
        
        // Save to history
        saveToHistory({
          id: `history-${Date.now()}`,
          contentType: contentType,
          originalText,
          timestamp: Date.now(),
          results: parsed,
        });
      } else {
        throw new Error('Invalid response format');
      }
    } catch (error) {
      console.error('Error generating versions:', error);
      alert('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-purple-950 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8 md:mb-12 pt-8">
          <div className="inline-flex items-center gap-3 mb-4">
            <Sparkles className="w-8 h-8 text-cyan-400 animate-pulse" />
            <h1 className="text-3xl md:text-5xl font-bold text-white">
              DreamRank Engine
            </h1>
            <Badge variant="outline" className="text-cyan-400 border-cyan-400 text-lg px-3 py-1">
              $RANK
            </Badge>
          </div>
          <p className="text-cyan-100 text-lg">
            Boost your reach in one tap
          </p>
          
          {/* Navigation */}
          <div className="flex flex-wrap justify-center gap-2 mt-6">
            <Button
              onClick={() => setView('main')}
              variant={view === 'main' ? 'default' : 'outline'}
              className={view === 'main' 
                ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white' 
                : 'border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10'}
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Create
            </Button>
            <Button
              onClick={() => setView('templates')}
              variant={view === 'templates' ? 'default' : 'outline'}
              className={view === 'templates' 
                ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white' 
                : 'border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10'}
            >
              <TrendingUp className="w-4 h-4 mr-2" />
              Templates
            </Button>
            <Button
              onClick={() => setView('favorites')}
              variant={view === 'favorites' ? 'default' : 'outline'}
              className={view === 'favorites' 
                ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white' 
                : 'border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10'}
            >
              <Heart className="w-4 h-4 mr-2" />
              Favorites
            </Button>
            <Button
              onClick={() => setView('history')}
              variant={view === 'history' ? 'default' : 'outline'}
              className={view === 'history' 
                ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white' 
                : 'border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10'}
            >
              <Clock className="w-4 h-4 mr-2" />
              History
            </Button>
          </div>
        </div>

        {/* Favorites View */}
        {view === 'favorites' && <FavoritesPanel />}

        {/* History View */}
        {view === 'history' && <HistoryPanel onRestore={handleRestoreFromHistory} />}

        {/* Templates View */}
        {view === 'templates' && <TrendingTemplates onUseTemplate={handleUseTemplate} />}

        {/* Main App View */}
        {view === 'main' && (
          <>
            {/* Step 1: Select Content Type */}
            {step === 1 && (
              <Card className="border-cyan-500/30 bg-slate-900/50 backdrop-blur shadow-2xl shadow-cyan-500/20">
                <CardHeader>
                  <CardTitle className="text-white text-2xl">What do you want to improve?</CardTitle>
                  <CardDescription className="text-cyan-100">
                    Choose the type of content you want to optimize
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {contentTypes.map((type) => (
                      <Button
                        key={type.value}
                        onClick={() => handleContentTypeSelect(type.value)}
                        variant="outline"
                        className="h-24 flex flex-col gap-2 border-cyan-500/30 hover:border-cyan-400 hover:bg-cyan-500/10 text-white transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/30"
                      >
                        <span className="text-3xl">{type.icon}</span>
                        <span className="text-sm">{type.label}</span>
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step 2: Enter Text & Generate */}
            {step === 2 && !results && (
              <Card className="border-cyan-500/30 bg-slate-900/50 backdrop-blur shadow-2xl shadow-cyan-500/20">
                <CardHeader>
                  <CardTitle className="text-white text-2xl flex items-center gap-2">
                    <span>Paste your {contentType}</span>
                  </CardTitle>
                  <CardDescription className="text-cyan-100">
                    Enter the text you want to enhance for better visibility
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Tone Sliders */}
                  <div className="space-y-4 p-4 rounded-lg bg-slate-800/50 border border-cyan-500/20">
                    <Label className="text-white text-lg">Adjust tone (optional)</Label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {toneOptions.map((tone) => (
                        <div key={tone.label} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-cyan-100 text-sm flex items-center gap-2">
                              <span>{tone.emoji}</span>
                              <span>{tone.label}</span>
                            </span>
                            <span className="text-cyan-400 text-sm font-bold">
                              {toneSliders[tone.label]}%
                            </span>
                          </div>
                          <Slider
                            value={[toneSliders[tone.label]]}
                            onValueChange={(value) =>
                              setToneSliders({ ...toneSliders, [tone.label]: value[0] })
                            }
                            max={100}
                            step={10}
                            className="[&_[role=slider]]:bg-cyan-400 [&_[role=slider]]:border-cyan-300"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Text Input */}
                  <div className="space-y-2">
                    <Label htmlFor="content" className="text-white">
                      Your content
                    </Label>
                    <Textarea
                      id="content"
                      placeholder={`Paste your ${contentType} here...`}
                      value={originalText}
                      onChange={(e) => setOriginalText(e.target.value)}
                      className="min-h-[200px] bg-slate-800/50 border-cyan-500/30 text-white placeholder:text-slate-400 focus:border-cyan-400"
                    />
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-4">
                    <Button
                      onClick={handleBack}
                      variant="outline"
                      className="border-cyan-500/30 text-white hover:bg-cyan-500/10"
                    >
                      Back
                    </Button>
                    <Button
                      onClick={generateImprovedVersions}
                      disabled={!originalText.trim() || loading}
                      className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-bold shadow-lg shadow-cyan-500/30"
                    >
                      {loading ? (
                        <>
                          <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                          Boosting your reach...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 mr-2" />
                          Boost My Content
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step 3: Results */}
            {results && (
              <div className="space-y-6">
                <Button
                  onClick={handleBack}
                  variant="outline"
                  className="border-cyan-500/30 text-white hover:bg-cyan-500/10"
                >
                  ← Start Over
                </Button>

                <Tabs defaultValue="versions" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 bg-slate-900/50 border border-cyan-500/30">
                    <TabsTrigger
                      value="versions"
                      className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400 text-white"
                    >
                      Optimized Versions
                    </TabsTrigger>
                    <TabsTrigger
                      value="extras"
                      className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400 text-white"
                    >
                      Extra Boosts
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="versions" className="space-y-4 mt-6">
                    {/* Core Versions */}
                    <ResultCard
                      title="Cleaner Version"
                      content={results.cleaner}
                      id="cleaner"
                      copiedId={copiedId}
                      onCopy={copyToClipboard}
                      onToggleFavorite={toggleFavorite}
                      isFavorite={favoriteIds.has('cleaner')}
                      description="Polished and clear"
                      versionType="cleaner"
                    />
                    <ResultCard
                      title="High-Engagement Version"
                      content={results.highEngagement}
                      id="highEngagement"
                      copiedId={copiedId}
                      onCopy={copyToClipboard}
                      onToggleFavorite={toggleFavorite}
                      isFavorite={favoriteIds.has('highEngagement')}
                      description="Optimized for interaction"
                      versionType="highEngagement"
                    />
                    <ResultCard
                      title="Emotional Version"
                      content={results.emotional}
                      id="emotional"
                      copiedId={copiedId}
                      onCopy={copyToClipboard}
                      onToggleFavorite={toggleFavorite}
                      isFavorite={favoriteIds.has('emotional')}
                      description="Connects deeply"
                      versionType="emotional"
                    />
                    <ResultCard
                      title="Bold & Viral Version"
                      content={results.boldViral}
                      id="boldViral"
                      copiedId={copiedId}
                      onCopy={copyToClipboard}
                      onToggleFavorite={toggleFavorite}
                      isFavorite={favoriteIds.has('boldViral')}
                      description="Attention-grabbing"
                      highlight
                      versionType="boldViral"
                    />
                    <ResultCard
                      title="Short & Punchy"
                      content={results.shortPunchy}
                      id="shortPunchy"
                      copiedId={copiedId}
                      onCopy={copyToClipboard}
                      onToggleFavorite={toggleFavorite}
                      isFavorite={favoriteIds.has('shortPunchy')}
                      description="Quick impact"
                      versionType="shortPunchy"
                    />

                    {/* Platform-Specific */}
                    <div className="pt-4">
                      <h3 className="text-white text-xl font-bold mb-4 flex items-center gap-2">
                        <span>📱</span>
                        Platform-Optimized Versions
                      </h3>
                      <div className="grid gap-4">
                        <ResultCard
                          title="Instagram"
                          content={results.instagram}
                          id="instagram"
                          copiedId={copiedId}
                          onCopy={copyToClipboard}
                          onToggleFavorite={toggleFavorite}
                          isFavorite={favoriteIds.has('instagram')}
                          description="Visual-focused"
                          platform="instagram"
                          versionType="instagram"
                        />
                        <ResultCard
                          title="TikTok"
                          content={results.tiktok}
                          id="tiktok"
                          copiedId={copiedId}
                          onCopy={copyToClipboard}
                          onToggleFavorite={toggleFavorite}
                          isFavorite={favoriteIds.has('tiktok')}
                          description="Trend-friendly"
                          platform="tiktok"
                          versionType="tiktok"
                        />
                        <ResultCard
                          title="YouTube Shorts"
                          content={results.youtubeShorts}
                          id="youtubeShorts"
                          copiedId={copiedId}
                          onCopy={copyToClipboard}
                          onToggleFavorite={toggleFavorite}
                          isFavorite={favoriteIds.has('youtubeShorts')}
                          description="Strong opening"
                          versionType="youtubeShorts"
                        />
                        <ResultCard
                          title="X (Twitter)"
                          content={results.x}
                          id="x"
                          copiedId={copiedId}
                          onCopy={copyToClipboard}
                          onToggleFavorite={toggleFavorite}
                          isFavorite={favoriteIds.has('x')}
                          description="Thread-ready"
                          platform="twitter"
                          versionType="x"
                        />
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="extras" className="space-y-4 mt-6">
                    {/* Hooks */}
                    <Card className="border-cyan-500/30 bg-slate-900/50 backdrop-blur">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                          <span>🎣</span>
                          Hook Suggestions
                        </CardTitle>
                        <CardDescription className="text-cyan-100">
                          Opening lines that grab attention
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        {results.hooks.map((hook, idx) => (
                          <div
                            key={idx}
                            className="p-3 bg-slate-800/50 rounded-lg border border-cyan-500/20 text-white flex items-start justify-between group"
                          >
                            <span className="flex-1">{hook}</span>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => copyToClipboard(hook, `hook-${idx}`)}
                              className="opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              {copiedId === `hook-${idx}` ? (
                                <Check className="w-4 h-4 text-green-400" />
                              ) : (
                                <Copy className="w-4 h-4 text-cyan-400" />
                              )}
                            </Button>
                          </div>
                        ))}
                      </CardContent>
                    </Card>

                    {/* CTA */}
                    <Card className="border-cyan-500/30 bg-slate-900/50 backdrop-blur">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                          <span>🎯</span>
                          Call-to-Action
                        </CardTitle>
                        <CardDescription className="text-cyan-100">
                          Drive engagement with a strong ending
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="p-4 bg-slate-800/50 rounded-lg border border-cyan-500/20 text-white flex items-start justify-between group">
                          <span className="flex-1">{results.cta}</span>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(results.cta, 'cta')}
                            className="opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            {copiedId === 'cta' ? (
                              <Check className="w-4 h-4 text-green-400" />
                            ) : (
                              <Copy className="w-4 h-4 text-cyan-400" />
                            )}
                          </Button>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Hashtags */}
                    <Card className="border-cyan-500/30 bg-slate-900/50 backdrop-blur">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                          <span>#️⃣</span>
                          Better Hashtags
                        </CardTitle>
                        <CardDescription className="text-cyan-100">
                          Tags that increase discoverability
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex flex-wrap gap-2">
                          {results.hashtags.map((tag, idx) => (
                            <Badge
                              key={idx}
                              variant="outline"
                              className="border-cyan-500/30 text-cyan-400 px-3 py-1 cursor-pointer hover:bg-cyan-500/10"
                              onClick={() => copyToClipboard(`#${tag}`, `tag-${idx}`)}
                            >
                              #{tag}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Posting Time */}
                    <Card className="border-cyan-500/30 bg-slate-900/50 backdrop-blur">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                          <span>⏰</span>
                          Ideal Posting Time
                        </CardTitle>
                        <CardDescription className="text-cyan-100">
                          When your audience is most active
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-white text-lg">{results.postingTime}</p>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>
            )}
          </>
        )}

        {/* Footer */}
        <div className="mt-16 text-center text-cyan-100/60 text-sm pb-8">
          <p>Part of the DreamNet Toolkit — simple tools for people who want to grow smarter and faster.</p>
        </div>
      </div>
    </div>
  );
}

interface ResultCardProps {
  title: string;
  content: string;
  id: string;
  copiedId: string | null;
  onCopy: (text: string, id: string) => Promise<void>;
  onToggleFavorite: (id: string, title: string, content: string, versionType: string) => void;
  isFavorite: boolean;
  description?: string;
  highlight?: boolean;
  platform?: 'instagram' | 'tiktok' | 'twitter';
  versionType: string;
}

const ResultCard: FC<ResultCardProps> = ({
  title,
  content,
  id,
  copiedId,
  onCopy,
  onToggleFavorite,
  isFavorite,
  description,
  highlight = false,
  platform,
  versionType,
}) => {
  return (
    <Card
      className={`border-cyan-500/30 bg-slate-900/50 backdrop-blur group hover:shadow-lg hover:shadow-cyan-500/20 transition-all ${
        highlight ? 'border-cyan-400 shadow-lg shadow-cyan-500/30' : ''
      }`}
    >
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-white text-lg">{title}</CardTitle>
            {description && (
              <CardDescription className="text-cyan-100">{description}</CardDescription>
            )}
          </div>
          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onToggleFavorite(id, title, content, versionType)}
              className="opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <Heart
                className={`w-4 h-4 ${isFavorite ? 'fill-pink-400 text-pink-400' : 'text-cyan-400'}`}
              />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onCopy(content, id)}
              className="opacity-0 group-hover:opacity-100 transition-opacity"
            >
              {copiedId === id ? (
                <Check className="w-4 h-4 text-green-400" />
              ) : (
                <Copy className="w-4 h-4 text-cyan-400" />
              )}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-white whitespace-pre-wrap">{content}</p>
        {platform && (
          <div className="pt-2 border-t border-cyan-500/20">
            <SocialShareButtons content={content} platform={platform} />
          </div>
        )}
      </CardContent>
    </Card>
  );
};
