'use client'
import type { FC } from 'react';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, Copy, Check, Trash2 } from 'lucide-react';
import { getFavorites, removeFavorite, type SavedContent } from '@/lib/storage';

export const FavoritesPanel: FC = () => {
  const [favorites, setFavorites] = useState<SavedContent[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    setFavorites(getFavorites());
  }, []);

  const handleRemove = (id: string): void => {
    removeFavorite(id);
    setFavorites(getFavorites());
  };

  const copyToClipboard = async (text: string, id: string): Promise<void> => {
    await navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (favorites.length === 0) {
    return (
      <Card className="border-cyan-500/30 bg-slate-900/50 backdrop-blur shadow-2xl shadow-cyan-500/20">
        <CardHeader>
          <CardTitle className="text-white text-2xl flex items-center gap-2">
            <Heart className="w-6 h-6 text-pink-400" />
            Your Favorites
          </CardTitle>
          <CardDescription className="text-cyan-100">
            Bookmark your best versions to access them anytime
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <Heart className="w-16 h-16 text-cyan-400/30 mx-auto mb-4" />
            <p className="text-cyan-100/60">No favorites yet. Click the heart icon on any version to save it!</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-cyan-500/30 bg-slate-900/50 backdrop-blur shadow-2xl shadow-cyan-500/20">
      <CardHeader>
        <CardTitle className="text-white text-2xl flex items-center gap-2">
          <Heart className="w-6 h-6 text-pink-400" />
          Your Favorites
        </CardTitle>
        <CardDescription className="text-cyan-100">
          {favorites.length} saved {favorites.length === 1 ? 'version' : 'versions'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {favorites.map((fav) => (
            <div
              key={fav.id}
              className="p-4 bg-slate-800/50 rounded-lg border border-cyan-500/20 group hover:border-cyan-400/40 transition-all"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="text-white font-semibold">{fav.title}</h4>
                    <Badge variant="outline" className="text-cyan-400 border-cyan-500/30 text-xs">
                      {fav.contentType}
                    </Badge>
                  </div>
                  <p className="text-xs text-cyan-100/60">
                    {new Date(fav.timestamp).toLocaleDateString()} at{' '}
                    {new Date(fav.timestamp).toLocaleTimeString()}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(fav.content, fav.id)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    {copiedId === fav.id ? (
                      <Check className="w-4 h-4 text-green-400" />
                    ) : (
                      <Copy className="w-4 h-4 text-cyan-400" />
                    )}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleRemove(fav.id)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </Button>
                </div>
              </div>
              <p className="text-white text-sm line-clamp-3">{fav.content}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
