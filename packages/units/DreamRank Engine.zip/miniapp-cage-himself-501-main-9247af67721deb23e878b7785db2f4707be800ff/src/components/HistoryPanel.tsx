'use client'
import type { FC } from 'react';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { History, Trash2, RotateCcw } from 'lucide-react';
import { getHistory, clearHistory, type HistoryItem } from '@/lib/storage';

interface HistoryPanelProps {
  onRestore: (item: HistoryItem) => void;
}

export const HistoryPanel: FC<HistoryPanelProps> = ({ onRestore }) => {
  const [history, setHistory] = useState<HistoryItem[]>([]);

  useEffect(() => {
    setHistory(getHistory());
  }, []);

  const handleClearHistory = (): void => {
    if (confirm('Clear all history? This cannot be undone.')) {
      clearHistory();
      setHistory([]);
    }
  };

  const handleRestore = (item: HistoryItem): void => {
    onRestore(item);
  };

  if (history.length === 0) {
    return (
      <Card className="border-cyan-500/30 bg-slate-900/50 backdrop-blur shadow-2xl shadow-cyan-500/20">
        <CardHeader>
          <CardTitle className="text-white text-2xl flex items-center gap-2">
            <History className="w-6 h-6 text-cyan-400" />
            Your History
          </CardTitle>
          <CardDescription className="text-cyan-100">
            View and restore your past optimizations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <History className="w-16 h-16 text-cyan-400/30 mx-auto mb-4" />
            <p className="text-cyan-100/60">No history yet. Start boosting content to build your history!</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-cyan-500/30 bg-slate-900/50 backdrop-blur shadow-2xl shadow-cyan-500/20">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-white text-2xl flex items-center gap-2">
              <History className="w-6 h-6 text-cyan-400" />
              Your History
            </CardTitle>
            <CardDescription className="text-cyan-100">
              {history.length} past {history.length === 1 ? 'optimization' : 'optimizations'}
            </CardDescription>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleClearHistory}
            className="border-red-500/30 text-red-400 hover:bg-red-500/10"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Clear All
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {history.map((item) => (
            <div
              key={item.id}
              className="p-4 bg-slate-800/50 rounded-lg border border-cyan-500/20 group hover:border-cyan-400/40 transition-all"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline" className="text-cyan-400 border-cyan-500/30 text-xs">
                      {item.contentType}
                    </Badge>
                    <p className="text-xs text-cyan-100/60">
                      {new Date(item.timestamp).toLocaleDateString()} at{' '}
                      {new Date(item.timestamp).toLocaleTimeString()}
                    </p>
                  </div>
                  <p className="text-white text-sm line-clamp-2">{item.originalText}</p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleRestore(item)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <RotateCcw className="w-4 h-4 text-cyan-400" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
