'use client'
import type { FC } from 'react';
import { Button } from '@/components/ui/button';
import { Share2 } from 'lucide-react';

interface SocialShareButtonsProps {
  content: string;
  platform?: 'instagram' | 'tiktok' | 'twitter' | 'facebook' | 'linkedin' | 'all';
}

export const SocialShareButtons: FC<SocialShareButtonsProps> = ({ content, platform = 'all' }) => {
  const shareToTwitter = (): void => {
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(content)}`;
    window.open(twitterUrl, '_blank', 'width=550,height=420');
  };

  const shareToFacebook = (): void => {
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?quote=${encodeURIComponent(content)}`;
    window.open(facebookUrl, '_blank', 'width=550,height=420');
  };

  const shareToLinkedIn = (): void => {
    const linkedInUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.href)}&summary=${encodeURIComponent(content)}`;
    window.open(linkedInUrl, '_blank', 'width=550,height=420');
  };

  const shareToClipboard = async (): Promise<void> => {
    await navigator.clipboard.writeText(content);
    alert('Copied! Open Instagram/TikTok to paste your content.');
  };

  const shareViaWebShare = async (): Promise<void> => {
    if (navigator.share) {
      try {
        await navigator.share({
          text: content,
        });
      } catch (error) {
        console.error('Error sharing:', error);
      }
    } else {
      await shareToClipboard();
    }
  };

  if (platform === 'instagram' || platform === 'tiktok') {
    return (
      <Button
        size="sm"
        onClick={shareToClipboard}
        variant="outline"
        className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
      >
        <Share2 className="w-4 h-4 mr-2" />
        Copy for {platform === 'instagram' ? 'Instagram' : 'TikTok'}
      </Button>
    );
  }

  if (platform === 'twitter') {
    return (
      <Button
        size="sm"
        onClick={shareToTwitter}
        variant="outline"
        className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
      >
        <Share2 className="w-4 h-4 mr-2" />
        Post to X
      </Button>
    );
  }

  if (platform === 'facebook') {
    return (
      <Button
        size="sm"
        onClick={shareToFacebook}
        variant="outline"
        className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
      >
        <Share2 className="w-4 h-4 mr-2" />
        Share on Facebook
      </Button>
    );
  }

  if (platform === 'linkedin') {
    return (
      <Button
        size="sm"
        onClick={shareToLinkedIn}
        variant="outline"
        className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
      >
        <Share2 className="w-4 h-4 mr-2" />
        Share on LinkedIn
      </Button>
    );
  }

  return (
    <div className="flex flex-wrap gap-2">
      <Button
        size="sm"
        onClick={shareToTwitter}
        variant="outline"
        className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
      >
        X
      </Button>
      <Button
        size="sm"
        onClick={shareToFacebook}
        variant="outline"
        className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
      >
        Facebook
      </Button>
      <Button
        size="sm"
        onClick={shareToLinkedIn}
        variant="outline"
        className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
      >
        LinkedIn
      </Button>
      <Button
        size="sm"
        onClick={shareViaWebShare}
        variant="outline"
        className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
      >
        <Share2 className="w-4 h-4 mr-2" />
        More
      </Button>
    </div>
  );
};
