'use client'
import type { FC } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { TrendingUp } from 'lucide-react';

interface Template {
  id: string;
  title: string;
  category: string;
  template: string;
  tags: string[];
}

const templates: Template[] = [
  {
    id: '1',
    title: 'The Hook Challenge',
    category: 'Viral',
    template: 'Nobody talks about [problem], but here\'s what actually works...',
    tags: ['viral', 'engagement', 'educational'],
  },
  {
    id: '2',
    title: 'Before & After',
    category: 'Transformation',
    template: 'I went from [bad state] to [good state] in [timeframe]. Here\'s exactly how...',
    tags: ['transformation', 'inspirational', 'story'],
  },
  {
    id: '3',
    title: 'Controversial Take',
    category: 'Bold',
    template: 'Unpopular opinion: [statement]. Here\'s why everyone gets it wrong...',
    tags: ['bold', 'debate', 'engagement'],
  },
  {
    id: '4',
    title: 'List That Delivers',
    category: 'Educational',
    template: '[Number] things I wish I knew about [topic] before [event]',
    tags: ['educational', 'listicle', 'value'],
  },
  {
    id: '5',
    title: 'Story Hook',
    category: 'Storytelling',
    template: 'I made a [big mistake] that changed everything. Let me explain...',
    tags: ['story', 'emotional', 'relatable'],
  },
  {
    id: '6',
    title: 'The Reality Check',
    category: 'Truth Bomb',
    template: 'Everyone tells you to [common advice], but nobody mentions [harsh truth]',
    tags: ['truth', 'real', 'authentic'],
  },
  {
    id: '7',
    title: 'Quick Win Formula',
    category: 'Actionable',
    template: 'Do this for [timeframe] and watch [desired outcome] happen. No fluff, just results.',
    tags: ['actionable', 'results', 'simple'],
  },
  {
    id: '8',
    title: 'Pattern Interrupt',
    category: 'Attention',
    template: 'Stop doing [common action]. Instead, try [better alternative] and thank me later.',
    tags: ['attention', 'practical', 'direct'],
  },
];

interface TrendingTemplatesProps {
  onUseTemplate: (template: string) => void;
}

export const TrendingTemplates: FC<TrendingTemplatesProps> = ({ onUseTemplate }) => {
  return (
    <Card className="border-cyan-500/30 bg-slate-900/50 backdrop-blur shadow-2xl shadow-cyan-500/20">
      <CardHeader>
        <CardTitle className="text-white text-2xl flex items-center gap-2">
          <TrendingUp className="w-6 h-6 text-cyan-400" />
          Trending Templates
        </CardTitle>
        <CardDescription className="text-cyan-100">
          Proven formulas that drive engagement and reach
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          {templates.map((template) => (
            <div
              key={template.id}
              className="p-4 bg-slate-800/50 rounded-lg border border-cyan-500/20 hover:border-cyan-400/40 transition-all group"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h4 className="text-white font-semibold text-lg">{template.title}</h4>
                  <Badge variant="outline" className="text-cyan-400 border-cyan-500/30 mt-1">
                    {template.category}
                  </Badge>
                </div>
                <Button
                  size="sm"
                  onClick={() => onUseTemplate(template.template)}
                  className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white"
                >
                  Use This
                </Button>
              </div>
              <p className="text-cyan-100 italic mb-3">&quot;{template.template}&quot;</p>
              <div className="flex flex-wrap gap-2">
                {template.tags.map((tag) => (
                  <span
                    key={tag}
                    className="text-xs px-2 py-1 rounded bg-cyan-500/10 text-cyan-300"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
