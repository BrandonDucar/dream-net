export interface SavedContent {
  id: string;
  title: string;
  content: string;
  contentType: string;
  versionType: string;
  timestamp: number;
  isFavorite: boolean;
}

export interface HistoryItem {
  id: string;
  contentType: string;
  originalText: string;
  timestamp: number;
  results: {
    cleaner: string;
    highEngagement: string;
    emotional: string;
    boldViral: string;
    shortPunchy: string;
    instagram: string;
    tiktok: string;
    youtubeShorts: string;
    x: string;
    hooks: string[];
    cta: string;
    hashtags: string[];
    postingTime: string;
  };
}

export const saveFavorite = (item: SavedContent): void => {
  const favorites = getFavorites();
  favorites.push(item);
  localStorage.setItem('dreamrank-favorites', JSON.stringify(favorites));
};

export const removeFavorite = (id: string): void => {
  const favorites = getFavorites();
  const filtered = favorites.filter((f) => f.id !== id);
  localStorage.setItem('dreamrank-favorites', JSON.stringify(filtered));
};

export const getFavorites = (): SavedContent[] => {
  if (typeof window === 'undefined') return [];
  const stored = localStorage.getItem('dreamrank-favorites');
  return stored ? JSON.parse(stored) as SavedContent[] : [];
};

export const saveToHistory = (item: HistoryItem): void => {
  const history = getHistory();
  history.unshift(item);
  // Keep only last 20 items
  const trimmed = history.slice(0, 20);
  localStorage.setItem('dreamrank-history', JSON.stringify(trimmed));
};

export const getHistory = (): HistoryItem[] => {
  if (typeof window === 'undefined') return [];
  const stored = localStorage.getItem('dreamrank-history');
  return stored ? JSON.parse(stored) as HistoryItem[] : [];
};

export const clearHistory = (): void => {
  localStorage.setItem('dreamrank-history', JSON.stringify([]));
};
