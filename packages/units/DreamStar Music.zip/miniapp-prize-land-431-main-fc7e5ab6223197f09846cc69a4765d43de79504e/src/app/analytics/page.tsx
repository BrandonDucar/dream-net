'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown,
  Brain,
  Target,
  Globe,
  Users,
  Music,
  Eye,
  Heart,
  Download,
  Share2,
  Calendar,
  Zap,
  AlertTriangle,
  CheckCircle,
  Clock
} from 'lucide-react'
import { PageLayout } from '@/components/layout/PageLayout'

interface AnalyticsData {
  totalPlays: number
  totalLikes: number
  totalEarnings: number
  growthRate: number
  topGenres: Array<{
    name: string
    percentage: number
    trend: 'up' | 'down' | 'stable'
  }>
  audienceInsights: Array<{
    metric: string
    value: string
    change: number
  }>
}

interface MarketTrend {
  genre: string
  popularity: number
  growth: number
  opportunity: 'high' | 'medium' | 'low'
  description: string
}

interface Prediction {
  title: string
  confidence: number
  impact: 'high' | 'medium' | 'low'
  description: string
  category: 'trend' | 'audience' | 'revenue'
}

const mockAnalytics: AnalyticsData = {
  totalPlays: 45892,
  totalLikes: 3247,
  totalEarnings: 567.89,
  growthRate: 23.5,
  topGenres: [
    { name: 'Electronic', percentage: 35, trend: 'up' },
    { name: 'Hip Hop', percentage: 28, trend: 'up' },
    { name: 'Jazz', percentage: 18, trend: 'stable' },
    { name: 'Country', percentage: 12, trend: 'down' },
    { name: 'Rock', percentage: 7, trend: 'stable' }
  ],
  audienceInsights: [
    { metric: 'Peak Listening Hours', value: '8-10 PM EST', change: 15 },
    { metric: 'Top Location', value: 'Los Angeles, CA', change: 8 },
    { metric: 'Avg Session Length', value: '4.2 minutes', change: 12 },
    { metric: 'Return Rate', value: '68%', change: -3 }
  ]
}

const mockMarketTrends: MarketTrend[] = [
  {
    genre: 'AI-Generated Pop',
    popularity: 89,
    growth: 45.2,
    opportunity: 'high',
    description: 'AI-generated pop tracks are seeing massive growth with 45% increase in plays'
  },
  {
    genre: 'Synthwave Revival',
    popularity: 72,
    growth: 28.7,
    opportunity: 'high',
    description: 'Nostalgic synthwave is making a comeback among Gen Z listeners'
  },
  {
    genre: 'Lo-Fi Hip Hop',
    popularity: 84,
    growth: 12.3,
    opportunity: 'medium',
    description: 'Steady growth continues in the study/work music category'
  },
  {
    genre: 'Country Trap',
    popularity: 58,
    growth: -5.2,
    opportunity: 'low',
    description: 'Genre fusion showing signs of saturation, consider pivot'
  }
]

const mockPredictions: Prediction[] = [
  {
    title: 'Your Electronic Tracks Will Peak Next Week',
    confidence: 89,
    impact: 'high',
    description: 'AI models predict a 40% increase in electronic music engagement based on seasonal patterns and current trends.',
    category: 'trend'
  },
  {
    title: 'Audience Age Demographic Shifting Younger',
    confidence: 76,
    impact: 'medium',
    description: 'Your audience is trending 15% younger, suggesting adaptation to Gen Z preferences could boost engagement.',
    category: 'audience'
  },
  {
    title: 'Revenue Forecast: +$120 This Month',
    confidence: 82,
    impact: 'high',
    description: 'Current trajectory suggests strong revenue growth if you maintain release schedule.',
    category: 'revenue'
  }
]

export default function AnalyticsPage(): JSX.Element {
  const [selectedTab, setSelectedTab] = useState<'overview' | 'trends' | 'predictions' | 'audience'>('overview')
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | '1y'>('30d')

  const getOpportunityColor = (opportunity: MarketTrend['opportunity']) => {
    switch (opportunity) {
      case 'high': return 'bg-green-500/20 text-green-400 border-green-500/30'
      case 'medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
      case 'low': return 'bg-red-500/20 text-red-400 border-red-500/30'
    }
  }

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return 'text-green-400'
    if (confidence >= 60) return 'text-yellow-400'
    return 'text-red-400'
  }

  const getImpactIcon = (impact: Prediction['impact']) => {
    switch (impact) {
      case 'high': return <TrendingUp className="w-4 h-4 text-green-400" />
      case 'medium': return <TrendingUp className="w-4 h-4 text-yellow-400" />
      case 'low': return <TrendingDown className="w-4 h-4 text-gray-400" />
    }
  }

  return (
    <PageLayout
      title="Advanced Analytics"
      description="AI-powered insights and predictions for your music portfolio"
      gradient="from-cyan-400 to-purple-600"
    >
      {/* Time Range Selector */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Button
            variant={timeRange === '7d' ? 'default' : 'outline'}
            onClick={() => setTimeRange('7d')}
            size="sm"
          >
            7 Days
          </Button>
          <Button
            variant={timeRange === '30d' ? 'default' : 'outline'}
            onClick={() => setTimeRange('30d')}
            size="sm"
          >
            30 Days
          </Button>
          <Button
            variant={timeRange === '90d' ? 'default' : 'outline'}
            onClick={() => setTimeRange('90d')}
            size="sm"
          >
            90 Days
          </Button>
          <Button
            variant={timeRange === '1y' ? 'default' : 'outline'}
            onClick={() => setTimeRange('1y')}
            size="sm"
          >
            1 Year
          </Button>
        </div>
        
        <Badge className="bg-gradient-to-r from-cyan-500/20 to-purple-600/20 text-cyan-300 border-cyan-500/30">
          <Brain className="w-3 h-3 mr-1" />
          AI Analytics Active
        </Badge>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card className="bg-gradient-to-br from-blue-900/50 to-blue-800/30 border border-blue-500/30">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-blue-500/20 rounded-lg backdrop-blur-sm">
                <Music className="w-5 h-5 text-blue-400" />
              </div>
              <Badge className="bg-green-500/20 text-green-400 border-0">
                +{mockAnalytics.growthRate}%
              </Badge>
            </div>
            <div className="space-y-1">
              <p className="text-2xl font-bold text-white">{mockAnalytics.totalPlays.toLocaleString()}</p>
              <p className="text-sm text-gray-400">Total Plays</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-pink-900/50 to-pink-800/30 border border-pink-500/30">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-pink-500/20 rounded-lg backdrop-blur-sm">
                <Heart className="w-5 h-5 text-pink-400" />
              </div>
              <Badge className="bg-green-500/20 text-green-400 border-0">
                +18.2%
              </Badge>
            </div>
            <div className="space-y-1">
              <p className="text-2xl font-bold text-white">{mockAnalytics.totalLikes.toLocaleString()}</p>
              <p className="text-sm text-gray-400">Total Likes</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-900/50 to-green-800/30 border border-green-500/30">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-green-500/20 rounded-lg backdrop-blur-sm">
                <BarChart3 className="w-5 h-5 text-green-400" />
              </div>
              <Badge className="bg-green-500/20 text-green-400 border-0">
                +32.1%
              </Badge>
            </div>
            <div className="space-y-1">
              <p className="text-2xl font-bold text-white">{mockAnalytics.totalEarnings} FAIR</p>
              <p className="text-sm text-gray-400">Total Earnings</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-900/50 to-purple-800/30 border border-purple-500/30">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-purple-500/20 rounded-lg backdrop-blur-sm">
                <Users className="w-5 h-5 text-purple-400" />
              </div>
              <Badge className="bg-green-500/20 text-green-400 border-0">
                +12.7%
              </Badge>
            </div>
            <div className="space-y-1">
              <p className="text-2xl font-bold text-white">2.4K</p>
              <p className="text-sm text-gray-400">Active Listeners</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Analytics Tabs */}
      <Tabs value={selectedTab} onValueChange={(value) => setSelectedTab(value as any)} className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-gray-900/50">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="trends" className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Market Trends
          </TabsTrigger>
          <TabsTrigger value="predictions" className="flex items-center gap-2">
            <Brain className="w-4 h-4" />
            AI Predictions
          </TabsTrigger>
          <TabsTrigger value="audience" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Audience
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Genre Performance */}
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Music className="w-5 h-5" />
                  Genre Performance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockAnalytics.topGenres.map((genre, index) => (
                    <div key={genre.name} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-white">{genre.name}</span>
                          {genre.trend === 'up' && <TrendingUp className="w-3 h-3 text-green-400" />}
                          {genre.trend === 'down' && <TrendingDown className="w-3 h-3 text-red-400" />}
                          {genre.trend === 'stable' && <div className="w-3 h-3 rounded-full bg-gray-400" />}
                        </div>
                        <span className="text-sm text-gray-400">{genre.percentage}%</span>
                      </div>
                      <Progress value={genre.percentage} className="w-full" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Audience Insights */}
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Audience Insights
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockAnalytics.audienceInsights.map((insight, index) => (
                    <div key={insight.metric} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                      <div>
                        <p className="text-sm text-gray-400">{insight.metric}</p>
                        <p className="text-white font-semibold">{insight.value}</p>
                      </div>
                      <Badge className={`${
                        insight.change > 0 ? 'bg-green-500/20 text-green-400' : 
                        insight.change < 0 ? 'bg-red-500/20 text-red-400' : 
                        'bg-gray-500/20 text-gray-400'
                      } border-0`}>
                        {insight.change > 0 ? '+' : ''}{insight.change}%
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Performance Timeline */}
          <Card className="bg-gray-900/50 border-gray-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Performance Timeline
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <BarChart3 className="w-16 h-16 text-white/20 mx-auto mb-4" />
                <p className="text-white/60">Advanced chart visualization</p>
                <p className="text-white/40 text-sm mt-2">Interactive charts showing plays, likes, and earnings over time</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Market Trends Tab */}
        <TabsContent value="trends" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {mockMarketTrends.map((trend, index) => (
              <Card key={trend.genre} className="bg-gray-900/50 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-2">{trend.genre}</h3>
                      <Badge className={getOpportunityColor(trend.opportunity)}>
                        {trend.opportunity.toUpperCase()} OPPORTUNITY
                      </Badge>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-white">{trend.popularity}%</p>
                      <p className="text-sm text-gray-400">Popularity</p>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span className="text-gray-400">Growth Rate</span>
                      <span className={`font-semibold ${trend.growth > 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {trend.growth > 0 ? '+' : ''}{trend.growth}%
                      </span>
                    </div>
                    <Progress value={Math.abs(trend.growth)} className="w-full" />
                  </div>

                  <p className="text-sm text-white/80">{trend.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* AI Predictions Tab */}
        <TabsContent value="predictions" className="space-y-6">
          <div className="space-y-4">
            {mockPredictions.map((prediction, index) => (
              <Card key={prediction.title} className="bg-gray-900/50 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-2">
                          {getImpactIcon(prediction.impact)}
                          <h3 className="text-lg font-semibold text-white">{prediction.title}</h3>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={`bg-blue-500/20 text-blue-400 border-blue-500/30`}>
                            {prediction.category.toUpperCase()}
                          </Badge>
                          <Badge className={`bg-white/10 ${getConfidenceColor(prediction.confidence)}`}>
                            {prediction.confidence}% confidence
                          </Badge>
                        </div>
                      </div>
                      
                      <p className="text-white/80 mb-4">{prediction.description}</p>
                      
                      <div className="flex items-center gap-2">
                        <Progress value={prediction.confidence} className="flex-1" />
                        <span className="text-sm text-gray-400">Confidence</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* AI Recommendations */}
          <Card className="bg-gradient-to-r from-purple-900/50 to-cyan-900/50 border-purple-500/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5" />
                AI Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <div>
                    <p className="text-sm font-medium text-white">Focus on Electronic Genre</p>
                    <p className="text-xs text-white/70">Your electronic tracks are performing 35% better than average</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                  <AlertTriangle className="w-5 h-5 text-yellow-400" />
                  <div>
                    <p className="text-sm font-medium text-white">Optimize Release Timing</p>
                    <p className="text-xs text-white/70">Release tracks on Tuesday-Thursday for maximum engagement</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3 p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                  <Clock className="w-5 h-5 text-blue-400" />
                  <div>
                    <p className="text-sm font-medium text-white">Increase Track Length</p>
                    <p className="text-xs text-white/70">Tracks over 3 minutes show 28% higher retention rates</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Audience Tab */}
        <TabsContent value="audience" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Demographics */}
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Demographics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-400">Age 18-24</span>
                      <span className="text-sm text-white">35%</span>
                    </div>
                    <Progress value={35} className="w-full" />
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-400">Age 25-34</span>
                      <span className="text-sm text-white">42%</span>
                    </div>
                    <Progress value={42} className="w-full" />
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-400">Age 35-44</span>
                      <span className="text-sm text-white">18%</span>
                    </div>
                    <Progress value={18} className="w-full" />
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-400">Age 45+</span>
                      <span className="text-sm text-white">5%</span>
                    </div>
                    <Progress value={5} className="w-full" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Geographic Distribution */}
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="w-5 h-5" />
                  Top Locations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <span className="text-white">Los Angeles, CA</span>
                    <Badge className="bg-blue-500/20 text-blue-400">28%</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <span className="text-white">New York, NY</span>
                    <Badge className="bg-blue-500/20 text-blue-400">22%</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <span className="text-white">London, UK</span>
                    <Badge className="bg-blue-500/20 text-blue-400">15%</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <span className="text-white">Tokyo, JP</span>
                    <Badge className="bg-blue-500/20 text-blue-400">12%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Listening Patterns */}
          <Card className="bg-gray-900/50 border-gray-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Listening Patterns
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <Clock className="w-16 h-16 text-white/20 mx-auto mb-4" />
                <p className="text-white/60">Time-based listening analysis</p>
                <p className="text-white/40 text-sm mt-2">Hourly breakdown of when your audience is most active</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </PageLayout>
  )
}