import { NextRequest, NextResponse } from 'next/server'

interface MintRequest {
  songId: string
  mintAmount: number
  mintPrice: number
  royaltyPercentage: number
  description: string
  blockchain: 'base' | 'ethereum'
  metadata: {
    title: string
    artist: string
    genre: string[]
    duration: number
    coverArt: string
    inspirations: string[]
  }
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body: MintRequest = await request.json()
    
    // Validate required fields
    if (!body.songId || !body.mintAmount || body.mintPrice === undefined) {
      return NextResponse.json(
        { error: 'Missing required fields: songId, mintAmount, mintPrice' },
        { status: 400 }
      )
    }

    // Validate mint amount
    if (body.mintAmount < 1 || body.mintAmount > 1000) {
      return NextResponse.json(
        { error: 'Mint amount must be between 1 and 1000' },
        { status: 400 }
      )
    }

    // Validate mint price
    if (body.mintPrice < 0.001) {
      return NextResponse.json(
        { error: 'Mint price must be at least 0.001 ETH' },
        { status: 400 }
      )
    }

    // Validate royalty percentage
    if (body.royaltyPercentage < 0 || body.royaltyPercentage > 20) {
      return NextResponse.json(
        { error: 'Royalty percentage must be between 0% and 20%' },
        { status: 400 }
      )
    }

    // Generate mock NFT data (in a real app, this would interact with smart contracts)
    const tokenId = Math.floor(Math.random() * 10000) + 1000
    const contractAddress = body.blockchain === 'base' 
      ? '0x' + Math.random().toString(16).substring(2, 42).padStart(40, '0')
      : '0x' + Math.random().toString(16).substring(2, 42).padStart(40, '0')
    
    const txHash = '0x' + Math.random().toString(16).substring(2, 66).padStart(64, '0')

    // Calculate rarity based on supply
    let rarity: 'common' | 'rare' | 'epic' | 'legendary'
    if (body.mintAmount <= 10) rarity = 'legendary'
    else if (body.mintAmount <= 25) rarity = 'epic'
    else if (body.mintAmount <= 100) rarity = 'rare'
    else rarity = 'common'

    // Prepare NFT metadata (would be uploaded to IPFS in a real app)
    const metadata = {
      name: body.metadata.title,
      description: body.description || `A holographic music NFT created by ${body.metadata.artist}`,
      image: body.metadata.coverArt,
      animation_url: `/api/audio/${body.songId}`, // Audio file URL
      attributes: [
        { trait_type: 'Artist', value: body.metadata.artist },
        { trait_type: 'Genre', value: body.metadata.genre.join(', ') },
        { trait_type: 'Duration', value: `${Math.floor(body.metadata.duration / 60)}:${(body.metadata.duration % 60).toString().padStart(2, '0')}` },
        { trait_type: 'Rarity', value: rarity },
        { trait_type: 'Supply', value: body.mintAmount },
        { trait_type: 'Blockchain', value: body.blockchain },
        { trait_type: 'AI Generated', value: 'Yes' },
        { trait_type: 'Royalty', value: `${body.royaltyPercentage}%` },
        ...(body.metadata.inspirations.length > 0 ? [{ trait_type: 'Inspirations', value: body.metadata.inspirations.join(', ') }] : [])
      ],
      external_url: `https://sonicprism.app/nft/${tokenId}`,
      seller_fee_basis_points: Math.round(body.royaltyPercentage * 100), // For OpenSea compatibility
      fee_recipient: 'creator_wallet_address' // Would be actual creator wallet
    }

    // In a real application, you would:
    // 1. Upload metadata to IPFS
    // 2. Deploy or interact with NFT smart contract
    // 3. Mint the NFTs on the specified blockchain
    // 4. Store transaction details in database
    // 5. Update user's NFT collection

    // Simulate blockchain transaction delay
    await new Promise(resolve => setTimeout(resolve, 2000))

    // Mock success response
    const response = {
      success: true,
      tokenId,
      contractAddress,
      txHash,
      blockchain: body.blockchain,
      mintAmount: body.mintAmount,
      mintPrice: body.mintPrice,
      rarity,
      metadata,
      opensea_url: `https://opensea.io/assets/${body.blockchain === 'base' ? 'base' : 'ethereum'}/${contractAddress}/${tokenId}`,
      etherscan_url: body.blockchain === 'base' 
        ? `https://basescan.org/tx/${txHash}`
        : `https://etherscan.io/tx/${txHash}`
    }

    return NextResponse.json(response, { status: 200 })

  } catch (error) {
    console.error('NFT Mint Error:', error)
    return NextResponse.json(
      { error: 'Failed to mint NFT. Please try again.' },
      { status: 500 }
    )
  }
}

export async function GET(): Promise<NextResponse> {
  return NextResponse.json(
    { error: 'Method not allowed. Use POST to mint NFTs.' },
    { status: 405 }
  )
}