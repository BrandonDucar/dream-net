import { NextRequest, NextResponse } from 'next/server'

interface CryptoPaymentRequest {
  tier: 'pro' | 'enterprise'
  billingCycle: 'monthly' | 'yearly'
  usdAmount: number
  blockchain: 'base' | 'ethereum'
}

// Mock exchange rates (in a real app, you'd fetch from an API like CoinGecko)
const MOCK_EXCHANGE_RATES = {
  ETH_USD: 2450.00,
  USDC_USD: 1.00
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body: CryptoPaymentRequest = await request.json()
    
    // Validate request
    if (!body.tier || !body.billingCycle || !body.usdAmount || !body.blockchain) {
      return NextResponse.json(
        { error: 'Missing required fields: tier, billingCycle, usdAmount, blockchain' },
        { status: 400 }
      )
    }

    if (body.usdAmount <= 0) {
      return NextResponse.json(
        { error: 'Amount must be greater than 0' },
        { status: 400 }
      )
    }

    // Calculate crypto amounts
    const ethAmount = (body.usdAmount / MOCK_EXCHANGE_RATES.ETH_USD).toFixed(6)
    const usdcAmount = (body.usdAmount / MOCK_EXCHANGE_RATES.USDC_USD).toFixed(2)

    // Generate mock payment address (in a real app, you'd generate a unique address per payment)
    const paymentAddress = body.blockchain === 'base' 
      ? '0x' + Math.random().toString(16).substring(2, 42).padStart(40, '0')
      : '0x' + Math.random().toString(16).substring(2, 42).padStart(40, '0')

    // Generate payment ID for tracking
    const paymentId = `crypto_payment_${Math.random().toString(36).substring(7)}`
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000) // 1 hour from now

    // In a real implementation, you would:
    // 1. Generate a unique payment address for this transaction
    // 2. Set up blockchain monitoring to watch for payments
    // 3. Store payment details in database
    // 4. Set up webhooks for payment confirmation
    // 5. Handle payment expiration

    const response = {
      payment_id: paymentId,
      payment_address: paymentAddress,
      blockchain: body.blockchain,
      amounts: {
        usd: body.usdAmount,
        eth: parseFloat(ethAmount),
        usdc: parseFloat(usdcAmount)
      },
      exchange_rates: {
        eth_usd: MOCK_EXCHANGE_RATES.ETH_USD,
        usdc_usd: MOCK_EXCHANGE_RATES.USDC_USD
      },
      expires_at: expiresAt.toISOString(),
      payment_options: [
        {
          currency: 'ETH',
          amount: ethAmount,
          contract_address: null, // Native ETH
          decimals: 18
        },
        {
          currency: 'USDC',
          amount: usdcAmount,
          contract_address: body.blockchain === 'base' 
            ? '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913' // USDC on Base
            : '0xA0b86a33E6441C41a07BDe8ae6B26Bc7E42eBB9e', // USDC on Ethereum
          decimals: 6
        }
      ],
      instructions: {
        step1: `Send exactly ${ethAmount} ETH or ${usdcAmount} USDC to the payment address`,
        step2: 'Payment will be confirmed automatically within 1-5 minutes',
        step3: 'Your subscription will be activated immediately after confirmation',
        warning: 'Only send the exact amount. Overpayments will be refunded, underpayments will be rejected.'
      },
      metadata: {
        tier: body.tier,
        billingCycle: body.billingCycle,
        userId: 'user_id_placeholder' // Would be actual user ID
      },
      status_url: `/api/payments/crypto/status/${paymentId}`,
      explorer_urls: {
        base: body.blockchain === 'base' ? `https://basescan.org/address/${paymentAddress}` : null,
        ethereum: body.blockchain === 'ethereum' ? `https://etherscan.io/address/${paymentAddress}` : null
      }
    }

    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800))

    return NextResponse.json(response, { status: 200 })

  } catch (error) {
    console.error('Crypto Payment Error:', error)
    return NextResponse.json(
      { error: 'Failed to create crypto payment' },
      { status: 500 }
    )
  }
}

export async function GET(): Promise<NextResponse> {
  return NextResponse.json(
    { error: 'Method not allowed. Use POST to create crypto payments.' },
    { status: 405 }
  )
}