import { NextRequest, NextResponse } from 'next/server';
import { aiChat } from '@/lib/thirdweb/thirdweb-chat-api';

// Base chain configuration (8453)
const BASE_CHAIN_ID = 8453;

// Subscription pricing in ETH (Base network)
const CRYPTO_PRICES = {
  'pro-monthly': '0.02',     // ~$50 at $2500 ETH
  'pro-yearly': '0.15',      // ~$375 (25% discount)
  'enterprise-monthly': '0.06', // ~$150
  'enterprise-yearly': '0.5',   // ~$1250 (30% discount)
};

// Smart contract address for payments (mock)
const PAYMENT_CONTRACT = '0x1234567890123456789012345678901234567890';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, tier, billingCycle, userAddress } = body;

    switch (action) {
      case 'create-payment-intent':
        return await createPaymentIntent(tier, billingCycle, userAddress);
      
      case 'verify-payment':
        return await verifyPayment(body.transactionHash, userAddress);
      
      case 'get-pricing':
        return await getPricing();
      
      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }
  } catch (error) {
    console.error('Crypto payment error:', error);
    return NextResponse.json(
      { error: 'Crypto payment processing failed' },
      { status: 500 }
    );
  }
}

async function createPaymentIntent(tier: string, billingCycle: string, userAddress: string) {
  const priceKey = `${tier}-${billingCycle}` as keyof typeof CRYPTO_PRICES;
  const amount = CRYPTO_PRICES[priceKey];
  
  if (!amount) {
    return NextResponse.json({ error: 'Invalid pricing tier' }, { status: 400 });
  }

  try {
    // Use Thirdweb AI to create payment transaction
    const response = await aiChat({
      messages: [
        {
          role: 'user',
          content: `Create a payment transaction to send ${amount} ETH from ${userAddress} to ${PAYMENT_CONTRACT} on Base network for ${tier} ${billingCycle} subscription`
        }
      ],
      context: {
        chain_ids: [BASE_CHAIN_ID],
        from: userAddress,
      }
    });

    // Extract transaction data from response
    const transactionAction = response.actions.find(action => action.type === 'sign_transaction');
    
    if (!transactionAction || transactionAction.type !== 'sign_transaction') {
      throw new Error('No transaction prepared by AI');
    }

    return NextResponse.json({
      transaction: transactionAction.data,
      amount: amount,
      tier: tier,
      billingCycle: billingCycle,
      recipient: PAYMENT_CONTRACT,
      sessionId: response.session_id,
      requestId: response.request_id,
    });

  } catch (error) {
    console.error('Transaction preparation failed:', error);
    return NextResponse.json(
      { error: 'Failed to prepare transaction' },
      { status: 500 }
    );
  }
}

async function verifyPayment(transactionHash: string, userAddress: string) {
  try {
    // Use Thirdweb AI to verify transaction
    const response = await aiChat({
      messages: [
        {
          role: 'user',
          content: `Verify transaction ${transactionHash} on Base network and confirm payment from ${userAddress}`
        }
      ],
      context: {
        chain_ids: [BASE_CHAIN_ID],
      }
    });

    // Mock verification for demo
    // In production, parse the AI response to get transaction status
    const isVerified = true; // Mock success
    const paymentAmount = '0.02'; // Mock amount
    
    if (isVerified) {
      // Update user subscription
      return NextResponse.json({
        verified: true,
        amount: paymentAmount,
        transactionHash: transactionHash,
        blockNumber: 12345678, // Mock block number
        timestamp: new Date().toISOString(),
      });
    } else {
      return NextResponse.json({
        verified: false,
        error: 'Transaction not found or invalid'
      }, { status: 400 });
    }

  } catch (error) {
    console.error('Payment verification failed:', error);
    return NextResponse.json(
      { error: 'Failed to verify payment' },
      { status: 500 }
    );
  }
}

async function getPricing() {
  return NextResponse.json({
    prices: CRYPTO_PRICES,
    currency: 'ETH',
    network: 'Base',
    chainId: BASE_CHAIN_ID,
    contract: PAYMENT_CONTRACT,
  });
}

// Webhook for monitoring payments
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { transactionHash, userAddress, amount } = body;

    // Monitor payment using Thirdweb AI
    const response = await aiChat({
      messages: [
        {
          role: 'user',
          content: `Monitor transaction ${transactionHash} for completion and notify when confirmed`
        }
      ],
      context: {
        chain_ids: [BASE_CHAIN_ID],
      }
    });

    const monitorAction = response.actions.find(action => action.type === 'monitor_transaction');
    
    if (monitorAction && monitorAction.type === 'monitor_transaction') {
      return NextResponse.json({
        monitoring: true,
        transactionId: monitorAction.data.transaction_id,
        sessionId: response.session_id,
      });
    }

    return NextResponse.json({ monitoring: false });

  } catch (error) {
    console.error('Payment monitoring failed:', error);
    return NextResponse.json(
      { error: 'Failed to monitor payment' },
      { status: 500 }
    );
  }
}