'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Heart, Share2, Play, Pause, Download, Zap, Trophy, TrendingUp, Music } from 'lucide-react'
import { toast } from 'sonner'
import { useSubscription } from '@/stores/subscriptionStore'
import { MusicPlayer } from '@/components/music/MusicPlayer'
import { NFTMintDialog } from '@/components/nft/NFTMintDialog'
import { ShareDialog } from '@/components/music/ShareDialog'
import { PageLayout } from '@/components/layout/PageLayout'

interface Song {
  id: string
  title: string
  artist: string
  genre: string[]
  duration: number
  playCount: number
  likes: number
  isLiked: boolean
  audioUrl: string
  coverArt: string
  createdAt: string
  rarity: 'common' | 'rare' | 'epic' | 'legendary'
  mintCount: number
  maxMints: number
  nftPrice: number
  inspirations: string[]
}

const mockSongs: Song[] = [
  {
    id: '1',
    title: 'Neon Dreams',
    artist: 'CyberPhoenix',
    genre: ['Synthwave', 'Electronic'],
    duration: 243,
    playCount: 15420,
    likes: 847,
    isLiked: false,
    audioUrl: '/demo-tracks/neon-dreams.mp3',
    coverArt: 'https://images.unsplash.com/photo-1571330735066-03aaa9429d89?w=300&h=300&fit=crop',
    createdAt: '2024-01-15',
    rarity: 'legendary',
    mintCount: 12,
    maxMints: 50,
    nftPrice: 0.08,
    inspirations: ['Outrun', 'Cyberpunk 2077 OST', 'The Midnight']
  },
  {
    id: '2',
    title: 'Desert Country House',
    artist: 'SonicAlchemist',
    genre: ['Country', 'House', 'Fusion'],
    duration: 198,
    playCount: 8932,
    likes: 623,
    isLiked: true,
    audioUrl: '/demo-tracks/desert-country-house.mp3',
    coverArt: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop',
    createdAt: '2024-01-12',
    rarity: 'epic',
    mintCount: 28,
    maxMints: 100,
    nftPrice: 0.05,
    inspirations: ['ATLiens by OutKast', 'Country Roads', 'Swedish House Mafia']
  },
  {
    id: '3',
    title: 'Holographic Jazz',
    artist: 'QuantumVibes',
    genre: ['Jazz', 'Ambient', 'Electronic'],
    duration: 312,
    playCount: 12156,
    likes: 934,
    isLiked: false,
    audioUrl: '/demo-tracks/holographic-jazz.mp3',
    coverArt: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=300&h=300&fit=crop',
    createdAt: '2024-01-10',
    rarity: 'rare',
    mintCount: 45,
    maxMints: 200,
    nftPrice: 0.03,
    inspirations: ['Miles Davis', 'Boards of Canada', 'Tycho']
  },
  {
    id: '4',
    title: 'Bass Drop Melody',
    artist: 'BeatCrafter',
    genre: ['Dubstep', 'Melodic Bass'],
    duration: 267,
    playCount: 23891,
    likes: 1247,
    isLiked: true,
    audioUrl: '/demo-tracks/bass-drop-melody.mp3',
    coverArt: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop',
    createdAt: '2024-01-08',
    rarity: 'common',
    mintCount: 156,
    maxMints: 500,
    nftPrice: 0.01,
    inspirations: ['Skrillex', 'Illenium', 'Seven Lions']
  }
]

export default function CommunityPage(): JSX.Element {
  const [songs, setSongs] = useState<Song[]>(mockSongs)
  const [currentPlaying, setCurrentPlaying] = useState<string | null>(null)
  const [selectedSong, setSelectedSong] = useState<Song | null>(null)
  const [showMintDialog, setShowMintDialog] = useState<boolean>(false)
  const [showShareDialog, setShowShareDialog] = useState<boolean>(false)
  const [sortBy, setSortBy] = useState<'trending' | 'newest' | 'most-liked'>('trending')
  const { subscription, checkFeatureAccess } = useSubscription()

  const getRarityColor = (rarity: Song['rarity']): string => {
    switch (rarity) {
      case 'legendary': return 'bg-gradient-to-r from-yellow-400 to-orange-500'
      case 'epic': return 'bg-gradient-to-r from-purple-400 to-pink-500'
      case 'rare': return 'bg-gradient-to-r from-blue-400 to-cyan-500'
      default: return 'bg-gradient-to-r from-gray-400 to-gray-600'
    }
  }

  const formatDuration = (seconds: number): string => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const handleLike = async (songId: string): Promise<void> => {
    if (!checkFeatureAccess('social_interactions')) {
      toast.error('Upgrade to Pro to like and interact with community posts!')
      return
    }

    setSongs(prev => prev.map(song => 
      song.id === songId 
        ? { ...song, isLiked: !song.isLiked, likes: song.isLiked ? song.likes - 1 : song.likes + 1 }
        : song
    ))
    toast.success('Added to your favorites!')
  }

  const handlePlay = (song: Song): void => {
    if (!checkFeatureAccess('music_playback')) {
      toast.error('Upgrade to Pro to play community tracks!')
      return
    }

    if (currentPlaying === song.id) {
      setCurrentPlaying(null)
    } else {
      setCurrentPlaying(song.id)
      setSongs(prev => prev.map(s => 
        s.id === song.id ? { ...s, playCount: s.playCount + 1 } : s
      ))
    }
  }

  const handleMint = (song: Song): void => {
    if (!checkFeatureAccess('nft_minting')) {
      toast.error('Upgrade to Enterprise to mint NFTs!')
      return
    }
    setSelectedSong(song)
    setShowMintDialog(true)
  }

  const handleShare = (song: Song): void => {
    setSelectedSong(song)
    setShowShareDialog(true)
  }

  const handleDownload = async (song: Song): Promise<void> => {
    if (!checkFeatureAccess('downloads')) {
      toast.error('Upgrade to Pro to download tracks!')
      return
    }
    
    try {
      const response = await fetch('/api/download-track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ songId: song.id })
      })
      
      if (response.ok) {
        const blob = await response.blob()
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `${song.title} - ${song.artist}.mp3`
        a.click()
        URL.revokeObjectURL(url)
        toast.success('Download started!')
      }
    } catch (error) {
      toast.error('Download failed. Please try again.')
    }
  }

  const sortedSongs = [...songs].sort((a, b) => {
    switch (sortBy) {
      case 'trending':
        return (b.playCount + b.likes) - (a.playCount + a.likes)
      case 'newest':
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      case 'most-liked':
        return b.likes - a.likes
      default:
        return 0
    }
  })

  return (
    <PageLayout
      title="Community Feed"
      description="Discover and collect original music created by our holographic AI community"
      gradient="from-cyan-400 to-purple-600"
    >
      {/* Sort Controls */}
      <div className="flex items-center justify-center gap-4 mb-8">
        <Button
          variant={sortBy === 'trending' ? 'default' : 'outline'}
          onClick={() => setSortBy('trending')}
          className={`flex items-center gap-2 ${
            sortBy === 'trending' 
              ? 'bg-gradient-to-r from-cyan-500 to-purple-600 text-white border-0' 
              : 'bg-white/10 text-white border-white/20 hover:bg-white/20'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          Trending
        </Button>
        <Button
          variant={sortBy === 'newest' ? 'default' : 'outline'}
          onClick={() => setSortBy('newest')}
          className={`${
            sortBy === 'newest' 
              ? 'bg-gradient-to-r from-cyan-500 to-purple-600 text-white border-0' 
              : 'bg-white/10 text-white border-white/20 hover:bg-white/20'
          }`}
        >
          Newest
        </Button>
        <Button
          variant={sortBy === 'most-liked' ? 'default' : 'outline'}
          onClick={() => setSortBy('most-liked')}
          className={`flex items-center gap-2 ${
            sortBy === 'most-liked' 
              ? 'bg-gradient-to-r from-cyan-500 to-purple-600 text-white border-0' 
              : 'bg-white/10 text-white border-white/20 hover:bg-white/20'
          }`}
        >
          <Heart className="w-4 h-4" />
          Most Liked
        </Button>
      </div>

      {/* Songs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sortedSongs.map((song) => (
          <Card key={song.id} className="bg-black/40 backdrop-blur-md border border-white/20 hover:bg-black/60 transition-all duration-300 group hover:scale-105">
              <CardHeader className="pb-4">
                <div className="relative">
                  <img
                    src={song.coverArt}
                    alt={song.title}
                    className="w-full h-48 object-cover rounded-lg mb-4"
                  />
                  <div className={`absolute top-2 right-2 px-2 py-1 rounded-full text-xs font-bold text-white ${getRarityColor(song.rarity)}`}>
                    {song.rarity.toUpperCase()}
                  </div>
                  <div className="absolute bottom-2 right-2 bg-black/70 backdrop-blur-sm rounded-full p-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handlePlay(song)}
                      className="w-8 h-8 hover:bg-white/20"
                    >
                      {currentPlaying === song.id ? (
                        <Pause className="w-4 h-4" />
                      ) : (
                        <Play className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                </div>
                
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg font-bold text-white mb-1">
                      {song.title}
                    </CardTitle>
                    <div className="flex items-center gap-2 mb-2">
                      <Avatar className="w-6 h-6">
                        <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${song.artist}`} />
                        <AvatarFallback>{song.artist[0]}</AvatarFallback>
                      </Avatar>
                      <p className="text-sm text-gray-400">{song.artist}</p>
                    </div>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                {/* Genre Tags */}
                <div className="flex flex-wrap gap-1 mb-3">
                  {song.genre.map((g) => (
                    <Badge key={g} variant="secondary" className="text-xs">
                      {g}
                    </Badge>
                  ))}
                </div>

                {/* Stats */}
                <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
                  <div className="flex items-center gap-4">
                    <span className="flex items-center gap-1">
                      <Play className="w-3 h-3" />
                      {song.playCount.toLocaleString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <Heart className="w-3 h-3" />
                      {song.likes}
                    </span>
                  </div>
                  <span>{formatDuration(song.duration)}</span>
                </div>

                {/* NFT Info */}
                <div className="bg-gray-800/50 rounded-lg p-3 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">NFT Status:</span>
                    <span className="text-green-400 font-semibold">
                      {song.mintCount}/{song.maxMints} minted
                    </span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2 mt-2">
                    <div 
                      className="bg-green-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(song.mintCount / song.maxMints) * 100}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between mt-2 text-xs text-gray-400">
                    <span>Floor: {song.nftPrice} ETH</span>
                    <span className="text-yellow-400">
                      {song.maxMints - song.mintCount < 50 ? 'Almost Sold Out!' : 'Available'}
                    </span>
                  </div>
                </div>

                {/* Inspirations */}
                <div className="mb-4">
                  <p className="text-xs text-gray-500 mb-1">Inspired by:</p>
                  <div className="flex flex-wrap gap-1">
                    {song.inspirations.map((inspiration, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs text-cyan-400 border-cyan-400">
                        {inspiration}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleLike(song.id)}
                      className={`w-8 h-8 ${song.isLiked ? 'text-red-500' : 'text-gray-400'}`}
                    >
                      <Heart className={`w-4 h-4 ${song.isLiked ? 'fill-current' : ''}`} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleShare(song)}
                      className="w-8 h-8 text-gray-400 hover:text-blue-400"
                    >
                      <Share2 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDownload(song)}
                      className="w-8 h-8 text-gray-400 hover:text-green-400"
                    >
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <Button
                    onClick={() => handleMint(song)}
                    className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white text-xs px-3 py-1"
                    disabled={song.mintCount >= song.maxMints}
                  >
                    <Zap className="w-3 h-3 mr-1" />
                    {song.mintCount >= song.maxMints ? 'Sold Out' : 'Mint NFT'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

      {/* Subscription Upgrade Banner */}
      {subscription === 'free' && (
        <div className="mt-12 bg-gradient-to-r from-purple-900/50 to-pink-900/50 border border-purple-500/30 rounded-xl p-6 text-center backdrop-blur-md">
          <Trophy className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-white mb-2">Unlock Premium Community Features</h3>
          <p className="text-gray-300 mb-4">
            Get unlimited plays, downloads, social interactions, and NFT minting with Pro or Enterprise
          </p>
          <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white border-0">
            Upgrade Now
          </Button>
        </div>
      )}

      {/* Dialogs */}
      {selectedSong && showMintDialog && (
        <NFTMintDialog
          song={selectedSong}
          open={showMintDialog}
          onClose={() => setShowMintDialog(false)}
        />
      )}
      
      {selectedSong && showShareDialog && (
        <ShareDialog
          song={selectedSong}
          open={showShareDialog}
          onClose={() => setShowShareDialog(false)}
        />
      )}

      {/* Music Player */}
      {currentPlaying && (
        <div className="fixed bottom-4 left-4 right-4 z-50">
          <MusicPlayer
            song={songs.find(s => s.id === currentPlaying)!}
            onClose={() => setCurrentPlaying(null)}
          />
        </div>
      )}
    </PageLayout>
  )
}