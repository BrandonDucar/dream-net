'use client'

import { useState, useRef, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Badge } from '../../components/ui/badge'
import { Slider } from '../../components/ui/slider'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'
import { 
  Palette, 
  ArrowLeft,
  Download,
  Share2,
  Sparkles,
  Music,
  Eye,
  Grid3X3,
  Image as ImageIcon,
  Wand2,
  RefreshCw,
  Heart,
  BookOpen,
  Camera,
  Zap
} from 'lucide-react'
import { useRouter } from 'next/navigation'

interface GeneratedArt {
  id: string
  title: string
  prompt: string
  imageUrl: string
  style: string
  musicGenre?: string
  musicTitle?: string
  timestamp: Date
  liked: boolean
  downloaded: boolean
}

interface ArtStyle {
  name: string
  description: string
  prompt: string
  preview: string
  musicGenres: string[]
}

export default function GalleryPage() {
  const router = useRouter()
  const [artPrompt, setArtPrompt] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedArt, setGeneratedArt] = useState<GeneratedArt[]>([
    {
      id: 'sample1',
      title: 'Neon Synthwave Dreams',
      prompt: 'Retro-futuristic cityscape with neon lights and synthwave aesthetics',
      imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop',
      style: 'Synthwave',
      musicGenre: 'Electronic',
      musicTitle: 'Midnight Drive',
      timestamp: new Date(Date.now() - 3600000),
      liked: true,
      downloaded: false
    },
    {
      id: 'sample2', 
      title: 'Abstract Jazz Vibes',
      prompt: 'Flowing abstract shapes in blues and golds, representing smooth jazz improvisation',
      imageUrl: 'https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=400&h=400&fit=crop',
      style: 'Abstract',
      musicGenre: 'Jazz',
      musicTitle: 'Blue Note Fusion',
      timestamp: new Date(Date.now() - 7200000),
      liked: false,
      downloaded: true
    }
  ])
  const [selectedArt, setSelectedArt] = useState<GeneratedArt | null>(null)
  const [artStyles, setArtStyles] = useState<ArtStyle[]>([
    {
      name: 'Synthwave',
      description: 'Retro-futuristic with neon colors and geometric patterns',
      prompt: 'synthwave aesthetic with neon colors, retro-futuristic elements, and geometric patterns',
      preview: '🌃',
      musicGenres: ['Electronic', 'Synthwave', 'Retrowave']
    },
    {
      name: 'Abstract Flow',
      description: 'Flowing organic shapes and color gradients',
      prompt: 'abstract flowing shapes with organic curves and smooth color gradients',
      preview: '🌊',
      musicGenres: ['Ambient', 'Jazz', 'Classical']
    },
    {
      name: 'Cyberpunk',
      description: 'Dark futuristic cityscape with holographic elements',
      prompt: 'cyberpunk cityscape with holographic displays, dark atmosphere, and futuristic elements',
      preview: '🌆',
      musicGenres: ['Dubstep', 'Trap', 'Industrial']
    },
    {
      name: 'Organic Nature',
      description: 'Natural elements with earthy tones and textures',
      prompt: 'natural organic elements with earthy tones, plant life, and natural textures',
      preview: '🌿',
      musicGenres: ['Folk', 'Country', 'Indie']
    },
    {
      name: 'Geometric Minimal',
      description: 'Clean geometric shapes with minimal color palette',
      prompt: 'minimal geometric shapes with clean lines and limited color palette',
      preview: '🔷',
      musicGenres: ['Techno', 'House', 'Minimal']
    },
    {
      name: 'Cosmic Space',
      description: 'Space themes with nebulae and celestial bodies',
      prompt: 'cosmic space scene with nebulae, stars, and celestial phenomena',
      preview: '🌌',
      musicGenres: ['Ambient', 'Psychedelic', 'Cinematic']
    }
  ])
  const [selectedStyle, setSelectedStyle] = useState<ArtStyle>(artStyles[0])
  const [creativityLevel, setCreativityLevel] = useState([70])
  const [musicReactive, setMusicReactive] = useState(true)
  const [currentMusic, setCurrentMusic] = useState<any>(null)
  const [filterGenre, setFilterGenre] = useState<string>('all')
  const fileInputRef = useRef<HTMLInputElement>(null)

  const generateArt = async () => {
    if (!artPrompt.trim()) return

    setIsGenerating(true)
    
    try {
      const response = await fetch('/api/generate-art', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: artPrompt,
          style: selectedStyle.name,
          creativity: creativityLevel[0],
          musicGenre: currentMusic?.genre,
          musicTitle: currentMusic?.title
        })
      })

      if (!response.ok) {
        throw new Error('Failed to generate artwork')
      }

      const data = await response.json()
      
      const newArt: GeneratedArt = {
        id: Date.now().toString(),
        title: artPrompt.slice(0, 30) + (artPrompt.length > 30 ? '...' : ''),
        prompt: data.prompt || artPrompt,
        imageUrl: data.imageUrl,
        style: selectedStyle.name,
        musicGenre: currentMusic?.genre || undefined,
        musicTitle: currentMusic?.title || undefined,
        timestamp: new Date(),
        liked: false,
        downloaded: false
      }

      setGeneratedArt(prev => [newArt, ...prev])
      setArtPrompt('')
    } catch (error) {
      console.error('Art generation failed:', error)
      // Show user-friendly error message
      alert('Failed to generate artwork. Please try again.')
    }
    
    setIsGenerating(false)
  }

  const generateMusicReactiveArt = () => {
    if (!currentMusic) return

    const musicPrompts = {
      electronic: 'digital waves and electronic circuits with pulsing neon lights',
      jazz: 'flowing abstract shapes in blues and golds with smooth gradients',
      rock: 'explosive energy with sharp angular shapes and bold colors',
      country: 'rustic landscapes with warm earth tones and natural textures',
      hip_hop: 'urban street art with bold graphics and vibrant colors',
      classical: 'elegant flowing forms with golden ratios and classical proportions'
    }

    const genre = currentMusic.genre?.toLowerCase() || 'electronic'
    const basePrompt = musicPrompts[genre as keyof typeof musicPrompts] || musicPrompts.electronic
    
    setArtPrompt(`${basePrompt}, inspired by ${currentMusic.title || 'untitled track'}, ${selectedStyle.prompt}`)
  }

  const toggleLike = (artId: string) => {
    setGeneratedArt(prev =>
      prev.map(art =>
        art.id === artId ? { ...art, liked: !art.liked } : art
      )
    )
  }

  const downloadArt = (art: GeneratedArt) => {
    // Simulate download
    setGeneratedArt(prev =>
      prev.map(a =>
        a.id === art.id ? { ...a, downloaded: true } : a
      )
    )
  }

  const filteredArt = generatedArt.filter(art => 
    filterGenre === 'all' || art.musicGenre?.toLowerCase() === filterGenre.toLowerCase()
  )

  const quickPrompts = [
    'Album cover for an electronic dance track with neon colors',
    'Minimalist artwork for a jazz piano solo',
    'Abstract visualization of bass drops and synthesizers',
    'Retro aesthetic for a synthwave instrumental',
    'Organic flowing shapes for an ambient soundscape',
    'Geometric patterns for a techno beat',
    'Cosmic space theme for a psychedelic track',
    'Urban street art style for a hip-hop beat'
  ]

  return (
    <div className="min-h-screen bg-[#050510] text-white">
      {/* Header */}
      <div className="flex items-center justify-between p-6 border-b border-white/10">
        <div className="flex items-center gap-4">
          <Button
            onClick={() => router.push('/')}
            className="bg-white/10 hover:bg-white/20 border border-white/30"
            size="sm"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Studio
          </Button>
          <div>
            <h1 className="text-2xl font-bold">
              <span className="bg-gradient-to-r from-pink-400 to-orange-400 bg-clip-text text-transparent">
                Art Generator
              </span>
            </h1>
            <p className="text-white/60 text-sm">Custom artwork for your music</p>
          </div>
        </div>
        
        {/* Quick Stats */}
        <div className="flex items-center gap-6 text-sm text-white/60">
          <div className="flex items-center gap-1">
            <ImageIcon className="w-4 h-4" />
            {generatedArt.length} Generated
          </div>
          <div className="flex items-center gap-1">
            <Heart className="w-4 h-4" />
            {generatedArt.filter(art => art.liked).length} Liked
          </div>
          <div className="flex items-center gap-1">
            <Download className="w-4 h-4" />
            {generatedArt.filter(art => art.downloaded).length} Downloads
          </div>
        </div>
      </div>

      <div className="p-6">
        <Tabs defaultValue="generate" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 lg:w-[400px]">
            <TabsTrigger value="generate">Generate Art</TabsTrigger>
            <TabsTrigger value="gallery">My Gallery</TabsTrigger>
            <TabsTrigger value="styles">Art Styles</TabsTrigger>
          </TabsList>

          {/* Generate Tab */}
          <TabsContent value="generate" className="space-y-6">
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
              {/* Generation Panel */}
              <div className="xl:col-span-2 space-y-6">
                <Card className="bg-black/40 border-white/20 backdrop-blur-md">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Wand2 className="w-5 h-5" />
                      AI Art Generator
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Art Prompt */}
                    <div>
                      <label className="text-sm text-white/70 mb-2 block">Art Description</label>
                      <Input
                        value={artPrompt}
                        onChange={(e) => setArtPrompt(e.target.value)}
                        placeholder="Describe the artwork you want to create..."
                        className="bg-white/10 border-white/20"
                      />
                    </div>

                    {/* Style Selection */}
                    <div>
                      <label className="text-sm text-white/70 mb-2 block">Art Style</label>
                      <div className="grid grid-cols-3 gap-2">
                        {artStyles.slice(0, 6).map((style) => (
                          <Button
                            key={style.name}
                            onClick={() => setSelectedStyle(style)}
                            variant={selectedStyle.name === style.name ? 'default' : 'outline'}
                            className={`p-3 h-auto flex flex-col items-center ${
                              selectedStyle.name === style.name 
                                ? 'bg-pink-500/30 border-pink-400/50' 
                                : 'bg-white/5 border-white/20 hover:bg-white/10'
                            }`}
                          >
                            <div className="text-lg mb-1">{style.preview}</div>
                            <div className="text-xs">{style.name}</div>
                          </Button>
                        ))}
                      </div>
                    </div>

                    {/* Settings */}
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm text-white/70 mb-2 block">
                          Creativity Level: {creativityLevel[0]}%
                        </label>
                        <Slider
                          value={creativityLevel}
                          onValueChange={setCreativityLevel}
                          max={100}
                          step={5}
                          className="w-full"
                        />
                      </div>
                      <div className="flex items-end">
                        <Button
                          onClick={() => setMusicReactive(!musicReactive)}
                          className={`${
                            musicReactive ? 'bg-cyan-500/30 text-cyan-100' : 'bg-white/10'
                          } hover:bg-white/20 border border-white/30`}
                          size="sm"
                        >
                          <Music className="w-3 h-3 mr-1" />
                          Music Reactive
                        </Button>
                      </div>
                    </div>

                    {/* Music Integration */}
                    {musicReactive && (
                      <Card className="bg-cyan-500/10 border-cyan-500/20">
                        <CardContent className="p-4">
                          <div className="text-sm text-cyan-300 mb-2">🎵 Music-Reactive Generation</div>
                          <div className="text-xs text-white/60 mb-3">
                            {currentMusic ? 
                              `Creating art inspired by: ${currentMusic.title} (${currentMusic.genre})` :
                              'No music track selected. Art will adapt to your current audio.'
                            }
                          </div>
                          <Button
                            onClick={generateMusicReactiveArt}
                            size="sm"
                            className="bg-cyan-500/30 hover:bg-cyan-500/40"
                          >
                            <Zap className="w-3 h-3 mr-1" />
                            Generate Music Art
                          </Button>
                        </CardContent>
                      </Card>
                    )}

                    {/* Generate Button */}
                    <Button
                      onClick={generateArt}
                      disabled={!artPrompt.trim() || isGenerating}
                      className="w-full bg-gradient-to-r from-pink-500/20 to-orange-500/20 hover:from-pink-500/30 hover:to-orange-500/30 border border-pink-400/30 py-6"
                    >
                      {isGenerating ? (
                        <>
                          <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                          Generating Artwork...
                        </>
                      ) : (
                        <>
                          <Palette className="w-4 h-4 mr-2" />
                          Generate Art
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>

                {/* Quick Prompts */}
                <Card className="bg-black/20 border-white/10">
                  <CardHeader>
                    <CardTitle className="text-sm">Quick Inspiration</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-2">
                      {quickPrompts.map((prompt, idx) => (
                        <Button
                          key={idx}
                          onClick={() => setArtPrompt(prompt)}
                          variant="outline"
                          className="text-left text-xs bg-white/5 hover:bg-white/10 border-white/20 h-auto p-3 whitespace-normal"
                        >
                          {prompt}
                        </Button>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Preview Panel */}
              <div className="space-y-6">
                <Card className="bg-black/40 border-white/20 backdrop-blur-md">
                  <CardHeader>
                    <CardTitle className="text-sm">Generation Preview</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {isGenerating ? (
                      <div className="aspect-square bg-gradient-to-br from-pink-500/20 to-orange-500/20 rounded-lg flex items-center justify-center">
                        <div className="text-center">
                          <Sparkles className="w-8 h-8 mx-auto mb-2 animate-spin text-pink-400" />
                          <div className="text-sm text-white/70">Creating your artwork...</div>
                          <div className="text-xs text-white/50 mt-1">This may take a few moments</div>
                        </div>
                      </div>
                    ) : artPrompt ? (
                      <div className="aspect-square bg-white/5 border-2 border-dashed border-white/20 rounded-lg flex items-center justify-center p-4">
                        <div className="text-center">
                          <Palette className="w-8 h-8 mx-auto mb-2 text-white/30" />
                          <div className="text-sm text-white/70 mb-2">Ready to generate:</div>
                          <div className="text-xs text-white/50 text-center">
                            {artPrompt.slice(0, 100)}{artPrompt.length > 100 ? '...' : ''}
                          </div>
                          <Badge className="mt-2 bg-pink-500/20 text-pink-400">{selectedStyle.name}</Badge>
                        </div>
                      </div>
                    ) : (
                      <div className="aspect-square bg-white/5 border-2 border-dashed border-white/20 rounded-lg flex items-center justify-center">
                        <div className="text-center text-white/30">
                          <ImageIcon className="w-8 h-8 mx-auto mb-2" />
                          <div className="text-sm">Enter a prompt to preview</div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Style Info */}
                <Card className="bg-purple-500/10 border-purple-500/20">
                  <CardHeader>
                    <CardTitle className="text-sm">Style: {selectedStyle.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-xs text-white/70 mb-3">{selectedStyle.description}</div>
                    <div className="space-y-2">
                      <div className="text-xs text-white/60">Best for genres:</div>
                      <div className="flex flex-wrap gap-1">
                        {selectedStyle.musicGenres.map(genre => (
                          <Badge key={genre} className="text-xs bg-purple-500/20 text-purple-300">
                            {genre}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Gallery Tab */}
          <TabsContent value="gallery" className="space-y-6">
            {/* Filters */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <select
                  value={filterGenre}
                  onChange={(e) => setFilterGenre(e.target.value)}
                  className="bg-white/10 border border-white/20 rounded-md px-3 py-1 text-sm"
                >
                  <option value="all">All Genres</option>
                  <option value="electronic">Electronic</option>
                  <option value="jazz">Jazz</option>
                  <option value="rock">Rock</option>
                  <option value="country">Country</option>
                  <option value="hip hop">Hip Hop</option>
                </select>
                <Badge className="bg-white/10">{filteredArt.length} artworks</Badge>
              </div>
              
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Grid3X3 className="w-3 h-3" />
                </Button>
                <Button variant="outline" size="sm">
                  <BookOpen className="w-3 h-3" />
                </Button>
              </div>
            </div>

            {/* Art Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {filteredArt.map((art) => (
                <Card key={art.id} className="bg-black/20 border-white/10 overflow-hidden group">
                  <div className="relative">
                    <img
                      src={art.imageUrl}
                      alt={art.title}
                      className="w-full aspect-square object-cover"
                    />
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <div className="flex gap-2">
                        <Button
                          onClick={() => toggleLike(art.id)}
                          size="sm"
                          className={`${art.liked ? 'bg-red-500/30 text-red-400' : 'bg-white/20'}`}
                        >
                          <Heart className={`w-3 h-3 ${art.liked ? 'fill-current' : ''}`} />
                        </Button>
                        <Button
                          onClick={() => downloadArt(art)}
                          size="sm"
                          className="bg-white/20"
                        >
                          <Download className="w-3 h-3" />
                        </Button>
                        <Button
                          onClick={() => setSelectedArt(art)}
                          size="sm"
                          className="bg-white/20"
                        >
                          <Eye className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  <CardContent className="p-3">
                    <div className="text-sm font-medium truncate mb-1">{art.title}</div>
                    <div className="flex items-center justify-between mb-2">
                      <Badge className="text-xs bg-pink-500/20 text-pink-300">{art.style}</Badge>
                      {art.musicGenre && (
                        <Badge className="text-xs bg-cyan-500/20 text-cyan-300">{art.musicGenre}</Badge>
                      )}
                    </div>
                    <div className="text-xs text-white/50">
                      {art.timestamp.toLocaleDateString()}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredArt.length === 0 && (
              <div className="text-center py-12">
                <ImageIcon className="w-12 h-12 text-white/30 mx-auto mb-4" />
                <p className="text-white/50 mb-2">No artwork found</p>
                <p className="text-xs text-white/30">
                  {filterGenre === 'all' ? 'Generate your first artwork!' : 'Try a different genre filter'}
                </p>
              </div>
            )}
          </TabsContent>

          {/* Styles Tab */}
          <TabsContent value="styles" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {artStyles.map((style) => (
                <Card key={style.name} className="bg-black/20 border-white/10">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <span className="text-2xl">{style.preview}</span>
                      {style.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-white/70 mb-4">{style.description}</p>
                    
                    <div className="space-y-3">
                      <div>
                        <div className="text-xs text-white/60 mb-1">Perfect for genres:</div>
                        <div className="flex flex-wrap gap-1">
                          {style.musicGenres.map(genre => (
                            <Badge key={genre} className="text-xs bg-purple-500/20 text-purple-300">
                              {genre}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <Button
                        onClick={() => {
                          setSelectedStyle(style)
                          // Switch to generate tab
                        }}
                        size="sm"
                        className="w-full bg-pink-500/20 hover:bg-pink-500/30 border border-pink-400/30"
                      >
                        <Wand2 className="w-3 h-3 mr-1" />
                        Use This Style
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Art Detail Modal */}
      {selectedArt && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-6">
          <div className="bg-black/90 border border-white/20 rounded-lg max-w-4xl w-full max-h-full overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold">{selectedArt.title}</h2>
                <Button
                  onClick={() => setSelectedArt(null)}
                  variant="outline"
                  size="sm"
                >
                  ✕
                </Button>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <img
                    src={selectedArt.imageUrl}
                    alt={selectedArt.title}
                    className="w-full aspect-square object-cover rounded-lg"
                  />
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-white/70 mb-2">Generation Prompt</h3>
                    <p className="text-sm text-white/90 bg-white/5 p-3 rounded-lg">{selectedArt.prompt}</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h3 className="text-sm font-medium text-white/70 mb-1">Style</h3>
                      <Badge className="bg-pink-500/20 text-pink-300">{selectedArt.style}</Badge>
                    </div>
                    {selectedArt.musicGenre && (
                      <div>
                        <h3 className="text-sm font-medium text-white/70 mb-1">Music Genre</h3>
                        <Badge className="bg-cyan-500/20 text-cyan-300">{selectedArt.musicGenre}</Badge>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      onClick={() => toggleLike(selectedArt.id)}
                      className={`${selectedArt.liked ? 'bg-red-500/30 text-red-400' : 'bg-white/10'}`}
                    >
                      <Heart className={`w-4 h-4 mr-1 ${selectedArt.liked ? 'fill-current' : ''}`} />
                      {selectedArt.liked ? 'Liked' : 'Like'}
                    </Button>
                    <Button
                      onClick={() => downloadArt(selectedArt)}
                      className="bg-cyan-500/20 hover:bg-cyan-500/30"
                    >
                      <Download className="w-4 h-4 mr-1" />
                      Download
                    </Button>
                    <Button
                      onClick={() => navigator.clipboard.writeText(selectedArt.imageUrl)}
                      variant="outline"
                    >
                      <Share2 className="w-4 h-4 mr-1" />
                      Share
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}