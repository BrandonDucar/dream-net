'use client'

import { useState, useRef, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'
import { Badge } from '../../components/ui/badge'
import { Progress } from '../../components/ui/progress'
import { Slider } from '../../components/ui/slider'
import { 
  Music, 
  Search, 
  Brain, 
  Sparkles, 
  TrendingUp, 
  ArrowLeft,
  Play,
  Pause,
  RotateCcw,
  Zap,
  Heart,
  Share2,
  Download,
  Star,
  User,
  Album
} from 'lucide-react'
import { useRouter } from 'next/navigation'

interface AnalyzedSong {
  title: string
  artist: string
  genre: string
  bpm: number
  key: string
  energy: number
  danceability: number
  valence: number
  acousticness: number
  structure: string[]
  inspirationPrompts: string[]
  legalStatus: 'analyzable' | 'transformative' | 'reference-only'
  imageUrl?: string
}

interface MusicalPattern {
  chord_progression: string[]
  rhythm_pattern: string
  melodic_contour: string
  harmonic_structure: string
  suggested_variations: string[]
}

interface SuggestedArtistProps {
  name: string
  genre: string
  topTrack: string
  imageUrl: string
  popularity: number
  onSelect: (artist: string, track: string) => void
}

function SuggestedArtist({ name, genre, topTrack, imageUrl, popularity, onSelect }: SuggestedArtistProps) {
  return (
    <Card className="bg-gradient-to-br from-gray-900/80 to-gray-800/40 border border-white/20 hover:border-white/40 transition-all duration-300 cursor-pointer group">
      <CardContent className="p-4">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-12 h-12 rounded-full overflow-hidden bg-gradient-to-br from-cyan-500/20 to-purple-500/20">
            <img src={imageUrl} alt={name} className="w-full h-full object-cover" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-white group-hover:text-cyan-300 transition-colors">{name}</h3>
            <p className="text-sm text-gray-400">{genre}</p>
          </div>
          <div className="flex items-center gap-1 text-yellow-400">
            <Star className="w-3 h-3 fill-current" />
            <span className="text-xs">{popularity}%</span>
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="text-xs text-gray-400">Top Track:</div>
          <div className="text-sm text-white font-medium">{topTrack}</div>
          <Button 
            size="sm" 
            className="w-full bg-gradient-to-r from-cyan-500/20 to-purple-500/20 hover:from-cyan-500/30 hover:to-purple-500/30 border border-cyan-400/30 text-white"
            onClick={() => onSelect(name, topTrack)}
          >
            <Search className="w-3 h-3 mr-1" />
            Analyze
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function InspirationPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState('')
  const [analyzedSong, setAnalyzedSong] = useState<AnalyzedSong | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisProgress, setAnalysisProgress] = useState(0)
  const [musicalPattern, setMusicalPattern] = useState<MusicalPattern | null>(null)
  const [transformationLevel, setTransformationLevel] = useState([75])
  const [selectedGenreShift, setSelectedGenreShift] = useState('electronic')
  const [generatedPrompt, setGeneratedPrompt] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)

  // Enhanced sample data with images
  const sampleAnalysis: Record<string, AnalyzedSong> = {
    'atliens outkast': {
      title: 'ATLiens',
      artist: 'OutKast',
      genre: 'Hip Hop',
      bpm: 79,
      key: 'Bb minor',
      energy: 0.7,
      danceability: 0.8,
      valence: 0.6,
      acousticness: 0.1,
      structure: ['Intro', 'Verse 1', 'Chorus', 'Verse 2', 'Chorus', 'Bridge', 'Chorus', 'Outro'],
      inspirationPrompts: [
        'Southern hip-hop with space-age production',
        'Futuristic alien invasion themes with earthly roots',
        'Slow, hypnotic beat with layered vocals',
        'Storytelling rap over atmospheric production'
      ],
      legalStatus: 'transformative',
      imageUrl: 'https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/42b8aa23-d1f9-4a4e-8af1-2ea03c72d99c_cmkni39xi0p6h0apa63zn4fsf-ItBZSw0wtfYPETsHZ9TcIwaBluMRiY.jpg?download=1'
    },
    'hey ya outkast': {
      title: 'Hey Ya!',
      artist: 'OutKast',  
      genre: 'Pop/Hip Hop',
      bpm: 159,
      key: 'G major',
      energy: 0.9,
      danceability: 0.9,
      valence: 0.9,
      acousticness: 0.2,
      structure: ['Intro', 'Verse 1', 'Chorus', 'Verse 2', 'Chorus', 'Bridge', 'Chorus x3'],
      inspirationPrompts: [
        'Upbeat danceable track with funky guitar',
        'Call and response vocals with crowd interaction',
        'Retro soul meets modern production',
        'High energy party anthem with unique song structure'
      ],
      legalStatus: 'transformative',
      imageUrl: 'https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/42b8aa23-d1f9-4a4e-8af1-2ea03c72d99c_cmkni39xi0p6h0apa63zn4fsf-ItBZSw0wtfYPETsHZ9TcIwaBluMRiY.jpg?download=1'
    },
    'shake it off taylor swift': {
      title: 'Shake It Off',
      artist: 'Taylor Swift',
      genre: 'Pop',
      bpm: 160,
      key: 'G major',
      energy: 0.8,
      danceability: 0.8,
      valence: 0.9,
      acousticness: 0.1,
      structure: ['Intro', 'Verse 1', 'Pre-Chorus', 'Chorus', 'Verse 2', 'Pre-Chorus', 'Chorus', 'Bridge', 'Chorus x2'],
      inspirationPrompts: [
        'Upbeat pop anthem with empowering lyrics',
        'Catchy hook with memorable chorus',
        'Pop-rock production with driving beat',
        'Confident attitude with danceable rhythm'
      ],
      legalStatus: 'transformative',
      imageUrl: 'https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/42b8aa23-d1f9-4a4e-8af1-2ea03c72d99c_cmkni39xi0p6h0apa63zn4fsf-ItBZSw0wtfYPETsHZ9TcIwaBluMRiY.jpg?download=1'
    }
  }

  // Suggested artists data
  const suggestedArtists = [
    {
      name: 'OutKast',
      genre: 'Hip Hop',
      topTrack: 'ATLiens',
      imageUrl: 'https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/42b8aa23-d1f9-4a4e-8af1-2ea03c72d99c_cmkni39xi0p6h0apa63zn4fsf-ItBZSw0wtfYPETsHZ9TcIwaBluMRiY.jpg?download=1',
      popularity: 92
    },
    {
      name: 'Taylor Swift',
      genre: 'Pop',
      topTrack: 'Shake It Off',
      imageUrl: 'https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/42b8aa23-d1f9-4a4e-8af1-2ea03c72d99c_cmkni39xi0p6h0apa63zn4fsf-ItBZSw0wtfYPETsHZ9TcIwaBluMRiY.jpg?download=1',
      popularity: 96
    },
    {
      name: 'The Beatles',
      genre: 'Rock',
      topTrack: 'Come Together',
      imageUrl: 'https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/42b8aa23-d1f9-4a4e-8af1-2ea03c72d99c_cmkni39xi0p6h0apa63zn4fsf-ItBZSw0wtfYPETsHZ9TcIwaBluMRiY.jpg?download=1',
      popularity: 94
    },
    {
      name: 'Billie Eilish',
      genre: 'Alternative Pop',
      topTrack: 'Bad Guy',
      imageUrl: 'https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/42b8aa23-d1f9-4a4e-8af1-2ea03c72d99c_cmkni39xi0p6h0apa63zn4fsf-ItBZSw0wtfYPETsHZ9TcIwaBluMRiY.jpg?download=1',
      popularity: 88
    },
    {
      name: 'Drake',
      genre: 'Hip Hop/R&B',
      topTrack: 'God\'s Plan',
      imageUrl: 'https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/42b8aa23-d1f9-4a4e-8af1-2ea03c72d99c_cmkni39xi0p6h0apa63zn4fsf-ItBZSw0wtfYPETsHZ9TcIwaBluMRiY.jpg?download=1',
      popularity: 90
    },
    {
      name: 'Ariana Grande',
      genre: 'Pop/R&B',
      topTrack: 'Thank U, Next',
      imageUrl: 'https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/42b8aa23-d1f9-4a4e-8af1-2ea03c72d99c_cmkni39xi0p6h0apa63zn4fsf-ItBZSw0wtfYPETsHZ9TcIwaBluMRiY.jpg?download=1',
      popularity: 87
    }
  ]

  const analyzeMusic = async () => {
    if (!searchQuery.trim()) return
    
    setIsAnalyzing(true)
    setAnalysisProgress(0)
    
    // Simulate analysis progress
    const progressInterval = setInterval(() => {
      setAnalysisProgress(prev => {
        if (prev >= 90) {
          clearInterval(progressInterval)
          return 90
        }
        return prev + Math.random() * 15
      })
    }, 200)

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    // Check if we have sample data
    const query = searchQuery.toLowerCase()
    const found = sampleAnalysis[query] || {
      title: 'Sample Track',
      artist: 'Sample Artist',
      genre: 'Unknown',
      bpm: Math.floor(Math.random() * 60) + 100,
      key: ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'][Math.floor(Math.random() * 12)] + (Math.random() > 0.5 ? ' major' : ' minor'),
      energy: Math.random(),
      danceability: Math.random(), 
      valence: Math.random(),
      acousticness: Math.random(),
      structure: ['Intro', 'Verse 1', 'Chorus', 'Verse 2', 'Chorus', 'Bridge', 'Outro'],
      inspirationPrompts: [
        'Create a track inspired by this rhythm and energy',
        'Take the harmonic progression in a new direction',
        'Reimagine this with a completely different genre'
      ],
      legalStatus: 'transformative' as const,
      imageUrl: 'https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/42b8aa23-d1f9-4a4e-8af1-2ea03c72d99c_cmkni39xi0p6h0apa63zn4fsf-ItBZSw0wtfYPETsHZ9TcIwaBluMRiY.jpg?download=1'
    }
    
    clearInterval(progressInterval)
    setAnalysisProgress(100)
    setAnalyzedSong(found)
    
    // Generate musical pattern analysis
    setMusicalPattern({
      chord_progression: ['I', 'vi', 'IV', 'V'],
      rhythm_pattern: 'Syncopated with emphasis on beat 2 and 4',
      melodic_contour: 'Ascending then descending with repeated motifs',
      harmonic_structure: 'Modern pop progression with jazz influences',
      suggested_variations: [
        'Try modal interchange with borrowed chords',
        'Add syncopation to the rhythm section',
        'Experiment with different time signatures',
        'Layer additional melodic counterpoint'
      ]
    })
    
    setIsAnalyzing(false)
  }

  const handleSuggestedSelect = (artist: string, track: string) => {
    setSearchQuery(`${track} ${artist}`)
    analyzeMusic()
  }

  const generateInspiredTrack = async () => {
    if (!analyzedSong) return
    
    setIsGenerating(true)
    
    // Create transformation prompt
    const prompt = `Create a ${selectedGenreShift} track inspired by ${analyzedSong.title} by ${analyzedSong.artist}. Transform the ${analyzedSong.bpm} BPM rhythm and ${analyzedSong.key} harmonic structure into a completely original composition. Energy level: ${transformationLevel[0]}%. Focus on ${selectedGenreShift} production techniques while maintaining the emotional essence of the original.`
    
    setGeneratedPrompt(prompt)
    
    // Simulate generation
    await new Promise(resolve => setTimeout(resolve, 1500))
    setIsGenerating(false)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      analyzeMusic()
    }
  }

  return (
    <div className="min-h-screen bg-[#050510] text-white">
      {/* Header */}
      <header className="px-4 py-6 border-b border-white/10 backdrop-blur-md bg-black/20">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                onClick={() => router.push('/')}
                className="bg-white/10 hover:bg-white/20 border border-white/30"
                size="sm"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
              <div>
                <h1 className="text-3xl font-bold">
                  <span className="bg-gradient-to-r from-cyan-400 to-pink-400 bg-clip-text text-transparent">
                    Music Inspiration Engine
                  </span>
                </h1>
                <p className="text-white/60 text-sm">Legal music analysis & transformative creation</p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Badge className="bg-green-500/20 text-green-400">Legal Framework Active</Badge>
              <Badge className="bg-blue-500/20 text-blue-400">12.8K Songs Analyzed</Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="px-4 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Suggested Artists Section */}
          <section className="mb-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold text-white mb-2">Popular Artists to Analyze</h2>
                <p className="text-gray-400">Quick-start your inspiration with these trending artists</p>
              </div>
              <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
                View All Artists
              </Button>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
              {suggestedArtists.map((artist, idx) => (
                <SuggestedArtist
                  key={idx}
                  {...artist}
                  onSelect={handleSuggestedSelect}
                />
              ))}
            </div>
          </section>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
            {/* Music Analysis Panel */}
            <Card className="bg-black/40 border-white/20 backdrop-blur-md">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="w-5 h-5" />
                  Song Analysis & Reference
                </CardTitle>
                <p className="text-sm text-white/60">
                  Analyze any song for musical patterns and inspiration (no copyright infringement)
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Search */}
                <div className="flex gap-2">
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Enter song title and artist (e.g., 'ATLiens OutKast')"
                    className="flex-1 bg-white/10 border-white/20"
                  />
                  <Button 
                    onClick={analyzeMusic}
                    disabled={isAnalyzing || !searchQuery.trim()}
                    className="bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/30"
                  >
                    <Search className="w-4 h-4" />
                  </Button>
                </div>

                {/* Analysis Progress */}
                {isAnalyzing && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-white/70">Analyzing musical patterns...</span>
                      <span className="text-cyan-400">{Math.round(analysisProgress)}%</span>
                    </div>
                    <Progress value={analysisProgress} className="w-full" />
                    <div className="text-xs text-white/50 space-y-1">
                      <div>• Extracting harmonic structure</div>
                      <div>• Analyzing rhythmic patterns</div>
                      <div>• Identifying melodic contours</div>
                      <div>• Generating inspiration prompts</div>
                    </div>
                  </div>
                )}

                {/* Analysis Results */}
                {analyzedSong && !isAnalyzing && (
                  <div className="space-y-4">
                    <div className="p-4 rounded-lg bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border border-cyan-400/30">
                      <div className="flex items-start gap-4 mb-3">
                        <div className="w-16 h-16 rounded-lg overflow-hidden bg-gradient-to-br from-cyan-500/20 to-purple-500/20">
                          {analyzedSong.imageUrl ? (
                            <img src={analyzedSong.imageUrl} alt={analyzedSong.title} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <Album className="w-8 h-8 text-white/60" />
                            </div>
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className="text-lg font-semibold">{analyzedSong.title}</h3>
                              <p className="text-white/70">by {analyzedSong.artist}</p>
                            </div>
                            <Badge className={`${
                              analyzedSong.legalStatus === 'transformative' 
                                ? 'bg-green-500/20 text-green-400' 
                                : 'bg-yellow-500/20 text-yellow-400'
                            }`}>
                              {analyzedSong.legalStatus === 'transformative' ? 'Transformative Use OK' : 'Reference Only'}
                            </Badge>
                          </div>
                        </div>
                      </div>

                      {/* Musical Data Grid */}
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-white/60">BPM:</span>
                            <span className="font-mono">{analyzedSong.bpm}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-white/60">Key:</span>
                            <span className="font-mono">{analyzedSong.key}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-white/60">Genre:</span>
                            <span>{analyzedSong.genre}</span>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-white/60">Energy:</span>
                            <span>{Math.round(analyzedSong.energy * 100)}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-white/60">Danceability:</span>
                            <span>{Math.round(analyzedSong.danceability * 100)}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-white/60">Mood:</span>
                            <span>{Math.round(analyzedSong.valence * 100)}%</span>
                          </div>
                        </div>
                      </div>

                      {/* Song Structure */}
                      <div className="mb-4">
                        <div className="text-sm text-white/60 mb-2">Song Structure:</div>
                        <div className="flex flex-wrap gap-1">
                          {analyzedSong.structure.map((section, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {section}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Rest of the analysis components remain the same... */}
                    {/* Musical Pattern Analysis */}
                    {musicalPattern && (
                      <Card className="bg-purple-500/10 border-purple-500/20">
                        <CardHeader className="pb-3">
                          <CardTitle className="text-sm">Musical Pattern Analysis</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div>
                            <div className="text-xs text-white/60 mb-1">Chord Progression:</div>
                            <div className="text-sm font-mono">{musicalPattern.chord_progression.join(' - ')}</div>
                          </div>
                          <div>
                            <div className="text-xs text-white/60 mb-1">Rhythm Pattern:</div>
                            <div className="text-sm">{musicalPattern.rhythm_pattern}</div>
                          </div>
                          <div>
                            <div className="text-xs text-white/60 mb-1">Creative Variations:</div>
                            <div className="space-y-1">
                              {musicalPattern.suggested_variations.map((variation, idx) => (
                                <div key={idx} className="text-xs text-white/70">• {variation}</div>
                              ))}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Inspiration Prompts */}
                    <Card className="bg-orange-500/10 border-orange-500/20">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm">AI Inspiration Prompts</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {analyzedSong.inspirationPrompts.map((prompt, idx) => (
                            <div 
                              key={idx}
                              className="p-3 rounded-lg bg-black/30 border border-orange-400/20 text-sm cursor-pointer hover:bg-black/50 transition-colors"
                              onClick={() => setGeneratedPrompt(prompt)}
                            >
                              💡 {prompt}
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Transformation Studio */}
            <Card className="bg-black/40 border-white/20 backdrop-blur-md">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <RotateCcw className="w-5 h-5" />
                  Transformative Creation Studio
                </CardTitle>
                <p className="text-sm text-white/60">
                  Generate original music inspired by analyzed patterns
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                {analyzedSong ? (
                  <>
                    {/* Transformation Controls */}
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm text-white/70 mb-2 block">Genre Transformation</label>
                        <select 
                          value={selectedGenreShift}
                          onChange={(e) => setSelectedGenreShift(e.target.value)}
                          className="w-full bg-white/10 border border-white/20 rounded-md px-3 py-2 text-white text-sm"
                        >
                          <option value="country">Country</option>
                          <option value="house">House</option>
                          <option value="electronic">Electronic</option>
                          <option value="jazz">Jazz</option>
                          <option value="rock">Rock</option>
                          <option value="reggae">Reggae</option>
                          <option value="classical">Classical</option>
                          <option value="r&b">R&B</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-sm text-white/70 mb-2 block">
                          Transformation Level: {transformationLevel[0]}%
                        </label>
                        <Slider
                          value={transformationLevel}
                          onValueChange={setTransformationLevel}
                          max={100}
                          min={25}
                          step={5}
                          className="w-full"
                        />
                        <div className="flex justify-between text-xs text-white/50 mt-1">
                          <span>Subtle Inspiration</span>
                          <span>Complete Transformation</span>
                        </div>
                      </div>
                    </div>

                    {/* Legal Framework Info */}
                    <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/20">
                      <h4 className="text-sm font-medium text-green-400 mb-2">🏛️ Legal Framework</h4>
                      <div className="text-xs text-white/70 space-y-1">
                        <div>✅ <strong>Transformative Use:</strong> Creating original works inspired by musical patterns</div>
                        <div>✅ <strong>No Copyright Infringement:</strong> Analyzing publicly available information</div>
                        <div>✅ <strong>Proper Attribution:</strong> "Inspired by {analyzedSong.title} by {analyzedSong.artist}"</div>
                        <div>✅ <strong>Original Creation:</strong> AI generates new composition, not reproduction</div>
                      </div>
                    </div>

                    {/* Generate Button */}
                    <Button 
                      onClick={generateInspiredTrack}
                      disabled={isGenerating}
                      className="w-full bg-gradient-to-r from-cyan-500/20 to-purple-500/20 hover:from-cyan-500/30 hover:to-purple-500/30 border border-cyan-400/30 py-6"
                    >
                      {isGenerating ? (
                        <>
                          <Brain className="w-4 h-4 mr-2 animate-spin" />
                          Generating Inspired Track...
                        </>
                      ) : (
                        <>
                          <Zap className="w-4 h-4 mr-2" />
                          Create Inspired Track
                        </>
                      )}
                    </Button>

                    {/* Generated Prompt */}
                    {generatedPrompt && (
                      <div className="space-y-4">
                        <Card className="bg-purple-500/10 border-purple-500/20">
                          <CardHeader className="pb-3">
                            <CardTitle className="text-sm">Generated AI Prompt</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="p-3 rounded-lg bg-black/30 border border-purple-400/20 text-sm">
                              {generatedPrompt}
                            </div>
                            <div className="flex gap-2 mt-3">
                              <Button 
                                onClick={() => router.push('/')}
                                className="bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/30"
                                size="sm"
                              >
                                <Play className="w-3 h-3 mr-1" />
                                Generate in Studio
                              </Button>
                              <Button 
                                onClick={() => navigator.clipboard.writeText(generatedPrompt)}
                                variant="outline"
                                size="sm"
                              >
                                <Share2 className="w-3 h-3 mr-1" />
                                Copy Prompt
                              </Button>
                            </div>
                          </CardContent>
                        </Card>

                        {/* Attribution Template */}
                        <Card className="bg-orange-500/10 border-orange-500/20">
                          <CardHeader className="pb-3">
                            <CardTitle className="text-sm">Attribution Template</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="p-3 rounded-lg bg-black/30 border border-orange-400/20 text-xs">
                              <div className="text-white/70">
                                This track was created using AI analysis of musical patterns from "{analyzedSong.title}" by {analyzedSong.artist}. 
                                This is an original composition inspired by the harmonic structure, rhythm patterns, and emotional essence 
                                of the reference track, transformed into the {selectedGenreShift} genre.
                              </div>
                              <div className="mt-2 text-orange-400">
                                Original inspiration: "{analyzedSong.title}" by {analyzedSong.artist}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center py-12">
                    <Brain className="w-12 h-12 text-white/30 mx-auto mb-4" />
                    <p className="text-white/50 mb-2">No song analyzed yet</p>
                    <p className="text-xs text-white/30">
                      Search and analyze a song or select from suggested artists to begin transformative creation
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Quick Examples */}
          <Card className="mt-8 bg-black/20 border-white/10">
            <CardHeader>
              <CardTitle className="text-lg">Try These Popular Examples</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {Object.entries(sampleAnalysis).map(([query, song]) => (
                  <Card key={query} className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 border border-white/20 hover:border-white/40 transition-all duration-300 cursor-pointer group">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-12 h-12 rounded-lg overflow-hidden">
                          <img src={song.imageUrl || ''} alt={song.title} className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <div className="font-medium text-white group-hover:text-cyan-300 transition-colors">{song.title}</div>
                          <div className="text-sm text-gray-400">{song.artist}</div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <Badge className="text-xs">{song.genre}</Badge>
                        <Button
                          onClick={() => {
                            setSearchQuery(query)
                            analyzeMusic()
                          }}
                          size="sm"
                          className="bg-gradient-to-r from-cyan-500/20 to-purple-500/20 hover:from-cyan-500/30 hover:to-purple-500/30 border border-cyan-400/30"
                        >
                          Analyze
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}