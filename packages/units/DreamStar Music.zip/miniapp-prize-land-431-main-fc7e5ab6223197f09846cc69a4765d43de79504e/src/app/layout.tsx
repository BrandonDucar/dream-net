import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { ResponseLogger } from "@/components/response-logger";
import { cookies } from "next/headers";
import { ReadyNotifier } from "@/components/ready-notifier";
import { Providers } from "./providers";
import FarcasterWrapper from "@/components/FarcasterWrapper";

const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const requestId = cookies().get("x-request-id")?.value;

  return (
        <html lang="en">
          <head>
            {requestId && <meta name="x-request-id" content={requestId} />}
            
            {/* Base Ecosystem Discovery - Structured Data */}
            <script
              type="application/ld+json"
              dangerouslySetInnerHTML={{
                __html: JSON.stringify({
                  "@context": "https://schema.org",
                  "@type": ["WebApplication", "SoftwareApplication"],
                  "name": "DreamStar Music",
                  "description": "Create music with AI, then visualize it in holographic 3D space. Generate original tracks, transform genres with AI tools, and watch your music come alive as interactive visuals.",
                  "applicationCategory": "MusicApplication",
                  "applicationSubCategory": "AI Music Creation",
                  "operatingSystem": "Web Browser",
                  "browserRequirements": "HTML5, WebGL, Web Audio API",
                  "offers": {
                    "@type": "Offer",
                    "price": "0",
                    "priceCurrency": "FAIR"
                  },
                  "author": {
                    "@type": "Organization",
                    "name": "DreamStar Music Team"
                  },
                  "publisher": {
                    "@type": "Organization", 
                    "name": "Base Ecosystem"
                  },
                  "featureList": [
                    "Holographic 3D interface",
                    "AI-powered music generation",
                    "Real-time audio processing",
                    "Cross-genre music transformation",
                    "Collaborative music creation",
                    "Base blockchain integration",
                    "Mobile-optimized controls"
                  ],
                  "screenshot": "https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_42b8aa23-d1f9-4a4e-8af1-2ea03c72d99c-tZbVKD3U2GVk8wDA650lKaKaukKbgg",
                  "aggregateRating": {
                    "@type": "AggregateRating",
                    "ratingValue": "5.0",
                    "ratingCount": "1"
                  },
                  "potentialAction": {
                    "@type": "UseAction",
                    "target": "https://prize-land-431.app.ohara.ai"
                  },
                  "mainEntityOfPage": {
                    "@type": "WebPage",
                    "@id": "https://prize-land-431.app.ohara.ai"
                  },
                  "additionalProperty": [
                    {
                      "@type": "PropertyValue",
                      "name": "blockchain",
                      "value": "Base"
                    },
                    {
                      "@type": "PropertyValue", 
                      "name": "chain-id",
                      "value": "8453"
                    },
                    {
                      "@type": "PropertyValue",
                      "name": "dapp-category",
                      "value": "music-creation"
                    },
                    {
                      "@type": "PropertyValue",
                      "name": "web3-compatible",
                      "value": "true"
                    },
                    {
                      "@type": "PropertyValue",
                      "name": "native-token",
                      "value": "FAIR"
                    }
                  ]
                })
              }}
            />
            
            {/* Base App Manifest for Enhanced Discovery */}
            <script
              type="application/json"
              id="base-app-manifest"
              dangerouslySetInnerHTML={{
                __html: JSON.stringify({
                  "name": "DreamStar Music",
                  "short_name": "DreamStar", 
                  "description": "Holographic AI Music Studio on Base with FAIR token",
                  "version": "1.0.0",
                  "blockchain": {
                    "network": "base-mainnet",
                    "chain_id": 8453,
                    "layer": 2,
                    "native_token": "FAIR"
                  },
                  "category": "entertainment",
                  "subcategory": "music-creation",
                  "tags": ["music", "ai", "holographic", "remix", "web3", "base", "fair"],
                  "features": [
                    "ai-music-generation",
                    "real-time-collaboration", 
                    "3d-holographic-interface",
                    "cross-genre-transformation",
                    "mobile-touch-controls",
                    "fair-token-integration"
                  ],
                  "discovery": {
                    "base_discoverable": true,
                    "ecosystem": "base",
                    "app_type": "dapp",
                    "compatibility": ["desktop", "mobile", "web3-wallets"]
                  }
                })
              }}
            />
          </head>
          <body
            className={`${geistSans.variable} ${geistMono.variable} antialiased`}
          >
            {/* Do not remove this component, we use it to notify the parent that the mini-app is ready */}
            <ReadyNotifier />
            <Providers>
      <FarcasterWrapper>
        {children}
      </FarcasterWrapper>
      </Providers>
            <ResponseLogger />
          </body>
        </html>
      );
}

export const metadata: Metadata = {
        title: "DreamStar Music - Holographic AI Music Studio",
        description: "Create music with AI, then visualize it in holographic 3D space. Generate original tracks, transform genres, and watch your music come alive as interactive visuals. Built on Base blockchain with FAIR token.",
        keywords: [
          "AI music", "Base blockchain", "Web3 music", "holographic studio", 
          "music creation", "AI remix", "blockchain music", "decentralized music",
          "Base dApp", "music NFT", "collaborative music", "AI audio processing", "FAIR token"
        ],
        authors: [{ name: "DreamStar Music Team" }],
        creator: "DreamStar Music",
        publisher: "Base Ecosystem",
        category: "Music & Audio",
        openGraph: {
          title: "DreamStar Music - Holographic AI Music Studio on Base",
          description: "Create music with AI, then visualize it in holographic 3D space. Generate original tracks and transform genres with AI tools. Built on Base blockchain with FAIR token.",
          type: "website",
          siteName: "DreamStar Music",
          images: [{
            url: "https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_42b8aa23-d1f9-4a4e-8af1-2ea03c72d99c-tZbVKD3U2GVk8wDA650lKaKaukKbgg",
            width: 1200,
            height: 630,
            alt: "DreamStar Music - Holographic AI Music Studio"
          }]
        },
        twitter: {
          card: "summary_large_image",
          title: "DreamStar Music - Holographic AI Music Studio on Base",
          description: "Create music with AI, then visualize it in 3D space. Generate original tracks and transform genres. Built on Base blockchain with FAIR token.",
          images: ["https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_42b8aa23-d1f9-4a4e-8af1-2ea03c72d99c-tZbVKD3U2GVk8wDA650lKaKaukKbgg"],
          creator: "@DreamStarMusic"
        },
        robots: {
          index: true,
          follow: true,
          googleBot: {
            index: true,
            follow: true,
            'max-video-preview': -1,
            'max-image-preview': 'large',
            'max-snippet': -1,
          },
        },
        verification: {
          google: "base-music-dapp-verification"
        },
        other: { 
          // Farcaster Frame metadata
          "fc:frame": JSON.stringify({"version":"next","imageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_42b8aa23-d1f9-4a4e-8af1-2ea03c72d99c-tZbVKD3U2GVk8wDA650lKaKaukKbgg","button":{"title":"Open with Ohara","action":{"type":"launch_frame","name":"DreamStar Music - Holographic AI Music Studio","url":"https://prize-land-431.app.ohara.ai","splashImageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/farcaster/splash_images/splash_image1.svg","splashBackgroundColor":"#0052ff"}}}),
          
          // Base Blockchain Discovery Metadata
          "base:network": "base-mainnet",
          "base:app-type": "music-creation",
          "base:category": "entertainment,music,ai,creative-tools",
          "base:blockchain-compatible": "true",
          "base:layer": "2",
          "base:discovery-tags": "music,ai,holographic,remix,collaboration,web3,nft,fair",
          "base:native-token": "FAIR",
          
          // Web3 App Metadata
          "web3:chain": "base",
          "web3:network": "8453",
          "web3:app-category": "music-creation",
          "web3:features": "ai-music-generation,real-time-collaboration,nft-support,fair-token",
          
          // PWA and Mobile App Metadata
          "mobile-web-app-capable": "yes",
          "apple-mobile-web-app-capable": "yes",
          "apple-mobile-web-app-status-bar-style": "black-translucent",
          "apple-mobile-web-app-title": "DreamStar Music",
          
          // Base Ecosystem Tags
          "base:dapp": "true",
          "base:version": "1.0.0",
          "base:built-with": "next.js,three.js,tone.js,ai,fair-token",
          "base:supports": "mobile,desktop,web3-wallets",
          
          // Discovery and SEO
          "application-name": "DreamStar Music",
          "theme-color": "#0052ff",
          "msapplication-TileColor": "#0052ff",
          "color-scheme": "dark light"
        }
    };