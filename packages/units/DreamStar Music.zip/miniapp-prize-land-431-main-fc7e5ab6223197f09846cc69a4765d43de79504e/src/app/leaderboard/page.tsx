'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Trophy, Crown, Zap, TrendingUp, Music, Users, Play, Heart, Star, Medal } from 'lucide-react'
import { useSubscription } from '@/stores/subscriptionStore'

interface LeaderboardEntry {
  id: string
  rank: number
  username: string
  avatar: string
  totalPlays: number
  totalLikes: number
  songsCreated: number
  nftsMinted: number
  totalEarnings: number
  streak: number
  badges: string[]
  tier: 'bronze' | 'silver' | 'gold' | 'diamond' | 'holographic'
}

interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  rarity: 'common' | 'rare' | 'epic' | 'legendary'
  progress: number
  maxProgress: number
  reward: string
}

const mockLeaderboard: LeaderboardEntry[] = [
  {
    id: '1',
    rank: 1,
    username: 'CyberPhoenix',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=CyberPhoenix',
    totalPlays: 245890,
    totalLikes: 18947,
    songsCreated: 127,
    nftsMinted: 89,
    totalEarnings: 12.47,
    streak: 23,
    badges: ['Pioneer', 'Trendsetter', 'NFT Master'],
    tier: 'holographic'
  },
  {
    id: '2',
    rank: 2,
    username: 'SonicAlchemist',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=SonicAlchemist',
    totalPlays: 198732,
    totalLikes: 15234,
    songsCreated: 98,
    nftsMinted: 67,
    totalEarnings: 9.83,
    streak: 19,
    badges: ['Genre Bender', 'Collaborative Spirit'],
    tier: 'diamond'
  },
  {
    id: '3',
    rank: 3,
    username: 'QuantumVibes',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=QuantumVibes',
    totalPlays: 176543,
    totalLikes: 13876,
    songsCreated: 84,
    nftsMinted: 52,
    totalEarnings: 7.92,
    streak: 15,
    badges: ['Jazz Master', 'AI Whisperer'],
    tier: 'gold'
  },
  {
    id: '4',
    rank: 4,
    username: 'BeatCrafter',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=BeatCrafter',
    totalPlays: 143298,
    totalLikes: 11203,
    songsCreated: 76,
    nftsMinted: 41,
    totalEarnings: 6.15,
    streak: 12,
    badges: ['Bass Legend', 'Community Favorite'],
    tier: 'gold'
  },
  {
    id: '5',
    rank: 5,
    username: 'HolographicHarmony',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=HolographicHarmony',
    totalPlays: 129847,
    totalLikes: 9876,
    songsCreated: 63,
    nftsMinted: 38,
    totalEarnings: 5.24,
    streak: 8,
    badges: ['Ambient Master', 'Rising Star'],
    tier: 'silver'
  }
]

const mockAchievements: Achievement[] = [
  {
    id: '1',
    title: 'First Steps',
    description: 'Create your first holographic track',
    icon: 'music',
    rarity: 'common',
    progress: 1,
    maxProgress: 1,
    reward: '0.01 ETH + Pioneer Badge'
  },
  {
    id: '2',
    title: 'Genre Master',
    description: 'Successfully blend 5 different genres',
    icon: 'zap',
    rarity: 'rare',
    progress: 3,
    maxProgress: 5,
    reward: '0.05 ETH + Genre Bender Badge'
  },
  {
    id: '3',
    title: 'Community Champion',
    description: 'Receive 1000 likes across all tracks',
    icon: 'heart',
    rarity: 'epic',
    progress: 847,
    maxProgress: 1000,
    reward: '0.1 ETH + Community Champion Badge'
  },
  {
    id: '4',
    title: 'NFT Mogul',
    description: 'Mint 50 successful NFTs',
    icon: 'crown',
    rarity: 'legendary',
    progress: 23,
    maxProgress: 50,
    reward: '0.5 ETH + NFT Master Badge'
  }
]

export default function LeaderboardPage(): JSX.Element {
  const [selectedTab, setSelectedTab] = useState<'artists' | 'tracks' | 'achievements'>('artists')
  const [timeframe, setTimeframe] = useState<'week' | 'month' | 'all'>('month')
  const { subscription } = useSubscription()

  const getTierIcon = (tier: LeaderboardEntry['tier']): JSX.Element => {
    switch (tier) {
      case 'holographic': return <Crown className="w-5 h-5 text-yellow-400" />
      case 'diamond': return <Star className="w-5 h-5 text-cyan-400" />
      case 'gold': return <Trophy className="w-5 h-5 text-yellow-600" />
      case 'silver': return <Medal className="w-5 h-5 text-gray-400" />
      default: return <Medal className="w-5 h-5 text-orange-600" />
    }
  }

  const getTierColor = (tier: LeaderboardEntry['tier']): string => {
    switch (tier) {
      case 'holographic': return 'from-yellow-400 via-purple-500 to-cyan-400'
      case 'diamond': return 'from-cyan-400 to-blue-600'
      case 'gold': return 'from-yellow-400 to-yellow-600'
      case 'silver': return 'from-gray-300 to-gray-500'
      default: return 'from-orange-400 to-orange-600'
    }
  }

  const getRarityColor = (rarity: Achievement['rarity']): string => {
    switch (rarity) {
      case 'legendary': return 'border-yellow-400 bg-yellow-400/10'
      case 'epic': return 'border-purple-500 bg-purple-500/10'
      case 'rare': return 'border-blue-400 bg-blue-400/10'
      default: return 'border-gray-500 bg-gray-500/10'
    }
  }

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-yellow-400 via-purple-500 to-cyan-400 bg-clip-text text-transparent">
                Global Leaderboard
              </h1>
              <p className="text-gray-400 mt-2">
                Compete with holographic artists worldwide and earn rewards
              </p>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant={timeframe === 'week' ? 'default' : 'outline'}
                onClick={() => setTimeframe('week')}
                size="sm"
              >
                Week
              </Button>
              <Button
                variant={timeframe === 'month' ? 'default' : 'outline'}
                onClick={() => setTimeframe('month')}
                size="sm"
              >
                Month
              </Button>
              <Button
                variant={timeframe === 'all' ? 'default' : 'outline'}
                onClick={() => setTimeframe('all')}
                size="sm"
              >
                All Time
              </Button>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={selectedTab} onValueChange={(value) => setSelectedTab(value as any)} className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-gray-900">
            <TabsTrigger value="artists" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Top Artists
            </TabsTrigger>
            <TabsTrigger value="tracks" className="flex items-center gap-2">
              <Music className="w-4 h-4" />
              Hot Tracks
            </TabsTrigger>
            <TabsTrigger value="achievements" className="flex items-center gap-2">
              <Trophy className="w-4 h-4" />
              Achievements
            </TabsTrigger>
          </TabsList>

          {/* Top Artists Tab */}
          <TabsContent value="artists" className="space-y-6">
            {/* Top 3 Podium */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {mockLeaderboard.slice(0, 3).map((entry, index) => (
                <Card key={entry.id} className={`bg-gradient-to-br ${getTierColor(entry.tier)} p-1`}>
                  <div className="bg-gray-900 rounded-lg p-6 h-full">
                    <div className="text-center">
                      <div className="relative mb-4">
                        <Avatar className="w-20 h-20 mx-auto">
                          <AvatarImage src={entry.avatar} />
                          <AvatarFallback>{entry.username[0]}</AvatarFallback>
                        </Avatar>
                        <div className="absolute -top-2 -right-2 bg-yellow-400 text-black rounded-full w-8 h-8 flex items-center justify-center font-bold">
                          #{entry.rank}
                        </div>
                      </div>
                      
                      <h3 className="text-xl font-bold mb-2">{entry.username}</h3>
                      
                      <div className="flex items-center justify-center gap-2 mb-4">
                        {getTierIcon(entry.tier)}
                        <Badge className={`bg-gradient-to-r ${getTierColor(entry.tier)} text-white`}>
                          {entry.tier.toUpperCase()}
                        </Badge>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Plays:</span>
                          <span className="font-semibold">{entry.totalPlays.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Likes:</span>
                          <span className="font-semibold">{entry.totalLikes.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">NFTs:</span>
                          <span className="font-semibold">{entry.nftsMinted}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Earnings:</span>
                          <span className="font-semibold text-green-400">{entry.totalEarnings} ETH</span>
                        </div>
                      </div>

                      <div className="flex flex-wrap justify-center gap-1 mt-4">
                        {entry.badges.map((badge) => (
                          <Badge key={badge} variant="secondary" className="text-xs">
                            {badge}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            {/* Full Leaderboard */}
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Full Rankings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockLeaderboard.map((entry) => (
                    <div key={entry.id} className="flex items-center gap-4 p-4 bg-gray-800/50 rounded-lg hover:bg-gray-700/50 transition-all">
                      <div className="text-2xl font-bold text-gray-400 w-8">
                        #{entry.rank}
                      </div>
                      
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={entry.avatar} />
                        <AvatarFallback>{entry.username[0]}</AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold">{entry.username}</h3>
                          {getTierIcon(entry.tier)}
                        </div>
                        <div className="flex items-center gap-4 text-sm text-gray-400">
                          <span className="flex items-center gap-1">
                            <Play className="w-3 h-3" />
                            {entry.totalPlays.toLocaleString()}
                          </span>
                          <span className="flex items-center gap-1">
                            <Heart className="w-3 h-3" />
                            {entry.totalLikes.toLocaleString()}
                          </span>
                          <span className="flex items-center gap-1">
                            <Music className="w-3 h-3" />
                            {entry.songsCreated}
                          </span>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className="text-lg font-bold text-green-400">
                          {entry.totalEarnings} ETH
                        </div>
                        <div className="text-sm text-gray-400">
                          {entry.streak} day streak
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Hot Tracks Tab */}
          <TabsContent value="tracks" className="space-y-6">
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Music className="w-5 h-5" />
                  Trending Tracks This {timeframe.charAt(0).toUpperCase() + timeframe.slice(1)}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-gray-400">
                  <Music className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Track leaderboard coming soon!</p>
                  <p className="text-sm mt-2">Vote for your favorite community tracks to see them ranked here.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {mockAchievements.map((achievement) => (
                <Card key={achievement.id} className={`border-2 ${getRarityColor(achievement.rarity)}`}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-cyan-500 rounded-full flex items-center justify-center">
                          {achievement.icon === 'music' && <Music className="w-5 h-5" />}
                          {achievement.icon === 'zap' && <Zap className="w-5 h-5" />}
                          {achievement.icon === 'heart' && <Heart className="w-5 h-5" />}
                          {achievement.icon === 'crown' && <Crown className="w-5 h-5" />}
                        </div>
                        <div>
                          <div className="font-bold">{achievement.title}</div>
                          <Badge className={getRarityColor(achievement.rarity).replace('border-', 'bg-').replace('bg-', '').replace('/10', '/20')}>
                            {achievement.rarity.toUpperCase()}
                          </Badge>
                        </div>
                      </CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-400 mb-4">{achievement.description}</p>
                    
                    <div className="mb-4">
                      <div className="flex justify-between text-sm mb-2">
                        <span>Progress</span>
                        <span>{achievement.progress}/{achievement.maxProgress}</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-purple-500 to-cyan-500 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${(achievement.progress / achievement.maxProgress) * 100}%` }}
                        />
                      </div>
                    </div>
                    
                    <div className="bg-gray-800 rounded-lg p-3">
                      <div className="text-sm text-gray-400 mb-1">Reward</div>
                      <div className="text-yellow-400 font-semibold">{achievement.reward}</div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Your Stats Card */}
        {subscription !== 'free' && (
          <Card className="bg-gradient-to-r from-purple-900/50 to-cyan-900/50 border-purple-500 mt-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5" />
                Your Stats
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-400">--</div>
                  <div className="text-sm text-gray-400">Current Rank</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-cyan-400">--</div>
                  <div className="text-sm text-gray-400">Total Plays</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-400">-- ETH</div>
                  <div className="text-sm text-gray-400">Earnings</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-400">--</div>
                  <div className="text-sm text-gray-400">Achievement Score</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}