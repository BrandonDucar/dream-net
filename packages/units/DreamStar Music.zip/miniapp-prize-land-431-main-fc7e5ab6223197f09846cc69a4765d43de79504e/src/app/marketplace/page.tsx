'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Heart, Play, Search, Filter, TrendingUp, Zap, Crown, Star, Eye, ShoppingCart } from 'lucide-react'
import { toast } from 'sonner'
import { useSubscription } from '@/stores/subscriptionStore'
import { NFTMintDialog } from '@/components/nft/NFTMintDialog'
import { NFTDetailsDialog } from '@/components/nft/NFTDetailsDialog'

interface NFTTrack {
  id: string
  tokenId: number
  title: string
  artist: string
  artistAvatar: string
  genre: string[]
  duration: number
  coverArt: string
  rarity: 'common' | 'rare' | 'epic' | 'legendary'
  mintCount: number
  maxMints: number
  floorPrice: number
  lastSalePrice: number
  isForSale: boolean
  salePrice: number
  owner: string
  ownerAvatar: string
  views: number
  likes: number
  createdAt: string
  blockchain: 'base' | 'ethereum'
  royaltyPercentage: number
  tradingVolume: number
}

const mockNFTs: NFTTrack[] = [
  {
    id: '1',
    tokenId: 1001,
    title: 'Holographic Dreams',
    artist: 'CyberPhoenix',
    artistAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=CyberPhoenix',
    genre: ['Synthwave', 'Electronic'],
    duration: 243,
    coverArt: 'https://images.unsplash.com/photo-1571330735066-03aaa9429d89?w=400&h=400&fit=crop',
    rarity: 'legendary',
    mintCount: 12,
    maxMints: 50,
    floorPrice: 0.08,
    lastSalePrice: 0.12,
    isForSale: true,
    salePrice: 0.15,
    owner: 'CollectorOne',
    ownerAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=CollectorOne',
    views: 15420,
    likes: 847,
    createdAt: '2024-01-15',
    blockchain: 'base',
    royaltyPercentage: 10,
    tradingVolume: 2.4
  },
  {
    id: '2',
    tokenId: 1002,
    title: 'Country House Fusion',
    artist: 'SonicAlchemist',
    artistAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=SonicAlchemist',
    genre: ['Country', 'House', 'Fusion'],
    duration: 198,
    coverArt: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=400&fit=crop',
    rarity: 'epic',
    mintCount: 28,
    maxMints: 100,
    floorPrice: 0.05,
    lastSalePrice: 0.07,
    isForSale: false,
    salePrice: 0,
    owner: 'VinylMaster',
    ownerAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=VinylMaster',
    views: 8932,
    likes: 623,
    createdAt: '2024-01-12',
    blockchain: 'base',
    royaltyPercentage: 7.5,
    tradingVolume: 1.8
  },
  {
    id: '3',
    tokenId: 1003,
    title: 'Quantum Jazz',
    artist: 'QuantumVibes',
    artistAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=QuantumVibes',
    genre: ['Jazz', 'Ambient', 'Electronic'],
    duration: 312,
    coverArt: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=400&h=400&fit=crop',
    rarity: 'rare',
    mintCount: 45,
    maxMints: 200,
    floorPrice: 0.03,
    lastSalePrice: 0.035,
    isForSale: true,
    salePrice: 0.04,
    owner: 'JazzCollector',
    ownerAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=JazzCollector',
    views: 12156,
    likes: 934,
    createdAt: '2024-01-10',
    blockchain: 'base',
    royaltyPercentage: 5,
    tradingVolume: 0.9
  },
  {
    id: '4',
    tokenId: 1004,
    title: 'Bass Symphony',
    artist: 'BeatCrafter',
    artistAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=BeatCrafter',
    genre: ['Dubstep', 'Orchestral'],
    duration: 267,
    coverArt: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=400&fit=crop',
    rarity: 'common',
    mintCount: 156,
    maxMints: 500,
    floorPrice: 0.01,
    lastSalePrice: 0.015,
    isForSale: true,
    salePrice: 0.02,
    owner: 'BassHead',
    ownerAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=BassHead',
    views: 23891,
    likes: 1247,
    createdAt: '2024-01-08',
    blockchain: 'base',
    royaltyPercentage: 2.5,
    tradingVolume: 3.2
  }
]

export default function MarketplacePage(): JSX.Element {
  const [nfts, setNfts] = useState<NFTTrack[]>(mockNFTs)
  const [selectedNFT, setSelectedNFT] = useState<NFTTrack | null>(null)
  const [showDetailsDialog, setShowDetailsDialog] = useState<boolean>(false)
  const [searchQuery, setSearchQuery] = useState<string>('')
  const [sortBy, setSortBy] = useState<'newest' | 'price-low' | 'price-high' | 'rarity' | 'volume'>('newest')
  const [filterRarity, setFilterRarity] = useState<'all' | 'common' | 'rare' | 'epic' | 'legendary'>('all')
  const [filterGenre, setFilterGenre] = useState<string>('all')
  const { subscription, checkFeatureAccess } = useSubscription()

  const getRarityColor = (rarity: NFTTrack['rarity']): string => {
    switch (rarity) {
      case 'legendary': return 'bg-gradient-to-r from-yellow-400 to-orange-500'
      case 'epic': return 'bg-gradient-to-r from-purple-400 to-pink-500'
      case 'rare': return 'bg-gradient-to-r from-blue-400 to-cyan-500'
      default: return 'bg-gradient-to-r from-gray-400 to-gray-600'
    }
  }

  const getRarityBorder = (rarity: NFTTrack['rarity']): string => {
    switch (rarity) {
      case 'legendary': return 'border-yellow-400'
      case 'epic': return 'border-purple-400'
      case 'rare': return 'border-blue-400'
      default: return 'border-gray-400'
    }
  }

  const formatDuration = (seconds: number): string => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const handleBuy = async (nft: NFTTrack): Promise<void> => {
    if (!checkFeatureAccess('nft_trading')) {
      toast.error('Upgrade to Enterprise to trade NFTs!')
      return
    }

    try {
      const response = await fetch('/api/nft/buy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          tokenId: nft.tokenId,
          price: nft.salePrice,
          blockchain: nft.blockchain 
        })
      })

      if (response.ok) {
        toast.success(`Successfully purchased "${nft.title}" for ${Math.round(nft.salePrice * 1000)} FAIR!`)
        // Update NFT ownership locally
        setNfts(prev => prev.map(n => 
          n.id === nft.id 
            ? { ...n, isForSale: false, owner: 'You', lastSalePrice: nft.salePrice }
            : n
        ))
      } else {
        toast.error('Purchase failed. Please try again.')
      }
    } catch (error) {
      toast.error('Network error. Please check your connection.')
    }
  }

  const handleViewDetails = (nft: NFTTrack): void => {
    setSelectedNFT(nft)
    setShowDetailsDialog(true)
  }

  const filteredAndSortedNFTs = nfts
    .filter(nft => {
      if (searchQuery && !nft.title.toLowerCase().includes(searchQuery.toLowerCase()) && 
          !nft.artist.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false
      }
      if (filterRarity !== 'all' && nft.rarity !== filterRarity) {
        return false
      }
      if (filterGenre !== 'all' && !nft.genre.some(g => g.toLowerCase().includes(filterGenre.toLowerCase()))) {
        return false
      }
      return true
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'price-low':
          return (a.isForSale ? a.salePrice : a.floorPrice) - (b.isForSale ? b.salePrice : b.floorPrice)
        case 'price-high':
          return (b.isForSale ? b.salePrice : b.floorPrice) - (a.isForSale ? a.salePrice : a.floorPrice)
        case 'rarity':
          const rarityOrder = { legendary: 4, epic: 3, rare: 2, common: 1 }
          return rarityOrder[b.rarity] - rarityOrder[a.rarity]
        case 'volume':
          return b.tradingVolume - a.tradingVolume
        default: // newest
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      }
    })

  const totalVolume = nfts.reduce((sum, nft) => sum + nft.tradingVolume, 0)
  const totalItems = nfts.length
  const averagePrice = nfts.reduce((sum, nft) => sum + (nft.isForSale ? nft.salePrice : nft.floorPrice), 0) / nfts.length

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent mb-4">
            NFT Marketplace
          </h1>
          <p className="text-gray-400 mb-6">
            Collect rare holographic music NFTs created by AI and human artists
          </p>

          {/* Stats Bar */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <Card className="bg-gray-900/50 border-gray-700">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-purple-400">{totalVolume.toFixed(1)}K FAIR</div>
                <div className="text-sm text-gray-400">Total Volume</div>
              </CardContent>
            </Card>
            <Card className="bg-gray-900/50 border-gray-700">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-cyan-400">{totalItems}</div>
                <div className="text-sm text-gray-400">Total Items</div>
              </CardContent>
            </Card>
            <Card className="bg-gray-900/50 border-gray-700">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-400">{(averagePrice * 1000).toFixed(0)} FAIR</div>
                <div className="text-sm text-gray-400">Avg. Price</div>
              </CardContent>
            </Card>
            <Card className="bg-gray-900/50 border-gray-700">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-yellow-400">{nfts.filter(n => n.isForSale).length}</div>
                <div className="text-sm text-gray-400">Listed</div>
              </CardContent>
            </Card>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search tracks, artists, or genres..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-gray-900/50 border-gray-700"
              />
            </div>
            
            <Select value={sortBy} onValueChange={(value) => setSortBy(value as any)}>
              <SelectTrigger className="w-full md:w-48 bg-gray-900/50 border-gray-700">
                <SelectValue placeholder="Sort by..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="rarity">Rarity</SelectItem>
                <SelectItem value="volume">Trading Volume</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterRarity} onValueChange={(value) => setFilterRarity(value as any)}>
              <SelectTrigger className="w-full md:w-32 bg-gray-900/50 border-gray-700">
                <SelectValue placeholder="Rarity" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Rarities</SelectItem>
                <SelectItem value="common">Common</SelectItem>
                <SelectItem value="rare">Rare</SelectItem>
                <SelectItem value="epic">Epic</SelectItem>
                <SelectItem value="legendary">Legendary</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* NFT Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredAndSortedNFTs.map((nft) => (
            <Card key={nft.id} className={`bg-gray-900/50 border-2 ${getRarityBorder(nft.rarity)} hover:bg-gray-800/50 transition-all duration-300 group`}>
              <CardHeader className="pb-3">
                <div className="relative">
                  <img
                    src={nft.coverArt}
                    alt={nft.title}
                    className="w-full h-48 object-cover rounded-lg mb-3"
                  />
                  
                  {/* Rarity Badge */}
                  <div className={`absolute top-2 right-2 px-2 py-1 rounded-full text-xs font-bold text-white ${getRarityColor(nft.rarity)}`}>
                    {nft.rarity.toUpperCase()}
                  </div>

                  {/* For Sale Badge */}
                  {nft.isForSale && (
                    <div className="absolute top-2 left-2 bg-green-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                      FOR SALE
                    </div>
                  )}

                  {/* Play Button Overlay */}
                  <div className="absolute bottom-2 right-2 bg-black/70 backdrop-blur-sm rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="icon" className="w-8 h-8">
                      <Play className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <CardTitle className="text-lg font-bold text-white truncate">
                    {nft.title}
                  </CardTitle>
                  
                  <div className="flex items-center gap-2">
                    <Avatar className="w-5 h-5">
                      <AvatarImage src={nft.artistAvatar} />
                      <AvatarFallback>{nft.artist[0]}</AvatarFallback>
                    </Avatar>
                    <span className="text-sm text-gray-400 truncate">{nft.artist}</span>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="pt-0">
                {/* Genre Tags */}
                <div className="flex flex-wrap gap-1 mb-3">
                  {nft.genre.slice(0, 2).map((g) => (
                    <Badge key={g} variant="secondary" className="text-xs">
                      {g}
                    </Badge>
                  ))}
                </div>

                {/* Stats */}
                <div className="flex items-center justify-between text-xs text-gray-400 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3" />
                      {nft.views.toLocaleString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <Heart className="w-3 h-3" />
                      {nft.likes}
                    </span>
                  </div>
                  <span>{formatDuration(nft.duration)}</span>
                </div>

                {/* NFT Info */}
                <div className="bg-gray-800/50 rounded-lg p-3 mb-4">
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="text-gray-400">Edition:</span>
                    <span className="text-white">#{nft.tokenId}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="text-gray-400">Supply:</span>
                    <span className="text-white">{nft.mintCount}/{nft.maxMints}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-400">Blockchain:</span>
                    <Badge className="bg-blue-600 text-white px-1 py-0 text-xs">
                      {nft.blockchain.toUpperCase()}
                    </Badge>
                  </div>
                </div>

                {/* Pricing */}
                <div className="space-y-2 mb-4">
                  {nft.isForSale ? (
                    <div>
                      <div className="text-xs text-gray-400 mb-1">Current Price</div>
                      <div className="text-xl font-bold text-green-400">
                        {Math.round(nft.salePrice * 1000)} FAIR
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div className="text-xs text-gray-400 mb-1">Floor Price</div>
                      <div className="text-xl font-bold text-gray-300">
                        {Math.round(nft.floorPrice * 1000)} FAIR
                      </div>
                    </div>
                  )}
                  
                  {nft.lastSalePrice > 0 && (
                    <div className="text-xs text-gray-400">
                      Last sold: {Math.round(nft.lastSalePrice * 1000)} FAIR
                    </div>
                  )}
                </div>

                {/* Owner */}
                <div className="flex items-center gap-2 mb-4">
                  <Avatar className="w-5 h-5">
                    <AvatarImage src={nft.ownerAvatar} />
                    <AvatarFallback>{nft.owner[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="text-xs text-gray-400">Owned by</div>
                    <div className="text-xs font-semibold">{nft.owner}</div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  {nft.isForSale ? (
                    <Button
                      onClick={() => handleBuy(nft)}
                      className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                      disabled={!checkFeatureAccess('nft_trading')}
                    >
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      Buy Now
                    </Button>
                  ) : (
                    <Button
                      variant="outline"
                      className="flex-1"
                      disabled
                    >
                      Not Listed
                    </Button>
                  )}
                  
                  <Button
                    variant="outline"
                    onClick={() => handleViewDetails(nft)}
                    className="px-3"
                  >
                    <Eye className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {filteredAndSortedNFTs.length === 0 && (
          <div className="text-center py-12">
            <Search className="w-12 h-12 text-gray-500 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">No NFTs found</h3>
            <p className="text-gray-400">Try adjusting your search or filter criteria</p>
          </div>
        )}

        {/* Subscription Upgrade Banner */}
        {subscription === 'free' && (
          <div className="mt-12 bg-gradient-to-r from-purple-900/50 to-cyan-900/50 border border-purple-500 rounded-xl p-6 text-center">
            <Crown className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2">Unlock NFT Trading</h3>
            <p className="text-gray-400 mb-4">
              Upgrade to Enterprise to buy, sell, and trade music NFTs in our marketplace
            </p>
            <Button className="bg-gradient-to-r from-purple-600 to-cyan-600">
              Upgrade to Enterprise
            </Button>
          </div>
        )}
      </div>

      {/* NFT Details Dialog */}
      {selectedNFT && showDetailsDialog && (
        <NFTDetailsDialog
          nft={selectedNFT}
          open={showDetailsDialog}
          onClose={() => setShowDetailsDialog(false)}
        />
      )}
    </div>
  )
}