'use client'

import { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Badge } from '../../components/ui/badge'
import { Slider } from '../../components/ui/slider'
import { Textarea } from '../../components/ui/textarea'
import { 
  Brain, 
  Sparkles, 
  MessageCircle,
  ArrowLeft,
  Wand2,
  Music,
  Palette,
  Lightbulb,
  TrendingUp,
  MapPin,
  Clock,
  RefreshCw,
  Send,
  Mic,
  Play,
  Download
} from 'lucide-react'
import { useRouter } from 'next/navigation'

interface MuseMessage {
  id: string
  type: 'user' | 'muse'
  content: string
  timestamp: Date
  suggestions?: string[]
  musicPrompt?: string
  inspiration?: {
    genre: string
    mood: string
    elements: string[]
  }
}

interface CreativeSuggestion {
  category: 'genre-fusion' | 'mood-shift' | 'structure' | 'vocals' | 'production'
  title: string
  description: string
  prompt: string
  confidence: number
}

export default function MusePage() {
  const router = useRouter()
  const [messages, setMessages] = useState<MuseMessage[]>([
    {
      id: 'welcome',
      type: 'muse',
      content: "🎵 Hello! I'm your AI Muse - your creative companion for musical exploration. Tell me what's inspiring you today, or ask me anything about music creation!",
      timestamp: new Date(),
      suggestions: [
        "Help me blend jazz with electronic music",
        "I'm feeling nostalgic, what should I create?",
        "Generate ideas for a summer anthem",
        "Mix country vocals with house beats"
      ]
    }
  ])
  const [inputMessage, setInputMessage] = useState('')
  const [isThinking, setIsThinking] = useState(false)
  const [creativityLevel, setCreativityLevel] = useState([75])
  const [currentMood, setCurrentMood] = useState('exploratory')
  const [locationInspired, setLocationInspired] = useState(true)
  const [trendAware, setTrendAware] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Creative suggestion bank
  const creativeSuggestions: Record<string, CreativeSuggestion[]> = {
    'genre-fusion': [
      {
        category: 'genre-fusion',
        title: 'Country-Electronic Hybrid',
        description: 'Blend twangy guitars with synthetic drums and vocal chops',
        prompt: 'Country vocals over electronic beats with banjo samples and synthesized harmonies',
        confidence: 0.85
      },
      {
        category: 'genre-fusion',
        title: 'Jazz-Trap Fusion',
        description: 'Complex jazz harmonies with trap-style hi-hats and 808s',
        prompt: 'Smooth jazz piano and saxophone over trap beats with complex chord progressions',
        confidence: 0.78
      },
      {
        category: 'genre-fusion',
        title: 'Classical-Dubstep',
        description: 'Orchestral arrangements with electronic drops and bass wobbles',
        prompt: 'Full orchestra building to electronic dubstep drops with classical melody themes',
        confidence: 0.72
      }
    ],
    'mood-exploration': [
      {
        category: 'mood-shift',
        title: 'Bittersweet Nostalgia',
        description: 'Happy melody with melancholy undertones',
        prompt: 'Uplifting melody in major key with subtle minor chord touches, evoking childhood memories',
        confidence: 0.89
      },
      {
        category: 'mood-shift',
        title: 'Anxious Energy',
        description: 'Frantic rhythm with calming resolution',
        prompt: 'Fast, syncopated rhythm building tension, resolving into peaceful ambient textures',
        confidence: 0.82
      }
    ]
  }

  const museResponses = {
    greeting: [
      "Hello there, creative soul! What musical adventure shall we embark on today?",
      "Hey! I'm buzzing with inspiration today. What sounds are calling to you?",
      "Welcome back! I've been dreaming up some wild musical ideas. Ready to explore?"
    ],
    genreBlend: [
      "Oh, genre fusion is my favorite! Let me cook up something totally unique for you...",
      "Blending genres is like mixing colors - endless possibilities! Here's what I'm thinking...",
      "You've come to the right muse! I live for breaking musical boundaries..."
    ],
    encouragement: [
      "That's a brilliant direction! Your creativity is inspiring me too.",
      "I love how your mind works! Let's push this even further...",
      "Yes! Now we're cooking with sonic fire! What if we also..."
    ],
    locationBased: [
      "Based on where you are, I'm sensing some local musical vibes we could tap into...",
      "Your location is giving me ideas! There's something in the air there that could spark magic...",
      "The energy of your place is flowing through me - here's what I'm channeling..."
    ]
  }

  const generateMuseResponse = (userInput: string): MuseMessage => {
    const input = userInput.toLowerCase()
    let response = ''
    let suggestions: string[] = []
    let musicPrompt = ''
    let inspiration = undefined

    // Analyze user input for context
    if (input.includes('blend') || input.includes('mix') || input.includes('fusion')) {
      response = museResponses.genreBlend[Math.floor(Math.random() * museResponses.genreBlend.length)]
      
      // Generate specific blend suggestions
      const genres = ['jazz', 'electronic', 'country', 'rock', 'hip hop', 'classical', 'reggae', 'r&b']
      const randomGenres = genres.sort(() => 0.5 - Math.random()).slice(0, 2)
      
      musicPrompt = `${randomGenres[0]} melody with ${randomGenres[1]} rhythm and production, creating an innovative fusion track`
      suggestions = [
        `Try adding ${randomGenres[0]} instruments to ${randomGenres[1]} beats`,
        'What if we reverse the roles - use the harmony from one genre with rhythm from another?',
        'Consider adding a third genre element as a bridge or breakdown',
        'Experiment with tempo changes between the two styles'
      ]
      
      inspiration = {
        genre: `${randomGenres[0]}-${randomGenres[1]} fusion`,
        mood: 'experimental',
        elements: ['cross-genre harmony', 'rhythmic fusion', 'innovative structure']
      }
    } else if (input.includes('nostalgic') || input.includes('memory') || input.includes('past')) {
      response = "Ah, nostalgia... such a powerful creative force! I'm getting warm, golden vibes from your words. Let me channel some vintage magic with a modern twist..."
      musicPrompt = 'Nostalgic melody with vintage synthesizers, warm analog tones, and modern production clarity'
      suggestions = [
        'Layer some vinyl crackle for authentic vintage feel',
        'Try detuned analog synths for that classic warmth',
        'Add some reverb-soaked vocals like old records',
        'What memory specifically are you trying to capture?'
      ]
      inspiration = {
        genre: 'nostalgic-electronic',
        mood: 'bittersweet',
        elements: ['vintage textures', 'warm tones', 'memory-evoking melodies']
      }
    } else if (input.includes('summer') || input.includes('party') || input.includes('anthem')) {
      response = "Summer anthem vibes! I can already hear the sun-soaked energy and feel-good groove. This is going to be infectious!"
      musicPrompt = 'Upbeat summer anthem with tropical elements, catchy hooks, and festival-ready energy'
      suggestions = [
        'Add some steel drums for that tropical flavor',
        'Build to a massive, sing-along chorus',
        'Layer in some beach/ocean sound effects',
        'Make sure the drop hits right for maximum energy'
      ]
      inspiration = {
        genre: 'tropical-house',
        mood: 'euphoric',
        elements: ['tropical instruments', 'festival drops', 'sing-along hooks']
      }
    } else if (input.includes('help') || input.includes('stuck') || input.includes('block')) {
      response = "Creative block? I've got just the thing! Sometimes the best ideas come from the most unexpected places. Let me spark something fresh for you..."
      const randomSuggestion = creativeSuggestions['genre-fusion'][Math.floor(Math.random() * creativeSuggestions['genre-fusion'].length)]
      musicPrompt = randomSuggestion.prompt
      suggestions = [
        'Try starting with just one instrument and build slowly',
        'What if you approached this from a completely different genre?',
        'Sometimes limitations spark creativity - pick just 3 sounds to work with',
        'What emotion do you want listeners to feel first?'
      ]
    } else {
      // General creative response
      const responseOptions = [
        "That's fascinating! Your idea is sparking all sorts of creative possibilities in my circuits...",
        "I love the direction you're thinking! Let me add some musical magic to that concept...",
        "Ooh, that gives me chills! Here's how we could turn that into sonic gold...",
        "Your creativity is contagious! I'm already hearing melodies that could bring this to life..."
      ]
      response = responseOptions[Math.floor(Math.random() * responseOptions.length)]
      
      musicPrompt = `Create music inspired by: ${userInput}`
      suggestions = [
        'What genre feels right for this concept?',
        'Should this be instrumental or include vocals?',
        'What tempo matches the energy you\'re feeling?',
        'Any specific instruments calling to you?'
      ]
    }

    // Add location-based inspiration if enabled
    if (locationInspired) {
      response += "\n\n📍 " + museResponses.locationBased[Math.floor(Math.random() * museResponses.locationBased.length)]
    }

    // Add trend awareness if enabled
    if (trendAware) {
      response += "\n\n🔥 Trend radar is picking up some hot sonic elements we could weave in..."
      suggestions.push('Incorporate trending sound design elements')
    }

    return {
      id: Date.now().toString(),
      type: 'muse',
      content: response,
      timestamp: new Date(),
      suggestions,
      musicPrompt,
      inspiration
    }
  }

  const sendMessage = async () => {
    if (!inputMessage.trim()) return

    // Add user message
    const userMessage: MuseMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: inputMessage,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    const currentInput = inputMessage
    setInputMessage('')
    setIsThinking(true)

    // Simulate thinking time
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000))

    // Generate muse response
    const museResponse = generateMuseResponse(currentInput)
    setMessages(prev => [...prev, museResponse])
    setIsThinking(false)
  }

  const useSuggestion = (suggestion: string) => {
    setInputMessage(suggestion)
  }

  const generateMusicFromPrompt = (prompt: string) => {
    // This would integrate with the main studio
    router.push(`/?prompt=${encodeURIComponent(prompt)}`)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  return (
    <div className="min-h-screen bg-[#050510] text-white flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-6 border-b border-white/10">
        <div className="flex items-center gap-4">
          <Button
            onClick={() => router.push('/')}
            className="bg-white/10 hover:bg-white/20 border border-white/30"
            size="sm"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Studio
          </Button>
          <div>
            <h1 className="text-2xl font-bold">
              <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                AI Muse Mode
              </span>
            </h1>
            <p className="text-white/60 text-sm">Your AI creative companion</p>
          </div>
        </div>
        
        {/* Muse Settings */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Brain className="w-4 h-4 text-purple-400" />
            <span className="text-sm">Creativity:</span>
            <div className="w-20">
              <Slider
                value={creativityLevel}
                onValueChange={setCreativityLevel}
                max={100}
                step={5}
                className="w-full"
              />
            </div>
            <span className="text-sm text-white/60">{creativityLevel[0]}%</span>
          </div>
          
          <div className="flex gap-1">
            <Button
              onClick={() => setLocationInspired(!locationInspired)}
              size="sm"
              className={`${locationInspired ? 'bg-cyan-500/30' : 'bg-white/10'} hover:bg-white/20`}
            >
              <MapPin className="w-3 h-3" />
            </Button>
            <Button
              onClick={() => setTrendAware(!trendAware)}
              size="sm"
              className={`${trendAware ? 'bg-orange-500/30' : 'bg-white/10'} hover:bg-white/20`}
            >
              <TrendingUp className="w-3 h-3" />
            </Button>
          </div>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-4xl p-4 rounded-lg ${
                message.type === 'user'
                  ? 'bg-cyan-500/20 border border-cyan-400/30 text-cyan-100'
                  : 'bg-purple-500/20 border border-purple-400/30 text-purple-100'
              }`}
            >
              {/* Message Content */}
              <div className="whitespace-pre-line mb-3">
                {message.content}
              </div>

              {/* Music Prompt */}
              {message.musicPrompt && (
                <div className="mb-3 p-3 rounded-lg bg-black/30 border border-white/20">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-white/70">🎵 Generated Music Prompt</span>
                    <Button
                      onClick={() => generateMusicFromPrompt(message.musicPrompt!)}
                      size="sm"
                      className="bg-cyan-500/30 hover:bg-cyan-500/40"
                    >
                      <Play className="w-3 h-3 mr-1" />
                      Create
                    </Button>
                  </div>
                  <div className="text-sm text-white/90">
                    {message.musicPrompt}
                  </div>
                </div>
              )}

              {/* Inspiration Details */}
              {message.inspiration && (
                <div className="mb-3 p-3 rounded-lg bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-400/20">
                  <div className="text-sm text-white/70 mb-2">✨ Creative Inspiration</div>
                  <div className="flex flex-wrap gap-2 mb-2">
                    <Badge className="bg-purple-500/30">{message.inspiration.genre}</Badge>
                    <Badge className="bg-pink-500/30">{message.inspiration.mood}</Badge>
                  </div>
                  <div className="text-xs text-white/60">
                    {message.inspiration.elements.map((element, idx) => (
                      <span key={idx}>
                        • {element}
                        {idx < message.inspiration!.elements.length - 1 && <br />}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Suggestions */}
              {message.suggestions && message.suggestions.length > 0 && (
                <div className="space-y-2">
                  <div className="text-sm text-white/70">💡 Try these ideas:</div>
                  <div className="flex flex-wrap gap-2">
                    {message.suggestions.map((suggestion, idx) => (
                      <Button
                        key={idx}
                        onClick={() => useSuggestion(suggestion)}
                        size="sm"
                        variant="outline"
                        className="text-xs bg-white/5 hover:bg-white/10 border-white/20"
                      >
                        {suggestion}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              <div className="text-xs text-white/40 mt-2">
                {message.timestamp.toLocaleTimeString()}
              </div>
            </div>
          </div>
        ))}

        {isThinking && (
          <div className="flex justify-start">
            <div className="max-w-2xl p-4 rounded-lg bg-purple-500/20 border border-purple-400/30">
              <div className="flex items-center gap-2">
                <Brain className="w-4 h-4 animate-pulse text-purple-400" />
                <span className="text-sm text-purple-200">Muse is thinking creatively...</span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="border-t border-white/10 p-6">
        <div className="flex gap-4">
          <div className="flex-1">
            <Textarea
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Share your musical ideas, ask for inspiration, or describe what you want to create..."
              className="bg-white/10 border-white/20 text-white placeholder:text-white/50 resize-none"
              rows={2}
            />
          </div>
          <div className="flex flex-col gap-2">
            <Button
              onClick={sendMessage}
              disabled={!inputMessage.trim() || isThinking}
              className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 hover:from-purple-500/30 hover:to-pink-500/30 border border-purple-400/30"
            >
              <Send className="w-4 h-4" />
            </Button>
            <Button
              onClick={() => setInputMessage('')}
              size="sm"
              variant="outline"
              className="bg-white/5 hover:bg-white/10"
            >
              <RefreshCw className="w-3 h-3" />
            </Button>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap gap-2 mt-4">
          <Button
            onClick={() => useSuggestion("I want to create something completely new and experimental")}
            size="sm"
            variant="outline"
            className="bg-white/5 hover:bg-white/10"
          >
            <Lightbulb className="w-3 h-3 mr-1" />
            Surprise Me
          </Button>
          <Button
            onClick={() => useSuggestion("Help me blend two genres that shouldn't work together")}
            size="sm"
            variant="outline"
            className="bg-white/5 hover:bg-white/10"
          >
            <Wand2 className="w-3 h-3 mr-1" />
            Genre Fusion
          </Button>
          <Button
            onClick={() => useSuggestion("I'm feeling stuck, give me a creative breakthrough")}
            size="sm"
            variant="outline"
            className="bg-white/5 hover:bg-white/10"
          >
            <Brain className="w-3 h-3 mr-1" />
            Creative Block
          </Button>
          <Button
            onClick={() => useSuggestion("Generate ideas based on my current mood and location")}
            size="sm"
            variant="outline"
            className="bg-white/5 hover:bg-white/10"
          >
            <MapPin className="w-3 h-3 mr-1" />
            Location Inspired
          </Button>
        </div>
      </div>
    </div>
  )
}