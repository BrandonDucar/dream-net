'use client'
import { Suspense, useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import { SonicPrismProvider } from '../components/sonic-prism/SonicPrismProvider';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Play, 
  Wand2, 
  Search, 
  MessageCircle, 
  Palette, 
  Users, 
  Trophy, 
  ShoppingBag,
  MapPin,
  Brain,
  Zap,
  Music,
  Sparkles,
  ChevronRight,
  ArrowRight,
  Headphones,
  Download,
  Share2,
  TrendingUp,
  DollarSign,
  PieChart,
  BarChart3
} from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

// Dynamic import to prevent SSR issues with Three.js
const SonicPrismStudio = dynamic(
  () => import('../components/sonic-prism/SonicPrismStudio'),
  { ssr: false, loading: () => <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 text-white">Initializing Holographic Interface...</div> }
);

interface PortfolioStatProps {
  title: string;
  value: string;
  change: string;
  changeType: 'positive' | 'negative' | 'neutral';
  icon: React.ReactNode;
}

function PortfolioStat({ title, value, change, changeType, icon }: PortfolioStatProps) {
  return (
    <Card className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 border border-white/10 backdrop-blur-sm">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="p-2 bg-white/10 rounded-lg backdrop-blur-sm">
            {icon}
          </div>
          <Badge 
            className={`${
              changeType === 'positive' ? 'bg-green-500/20 text-green-400' :
              changeType === 'negative' ? 'bg-red-500/20 text-red-400' :
              'bg-gray-500/20 text-gray-400'
            } border-0`}
          >
            {change}
          </Badge>
        </div>
        <div className="space-y-1">
          <p className="text-2xl font-bold text-white">{value}</p>
          <p className="text-sm text-gray-400">{title}</p>
        </div>
      </CardContent>
    </Card>
  );
}

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  badge?: string;
  onClick: () => void;
  gradient: string;
  stats?: { label: string; value: string }[];
}

function FeatureCard({ icon, title, description, badge, onClick, gradient, stats }: FeatureCardProps) {
  return (
    <Card 
      className={`bg-gradient-to-br ${gradient} border-0 hover:scale-105 transition-all duration-500 cursor-pointer group overflow-hidden relative`}
      onClick={onClick}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      <CardHeader className="relative z-10">
        <div className="flex items-center justify-between mb-2">
          <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
            {icon}
          </div>
          {badge && (
            <Badge className="bg-white/20 text-white border-white/30 backdrop-blur-sm">
              {badge}
            </Badge>
          )}
        </div>
        <CardTitle className="text-white text-xl font-bold">{title}</CardTitle>
      </CardHeader>
      <CardContent className="relative z-10">
        <p className="text-white/90 mb-4">{description}</p>
        
        {stats && (
          <div className="grid grid-cols-2 gap-3 mb-4">
            {stats.map((stat, idx) => (
              <div key={idx} className="text-center">
                <div className="text-lg font-bold text-white">{stat.value}</div>
                <div className="text-xs text-white/70">{stat.label}</div>
              </div>
            ))}
          </div>
        )}
        
        <div className="flex items-center text-white/80 group-hover:text-white transition-colors">
          <span className="text-sm font-medium">Explore</span>
          <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
        </div>
      </CardContent>
    </Card>
  );
}

interface InvestmentOpportunityProps {
  title: string;
  artist: string;
  genre: string;
  apy: string;
  minInvestment: string;
  totalRaised: string;
  imageUrl?: string;
  riskLevel: 'low' | 'medium' | 'high';
}

function InvestmentOpportunity({ title, artist, genre, apy, minInvestment, totalRaised, imageUrl, riskLevel }: InvestmentOpportunityProps) {
  return (
    <Card className="bg-gradient-to-br from-gray-900/80 to-gray-800/40 border border-white/20 hover:border-white/40 transition-all duration-300 cursor-pointer group">
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-cyan-500/20 to-purple-500/20 flex items-center justify-center overflow-hidden">
            {imageUrl ? (
              <img src={imageUrl} alt={title} className="w-full h-full object-cover" />
            ) : (
              <Music className="w-8 h-8 text-white/60" />
            )}
          </div>
          <div className="flex-1">
            <div className="flex items-start justify-between mb-2">
              <div>
                <h3 className="font-semibold text-white group-hover:text-cyan-300 transition-colors">{title}</h3>
                <p className="text-sm text-gray-400">{artist}</p>
              </div>
              <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                {apy} APY
              </Badge>
            </div>
            
            <div className="flex items-center gap-4 text-sm text-gray-400 mb-3">
              <span>{genre}</span>
              <span>•</span>
              <span>Min: {minInvestment}</span>
              <span>•</span>
              <Badge 
                className={`text-xs ${
                  riskLevel === 'low' ? 'bg-green-500/20 text-green-400' :
                  riskLevel === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                  'bg-red-500/20 text-red-400'
                } border-0`}
              >
                {riskLevel.toUpperCase()} RISK
              </Badge>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs text-gray-400">Total Raised</span>
                <div className="font-semibold text-white">{totalRaised}</div>
              </div>
              <Button size="sm" className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white border-0">
                Invest
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Page() {
  const [currentView, setCurrentView] = useState<'landing' | 'studio'>('landing');
  const [isVisible, setIsVisible] = useState(false);
  
  const { addMiniApp } = useAddMiniApp();
  const isInFarcaster = useIsInFarcaster()
  useQuickAuth(isInFarcaster)

  useEffect(() => {
    setIsVisible(true);
    
    const tryAddMiniApp = async () => {
      try {
        await addMiniApp()
      } catch (error) {
        console.error('Failed to add mini app:', error)
      }
    }

    tryAddMiniApp()
  }, [addMiniApp])

  useEffect(() => {
    const initializeFarcaster = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 100))
        
        if (document.readyState !== 'complete') {
          await new Promise<void>(resolve => {
            if (document.readyState === 'complete') {
              resolve()
            } else {
              window.addEventListener('load', () => resolve(), { once: true })
            }
          })
        }

        await sdk.actions.ready()
        console.log('Farcaster SDK initialized successfully - app fully loaded')
      } catch (error) {
        console.error('Failed to initialize Farcaster SDK:', error)
        
        setTimeout(async () => {
          try {
            await sdk.actions.ready()
            console.log('Farcaster SDK initialized on retry')
          } catch (retryError) {
            console.error('Farcaster SDK retry failed:', retryError)
          }
        }, 1000)
      }
    }

    initializeFarcaster()
  }, [])

  if (currentView === 'studio') {
    return (
      <main className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 relative overflow-hidden">
        <SonicPrismProvider>
          <Suspense fallback={<div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 text-white">Loading DreamStar Music...</div>}>
            <SonicPrismStudio />
          </Suspense>
          {/* Back to Landing Button */}
          <button
            onClick={() => setCurrentView('landing')}
            className="absolute top-4 left-4 z-50 p-3 bg-black/40 hover:bg-black/60 border border-white/20 rounded-xl backdrop-blur-md text-white transition-all duration-300 hover:scale-105"
          >
            <ChevronRight className="w-5 h-5 rotate-180" />
          </button>
        </SonicPrismProvider>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-900 via-indigo-900 to-purple-900 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-20 w-72 h-72 bg-cyan-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
        <div className="absolute top-40 right-20 w-72 h-72 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-2s"></div>
        <div className="absolute -bottom-8 left-20 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-4s"></div>
      </div>

      <div className={`relative z-10 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
        {/* Header with Portfolio-Style Navigation */}
        <header className="px-4 py-6 border-b border-white/10 backdrop-blur-md">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-gradient-to-br from-cyan-500 to-purple-600 rounded-2xl">
                    <Music className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h1 className="text-2xl md:text-3xl font-bold text-white">
                      DreamStar Music
                    </h1>
                    <p className="text-cyan-300 text-sm">Holographic AI Music Platform</p>
                  </div>
                </div>
                
                {/* Portfolio-style nav links */}
                <nav className="hidden lg:flex items-center gap-1 bg-black/20 rounded-xl p-1">
                  <Button variant="ghost" className="text-white/70 hover:text-white hover:bg-white/10 text-sm px-4">
                    Studio
                  </Button>
                  <Button variant="ghost" className="text-white/70 hover:text-white hover:bg-white/10 text-sm px-4">
                    Marketplace
                  </Button>
                  <Button variant="ghost" className="text-white/70 hover:text-white hover:bg-white/10 text-sm px-4">
                    Portfolio
                  </Button>
                  <Button variant="ghost" className="text-white/70 hover:text-white hover:bg-white/10 text-sm px-4">
                    Analytics
                  </Button>
                </nav>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="hidden md:flex items-center gap-3 text-sm">
                  <div className="text-center">
                    <div className="text-green-400 font-semibold">+15.2%</div>
                    <div className="text-gray-400 text-xs">Portfolio</div>
                  </div>
                  <div className="text-center">
                    <div className="text-white font-semibold">2.4K FAIR</div>
                    <div className="text-gray-400 text-xs">Earnings</div>
                  </div>
                </div>
                <Button 
                  className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white border-0"
                  onClick={() => setCurrentView('studio')}
                >
                  Launch Studio
                </Button>
              </div>
            </div>
          </div>
        </header>

        {/* Hero Section with Portfolio Stats */}
        <section className="px-4 py-8">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-8">
              <Badge className="bg-gradient-to-r from-cyan-500/20 to-purple-600/20 text-cyan-300 border-cyan-500/30 mb-4 px-4 py-2">
                Revolutionary AI Music Investment Platform
              </Badge>
              
              <h2 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
                Create Music With AI
                <span className="bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent block">
                  Invest In The Future
                </span>
              </h2>
              
              <p className="text-xl text-white/90 mb-8 leading-relaxed max-w-3xl mx-auto">
                Generate original tracks with AI, visualize in holographic 3D, and build your music investment portfolio. 
                Join 20,000+ creators earning 7.5% - 20% APY from music rights and NFT trading.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
                <Button 
                  size="lg"
                  className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white border-0 px-8 py-6 text-lg font-semibold"
                  onClick={() => setCurrentView('studio')}
                >
                  <Wand2 className="w-5 h-5 mr-2" />
                  Start Creating
                </Button>
                <Button 
                  size="lg"
                  variant="outline"
                  className="border-white/20 text-white hover:bg-white/10 px-8 py-6 text-lg"
                  onClick={() => window.location.href = '/marketplace'}
                >
                  <DollarSign className="w-5 h-5 mr-2" />
                  Browse Investments
                </Button>
              </div>
            </div>

            {/* Portfolio Stats Dashboard */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <PortfolioStat
                icon={<TrendingUp className="w-5 h-5 text-cyan-400" />}
                title="Platform Volume"
                value="247K FAIR"
                change="+24.5%"
                changeType="positive"
              />
              <PortfolioStat
                icon={<Users className="w-5 h-5 text-purple-400" />}
                title="Active Investors"
                value="20.1K+"
                change="+12.8%"
                changeType="positive"
              />
              <PortfolioStat
                icon={<Music className="w-5 h-5 text-pink-400" />}
                title="Tracks Created"
                value="50.2K+"
                change="+18.3%"
                changeType="positive"
              />
              <PortfolioStat
                icon={<ShoppingBag className="w-5 h-5 text-green-400" />}
                title="NFTs Minted"
                value="15.7K+"
                change="+31.2%"
                changeType="positive"
              />
            </div>
          </div>
        </section>

        {/* Investment Opportunities Section */}
        <section className="px-4 py-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-2xl font-bold text-white mb-2">Featured Investment Opportunities</h3>
                <p className="text-gray-400">High-yield music rights and NFT collections</p>
              </div>
              <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
                View All
              </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-8">
              <InvestmentOpportunity
                title="ATLiens Remix Collection"
                artist="AI-Generated OutKast Style"
                genre="Hip-Hop/Electronic"
                apy="18.5%"
                minInvestment="100 FAIR"
                totalRaised="45.2K FAIR"
                riskLevel="medium"
              />
              <InvestmentOpportunity
                title="Holographic Pop Hits"
                artist="Various AI Artists"
                genre="Pop/Synthwave"
                apy="12.3%"
                minInvestment="50 FAIR"
                totalRaised="127.8K FAIR"
                riskLevel="low"
              />
            </div>
          </div>
        </section>

        {/* Features Grid with Investment Stats */}
        <section className="px-4 py-12">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <h3 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Your Complete Music Investment Suite
              </h3>
              <p className="text-gray-300 text-lg">
                Create, invest, and profit from the future of music
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
              <FeatureCard
                icon={<Wand2 className="w-6 h-6 text-white" />}
                title="Holographic Studio"
                description="Create music in 3D space with AI prisms and real-time visualization"
                badge="Create"
                onClick={() => setCurrentView('studio')}
                gradient="from-cyan-600 via-blue-600 to-purple-600"
                stats={[
                  { label: "Tracks/Day", value: "420+" },
                  { label: "AI Models", value: "8" }
                ]}
              />
              
              <FeatureCard
                icon={<ShoppingBag className="w-6 h-6 text-white" />}
                title="NFT Marketplace"
                description="Trade music NFTs with rarity mechanics and automated royalty distribution"
                badge="Invest"
                onClick={() => window.location.href = '/marketplace'}
                gradient="from-yellow-500 via-amber-500 to-orange-500"
                stats={[
                  { label: "Avg APY", value: "15.2%" },
                  { label: "Collections", value: "2.4K" }
                ]}
              />
              
              <FeatureCard
                icon={<PieChart className="w-6 h-6 text-white" />}
                title="Portfolio Analytics"
                description="Track your music investments with real-time performance metrics"
                badge="Monitor"
                onClick={() => window.location.href = '/portfolio'}
                gradient="from-green-500 via-teal-500 to-cyan-500"
                stats={[
                  { label: "ROI", value: "+24.5%" },
                  { label: "Holdings", value: "47" }
                ]}
              />
              
              <FeatureCard
                icon={<Search className="w-6 h-6 text-white" />}
                title="Music Inspiration"
                description="Analyze existing tracks and create legal transformative works"
                badge="Analyze"
                onClick={() => window.location.href = '/inspiration'}
                gradient="from-orange-500 via-pink-500 to-red-500"
                stats={[
                  { label: "Songs Analyzed", value: "12.8K" },
                  { label: "Success Rate", value: "94%" }
                ]}
              />
              
              <FeatureCard
                icon={<Users className="w-6 h-6 text-white" />}
                title="Community Hub"
                description="Connect with artists, share creations, and discover investment opportunities"
                badge="Social"
                onClick={() => window.location.href = '/community'}
                gradient="from-purple-500 via-violet-500 to-indigo-500"
                stats={[
                  { label: "Members", value: "20.1K" },
                  { label: "Daily Active", value: "3.2K" }
                ]}
              />
              
              <FeatureCard
                icon={<BarChart3 className="w-6 h-6 text-white" />}
                title="Advanced Analytics"
                description="AI-powered market insights and investment recommendations"
                badge="Pro"
                onClick={() => window.location.href = '/analytics'}
                gradient="from-pink-500 via-rose-500 to-orange-500"
                stats={[
                  { label: "Accuracy", value: "91.3%" },
                  { label: "Predictions", value: "Daily" }
                ]}
              />
            </div>

            {/* Three-Step Process like Bolero */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <Card className="bg-gradient-to-br from-cyan-900/30 to-cyan-800/20 border border-cyan-500/30">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-cyan-500 to-cyan-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-white">1</span>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">Create & Mint</h3>
                  <p className="text-gray-300 text-sm">
                    Generate AI music in our holographic studio, then mint as NFTs with customizable rarity levels
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-purple-900/30 to-purple-800/20 border border-purple-500/30">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-white">2</span>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">Build Portfolio</h3>
                  <p className="text-gray-300 text-sm">
                    Invest in promising music NFTs and collections. Diversify across genres, artists, and risk levels
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-orange-900/30 to-orange-800/20 border border-orange-500/30">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-white">3</span>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">Earn Passively</h3>
                  <p className="text-gray-300 text-sm">
                    Collect royalties from streaming, licensing, and NFT trading. Average 7.5%-20% APY with automated payouts
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="px-4 py-8 border-t border-white/10 bg-black/20 backdrop-blur-sm">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-gradient-to-br from-cyan-500 to-purple-600 rounded-lg">
                    <Music className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <div className="text-white font-semibold">DreamStar Music</div>
                    <div className="text-gray-400 text-sm">Built on Base</div>
                  </div>
                </div>
                <p className="text-gray-400 text-sm">
                  The first holographic AI music investment platform combining creation and passive income.
                </p>
              </div>
              
              <div>
                <h4 className="text-white font-semibold mb-3">Platform</h4>
                <div className="space-y-2 text-sm">
                  <div className="text-gray-400 hover:text-white cursor-pointer">Studio</div>
                  <div className="text-gray-400 hover:text-white cursor-pointer">Marketplace</div>
                  <div className="text-gray-400 hover:text-white cursor-pointer">Portfolio</div>
                  <div className="text-gray-400 hover:text-white cursor-pointer">Analytics</div>
                </div>
              </div>
              
              <div>
                <h4 className="text-white font-semibold mb-3">Community</h4>
                <div className="space-y-2 text-sm">
                  <div className="text-gray-400 hover:text-white cursor-pointer">Discord</div>
                  <div className="text-gray-400 hover:text-white cursor-pointer">Twitter</div>
                  <div className="text-gray-400 hover:text-white cursor-pointer">Farcaster</div>
                  <div className="text-gray-400 hover:text-white cursor-pointer">Telegram</div>
                </div>
              </div>
              
              <div>
                <h4 className="text-white font-semibold mb-3">Resources</h4>
                <div className="space-y-2 text-sm">
                  <div className="text-gray-400 hover:text-white cursor-pointer">Documentation</div>
                  <div className="text-gray-400 hover:text-white cursor-pointer">API</div>
                  <div className="text-gray-400 hover:text-white cursor-pointer">Legal</div>
                  <div className="text-gray-400 hover:text-white cursor-pointer">Support</div>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-8 border-t border-white/10">
              <div className="text-gray-400 text-sm">
                © 2024 DreamStar Music. All rights reserved.
              </div>
              <div className="flex items-center gap-6 text-sm">
                <span className="text-green-400">Platform Volume: 247K FAIR</span>
                <span className="text-cyan-400">20K+ Active Investors</span>
                <span className="text-purple-400">Avg APY: 15.2%</span>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </main>
  );
}