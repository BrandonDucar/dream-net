'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { 
  TrendingUp, 
  DollarSign, 
  Music, 
  Trophy, 
  PieChart,
  BarChart3,
  ArrowLeft,
  Play,
  Heart,
  Download,
  Eye,
  Wallet,
  Target,
  Calendar,
  Award
} from 'lucide-react'
import { PageLayout } from '@/components/layout/PageLayout'
import { useRouter } from 'next/navigation'

interface PortfolioHolding {
  id: string
  title: string
  artist: string
  genre: string
  purchasePrice: number
  currentValue: number
  roi: number
  shares: number
  totalShares: number
  monthlyEarnings: number
  coverArt: string
  riskLevel: 'low' | 'medium' | 'high'
}

interface PersonalTrack {
  id: string
  title: string
  genre: string
  plays: number
  likes: number
  earnings: number
  nftsMinted: number
  coverArt: string
  createdAt: string
}

const mockHoldings: PortfolioHolding[] = [
  {
    id: '1',
    title: 'Neon Dreams Collection',
    artist: 'CyberPhoenix',
    genre: 'Synthwave',
    purchasePrice: 150,
    currentValue: 185,
    roi: 23.3,
    shares: 25,
    totalShares: 100,
    monthlyEarnings: 12.5,
    coverArt: 'https://images.unsplash.com/photo-1571330735066-03aaa9429d89?w=400&h=400&fit=crop',
    riskLevel: 'medium'
  },
  {
    id: '2',
    title: 'Jazz Fusion Classics',
    artist: 'QuantumVibes',
    genre: 'Jazz',
    purchasePrice: 200,
    currentValue: 245,
    roi: 22.5,
    shares: 50,
    totalShares: 200,
    monthlyEarnings: 18.2,
    coverArt: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=400&h=400&fit=crop',
    riskLevel: 'low'
  }
]

const mockPersonalTracks: PersonalTrack[] = [
  {
    id: '1',
    title: 'Holographic Nights',
    genre: 'Electronic',
    plays: 15420,
    likes: 892,
    earnings: 127.50,
    nftsMinted: 25,
    coverArt: 'https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop',
    createdAt: '2024-01-15'
  },
  {
    id: '2',
    title: 'Country Roads Remix',
    genre: 'Country Fusion',
    plays: 8934,
    likes: 623,
    earnings: 89.20,
    nftsMinted: 15,
    coverArt: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=400&fit=crop',
    createdAt: '2024-01-10'
  }
]

export default function PortfolioPage(): JSX.Element {
  const router = useRouter()
  const [selectedTab, setSelectedTab] = useState<'overview' | 'investments' | 'tracks'>('overview')
  const [totalPortfolioValue, setTotalPortfolioValue] = useState(0)
  const [totalMonthlyEarnings, setTotalMonthlyEarnings] = useState(0)
  const [totalROI, setTotalROI] = useState(0)

  useEffect(() => {
    // Calculate portfolio stats
    const totalValue = mockHoldings.reduce((sum, holding) => sum + holding.currentValue, 0)
    const totalEarnings = mockHoldings.reduce((sum, holding) => sum + holding.monthlyEarnings, 0)
    const totalInvestment = mockHoldings.reduce((sum, holding) => sum + holding.purchasePrice, 0)
    const avgROI = totalInvestment > 0 ? ((totalValue - totalInvestment) / totalInvestment) * 100 : 0

    setTotalPortfolioValue(totalValue)
    setTotalMonthlyEarnings(totalEarnings)
    setTotalROI(avgROI)
  }, [])

  const getRiskColor = (risk: PortfolioHolding['riskLevel']) => {
    switch (risk) {
      case 'low': return 'bg-green-500/20 text-green-400 border-green-500/30'
      case 'medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
      case 'high': return 'bg-red-500/20 text-red-400 border-red-500/30'
    }
  }

  return (
    <PageLayout
      title="Investment Portfolio"
      description="Track your music investments and personal earnings in real-time"
      gradient="from-green-400 to-blue-600"
    >
      {/* Portfolio Overview Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card className="bg-gradient-to-br from-green-900/50 to-green-800/30 border border-green-500/30">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-green-500/20 rounded-lg backdrop-blur-sm">
                <DollarSign className="w-5 h-5 text-green-400" />
              </div>
              <Badge className="bg-green-500/20 text-green-400 border-0">
                +{totalROI.toFixed(1)}%
              </Badge>
            </div>
            <div className="space-y-1">
              <p className="text-2xl font-bold text-white">{totalPortfolioValue} FAIR</p>
              <p className="text-sm text-gray-400">Portfolio Value</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-900/50 to-blue-800/30 border border-blue-500/30">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-blue-500/20 rounded-lg backdrop-blur-sm">
                <TrendingUp className="w-5 h-5 text-blue-400" />
              </div>
              <Badge className="bg-blue-500/20 text-blue-400 border-0">
                Monthly
              </Badge>
            </div>
            <div className="space-y-1">
              <p className="text-2xl font-bold text-white">{totalMonthlyEarnings.toFixed(1)} FAIR</p>
              <p className="text-sm text-gray-400">Passive Earnings</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-900/50 to-purple-800/30 border border-purple-500/30">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-purple-500/20 rounded-lg backdrop-blur-sm">
                <Music className="w-5 h-5 text-purple-400" />
              </div>
              <Badge className="bg-purple-500/20 text-purple-400 border-0">
                Active
              </Badge>
            </div>
            <div className="space-y-1">
              <p className="text-2xl font-bold text-white">{mockHoldings.length}</p>
              <p className="text-sm text-gray-400">Investments</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-cyan-900/50 to-cyan-800/30 border border-cyan-500/30">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-cyan-500/20 rounded-lg backdrop-blur-sm">
                <Trophy className="w-5 h-5 text-cyan-400" />
              </div>
              <Badge className="bg-cyan-500/20 text-cyan-400 border-0">
                Created
              </Badge>
            </div>
            <div className="space-y-1">
              <p className="text-2xl font-bold text-white">{mockPersonalTracks.length}</p>
              <p className="text-sm text-gray-400">Your Tracks</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={selectedTab} onValueChange={(value) => setSelectedTab(value as any)} className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-gray-900/50">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <PieChart className="w-4 h-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="investments" className="flex items-center gap-2">
            <Wallet className="w-4 h-4" />
            My Investments
          </TabsTrigger>
          <TabsTrigger value="tracks" className="flex items-center gap-2">
            <Music className="w-4 h-4" />
            My Tracks
          </TabsTrigger>
        </TabsList>

        {/* Portfolio Overview */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Performance Chart */}
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Portfolio Performance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">7 Days</span>
                    <span className="text-green-400 font-semibold">+12.5%</span>
                  </div>
                  <Progress value={75} className="w-full" />
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">30 Days</span>
                    <span className="text-green-400 font-semibold">+18.2%</span>
                  </div>
                  <Progress value={85} className="w-full" />
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">All Time</span>
                    <span className="text-green-400 font-semibold">+{totalROI.toFixed(1)}%</span>
                  </div>
                  <Progress value={Math.min(totalROI * 2, 100)} className="w-full" />
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  onClick={() => router.push('/marketplace')}
                  className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white border-0"
                >
                  <DollarSign className="w-4 h-4 mr-2" />
                  Browse New Investments
                </Button>
                
                <Button 
                  onClick={() => router.push('/')}
                  className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white border-0"
                >
                  <Music className="w-4 h-4 mr-2" />
                  Create New Track
                </Button>
                
                <Button 
                  onClick={() => router.push('/community')}
                  variant="outline"
                  className="w-full border-white/20 text-white hover:bg-white/10"
                >
                  <Eye className="w-4 h-4 mr-2" />
                  View Community
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <Card className="bg-gray-900/50 border-gray-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span className="text-sm">Earned 12.5 FAIR from "Neon Dreams Collection"</span>
                  </div>
                  <span className="text-xs text-gray-400">2 hours ago</span>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                    <span className="text-sm">Your track "Holographic Nights" gained 234 new plays</span>
                  </div>
                  <span className="text-xs text-gray-400">1 day ago</span>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-purple-500/10 border border-purple-500/20 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                    <span className="text-sm">Purchased 25 shares in "Jazz Fusion Classics"</span>
                  </div>
                  <span className="text-xs text-gray-400">3 days ago</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* My Investments Tab */}
        <TabsContent value="investments" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {mockHoldings.map((holding) => (
              <Card key={holding.id} className="bg-gray-900/50 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-16 h-16 rounded-lg overflow-hidden">
                      <img src={holding.coverArt} alt={holding.title} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-white mb-1">{holding.title}</h3>
                      <p className="text-sm text-gray-400 mb-2">by {holding.artist}</p>
                      <div className="flex items-center gap-2">
                        <Badge className="text-xs bg-cyan-500/20 text-cyan-400">{holding.genre}</Badge>
                        <Badge className={`text-xs ${getRiskColor(holding.riskLevel)}`}>
                          {holding.riskLevel.toUpperCase()} RISK
                        </Badge>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge className={`${holding.roi > 0 ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'} border-0`}>
                        {holding.roi > 0 ? '+' : ''}{holding.roi.toFixed(1)}%
                      </Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-xs text-gray-400">Current Value</p>
                      <p className="text-lg font-bold text-white">{holding.currentValue} FAIR</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">Monthly Earnings</p>
                      <p className="text-lg font-bold text-green-400">{holding.monthlyEarnings} FAIR</p>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span className="text-gray-400">Your Ownership</span>
                      <span className="text-white">{holding.shares}/{holding.totalShares} ({((holding.shares / holding.totalShares) * 100).toFixed(1)}%)</span>
                    </div>
                    <Progress value={(holding.shares / holding.totalShares) * 100} className="w-full" />
                  </div>

                  <div className="flex gap-2">
                    <Button size="sm" className="flex-1 bg-green-500/20 hover:bg-green-500/30 text-green-400 border-green-500/30">
                      Buy More
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1 border-red-500/30 text-red-400 hover:bg-red-500/10">
                      Sell
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* My Tracks Tab */}
        <TabsContent value="tracks" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {mockPersonalTracks.map((track) => (
              <Card key={track.id} className="bg-gray-900/50 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-16 h-16 rounded-lg overflow-hidden">
                      <img src={track.coverArt} alt={track.title} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-white mb-1">{track.title}</h3>
                      <Badge className="text-xs bg-purple-500/20 text-purple-400 mb-2">{track.genre}</Badge>
                      <p className="text-xs text-gray-400">Created {new Date(track.createdAt).toLocaleDateString()}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-green-400">{track.earnings} FAIR</p>
                      <p className="text-xs text-gray-400">Total Earned</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="text-center">
                      <p className="text-lg font-bold text-white">{track.plays.toLocaleString()}</p>
                      <p className="text-xs text-gray-400">Plays</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-bold text-white">{track.likes}</p>
                      <p className="text-xs text-gray-400">Likes</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-bold text-white">{track.nftsMinted}</p>
                      <p className="text-xs text-gray-400">NFTs</p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button size="sm" className="flex-1 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400">
                      <Play className="w-3 h-3 mr-1" />
                      Play
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1 border-white/20 text-white hover:bg-white/10">
                      <Award className="w-3 h-3 mr-1" />
                      Promote
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </PageLayout>
  )
}