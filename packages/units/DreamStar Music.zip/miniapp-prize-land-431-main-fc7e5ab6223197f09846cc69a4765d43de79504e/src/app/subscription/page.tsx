'use client';

import { SubscriptionManager } from '@/components/subscription/SubscriptionManager';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Crown,
  Zap,
  Music,
  Palette,
  Globe,
  DollarSign,
  Shield,
  TrendingUp
} from 'lucide-react';

export default function SubscriptionPage() {
  return (
    <div className="min-h-screen bg-[#050510] text-white">
      <div className="container mx-auto px-4 py-8 space-y-8">
        
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-2">
            <Crown className="h-8 w-8 text-yellow-500" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-yellow-400 to-purple-500 bg-clip-text text-transparent">
              DreamStar Music Pro
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Unlock the full power of AI-driven holographic music creation with advanced features, unlimited generation, and professional tools.
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="bg-gradient-to-br from-purple-900/20 to-purple-600/20 border-purple-500/20">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Music className="h-5 w-5 text-purple-400" />
                <CardTitle className="text-lg">Unlimited Creation</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Generate unlimited music tracks, vocals, and AI transformations without monthly limits.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-yellow-900/20 to-yellow-600/20 border-yellow-500/20">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-yellow-400" />
                <CardTitle className="text-lg">Advanced AI Prisms</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Access premium AI transformation tools with custom genre shifting and professional mastering.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-900/20 to-blue-600/20 border-blue-500/20">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Palette className="h-5 w-5 text-blue-400" />
                <CardTitle className="text-lg">Custom Artwork</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Generate custom album artwork that matches your music's mood and style automatically.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-900/20 to-green-600/20 border-green-500/20">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-green-400" />
                <CardTitle className="text-lg">Monetization Tools</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Built-in revenue sharing, commercial licensing, and direct fan monetization features.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Advanced Features Showcase */}
        <div className="grid lg:grid-cols-2 gap-8">
          <Card className="border-cyan-500/20 bg-gradient-to-br from-cyan-900/10 to-transparent">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-cyan-400" />
                AI SEO & Discovery
              </CardTitle>
              <CardDescription>
                Automatic optimization for maximum reach and discoverability
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Badge variant="outline" className="w-full justify-center">Location-Based Creation</Badge>
                  <p className="text-xs text-muted-foreground text-center">
                    AI adapts to your geographic location for culturally relevant music
                  </p>
                </div>
                <div className="space-y-2">
                  <Badge variant="outline" className="w-full justify-center">Viral Prediction</Badge>
                  <p className="text-xs text-muted-foreground text-center">
                    Real-time analysis of viral potential before publishing
                  </p>
                </div>
              </div>
              
              <div className="space-y-2">
                <Badge variant="outline" className="w-full justify-center">Smart Content Generation</Badge>
                <p className="text-xs text-muted-foreground text-center">
                  Auto-generates titles, descriptions, hashtags, and social media posts
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-orange-500/20 bg-gradient-to-br from-orange-900/10 to-transparent">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-orange-400" />
                Competitive Intelligence
              </CardTitle>
              <CardDescription>
                Stay ahead with market insights and trend analysis
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Badge variant="outline" className="w-full justify-center">Market Analysis</Badge>
                  <p className="text-xs text-muted-foreground text-center">
                    Real-time analysis of trending genres and successful patterns
                  </p>
                </div>
                <div className="space-y-2">
                  <Badge variant="outline" className="w-full justify-center">Competitor Tracking</Badge>
                  <p className="text-xs text-muted-foreground text-center">
                    Monitor similar artists and identify opportunities
                  </p>
                </div>
              </div>
              
              <div className="space-y-2">
                <Badge variant="outline" className="w-full justify-center">Trend Prediction</Badge>
                <p className="text-xs text-muted-foreground text-center">
                  AI forecasts upcoming musical trends and genre shifts
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Subscription Manager */}
        <SubscriptionManager />

        {/* Success Stories */}
        <Card className="border-green-500/20 bg-gradient-to-br from-green-900/10 to-transparent">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2">
              <Shield className="h-5 w-5 text-green-400" />
              Trusted by Creators Worldwide
            </CardTitle>
            <CardDescription>
              Join thousands of artists already using DreamStar Music Pro
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div className="space-y-2">
                <div className="text-2xl font-bold text-green-400">50K+</div>
                <p className="text-sm text-muted-foreground">Tracks Created</p>
              </div>
              <div className="space-y-2">
                <div className="text-2xl font-bold text-blue-400">10K+</div>
                <p className="text-sm text-muted-foreground">Active Artists</p>
              </div>
              <div className="space-y-2">
                <div className="text-2xl font-bold text-purple-400">$2M+</div>
                <p className="text-sm text-muted-foreground">Artist Revenue Generated</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center space-y-2 pt-8 border-t border-muted">
          <p className="text-sm text-muted-foreground">
            DreamStar Music Pro - The Future of Music Creation
          </p>
          <p className="text-xs text-muted-foreground">
            Cancel anytime • 30-day money-back guarantee • Enterprise support available
          </p>
        </div>
      </div>
    </div>
  );
}