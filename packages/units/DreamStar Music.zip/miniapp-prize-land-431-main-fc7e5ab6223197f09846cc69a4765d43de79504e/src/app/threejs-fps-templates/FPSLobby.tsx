'use client';

import dynamic from 'next/dynamic';
import { useState, useEffect } from 'react';
import { Html } from '@react-three/drei';
import { GameCanvas } from '../threejs-templates/core/GameCanvas';
import { FPSMobileControls } from './ui/FPSMobileControls';
import { HUD } from './ui/HUD';

// Dynamic import for the FPS Scene
const Scene = dynamic(() => import('./scene/FPSScene'), {
  ssr: false,
  loading: () => (
    <Html center>
      <div className="text-white font-mono animate-pulse">Loading FPS...</div>
    </Html>
  ),
});

export function FPSLobby() {
  const [inGame, setInGame] = useState(false);

  return (
    <div className="h-screen w-full bg-black">
      {!inGame ? (
        <div className="h-full flex flex-col items-center justify-center text-white">
          <h1 className="text-4xl font-bold mb-4 text-red-500 tracking-widest">FPS MODE</h1>
          <button
            onClick={() => setInGame(true)}
            className="px-8 py-3 bg-red-600 text-white font-bold rounded hover:bg-red-700"
          >
            DEPLOY
          </button>
        </div>
      ) : (
        <GameCanvas overlay={<><HUD /><FPSMobileControls /></>}>
          <Scene />
        </GameCanvas>
      )}
    </div>
  );
}
