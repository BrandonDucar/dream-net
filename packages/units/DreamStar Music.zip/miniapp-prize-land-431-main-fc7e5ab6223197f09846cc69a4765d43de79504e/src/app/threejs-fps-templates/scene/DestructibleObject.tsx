'use client';

import { useState, useEffect, useMemo } from 'react';
import { RigidBody, type RigidBodyProps } from '@react-three/rapier';
import { Vector3 } from 'three';

type ShapeType = 'box' | 'sphere' | 'cylinder' | 'cone';

interface DestructibleObjectProps extends RigidBodyProps {
  id: string;
  shape?: ShapeType;
  initialHealth?: number;
  color?: string;
}

export function DestructibleObject({ 
  id, 
  shape = 'box', 
  initialHealth = 100, 
  color = '#e74c3c',
  children,
  ...props 
}: DestructibleObjectProps) {
  const [health, setHealth] = useState(initialHealth);
  const [isDestroyed, setIsDestroyed] = useState(false);

  useEffect(() => {
    const handleDamage = (e: any) => {
      if (e.detail.id === id && !isDestroyed) {
        setHealth(prev => {
          const newHealth = prev - e.detail.damage;
          if (newHealth <= 0) {
            setIsDestroyed(true);
            // Optional: Spawn particles here or dispatch 'object-destroyed' event
          }
          return newHealth;
        });
      }
    };

    window.addEventListener('object-damage', handleDamage);
    return () => window.removeEventListener('object-damage', handleDamage);
  }, [id, isDestroyed]);

  if (isDestroyed) return null; // Or render destruction debris

  const Geometry = () => {
    switch (shape) {
      case 'box': return <boxGeometry args={[1, 1, 1]} />;
      case 'sphere': return <sphereGeometry args={[0.6, 16, 16]} />;
      case 'cylinder': return <cylinderGeometry args={[0.5, 0.5, 1, 16]} />;
      case 'cone': return <coneGeometry args={[0.5, 1, 16]} />; // Pyramid-ish
      default: return <boxGeometry args={[1, 1, 1]} />;
    }
  };

  return (
    <RigidBody colliders="cuboid" {...props}>
      <mesh 
        castShadow 
        receiveShadow 
        userData={{ shootable: true, id }} // CRITICAL for Raycasting
        onClick={(e) => e.stopPropagation()} // Block clicks passing through
      >
        <Geometry />
        <meshStandardMaterial color={health < 50 ? '#555' : color} />
      </mesh>
      {children}
    </RigidBody>
  );
}
