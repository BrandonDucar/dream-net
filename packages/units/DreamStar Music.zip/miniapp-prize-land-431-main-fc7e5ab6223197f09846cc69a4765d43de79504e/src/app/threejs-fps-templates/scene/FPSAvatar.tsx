'use client';

import { useEffect, useRef, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { RigidBody, CapsuleCollider, type RapierRigidBody } from '@react-three/rapier';
import { Vector3, Euler, Quaternion, Raycaster, Group } from 'three';
import { useKeyboardControls } from '@react-three/drei';
import { useInput } from '../../threejs-templates/core/Input';
import { Weapon } from './Weapon';

const MOVEMENT_SPEED = 6;
const JUMP_FORCE = 12.5;
const ROTATION_SPEED = 2.0;
const MOUSE_SENSITIVITY = 0.002;

// Reusable temp vectors
const dir = new Vector3();
const front = new Vector3();
const side = new Vector3();
const velocity = new Vector3();
const worldUp = new Vector3(0, 1, 0);
const bodyQuat = new Quaternion();

// Simple Hit Effect Component
function HitEffect({ position }: { position: Vector3 }) {
  const [visible, setVisible] = useState(true);
  const scaleRef = useRef(1);
  
  useFrame((state, delta) => {
    scaleRef.current -= delta * 5;
    if (scaleRef.current <= 0) setVisible(false);
  });

  if (!visible) return null;

  return (
    <mesh position={position} scale={scaleRef.current}>
      <sphereGeometry args={[0.15, 8, 8]} />
      <meshBasicMaterial color="orange" transparent opacity={0.8} />
    </mesh>
  );
}

export function FPSAvatar() {
  const body = useRef<RapierRigidBody>(null);
  const weaponGroup = useRef<Group>(null);
  const { input, device } = useInput();
  const [_, getKeys] = useKeyboardControls();
  const { camera, gl, scene } = useThree();
  
  // FPS State
  const [shooting, setShooting] = useState(false);
  const [reloading, setReloading] = useState(false);
  const [hitPoints, setHitPoints] = useState<{ id: number, pos: Vector3 }[]>([]);
  
  // Raycaster for shooting
  const raycaster = useRef(new Raycaster());

  // Camera state (Pitch/Yaw) - Order YXZ is critical for FPS (Yaw first, then Pitch)
  const currentLook = useRef(new Euler(0, 0, 0, 'YXZ'));

  // Game State Refs
  const gameState = useRef({
    health: 100,
    ammo: 30,
    totalAmmo: 90,
    isReloading: false
  });

  const updateHUD = () => {
    window.dispatchEvent(new CustomEvent('fps-update', { detail: gameState.current }));
  };

  const fireWeapon = () => {
    if (gameState.current.isReloading || gameState.current.ammo <= 0) {
        if (gameState.current.ammo <= 0 && !gameState.current.isReloading) triggerReload();
        return;
    }
    
    gameState.current.ammo--;
    updateHUD();
    setShooting(true);
    setTimeout(() => setShooting(false), 100);

    // Raycast Logic
    raycaster.current.setFromCamera({ x: 0, y: 0 }, camera);
    raycaster.current.near = 0.5; // Skip weapon/self
    
    const hits = raycaster.current.intersectObjects(scene.children, true);
    
    // Filter out the weapon/player itself if accidentally hit, though 'near=0.5' helps
    // Find first valid hit
    const hit = hits[0]; 
    
    if (hit) {
        // Visual Effect (Wall Hit)
        // Limit active hits to avoid memory leak
        const newHit = { id: Date.now(), pos: hit.point.clone() };
        setHitPoints(prev => [...prev.slice(-10), newHit]);
        
        // Logic (Damage)
        // Traverse up to find if object has userData.id (Shootable)
        let target = hit.object;
        while (target) {
            if (target.userData?.shootable) {
                window.dispatchEvent(new CustomEvent('object-damage', { 
                    detail: { id: target.userData.id, damage: 25 } 
                }));
                break;
            }
            target = target.parent as any;
        }
    }
  };

  const triggerReload = () => {
    if (gameState.current.isReloading || gameState.current.ammo === 30 || gameState.current.totalAmmo === 0) return;
    
    setReloading(true);
    gameState.current.isReloading = true;
    
    setTimeout(() => {
      const needed = 30 - gameState.current.ammo;
      const available = Math.min(needed, gameState.current.totalAmmo);
      gameState.current.ammo += available;
      setReloading(false);
      gameState.current.isReloading = false;
      updateHUD();
    }, 1500);
  };

  // Mouse Look & Shooting
  useEffect(() => {
    const handleAction = (e: any) => {
      if (e.detail === 'shoot') fireWeapon();
      if (e.detail === 'reload') triggerReload();
    };

    window.addEventListener('fps-action', handleAction);

    if (device === 'touch') return () => window.removeEventListener('fps-action', handleAction);

    const onClick = () => {
      if (document.pointerLockElement !== gl.domElement) {
        gl.domElement.requestPointerLock();
      } else {
        fireWeapon();
      }
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'KeyR') triggerReload();
    };
    
    const onMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement === gl.domElement) {
        // Update Look state
        currentLook.current.y -= e.movementX * MOUSE_SENSITIVITY;
        currentLook.current.x -= e.movementY * MOUSE_SENSITIVITY;
      }
    };

    const element = gl.domElement;
    element.addEventListener('click', onClick);
    window.addEventListener('keydown', onKeyDown);
    document.addEventListener('mousemove', onMouseMove);

    return () => {
      window.removeEventListener('fps-action', handleAction);
      element.removeEventListener('click', onClick);
      window.removeEventListener('keydown', onKeyDown);
      document.removeEventListener('mousemove', onMouseMove);
    };
  }, [gl.domElement, device]); 

  useFrame((state, delta) => {
    if (!body.current) return;

    const keys = getKeys();
    
    /* --- INPUT --- */
    // Rotation
    if (Math.abs(input.lookX) > 0.01) currentLook.current.y -= input.lookX * ROTATION_SPEED * delta;
    if (Math.abs(input.lookY) > 0.01) currentLook.current.x += input.lookY * ROTATION_SPEED * delta;

    if (keys.rotateLeft) currentLook.current.y += ROTATION_SPEED * delta;
    if (keys.rotateRight) currentLook.current.y -= ROTATION_SPEED * delta;

    // Clamp Pitch (Vertical Look)
    currentLook.current.x = Math.max(-1.5, Math.min(1.5, currentLook.current.x));

    // Movement
    const forward = (keys.forward ? 1 : 0) - (keys.backward ? 1 : 0) + input.moveY;
    const strafe = (keys.right ? 1 : 0) - (keys.left ? 1 : 0) + input.moveX;
    const isJumping = keys.jump || input.jump;

    /* --- PHYSICS --- */
    const linvel = body.current.linvel();
    const translation = body.current.translation();

    // Direction relative to Camera Yaw (ignore Pitch for movement)
    front.set(0, 0, -1).applyEuler(new Euler(0, currentLook.current.y, 0));
    side.crossVectors(front, worldUp).normalize();

    dir.addVectors(front.multiplyScalar(forward), side.multiplyScalar(strafe)).normalize();
    velocity.set(dir.x * MOVEMENT_SPEED, linvel.y, dir.z * MOVEMENT_SPEED);
    body.current.setLinvel(velocity, true);

    // Rotate Body to face Camera Yaw
    bodyQuat.setFromAxisAngle(worldUp, currentLook.current.y);
    body.current.setRotation(bodyQuat, true);

    if (isJumping && Math.abs(linvel.y) < 0.1) {
       body.current.applyImpulse({ x: 0, y: JUMP_FORCE, z: 0 }, true);
    }

    /* --- CAMERA SYNC --- */
    const headPos = new Vector3(translation.x, translation.y + 1.6, translation.z);
    
    // 1. Set Position
    camera.position.copy(headPos);
    
    // 2. Set Rotation (using Quaternion derived from Euler YXZ)
    // This fixes the "twisting" by strictly enforcing Y-then-X rotation order
    camera.quaternion.setFromEuler(currentLook.current);

    /* --- WEAPON SYNC --- */
    // Sync strictly AFTER camera update to prevent floating/lag
    if (weaponGroup.current) {
      weaponGroup.current.position.copy(camera.position);
      weaponGroup.current.quaternion.copy(camera.quaternion);
    }
  });

  return (
    <>
      <RigidBody 
        ref={body} 
        colliders={false} 
        enabledRotations={[false, false, false]} 
        position={[0, 5, 0]}
        friction={1}
      >
        <CapsuleCollider args={[0.5, 0.5]} />
        
        {/* Player Visuals (For Mirror/Shadows) */}
        <group position={[0, 0, 0]}>
          {/* Torso */}
          <mesh position={[0, 0, 0]} castShadow receiveShadow>
            <boxGeometry args={[0.6, 0.8, 0.3]} />
            <meshStandardMaterial color="#15202b" metalness={0.5} roughness={0.5} />
          </mesh>
          {/* Emissive Core */}
          <mesh position={[0, 0.1, 0.16]}>
            <boxGeometry args={[0.2, 0.3, 0.05]} />
            <meshStandardMaterial color="#00ffff" emissive="#00ffff" emissiveIntensity={2} />
          </mesh>
          {/* Head (Slightly lower than camera to avoid clipping view) */}
          <mesh position={[0, 0.7, 0]} castShadow>
            <boxGeometry args={[0.4, 0.4, 0.4]} />
            <meshStandardMaterial color="#333" />
          </mesh>
           {/* Visor (Mirror reflection will see this) */}
           <mesh position={[0, 0.7, 0.21]}>
             <planeGeometry args={[0.3, 0.15]} />
             <meshStandardMaterial color="#ff0033" emissive="#ff0033" />
           </mesh>
        </group>

      </RigidBody>
      
      {/* Weapon: Rendered outside RigidBody so we have full control over its transform */}
      <group ref={weaponGroup}>
        <Weapon isShooting={shooting} isReloading={reloading} />
      </group>
      
      {/* Bullet Impacts */}
      {hitPoints.map(h => <HitEffect key={h.id} position={h.pos} />)}
    </>
  );
}