'use client';

import { Physics, RigidBody } from '@react-three/rapier';
import { Environment, MeshReflectorMaterial } from '@react-three/drei';
import { FPSAvatar } from './FPSAvatar';
import { Level } from './LevelGeometry';
import { DestructibleObject } from './DestructibleObject';

export default function FPSScene() {
  return (
    <>
      <Physics gravity={[0, -15, 0]}>
        <FPSAvatar />
        
        {/* Dynamic Level */}
        <Level />

        {/* Floor (Matches Level Extents roughly, but infinite plane covers all) */}
        <RigidBody type="fixed" friction={2} restitution={0}>
          <mesh rotation-x={-Math.PI / 2} receiveShadow position={[0, -0.01, 0]}>
            <planeGeometry args={[2000, 2000]} />
            <MeshReflectorMaterial
              blur={[0, 0]}
              resolution={512}
              mixBlur={0}
              mixStrength={40}
              roughness={0.2}
              depthScale={1.2}
              minDepthThreshold={0.4}
              maxDepthThreshold={1.4}
              color="#151515"
              metalness={0.6}
              mirror={0.7}
            />
          </mesh>
        </RigidBody>

        {/* Destructible Targets */}
        <DestructibleObject id="box1" position={[5, 1, 5]} shape="box" color="red" />
        <DestructibleObject id="cyl1" position={[-5, 1, 5]} shape="cylinder" color="blue" />
        <DestructibleObject id="pyr1" position={[5, 1, -5]} shape="cone" color="green" />
        
      </Physics>
      <ambientLight intensity={0.4} />
      <directionalLight position={[10, 20, 10]} intensity={1.2} castShadow />
      <Environment preset="night" background />
    </>
  );
}
