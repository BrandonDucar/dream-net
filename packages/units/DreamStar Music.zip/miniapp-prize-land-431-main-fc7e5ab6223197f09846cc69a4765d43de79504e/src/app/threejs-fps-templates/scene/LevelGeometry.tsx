'use client';

import { useMemo } from 'react';
import { RigidBody, CuboidCollider } from '@react-three/rapier';
import { Instance, Instances } from '@react-three/drei';

// === CONFIG ===
const MAP_SIZE = 30; // Reset to Original Size
const TILE_SIZE = 5;
const WALL_HEIGHT = 6;

// === MAZE GENERATOR (Rooms + Corridors) ===
type TileType = 'WALL' | 'FLOOR';

function generateMaze() {
  const map: TileType[][] = Array(MAP_SIZE).fill(null).map(() => Array(MAP_SIZE).fill('WALL'));

  // Helper to carve a room
  const carveRoom = (cx: number, cy: number, w: number, h: number) => {
    for (let y = cy - h; y <= cy + h; y++) {
      for (let x = cx - w; x <= cx + w; x++) {
        if (x > 0 && x < MAP_SIZE - 1 && y > 0 && y < MAP_SIZE - 1) {
          map[y][x] = 'FLOOR';
        }
      }
    }
  };

  // 1. Create Main Rooms (Randomly placed)
  const roomCount = 12;
  const rooms: {x: number, y: number}[] = [];
  
  for (let i = 0; i < roomCount; i++) {
    const w = Math.floor(Math.random() * 2) + 2; // Radius 2-3
    const h = Math.floor(Math.random() * 2) + 2;
    const cx = Math.floor(Math.random() * (MAP_SIZE - 6)) + 3;
    const cy = Math.floor(Math.random() * (MAP_SIZE - 6)) + 3;
    
    carveRoom(cx, cy, w, h);
    rooms.push({x: cx, y: cy});
  }

  // 2. Connect Rooms
  rooms.sort((a, b) => a.x - b.x);
  
  for (let i = 0; i < rooms.length - 1; i++) {
    const start = rooms[i];
    const end = rooms[i + 1];
    
    // Horizontal Corridor
    const xMin = Math.min(start.x, end.x);
    const xMax = Math.max(start.x, end.x);
    for (let x = xMin; x <= xMax; x++) map[start.y][x] = 'FLOOR';
    
    // Vertical Corridor
    const yMin = Math.min(start.y, end.y);
    const yMax = Math.max(start.y, end.y);
    for (let y = yMin; y <= yMax; y++) map[y][end.x] = 'FLOOR';
  }

  // 3. Ensure Spawn Area (Center) is clear
  const center = Math.floor(MAP_SIZE / 2);
  carveRoom(center, center, 3, 3);

  return map;
}

// === MATERIALS ===
const MATERIAL_PROPS = {
  wall: <meshStandardMaterial color="#555" roughness={0.2} metalness={0.1} />,
  wallTrim: <meshStandardMaterial color="#ffaa00" emissive="#ffaa00" emissiveIntensity={0.5} />,
  floor: <meshStandardMaterial color="#111" roughness={0.3} metalness={0.5} />,
};

export function Level() {
  const map = useMemo(() => generateMaze(), []);
  
  const walls: {x: number, z: number}[] = [];

  // Parse Map
  for (let z = 0; z < MAP_SIZE; z++) {
    for (let x = 0; x < MAP_SIZE; x++) {
      const worldX = (x - MAP_SIZE / 2) * TILE_SIZE;
      const worldZ = (z - MAP_SIZE / 2) * TILE_SIZE;

      if (map[z][x] === 'WALL') {
        walls.push({ x: worldX, z: worldZ });
      }
    }
  }

  return (
    <group>
      {/* === WALLS (Instanced) === */}
      <Instances range={walls.length}>
        <boxGeometry args={[TILE_SIZE, WALL_HEIGHT, TILE_SIZE]} />
        {MATERIAL_PROPS.wall}
        
        {walls.map((pos, i) => (
           <WallInstance key={i} position={[pos.x, WALL_HEIGHT / 2, pos.z]} />
        ))}
      </Instances>

      {/* === WALL TRIMS (Detail Layer - Glowing Top) === */}
      <Instances range={walls.length}>
        <boxGeometry args={[TILE_SIZE + 0.1, 0.2, TILE_SIZE + 0.1]} /> {/* Slightly wider */}
        {MATERIAL_PROPS.wallTrim}

        {walls.map((pos, i) => (
           <Instance key={i} position={[pos.x, WALL_HEIGHT - 0.5, pos.z]} />
        ))}
      </Instances>

    </group>
  );
}

function WallInstance({ position }: { position: [number, number, number] }) {
  return (
    <RigidBody type="fixed" position={position} colliders={false}>
      <CuboidCollider args={[2.5, 3, 2.5]} />
      <Instance />
    </RigidBody>
  );
}