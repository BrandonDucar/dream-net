'use client';

import { useRef, useMemo, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { Vector3, Group, MathUtils, InstancedMesh, Object3D } from 'three';

// === MATERIALS (REVAMPED: SCI-FI ELITE) ===
const MATERIALS = {
  // Deep Matte Navy/Charcoal for main casing
  body: <meshPhysicalMaterial 
    color="#15202b" 
    metalness={0.6} 
    roughness={0.4} 
    clearcoat={0.3} 
  />,
  // High-contrast "Cyber Yellow" for structural accents
  accent: <meshStandardMaterial color="#ffaa00" metalness={0.8} roughness={0.3} />,
  // Dark Rubber Grip
  grip: <meshStandardMaterial color="#0a0a0a" roughness={0.95} />,
  // Polished Titanium/Silver for barrel & mechanical parts
  metal: <meshPhysicalMaterial color="#e2e8f0" metalness={0.9} roughness={0.2} clearcoat={0.8} />,
  // GLOWING CYBER LENS (Replaced for visibility)
  scopeLens: <meshBasicMaterial 
    color="#00ffff" 
    transparent 
    opacity={0.6}
  />,
  // Red Hot Emissive Vents
  emissive: <meshStandardMaterial color="#ff0033" emissive="#ff0000" emissiveIntensity={3} toneMapped={false} />,
};

// === PARTICLE SYSTEM FOR MUZZLE FLASH ===
function MuzzleParticles({ isShooting }: { isShooting: boolean }) {
  const meshRef = useRef<InstancedMesh>(null);
  const dummy = useMemo(() => new Object3D(), []);
  const particleCount = 15;

  // Store particle states: [vx, vy, vz, life]
  const particles = useRef(new Float32Array(particleCount * 4)); 

  // HIDE PARTICLES INITIALLY
  useEffect(() => {
    if (meshRef.current) {
        for (let i = 0; i < particleCount; i++) {
            dummy.scale.setScalar(0);
            dummy.updateMatrix();
            meshRef.current.setMatrixAt(i, dummy.matrix);
        }
        meshRef.current.instanceMatrix.needsUpdate = true;
    }
  }, [dummy, particleCount]);

  useFrame((state, delta) => {
    if (!meshRef.current) return;

    // If shooting, reset some dead particles to "explode"
    if (isShooting) {
      for (let i = 0; i < particleCount; i++) {
        // Reset if "dead" (life <= 0) or just randomly refresh during sustained fire
        if (particles.current[i * 4 + 3] <= 0 || Math.random() > 0.8) {
          particles.current[i * 4 + 0] = (Math.random() - 0.5) * 2.5; // VX (Spread)
          particles.current[i * 4 + 1] = (Math.random() - 0.5) * 2.5; // VY (Spread)
          particles.current[i * 4 + 2] = -Math.random() * 5 - 2;      // VZ (Forward fast)
          particles.current[i * 4 + 3] = 0.1 + Math.random() * 0.2;   // Life (short)
          
          // Reset Position to Muzzle origin (local 0,0,0 relative to parent group)
          dummy.position.set(0, 0, 0);
          dummy.scale.setScalar(0);
          dummy.updateMatrix();
          meshRef.current.setMatrixAt(i, dummy.matrix);
        }
      }
    }

    // Update Particles
    let activeCount = 0;
    for (let i = 0; i < particleCount; i++) {
      let life = particles.current[i * 4 + 3];

      if (life > 0) {
        // Move
        const vx = particles.current[i * 4 + 0];
        const vy = particles.current[i * 4 + 1];
        const vz = particles.current[i * 4 + 2];
        
        const maxLife = 0.3; // approximate
        const timeAlive = maxLife - life; // growing time
        
        // Random trajectory simulation
        dummy.position.set(
             vx * timeAlive * 2,
             vy * timeAlive * 2,
             vz * timeAlive * 2
        );
            
        // Scale flickers and shrinks
        const scale = Math.max(0, (life * 2)); // Shrink as it dies
        dummy.scale.setScalar(scale * 0.05);
        dummy.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, 0);
            
        dummy.updateMatrix();
        meshRef.current.setMatrixAt(i, dummy.matrix);
        activeCount++;
        
        particles.current[i * 4 + 3] -= delta; // Decay
      } else {
        // Hide
        dummy.scale.setScalar(0);
        dummy.updateMatrix();
        meshRef.current.setMatrixAt(i, dummy.matrix);
      }
    }
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, particleCount]} position={[0, 0.05, -1.4]}>
      <boxGeometry args={[1, 1, 1]} />
      <meshBasicMaterial color="#ffaa00" toneMapped={false} />
    </instancedMesh>
  );
}


// === MAIN WEAPON COMPONENT ===
export function Weapon({ isShooting, isReloading }: { isShooting: boolean; isReloading: boolean }) {
  const groupRef = useRef<Group>(null);
  const recoilOffset = useRef(new Vector3(0, 0, 0));

  useFrame((state, delta) => {
    if (!groupRef.current) return;

    // 1. Recoil Logic (Snappier)
    if (isShooting) {
      recoilOffset.current.z = 0.25; // Harder kick
      recoilOffset.current.y = 0.03; // Muzzle climb
      recoilOffset.current.x = (Math.random() - 0.5) * 0.02; // Shake
    }

    // Fast recovery (Spring-like)
    recoilOffset.current.lerp(new Vector3(0, 0, 0), delta * 20);

    // 2. Sway
    const t = state.clock.getElapsedTime();
    const swayX = Math.sin(t * 1.5) * 0.003;
    const swayY = Math.cos(t * 1.2) * 0.003;

    // 3. Position (CENTERED for Mobile)
    groupRef.current.position.set(0.08 + swayX, -0.28 + swayY, -0.5).add(recoilOffset.current);
    
    // 4. Reload Animation
    if (isReloading) {
      groupRef.current.rotation.x = MathUtils.lerp(groupRef.current.rotation.x, -Math.PI / 2.5, delta * 8);
      groupRef.current.rotation.z = MathUtils.lerp(groupRef.current.rotation.z, 0.5, delta * 8);
    } else {
      groupRef.current.rotation.x = MathUtils.lerp(groupRef.current.rotation.x, 0, delta * 12);
      groupRef.current.rotation.z = MathUtils.lerp(groupRef.current.rotation.z, 0, delta * 12);
    }
  });

  return (
    <group ref={groupRef}>
      
      {/* === RIFLE GEOMETRY === */}
      <group scale={1.3}>
        
        {/* 1. Receiver (Main Body) */}
        <mesh position={[0, 0, 0]} castShadow receiveShadow>
          <boxGeometry args={[0.08, 0.12, 0.4]} />
          {MATERIALS.body}
        </mesh>
        
        {/* Decor: Side Plates */}
        <mesh position={[0.042, 0, 0]} castShadow>
            <boxGeometry args={[0.01, 0.08, 0.3]} />
            {MATERIALS.metal}
        </mesh>
        <mesh position={[-0.042, 0, 0]} castShadow>
            <boxGeometry args={[0.01, 0.08, 0.3]} />
            {MATERIALS.metal}
        </mesh>
        
        {/* Rail (Dark Grey now, was Yellow) */}
        <mesh position={[0, 0.065, 0]} castShadow>
          <boxGeometry args={[0.05, 0.015, 0.38]} />
          {MATERIALS.metal}
        </mesh>

        {/* 2. Handguard (Front) */}
        <mesh position={[0, 0, -0.35]} castShadow receiveShadow>
          <boxGeometry args={[0.07, 0.11, 0.3]} />
          {MATERIALS.body}
        </mesh>
        {/* Vents (Glowing Red) */}
        <mesh position={[0.036, 0, -0.35]} castShadow>
          <boxGeometry args={[0.01, 0.02, 0.2]} />
          {MATERIALS.emissive}
        </mesh>
        <mesh position={[-0.036, 0, -0.35]} castShadow>
          <boxGeometry args={[0.01, 0.02, 0.2]} />
          {MATERIALS.emissive}
        </mesh>

        {/* 3. Barrel & Suppressor (FIXED: Rotation on MESH not GEOMETRY) */}
        {/* Main Barrel Tube */}
        <mesh position={[0, 0.02, -0.6]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <cylinderGeometry args={[0.02, 0.02, 0.5, 16]} />
          {MATERIALS.metal}
        </mesh>
        
        {/* Suppressor (Big Horizontal Cylinder) replaces small brake */}
        <mesh position={[0, 0.02, -0.95]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <cylinderGeometry args={[0.035, 0.035, 0.3, 16]} />
          {MATERIALS.body}
        </mesh>
        {/* Suppressor Ring Accent */}
        <mesh position={[0, 0.02, -0.85]} rotation={[Math.PI / 2, 0, 0]} castShadow>
             <cylinderGeometry args={[0.036, 0.036, 0.02, 16]} />
             {MATERIALS.accent}
        </mesh>

        {/* 4. Magazine (Angled) */}
        <mesh position={[0, -0.1, 0.05]} rotation={[0.3, 0, 0]} castShadow receiveShadow>
          <boxGeometry args={[0.055, 0.25, 0.09]} />
          {MATERIALS.grip}
        </mesh>
        {/* Mag Detail */}
        <mesh position={[0, -0.15, 0.05]} rotation={[0.3, 0, 0]} castShadow>
            <boxGeometry args={[0.06, 0.05, 0.1]} />
            {MATERIALS.accent}
        </mesh>

        {/* 5. Grip */}
        <mesh position={[0, -0.08, 0.15]} rotation={[-0.2, 0, 0]} castShadow receiveShadow>
          <boxGeometry args={[0.05, 0.15, 0.07]} />
          {MATERIALS.grip}
        </mesh>

        {/* 6. Stock (Back) */}
        <group position={[0, 0, 0.35]}>
          {/* Tube (FIXED Rotation) */}
          <mesh position={[0, 0, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
            <cylinderGeometry args={[0.02, 0.02, 0.3, 8]} />
            {MATERIALS.metal}
          </mesh>
          {/* Buttpad (Slightly Angled, slimmer) */}
          <mesh position={[0, -0.03, 0.15]} rotation={[-0.15, 0, 0]} castShadow receiveShadow>
            <boxGeometry args={[0.05, 0.14, 0.04]} />
            {MATERIALS.body}
          </mesh>
        </group>

        {/* 7. Compact Cyber-Scope (Short) */}
        <group position={[0, 0.085, -0.05]}>
           {/* Mount (Dark, not yellow) */}
           <mesh position={[0, -0.025, 0]} castShadow><boxGeometry args={[0.04, 0.03, 0.1]} />{MATERIALS.body}</mesh>
           
           {/* Main Body (Stubby) */}
           <mesh rotation={[Math.PI / 2, 0, 0]} castShadow>
             <cylinderGeometry args={[0.03, 0.03, 0.14, 16]} />
             {MATERIALS.metal}
           </mesh>

           {/* Front Lens Housing (Hexagonal/Techy look) */}
           <mesh position={[0, 0, -0.08]} rotation={[Math.PI / 2, 0, 0]} castShadow>
             <cylinderGeometry args={[0.036, 0.03, 0.04, 8]} /> 
             {MATERIALS.body}
           </mesh>
           {/* Glowing Ring Front - Rotated to face Z */}
           <mesh position={[0, 0, -0.101]}>
             <torusGeometry args={[0.028, 0.002, 8, 16]} />
             {MATERIALS.emissive}
           </mesh>
           {/* Front Lens - FACE -Z (No X rotation needed if default is XY plane? No, default is XY plane facing Z) */}
           {/* We want it to be flat against the Z-axis cylinder cap. */}
           <mesh position={[0, 0, -0.105]}>
             <circleGeometry args={[0.028, 16]} />
             {MATERIALS.scopeLens}
           </mesh>

           {/* Rear Eyepiece */}
           <mesh position={[0, 0, 0.08]} rotation={[Math.PI / 2, 0, 0]} castShadow>
             <cylinderGeometry args={[0.03, 0.035, 0.04, 16]} />
             {MATERIALS.body}
           </mesh>
           {/* Rear Lens - FACE +Z */}
           <mesh position={[0, 0, 0.105]} rotation={[0, Math.PI, 0]}>
             <circleGeometry args={[0.03, 16]} />
             {MATERIALS.scopeLens}
           </mesh>

           {/* Cyber Knobs */}
           <mesh position={[0, 0.035, 0]} castShadow>
              <boxGeometry args={[0.03, 0.01, 0.03]} />
              {MATERIALS.emissive}
           </mesh>
        </group>

      </group>

      {/* === PARTICLE EFFECT === */}
      <MuzzleParticles isShooting={isShooting} />
      
      {/* Dynamic Light on Shoot */}
      {isShooting && (
         <pointLight position={[0, 0.1, -1.0]} color="#ffaa00" intensity={8} distance={6} decay={2} />
      )}

    </group>
  );
}
