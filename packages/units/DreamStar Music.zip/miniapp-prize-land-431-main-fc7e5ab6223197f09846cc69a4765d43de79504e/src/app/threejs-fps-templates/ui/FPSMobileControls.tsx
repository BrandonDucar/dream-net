'use client';

import { useEffect, useRef, useState } from 'react';
import { useInput } from '../../threejs-templates/core/Input';

// Extend Input State locally for FPS actions?
// We need a way to signal "Shoot" to FPSAvatar.
// We can use a custom event or a small Zustand store.
// For simplicity in this template, we will dispatch a custom event 'fps-action'.

export function FPSMobileControls() {
  const { device, updateInput, input } = useInput();

  if (device !== 'touch') return null;

  const emitAction = (action: string) => {
    window.dispatchEvent(new CustomEvent('fps-action', { detail: action }));
  };

  return (
    <div className="pointer-events-auto absolute bottom-8 left-8 right-8 flex items-end justify-between select-none">
      {/* Left: Movement Joystick */}
      <Joystick
        onChange={(x, y) => updateInput({ moveX: x, moveY: y })}
        style={{ aspectRatio: 1 }}
        className="flex-shrink-0"
      />

      {/* Right Container: Actions + Look Joystick */}
      <div className="flex flex-col items-end gap-6">
        
        {/* Action Buttons Stack */}
        <div className="flex flex-col items-center gap-3 mr-2">
          <div className="flex gap-3">
            <ControlButton 
              label="R" 
              onPress={() => emitAction('reload')} 
              className="h-12 w-12 bg-yellow-600/80"
            />
            <ControlButton 
              label="JUMP" 
              active={input.jump}
              onPress={(v) => updateInput({ jump: v })} 
              className="h-14 w-14 bg-blue-500/40"
            />
          </div>
          
          {/* Shoot Button - Prominent */}
          <ControlButton 
            label="SHOOT" 
            onPress={(v) => v && emitAction('shoot')} 
            className="h-20 w-20 bg-red-600/80 border-2 border-red-400/50 text-sm"
          />
        </div>

        {/* Right: Look Joystick */}
        <Joystick
          onChange={(x, y) => updateInput({ lookX: x, lookY: y })}
          style={{ aspectRatio: 1 }}
          className="flex-shrink-0"
        />
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                                 COMPONENTS                                 */
/* -------------------------------------------------------------------------- */

function Joystick({ onChange, style = {}, className = "" }: { onChange: (x: number, y: number) => void; style?: React.CSSProperties; className?: string }) {
  const radius = 50;
  const [active, setActive] = useState(false);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const ref = useRef<HTMLDivElement>(null);
  const origin = useRef({ x: 0, y: 0 });

  const handleStart = (e: React.PointerEvent) => {
    e.preventDefault(); 
    setActive(true);
    origin.current = { x: e.clientX, y: e.clientY };
    (e.target as Element).setPointerCapture(e.pointerId);
  };

  const handleMove = (e: React.PointerEvent) => {
    if (!active) return;
    const dx = e.clientX - origin.current.x;
    const dy = e.clientY - origin.current.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const clampedDist = Math.min(distance, radius);
    const angle = Math.atan2(dy, dx);
    const x = Math.cos(angle) * clampedDist;
    const y = Math.sin(angle) * clampedDist;
    setPos({ x, y });
    onChange(x / radius, -(y / radius));
  };

  const handleEnd = (e: React.PointerEvent) => {
    setActive(false);
    setPos({ x: 0, y: 0 });
    onChange(0, 0);
    (e.target as Element).releasePointerCapture(e.pointerId);
  };

  return (
    <div
      ref={ref}
      className={`relative h-32 w-32 rounded-full bg-white/10 backdrop-blur-sm touch-none ${className}`}
      style={style}
      onPointerDown={handleStart}
      onPointerMove={handleMove}
      onPointerUp={handleEnd}
      onPointerCancel={handleEnd}
    >
      <div
        className="absolute left-1/2 top-1/2 h-12 w-12 -ml-6 -mt-6 rounded-full bg-white/50 shadow-lg transition-transform duration-75"
        style={{ transform: `translate(${pos.x}px, ${pos.y}px)` }}
      />
    </div>
  );
}

function ControlButton({ 
  label, 
  active = false, 
  onPress, 
  className = ""
}: { 
  label: string, 
  active?: boolean, 
  onPress?: (v: boolean) => void,
  className?: string
}) {
  return (
    <button
      className={`rounded-full text-xs font-bold tracking-wider shadow-sm backdrop-blur-sm transition-all flex items-center justify-center
        ${active ? 'scale-95 brightness-125' : 'active:scale-95'}
        ${className}
      `}
      onPointerDown={(e) => { e.preventDefault(); onPress?.(true); }}
      onPointerUp={(e) => { e.preventDefault(); onPress?.(false); }}
      onPointerLeave={() => onPress?.(false)}
    >
      {label}
    </button>
  );
}
