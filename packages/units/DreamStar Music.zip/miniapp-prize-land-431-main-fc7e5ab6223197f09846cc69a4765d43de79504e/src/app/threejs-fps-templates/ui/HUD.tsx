'use client';

import { useEffect, useState } from 'react';

type GameState = {
  health: number;
  ammo: number;
  totalAmmo: number;
};

export function HUD() {
  const [state, setState] = useState<GameState>({
    health: 100,
    ammo: 30,
    totalAmmo: 90,
  });

  useEffect(() => {
    const handleUpdate = (e: any) => {
      if (e.detail) {
        setState((prev) => ({ ...prev, ...e.detail }));
      }
    };
    window.addEventListener('fps-update', handleUpdate);
    return () => window.removeEventListener('fps-update', handleUpdate);
  }, []);

  return (
    <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-6 select-none">
      {/* Crosshair */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
        <div className="w-1.5 h-1.5 bg-white/80 rounded-full shadow-[0_0_2px_rgba(0,0,0,0.5)]" />
      </div>

      {/* Top Left: Health */}
      <div className="flex items-center gap-3">
        <div className="w-48 h-4 bg-black/50 border border-white/10 skew-x-[-12deg] overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-red-600 to-red-500 transition-all duration-300 ease-out"
            style={{ width: `${state.health}%` }}
          />
        </div>
        <span className="text-xl font-bold text-white tracking-wider">{state.health}</span>
      </div>

      {/* Bottom Right: Ammo */}
      <div className="self-end flex items-end flex-col text-right">
        <div className="flex items-baseline gap-1 text-white">
          <span className="text-5xl font-bold tracking-tighter">{state.ammo}</span>
          <span className="text-2xl text-white/50 font-medium">/ {state.totalAmmo}</span>
        </div>
        <div className="w-32 h-1.5 bg-white/20 mt-1">
          <div 
            className="h-full bg-white shadow-[0_0_10px_white]" 
            style={{ width: `${(state.ammo / 30) * 100}%` }} 
          />
        </div>
      </div>
    </div>
  );
}
