'use client';

import { useEffect, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { RigidBody, CapsuleCollider, type RapierRigidBody } from '@react-three/rapier';
import { Vector3, Euler, Quaternion } from 'three';
import { useKeyboardControls } from '@react-three/drei';
import { useInput } from '../core/Input';

const MOVEMENT_SPEED = 6;
const JUMP_FORCE = 25;
const ROTATION_SPEED = 2.0;
const MOUSE_SENSITIVITY = 0.002;

// Reusable temp vectors
const dir = new Vector3();
const front = new Vector3();
const side = new Vector3();
const velocity = new Vector3();
const worldUp = new Vector3(0, 1, 0);
const bodyQuat = new Quaternion();

export function Avatar() {
  const body = useRef<RapierRigidBody>(null);
  const { input, mode, device } = useInput();
  const [_, getKeys] = useKeyboardControls();
  const { camera, gl } = useThree();
  
  // Camera state
  // x: Pitch, y: Yaw
  const currentLook = useRef(new Euler(0, 0, 0, 'YXZ'));

  // Mouse Look (Pointer Lock) - Desktop Only
  useEffect(() => {
    if (device === 'touch') return;

    const onClick = () => {
      gl.domElement.requestPointerLock();
    };
    
    const onMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement === gl.domElement) {
        currentLook.current.y -= e.movementX * MOUSE_SENSITIVITY;
        // Fix Inversion: Mouse Down (positive Y) -> Look Down (negative Pitch)
        // Mouse Up (negative Y) -> Look Up (positive Pitch)
        currentLook.current.x -= e.movementY * MOUSE_SENSITIVITY;
      }
    };

    const element = gl.domElement;
    element.addEventListener('click', onClick);
    document.addEventListener('mousemove', onMouseMove);

    return () => {
      element.removeEventListener('click', onClick);
      document.removeEventListener('mousemove', onMouseMove);
    };
  }, [gl.domElement, device]);

  useFrame((state, delta) => {
    if (!body.current) return;

    const keys = getKeys();
    
    /* -------------------------------------------------------------------------- */
    /*                                    INPUT                                   */
    /* -------------------------------------------------------------------------- */
    
    // 1. Rotation
    // Joystick Look (Continuous)
    if (Math.abs(input.lookX) > 0.01) currentLook.current.y -= input.lookX * ROTATION_SPEED * delta;
    
    // Fix Inversion: Joystick Up (positive input.lookY due to MobileControls) -> Look Up (positive Pitch)
    if (Math.abs(input.lookY) > 0.01) currentLook.current.x += input.lookY * ROTATION_SPEED * delta;

    // Keyboard Rotation (Q/E)
    if (keys.rotateLeft) currentLook.current.y += ROTATION_SPEED * delta;
    if (keys.rotateRight) currentLook.current.y -= ROTATION_SPEED * delta;

    // Clamp Pitch
    currentLook.current.x = Math.max(-1.4, Math.min(1.4, currentLook.current.x));

    // 2. Movement
    // Joystick Move + Keyboard WASD
    // Fix: Align Keyboard with Joystick (Right is Positive)
    const forward = (keys.forward ? 1 : 0) - (keys.backward ? 1 : 0) + input.moveY;
    const strafe = (keys.right ? 1 : 0) - (keys.left ? 1 : 0) + input.moveX;
    const isJumping = keys.jump || input.jump;

    /* -------------------------------------------------------------------------- */
    /*                                   PHYSICS                                  */
    /* -------------------------------------------------------------------------- */
    const linvel = body.current.linvel();
    const translation = body.current.translation();

    // Calculate forward vector based on Y-rotation (Azimuth)
    front.set(0, 0, -1).applyEuler(new Euler(0, currentLook.current.y, 0));
    side.crossVectors(front, worldUp).normalize();

    // Combine inputs
    // Fix: Use positive strafe (Right is +Side)
    dir.addVectors(front.multiplyScalar(forward), side.multiplyScalar(strafe)).normalize();

    // Apply velocity
    const speed = MOVEMENT_SPEED;
    velocity.set(dir.x * speed, linvel.y, dir.z * speed);
    body.current.setLinvel(velocity, true);

    // Rotate Body to face Camera Yaw
    bodyQuat.setFromAxisAngle(worldUp, currentLook.current.y);
    body.current.setRotation(bodyQuat, true);

    // Jump
    if (isJumping && Math.abs(linvel.y) < 0.1) {
       body.current.applyImpulse({ x: 0, y: JUMP_FORCE, z: 0 }, true);
    }

    /* -------------------------------------------------------------------------- */
    /*                                   CAMERA                                   */
    /* -------------------------------------------------------------------------- */
    const pos = new Vector3(translation.x, translation.y, translation.z);

    if (mode === 'first-person') {
       const headPos = pos.clone().add(new Vector3(0, 1.6, 0));
       camera.position.copy(headPos);
       // Look direction: apply Pitch (x) and Yaw (y)
       // Note: We rely on the currentLook state, not the body rotation for Pitch
       const target = new Vector3(0, 0, -1).applyEuler(currentLook.current).add(camera.position);
       camera.lookAt(target);
    } else {
       // Third Person Chase
       const offset = new Vector3(0, 0, 6).applyEuler(currentLook.current); // Behind
       offset.y = 2.5; // Up
       const camPos = pos.clone().add(offset);
       camera.position.lerp(camPos, 0.2); // smooth follow
       
       const target = pos.clone().add(new Vector3(0, 1.5, 0)); // Look at head
       camera.lookAt(target);
    }
  });

  return (
    <RigidBody 
      ref={body} 
      colliders={false} 
      enabledRotations={[false, false, false]} 
      position={[0, 5, 0]}
      friction={1}
    >
      <CapsuleCollider args={[0.5, 0.5]} />
      {/* Visuals - Placeholder Capsule */}
      {mode === 'first-person' ? null : ( // Hide when in first-person
        <group position={[0, 0.5, 0]}>
          <mesh castShadow>
            <capsuleGeometry args={[0.5, 1, 4, 8]} />
            <meshStandardMaterial color="#88c" />
          </mesh>
          {/* Visor to indicate front */}
          <mesh position={[0, 0.5, -0.4]} castShadow>
            <boxGeometry args={[0.5, 0.2, 0.2]} />
            <meshStandardMaterial color="#333" />
          </mesh>
        </group>
      )}
    </RigidBody>
  );
}
