'use client';

import { AppHeader } from '../navigation/AppHeader';

interface PageLayoutProps {
  children: React.ReactNode;
  title?: string;
  description?: string;
  gradient?: string;
  showBackButton?: boolean;
  showStats?: boolean;
  stats?: Array<{
    label: string;
    value: string;
    change?: string;
    changeType?: 'positive' | 'negative' | 'neutral';
  }>;
}

export function PageLayout({ 
  children, 
  title, 
  description, 
  gradient, 
  showBackButton = true,
  showStats = false,
  stats = []
}: PageLayoutProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-indigo-900 to-purple-900 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-15">
        <div className="absolute top-20 left-20 w-96 h-96 bg-cyan-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
        <div className="absolute top-40 right-20 w-96 h-96 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-2s"></div>
        <div className="absolute -bottom-8 left-20 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-4s"></div>
      </div>

      <div className="relative z-10">
        <AppHeader 
          title={title}
          description={description}
          gradient={gradient}
          showBackButton={showBackButton}
        />
        
        {/* Stats Bar */}
        {showStats && stats.length > 0 && (
          <div className="px-4 py-4 border-b border-white/10 bg-black/10 backdrop-blur-md">
            <div className="max-w-7xl mx-auto">
              <div className="flex items-center justify-center gap-8 text-sm">
                {stats.map((stat, idx) => (
                  <div key={idx} className="text-center">
                    <div className={`font-bold ${
                      stat.changeType === 'positive' ? 'text-green-400' :
                      stat.changeType === 'negative' ? 'text-red-400' :
                      'text-white'
                    }`}>
                      {stat.value}
                      {stat.change && (
                        <span className={`ml-1 text-xs ${
                          stat.changeType === 'positive' ? 'text-green-400' :
                          stat.changeType === 'negative' ? 'text-red-400' :
                          'text-gray-400'
                        }`}>
                          {stat.change}
                        </span>
                      )}
                    </div>
                    <div className="text-gray-400 text-xs">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
        
        <main className="px-4 pb-8">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}