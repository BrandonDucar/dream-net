'use client'

import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Volume2, 
  VolumeX, 
  Repeat, 
  Shuffle,
  Heart,
  Share2,
  Download,
  Maximize2,
  Minimize2,
  Music,
  Headphones
} from 'lucide-react'
import { toast } from 'sonner'
import { useSubscription } from '@/stores/subscriptionStore'

interface Song {
  id: string
  title: string
  artist: string
  genre?: string[]
  duration: number
  coverArt: string
  audioUrl: string
  isLiked?: boolean
}

interface EnhancedMusicPlayerProps {
  song: Song
  playlist?: Song[]
  onClose: () => void
  onNext?: () => void
  onPrevious?: () => void
}

export function EnhancedMusicPlayer({ 
  song, 
  playlist = [], 
  onClose, 
  onNext, 
  onPrevious 
}: EnhancedMusicPlayerProps): JSX.Element {
  const [isPlaying, setIsPlaying] = useState<boolean>(false)
  const [currentTime, setCurrentTime] = useState<number>(0)
  const [volume, setVolume] = useState<number[]>([70])
  const [isMuted, setIsMuted] = useState<boolean>(false)
  const [isShuffled, setIsShuffled] = useState<boolean>(false)
  const [repeatMode, setRepeatMode] = useState<'none' | 'one' | 'all'>('none')
  const [isLiked, setIsLiked] = useState<boolean>(song.isLiked || false)
  const [isExpanded, setIsExpanded] = useState<boolean>(false)
  const [visualizerData, setVisualizerData] = useState<number[]>([])
  
  const audioRef = useRef<HTMLAudioElement>(null)
  const animationFrameRef = useRef<number>()
  const { subscription, checkFeatureAccess } = useSubscription()

  useEffect(() => {
    // Generate mock visualizer data
    const generateVisualizerData = (): void => {
      if (isPlaying) {
        const data = Array.from({ length: 32 }, () => Math.random() * 100)
        setVisualizerData(data)
        animationFrameRef.current = requestAnimationFrame(generateVisualizerData)
      }
    }

    if (isPlaying) {
      generateVisualizerData()
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
    }
  }, [isPlaying])

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const updateTime = (): void => {
      setCurrentTime(audio.currentTime)
    }

    const handleEnded = (): void => {
      if (repeatMode === 'one') {
        audio.currentTime = 0
        audio.play()
      } else if (repeatMode === 'all' && onNext) {
        onNext()
      } else {
        setIsPlaying(false)
      }
    }

    audio.addEventListener('timeupdate', updateTime)
    audio.addEventListener('ended', handleEnded)

    return () => {
      audio.removeEventListener('timeupdate', updateTime)
      audio.removeEventListener('ended', handleEnded)
    }
  }, [repeatMode, onNext])

  const togglePlay = async (): Promise<void> => {
    const audio = audioRef.current
    if (!audio) return

    if (!checkFeatureAccess('music_playback')) {
      toast.error('Upgrade to Pro to play music!')
      return
    }

    try {
      if (isPlaying) {
        await audio.pause()
      } else {
        await audio.play()
      }
      setIsPlaying(!isPlaying)
    } catch (error) {
      toast.error('Failed to play audio')
    }
  }

  const handleSeek = (values: number[]): void => {
    const audio = audioRef.current
    if (audio) {
      const newTime = (values[0] / 100) * song.duration
      audio.currentTime = newTime
      setCurrentTime(newTime)
    }
  }

  const handleVolumeChange = (values: number[]): void => {
    const audio = audioRef.current
    if (audio) {
      const newVolume = values[0] / 100
      audio.volume = newVolume
      setVolume(values)
      setIsMuted(newVolume === 0)
    }
  }

  const toggleMute = (): void => {
    const audio = audioRef.current
    if (audio) {
      if (isMuted) {
        audio.volume = volume[0] / 100
        setIsMuted(false)
      } else {
        audio.volume = 0
        setIsMuted(true)
      }
    }
  }

  const handleLike = (): void => {
    setIsLiked(!isLiked)
    toast.success(isLiked ? 'Removed from favorites' : 'Added to favorites')
  }

  const handleShare = (): void => {
    const shareUrl = `https://sonicprism.app/track/${song.id}`
    navigator.clipboard.writeText(shareUrl)
    toast.success('Track link copied to clipboard!')
  }

  const handleDownload = async (): Promise<void> => {
    if (!checkFeatureAccess('downloads')) {
      toast.error('Upgrade to Pro to download tracks!')
      return
    }

    try {
      const response = await fetch('/api/download-track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ songId: song.id })
      })
      
      if (response.ok) {
        const blob = await response.blob()
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `${song.title} - ${song.artist}.mp3`
        a.click()
        URL.revokeObjectURL(url)
        toast.success('Download started!')
      }
    } catch (error) {
      toast.error('Download failed')
    }
  }

  const toggleRepeat = (): void => {
    const modes: Array<'none' | 'one' | 'all'> = ['none', 'one', 'all']
    const currentIndex = modes.indexOf(repeatMode)
    const nextMode = modes[(currentIndex + 1) % modes.length]
    setRepeatMode(nextMode)
    
    const messages = {
      none: 'Repeat off',
      one: 'Repeat current track',
      all: 'Repeat playlist'
    }
    toast.success(messages[nextMode])
  }

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const progress = song.duration > 0 ? (currentTime / song.duration) * 100 : 0

  return (
    <>
      {/* Hidden Audio Element */}
      <audio
        ref={audioRef}
        src={song.audioUrl}
        onLoadedData={() => {
          if (audioRef.current) {
            audioRef.current.volume = volume[0] / 100
          }
        }}
      />

      <Card className={`bg-gray-900/95 backdrop-blur-lg border-gray-700 text-white transition-all duration-300 ${
        isExpanded ? 'fixed inset-4 z-50' : 'relative'
      }`}>
        <CardContent className="p-0">
          <div className={`${isExpanded ? 'h-full flex flex-col' : ''}`}>
            {/* Main Player */}
            <div className={`${isExpanded ? 'flex-1 flex items-center' : 'flex items-center'} p-4 gap-4`}>
              {/* Album Art */}
              <div className={`relative ${isExpanded ? 'w-80 h-80' : 'w-16 h-16'} flex-shrink-0`}>
                <img
                  src={song.coverArt}
                  alt={song.title}
                  className={`w-full h-full object-cover ${isExpanded ? 'rounded-xl' : 'rounded-lg'}`}
                />
                {isExpanded && (
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-xl" />
                )}
              </div>

              {/* Track Info & Controls */}
              <div className={`flex-1 ${isExpanded ? 'ml-8' : ''}`}>
                <div className="flex items-center justify-between mb-2">
                  <div className={`flex-1 ${isExpanded ? 'mb-6' : ''}`}>
                    <h3 className={`font-bold truncate ${isExpanded ? 'text-3xl mb-2' : 'text-sm'}`}>
                      {song.title}
                    </h3>
                    <div className="flex items-center gap-2">
                      <Avatar className={`${isExpanded ? 'w-8 h-8' : 'w-5 h-5'}`}>
                        <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${song.artist}`} />
                        <AvatarFallback>{song.artist[0]}</AvatarFallback>
                      </Avatar>
                      <p className={`text-gray-400 truncate ${isExpanded ? 'text-lg' : 'text-xs'}`}>
                        {song.artist}
                      </p>
                    </div>
                    
                    {isExpanded && song.genre && (
                      <div className="flex gap-2 mt-3">
                        {song.genre.map((g) => (
                          <Badge key={g} variant="secondary">{g}</Badge>
                        ))}
                      </div>
                    )}
                  </div>

                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setIsExpanded(!isExpanded)}
                    className={`${isExpanded ? 'absolute top-4 right-4' : ''}`}
                  >
                    {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                  </Button>
                </div>

                {/* Audio Visualizer (Expanded Mode Only) */}
                {isExpanded && (
                  <div className="mb-6">
                    <div className="flex items-end gap-1 h-16 bg-gray-800/50 rounded-lg p-2">
                      {visualizerData.map((height, index) => (
                        <div
                          key={index}
                          className="bg-gradient-to-t from-purple-500 to-cyan-400 rounded-sm transition-all duration-75"
                          style={{
                            height: `${Math.max(4, height)}%`,
                            width: `${100 / visualizerData.length}%`
                          }}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {/* Progress Bar */}
                <div className={`mb-3 ${isExpanded ? 'mb-6' : ''}`}>
                  <Slider
                    value={[progress]}
                    onValueChange={handleSeek}
                    max={100}
                    step={0.1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-400 mt-1">
                    <span>{formatTime(currentTime)}</span>
                    <span>{formatTime(song.duration)}</span>
                  </div>
                </div>

                {/* Controls */}
                <div className={`flex items-center justify-between ${isExpanded ? 'mb-6' : ''}`}>
                  <div className="flex items-center gap-2">
                    {/* Previous */}
                    <Button
                      variant="ghost"
                      size={isExpanded ? 'default' : 'sm'}
                      onClick={onPrevious}
                      disabled={!onPrevious}
                    >
                      <SkipBack className={`${isExpanded ? 'w-5 h-5' : 'w-4 h-4'}`} />
                    </Button>

                    {/* Play/Pause */}
                    <Button
                      onClick={togglePlay}
                      className={`${isExpanded ? 'w-14 h-14' : 'w-10 h-10'} rounded-full bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700`}
                    >
                      {isPlaying ? (
                        <Pause className={`${isExpanded ? 'w-6 h-6' : 'w-4 h-4'}`} />
                      ) : (
                        <Play className={`${isExpanded ? 'w-6 h-6' : 'w-4 h-4'} ml-1`} />
                      )}
                    </Button>

                    {/* Next */}
                    <Button
                      variant="ghost"
                      size={isExpanded ? 'default' : 'sm'}
                      onClick={onNext}
                      disabled={!onNext}
                    >
                      <SkipForward className={`${isExpanded ? 'w-5 h-5' : 'w-4 h-4'}`} />
                    </Button>
                  </div>

                  {/* Secondary Controls */}
                  {!isExpanded ? (
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="icon" onClick={handleLike}>
                        <Heart className={`w-4 h-4 ${isLiked ? 'fill-current text-red-500' : ''}`} />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={onClose}>
                        ×
                      </Button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" onClick={handleLike}>
                        <Heart className={`w-5 h-5 mr-2 ${isLiked ? 'fill-current text-red-500' : ''}`} />
                        {isLiked ? 'Liked' : 'Like'}
                      </Button>
                      <Button variant="ghost" onClick={handleShare}>
                        <Share2 className="w-5 h-5 mr-2" />
                        Share
                      </Button>
                      <Button variant="ghost" onClick={handleDownload}>
                        <Download className="w-5 h-5 mr-2" />
                        Download
                      </Button>
                    </div>
                  )}
                </div>

                {/* Expanded Controls */}
                {isExpanded && (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <Button
                        variant="ghost"
                        onClick={() => setIsShuffled(!isShuffled)}
                        className={isShuffled ? 'text-cyan-400' : ''}
                      >
                        <Shuffle className="w-5 h-5" />
                      </Button>
                      
                      <Button
                        variant="ghost"
                        onClick={toggleRepeat}
                        className={repeatMode !== 'none' ? 'text-cyan-400' : ''}
                      >
                        <Repeat className="w-5 h-5" />
                        {repeatMode === 'one' && <span className="text-xs ml-1">1</span>}
                      </Button>
                    </div>

                    {/* Volume Control */}
                    <div className="flex items-center gap-3">
                      <Button variant="ghost" size="icon" onClick={toggleMute}>
                        {isMuted || volume[0] === 0 ? (
                          <VolumeX className="w-5 h-5" />
                        ) : (
                          <Volume2 className="w-5 h-5" />
                        )}
                      </Button>
                      <div className="w-24">
                        <Slider
                          value={isMuted ? [0] : volume}
                          onValueChange={handleVolumeChange}
                          max={100}
                          step={1}
                        />
                      </div>
                    </div>

                    <Button variant="outline" onClick={onClose}>
                      Close
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  )
}