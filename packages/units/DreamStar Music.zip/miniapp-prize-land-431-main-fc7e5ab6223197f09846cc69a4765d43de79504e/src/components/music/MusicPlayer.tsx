'use client';

import { useEffect, useRef, useState } from 'react';
import { useSonicPrism } from '@/components/sonic-prism/SonicPrismProvider';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward,
  Volume2,
  VolumeX,
  Download,
  Share2,
  Heart,
  MoreHorizontal,
  Music,
  Waveform,
  Clock,
  User
} from 'lucide-react';
import * as Tone from 'tone';

interface PlaylistTrack {
  id: string;
  name: string;
  artist: string;
  duration: number;
  audioUrl: string;
  genre: string;
  bpm: number;
  key: string;
  energy: number;
  isLiked: boolean;
  createdAt: string;
}

export function MusicPlayer() {
  const {
    ribbons,
    selectedRibbonId,
    selectRibbon,
    isPlaying,
    setPlaying,
    masterVolume,
    setMasterVolume,
    audioFeatures
  } = useSonicPrism();

  const [currentTrack, setCurrentTrack] = useState<PlaylistTrack | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isShuffled, setIsShuffled] = useState(false);
  const [repeatMode, setRepeatMode] = useState<'off' | 'one' | 'all'>('off');
  const [playlist, setPlaylist] = useState<PlaylistTrack[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(false);

  const playerRef = useRef<Tone.Player | null>(null);
  const positionRef = useRef<number>(0);

  // Convert ribbons to playlist tracks
  useEffect(() => {
    const tracks: PlaylistTrack[] = ribbons.map((ribbon, index) => ({
      id: ribbon.id,
      name: ribbon.name,
      artist: 'DreamStar Music AI',
      duration: 180, // Default 3 minutes, should be calculated from audio
      audioUrl: ribbon.audioUrl || '',
      genre: ribbon.genre,
      bpm: ribbon.bpm,
      key: ribbon.key,
      energy: ribbon.energy,
      isLiked: false,
      createdAt: new Date().toISOString(),
    }));
    
    setPlaylist(tracks);
    
    // Set current track if none selected
    if (!currentTrack && tracks.length > 0) {
      setCurrentTrack(tracks[0]);
      setCurrentIndex(0);
    }
  }, [ribbons, currentTrack]);

  // Load current track
  useEffect(() => {
    if (currentTrack && currentTrack.audioUrl) {
      loadTrack(currentTrack.audioUrl);
    }
  }, [currentTrack]);

  // Update position
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isPlaying && playerRef.current) {
      interval = setInterval(() => {
        positionRef.current += 0.1;
        setCurrentTime(positionRef.current);
        
        // Auto-advance to next track when finished
        if (positionRef.current >= duration) {
          handleNext();
        }
      }, 100);
    }
    
    return () => clearInterval(interval);
  }, [isPlaying, duration]);

  const loadTrack = async (audioUrl: string) => {
    try {
      setIsLoading(true);
      
      // Dispose previous player
      if (playerRef.current) {
        playerRef.current.dispose();
      }

      // Create new player
      playerRef.current = new Tone.Player({
        url: audioUrl,
        onload: () => {
          if (playerRef.current) {
            const trackDuration = playerRef.current.buffer.duration;
            setDuration(trackDuration);
            setIsLoading(false);
          }
        },
        onerror: (error) => {
          console.error('Audio load error:', error);
          setIsLoading(false);
        }
      }).toDestination();

      // Reset position
      positionRef.current = 0;
      setCurrentTime(0);

    } catch (error) {
      console.error('Failed to load track:', error);
      setIsLoading(false);
    }
  };

  const togglePlay = async () => {
    if (!playerRef.current) return;

    if (Tone.context.state !== 'running') {
      await Tone.start();
    }

    if (isPlaying) {
      playerRef.current.stop();
      setPlaying(false);
    } else {
      playerRef.current.start(0, positionRef.current);
      setPlaying(true);
    }
  };

  const handleSeek = (value: number[]) => {
    const newTime = value[0];
    setCurrentTime(newTime);
    positionRef.current = newTime;
    
    if (playerRef.current && isPlaying) {
      playerRef.current.stop();
      playerRef.current.start(0, newTime);
    }
  };

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0] / 100;
    setMasterVolume(newVolume);
  };

  const toggleMute = () => {
    if (isMuted) {
      setMasterVolume(0.7);
      setIsMuted(false);
    } else {
      setMasterVolume(0);
      setIsMuted(true);
    }
  };

  const handlePrevious = () => {
    const newIndex = currentIndex > 0 ? currentIndex - 1 : playlist.length - 1;
    setCurrentIndex(newIndex);
    setCurrentTrack(playlist[newIndex]);
  };

  const handleNext = () => {
    let newIndex: number;
    
    if (repeatMode === 'one') {
      newIndex = currentIndex;
    } else if (repeatMode === 'all') {
      newIndex = currentIndex < playlist.length - 1 ? currentIndex + 1 : 0;
    } else {
      newIndex = currentIndex < playlist.length - 1 ? currentIndex + 1 : 0;
    }
    
    setCurrentIndex(newIndex);
    setCurrentTrack(playlist[newIndex]);
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleShare = async () => {
    if (currentTrack && navigator.share) {
      await navigator.share({
        title: currentTrack.name,
        text: `Check out "${currentTrack.name}" created with DreamStar Music`,
        url: window.location.href
      });
    }
  };

  const handleDownload = () => {
    if (currentTrack?.audioUrl) {
      const link = document.createElement('a');
      link.href = currentTrack.audioUrl;
      link.download = `${currentTrack.name}.mp3`;
      link.click();
    }
  };

  if (!currentTrack) {
    return (
      <Card className="w-full">
        <CardContent className="flex items-center justify-center p-8">
          <div className="text-center space-y-2">
            <Music className="h-12 w-12 mx-auto text-muted-foreground" />
            <p className="text-muted-foreground">No tracks available</p>
            <p className="text-sm text-muted-foreground">Create some music to start playing</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardContent className="p-6 space-y-6">
        {/* Track Info */}
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
            <Waveform className="h-8 w-8 text-white" />
          </div>
          
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold truncate">{currentTrack.name}</h3>
            <p className="text-sm text-muted-foreground flex items-center gap-2">
              <User className="h-3 w-3" />
              {currentTrack.artist}
            </p>
            
            <div className="flex items-center gap-4 mt-1">
              <Badge variant="outline" className="text-xs">
                {currentTrack.genre}
              </Badge>
              <Badge variant="outline" className="text-xs">
                {currentTrack.bpm} BPM
              </Badge>
              <Badge variant="outline" className="text-xs">
                Key: {currentTrack.key}
              </Badge>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm">
              <Heart className={`h-4 w-4 ${currentTrack.isLiked ? 'fill-red-500 text-red-500' : ''}`} />
            </Button>
            <Button variant="ghost" size="sm" onClick={handleShare}>
              <Share2 className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={handleDownload}>
              <Download className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="space-y-2">
          <Slider
            value={[currentTime]}
            max={duration}
            step={0.1}
            onValueChange={handleSeek}
            className="w-full"
          />
          
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-4">
          <Button variant="ghost" size="sm" onClick={handlePrevious}>
            <SkipBack className="h-4 w-4" />
          </Button>
          
          <Button 
            onClick={togglePlay} 
            disabled={isLoading}
            className="h-12 w-12 rounded-full"
          >
            {isLoading ? (
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
            ) : isPlaying ? (
              <Pause className="h-5 w-5" />
            ) : (
              <Play className="h-5 w-5" />
            )}
          </Button>
          
          <Button variant="ghost" size="sm" onClick={handleNext}>
            <SkipForward className="h-4 w-4" />
          </Button>
        </div>

        {/* Volume Control */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={toggleMute}>
            {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          </Button>
          
          <div className="flex-1">
            <Slider
              value={[masterVolume * 100]}
              max={100}
              step={1}
              onValueChange={handleVolumeChange}
              className="w-full"
            />
          </div>
        </div>

        <Separator />

        {/* Audio Visualization */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm font-medium">
            <span>Audio Analysis</span>
            <span className="text-muted-foreground">Real-time</span>
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="space-y-1">
              <div className="flex justify-between">
                <span>Energy</span>
                <span>{Math.round(audioFeatures.energy * 100)}%</span>
              </div>
              <Progress value={audioFeatures.energy * 100} className="h-2" />
            </div>
            
            <div className="space-y-1">
              <div className="flex justify-between">
                <span>RMS</span>
                <span>{Math.round(audioFeatures.rms * 100)}%</span>
              </div>
              <Progress value={audioFeatures.rms * 100} className="h-2" />
            </div>
          </div>
        </div>

        {/* Playlist Preview */}
        {playlist.length > 1 && (
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Up Next</span>
              <Badge variant="outline" className="text-xs">
                {playlist.length} tracks
              </Badge>
            </div>
            
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {playlist.slice(currentIndex + 1, currentIndex + 4).map((track, index) => (
                <div key={track.id} className="flex items-center gap-2 p-2 rounded-md hover:bg-muted/50 cursor-pointer">
                  <div className="w-2 h-2 bg-muted-foreground rounded-full" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm truncate">{track.name}</p>
                    <p className="text-xs text-muted-foreground">{track.artist}</p>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    <Clock className="h-3 w-3 inline mr-1" />
                    {formatTime(track.duration)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}