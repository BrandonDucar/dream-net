'use client';

import { useState } from 'react';
import { useSubscriptionStore } from '@/stores/subscriptionStore';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { 
  Share2, 
  Copy, 
  Twitter, 
  Facebook, 
  Instagram, 
  Music, 
  Download,
  ExternalLink,
  Crown,
  CheckCircle
} from 'lucide-react';
import type { AudioRibbon } from '@/components/sonic-prism/SonicPrismProvider';

interface ShareDialogProps {
  track: AudioRibbon;
  children: React.ReactNode;
}

export function ShareDialog({ track, children }: ShareDialogProps) {
  const { currentTier, canUseFeature } = useSubscriptionStore();
  const [isOpen, setIsOpen] = useState(false);
  const [shareUrl, setShareUrl] = useState('');
  const [title, setTitle] = useState(track.name);
  const [description, setDescription] = useState(`Created with DreamStar Music - ${track.genre} track in ${track.key} key at ${track.bpm} BPM`);
  const [enableComments, setEnableComments] = useState(true);
  const [enableDownloads, setEnableDownloads] = useState(currentTier !== 'free');
  const [commercialUse, setCommercialUse] = useState(canUseFeature('commercialUse'));
  const [isGeneratingShare, setIsGeneratingShare] = useState(false);
  const [shareGenerated, setShareGenerated] = useState(false);

  const generateShareLink = async () => {
    setIsGeneratingShare(true);
    
    // Simulate share link generation
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const baseUrl = window.location.origin;
    const trackId = track.id;
    const generatedUrl = `${baseUrl}/track/${trackId}?title=${encodeURIComponent(title)}&desc=${encodeURIComponent(description)}`;
    
    setShareUrl(generatedUrl);
    setShareGenerated(true);
    setIsGeneratingShare(false);
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      // Could add toast notification here
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };

  const shareToSocial = (platform: 'twitter' | 'facebook' | 'instagram') => {
    const encodedTitle = encodeURIComponent(title);
    const encodedUrl = encodeURIComponent(shareUrl || window.location.href);
    const encodedDesc = encodeURIComponent(description);
    
    const urls = {
      twitter: `https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encodedUrl}&hashtags=DreamStarMusic,AIMusic,MusicCreation`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}&quote=${encodedTitle}`,
      instagram: `https://www.instagram.com/?url=${encodedUrl}` // Instagram doesn't have direct sharing URL
    };
    
    if (platform === 'instagram') {
      // For Instagram, copy to clipboard since they don't support URL sharing
      copyToClipboard(`${title}\n\n${description}\n\n${shareUrl}\n\n#DreamStarMusic #AIMusic #MusicCreation`);
      alert('Content copied to clipboard! Paste it in your Instagram post.');
      return;
    }
    
    window.open(urls[platform], '_blank', 'width=600,height=400');
  };

  const downloadTrack = () => {
    if (!canUseFeature('socialSharing')) {
      alert('Download feature requires a paid subscription');
      return;
    }
    
    if (track.audioUrl) {
      const link = document.createElement('a');
      link.href = track.audioUrl;
      link.download = `${track.name}.mp3`;
      link.click();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="h-5 w-5" />
            Share Your Music
          </DialogTitle>
          <DialogDescription>
            Share your AI-generated track with the world
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Track Preview */}
          <div className="flex items-center gap-4 p-4 bg-muted/50 rounded-lg">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <Music className="h-8 w-8 text-white" />
            </div>
            
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold truncate">{track.name}</h3>
              <p className="text-sm text-muted-foreground">
                {track.genre} • {track.key} key • {track.bpm} BPM
              </p>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="outline" className="text-xs">
                  Energy: {Math.round(track.energy * 100)}%
                </Badge>
                {canUseFeature('commercialUse') && (
                  <Badge variant="outline" className="text-xs text-green-600">
                    Commercial Use OK
                  </Badge>
                )}
              </div>
            </div>
          </div>

          {/* Share Configuration */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Give your track a catchy title"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe your track..."
                rows={3}
              />
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label>Enable Comments</Label>
                  <p className="text-xs text-muted-foreground">Allow others to comment on your track</p>
                </div>
                <Switch
                  checked={enableComments}
                  onCheckedChange={setEnableComments}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label>Allow Downloads</Label>
                  <p className="text-xs text-muted-foreground">
                    {canUseFeature('socialSharing') 
                      ? 'Let others download your track' 
                      : 'Requires paid subscription'
                    }
                  </p>
                </div>
                <Switch
                  checked={enableDownloads}
                  onCheckedChange={setEnableDownloads}
                  disabled={!canUseFeature('socialSharing')}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="flex items-center gap-2">
                    Commercial Use License
                    {!canUseFeature('commercialUse') && <Crown className="h-3 w-3 text-yellow-500" />}
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    {canUseFeature('commercialUse') 
                      ? 'Allow commercial use of your track' 
                      : 'Upgrade to Pro for commercial licensing'
                    }
                  </p>
                </div>
                <Switch
                  checked={commercialUse}
                  onCheckedChange={setCommercialUse}
                  disabled={!canUseFeature('commercialUse')}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Share Link Generation */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label>Shareable Link</Label>
              {!shareGenerated && (
                <Button 
                  onClick={generateShareLink}
                  disabled={isGeneratingShare}
                  size="sm"
                >
                  {isGeneratingShare ? 'Generating...' : 'Generate Link'}
                </Button>
              )}
            </div>

            {shareGenerated && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-sm text-green-600">Share link generated successfully!</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <Input
                    value={shareUrl}
                    readOnly
                    className="flex-1"
                  />
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => copyToClipboard(shareUrl)}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Social Media Sharing */}
          {shareGenerated && (
            <>
              <Separator />
              
              <div className="space-y-4">
                <Label>Share on Social Media</Label>
                
                <div className="grid grid-cols-3 gap-3">
                  <Button 
                    variant="outline" 
                    onClick={() => shareToSocial('twitter')}
                    className="flex items-center gap-2"
                  >
                    <Twitter className="h-4 w-4 text-blue-500" />
                    Twitter
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    onClick={() => shareToSocial('facebook')}
                    className="flex items-center gap-2"
                  >
                    <Facebook className="h-4 w-4 text-blue-600" />
                    Facebook
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    onClick={() => shareToSocial('instagram')}
                    className="flex items-center gap-2"
                  >
                    <Instagram className="h-4 w-4 text-pink-500" />
                    Instagram
                  </Button>
                </div>
              </div>
            </>
          )}

          {/* Additional Actions */}
          <Separator />
          
          <div className="flex justify-between items-center">
            <Button 
              variant="outline" 
              onClick={downloadTrack}
              disabled={!canUseFeature('socialSharing')}
              className="flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              Download Track
              {!canUseFeature('socialSharing') && <Crown className="h-3 w-3 text-yellow-500" />}
            </Button>

            {shareGenerated && (
              <Button 
                onClick={() => window.open(shareUrl, '_blank')}
                className="flex items-center gap-2"
              >
                <ExternalLink className="h-4 w-4" />
                Preview Share Page
              </Button>
            )}
          </div>

          {/* Upgrade Prompt for Free Users */}
          {currentTier === 'free' && (
            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-start gap-3">
                <Crown className="h-5 w-5 text-yellow-500 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-sm font-medium text-yellow-800">
                    Unlock Full Sharing Features
                  </p>
                  <p className="text-xs text-yellow-700">
                    Upgrade to Pro to enable downloads, commercial use licensing, and advanced sharing features.
                  </p>
                  <Button size="sm" className="mt-2" onClick={() => setIsOpen(false)}>
                    Upgrade Now
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}