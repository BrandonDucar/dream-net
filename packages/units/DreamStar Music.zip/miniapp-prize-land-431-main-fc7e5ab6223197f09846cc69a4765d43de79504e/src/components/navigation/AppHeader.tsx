'use client';

import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { ArrowLeft, Music, Home, Users, TrendingUp, ShoppingBag } from 'lucide-react';
import { useRouter } from 'next/navigation';

interface AppHeaderProps {
  title?: string;
  description?: string;
  gradient?: string;
  showBackButton?: boolean;
}

export function AppHeader({ 
  title, 
  description, 
  gradient, 
  showBackButton = true 
}: AppHeaderProps) {
  const router = useRouter();

  return (
    <header className="px-4 py-6 border-b border-white/10 backdrop-blur-md bg-black/10">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            {/* Logo and Brand */}
            <div className="flex items-center gap-4">
              {showBackButton && (
                <Button
                  onClick={() => router.push('/')}
                  className="bg-white/10 hover:bg-white/20 border border-white/20 backdrop-blur-sm"
                  size="sm"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Home
                </Button>
              )}
              
              <div className="flex items-center gap-3">
                <div className="p-2 bg-gradient-to-br from-cyan-500 to-purple-600 rounded-xl">
                  <Music className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl md:text-2xl font-bold text-white">
                    DreamStar Music
                  </h1>
                  <p className="text-cyan-300 text-xs">Holographic AI Music Platform</p>
                </div>
              </div>
            </div>
            
            {/* Navigation Pills */}
            <nav className="hidden lg:flex items-center gap-1 bg-black/20 rounded-xl p-1">
              <Button
                variant="ghost"
                size="sm"
                className="text-white/70 hover:text-white hover:bg-white/10 px-4 py-2 text-sm"
                onClick={() => router.push('/')}
              >
                <Home className="w-4 h-4 mr-2" />
                Studio
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-white/70 hover:text-white hover:bg-white/10 px-4 py-2 text-sm"
                onClick={() => router.push('/marketplace')}
              >
                <ShoppingBag className="w-4 h-4 mr-2" />
                Market
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-white/70 hover:text-white hover:bg-white/10 px-4 py-2 text-sm"
                onClick={() => router.push('/community')}
              >
                <Users className="w-4 h-4 mr-2" />
                Community
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-white/70 hover:text-white hover:bg-white/10 px-4 py-2 text-sm"
                onClick={() => router.push('/leaderboard')}
              >
                <TrendingUp className="w-4 h-4 mr-2" />
                Leaderboard
              </Button>
            </nav>
          </div>
          
          {/* Right side content */}
          <div className="flex items-center gap-4">
            {/* Quick Stats */}
            <div className="hidden md:flex items-center gap-4 text-sm">
              <div className="text-center">
                <div className="text-green-400 font-semibold">+15.2%</div>
                <div className="text-gray-400 text-xs">Portfolio</div>
              </div>
              <div className="text-center">
                <div className="text-white font-semibold">2.4 ETH</div>
                <div className="text-gray-400 text-xs">Earned</div>
              </div>
            </div>
            
            {/* Status Badges */}
            <div className="flex items-center gap-2">
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">
                Online
              </Badge>
            </div>
          </div>
        </div>
        
        {/* Page Title Section */}
        {title && (
          <div className="mt-6">
            <div className="flex items-center gap-4 mb-2">
              <h2 className={`text-2xl md:text-3xl font-bold ${
                gradient ? `bg-gradient-to-r ${gradient} bg-clip-text text-transparent` : 'text-white'
              }`}>
                {title}
              </h2>
            </div>
            {description && (
              <p className="text-gray-300">{description}</p>
            )}
          </div>
        )}
      </div>
    </header>
  );
}