'use client'

import { useState } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Play, 
  Pause, 
  Heart, 
  Share2, 
  Eye, 
  TrendingUp, 
  Calendar, 
  Crown, 
  Star, 
  Medal, 
  Coins,
  ExternalLink,
  Copy,
  ShoppingCart
} from 'lucide-react'
import { toast } from 'sonner'

interface NFTTrack {
  id: string
  tokenId: number
  title: string
  artist: string
  artistAvatar: string
  genre: string[]
  duration: number
  coverArt: string
  rarity: 'common' | 'rare' | 'epic' | 'legendary'
  mintCount: number
  maxMints: number
  floorPrice: number
  lastSalePrice: number
  isForSale: boolean
  salePrice: number
  owner: string
  ownerAvatar: string
  views: number
  likes: number
  createdAt: string
  blockchain: 'base' | 'ethereum'
  royaltyPercentage: number
  tradingVolume: number
}

interface NFTDetailsDialogProps {
  nft: NFTTrack
  open: boolean
  onClose: () => void
}

export function NFTDetailsDialog({ nft, open, onClose }: NFTDetailsDialogProps): JSX.Element {
  const [isPlaying, setIsPlaying] = useState<boolean>(false)
  const [isLiked, setIsLiked] = useState<boolean>(false)

  const getRarityIcon = (rarity: NFTTrack['rarity']): JSX.Element => {
    switch (rarity) {
      case 'legendary': return <Crown className="w-4 h-4 text-yellow-400" />
      case 'epic': return <Star className="w-4 h-4 text-purple-400" />
      case 'rare': return <Medal className="w-4 h-4 text-blue-400" />
      default: return <Coins className="w-4 h-4 text-gray-400" />
    }
  }

  const getRarityColor = (rarity: NFTTrack['rarity']): string => {
    switch (rarity) {
      case 'legendary': return 'text-yellow-400 border-yellow-400'
      case 'epic': return 'text-purple-400 border-purple-400'
      case 'rare': return 'text-blue-400 border-blue-400'
      default: return 'text-gray-400 border-gray-400'
    }
  }

  const formatDuration = (seconds: number): string => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  const handlePlay = (): void => {
    setIsPlaying(!isPlaying)
    // In a real app, this would trigger actual audio playback
    toast.success(isPlaying ? 'Paused' : 'Playing track')
  }

  const handleLike = (): void => {
    setIsLiked(!isLiked)
    toast.success(isLiked ? 'Removed from favorites' : 'Added to favorites')
  }

  const handleShare = (): void => {
    const shareUrl = `https://sonicprism.app/nft/${nft.tokenId}`
    navigator.clipboard.writeText(shareUrl)
    toast.success('NFT link copied to clipboard!')
  }

  const handleViewOnBlockchain = (): void => {
    const explorerUrl = nft.blockchain === 'base' 
      ? `https://basescan.org/token/${nft.tokenId}`
      : `https://etherscan.io/token/${nft.tokenId}`
    window.open(explorerUrl, '_blank')
  }

  const mockPriceHistory = [
    { date: '2024-01-15', price: 0.08 },
    { date: '2024-01-12', price: 0.12 },
    { date: '2024-01-10', price: 0.07 },
    { date: '2024-01-08', price: 0.05 },
    { date: '2024-01-05', price: 0.09 }
  ]

  const mockTraitRarities = [
    { trait: 'Genre', value: 'Synthwave', rarity: '15%' },
    { trait: 'Duration', value: '240s+', rarity: '8%' },
    { trait: 'AI Generated', value: 'Yes', rarity: '45%' },
    { trait: 'Collab Track', value: 'No', rarity: '78%' }
  ]

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="sr-only">NFT Details</DialogTitle>
          <DialogDescription className="sr-only">
            Detailed information about the NFT including price, history, and metadata
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column - Media & Main Info */}
          <div className="space-y-6">
            {/* Cover Art with Controls */}
            <div className="relative group">
              <img
                src={nft.coverArt}
                alt={nft.title}
                className="w-full aspect-square object-cover rounded-xl"
              />
              
              {/* Rarity Badge */}
              <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-sm font-bold border ${getRarityColor(nft.rarity)} bg-black/80 backdrop-blur-sm`}>
                <div className="flex items-center gap-2">
                  {getRarityIcon(nft.rarity)}
                  {nft.rarity.toUpperCase()}
                </div>
              </div>

              {/* Play Controls Overlay */}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl flex items-center justify-center">
                <Button
                  onClick={handlePlay}
                  size="lg"
                  className="bg-white/20 backdrop-blur-sm hover:bg-white/30 text-white border-white/30"
                >
                  {isPlaying ? (
                    <Pause className="w-6 h-6" />
                  ) : (
                    <Play className="w-6 h-6" />
                  )}
                </Button>
              </div>
            </div>

            {/* Basic Info */}
            <div>
              <h1 className="text-3xl font-bold mb-2">{nft.title}</h1>
              
              <div className="flex items-center gap-3 mb-4">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={nft.artistAvatar} />
                  <AvatarFallback>{nft.artist[0]}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{nft.artist}</p>
                  <p className="text-sm text-gray-400">Creator</p>
                </div>
              </div>

              {/* Genre Tags */}
              <div className="flex flex-wrap gap-2 mb-4">
                {nft.genre.map((g) => (
                  <Badge key={g} variant="secondary">
                    {g}
                  </Badge>
                ))}
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-400">{nft.views.toLocaleString()}</div>
                  <div className="text-sm text-gray-400">Views</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-cyan-400">{nft.likes}</div>
                  <div className="text-sm text-gray-400">Likes</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-400">{formatDuration(nft.duration)}</div>
                  <div className="text-sm text-gray-400">Duration</div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button
                  onClick={handleLike}
                  variant="outline"
                  className={`flex-1 ${isLiked ? 'text-red-500 border-red-500' : ''}`}
                >
                  <Heart className={`w-4 h-4 mr-2 ${isLiked ? 'fill-current' : ''}`} />
                  {isLiked ? 'Liked' : 'Like'}
                </Button>
                <Button onClick={handleShare} variant="outline" className="flex-1">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </Button>
                <Button onClick={handleViewOnBlockchain} variant="outline">
                  <ExternalLink className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Right Column - Pricing & Details */}
          <div className="space-y-6">
            {/* Current Owner & Price */}
            <div className="bg-gray-800/50 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-sm text-gray-400 mb-1">Current Owner</p>
                  <div className="flex items-center gap-2">
                    <Avatar className="w-6 h-6">
                      <AvatarImage src={nft.ownerAvatar} />
                      <AvatarFallback>{nft.owner[0]}</AvatarFallback>
                    </Avatar>
                    <span className="font-medium">{nft.owner}</span>
                  </div>
                </div>
                <Badge className={`${nft.blockchain === 'base' ? 'bg-blue-600' : 'bg-gray-600'} text-white`}>
                  {nft.blockchain.toUpperCase()}
                </Badge>
              </div>

              {nft.isForSale ? (
                <div>
                  <p className="text-sm text-gray-400 mb-2">Listed Price</p>
                  <div className="text-3xl font-bold text-green-400 mb-4">
                    {nft.salePrice} ETH
                  </div>
                  <Button className="w-full bg-green-600 hover:bg-green-700 text-white">
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Buy Now for {nft.salePrice} ETH
                  </Button>
                </div>
              ) : (
                <div>
                  <p className="text-sm text-gray-400 mb-2">Floor Price</p>
                  <div className="text-3xl font-bold text-gray-300 mb-4">
                    {nft.floorPrice} ETH
                  </div>
                  <Button variant="outline" className="w-full" disabled>
                    Not Listed for Sale
                  </Button>
                </div>
              )}

              {nft.lastSalePrice > 0 && (
                <div className="mt-4 pt-4 border-t border-gray-700">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Last Sale:</span>
                    <span className="font-semibold">{nft.lastSalePrice} ETH</span>
                  </div>
                </div>
              )}
            </div>

            {/* NFT Details */}
            <Tabs defaultValue="details" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="details">Details</TabsTrigger>
                <TabsTrigger value="history">History</TabsTrigger>
                <TabsTrigger value="traits">Traits</TabsTrigger>
              </TabsList>

              <TabsContent value="details" className="space-y-4 mt-4">
                <div className="bg-gray-800/50 rounded-lg p-4">
                  <h3 className="font-semibold mb-3">Collection Info</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Token ID:</span>
                      <span className="font-mono">#{nft.tokenId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Edition:</span>
                      <span>{nft.mintCount} of {nft.maxMints}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Royalties:</span>
                      <span>{nft.royaltyPercentage}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Created:</span>
                      <span>{formatDate(nft.createdAt)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Total Volume:</span>
                      <span>{nft.tradingVolume} ETH</span>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="history" className="space-y-4 mt-4">
                <div className="bg-gray-800/50 rounded-lg p-4">
                  <h3 className="font-semibold mb-3">Price History</h3>
                  <div className="space-y-3">
                    {mockPriceHistory.map((entry, index) => (
                      <div key={index} className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-3">
                          <TrendingUp className="w-4 h-4 text-green-400" />
                          <span className="text-gray-400">{formatDate(entry.date)}</span>
                        </div>
                        <span className="font-semibold">{entry.price} ETH</span>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="traits" className="space-y-4 mt-4">
                <div className="bg-gray-800/50 rounded-lg p-4">
                  <h3 className="font-semibold mb-3">Trait Rarity</h3>
                  <div className="space-y-3">
                    {mockTraitRarities.map((trait, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
                        <div>
                          <div className="font-medium text-sm">{trait.trait}</div>
                          <div className="text-gray-400 text-xs">{trait.value}</div>
                        </div>
                        <Badge variant="outline" className="text-cyan-400 border-cyan-400">
                          {trait.rarity}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}