'use client'

import { useState } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Slider } from '@/components/ui/slider'
import { Badge } from '@/components/ui/badge'
import { Zap, Crown, Star, Medal, AlertTriangle, Coins } from 'lucide-react'
import { toast } from 'sonner'

interface Song {
  id: string
  title: string
  artist: string
  genre: string[]
  duration: number
  coverArt: string
  rarity?: string
  inspirations?: string[]
}

interface NFTMintDialogProps {
  song: Song
  open: boolean
  onClose: () => void
}

export function NFTMintDialog({ song, open, onClose }: NFTMintDialogProps): JSX.Element {
  const [mintAmount, setMintAmount] = useState<number>(50)
  const [mintPrice, setMintPrice] = useState<number>(0.05)
  const [royaltyPercentage, setRoyaltyPercentage] = useState<number[]>([10])
  const [description, setDescription] = useState<string>('')
  const [blockchain, setBlockchain] = useState<'base' | 'ethereum'>('base')
  const [isLoading, setIsLoading] = useState<boolean>(false)

  const calculateRarity = (): { rarity: string; color: string; icon: JSX.Element } => {
    if (mintAmount <= 10) return { 
      rarity: 'Legendary', 
      color: 'text-yellow-400', 
      icon: <Crown className="w-4 h-4" /> 
    }
    if (mintAmount <= 25) return { 
      rarity: 'Epic', 
      color: 'text-purple-400', 
      icon: <Star className="w-4 h-4" /> 
    }
    if (mintAmount <= 100) return { 
      rarity: 'Rare', 
      color: 'text-blue-400', 
      icon: <Medal className="w-4 h-4" /> 
    }
    return { 
      rarity: 'Common', 
      color: 'text-gray-400', 
      icon: <Coins className="w-4 h-4" /> 
    }
  }

  const estimateGasFees = (): number => {
    return blockchain === 'base' ? 0.002 : 0.015
  }

  const calculateTotalCost = (): number => {
    return estimateGasFees() + 0.01 // Platform fee
  }

  const handleMint = async (): Promise<void> => {
    setIsLoading(true)
    
    try {
      const response = await fetch('/api/nft/mint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          songId: song.id,
          mintAmount,
          mintPrice,
          royaltyPercentage: royaltyPercentage[0],
          description,
          blockchain,
          metadata: {
            title: song.title,
            artist: song.artist,
            genre: song.genre,
            duration: song.duration,
            coverArt: song.coverArt,
            inspirations: song.inspirations || []
          }
        })
      })

      if (response.ok) {
        const data = await response.json()
        toast.success(`Successfully minted ${mintAmount} NFTs for "${song.title}"!`)
        toast.info(`Transaction hash: ${data.txHash}`)
        onClose()
      } else {
        const error = await response.json()
        toast.error(`Minting failed: ${error.message}`)
      }
    } catch (error) {
      toast.error('Network error. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  const rarityInfo = calculateRarity()

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Zap className="w-5 h-5 text-purple-400" />
            Mint Music NFT
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Transform your creation into a collectible NFT on the blockchain
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Song Preview */}
          <div className="flex items-center gap-4 p-4 bg-gray-800/50 rounded-lg">
            <img
              src={song.coverArt}
              alt={song.title}
              className="w-16 h-16 rounded-lg object-cover"
            />
            <div className="flex-1">
              <h3 className="font-semibold">{song.title}</h3>
              <p className="text-gray-400 text-sm">{song.artist}</p>
              <div className="flex gap-1 mt-1">
                {song.genre.map((g) => (
                  <Badge key={g} variant="secondary" className="text-xs">
                    {g}
                  </Badge>
                ))}
              </div>
            </div>
            <div className={`flex items-center gap-2 ${rarityInfo.color}`}>
              {rarityInfo.icon}
              <span className="font-semibold">{rarityInfo.rarity}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Left Column */}
            <div className="space-y-4">
              {/* Mint Amount */}
              <div>
                <Label htmlFor="mintAmount" className="text-sm font-medium">
                  Total Supply
                </Label>
                <Input
                  id="mintAmount"
                  type="number"
                  value={mintAmount}
                  onChange={(e) => setMintAmount(parseInt(e.target.value) || 1)}
                  min={1}
                  max={1000}
                  className="bg-gray-800 border-gray-600 mt-1"
                />
                <p className="text-xs text-gray-400 mt-1">
                  Lower supply = Higher rarity = Higher value potential
                </p>
              </div>

              {/* Mint Price */}
              <div>
                <Label htmlFor="mintPrice" className="text-sm font-medium">
                  Initial Price (FAIR)
                </Label>
                <Input
                  id="mintPrice"
                  type="number"
                  step="0.001"
                  value={mintPrice}
                  onChange={(e) => setMintPrice(parseFloat(e.target.value) || 0)}
                  min={0.001}
                  className="bg-gray-800 border-gray-600 mt-1"
                />
                <p className="text-xs text-gray-400 mt-1">
                  Recommended: {mintAmount <= 10 ? '0.1-0.5' : mintAmount <= 100 ? '0.05-0.15' : '0.01-0.05'} ETH
                </p>
              </div>

              {/* Blockchain */}
              <div>
                <Label className="text-sm font-medium mb-2 block">
                  Blockchain
                </Label>
                <Select value={blockchain} onValueChange={(value) => setBlockchain(value as any)}>
                  <SelectTrigger className="bg-gray-800 border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="base">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-blue-500 rounded-full" />
                        Base (Recommended)
                      </div>
                    </SelectItem>
                    <SelectItem value="ethereum">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-gray-400 rounded-full" />
                        Ethereum
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-400 mt-1">
                  Base: Lower fees, faster transactions. Ethereum: Wider adoption
                </p>
              </div>
            </div>

            {/* Right Column */}
            <div className="space-y-4">
              {/* Royalty Percentage */}
              <div>
                <Label className="text-sm font-medium mb-2 block">
                  Creator Royalty: {royaltyPercentage[0]}%
                </Label>
                <Slider
                  value={royaltyPercentage}
                  onValueChange={setRoyaltyPercentage}
                  max={20}
                  min={0}
                  step={0.5}
                  className="mt-2"
                />
                <div className="flex justify-between text-xs text-gray-400 mt-1">
                  <span>0%</span>
                  <span>20%</span>
                </div>
                <p className="text-xs text-gray-400 mt-1">
                  Earn {royaltyPercentage[0]}% from every future resale
                </p>
              </div>

              {/* Cost Breakdown */}
              <div className="bg-gray-800/50 rounded-lg p-4">
                <h4 className="font-medium mb-3">Cost Breakdown</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Gas Fees:</span>
                    <span>{estimateGasFees().toFixed(4)} ETH</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Platform Fee:</span>
                    <span>0.01 ETH</span>
                  </div>
                  <hr className="border-gray-600" />
                  <div className="flex justify-between font-semibold">
                    <span>Total Cost:</span>
                    <span className="text-green-400">{calculateTotalCost().toFixed(4)} ETH</span>
                  </div>
                </div>
              </div>

              {/* Revenue Potential */}
              <div className="bg-green-900/20 border border-green-600/30 rounded-lg p-4">
                <h4 className="font-medium text-green-400 mb-2">Revenue Potential</h4>
                <div className="text-sm space-y-1">
                  <div className="flex justify-between">
                    <span className="text-gray-400">If all sell:</span>
                    <span className="text-green-400">{(mintAmount * mintPrice).toFixed(3)} ETH</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Future royalties:</span>
                    <span className="text-green-400">{royaltyPercentage[0]}% of resales</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="description" className="text-sm font-medium">
              NFT Description (Optional)
            </Label>
            <Textarea
              id="description"
              placeholder="Tell collectors about your creation, inspiration, and what makes it special..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="bg-gray-800 border-gray-600 mt-1 resize-none"
              rows={3}
            />
          </div>

          {/* Warnings */}
          <div className="bg-yellow-900/20 border border-yellow-600/30 rounded-lg p-4">
            <div className="flex gap-2">
              <AlertTriangle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-yellow-400 mb-1">Important Notes:</p>
                <ul className="space-y-1 text-gray-300">
                  <li>• NFTs cannot be deleted or modified once minted</li>
                  <li>• Lower supply creates higher rarity and value potential</li>
                  <li>• You'll earn royalties from every future resale</li>
                  <li>• Base blockchain offers lower fees and faster transactions</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isLoading}>
            Cancel
          </Button>
          <Button
            onClick={handleMint}
            disabled={isLoading || mintAmount < 1 || mintPrice <= 0}
            className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700"
          >
            {isLoading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2" />
                Minting...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 mr-2" />
                Mint {mintAmount} NFT{mintAmount > 1 ? 's' : ''}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}