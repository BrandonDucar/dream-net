'use client';

import { useRef, useMemo } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { Text, useDragControls } from '@react-three/drei';
import { useSonicPrism } from '../SonicPrismProvider';
import type { Mesh, BufferGeometry, Material } from 'three';
import { Vector3 } from 'three';

interface PrismMeshProps {
  prism: {
    id: string;
    type: 'GenreShift' | 'Cleanup' | 'Harmonize' | 'Vocalize';
    position: [number, number, number];
    intensity: number;
    divergence: number;
    isActive: boolean;
    color: string;
  };
  isSelected: boolean;
}

function PrismMesh({ prism, isSelected }: PrismMeshProps) {
  const meshRef = useRef<Mesh<BufferGeometry, Material | Material[]>>(null);
  const { camera, raycaster, gl } = useThree();
  const { updatePrism, ribbons, applyPrismTransform } = useSonicPrism();
  
  // Different geometries for different prism types
  const geometry = useMemo(() => {
    switch (prism.type) {
      case 'GenreShift':
        return <octahedronGeometry args={[0.8, 0]} />;
      case 'Cleanup':
        return <tetrahedronGeometry args={[0.8, 0]} />;
      case 'Harmonize':
        return <icosahedronGeometry args={[0.8, 0]} />;
      case 'Vocalize':
        return <dodecahedronGeometry args={[0.8, 0]} />;
      default:
        return <boxGeometry args={[1, 1, 1]} />;
    }
  }, [prism.type]);
  
  // Animation and effects
  useFrame((state) => {
    if (!meshRef.current) return;
    
    const time = state.clock.elapsedTime;
    
    // Rotation based on type
    meshRef.current.rotation.x = time * 0.3 * prism.intensity;
    meshRef.current.rotation.y = time * 0.5 * prism.intensity;
    
    // Pulsing based on activity
    if (prism.isActive) {
      const pulse = 1 + Math.sin(time * 8) * 0.3;
      meshRef.current.scale.setScalar(pulse);
    } else {
      const baseScale = 1 + prism.intensity * 0.2;
      meshRef.current.scale.setScalar(baseScale);
    }
    
    // Selection highlight
    if (isSelected) {
      meshRef.current.scale.multiplyScalar(1.3);
    }
  });
  
  // Handle drag and drop
  const handlePointerDown = (event: any) => {
    event.stopPropagation();
    
    // Select this prism
    const store = useSonicPrism.getState();
    store.selectPrism(prism.id);
    
    // Check for ribbon collision on release
    const checkCollision = () => {
      if (!meshRef.current) return;
      
      const prismPosition = new Vector3().setFromMatrixPosition(meshRef.current.matrixWorld);
      
      // Check collision with ribbons
      ribbons.forEach(ribbon => {
        const ribbonPosition = new Vector3(...ribbon.position);
        const distance = prismPosition.distanceTo(ribbonPosition);
        
        if (distance < 2) {
          // Collision detected - apply transformation
          applyPrismTransform(prism.id, ribbon.id);
          
          // Visual feedback
          if (meshRef.current) {
            meshRef.current.scale.setScalar(1.5);
          }
        }
      });
    };
    
    // Add temporary listener for pointer up
    const handlePointerUp = () => {
      checkCollision();
      gl.domElement.removeEventListener('pointerup', handlePointerUp);
    };
    
    gl.domElement.addEventListener('pointerup', handlePointerUp);
  };
  
  // Style Dial interaction for intensity control
  const handleWheel = (event: any) => {
    event.stopPropagation();
    const newIntensity = Math.max(0, Math.min(1, prism.intensity + event.deltaY * -0.001));
    updatePrism(prism.id, { intensity: newIntensity });
  };
  
  return (
    <group>
      <mesh
        ref={meshRef}
        position={prism.position}
        onPointerDown={handlePointerDown}
        onWheel={handleWheel}
      >
        {geometry}
        <meshStandardMaterial
          color={prism.color}
          emissive={prism.color}
          emissiveIntensity={prism.isActive ? 0.8 : 0.3}
          transparent
          opacity={0.7 + prism.intensity * 0.3}
          metalness={0.8}
          roughness={0.1}
        />
      </mesh>
      
      {/* Prism type label */}
      <Text
        position={[prism.position[0], prism.position[1] + 1.5, prism.position[2]]}
        fontSize={0.25}
        color={prism.color}
        anchorX="center"
        anchorY="middle"
        outlineWidth={0.02}
        outlineColor="#000000"
      >
        {prism.type}
      </Text>
      
      {/* Intensity indicator ring */}
      <mesh 
        position={prism.position}
        rotation-x={Math.PI / 2}
      >
        <ringGeometry args={[1.2, 1.4, 16]} />
        <meshStandardMaterial
          color={prism.color}
          transparent
          opacity={prism.intensity * 0.5}
          emissive={prism.color}
          emissiveIntensity={prism.intensity * 0.3}
        />
      </mesh>
      
      {/* Activity particles when processing */}
      {prism.isActive && (
        <points position={prism.position}>
          <bufferGeometry>
            <bufferAttribute
              attach="attributes-position"
              array={new Float32Array(Array.from({ length: 50 }, () => [
                (Math.random() - 0.5) * 3,
                (Math.random() - 0.5) * 3,
                (Math.random() - 0.5) * 3
              ]).flat())}
              count={50}
              itemSize={3}
            />
          </bufferGeometry>
          <pointsMaterial
            color={prism.color}
            size={0.05}
            transparent
            opacity={0.8}
          />
        </points>
      )}
    </group>
  );
}

export function AIPrisms() {
  const { prisms, selectedPrismId } = useSonicPrism();
  
  return (
    <group>
      {prisms.map((prism) => (
        <PrismMesh
          key={prism.id}
          prism={prism}
          isSelected={selectedPrismId === prism.id}
        />
      ))}
    </group>
  );
}