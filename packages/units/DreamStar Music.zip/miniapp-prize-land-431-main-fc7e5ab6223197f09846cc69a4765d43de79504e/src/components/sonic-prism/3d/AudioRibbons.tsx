'use client';

import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useSonicPrism } from '../SonicPrismProvider';
import { Text } from '@react-three/drei';
import type { Mesh, BufferGeometry, Material, Vector3 } from 'three';
import { CatmullRomCurve3, Vector3 as ThreeVector3, TubeGeometry } from 'three';

interface RibbonMeshProps {
  ribbon: {
    id: string;
    name: string;
    position: [number, number, number];
    color: string;
    energy: number;
    isPlaying: boolean;
    volume: number;
    roughness: number;
    bpm: number;
  };
  isSelected: boolean;
}

function RibbonMesh({ ribbon, isSelected }: RibbonMeshProps) {
  const meshRef = useRef<Mesh<BufferGeometry, Material | Material[]>>(null);
  const { audioFeatures } = useSonicPrism();
  
  // Create flowing ribbon geometry
  const { geometry, curve } = useMemo(() => {
    const points: ThreeVector3[] = [];
    const [x, y, z] = ribbon.position;
    
    // Generate flowing curve points based on ribbon properties
    for (let i = 0; i <= 20; i++) {
      const t = i / 20;
      const flowX = x + Math.sin(t * Math.PI * 2) * (2 + ribbon.roughness);
      const flowY = y + Math.sin(t * Math.PI * 4 + Date.now() * 0.001) * (0.5 + ribbon.energy);
      const flowZ = z + t * 8 - 4;
      points.push(new ThreeVector3(flowX, flowY, flowZ));
    }
    
    const curve = new CatmullRomCurve3(points);
    const geometry = new TubeGeometry(
      curve, 
      64, // tubular segments
      0.1 + ribbon.volume * 0.2, // radius based on volume
      8, // radial segments
      false // not closed
    );
    
    return { geometry, curve };
  }, [ribbon.position, ribbon.roughness, ribbon.energy, ribbon.volume]);
  
  // Animate ribbon flow and pulsing
  useFrame((state) => {
    if (!meshRef.current) return;
    
    const time = state.clock.elapsedTime;
    
    // Pulsing based on audio energy and BPM
    const bpmPulse = Math.sin(time * (ribbon.bpm / 60) * Math.PI) * 0.1 + 1;
    const energyPulse = 1 + audioFeatures.energy * 0.3;
    const scale = bpmPulse * energyPulse;
    
    meshRef.current.scale.setScalar(scale);
    
    // Flowing animation
    if (ribbon.isPlaying) {
      meshRef.current.rotation.z = time * 0.2;
      
      // Additional glow when playing
      const material = meshRef.current.material as any;
      if (material.emissiveIntensity !== undefined) {
        material.emissiveIntensity = 0.5 + Math.sin(time * 4) * 0.2;
      }
    }
    
    // Selection highlight
    if (isSelected) {
      meshRef.current.scale.multiplyScalar(1.2);
      const material = meshRef.current.material as any;
      if (material.emissiveIntensity !== undefined) {
        material.emissiveIntensity = Math.max(material.emissiveIntensity || 0, 0.8);
      }
    }
  });
  
  return (
    <group>
      <mesh 
        ref={meshRef} 
        geometry={geometry}
        position={ribbon.position}
        onClick={() => {
          // Handle ribbon selection
          const store = useSonicPrism.getState();
          store.selectRibbon(ribbon.id);
        }}
      >
        <meshStandardMaterial
          color={ribbon.color}
          emissive={ribbon.color}
          emissiveIntensity={ribbon.isPlaying ? 0.4 : 0.2}
          transparent
          opacity={0.8 + ribbon.volume * 0.2}
          metalness={0.1}
          roughness={0.2}
        />
      </mesh>
      
      {/* Floating label */}
      <Text
        position={[ribbon.position[0], ribbon.position[1] + 1.5, ribbon.position[2]]}
        fontSize={0.3}
        color={ribbon.color}
        anchorX="center"
        anchorY="middle"
        outlineWidth={0.02}
        outlineColor="#000000"
      >
        {ribbon.name}
      </Text>
      
      {/* Audio visualization particles */}
      {ribbon.isPlaying && audioFeatures.spectralData && (
        <points position={ribbon.position}>
          <bufferGeometry>
            <bufferAttribute
              attach="attributes-position"
              array={new Float32Array(audioFeatures.spectralData.length * 3)}
              count={audioFeatures.spectralData.length}
              itemSize={3}
            />
          </bufferGeometry>
          <pointsMaterial 
            color={ribbon.color}
            size={0.05}
            transparent
            opacity={0.6}
          />
        </points>
      )}
    </group>
  );
}

export function AudioRibbons() {
  const { ribbons, selectedRibbonId } = useSonicPrism();
  
  return (
    <group>
      {ribbons.map((ribbon) => (
        <RibbonMesh
          key={ribbon.id}
          ribbon={ribbon}
          isSelected={selectedRibbonId === ribbon.id}
        />
      ))}
    </group>
  );
}