'use client';

import { useMemo } from 'react';
import { EffectComposer, Bloom, ChromaticAberration, Vignette } from '@react-three/postprocessing';
import { BlendFunction } from 'postprocessing';
import { useSonicPrism } from '../SonicPrismProvider';
import { Vector2 } from 'three';

export function HolographicEffects() {
  const { audioFeatures, isPlaying } = useSonicPrism();
  
  // Dynamic effect parameters based on audio
  const effectParams = useMemo(() => {
    const baseIntensity = isPlaying ? 0.3 : 0.1;
    const audioMultiplier = 1 + audioFeatures.energy * 0.5;
    
    return {
      bloomIntensity: baseIntensity * audioMultiplier,
      chromaticAberration: new Vector2(0.001 * audioMultiplier, 0.001 * audioMultiplier),
      vignetteIntensity: 0.3 + audioFeatures.energy * 0.2
    };
  }, [audioFeatures.energy, isPlaying]);
  
  return (
    <EffectComposer>
      {/* Bloom effect for holographic glow */}
      <Bloom
        intensity={effectParams.bloomIntensity}
        kernelSize={3}
        luminanceThreshold={0.1}
        luminanceSmoothing={0.9}
        mipmapBlur={true}
        blendFunction={BlendFunction.SCREEN}
      />
      
      {/* Chromatic aberration for holographic distortion */}
      <ChromaticAberration
        blendFunction={BlendFunction.NORMAL}
        offset={effectParams.chromaticAberration}
        radialModulation={false}
        modulationOffset={0.15}
      />
      
      {/* Vignette for atmospheric depth */}
      <Vignette
        blendFunction={BlendFunction.MULTIPLY}
        darkness={effectParams.vignetteIntensity}
        eskil={false}
      />
    </EffectComposer>
  );
}