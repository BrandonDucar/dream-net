'use client';

import { useRef, useState, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { OrbitControls, Environment, Text } from '@react-three/drei';
import { AudioRibbons } from './AudioRibbons';
import { AIPrisms } from './AIPrisms';
import { HolographicEffects } from './HolographicEffects';
import { useSonicPrism } from '../SonicPrismProvider';
import type { Group } from 'three';

// Demo content component for when no music is loaded
function DemoHolographicContent() {
  const demoRef = useRef<Group>(null);
  
  useFrame((state) => {
    if (!demoRef.current) return;
    
    const time = state.clock.elapsedTime;
    demoRef.current.rotation.y = time * 0.1;
    
    // Pulse the entire demo scene
    const pulse = 1 + Math.sin(time * 2) * 0.1;
    demoRef.current.scale.setScalar(pulse);
  });

  return (
    <group ref={demoRef}>
      {/* Demo Audio Ribbons */}
      <group position={[-2, 1, 0]}>
        <mesh>
          <tubeGeometry args={[
            // Create a simple curve
            (() => {
              const { CatmullRomCurve3, Vector3 } = require('three');
              return new CatmullRomCurve3([
                new Vector3(-2, 0, -2),
                new Vector3(-1, 0.5, 0),
                new Vector3(0, 0, 2),
                new Vector3(2, -0.5, 0)
              ]);
            })(),
            64, 0.15, 8, false
          ]} />
          <meshStandardMaterial
            color="#00F0FF"
            emissive="#00F0FF"
            emissiveIntensity={0.3}
            transparent
            opacity={0.8}
            metalness={0.1}
            roughness={0.2}
          />
        </mesh>
        <Text
          position={[0, 1.5, 0]}
          fontSize={0.3}
          color="#00F0FF"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.02}
          outlineColor="#000000"
        >
          Cosmic Journey
        </Text>
      </group>

      {/* Demo Audio Ribbon 2 */}
      <group position={[2, 1, 0]}>
        <mesh>
          <tubeGeometry args={[
            (() => {
              const { CatmullRomCurve3, Vector3 } = require('three');
              return new CatmullRomCurve3([
                new Vector3(-1, 0, -1),
                new Vector3(0, 1, 0),
                new Vector3(1, 0, 1),
                new Vector3(0, -0.5, 0)
              ]);
            })(),
            64, 0.12, 8, false
          ]} />
          <meshStandardMaterial
            color="#FF6B35"
            emissive="#FF6B35"
            emissiveIntensity={0.3}
            transparent
            opacity={0.8}
            metalness={0.1}
            roughness={0.2}
          />
        </mesh>
        <Text
          position={[0, 1.5, 0]}
          fontSize={0.3}
          color="#FF6B35"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.02}
          outlineColor="#000000"
        >
          Urban Fusion
        </Text>
      </group>

      {/* Demo AI Prisms */}
      <group position={[-1.5, 2.5, 0]}>
        <mesh>
          <octahedronGeometry args={[0.6, 0]} />
          <meshStandardMaterial
            color="#8A2BE2"
            emissive="#8A2BE2"
            emissiveIntensity={0.4}
            transparent
            opacity={0.7}
            metalness={0.8}
            roughness={0.1}
          />
        </mesh>
        <Text
          position={[0, 1.2, 0]}
          fontSize={0.25}
          color="#8A2BE2"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.02}
          outlineColor="#000000"
        >
          Genre Shift
        </Text>
      </group>

      <group position={[1.5, 2.5, 0]}>
        <mesh>
          <icosahedronGeometry args={[0.6, 0]} />
          <meshStandardMaterial
            color="#FFD700"
            emissive="#FFD700"
            emissiveIntensity={0.4}
            transparent
            opacity={0.7}
            metalness={0.8}
            roughness={0.1}
          />
        </mesh>
        <Text
          position={[0, 1.2, 0]}
          fontSize={0.25}
          color="#FFD700"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.02}
          outlineColor="#000000"
        >
          Harmonize
        </Text>
      </group>

      {/* Floating particles */}
      <points>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            array={new Float32Array(Array.from({ length: 100 }, () => [
              (Math.random() - 0.5) * 20,
              (Math.random() - 0.5) * 10 + 3,
              (Math.random() - 0.5) * 20
            ]).flat())}
            count={100}
            itemSize={3}
          />
        </bufferGeometry>
        <pointsMaterial
          color="#ffffff"
          size={0.03}
          transparent
          opacity={0.4}
        />
      </points>

      {/* Central instruction text */}
      <Text
        position={[0, -1, 0]}
        fontSize={0.4}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
        outlineWidth={0.02}
        outlineColor="#000000"
        maxWidth={8}
        textAlign="center"
      >
        Demo Holographic View
        {'\n'}
        Create music to see your tracks here as interactive 3D ribbons
      </Text>
    </group>
  );
}

export function HolographicScene() {
  const sceneRef = useRef<Group>(null);
  const { audioFeatures, ribbons, prisms } = useSonicPrism();
  const [showDemo, setShowDemo] = useState(true);
  
  // Hide demo when user has actual content
  useEffect(() => {
    if (ribbons.length > 0) {
      setShowDemo(false);
    } else {
      setShowDemo(true);
    }
  }, [ribbons.length]);
  
  // Reactive scene scaling based on audio energy
  useFrame(() => {
    if (sceneRef.current && audioFeatures.energy > 0) {
      const scale = 1 + audioFeatures.energy * 0.1;
      sceneRef.current.scale.setScalar(scale);
    }
  });

  return (
    <>
      {/* Camera Controls - smooth orbit for holographic navigation */}
      <OrbitControls
        enablePan={true}
        enableZoom={true}
        enableRotate={true}
        maxDistance={20}
        minDistance={3}
        maxPolarAngle={Math.PI * 0.8}
        minPolarAngle={Math.PI * 0.2}
        dampingFactor={0.1}
        enableDamping={true}
      />
      
      {/* Holographic Lighting Setup */}
      <ambientLight intensity={0.2} color="#001122" />
      
      {/* Main directional light with subtle cyan tint */}
      <directionalLight 
        position={[10, 10, 5]} 
        intensity={0.8} 
        color="#004488"
        castShadow
        shadow-mapSize={[1024, 1024]}
        shadow-bias={-0.0001}
      />
      
      {/* Accent lights for holographic effect */}
      <pointLight position={[-5, 3, -5]} intensity={0.3} color="#FF00AA" />
      <pointLight position={[5, 3, 5]} intensity={0.3} color="#00F0FF" />
      
      {/* Environment with dark sci-fi atmosphere */}
      <Environment preset="city" backgroundIntensity={0.1} />
      
      {/* Main Scene Group */}
      <group ref={sceneRef}>
        {/* Show demo content or actual user content */}
        {showDemo ? (
          <DemoHolographicContent />
        ) : (
          <>
            {/* Audio Ribbons - floating luminescent tracks */}
            <AudioRibbons />
            
            {/* AI Prisms - crystalline transformation tools */}
            <AIPrisms />
          </>
        )}
        
        {/* Holographic Grid Floor */}
        <mesh rotation-x={-Math.PI / 2} position={[0, -0.1, 0]} receiveShadow>
          <planeGeometry args={[100, 100, 50, 50]} />
          <meshStandardMaterial 
            color="#001122"
            transparent
            opacity={0.1}
            wireframe={true}
            emissive="#002244"
            emissiveIntensity={0.2}
          />
        </mesh>
        
        {/* Central holographic platform */}
        <mesh position={[0, -0.05, 0]} receiveShadow>
          <cylinderGeometry args={[8, 8, 0.1, 32]} />
          <meshStandardMaterial 
            color="#003366" 
            transparent 
            opacity={0.3}
            emissive="#004488"
            emissiveIntensity={0.1}
          />
        </mesh>
      </group>
      
      {/* Post-processing effects for holographic glow */}
      <HolographicEffects />
    </>
  );
}