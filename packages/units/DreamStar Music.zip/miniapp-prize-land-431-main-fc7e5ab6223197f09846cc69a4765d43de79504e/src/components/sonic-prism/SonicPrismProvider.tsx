'use client';

import { createContext, useContext, useEffect, ReactNode } from 'react';
import { create } from 'zustand';
import * as Tone from 'tone';
import { useSubscriptionStore } from '@/stores/subscriptionStore';
import type { Vector3Tuple } from 'three';

// Types for our holographic music system
export interface AudioRibbon {
  id: string;
  name: string;
  audioUrl?: string;
  audioBuffer?: AudioBuffer;
  position: Vector3Tuple;
  color: string;
  energy: number; // 0-1
  bpm: number;
  key: string;
  genre: string;
  roughness: number; // 0-1, affects visual texture
  isPlaying: boolean;
  volume: number; // 0-1
  player?: Tone.Player;
}

export interface AIPrism {
  id: string;
  type: 'GenreShift' | 'Cleanup' | 'Harmonize' | 'Vocalize';
  position: Vector3Tuple;
  intensity: number; // 0-1
  divergence: number; // 0-1
  isActive: boolean;
  color: string;
  targetRibbonId?: string;
}

export interface SonicPrismState {
  // Audio ribbons (tracks)
  ribbons: AudioRibbon[];
  selectedRibbonId?: string;
  
  // AI Prisms (transformers)
  prisms: AIPrism[];
  selectedPrismId?: string;
  
  // Playback state
  isPlaying: boolean;
  masterVolume: number;
  
  // UI state
  isRecording: boolean;
  showGhostTracks: boolean;
  currentMode: 'create' | 'jam' | 'export';
  
  // Audio analysis
  audioFeatures: {
    rms: number;
    spectralData: Float32Array | null;
    bpm: number;
    energy: number;
  };
  
  // Actions
  addRibbon: (ribbon: Omit<AudioRibbon, 'id'>) => void;
  updateRibbon: (id: string, updates: Partial<AudioRibbon>) => void;
  removeRibbon: (id: string) => void;
  selectRibbon: (id?: string) => void;
  
  addPrism: (prism: Omit<AIPrism, 'id'>) => void;
  updatePrism: (id: string, updates: Partial<AIPrism>) => void;
  removePrism: (id: string) => void;
  selectPrism: (id?: string) => void;
  
  setPlaying: (playing: boolean) => void;
  setMasterVolume: (volume: number) => void;
  updateAudioFeatures: (features: Partial<SonicPrismState['audioFeatures']>) => void;
  
  // AI actions
  generateMusic: (prompt: string) => Promise<void>;
  generateVocals: (text: string, voiceId: string) => Promise<void>;
  applyPrismTransform: (prismId: string, ribbonId: string) => Promise<void>;
}

const useSonicPrismStore = create<SonicPrismState>((set, get) => ({
  // Initial state
  ribbons: [],
  prisms: [],
  isPlaying: false,
  masterVolume: 0.7,
  isRecording: false,
  showGhostTracks: true,
  currentMode: 'create',
  audioFeatures: {
    rms: 0,
    spectralData: null,
    bpm: 120,
    energy: 0,
  },
  
  // Ribbon actions
  addRibbon: (ribbon) => {
    const subscription = useSubscriptionStore.getState();
    
    // Check if user can store more tracks
    if (!subscription.canStoreTrack()) {
      throw new Error('Track storage limit reached. Upgrade your plan to store more tracks.');
    }

    set((state) => ({
      ribbons: [...state.ribbons, { ...ribbon, id: `ribbon_${Date.now()}_${Math.random()}` }]
    }));

    // Update usage
    subscription.updateUsage({
      tracksStored: subscription.usage.tracksStored + 1
    });
  },
  
  updateRibbon: (id, updates) => set((state) => ({
    ribbons: state.ribbons.map(r => r.id === id ? { ...r, ...updates } : r)
  })),
  
  removeRibbon: (id) => set((state) => {
    const ribbon = state.ribbons.find(r => r.id === id);
    if (ribbon?.player) {
      ribbon.player.dispose();
    }
    return {
      ribbons: state.ribbons.filter(r => r.id !== id),
      selectedRibbonId: state.selectedRibbonId === id ? undefined : state.selectedRibbonId
    };
  }),
  
  selectRibbon: (id) => set({ selectedRibbonId: id }),
  
  // Prism actions
  addPrism: (prism) => set((state) => ({
    prisms: [...state.prisms, { ...prism, id: `prism_${Date.now()}_${Math.random()}` }]
  })),
  
  updatePrism: (id, updates) => set((state) => ({
    prisms: state.prisms.map(p => p.id === id ? { ...p, ...updates } : p)
  })),
  
  removePrism: (id) => set((state) => ({
    prisms: state.prisms.filter(p => p.id !== id),
    selectedPrismId: state.selectedPrismId === id ? undefined : state.selectedPrismId
  })),
  
  selectPrism: (id) => set({ selectedPrismId: id }),
  
  // Playback actions
  setPlaying: (playing) => {
    const { ribbons } = get();
    if (playing) {
      Tone.start();
      ribbons.forEach(ribbon => {
        if (ribbon.player && ribbon.isPlaying) {
          ribbon.player.start();
        }
      });
    } else {
      ribbons.forEach(ribbon => {
        if (ribbon.player) {
          ribbon.player.stop();
        }
      });
    }
    set({ isPlaying: playing });
  },
  
  setMasterVolume: (volume) => {
    Tone.getDestination().volume.value = Tone.gainToDb(volume);
    set({ masterVolume: volume });
  },
  
  updateAudioFeatures: (features) => set((state) => ({
    audioFeatures: { ...state.audioFeatures, ...features }
  })),
  
  // AI Actions
  generateMusic: async (prompt) => {
    const subscription = useSubscriptionStore.getState();
    
    // Check if user can generate music
    if (!subscription.canGenerateMusic()) {
      throw new Error('Music generation limit reached. Upgrade your plan to continue.');
    }

    try {
      const { lyria2Submit, lyria2PollStatus, lyria2FetchAudioUrl } = await import('../../lyria2-api');
      
      const requestId = await lyria2Submit({
        prompt,
        negative_prompt: 'vocals, talking, speech'
      });
      
      await lyria2PollStatus(requestId);
      const audioUrl = await lyria2FetchAudioUrl(requestId);
      
      // Create audio ribbon from generated music
      const ribbon: Omit<AudioRibbon, 'id'> = {
        name: `AI: ${prompt.slice(0, 30)}...`,
        audioUrl,
        position: [Math.random() * 10 - 5, 0, Math.random() * 10 - 5],
        color: '#00F0FF',
        energy: 0.7,
        bpm: 120,
        key: 'C',
        genre: 'AI Generated',
        roughness: 0.3,
        isPlaying: false,
        volume: 0.8
      };
      
      get().addRibbon(ribbon);
      
      // Update usage
      subscription.updateUsage({
        musicGenerationsUsed: subscription.usage.musicGenerationsUsed + 1
      });
    } catch (error) {
      console.error('Music generation failed:', error);
      throw error;
    }
  },
  
  generateVocals: async (text, voiceId) => {
    const subscription = useSubscriptionStore.getState();
    
    // Check if user can generate vocals
    if (!subscription.canGenerateVocals()) {
      throw new Error('Vocal generation limit reached. Upgrade your plan to continue.');
    }

    try {
      const { ttsFalSubmit, ttsFalPollStatus, ttsFalFetchAudioUrl } = await import('../../elevenlabs-api');
      
      const requestId = await ttsFalSubmit({
        text,
        voice: voiceId,
        stability: 0.5,
        similarity_boost: 0.8,
        style: 0.3
      });
      
      await ttsFalPollStatus(requestId);
      const audioUrl = await ttsFalFetchAudioUrl(requestId);
      
      // Create vocal ribbon
      const ribbon: Omit<AudioRibbon, 'id'> = {
        name: `Vocals: ${text.slice(0, 20)}...`,
        audioUrl,
        position: [0, 2, 0],
        color: '#FF00AA',
        energy: 0.6,
        bpm: 120,
        key: 'C',
        genre: 'Vocal',
        roughness: 0.1,
        isPlaying: false,
        volume: 0.9
      };
      
      get().addRibbon(ribbon);
      
      // Update usage
      subscription.updateUsage({
        vocalGenerationsUsed: subscription.usage.vocalGenerationsUsed + 1
      });
    } catch (error) {
      console.error('Vocal generation failed:', error);
      throw error;
    }
  },
  
  applyPrismTransform: async (prismId, ribbonId) => {
    const subscription = useSubscriptionStore.getState();
    
    // Check if user can use AI transforms
    if (!subscription.canTransformAudio()) {
      throw new Error('AI transform limit reached. Upgrade your plan to continue.');
    }

    const { prisms, ribbons } = get();
    const prism = prisms.find(p => p.id === prismId);
    const ribbon = ribbons.find(r => r.id === ribbonId);
    
    if (!prism || !ribbon) return;
    
    // Update prism to show it's processing
    get().updatePrism(prismId, { isActive: true });
    
    try {
      // Simulate AI transformation based on prism type
      let transformPrompt = '';
      switch (prism.type) {
        case 'GenreShift':
          transformPrompt = `Transform this ${ribbon.genre} track into electronic dance music with pulsing bass`;
          break;
        case 'Cleanup':
          transformPrompt = `Clean and enhance this audio track with professional mastering`;
          break;
        case 'Harmonize':
          transformPrompt = `Add harmonies and layers to this ${ribbon.key} key track`;
          break;
        case 'Vocalize':
          transformPrompt = `Add melodic vocals to this instrumental track`;
          break;
      }
      
      await get().generateMusic(transformPrompt);
      
      // Update usage
      subscription.updateUsage({
        aiTransformsUsed: subscription.usage.aiTransformsUsed + 1
      });
    } catch (error) {
      console.error('Prism transform failed:', error);
      throw error;
    } finally {
      get().updatePrism(prismId, { isActive: false });
    }
  }
}));

const SonicPrismContext = createContext<typeof useSonicPrismStore | null>(null);

interface SonicPrismProviderProps {
  children: ReactNode;
}

export function SonicPrismProvider({ children }: SonicPrismProviderProps) {
  useEffect(() => {
    // Initialize Tone.js
    const initAudio = async () => {
      if (Tone.context.state !== 'running') {
        await Tone.start();
      }
      
      // Set up master volume
      Tone.getDestination().volume.value = Tone.gainToDb(0.7);
      
      // Add some demo content
      const store = useSonicPrismStore.getState();
      
      // Add default prisms
      store.addPrism({
        type: 'GenreShift',
        position: [-3, 0, -2],
        intensity: 0.5,
        divergence: 0.7,
        isActive: false,
        color: '#FF6B35'
      });
      
      store.addPrism({
        type: 'Vocalize',
        position: [3, 0, -2],
        intensity: 0.4,
        divergence: 0.3,
        isActive: false,
        color: '#00D4AA'
      });
    };
    
    initAudio();
    
    // Cleanup on unmount
    return () => {
      const state = useSonicPrismStore.getState();
      state.ribbons.forEach(ribbon => {
        if (ribbon.player) {
          ribbon.player.dispose();
        }
      });
    };
  }, []);

  return (
    <SonicPrismContext.Provider value={useSonicPrismStore}>
      {children}
    </SonicPrismContext.Provider>
  );
}

export function useSonicPrism() {
  const context = useContext(SonicPrismContext);
  if (!context) {
    throw new Error('useSonicPrism must be used within SonicPrismProvider');
  }
  return context();
}