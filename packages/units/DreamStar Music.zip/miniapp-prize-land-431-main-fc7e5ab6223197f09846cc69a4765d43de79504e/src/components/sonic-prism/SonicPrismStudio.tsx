'use client';

import { Canvas } from '@react-three/fiber';
import { Suspense, useState, useEffect } from 'react';
import { HolographicScene } from './3d/HolographicScene';
import { AudioEngine } from './audio/AudioEngine';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { useSonicPrism } from './SonicPrismProvider';
import { useSubscriptionStore } from '@/stores/subscriptionStore';
import { 
  Play, 
  Pause, 
  Volume2, 
  Home,
  Mic,
  Music,
  Sparkles,
  Wand2,
  ArrowRight,
  Download,
  Share2,
  Eye,
  EyeOff,
  RotateCcw
} from 'lucide-react';
import { Slider } from '../ui/slider';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';

export default function SonicPrismStudio() {
  const [currentStep, setCurrentStep] = useState<'create' | 'visualize'>('create');
  const [showVisualization, setShowVisualization] = useState(false);
  const [musicPrompt, setMusicPrompt] = useState('');
  const [vocalText, setVocalText] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('electronic');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedTracks, setGeneratedTracks] = useState<Array<{
    id: string;
    title: string;
    genre: string;
    duration: string;
    prompt: string;
    url?: string;
  }>>([]);

  const {
    isPlaying,
    masterVolume,
    ribbons,
    prisms,
    setPlaying,
    setMasterVolume,
    generateMusic,
    generateVocals,
    addPrism
  } = useSonicPrism();

  const { currentTier, getRemainingUsage } = useSubscriptionStore();

  // Demo sample tracks for new users
  useEffect(() => {
    if (generatedTracks.length === 0) {
      setGeneratedTracks([
        {
          id: 'demo1',
          title: 'Cosmic Journey',
          genre: 'Electronic',
          duration: '3:24',
          prompt: 'Ambient electronic music with cosmic synthesizers',
        },
        {
          id: 'demo2', 
          title: 'Urban Fusion',
          genre: 'Hip Hop',
          duration: '2:48',
          prompt: 'Hip hop beat with jazz influences and urban atmosphere',
        }
      ]);
    }
  }, [generatedTracks.length]);

  const handleGenerateMusic = async () => {
    if (!musicPrompt.trim()) return;
    
    setIsGenerating(true);
    try {
      // Call the REAL AI music generation
      await generateMusic(musicPrompt);
      
      // Add to our local tracks list after successful generation
      const newTrack = {
        id: Date.now().toString(),
        title: musicPrompt.slice(0, 30) + '...',
        genre: selectedGenre.charAt(0).toUpperCase() + selectedGenre.slice(1),
        duration: '3:12',
        prompt: musicPrompt,
      };
      
      setGeneratedTracks(prev => [newTrack, ...prev]);
      setMusicPrompt('');
      
      // Auto-switch to visualization after successful generation
      setTimeout(() => {
        setCurrentStep('visualize');
        setShowVisualization(true);
      }, 1000);
      
    } catch (error) {
      console.error('Failed to generate music:', error);
      // Show user-friendly error message
      alert(`Music generation failed: ${error.message}`);
    }
    setIsGenerating(false);
  };

  const handleGenerateVocals = async () => {
    if (!vocalText.trim()) return;
    
    setIsGenerating(true);
    try {
      await generateVocals(vocalText, 'Rachel');
      setVocalText('');
    } catch (error) {
      console.error('Failed to generate vocals:', error);
    }
    setIsGenerating(false);
  };

  const playTrack = (track: typeof generatedTracks[0]) => {
    // Find the corresponding ribbon if it exists
    const ribbon = ribbons.find(r => r.name.includes(track.prompt.slice(0, 10)));
    
    if (ribbon && ribbon.player) {
      // Play the actual audio if available
      setPlaying(true);
    } else {
      // Add visual elements for demo tracks
      addPrism({
        type: 'GenreShift',
        position: [Math.random() * 4 - 2, 1 + Math.random() * 2, Math.random() * 4 - 2],
        intensity: 0.7,
        divergence: 0.5,
        isActive: false,
        color: '#FF6B35'
      });
    }
    
    setShowVisualization(true);
    setCurrentStep('visualize');
  };

  if (currentStep === 'create') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 p-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button
            onClick={() => window.location.href = '/'}
            className="bg-black/40 hover:bg-black/60 border border-white/30 text-white backdrop-blur-md"
            size="sm"
          >
            <Home className="w-4 h-4 mr-2" />
            Home
          </Button>

          <Card className="bg-black/40 backdrop-blur-md border border-white/30 px-6 py-3">
            <h1 className="text-xl font-bold">
              <span className="bg-gradient-to-r from-cyan-400 to-pink-400 bg-clip-text text-transparent">
                SONIC PRISM STUDIO
              </span>
            </h1>
          </Card>

          <Button
            onClick={() => {
              if (generatedTracks.length > 0) {
                setCurrentStep('visualize');
                setShowVisualization(true);
              }
            }}
            disabled={generatedTracks.length === 0}
            className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white"
            size="sm"
          >
            <Eye className="w-4 h-4 mr-2" />
            Visualize
          </Button>
        </div>

        {/* Step 1: Create Music */}
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-white mb-2">Create Your Music</h2>
            <p className="text-gray-300">Generate original tracks with AI, then visualize them in holographic 3D space</p>
          </div>

          {/* Music Creation Form */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {/* Music Generator */}
            <Card className="bg-black/40 backdrop-blur-md border border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Music className="w-5 h-5 text-cyan-400" />
                  Generate Music Track
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm text-white/80 mb-2 block">Genre</label>
                  <select 
                    value={selectedGenre}
                    onChange={(e) => setSelectedGenre(e.target.value)}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-cyan-500"
                  >
                    <option value="electronic">Electronic</option>
                    <option value="rock">Rock</option>
                    <option value="jazz">Jazz</option>
                    <option value="country">Country</option>
                    <option value="hip_hop">Hip Hop</option>
                    <option value="latin">Latin</option>
                    <option value="indie">Indie</option>
                    <option value="classical">Classical</option>
                  </select>
                </div>

                <div>
                  <label className="text-sm text-white/80 mb-2 block">Describe your music</label>
                  <Textarea
                    value={musicPrompt}
                    onChange={(e) => setMusicPrompt(e.target.value)}
                    placeholder="Describe the mood, instruments, style, tempo, or feeling you want..."
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:ring-2 focus:ring-cyan-500 min-h-[100px]"
                  />
                </div>

                <Button 
                  onClick={handleGenerateMusic}
                  disabled={!musicPrompt.trim() || isGenerating}
                  className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white"
                >
                  {isGenerating ? (
                    <>
                      <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Music className="w-4 h-4 mr-2" />
                      Generate Music Track
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Vocal Generator */}
            <Card className="bg-black/40 backdrop-blur-md border border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Mic className="w-5 h-5 text-pink-400" />
                  Generate Vocals
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm text-white/80 mb-2 block">Lyrics or vocal description</label>
                  <Textarea
                    value={vocalText}
                    onChange={(e) => setVocalText(e.target.value)}
                    placeholder="Enter lyrics, or describe the vocal style you want..."
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:ring-2 focus:ring-pink-500 min-h-[100px]"
                  />
                </div>

                <Button 
                  onClick={handleGenerateVocals}
                  disabled={!vocalText.trim() || isGenerating}
                  className="w-full bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 text-white"
                >
                  {isGenerating ? (
                    <>
                      <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Mic className="w-4 h-4 mr-2" />
                      Generate Vocals
                    </>
                  )}
                </Button>

                <div className="text-xs text-white/60 space-y-1">
                  <p>• Vocals will layer on top of your music tracks</p>
                  <p>• Choose from different voice styles and emotions</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Generated Tracks List */}
          <Card className="bg-black/40 backdrop-blur-md border border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-400" />
                Your Generated Tracks
              </CardTitle>
            </CardHeader>
            <CardContent>
              {generatedTracks.length === 0 ? (
                <div className="text-center py-8">
                  <Music className="w-12 h-12 text-white/20 mx-auto mb-4" />
                  <p className="text-white/60">No tracks yet. Generate your first track above!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {generatedTracks.map((track) => (
                    <div 
                      key={track.id} 
                      className="flex items-center justify-between p-4 bg-white/5 rounded-lg hover:bg-white/10 transition-colors"
                    >
                      <div className="flex-1">
                        <h4 className="text-white font-semibold">{track.title}</h4>
                        <p className="text-white/60 text-sm">{track.genre} • {track.duration}</p>
                        <p className="text-white/40 text-xs mt-1">{track.prompt}</p>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Button
                          onClick={() => playTrack(track)}
                          size="sm"
                          className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white"
                        >
                          <Play className="w-4 h-4 mr-1" />
                          Visualize
                        </Button>
                        
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-white/20 text-white hover:bg-white/10"
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                        
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-white/20 text-white hover:bg-white/10"
                        >
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-screen overflow-hidden bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900">
      {/* Audio Processing Engine */}
      <AudioEngine />
      
      {/* 3D Holographic Canvas */}
      {showVisualization && (
        <Canvas
          camera={{ position: [0, 5, 8], fov: 60 }}
          dpr={[1, 2]}
          shadows
          className="absolute inset-0"
          gl={{ 
            antialias: true,
            alpha: true,
            powerPreference: 'high-performance'
          }}
        >
          <Suspense fallback={null}>
            <HolographicScene />
          </Suspense>
        </Canvas>
      )}
      
      {/* Top Navigation Bar */}
      <div className="absolute top-0 left-0 right-0 z-20">
        <div className="flex items-center justify-between p-4">
          {/* Left: Back to Create */}
          <Button
            onClick={() => setCurrentStep('create')}
            className="bg-black/40 hover:bg-black/60 border border-white/30 text-white backdrop-blur-md"
            size="sm"
          >
            <ArrowRight className="w-4 h-4 mr-2 rotate-180" />
            Back to Create
          </Button>

          {/* Center: Logo */}
          <Card className="bg-black/40 backdrop-blur-md border border-white/30 px-4 py-2">
            <h1 className="text-lg font-bold">
              <span className="bg-gradient-to-r from-cyan-400 to-pink-400 bg-clip-text text-transparent">
                HOLOGRAPHIC VIEW
              </span>
            </h1>
          </Card>

          {/* Right: Toggle Visualization */}
          <Button
            onClick={() => setShowVisualization(!showVisualization)}
            className="bg-black/40 hover:bg-black/60 border border-white/30 text-white backdrop-blur-md"
            size="sm"
          >
            {showVisualization ? (
              <>
                <EyeOff className="w-4 h-4 mr-2" />
                Hide 3D
              </>
            ) : (
              <>
                <Eye className="w-4 h-4 mr-2" />
                Show 3D
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Audio Controls */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 z-20">
        <Card className="bg-black/40 backdrop-blur-md border border-white/30 px-6 py-3">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => setPlaying(!isPlaying)}
              className="bg-white/10 hover:bg-white/20 border border-white/30 text-white"
              size="sm"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </Button>
            
            <div className="flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-white" />
              <Slider
                value={[masterVolume]}
                onValueChange={(value) => setMasterVolume(value[0])}
                max={1}
                step={0.01}
                className="w-32"
              />
            </div>
            
            <div className="flex items-center gap-4 text-xs text-white/80 border-l border-white/20 pl-4 ml-2">
              <span className="flex items-center gap-2">
                <Music className="w-3 h-3" />
                {ribbons.length} Audio Ribbons
              </span>
              <span className="flex items-center gap-2">
                <Sparkles className="w-3 h-3" />
                {prisms.length} AI Prisms
              </span>
              <span className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${isPlaying ? 'bg-green-400 animate-pulse' : 'bg-gray-500'}`} />
                {isPlaying ? 'Playing' : 'Stopped'}
              </span>
            </div>
          </div>
        </Card>
      </div>

      {/* Instructions */}
      {!showVisualization && (
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-10">
          <Card className="bg-black/60 backdrop-blur-md border border-white/30 p-8 max-w-md text-center">
            <Sparkles className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
            <h3 className="text-white font-semibold text-xl mb-2">Holographic Visualization</h3>
            <p className="text-white/80 mb-6">
              Your music appears as glowing ribbons of light, flowing through 3D space. 
              AI prisms transform and enhance your sound in real-time.
            </p>
            <Button
              onClick={() => setShowVisualization(true)}
              className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white"
            >
              <Eye className="w-4 h-4 mr-2" />
              Enable Holographic View
            </Button>
          </Card>
        </div>
      )}
    </div>
  );
}