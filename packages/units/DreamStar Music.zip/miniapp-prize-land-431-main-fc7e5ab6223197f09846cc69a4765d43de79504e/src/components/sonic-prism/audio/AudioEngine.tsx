'use client';

import { useEffect, useRef } from 'react';
import * as Tone from 'tone';
import { useSonicPrism } from '../SonicPrismProvider';

export function AudioEngine() {
  const { ribbons, updateAudioFeatures, masterVolume, updateRibbon } = useSonicPrism();
  const analyserRef = useRef<Tone.Analyser | null>(null);
  const meterRef = useRef<Tone.Meter | null>(null);
  const animationFrameRef = useRef<number>();
  
  useEffect(() => {
    // Initialize audio analysis
    const initAudioAnalysis = async () => {
      await Tone.start();
      
      // Create analyser for spectral data
      analyserRef.current = new Tone.Analyser('fft', 256);
      analyserRef.current.toDestination();
      
      // Create meter for RMS analysis
      meterRef.current = new Tone.Meter();
      meterRef.current.toDestination();
      
      // Start analysis loop
      const analyzeAudio = () => {
        if (analyserRef.current && meterRef.current) {
          const spectralData = analyserRef.current.getValue() as Float32Array;
          const rms = Array.isArray(meterRef.current.getValue()) 
            ? (meterRef.current.getValue() as number[])[0]
            : meterRef.current.getValue() as number;
          
          // Calculate energy from spectral data
          const energy = spectralData.reduce((sum, val) => sum + Math.abs(val), 0) / spectralData.length;
          const normalizedEnergy = Math.min(1, Math.max(0, (energy + 140) / 60)); // Normalize dB to 0-1
          
          // Simple BPM detection (placeholder - would use more sophisticated algorithm)
          const bpm = 120 + Math.sin(Date.now() * 0.001) * 20;
          
          updateAudioFeatures({
            spectralData,
            rms: Math.abs(rms),
            energy: normalizedEnergy,
            bpm
          });
        }
        
        animationFrameRef.current = requestAnimationFrame(analyzeAudio);
      };
      
      analyzeAudio();
    };
    
    initAudioAnalysis();
    
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      if (analyserRef.current) {
        analyserRef.current.dispose();
      }
      if (meterRef.current) {
        meterRef.current.dispose();
      }
    };
  }, [updateAudioFeatures]);
  
  // Update ribbon audio players when ribbons change
  useEffect(() => {
    ribbons.forEach(async (ribbon) => {
      if (ribbon.audioUrl && !ribbon.player) {
        try {
          const player = new Tone.Player(ribbon.audioUrl);
          player.volume.value = Tone.gainToDb(ribbon.volume);
          
          // Connect to analyser
          if (analyserRef.current && meterRef.current) {
            player.connect(analyserRef.current);
            player.connect(meterRef.current);
          }
          
          player.toDestination();
          
          updateRibbon(ribbon.id, { player });
        } catch (error) {
          console.error('Failed to load audio for ribbon:', ribbon.id, error);
        }
      }
    });
  }, [ribbons, updateRibbon]);
  
  // Update master volume
  useEffect(() => {
    if (Tone.getDestination()) {
      Tone.getDestination().volume.value = Tone.gainToDb(masterVolume);
    }
  }, [masterVolume]);
  
  return null; // This component only handles audio processing
}