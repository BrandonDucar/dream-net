'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../../ui/card'
import { Button } from '../../ui/button'
import { Badge } from '../../ui/badge'
import { Textarea } from '../../ui/textarea'
import { useAISEO, type MusicSEOData, type AIContentSuggestion } from '../../../hooks/useAISEO'
import { Brain, Search, TrendingUp, Hash, Share2, Copy, Check } from 'lucide-react'

interface AISEOPanelProps {
  currentTrack?: {
    genre: string
    mood: string
    title?: string
    artist?: string
    bpm?: number
  }
  location?: string
  onMetadataGenerated?: (metadata: any) => void
}

export function AISEOPanel({ currentTrack, location = 'Global', onMetadataGenerated }: AISEOPanelProps) {
  const {
    seoData,
    isGenerating,
    contentSuggestions,
    generateSEOMetadata,
    generateContentSuggestions,
    optimizeForSearch,
    calculateSEOScore
  } = useAISEO()

  const [activeTab, setActiveTab] = useState<'optimize' | 'content' | 'analytics'>('optimize')
  const [customContent, setCustomContent] = useState('')
  const [seoScore, setSeoScore] = useState(0)
  const [copiedItem, setCopiedItem] = useState<string | null>(null)

  // Auto-generate SEO when track changes
  useEffect(() => {
    if (currentTrack) {
      const musicData: MusicSEOData = {
        genre: currentTrack.genre,
        mood: currentTrack.mood,
        location,
        artist: currentTrack.artist,
        trackTitle: currentTrack.title,
        bpm: currentTrack.bpm
      }

      generateSEOMetadata(musicData).then(metadata => {
        onMetadataGenerated?.(metadata)
      })

      generateContentSuggestions(musicData)
    }
  }, [currentTrack, location, generateSEOMetadata, generateContentSuggestions, onMetadataGenerated])

  // Calculate SEO score for custom content
  useEffect(() => {
    if (customContent && seoData) {
      const score = calculateSEOScore(customContent, seoData.keywords)
      setSeoScore(score)
    }
  }, [customContent, seoData, calculateSEOScore])

  const copyToClipboard = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedItem(id)
      setTimeout(() => setCopiedItem(null), 2000)
    } catch (error) {
      console.error('Failed to copy:', error)
    }
  }

  const getSEOScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-400'
    if (score >= 60) return 'text-yellow-400'
    return 'text-red-400'
  }

  const getSEOScoreLabel = (score: number) => {
    if (score >= 80) return 'Excellent'
    if (score >= 60) return 'Good'
    if (score >= 40) return 'Fair'
    return 'Needs Work'
  }

  return (
    <Card className="w-full bg-black/40 border-purple-500/30 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-purple-400">
          <Brain className="w-4 h-4" />
          AI SEO Assistant
        </CardTitle>
        
        {/* Tab Navigation */}
        <div className="flex gap-1 mt-3">
          {(['optimize', 'content', 'analytics'] as const).map((tab) => (
            <Button
              key={tab}
              size="sm"
              variant={activeTab === tab ? "default" : "ghost"}
              onClick={() => setActiveTab(tab)}
              className={
                activeTab === tab
                  ? "bg-purple-500/20 text-purple-400 hover:bg-purple-500/30"
                  : "text-white/60 hover:text-white hover:bg-white/10"
              }
            >
              {tab === 'optimize' && <Search className="w-3 h-3 mr-1" />}
              {tab === 'content' && <Share2 className="w-3 h-3 mr-1" />}
              {tab === 'analytics' && <TrendingUp className="w-3 h-3 mr-1" />}
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </Button>
          ))}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* SEO Optimization Tab */}
        {activeTab === 'optimize' && (
          <div className="space-y-4">
            {isGenerating ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-center">
                  <Brain className="w-8 h-8 text-purple-400 animate-pulse mx-auto mb-2" />
                  <div className="text-sm text-white/70">Analyzing & Optimizing...</div>
                </div>
              </div>
            ) : seoData ? (
              <div className="space-y-4">
                {/* SEO Score */}
                <div className="p-4 rounded-lg bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/30">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-white/80">SEO Score</span>
                    <span className={`font-bold text-lg ${getSEOScoreColor(customContent ? seoScore : 85)}`}>
                      {customContent ? seoScore : 85}/100
                    </span>
                  </div>
                  <div className="w-full bg-black/30 rounded-full h-2 mb-1">
                    <div 
                      className={`h-2 rounded-full transition-all duration-500 ${
                        (customContent ? seoScore : 85) >= 80 ? 'bg-green-400' :
                        (customContent ? seoScore : 85) >= 60 ? 'bg-yellow-400' : 'bg-red-400'
                      }`}
                      style={{ width: `${customContent ? seoScore : 85}%` }}
                    />
                  </div>
                  <div className="text-xs text-white/60">
                    {getSEOScoreLabel(customContent ? seoScore : 85)} - {currentTrack?.genre || 'Electronic'} music optimized for {location}
                  </div>
                </div>

                {/* Optimized Title */}
                <div className="space-y-2">
                  <label className="text-sm text-white/70">Optimized Title</label>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 p-3 rounded-lg bg-black/30 border border-white/10 text-white text-sm">
                      {seoData.title}
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(seoData.title, 'title')}
                      className="text-white/60 hover:text-white"
                    >
                      {copiedItem === 'title' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                {/* Meta Description */}
                <div className="space-y-2">
                  <label className="text-sm text-white/70">Meta Description</label>
                  <div className="flex items-start gap-2">
                    <div className="flex-1 p-3 rounded-lg bg-black/30 border border-white/10 text-white text-sm">
                      {seoData.description}
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(seoData.description, 'description')}
                      className="text-white/60 hover:text-white"
                    >
                      {copiedItem === 'description' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                {/* Keywords */}
                <div className="space-y-2">
                  <label className="text-sm text-white/70">Target Keywords</label>
                  <div className="flex flex-wrap gap-1">
                    {seoData.keywords.slice(0, 8).map((keyword, index) => (
                      <Badge 
                        key={index}
                        variant="outline"
                        className="text-xs bg-purple-500/20 text-purple-300 border-purple-500/30 cursor-pointer"
                        onClick={() => copyToClipboard(keyword, `keyword-${index}`)}
                      >
                        {keyword}
                        {copiedItem === `keyword-${index}` ? 
                          <Check className="w-3 h-3 ml-1" /> : 
                          <Copy className="w-3 h-3 ml-1" />
                        }
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-6">
                <Search className="w-8 h-8 text-white/20 mx-auto mb-3" />
                <div className="text-sm text-white/50 mb-3">
                  Create music to generate SEO optimization
                </div>
              </div>
            )}
          </div>
        )}

        {/* Content Generation Tab */}
        {activeTab === 'content' && (
          <div className="space-y-4">
            {contentSuggestions.length > 0 ? (
              contentSuggestions.map((suggestion, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Hash className="w-4 h-4 text-purple-400" />
                    <span className="text-sm text-white/70 capitalize">
                      {suggestion.type.replace('_', ' ')}
                    </span>
                    <Badge variant="outline" className="text-xs">
                      {Math.round(suggestion.confidence * 100)}% confidence
                    </Badge>
                  </div>
                  
                  <div className="p-3 rounded-lg bg-black/30 border border-white/10">
                    <div className="text-white text-sm mb-2">
                      {suggestion.content}
                    </div>
                    
                    {suggestion.variations.length > 1 && (
                      <div className="space-y-1 mt-3">
                        <div className="text-xs text-white/50">Variations:</div>
                        {suggestion.variations.slice(1, 3).map((variation, vIndex) => (
                          <div key={vIndex} className="text-xs text-white/60 pl-2 border-l border-white/10">
                            {variation}
                          </div>
                        ))}
                      </div>
                    )}
                    
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(suggestion.content, `suggestion-${index}`)}
                      className="mt-2 text-purple-400 hover:text-purple-300 hover:bg-purple-500/20"
                    >
                      {copiedItem === `suggestion-${index}` ? 
                        <Check className="w-3 h-3 mr-1" /> : 
                        <Copy className="w-3 h-3 mr-1" />
                      }
                      Copy
                    </Button>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-6">
                <Share2 className="w-8 h-8 text-white/20 mx-auto mb-3" />
                <div className="text-sm text-white/50 mb-3">
                  No content suggestions yet
                </div>
                <div className="text-xs text-white/30">
                  Create music to get AI-powered content suggestions
                </div>
              </div>
            )}

            {/* Custom Content Optimizer */}
            <div className="space-y-2 border-t border-white/10 pt-4">
              <label className="text-sm text-white/70">Test Your Own Content</label>
              <Textarea
                value={customContent}
                onChange={(e) => setCustomContent(e.target.value)}
                placeholder="Enter your content to get real-time SEO optimization..."
                className="bg-black/30 border-white/10 text-white placeholder:text-white/40"
                rows={3}
              />
              {customContent && seoScore > 0 && (
                <div className="text-xs text-white/60">
                  SEO Score: <span className={getSEOScoreColor(seoScore)}>{seoScore}/100</span> - 
                  {seoScore >= 80 ? ' Great optimization!' :
                   seoScore >= 60 ? ' Good, try adding more keywords.' :
                   ' Needs more relevant keywords and better structure.'}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === 'analytics' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              {/* Performance Metrics */}
              <div className="p-4 rounded-lg bg-gradient-to-br from-green-500/20 to-blue-500/20 border border-green-500/30">
                <div className="text-lg font-bold text-green-400">92%</div>
                <div className="text-xs text-white/60">Discoverability</div>
              </div>
              
              <div className="p-4 rounded-lg bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/30">
                <div className="text-lg font-bold text-blue-400">78%</div>
                <div className="text-xs text-white/60">Social Reach</div>
              </div>
              
              <div className="p-4 rounded-lg bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/30">
                <div className="text-lg font-bold text-purple-400">8.4K</div>
                <div className="text-xs text-white/60">Keyword Rank</div>
              </div>
              
              <div className="p-4 rounded-lg bg-gradient-to-br from-pink-500/20 to-red-500/20 border border-pink-500/30">
                <div className="text-lg font-bold text-pink-400">156</div>
                <div className="text-xs text-white/60">Trending Score</div>
              </div>
            </div>

            {/* Top Keywords */}
            <div className="space-y-2">
              <div className="text-sm text-white/70">Top Performing Keywords</div>
              <div className="space-y-1">
                {['AI music creation', 'holographic interface', 'location-based music', 'remix AI'].map((keyword, index) => (
                  <div key={index} className="flex items-center justify-between p-2 rounded bg-black/20">
                    <span className="text-xs text-white/60">{keyword}</span>
                    <Badge variant="outline" className="text-xs">
                      #{index + 1}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>

            {/* Insights */}
            <div className="p-4 rounded-lg bg-gradient-to-r from-indigo-500/20 to-cyan-500/20 border border-indigo-500/30">
              <div className="text-sm text-white/80 mb-2">🧠 AI Insights</div>
              <div className="text-xs text-white/60 space-y-1">
                <div>• Location-based content performs 300% better</div>
                <div>• Genre-specific hashtags increase reach by 150%</div>
                <div>• AI-generated descriptions have 85% engagement rate</div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}