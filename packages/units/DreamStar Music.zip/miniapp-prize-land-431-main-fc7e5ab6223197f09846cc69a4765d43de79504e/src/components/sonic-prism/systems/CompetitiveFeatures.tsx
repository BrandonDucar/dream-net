'use client'

import { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../../ui/card'
import { Button } from '../../ui/button'
import { Badge } from '../../ui/badge'
import { Slider } from '../../ui/slider'
import { Switch } from '../../ui/switch'
import { 
  Sparkles, 
  Shuffle, 
  Mic, 
  Users, 
  TrendingUp, 
  Music, 
  Headphones,
  Radio,
  Palette,
  Zap
} from 'lucide-react'

interface CompetitiveFeaturesProps {
  onFeatureToggle?: (feature: string, enabled: boolean) => void
  currentTrack?: any
}

// Competitive features inspired by market leaders
const COMPETITIVE_FEATURES = {
  spotify: {
    name: 'Spotify AI DJ',
    description: 'AI narrator that curates and explains your music',
    icon: Headphones,
    status: 'enhanced',
    improvements: [
      'Real-time voice synthesis with emotional expression',
      'Holographic avatar DJ that responds to your music',
      'Location-aware music curation with local insights'
    ]
  },
  bandlab: {
    name: 'Social Collaboration',
    description: 'Real-time collaborative music creation',
    icon: Users,
    status: 'enhanced',
    improvements: [
      'Holographic shared workspace for multiple users',
      'Real-time 3D audio placement for each collaborator',
      'AI-powered conflict resolution for simultaneous edits'
    ]
  },
  amper: {
    name: 'Instant AI Composition',
    description: 'Generate complete tracks from simple inputs',
    icon: Zap,
    status: 'enhanced',
    improvements: [
      'Visual composition with 3D audio ribbon manipulation',
      'Location-based AI prompts for contextual music',
      'Real-time genre morphing with visual feedback'
    ]
  },
  splice: {
    name: 'Smart Sample Discovery',
    description: 'AI-powered sample recommendations',
    icon: Sparkles,
    status: 'revolutionized',
    improvements: [
      'Holographic sample library with spatial audio preview',
      'AI that analyzes your location to suggest regional sounds',
      'Visual waveform manipulation in 3D space'
    ]
  },
  tiktok: {
    name: 'Viral Remix Engine',
    description: 'Create remixes optimized for social media',
    icon: TrendingUp,
    status: 'enhanced',
    improvements: [
      'Real-time trending analysis with visual trend indicators',
      'AI that predicts viral potential of your creations',
      'Automatic optimization for different social platforms'
    ]
  },
  youtube: {
    name: 'Content Creator Studio',
    description: 'AI-powered content creation for creators',
    icon: Radio,
    status: 'enhanced',
    improvements: [
      'Holographic podcast/video soundtrack generation',
      'AI that matches music to visual content automatically',
      'Real-time audience engagement prediction'
    ]
  }
}

export function CompetitiveFeatures({ onFeatureToggle, currentTrack }: CompetitiveFeaturesProps) {
  const [activeFeatures, setActiveFeatures] = useState<Record<string, boolean>>({
    aiDJ: true,
    collaboration: false,
    instantComposition: true,
    sampleDiscovery: true,
    viralRemix: false,
    contentStudio: false
  })

  const [djPersonality, setDjPersonality] = useState([50])
  const [collaborationMode, setCollaborationMode] = useState<'realtime' | 'async'>('realtime')
  const [viralOptimization, setViralOptimization] = useState([75])
  
  const aiDJRef = useRef<HTMLDivElement>(null)

  const toggleFeature = (featureKey: string, enabled: boolean) => {
    setActiveFeatures(prev => ({ ...prev, [featureKey]: enabled }))
    onFeatureToggle?.(featureKey, enabled)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'enhanced': return 'text-blue-400 bg-blue-500/20'
      case 'revolutionized': return 'text-purple-400 bg-purple-500/20'
      default: return 'text-gray-400 bg-gray-500/20'
    }
  }

  return (
    <Card className="w-full bg-black/40 border-orange-500/30 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-orange-400">
          <Palette className="w-4 h-4" />
          Competitive Advantage Suite
        </CardTitle>
        <div className="text-xs text-white/60">
          Taking the best from Spotify, BandLab, Amper, and more - but better
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Spotify AI DJ Enhancement */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Headphones className="w-5 h-5 text-blue-400" />
              <div>
                <div className="text-sm font-medium text-white">Holographic AI DJ</div>
                <div className="text-xs text-white/60">Enhanced from Spotify AI DJ</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className={getStatusColor('enhanced')}>Enhanced</Badge>
              <Switch
                checked={activeFeatures.aiDJ}
                onCheckedChange={(enabled) => toggleFeature('aiDJ', enabled)}
              />
            </div>
          </div>

          {activeFeatures.aiDJ && (
            <div className="p-4 rounded-lg bg-blue-500/10 border border-blue-500/20 space-y-3">
              <div className="text-xs text-white/70">
                🎯 <strong>Our Innovation:</strong> 3D AI avatar that explains your music while visualizing it holographically
              </div>
              
              <div className="space-y-2">
                <label className="text-xs text-white/60">DJ Personality (Chill ↔ Energetic)</label>
                <Slider
                  value={djPersonality}
                  onValueChange={setDjPersonality}
                  max={100}
                  step={1}
                  className="w-full"
                />
                <div className="text-xs text-white/50">
                  Current: {djPersonality[0] < 30 ? 'Chill & Smooth' : 
                          djPersonality[0] < 70 ? 'Balanced & Informative' : 'Energetic & Hype'}
                </div>
              </div>

              <div 
                ref={aiDJRef}
                className="p-3 rounded-lg bg-black/30 border border-blue-400/30 text-center"
              >
                <div className="text-sm text-blue-300 mb-1">🎙️ AI DJ Speaking</div>
                <div className="text-xs text-white/70 italic">
                  "This {currentTrack?.genre || 'electronic'} track has that perfect {currentTrack?.mood || 'energetic'} vibe for your current location. I'm detecting some amazing harmonic progressions that would blend perfectly with jazz fusion elements..."
                </div>
              </div>
            </div>
          )}
        </div>

        {/* BandLab Collaboration Enhancement */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Users className="w-5 h-5 text-green-400" />
              <div>
                <div className="text-sm font-medium text-white">Holographic Collaboration</div>
                <div className="text-xs text-white/60">Enhanced from BandLab Social Features</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className={getStatusColor('enhanced')}>Enhanced</Badge>
              <Switch
                checked={activeFeatures.collaboration}
                onCheckedChange={(enabled) => toggleFeature('collaboration', enabled)}
              />
            </div>
          </div>

          {activeFeatures.collaboration && (
            <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/20 space-y-3">
              <div className="text-xs text-white/70">
                🎯 <strong>Our Innovation:</strong> Multiple users see each other's audio as 3D ribbons in shared holographic space
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-xs text-white/60">Collaboration Mode</span>
                <div className="flex gap-1">
                  <Button
                    size="sm"
                    variant={collaborationMode === 'realtime' ? 'default' : 'ghost'}
                    onClick={() => setCollaborationMode('realtime')}
                    className="text-xs"
                  >
                    Real-time
                  </Button>
                  <Button
                    size="sm"
                    variant={collaborationMode === 'async' ? 'default' : 'ghost'}
                    onClick={() => setCollaborationMode('async')}
                    className="text-xs"
                  >
                    Async
                  </Button>
                </div>
              </div>

              <div className="text-xs text-white/50">
                • Up to 8 users in shared holographic workspace
                • Real-time conflict resolution when editing same sections
                • Spatial audio - hear each collaborator's position in 3D space
              </div>
            </div>
          )}
        </div>

        {/* Amper Instant Composition Enhancement */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Zap className="w-5 h-5 text-yellow-400" />
              <div>
                <div className="text-sm font-medium text-white">Visual AI Composition</div>
                <div className="text-xs text-white/60">Enhanced from Amper Music AI</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className={getStatusColor('enhanced')}>Enhanced</Badge>
              <Switch
                checked={activeFeatures.instantComposition}
                onCheckedChange={(enabled) => toggleFeature('instantComposition', enabled)}
              />
            </div>
          </div>

          {activeFeatures.instantComposition && (
            <div className="p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
              <div className="text-xs text-white/70 mb-2">
                🎯 <strong>Our Innovation:</strong> Touch and drag 3D prisms to compose instead of typing prompts
              </div>
              <div className="text-xs text-white/50">
                • Visual composition with holographic interface
                • Location-aware AI prompts automatically generated
                • Real-time genre morphing with instant audio feedback
              </div>
            </div>
          )}
        </div>

        {/* Splice Sample Discovery Revolution */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-purple-400" />
              <div>
                <div className="text-sm font-medium text-white">3D Sample Universe</div>
                <div className="text-xs text-white/60">Revolutionized from Splice Discovery</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className={getStatusColor('revolutionized')}>Revolutionized</Badge>
              <Switch
                checked={activeFeatures.sampleDiscovery}
                onCheckedChange={(enabled) => toggleFeature('sampleDiscovery', enabled)}
              />
            </div>
          </div>

          {activeFeatures.sampleDiscovery && (
            <div className="p-4 rounded-lg bg-purple-500/10 border border-purple-500/20">
              <div className="text-xs text-white/70 mb-2">
                🎯 <strong>Our Innovation:</strong> Samples float in 3D space, spatially organized by similarity and location relevance
              </div>
              <div className="text-xs text-white/50">
                • Samples arranged in holographic constellations
                • AI analyzes your location to suggest regional sounds
                • Visual similarity mapping - similar samples cluster together
              </div>
            </div>
          )}
        </div>

        {/* TikTok Viral Optimization */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-5 h-5 text-pink-400" />
              <div>
                <div className="text-sm font-medium text-white">Viral AI Predictor</div>
                <div className="text-xs text-white/60">Enhanced from TikTok Algorithm Insights</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className={getStatusColor('enhanced')}>Enhanced</Badge>
              <Switch
                checked={activeFeatures.viralRemix}
                onCheckedChange={(enabled) => toggleFeature('viralRemix', enabled)}
              />
            </div>
          </div>

          {activeFeatures.viralRemix && (
            <div className="p-4 rounded-lg bg-pink-500/10 border border-pink-500/20 space-y-3">
              <div className="text-xs text-white/70">
                🎯 <strong>Our Innovation:</strong> Real-time viral potential analysis with visual trend indicators
              </div>
              
              <div className="space-y-2">
                <label className="text-xs text-white/60">Viral Optimization Level</label>
                <Slider
                  value={viralOptimization}
                  onValueChange={setViralOptimization}
                  max={100}
                  step={1}
                  className="w-full"
                />
                <div className="text-xs text-white/50">
                  Current: {viralOptimization[0]}% - {
                    viralOptimization[0] < 30 ? 'Artistic Focus' :
                    viralOptimization[0] < 70 ? 'Balanced Appeal' : 'Maximum Viral Potential'
                  }
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2 rounded bg-black/20">
                  <div className="text-pink-300">Trend Score: 89%</div>
                  <div className="text-white/50">Hook Timing Perfect</div>
                </div>
                <div className="p-2 rounded bg-black/20">
                  <div className="text-pink-300">Platform Fit: 94%</div>
                  <div className="text-white/50">TikTok + Instagram</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* YouTube Content Creator Studio */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Radio className="w-5 h-5 text-red-400" />
              <div>
                <div className="text-sm font-medium text-white">Creator AI Studio</div>
                <div className="text-xs text-white/60">Enhanced from YouTube Audio Library</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className={getStatusColor('enhanced')}>Enhanced</Badge>
              <Switch
                checked={activeFeatures.contentStudio}
                onCheckedChange={(enabled) => toggleFeature('contentStudio', enabled)}
              />
            </div>
          </div>

          {activeFeatures.contentStudio && (
            <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/20">
              <div className="text-xs text-white/70 mb-2">
                🎯 <strong>Our Innovation:</strong> AI matches music to video content automatically, predicts audience engagement
              </div>
              <div className="text-xs text-white/50">
                • Real-time soundtrack generation for video content
                • Audience engagement prediction with visual feedback
                • Multi-platform optimization (YouTube, Twitch, Podcast platforms)
              </div>
            </div>
          )}
        </div>

        {/* Market Dominance Summary */}
        <div className="p-4 rounded-lg bg-gradient-to-r from-orange-500/20 to-red-500/20 border border-orange-500/30">
          <div className="text-sm text-white/80 mb-2">🏆 Market Position Summary</div>
          <div className="text-xs text-white/60 space-y-1">
            <div>• <strong>Spotify:</strong> Their AI DJ talks - ours shows + explains in 3D</div>
            <div>• <strong>BandLab:</strong> Their collab is 2D chat - ours is holographic presence</div>
            <div>• <strong>Amper:</strong> Their AI needs prompts - ours reads location + gestures</div>
            <div>• <strong>Splice:</strong> Their samples are lists - ours are spatial constellations</div>
            <div>• <strong>TikTok:</strong> Their algo is black box - ours shows viral prediction visually</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}