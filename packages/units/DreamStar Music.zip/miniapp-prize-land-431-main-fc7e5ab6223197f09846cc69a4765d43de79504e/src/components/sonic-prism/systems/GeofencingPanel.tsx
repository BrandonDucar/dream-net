'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../../ui/card'
import { Button } from '../../ui/button'
import { Badge } from '../../ui/badge'
import { useGeofencing, type MusicGeofence } from '../../../hooks/useGeofencing'
import { MapPin, Music, Navigation, Users } from 'lucide-react'

interface GeofencingPanelProps {
  onLocationChange?: (geofence: MusicGeofence | null) => void
  onAIPromptsUpdate?: (prompts: string[]) => void
}

export function GeofencingPanel({ onLocationChange, onAIPromptsUpdate }: GeofencingPanelProps) {
  const {
    currentPosition,
    activeGeofence,
    nearbyGeofences,
    locationError,
    isTracking,
    startTracking,
    stopTracking,
    getLocationAIPrompts,
    getLocationGenres,
    calculateDistance
  } = useGeofencing()

  const [showNearby, setShowNearby] = useState(false)

  useEffect(() => {
    onLocationChange?.(activeGeofence)
    onAIPromptsUpdate?.(getLocationAIPrompts())
  }, [activeGeofence, onLocationChange, onAIPromptsUpdate, getLocationAIPrompts])

  useEffect(() => {
    // Auto-start tracking on mount
    const cleanup = startTracking()
    return cleanup
  }, [startTracking])

  const formatDistance = (geofence: MusicGeofence): string => {
    if (!currentPosition) return ''
    const distance = calculateDistance(currentPosition, geofence.center)
    return distance < 1000 
      ? `${Math.round(distance)}m away` 
      : `${(distance / 1000).toFixed(1)}km away`
  }

  const getMoodEmoji = (mood: string): string => {
    const moods: Record<string, string> = {
      'energetic': '⚡',
      'rebellious': '🔥',
      'soulful': '🎺',
      'smooth': '🎷',
      'creative': '🎨',
      'tropical': '🌴',
      'alternative': '☕',
      'industrial': '⚙️'
    }
    return moods[mood] || '🎵'
  }

  return (
    <Card className="w-full bg-black/40 border-cyan-500/30 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-cyan-400">
          <Navigation className="w-4 h-4" />
          Location-Based Discovery
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Tracking Status */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-cyan-400" />
            <span className="text-sm text-white/70">
              {isTracking ? 'Tracking Active' : 'Location Off'}
            </span>
          </div>
          <Button
            size="sm"
            variant={isTracking ? "destructive" : "default"}
            onClick={isTracking ? stopTracking : startTracking}
            className={isTracking ? 
              "bg-red-500/20 text-red-400 hover:bg-red-500/30" : 
              "bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30"
            }
          >
            {isTracking ? 'Stop' : 'Start'}
          </Button>
        </div>

        {/* Location Error */}
        {locationError && (
          <div className="p-3 rounded-lg bg-red-500/20 border border-red-500/30">
            <p className="text-sm text-red-400">{locationError}</p>
          </div>
        )}

        {/* Current Location Status */}
        {currentPosition && (
          <div className="space-y-3">
            <div className="text-sm text-white/50">
              📍 {currentPosition.lat.toFixed(4)}, {currentPosition.lng.toFixed(4)}
              {currentPosition.accuracy && (
                <span className="ml-2">±{Math.round(currentPosition.accuracy)}m</span>
              )}
            </div>

            {/* Active Geofence */}
            {activeGeofence ? (
              <div className="p-4 rounded-lg bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border border-cyan-500/30">
                <div className="flex items-center gap-2 mb-2">
                  <Music className="w-5 h-5 text-cyan-400" />
                  <span className="font-medium text-white">{activeGeofence.venue}</span>
                  <Badge variant="secondary" className="bg-cyan-500/20 text-cyan-400">
                    {getMoodEmoji(activeGeofence.mood)} {activeGeofence.genre}
                  </Badge>
                </div>
                
                <div className="text-sm text-white/70 mb-3">
                  Perfect for <strong>{activeGeofence.mood}</strong> music creation
                </div>

                <div className="space-y-2">
                  <div className="text-xs text-white/50">AI Music Prompts:</div>
                  <div className="flex flex-wrap gap-1">
                    {activeGeofence.aiPrompts.map((prompt, index) => (
                      <Badge 
                        key={index}
                        variant="outline"
                        className="text-xs bg-black/30 text-cyan-300 border-cyan-500/30"
                      >
                        {prompt}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="mt-3 space-y-1">
                  <div className="text-xs text-white/50">Curated Playlists:</div>
                  {activeGeofence.playlists.map((playlist, index) => (
                    <div key={index} className="text-xs text-white/70">• {playlist}</div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="p-4 rounded-lg bg-white/5 border border-white/10 text-center">
                <Music className="w-6 h-6 text-white/30 mx-auto mb-2" />
                <div className="text-sm text-white/50">
                  No music venues nearby
                </div>
                <div className="text-xs text-white/30 mt-1">
                  Move around to discover location-based music
                </div>
              </div>
            )}

            {/* Nearby Geofences */}
            {nearbyGeofences.length > 0 && (
              <div className="space-y-2">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setShowNearby(!showNearby)}
                  className="text-white/70 hover:text-white hover:bg-white/10"
                >
                  <Users className="w-4 h-4 mr-2" />
                  {nearbyGeofences.length} Nearby Venues
                  <span className="ml-1">{showNearby ? '▼' : '▶'}</span>
                </Button>

                {showNearby && (
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {nearbyGeofences.map((geofence) => (
                      <div
                        key={geofence.id}
                        className="p-3 rounded-lg bg-white/5 border border-white/10"
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm text-white font-medium">
                            {geofence.venue}
                          </span>
                          <Badge variant="outline" className="text-xs">
                            {getMoodEmoji(geofence.mood)} {geofence.genre}
                          </Badge>
                        </div>
                        <div className="text-xs text-white/50">
                          {formatDistance(geofence)}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Location Insights */}
            <div className="p-3 rounded-lg bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/30">
              <div className="text-sm text-white/80 mb-2">
                🎯 <strong>Location AI Insights</strong>
              </div>
              <div className="text-xs text-white/60">
                • Recommended genres: {getLocationGenres().join(', ') || 'Ambient, Experimental'}
              </div>
              <div className="text-xs text-white/60 mt-1">
                • AI will adapt music based on your current environment
              </div>
              <div className="text-xs text-white/60 mt-1">
                • Location history helps improve recommendations
              </div>
            </div>
          </div>
        )}

        {/* No Location Permission */}
        {!isTracking && !locationError && (
          <div className="text-center py-6">
            <MapPin className="w-8 h-8 text-white/20 mx-auto mb-3" />
            <div className="text-sm text-white/50 mb-3">
              Enable location for AI-powered music discovery
            </div>
            <div className="text-xs text-white/30 mb-4">
              Discover music venues, get location-based AI prompts, and create music that matches your environment
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}