'use client'

import { useState, useRef } from 'react'
import { useSonicPrism } from '../SonicPrismProvider'
import { Button } from '../../ui/button'
import { Slider } from '../../ui/slider'
import { Input } from '../../ui/input'
import { Card } from '../../ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../ui/tabs'
import { GeofencingPanel } from '../systems/GeofencingPanel'
import { AISEOPanel } from '../systems/AISEOPanel'
import { CompetitiveFeatures } from '../systems/CompetitiveFeatures'
import { 
  Play, 
  Pause, 
  Plus, 
  Mic, 
  Music, 
  Volume2, 
  Settings,
  MapPin,
  Brain,
  Trophy,
  Wand2,
  Sparkles,
  Palette,
  MessageCircle,
  Search,
  ExternalLink,
  Navigation
} from 'lucide-react'

export function EnhancedSonicPrismUI() {
  const {
    isPlaying,
    masterVolume,
    selectedRibbonId,
    selectedPrismId,
    ribbons,
    prisms,
    currentMode,
    setPlaying,
    setMasterVolume,
    generateMusic,
    generateVocals,
    addPrism
  } = useSonicPrism()
  
  const [musicPrompt, setMusicPrompt] = useState('')
  const [vocalText, setVocalText] = useState('')
  const [activeTab, setActiveTab] = useState('create')
  const [selectedGenre, setSelectedGenre] = useState('electronic')
  const [currentTrack, setCurrentTrack] = useState<any>(null)
  
  const selectedRibbon = ribbons.find(r => r.id === selectedRibbonId)
  const selectedPrism = prisms.find(p => p.id === selectedPrismId)
  
  const handleGenerateMusic = async () => {
    if (musicPrompt.trim()) {
      await generateMusic(musicPrompt)
      // Update current track for SEO analysis
      setCurrentTrack({
        genre: selectedGenre,
        mood: 'energetic',
        title: `AI Generated ${selectedGenre} Track`,
        artist: 'Sonic Prism AI'
      })
      setMusicPrompt('')
    }
  }
  
  const handleGenerateVocals = async () => {
    if (vocalText.trim()) {
      await generateVocals(vocalText, 'Rachel')
      setVocalText('')
    }
  }
  
  const handleAddPrism = (type: 'GenreShift' | 'Cleanup' | 'Harmonize' | 'Vocalize') => {
    const colors = {
      GenreShift: '#FF6B35',
      Cleanup: '#00D4AA',
      Harmonize: '#8A2BE2',
      Vocalize: '#FFD700'
    }
    
    addPrism({
      type,
      position: [Math.random() * 6 - 3, 1, Math.random() * 6 - 3],
      intensity: 0.5,
      divergence: 0.5,
      isActive: false,
      color: colors[type]
    })
  }

  return (
    <>
      {/* Navigation Menu */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 pointer-events-auto z-20">
        <Card className="bg-black/60 backdrop-blur-md border border-white/20 px-4 py-2">
          <div className="flex items-center gap-2">
            <Button
              onClick={() => window.location.href = '/'}
              className="bg-cyan-500/30 text-cyan-100 border border-cyan-400/50 text-xs"
              size="sm"
            >
              <Wand2 className="w-3 h-3 mr-1" />
              Studio
            </Button>
            <Button
              onClick={() => window.location.href = '/inspiration'}
              className="bg-white/10 hover:bg-orange-500/20 border border-white/30 text-white text-xs"
              size="sm"
            >
              <Search className="w-3 h-3 mr-1" />
              Inspiration
            </Button>
            <Button
              onClick={() => window.location.href = '/muse'}
              className="bg-white/10 hover:bg-purple-500/20 border border-white/30 text-white text-xs"
              size="sm"
            >
              <MessageCircle className="w-3 h-3 mr-1" />
              Muse
            </Button>
            <Button
              onClick={() => window.location.href = '/gallery'}
              className="bg-white/10 hover:bg-pink-500/20 border border-white/30 text-white text-xs"
              size="sm"
            >
              <Palette className="w-3 h-3 mr-1" />
              Gallery
            </Button>
          </div>
        </Card>
      </div>
      
      {/* Top Control Bar */}
      <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-auto z-10">
        <div className="flex items-center gap-4">
          {/* Play/Pause */}
          <Button
            onClick={() => setPlaying(!isPlaying)}
            className="bg-white/10 hover:bg-white/20 border border-white/30 text-white backdrop-blur-sm"
            size="sm"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </Button>
          
          {/* Master Volume */}
          <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-md px-3 py-2 border border-white/20">
            <Volume2 className="w-4 h-4 text-white" />
            <Slider
              value={[masterVolume]}
              onValueChange={(value) => setMasterVolume(value[0])}
              max={1}
              step={0.01}
              className="w-20"
            />
          </div>
        </div>
        
        {/* Logo */}
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white tracking-wider">
            <span className="bg-gradient-to-r from-cyan-400 to-pink-400 bg-clip-text text-transparent">
              SONIC PRISM
            </span>
          </h1>
          <p className="text-xs text-white/60">AI-Powered Holographic Studio</p>
        </div>
        
        {/* Quick Access Icons */}
        <div className="flex items-center gap-2">
          <Button
            onClick={() => setActiveTab('location')}
            className={`${activeTab === 'location' ? 'bg-cyan-500/30' : 'bg-white/10'} hover:bg-white/20 border border-white/30 text-white backdrop-blur-sm`}
            size="sm"
          >
            <MapPin className="w-4 h-4" />
          </Button>
          <Button
            onClick={() => setActiveTab('seo')}
            className={`${activeTab === 'seo' ? 'bg-purple-500/30' : 'bg-white/10'} hover:bg-white/20 border border-white/30 text-white backdrop-blur-sm`}
            size="sm"
          >
            <Brain className="w-4 h-4" />
          </Button>
          <Button
            onClick={() => setActiveTab('competitive')}
            className={`${activeTab === 'competitive' ? 'bg-orange-500/30' : 'bg-white/10'} hover:bg-white/20 border border-white/30 text-white backdrop-blur-sm`}
            size="sm"
          >
            <Trophy className="w-4 h-4" />
          </Button>
        </div>
      </div>
      
      {/* Left Sidebar - Enhanced Creation Tools */}
      <div className="absolute left-4 top-20 bottom-4 w-80 pointer-events-auto">
        <Card className="h-full bg-black/40 backdrop-blur-md border border-white/20 overflow-hidden">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
            <TabsList className="grid w-full grid-cols-6 m-4 mb-0">
              <TabsTrigger value="create" className="text-xs">
                <Wand2 className="w-3 h-3" />
              </TabsTrigger>
              <TabsTrigger value="prisms" className="text-xs">
                <Sparkles className="w-3 h-3" />
              </TabsTrigger>
              <TabsTrigger value="location" className="text-xs">
                <MapPin className="w-3 h-3" />
              </TabsTrigger>
              <TabsTrigger value="seo" className="text-xs">
                <Brain className="w-3 h-3" />
              </TabsTrigger>
              <TabsTrigger value="competitive" className="text-xs">
                <Trophy className="w-3 h-3" />
              </TabsTrigger>
              <TabsTrigger value="settings" className="text-xs">
                <Settings className="w-3 h-3" />
              </TabsTrigger>
            </TabsList>

            {/* Create Tab */}
            <TabsContent value="create" className="flex-1 p-4 pt-2 overflow-y-auto">
              <h2 className="text-lg font-semibold text-white mb-4">AI Creation Studio</h2>
              
              {/* Genre Selection */}
              <div className="mb-4">
                <label className="text-sm text-white/70 mb-2 block">Genre</label>
                <select 
                  value={selectedGenre}
                  onChange={(e) => setSelectedGenre(e.target.value)}
                  className="w-full bg-white/10 border border-white/20 rounded-md px-3 py-2 text-white text-sm"
                >
                  <option value="electronic">Electronic</option>
                  <option value="rock">Rock</option>
                  <option value="jazz">Jazz</option>
                  <option value="country">Country</option>
                  <option value="hip_hop">Hip Hop</option>
                  <option value="latin">Latin</option>
                  <option value="indie">Indie</option>
                  <option value="classical">Classical</option>
                </select>
              </div>

              {/* AI Music Generation */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-white/80 mb-2 flex items-center gap-2">
                  <Music className="w-4 h-4" />
                  Generate Music
                </h3>
                <div className="space-y-2">
                  <Input
                    value={musicPrompt}
                    onChange={(e) => setMusicPrompt(e.target.value)}
                    placeholder="Describe your music..."
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                  />
                  <Button 
                    onClick={handleGenerateMusic}
                    disabled={!musicPrompt.trim()}
                    className="w-full bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/30 text-cyan-100"
                    size="sm"
                  >
                    Generate Track
                  </Button>
                </div>
              </div>
              
              {/* AI Vocal Generation */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-white/80 mb-2 flex items-center gap-2">
                  <Mic className="w-4 h-4" />
                  Generate Vocals
                </h3>
                <div className="space-y-2">
                  <Input
                    value={vocalText}
                    onChange={(e) => setVocalText(e.target.value)}
                    placeholder="Enter lyrics..."
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                  />
                  <Button 
                    onClick={handleGenerateVocals}
                    disabled={!vocalText.trim()}
                    className="w-full bg-pink-500/20 hover:bg-pink-500/30 border border-pink-400/30 text-pink-100"
                    size="sm"
                  >
                    Generate Vocals
                  </Button>
                </div>
              </div>
            </TabsContent>

            {/* Prisms Tab */}
            <TabsContent value="prisms" className="flex-1 p-4 pt-2 overflow-y-auto">
              <h2 className="text-lg font-semibold text-white mb-4">AI Prisms</h2>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  onClick={() => handleAddPrism('GenreShift')}
                  className="bg-orange-500/20 hover:bg-orange-500/30 border border-orange-400/30 text-orange-100"
                  size="sm"
                >
                  Genre Shift
                </Button>
                <Button
                  onClick={() => handleAddPrism('Cleanup')}
                  className="bg-green-500/20 hover:bg-green-500/30 border border-green-400/30 text-green-100"
                  size="sm"
                >
                  Cleanup
                </Button>
                <Button
                  onClick={() => handleAddPrism('Harmonize')}
                  className="bg-purple-500/20 hover:bg-purple-500/30 border border-purple-400/30 text-purple-100"
                  size="sm"
                >
                  Harmonize
                </Button>
                <Button
                  onClick={() => handleAddPrism('Vocalize')}
                  className="bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-400/30 text-yellow-100"
                  size="sm"
                >
                  Vocalize
                </Button>
              </div>
              <div className="text-xs text-white/60 mt-4 space-y-1">
                <p>• Drag prisms to audio ribbons to transform them</p>
                <p>• Scroll on prisms to adjust intensity</p>
                <p>• Click elements to select and edit</p>
              </div>
            </TabsContent>

            {/* Location-Based Discovery Tab */}
            <TabsContent value="location" className="flex-1 p-4 pt-2 overflow-y-auto">
              <GeofencingPanel 
                onLocationChange={(geofence) => {
                  if (geofence) {
                    setMusicPrompt(geofence.aiPrompts[0] || musicPrompt)
                    setSelectedGenre(geofence.genre)
                  }
                }}
                onAIPromptsUpdate={(prompts) => {
                  console.log('Location AI prompts updated:', prompts)
                }}
              />
            </TabsContent>

            {/* AI SEO Tab */}
            <TabsContent value="seo" className="flex-1 p-4 pt-2 overflow-y-auto">
              <AISEOPanel 
                currentTrack={currentTrack}
                location="Current Location"
                onMetadataGenerated={(metadata) => {
                  console.log('SEO metadata generated:', metadata)
                }}
              />
            </TabsContent>

            {/* Competitive Features Tab */}
            <TabsContent value="competitive" className="flex-1 p-4 pt-2 overflow-y-auto">
              <CompetitiveFeatures 
                onFeatureToggle={(feature, enabled) => {
                  console.log(`Feature ${feature} ${enabled ? 'enabled' : 'disabled'}`)
                }}
                currentTrack={currentTrack}
              />
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="flex-1 p-4 pt-2 overflow-y-auto">
              <h2 className="text-lg font-semibold text-white mb-4">Settings</h2>
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-white/70 mb-2 block">Audio Quality</label>
                  <Slider
                    defaultValue={[80]}
                    max={100}
                    step={10}
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="text-sm text-white/70 mb-2 block">Reverb Amount</label>
                  <Slider
                    defaultValue={[30]}
                    max={100}
                    step={5}
                    className="w-full"
                  />
                </div>
                {/* System Status */}
                <div className="border-t border-white/10 pt-4">
                  <div className="text-sm text-white/70 mb-3">System Status</div>
                  <div className="space-y-2 text-xs text-white/50">
                    <div className="flex items-center justify-between">
                      <span>Location Discovery</span>
                      <span className="text-green-400">Active</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>AI SEO</span>
                      <span className="text-blue-400">Optimizing</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Competitive Edge</span>
                      <span className="text-purple-400">Enhanced</span>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </Card>
      </div>
      
      {/* Right Sidebar - Selection Details */}
      {(selectedRibbon || selectedPrism) && (
        <div className="absolute right-4 top-20 bottom-4 w-80 pointer-events-auto">
          <Card className="h-full bg-black/40 backdrop-blur-md border border-white/20 p-4 overflow-y-auto">
            <h2 className="text-lg font-semibold text-white mb-4">
              {selectedRibbon ? 'Audio Ribbon' : 'AI Prism'}
            </h2>
            
            {selectedRibbon && (
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-white/80">Name</label>
                  <p className="text-white font-medium">{selectedRibbon.name}</p>
                </div>
                <div>
                  <label className="text-sm text-white/80">Genre</label>
                  <p className="text-white">{selectedRibbon.genre}</p>
                </div>
                <div>
                  <label className="text-sm text-white/80">Volume</label>
                  <Slider
                    value={[selectedRibbon.volume]}
                    onValueChange={(value) => {
                      const store = useSonicPrism.getState()
                      store.updateRibbon(selectedRibbon.id, { volume: value[0] })
                    }}
                    max={1}
                    step={0.01}
                    className="mt-2"
                  />
                </div>
              </div>
            )}
            
            {selectedPrism && (
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-white/80">Type</label>
                  <p className="text-white font-medium">{selectedPrism.type}</p>
                </div>
                <div>
                  <label className="text-sm text-white/80">Intensity</label>
                  <Slider
                    value={[selectedPrism.intensity]}
                    onValueChange={(value) => {
                      const store = useSonicPrism.getState()
                      store.updatePrism(selectedPrism.id, { intensity: value[0] })
                    }}
                    max={1}
                    step={0.01}
                    className="mt-2"
                  />
                </div>
              </div>
            )}
          </Card>
        </div>
      )}
      
      {/* Bottom Status Bar - Enhanced */}
      <div className="absolute bottom-4 left-4 right-4 flex items-center justify-center pointer-events-auto">
        <Card className="bg-black/40 backdrop-blur-md border border-white/20 px-6 py-3">
          <div className="flex items-center gap-8 text-xs text-white/60">
            <span className="flex items-center gap-1">
              <Music className="w-3 h-3" />
              {ribbons.length} Ribbons
            </span>
            <span className="flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              {prisms.length} Prisms
            </span>
            <span className="flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              Location: Active
            </span>
            <span className="flex items-center gap-1">
              <Brain className="w-3 h-3" />
              AI SEO: Auto
            </span>
            <span className="flex items-center gap-1">
              <div className={`w-2 h-2 rounded-full ${isPlaying ? 'bg-green-400 animate-pulse' : 'bg-gray-500'}`} />
              {isPlaying ? 'Playing' : 'Stopped'}
            </span>
          </div>
        </Card>
      </div>
    </>
  )
}