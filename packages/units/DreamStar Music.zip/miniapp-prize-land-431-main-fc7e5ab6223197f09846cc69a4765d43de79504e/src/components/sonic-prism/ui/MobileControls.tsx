'use client';

import { useState, useRef } from 'react';
import { useSonicPrism } from '../SonicPrismProvider';
import { Button } from '../../ui/button';
import { Play, Pause, Plus, Mic, Music } from 'lucide-react';

export function MobileControls() {
  const [showOnMobile, setShowOnMobile] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  
  const {
    isPlaying,
    setPlaying,
    generateMusic,
    generateVocals,
    addPrism
  } = useSonicPrism();
  
  // Check if we're on mobile
  useState(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768 || 'ontouchstart' in window);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  });
  
  if (!isMobile) return null;
  
  return (
    <>
      {/* Mobile Control Toggle */}
      <div className="md:hidden absolute bottom-4 right-4 z-50 pointer-events-auto">
        <Button
          onClick={() => setShowOnMobile(!showOnMobile)}
          className="bg-black/60 backdrop-blur-md border border-white/30 text-white w-12 h-12 rounded-full p-0"
        >
          <Plus className={`w-6 h-6 transition-transform ${showOnMobile ? 'rotate-45' : ''}`} />
        </Button>
      </div>
      
      {/* Mobile Control Panel */}
      {showOnMobile && (
        <div className="md:hidden absolute inset-x-4 bottom-20 z-40 pointer-events-auto">
          <div className="bg-black/80 backdrop-blur-md rounded-xl border border-white/20 p-4 space-y-4">
            
            {/* Main Controls */}
            <div className="flex items-center justify-center gap-4">
              <Button
                onClick={() => setPlaying(!isPlaying)}
                className="bg-white/10 hover:bg-white/20 border border-white/30 text-white w-12 h-12 rounded-full p-0"
              >
                {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
              </Button>
            </div>
            
            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-3">
              <Button
                onClick={() => generateMusic('Upbeat electronic dance track')}
                className="bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/30 text-cyan-100 h-12"
              >
                <Music className="w-4 h-4 mr-2" />
                Quick Beat
              </Button>
              
              <Button
                onClick={() => generateVocals('La la la la la')}
                className="bg-pink-500/20 hover:bg-pink-500/30 border border-pink-400/30 text-pink-100 h-12"
              >
                <Mic className="w-4 h-4 mr-2" />
                Add Vocals
              </Button>
            </div>
            
            {/* Prism Shortcuts */}
            <div className="grid grid-cols-2 gap-2">
              <Button
                onClick={() => addPrism({
                  type: 'GenreShift',
                  position: [0, 1, 0],
                  intensity: 0.5,
                  divergence: 0.7,
                  isActive: false,
                  color: '#FF6B35'
                })}
                className="bg-orange-500/20 hover:bg-orange-500/30 border border-orange-400/30 text-orange-100 text-xs h-10"
              >
                Genre Shift
              </Button>
              
              <Button
                onClick={() => addPrism({
                  type: 'Vocalize',
                  position: [2, 1, 0],
                  intensity: 0.4,
                  divergence: 0.3,
                  isActive: false,
                  color: '#FFD700'
                })}
                className="bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-400/30 text-yellow-100 text-xs h-10"
              >
                Vocalize
              </Button>
            </div>
            
            {/* Mobile Instructions */}
            <div className="text-xs text-white/60 text-center space-y-1 pt-2 border-t border-white/20">
              <p>Tap and drag to move around the holographic space</p>
              <p>Pinch to zoom • Touch prisms and ribbons to interact</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Mobile background overlay when controls are open */}
      {showOnMobile && (
        <div 
          className="md:hidden absolute inset-0 bg-black/20 backdrop-blur-sm z-30 pointer-events-auto"
          onClick={() => setShowOnMobile(false)}
        />
      )}
    </>
  );
}