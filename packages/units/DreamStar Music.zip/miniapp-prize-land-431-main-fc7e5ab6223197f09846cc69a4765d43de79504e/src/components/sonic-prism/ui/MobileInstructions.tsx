'use client';

import { useState, useEffect } from 'react';
import { Card } from '../../ui/card';
import { Button } from '../../ui/button';
import { X, Smartphone } from 'lucide-react';

export function MobileInstructions() {
  const [showInstructions, setShowInstructions] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  
  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth < 768 || 'ontouchstart' in window;
      setIsMobile(mobile);
      
      // Auto-show instructions on first mobile visit
      if (mobile && !localStorage.getItem('sonic-prism-mobile-seen')) {
        setShowInstructions(true);
        localStorage.setItem('sonic-prism-mobile-seen', 'true');
      }
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);
  
  if (!isMobile || !showInstructions) return null;
  
  return (
    <div className="absolute inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="bg-black/80 backdrop-blur-md border border-cyan-400/30 p-6 max-w-md w-full">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-cyan-500/20 rounded-full flex items-center justify-center">
              <Smartphone className="w-4 h-4 text-cyan-400" />
            </div>
            <h2 className="text-lg font-semibold text-white">Welcome to Sonic Prism</h2>
          </div>
          <Button
            onClick={() => setShowInstructions(false)}
            className="bg-transparent hover:bg-white/10 text-white p-2 h-auto"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
        
        <div className="space-y-4 text-white/90">
          <p className="text-sm">
            Experience the future of music creation in a holographic interface where audio becomes light and AI transforms sound.
          </p>
          
          <div className="space-y-3 text-sm">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-gradient-to-r from-cyan-400 to-pink-400 rounded-full flex items-center justify-center text-xs font-bold text-black mt-0.5">
                1
              </div>
              <div>
                <p className="font-medium">Navigate the Holographic Space</p>
                <p className="text-white/70 text-xs">Touch and drag to orbit • Pinch to zoom • Explore the void</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-gradient-to-r from-cyan-400 to-pink-400 rounded-full flex items-center justify-center text-xs font-bold text-black mt-0.5">
                2
              </div>
              <div>
                <p className="font-medium">Create Audio Ribbons</p>
                <p className="text-white/70 text-xs">Generate music with AI • Add vocals • Watch your sound become light</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-gradient-to-r from-cyan-400 to-pink-400 rounded-full flex items-center justify-center text-xs font-bold text-black mt-0.5">
                3
              </div>
              <div>
                <p className="font-medium">Transform with AI Prisms</p>
                <p className="text-white/70 text-xs">Drag crystalline prisms to ribbons • Watch genres shift • Experience musical alchemy</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-gradient-to-r from-cyan-400 to-pink-400 rounded-full flex items-center justify-center text-xs font-bold text-black mt-0.5">
                4
              </div>
              <div>
                <p className="font-medium">Mobile Controls</p>
                <p className="text-white/70 text-xs">Tap the + button for quick actions • All tools optimized for touch</p>
              </div>
            </div>
          </div>
          
          <div className="bg-gradient-to-r from-cyan-500/20 to-pink-500/20 rounded-lg p-3 border border-cyan-400/20 mt-6">
            <p className="text-xs text-center text-white/80">
              <span className="font-medium">Tip:</span> For the best experience, use headphones and explore the holographic space in landscape mode
            </p>
          </div>
        </div>
        
        <Button
          onClick={() => setShowInstructions(false)}
          className="w-full mt-6 bg-gradient-to-r from-cyan-500 to-pink-500 hover:from-cyan-600 hover:to-pink-600 text-white font-medium"
        >
          Enter the Sonic Prism
        </Button>
      </Card>
    </div>
  );
}