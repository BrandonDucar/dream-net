'use client';

import { useState } from 'react';
import { useSonicPrism } from '../SonicPrismProvider';
import { Button } from '../../ui/button';
import { Slider } from '../../ui/slider';
import { Input } from '../../ui/input';
import { Card } from '../../ui/card';
import { Play, Pause, Plus, Mic, Music, Volume2, Settings } from 'lucide-react';

export function SonicPrismUI() {
  const {
    isPlaying,
    masterVolume,
    selectedRibbonId,
    selectedPrismId,
    ribbons,
    prisms,
    currentMode,
    setPlaying,
    setMasterVolume,
    generateMusic,
    generateVocals,
    addPrism
  } = useSonicPrism();
  
  const [musicPrompt, setMusicPrompt] = useState('');
  const [vocalText, setVocalText] = useState('');
  const [showAdvanced, setShowAdvanced] = useState(false);
  
  const selectedRibbon = ribbons.find(r => r.id === selectedRibbonId);
  const selectedPrism = prisms.find(p => p.id === selectedPrismId);
  
  const handleGenerateMusic = async () => {
    if (musicPrompt.trim()) {
      await generateMusic(musicPrompt);
      setMusicPrompt('');
    }
  };
  
  const handleGenerateVocals = async () => {
    if (vocalText.trim()) {
      await generateVocals(vocalText, 'Rachel'); // Default voice
      setVocalText('');
    }
  };
  
  const handleAddPrism = (type: 'GenreShift' | 'Cleanup' | 'Harmonize' | 'Vocalize') => {
    const colors = {
      GenreShift: '#FF6B35',
      Cleanup: '#00D4AA',
      Harmonize: '#8A2BE2',
      Vocalize: '#FFD700'
    };
    
    addPrism({
      type,
      position: [Math.random() * 6 - 3, 1, Math.random() * 6 - 3],
      intensity: 0.5,
      divergence: 0.5,
      isActive: false,
      color: colors[type]
    });
  };
  
  return (
    <>
      {/* Top Control Bar */}
      <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-auto z-10">
        <div className="flex items-center gap-4">
          {/* Play/Pause */}
          <Button
            onClick={() => setPlaying(!isPlaying)}
            className="bg-white/10 hover:bg-white/20 border border-white/30 text-white backdrop-blur-sm"
            size="sm"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </Button>
          
          {/* Master Volume */}
          <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-md px-3 py-2 border border-white/20">
            <Volume2 className="w-4 h-4 text-white" />
            <Slider
              value={[masterVolume]}
              onValueChange={(value) => setMasterVolume(value[0])}
              max={1}
              step={0.01}
              className="w-20"
            />
          </div>
        </div>
        
        {/* Logo */}
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white tracking-wider">
            <span className="bg-gradient-to-r from-cyan-400 to-pink-400 bg-clip-text text-transparent">
              SONIC PRISM
            </span>
          </h1>
          <p className="text-xs text-white/60">Holographic Music Studio</p>
        </div>
        
        {/* Settings */}
        <Button
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="bg-white/10 hover:bg-white/20 border border-white/30 text-white backdrop-blur-sm"
          size="sm"
        >
          <Settings className="w-4 h-4" />
        </Button>
      </div>
      
      {/* Left Sidebar - Creation Tools */}
      <div className="absolute left-4 top-20 bottom-4 w-80 pointer-events-auto">
        <Card className="h-full bg-black/40 backdrop-blur-md border border-white/20 p-4 overflow-y-auto">
          <h2 className="text-lg font-semibold text-white mb-4">Creative Tools</h2>
          
          {/* AI Music Generation */}
          <div className="mb-6">
            <h3 className="text-sm font-medium text-white/80 mb-2 flex items-center gap-2">
              <Music className="w-4 h-4" />
              Generate Music
            </h3>
            <div className="space-y-2">
              <Input
                value={musicPrompt}
                onChange={(e) => setMusicPrompt(e.target.value)}
                placeholder="Describe the music you want..."
                className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
              />
              <Button 
                onClick={handleGenerateMusic}
                disabled={!musicPrompt.trim()}
                className="w-full bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/30 text-cyan-100"
                size="sm"
              >
                Generate Track
              </Button>
            </div>
          </div>
          
          {/* AI Vocal Generation */}
          <div className="mb-6">
            <h3 className="text-sm font-medium text-white/80 mb-2 flex items-center gap-2">
              <Mic className="w-4 h-4" />
              Generate Vocals
            </h3>
            <div className="space-y-2">
              <Input
                value={vocalText}
                onChange={(e) => setVocalText(e.target.value)}
                placeholder="Enter lyrics or vocal text..."
                className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
              />
              <Button 
                onClick={handleGenerateVocals}
                disabled={!vocalText.trim()}
                className="w-full bg-pink-500/20 hover:bg-pink-500/30 border border-pink-400/30 text-pink-100"
                size="sm"
              >
                Generate Vocals
              </Button>
            </div>
          </div>
          
          {/* AI Prisms */}
          <div className="mb-6">
            <h3 className="text-sm font-medium text-white/80 mb-2 flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Add AI Prisms
            </h3>
            <div className="grid grid-cols-2 gap-2">
              <Button
                onClick={() => handleAddPrism('GenreShift')}
                className="bg-orange-500/20 hover:bg-orange-500/30 border border-orange-400/30 text-orange-100"
                size="sm"
              >
                Genre Shift
              </Button>
              <Button
                onClick={() => handleAddPrism('Cleanup')}
                className="bg-green-500/20 hover:bg-green-500/30 border border-green-400/30 text-green-100"
                size="sm"
              >
                Cleanup
              </Button>
              <Button
                onClick={() => handleAddPrism('Harmonize')}
                className="bg-purple-500/20 hover:bg-purple-500/30 border border-purple-400/30 text-purple-100"
                size="sm"
              >
                Harmonize
              </Button>
              <Button
                onClick={() => handleAddPrism('Vocalize')}
                className="bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-400/30 text-yellow-100"
                size="sm"
              >
                Vocalize
              </Button>
            </div>
          </div>
          
          {/* Quick Instructions */}
          <div className="text-xs text-white/60 space-y-1">
            <p>• Drag prisms to audio ribbons to transform them</p>
            <p>• Scroll on prisms to adjust intensity</p>
            <p>• Click elements to select and edit</p>
            <p>• Use mouse/touch to navigate the holographic space</p>
          </div>
        </Card>
      </div>
      
      {/* Right Sidebar - Selection Details */}
      {(selectedRibbon || selectedPrism) && (
        <div className="absolute right-4 top-20 bottom-4 w-80 pointer-events-auto">
          <Card className="h-full bg-black/40 backdrop-blur-md border border-white/20 p-4 overflow-y-auto">
            <h2 className="text-lg font-semibold text-white mb-4">
              {selectedRibbon ? 'Audio Ribbon' : 'AI Prism'}
            </h2>
            
            {selectedRibbon && (
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-white/80">Name</label>
                  <p className="text-white font-medium">{selectedRibbon.name}</p>
                </div>
                <div>
                  <label className="text-sm text-white/80">Genre</label>
                  <p className="text-white">{selectedRibbon.genre}</p>
                </div>
                <div>
                  <label className="text-sm text-white/80">Key</label>
                  <p className="text-white">{selectedRibbon.key}</p>
                </div>
                <div>
                  <label className="text-sm text-white/80">BPM</label>
                  <p className="text-white">{selectedRibbon.bpm}</p>
                </div>
                <div>
                  <label className="text-sm text-white/80">Volume</label>
                  <Slider
                    value={[selectedRibbon.volume]}
                    onValueChange={(value) => {
                      const store = useSonicPrism.getState();
                      store.updateRibbon(selectedRibbon.id, { volume: value[0] });
                    }}
                    max={1}
                    step={0.01}
                    className="mt-2"
                  />
                </div>
              </div>
            )}
            
            {selectedPrism && (
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-white/80">Type</label>
                  <p className="text-white font-medium">{selectedPrism.type}</p>
                </div>
                <div>
                  <label className="text-sm text-white/80">Intensity</label>
                  <Slider
                    value={[selectedPrism.intensity]}
                    onValueChange={(value) => {
                      const store = useSonicPrism.getState();
                      store.updatePrism(selectedPrism.id, { intensity: value[0] });
                    }}
                    max={1}
                    step={0.01}
                    className="mt-2"
                  />
                </div>
                <div>
                  <label className="text-sm text-white/80">Divergence</label>
                  <Slider
                    value={[selectedPrism.divergence]}
                    onValueChange={(value) => {
                      const store = useSonicPrism.getState();
                      store.updatePrism(selectedPrism.id, { divergence: value[0] });
                    }}
                    max={1}
                    step={0.01}
                    className="mt-2"
                  />
                </div>
              </div>
            )}
          </Card>
        </div>
      )}
      
      {/* Bottom Status Bar */}
      <div className="absolute bottom-4 left-4 right-4 flex items-center justify-center pointer-events-auto">
        <Card className="bg-black/40 backdrop-blur-md border border-white/20 px-4 py-2">
          <div className="flex items-center gap-6 text-xs text-white/60">
            <span>{ribbons.length} Ribbons</span>
            <span>{prisms.length} Prisms</span>
            <span>Mode: {currentMode}</span>
            <span className="flex items-center gap-1">
              <div className={`w-2 h-2 rounded-full ${isPlaying ? 'bg-green-400 animate-pulse' : 'bg-gray-500'}`} />
              {isPlaying ? 'Playing' : 'Stopped'}
            </span>
          </div>
        </Card>
      </div>
    </>
  );
}