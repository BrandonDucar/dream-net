'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Switch } from '@/components/ui/switch'
import { 
  Crown, 
  Star, 
  Zap, 
  Check, 
  X, 
  CreditCard, 
  Bitcoin,
  Music,
  Heart,
  Download,
  Palette,
  TrendingUp,
  Shield,
  Clock
} from 'lucide-react'
import { toast } from 'sonner'
import { useEnhancedSubscription, type SubscriptionTier } from '@/stores/enhancedSubscriptionStore'

interface EnhancedSubscriptionManagerProps {
  open: boolean
  onClose: () => void
  defaultTab?: 'plans' | 'billing' | 'usage'
}

export function EnhancedSubscriptionManager({ 
  open, 
  onClose, 
  defaultTab = 'plans' 
}: EnhancedSubscriptionManagerProps): JSX.Element {
  const [selectedTab, setSelectedTab] = useState<string>(defaultTab)
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly')
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const [selectedTier, setSelectedTier] = useState<SubscriptionTier | null>(null)
  const [paymentMethod, setPaymentMethod] = useState<'stripe' | 'crypto'>('stripe')

  const { subscription, plans, upgradeSubscription, cancelSubscription, processStripePayment, processCryptoPayment } = useEnhancedSubscription()

  const getTierIcon = (tier: SubscriptionTier): JSX.Element => {
    switch (tier) {
      case 'enterprise': return <Crown className="w-6 h-6 text-yellow-400" />
      case 'pro': return <Star className="w-6 h-6 text-purple-400" />
      default: return <Zap className="w-6 h-6 text-gray-400" />
    }
  }

  const getTierColor = (tier: SubscriptionTier): string => {
    switch (tier) {
      case 'enterprise': return 'from-yellow-400 to-orange-500'
      case 'pro': return 'from-purple-400 to-pink-500'
      default: return 'from-gray-400 to-gray-600'
    }
  }

  const handleUpgrade = async (tier: SubscriptionTier): Promise<void> => {
    if (tier === subscription.tier) return

    setIsLoading(true)
    setSelectedTier(tier)

    try {
      if (paymentMethod === 'stripe') {
        const checkoutUrl = await processStripePayment(tier, billingCycle)
        window.open(checkoutUrl, '_blank')
        toast.success('Redirecting to Stripe checkout...')
      } else {
        const paymentAddress = await processCryptoPayment(tier, billingCycle)
        toast.success(`Send payment to: ${paymentAddress}`)
        // In a real app, you'd show a crypto payment dialog
      }
      
      // The actual subscription update would happen via webhook after payment
      // For demo purposes, we'll simulate it
      setTimeout(async () => {
        const success = await upgradeSubscription(tier, paymentMethod)
        if (success) {
          toast.success(`Successfully upgraded to ${tier}!`)
          onClose()
        }
      }, 3000)

    } catch (error) {
      toast.error('Payment failed. Please try again.')
    } finally {
      setIsLoading(false)
      setSelectedTier(null)
    }
  }

  const handleCancelSubscription = async (): Promise<void> => {
    setIsLoading(true)
    const success = await cancelSubscription()
    
    if (success) {
      toast.success('Subscription cancelled. You\'ll retain access until your current billing period ends.')
    } else {
      toast.error('Failed to cancel subscription. Please contact support.')
    }
    
    setIsLoading(false)
  }

  const getFeatureIcon = (feature: string): JSX.Element => {
    switch (feature) {
      case 'music_playback': return <Music className="w-4 h-4" />
      case 'social_interactions': return <Heart className="w-4 h-4" />
      case 'downloads': return <Download className="w-4 h-4" />
      case 'custom_art_generation': return <Palette className="w-4 h-4" />
      case 'nft_trading': return <TrendingUp className="w-4 h-4" />
      case 'priority_support': return <Shield className="w-4 h-4" />
      case 'early_access': return <Clock className="w-4 h-4" />
      default: return <Check className="w-4 h-4" />
    }
  }

  const keyFeaturesList = {
    free: ['Basic holographic interface', '5 AI generations/month', 'View NFT marketplace'],
    pro: ['Unlimited music playback', 'Social interactions', 'Custom art generation', 'Download tracks', 'Premium analytics'],
    enterprise: ['NFT minting & trading', 'API access', 'Priority support', 'Advanced creator tools', 'Revenue sharing']
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
            Subscription Management
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Unlock the full potential of holographic music creation
          </DialogDescription>
        </DialogHeader>

        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-gray-800">
            <TabsTrigger value="plans">Plans</TabsTrigger>
            <TabsTrigger value="billing">Billing</TabsTrigger>
            <TabsTrigger value="usage">Usage</TabsTrigger>
          </TabsList>

          {/* Plans Tab */}
          <TabsContent value="plans" className="space-y-6">
            {/* Billing Cycle Toggle */}
            <div className="flex items-center justify-center gap-4 mb-6">
              <span className={billingCycle === 'monthly' ? 'font-semibold' : 'text-gray-400'}>Monthly</span>
              <Switch
                checked={billingCycle === 'yearly'}
                onCheckedChange={(checked) => setBillingCycle(checked ? 'yearly' : 'monthly')}
              />
              <span className={billingCycle === 'yearly' ? 'font-semibold' : 'text-gray-400'}>
                Yearly <Badge className="bg-green-600 ml-1">Save 20%</Badge>
              </span>
            </div>

            {/* Subscription Plans */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {plans.map((plan) => {
                const isCurrentPlan = subscription.tier === plan.id
                const price = billingCycle === 'yearly' ? plan.price.yearly : plan.price.monthly
                const yearlyPrice = plan.price.yearly
                const monthlySavings = billingCycle === 'yearly' && yearlyPrice > 0 ? ((plan.price.monthly * 12 - yearlyPrice) / 12).toFixed(0) : 0

                return (
                  <Card key={plan.id} className={`relative ${isCurrentPlan ? 'ring-2 ring-purple-500' : ''} ${plan.popular ? 'border-purple-500 border-2' : 'border-gray-700'} bg-gray-800/50`}>
                    {plan.popular && (
                      <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                        <Badge className="bg-purple-600 text-white px-4 py-1">
                          Most Popular
                        </Badge>
                      </div>
                    )}
                    
                    <CardHeader className="text-center">
                      <div className="flex justify-center mb-3">
                        {getTierIcon(plan.id)}
                      </div>
                      <CardTitle className="text-xl">{plan.name}</CardTitle>
                      <div className="text-3xl font-bold">
                        {price === 0 ? 'Free' : `$${price}`}
                        {price > 0 && (
                          <span className="text-sm font-normal text-gray-400">
                            /{billingCycle === 'yearly' ? 'year' : 'month'}
                          </span>
                        )}
                      </div>
                      {billingCycle === 'yearly' && monthlySavings > 0 && (
                        <p className="text-sm text-green-400">Save $${monthlySavings}/month</p>
                      )}
                      
                      {isCurrentPlan && (
                        <Badge className="bg-green-600 text-white">Current Plan</Badge>
                      )}
                    </CardHeader>

                    <CardContent>
                      {/* Key Features */}
                      <div className="space-y-3 mb-6">
                        {keyFeaturesList[plan.id].map((feature, index) => (
                          <div key={index} className="flex items-center gap-3">
                            <Check className="w-4 h-4 text-green-400 flex-shrink-0" />
                            <span className="text-sm">{feature}</span>
                          </div>
                        ))}
                      </div>

                      {/* Limits */}
                      <div className="bg-gray-700/50 rounded-lg p-3 mb-6">
                        <h4 className="text-sm font-semibold mb-2">Usage Limits</h4>
                        <div className="space-y-1 text-xs text-gray-400">
                          <div className="flex justify-between">
                            <span>AI Generations:</span>
                            <span>{plan.limits.monthly_generations === 500 ? 'Unlimited' : `${plan.limits.monthly_generations}/month`}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Storage:</span>
                            <span>{plan.limits.storage_gb}GB</span>
                          </div>
                          <div className="flex justify-between">
                            <span>NFT Mints:</span>
                            <span>{plan.limits.nft_mints_per_month === 0 ? 'None' : `${plan.limits.nft_mints_per_month}/month`}</span>
                          </div>
                        </div>
                      </div>

                      {/* Action Button */}
                      {isCurrentPlan ? (
                        <Button variant="outline" className="w-full" disabled>
                          Current Plan
                        </Button>
                      ) : plan.id === 'free' ? (
                        <Button 
                          variant="outline" 
                          className="w-full"
                          onClick={() => handleUpgrade('free')}
                          disabled={subscription.tier === 'free'}
                        >
                          Downgrade to Free
                        </Button>
                      ) : (
                        <Button
                          onClick={() => handleUpgrade(plan.id)}
                          className={`w-full bg-gradient-to-r ${getTierColor(plan.id)} hover:opacity-90`}
                          disabled={isLoading}
                        >
                          {isLoading && selectedTier === plan.id ? (
                            <>
                              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2" />
                              Processing...
                            </>
                          ) : (
                            `Upgrade to ${plan.name}`
                          )}
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            {/* Payment Methods */}
            {subscription.tier === 'free' && (
              <div className="bg-gray-800/50 rounded-lg p-6 mt-8">
                <h3 className="text-lg font-semibold mb-4">Payment Methods</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className={`cursor-pointer transition-all ${paymentMethod === 'stripe' ? 'ring-2 ring-blue-500 bg-blue-900/20' : 'bg-gray-700/50 hover:bg-gray-700/70'}`} onClick={() => setPaymentMethod('stripe')}>
                    <CardContent className="p-4 flex items-center gap-3">
                      <CreditCard className="w-6 h-6 text-blue-400" />
                      <div>
                        <h4 className="font-semibold">Card Payment</h4>
                        <p className="text-sm text-gray-400">Visa, Mastercard, PayPal</p>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className={`cursor-pointer transition-all ${paymentMethod === 'crypto' ? 'ring-2 ring-orange-500 bg-orange-900/20' : 'bg-gray-700/50 hover:bg-gray-700/70'}`} onClick={() => setPaymentMethod('crypto')}>
                    <CardContent className="p-4 flex items-center gap-3">
                      <Bitcoin className="w-6 h-6 text-orange-400" />
                      <div>
                        <h4 className="font-semibold">Cryptocurrency</h4>
                        <p className="text-sm text-gray-400">ETH, USDC on Base</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </TabsContent>

          {/* Billing Tab */}
          <TabsContent value="billing" className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle>Current Subscription</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Plan:</span>
                    <span className="font-semibold capitalize">{subscription.tier}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Payment Method:</span>
                    <span className="capitalize">{subscription.payment_method}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Auto Renew:</span>
                    <span>{subscription.auto_renew ? 'Enabled' : 'Disabled'}</span>
                  </div>
                  {subscription.expires_at && (
                    <div className="flex justify-between">
                      <span className="text-gray-400">Next Billing:</span>
                      <span>{new Date(subscription.expires_at).toLocaleDateString()}</span>
                    </div>
                  )}
                </div>

                {subscription.tier !== 'free' && (
                  <div className="pt-4 mt-4 border-t border-gray-700">
                    <Button
                      variant="outline"
                      onClick={handleCancelSubscription}
                      disabled={isLoading}
                      className="text-red-400 border-red-400 hover:bg-red-900/20"
                    >
                      Cancel Subscription
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Billing History */}
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle>Billing History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-gray-400">
                  <CreditCard className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No billing history available</p>
                  <p className="text-sm mt-2">Payment history will appear here after your first transaction</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Usage Tab */}
          <TabsContent value="usage" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-lg">Monthly Usage</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-gray-400">AI Generations</span>
                        <span className="text-sm">0 / {plans.find(p => p.id === subscription.tier)?.limits.monthly_generations || 0}</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div className="bg-purple-600 h-2 rounded-full" style={{ width: '0%' }} />
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-gray-400">Storage Used</span>
                        <span className="text-sm">0 GB / {plans.find(p => p.id === subscription.tier)?.limits.storage_gb || 0} GB</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div className="bg-cyan-600 h-2 rounded-full" style={{ width: '0%' }} />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-gray-400">NFT Mints</span>
                        <span className="text-sm">0 / {plans.find(p => p.id === subscription.tier)?.limits.nft_mints_per_month || 0}</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div className="bg-green-600 h-2 rounded-full" style={{ width: '0%' }} />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-lg">Feature Access</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Object.entries(plans.find(p => p.id === subscription.tier)?.features || {}).map(([feature, enabled]) => (
                      <div key={feature} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {getFeatureIcon(feature)}
                          <span className="text-sm capitalize">{feature.replace(/_/g, ' ')}</span>
                        </div>
                        {enabled ? (
                          <Check className="w-4 h-4 text-green-400" />
                        ) : (
                          <X className="w-4 h-4 text-red-400" />
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}