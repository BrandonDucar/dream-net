'use client';

import { useState } from 'react';
import { useSubscriptionStore, SUBSCRIPTION_FEATURES, SUBSCRIPTION_PRICES, type SubscriptionTier } from '@/stores/subscriptionStore';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Crown, 
  Zap, 
  Music, 
  Mic, 
  Palette, 
  Share, 
  Globe, 
  DollarSign, 
  Shield,
  CheckCircle,
  XCircle,
  CreditCard,
  Bitcoin,
  Loader2
} from 'lucide-react';

export function SubscriptionManager() {
  const {
    currentTier,
    usage,
    upgradeTo,
    downgrade,
    canGenerateMusic,
    canGenerateVocals,
    canTransformAudio,
    getRemainingUsage,
    isProcessingPayment,
    paymentError,
  } = useSubscriptionStore();

  const [selectedTier, setSelectedTier] = useState<SubscriptionTier>('pro');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [paymentMethod, setPaymentMethod] = useState<'stripe' | 'crypto'>('stripe');
  const [showUpgrade, setShowUpgrade] = useState(false);

  const handleUpgrade = async () => {
    const success = await upgradeTo(selectedTier, billingCycle);
    if (success) {
      setShowUpgrade(false);
    }
  };

  const handleDowngrade = async () => {
    await downgrade();
    setShowUpgrade(false);
  };

  const getTierIcon = (tier: SubscriptionTier) => {
    switch (tier) {
      case 'free': return <Music className="h-5 w-5" />;
      case 'pro': return <Zap className="h-5 w-5 text-yellow-500" />;
      case 'enterprise': return <Crown className="h-5 w-5 text-purple-500" />;
    }
  };

  const getTierColor = (tier: SubscriptionTier) => {
    switch (tier) {
      case 'free': return 'bg-gray-100 text-gray-800';
      case 'pro': return 'bg-yellow-100 text-yellow-800';
      case 'enterprise': return 'bg-purple-100 text-purple-800';
    }
  };

  const renderUsageStats = () => (
    <div className="space-y-4">
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span>Music Generations</span>
          <span>{usage.musicGenerationsUsed} / {SUBSCRIPTION_FEATURES[currentTier].musicGenerationsPerMonth === -1 ? '∞' : SUBSCRIPTION_FEATURES[currentTier].musicGenerationsPerMonth}</span>
        </div>
        <Progress 
          value={SUBSCRIPTION_FEATURES[currentTier].musicGenerationsPerMonth === -1 ? 0 : (usage.musicGenerationsUsed / SUBSCRIPTION_FEATURES[currentTier].musicGenerationsPerMonth) * 100} 
          className="h-2" 
        />
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span>Vocal Generations</span>
          <span>{usage.vocalGenerationsUsed} / {SUBSCRIPTION_FEATURES[currentTier].vocalGenerationsPerMonth === -1 ? '∞' : SUBSCRIPTION_FEATURES[currentTier].vocalGenerationsPerMonth}</span>
        </div>
        <Progress 
          value={SUBSCRIPTION_FEATURES[currentTier].vocalGenerationsPerMonth === -1 ? 0 : (usage.vocalGenerationsUsed / SUBSCRIPTION_FEATURES[currentTier].vocalGenerationsPerMonth) * 100} 
          className="h-2" 
        />
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span>AI Transforms</span>
          <span>{usage.aiTransformsUsed} / {SUBSCRIPTION_FEATURES[currentTier].aiTransformsPerMonth === -1 ? '∞' : SUBSCRIPTION_FEATURES[currentTier].aiTransformsPerMonth}</span>
        </div>
        <Progress 
          value={SUBSCRIPTION_FEATURES[currentTier].aiTransformsPerMonth === -1 ? 0 : (usage.aiTransformsUsed / SUBSCRIPTION_FEATURES[currentTier].aiTransformsPerMonth) * 100} 
          className="h-2" 
        />
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span>Tracks Stored</span>
          <span>{usage.tracksStored} / {SUBSCRIPTION_FEATURES[currentTier].trackStorage === -1 ? '∞' : SUBSCRIPTION_FEATURES[currentTier].trackStorage}</span>
        </div>
        <Progress 
          value={SUBSCRIPTION_FEATURES[currentTier].trackStorage === -1 ? 0 : (usage.tracksStored / SUBSCRIPTION_FEATURES[currentTier].trackStorage) * 100} 
          className="h-2" 
        />
      </div>
    </div>
  );

  const renderTierCard = (tier: SubscriptionTier) => {
    const features = SUBSCRIPTION_FEATURES[tier];
    const isCurrentTier = currentTier === tier;
    const price = tier === 'free' ? 0 : SUBSCRIPTION_PRICES[tier][billingCycle];

    return (
      <Card key={tier} className={`relative ${selectedTier === tier ? 'ring-2 ring-blue-500' : ''} ${isCurrentTier ? 'border-green-500' : ''}`}>
        {isCurrentTier && (
          <Badge className="absolute -top-2 left-4 bg-green-500">Current Plan</Badge>
        )}
        
        <CardHeader>
          <CardTitle className="flex items-center gap-2 capitalize">
            {getTierIcon(tier)}
            {tier}
          </CardTitle>
          <CardDescription>
            <span className="text-3xl font-bold">${typeof price === 'number' ? price.toFixed(2) : '0.00'}</span>
            {tier !== 'free' && <span className="text-sm">/{billingCycle}</span>}
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span>Music Generations</span>
              <span className="font-semibold">{features.musicGenerationsPerMonth === -1 ? 'Unlimited' : features.musicGenerationsPerMonth}/month</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Vocal Generations</span>
              <span className="font-semibold">{features.vocalGenerationsPerMonth === -1 ? 'Unlimited' : features.vocalGenerationsPerMonth}/month</span>
            </div>
            <div className="flex items-center justify-between">
              <span>AI Transforms</span>
              <span className="font-semibold">{features.aiTransformsPerMonth === -1 ? 'Unlimited' : features.aiTransformsPerMonth}/month</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Track Storage</span>
              <span className="font-semibold">{features.trackStorage === -1 ? 'Unlimited' : features.trackStorage} tracks</span>
            </div>
          </div>

          <Separator />

          <div className="space-y-2 text-sm">
            {[
              { key: 'highQualityAudio', label: 'High Quality Audio', icon: <Music className="h-4 w-4" /> },
              { key: 'advancedPrisms', label: 'Advanced AI Prisms', icon: <Zap className="h-4 w-4" /> },
              { key: 'collaborativeMode', label: 'Collaborative Mode', icon: <Share className="h-4 w-4" /> },
              { key: 'commercialUse', label: 'Commercial Use', icon: <DollarSign className="h-4 w-4" /> },
              { key: 'aiSeoOptimization', label: 'AI SEO Optimization', icon: <Globe className="h-4 w-4" /> },
              { key: 'customArtGeneration', label: 'Custom Art Generation', icon: <Palette className="h-4 w-4" /> },
              { key: 'monetizationTools', label: 'Monetization Tools', icon: <DollarSign className="h-4 w-4" /> },
              { key: 'prioritySupport', label: 'Priority Support', icon: <Shield className="h-4 w-4" /> },
            ].map(({ key, label, icon }) => (
              <div key={key} className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  {icon}
                  {label}
                </span>
                {features[key as keyof typeof features] ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <XCircle className="h-4 w-4 text-gray-300" />
                )}
              </div>
            ))}
          </div>

          {!isCurrentTier && (
            <Button
              className="w-full"
              variant={selectedTier === tier ? "default" : "outline"}
              onClick={() => setSelectedTier(tier)}
            >
              {tier === 'free' ? 'Downgrade' : 'Select Plan'}
            </Button>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      {/* Current Plan Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {getTierIcon(currentTier)}
            <span className="capitalize">{currentTier} Plan</span>
            <Badge className={getTierColor(currentTier)}>Active</Badge>
          </CardTitle>
          <CardDescription>
            Your current subscription and usage statistics
          </CardDescription>
        </CardHeader>
        <CardContent>
          {renderUsageStats()}
          
          <div className="flex gap-2 mt-4">
            <Dialog open={showUpgrade} onOpenChange={setShowUpgrade}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  {currentTier === 'free' ? 'Upgrade Plan' : 'Manage Subscription'}
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Subscription Plans</DialogTitle>
                  <DialogDescription>
                    Choose the plan that fits your music creation needs
                  </DialogDescription>
                </DialogHeader>

                <div className="space-y-6">
                  {/* Billing Cycle Toggle */}
                  <div className="flex items-center justify-center gap-4">
                    <span className={billingCycle === 'monthly' ? 'font-semibold' : ''}>Monthly</span>
                    <Switch
                      checked={billingCycle === 'yearly'}
                      onCheckedChange={(checked) => setBillingCycle(checked ? 'yearly' : 'monthly')}
                    />
                    <span className={billingCycle === 'yearly' ? 'font-semibold' : ''}>
                      Yearly <Badge variant="secondary">Save 17%</Badge>
                    </span>
                  </div>

                  {/* Plan Cards */}
                  <div className="grid md:grid-cols-3 gap-6">
                    {renderTierCard('free')}
                    {renderTierCard('pro')}
                    {renderTierCard('enterprise')}
                  </div>

                  {/* Payment Method Selection */}
                  {selectedTier !== 'free' && (
                    <div className="space-y-4">
                      <h3 className="font-semibold">Payment Method</h3>
                      <Tabs value={paymentMethod} onValueChange={(value) => setPaymentMethod(value as 'stripe' | 'crypto')}>
                        <TabsList className="grid w-full grid-cols-2">
                          <TabsTrigger value="stripe" className="flex items-center gap-2">
                            <CreditCard className="h-4 w-4" />
                            Credit Card
                          </TabsTrigger>
                          <TabsTrigger value="crypto" className="flex items-center gap-2">
                            <Bitcoin className="h-4 w-4" />
                            Crypto (Base)
                          </TabsTrigger>
                        </TabsList>
                        
                        <TabsContent value="stripe" className="text-center py-4">
                          <p className="text-sm text-muted-foreground">
                            Pay securely with credit card through Stripe
                          </p>
                        </TabsContent>
                        
                        <TabsContent value="crypto" className="text-center py-4">
                          <p className="text-sm text-muted-foreground">
                            Pay with ETH on Base network for lower fees
                          </p>
                        </TabsContent>
                      </Tabs>
                    </div>
                  )}

                  {paymentError && (
                    <div className="text-red-600 text-sm bg-red-50 p-3 rounded-md">
                      {paymentError}
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex justify-end gap-2">
                    {selectedTier === 'free' ? (
                      <Button
                        onClick={handleDowngrade}
                        disabled={isProcessingPayment}
                        variant="destructive"
                      >
                        {isProcessingPayment ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          'Downgrade to Free'
                        )}
                      </Button>
                    ) : (
                      <Button
                        onClick={handleUpgrade}
                        disabled={isProcessingPayment || selectedTier === currentTier}
                      >
                        {isProcessingPayment ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Processing...
                          </>
                        ) : selectedTier === currentTier ? (
                          'Current Plan'
                        ) : (
                          `Upgrade to ${selectedTier}`
                        )}
                      </Button>
                    )}
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>

      {/* Feature Limits Alerts */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card className={!canGenerateMusic() ? 'border-red-200 bg-red-50' : ''}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Music className="h-4 w-4" />
                <span className="text-sm font-medium">Music Generation</span>
              </div>
              <Badge variant={canGenerateMusic() ? "success" : "destructive"}>
                {getRemainingUsage('music') === -1 ? 'Unlimited' : `${getRemainingUsage('music')} left`}
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card className={!canGenerateVocals() ? 'border-red-200 bg-red-50' : ''}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Mic className="h-4 w-4" />
                <span className="text-sm font-medium">Vocal Generation</span>
              </div>
              <Badge variant={canGenerateVocals() ? "success" : "destructive"}>
                {getRemainingUsage('vocals') === -1 ? 'Unlimited' : `${getRemainingUsage('vocals')} left`}
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card className={!canTransformAudio() ? 'border-red-200 bg-red-50' : ''}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Zap className="h-4 w-4" />
                <span className="text-sm font-medium">AI Transforms</span>
              </div>
              <Badge variant={canTransformAudio() ? "success" : "destructive"}>
                {getRemainingUsage('transforms') === -1 ? 'Unlimited' : `${getRemainingUsage('transforms')} left`}
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}