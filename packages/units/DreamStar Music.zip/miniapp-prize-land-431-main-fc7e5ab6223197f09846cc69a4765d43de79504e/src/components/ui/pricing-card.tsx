'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle } from 'lucide-react';
import type { SubscriptionTier, SubscriptionFeatures } from '@/stores/subscriptionStore';

interface PricingCardProps {
  tier: SubscriptionTier;
  features: SubscriptionFeatures;
  price: number;
  billingCycle: 'monthly' | 'yearly';
  isCurrentTier: boolean;
  isSelected: boolean;
  isPopular?: boolean;
  onSelect: () => void;
  onUpgrade: () => void;
}

export function PricingCard({
  tier,
  features,
  price,
  billingCycle,
  isCurrentTier,
  isSelected,
  isPopular,
  onSelect,
  onUpgrade,
}: PricingCardProps) {
  const formatFeatureValue = (value: number | boolean | string[], label: string): string => {
    if (typeof value === 'boolean') {
      return value ? 'Included' : 'Not included';
    }
    if (Array.isArray(value)) {
      return value.join(', ');
    }
    if (value === -1) {
      return 'Unlimited';
    }
    return `${value} ${label}`;
  };

  const getFeatureIcon = (value: number | boolean | string[]) => {
    if (typeof value === 'boolean') {
      return value ? (
        <CheckCircle className="h-4 w-4 text-green-500" />
      ) : (
        <XCircle className="h-4 w-4 text-gray-300" />
      );
    }
    return <CheckCircle className="h-4 w-4 text-green-500" />;
  };

  const tierColors = {
    free: 'from-gray-500 to-gray-600',
    pro: 'from-yellow-500 to-orange-500',
    enterprise: 'from-purple-500 to-pink-500',
  };

  const featureList = [
    { key: 'musicGenerationsPerMonth', label: 'per month', display: 'Music Generations' },
    { key: 'vocalGenerationsPerMonth', label: 'per month', display: 'Vocal Generations' },
    { key: 'aiTransformsPerMonth', label: 'per month', display: 'AI Transforms' },
    { key: 'trackStorage', label: 'tracks', display: 'Track Storage' },
    { key: 'highQualityAudio', label: '', display: 'High Quality Audio' },
    { key: 'advancedPrisms', label: '', display: 'Advanced AI Prisms' },
    { key: 'collaborativeMode', label: '', display: 'Collaborative Mode' },
    { key: 'commercialUse', label: '', display: 'Commercial Use' },
    { key: 'aiSeoOptimization', label: '', display: 'AI SEO Optimization' },
    { key: 'customArtGeneration', label: '', display: 'Custom Art Generation' },
    { key: 'monetizationTools', label: '', display: 'Monetization Tools' },
    { key: 'prioritySupport', label: '', display: 'Priority Support' },
  ];

  return (
    <Card className={`relative transition-all duration-200 ${
      isSelected ? 'ring-2 ring-blue-500 transform scale-105' : ''
    } ${isCurrentTier ? 'border-green-500' : ''} ${
      isPopular ? 'border-yellow-500' : ''
    }`}>
      {isPopular && (
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
          <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white font-semibold px-4 py-1">
            Most Popular
          </Badge>
        </div>
      )}
      
      {isCurrentTier && (
        <div className="absolute -top-3 right-4">
          <Badge className="bg-green-500 text-white">Current Plan</Badge>
        </div>
      )}

      <CardHeader className="text-center pb-4">
        <CardTitle className={`text-2xl font-bold capitalize bg-gradient-to-r ${tierColors[tier]} bg-clip-text text-transparent`}>
          {tier}
        </CardTitle>
        <CardDescription>
          <div className="text-4xl font-bold text-foreground">
            ${price.toFixed(2)}
            <span className="text-lg font-normal text-muted-foreground">
              /{billingCycle}
            </span>
          </div>
          {billingCycle === 'yearly' && tier !== 'free' && (
            <Badge variant="outline" className="mt-2">
              Save {tier === 'pro' ? '17%' : '18%'}
            </Badge>
          )}
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="space-y-3">
          {featureList.map(({ key, label, display }) => {
            const value = features[key as keyof SubscriptionFeatures];
            return (
              <div key={key} className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-2">
                  {getFeatureIcon(value)}
                  {display}
                </span>
                <span className="font-medium text-right">
                  {formatFeatureValue(value, label)}
                </span>
              </div>
            );
          })}
        </div>

        <div className="pt-4 space-y-2">
          {!isCurrentTier && (
            <Button
              className={`w-full ${isSelected ? 'bg-blue-600 hover:bg-blue-700' : ''}`}
              variant={isSelected ? "default" : "outline"}
              onClick={onSelect}
            >
              {tier === 'free' ? 'Downgrade' : 'Select Plan'}
            </Button>
          )}
          
          {isSelected && tier !== 'free' && !isCurrentTier && (
            <Button
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              onClick={onUpgrade}
            >
              Upgrade to {tier}
            </Button>
          )}

          {isCurrentTier && (
            <div className="text-center py-2">
              <Badge className="bg-green-100 text-green-800">
                Active Subscription
              </Badge>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}