// elevenlabs-api.ts
/**
 * ================================================================================
 * DO NOT MODIFY THIS FILE. This file is READ ONLY and is DETERMINISTIC.
 * FAL ElevenLabs TTS v3 — Strict, Typed, and Agent-Ready API
 * ================================================================================
 */

const FAL_TTS_API_KEY = 'secret_cmcawa6x10000356ntm6lutf5';
const FAL_TTS_QUEUE_ORIGIN = 'queue.fal.run';
const FAL_TTS_V3_PATH = '/fal-ai/elevenlabs/tts/eleven-v3';
const FAL_TTS_TURBO_PATH = '/fal-ai/elevenlabs/tts/turbo-v2.5';
const ELEVENLABS_API_KEY = 'secret_cmcawacgd0001356nhef43d6m';
const ELEVENLABS_API_ORIGIN = 'api.elevenlabs.io';

export type TTSFalPrompt = {
  /** Text prompt to convert to speech (required, non-empty) */
  text: string;
  voice?: string;
  stability?: number;
  similarity_boost?: number;
  style?: number;
  speed?: number;
  timestamps?: boolean;
  previous_text?: string;
  next_text?: string;
  language_code?: string;
};

export type TTSFalSubmitResponse = {
  request_id: string;
};

export type TTSFalStatusResponse =
  | { status: 'IN_QUEUE'; request_id: string; queue_position?: number }
  | { status: 'IN_PROGRESS'; request_id: string }
  | { status: 'COMPLETED'; request_id: string }
  | { status: string; request_id: string; [k: string]: any }; // For error/unknown

export type TTSFalAudioResult = {
  audio: {
    url: string; // Always MP3 file, always check presence!
    content_type?: string;
    file_name?: string;
    file_size?: number;
    file_data?: string;
  };
};

function _throwIfInvalid(res: any, keys: string[]) {
  for (const k of keys) {
    if (res == null || res[k] == null || (typeof res[k] === 'string' && !res[k].trim()))
      throw new Error(`TTSFal: Required property "${k}" missing in response.`);
  }
}

function _extractErrorMessage(res: any): string | null {
  if (!res) return null;
  const detail = res.detail;
  if (typeof detail === 'string') return detail;
  if (detail && typeof detail === 'object') {
    for (const key of ['message', 'error', 'status']) {
      const value = detail[key];
      if (typeof value === 'string' && value.trim()) return value;
    }
  }
  if (typeof res.error === 'string' && res.error.trim()) return res.error;
  if (typeof res.message === 'string' && res.message.trim()) return res.message;
  return null;
}

function _isVoiceNotFound(res: any): boolean {
  const message = _extractErrorMessage(res);
  if (!message) return false;
  const normalized = message.toLowerCase();
  return (
    normalized.includes('voice_not_found') ||
    (normalized.includes('voice') && normalized.includes('not found'))
  );
}

async function _proxyTTSFal(options: {
  path: string;
  method?: 'GET' | 'POST';
  body?: any;
}): Promise<any> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Authorization: `Key ${FAL_TTS_API_KEY}`,
  };
  const payload: any = {
    protocol: 'https',
    origin: FAL_TTS_QUEUE_ORIGIN,
    path: options.path,
    method: options.method || 'POST',
    headers,
  };
  if (options.body) payload.body = JSON.stringify(options.body);
  const res = await fetch('/api/proxy', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const status = res.status;
  const raw = await res.text();
  if (!raw) return { __status: status };
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && parsed.__status === undefined)
      parsed.__status = status;
    return parsed;
  } catch {
    return { __status: status, __raw: raw };
  }
}

function _isSandboxNetworkError(res: any): boolean {
  const message = _extractErrorMessage(res);
  if (message) {
    const normalized = message.toLowerCase();
    if (normalized.includes('sandbox') && normalized.includes('port')) return true;
    if (normalized.includes('sandbox') && normalized.includes('closed')) return true;
  }
  if (res?.__status && res.__status >= 500) {
    const raw = typeof res.__raw === 'string' ? res.__raw.toLowerCase() : '';
    if (raw.includes('sandbox') && raw.includes('port')) return true;
  }
  return false;
}

/**
 * Submit a new ElevenLabs v3 TTS generation job.
 * @param input { text: string; voice?: string; ... }
 * @returns request_id (string)
 * @throws if text is missing/empty, or request_id missing in response
 * NOTE: "voice" must be a valid name from listVoicesFal().
 */
export async function ttsFalSubmit(input: TTSFalPrompt): Promise<string> {
  if (!input?.text || typeof input.text !== 'string' || !input.text.trim())
    throw new Error('Text is required and must be a non-empty string.');

  const ensureRange = (value: number, min: number, max: number, name: string) => {
    if (typeof value !== 'number' || Number.isNaN(value) || value < min || value > max)
      throw new Error(`TTSFal: ${name} must be a number between ${min} and ${max}.`);
  };
  const VALID_STABILITY_VALUES = new Set([0, 0.5, 1]);
  const ensureDiscrete = (value: number, allowed: Set<number>, name: string) => {
    const matches = Array.from(allowed.values()).some((allowedValue) =>
      Math.abs(value - allowedValue) < 1e-9
    );
    if (!matches)
      throw new Error(
        `TTSFal: ${name} must be one of ${Array.from(allowed.values()).join(', ')}.`
      );
  };
  if (input.stability !== undefined) {
    ensureRange(input.stability, 0, 1, 'stability');
    ensureDiscrete(input.stability, VALID_STABILITY_VALUES, 'stability');
  }
  if (input.similarity_boost !== undefined)
    ensureRange(input.similarity_boost, 0, 1, 'similarity_boost');
  if (input.style !== undefined) ensureRange(input.style, 0, 1, 'style');
  if (input.speed !== undefined) ensureRange(input.speed, 0.7, 1.2, 'speed');

  const body: any = { text: input.text };
  for (const key of [
    "voice", "stability", "similarity_boost", "style", "speed",
    "timestamps", "previous_text", "next_text", "language_code"
  ]) {
    if (input[key] !== undefined) body[key] = input[key];
  }

  const submit = async (payload: any, path: string) =>
    _proxyTTSFal({ path, method: 'POST', body: payload });

  const handleTurboFallback = async (payload: any) => {
    const turboRes = await submit(payload, FAL_TTS_TURBO_PATH);
    if (turboRes?.request_id) {
      _throwIfInvalid(turboRes, ['request_id']);
      return turboRes.request_id;
    }
    if (_isVoiceNotFound(turboRes) && payload.voice && payload.voice !== 'Rachel') {
      const rachelPayload = { ...payload, voice: 'Rachel' };
      const turboRachel = await submit(rachelPayload, FAL_TTS_TURBO_PATH);
      if (turboRachel?.request_id) {
        console.warn('TTSFal: Falling back to turbo-v2.5 with voice "Rachel" due to sandbox issues.');
        _throwIfInvalid(turboRachel, ['request_id']);
        return turboRachel.request_id;
      }
      const rachelMsg = _extractErrorMessage(turboRachel);
      throw new Error(
        rachelMsg
          ? `FAL ElevenLabs turbo fallback: ${rachelMsg}`
          : 'TTSFal: Missing request_id in turbo fallback (Rachel) response.'
      );
    }
    const turboMsg = _extractErrorMessage(turboRes);
    throw new Error(
      turboMsg
        ? `FAL ElevenLabs turbo fallback: ${turboMsg}`
        : 'TTSFal: Missing request_id in turbo fallback response.'
    );
  };

  const initialRes = await submit(body, FAL_TTS_V3_PATH);
  if (initialRes?.request_id) {
    _throwIfInvalid(initialRes, ['request_id']);
    return initialRes.request_id;
  }

  if (_isSandboxNetworkError(initialRes)) {
    console.warn('TTSFal: eleven-v3 unavailable (sandbox network), retrying with turbo-v2.5.');
    return handleTurboFallback(body);
  }

  if (_isVoiceNotFound(initialRes) && body.voice && body.voice !== 'Rachel') {
    const fallbackBody = { ...body, voice: 'Rachel' };
    const fallbackRes = await submit(fallbackBody, FAL_TTS_V3_PATH);
    if (fallbackRes?.request_id) {
      _throwIfInvalid(fallbackRes, ['request_id']);
      return fallbackRes.request_id;
    }
    const fallbackMessage = _extractErrorMessage(fallbackRes);
    throw new Error(
      fallbackMessage
        ? `FAL ElevenLabs TTS v3: ${fallbackMessage}`
        : 'TTSFal: Missing request_id in fallback response.'
    );
  }

  if (initialRes?.__status && initialRes.__status >= 500) {
    console.warn(
      `TTSFal: eleven-v3 returned status ${initialRes.__status}, attempting turbo-v2.5 fallback.`
    );
    return handleTurboFallback(body);
  }

  const detailMessage = _extractErrorMessage(initialRes);
  throw new Error(
    detailMessage
      ? `FAL ElevenLabs TTS v3: ${detailMessage}`
      : 'TTSFal: Missing request_id in response.'
  );
}

/**
 * Poll for TTS job status. Halts on error or unexpected status.
 * Cycles every 3 seconds until status is "COMPLETED" (max 10 min).
 * @param request_id (string)
 * @throws if request_id is missing, or API returns error/missing fields.
 */
export async function ttsFalPollStatus(
  request_id: string,
  maxAttempts = 200, // 10 min (3s x 200)
  intervalMs = 3000
): Promise<void> {
  if (!request_id || typeof request_id !== 'string')
    throw new Error('Missing request_id');
  let attempts = 0;
  while (true) {
    const res: TTSFalStatusResponse = await _proxyTTSFal({
      path: `/fal-ai/elevenlabs/requests/${request_id}/status`,
      method: 'GET',
    });
    const detailMessage = _extractErrorMessage(res);
    if (detailMessage) {
      throw new Error(`FAL ElevenLabs TTS: ${detailMessage}`);
    }
    _throwIfInvalid(res, ['status', 'request_id']);
    if (res.status === 'COMPLETED') return;
    if (res.status === 'IN_QUEUE' || res.status === 'IN_PROGRESS') {
      await new Promise((r) => setTimeout(r, intervalMs));
      attempts++;
      if (attempts > maxAttempts)
        throw new Error('TTSFal: Timeout waiting for TTS generation');
    } else {
      throw new Error(`TTSFal: Unexpected status "${res.status}" in polling`);
    }
  }
}

/**
 * Fetch TTS result (audio MP3 URL). Polls every 2s until present or throws on error/missing data.
 * @param request_id (string)
 * @returns audio.url (string, always .mp3)
 * @throws if missing/invalid.
 */
export async function ttsFalFetchAudioUrl(
  request_id: string,
  maxAttempts = 120,
  intervalMs = 2000
): Promise<string> {
  if (!request_id || typeof request_id !== 'string')
    throw new Error('Missing request_id');
  let attempts = 0;
  while (true) {
    const res = await _proxyTTSFal({
      path: `/fal-ai/elevenlabs/requests/${request_id}`,
      method: 'GET',
    });
    // FAL may return a detail error object instead of audio
    if (res?.audio?.url) return res.audio.url;
    // Handle FAL error in completed request: detail, status, message, etc
    if (_isVoiceNotFound(res)) {
      throw new Error(
        "FAL ElevenLabs TTS: The selected voice is not supported (voice_not_found). Please use only supported voices (often just 'Rachel')."
      );
    }
    const detailMessage = _extractErrorMessage(res);
    if (detailMessage) {
      throw new Error(`FAL ElevenLabs TTS: ${detailMessage}`);
    }
    if (res?.__status && res.__status >= 400) {
      throw new Error(
        `FAL ElevenLabs TTS: Request failed with status ${res.__status}.`
      );
    }
    await new Promise((r) => setTimeout(r, intervalMs));
    attempts++;
    if (attempts > maxAttempts)
      throw new Error('TTSFal: Timeout waiting for audio result');
  }
}

// voices-fal-elevenlabs.ts
/**
 * List all ElevenLabs voices with metadata, for use with the FAL TTS "voice" parameter.
 * Returns: Array of voices with voice_id, name, category, description, preview_url, etc.
 * NOTE: Pass the "voice_id" field as the `voice` value to FAL's TTS endpoint.
 */
export type ElevenLabsVoice = {
  voice_id: string;
  name: string;
  category: string;
  description?: string | null;
  preview_url?: string;
  labels?: Record<string, string>;
  [key: string]: any;
};
type ListVoicesResponse = {
  voices: ElevenLabsVoice[];
  has_more: boolean;
  total_count: number;
  next_page_token?: string;
};

// You must set your ElevenLabs API key here:

async function _proxyElevenLabsVoices<T = any>(options: {
  path: string;
  method?: "GET" | "POST";
}): Promise<T> {
  const { path, method = "GET" } = options;
  const headers: Record<string, string> = {
    "accept": "*/*",
    "xi-api-key": ELEVENLABS_API_KEY,
  };
  const payload: any = {
    protocol: "https",
    origin: ELEVENLABS_API_ORIGIN,
    path,
    method,
    headers,
  };
  const fetchOpts: any = {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  };
  const res = await fetch("/api/proxy", fetchOpts);

  let json;
  try {
    json = await res.json();
  } catch {
    throw new Error("Invalid JSON from ElevenLabs proxy");
  }
  if (!res.ok || json?.detail || json?.error) {
    throw new Error(
      "ElevenLabs API error: " +
        (json?.detail || json?.error || res.statusText)
    );
  }
  return json;
}

/**
 * Exported function: list all ElevenLabs voices (for FAL TTS voice param).
 */
/**
 * Exported function: list all supported ElevenLabs voices for FAL TTS v3.
 * Use the .voice_id field as the "voice" param for FAL TTS.
 */
export async function listVoicesFal(): Promise<ElevenLabsVoice[]> {
  const result = await _proxyElevenLabsVoices<ListVoicesResponse>({
    path: "/v2/voices?voice_type=default&limit=100",
    method: "GET",
  });
  if (!result.voices) throw new Error("No voices found");
  // Only include legacy voices (those known to be supported by FAL)
  return result.voices;
}
