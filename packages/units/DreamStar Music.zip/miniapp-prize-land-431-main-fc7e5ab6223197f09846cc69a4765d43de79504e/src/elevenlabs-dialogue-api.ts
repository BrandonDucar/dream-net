// elevenlabs-dialogue-api.ts
/**
 * ================================================================================
 * DO NOT MODIFY THIS FILE. This file is READ ONLY and IS DETERMINISTIC.
 * FAL ElevenLabs Text-to-Dialogue v3 — Typed, Agent-Friendly API
 * ================================================================================
 */

const FAL_DIALOGUE_API_KEY = 'secret_cmcawa6x10000356ntm6lutf5';
const FAL_DIALOGUE_QUEUE_ORIGIN = 'queue.fal.run';
const FAL_DIALOGUE_V3_PATH = '/fal-ai/elevenlabs/text-to-dialogue/eleven-v3';

export type DialogueBlock = {
  /** Dialogue line to perform (required, non-empty) */
  text: string;
  /** Voice identifier (name or voice_id) */
  voice: string;
};

export type PronunciationDictionaryLocator = {
  pronunciation_dictionary_id: string;
  version_id?: string;
};

export type DialogueFalPrompt = {
  /** Sequence of dialogue lines to render (required, length >= 1) */
  inputs: DialogueBlock[];
  /** Voice stability preset (0, 0.5, 1) */
  stability?: number;
  /** Boost similarity to the base speaker */
  use_speaker_boost?: boolean;
  /** Optional pronunciation dictionaries (max 3) */
  pronunciation_dictionary_locators?: PronunciationDictionaryLocator[];
  /** Optional deterministic seed */
  seed?: number;
};

export type DialogueFalSubmitResponse = {
  request_id: string;
};

export type DialogueFalStatusResponse =
  | { status: 'IN_QUEUE'; request_id: string; queue_position?: number }
  | { status: 'IN_PROGRESS'; request_id: string }
  | { status: 'COMPLETED'; request_id: string }
  | { status: string; request_id: string; [k: string]: any };

export type DialogueFalAudioResult = {
  audio: {
    url: string;
    content_type?: string;
    file_name?: string;
    file_size?: number;
    file_data?: string;
  };
  seed?: number;
};

function _throwIfInvalid(res: any, keys: string[]) {
  for (const k of keys) {
    if (res == null || res[k] == null || (typeof res[k] === 'string' && !res[k].trim()))
      throw new Error(`DialogueFal: Required property "${k}" missing in response.`);
  }
}

function _extractErrorMessage(res: any): string | null {
  if (!res) return null;
  const detail = res.detail;
  if (typeof detail === 'string') return detail;
  if (detail && typeof detail === 'object') {
    for (const key of ['message', 'error', 'status']) {
      const value = detail[key];
      if (typeof value === 'string' && value.trim()) return value;
    }
  }
  if (typeof res.error === 'string' && res.error.trim()) return res.error;
  if (typeof res.message === 'string' && res.message.trim()) return res.message;
  return null;
}

async function _proxyFalDialogue(options: {
  path: string;
  method?: 'GET' | 'POST';
  body?: any;
}): Promise<any> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Authorization: `Key ${FAL_DIALOGUE_API_KEY}`,
  };
  const payload: any = {
    protocol: 'https',
    origin: FAL_DIALOGUE_QUEUE_ORIGIN,
    path: options.path,
    method: options.method || 'POST',
    headers,
  };
  if (options.body) payload.body = JSON.stringify(options.body);
  const res = await fetch('/api/proxy', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const status = res.status;
  const raw = await res.text();
  if (!raw) return { __status: status };
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && parsed.__status === undefined)
      parsed.__status = status;
    return parsed;
  } catch {
    return { __status: status, __raw: raw };
  }
}

function _ensureDialogueBlocks(blocks: DialogueBlock[]): void {
  if (!Array.isArray(blocks) || blocks.length === 0)
    throw new Error('DialogueFal: inputs must be a non-empty array.');
  blocks.forEach((block, index) => {
    if (!block || typeof block !== 'object')
      throw new Error(`DialogueFal: inputs[${index}] must be an object.`);
    if (!block.text || typeof block.text !== 'string' || !block.text.trim())
      throw new Error(`DialogueFal: inputs[${index}].text must be a non-empty string.`);
    if (!block.voice || typeof block.voice !== 'string' || !block.voice.trim())
      throw new Error(`DialogueFal: inputs[${index}].voice must be a non-empty string.`);
  });
}

function _ensurePronunciationDictionaries(
  locators?: PronunciationDictionaryLocator[]
): void {
  if (!locators) return;
  if (!Array.isArray(locators))
    throw new Error('DialogueFal: pronunciation_dictionary_locators must be an array.');
  if (locators.length > 3)
    throw new Error('DialogueFal: You may provide at most 3 pronunciation dictionary locators.');
  locators.forEach((locator, index) => {
    if (!locator || typeof locator !== 'object')
      throw new Error(
        `DialogueFal: pronunciation_dictionary_locators[${index}] must be an object.`
      );
    if (
      !locator.pronunciation_dictionary_id ||
      typeof locator.pronunciation_dictionary_id !== 'string' ||
      !locator.pronunciation_dictionary_id.trim()
    )
      throw new Error(
        `DialogueFal: pronunciation_dictionary_locators[${index}].pronunciation_dictionary_id must be a non-empty string.`
      );
    if (
      locator.version_id != null &&
      (typeof locator.version_id !== 'string' || !locator.version_id.trim())
    )
      throw new Error(
        `DialogueFal: pronunciation_dictionary_locators[${index}].version_id must be a non-empty string when provided.`
      );
  });
}

export async function dialogueFalSubmit(input: DialogueFalPrompt): Promise<string> {
  if (!input || typeof input !== 'object')
    throw new Error('DialogueFal: input payload is required.');

  _ensureDialogueBlocks(input.inputs);
  _ensurePronunciationDictionaries(input.pronunciation_dictionary_locators);

  const ensureRange = (value: number, min: number, max: number, name: string) => {
    if (typeof value !== 'number' || Number.isNaN(value) || value < min || value > max)
      throw new Error(`DialogueFal: ${name} must be a number between ${min} and ${max}.`);
  };
  const VALID_STABILITY_VALUES = new Set([0, 0.5, 1]);
  const ensureDiscrete = (value: number, allowed: Set<number>, name: string) => {
    const matches = Array.from(allowed.values()).some(
      (allowedValue) => Math.abs(value - allowedValue) < 1e-9
    );
    if (!matches)
      throw new Error(
        `DialogueFal: ${name} must be one of ${Array.from(allowed.values()).join(', ')}.`
      );
  };

  if (input.stability !== undefined) {
    ensureRange(input.stability, 0, 1, 'stability');
    ensureDiscrete(input.stability, VALID_STABILITY_VALUES, 'stability');
  }
  if (input.seed !== undefined && !Number.isFinite(input.seed))
    throw new Error('DialogueFal: seed must be a finite number when provided.');

  const body: any = {
    inputs: input.inputs.map((block) => ({
      text: block.text,
      voice: block.voice,
    })),
  };

  if (input.stability !== undefined) body.stability = input.stability;
  if (typeof input.use_speaker_boost === 'boolean')
    body.use_speaker_boost = input.use_speaker_boost;
  if (input.pronunciation_dictionary_locators?.length)
    body.pronunciation_dictionary_locators = input.pronunciation_dictionary_locators;
  if (typeof input.seed === 'number') body.seed = input.seed;

  const res = await _proxyFalDialogue({
    path: FAL_DIALOGUE_V3_PATH,
    method: 'POST',
    body,
  });

  if (res?.request_id) {
    _throwIfInvalid(res, ['request_id']);
    return res.request_id;
  }

  const detailMessage = _extractErrorMessage(res);
  throw new Error(
    detailMessage
      ? `FAL ElevenLabs Dialogue v3: ${detailMessage}`
      : 'DialogueFal: Missing request_id in response.'
  );
}

export async function dialogueFalPollStatus(
  request_id: string,
  maxAttempts = 200,
  intervalMs = 3000
): Promise<void> {
  if (!request_id || typeof request_id !== 'string')
    throw new Error('DialogueFal: Missing request_id.');
  let attempts = 0;
  while (true) {
    const res: DialogueFalStatusResponse = await _proxyFalDialogue({
      path: `/fal-ai/elevenlabs/requests/${request_id}/status`,
      method: 'GET',
    });
    const detailMessage = _extractErrorMessage(res);
    if (detailMessage) {
      throw new Error(`FAL ElevenLabs Dialogue v3: ${detailMessage}`);
    }
    _throwIfInvalid(res, ['status', 'request_id']);
    if (res.status === 'COMPLETED') return;
    if (res.status === 'IN_QUEUE' || res.status === 'IN_PROGRESS') {
      await new Promise((r) => setTimeout(r, intervalMs));
      attempts++;
      if (attempts > maxAttempts)
        throw new Error('DialogueFal: Timeout waiting for dialogue generation.');
    } else {
      throw new Error(`DialogueFal: Unexpected status "${res.status}" in polling.`);
    }
  }
}

export async function dialogueFalFetchAudioUrl(
  request_id: string,
  maxAttempts = 120,
  intervalMs = 2000
): Promise<string> {
  if (!request_id || typeof request_id !== 'string')
    throw new Error('DialogueFal: Missing request_id.');
  let attempts = 0;
  while (true) {
    const res: DialogueFalAudioResult & { __status?: number } = await _proxyFalDialogue({
      path: `/fal-ai/elevenlabs/requests/${request_id}`,
      method: 'GET',
    });
    if (res?.audio?.url) return res.audio.url;
    const detailMessage = _extractErrorMessage(res);
    if (detailMessage) {
      throw new Error(`FAL ElevenLabs Dialogue v3: ${detailMessage}`);
    }
    if (res?.__status && res.__status >= 400) {
      throw new Error(
        `FAL ElevenLabs Dialogue v3: Request failed with status ${res.__status}.`
      );
    }
    await new Promise((r) => setTimeout(r, intervalMs));
    attempts++;
    if (attempts > maxAttempts)
      throw new Error('DialogueFal: Timeout waiting for dialogue audio result.');
  }
}
