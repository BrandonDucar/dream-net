'use client'

import { useState, useEffect, useCallback } from 'react'

export interface Location {
  lat: number
  lng: number
  accuracy?: number
}

export interface MusicGeofence {
  id: string
  center: Location
  radius: number // meters
  genre: string
  venue: string
  playlists: string[]
  mood: string
  aiPrompts: string[]
}

// Premium music venues and districts with AI-curated content
export const MUSIC_GEOFENCES: MusicGeofence[] = [
  {
    id: 'nyc-times-square',
    center: { lat: 40.7589, lng: -73.9851 },
    radius: 800,
    genre: 'electronic',
    venue: 'NYC Times Square',
    playlists: ['Electronic City Vibes', 'Neon Nights', 'Urban Pulse'],
    mood: 'energetic',
    aiPrompts: ['upbeat electronic music for city nightlife', 'neon-lit dance tracks', 'urban electronic energy']
  },
  {
    id: 'la-sunset-strip',
    center: { lat: 34.0901, lng: -118.3850 },
    radius: 1200,
    genre: 'rock',
    venue: 'Sunset Strip',
    playlists: ['Rock Legends', 'Sunset Vibes', 'LA Dreams'],
    mood: 'rebellious',
    aiPrompts: ['classic rock for california highways', 'sunset strip legends', 'rebellious rock anthems']
  },
  {
    id: 'nashville-music-row',
    center: { lat: 36.1537, lng: -86.7956 },
    radius: 600,
    genre: 'country',
    venue: 'Music Row Nashville',
    playlists: ['Country Roads', 'Nashville Nights', 'Honky Tonk'],
    mood: 'soulful',
    aiPrompts: ['authentic country music for music city', 'nashville songwriter vibes', 'honky tonk classics']
  },
  {
    id: 'new-orleans-french-quarter',
    center: { lat: 29.9584, lng: -90.0644 },
    radius: 500,
    genre: 'jazz',
    venue: 'French Quarter',
    playlists: ['Jazz Quarter', 'Bourbon Street Blues', 'NOLA Soul'],
    mood: 'smooth',
    aiPrompts: ['smooth jazz for french quarter evenings', 'new orleans blues and soul', 'bourbon street saxophone']
  },
  {
    id: 'austin-6th-street',
    center: { lat: 30.2672, lng: -97.7431 },
    radius: 700,
    genre: 'indie',
    venue: '6th Street Austin',
    playlists: ['Indie Austin', 'SXSW Vibes', 'Live Music Capital'],
    mood: 'creative',
    aiPrompts: ['indie music for austin venues', 'sxsw discovery tracks', 'texas indie rock scene']
  },
  {
    id: 'miami-south-beach',
    center: { lat: 25.7814, lng: -80.1300 },
    radius: 900,
    genre: 'latin',
    venue: 'South Beach Miami',
    playlists: ['Miami Heat', 'Latin Fusion', 'Beach Party'],
    mood: 'tropical',
    aiPrompts: ['latin music for miami beaches', 'tropical house fusion', 'south beach party vibes']
  },
  {
    id: 'seattle-capitol-hill',
    center: { lat: 47.6147, lng: -122.3200 },
    radius: 650,
    genre: 'grunge',
    venue: 'Capitol Hill Seattle',
    playlists: ['Grunge Revival', 'Seattle Sound', 'Coffee Shop Vibes'],
    mood: 'alternative',
    aiPrompts: ['grunge music for seattle coffee shops', 'alternative rock rainy days', 'pacific northwest indie']
  },
  {
    id: 'detroit-downtown',
    center: { lat: 42.3314, lng: -83.0458 },
    radius: 800,
    genre: 'techno',
    venue: 'Detroit Downtown',
    playlists: ['Detroit Techno', 'Motor City Beats', 'Underground'],
    mood: 'industrial',
    aiPrompts: ['detroit techno industrial beats', 'motor city underground', 'mechanical rhythm tracks']
  }
]

// Haversine distance calculation
const calculateDistance = (point1: Location, point2: Location): number => {
  const R = 6371000 // Earth's radius in meters
  const φ1 = (point1.lat * Math.PI) / 180
  const φ2 = (point2.lat * Math.PI) / 180
  const Δφ = ((point2.lat - point1.lat) * Math.PI) / 180
  const Δλ = ((point2.lng - point1.lng) * Math.PI) / 180

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ / 2) * Math.sin(Δλ / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

  return R * c
}

// Check if position is within geofence
const isWithinGeofence = (position: Location, geofence: MusicGeofence): boolean => {
  const distance = calculateDistance(position, geofence.center)
  return distance <= geofence.radius
}

export interface GeofencingState {
  currentPosition: Location | null
  activeGeofence: MusicGeofence | null
  nearbyGeofences: MusicGeofence[]
  locationError: string | null
  isTracking: boolean
}

export function useGeofencing() {
  const [state, setState] = useState<GeofencingState>({
    currentPosition: null,
    activeGeofence: null,
    nearbyGeofences: [],
    locationError: null,
    isTracking: false
  })

  const updatePosition = useCallback((position: GeolocationPosition) => {
    const currentLocation: Location = {
      lat: position.coords.latitude,
      lng: position.coords.longitude,
      accuracy: position.coords.accuracy
    }

    // Find active geofence
    const activeGeofence = MUSIC_GEOFENCES.find(geofence =>
      isWithinGeofence(currentLocation, geofence)
    )

    // Find nearby geofences (within 5km)
    const nearbyGeofences = MUSIC_GEOFENCES.filter(geofence => {
      const distance = calculateDistance(currentLocation, geofence.center)
      return distance <= 5000 && distance > geofence.radius
    }).sort((a, b) => {
      const distA = calculateDistance(currentLocation, a.center)
      const distB = calculateDistance(currentLocation, b.center)
      return distA - distB
    })

    setState(prev => ({
      ...prev,
      currentPosition: currentLocation,
      activeGeofence: activeGeofence || null,
      nearbyGeofences,
      locationError: null
    }))
  }, [])

  const handleLocationError = useCallback((error: GeolocationPositionError) => {
    let errorMessage = 'Location access denied'
    
    switch (error.code) {
      case error.PERMISSION_DENIED:
        errorMessage = 'Location access denied. Enable location services for music discovery.'
        break
      case error.POSITION_UNAVAILABLE:
        errorMessage = 'Location information unavailable.'
        break
      case error.TIMEOUT:
        errorMessage = 'Location request timed out.'
        break
    }

    setState(prev => ({
      ...prev,
      locationError: errorMessage,
      isTracking: false
    }))
  }, [])

  const startTracking = useCallback(() => {
    if (!navigator.geolocation) {
      setState(prev => ({
        ...prev,
        locationError: 'Geolocation not supported by this browser'
      }))
      return
    }

    setState(prev => ({ ...prev, isTracking: true, locationError: null }))

    // Watch position with high accuracy
    const watchId = navigator.geolocation.watchPosition(
      updatePosition,
      handleLocationError,
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 30000 // 30 seconds
      }
    )

    return () => {
      navigator.geolocation.clearWatch(watchId)
      setState(prev => ({ ...prev, isTracking: false }))
    }
  }, [updatePosition, handleLocationError])

  const stopTracking = useCallback(() => {
    setState(prev => ({
      ...prev,
      isTracking: false,
      currentPosition: null,
      activeGeofence: null,
      nearbyGeofences: []
    }))
  }, [])

  // Get AI prompts for current location
  const getLocationAIPrompts = useCallback(() => {
    if (state.activeGeofence) {
      return state.activeGeofence.aiPrompts
    }
    return ['ambient music for current location', 'local soundscape inspiration', 'regional musical influence']
  }, [state.activeGeofence])

  // Get location-based genre recommendations
  const getLocationGenres = useCallback(() => {
    const genres = new Set<string>()
    
    if (state.activeGeofence) {
      genres.add(state.activeGeofence.genre)
    }
    
    state.nearbyGeofences.forEach(geofence => {
      genres.add(geofence.genre)
    })

    return Array.from(genres)
  }, [state.activeGeofence, state.nearbyGeofences])

  return {
    ...state,
    startTracking,
    stopTracking,
    getLocationAIPrompts,
    getLocationGenres,
    calculateDistance
  }
}