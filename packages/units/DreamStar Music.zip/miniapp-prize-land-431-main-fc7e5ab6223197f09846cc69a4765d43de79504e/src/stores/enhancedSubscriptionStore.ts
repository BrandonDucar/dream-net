'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type SubscriptionTier = 'free' | 'pro' | 'enterprise'

export interface SubscriptionFeatures {
  // Music Features
  music_playback: boolean
  unlimited_plays: boolean
  downloads: boolean
  high_quality_audio: boolean
  
  // Social Features
  social_interactions: boolean
  community_posting: boolean
  leaderboard_access: boolean
  
  // Creation Features
  ai_music_generation: boolean
  advanced_ai_features: boolean
  custom_art_generation: boolean
  holographic_interface: boolean
  
  // NFT Features
  nft_minting: boolean
  nft_trading: boolean
  nft_marketplace_access: boolean
  
  // Monetization Features
  revenue_sharing: boolean
  premium_analytics: boolean
  creator_tools: boolean
  
  // Platform Features
  priority_support: boolean
  early_access: boolean
  api_access: boolean
}

export interface SubscriptionPlan {
  id: SubscriptionTier
  name: string
  price: {
    monthly: number
    yearly: number
  }
  features: SubscriptionFeatures
  limits: {
    monthly_generations: number
    storage_gb: number
    nft_mints_per_month: number
  }
  popular?: boolean
}

export interface UserSubscription {
  tier: SubscriptionTier
  expires_at: string | null
  created_at: string
  payment_method: 'stripe' | 'crypto' | 'free'
  auto_renew: boolean
}

interface SubscriptionStore {
  subscription: UserSubscription
  plans: SubscriptionPlan[]
  
  // Actions
  updateSubscription: (subscription: Partial<UserSubscription>) => void
  checkFeatureAccess: (feature: keyof SubscriptionFeatures) => boolean
  getUsageLimits: () => SubscriptionPlan['limits']
  upgradeSubscription: (tier: SubscriptionTier, paymentMethod: 'stripe' | 'crypto') => Promise<boolean>
  cancelSubscription: () => Promise<boolean>
  
  // Payment Methods
  processStripePayment: (tier: SubscriptionTier, billingCycle: 'monthly' | 'yearly') => Promise<string>
  processCryptoPayment: (tier: SubscriptionTier, billingCycle: 'monthly' | 'yearly') => Promise<string>
}

const SUBSCRIPTION_PLANS: SubscriptionPlan[] = [
  {
    id: 'free',
    name: 'Free Tier',
    price: { monthly: 0, yearly: 0 },
    features: {
      music_playback: false, // Limited plays per day
      unlimited_plays: false,
      downloads: false,
      high_quality_audio: false,
      social_interactions: false, // Can't like, comment, or interact
      community_posting: false,
      leaderboard_access: false,
      ai_music_generation: true, // 5 per month
      advanced_ai_features: false,
      custom_art_generation: false,
      holographic_interface: true, // Basic version
      nft_minting: false,
      nft_trading: false,
      nft_marketplace_access: true, // View only
      revenue_sharing: false,
      premium_analytics: false,
      creator_tools: false,
      priority_support: false,
      early_access: false,
      api_access: false
    },
    limits: {
      monthly_generations: 5,
      storage_gb: 0.5,
      nft_mints_per_month: 0
    }
  },
  {
    id: 'pro',
    name: 'Pro Creator',
    price: { monthly: 19, yearly: 190 }, // ~17/month yearly
    features: {
      music_playback: true,
      unlimited_plays: true,
      downloads: true,
      high_quality_audio: true,
      social_interactions: true,
      community_posting: true,
      leaderboard_access: true,
      ai_music_generation: true,
      advanced_ai_features: true, // Genre fusion, mood analysis
      custom_art_generation: true,
      holographic_interface: true, // Full version
      nft_minting: false, // Still requires Enterprise
      nft_trading: false,
      nft_marketplace_access: true,
      revenue_sharing: true, // 70/30 split
      premium_analytics: true,
      creator_tools: true,
      priority_support: true,
      early_access: true,
      api_access: false
    },
    limits: {
      monthly_generations: 100,
      storage_gb: 10,
      nft_mints_per_month: 0
    },
    popular: true
  },
  {
    id: 'enterprise',
    name: 'Enterprise Studio',
    price: { monthly: 49, yearly: 490 }, // ~41/month yearly
    features: {
      music_playback: true,
      unlimited_plays: true,
      downloads: true,
      high_quality_audio: true,
      social_interactions: true,
      community_posting: true,
      leaderboard_access: true,
      ai_music_generation: true,
      advanced_ai_features: true,
      custom_art_generation: true,
      holographic_interface: true,
      nft_minting: true, // Full NFT capabilities
      nft_trading: true,
      nft_marketplace_access: true,
      revenue_sharing: true, // 80/20 split (better for creators)
      premium_analytics: true,
      creator_tools: true,
      priority_support: true,
      early_access: true,
      api_access: true
    },
    limits: {
      monthly_generations: 500,
      storage_gb: 100,
      nft_mints_per_month: 50
    }
  }
]

export const useEnhancedSubscription = create<SubscriptionStore>()(
  persist(
    (set, get) => ({
      subscription: {
        tier: 'free',
        expires_at: null,
        created_at: new Date().toISOString(),
        payment_method: 'free',
        auto_renew: false
      },
      plans: SUBSCRIPTION_PLANS,

      updateSubscription: (updates) => {
        set((state) => ({
          subscription: { ...state.subscription, ...updates }
        }))
      },

      checkFeatureAccess: (feature) => {
        const { subscription, plans } = get()
        const currentPlan = plans.find(p => p.id === subscription.tier)
        
        if (!currentPlan) return false
        
        // Check if subscription is expired
        if (subscription.expires_at && new Date(subscription.expires_at) < new Date()) {
          // Downgrade to free if expired
          set((state) => ({
            subscription: { ...state.subscription, tier: 'free' }
          }))
          return SUBSCRIPTION_PLANS[0].features[feature]
        }
        
        return currentPlan.features[feature]
      },

      getUsageLimits: () => {
        const { subscription, plans } = get()
        const currentPlan = plans.find(p => p.id === subscription.tier)
        return currentPlan?.limits || SUBSCRIPTION_PLANS[0].limits
      },

      upgradeSubscription: async (tier, paymentMethod) => {
        try {
          // This would integrate with your payment processor
          const response = await fetch('/api/subscription/upgrade', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ tier, paymentMethod })
          })

          if (response.ok) {
            const data = await response.json()
            set((state) => ({
              subscription: {
                ...state.subscription,
                tier,
                payment_method: paymentMethod,
                expires_at: data.expires_at,
                auto_renew: true
              }
            }))
            return true
          }
          return false
        } catch (error) {
          console.error('Upgrade failed:', error)
          return false
        }
      },

      cancelSubscription: async () => {
        try {
          const response = await fetch('/api/subscription/cancel', {
            method: 'POST'
          })

          if (response.ok) {
            set((state) => ({
              subscription: {
                ...state.subscription,
                auto_renew: false
              }
            }))
            return true
          }
          return false
        } catch (error) {
          console.error('Cancel failed:', error)
          return false
        }
      },

      processStripePayment: async (tier, billingCycle) => {
        const plan = SUBSCRIPTION_PLANS.find(p => p.id === tier)
        if (!plan) throw new Error('Plan not found')

        const amount = billingCycle === 'yearly' ? plan.price.yearly : plan.price.monthly
        
        const response = await fetch('/api/payments/stripe/create-checkout', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            tier,
            billingCycle,
            amount,
            currency: 'usd'
          })
        })

        const data = await response.json()
        return data.checkout_url // Return Stripe checkout URL
      },

      processCryptoPayment: async (tier, billingCycle) => {
        const plan = SUBSCRIPTION_PLANS.find(p => p.id === tier)
        if (!plan) throw new Error('Plan not found')

        const usdAmount = billingCycle === 'yearly' ? plan.price.yearly : plan.price.monthly
        
        const response = await fetch('/api/payments/crypto/create-payment', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            tier,
            billingCycle,
            usdAmount,
            blockchain: 'base' // Default to Base for lower fees
          })
        })

        const data = await response.json()
        return data.payment_address // Return crypto payment address
      }
    }),
    {
      name: 'enhanced-subscription-storage',
      version: 1
    }
  )
)