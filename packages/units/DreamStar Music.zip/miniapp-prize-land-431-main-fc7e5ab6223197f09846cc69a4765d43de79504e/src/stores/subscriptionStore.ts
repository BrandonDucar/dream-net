'use client';

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// Subscription tiers and features
export type SubscriptionTier = 'free' | 'pro' | 'enterprise';

export interface SubscriptionFeatures {
  // Music creation limits
  musicGenerationsPerMonth: number;
  vocalGenerationsPerMonth: number;
  aiTransformsPerMonth: number;
  
  // Quality & Features
  highQualityAudio: boolean;
  advancedPrisms: boolean;
  customGenres: boolean;
  collaborativeMode: boolean;
  
  // Export & Sharing
  exportFormats: string[];
  socialSharing: boolean;
  commercialUse: boolean;
  
  // Storage & History
  trackStorage: number; // Number of tracks
  projectHistory: number; // Days of history
  
  // Advanced Features
  aiSeoOptimization: boolean;
  geofencingFeatures: boolean;
  competitiveAnalysis: boolean;
  customArtGeneration: boolean;
  
  // Revenue Features
  monetizationTools: boolean;
  revenueSharing: boolean;
  nftMinting: boolean;
  
  // Support & Analytics
  prioritySupport: boolean;
  advancedAnalytics: boolean;
  apiAccess: boolean;
}

export const SUBSCRIPTION_FEATURES: Record<SubscriptionTier, SubscriptionFeatures> = {
  free: {
    musicGenerationsPerMonth: 10,
    vocalGenerationsPerMonth: 5,
    aiTransformsPerMonth: 20,
    
    highQualityAudio: false,
    advancedPrisms: false,
    customGenres: false,
    collaborativeMode: false,
    
    exportFormats: ['mp3'],
    socialSharing: true,
    commercialUse: false,
    
    trackStorage: 5,
    projectHistory: 7,
    
    aiSeoOptimization: false,
    geofencingFeatures: false,
    competitiveAnalysis: false,
    customArtGeneration: false,
    
    monetizationTools: false,
    revenueSharing: false,
    nftMinting: false,
    
    prioritySupport: false,
    advancedAnalytics: false,
    apiAccess: false,
  },
  pro: {
    musicGenerationsPerMonth: 100,
    vocalGenerationsPerMonth: 50,
    aiTransformsPerMonth: 200,
    
    highQualityAudio: true,
    advancedPrisms: true,
    customGenres: true,
    collaborativeMode: true,
    
    exportFormats: ['mp3', 'wav', 'flac'],
    socialSharing: true,
    commercialUse: true,
    
    trackStorage: 100,
    projectHistory: 90,
    
    aiSeoOptimization: true,
    geofencingFeatures: true,
    competitiveAnalysis: true,
    customArtGeneration: true,
    
    monetizationTools: true,
    revenueSharing: true,
    nftMinting: false,
    
    prioritySupport: true,
    advancedAnalytics: true,
    apiAccess: false,
  },
  enterprise: {
    musicGenerationsPerMonth: -1, // Unlimited
    vocalGenerationsPerMonth: -1,
    aiTransformsPerMonth: -1,
    
    highQualityAudio: true,
    advancedPrisms: true,
    customGenres: true,
    collaborativeMode: true,
    
    exportFormats: ['mp3', 'wav', 'flac', 'stems', '24bit'],
    socialSharing: true,
    commercialUse: true,
    
    trackStorage: -1, // Unlimited
    projectHistory: -1, // Unlimited
    
    aiSeoOptimization: true,
    geofencingFeatures: true,
    competitiveAnalysis: true,
    customArtGeneration: true,
    
    monetizationTools: true,
    revenueSharing: true,
    nftMinting: true,
    
    prioritySupport: true,
    advancedAnalytics: true,
    apiAccess: true,
  },
};

export const SUBSCRIPTION_PRICES = {
  pro: {
    monthly: 29.99,
    yearly: 299.99, // 2 months free
  },
  enterprise: {
    monthly: 99.99,
    yearly: 999.99, // 2 months free
  },
};

export interface UsageStats {
  musicGenerationsUsed: number;
  vocalGenerationsUsed: number;
  aiTransformsUsed: number;
  tracksStored: number;
  lastResetDate: string;
}

export interface SubscriptionState {
  // Current subscription
  currentTier: SubscriptionTier;
  isActive: boolean;
  expiresAt?: string;
  paymentMethod?: string;
  
  // Usage tracking
  usage: UsageStats;
  
  // User preferences
  autoRenew: boolean;
  billingCycle: 'monthly' | 'yearly';
  
  // Payment processing
  isProcessingPayment: boolean;
  paymentError?: string;
  
  // Actions
  upgradeTo: (tier: SubscriptionTier, billingCycle: 'monthly' | 'yearly') => Promise<boolean>;
  downgrade: () => Promise<boolean>;
  updateUsage: (usage: Partial<UsageStats>) => void;
  resetUsage: () => void;
  canUseFeature: (feature: keyof SubscriptionFeatures) => boolean;
  getRemainingUsage: (feature: 'music' | 'vocals' | 'transforms') => number;
  setPaymentProcessing: (processing: boolean, error?: string) => void;
  
  // Feature checkers
  canGenerateMusic: () => boolean;
  canGenerateVocals: () => boolean;
  canTransformAudio: () => boolean;
  canStoreTrack: () => boolean;
}

export const useSubscriptionStore = create<SubscriptionState>()(
  persist(
    (set, get) => ({
      // Initial state
      currentTier: 'free',
      isActive: true,
      autoRenew: true,
      billingCycle: 'monthly',
      isProcessingPayment: false,
      
      usage: {
        musicGenerationsUsed: 0,
        vocalGenerationsUsed: 0,
        aiTransformsUsed: 0,
        tracksStored: 0,
        lastResetDate: new Date().toISOString(),
      },
      
      // Actions
      upgradeTo: async (tier, billingCycle) => {
        set({ isProcessingPayment: true, paymentError: undefined });
        
        try {
          // Mock payment processing - replace with actual Stripe/Thirdweb integration
          await new Promise(resolve => setTimeout(resolve, 2000));
          
          // Update subscription
          set({
            currentTier: tier,
            isActive: true,
            billingCycle,
            expiresAt: new Date(Date.now() + (billingCycle === 'yearly' ? 365 : 30) * 24 * 60 * 60 * 1000).toISOString(),
            isProcessingPayment: false,
          });
          
          // Reset usage for new tier
          get().resetUsage();
          
          return true;
        } catch (error) {
          set({ 
            isProcessingPayment: false, 
            paymentError: error instanceof Error ? error.message : 'Payment failed' 
          });
          return false;
        }
      },
      
      downgrade: async () => {
        set({ isProcessingPayment: true });
        
        try {
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          set({
            currentTier: 'free',
            isActive: true,
            expiresAt: undefined,
            isProcessingPayment: false,
            autoRenew: false,
          });
          
          get().resetUsage();
          return true;
        } catch (error) {
          set({ isProcessingPayment: false });
          return false;
        }
      },
      
      updateUsage: (newUsage) => {
        set(state => ({
          usage: { ...state.usage, ...newUsage }
        }));
      },
      
      resetUsage: () => {
        set({
          usage: {
            musicGenerationsUsed: 0,
            vocalGenerationsUsed: 0,
            aiTransformsUsed: 0,
            tracksStored: get().usage.tracksStored, // Keep stored tracks
            lastResetDate: new Date().toISOString(),
          }
        });
      },
      
      canUseFeature: (feature) => {
        const { currentTier } = get();
        const features = SUBSCRIPTION_FEATURES[currentTier];
        return features[feature] as boolean;
      },
      
      getRemainingUsage: (feature) => {
        const { currentTier, usage } = get();
        const features = SUBSCRIPTION_FEATURES[currentTier];
        
        switch (feature) {
          case 'music':
            const musicLimit = features.musicGenerationsPerMonth;
            return musicLimit === -1 ? -1 : Math.max(0, musicLimit - usage.musicGenerationsUsed);
          case 'vocals':
            const vocalLimit = features.vocalGenerationsPerMonth;
            return vocalLimit === -1 ? -1 : Math.max(0, vocalLimit - usage.vocalGenerationsUsed);
          case 'transforms':
            const transformLimit = features.aiTransformsPerMonth;
            return transformLimit === -1 ? -1 : Math.max(0, transformLimit - usage.aiTransformsUsed);
          default:
            return 0;
        }
      },
      
      setPaymentProcessing: (processing, error) => {
        set({ isProcessingPayment: processing, paymentError: error });
      },
      
      // Feature checkers
      canGenerateMusic: () => {
        const remaining = get().getRemainingUsage('music');
        return remaining === -1 || remaining > 0;
      },
      
      canGenerateVocals: () => {
        const remaining = get().getRemainingUsage('vocals');
        return remaining === -1 || remaining > 0;
      },
      
      canTransformAudio: () => {
        const remaining = get().getRemainingUsage('transforms');
        return remaining === -1 || remaining > 0;
      },
      
      canStoreTrack: () => {
        const { currentTier, usage } = get();
        const features = SUBSCRIPTION_FEATURES[currentTier];
        const storageLimit = features.trackStorage;
        return storageLimit === -1 || usage.tracksStored < storageLimit;
      },
    }),
    {
      name: 'sonic-prism-subscription',
      partialize: (state) => ({
        currentTier: state.currentTier,
        isActive: state.isActive,
        expiresAt: state.expiresAt,
        usage: state.usage,
        autoRenew: state.autoRenew,
        billingCycle: state.billingCycle,
      }),
    }
  )
);