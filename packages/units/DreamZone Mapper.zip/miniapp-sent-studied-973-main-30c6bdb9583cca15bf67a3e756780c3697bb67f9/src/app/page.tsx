'use client'
import { useState, useEffect } from 'react';
import type { ReactElement } from 'react';
import { GoalSelection } from '@/components/dreamzone/goal-selection';
import { LocationInput } from '@/components/dreamzone/location-input';
import { Recommendations } from '@/components/dreamzone/recommendations';
import { Favorites } from '@/components/dreamzone/favorites';
import type { Recommendation, Goal } from '@/types/dreamzone';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DreamZoneMapper(): ReactElement {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [step, setStep] = useState<number>(1);
  const [selectedGoal, setSelectedGoal] = useState<Goal | null>(null);
  const [location, setLocation] = useState<string>('');
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [favorites, setFavorites] = useState<Recommendation[]>([]);
  const [showFavorites, setShowFavorites] = useState<boolean>(false);

  const handleGoalSelect = (goal: Goal): void => {
    setSelectedGoal(goal);
    setStep(2);
  };

  const handleLocationSubmit = (loc: string): void => {
    setLocation(loc);
    generateRecommendations(selectedGoal!, loc);
    setStep(3);
  };

  const generateRecommendations = (goal: Goal, loc: string): void => {
    const newRecommendations = createRecommendations(goal, loc);
    setRecommendations(newRecommendations);
  };

  const handleRefine = (): void => {
    if (selectedGoal && location) {
      generateRecommendations(selectedGoal, location);
    }
  };

  const handleStartOver = (): void => {
    setStep(1);
    setSelectedGoal(null);
    setLocation('');
    setRecommendations([]);
  };

  const toggleFavorite = (recommendation: Recommendation): void => {
    const isFavorite = favorites.some((fav: Recommendation): boolean => fav.id === recommendation.id);
    if (isFavorite) {
      setFavorites(favorites.filter((fav: Recommendation): boolean => fav.id !== recommendation.id));
    } else {
      setFavorites([...favorites, recommendation]);
    }
  };

  const isFavorite = (id: string): boolean => {
    return favorites.some((fav: Recommendation): boolean => fav.id === id);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <div className="container mx-auto px-4 py-8 pt-16">
        <header className="text-center mb-12">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent mb-3">
            DreamZone Mapper
          </h1>
          <p className="text-gray-600 text-lg">
            Discover the best spots in your area, perfectly matched to your goals
          </p>
        </header>

        {!showFavorites ? (
          <>
            {step === 1 && <GoalSelection onSelect={handleGoalSelect} />}
            
            {step === 2 && (
              <LocationInput
                onSubmit={handleLocationSubmit}
                onBack={(): void => setStep(1)}
              />
            )}
            
            {step === 3 && (
              <Recommendations
                recommendations={recommendations}
                onRefine={handleRefine}
                onStartOver={handleStartOver}
                toggleFavorite={toggleFavorite}
                isFavorite={isFavorite}
              />
            )}

            {favorites.length > 0 && (
              <div className="fixed bottom-6 right-6">
                <button
                  onClick={(): void => setShowFavorites(true)}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center gap-2"
                >
                  <span>💖</span>
                  <span>My Favorites ({favorites.length})</span>
                </button>
              </div>
            )}
          </>
        ) : (
          <Favorites
            favorites={favorites}
            onBack={(): void => setShowFavorites(false)}
            removeFavorite={(id: string): void => {
              setFavorites(favorites.filter((fav: Recommendation): boolean => fav.id !== id));
            }}
          />
        )}
      </div>
    </div>
  );
}

function createRecommendations(goal: Goal, location: string): Recommendation[] {
  const baseRecommendations: Record<string, Array<Omit<Recommendation, 'id' | 'category'>>> = {
    food: [
      {
        name: 'The Garden Bistro',
        type: 'Farm-to-Table Restaurant',
        whyGoodPick: 'Perfect for fresh, seasonal ingredients with a cozy atmosphere',
        whatMakesSpecial: 'They source everything from local farms within 50 miles',
        insiderTip: 'Try the chef\'s daily special - it\'s always amazing',
        bestTime: 'Weekday lunch for the quietest experience',
        matchesPersonType: 'Health-conscious foodies who value sustainability',
        image: '🌿'
      },
      {
        name: 'Midnight Tacos',
        type: 'Late Night Eatery',
        whyGoodPick: 'Authentic street food open until 2 AM',
        whatMakesSpecial: 'Family recipes passed down three generations',
        insiderTip: 'The al pastor is legendary, but only available after 9 PM',
        bestTime: 'After 10 PM when the night crowd arrives',
        matchesPersonType: 'Night owls and taco enthusiasts',
        image: '🌮'
      },
      {
        name: 'Sunrise Bakery',
        type: 'Artisan Bakery',
        whyGoodPick: 'Fresh-baked pastries every morning at 6 AM',
        whatMakesSpecial: 'Everything is made with organic, stone-ground flour',
        insiderTip: 'Get there before 8 AM for the best selection',
        bestTime: 'Early morning, right when they open',
        matchesPersonType: 'Early risers who love fresh-baked goods',
        image: '🥐'
      }
    ],
    fitness: [
      {
        name: 'Zen Power Studio',
        type: 'Yoga & Strength Training',
        whyGoodPick: 'Combines mindfulness with high-intensity workouts',
        whatMakesSpecial: 'Rooftop classes with stunning city views',
        insiderTip: 'Sunrise yoga at 6:30 AM is life-changing',
        bestTime: 'Early morning or sunset sessions',
        matchesPersonType: 'Wellness seekers balancing body and mind',
        image: '🧘'
      },
      {
        name: 'Iron Mountain Gym',
        type: 'Powerlifting & CrossFit',
        whyGoodPick: 'Serious training environment with top equipment',
        whatMakesSpecial: 'Olympic lifting platforms and expert coaches',
        insiderTip: 'Free guest pass for first-timers on weekdays',
        bestTime: 'Weekday mornings to avoid the rush',
        matchesPersonType: 'Dedicated athletes pushing their limits',
        image: '🏋️'
      },
      {
        name: 'Trail Runners Hub',
        type: 'Outdoor Fitness Community',
        whyGoodPick: 'Group runs on scenic trails every weekend',
        whatMakesSpecial: 'All skill levels welcome, amazing community',
        insiderTip: 'Bring water and snacks - runs go for 1-2 hours',
        bestTime: 'Saturday mornings at 7 AM',
        matchesPersonType: 'Nature lovers who prefer outdoor workouts',
        image: '🏃'
      }
    ],
    nightlife: [
      {
        name: 'The Velvet Lounge',
        type: 'Jazz & Cocktail Bar',
        whyGoodPick: 'Live music every night with craft cocktails',
        whatMakesSpecial: 'Hidden speakeasy vibe with world-class mixologists',
        insiderTip: 'Ask for the "secret menu" - they\'ll hook you up',
        bestTime: 'Thursday nights for the best jazz sets',
        matchesPersonType: 'Sophisticated night owls who appreciate live music',
        image: '🎷'
      },
      {
        name: 'Electric Dreams',
        type: 'Dance Club',
        whyGoodPick: 'Best DJ lineup in the city every weekend',
        whatMakesSpecial: 'State-of-the-art sound system and light show',
        insiderTip: 'Get there before 11 PM to skip the line',
        bestTime: 'Friday and Saturday after midnight',
        matchesPersonType: 'Dance lovers and electronic music fans',
        image: '🎧'
      },
      {
        name: 'Rooftop Social',
        type: 'Outdoor Bar',
        whyGoodPick: 'Panoramic views with a relaxed atmosphere',
        whatMakesSpecial: 'Fire pits and cozy seating under the stars',
        insiderTip: 'Sunset happy hour has half-price appetizers',
        bestTime: 'Golden hour through evening',
        matchesPersonType: 'Social butterflies who love scenic views',
        image: '🌆'
      }
    ],
    services: [
      {
        name: 'QuickFix Tech Hub',
        type: 'Electronics Repair',
        whyGoodPick: 'Same-day repairs for most devices',
        whatMakesSpecial: 'Transparent pricing with lifetime warranty',
        insiderTip: 'Book online for 15% off your first visit',
        bestTime: 'Weekday mornings for fastest service',
        matchesPersonType: 'Tech users needing reliable repairs',
        image: '💻'
      },
      {
        name: 'Pamper Palace Spa',
        type: 'Day Spa',
        whyGoodPick: 'Luxury treatments at reasonable prices',
        whatMakesSpecial: 'Uses organic, locally-sourced products',
        insiderTip: 'Tuesday and Wednesday packages are 30% off',
        bestTime: 'Weekday afternoons for peace and quiet',
        matchesPersonType: 'Self-care enthusiasts seeking relaxation',
        image: '💆'
      },
      {
        name: 'Pet Paradise Grooming',
        type: 'Pet Care',
        whyGoodPick: 'Cage-free environment with loving staff',
        whatMakesSpecial: 'They treat every pet like their own',
        insiderTip: 'Monthly packages save you 20%',
        bestTime: 'Weekday mornings for the calmest experience',
        matchesPersonType: 'Pet parents who want the best for their furry friends',
        image: '🐾'
      }
    ],
    family: [
      {
        name: 'Adventure Kingdom',
        type: 'Indoor Play Center',
        whyGoodPick: 'Safe, supervised fun for all ages',
        whatMakesSpecial: 'Separate zones for toddlers and older kids',
        insiderTip: 'Parent cafe offers free coffee while kids play',
        bestTime: 'Weekday mornings for smaller crowds',
        matchesPersonType: 'Parents looking for safe, engaging activities',
        image: '🎠'
      },
      {
        name: 'Science Discovery Museum',
        type: 'Interactive Museum',
        whyGoodPick: 'Hands-on exhibits that make learning fun',
        whatMakesSpecial: 'New exhibits rotate every season',
        insiderTip: 'First Sunday of the month is free admission',
        bestTime: 'Weekend mornings right when they open',
        matchesPersonType: 'Curious families who love learning together',
        image: '🔬'
      },
      {
        name: 'Splash Zone Water Park',
        type: 'Outdoor Water Park',
        whyGoodPick: 'Clean facilities with lifeguards everywhere',
        whatMakesSpecial: 'Designated splash pad for littles ones',
        insiderTip: 'Season passes pay for themselves after 3 visits',
        bestTime: 'Weekdays or early weekend mornings',
        matchesPersonType: 'Active families who love water fun',
        image: '💦'
      }
    ],
    gems: [
      {
        name: 'The Secret Garden',
        type: 'Hidden Park',
        whyGoodPick: 'Tucked away oasis most locals don\'t know about',
        whatMakesSpecial: 'Stunning flower garden maintained by volunteers',
        insiderTip: 'Look for the unmarked path behind the library',
        bestTime: 'Early morning for peaceful solitude',
        matchesPersonType: 'Explorers seeking quiet, beautiful spaces',
        image: '🌸'
      },
      {
        name: 'Vinyl Haven Records',
        type: 'Record Shop',
        whyGoodPick: 'Incredible collection of rare finds and classics',
        whatMakesSpecial: 'Owner personally curates every record',
        insiderTip: 'New arrivals go out on Fridays - get there early',
        bestTime: 'Saturday afternoons for browsing',
        matchesPersonType: 'Music collectors and vinyl enthusiasts',
        image: '🎵'
      },
      {
        name: 'Moonlight Cinema',
        type: 'Indie Theater',
        whyGoodPick: 'Shows cult classics and indie films',
        whatMakesSpecial: 'Art deco interior from the 1940s',
        insiderTip: 'Tuesday nights are $5 with free popcorn',
        bestTime: 'Late evening shows for the full experience',
        matchesPersonType: 'Film buffs who appreciate cinema history',
        image: '🎬'
      }
    ],
    relaxing: [
      {
        name: 'Tranquility Tea House',
        type: 'Tea Cafe',
        whyGoodPick: 'Peaceful atmosphere with 100+ tea varieties',
        whatMakesSpecial: 'Traditional tea ceremonies on weekends',
        insiderTip: 'Try the seasonal blend - it changes monthly',
        bestTime: 'Afternoon for the full tea service',
        matchesPersonType: 'Those seeking calm and mindfulness',
        image: '🍵'
      },
      {
        name: 'Sunset Beach Point',
        type: 'Scenic Overlook',
        whyGoodPick: 'Best sunset views in the entire area',
        whatMakesSpecial: 'Rarely crowded despite the stunning views',
        insiderTip: 'Bring a blanket and arrive 30 minutes early',
        bestTime: 'Golden hour through sunset',
        matchesPersonType: 'Nature lovers and contemplative souls',
        image: '🌅'
      },
      {
        name: 'Harmony Float Spa',
        type: 'Sensory Deprivation',
        whyGoodPick: 'Ultimate relaxation in isolation tanks',
        whatMakesSpecial: 'Medical-grade salt water and soundproofing',
        insiderTip: 'First-time floaters get a guide session included',
        bestTime: 'Evening for the deepest relaxation',
        matchesPersonType: 'Stress-relief seekers and meditation practitioners',
        image: '🌊'
      }
    ],
    trending: [
      {
        name: 'Pixel Playground',
        type: 'VR Gaming Lounge',
        whyGoodPick: 'Latest VR tech with multiplayer experiences',
        whatMakesSpecial: 'First VR lounge in the area',
        insiderTip: 'Group bookings get a private room',
        bestTime: 'Weekend evenings for the social vibe',
        matchesPersonType: 'Tech enthusiasts and gamers',
        image: '🎮'
      },
      {
        name: 'Neon Night Market',
        type: 'Food & Art Market',
        whyGoodPick: 'Instagram-worthy with amazing street food',
        whatMakesSpecial: 'Different vendors every week',
        insiderTip: 'Follow on social for weekly vendor lineups',
        bestTime: 'Friday and Saturday nights',
        matchesPersonType: 'Foodies and social media creators',
        image: '🎨'
      },
      {
        name: 'The Crypto Cafe',
        type: 'Blockchain Community Hub',
        whyGoodPick: 'Where Web3 builders and creators meet',
        whatMakesSpecial: 'Free workshops on crypto and NFTs',
        insiderTip: 'Pay with crypto for 10% discount',
        bestTime: 'Thursday evenings for networking events',
        matchesPersonType: 'Tech innovators and crypto enthusiasts',
        image: '⚡'
      }
    ]
  };

  const goalKey = goal.value as keyof typeof baseRecommendations;
  const recs = baseRecommendations[goalKey] || baseRecommendations.food;

  const categories: Array<'closeby' | 'today' | 'budget' | 'popular' | 'underradar'> = [
    'closeby',
    'today',
    'budget',
    'popular',
    'underradar'
  ];

  return recs.map((rec, index) => ({
    ...rec,
    id: `${goal.value}-${index}-${Date.now()}`,
    category: categories[index % categories.length]
  }));
}
