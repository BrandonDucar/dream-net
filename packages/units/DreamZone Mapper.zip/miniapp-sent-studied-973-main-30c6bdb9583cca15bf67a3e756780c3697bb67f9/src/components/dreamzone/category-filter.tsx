'use client';

import type { ReactElement } from 'react';
import { Button } from '@/components/ui/button';

interface CategoryFilterProps {
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
}

interface Category {
  value: string;
  label: string;
  emoji: string;
}

const categories: Category[] = [
  { value: 'all', label: 'All Spots', emoji: '🗺️' },
  { value: 'closeby', label: 'Close By', emoji: '📍' },
  { value: 'today', label: 'Best for Today', emoji: '⭐' },
  { value: 'budget', label: 'Budget-Friendly', emoji: '💰' },
  { value: 'popular', label: 'Most Popular', emoji: '🔥' },
  { value: 'underradar', label: 'Under-the-Radar', emoji: '💎' }
];

export function CategoryFilter({
  selectedCategory,
  onSelectCategory
}: CategoryFilterProps): ReactElement {
  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-lg border-2 border-purple-200 p-4 shadow-lg">
      <div className="flex flex-wrap gap-2 justify-center">
        {categories.map((category: Category) => (
          <Button
            key={category.value}
            onClick={(): void => onSelectCategory(category.value)}
            variant={selectedCategory === category.value ? 'default' : 'outline'}
            className={
              selectedCategory === category.value
                ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white border-0 shadow-lg'
                : 'border-2 border-purple-200 hover:border-purple-400 hover:bg-purple-50'
            }
          >
            <span className="mr-2">{category.emoji}</span>
            {category.label}
          </Button>
        ))}
      </div>
    </div>
  );
}
