'use client';

import type { ReactElement } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { Recommendation } from '@/types/dreamzone';

interface FavoritesProps {
  favorites: Recommendation[];
  onBack: () => void;
  removeFavorite: (id: string) => void;
}

const categoryLabels: Record<string, string> = {
  closeby: 'Close By',
  today: 'Best for Today',
  budget: 'Budget-Friendly',
  popular: 'Most Popular',
  underradar: 'Under-the-Radar'
};

const categoryColors: Record<string, string> = {
  closeby: 'bg-blue-100 text-blue-700 border-blue-300',
  today: 'bg-green-100 text-green-700 border-green-300',
  budget: 'bg-yellow-100 text-yellow-700 border-yellow-300',
  popular: 'bg-purple-100 text-purple-700 border-purple-300',
  underradar: 'bg-pink-100 text-pink-700 border-pink-300'
};

export function Favorites({
  favorites,
  onBack,
  removeFavorite
}: FavoritesProps): ReactElement {
  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-3">
          💖 My Favorite Zones
        </h2>
        <p className="text-gray-600">
          {favorites.length} {favorites.length === 1 ? 'spot' : 'spots'} saved for later
        </p>
      </div>

      <div className="space-y-4">
        {favorites.map((favorite: Recommendation) => (
          <Card
            key={favorite.id}
            className="border-2 border-purple-200 hover:shadow-xl transition-all duration-300 bg-white/90 backdrop-blur-sm"
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="text-5xl">{favorite.image}</div>
                  <div>
                    <Badge
                      className={`${categoryColors[favorite.category]} border mb-2`}
                    >
                      {categoryLabels[favorite.category]}
                    </Badge>
                    <CardTitle className="text-2xl mb-1">
                      {favorite.name}
                    </CardTitle>
                    <p className="text-purple-600 font-medium">
                      {favorite.type}
                    </p>
                  </div>
                </div>
                <Button
                  onClick={(): void => removeFavorite(favorite.id)}
                  variant="ghost"
                  className="text-3xl hover:bg-red-50"
                >
                  🗑️
                </Button>
              </div>
            </CardHeader>

            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="bg-purple-50 rounded-lg p-3 border border-purple-200">
                  <p className="text-sm font-semibold text-purple-900 mb-1">
                    Why it's special
                  </p>
                  <p className="text-sm text-gray-700">
                    {favorite.whatMakesSpecial}
                  </p>
                </div>
                <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
                  <p className="text-sm font-semibold text-blue-900 mb-1">
                    Insider tip
                  </p>
                  <p className="text-sm text-gray-700">
                    {favorite.insiderTip}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {favorites.length === 0 && (
        <Card className="border-2 border-purple-200 bg-white/90 backdrop-blur-sm">
          <CardContent className="text-center py-12">
            <div className="text-6xl mb-4">🤍</div>
            <p className="text-xl text-gray-600 mb-2">
              No favorites yet
            </p>
            <p className="text-gray-500">
              Start exploring and save your favorite spots!
            </p>
          </CardContent>
        </Card>
      )}

      <div className="flex justify-center pt-6">
        <Button
          onClick={onBack}
          size="lg"
          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-lg hover:shadow-xl transition-all"
        >
          ← Back to Recommendations
        </Button>
      </div>
    </div>
  );
}
