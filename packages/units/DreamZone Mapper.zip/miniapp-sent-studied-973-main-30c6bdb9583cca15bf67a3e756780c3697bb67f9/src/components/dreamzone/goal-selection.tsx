'use client';

import type { ReactElement } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import type { Goal } from '@/types/dreamzone';

interface GoalSelectionProps {
  onSelect: (goal: Goal) => void;
}

const goals: Goal[] = [
  {
    value: 'food',
    label: 'Food & Dining',
    description: 'Discover amazing restaurants, cafes, and eateries',
    emoji: '🍽️'
  },
  {
    value: 'fitness',
    label: 'Fitness & Wellness',
    description: 'Find gyms, yoga studios, and wellness centers',
    emoji: '💪'
  },
  {
    value: 'nightlife',
    label: 'Nightlife & Entertainment',
    description: 'Explore bars, clubs, and evening activities',
    emoji: '🎉'
  },
  {
    value: 'services',
    label: 'Services & Care',
    description: 'Locate helpful services and professional care',
    emoji: '✨'
  },
  {
    value: 'family',
    label: 'Family Activities',
    description: 'Fun spots perfect for kids and families',
    emoji: '👨‍👩‍👧‍👦'
  },
  {
    value: 'gems',
    label: 'Hidden Gems',
    description: 'Uncover secret spots locals love',
    emoji: '💎'
  },
  {
    value: 'relaxing',
    label: 'Relaxing Spots',
    description: 'Peaceful places to unwind and recharge',
    emoji: '🧘'
  },
  {
    value: 'trending',
    label: 'Trending Areas',
    description: 'Hot spots everyone is talking about',
    emoji: '🔥'
  }
];

export function GoalSelection({ onSelect }: GoalSelectionProps): ReactElement {
  return (
    <div className="max-w-5xl mx-auto">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-gray-800 mb-3">
          What are you looking for?
        </h2>
        <p className="text-gray-600">
          Choose your goal and we'll find the perfect spots for you
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {goals.map((goal: Goal) => (
          <Card
            key={goal.value}
            className="cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-xl border-2 border-transparent hover:border-purple-300 bg-white/80 backdrop-blur-sm"
            onClick={(): void => onSelect(goal)}
          >
            <CardContent className="p-6 text-center">
              <div className="text-5xl mb-3">{goal.emoji}</div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">
                {goal.label}
              </h3>
              <p className="text-sm text-gray-600">
                {goal.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-8 text-center">
        <p className="text-gray-500 text-sm">
          Not seeing what you need? Pick the closest match and refine your results later
        </p>
      </div>
    </div>
  );
}
