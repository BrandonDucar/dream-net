'use client';

import { useState } from 'react';
import type { ReactElement, FormEvent } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

interface LocationInputProps {
  onSubmit: (location: string) => void;
  onBack: () => void;
}

export function LocationInput({ onSubmit, onBack }: LocationInputProps): ReactElement {
  const [location, setLocation] = useState<string>('');

  const handleSubmit = (e: FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    if (location.trim()) {
      onSubmit(location.trim());
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <Card className="border-2 border-purple-200 shadow-xl bg-white/90 backdrop-blur-sm">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Where are you?
          </CardTitle>
          <p className="text-gray-600 mt-2">
            Enter your city or zipcode to find spots near you
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Input
                type="text"
                placeholder="e.g., San Francisco or 94102"
                value={location}
                onChange={(e): void => setLocation(e.target.value)}
                className="text-lg h-14 border-2 border-purple-200 focus:border-purple-400"
              />
            </div>

            <div className="flex gap-3">
              <Button
                type="button"
                onClick={onBack}
                variant="outline"
                className="flex-1 h-12 border-2"
              >
                ← Back
              </Button>
              <Button
                type="submit"
                disabled={!location.trim()}
                className="flex-1 h-12 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
              >
                Find My Zones →
              </Button>
            </div>
          </form>

          <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
            <p className="text-sm text-gray-700 text-center">
              💡 <span className="font-semibold">Tip:</span> The more specific your location, the better your recommendations
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
