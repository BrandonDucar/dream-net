'use client';

import type { ReactElement } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { Recommendation } from '@/types/dreamzone';

interface RecommendationCardProps {
  recommendation: Recommendation;
  isFavorite: boolean;
  toggleFavorite: () => void;
}

const categoryLabels: Record<string, string> = {
  closeby: 'Close By',
  today: 'Best for Today',
  budget: 'Budget-Friendly',
  popular: 'Most Popular',
  underradar: 'Under-the-Radar'
};

const categoryColors: Record<string, string> = {
  closeby: 'bg-blue-100 text-blue-700 border-blue-300',
  today: 'bg-green-100 text-green-700 border-green-300',
  budget: 'bg-yellow-100 text-yellow-700 border-yellow-300',
  popular: 'bg-purple-100 text-purple-700 border-purple-300',
  underradar: 'bg-pink-100 text-pink-700 border-pink-300'
};

export function RecommendationCard({
  recommendation,
  isFavorite,
  toggleFavorite
}: RecommendationCardProps): ReactElement {
  return (
    <Card className="border-2 border-purple-100 hover:border-purple-300 hover:shadow-xl transition-all duration-300 bg-white/90 backdrop-blur-sm overflow-hidden">
      <div className="absolute top-4 right-4 z-10">
        <button
          onClick={toggleFavorite}
          className="text-3xl transition-transform hover:scale-125 focus:outline-none"
        >
          {isFavorite ? '💖' : '🤍'}
        </button>
      </div>

      <CardHeader className="pb-3">
        <div className="flex items-start gap-4">
          <div className="text-6xl">{recommendation.image}</div>
          <div className="flex-1">
            <Badge
              className={`${categoryColors[recommendation.category]} border mb-2`}
            >
              {categoryLabels[recommendation.category]}
            </Badge>
            <CardTitle className="text-2xl mb-1">
              {recommendation.name}
            </CardTitle>
            <p className="text-purple-600 font-medium">
              {recommendation.type}
            </p>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="grid gap-4">
          <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
            <h4 className="font-semibold text-purple-900 mb-2 flex items-center gap-2">
              <span>✨</span> Why It's a Good Pick
            </h4>
            <p className="text-gray-700">{recommendation.whyGoodPick}</p>
          </div>

          <div className="bg-pink-50 rounded-lg p-4 border border-pink-200">
            <h4 className="font-semibold text-pink-900 mb-2 flex items-center gap-2">
              <span>💫</span> What Makes It Special
            </h4>
            <p className="text-gray-700">{recommendation.whatMakesSpecial}</p>
          </div>

          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <h4 className="font-semibold text-blue-900 mb-2 flex items-center gap-2">
              <span>🔑</span> Insider Tip
            </h4>
            <p className="text-gray-700">{recommendation.insiderTip}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-green-50 rounded-lg p-4 border border-green-200">
              <h4 className="font-semibold text-green-900 mb-2 flex items-center gap-2">
                <span>⏰</span> Best Time to Go
              </h4>
              <p className="text-gray-700 text-sm">{recommendation.bestTime}</p>
            </div>

            <div className="bg-yellow-50 rounded-lg p-4 border border-yellow-200">
              <h4 className="font-semibold text-yellow-900 mb-2 flex items-center gap-2">
                <span>👤</span> Perfect For
              </h4>
              <p className="text-gray-700 text-sm">{recommendation.matchesPersonType}</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
