'use client';

import { useState } from 'react';
import type { ReactElement } from 'react';
import { Button } from '@/components/ui/button';
import { RecommendationCard } from './recommendation-card';
import { CategoryFilter } from './category-filter';
import type { Recommendation } from '@/types/dreamzone';

interface RecommendationsProps {
  recommendations: Recommendation[];
  onRefine: () => void;
  onStartOver: () => void;
  toggleFavorite: (recommendation: Recommendation) => void;
  isFavorite: (id: string) => boolean;
}

export function Recommendations({
  recommendations,
  onRefine,
  onStartOver,
  toggleFavorite,
  isFavorite
}: RecommendationsProps): ReactElement {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const filteredRecommendations = selectedCategory === 'all'
    ? recommendations
    : recommendations.filter((rec: Recommendation): boolean => rec.category === selectedCategory);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-3">
          Your DreamZones
        </h2>
        <p className="text-gray-600">
          We found {recommendations.length} perfect spots for you
        </p>
      </div>

      <CategoryFilter
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
      />

      <div className="space-y-6">
        {filteredRecommendations.map((recommendation: Recommendation) => (
          <RecommendationCard
            key={recommendation.id}
            recommendation={recommendation}
            isFavorite={isFavorite(recommendation.id)}
            toggleFavorite={(): void => toggleFavorite(recommendation)}
          />
        ))}
      </div>

      {filteredRecommendations.length === 0 && (
        <div className="text-center py-12 bg-white/80 backdrop-blur-sm rounded-lg border-2 border-purple-200">
          <p className="text-gray-600 text-lg mb-4">
            No spots in this category yet
          </p>
          <Button
            onClick={(): void => setSelectedCategory('all')}
            variant="outline"
            className="border-2"
          >
            View All Spots
          </Button>
        </div>
      )}

      <div className="flex gap-4 justify-center pt-6">
        <Button
          onClick={onRefine}
          size="lg"
          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-lg hover:shadow-xl transition-all"
        >
          ✨ Refine My Results
        </Button>
        <Button
          onClick={onStartOver}
          size="lg"
          variant="outline"
          className="border-2 border-purple-300 hover:bg-purple-50"
        >
          ← Start Over
        </Button>
      </div>
    </div>
  );
}
