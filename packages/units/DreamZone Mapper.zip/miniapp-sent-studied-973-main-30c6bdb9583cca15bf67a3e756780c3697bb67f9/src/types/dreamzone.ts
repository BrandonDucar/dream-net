export interface Goal {
  value: string;
  label: string;
  description: string;
  emoji: string;
}

export interface Recommendation {
  id: string;
  name: string;
  type: string;
  category: 'closeby' | 'today' | 'budget' | 'popular' | 'underradar';
  whyGoodPick: string;
  whatMakesSpecial: string;
  insiderTip: string;
  bestTime: string;
  matchesPersonType: string;
  image: string;
}
