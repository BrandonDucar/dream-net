'use client'
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { SpecDisplay } from '@/components/spec-display';
import { generateSpec } from '@/lib/spec-generator';
import type { DreamNetSpec } from '@/types/spec';
import { Loader2, Sparkles } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Home(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [idea, setIdea] = useState<string>('');
  const [spec, setSpec] = useState<DreamNetSpec | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const handleForge = async (): Promise<void> => {
    if (!idea.trim()) return;

    setLoading(true);
    setError('');
    setSpec(null);

    try {
      const generatedSpec = await generateSpec(idea);
      setSpec(generatedSpec);
    } catch (err) {
      setError((err as Error).message || 'Failed to generate spec');
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-2 pt-8 md:pt-12">
          <div className="flex items-center justify-center gap-2">
            <Sparkles className="w-8 h-8 text-yellow-400" />
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
              PulseSmith
            </h1>
          </div>
          <p className="text-slate-400 text-lg">DreamNet Micro-Forge</p>
          <p className="text-slate-500 text-sm max-w-2xl mx-auto">
            Transform any idea into a production-ready dev spec. Drop your concept, get a complete technical blueprint.
          </p>
        </div>

        {/* Input Section */}
        <Card className="border-slate-700 bg-slate-800/50 backdrop-blur">
          <CardHeader>
            <CardTitle className="text-white">Drop Your Idea</CardTitle>
            <CardDescription className="text-slate-400">
              Type any app concept, feature, or product idea. Be as detailed or as vague as you want.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              placeholder="e.g., A social app for developers to share code snippets with real-time collaboration..."
              value={idea}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setIdea(e.target.value)}
              className="min-h-32 bg-slate-900/50 border-slate-600 text-white placeholder:text-slate-500"
            />
            <Button 
              onClick={handleForge}
              disabled={!idea.trim() || loading}
              className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-semibold"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Forging Spec...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Forge Spec
                </>
              )}
            </Button>

            {error && (
              <div className="p-4 bg-red-900/20 border border-red-800 rounded-lg text-red-200 text-sm">
                {error}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Results Section */}
        {spec && (
          <div className="animate-in fade-in duration-500">
            <SpecDisplay spec={spec} />
          </div>
        )}

        {/* Footer */}
        <div className="text-center text-slate-500 text-xs pb-8">
          <p>Built with Next.js • Powered by AI • Optimized for builders</p>
        </div>
      </div>
    </main>
  );
}
