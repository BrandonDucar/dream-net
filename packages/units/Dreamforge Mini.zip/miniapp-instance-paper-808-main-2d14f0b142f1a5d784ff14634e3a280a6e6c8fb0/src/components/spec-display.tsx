'use client';

import type { DreamNetSpec } from '@/types/spec';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';

interface SpecDisplayProps {
  spec: DreamNetSpec;
}

export function SpecDisplay({ spec }: SpecDisplayProps): JSX.Element {
  return (
    <div className="space-y-6 w-full">
      {/* Concept Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">{spec.concept.title}</CardTitle>
          <p className="text-muted-foreground">{spec.concept.tagline}</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">Core Value</h3>
            <p className="text-sm">{spec.concept.coreValue}</p>
          </div>
          <div>
            <h3 className="font-semibold mb-2">Target User</h3>
            <p className="text-sm">{spec.concept.targetUser}</p>
          </div>
          <div>
            <h3 className="font-semibold mb-2">Key Features</h3>
            <div className="flex flex-wrap gap-2">
              {spec.concept.keyFeatures.map((feature: string, i: number) => (
                <Badge key={i} variant="secondary">{feature}</Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Technical Blueprint */}
      <Card>
        <CardHeader>
          <CardTitle>Technical Blueprint</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="database" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="database">Database</TabsTrigger>
              <TabsTrigger value="apis">APIs</TabsTrigger>
              <TabsTrigger value="logic">Logic Flow</TabsTrigger>
              <TabsTrigger value="stack">Tech Stack</TabsTrigger>
            </TabsList>

            <TabsContent value="database" className="space-y-4">
              {spec.technical.database.map((table, i) => (
                <div key={i} className="border rounded-lg p-4">
                  <h4 className="font-semibold mb-2">{table.name}</h4>
                  <div className="space-y-1 text-sm">
                    {table.fields.map((field, j) => (
                      <div key={j} className="font-mono text-xs">
                        {field.name}: {field.type} {field.constraints.join(' ')}
                      </div>
                    ))}
                  </div>
                  {table.relations.length > 0 && (
                    <div className="mt-2 text-xs text-muted-foreground">
                      Relations: {table.relations.join(', ')}
                    </div>
                  )}
                </div>
              ))}
            </TabsContent>

            <TabsContent value="apis" className="space-y-4">
              {spec.technical.apis.map((api, i) => (
                <div key={i} className="border rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant={api.method === 'GET' ? 'default' : 'outline'}>{api.method}</Badge>
                    <code className="text-sm">{api.path}</code>
                  </div>
                  <p className="text-sm mb-2">{api.purpose}</p>
                  {api.requestBody && (
                    <div className="text-xs">
                      <span className="font-semibold">Request:</span>
                      <pre className="mt-1 p-2 bg-muted rounded">{api.requestBody}</pre>
                    </div>
                  )}
                  {api.responseBody && (
                    <div className="text-xs mt-2">
                      <span className="font-semibold">Response:</span>
                      <pre className="mt-1 p-2 bg-muted rounded">{api.responseBody}</pre>
                    </div>
                  )}
                </div>
              ))}
            </TabsContent>

            <TabsContent value="logic" className="space-y-3">
              {spec.technical.logicFlow.map((flow, i) => (
                <div key={i} className="border-l-4 border-primary pl-4 py-2">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline">Step {flow.step}</Badge>
                    <span className="font-semibold text-sm">{flow.action}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">Trigger: {flow.trigger}</p>
                  <p className="text-xs">Outcome: {flow.outcome}</p>
                </div>
              ))}
            </TabsContent>

            <TabsContent value="stack" className="space-y-3">
              {spec.technical.techStack.map((item, i) => (
                <div key={i} className="flex gap-4 items-start">
                  <Badge className="mt-1">{item.category}</Badge>
                  <div className="flex-1">
                    <p className="font-semibold text-sm">{item.technology}</p>
                    <p className="text-xs text-muted-foreground">{item.rationale}</p>
                  </div>
                </div>
              ))}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Evolution Path */}
      <Card>
        <CardHeader>
          <CardTitle>DreamNet Evolution Path</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {Object.entries(spec.evolution).map(([phase, data]) => (
              <div key={phase} className="border rounded-lg p-4">
                <h3 className="font-semibold capitalize mb-2">{phase}</h3>
                <p className="text-xs text-muted-foreground mb-3">{data.duration}</p>
                <p className="text-sm font-medium mb-2">{data.focus}</p>
                <div className="space-y-2">
                  <div>
                    <p className="text-xs font-semibold mb-1">Deliverables:</p>
                    <ul className="text-xs space-y-1">
                      {data.deliverables.map((item: string, i: number) => (
                        <li key={i}>• {item}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <p className="text-xs font-semibold mb-1">Metrics:</p>
                    <ul className="text-xs space-y-1">
                      {data.metrics.map((item: string, i: number) => (
                        <li key={i}>• {item}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Implementation Code */}
      <Card>
        <CardHeader>
          <CardTitle>Implementation Starter Code</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="setup" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="setup">Setup</TabsTrigger>
              <TabsTrigger value="core">Core Logic</TabsTrigger>
              <TabsTrigger value="api">API Route</TabsTrigger>
              <TabsTrigger value="ui">UI Component</TabsTrigger>
            </TabsList>

            <TabsContent value="setup">
              <pre className="text-xs p-4 bg-black text-green-400 rounded-lg overflow-x-auto">
                <code>{spec.implementation.setup}</code>
              </pre>
            </TabsContent>

            <TabsContent value="core">
              <pre className="text-xs p-4 bg-black text-green-400 rounded-lg overflow-x-auto">
                <code>{spec.implementation.coreLogic}</code>
              </pre>
            </TabsContent>

            <TabsContent value="api">
              <pre className="text-xs p-4 bg-black text-green-400 rounded-lg overflow-x-auto">
                <code>{spec.implementation.apiExample}</code>
              </pre>
            </TabsContent>

            <TabsContent value="ui">
              <pre className="text-xs p-4 bg-black text-green-400 rounded-lg overflow-x-auto">
                <code>{spec.implementation.uiComponent}</code>
              </pre>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Risk Analysis */}
      <Card>
        <CardHeader>
          <CardTitle>Risk Analysis</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-3">Technical Risks</h3>
            <div className="space-y-2">
              {spec.risks.technical.map((risk, i) => (
                <div key={i} className="flex items-start gap-3">
                  <Badge 
                    variant={risk.severity === 'high' ? 'destructive' : risk.severity === 'medium' ? 'default' : 'secondary'}
                  >
                    {risk.severity}
                  </Badge>
                  <div className="flex-1">
                    <p className="font-semibold text-sm">{risk.category}</p>
                    <p className="text-xs text-muted-foreground">{risk.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="font-semibold mb-3">Business Risks</h3>
            <div className="space-y-2">
              {spec.risks.business.map((risk, i) => (
                <div key={i} className="flex items-start gap-3">
                  <Badge 
                    variant={risk.severity === 'high' ? 'destructive' : risk.severity === 'medium' ? 'default' : 'secondary'}
                  >
                    {risk.severity}
                  </Badge>
                  <div className="flex-1">
                    <p className="font-semibold text-sm">{risk.category}</p>
                    <p className="text-xs text-muted-foreground">{risk.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="font-semibold mb-3">Mitigation Strategies</h3>
            <ul className="space-y-2">
              {spec.risks.mitigation.map((strategy: string, i: number) => (
                <li key={i} className="text-sm flex gap-2">
                  <span className="text-primary">→</span>
                  <span>{strategy}</span>
                </li>
              ))}
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
