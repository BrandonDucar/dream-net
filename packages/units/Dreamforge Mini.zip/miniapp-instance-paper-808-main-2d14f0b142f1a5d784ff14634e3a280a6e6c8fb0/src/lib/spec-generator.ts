import { openaiChatCompletion } from '@/openai-api';
import type { DreamNetSpec } from '@/types/spec';

export async function generateSpec(idea: string): Promise<DreamNetSpec> {
  const prompt = `You are PulseSmith, an expert dev spec generator. Transform this raw idea into a production-ready spec.

Idea: "${idea}"

Generate a complete, technical spec in JSON format with these exact fields:

{
  "concept": {
    "title": "Project name",
    "tagline": "One-liner pitch",
    "coreValue": "Main value proposition",
    "targetUser": "Who this serves",
    "keyFeatures": ["feature1", "feature2", "feature3"]
  },
  "technical": {
    "database": [
      {
        "name": "TableName",
        "fields": [
          { "name": "id", "type": "uuid", "constraints": ["primary key", "default gen_random_uuid()"] },
          { "name": "fieldName", "type": "varchar(255)", "constraints": ["not null"] }
        ],
        "relations": ["foreignKey to OtherTable"]
      }
    ],
    "apis": [
      {
        "method": "POST",
        "path": "/api/endpoint",
        "purpose": "What it does",
        "requestBody": "{ field: type }",
        "responseBody": "{ field: type }"
      }
    ],
    "logicFlow": [
      {
        "step": 1,
        "action": "User action",
        "trigger": "What causes this",
        "outcome": "What happens"
      }
    ],
    "techStack": [
      { "category": "Frontend", "technology": "Next.js", "rationale": "Why" },
      { "category": "Backend", "technology": "API Routes", "rationale": "Why" }
    ]
  },
  "evolution": {
    "seed": {
      "duration": "Week 1-2",
      "focus": "Core MVP",
      "deliverables": ["item1", "item2"],
      "metrics": ["metric1", "metric2"]
    },
    "cocoon": {
      "duration": "Week 3-4",
      "focus": "Refinement",
      "deliverables": ["item1", "item2"],
      "metrics": ["metric1", "metric2"]
    },
    "v1": {
      "duration": "Week 5-6",
      "focus": "Launch prep",
      "deliverables": ["item1", "item2"],
      "metrics": ["metric1", "metric2"]
    },
    "organism": {
      "duration": "Week 7+",
      "focus": "Scale & iterate",
      "deliverables": ["item1", "item2"],
      "metrics": ["metric1", "metric2"]
    }
  },
  "implementation": {
    "setup": "// Package installs and setup commands",
    "coreLogic": "// Core business logic implementation",
    "apiExample": "// Full API route example",
    "uiComponent": "// Main UI component code"
  },
  "risks": {
    "technical": [
      { "category": "Performance", "severity": "medium", "description": "Details" }
    ],
    "business": [
      { "category": "Market", "severity": "low", "description": "Details" }
    ],
    "mitigation": ["strategy1", "strategy2"]
  },
  "optimization": {
    "viabilityScore": 85,
    "marketFit": 78,
    "technicalComplexity": 65,
    "timeToMarket": 72,
    "competitiveEdge": 81,
    "targetRanking": "A-tier: High potential, moderate complexity"
  }
}

Be thorough, technical, and builder-minded. Return ONLY valid JSON, no markdown.`;

  const response = await openaiChatCompletion({
    model: 'gpt-4o',
    messages: [
      { role: 'system', content: 'You are a technical spec generator. Return only valid JSON.' },
      { role: 'user', content: prompt }
    ]
  });

  const content = response.choices[0].message.content;
  
  // Clean up markdown code blocks if present
  const jsonContent = content
    .replace(/```json\n?/g, '')
    .replace(/```\n?/g, '')
    .trim();

  try {
    return JSON.parse(jsonContent);
  } catch (error) {
    throw new Error('Failed to parse spec JSON: ' + (error as Error).message);
  }
}
