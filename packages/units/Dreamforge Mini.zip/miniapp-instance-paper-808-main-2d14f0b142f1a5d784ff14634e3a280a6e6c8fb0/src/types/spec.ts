export interface DreamNetSpec {
  concept: ConceptSummary;
  technical: TechnicalBlueprint;
  evolution: EvolutionPath;
  implementation: ImplementationCode;
  risks: RiskAnalysis;
  optimization: OptimizationLayer;
}

export interface ConceptSummary {
  title: string;
  tagline: string;
  coreValue: string;
  targetUser: string;
  keyFeatures: string[];
}

export interface TechnicalBlueprint {
  database: DBTable[];
  apis: APIEndpoint[];
  logicFlow: LogicFlow[];
  techStack: TechStackItem[];
}

export interface DBTable {
  name: string;
  fields: DBField[];
  relations: string[];
}

export interface DBField {
  name: string;
  type: string;
  constraints: string[];
}

export interface APIEndpoint {
  method: string;
  path: string;
  purpose: string;
  requestBody?: string;
  responseBody?: string;
}

export interface LogicFlow {
  step: number;
  action: string;
  trigger: string;
  outcome: string;
}

export interface TechStackItem {
  category: string;
  technology: string;
  rationale: string;
}

export interface EvolutionPath {
  seed: PhaseDescription;
  cocoon: PhaseDescription;
  v1: PhaseDescription;
  organism: PhaseDescription;
}

export interface PhaseDescription {
  duration: string;
  focus: string;
  deliverables: string[];
  metrics: string[];
}

export interface ImplementationCode {
  setup: string;
  coreLogic: string;
  apiExample: string;
  uiComponent: string;
}

export interface RiskAnalysis {
  technical: Risk[];
  business: Risk[];
  mitigation: string[];
}

export interface Risk {
  category: string;
  severity: 'low' | 'medium' | 'high';
  description: string;
}

export interface OptimizationLayer {
  viabilityScore: number;
  marketFit: number;
  technicalComplexity: number;
  timeToMarket: number;
  competitiveEdge: number;
  targetRanking: string;
}
