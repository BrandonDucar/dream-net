import { NextRequest, NextResponse } from 'next/server';
import type { AnalysisRequest, AnalysisResponse } from '@/types/analysis';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY || 'sk-proj-default';

export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    const body: AnalysisRequest = await req.json();
    const { input, analysisType } = body;

    if (!input || !analysisType) {
      return NextResponse.json(
        { success: false, message: 'Missing required fields' },
        { status: 400 }
      );
    }

    const startTime = Date.now();

    // Build analysis prompt based on type
    const systemPrompt = getSystemPrompt(analysisType);
    const userPrompt = buildUserPrompt(input, analysisType);

    // Call OpenAI API
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        temperature: 0.7,
        response_format: { type: 'json_object' },
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.statusText}`);
    }

    const data = await response.json();
    const analysisResult = JSON.parse(data.choices[0].message.content);

    const analysisTime = Date.now() - startTime;

    const result: AnalysisResponse = {
      success: true,
      message: analysisResult.message || 'Analysis complete',
      issues: analysisResult.issues || [],
      riskZones: analysisResult.riskZones || [],
      suggestions: analysisResult.suggestions || [],
      cursorTasks: analysisResult.cursorTasks || [],
      metadata: {
        analysisTime,
        modelUsed: 'gpt-4o',
        confidence: analysisResult.confidence || 0.85,
      },
    };

    return NextResponse.json(result);
  } catch (error: unknown) {
    console.error('Analysis error:', error);
    return NextResponse.json(
      {
        success: false,
        message: 'Failed to analyze. Please try again.',
        issues: [],
        riskZones: [],
        suggestions: [],
        cursorTasks: [],
      },
      { status: 500 }
    );
  }
}

function getSystemPrompt(analysisType: string): string {
  const basePrompt = `You are DreamNet Debug Oracle, an expert AI system that predicts bugs, architectural flaws, and deployment issues before code is written. You analyze project ideas, features, and specifications to identify potential problems.`;

  const typeSpecificPrompts: Record<string, string> = {
    premortum: `${basePrompt}

Focus on Pre-Mortem Analysis:
- Imagine the project has catastrophically failed in production
- Identify the most likely causes of failure
- Consider edge cases, scaling issues, and user experience problems
- Think about what could go wrong in deployment, maintenance, and operation`,

    structural: `${basePrompt}

Focus on Structural Analysis:
- Identify architectural flaws and design anti-patterns
- Analyze component coupling and dependencies
- Evaluate data flow and state management
- Consider scalability and maintainability issues`,

    riskmap: `${basePrompt}

Focus on Risk Zone Mapping:
- Identify specific risk zones across domains: API, Database, Auth, Latency, Blockchain, Infrastructure, Security
- Assign risk levels: low, medium, high, critical
- Provide concrete mitigations for each risk zone
- Consider cross-domain dependencies and cascading failures`,

    architecture: `${basePrompt}

Focus on Architecture Suggestions:
- Recommend optimal design patterns and best practices
- Suggest specific technologies and frameworks
- Provide implementation strategies with clear benefits
- Prioritize suggestions based on impact and effort`,
  };

  return typeSpecificPrompts[analysisType] || basePrompt;
}

function buildUserPrompt(input: string, analysisType: string): string {
  return `Analyze the following project description and provide a detailed ${analysisType} analysis:

${input}

Return a JSON object with the following structure:
{
  "message": "Brief summary of the analysis",
  "confidence": 0.85,
  "issues": [
    {
      "id": "unique-id",
      "title": "Issue title",
      "description": "Detailed description",
      "severity": "low|medium|high|critical",
      "category": "Category name",
      "impact": "Impact description",
      "likelihood": "Likelihood assessment"
    }
  ],
  "riskZones": [
    {
      "id": "unique-id",
      "name": "Risk zone name",
      "domain": "api|database|auth|latency|blockchain|infrastructure|security",
      "riskLevel": "low|medium|high|critical",
      "description": "Risk description",
      "mitigations": ["Mitigation 1", "Mitigation 2"]
    }
  ],
  "suggestions": [
    {
      "id": "unique-id",
      "title": "Suggestion title",
      "description": "Detailed description",
      "priority": "low|medium|high",
      "implementation": "Implementation details",
      "benefits": ["Benefit 1", "Benefit 2"]
    }
  ],
  "cursorTasks": [
    {
      "id": "unique-id",
      "title": "Task title",
      "description": "Task description",
      "priority": 1-10,
      "tags": ["tag1", "tag2"],
      "estimatedTime": "2h"
    }
  ]
}

Be thorough, specific, and actionable. Identify real problems that could occur.`;
}
