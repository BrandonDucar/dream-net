import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';
import FarcasterWrapper from "@/components/FarcasterWrapper";

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
        <html lang="en">
          <head>
            <meta name="geo.region" content="US" />
            <meta name="geo.placename" content="Global" />
            <meta name="geo.position" content="37.7749;-122.4194" />
            <meta name="ICBM" content="37.7749, -122.4194" />
            <meta name="theme-color" content="#000000" />
            <link rel="canonical" href="/" />
          </head>
          <body className={`${geistSans.variable} ${geistMono.variable} antialiased`}>
            
      <FarcasterWrapper>
        {children}
      </FarcasterWrapper>
      
          </body>
        </html>
      );
}

export const metadata: Metadata = {
        title: "DreamNet Debug Oracle",
        description: "Predict bugs and bottlenecks before coding. Analyze structures, map risk zones, suggest patches, and optimize architecture. Enhance app development with AI foresight.",
        other: { "fc:frame": JSON.stringify({"version":"next","imageUrl":"https://placehold.co/600x400","button":{"title":"Open with Ohara","action":{"type":"launch_frame","name":"DreamNet Debug Oracle","url":"https://tried-below-197.app.ohara.ai","splashImageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/farcaster/splash_images/splash_image1.svg","splashBackgroundColor":"#ffffff"}}}
        ) }
    };
