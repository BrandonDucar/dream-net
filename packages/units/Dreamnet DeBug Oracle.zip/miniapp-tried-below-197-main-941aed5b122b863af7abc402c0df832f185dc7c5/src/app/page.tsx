'use client'
import { type FC, useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { AlertCircle, Brain, CheckCircle, FileCode, Sparkles, Zap } from 'lucide-react';
import { AnalysisResults } from '@/components/analysis-results';
import { RiskMap } from '@/components/risk-map';
import { CursorExport } from '@/components/cursor-export';
import type { AnalysisResponse, AnalysisType } from '@/types/analysis';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

const Page: FC = () => {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [input, setInput] = useState<string>('');
  const [analysisType, setAnalysisType] = useState<AnalysisType>('premortum');
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<AnalysisResponse | null>(null);

  const handleAnalyze = async (): Promise<void> => {
    if (!input.trim()) return;

    setLoading(true);
    setResult(null);

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          input,
          analysisType,
        }),
      });

      if (!response.ok) {
        throw new Error('Analysis failed');
      }

      const data: AnalysisResponse = await response.json();
      setResult(data);
    } catch (error: unknown) {
      console.error('Analysis error:', error);
      setResult({
        success: false,
        message: 'Failed to analyze. Please try again.',
        issues: [],
        riskZones: [],
        suggestions: [],
        cursorTasks: [],
      });
    } finally {
      setLoading(false);
    }
  };

  const analysisTypeDescriptions: Record<AnalysisType, { title: string; description: string; icon: JSX.Element }> = {
    premortum: {
      title: 'Pre-mortem',
      description: 'Imagine your project failed. What went wrong?',
      icon: <Brain className="h-4 w-4" />,
    },
    structural: {
      title: 'Structural Analysis',
      description: 'Identify architectural flaws before writing code',
      icon: <FileCode className="h-4 w-4" />,
    },
    riskmap: {
      title: 'Risk Mapping',
      description: 'Map API, DB, auth, latency, and chain risk zones',
      icon: <AlertCircle className="h-4 w-4" />,
    },
    architecture: {
      title: 'Architecture Suggestions',
      description: 'Get optimal patterns and implementation strategies',
      icon: <Zap className="h-4 w-4" />,
    },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white pt-12 pb-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 mb-4">
            <Sparkles className="h-8 w-8 text-purple-400" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
              DreamNet Debug Oracle
            </h1>
          </div>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            A pocket-sized AI oracle that sees every flaw before you write a single line of code.
            Predict bugs, bottlenecks, and deployment traps with DreamNet clairvoyance.
          </p>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Input Section */}
          <Card className="lg:col-span-2 bg-gray-900/50 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Brain className="h-5 w-5 text-purple-400" />
                Describe Your Vision
              </CardTitle>
              <CardDescription className="text-gray-400">
                Paste your idea, mockup description, wireframe notes, or feature spec. The Oracle will reveal hidden risks.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={input}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setInput(e.target.value)}
                placeholder="e.g., Building a real-time multiplayer game with NFT rewards. Players connect wallets, mint characters, battle in 3D arenas, earn tokens. Need leaderboards, chat, and mobile support..."
                className="min-h-[300px] bg-black/50 border-gray-700 text-white placeholder:text-gray-500 focus:border-purple-500"
              />

              <div className="space-y-3">
                <label className="text-sm text-gray-300 font-medium">Analysis Type</label>
                <div className="grid grid-cols-2 gap-3">
                  {(Object.keys(analysisTypeDescriptions) as AnalysisType[]).map((type: AnalysisType) => {
                    const config = analysisTypeDescriptions[type];
                    return (
                      <button
                        key={type}
                        onClick={() => setAnalysisType(type)}
                        className={`p-4 rounded-lg border-2 transition-all text-left ${
                          analysisType === type
                            ? 'border-purple-500 bg-purple-500/10'
                            : 'border-gray-700 bg-black/30 hover:border-gray-600'
                        }`}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          {config.icon}
                          <span className="font-medium text-sm text-white">{config.title}</span>
                        </div>
                        <p className="text-xs text-gray-400">{config.description}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              <Button
                onClick={handleAnalyze}
                disabled={loading || !input.trim()}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold"
              >
                {loading ? (
                  <>
                    <Brain className="h-4 w-4 mr-2 animate-pulse" />
                    Oracle is thinking...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Reveal Hidden Risks
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <div className="space-y-4">
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white text-sm">Oracle Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400 text-sm">Mode</span>
                  <Badge variant="outline" className="text-purple-400 border-purple-400">
                    {analysisTypeDescriptions[analysisType].title}
                  </Badge>
                </div>
                <Separator className="bg-gray-800" />
                <div className="flex items-center justify-between">
                  <span className="text-gray-400 text-sm">Status</span>
                  <Badge variant="outline" className={loading ? 'text-yellow-400 border-yellow-400' : 'text-green-400 border-green-400'}>
                    {loading ? 'Analyzing' : 'Ready'}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-900/20 to-pink-900/20 border-purple-800/50">
              <CardHeader>
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-purple-400" />
                  Oracle Powers
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-300">
                  <li className="flex items-start gap-2">
                    <span className="text-purple-400 mt-0.5">•</span>
                    <span>Predicts structural failures</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-purple-400 mt-0.5">•</span>
                    <span>Runs pre-mortem analysis</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-purple-400 mt-0.5">•</span>
                    <span>Maps risk zones</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-purple-400 mt-0.5">•</span>
                    <span>Suggests optimal architecture</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-purple-400 mt-0.5">•</span>
                    <span>Exports Cursor tasks</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Results Section */}
        {result && (
          <div className="mt-8 space-y-6">
            <Separator className="bg-gray-800" />
            
            <Tabs defaultValue="analysis" className="w-full">
              <TabsList className="bg-gray-900/50 border border-gray-800">
                <TabsTrigger value="analysis" className="data-[state=active]:bg-purple-600">
                  Analysis Results
                </TabsTrigger>
                <TabsTrigger value="riskmap" className="data-[state=active]:bg-purple-600">
                  Risk Map
                </TabsTrigger>
                <TabsTrigger value="export" className="data-[state=active]:bg-purple-600">
                  Cursor Export
                </TabsTrigger>
              </TabsList>

              <TabsContent value="analysis" className="mt-6">
                <AnalysisResults result={result} />
              </TabsContent>

              <TabsContent value="riskmap" className="mt-6">
                <RiskMap riskZones={result.riskZones} />
              </TabsContent>

              <TabsContent value="export" className="mt-6">
                <CursorExport tasks={result.cursorTasks} />
              </TabsContent>
            </Tabs>
          </div>
        )}
      </div>
    </div>
  );
};

export default Page;
