'use client';

import type { FC } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, CheckCircle2, Info, XCircle } from 'lucide-react';
import type { AnalysisResponse, RiskLevel } from '@/types/analysis';

interface AnalysisResultsProps {
  result: AnalysisResponse;
}

export const AnalysisResults: FC<AnalysisResultsProps> = ({ result }) => {
  const getSeverityColor = (severity: RiskLevel): string => {
    const colors: Record<RiskLevel, string> = {
      low: 'text-green-400 border-green-400',
      medium: 'text-yellow-400 border-yellow-400',
      high: 'text-orange-400 border-orange-400',
      critical: 'text-red-400 border-red-400',
    };
    return colors[severity];
  };

  const getSeverityIcon = (severity: RiskLevel): JSX.Element => {
    const icons: Record<RiskLevel, JSX.Element> = {
      low: <Info className="h-4 w-4" />,
      medium: <AlertTriangle className="h-4 w-4" />,
      high: <AlertTriangle className="h-4 w-4" />,
      critical: <XCircle className="h-4 w-4" />,
    };
    return icons[severity];
  };

  if (!result.success) {
    return (
      <Alert className="bg-red-900/20 border-red-800">
        <XCircle className="h-4 w-4 text-red-400" />
        <AlertDescription className="text-red-300">{result.message}</AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Alert */}
      <Alert className="bg-purple-900/20 border-purple-800">
        <CheckCircle2 className="h-4 w-4 text-purple-400" />
        <AlertDescription className="text-purple-300">{result.message}</AlertDescription>
      </Alert>

      {/* Issues */}
      {result.issues.length > 0 && (
        <Card className="bg-gray-900/50 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-orange-400" />
              Predicted Issues ({result.issues.length})
            </CardTitle>
            <CardDescription className="text-gray-400">
              Potential problems identified by the Oracle
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {result.issues.map((issue) => (
              <div
                key={issue.id}
                className="p-4 rounded-lg bg-black/30 border border-gray-800 hover:border-gray-700 transition-colors"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {getSeverityIcon(issue.severity)}
                    <h3 className="font-semibold text-white">{issue.title}</h3>
                  </div>
                  <Badge variant="outline" className={getSeverityColor(issue.severity)}>
                    {issue.severity.toUpperCase()}
                  </Badge>
                </div>
                <p className="text-gray-300 text-sm mb-3">{issue.description}</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                  <div>
                    <span className="text-gray-500">Category:</span>
                    <span className="text-gray-300 ml-2">{issue.category}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Impact:</span>
                    <span className="text-gray-300 ml-2">{issue.impact}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Likelihood:</span>
                    <span className="text-gray-300 ml-2">{issue.likelihood}</span>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Suggestions */}
      {result.suggestions.length > 0 && (
        <Card className="bg-gray-900/50 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-400" />
              Architecture Suggestions ({result.suggestions.length})
            </CardTitle>
            <CardDescription className="text-gray-400">
              Recommended patterns and optimizations
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {result.suggestions.map((suggestion) => (
              <div
                key={suggestion.id}
                className="p-4 rounded-lg bg-black/30 border border-gray-800 hover:border-gray-700 transition-colors"
              >
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-white">{suggestion.title}</h3>
                  <Badge
                    variant="outline"
                    className={
                      suggestion.priority === 'high'
                        ? 'text-red-400 border-red-400'
                        : suggestion.priority === 'medium'
                        ? 'text-yellow-400 border-yellow-400'
                        : 'text-green-400 border-green-400'
                    }
                  >
                    {suggestion.priority.toUpperCase()}
                  </Badge>
                </div>
                <p className="text-gray-300 text-sm mb-3">{suggestion.description}</p>
                <div className="mb-3">
                  <span className="text-xs text-gray-500 font-medium">Implementation:</span>
                  <p className="text-xs text-gray-400 mt-1">{suggestion.implementation}</p>
                </div>
                {suggestion.benefits.length > 0 && (
                  <div>
                    <span className="text-xs text-gray-500 font-medium">Benefits:</span>
                    <ul className="mt-1 space-y-1">
                      {suggestion.benefits.map((benefit, idx) => (
                        <li key={idx} className="text-xs text-gray-400 flex items-start gap-2">
                          <span className="text-green-400 mt-0.5">✓</span>
                          <span>{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Metadata */}
      {result.metadata && (
        <div className="flex items-center justify-center gap-6 text-xs text-gray-500">
          <span>Analysis time: {result.metadata.analysisTime}ms</span>
          <span>Model: {result.metadata.modelUsed}</span>
          <span>Confidence: {Math.round(result.metadata.confidence * 100)}%</span>
        </div>
      )}
    </div>
  );
};
