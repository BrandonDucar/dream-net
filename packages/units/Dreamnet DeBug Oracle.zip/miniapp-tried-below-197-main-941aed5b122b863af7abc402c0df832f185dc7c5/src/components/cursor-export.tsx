'use client';

import type { FC } from 'react';
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Copy, Check, FileCode, Clock } from 'lucide-react';
import type { CursorTask } from '@/types/analysis';

interface CursorExportProps {
  tasks: CursorTask[];
}

export const CursorExport: FC<CursorExportProps> = ({ tasks }) => {
  const [copied, setCopied] = useState<boolean>(false);

  const formatCursorTasks = (): string => {
    return tasks
      .map(
        (task, idx) =>
          `## Task ${idx + 1}: ${task.title}\n\n` +
          `**Priority:** ${task.priority}/10\n` +
          `**Estimated Time:** ${task.estimatedTime}\n` +
          `**Tags:** ${task.tags.join(', ')}\n\n` +
          `### Description\n${task.description}\n\n` +
          `---\n`
      )
      .join('\n');
  };

  const handleCopy = async (): Promise<void> => {
    try {
      await navigator.clipboard.writeText(formatCursorTasks());
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error: unknown) {
      console.error('Failed to copy:', error);
    }
  };

  if (tasks.length === 0) {
    return (
      <Alert className="bg-gray-900/50 border-gray-800">
        <FileCode className="h-4 w-4 text-gray-400" />
        <AlertDescription className="text-gray-300">
          No tasks generated yet. Run an analysis to get actionable Cursor tasks.
        </AlertDescription>
      </Alert>
    );
  }

  const totalTime = tasks.reduce((acc, task) => {
    const hours = parseFloat(task.estimatedTime.replace(/[^0-9.]/g, '')) || 0;
    return acc + hours;
  }, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Ready-to-Paste Cursor Tasks</h2>
          <p className="text-gray-400 text-sm mt-1">
            {tasks.length} task{tasks.length !== 1 ? 's' : ''} • Estimated {totalTime.toFixed(1)}h total
          </p>
        </div>
        <Button
          onClick={handleCopy}
          className="bg-purple-600 hover:bg-purple-700 text-white"
        >
          {copied ? (
            <>
              <Check className="h-4 w-4 mr-2" />
              Copied!
            </>
          ) : (
            <>
              <Copy className="h-4 w-4 mr-2" />
              Copy All Tasks
            </>
          )}
        </Button>
      </div>

      {/* Tasks List */}
      <div className="space-y-4">
        {tasks.map((task, idx) => (
          <Card key={task.id} className="bg-gray-900/50 border-gray-800 hover:border-gray-700 transition-colors">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div className="mt-1 w-8 h-8 rounded-full bg-purple-600/20 border border-purple-600 flex items-center justify-center">
                    <span className="text-sm font-bold text-purple-400">{idx + 1}</span>
                  </div>
                  <div>
                    <CardTitle className="text-white text-base">{task.title}</CardTitle>
                    <CardDescription className="text-gray-400 text-sm mt-1">
                      {task.description}
                    </CardDescription>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <Badge
                    variant="outline"
                    className={
                      task.priority >= 8
                        ? 'text-red-400 border-red-400'
                        : task.priority >= 5
                        ? 'text-yellow-400 border-yellow-400'
                        : 'text-green-400 border-green-400'
                    }
                  >
                    P{task.priority}
                  </Badge>
                  <div className="flex items-center gap-1 text-xs text-gray-400">
                    <Clock className="h-3 w-3" />
                    <span>{task.estimatedTime}</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {task.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="bg-gray-800 text-gray-300 text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Preview Card */}
      <Card className="bg-black/30 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <FileCode className="h-4 w-4 text-purple-400" />
            Markdown Preview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="text-xs text-gray-300 overflow-x-auto p-4 bg-black/50 rounded-lg border border-gray-800">
            {formatCursorTasks()}
          </pre>
        </CardContent>
      </Card>
    </div>
  );
};
