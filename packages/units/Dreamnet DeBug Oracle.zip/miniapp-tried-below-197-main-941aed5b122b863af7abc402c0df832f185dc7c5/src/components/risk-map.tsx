'use client';

import type { FC } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, Database, Lock, Zap, Globe, Shield, Server } from 'lucide-react';
import type { RiskZone, RiskLevel } from '@/types/analysis';

interface RiskMapProps {
  riskZones: RiskZone[];
}

export const RiskMap: FC<RiskMapProps> = ({ riskZones }) => {
  const getDomainIcon = (domain: RiskZone['domain']): JSX.Element => {
    const icons: Record<RiskZone['domain'], JSX.Element> = {
      api: <Globe className="h-5 w-5" />,
      database: <Database className="h-5 w-5" />,
      auth: <Lock className="h-5 w-5" />,
      latency: <Zap className="h-5 w-5" />,
      blockchain: <Shield className="h-5 w-5" />,
      infrastructure: <Server className="h-5 w-5" />,
      security: <AlertTriangle className="h-5 w-5" />,
    };
    return icons[domain];
  };

  const getRiskColor = (level: RiskLevel): string => {
    const colors: Record<RiskLevel, string> = {
      low: 'bg-green-500/20 border-green-500 text-green-400',
      medium: 'bg-yellow-500/20 border-yellow-500 text-yellow-400',
      high: 'bg-orange-500/20 border-orange-500 text-orange-400',
      critical: 'bg-red-500/20 border-red-500 text-red-400',
    };
    return colors[level];
  };

  const getRiskScore = (level: RiskLevel): number => {
    const scores: Record<RiskLevel, number> = {
      low: 25,
      medium: 50,
      high: 75,
      critical: 100,
    };
    return scores[level];
  };

  if (riskZones.length === 0) {
    return (
      <Alert className="bg-green-900/20 border-green-800">
        <Shield className="h-4 w-4 text-green-400" />
        <AlertDescription className="text-green-300">
          No significant risk zones detected. Your architecture looks solid!
        </AlertDescription>
      </Alert>
    );
  }

  const criticalCount = riskZones.filter((z) => z.riskLevel === 'critical').length;
  const highCount = riskZones.filter((z) => z.riskLevel === 'high').length;

  return (
    <div className="space-y-6">
      {/* Summary */}
      <Alert className={criticalCount > 0 ? 'bg-red-900/20 border-red-800' : 'bg-yellow-900/20 border-yellow-800'}>
        <AlertTriangle className={`h-4 w-4 ${criticalCount > 0 ? 'text-red-400' : 'text-yellow-400'}`} />
        <AlertDescription className={criticalCount > 0 ? 'text-red-300' : 'text-yellow-300'}>
          Detected {riskZones.length} risk zone{riskZones.length !== 1 ? 's' : ''}
          {criticalCount > 0 && ` (${criticalCount} critical)`}
          {highCount > 0 && ` (${highCount} high)`}
        </AlertDescription>
      </Alert>

      {/* Risk Zones Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {riskZones.map((zone) => (
          <Card key={zone.id} className={`border-2 ${getRiskColor(zone.riskLevel)}`}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${getRiskColor(zone.riskLevel)}`}>
                    {getDomainIcon(zone.domain)}
                  </div>
                  <div>
                    <CardTitle className="text-white text-base">{zone.name}</CardTitle>
                    <CardDescription className="text-gray-400 text-xs capitalize">
                      {zone.domain} Domain
                    </CardDescription>
                  </div>
                </div>
                <Badge variant="outline" className={getRiskColor(zone.riskLevel)}>
                  {zone.riskLevel.toUpperCase()}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Risk Score Bar */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-400">Risk Score</span>
                  <span className="text-gray-300 font-semibold">{getRiskScore(zone.riskLevel)}/100</span>
                </div>
                <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all ${
                      zone.riskLevel === 'critical'
                        ? 'bg-red-500'
                        : zone.riskLevel === 'high'
                        ? 'bg-orange-500'
                        : zone.riskLevel === 'medium'
                        ? 'bg-yellow-500'
                        : 'bg-green-500'
                    }`}
                    style={{ width: `${getRiskScore(zone.riskLevel)}%` }}
                  />
                </div>
              </div>

              {/* Description */}
              <p className="text-sm text-gray-300">{zone.description}</p>

              {/* Mitigations */}
              {zone.mitigations.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-xs font-semibold text-gray-400">Recommended Mitigations:</h4>
                  <ul className="space-y-1">
                    {zone.mitigations.map((mitigation, idx) => (
                      <li key={idx} className="text-xs text-gray-300 flex items-start gap-2">
                        <span className="text-purple-400 mt-0.5">→</span>
                        <span>{mitigation}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};
