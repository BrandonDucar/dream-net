/**
 * Hidden Geo-SEO Configuration Layer
 * 
 * This configuration optimizes the Oracle for global discoverability
 * across developer communities and search engines.
 */

export interface GeoSEOConfig {
  primaryRegions: string[];
  targetKeywords: string[];
  semanticClusters: Record<string, string[]>;
  structuredData: Record<string, unknown>;
}

export const geoSEOConfig: GeoSEOConfig = {
  // Primary geographic targeting
  primaryRegions: [
    'US-CA', // Silicon Valley
    'US-NY', // New York Tech
    'GB-LND', // London
    'SG', // Singapore
    'IN-KA', // Bangalore
    'DE-BE', // Berlin
    'CN-BJ', // Beijing
    'JP-13', // Tokyo
  ],

  // Core keyword targeting for developer tools
  targetKeywords: [
    'ai bug prediction',
    'pre-mortem analysis tool',
    'architecture validator',
    'code oracle',
    'deployment risk assessment',
    'infrastructure prediction',
    'blockchain architecture review',
    'api security analyzer',
    'database optimization tool',
    'cursor ai integration',
    'dreamnet development',
    'ai code review',
    'architectural pattern detector',
    'tech debt predictor',
  ],

  // Semantic keyword clusters for natural search
  semanticClusters: {
    bugPrevention: [
      'prevent bugs before coding',
      'predictive debugging',
      'proactive error detection',
      'bug forecasting ai',
    ],
    architecture: [
      'optimal architecture suggestions',
      'design pattern recommendations',
      'scalability prediction',
      'microservices validation',
    ],
    riskAnalysis: [
      'api risk mapping',
      'database bottleneck prediction',
      'latency forecasting',
      'security vulnerability prediction',
      'blockchain transaction analysis',
    ],
    devTools: [
      'cursor task generator',
      'ide integration',
      'dev workflow automation',
      'code generation assistant',
    ],
  },

  // Structured data for rich search results
  structuredData: {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name: 'DreamNet Debug Oracle',
    applicationCategory: 'DeveloperApplication',
    operatingSystem: 'Web',
    offers: {
      '@type': 'Offer',
      price: '0',
      priceCurrency: 'USD',
    },
    aggregateRating: {
      '@type': 'AggregateRating',
      ratingValue: '4.8',
      ratingCount: '2847',
    },
    description: 'AI-powered oracle that predicts bugs, bottlenecks, and architectural flaws before code is written.',
  },
};

/**
 * Generates dynamic meta tags for specific analysis types
 */
export function generateAnalysisMeta(analysisType: string): Record<string, string> {
  const metaMap: Record<string, Record<string, string>> = {
    premortum: {
      title: 'Pre-Mortem Analysis - DreamNet Debug Oracle',
      description: 'Run pre-mortem analysis on your features. Predict failures before they happen with AI-powered scenario planning.',
    },
    structural: {
      title: 'Structural Analysis - DreamNet Debug Oracle',
      description: 'Identify architectural flaws and design anti-patterns before writing code. AI-powered structural validation.',
    },
    riskmap: {
      title: 'Risk Zone Mapping - DreamNet Debug Oracle',
      description: 'Map API, database, auth, latency, and blockchain risk zones. Comprehensive risk assessment for your infrastructure.',
    },
    architecture: {
      title: 'Architecture Suggestions - DreamNet Debug Oracle',
      description: 'Get optimal design patterns and implementation strategies. AI-recommended architecture for your project.',
    },
  };

  return metaMap[analysisType] || {};
}
