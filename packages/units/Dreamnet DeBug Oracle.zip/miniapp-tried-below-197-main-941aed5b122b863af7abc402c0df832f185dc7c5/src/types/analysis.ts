export type AnalysisType = 'premortum' | 'structural' | 'riskmap' | 'architecture';

export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';

export interface Issue {
  id: string;
  title: string;
  description: string;
  severity: RiskLevel;
  category: string;
  impact: string;
  likelihood: string;
}

export interface RiskZone {
  id: string;
  name: string;
  domain: 'api' | 'database' | 'auth' | 'latency' | 'blockchain' | 'infrastructure' | 'security';
  riskLevel: RiskLevel;
  description: string;
  mitigations: string[];
}

export interface Suggestion {
  id: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high';
  implementation: string;
  benefits: string[];
}

export interface CursorTask {
  id: string;
  title: string;
  description: string;
  priority: number;
  tags: string[];
  estimatedTime: string;
}

export interface AnalysisResponse {
  success: boolean;
  message: string;
  issues: Issue[];
  riskZones: RiskZone[];
  suggestions: Suggestion[];
  cursorTasks: CursorTask[];
  metadata?: {
    analysisTime: number;
    modelUsed: string;
    confidence: number;
  };
}

export interface AnalysisRequest {
  input: string;
  analysisType: AnalysisType;
}
