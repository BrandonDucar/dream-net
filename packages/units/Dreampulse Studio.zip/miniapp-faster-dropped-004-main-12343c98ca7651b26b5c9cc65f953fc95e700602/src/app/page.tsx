'use client'
import { useState, useEffect } from 'react';
import { ContentGenerator } from '@/components/content-generator';
import { HistoryPanel } from '@/components/history-panel';
import { ApiKeyInput } from '@/components/api-key-input';
import { Sparkles } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Home(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [apiKey, setApiKey] = useState<string>('');
  const [refreshHistory, setRefreshHistory] = useState<number>(0);

  const handleGenerationComplete = (): void => {
    setRefreshHistory(prev => prev + 1);
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <div className="container mx-auto px-4 py-8 md:py-12">
        {/* Header */}
        <div className="text-center mb-8 md:mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Sparkles className="w-8 h-8 text-purple-600" />
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              DreamPulse Studio
            </h1>
          </div>
          <p className="text-gray-600 text-lg">
            Generate quotes, captions, prompts, hashtags & hooks instantly
          </p>
        </div>

        {/* API Key Input */}
        {!apiKey && (
          <div className="max-w-2xl mx-auto mb-8">
            <ApiKeyInput onApiKeySet={setApiKey} />
          </div>
        )}

        {/* Main Content */}
        {apiKey && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Generator Section */}
            <div className="lg:col-span-2">
              <ContentGenerator 
                apiKey={apiKey} 
                onGenerationComplete={handleGenerationComplete}
              />
            </div>

            {/* History Panel */}
            <div className="lg:col-span-1">
              <HistoryPanel refreshTrigger={refreshHistory} />
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
