'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Key, ExternalLink } from 'lucide-react';

interface ApiKeyInputProps {
  onApiKeySet: (key: string) => void;
}

export function ApiKeyInput({ onApiKeySet }: ApiKeyInputProps): JSX.Element {
  const [inputValue, setInputValue] = useState<string>('');

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    if (inputValue.trim()) {
      onApiKeySet(inputValue.trim());
    }
  };

  return (
    <Card className="border-2 border-purple-200 shadow-lg">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Key className="w-5 h-5 text-purple-600" />
          <CardTitle>API Key Required</CardTitle>
        </div>
        <CardDescription>
          Enter your OpenAI API key to start generating content. Your key is stored locally and never sent to our servers.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="apiKey">OpenAI API Key</Label>
            <Input
              id="apiKey"
              type="password"
              placeholder="sk-..."
              value={inputValue}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setInputValue(e.target.value)}
              className="font-mono"
            />
          </div>
          <div className="flex items-start gap-2 text-sm text-gray-600">
            <ExternalLink className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <p>
              Don&apos;t have an API key?{' '}
              <a
                href="https://platform.openai.com/api-keys"
                target="_blank"
                rel="noopener noreferrer"
                className="text-purple-600 hover:underline"
              >
                Get one from OpenAI
              </a>
            </p>
          </div>
          <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700">
            Start Generating
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
