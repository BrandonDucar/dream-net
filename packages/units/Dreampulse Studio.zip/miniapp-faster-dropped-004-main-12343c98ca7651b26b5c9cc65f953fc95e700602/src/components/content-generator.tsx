'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Loader2, Sparkles } from 'lucide-react';
import { GeneratedContent } from '@/components/generated-content';
import type { ContentResult } from '@/types/content';

interface ContentGeneratorProps {
  apiKey: string;
  onGenerationComplete: () => void;
}

export function ContentGenerator({ apiKey, onGenerationComplete }: ContentGeneratorProps): JSX.Element {
  const [theme, setTheme] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [content, setContent] = useState<ContentResult | null>(null);
  const [error, setError] = useState<string>('');

  const handleGenerate = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    if (!theme.trim()) return;

    setLoading(true);
    setError('');
    setContent(null);

    try {
      const response = await fetch('/api/proxy', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          protocol: 'https',
          origin: 'api.openai.com',
          path: '/v1/chat/completions',
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
          },
          body: {
            model: 'gpt-4o-mini',
            messages: [
              {
                role: 'system',
                content: `You are a social media content expert. Generate engaging content for the given theme. Return a JSON object with these exact fields:
{
  "quote": "An inspirational quote related to the theme",
  "memeCaption": "A catchy meme caption",
  "imagePrompt": "A detailed prompt for AI image generation",
  "hashtags": ["hashtag1", "hashtag2", "hashtag3", "hashtag4", "hashtag5"],
  "tiktokHook": "An attention-grabbing TikTok hook"
}

Make it engaging, shareable, and on-brand for social media.`
              },
              {
                role: 'user',
                content: `Generate social media content for the theme: "${theme}"`
              }
            ],
            temperature: 0.9,
            response_format: { type: 'json_object' }
          },
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate content. Please check your API key.');
      }

      const data = await response.json();
      const generatedText = data.choices[0].message.content;
      const parsed = JSON.parse(generatedText) as ContentResult;

      setContent(parsed);

      // Save to history
      const history = JSON.parse(localStorage.getItem('contentHistory') || '[]') as Array<{
        theme: string;
        content: ContentResult;
        timestamp: number;
      }>;
      
      history.unshift({
        theme,
        content: parsed,
        timestamp: Date.now(),
      });

      // Keep only last 20 items
      if (history.length > 20) {
        history.pop();
      }

      localStorage.setItem('contentHistory', JSON.stringify(history));
      onGenerationComplete();

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="border-2 border-purple-200 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            Generate Content
          </CardTitle>
          <CardDescription>
            Enter a theme to generate quotes, captions, prompts, hashtags, and hooks
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleGenerate} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="theme">Theme</Label>
              <Input
                id="theme"
                placeholder="e.g., crypto, mindset, hustle, wellness, motivation..."
                value={theme}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTheme(e.target.value)}
                disabled={loading}
              />
            </div>
            <Button 
              type="submit" 
              className="w-full bg-purple-600 hover:bg-purple-700"
              disabled={loading || !theme.trim()}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate Content
                </>
              )}
            </Button>
          </form>

          {error && (
            <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-600 text-sm">
              {error}
            </div>
          )}
        </CardContent>
      </Card>

      {content && <GeneratedContent theme={theme} content={content} />}
    </div>
  );
}
