'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Copy, 
  Download, 
  Quote, 
  Image, 
  Hash, 
  Video, 
  MessageSquare,
  Check
} from 'lucide-react';
import { useState } from 'react';
import type { ContentResult } from '@/types/content';

interface GeneratedContentProps {
  theme: string;
  content: ContentResult;
}

export function GeneratedContent({ theme, content }: GeneratedContentProps): JSX.Element {
  const [copied, setCopied] = useState<string>('');

  const handleCopy = async (text: string, id: string): Promise<void> => {
    await navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(''), 2000);
  };

  const handleCopyAll = async (): Promise<void> => {
    const allContent = `
THEME: ${theme}

QUOTE:
${content.quote}

MEME CAPTION:
${content.memeCaption}

IMAGE PROMPT:
${content.imagePrompt}

HASHTAGS:
${content.hashtags.join(' ')}

TIKTOK HOOK:
${content.tiktokHook}
    `.trim();

    await navigator.clipboard.writeText(allContent);
    setCopied('all');
    setTimeout(() => setCopied(''), 2000);
  };

  const handleDownload = (): void => {
    const allContent = `
THEME: ${theme}

QUOTE:
${content.quote}

MEME CAPTION:
${content.memeCaption}

IMAGE PROMPT:
${content.imagePrompt}

HASHTAGS:
${content.hashtags.join(' ')}

TIKTOK HOOK:
${content.tiktokHook}
    `.trim();

    const blob = new Blob([allContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `social-content-${theme.toLowerCase().replace(/\s+/g, '-')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      {/* Export Buttons */}
      <div className="flex gap-2">
        <Button
          onClick={handleCopyAll}
          variant="outline"
          className="flex-1"
        >
          {copied === 'all' ? (
            <>
              <Check className="w-4 h-4 mr-2" />
              Copied!
            </>
          ) : (
            <>
              <Copy className="w-4 h-4 mr-2" />
              Copy All
            </>
          )}
        </Button>
        <Button
          onClick={handleDownload}
          variant="outline"
          className="flex-1"
        >
          <Download className="w-4 h-4 mr-2" />
          Download
        </Button>
      </div>

      {/* Quote */}
      <Card className="border-l-4 border-l-purple-500">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Quote className="w-5 h-5 text-purple-600" />
            Inspirational Quote
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-gray-700 italic">&ldquo;{content.quote}&rdquo;</p>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => handleCopy(content.quote, 'quote')}
          >
            {copied === 'quote' ? (
              <>
                <Check className="w-3 h-3 mr-1" />
                Copied
              </>
            ) : (
              <>
                <Copy className="w-3 h-3 mr-1" />
                Copy
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Meme Caption */}
      <Card className="border-l-4 border-l-pink-500">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-pink-600" />
            Meme Caption
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-gray-700 font-medium">{content.memeCaption}</p>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => handleCopy(content.memeCaption, 'meme')}
          >
            {copied === 'meme' ? (
              <>
                <Check className="w-3 h-3 mr-1" />
                Copied
              </>
            ) : (
              <>
                <Copy className="w-3 h-3 mr-1" />
                Copy
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Image Prompt */}
      <Card className="border-l-4 border-l-blue-500">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Image className="w-5 h-5 text-blue-600" />
            AI Image Prompt
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-gray-700">{content.imagePrompt}</p>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => handleCopy(content.imagePrompt, 'image')}
          >
            {copied === 'image' ? (
              <>
                <Check className="w-3 h-3 mr-1" />
                Copied
              </>
            ) : (
              <>
                <Copy className="w-3 h-3 mr-1" />
                Copy
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Hashtags */}
      <Card className="border-l-4 border-l-green-500">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Hash className="w-5 h-5 text-green-600" />
            Hashtags
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap gap-2">
            {content.hashtags.map((tag: string, index: number) => (
              <Badge key={index} variant="secondary" className="text-sm">
                #{tag}
              </Badge>
            ))}
          </div>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => handleCopy(content.hashtags.map((tag: string) => `#${tag}`).join(' '), 'hashtags')}
          >
            {copied === 'hashtags' ? (
              <>
                <Check className="w-3 h-3 mr-1" />
                Copied
              </>
            ) : (
              <>
                <Copy className="w-3 h-3 mr-1" />
                Copy All
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* TikTok Hook */}
      <Card className="border-l-4 border-l-orange-500">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Video className="w-5 h-5 text-orange-600" />
            TikTok Hook
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-gray-700 font-semibold">{content.tiktokHook}</p>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => handleCopy(content.tiktokHook, 'tiktok')}
          >
            {copied === 'tiktok' ? (
              <>
                <Check className="w-3 h-3 mr-1" />
                Copied
              </>
            ) : (
              <>
                <Copy className="w-3 h-3 mr-1" />
                Copy
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
