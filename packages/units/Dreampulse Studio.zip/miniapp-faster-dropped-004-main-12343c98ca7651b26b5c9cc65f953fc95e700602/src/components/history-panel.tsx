'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { History, Trash2, Calendar } from 'lucide-react';
import type { ContentResult } from '@/types/content';

interface HistoryItem {
  theme: string;
  content: ContentResult;
  timestamp: number;
}

interface HistoryPanelProps {
  refreshTrigger: number;
}

export function HistoryPanel({ refreshTrigger }: HistoryPanelProps): JSX.Element {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<HistoryItem | null>(null);

  useEffect(() => {
    loadHistory();
  }, [refreshTrigger]);

  const loadHistory = (): void => {
    const stored = localStorage.getItem('contentHistory');
    if (stored) {
      setHistory(JSON.parse(stored) as HistoryItem[]);
    }
  };

  const clearHistory = (): void => {
    localStorage.removeItem('contentHistory');
    setHistory([]);
    setSelectedItem(null);
  };

  const deleteItem = (timestamp: number): void => {
    const updated = history.filter((item: HistoryItem) => item.timestamp !== timestamp);
    localStorage.setItem('contentHistory', JSON.stringify(updated));
    setHistory(updated);
    if (selectedItem?.timestamp === timestamp) {
      setSelectedItem(null);
    }
  };

  const formatDate = (timestamp: number): string => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="space-y-4">
      <Card className="border-2 border-purple-200 shadow-lg">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <History className="w-5 h-5" />
                History
              </CardTitle>
              <CardDescription>
                {history.length} generation{history.length !== 1 ? 's' : ''}
              </CardDescription>
            </div>
            {history.length > 0 && (
              <Button
                size="sm"
                variant="ghost"
                onClick={clearHistory}
                className="text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {history.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <History className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>No history yet</p>
              <p className="text-sm">Generate content to see it here</p>
            </div>
          ) : (
            <ScrollArea className="h-[600px] pr-4">
              <div className="space-y-3">
                {history.map((item: HistoryItem) => (
                  <div
                    key={item.timestamp}
                    className={`p-3 rounded-lg border-2 cursor-pointer transition-colors ${
                      selectedItem?.timestamp === item.timestamp
                        ? 'border-purple-400 bg-purple-50'
                        : 'border-gray-200 hover:border-purple-200'
                    }`}
                    onClick={() => setSelectedItem(item)}
                  >
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <Badge variant="outline" className="font-semibold">
                        {item.theme}
                      </Badge>
                      <button
                        onClick={(e: React.MouseEvent<HTMLButtonElement>) => {
                          e.stopPropagation();
                          deleteItem(item.timestamp);
                        }}
                        className="text-gray-400 hover:text-red-600"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                    <p className="text-xs text-gray-500 flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {formatDate(item.timestamp)}
                    </p>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>

      {/* Selected Item Preview */}
      {selectedItem && (
        <Card className="border-2 border-purple-200">
          <CardHeader>
            <CardTitle className="text-lg">Preview</CardTitle>
            <CardDescription>{selectedItem.theme}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div>
              <p className="font-semibold text-gray-700 mb-1">Quote:</p>
              <p className="text-gray-600 italic">&ldquo;{selectedItem.content.quote}&rdquo;</p>
            </div>
            <div>
              <p className="font-semibold text-gray-700 mb-1">Meme Caption:</p>
              <p className="text-gray-600">{selectedItem.content.memeCaption}</p>
            </div>
            <div>
              <p className="font-semibold text-gray-700 mb-1">Hashtags:</p>
              <div className="flex flex-wrap gap-1">
                {selectedItem.content.hashtags.map((tag: string, index: number) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    #{tag}
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
