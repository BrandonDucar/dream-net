export interface ContentResult {
  quote: string;
  memeCaption: string;
  imagePrompt: string;
  hashtags: string[];
  tiktokHook: string;
}
