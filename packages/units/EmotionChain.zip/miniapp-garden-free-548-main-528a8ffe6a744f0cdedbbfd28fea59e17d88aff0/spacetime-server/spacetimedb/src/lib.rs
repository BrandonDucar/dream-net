use spacetimedb::{table, reducer, ReducerContext, Identity, Table, Timestamp};

const ALLOWED_MOODS: [&str; 8] = [
    "happy",
    "sad",
    "neutral",
    "excited",
    "anxious",
    "calm",
    "angry",
    "tired",
];

// --- Table Definitions ---

#[table(name = mood_entry, public)]
#[derive(Clone)]
pub struct MoodEntry {
    #[primary_key]
    identity: Identity,
    mood: String,
    metadata: Option<String>,
    timestamp: Timestamp,
    wallet_address: String,
}

#[table(name = user_profile, public)]
#[derive(Clone)]
pub struct UserProfile {
    #[primary_key]
    identity: Identity,
    username: String,
    wallet_address: String,
    current_theme_colors: String,
}

#[table(name = mood_community, public)]
#[derive(Clone)]
pub struct MoodCommunity {
    #[primary_key]
    mood_type: String,
    member_count: u32,
    last_active_timestamp: Timestamp,
}

// Result tables for query-like reducers
#[table(name = user_mood_query_results, public)]
#[derive(Clone)]
pub struct UserMoodQueryResult {
    #[primary_key]
    #[auto_inc]
    id: u64,
    requester: Identity,
    entry_identity: Identity,
    mood: String,
    metadata: Option<String>,
    timestamp: Timestamp,
    wallet_address: String,
}

#[table(name = recent_mood_query_results, public)]
#[derive(Clone)]
pub struct RecentMoodQueryResult {
    #[primary_key]
    #[auto_inc]
    id: u64,
    requester: Identity,
    entry_identity: Identity,
    mood: String,
    metadata: Option<String>,
    timestamp: Timestamp,
    wallet_address: String,
}

// --- Helper Functions ---

fn is_allowed_mood(mood: &str) -> bool {
    ALLOWED_MOODS.contains(&mood)
}

fn count_members_with_mood(ctx: &ReducerContext, mood: &str) -> u32 {
    let mut count: u32 = 0;
    for entry in ctx.db.mood_entry().iter() {
        if entry.mood == mood {
            count = count.saturating_add(1);
        }
    }
    count
}

fn upsert_mood_community(ctx: &ReducerContext, mood: &str) {
    let member_count = count_members_with_mood(ctx, mood);
    if let Some(mut community) = ctx.db.mood_community().mood_type().find(&mood.to_string()) {
        community.member_count = member_count;
        community.last_active_timestamp = ctx.timestamp;
        ctx.db.mood_community().mood_type().update(community);
    } else {
        let new_row = MoodCommunity {
            mood_type: mood.to_string(),
            member_count,
            last_active_timestamp: ctx.timestamp,
        };
        ctx.db.mood_community().insert(new_row);
    }
}

fn clear_user_mood_query_results(ctx: &ReducerContext) {
    let mut to_delete: Vec<u64> = Vec::new();
    for row in ctx.db.user_mood_query_results().iter() {
        if row.requester == ctx.sender {
            to_delete.push(row.id);
        }
    }
    for id in to_delete {
        ctx.db.user_mood_query_results().id().delete(&id);
    }
}

fn clear_recent_mood_query_results(ctx: &ReducerContext) {
    let mut to_delete: Vec<u64> = Vec::new();
    for row in ctx.db.recent_mood_query_results().iter() {
        if row.requester == ctx.sender {
            to_delete.push(row.id);
        }
    }
    for id in to_delete {
        ctx.db.recent_mood_query_results().id().delete(&id);
    }
}

// --- Reducers ---

#[reducer]
pub fn record_mood(
    ctx: &ReducerContext,
    mood: String,
    metadata: Option<String>,
    wallet_address: String,
) -> Result<(), String> {
    if !is_allowed_mood(&mood) {
        return Err(format!("Invalid mood '{}'. Allowed: {:?}", mood, ALLOWED_MOODS));
    }

    let mut prev_mood: Option<String> = None;

    if let Some(mut entry) = ctx.db.mood_entry().identity().find(&ctx.sender) {
        prev_mood = Some(entry.mood.clone());
        entry.mood = mood.clone();
        entry.metadata = metadata.clone();
        entry.timestamp = ctx.timestamp;
        entry.wallet_address = wallet_address.clone();
        ctx.db.mood_entry().identity().update(entry);
    } else {
        let new_entry = MoodEntry {
            identity: ctx.sender,
            mood: mood.clone(),
            metadata: metadata.clone(),
            timestamp: ctx.timestamp,
            wallet_address: wallet_address.clone(),
        };
        ctx.db.mood_entry().insert(new_entry);
    }

    // Optionally sync wallet_address to profile if it exists
    if let Some(mut profile) = ctx.db.user_profile().identity().find(&ctx.sender) {
        profile.wallet_address = wallet_address.clone();
        ctx.db.user_profile().identity().update(profile);
    }

    // Update mood community counts for both previous and new mood
    if let Some(old) = prev_mood {
        if old != mood {
            upsert_mood_community(ctx, &old);
        }
    }
    upsert_mood_community(ctx, &mood);

    Ok(())
}

#[reducer]
pub fn update_theme(ctx: &ReducerContext, theme_colors: String) -> Result<(), String> {
    if let Some(mut profile) = ctx.db.user_profile().identity().find(&ctx.sender) {
        profile.current_theme_colors = theme_colors.clone();
        ctx.db.user_profile().identity().update(profile);
    } else {
        // Try to source wallet from any existing mood entry; else empty
        let wallet = if let Some(entry) = ctx.db.mood_entry().identity().find(&ctx.sender) {
            entry.wallet_address.clone()
        } else {
            String::new()
        };
        let profile = UserProfile {
            identity: ctx.sender,
            username: String::new(),
            wallet_address: wallet,
            current_theme_colors: theme_colors.clone(),
        };
        ctx.db.user_profile().insert(profile);
    }
    Ok(())
}

#[reducer]
pub fn join_mood_community(ctx: &ReducerContext, mood: String) -> Result<(), String> {
    if !is_allowed_mood(&mood) {
        return Err(format!("Invalid mood '{}'. Allowed: {:?}", mood, ALLOWED_MOODS));
    }

    let mut prev_mood: Option<String> = None;

    if let Some(mut entry) = ctx.db.mood_entry().identity().find(&ctx.sender) {
        prev_mood = Some(entry.mood.clone());
        entry.mood = mood.clone();
        entry.timestamp = ctx.timestamp;
        ctx.db.mood_entry().identity().update(entry);
    } else {
        let new_entry = MoodEntry {
            identity: ctx.sender,
            mood: mood.clone(),
            metadata: None,
            timestamp: ctx.timestamp,
            wallet_address: String::new(),
        };
        ctx.db.mood_entry().insert(new_entry);
    }

    // Update both affected communities' counts
    if let Some(old) = prev_mood {
        if old != mood {
            upsert_mood_community(ctx, &old);
        }
    }
    upsert_mood_community(ctx, &mood);

    Ok(())
}

#[reducer]
pub fn get_user_moods(ctx: &ReducerContext, user_identity: Identity) -> Result<(), String> {
    // Clear previous results for this requester
    clear_user_mood_query_results(ctx);

    // Insert matching entries (in this schema, at most one)
    for entry in ctx.db.mood_entry().iter() {
        if entry.identity == user_identity {
            let row = UserMoodQueryResult {
                id: 0,
                requester: ctx.sender,
                entry_identity: entry.identity,
                mood: entry.mood.clone(),
                metadata: entry.metadata.clone(),
                timestamp: entry.timestamp,
                wallet_address: entry.wallet_address.clone(),
            };
            ctx.db.user_mood_query_results().insert(row);
        }
    }

    Ok(())
}

#[reducer]
pub fn get_recent_moods(ctx: &ReducerContext) -> Result<(), String> {
    // Clear previous results for this requester
    clear_recent_mood_query_results(ctx);

    // Collect and sort by timestamp desc
    let mut entries: Vec<MoodEntry> = ctx.db.mood_entry().iter().collect();
    entries.sort_by_key(|e| std::cmp::Reverse(e.timestamp.to_micros_since_unix_epoch()));

    // Take up to 50
    for entry in entries.into_iter().take(50) {
        let row = RecentMoodQueryResult {
            id: 0,
            requester: ctx.sender,
            entry_identity: entry.identity,
            mood: entry.mood.clone(),
            metadata: entry.metadata.clone(),
            timestamp: entry.timestamp,
            wallet_address: entry.wallet_address.clone(),
        };
        ctx.db.recent_mood_query_results().insert(row);
    }

    Ok(())
}