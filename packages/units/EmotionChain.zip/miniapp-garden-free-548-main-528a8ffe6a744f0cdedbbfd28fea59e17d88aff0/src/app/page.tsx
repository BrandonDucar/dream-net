'use client'
import { useState, useEffect, useMemo } from 'react';
import { useAccount } from 'wagmi';
import { useSpacetimeMoodChain } from '@/hooks/use-spacetime-moodchain';
import { MoodSelector } from '@/components/mood-selector';
import { MoodFeed } from '@/components/mood-feed';
import { MoodCommunities } from '@/components/mood-communities';
import { ThemeManager } from '@/components/theme-manager';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Loader2, Wallet } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function MoodChainPage() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const { address, status } = useAccount();
  const moodChain = useSpacetimeMoodChain();
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const currentMood = useMemo(() => {
    return moodChain.currentUserMood?.mood || null;
  }, [moodChain.currentUserMood]);

  const moodCount = useMemo(() => {
    return moodChain.moods.size;
  }, [moodChain.moods]);

  if (!isClient) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50 dark:from-purple-950 dark:via-blue-950 dark:to-pink-950 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50 dark:from-purple-950 dark:via-blue-950 dark:to-pink-950">
      <ThemeManager currentMood={currentMood} />
      
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <div className="mb-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 bg-clip-text text-transparent">
            MoodChain
          </h1>
          <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">
            Encode emotions onchain • Discover communities by mood • Earn emotion-reactive rewards
          </p>
          
          {status === 'connecting' || status === 'reconnecting' ? (
            <div className="flex items-center justify-center gap-2 text-gray-600 dark:text-gray-400">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Connecting wallet...</span>
            </div>
          ) : !address ? (
            <Card className="max-w-md mx-auto bg-white/80 dark:bg-gray-900/80 backdrop-blur">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 justify-center">
                  <Wallet className="w-5 h-5" />
                  Base Smart Wallet Required
                </CardTitle>
                <CardDescription>
                  Open MoodChain in Warpcast to connect your Base smart wallet and start sharing emotions onchain.
                </CardDescription>
              </CardHeader>
            </Card>
          ) : (
            <div className="flex flex-wrap items-center justify-center gap-3">
              <Badge variant="secondary" className="text-sm">
                <Wallet className="w-4 h-4 mr-1" />
                {`${address.slice(0, 6)}...${address.slice(-4)}`}
              </Badge>
              <Badge variant="outline" className="text-sm">
                {moodCount} emotions onchain
              </Badge>
              {moodChain.connected && (
                <Badge variant="default" className="text-sm bg-green-600">
                  Real-time updates active
                </Badge>
              )}
            </div>
          )}
        </div>

        {address && (
          <>
            <div className="mb-8">
              <MoodSelector
                currentMood={currentMood}
                onMoodSelect={(mood, metadata) => {
                  moodChain.recordMood(mood, metadata, address);
                }}
                disabled={!moodChain.connected}
              />
            </div>

            <Tabs defaultValue="feed" className="space-y-6">
              <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
                <TabsTrigger value="feed">Mood Feed</TabsTrigger>
                <TabsTrigger value="communities">Communities</TabsTrigger>
              </TabsList>

              <TabsContent value="feed" className="space-y-4">
                <MoodFeed moods={Array.from(moodChain.moods.values())} />
              </TabsContent>

              <TabsContent value="communities" className="space-y-4">
                <MoodCommunities
                  communities={Array.from(moodChain.communities.values())}
                  onJoinCommunity={(mood) => moodChain.joinMoodCommunity(mood)}
                  currentUserMood={currentMood}
                  disabled={!moodChain.connected}
                />
              </TabsContent>
            </Tabs>
          </>
        )}

        {!moodChain.connected && (
          <div className="text-center mt-8 text-gray-600 dark:text-gray-400">
            {moodChain.statusMessage}
          </div>
        )}
      </div>
    </div>
  );
}
