'use client';

import type { MoodCommunity } from '@/spacetime_module_bindings';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Users, TrendingUp } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface MoodCommunitiesProps {
  communities: MoodCommunity[];
  onJoinCommunity: (mood: string) => void;
  currentUserMood: string | null;
  disabled?: boolean;
}

const MOOD_GRADIENTS: Record<string, string> = {
  'motivated': 'from-orange-400 to-red-500',
  'grateful': 'from-pink-400 to-rose-500',
  'stressed': 'from-gray-400 to-gray-600',
  'focused': 'from-blue-400 to-indigo-500',
  'rebuilding': 'from-green-400 to-emerald-500',
  'recovering': 'from-purple-400 to-indigo-500',
  'grinding': 'from-amber-400 to-orange-500',
  'lost': 'from-slate-400 to-gray-500',
  'pumped': 'from-yellow-400 to-orange-500',
  'ascendant': 'from-violet-400 to-purple-500',
  'chill': 'from-cyan-400 to-blue-500',
  'locked-in': 'from-red-400 to-rose-500',
};

export function MoodCommunities({ 
  communities, 
  onJoinCommunity, 
  currentUserMood,
  disabled 
}: MoodCommunitiesProps) {
  const sortedCommunities = [...communities].sort((a, b) => b.memberCount - a.memberCount);

  if (sortedCommunities.length === 0) {
    return (
      <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur">
        <CardContent className="py-12 text-center text-gray-500">
          <p>No communities formed yet. Record a mood to create the first community!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {sortedCommunities.map((community) => {
        const isUserInCommunity = currentUserMood === community.moodType;
        const gradient = MOOD_GRADIENTS[community.moodType] || 'from-gray-400 to-gray-600';
        const lastActive = formatDistanceToNow(community.lastActiveTimestamp.toDate(), { 
          addSuffix: true 
        });

        return (
          <Card 
            key={community.moodType}
            className={`bg-white/80 dark:bg-gray-900/80 backdrop-blur hover:shadow-xl transition-all ${
              isUserInCommunity ? 'ring-2 ring-purple-500' : ''
            }`}
          >
            <CardHeader>
              <div className={`w-full h-2 rounded-full bg-gradient-to-r ${gradient} mb-3`} />
              <CardTitle className="flex items-center justify-between">
                <span className="capitalize">{community.moodType}</span>
                {isUserInCommunity && (
                  <Badge variant="default" className="bg-purple-600">
                    Your Mood
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>
                <div className="flex items-center gap-2 mt-2">
                  <Users className="w-4 h-4" />
                  <span>{community.memberCount} {community.memberCount === 1 ? 'member' : 'members'}</span>
                </div>
                <div className="flex items-center gap-2 mt-1 text-xs">
                  <TrendingUp className="w-3 h-3" />
                  <span>Active {lastActive}</span>
                </div>
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={() => onJoinCommunity(community.moodType)}
                className={`w-full bg-gradient-to-r ${gradient} hover:opacity-90 text-white`}
                disabled={disabled || isUserInCommunity}
              >
                {isUserInCommunity ? 'Already In Community' : 'Join Community'}
              </Button>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
