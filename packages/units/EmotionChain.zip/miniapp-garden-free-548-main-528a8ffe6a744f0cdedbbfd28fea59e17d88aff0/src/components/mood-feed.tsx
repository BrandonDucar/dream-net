'use client';

import { useMemo } from 'react';
import type { MoodEntry } from '@/spacetime_module_bindings';
import { Card, CardContent, CardHeader } from './ui/card';
import { Badge } from './ui/badge';
import { formatDistanceToNow } from 'date-fns';

interface MoodFeedProps {
  moods: MoodEntry[];
}

const MOOD_COLORS: Record<string, string> = {
  'motivated': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200',
  'grateful': 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200',
  'stressed': 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200',
  'focused': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
  'rebuilding': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
  'recovering': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
  'grinding': 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200',
  'lost': 'bg-slate-100 text-slate-800 dark:bg-slate-900 dark:text-slate-200',
  'pumped': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
  'ascendant': 'bg-violet-100 text-violet-800 dark:bg-violet-900 dark:text-violet-200',
  'chill': 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-200',
  'locked-in': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
};

export function MoodFeed({ moods }: MoodFeedProps) {
  const sortedMoods = useMemo(() => {
    return [...moods].sort((a, b) => {
      const timeA = a.timestamp.toDate().getTime();
      const timeB = b.timestamp.toDate().getTime();
      return timeB - timeA;
    });
  }, [moods]);

  if (sortedMoods.length === 0) {
    return (
      <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur">
        <CardContent className="py-12 text-center text-gray-500">
          <p>No moods recorded yet. Be the first to share your emotions onchain!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {sortedMoods.map((mood) => {
        const timeAgo = formatDistanceToNow(mood.timestamp.toDate(), { addSuffix: true });
        const moodColorClass = MOOD_COLORS[mood.mood] || 'bg-gray-100 text-gray-800';
        
        return (
          <Card 
            key={mood.identity.toHexString()} 
            className="bg-white/80 dark:bg-gray-900/80 backdrop-blur hover:shadow-lg transition-shadow"
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <Badge className={moodColorClass}>
                  {mood.mood}
                </Badge>
                <span className="text-xs text-gray-500">{timeAgo}</span>
              </div>
            </CardHeader>
            {mood.metadata && (
              <CardContent className="pt-0">
                <p className="text-sm text-gray-700 dark:text-gray-300 italic">
                  "{mood.metadata}"
                </p>
              </CardContent>
            )}
            <CardContent className="pt-2 pb-4">
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <span className="font-mono">
                  {mood.walletAddress
                    ? `${mood.walletAddress.slice(0, 6)}...${mood.walletAddress.slice(-4)}`
                    : `${mood.identity.toHexString().slice(0, 6)}...`}
                </span>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
