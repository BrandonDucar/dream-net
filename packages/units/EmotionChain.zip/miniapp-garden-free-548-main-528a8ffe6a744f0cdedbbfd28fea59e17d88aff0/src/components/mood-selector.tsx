'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { 
  Smile, 
  Frown, 
  Meh, 
  Zap, 
  Brain, 
  Heart, 
  Target, 
  Sparkles,
  TrendingUp,
  Moon,
  Coffee,
  Flame
} from 'lucide-react';

export interface MoodOption {
  id: string;
  label: string;
  icon: React.ReactNode;
  color: string;
  gradient: string;
}

const MOODS: MoodOption[] = [
  { 
    id: 'motivated', 
    label: 'Motivated', 
    icon: <Target className="w-6 h-6" />, 
    color: 'text-orange-600',
    gradient: 'from-orange-400 to-red-500'
  },
  { 
    id: 'grateful', 
    label: 'Grateful', 
    icon: <Heart className="w-6 h-6" />, 
    color: 'text-pink-600',
    gradient: 'from-pink-400 to-rose-500'
  },
  { 
    id: 'stressed', 
    label: 'Stressed', 
    icon: <Frown className="w-6 h-6" />, 
    color: 'text-gray-600',
    gradient: 'from-gray-400 to-gray-600'
  },
  { 
    id: 'focused', 
    label: 'Focused', 
    icon: <Brain className="w-6 h-6" />, 
    color: 'text-blue-600',
    gradient: 'from-blue-400 to-indigo-500'
  },
  { 
    id: 'rebuilding', 
    label: 'Rebuilding', 
    icon: <TrendingUp className="w-6 h-6" />, 
    color: 'text-green-600',
    gradient: 'from-green-400 to-emerald-500'
  },
  { 
    id: 'recovering', 
    label: 'Recovering', 
    icon: <Moon className="w-6 h-6" />, 
    color: 'text-purple-600',
    gradient: 'from-purple-400 to-indigo-500'
  },
  { 
    id: 'grinding', 
    label: 'Grinding', 
    icon: <Coffee className="w-6 h-6" />, 
    color: 'text-amber-600',
    gradient: 'from-amber-400 to-orange-500'
  },
  { 
    id: 'lost', 
    label: 'Lost', 
    icon: <Meh className="w-6 h-6" />, 
    color: 'text-slate-600',
    gradient: 'from-slate-400 to-gray-500'
  },
  { 
    id: 'pumped', 
    label: 'Pumped', 
    icon: <Zap className="w-6 h-6" />, 
    color: 'text-yellow-600',
    gradient: 'from-yellow-400 to-orange-500'
  },
  { 
    id: 'ascendant', 
    label: 'Ascendant', 
    icon: <Sparkles className="w-6 h-6" />, 
    color: 'text-violet-600',
    gradient: 'from-violet-400 to-purple-500'
  },
  { 
    id: 'chill', 
    label: 'Chill', 
    icon: <Smile className="w-6 h-6" />, 
    color: 'text-cyan-600',
    gradient: 'from-cyan-400 to-blue-500'
  },
  { 
    id: 'locked-in', 
    label: 'Locked In', 
    icon: <Flame className="w-6 h-6" />, 
    color: 'text-red-600',
    gradient: 'from-red-400 to-rose-500'
  },
];

interface MoodSelectorProps {
  currentMood: string | null;
  onMoodSelect: (mood: string, metadata?: string) => void;
  disabled?: boolean;
}

export function MoodSelector({ currentMood, onMoodSelect, disabled }: MoodSelectorProps) {
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [metadata, setMetadata] = useState('');
  const [showMetadata, setShowMetadata] = useState(false);

  const handleMoodClick = (moodId: string) => {
    setSelectedMood(moodId);
    setShowMetadata(true);
  };

  const handleSubmit = () => {
    if (selectedMood) {
      onMoodSelect(selectedMood, metadata || undefined);
      setMetadata('');
      setShowMetadata(false);
      setSelectedMood(null);
    }
  };

  const handleSkipMetadata = () => {
    if (selectedMood) {
      onMoodSelect(selectedMood, undefined);
      setShowMetadata(false);
      setSelectedMood(null);
    }
  };

  return (
    <Card className="bg-white/90 dark:bg-gray-900/90 backdrop-blur border-2 shadow-xl">
      <CardHeader>
        <CardTitle>How are you feeling?</CardTitle>
        <CardDescription>
          Select your current mood to encode it onchain
          {currentMood && (
            <span className="block mt-2 text-sm font-semibold">
              Current: <span className="text-purple-600">{currentMood}</span>
            </span>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {!showMetadata ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {MOODS.map((mood) => (
              <Button
                key={mood.id}
                variant={currentMood === mood.id ? 'default' : 'outline'}
                className={`h-24 flex flex-col items-center justify-center gap-2 transition-all hover:scale-105 ${
                  currentMood === mood.id 
                    ? `bg-gradient-to-br ${mood.gradient} text-white` 
                    : ''
                }`}
                onClick={() => handleMoodClick(mood.id)}
                disabled={disabled}
              >
                <span className={currentMood === mood.id ? '' : mood.color}>
                  {mood.icon}
                </span>
                <span className="text-xs font-semibold">{mood.label}</span>
              </Button>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium mb-2">
                Add a note about your {selectedMood} mood (optional)
              </p>
              <Textarea
                placeholder="What's on your mind? Share context about your mood..."
                value={metadata}
                onChange={(e) => setMetadata(e.target.value)}
                rows={4}
                className="resize-none"
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSubmit} className="flex-1" disabled={disabled}>
                Record Mood Onchain
              </Button>
              <Button onClick={handleSkipMetadata} variant="outline" disabled={disabled}>
                Skip Note
              </Button>
              <Button onClick={() => {
                setShowMetadata(false);
                setSelectedMood(null);
                setMetadata('');
              }} variant="ghost">
                Cancel
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
