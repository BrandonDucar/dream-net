'use client';

import { useEffect } from 'react';

interface ThemeManagerProps {
  currentMood: string | null;
}

const MOOD_THEMES: Record<string, { primary: string; secondary: string; accent: string }> = {
  'motivated': { primary: '#ea580c', secondary: '#fb923c', accent: '#f97316' },
  'grateful': { primary: '#db2777', secondary: '#f472b6', accent: '#ec4899' },
  'stressed': { primary: '#4b5563', secondary: '#9ca3af', accent: '#6b7280' },
  'focused': { primary: '#2563eb', secondary: '#60a5fa', accent: '#3b82f6' },
  'rebuilding': { primary: '#059669', secondary: '#34d399', accent: '#10b981' },
  'recovering': { primary: '#7c3aed', secondary: '#a78bfa', accent: '#8b5cf6' },
  'grinding': { primary: '#d97706', secondary: '#fbbf24', accent: '#f59e0b' },
  'lost': { primary: '#64748b', secondary: '#94a3b8', accent: '#475569' },
  'pumped': { primary: '#eab308', secondary: '#fde047', accent: '#facc15' },
  'ascendant': { primary: '#7c3aed', secondary: '#c084fc', accent: '#a855f7' },
  'chill': { primary: '#06b6d4', secondary: '#67e8f9', accent: '#22d3ee' },
  'locked-in': { primary: '#dc2626', secondary: '#f87171', accent: '#ef4444' },
};

export function ThemeManager({ currentMood }: ThemeManagerProps) {
  useEffect(() => {
    if (!currentMood || typeof window === 'undefined') return;

    const theme = MOOD_THEMES[currentMood];
    if (!theme) return;

    const root = document.documentElement;
    
    root.style.setProperty('--mood-primary', theme.primary);
    root.style.setProperty('--mood-secondary', theme.secondary);
    root.style.setProperty('--mood-accent', theme.accent);

    const style = document.createElement('style');
    style.id = 'mood-theme-override';
    style.innerHTML = `
      :root {
        --primary: ${theme.primary};
      }
    `;

    const existing = document.getElementById('mood-theme-override');
    if (existing) {
      existing.remove();
    }
    document.head.appendChild(style);

    return () => {
      const styleToRemove = document.getElementById('mood-theme-override');
      if (styleToRemove) {
        styleToRemove.remove();
      }
    };
  }, [currentMood]);

  return null;
}
