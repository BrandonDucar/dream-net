'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { Identity } from 'spacetimedb';
import * as moduleBindings from '../spacetime_module_bindings';

type DbConnection = moduleBindings.DbConnection;
type EventContext = moduleBindings.EventContext;
type ErrorContext = moduleBindings.ErrorContext;
type MoodEntry = moduleBindings.MoodEntry;
type MoodCommunity = moduleBindings.MoodCommunity;

export interface MoodChainState {
  connected: boolean;
  identity: Identity | null;
  statusMessage: string;
  connection: DbConnection | null;
  moods: ReadonlyMap<string, MoodEntry>;
  communities: ReadonlyMap<string, MoodCommunity>;
  currentUserMood: MoodEntry | null;
}

export interface MoodChainActions {
  recordMood: (mood: string, metadata: string | undefined, walletAddress: string) => void;
  updateTheme: (themeColors: string) => void;
  joinMoodCommunity: (mood: string) => void;
}

export function useSpacetimeMoodChain(): MoodChainState & MoodChainActions {
  const [connected, setConnected] = useState(false);
  const [identity, setIdentity] = useState<Identity | null>(null);
  const [statusMessage, setStatusMessage] = useState('Connecting...');
  const [moods, setMoods] = useState<ReadonlyMap<string, MoodEntry>>(new Map());
  const [communities, setCommunities] = useState<ReadonlyMap<string, MoodCommunity>>(new Map());
  const [currentUserMood, setCurrentUserMood] = useState<MoodEntry | null>(null);
  
  const connectionRef = useRef<DbConnection | null>(null);

  const subscribeToTables = useCallback(() => {
    if (!connectionRef.current) return;
    
    console.log('Subscribing to MoodChain tables...');
    
    const queries = [
      'SELECT * FROM mood_entry',
      'SELECT * FROM mood_community',
    ];
    
    connectionRef.current
      .subscriptionBuilder()
      .onApplied(() => {
        console.log('Subscription applied');
        processInitialCache();
      })
      .onError((error: Error) => {
        console.error('Subscription error:', error);
        setStatusMessage(`Error: ${error.message}`);
      })
      .subscribe(queries);
  }, []);

  const processInitialCache = useCallback(() => {
    if (!connectionRef.current) return;
    console.log('Processing initial cache...');
    
    const initialMoods = new Map<string, MoodEntry>();
    for (const mood of connectionRef.current.db.moodEntry.iter()) {
      initialMoods.set(mood.identity.toHexString(), mood);
      if (identity && mood.identity.toHexString() === identity.toHexString()) {
        setCurrentUserMood(mood);
      }
    }
    setMoods(initialMoods);
    
    const initialCommunities = new Map<string, MoodCommunity>();
    for (const community of connectionRef.current.db.moodCommunity.iter()) {
      initialCommunities.set(community.moodType, community);
    }
    setCommunities(initialCommunities);
  }, [identity]);

  const registerTableCallbacks = useCallback((currentIdentity: Identity) => {
    if (!connectionRef.current) return;
    
    console.log('Registering table callbacks...');

    connectionRef.current.db.moodEntry.onInsert((_ctx: EventContext | undefined, mood: MoodEntry) => {
      console.log('Mood inserted:', mood.mood);
      setMoods((prev: ReadonlyMap<string, MoodEntry>) =>
        new Map(prev).set(mood.identity.toHexString(), mood)
      );
      
      if (currentIdentity && mood.identity.toHexString() === currentIdentity.toHexString()) {
        setCurrentUserMood(mood);
      }
    });

    connectionRef.current.db.moodEntry.onUpdate((_ctx: EventContext | undefined, _oldMood: MoodEntry, newMood: MoodEntry) => {
      setMoods((prev: ReadonlyMap<string, MoodEntry>) => {
        const newMap = new Map(prev);
        newMap.set(newMood.identity.toHexString(), newMood);
        return newMap;
      });
      
      if (currentIdentity && newMood.identity.toHexString() === currentIdentity.toHexString()) {
        setCurrentUserMood(newMood);
      }
    });

    connectionRef.current.db.moodEntry.onDelete((_ctx: EventContext, mood: MoodEntry) => {
      console.log('Mood deleted:', mood.identity.toHexString());
      setMoods((prev: ReadonlyMap<string, MoodEntry>) => {
        const newMap = new Map(prev);
        newMap.delete(mood.identity.toHexString());
        return newMap;
      });
    });

    connectionRef.current.db.moodCommunity.onInsert((_ctx: EventContext | undefined, community: MoodCommunity) => {
      console.log('Community inserted:', community.moodType);
      setCommunities((prev: ReadonlyMap<string, MoodCommunity>) =>
        new Map(prev).set(community.moodType, community)
      );
    });

    connectionRef.current.db.moodCommunity.onUpdate((_ctx: EventContext | undefined, _old: MoodCommunity, newCommunity: MoodCommunity) => {
      setCommunities((prev: ReadonlyMap<string, MoodCommunity>) => {
        const newMap = new Map(prev);
        newMap.set(newCommunity.moodType, newCommunity);
        return newMap;
      });
    });
  }, []);

  useEffect(() => {
    if (connectionRef.current) {
      console.log('Connection already established');
      return;
    }

    const dbHost = 'wss://maincloud.spacetimedb.com';
    const dbName = process.env.NEXT_PUBLIC_SPACETIME_MODULE_NAME || 'default_module';

    const onConnect = (connection: DbConnection, id: Identity, _token: string) => {
      console.log('Connected to MoodChain!');
      connectionRef.current = connection;
      setIdentity(id);
      setConnected(true);
      setStatusMessage(`Connected as ${id.toHexString().substring(0, 8)}...`);
      
      subscribeToTables();
      registerTableCallbacks(id);
    };

    const onDisconnect = (_ctx: ErrorContext, reason?: Error | null) => {
      const reasonStr = reason ? reason.message : 'No reason given';
      console.log('Disconnected:', reasonStr);
      setStatusMessage(`Disconnected: ${reasonStr}`);
      connectionRef.current = null;
      setIdentity(null);
      setConnected(false);
    };

    moduleBindings.DbConnection.builder()
      .withUri(dbHost)
      .withModuleName(dbName)
      .onConnect(onConnect)
      .onDisconnect(onDisconnect)
      .build();
  }, [subscribeToTables, registerTableCallbacks]);

  const recordMood = useCallback((mood: string, metadata: string | undefined, walletAddress: string) => {
    if (!connectionRef.current || !identity || !connected) return;
    connectionRef.current.reducers.recordMood(mood, metadata, walletAddress);
  }, [identity, connected]);

  const updateTheme = useCallback((themeColors: string) => {
    if (!connectionRef.current || !identity || !connected) return;
    connectionRef.current.reducers.updateTheme(themeColors);
  }, [identity, connected]);

  const joinMoodCommunity = useCallback((mood: string) => {
    if (!connectionRef.current || !identity || !connected) return;
    connectionRef.current.reducers.joinMoodCommunity(mood);
  }, [identity, connected]);

  return {
    connected,
    identity,
    statusMessage,
    connection: connectionRef.current,
    moods,
    communities,
    currentUserMood,
    recordMood,
    updateTheme,
    joinMoodCommunity,
  };
}
