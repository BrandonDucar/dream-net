// SpacetimeDB imports
use spacetimedb::{reducer, table, ReducerContext, Table, SpacetimeType};

// --- Helper Types ---

#[derive(SpacetimeType, Clone, Debug, PartialEq, Eq)]
pub enum MiniAppRole {
    Generator,
    Planner,
    Analyzer,
    Router,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq, Eq)]
pub enum HttpMethod {
    GET,
    POST,
    PUT,
    DELETE,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq, Eq)]
pub enum AccountPlatform {
    Farcaster,
    X,
    Zora,
    BaseFeed,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq, Eq)]
pub enum AccountRole {
    FounderMain,
    Project,
    MemeAlt,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq, Eq)]
pub enum ObjectType {
    Token,
    CultureCoin,
    Drop,
    Script,
    ContentStream,
    Segment,
    Action,
    Pickleball,
    Other,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq, Eq)]
pub enum FlowCategory {
    Culture,
    Launch,
    Pickleball,
    Ops,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq, Eq)]
pub enum PriorityLevel {
    Low,
    Medium,
    High,
    Critical,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq, Eq)]
pub enum FlowStatus {
    Idea,
    Draft,
    Active,
    Paused,
    Retired,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq, Eq)]
pub enum StepType {
    Manual,
    OharaMiniApp,
    BackendApi,
    SocialPost,
    Onchain,
    Analysis,
    Other,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq, Eq)]
pub enum TriggerType {
    Manual,
    TimeBased,
    EventBased,
    StateChange,
    ExternalSignal,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq, Eq)]
pub enum RiskLevel {
    Low,
    Medium,
    High,
}

#[derive(SpacetimeType, Clone, Debug)]
pub struct StepOrderUpdate {
    pub step_id: String,
    pub new_order: u32,
}

// --- Tables ---

#[table(name = mini_app_ref, public)]
#[derive(Clone)]
pub struct MiniAppRef {
    #[primary_key]
    pub id: String,
    pub name: String,
    pub role: MiniAppRole,
    pub notes: String,
}

#[table(name = backend_endpoint_ref, public)]
#[derive(Clone)]
pub struct BackendEndpointRef {
    #[primary_key]
    pub id: String,
    pub name: String,
    pub path: String, // e.g., /v1/drops
    pub method: HttpMethod,
    pub notes: String,
}

#[table(name = account_ref, public)]
#[derive(Clone)]
pub struct AccountRef {
    #[primary_key]
    pub id: String,
    pub platform: AccountPlatform,
    pub handle: String,
    pub role: AccountRole,
    pub notes: String,
}

#[table(name = object_ref, public)]
#[derive(Clone)]
pub struct ObjectRef {
    #[primary_key]
    pub id: String,
    pub object_type: ObjectType, // "type" is reserved; using object_type
    pub name: String,
    pub description: String,
    pub source_mini_app_id: Option<String>,
    pub backend_model_name: Option<String>,
    pub backend_key_field: Option<String>,
    pub notes: String,
}

#[table(name = flow, public)]
#[derive(Clone)]
pub struct Flow {
    #[primary_key]
    pub id: String,
    pub name: String,
    pub description: String,
    pub category: FlowCategory,
    pub goal: String,
    pub priority_level: PriorityLevel,
    pub status: FlowStatus,
    pub tags: Vec<String>,
    pub seo_title: String,
    pub seo_description: String,
    pub seo_keywords: Vec<String>,
    pub seo_hashtags: Vec<String>,
    pub alt_text: String,
}

#[table(name = flow_step, public)]
#[derive(Clone)]
pub struct FlowStep {
    #[primary_key]
    pub id: String,
    pub flow_id: String,
    pub step_order: u32,
    pub name: String,
    pub description: String,
    pub step_type: StepType,
    pub mini_app_id: Option<String>,
    pub endpoint_id: Option<String>,
    pub account_id: Option<String>,
    pub inputs: Vec<String>,
    pub outputs: Vec<String>,
    pub required_action_type_codes: Vec<String>,
    pub depends_on_step_ids: Vec<String>,
    pub automation_hint: String,
    pub risk_level: RiskLevel,
    pub notes: String,
}

#[table(name = trigger, public)]
#[derive(Clone)]
pub struct Trigger {
    #[primary_key]
    pub id: String,
    pub flow_id: String,
    pub name: String,
    pub description: String,
    pub trigger_type: TriggerType,
    pub related_object_type: Option<String>,
    pub condition_text: String,
    pub notes: String,
}

#[table(name = flow_attachment, public)]
#[derive(Clone)]
pub struct FlowAttachment {
    #[primary_key]
    pub id: String,
    pub flow_id: String,
    pub object_ref_id: String,
    pub role: String, // e.g., "primary token", "launch drop"
}

#[table(name = geo_target, public)]
#[derive(Clone)]
pub struct GeoTarget {
    #[primary_key]
    pub id: String,
    pub flow_id: String,
    pub region: String,
    pub country: String,
    pub city_or_market: String,
    pub language: String,
}

// --- Internal helpers (SEO) ---

fn to_title_case(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut new_word = true;
    for ch in s.chars() {
        if ch.is_alphanumeric() {
            if new_word {
                for up in ch.to_uppercase() {
                    out.push(up);
                }
                new_word = false;
            } else {
                out.push(ch);
            }
        } else {
            out.push(ch);
            new_word = true;
        }
    }
    out
}

fn trim_to_len(s: &str, max_len: usize) -> String {
    if s.len() <= max_len {
        s.to_string()
    } else {
        let mut truncated = s.chars().take(max_len).collect::<String>();
        if let Some(last_space) = truncated.rfind(' ') {
            truncated.truncate(last_space);
        }
        truncated
    }
}

fn normalize_tag(s: &str) -> String {
    s.trim().to_string()
}

fn to_hashtag(s: &str) -> String {
    let t = s.trim();
    if t.is_empty() {
        String::new()
    } else if t.starts_with('#') {
        t.to_string()
    } else {
        format!("#{}", t.replace(' ', ""))
    }
}

fn tokenize_words(s: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut cur = String::new();
    for ch in s.chars() {
        if ch.is_alphanumeric() {
            cur.push(ch.to_ascii_lowercase());
        } else {
            if !cur.is_empty() {
                out.push(cur.clone());
                cur.clear();
            }
        }
    }
    if !cur.is_empty() {
        out.push(cur);
    }
    out
}

fn dedup_lower(vec: &mut Vec<String>) {
    let mut seen = std::collections::HashSet::new();
    vec.retain(|v| seen.insert(v.to_ascii_lowercase()));
}

fn flow_category_label(c: &FlowCategory) -> &'static str {
    match c {
        FlowCategory::Culture => "Culture",
        FlowCategory::Launch => "Launch",
        FlowCategory::Pickleball => "Pickleball",
        FlowCategory::Ops => "Ops",
    }
}

fn generate_seo_fields(
    name: &str,
    description: &str,
    category_label: &str,
    tags: &[String],
    alt_text_override: Option<String>,
) -> (String, String, Vec<String>, Vec<String>, String) {
    let title = format!("{} | DreamNet Flow", to_title_case(name));
    let desc_base = if description.trim().is_empty() {
        format!("{} - DreamNet Flow ({})", to_title_case(name), category_label)
    } else {
        description.trim().to_string()
    };
    let seo_description = trim_to_len(&desc_base, 160);

    let mut keywords: Vec<String> = Vec::new();
    for t in tags {
        let nt = normalize_tag(t);
        if !nt.is_empty() {
            keywords.push(nt);
        }
    }
    for w in tokenize_words(name) {
        keywords.push(w);
    }
    for w in tokenize_words(description) {
        keywords.push(w);
    }
    for w in tokenize_words(category_label) {
        keywords.push(w);
    }
    dedup_lower(&mut keywords);

    let mut hashtags: Vec<String> = Vec::new();
    for t in tags {
        let ht = to_hashtag(t);
        if !ht.is_empty() {
            hashtags.push(ht);
        }
    }
    let cat_tag = to_hashtag(category_label);
    if !cat_tag.is_empty() {
        hashtags.push(cat_tag);
    }
    dedup_lower(&mut hashtags);

    let alt_text = alt_text_override
        .filter(|s| !s.trim().is_empty())
        .unwrap_or_else(|| format!("{} - {} visual context", to_title_case(name), category_label));

    (title, seo_description, keywords, hashtags, alt_text)
}

// --- Reducers ---

#[reducer]
pub fn register_mini_app_ref(
    ctx: &ReducerContext,
    id: String,
    name: String,
    role: MiniAppRole,
    notes: String,
) -> Result<(), String> {
    if let Some(mut row) = ctx.db.mini_app_ref().id().find(&id) {
        row.name = name;
        row.role = role;
        row.notes = notes;
        ctx.db.mini_app_ref().id().update(row);
        Ok(())
    } else {
        let row = MiniAppRef { id, name, role, notes };
        match ctx.db.mini_app_ref().try_insert(row) {
            Ok(_) => Ok(()),
            Err(e) => Err(format!("Failed to insert MiniAppRef: {}", e)),
        }
    }
}

#[reducer]
pub fn register_backend_endpoint_ref(
    ctx: &ReducerContext,
    id: String,
    name: String,
    path: String,
    method: HttpMethod,
    notes: String,
) -> Result<(), String> {
    if let Some(mut row) = ctx.db.backend_endpoint_ref().id().find(&id) {
        row.name = name;
        row.path = path;
        row.method = method;
        row.notes = notes;
        ctx.db.backend_endpoint_ref().id().update(row);
        Ok(())
    } else {
        let row = BackendEndpointRef { id, name, path, method, notes };
        match ctx.db.backend_endpoint_ref().try_insert(row) {
            Ok(_) => Ok(()),
            Err(e) => Err(format!("Failed to insert BackendEndpointRef: {}", e)),
        }
    }
}

#[reducer]
pub fn register_account_ref(
    ctx: &ReducerContext,
    id: String,
    platform: AccountPlatform,
    handle: String,
    role: AccountRole,
    notes: String,
) -> Result<(), String> {
    if let Some(mut row) = ctx.db.account_ref().id().find(&id) {
        row.platform = platform;
        row.handle = handle;
        row.role = role;
        row.notes = notes;
        ctx.db.account_ref().id().update(row);
        Ok(())
    } else {
        let row = AccountRef { id, platform, handle, role, notes };
        match ctx.db.account_ref().try_insert(row) {
            Ok(_) => Ok(()),
            Err(e) => Err(format!("Failed to insert AccountRef: {}", e)),
        }
    }
}

#[reducer]
pub fn register_object_ref(
    ctx: &ReducerContext,
    id: String,
    object_type: ObjectType,
    name: String,
    description: String,
    source_mini_app_id: Option<String>,
    backend_model_name: Option<String>,
    backend_key_field: Option<String>,
    notes: String,
) -> Result<(), String> {
    if let Some(mut row) = ctx.db.object_ref().id().find(&id) {
        row.object_type = object_type;
        row.name = name;
        row.description = description;
        row.source_mini_app_id = source_mini_app_id;
        row.backend_model_name = backend_model_name;
        row.backend_key_field = backend_key_field;
        row.notes = notes;
        ctx.db.object_ref().id().update(row);
        Ok(())
    } else {
        let row = ObjectRef {
            id,
            object_type,
            name,
            description,
            source_mini_app_id,
            backend_model_name,
            backend_key_field,
            notes,
        };
        match ctx.db.object_ref().try_insert(row) {
            Ok(_) => Ok(()),
            Err(e) => Err(format!("Failed to insert ObjectRef: {}", e)),
        }
    }
}

#[reducer]
pub fn create_flow(
    ctx: &ReducerContext,
    id: String,
    name: String,
    description: String,
    category: FlowCategory,
    goal: String,
    priority_level: PriorityLevel,
    status: FlowStatus,
    tags: Vec<String>,
    seo_data: Option<String>, // provided but ignored; SEO is auto-generated
) -> Result<(), String> {
    let _ = seo_data;
    if ctx.db.flow().id().find(&id).is_some() {
        return Err("Flow with this id already exists".to_string());
    }
    let clean_tags: Vec<String> = tags.into_iter().map(|t| normalize_tag(&t)).collect();
    let (seo_title, seo_description, seo_keywords, seo_hashtags, alt_text) =
        generate_seo_fields(&name, &description, flow_category_label(&category), &clean_tags, None);

    let row = Flow {
        id,
        name,
        description,
        category,
        goal,
        priority_level,
        status,
        tags: clean_tags,
        seo_title,
        seo_description,
        seo_keywords,
        seo_hashtags,
        alt_text,
    };
    match ctx.db.flow().try_insert(row) {
        Ok(_) => Ok(()),
        Err(e) => Err(format!("Failed to create Flow: {}", e)),
    }
}

#[reducer]
pub fn update_flow(
    ctx: &ReducerContext,
    id: String,
    name: String,
    description: String,
    category: FlowCategory,
    goal: String,
    priority_level: PriorityLevel,
    status: FlowStatus,
    tags: Vec<String>,
) -> Result<(), String> {
    if let Some(mut row) = ctx.db.flow().id().find(&id) {
        row.name = name;
        row.description = description;
        row.category = category;
        row.goal = goal;
        row.priority_level = priority_level;
        row.status = status;
        row.tags = tags.into_iter().map(|t| normalize_tag(&t)).collect();

        let (seo_title, seo_description, seo_keywords, seo_hashtags, alt_text) =
            generate_seo_fields(&row.name, &row.description, flow_category_label(&row.category), &row.tags, None);
        row.seo_title = seo_title;
        row.seo_description = seo_description;
        row.seo_keywords = seo_keywords;
        row.seo_hashtags = seo_hashtags;
        row.alt_text = alt_text;

        ctx.db.flow().id().update(row);
        Ok(())
    } else {
        Err("Flow not found".to_string())
    }
}

#[reducer]
pub fn delete_flow(ctx: &ReducerContext, id: String) -> Result<(), String> {
    if ctx.db.flow().id().find(&id).is_some() {
        ctx.db.flow().id().delete(&id);
        Ok(())
    } else {
        Err("Flow not found".to_string())
    }
}

#[reducer]
pub fn create_flow_step(
    ctx: &ReducerContext,
    id: String,
    flow_id: String,
    step_order: u32,
    name: String,
    description: String,
    step_type: StepType,
    mini_app_id: Option<String>,
    endpoint_id: Option<String>,
    account_id: Option<String>,
    inputs: Vec<String>,
    outputs: Vec<String>,
    required_action_type_codes: Vec<String>,
    depends_on_step_ids: Vec<String>,
    automation_hint: String,
    risk_level: RiskLevel,
    notes: String,
) -> Result<(), String> {
    if ctx.db.flow_step().id().find(&id).is_some() {
        return Err("FlowStep with this id already exists".to_string());
    }
    let row = FlowStep {
        id,
        flow_id,
        step_order,
        name,
        description,
        step_type,
        mini_app_id,
        endpoint_id,
        account_id,
        inputs,
        outputs,
        required_action_type_codes,
        depends_on_step_ids,
        automation_hint,
        risk_level,
        notes,
    };
    match ctx.db.flow_step().try_insert(row) {
        Ok(_) => Ok(()),
        Err(e) => Err(format!("Failed to create FlowStep: {}", e)),
    }
}

#[reducer]
pub fn update_flow_step(
    ctx: &ReducerContext,
    id: String,
    name: String,
    description: String,
    step_type: StepType,
    mini_app_id: Option<String>,
    endpoint_id: Option<String>,
    account_id: Option<String>,
    inputs: Vec<String>,
    outputs: Vec<String>,
    required_action_type_codes: Vec<String>,
    depends_on_step_ids: Vec<String>,
    automation_hint: String,
    risk_level: RiskLevel,
    notes: String,
) -> Result<(), String> {
    if let Some(mut row) = ctx.db.flow_step().id().find(&id) {
        row.name = name;
        row.description = description;
        row.step_type = step_type;
        row.mini_app_id = mini_app_id;
        row.endpoint_id = endpoint_id;
        row.account_id = account_id;
        row.inputs = inputs;
        row.outputs = outputs;
        row.required_action_type_codes = required_action_type_codes;
        row.depends_on_step_ids = depends_on_step_ids;
        row.automation_hint = automation_hint;
        row.risk_level = risk_level;
        row.notes = notes;
        ctx.db.flow_step().id().update(row);
        Ok(())
    } else {
        Err("FlowStep not found".to_string())
    }
}

#[reducer]
pub fn delete_flow_step(ctx: &ReducerContext, id: String) -> Result<(), String> {
    if ctx.db.flow_step().id().find(&id).is_some() {
        ctx.db.flow_step().id().delete(&id);
        Ok(())
    } else {
        Err("FlowStep not found".to_string())
    }
}

#[reducer]
pub fn reorder_flow_steps(
    ctx: &ReducerContext,
    flow_id: String,
    updates: Vec<StepOrderUpdate>,
) -> Result<(), String> {
    for upd in updates {
        if let Some(mut step) = ctx.db.flow_step().id().find(&upd.step_id) {
            if step.flow_id != flow_id {
                return Err(format!(
                    "Step {} does not belong to flow {}",
                    upd.step_id, flow_id
                ));
            }
            step.step_order = upd.new_order;
            ctx.db.flow_step().id().update(step);
        } else {
            return Err(format!("FlowStep not found: {}", upd.step_id));
        }
    }
    Ok(())
}

#[reducer]
pub fn create_trigger(
    ctx: &ReducerContext,
    id: String,
    flow_id: String,
    name: String,
    description: String,
    trigger_type: TriggerType,
    related_object_type: Option<String>,
    condition_text: String,
    notes: String,
) -> Result<(), String> {
    if ctx.db.trigger().id().find(&id).is_some() {
        return Err("Trigger with this id already exists".to_string());
    }
    let row = Trigger {
        id,
        flow_id,
        name,
        description,
        trigger_type,
        related_object_type,
        condition_text,
        notes,
    };
    match ctx.db.trigger().try_insert(row) {
        Ok(_) => Ok(()),
        Err(e) => Err(format!("Failed to create Trigger: {}", e)),
    }
}

#[reducer]
pub fn update_trigger(
    ctx: &ReducerContext,
    id: String,
    name: String,
    description: String,
    trigger_type: TriggerType,
    related_object_type: Option<String>,
    condition_text: String,
    notes: String,
) -> Result<(), String> {
    if let Some(mut row) = ctx.db.trigger().id().find(&id) {
        row.name = name;
        row.description = description;
        row.trigger_type = trigger_type;
        row.related_object_type = related_object_type;
        row.condition_text = condition_text;
        row.notes = notes;
        ctx.db.trigger().id().update(row);
        Ok(())
    } else {
        Err("Trigger not found".to_string())
    }
}

#[reducer]
pub fn delete_trigger(ctx: &ReducerContext, id: String) -> Result<(), String> {
    if ctx.db.trigger().id().find(&id).is_some() {
        ctx.db.trigger().id().delete(&id);
        Ok(())
    } else {
        Err("Trigger not found".to_string())
    }
}

#[reducer]
pub fn attach_object_to_flow(
    ctx: &ReducerContext,
    id: String,
    flow_id: String,
    object_ref_id: String,
    role: String,
) -> Result<(), String> {
    if ctx.db.flow_attachment().id().find(&id).is_some() {
        return Err("FlowAttachment with this id already exists".to_string());
    }
    let row = FlowAttachment { id, flow_id, object_ref_id, role };
    match ctx.db.flow_attachment().try_insert(row) {
        Ok(_) => Ok(()),
        Err(e) => Err(format!("Failed to create FlowAttachment: {}", e)),
    }
}

#[reducer]
pub fn delete_flow_attachment(ctx: &ReducerContext, id: String) -> Result<(), String> {
    if ctx.db.flow_attachment().id().find(&id).is_some() {
        ctx.db.flow_attachment().id().delete(&id);
        Ok(())
    } else {
        Err("FlowAttachment not found".to_string())
    }
}

#[reducer]
pub fn create_geo_target(
    ctx: &ReducerContext,
    id: String,
    flow_id: String,
    region: String,
    country: String,
    city_or_market: String,
    language: String,
) -> Result<(), String> {
    if ctx.db.geo_target().id().find(&id).is_some() {
        return Err("GeoTarget with this id already exists".to_string());
    }
    let row = GeoTarget { id, flow_id, region, country, city_or_market, language };
    match ctx.db.geo_target().try_insert(row) {
        Ok(_) => Ok(()),
        Err(e) => Err(format!("Failed to create GeoTarget: {}", e)),
    }
}

#[reducer]
pub fn delete_geo_target(ctx: &ReducerContext, id: String) -> Result<(), String> {
    if ctx.db.geo_target().id().find(&id).is_some() {
        ctx.db.geo_target().id().delete(&id);
        Ok(())
    } else {
        Err("GeoTarget not found".to_string())
    }
}

// --- Delete reducers for reference entities ---

#[reducer]
pub fn delete_mini_app_ref(ctx: &ReducerContext, id: String) -> Result<(), String> {
    if ctx.db.mini_app_ref().id().find(&id).is_some() {
        ctx.db.mini_app_ref().id().delete(&id);
        Ok(())
    } else {
        Err("MiniAppRef not found".to_string())
    }
}

#[reducer]
pub fn delete_backend_endpoint_ref(ctx: &ReducerContext, id: String) -> Result<(), String> {
    if ctx.db.backend_endpoint_ref().id().find(&id).is_some() {
        ctx.db.backend_endpoint_ref().id().delete(&id);
        Ok(())
    } else {
        Err("BackendEndpointRef not found".to_string())
    }
}

#[reducer]
pub fn delete_account_ref(ctx: &ReducerContext, id: String) -> Result<(), String> {
    if ctx.db.account_ref().id().find(&id).is_some() {
        ctx.db.account_ref().id().delete(&id);
        Ok(())
    } else {
        Err("AccountRef not found".to_string())
    }
}

#[reducer]
pub fn delete_object_ref(ctx: &ReducerContext, id: String) -> Result<(), String> {
    if ctx.db.object_ref().id().find(&id).is_some() {
        ctx.db.object_ref().id().delete(&id);
        Ok(())
    } else {
        Err("ObjectRef not found".to_string())
    }
}