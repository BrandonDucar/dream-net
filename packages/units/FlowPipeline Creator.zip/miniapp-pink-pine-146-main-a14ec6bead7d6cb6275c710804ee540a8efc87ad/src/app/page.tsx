'use client'
import { useState, useEffect } from 'react';
import { FlowList } from '@/components/flow-list';
import { FlowDetail } from '@/components/flow-detail';
import { Registries } from '@/components/registries';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Page() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [selectedFlowId, setSelectedFlowId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>('flows');

  const handleFlowSelect = (flowId: string) => {
    setSelectedFlowId(flowId);
    setActiveTab('flow-detail');
  };

  const handleBackToList = () => {
    setSelectedFlowId(null);
    setActiveTab('flows');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-cyan-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 via-blue-600 to-cyan-600 bg-clip-text text-transparent mb-2">
            DreamNet Flowchain Designer
          </h1>
          <p className="text-gray-600 text-lg">
            Design, document, and map your tool pipelines
          </p>
        </header>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="flows">Flows</TabsTrigger>
            <TabsTrigger value="registries">Registries</TabsTrigger>
            <TabsTrigger value="flow-detail" disabled={!selectedFlowId}>
              Flow Detail
            </TabsTrigger>
          </TabsList>

          <TabsContent value="flows" className="mt-0">
            <FlowList onFlowSelect={handleFlowSelect} />
          </TabsContent>

          <TabsContent value="registries" className="mt-0">
            <Registries />
          </TabsContent>

          <TabsContent value="flow-detail" className="mt-0">
            {selectedFlowId ? (
              <FlowDetail flowId={selectedFlowId} onBack={handleBackToList} />
            ) : (
              <div className="text-center text-gray-500 py-12">
                Select a flow to view details
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
