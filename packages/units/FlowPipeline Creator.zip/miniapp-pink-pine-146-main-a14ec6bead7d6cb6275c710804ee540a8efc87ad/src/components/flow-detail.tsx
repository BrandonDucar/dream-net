'use client';

import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, generateSEO, type Flow, type FlowStep, type Trigger, type FlowAttachment, type GeoTarget } from '@/lib/db';
import { generateFlowDiagramDescription, exportFlowSpec } from '@/lib/flow-utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  ArrowLeft,
  Plus,
  GitBranch,
  Download,
  GripVertical,
  Edit,
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';

interface FlowDetailProps {
  flowId: string;
  onBack: () => void;
}

export function FlowDetail({ flowId, onBack }: FlowDetailProps) {
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [stepDialogOpen, setStepDialogOpen] = useState(false);
  const [triggerDialogOpen, setTriggerDialogOpen] = useState(false);
  const [attachDialogOpen, setAttachDialogOpen] = useState(false);
  const [geoDialogOpen, setGeoDialogOpen] = useState(false);

  // Fetch data
  const flow = useLiveQuery(() => db.flows.get(flowId));
  const steps = useLiveQuery(() => db.flowSteps.where('flowId').equals(flowId).sortBy('stepOrder'));
  const triggers = useLiveQuery(() => db.triggers.where('flowId').equals(flowId).toArray());
  const attachments = useLiveQuery(() => db.flowAttachments.where('flowId').equals(flowId).toArray());
  const allMiniApps = useLiveQuery(() => db.miniApps.toArray());
  const allEndpoints = useLiveQuery(() => db.endpoints.toArray());
  const allAccounts = useLiveQuery(() => db.accounts.toArray());
  const allObjects = useLiveQuery(() => db.objects.toArray());
  const geoTargets = useLiveQuery(async () => {
    if (!flow?.primaryGeoTargets) return [];
    return db.geoTargets.where('id').anyOf(flow.primaryGeoTargets.map(String)).toArray();
  }, [flow?.primaryGeoTargets]);

  // Form states
  const [flowForm, setFlowForm] = useState({
    name: '',
    description: '',
    category: '',
    goal: '',
    priorityLevel: 'medium' as Flow['priorityLevel'],
    status: 'draft' as Flow['status'],
  });

  const [stepForm, setStepForm] = useState({
    name: '',
    description: '',
    stepType: 'manual' as FlowStep['stepType'],
    stepOrder: 1,
    miniAppId: '',
    endpointId: '',
    accountId: '',
    inputs: '',
    outputs: '',
    requiredActionTypeCodes: '',
    riskLevel: 'low' as FlowStep['riskLevel'],
    automationHint: '',
    notes: '',
  });

  const [triggerForm, setTriggerForm] = useState({
    name: '',
    description: '',
    triggerType: 'manual' as Trigger['triggerType'],
    relatedObjectType: '',
    conditionText: '',
    notes: '',
  });

  const [attachForm, setAttachForm] = useState({
    objectRefId: '',
    role: '',
  });

  const [geoForm, setGeoForm] = useState({
    region: '',
    country: '',
    cityOrMarket: '',
    language: '',
  });

  // Initialize flow form when flow loads
  if (flow && flowForm.name === '') {
    setFlowForm({
      name: flow.name,
      description: flow.description,
      category: flow.category,
      goal: flow.goal,
      priorityLevel: flow.priorityLevel,
      status: flow.status,
    });
  }

  const handleUpdateFlow = async () => {
    if (!flow) return;

    try {
      await db.flows.update(flowId, {
        name: flowForm.name,
        description: flowForm.description,
        category: flowForm.category,
        goal: flowForm.goal,
        priorityLevel: flowForm.priorityLevel,
        status: flowForm.status,
      });
      toast.success('Flow updated successfully!');
      setEditDialogOpen(false);
    } catch (error) {
      toast.error('Failed to update flow');
      console.error(error);
    }
  };

  const handleRegenerateSEO = async () => {
    if (!flow) return;

    try {
      const seo = generateSEO(flow);
      await db.flows.update(flowId, seo);
      toast.success('SEO regenerated successfully!');
    } catch (error) {
      toast.error('Failed to regenerate SEO');
      console.error(error);
    }
  };

  const handleAddStep = async () => {
    if (!stepForm.name.trim()) {
      toast.error('Step name is required');
      return;
    }

    try {
      await db.flowSteps.add({
        flowId,
        stepOrder: stepForm.stepOrder,
        name: stepForm.name.trim(),
        description: stepForm.description.trim(),
        stepType: stepForm.stepType,
        miniAppId: stepForm.miniAppId,
        endpointId: stepForm.endpointId,
        accountId: stepForm.accountId,
        inputs: stepForm.inputs.split(',').map((s) => s.trim()).filter(Boolean),
        outputs: stepForm.outputs.split(',').map((s) => s.trim()).filter(Boolean),
        requiredActionTypeCodes: stepForm.requiredActionTypeCodes.split(',').map((s) => s.trim()).filter(Boolean),
        dependsOnStepIds: [],
        automationHint: stepForm.automationHint.trim(),
        riskLevel: stepForm.riskLevel,
        notes: stepForm.notes.trim(),
      });
      toast.success('Step added successfully!');
      setStepForm({
        name: '',
        description: '',
        stepType: 'manual',
        stepOrder: (steps?.length || 0) + 2,
        miniAppId: '',
        endpointId: '',
        accountId: '',
        inputs: '',
        outputs: '',
        requiredActionTypeCodes: '',
        riskLevel: 'low',
        automationHint: '',
        notes: '',
      });
      setStepDialogOpen(false);
    } catch (error) {
      toast.error('Failed to add step');
      console.error(error);
    }
  };

  const handleAddTrigger = async () => {
    if (!triggerForm.name.trim()) {
      toast.error('Trigger name is required');
      return;
    }

    try {
      await db.triggers.add({
        flowId,
        name: triggerForm.name.trim(),
        description: triggerForm.description.trim(),
        triggerType: triggerForm.triggerType,
        relatedObjectType: triggerForm.relatedObjectType.trim(),
        conditionText: triggerForm.conditionText.trim(),
        notes: triggerForm.notes.trim(),
      });
      toast.success('Trigger added successfully!');
      setTriggerForm({
        name: '',
        description: '',
        triggerType: 'manual',
        relatedObjectType: '',
        conditionText: '',
        notes: '',
      });
      setTriggerDialogOpen(false);
    } catch (error) {
      toast.error('Failed to add trigger');
      console.error(error);
    }
  };

  const handleAttachObject = async () => {
    if (!attachForm.objectRefId || !attachForm.role.trim()) {
      toast.error('Object and role are required');
      return;
    }

    try {
      await db.flowAttachments.add({
        flowId,
        objectRefId: attachForm.objectRefId,
        role: attachForm.role.trim(),
      });
      toast.success('Object attached successfully!');
      setAttachForm({ objectRefId: '', role: '' });
      setAttachDialogOpen(false);
    } catch (error) {
      toast.error('Failed to attach object');
      console.error(error);
    }
  };

  const handleAddGeoTarget = async () => {
    if (!geoForm.region.trim()) {
      toast.error('Region is required');
      return;
    }

    try {
      const id = await db.geoTargets.add({
        region: geoForm.region.trim(),
        country: geoForm.country.trim(),
        cityOrMarket: geoForm.cityOrMarket.trim(),
        language: geoForm.language.trim(),
      });

      if (flow) {
        await db.flows.update(flowId, {
          primaryGeoTargets: [...flow.primaryGeoTargets, String(id)],
        });
      }

      toast.success('Geo target added successfully!');
      setGeoForm({ region: '', country: '', cityOrMarket: '', language: '' });
      setGeoDialogOpen(false);
    } catch (error) {
      toast.error('Failed to add geo target');
      console.error(error);
    }
  };

  const handleGenerateDiagram = async () => {
    try {
      const diagram = await generateFlowDiagramDescription(flowId);
      const blob = new Blob([diagram], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${flow?.name || 'flow'}-diagram-${Date.now()}.txt`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Diagram exported successfully!');
    } catch (error) {
      toast.error('Failed to generate diagram');
      console.error(error);
    }
  };

  const handleExportSpec = async () => {
    try {
      const spec = await exportFlowSpec(flowId);
      const blob = new Blob([spec], { type: 'text/markdown' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${flow?.name || 'flow'}-spec-${Date.now()}.md`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Spec exported successfully!');
    } catch (error) {
      toast.error('Failed to export spec');
      console.error(error);
    }
  };

  if (!flow) {
    return <div className="text-center py-12">Loading...</div>;
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-500 hover:bg-red-600';
      case 'high': return 'bg-orange-500 hover:bg-orange-600';
      case 'medium': return 'bg-blue-500 hover:bg-blue-600';
      case 'low': return 'bg-gray-500 hover:bg-gray-600';
      default: return 'bg-gray-500 hover:bg-gray-600';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'high': return 'bg-red-500 hover:bg-red-600';
      case 'medium': return 'bg-yellow-500 hover:bg-yellow-600';
      case 'low': return 'bg-green-500 hover:bg-green-600';
      default: return 'bg-green-500 hover:bg-green-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button onClick={onBack} variant="ghost" size="sm">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div>
            <h2 className="text-2xl font-bold">{flow.name}</h2>
            <p className="text-sm text-muted-foreground">{flow.description}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleGenerateDiagram} variant="outline" size="sm">
            <GitBranch className="h-4 w-4 mr-2" />
            Diagram
          </Button>
          <Button onClick={handleExportSpec} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export Spec
          </Button>
          <Button onClick={() => setEditDialogOpen(true)} size="sm">
            <Edit className="h-4 w-4 mr-2" />
            Edit Flow
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Category</CardTitle>
          </CardHeader>
          <CardContent>
            <Badge variant="outline">{flow.category}</Badge>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Priority</CardTitle>
          </CardHeader>
          <CardContent>
            <Badge className={getPriorityColor(flow.priorityLevel)}>{flow.priorityLevel}</Badge>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Status</CardTitle>
          </CardHeader>
          <CardContent>
            <Badge variant="outline">{flow.status}</Badge>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Steps</CardTitle>
          </CardHeader>
          <CardContent>
            <span className="text-2xl font-bold">{steps?.length || 0}</span>
          </CardContent>
        </Card>
      </div>

      {/* Goal */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Goal</CardTitle>
        </CardHeader>
        <CardContent>
          <p>{flow.goal}</p>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="steps" className="w-full">
        <TabsList>
          <TabsTrigger value="steps">Steps</TabsTrigger>
          <TabsTrigger value="triggers">Triggers</TabsTrigger>
          <TabsTrigger value="objects">Objects</TabsTrigger>
          <TabsTrigger value="seo">SEO</TabsTrigger>
          <TabsTrigger value="geo">Geo Targets</TabsTrigger>
        </TabsList>

        {/* Steps Tab */}
        <TabsContent value="steps" className="space-y-4 mt-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Flow Steps</h3>
            <Button onClick={() => { setStepForm({ ...stepForm, stepOrder: (steps?.length || 0) + 1 }); setStepDialogOpen(true); }} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Step
            </Button>
          </div>

          {steps?.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                No steps defined yet
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {steps?.map((step) => {
                const miniApp = allMiniApps?.find((m) => m.id === Number(step.miniAppId));
                const endpoint = allEndpoints?.find((e) => e.id === Number(step.endpointId));
                const account = allAccounts?.find((a) => a.id === Number(step.accountId));

                return (
                  <Card key={step.id}>
                    <CardContent className="py-4">
                      <div className="flex items-start gap-4">
                        <div className="flex items-center gap-2 min-w-[60px]">
                          <GripVertical className="h-4 w-4 text-muted-foreground" />
                          <Badge variant="outline" className="font-mono">
                            {step.stepOrder}
                          </Badge>
                        </div>
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center justify-between">
                            <h4 className="font-semibold">{step.name}</h4>
                            <div className="flex gap-2">
                              <Badge variant="secondary">{step.stepType}</Badge>
                              <Badge className={getRiskColor(step.riskLevel)}>
                                {step.riskLevel}
                              </Badge>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground">{step.description}</p>
                          <div className="flex gap-4 text-sm">
                            {miniApp && (
                              <span className="text-blue-600">Mini App: {miniApp.name}</span>
                            )}
                            {endpoint && (
                              <span className="text-green-600">
                                {endpoint.method} {endpoint.path}
                              </span>
                            )}
                            {account && (
                              <span className="text-purple-600">
                                {account.platform}/{account.handle}
                              </span>
                            )}
                          </div>
                          {step.inputs.length > 0 && (
                            <div className="text-sm">
                              <span className="font-medium">Inputs: </span>
                              {step.inputs.join(', ')}
                            </div>
                          )}
                          {step.outputs.length > 0 && (
                            <div className="text-sm">
                              <span className="font-medium">Outputs: </span>
                              {step.outputs.join(', ')}
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* Triggers Tab */}
        <TabsContent value="triggers" className="space-y-4 mt-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Triggers</h3>
            <Button onClick={() => setTriggerDialogOpen(true)} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Trigger
            </Button>
          </div>

          {triggers?.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                No triggers defined yet
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {triggers?.map((trigger) => (
                <Card key={trigger.id}>
                  <CardContent className="py-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold">{trigger.name}</h4>
                        <Badge variant="secondary">{trigger.triggerType}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{trigger.description}</p>
                      {trigger.conditionText && (
                        <div className="mt-2 p-2 bg-muted rounded text-sm font-mono">
                          {trigger.conditionText}
                        </div>
                      )}
                      {trigger.relatedObjectType && (
                        <div className="text-sm">
                          <span className="font-medium">Related Object: </span>
                          {trigger.relatedObjectType}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Objects Tab */}
        <TabsContent value="objects" className="space-y-4 mt-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Attached Objects</h3>
            <Button onClick={() => setAttachDialogOpen(true)} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Attach Object
            </Button>
          </div>

          {attachments?.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                No objects attached yet
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {attachments?.map((attachment) => {
                const obj = allObjects?.find((o) => o.id === Number(attachment.objectRefId));
                if (!obj) return null;

                const sourceMiniApp = allMiniApps?.find((m) => m.id === Number(obj.sourceMiniAppId));

                return (
                  <Card key={attachment.id}>
                    <CardContent className="py-4">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <h4 className="font-semibold">{obj.name}</h4>
                          <div className="flex gap-2">
                            <Badge variant="outline">{obj.type}</Badge>
                            <Badge variant="secondary">{attachment.role}</Badge>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground">{obj.description}</p>
                        {sourceMiniApp && (
                          <div className="text-sm">
                            <span className="font-medium">Source: </span>
                            {sourceMiniApp.name}
                          </div>
                        )}
                        {obj.backendModelName && (
                          <div className="text-sm">
                            <span className="font-medium">Backend Model: </span>
                            {obj.backendModelName}
                            {obj.backendKeyField && ` (${obj.backendKeyField})`}
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* SEO Tab */}
        <TabsContent value="seo" className="space-y-4 mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>SEO Metadata</CardTitle>
              <Button onClick={handleRegenerateSEO} variant="outline" size="sm">
                Regenerate SEO
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">Title</label>
                <p className="text-sm text-muted-foreground mt-1">{flow.seoTitle}</p>
              </div>
              <Separator />
              <div>
                <label className="text-sm font-medium">Description</label>
                <p className="text-sm text-muted-foreground mt-1">{flow.seoDescription}</p>
              </div>
              <Separator />
              <div>
                <label className="text-sm font-medium">Keywords</label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {flow.seoKeywords.map((kw, idx) => (
                    <Badge key={idx} variant="secondary">
                      {kw}
                    </Badge>
                  ))}
                </div>
              </div>
              <Separator />
              <div>
                <label className="text-sm font-medium">Hashtags</label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {flow.seoHashtags.map((tag, idx) => (
                    <Badge key={idx} variant="outline">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
              <Separator />
              <div>
                <label className="text-sm font-medium">Alt Text</label>
                <p className="text-sm text-muted-foreground mt-1">{flow.altText}</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Geo Targets Tab */}
        <TabsContent value="geo" className="space-y-4 mt-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Geo Targets</h3>
            <Button onClick={() => setGeoDialogOpen(true)} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Geo Target
            </Button>
          </div>

          {geoTargets?.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                No geo targets defined yet
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {geoTargets?.map((gt) => (
                <Card key={gt.id}>
                  <CardContent className="py-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <span className="text-sm font-medium">Region: </span>
                        <span className="text-sm">{gt.region}</span>
                      </div>
                      <div>
                        <span className="text-sm font-medium">Country: </span>
                        <span className="text-sm">{gt.country}</span>
                      </div>
                      <div>
                        <span className="text-sm font-medium">City/Market: </span>
                        <span className="text-sm">{gt.cityOrMarket}</span>
                      </div>
                      <div>
                        <span className="text-sm font-medium">Language: </span>
                        <span className="text-sm">{gt.language}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Edit Flow Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Flow</DialogTitle>
            <DialogDescription>Update flow information and settings</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="edit-name">Name</Label>
              <Input
                id="edit-name"
                value={flowForm.name}
                onChange={(e) => setFlowForm({ ...flowForm, name: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                value={flowForm.description}
                onChange={(e) => setFlowForm({ ...flowForm, description: e.target.value })}
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-category">Category</Label>
                <Select value={flowForm.category} onValueChange={(value) => setFlowForm({ ...flowForm, category: value })}>
                  <SelectTrigger id="edit-category">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="culture">Culture</SelectItem>
                    <SelectItem value="launch">Launch</SelectItem>
                    <SelectItem value="pickleball">Pickleball</SelectItem>
                    <SelectItem value="ops">Ops</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="edit-priority">Priority</Label>
                <Select value={flowForm.priorityLevel} onValueChange={(value) => setFlowForm({ ...flowForm, priorityLevel: value as Flow['priorityLevel'] })}>
                  <SelectTrigger id="edit-priority">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-status">Status</Label>
                <Select value={flowForm.status} onValueChange={(value) => setFlowForm({ ...flowForm, status: value as Flow['status'] })}>
                  <SelectTrigger id="edit-status">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="idea">Idea</SelectItem>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="paused">Paused</SelectItem>
                    <SelectItem value="retired">Retired</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="edit-goal">Goal</Label>
              <Textarea
                id="edit-goal"
                value={flowForm.goal}
                onChange={(e) => setFlowForm({ ...flowForm, goal: e.target.value })}
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleUpdateFlow}>Update Flow</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Step Dialog */}
      <Dialog open={stepDialogOpen} onOpenChange={setStepDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add Flow Step</DialogTitle>
            <DialogDescription>Define a new step in your workflow pipeline</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="step-name">Name *</Label>
                <Input
                  id="step-name"
                  value={stepForm.name}
                  onChange={(e) => setStepForm({ ...stepForm, name: e.target.value })}
                  placeholder="Define CultureCoin"
                />
              </div>
              <div>
                <Label htmlFor="step-order">Step Order</Label>
                <Input
                  id="step-order"
                  type="number"
                  value={stepForm.stepOrder}
                  onChange={(e) => setStepForm({ ...stepForm, stepOrder: parseInt(e.target.value) })}
                />
              </div>
            </div>
            <div>
              <Label htmlFor="step-description">Description</Label>
              <Textarea
                id="step-description"
                value={stepForm.description}
                onChange={(e) => setStepForm({ ...stepForm, description: e.target.value })}
                rows={2}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="step-type">Step Type</Label>
                <Select value={stepForm.stepType} onValueChange={(value) => setStepForm({ ...stepForm, stepType: value as FlowStep['stepType'] })}>
                  <SelectTrigger id="step-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="manual">Manual</SelectItem>
                    <SelectItem value="ohara-mini-app">Ohara Mini App</SelectItem>
                    <SelectItem value="backend-api">Backend API</SelectItem>
                    <SelectItem value="social-post">Social Post</SelectItem>
                    <SelectItem value="onchain">Onchain</SelectItem>
                    <SelectItem value="analysis">Analysis</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="step-risk">Risk Level</Label>
                <Select value={stepForm.riskLevel} onValueChange={(value) => setStepForm({ ...stepForm, riskLevel: value as FlowStep['riskLevel'] })}>
                  <SelectTrigger id="step-risk">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="step-miniapp">Mini App</Label>
                <Select value={stepForm.miniAppId} onValueChange={(value) => setStepForm({ ...stepForm, miniAppId: value })}>
                  <SelectTrigger id="step-miniapp">
                    <SelectValue placeholder="None" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">None</SelectItem>
                    {allMiniApps?.map((app) => (
                      <SelectItem key={app.id} value={String(app.id)}>{app.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="step-endpoint">Endpoint</Label>
                <Select value={stepForm.endpointId} onValueChange={(value) => setStepForm({ ...stepForm, endpointId: value })}>
                  <SelectTrigger id="step-endpoint">
                    <SelectValue placeholder="None" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">None</SelectItem>
                    {allEndpoints?.map((ep) => (
                      <SelectItem key={ep.id} value={String(ep.id)}>{ep.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="step-account">Account</Label>
                <Select value={stepForm.accountId} onValueChange={(value) => setStepForm({ ...stepForm, accountId: value })}>
                  <SelectTrigger id="step-account">
                    <SelectValue placeholder="None" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">None</SelectItem>
                    {allAccounts?.map((acc) => (
                      <SelectItem key={acc.id} value={String(acc.id)}>{acc.handle}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="step-inputs">Inputs (comma-separated)</Label>
                <Input
                  id="step-inputs"
                  value={stepForm.inputs}
                  onChange={(e) => setStepForm({ ...stepForm, inputs: e.target.value })}
                  placeholder="idea prompt, CultureCoin"
                />
              </div>
              <div>
                <Label htmlFor="step-outputs">Outputs (comma-separated)</Label>
                <Input
                  id="step-outputs"
                  value={stepForm.outputs}
                  onChange={(e) => setStepForm({ ...stepForm, outputs: e.target.value })}
                  placeholder="CultureCoin record, Drop ID"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="step-actions">Required Action Codes (comma-separated)</Label>
              <Input
                id="step-actions"
                value={stepForm.requiredActionTypeCodes}
                onChange={(e) => setStepForm({ ...stepForm, requiredActionTypeCodes: e.target.value })}
                placeholder="ANNOUNCE_DROP, PUBLISH_SCRIPT"
              />
            </div>
            <div>
              <Label htmlFor="step-automation">Automation Hint</Label>
              <Input
                id="step-automation"
                value={stepForm.automationHint}
                onChange={(e) => setStepForm({ ...stepForm, automationHint: e.target.value })}
                placeholder="Manual now, later to be automated"
              />
            </div>
            <div>
              <Label htmlFor="step-notes">Notes</Label>
              <Textarea
                id="step-notes"
                value={stepForm.notes}
                onChange={(e) => setStepForm({ ...stepForm, notes: e.target.value })}
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setStepDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleAddStep}>Add Step</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Trigger Dialog */}
      <Dialog open={triggerDialogOpen} onOpenChange={setTriggerDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Add Trigger</DialogTitle>
            <DialogDescription>Define what initiates this flow</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="trigger-name">Name *</Label>
              <Input
                id="trigger-name"
                value={triggerForm.name}
                onChange={(e) => setTriggerForm({ ...triggerForm, name: e.target.value })}
                placeholder="New CultureCoin created"
              />
            </div>
            <div>
              <Label htmlFor="trigger-type">Trigger Type</Label>
              <Select value={triggerForm.triggerType} onValueChange={(value) => setTriggerForm({ ...triggerForm, triggerType: value as Trigger['triggerType'] })}>
                <SelectTrigger id="trigger-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="manual">Manual</SelectItem>
                  <SelectItem value="time-based">Time-Based</SelectItem>
                  <SelectItem value="event-based">Event-Based</SelectItem>
                  <SelectItem value="state-change">State-Change</SelectItem>
                  <SelectItem value="external-signal">External-Signal</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="trigger-description">Description</Label>
              <Textarea
                id="trigger-description"
                value={triggerForm.description}
                onChange={(e) => setTriggerForm({ ...triggerForm, description: e.target.value })}
                rows={2}
              />
            </div>
            <div>
              <Label htmlFor="trigger-object">Related Object Type</Label>
              <Input
                id="trigger-object"
                value={triggerForm.relatedObjectType}
                onChange={(e) => setTriggerForm({ ...triggerForm, relatedObjectType: e.target.value })}
                placeholder="CultureCoin, Drop"
              />
            </div>
            <div>
              <Label htmlFor="trigger-condition">Condition Text</Label>
              <Textarea
                id="trigger-condition"
                value={triggerForm.conditionText}
                onChange={(e) => setTriggerForm({ ...triggerForm, conditionText: e.target.value })}
                placeholder="status = 'ready'"
                rows={2}
              />
            </div>
            <div>
              <Label htmlFor="trigger-notes">Notes</Label>
              <Textarea
                id="trigger-notes"
                value={triggerForm.notes}
                onChange={(e) => setTriggerForm({ ...triggerForm, notes: e.target.value })}
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTriggerDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleAddTrigger}>Add Trigger</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Attach Object Dialog */}
      <Dialog open={attachDialogOpen} onOpenChange={setAttachDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Attach Object</DialogTitle>
            <DialogDescription>Link an object reference to this flow</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="attach-object">Object *</Label>
              <Select value={attachForm.objectRefId} onValueChange={(value) => setAttachForm({ ...attachForm, objectRefId: value })}>
                <SelectTrigger id="attach-object">
                  <SelectValue placeholder="Select object" />
                </SelectTrigger>
                <SelectContent>
                  {allObjects?.map((obj) => (
                    <SelectItem key={obj.id} value={String(obj.id)}>{obj.name} ({obj.type})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="attach-role">Role in Flow *</Label>
              <Input
                id="attach-role"
                value={attachForm.role}
                onChange={(e) => setAttachForm({ ...attachForm, role: e.target.value })}
                placeholder="primary token, launch drop"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAttachDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleAttachObject}>Attach</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Geo Target Dialog */}
      <Dialog open={geoDialogOpen} onOpenChange={setGeoDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Geo Target</DialogTitle>
            <DialogDescription>Define a regional variant for this flow</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="geo-region">Region *</Label>
              <Input
                id="geo-region"
                value={geoForm.region}
                onChange={(e) => setGeoForm({ ...geoForm, region: e.target.value })}
                placeholder="US, LATAM, EU"
              />
            </div>
            <div>
              <Label htmlFor="geo-country">Country</Label>
              <Input
                id="geo-country"
                value={geoForm.country}
                onChange={(e) => setGeoForm({ ...geoForm, country: e.target.value })}
                placeholder="USA, Brazil"
              />
            </div>
            <div>
              <Label htmlFor="geo-city">City/Market</Label>
              <Input
                id="geo-city"
                value={geoForm.cityOrMarket}
                onChange={(e) => setGeoForm({ ...geoForm, cityOrMarket: e.target.value })}
                placeholder="Miami, Berlin"
              />
            </div>
            <div>
              <Label htmlFor="geo-language">Language</Label>
              <Input
                id="geo-language"
                value={geoForm.language}
                onChange={(e) => setGeoForm({ ...geoForm, language: e.target.value })}
                placeholder="en, es, pt-BR"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setGeoDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleAddGeoTarget}>Add Geo Target</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
