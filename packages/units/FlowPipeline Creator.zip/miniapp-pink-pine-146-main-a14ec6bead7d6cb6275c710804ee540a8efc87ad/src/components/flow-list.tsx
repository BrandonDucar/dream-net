'use client';

import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, generateSEO, type Flow } from '@/lib/db';
import { exportAllFlowsOverview } from '@/lib/flow-utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Download, Search } from 'lucide-react';
import { toast } from 'sonner';

interface FlowListProps {
  onFlowSelect: (flowId: string) => void;
}

export function FlowList({ onFlowSelect }: FlowListProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [createDialogOpen, setCreateDialogOpen] = useState(false);

  // Form state
  const [newFlowName, setNewFlowName] = useState('');
  const [newFlowDescription, setNewFlowDescription] = useState('');
  const [newFlowCategory, setNewFlowCategory] = useState('culture');
  const [newFlowGoal, setNewFlowGoal] = useState('');
  const [newFlowPriority, setNewFlowPriority] = useState<'low' | 'medium' | 'high' | 'critical'>('medium');

  // Fetch all flows
  const allFlows = useLiveQuery(() => db.flows.orderBy('createdAt').reverse().toArray());

  // Fetch step counts for each flow
  const flowStepCounts = useLiveQuery(async () => {
    if (!allFlows) return {};
    const counts: Record<string, number> = {};
    for (const flow of allFlows) {
      if (flow.id) {
        counts[flow.id] = await db.flowSteps.where('flowId').equals(flow.id).count();
      }
    }
    return counts;
  }, [allFlows]);

  // Filter flows
  const filteredFlows = allFlows?.filter((flow) => {
    const matchesSearch = searchQuery
      ? flow.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        flow.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        flow.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      : true;

    const matchesCategory = categoryFilter === 'all' || flow.category === categoryFilter;
    const matchesPriority = priorityFilter === 'all' || flow.priorityLevel === priorityFilter;
    const matchesStatus = statusFilter === 'all' || flow.status === statusFilter;

    return matchesSearch && matchesCategory && matchesPriority && matchesStatus;
  });

  const handleCreateFlow = async () => {
    if (!newFlowName.trim()) {
      toast.error('Flow name is required');
      return;
    }

    const seo = generateSEO({
      name: newFlowName,
      description: newFlowDescription,
      category: newFlowCategory,
    });

    const newFlow: Flow = {
      name: newFlowName.trim(),
      description: newFlowDescription.trim(),
      category: newFlowCategory,
      goal: newFlowGoal.trim(),
      priorityLevel: newFlowPriority,
      status: 'draft',
      tags: [],
      ...seo,
      primaryGeoTargets: [],
      flowIntroLocalized: {},
      tagsLocalized: {},
      createdAt: Date.now(),
    };

    try {
      await db.flows.add(newFlow);
      toast.success('Flow created successfully!');
      setCreateDialogOpen(false);
      setNewFlowName('');
      setNewFlowDescription('');
      setNewFlowCategory('culture');
      setNewFlowGoal('');
      setNewFlowPriority('medium');
    } catch (error) {
      toast.error('Failed to create flow');
      console.error(error);
    }
  };

  const handleExportOverview = async () => {
    try {
      const overview = await exportAllFlowsOverview();
      const blob = new Blob([overview], { type: 'text/markdown' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `dreamnet-flows-overview-${Date.now()}.md`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Overview exported successfully!');
    } catch (error) {
      toast.error('Failed to export overview');
      console.error(error);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical':
        return 'destructive';
      case 'high':
        return 'default';
      case 'medium':
        return 'secondary';
      case 'low':
        return 'outline';
      default:
        return 'secondary';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 hover:bg-green-100';
      case 'draft':
        return 'bg-blue-100 text-blue-800 hover:bg-blue-100';
      case 'paused':
        return 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100';
      case 'retired':
        return 'bg-gray-100 text-gray-800 hover:bg-gray-100';
      case 'idea':
        return 'bg-purple-100 text-purple-800 hover:bg-purple-100';
      default:
        return 'bg-gray-100 text-gray-800 hover:bg-gray-100';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with actions */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search flows..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setCreateDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Create Flow
          </Button>
          <Button variant="outline" onClick={handleExportOverview}>
            <Download className="h-4 w-4 mr-2" />
            Export Overview
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="culture">Culture</SelectItem>
            <SelectItem value="launch">Launch</SelectItem>
            <SelectItem value="pickleball">Pickleball</SelectItem>
            <SelectItem value="ops">Ops</SelectItem>
          </SelectContent>
        </Select>

        <Select value={priorityFilter} onValueChange={setPriorityFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Priority" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Priorities</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
            <SelectItem value="high">High</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="low">Low</SelectItem>
          </SelectContent>
        </Select>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="idea">Idea</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="paused">Paused</SelectItem>
            <SelectItem value="retired">Retired</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Flow list */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredFlows?.map((flow) => (
          <Card
            key={flow.id}
            className="cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => flow.id && onFlowSelect(flow.id)}
          >
            <CardHeader>
              <CardTitle className="flex items-start justify-between">
                <span className="flex-1">{flow.name}</span>
              </CardTitle>
              <CardDescription className="line-clamp-2">{flow.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex flex-wrap gap-2">
                <Badge variant={getPriorityColor(flow.priorityLevel)}>
                  {flow.priorityLevel}
                </Badge>
                <Badge className={getStatusColor(flow.status)}>{flow.status}</Badge>
                <Badge variant="outline">{flow.category}</Badge>
              </div>
              <div className="text-sm text-gray-600">
                {flowStepCounts?.[flow.id!] || 0} steps
              </div>
              {flow.tags.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {flow.tags.slice(0, 3).map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                  {flow.tags.length > 3 && (
                    <Badge variant="secondary" className="text-xs">
                      +{flow.tags.length - 3}
                    </Badge>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredFlows?.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">No flows found. Create your first flow to get started!</p>
        </div>
      )}

      {/* Create Flow Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Create New Flow</DialogTitle>
            <DialogDescription>
              Define a new workflow pipeline for your DreamNet ecosystem
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Flow Name *</Label>
              <Input
                id="name"
                value={newFlowName}
                onChange={(e) => setNewFlowName(e.target.value)}
                placeholder="e.g., Culture Launch Flow v1"
              />
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={newFlowDescription}
                onChange={(e) => setNewFlowDescription(e.target.value)}
                placeholder="Describe what this flow does..."
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="category">Category</Label>
                <Select value={newFlowCategory} onValueChange={setNewFlowCategory}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="culture">Culture</SelectItem>
                    <SelectItem value="launch">Launch</SelectItem>
                    <SelectItem value="pickleball">Pickleball</SelectItem>
                    <SelectItem value="ops">Ops</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="priority">Priority</Label>
                <Select value={newFlowPriority} onValueChange={(value) => setNewFlowPriority(value as Flow['priorityLevel'])}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="goal">Goal</Label>
              <Textarea
                id="goal"
                value={newFlowGoal}
                onChange={(e) => setNewFlowGoal(e.target.value)}
                placeholder="What is the end goal of this flow?"
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateFlow}>Create Flow</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
