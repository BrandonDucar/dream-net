'use client';

import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, type MiniAppRef, type BackendEndpointRef, type AccountRef, type ObjectRef } from '@/lib/db';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';

export function Registries() {
  const [tab, setTab] = useState<string>('miniApps');
  const [showAddDialog, setShowAddDialog] = useState<boolean>(false);

  // Fetch data with Dexie live queries
  const miniApps = useLiveQuery(() => db.miniApps.toArray());
  const endpoints = useLiveQuery(() => db.endpoints.toArray());
  const accounts = useLiveQuery(() => db.accounts.toArray());
  const objects = useLiveQuery(() => db.objects.toArray());

  // Form states
  const [miniAppForm, setMiniAppForm] = useState({ name: '', role: 'generator', notes: '' });
  const [endpointForm, setEndpointForm] = useState({
    name: '',
    path: '',
    method: 'GET',
    notes: '',
  });
  const [accountForm, setAccountForm] = useState({
    platform: 'farcaster',
    handle: '',
    role: 'founder-main',
    notes: '',
  });
  const [objectForm, setObjectForm] = useState({
    type: 'token' as ObjectRef['type'],
    name: '',
    description: '',
    sourceMiniAppId: '',
    backendModelName: '',
    backendKeyField: '',
    notes: '',
  });

  const handleAddMiniApp = async () => {
    if (!miniAppForm.name.trim()) {
      toast.error('Name is required');
      return;
    }

    try {
      await db.miniApps.add({
        name: miniAppForm.name.trim(),
        role: miniAppForm.role,
        notes: miniAppForm.notes.trim(),
      });
      toast.success('Mini app added successfully!');
      setMiniAppForm({ name: '', role: 'generator', notes: '' });
      setShowAddDialog(false);
    } catch (error) {
      toast.error('Failed to add mini app');
      console.error(error);
    }
  };

  const handleAddEndpoint = async () => {
    if (!endpointForm.name.trim() || !endpointForm.path.trim()) {
      toast.error('Name and path are required');
      return;
    }

    try {
      await db.endpoints.add({
        name: endpointForm.name.trim(),
        path: endpointForm.path.trim(),
        method: endpointForm.method,
        notes: endpointForm.notes.trim(),
      });
      toast.success('Endpoint added successfully!');
      setEndpointForm({ name: '', path: '', method: 'GET', notes: '' });
      setShowAddDialog(false);
    } catch (error) {
      toast.error('Failed to add endpoint');
      console.error(error);
    }
  };

  const handleAddAccount = async () => {
    if (!accountForm.handle.trim()) {
      toast.error('Handle is required');
      return;
    }

    try {
      await db.accounts.add({
        platform: accountForm.platform,
        handle: accountForm.handle.trim(),
        role: accountForm.role,
        notes: accountForm.notes.trim(),
      });
      toast.success('Account added successfully!');
      setAccountForm({ platform: 'farcaster', handle: '', role: 'founder-main', notes: '' });
      setShowAddDialog(false);
    } catch (error) {
      toast.error('Failed to add account');
      console.error(error);
    }
  };

  const handleAddObject = async () => {
    if (!objectForm.name.trim()) {
      toast.error('Name is required');
      return;
    }

    try {
      await db.objects.add({
        type: objectForm.type,
        name: objectForm.name.trim(),
        description: objectForm.description.trim(),
        sourceMiniAppId: objectForm.sourceMiniAppId.trim(),
        backendModelName: objectForm.backendModelName.trim(),
        backendKeyField: objectForm.backendKeyField.trim(),
        notes: objectForm.notes.trim(),
      });
      toast.success('Object added successfully!');
      setObjectForm({
        type: 'token',
        name: '',
        description: '',
        sourceMiniAppId: '',
        backendModelName: '',
        backendKeyField: '',
        notes: '',
      });
      setShowAddDialog(false);
    } catch (error) {
      toast.error('Failed to add object');
      console.error(error);
    }
  };

  const handleDelete = async (type: string, id: number) => {
    if (!confirm('Are you sure you want to delete this item?')) return;

    try {
      if (type === 'miniApp') {
        await db.miniApps.delete(id);
      } else if (type === 'endpoint') {
        await db.endpoints.delete(id);
      } else if (type === 'account') {
        await db.accounts.delete(id);
      } else if (type === 'object') {
        await db.objects.delete(id);
      }
      toast.success('Item deleted successfully!');
    } catch (error) {
      toast.error('Failed to delete item');
      console.error(error);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Registries</h2>
        <Button onClick={() => setShowAddDialog(true)} size="sm">
          <Plus className="h-4 w-4 mr-2" />
          Add Item
        </Button>
      </div>

      <Tabs value={tab} onValueChange={setTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="miniApps">Mini Apps ({miniApps?.length || 0})</TabsTrigger>
          <TabsTrigger value="endpoints">Endpoints ({endpoints?.length || 0})</TabsTrigger>
          <TabsTrigger value="accounts">Accounts ({accounts?.length || 0})</TabsTrigger>
          <TabsTrigger value="objects">Objects ({objects?.length || 0})</TabsTrigger>
        </TabsList>

        <TabsContent value="miniApps" className="mt-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Notes</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {miniApps?.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                        No mini apps registered yet
                      </TableCell>
                    </TableRow>
                  ) : (
                    miniApps?.map((app) => (
                      <TableRow key={app.id}>
                        <TableCell className="font-medium">{app.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{app.role}</Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {app.notes || '-'}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => app.id && handleDelete('miniApp', app.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="endpoints" className="mt-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>Path</TableHead>
                    <TableHead>Notes</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {endpoints?.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                        No endpoints registered yet
                      </TableCell>
                    </TableRow>
                  ) : (
                    endpoints?.map((ep) => (
                      <TableRow key={ep.id}>
                        <TableCell className="font-medium">{ep.name}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">{ep.method}</Badge>
                        </TableCell>
                        <TableCell className="font-mono text-sm">{ep.path}</TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {ep.notes || '-'}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => ep.id && handleDelete('endpoint', ep.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="accounts" className="mt-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Platform</TableHead>
                    <TableHead>Handle</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Notes</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {accounts?.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                        No accounts registered yet
                      </TableCell>
                    </TableRow>
                  ) : (
                    accounts?.map((acc) => (
                      <TableRow key={acc.id}>
                        <TableCell>
                          <Badge variant="outline">{acc.platform}</Badge>
                        </TableCell>
                        <TableCell className="font-medium">{acc.handle}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">{acc.role}</Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {acc.notes || '-'}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => acc.id && handleDelete('account', acc.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="objects" className="mt-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Backend Model</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {objects?.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                        No objects registered yet
                      </TableCell>
                    </TableRow>
                  ) : (
                    objects?.map((obj) => (
                      <TableRow key={obj.id}>
                        <TableCell className="font-medium">{obj.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{obj.type}</Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground max-w-[300px] truncate">
                          {obj.description || '-'}
                        </TableCell>
                        <TableCell className="text-sm">
                          {obj.backendModelName || '-'}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => obj.id && handleDelete('object', obj.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add Item Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              Add {tab === 'miniApps' && 'Mini App'}
              {tab === 'endpoints' && 'Endpoint'}
              {tab === 'accounts' && 'Account'}
              {tab === 'objects' && 'Object'}
            </DialogTitle>
            <DialogDescription>
              Register a new {tab === 'miniApps' && 'mini app'}
              {tab === 'endpoints' && 'backend endpoint'}
              {tab === 'accounts' && 'social account'}
              {tab === 'objects' && 'object reference'} to use in your flows
            </DialogDescription>
          </DialogHeader>

          {tab === 'miniApps' && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="miniapp-name">Name *</Label>
                <Input
                  id="miniapp-name"
                  value={miniAppForm.name}
                  onChange={(e) =>
                    setMiniAppForm({ ...miniAppForm, name: e.target.value })
                  }
                  placeholder="CultureCoin Foundry"
                />
              </div>
              <div>
                <Label htmlFor="miniapp-role">Role</Label>
                <Select
                  value={miniAppForm.role}
                  onValueChange={(value) =>
                    setMiniAppForm({ ...miniAppForm, role: value })
                  }
                >
                  <SelectTrigger id="miniapp-role">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="generator">Generator</SelectItem>
                    <SelectItem value="planner">Planner</SelectItem>
                    <SelectItem value="analyzer">Analyzer</SelectItem>
                    <SelectItem value="router">Router</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="miniapp-notes">Notes</Label>
                <Textarea
                  id="miniapp-notes"
                  value={miniAppForm.notes}
                  onChange={(e) =>
                    setMiniAppForm({ ...miniAppForm, notes: e.target.value })
                  }
                  placeholder="Optional notes..."
                />
              </div>
            </div>
          )}

          {tab === 'endpoints' && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="endpoint-name">Name *</Label>
                <Input
                  id="endpoint-name"
                  value={endpointForm.name}
                  onChange={(e) =>
                    setEndpointForm({ ...endpointForm, name: e.target.value })
                  }
                  placeholder="List Drops"
                />
              </div>
              <div>
                <Label htmlFor="endpoint-method">Method</Label>
                <Select
                  value={endpointForm.method}
                  onValueChange={(value) =>
                    setEndpointForm({ ...endpointForm, method: value })
                  }
                >
                  <SelectTrigger id="endpoint-method">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="GET">GET</SelectItem>
                    <SelectItem value="POST">POST</SelectItem>
                    <SelectItem value="PUT">PUT</SelectItem>
                    <SelectItem value="DELETE">DELETE</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="endpoint-path">Path *</Label>
                <Input
                  id="endpoint-path"
                  value={endpointForm.path}
                  onChange={(e) =>
                    setEndpointForm({ ...endpointForm, path: e.target.value })
                  }
                  placeholder="/v1/drops"
                />
              </div>
              <div>
                <Label htmlFor="endpoint-notes">Notes</Label>
                <Textarea
                  id="endpoint-notes"
                  value={endpointForm.notes}
                  onChange={(e) =>
                    setEndpointForm({ ...endpointForm, notes: e.target.value })
                  }
                  placeholder="Optional notes..."
                />
              </div>
            </div>
          )}

          {tab === 'accounts' && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="account-platform">Platform</Label>
                <Select
                  value={accountForm.platform}
                  onValueChange={(value) =>
                    setAccountForm({ ...accountForm, platform: value })
                  }
                >
                  <SelectTrigger id="account-platform">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="farcaster">Farcaster</SelectItem>
                    <SelectItem value="x">X</SelectItem>
                    <SelectItem value="zora">Zora</SelectItem>
                    <SelectItem value="base-feed">Base Feed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="account-handle">Handle *</Label>
                <Input
                  id="account-handle"
                  value={accountForm.handle}
                  onChange={(e) =>
                    setAccountForm({ ...accountForm, handle: e.target.value })
                  }
                  placeholder="@BrandonDucar"
                />
              </div>
              <div>
                <Label htmlFor="account-role">Role</Label>
                <Select
                  value={accountForm.role}
                  onValueChange={(value) =>
                    setAccountForm({ ...accountForm, role: value })
                  }
                >
                  <SelectTrigger id="account-role">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="founder-main">Founder Main</SelectItem>
                    <SelectItem value="project">Project</SelectItem>
                    <SelectItem value="meme-alt">Meme Alt</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="account-notes">Notes</Label>
                <Textarea
                  id="account-notes"
                  value={accountForm.notes}
                  onChange={(e) =>
                    setAccountForm({ ...accountForm, notes: e.target.value })
                  }
                  placeholder="Optional notes..."
                />
              </div>
            </div>
          )}

          {tab === 'objects' && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="object-type">Type</Label>
                <Select
                  value={objectForm.type}
                  onValueChange={(value) =>
                    setObjectForm({ ...objectForm, type: value as ObjectRef['type'] })
                  }
                >
                  <SelectTrigger id="object-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="token">Token</SelectItem>
                    <SelectItem value="culture-coin">CultureCoin</SelectItem>
                    <SelectItem value="drop">Drop</SelectItem>
                    <SelectItem value="script">Script</SelectItem>
                    <SelectItem value="content-stream">Content Stream</SelectItem>
                    <SelectItem value="segment">Segment</SelectItem>
                    <SelectItem value="action">Action</SelectItem>
                    <SelectItem value="pickleball">Pickleball</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="object-name">Name *</Label>
                <Input
                  id="object-name"
                  value={objectForm.name}
                  onChange={(e) =>
                    setObjectForm({ ...objectForm, name: e.target.value })
                  }
                  placeholder="MEME Token"
                />
              </div>
              <div>
                <Label htmlFor="object-description">Description</Label>
                <Textarea
                  id="object-description"
                  value={objectForm.description}
                  onChange={(e) =>
                    setObjectForm({ ...objectForm, description: e.target.value })
                  }
                  placeholder="Description..."
                />
              </div>
              <div>
                <Label htmlFor="object-backend-model">Backend Model Name (optional)</Label>
                <Input
                  id="object-backend-model"
                  value={objectForm.backendModelName}
                  onChange={(e) =>
                    setObjectForm({ ...objectForm, backendModelName: e.target.value })
                  }
                  placeholder="CultureCoin"
                />
              </div>
              <div>
                <Label htmlFor="object-backend-key">Backend Key Field (optional)</Label>
                <Input
                  id="object-backend-key"
                  value={objectForm.backendKeyField}
                  onChange={(e) =>
                    setObjectForm({ ...objectForm, backendKeyField: e.target.value })
                  }
                  placeholder="coin_id"
                />
              </div>
              <div>
                <Label htmlFor="object-notes">Notes</Label>
                <Textarea
                  id="object-notes"
                  value={objectForm.notes}
                  onChange={(e) =>
                    setObjectForm({ ...objectForm, notes: e.target.value })
                  }
                  placeholder="Optional notes..."
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (tab === 'miniApps') handleAddMiniApp();
                else if (tab === 'endpoints') handleAddEndpoint();
                else if (tab === 'accounts') handleAddAccount();
                else if (tab === 'objects') handleAddObject();
              }}
            >
              Add
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
