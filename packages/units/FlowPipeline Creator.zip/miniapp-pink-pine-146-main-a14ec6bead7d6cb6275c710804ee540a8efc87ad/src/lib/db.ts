'use client';

import { Dexie, type EntityTable } from 'dexie';

// ============================================
// TYPES
// ============================================

export interface MiniAppRef {
  id?: string;
  name: string;
  role: string;
  notes: string;
}

export interface BackendEndpointRef {
  id?: string;
  name: string;
  path: string;
  method: string;
  notes: string;
}

export interface AccountRef {
  id?: string;
  platform: string;
  handle: string;
  role: string;
  notes: string;
}

export interface ObjectRef {
  id?: string;
  type: 'token' | 'culture-coin' | 'drop' | 'script' | 'content-stream' | 'segment' | 'action' | 'pickleball' | 'other';
  name: string;
  description: string;
  sourceMiniAppId: string;
  backendModelName: string;
  backendKeyField: string;
  notes: string;
}

export interface GeoTarget {
  id?: string;
  region: string;
  country: string;
  cityOrMarket: string;
  language: string;
}

export interface Flow {
  id?: string;
  name: string;
  description: string;
  category: string;
  goal: string;
  priorityLevel: 'low' | 'medium' | 'high' | 'critical';
  status: 'idea' | 'draft' | 'active' | 'paused' | 'retired';
  tags: string[];
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
  primaryGeoTargets: string[];
  flowIntroLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
  createdAt: number;
}

export interface FlowStep {
  id?: string;
  flowId: string;
  stepOrder: number;
  name: string;
  description: string;
  stepType: 'manual' | 'ohara-mini-app' | 'backend-api' | 'social-post' | 'onchain' | 'analysis' | 'other';
  miniAppId: string;
  endpointId: string;
  accountId: string;
  inputs: string[];
  outputs: string[];
  requiredActionTypeCodes: string[];
  dependsOnStepIds: string[];
  automationHint: string;
  riskLevel: 'low' | 'medium' | 'high';
  notes: string;
}

export interface Trigger {
  id?: string;
  flowId: string;
  name: string;
  description: string;
  triggerType: 'manual' | 'time-based' | 'event-based' | 'state-change' | 'external-signal';
  relatedObjectType: string;
  conditionText: string;
  notes: string;
}

export interface FlowAttachment {
  id?: string;
  flowId: string;
  objectRefId: string;
  role: string;
}

// ============================================
// DATABASE SCHEMA
// ============================================

export class DreamNetDB extends Dexie {
  miniApps!: EntityTable<MiniAppRef, 'id'>;
  endpoints!: EntityTable<BackendEndpointRef, 'id'>;
  accounts!: EntityTable<AccountRef, 'id'>;
  objects!: EntityTable<ObjectRef, 'id'>;
  geoTargets!: EntityTable<GeoTarget, 'id'>;
  flows!: EntityTable<Flow, 'id'>;
  flowSteps!: EntityTable<FlowStep, 'id'>;
  triggers!: EntityTable<Trigger, 'id'>;
  flowAttachments!: EntityTable<FlowAttachment, 'id'>;

  constructor() {
    super('DreamNetDB');
    this.version(1).stores({
      miniApps: '++id, name, role',
      endpoints: '++id, name, path, method',
      accounts: '++id, platform, handle',
      objects: '++id, type, name, sourceMiniAppId',
      geoTargets: '++id, region, country, language',
      flows: '++id, name, category, priorityLevel, status, createdAt',
      flowSteps: '++id, flowId, stepOrder',
      triggers: '++id, flowId, triggerType',
      flowAttachments: '++id, flowId, objectRefId',
    });
  }
}

export const db = new DreamNetDB();

// ============================================
// HELPER FUNCTIONS
// ============================================

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

export function generateSEO(flow: Partial<Flow>): Pick<Flow, 'seoTitle' | 'seoDescription' | 'seoKeywords' | 'seoHashtags' | 'altText'> {
  const name = flow.name || 'Flow';
  const description = flow.description || '';
  const category = flow.category || '';
  
  return {
    seoTitle: `${name} - DreamNet Flow`,
    seoDescription: description.slice(0, 160) || `${name} workflow for ${category}`,
    seoKeywords: [name, category, 'workflow', 'pipeline', 'automation'].filter(Boolean),
    seoHashtags: [`#${category.replace(/\s+/g, '')}`, '#DreamNet', '#Flow'].filter(Boolean),
    altText: `${name} workflow diagram`,
  };
}
