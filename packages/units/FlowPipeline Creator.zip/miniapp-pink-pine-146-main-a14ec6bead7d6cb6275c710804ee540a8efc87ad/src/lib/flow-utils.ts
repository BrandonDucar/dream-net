import type { Flow, FlowStep, Trigger, FlowAttachment, ObjectRef, MiniAppRef, BackendEndpointRef, AccountRef } from './db';
import { db } from './db';

export async function generateFlowDiagramDescription(flowId: string): Promise<string> {
  const flow = await db.flows.get(flowId);
  if (!flow) return 'Flow not found';

  const steps = await db.flowSteps.where('flowId').equals(flowId).sortBy('stepOrder');
  const triggers = await db.triggers.where('flowId').equals(flowId).toArray();
  const attachments = await db.flowAttachments.where('flowId').equals(flowId).toArray();

  let diagram = `Flow: ${flow.name}\n`;
  diagram += `Category: ${flow.category} | Priority: ${flow.priorityLevel} | Status: ${flow.status}\n`;
  diagram += `Goal: ${flow.goal}\n\n`;

  if (triggers.length > 0) {
    diagram += `Triggers:\n`;
    for (const trigger of triggers) {
      diagram += `  - ${trigger.name} (${trigger.triggerType})\n`;
      if (trigger.relatedObjectType) {
        diagram += `    Related to: ${trigger.relatedObjectType}\n`;
      }
      if (trigger.conditionText) {
        diagram += `    Condition: ${trigger.conditionText}\n`;
      }
    }
    diagram += `\n`;
  }

  if (attachments.length > 0) {
    diagram += `Attached Objects:\n`;
    for (const attachment of attachments) {
      const obj = await db.objects.get(attachment.objectRefId);
      if (obj) {
        diagram += `  - ${obj.name} (${obj.type}) - ${attachment.role}\n`;
      }
    }
    diagram += `\n`;
  }

  diagram += `Steps:\n`;
  for (const step of steps) {
    diagram += `\nStep ${step.stepOrder}: ${step.name}\n`;
    diagram += `  Type: ${step.stepType}\n`;
    
    if (step.miniAppId) {
      const miniApp = await db.miniApps.get(step.miniAppId);
      if (miniApp) {
        diagram += `  Mini App: ${miniApp.name} (${miniApp.role})\n`;
      }
    }
    
    if (step.endpointId) {
      const endpoint = await db.endpoints.get(step.endpointId);
      if (endpoint) {
        diagram += `  Endpoint: ${endpoint.method} ${endpoint.path}\n`;
      }
    }
    
    if (step.accountId) {
      const account = await db.accounts.get(step.accountId);
      if (account) {
        diagram += `  Account: ${account.handle} (${account.platform})\n`;
      }
    }
    
    if (step.inputs.length > 0) {
      diagram += `  Inputs: ${step.inputs.join(', ')}\n`;
    }
    
    if (step.outputs.length > 0) {
      diagram += `  Outputs: ${step.outputs.join(', ')}\n`;
    }
    
    if (step.requiredActionTypeCodes.length > 0) {
      diagram += `  Action Codes: ${step.requiredActionTypeCodes.join(', ')}\n`;
    }
    
    if (step.dependsOnStepIds.length > 0) {
      const depSteps = await Promise.all(
        step.dependsOnStepIds.map(async (id) => {
          const s = await db.flowSteps.get(id);
          return s ? `Step ${s.stepOrder}` : id;
        })
      );
      diagram += `  Depends on: ${depSteps.join(', ')}\n`;
    }
    
    diagram += `  Risk Level: ${step.riskLevel}\n`;
    
    if (step.automationHint) {
      diagram += `  Automation: ${step.automationHint}\n`;
    }
    
    if (step.description) {
      diagram += `  Description: ${step.description}\n`;
    }
  }

  return diagram;
}

export async function exportFlowSpec(flowId: string): Promise<string> {
  const flow = await db.flows.get(flowId);
  if (!flow) return 'Flow not found';

  const steps = await db.flowSteps.where('flowId').equals(flowId).sortBy('stepOrder');
  const triggers = await db.triggers.where('flowId').equals(flowId).toArray();
  const attachments = await db.flowAttachments.where('flowId').equals(flowId).toArray();

  let spec = `# Flow Specification: ${flow.name}\n\n`;
  
  spec += `## Metadata\n`;
  spec += `- **ID**: ${flow.id}\n`;
  spec += `- **Category**: ${flow.category}\n`;
  spec += `- **Priority**: ${flow.priorityLevel}\n`;
  spec += `- **Status**: ${flow.status}\n`;
  spec += `- **Goal**: ${flow.goal}\n`;
  spec += `- **Description**: ${flow.description}\n`;
  
  if (flow.tags.length > 0) {
    spec += `- **Tags**: ${flow.tags.join(', ')}\n`;
  }
  
  spec += `\n## SEO\n`;
  spec += `- **Title**: ${flow.seoTitle}\n`;
  spec += `- **Description**: ${flow.seoDescription}\n`;
  spec += `- **Keywords**: ${flow.seoKeywords.join(', ')}\n`;
  spec += `- **Hashtags**: ${flow.seoHashtags.join(', ')}\n`;
  spec += `- **Alt Text**: ${flow.altText}\n`;

  if (flow.primaryGeoTargets.length > 0) {
    spec += `\n## Geo Targeting\n`;
    spec += `- **Primary Targets**: ${flow.primaryGeoTargets.join(', ')}\n`;
    
    if (Object.keys(flow.flowIntroLocalized).length > 0) {
      spec += `\n### Localized Intros\n`;
      for (const [key, value] of Object.entries(flow.flowIntroLocalized)) {
        spec += `- **${key}**: ${value}\n`;
      }
    }
    
    if (Object.keys(flow.tagsLocalized).length > 0) {
      spec += `\n### Localized Tags\n`;
      for (const [key, tags] of Object.entries(flow.tagsLocalized)) {
        spec += `- **${key}**: ${tags.join(', ')}\n`;
      }
    }
  }

  if (attachments.length > 0) {
    spec += `\n## Attached Objects\n`;
    for (const attachment of attachments) {
      const obj = await db.objects.get(attachment.objectRefId);
      if (obj) {
        spec += `\n### ${obj.name} (${obj.type})\n`;
        spec += `- **Role in Flow**: ${attachment.role}\n`;
        spec += `- **Description**: ${obj.description}\n`;
        if (obj.backendModelName) {
          spec += `- **Backend Model**: ${obj.backendModelName}\n`;
        }
        if (obj.backendKeyField) {
          spec += `- **Key Field**: ${obj.backendKeyField}\n`;
        }
        if (obj.sourceMiniAppId) {
          const miniApp = await db.miniApps.get(obj.sourceMiniAppId);
          if (miniApp) {
            spec += `- **Source Mini App**: ${miniApp.name}\n`;
          }
        }
      }
    }
  }

  if (triggers.length > 0) {
    spec += `\n## Triggers\n`;
    for (const trigger of triggers) {
      spec += `\n### ${trigger.name}\n`;
      spec += `- **Type**: ${trigger.triggerType}\n`;
      spec += `- **Description**: ${trigger.description}\n`;
      if (trigger.relatedObjectType) {
        spec += `- **Related Object Type**: ${trigger.relatedObjectType}\n`;
      }
      if (trigger.conditionText) {
        spec += `- **Condition**: ${trigger.conditionText}\n`;
      }
      if (trigger.notes) {
        spec += `- **Notes**: ${trigger.notes}\n`;
      }
    }
  }

  spec += `\n## Steps\n`;
  for (const step of steps) {
    spec += `\n### Step ${step.stepOrder}: ${step.name}\n`;
    spec += `- **Type**: ${step.stepType}\n`;
    spec += `- **Description**: ${step.description}\n`;
    
    if (step.miniAppId) {
      const miniApp = await db.miniApps.get(step.miniAppId);
      if (miniApp) {
        spec += `- **Mini App**: ${miniApp.name} (${miniApp.role})\n`;
      }
    }
    
    if (step.endpointId) {
      const endpoint = await db.endpoints.get(step.endpointId);
      if (endpoint) {
        spec += `- **Endpoint**: ${endpoint.method} ${endpoint.path} - ${endpoint.name}\n`;
      }
    }
    
    if (step.accountId) {
      const account = await db.accounts.get(step.accountId);
      if (account) {
        spec += `- **Account**: ${account.handle} on ${account.platform} (${account.role})\n`;
      }
    }
    
    if (step.inputs.length > 0) {
      spec += `- **Inputs**: ${step.inputs.join(', ')}\n`;
    }
    
    if (step.outputs.length > 0) {
      spec += `- **Outputs**: ${step.outputs.join(', ')}\n`;
    }
    
    if (step.requiredActionTypeCodes.length > 0) {
      spec += `- **Required Action Codes**: ${step.requiredActionTypeCodes.join(', ')}\n`;
    }
    
    if (step.dependsOnStepIds.length > 0) {
      const depSteps = await Promise.all(
        step.dependsOnStepIds.map(async (id) => {
          const s = await db.flowSteps.get(id);
          return s ? `Step ${s.stepOrder}: ${s.name}` : id;
        })
      );
      spec += `- **Dependencies**: ${depSteps.join(', ')}\n`;
    }
    
    spec += `- **Risk Level**: ${step.riskLevel}\n`;
    
    if (step.automationHint) {
      spec += `- **Automation Hint**: ${step.automationHint}\n`;
    }
    
    if (step.notes) {
      spec += `- **Notes**: ${step.notes}\n`;
    }
  }

  spec += `\n---\n`;
  spec += `*Generated: ${new Date().toISOString()}*\n`;

  return spec;
}

export async function exportAllFlowsOverview(): Promise<string> {
  const flows = await db.flows.orderBy('createdAt').reverse().toArray();
  
  let overview = `# DreamNet Flowchain Overview\n\n`;
  overview += `Total Flows: ${flows.length}\n\n`;

  const categories = new Set(flows.map((f) => f.category));
  for (const category of categories) {
    const categoryFlows = flows.filter((f) => f.category === category);
    overview += `## ${category} (${categoryFlows.length})\n\n`;
    
    for (const flow of categoryFlows) {
      const steps = await db.flowSteps.where('flowId').equals(flow.id!).count();
      const attachments = await db.flowAttachments.where('flowId').equals(flow.id!).toArray();
      
      overview += `### ${flow.name}\n`;
      overview += `- **Status**: ${flow.status}\n`;
      overview += `- **Priority**: ${flow.priorityLevel}\n`;
      overview += `- **Goal**: ${flow.goal}\n`;
      overview += `- **Steps**: ${steps}\n`;
      
      if (attachments.length > 0) {
        const objects = await Promise.all(
          attachments.map(async (a) => {
            const obj = await db.objects.get(a.objectRefId);
            return obj ? `${obj.name} (${obj.type})` : null;
          })
        );
        overview += `- **Key Objects**: ${objects.filter(Boolean).join(', ')}\n`;
      }
      
      if (flow.tags.length > 0) {
        overview += `- **Tags**: ${flow.tags.join(', ')}\n`;
      }
      
      overview += `\n`;
    }
  }

  overview += `\n---\n`;
  overview += `*Generated: ${new Date().toISOString()}*\n`;

  return overview;
}
