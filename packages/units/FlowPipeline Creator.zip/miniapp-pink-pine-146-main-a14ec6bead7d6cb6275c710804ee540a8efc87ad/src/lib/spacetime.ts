'use client';

import { DbConnection } from '@/spacetime_module_bindings';
import { useEffect, useState } from 'react';
import type { RemoteTables, RemoteReducers } from '@/spacetime_module_bindings';

let dbInstance: DbConnection | null = null;

export function getDb(): DbConnection {
  if (!dbInstance) {
    dbInstance = DbConnection.builder()
      .withUri('ws://localhost:3001')
      .onConnect(() => {
        console.log('✅ SpacetimeDB Connected');
      })
      .onConnectError((error: Error) => {
        console.error('❌ Connection Error:', error);
      })
      .build();
  }
  return dbInstance;
}

export function useSpacetime() {
  const [db, setDb] = useState<DbConnection | null>(null);
  const [connected, setConnected] = useState<boolean>(false);
  const [tables, setTables] = useState<RemoteTables | null>(null);
  const [reducers, setReducers] = useState<RemoteReducers | null>(null);

  useEffect(() => {
    const connection = getDb();
    setDb(connection);

    const subscription = connection.subscriptionBuilder().subscribe([
      'mini_app_ref',
      'backend_endpoint_ref',
      'account_ref',
      'object_ref',
      'flow',
      'flow_step',
      'trigger',
      'flow_attachment',
      'geo_target'
    ]);

    setConnected(true);
    setTables(connection.db);
    setReducers(connection.reducers);

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return { db, connected, tables, reducers };
}
