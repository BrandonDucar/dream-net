'use client'
import { useState, useEffect } from 'react'
import type { FormRequirements, FormSpecification } from '@/types/form-architect'
import { InputSection } from '@/components/form-architect/input-section'
import { OutputSection } from '@/components/form-architect/output-section'
import { analyzeFormRequirements } from '@/lib/form-analyzer'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Sparkles, RefreshCw } from 'lucide-react'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function FormArchitectPage(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [requirements, setRequirements] = useState<FormRequirements>({
    purpose: '',
    audience: '',
    requiredFields: '',
    niceToHaveFields: ''
  })
  const [specification, setSpecification] = useState<FormSpecification | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false)

  const handleAnalyze = (): void => {
    setIsAnalyzing(true)
    // Simulate analysis time for better UX
    setTimeout(() => {
      const spec = analyzeFormRequirements(requirements)
      setSpecification(spec)
      setIsAnalyzing(false)
    }, 800)
  }

  const handleReset = (): void => {
    setRequirements({
      purpose: '',
      audience: '',
      requiredFields: '',
      niceToHaveFields: ''
    })
    setSpecification(null)
  }

  const canAnalyze = requirements.purpose.trim() !== '' && 
                     requirements.audience.trim() !== '' && 
                     requirements.requiredFields.trim() !== ''

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50 pt-12 pb-16 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-violet-500 to-purple-600 rounded-2xl mb-4 shadow-lg">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-5xl font-bold text-slate-900 mb-4">
            Form Architect
          </h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Design forms, wizards, and data capture flows that don't suck
          </p>
        </div>

        {/* Main Content */}
        {!specification ? (
          <div className="max-w-3xl mx-auto">
            <Card className="shadow-xl border-slate-200">
              <CardHeader className="border-b border-slate-100 bg-slate-50">
                <CardTitle className="text-2xl text-slate-900">Tell me about your form</CardTitle>
                <CardDescription className="text-slate-600">
                  Answer these questions to get a detailed form specification
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <InputSection 
                  requirements={requirements} 
                  onChange={setRequirements}
                />
                
                <div className="flex gap-3 mt-8">
                  <Button
                    onClick={handleAnalyze}
                    disabled={!canAnalyze || isAnalyzing}
                    className="flex-1 h-12 text-base bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700"
                  >
                    {isAnalyzing ? (
                      <>
                        <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Generate Form Architecture
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="max-w-6xl mx-auto">
            <OutputSection 
              specification={specification} 
              onReset={handleReset}
            />
          </div>
        )}
      </div>
    </main>
  )
}
