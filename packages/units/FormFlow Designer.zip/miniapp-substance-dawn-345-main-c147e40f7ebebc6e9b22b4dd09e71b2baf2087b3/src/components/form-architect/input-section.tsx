'use client'

import type { FormRequirements } from '@/types/form-architect'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { HelpCircle } from 'lucide-react'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'

interface InputSectionProps {
  requirements: FormRequirements
  onChange: (requirements: FormRequirements) => void
}

export function InputSection({ requirements, onChange }: InputSectionProps): JSX.Element {
  const handleChange = (field: keyof FormRequirements, value: string): void => {
    onChange({ ...requirements, [field]: value })
  }

  return (
    <div className="space-y-6">
      {/* Purpose */}
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <Label htmlFor="purpose" className="text-base font-semibold text-slate-900">
            What is this form for? *
          </Label>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <HelpCircle className="w-4 h-4 text-slate-400 cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p>Describe the primary goal: user registration, checkout, survey, contact, etc.</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <Input
          id="purpose"
          placeholder="e.g., User registration for a SaaS product"
          value={requirements.purpose}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('purpose', e.target.value)}
          className="h-11"
        />
      </div>

      {/* Audience */}
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <Label htmlFor="audience" className="text-base font-semibold text-slate-900">
            Who is filling it out? *
          </Label>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <HelpCircle className="w-4 h-4 text-slate-400 cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p>Define your users: tech level, context (mobile/desktop), time constraints, etc.</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <Textarea
          id="audience"
          placeholder="e.g., Busy professionals on mobile devices, ages 25-45, moderate tech skills"
          value={requirements.audience}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => handleChange('audience', e.target.value)}
          rows={3}
          className="resize-none"
        />
      </div>

      {/* Required Fields */}
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <Label htmlFor="requiredFields" className="text-base font-semibold text-slate-900">
            What absolutely must be collected? *
          </Label>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <HelpCircle className="w-4 h-4 text-slate-400 cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p>List the critical fields you cannot proceed without (one per line or comma-separated)</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <Textarea
          id="requiredFields"
          placeholder="e.g., Email, Password, Company Name, Role"
          value={requirements.requiredFields}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => handleChange('requiredFields', e.target.value)}
          rows={4}
          className="resize-none"
        />
      </div>

      {/* Nice to Have Fields */}
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <Label htmlFor="niceToHaveFields" className="text-base font-semibold text-slate-900">
            What's nice to have but optional?
          </Label>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <HelpCircle className="w-4 h-4 text-slate-400 cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p>Additional fields that would be helpful but not mandatory</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <Textarea
          id="niceToHaveFields"
          placeholder="e.g., Phone number, LinkedIn profile, Company size, Industry"
          value={requirements.niceToHaveFields}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => handleChange('niceToHaveFields', e.target.value)}
          rows={4}
          className="resize-none"
        />
      </div>
    </div>
  )
}
