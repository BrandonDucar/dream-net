'use client'

import type { FormSpecification } from '@/types/form-architect'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { ArrowLeft, CheckCircle2, Layers, AlertTriangle, Zap, Copy, Download } from 'lucide-react'
import { toast } from 'sonner'

interface OutputSectionProps {
  specification: FormSpecification
  onReset: () => void
}

export function OutputSection({ specification, onReset }: OutputSectionProps): JSX.Element {
  const handleCopy = (): void => {
    const text = generateSpecificationText(specification)
    navigator.clipboard.writeText(text)
    toast.success('Specification copied to clipboard!')
  }

  const handleDownload = (): void => {
    const text = generateSpecificationText(specification)
    const blob = new Blob([text], { type: 'text/markdown' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'form-specification.md'
    a.click()
    URL.revokeObjectURL(url)
    toast.success('Specification downloaded!')
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button
          variant="ghost"
          onClick={onReset}
          className="text-slate-600 hover:text-slate-900"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Start Over
        </Button>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={handleCopy}
            className="border-slate-300"
          >
            <Copy className="w-4 h-4 mr-2" />
            Copy
          </Button>
          <Button
            variant="outline"
            onClick={handleDownload}
            className="border-slate-300"
          >
            <Download className="w-4 h-4 mr-2" />
            Download
          </Button>
        </div>
      </div>

      {/* Multi-step Decision */}
      <Card className="shadow-lg border-slate-200">
        <CardHeader className="bg-gradient-to-r from-violet-50 to-purple-50 border-b border-slate-200">
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-2xl text-slate-900">Form Architecture</CardTitle>
              <CardDescription className="text-slate-600 mt-1">
                Recommended approach based on your requirements
              </CardDescription>
            </div>
            <Badge 
              variant={specification.isMultiStep ? 'default' : 'secondary'}
              className="text-sm px-3 py-1"
            >
              {specification.isMultiStep ? 'Multi-Step Wizard' : 'Single Page'}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <Layers className="w-5 h-5 text-violet-600 mt-0.5 flex-shrink-0" />
            <p className="text-slate-700 leading-relaxed">{specification.reasoning}</p>
          </div>
        </CardContent>
      </Card>

      {/* Field List */}
      <Card className="shadow-lg border-slate-200">
        <CardHeader className="bg-slate-50 border-b border-slate-200">
          <CardTitle className="text-2xl text-slate-900">Field Specifications</CardTitle>
          <CardDescription className="text-slate-600">
            Detailed breakdown by section {specification.isMultiStep && '(recommended steps)'}
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-8">
            {specification.sections.map((section, sectionIndex) => (
              <div key={sectionIndex}>
                {sectionIndex > 0 && <Separator className="my-8" />}
                
                <div className="mb-4">
                  <div className="flex items-center gap-2 mb-2">
                    {specification.isMultiStep && (
                      <Badge variant="outline" className="text-xs">
                        Step {sectionIndex + 1}
                      </Badge>
                    )}
                    <h3 className="text-xl font-semibold text-slate-900">{section.title}</h3>
                  </div>
                  <p className="text-sm text-slate-600">{section.description}</p>
                </div>

                <div className="space-y-4">
                  {section.fields.map((field, fieldIndex) => (
                    <div 
                      key={fieldIndex}
                      className="border border-slate-200 rounded-lg p-4 hover:border-violet-300 transition-colors bg-white"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold text-slate-900">{field.label}</h4>
                          {field.required && (
                            <Badge variant="destructive" className="text-xs">Required</Badge>
                          )}
                        </div>
                        <Badge variant="outline" className="text-xs font-mono">
                          {field.type}
                        </Badge>
                      </div>

                      {field.helperText && (
                        <p className="text-sm text-slate-600 mb-3">{field.helperText}</p>
                      )}

                      {field.placeholder && (
                        <div className="text-xs text-slate-500 mb-2">
                          <span className="font-medium">Placeholder:</span> {field.placeholder}
                        </div>
                      )}

                      {field.options && field.options.length > 0 && (
                        <div className="text-xs text-slate-500 mb-2">
                          <span className="font-medium">Options:</span> {field.options.join(', ')}
                        </div>
                      )}

                      {field.validationRules.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-slate-100">
                          <p className="text-xs font-medium text-slate-700 mb-2">Validation Rules:</p>
                          <ul className="space-y-1">
                            {field.validationRules.map((rule, ruleIndex) => (
                              <li key={ruleIndex} className="flex items-start gap-2 text-xs text-slate-600">
                                <CheckCircle2 className="w-3 h-3 text-green-600 mt-0.5 flex-shrink-0" />
                                <span>{rule}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Error Handling */}
      <Card className="shadow-lg border-slate-200">
        <CardHeader className="bg-red-50 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            <CardTitle className="text-xl text-slate-900">Error Handling & UX</CardTitle>
          </div>
          <CardDescription className="text-slate-600">
            How to handle errors and improve user experience
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-6">
            <div>
              <h4 className="font-semibold text-slate-900 mb-2">Error Display Strategy</h4>
              <p className="text-sm text-slate-700 mb-3">{specification.errorHandling.strategy}</p>
              <ul className="space-y-2">
                {specification.errorHandling.recommendations.map((rec, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-violet-600 mt-0.5 flex-shrink-0" />
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>

            <Separator />

            <div>
              <h4 className="font-semibold text-slate-900 mb-2">Progress Saving</h4>
              <ul className="space-y-2">
                {specification.uxNotes.progressSaving.map((note, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                    <span>{note}</span>
                  </li>
                ))}
              </ul>
            </div>

            <Separator />

            <div>
              <h4 className="font-semibold text-slate-900 mb-2">Pre-fill & Data Inference</h4>
              <ul className="space-y-2">
                {specification.uxNotes.prefillStrategy.map((note, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>{note}</span>
                  </li>
                ))}
              </ul>
            </div>

            <Separator />

            <div>
              <h4 className="font-semibold text-slate-900 mb-2">Accessibility Considerations</h4>
              <ul className="space-y-2">
                {specification.uxNotes.accessibility.map((note, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                    <span>{note}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Event Hooks */}
      <Card className="shadow-lg border-slate-200">
        <CardHeader className="bg-amber-50 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-600" />
            <CardTitle className="text-xl text-slate-900">Event Hooks & Workflows</CardTitle>
          </div>
          <CardDescription className="text-slate-600">
            Recommended triggers for analytics, emails, and follow-up actions
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-4">
            {specification.eventHooks.map((hook, index) => (
              <div 
                key={index}
                className="border border-slate-200 rounded-lg p-4 bg-white hover:border-amber-300 transition-colors"
              >
                <div className="flex items-start gap-3">
                  <div className="flex-1">
                    <h4 className="font-semibold text-slate-900 mb-1">{hook.name}</h4>
                    <div className="text-sm text-slate-600 mb-2">
                      <span className="font-medium text-slate-700">Trigger:</span> {hook.trigger}
                    </div>
                    <p className="text-sm text-slate-600">{hook.purpose}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function generateSpecificationText(spec: FormSpecification): string {
  let text = '# Form Architecture Specification\n\n'
  
  text += `## Form Type: ${spec.isMultiStep ? 'Multi-Step Wizard' : 'Single Page'}\n\n`
  text += `${spec.reasoning}\n\n`
  
  text += '## Field Specifications\n\n'
  spec.sections.forEach((section, index) => {
    text += `### ${spec.isMultiStep ? `Step ${index + 1}: ` : ''}${section.title}\n\n`
    text += `${section.description}\n\n`
    
    section.fields.forEach((field) => {
      text += `#### ${field.label}${field.required ? ' (Required)' : ''}\n\n`
      text += `- **Type:** ${field.type}\n`
      text += `- **Helper Text:** ${field.helperText}\n`
      if (field.placeholder) text += `- **Placeholder:** ${field.placeholder}\n`
      if (field.options) text += `- **Options:** ${field.options.join(', ')}\n`
      text += `- **Validation Rules:**\n`
      field.validationRules.forEach(rule => {
        text += `  - ${rule}\n`
      })
      text += '\n'
    })
  })
  
  text += '## Error Handling\n\n'
  text += `**Strategy:** ${spec.errorHandling.strategy}\n\n`
  text += '**Recommendations:**\n'
  spec.errorHandling.recommendations.forEach(rec => {
    text += `- ${rec}\n`
  })
  
  text += '\n## UX Notes\n\n'
  text += '### Progress Saving\n'
  spec.uxNotes.progressSaving.forEach(note => {
    text += `- ${note}\n`
  })
  
  text += '\n### Pre-fill Strategy\n'
  spec.uxNotes.prefillStrategy.forEach(note => {
    text += `- ${note}\n`
  })
  
  text += '\n### Accessibility\n'
  spec.uxNotes.accessibility.forEach(note => {
    text += `- ${note}\n`
  })
  
  text += '\n## Event Hooks\n\n'
  spec.eventHooks.forEach(hook => {
    text += `### ${hook.name}\n`
    text += `- **Trigger:** ${hook.trigger}\n`
    text += `- **Purpose:** ${hook.purpose}\n\n`
  })
  
  return text
}
