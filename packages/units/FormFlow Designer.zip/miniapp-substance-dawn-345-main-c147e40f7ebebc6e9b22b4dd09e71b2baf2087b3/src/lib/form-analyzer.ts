import type { FormRequirements, FormSpecification, FormField, FormSection } from '@/types/form-architect'

export function analyzeFormRequirements(requirements: FormRequirements): FormSpecification {
  const requiredFieldsList = parseFieldList(requirements.requiredFields)
  const niceToHaveFieldsList = parseFieldList(requirements.niceToHaveFields)
  
  const allFieldsCount = requiredFieldsList.length + niceToHaveFieldsList.length
  const isMultiStep = shouldBeMultiStep(requirements, allFieldsCount)
  
  const sections = generateSections(requirements, requiredFieldsList, niceToHaveFieldsList, isMultiStep)
  const errorHandling = generateErrorHandling(isMultiStep, requirements.audience)
  const uxNotes = generateUXNotes(isMultiStep, requirements.audience, requirements.purpose)
  const eventHooks = generateEventHooks(requirements.purpose)
  
  return {
    isMultiStep,
    reasoning: generateReasoning(isMultiStep, allFieldsCount, requirements),
    sections,
    errorHandling,
    uxNotes,
    eventHooks
  }
}

function parseFieldList(fieldString: string): string[] {
  if (!fieldString.trim()) return []
  
  // Split by newlines or commas
  return fieldString
    .split(/[\n,]/)
    .map((field: string) => field.trim())
    .filter((field: string) => field.length > 0)
}

function shouldBeMultiStep(requirements: FormRequirements, totalFields: number): boolean {
  const complexityFactors = {
    fieldCount: totalFields > 8,
    audienceMobile: requirements.audience.toLowerCase().includes('mobile'),
    audienceBusy: requirements.audience.toLowerCase().includes('busy') || 
                   requirements.audience.toLowerCase().includes('time'),
    purposeComplex: requirements.purpose.toLowerCase().includes('checkout') ||
                     requirements.purpose.toLowerCase().includes('registration') ||
                     requirements.purpose.toLowerCase().includes('onboarding')
  }
  
  const complexityScore = Object.values(complexityFactors).filter(Boolean).length
  return complexityScore >= 2
}

function generateReasoning(isMultiStep: boolean, fieldCount: number, requirements: FormRequirements): string {
  if (isMultiStep) {
    const reasons: string[] = []
    
    if (fieldCount > 8) {
      reasons.push(`with ${fieldCount} total fields, breaking into steps reduces cognitive load`)
    }
    
    if (requirements.audience.toLowerCase().includes('mobile')) {
      reasons.push('mobile users benefit from focused, single-purpose screens')
    }
    
    if (requirements.audience.toLowerCase().includes('busy')) {
      reasons.push('busy users can save progress and return later')
    }
    
    return `Recommended as a multi-step wizard because ${reasons.join(', and ')}. This approach improves completion rates and provides clear progress indicators.`
  } else {
    return `Recommended as a single-page form because you have ${fieldCount} total fields, which is manageable on one screen. This reduces friction and allows users to see all requirements upfront, making it easier to gather information before starting.`
  }
}

function generateSections(
  requirements: FormRequirements,
  requiredFields: string[],
  niceToHaveFields: string[],
  isMultiStep: boolean
): FormSection[] {
  const sections: FormSection[] = []
  
  if (isMultiStep) {
    // Step 1: Essential information
    const essentialFields = requiredFields.slice(0, Math.ceil(requiredFields.length / 2))
    sections.push({
      title: 'Essential Information',
      description: 'Core details we need to get started',
      fields: essentialFields.map((field: string) => generateFieldSpec(field, true, requirements.purpose))
    })
    
    // Step 2: Additional details
    const additionalRequiredFields = requiredFields.slice(Math.ceil(requiredFields.length / 2))
    if (additionalRequiredFields.length > 0) {
      sections.push({
        title: 'Additional Details',
        description: 'Complete your profile with these required fields',
        fields: additionalRequiredFields.map((field: string) => generateFieldSpec(field, true, requirements.purpose))
      })
    }
    
    // Step 3: Optional information
    if (niceToHaveFields.length > 0) {
      sections.push({
        title: 'Optional Information',
        description: 'Help us serve you better (you can skip this step)',
        fields: niceToHaveFields.map((field: string) => generateFieldSpec(field, false, requirements.purpose))
      })
    }
    
    // Step 4: Review
    sections.push({
      title: 'Review & Submit',
      description: 'Confirm your information before submitting',
      fields: []
    })
  } else {
    // Single page: group by required vs optional
    if (requiredFields.length > 0) {
      sections.push({
        title: 'Required Information',
        description: 'All fields marked with * are required',
        fields: requiredFields.map((field: string) => generateFieldSpec(field, true, requirements.purpose))
      })
    }
    
    if (niceToHaveFields.length > 0) {
      sections.push({
        title: 'Optional Information',
        description: 'Help us serve you better',
        fields: niceToHaveFields.map((field: string) => generateFieldSpec(field, false, requirements.purpose))
      })
    }
  }
  
  return sections
}

function generateFieldSpec(fieldName: string, required: boolean, purpose: string): FormField {
  const lowerName = fieldName.toLowerCase()
  const id = fieldName.toLowerCase().replace(/\s+/g, '_')
  
  // Email
  if (lowerName.includes('email') || lowerName.includes('e-mail')) {
    return {
      id,
      label: fieldName,
      type: 'email',
      helperText: 'We\'ll use this to contact you',
      validationRules: [
        'Must be a valid email format (user@domain.com)',
        'Cannot contain spaces',
        'Domain must exist'
      ],
      required,
      placeholder: 'you@example.com'
    }
  }
  
  // Phone
  if (lowerName.includes('phone') || lowerName.includes('mobile') || lowerName.includes('tel')) {
    return {
      id,
      label: fieldName,
      type: 'tel',
      helperText: 'Include country code for international numbers',
      validationRules: [
        'Must be a valid phone number format',
        'Minimum 10 digits',
        'Only numbers, spaces, hyphens, and parentheses allowed'
      ],
      required,
      placeholder: '+1 (555) 123-4567'
    }
  }
  
  // Password
  if (lowerName.includes('password')) {
    return {
      id,
      label: fieldName,
      type: 'password',
      helperText: 'Choose a strong password to protect your account',
      validationRules: [
        'Minimum 8 characters',
        'At least one uppercase letter',
        'At least one lowercase letter',
        'At least one number',
        'At least one special character (!@#$%^&*)'
      ],
      required,
      placeholder: '••••••••'
    }
  }
  
  // URL/Website
  if (lowerName.includes('website') || lowerName.includes('url') || lowerName.includes('link')) {
    return {
      id,
      label: fieldName,
      type: 'url',
      helperText: 'Your website or online profile',
      validationRules: [
        'Must be a valid URL format',
        'Should start with http:// or https://',
        'Domain must be properly formatted'
      ],
      required,
      placeholder: 'https://example.com'
    }
  }
  
  // Date
  if (lowerName.includes('date') || lowerName.includes('birthday') || lowerName.includes('dob')) {
    return {
      id,
      label: fieldName,
      type: 'date',
      helperText: 'Select a date from the calendar',
      validationRules: [
        'Must be a valid date',
        lowerName.includes('birth') ? 'Must be at least 18 years ago' : 'Cannot be in the past'
      ],
      required
    }
  }
  
  // Number fields
  if (lowerName.includes('age') || lowerName.includes('size') || lowerName.includes('count') || 
      lowerName.includes('number of')) {
    return {
      id,
      label: fieldName,
      type: 'number',
      helperText: 'Enter a numeric value',
      validationRules: [
        'Must be a positive number',
        lowerName.includes('age') ? 'Must be between 1 and 120' : 'Must be greater than 0'
      ],
      required,
      placeholder: '0'
    }
  }
  
  // Select fields (role, industry, etc.)
  if (lowerName.includes('role') || lowerName.includes('position') || lowerName.includes('title')) {
    return {
      id,
      label: fieldName,
      type: 'select',
      helperText: 'Select your current role',
      validationRules: ['Must select one option from the list'],
      required,
      options: ['Developer', 'Designer', 'Product Manager', 'Marketing', 'Sales', 'Executive', 'Other']
    }
  }
  
  if (lowerName.includes('industry') || lowerName.includes('sector')) {
    return {
      id,
      label: fieldName,
      type: 'select',
      helperText: 'What industry do you work in?',
      validationRules: ['Must select one option from the list'],
      required,
      options: ['Technology', 'Healthcare', 'Finance', 'Education', 'Retail', 'Manufacturing', 'Other']
    }
  }
  
  // Textarea for long content
  if (lowerName.includes('message') || lowerName.includes('description') || lowerName.includes('comment') ||
      lowerName.includes('details') || lowerName.includes('bio')) {
    return {
      id,
      label: fieldName,
      type: 'textarea',
      helperText: 'Provide additional context or information',
      validationRules: [
        required ? 'Minimum 10 characters' : 'Optional',
        'Maximum 500 characters'
      ],
      required,
      placeholder: 'Enter your message here...'
    }
  }
  
  // Default to text input
  return {
    id,
    label: fieldName,
    type: 'text',
    helperText: `Enter your ${fieldName.toLowerCase()}`,
    validationRules: [
      required ? 'Cannot be empty' : 'Optional',
      'Minimum 2 characters',
      'Maximum 100 characters',
      'Special characters allowed: - . , \' space'
    ],
    required,
    placeholder: `Your ${fieldName.toLowerCase()}`
  }
}

function generateErrorHandling(isMultiStep: boolean, audience: string): {
  strategy: string
  recommendations: string[]
} {
  const isMobile = audience.toLowerCase().includes('mobile')
  
  return {
    strategy: isMultiStep 
      ? 'Validate each step before allowing progression. Show errors inline as users complete fields, with a summary at step submission.'
      : 'Use inline validation with real-time feedback as users type. Display a summary of all errors above the form on submission attempt.',
    recommendations: [
      'Show errors next to the relevant field with clear, specific messages',
      isMobile 
        ? 'Use larger touch targets and clear error colors (avoid relying on color alone)'
        : 'Use tooltips for additional validation help when fields have complex rules',
      'Highlight the first error field and scroll it into view',
      'Prevent form submission until all errors are resolved',
      'Use positive reinforcement with checkmarks for valid fields',
      'Provide example formats for complex fields (e.g., phone, date)',
      'Allow users to see passwords temporarily with a "show" toggle'
    ]
  }
}

function generateUXNotes(isMultiStep: boolean, audience: string, purpose: string): {
  progressSaving: string[]
  prefillStrategy: string[]
  accessibility: string[]
} {
  const isBusy = audience.toLowerCase().includes('busy')
  const isMobile = audience.toLowerCase().includes('mobile')
  
  return {
    progressSaving: isMultiStep ? [
      'Auto-save each step to localStorage or session storage',
      'Show "Draft saved" confirmation after each auto-save',
      'Allow users to resume from any device using their email',
      'Set a 30-day expiration on saved drafts',
      isBusy ? 'Send email reminders for incomplete forms after 24 hours' : 'Prompt to complete if user returns within 7 days'
    ] : [
      'Auto-save form data to localStorage on field blur',
      'Show a "Draft saved" indicator in the form header',
      'Clear saved data after successful submission',
      isBusy ? 'Prompt user to resume if they navigate away and return' : 'Keep draft data for 7 days'
    ],
    
    prefillStrategy: [
      'Use OAuth/SSO data to pre-fill name, email, and profile picture',
      'Detect user location for country/region fields using IP geolocation',
      purpose.toLowerCase().includes('checkout') 
        ? 'Pre-fill shipping from billing address with an opt-out checkbox'
        : 'Suggest company domain from email address (e.g., @company.com → Company Name)',
      'Remember previous selections for returning users',
      'Use browser autocomplete attributes for standard fields (name, email, tel, etc.)',
      'Infer phone country code from detected location'
    ],
    
    accessibility: [
      'Use proper ARIA labels and roles for all form elements',
      'Ensure keyboard navigation works (Tab, Shift+Tab, Enter)',
      'Provide clear focus indicators with high contrast',
      'Use semantic HTML (<label>, <fieldset>, <legend>)',
      isMobile 
        ? 'Ensure minimum touch target size of 44x44px for mobile'
        : 'Support keyboard shortcuts for power users',
      'Test with screen readers (NVDA, JAWS, VoiceOver)',
      'Provide text alternatives for any icons or visual indicators',
      'Ensure color contrast ratios meet WCAG AA standards (4.5:1)',
      'Allow font size adjustments without breaking layout'
    ]
  }
}

function generateEventHooks(purpose: string): Array<{ name: string; trigger: string; purpose: string }> {
  const hooks = [
    {
      name: 'form_started',
      trigger: 'User begins filling the form (first field interaction)',
      purpose: 'Track conversion funnel, identify drop-off points, personalize follow-up'
    },
    {
      name: 'form_abandoned',
      trigger: 'User leaves page with incomplete form (>50% complete)',
      purpose: 'Send recovery email, offer help via chat, analyze UX friction points'
    },
    {
      name: 'validation_failed',
      trigger: 'User attempts submission with validation errors',
      purpose: 'Track problematic fields, improve error messages, identify UX issues'
    },
    {
      name: 'form_submitted',
      trigger: 'Successful form submission',
      purpose: 'Send confirmation email, trigger onboarding workflow, update CRM'
    }
  ]
  
  const lowerPurpose = purpose.toLowerCase()
  
  if (lowerPurpose.includes('checkout') || lowerPurpose.includes('payment')) {
    hooks.push({
      name: 'payment_initiated',
      trigger: 'User clicks final payment/submit button',
      purpose: 'Track conversion, prevent duplicate submissions, trigger fraud checks'
    })
  }
  
  if (lowerPurpose.includes('registration') || lowerPurpose.includes('signup')) {
    hooks.push({
      name: 'account_created',
      trigger: 'After successful form submission and account creation',
      purpose: 'Send welcome email, trigger onboarding sequence, create user profile'
    })
  }
  
  if (lowerPurpose.includes('contact') || lowerPurpose.includes('inquiry')) {
    hooks.push({
      name: 'inquiry_received',
      trigger: 'After form submission',
      purpose: 'Notify sales team, create support ticket, send auto-reply'
    })
  }
  
  return hooks
}
