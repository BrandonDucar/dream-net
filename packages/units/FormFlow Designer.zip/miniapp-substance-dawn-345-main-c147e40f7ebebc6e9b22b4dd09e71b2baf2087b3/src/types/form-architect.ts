export interface FormRequirements {
  purpose: string
  audience: string
  requiredFields: string
  niceToHaveFields: string
}

export interface FormField {
  id: string
  label: string
  type: 'text' | 'email' | 'tel' | 'number' | 'textarea' | 'select' | 'radio' | 'checkbox' | 'date' | 'file' | 'url' | 'password'
  helperText: string
  validationRules: string[]
  required: boolean
  options?: string[]
  placeholder?: string
  step?: number
}

export interface FormSection {
  title: string
  description: string
  fields: FormField[]
}

export interface FormSpecification {
  isMultiStep: boolean
  reasoning: string
  sections: FormSection[]
  errorHandling: {
    strategy: string
    recommendations: string[]
  }
  uxNotes: {
    progressSaving: string[]
    prefillStrategy: string[]
    accessibility: string[]
  }
  eventHooks: {
    name: string
    trigger: string
    purpose: string
  }[]
}
