'use client'
import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

// Oracle responses library
const oracleResponses: string[] = [
  "The sheep say: Yes, absolutely! The wool is aligned in your favor.",
  "The flock whispers: Perhaps... but only if you believe in the power of pasture.",
  "A wise ram declares: Not today, but tomorrow holds fleece-y possibilities.",
  "The shepherd's intuition suggests: This path is full of wool-derful surprises!",
  "Baaa-lieve it or not, the answer is a resounding YES!",
  "The meadow speaks softly: Things are unclear, like morning fog over grass.",
  "Ancient sheep wisdom reveals: The stars are grazing elsewhere tonight.",
  "The oracle bleats: Definitely not. The grass is greener on the other side.",
  "A lamb's prophecy: You already know the answer deep in your fleece.",
  "The herd consensus: Absolutely, without a shadow of a ewe!",
  "Mystic sheep vision: Proceed with caution, but proceed nonetheless.",
  "The wool is tangled on this one. Ask again when the moon is full.",
  "A shepherdess once said: All signs point to a fluffy YES!",
  "The cosmic rams decree: No, but the universe has better plans for ewe.",
  "Listen closely... the sheep are saying: Maybe, maybe not. Life is mysterious!",
  "The oracle has spoken: Yes! The flock approves with enthusiastic bleating.",
  "Sheep wisdom suggests: This is not your field to graze in right now.",
  "A gentle lamb predicts: Sweet dreams will guide you to the answer.",
  "The ancient prophecy states: Count on it like counting sheep!",
  "The mystical flock declares: Outlook unclear. Try grazing elsewhere."
]

// Sheep moods
const sheepMoods: string[] = ['Calm', 'Curious', 'Hyper', 'Wise']

// Mood colors for badges
const moodColors: Record<string, string> = {
  'Calm': 'bg-blue-100 text-blue-800 hover:bg-blue-100',
  'Curious': 'bg-purple-100 text-purple-800 hover:bg-purple-100',
  'Hyper': 'bg-orange-100 text-orange-800 hover:bg-orange-100',
  'Wise': 'bg-green-100 text-green-800 hover:bg-green-100'
}

interface OracleResult {
  answer: string
  confidence: number
  mood: string
}

export default function SheepWhispererPage(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [question, setQuestion] = useState<string>('')
  const [result, setResult] = useState<OracleResult | null>(null)
  const [isRevealing, setIsRevealing] = useState<boolean>(false)

  const askTheSheep = (): void => {
    if (!question.trim()) {
      return
    }

    setIsRevealing(true)

    // Simulate "thinking" delay for dramatic effect
    setTimeout(() => {
      // Random answer
      const randomAnswer: string = oracleResponses[Math.floor(Math.random() * oracleResponses.length)]
      
      // Random mood
      const randomMood: string = sheepMoods[Math.floor(Math.random() * sheepMoods.length)]
      
      // Confidence influenced by question length (longer questions = higher confidence)
      const baseConfidence: number = Math.floor(Math.random() * 60) + 20 // 20-80 base
      const lengthBonus: number = Math.min(question.length, 50) / 2 // Up to +25 bonus
      const finalConfidence: number = Math.min(Math.round(baseConfidence + lengthBonus), 100)

      setResult({
        answer: randomAnswer,
        confidence: finalConfidence,
        mood: randomMood
      })
      setIsRevealing(false)
    }, 1500)
  }

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>): void => {
    if (e.key === 'Enter') {
      askTheSheep()
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50 flex items-center justify-center p-4 pt-16 md:pt-4">
      <div className="w-full max-w-2xl space-y-8">
        {/* Header */}
        <div className="text-center space-y-3">
          <div className="flex items-center justify-center gap-3">
            <span className="text-6xl">🐑</span>
            <div>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-800">
                SHEEP Whisperer
              </h1>
              <p className="text-sm text-gray-600 font-mono">$SHWP</p>
            </div>
            <span className="text-6xl">🐑</span>
          </div>
          <p className="text-gray-600 max-w-md mx-auto">
            Ask the mystical sheep oracle anything, and receive divine wool-powered wisdom.
          </p>
        </div>

        {/* Question Input */}
        <Card className="shadow-xl border-2 border-gray-200">
          <CardHeader>
            <CardTitle className="text-xl">Your Question</CardTitle>
            <CardDescription>
              Type your question below and let the sheep guide you...
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              type="text"
              placeholder="Will I find happiness today?"
              value={question}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setQuestion(e.target.value)}
              onKeyPress={handleKeyPress}
              className="text-lg py-6"
              disabled={isRevealing}
            />
            <Button
              onClick={askTheSheep}
              disabled={!question.trim() || isRevealing}
              className="w-full text-lg py-6 bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
            >
              {isRevealing ? (
                <>
                  <span className="animate-pulse">🐑 Consulting the Flock...</span>
                </>
              ) : (
                '🐑 Ask the SHEEP'
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Result Display */}
        {result && (
          <Card className="shadow-xl border-2 border-purple-200 bg-gradient-to-br from-white to-purple-50 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-2xl">Oracle Answer</CardTitle>
                <Badge className={moodColors[result.mood]}>
                  {result.mood} Sheep
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Answer */}
              <div className="bg-white p-6 rounded-lg border-2 border-gray-200 shadow-sm">
                <p className="text-lg text-gray-800 leading-relaxed italic">
                  "{result.answer}"
                </p>
              </div>

              {/* Confidence Score */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold text-gray-700">
                    Confidence Score
                  </span>
                  <span className="text-2xl font-bold text-gray-900">
                    {result.confidence}%
                  </span>
                </div>
                <Progress 
                  value={result.confidence} 
                  className="h-3"
                />
                <p className="text-xs text-gray-500 text-center">
                  {result.confidence >= 80 && "The sheep are extremely confident!"}
                  {result.confidence >= 60 && result.confidence < 80 && "The flock is fairly certain."}
                  {result.confidence >= 40 && result.confidence < 60 && "The sheep are somewhat uncertain."}
                  {result.confidence < 40 && "The oracle is hazy today."}
                </p>
              </div>

              {/* Sheep Mood Description */}
              <div className="bg-gradient-to-r from-purple-50 to-blue-50 p-4 rounded-lg border border-purple-200">
                <p className="text-sm text-gray-700">
                  <strong>Sheep Mood:</strong> The oracle sheep is feeling{' '}
                  <span className="font-semibold">{result.mood.toLowerCase()}</span> today.{' '}
                  {result.mood === 'Calm' && 'Peaceful grazing energy flows through the answer.'}
                  {result.mood === 'Curious' && 'An inquisitive spirit guides this wisdom.'}
                  {result.mood === 'Hyper' && 'Energetic bleating amplifies the message!'}
                  {result.mood === 'Wise' && 'Ancient sheep knowledge speaks through ages.'}
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Footer */}
        <div className="text-center text-sm text-gray-500 space-y-1">
          <p>✨ Powered by mystical sheep energy ✨</p>
          <p className="text-xs">For entertainment purposes only. Please don't base life decisions on sheep advice.</p>
        </div>
      </div>
    </main>
  )
}
