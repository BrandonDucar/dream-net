'use client'
import { useState, useEffect } from 'react';
import { DreamNetProvider } from '@/contexts/DreamNetContext';
import SegmentDashboard from '@/components/dreamnet/SegmentDashboard';
import SegmentDetail from '@/components/dreamnet/SegmentDetail';
import FunnelDetail from '@/components/dreamnet/FunnelDetail';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type View = 'dashboard' | 'segment' | 'funnel';

export default function DreamNetCartographer() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [selectedSegmentId, setSelectedSegmentId] = useState<string | null>(null);
  const [selectedFunnelId, setSelectedFunnelId] = useState<string | null>(null);

  const handleViewSegment = (segmentId: string): void => {
    setSelectedSegmentId(segmentId);
    setCurrentView('segment');
  };

  const handleViewFunnel = (funnelId: string): void => {
    setSelectedFunnelId(funnelId);
    setCurrentView('funnel');
  };

  const handleBack = (): void => {
    if (currentView === 'funnel') {
      setCurrentView('segment');
      setSelectedFunnelId(null);
    } else if (currentView === 'segment') {
      setCurrentView('dashboard');
      setSelectedSegmentId(null);
    }
  };

  return (
    <DreamNetProvider>
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-4 mb-4">
              {currentView !== 'dashboard' && (
                <Button
                  onClick={handleBack}
                  variant="ghost"
                  size="sm"
                  className="text-slate-300 hover:text-white"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back
                </Button>
              )}
            </div>
            
            <div className="text-center">
              <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent mb-3">
                DreamNet Funnel Cartographer
              </h1>
              <p className="text-slate-400 text-lg">
                Design and manage audience segments + funnels for your ecosystem
              </p>
            </div>
          </div>

          {/* Content */}
          <div className="bg-slate-900/50 backdrop-blur-sm rounded-2xl border border-slate-800 shadow-2xl p-8">
            {currentView === 'dashboard' && (
              <SegmentDashboard onViewSegment={handleViewSegment} />
            )}
            
            {currentView === 'segment' && selectedSegmentId && (
              <SegmentDetail
                segmentId={selectedSegmentId}
                onViewFunnel={handleViewFunnel}
              />
            )}
            
            {currentView === 'funnel' && selectedFunnelId && (
              <FunnelDetail funnelId={selectedFunnelId} />
            )}
          </div>

          {/* Footer */}
          <div className="mt-8 text-center text-slate-500 text-sm">
            <p>All data stored locally • No external APIs</p>
          </div>
        </div>
      </div>
    </DreamNetProvider>
  );
}
