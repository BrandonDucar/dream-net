'use client';

import { useState } from 'react';
import { useDreamNet } from '@/contexts/DreamNetContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Target } from 'lucide-react';

interface CreateFunnelDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  segmentId: string;
  onCreated: (funnelId: string) => void;
}

export default function CreateFunnelDialog({ open, onOpenChange, segmentId, onCreated }: CreateFunnelDialogProps) {
  const { createCustomFunnel } = useDreamNet();
  const [name, setName] = useState<string>('');
  const [description, setDescription] = useState<string>('');

  const handleCreate = (): void => {
    if (!name || !description) return;

    const funnel = createCustomFunnel(segmentId, name, description);
    
    setName('');
    setDescription('');
    onOpenChange(false);
    onCreated(funnel.id);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-900 border-slate-700">
        <DialogHeader>
          <DialogTitle className="text-2xl text-white flex items-center gap-2">
            <Target className="h-6 w-6 text-purple-400" />
            Create Custom Funnel
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            Create a custom funnel map and add your own stages
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="funnel-name" className="text-slate-300">
              Funnel Name
            </Label>
            <Input
              id="funnel-name"
              placeholder="e.g. Wolf Pack Advanced Journey"
              value={name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
              className="bg-slate-800/50 border-slate-700 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="funnel-description" className="text-slate-300">
              Description
            </Label>
            <Textarea
              id="funnel-description"
              placeholder="Describe the purpose and goals of this funnel..."
              value={description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
              className="bg-slate-800/50 border-slate-700 text-white min-h-[100px]"
            />
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <Button
            variant="ghost"
            onClick={() => onOpenChange(false)}
            className="text-slate-400"
          >
            Cancel
          </Button>
          <Button
            onClick={handleCreate}
            disabled={!name || !description}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
          >
            Create Funnel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
