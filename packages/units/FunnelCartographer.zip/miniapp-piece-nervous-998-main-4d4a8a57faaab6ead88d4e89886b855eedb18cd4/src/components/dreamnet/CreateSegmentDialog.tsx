'use client';

import { useState } from 'react';
import { useDreamNet } from '@/contexts/DreamNetContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Sparkles } from 'lucide-react';

interface CreateSegmentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function CreateSegmentDialog({ open, onOpenChange }: CreateSegmentDialogProps) {
  const { createAudienceSegment } = useDreamNet();
  const [name, setName] = useState<string>('');
  const [archetype, setArchetype] = useState<string>('');
  const [prompt, setPrompt] = useState<string>('');
  const [isCreating, setIsCreating] = useState<boolean>(false);

  const handleCreate = async (): Promise<void> => {
    if (!name || !archetype || !prompt) return;

    setIsCreating(true);
    
    try {
      createAudienceSegment({ name, archetype, prompt });
      
      setName('');
      setArchetype('');
      setPrompt('');
      onOpenChange(false);
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-900 border-slate-700 max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl text-white flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-purple-400" />
            Create Audience Segment
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            Define your audience and let DreamNet generate insights, motivations, and SEO metadata
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-slate-300">
              Segment Name
            </Label>
            <Input
              id="name"
              placeholder="e.g. Wolf Pack, Whale Ops, Pickleball Locals"
              value={name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
              className="bg-slate-800/50 border-slate-700 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="archetype" className="text-slate-300">
              Archetype
            </Label>
            <Input
              id="archetype"
              placeholder="e.g. hunter, guardian, builder, lurker"
              value={archetype}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setArchetype(e.target.value)}
              className="bg-slate-800/50 border-slate-700 text-white"
            />
            <p className="text-xs text-slate-500">
              What type of personality or role does this segment represent?
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="prompt" className="text-slate-300">
              Description Prompt
            </Label>
            <Textarea
              id="prompt"
              placeholder="e.g. Base degen meme traders who love weird narratives OR local pickleball players in Jupiter, FL who like fun social games"
              value={prompt}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setPrompt(e.target.value)}
              className="bg-slate-800/50 border-slate-700 text-white min-h-[120px]"
            />
            <p className="text-xs text-slate-500">
              Describe who they are, what they care about, and any relevant context
            </p>
          </div>

          <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
            <h4 className="text-sm font-semibold text-purple-300 mb-2">
              What gets generated:
            </h4>
            <ul className="text-xs text-slate-400 space-y-1">
              <li>• Core motivations and pain points</li>
              <li>• Preferred channels and chain affinity</li>
              <li>• SEO metadata (title, description, keywords, hashtags)</li>
              <li>• Tags and categorization</li>
            </ul>
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <Button
            variant="ghost"
            onClick={() => onOpenChange(false)}
            disabled={isCreating}
            className="text-slate-400"
          >
            Cancel
          </Button>
          <Button
            onClick={handleCreate}
            disabled={!name || !archetype || !prompt || isCreating}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
          >
            {isCreating ? (
              <>Creating...</>
            ) : (
              <>
                <Sparkles className="h-4 w-4 mr-2" />
                Create Segment
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
