'use client';

import { useState } from 'react';
import { useDreamNet } from '@/contexts/DreamNetContext';
import type { FunnelStatus } from '@/types/dreamnet';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { FileText, Edit2, Plus, Trash2, Copy, CheckCircle2, Target, ArrowDown } from 'lucide-react';
import StageDetailDialog from './StageDetailDialog';

interface FunnelDetailProps {
  funnelId: string;
}

export default function FunnelDetail({ funnelId }: FunnelDetailProps) {
  const {
    getFunnelDetails,
    getSegment,
    updateFunnel,
    deleteFunnel,
    deleteStage,
    addOrUpdateFunnelStage,
    exportBrief,
  } = useDreamNet();

  const details = getFunnelDetails(funnelId);
  const segment = details ? getSegment(details.funnel.segmentId) : null;

  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);
  const [exportedBrief, setExportedBrief] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [selectedStageId, setSelectedStageId] = useState<string | null>(null);
  const [isStageDialogOpen, setIsStageDialogOpen] = useState<boolean>(false);

  if (!details || !segment) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-400">Funnel not found</p>
      </div>
    );
  }

  const { funnel, stages } = details;

  const handleExport = (): void => {
    const brief = exportBrief(funnelId);
    setExportedBrief(brief);
    setIsExportOpen(true);
  };

  const handleCopyBrief = (): void => {
    navigator.clipboard.writeText(exportedBrief);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleStatusChange = (status: string): void => {
    updateFunnel(funnelId, { status: status as FunnelStatus });
  };

  const handleDeleteFunnel = (): void => {
    if (confirm(`Delete "${funnel.name}"? This will also delete all stages.`)) {
      deleteFunnel(funnelId);
    }
  };

  const handleDeleteStage = (stageId: string): void => {
    if (confirm('Delete this stage?')) {
      deleteStage(stageId);
    }
  };

  const handleAddStage = (): void => {
    const maxOrder = stages.length > 0 ? Math.max(...stages.map((s) => s.stageOrder)) : 0;
    const newStage = addOrUpdateFunnelStage({
      segmentId: funnel.segmentId,
      stageName: 'New Stage',
      stageOrder: maxOrder + 1,
      objective: 'Define the objective for this stage',
      keyMessages: ['Add key message'],
      recommendedCTAs: ['Add CTA'],
      recommendedAssets: [],
      notes: '',
    });

    updateFunnel(funnelId, {
      stageIds: [...funnel.stageIds, newStage.id],
    });
  };

  const handleEditStage = (stageId: string): void => {
    setSelectedStageId(stageId);
    setIsStageDialogOpen(true);
  };

  const getStatusColor = (status: FunnelStatus): string => {
    switch (status) {
      case 'active':
        return 'bg-green-500/20 text-green-300 border-green-500/50';
      case 'draft':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/50';
      case 'paused':
        return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/50';
      case 'retired':
        return 'bg-slate-500/20 text-slate-300 border-slate-500/50';
      case 'idea':
        return 'bg-purple-500/20 text-purple-300 border-purple-500/50';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
        <div className="flex-1">
          <h2 className="text-3xl font-bold text-white mb-2">{funnel.name}</h2>
          <p className="text-slate-400 mb-3">{funnel.description}</p>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="border-slate-600 text-slate-300">
              {segment.name}
            </Badge>
            <Badge className={getStatusColor(funnel.status)}>{funnel.status}</Badge>
          </div>
        </div>

        <div className="flex gap-2">
          <Select value={funnel.status} onValueChange={handleStatusChange}>
            <SelectTrigger className="bg-slate-800 border-slate-700 w-[140px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="idea">Idea</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="paused">Paused</SelectItem>
              <SelectItem value="retired">Retired</SelectItem>
            </SelectContent>
          </Select>

          <Button
            onClick={handleExport}
            variant="outline"
            className="border-purple-500/50 text-purple-300 hover:bg-purple-500/10"
          >
            <FileText className="h-4 w-4 mr-2" />
            Export Brief
          </Button>

          <Button onClick={handleDeleteFunnel} variant="destructive" size="icon">
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Stages */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white flex items-center gap-2">
              <Target className="h-5 w-5" />
              Funnel Stages
            </CardTitle>
            <Button
              onClick={handleAddStage}
              size="sm"
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Stage
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {stages.length === 0 ? (
            <div className="text-center py-8">
              <Target className="h-12 w-12 text-slate-600 mx-auto mb-3" />
              <p className="text-slate-500 mb-4">No stages defined yet</p>
              <Button onClick={handleAddStage} variant="outline" className="border-slate-700">
                Add Your First Stage
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {stages.map((stage, index) => (
                <div key={stage.id}>
                  <div className="bg-gradient-to-br from-slate-900/80 to-slate-800/80 rounded-lg p-5 border border-slate-700 hover:border-purple-500/50 transition-colors">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-purple-500/20 text-purple-300 font-bold text-sm">
                          {stage.stageOrder}
                        </div>
                        <div>
                          <h4 className="text-lg font-semibold text-white">{stage.stageName}</h4>
                          <p className="text-sm text-slate-400 mt-1">{stage.objective}</p>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleEditStage(stage.id)}
                          variant="ghost"
                          size="sm"
                          className="text-slate-400 hover:text-white"
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button
                          onClick={() => handleDeleteStage(stage.id)}
                          variant="ghost"
                          size="sm"
                          className="text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <Separator className="bg-slate-700 my-3" />

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <h5 className="text-xs font-semibold text-slate-400 mb-2 uppercase tracking-wide">
                          Key Messages
                        </h5>
                        <ul className="space-y-1">
                          {stage.keyMessages.slice(0, 3).map((msg: string, i: number) => (
                            <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                              <span className="text-purple-400 mt-1">•</span>
                              <span className="line-clamp-2">{msg}</span>
                            </li>
                          ))}
                          {stage.keyMessages.length > 3 && (
                            <li className="text-xs text-slate-500 italic">
                              +{stage.keyMessages.length - 3} more
                            </li>
                          )}
                        </ul>
                      </div>

                      <div>
                        <h5 className="text-xs font-semibold text-slate-400 mb-2 uppercase tracking-wide">
                          Recommended CTAs
                        </h5>
                        <div className="flex flex-wrap gap-2">
                          {stage.recommendedCTAs.map((cta: string, i: number) => (
                            <Badge key={i} variant="outline" className="border-purple-500/50 text-purple-300">
                              {cta}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>

                    {stage.recommendedAssets.length > 0 && (
                      <div className="mt-4">
                        <h5 className="text-xs font-semibold text-slate-400 mb-2 uppercase tracking-wide">
                          Recommended Assets
                        </h5>
                        <div className="flex flex-wrap gap-2">
                          {stage.recommendedAssets.map((asset: string, i: number) => (
                            <Badge key={i} variant="secondary" className="text-xs">
                              {asset}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {stage.notes && (
                      <div className="mt-4 text-xs text-slate-500 italic">
                        Note: {stage.notes}
                      </div>
                    )}
                  </div>

                  {index < stages.length - 1 && (
                    <div className="flex justify-center py-2">
                      <ArrowDown className="h-5 w-5 text-slate-600" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Export Dialog */}
      <Dialog open={isExportOpen} onOpenChange={setIsExportOpen}>
        <DialogContent className="bg-slate-900 border-slate-700 max-w-4xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="text-2xl text-white flex items-center gap-2">
              <FileText className="h-6 w-6 text-purple-400" />
              Funnel Brief Export
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="flex justify-end">
              <Button
                onClick={handleCopyBrief}
                variant="outline"
                className="border-slate-700"
              >
                {copied ? (
                  <>
                    <CheckCircle2 className="h-4 w-4 mr-2 text-green-400" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4 mr-2" />
                    Copy All
                  </>
                )}
              </Button>
            </div>

            <Textarea
              value={exportedBrief}
              readOnly
              className="bg-slate-800/50 border-slate-700 text-slate-300 font-mono text-xs min-h-[500px]"
            />

            <p className="text-xs text-slate-500">
              This brief can be copied and pasted into your planning docs, other tools, or shared with your team.
            </p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Stage Detail Dialog */}
      {selectedStageId && (
        <StageDetailDialog
          open={isStageDialogOpen}
          onOpenChange={setIsStageDialogOpen}
          stageId={selectedStageId}
          segmentId={funnel.segmentId}
        />
      )}
    </div>
  );
}
