'use client';

import { useState } from 'react';
import { useDreamNet } from '@/contexts/DreamNetContext';
import type { GeoTarget } from '@/types/dreamnet';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, Globe } from 'lucide-react';

interface GeoTargetManagerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  segmentId: string;
}

export default function GeoTargetManager({ open, onOpenChange, segmentId }: GeoTargetManagerProps) {
  const { getSegment, assignGeoTargetsToSegment } = useDreamNet();
  const segment = getSegment(segmentId);
  
  const [geoTargets, setGeoTargets] = useState<GeoTarget[]>(segment?.primaryGeoTargets || []);
  const [newGeo, setNewGeo] = useState<Partial<GeoTarget>>({
    region: '',
    country: '',
    cityOrMarket: '',
    language: '',
  });

  const handleAddGeo = (): void => {
    if (!newGeo.region || !newGeo.language) return;

    const id = `${newGeo.region.toLowerCase()}-${newGeo.language.toLowerCase()}${
      newGeo.cityOrMarket ? `-${newGeo.cityOrMarket.toLowerCase().replace(/\s+/g, '-')}` : ''
    }`;

    const target: GeoTarget = {
      id,
      region: newGeo.region,
      country: newGeo.country || undefined,
      cityOrMarket: newGeo.cityOrMarket || undefined,
      language: newGeo.language,
    };

    setGeoTargets([...geoTargets, target]);
    setNewGeo({ region: '', country: '', cityOrMarket: '', language: '' });
  };

  const handleRemoveGeo = (id: string): void => {
    setGeoTargets(geoTargets.filter((g: GeoTarget) => g.id !== id));
  };

  const handleSave = (): void => {
    assignGeoTargetsToSegment(segmentId, geoTargets);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-900 border-slate-700 max-w-3xl">
        <DialogHeader>
          <DialogTitle className="text-2xl text-white flex items-center gap-2">
            <Globe className="h-6 w-6 text-purple-400" />
            Manage Geographic Targets
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            Define regional targeting for {segment?.name}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Existing Targets */}
          {geoTargets.length > 0 && (
            <div className="space-y-2">
              <Label className="text-slate-300">Current Targets</Label>
              <div className="space-y-2 max-h-[200px] overflow-y-auto">
                {geoTargets.map((geo: GeoTarget) => (
                  <div
                    key={geo.id}
                    className="bg-slate-800/50 rounded-lg p-3 flex items-start justify-between"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline" className="text-xs">
                          {geo.id}
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          {geo.language}
                        </Badge>
                      </div>
                      <div className="text-sm text-slate-400">
                        <p>Region: {geo.region}</p>
                        {geo.country && <p>Country: {geo.country}</p>}
                        {geo.cityOrMarket && <p>City/Market: {geo.cityOrMarket}</p>}
                      </div>
                    </div>
                    <Button
                      onClick={() => handleRemoveGeo(geo.id)}
                      variant="ghost"
                      size="icon"
                      className="text-red-400 hover:text-red-300"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Add New Target */}
          <div className="space-y-4 border-t border-slate-700 pt-4">
            <Label className="text-slate-300">Add New Target</Label>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="region" className="text-slate-400 text-xs">
                  Region *
                </Label>
                <Input
                  id="region"
                  placeholder="e.g. US, LATAM, EU"
                  value={newGeo.region}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setNewGeo({ ...newGeo, region: e.target.value })
                  }
                  className="bg-slate-800/50 border-slate-700"
                />
              </div>

              <div>
                <Label htmlFor="language" className="text-slate-400 text-xs">
                  Language *
                </Label>
                <Input
                  id="language"
                  placeholder="e.g. en, es, pt-BR"
                  value={newGeo.language}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setNewGeo({ ...newGeo, language: e.target.value })
                  }
                  className="bg-slate-800/50 border-slate-700"
                />
              </div>

              <div>
                <Label htmlFor="country" className="text-slate-400 text-xs">
                  Country (optional)
                </Label>
                <Input
                  id="country"
                  placeholder="e.g. USA, Brazil, Germany"
                  value={newGeo.country}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setNewGeo({ ...newGeo, country: e.target.value })
                  }
                  className="bg-slate-800/50 border-slate-700"
                />
              </div>

              <div>
                <Label htmlFor="city" className="text-slate-400 text-xs">
                  City/Market (optional)
                </Label>
                <Input
                  id="city"
                  placeholder="e.g. Miami, Berlin"
                  value={newGeo.cityOrMarket}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setNewGeo({ ...newGeo, cityOrMarket: e.target.value })
                  }
                  className="bg-slate-800/50 border-slate-700"
                />
              </div>
            </div>

            <Button
              onClick={handleAddGeo}
              disabled={!newGeo.region || !newGeo.language}
              variant="outline"
              className="w-full border-slate-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Target
            </Button>
          </div>

          <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3 text-xs text-slate-400">
            <p className="mb-1">
              <strong className="text-blue-300">Tip:</strong> After saving, use "Generate Localized Variants" to create region-specific messaging.
            </p>
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <Button
            variant="ghost"
            onClick={() => onOpenChange(false)}
            className="text-slate-400"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
          >
            Save Targets
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
