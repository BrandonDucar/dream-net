'use client';

import { useState } from 'react';
import { useDreamNet } from '@/contexts/DreamNetContext';
import type { SegmentFilter, PriorityLevel } from '@/types/dreamnet';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Users, Sparkles, TrendingUp } from 'lucide-react';
import CreateSegmentDialog from './CreateSegmentDialog';

interface SegmentDashboardProps {
  onViewSegment: (segmentId: string) => void;
}

export default function SegmentDashboard({ onViewSegment }: SegmentDashboardProps) {
  const { listSegments, listFunnelsForSegment } = useDreamNet();
  const [isCreateOpen, setIsCreateOpen] = useState<boolean>(false);
  const [filter, setFilter] = useState<SegmentFilter>({});
  const [tagSearch, setTagSearch] = useState<string>('');

  const segments = listSegments(filter);

  const handlePriorityFilter = (value: string): void => {
    if (value === 'all') {
      setFilter((prev: SegmentFilter) => ({ ...prev, priorityLevel: undefined }));
    } else {
      setFilter((prev: SegmentFilter) => ({ ...prev, priorityLevel: value as PriorityLevel }));
    }
  };

  const handleTagSearch = (): void => {
    setFilter((prev: SegmentFilter) => ({ ...prev, tag: tagSearch || undefined }));
  };

  const getPriorityColor = (priority: PriorityLevel): string => {
    switch (priority) {
      case 'critical':
        return 'bg-red-500/20 text-red-300 border-red-500/50';
      case 'high':
        return 'bg-orange-500/20 text-orange-300 border-orange-500/50';
      case 'medium':
        return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/50';
      case 'low':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/50';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header and Filters */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-white flex items-center gap-2">
            <Users className="h-8 w-8 text-purple-400" />
            Audience Segments
          </h2>
          <p className="text-slate-400 mt-1">
            {segments.length} segment{segments.length !== 1 ? 's' : ''} mapped
          </p>
        </div>

        <Button
          onClick={() => setIsCreateOpen(true)}
          className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
        >
          <Plus className="h-4 w-4 mr-2" />
          Create Segment
        </Button>
      </div>

      {/* Filters */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm text-slate-300 mb-2 block">Priority Level</label>
              <Select onValueChange={handlePriorityFilter} defaultValue="all">
                <SelectTrigger className="bg-slate-900/50 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Priorities</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm text-slate-300 mb-2 block">Search by Tag</label>
              <div className="flex gap-2">
                <Input
                  placeholder="e.g. crypto, builders..."
                  value={tagSearch}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTagSearch(e.target.value)}
                  onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                    if (e.key === 'Enter') handleTagSearch();
                  }}
                  className="bg-slate-900/50 border-slate-700"
                />
                <Button onClick={handleTagSearch} variant="secondary">
                  Filter
                </Button>
              </div>
            </div>

            <div>
              <label className="text-sm text-slate-300 mb-2 block">Quick Actions</label>
              <Button
                onClick={() => setFilter({})}
                variant="outline"
                className="w-full border-slate-700"
              >
                Clear Filters
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Segments Grid */}
      {segments.length === 0 ? (
        <Card className="bg-slate-800/30 border-slate-700 border-dashed">
          <CardContent className="pt-12 pb-12 text-center">
            <Sparkles className="h-16 w-16 text-slate-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-300 mb-2">
              No segments found
            </h3>
            <p className="text-slate-500 mb-6">
              {filter.priorityLevel || filter.tag || filter.chainAffinity
                ? 'Try adjusting your filters'
                : 'Create your first audience segment to get started'}
            </p>
            {!filter.priorityLevel && !filter.tag && !filter.chainAffinity && (
              <Button
                onClick={() => setIsCreateOpen(true)}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Your First Segment
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {segments.map((segment) => {
            const funnelsCount = listFunnelsForSegment(segment.id).length;
            
            return (
              <Card
                key={segment.id}
                className="bg-gradient-to-br from-slate-800/80 to-slate-900/80 border-slate-700 hover:border-purple-500/50 transition-all cursor-pointer group"
                onClick={() => onViewSegment(segment.id)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <CardTitle className="text-white group-hover:text-purple-400 transition-colors">
                      {segment.name}
                    </CardTitle>
                    <Badge className={getPriorityColor(segment.priorityLevel)}>
                      {segment.priorityLevel}
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-400 italic">
                    {segment.archetype}
                  </p>
                </CardHeader>

                <CardContent className="space-y-4">
                  <p className="text-slate-300 text-sm line-clamp-2">
                    {segment.description}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2">
                    {segment.tags.slice(0, 4).map((tag: string) => (
                      <Badge
                        key={tag}
                        variant="outline"
                        className="text-xs border-slate-600 text-slate-300"
                      >
                        {tag}
                      </Badge>
                    ))}
                    {segment.tags.length > 4 && (
                      <Badge variant="outline" className="text-xs border-slate-600 text-slate-400">
                        +{segment.tags.length - 4}
                      </Badge>
                    )}
                  </div>

                  {/* Chain Affinity */}
                  {segment.chainAffinity.length > 0 && (
                    <div className="flex items-center gap-2 text-sm text-slate-400">
                      <TrendingUp className="h-4 w-4" />
                      <span>{segment.chainAffinity.join(', ')}</span>
                    </div>
                  )}

                  {/* Funnel Count */}
                  <div className="pt-3 border-t border-slate-700">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-400">
                        {funnelsCount} funnel{funnelsCount !== 1 ? 's' : ''}
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-purple-400 hover:text-purple-300"
                        onClick={(e: React.MouseEvent) => {
                          e.stopPropagation();
                          onViewSegment(segment.id);
                        }}
                      >
                        View Details →
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <CreateSegmentDialog open={isCreateOpen} onOpenChange={setIsCreateOpen} />
    </div>
  );
}
