'use client';

import { useState } from 'react';
import { useDreamNet } from '@/contexts/DreamNetContext';
import type { PriorityLevel, GeoTarget } from '@/types/dreamnet';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { Edit2, Globe, Sparkles, TrendingUp, Users, Target, Trash2, Plus, MapPin } from 'lucide-react';
import GeoTargetManager from './GeoTargetManager';
import CreateFunnelDialog from './CreateFunnelDialog';

interface SegmentDetailProps {
  segmentId: string;
  onViewFunnel: (funnelId: string) => void;
}

export default function SegmentDetail({ segmentId, onViewFunnel }: SegmentDetailProps) {
  const {
    getSegment,
    updateAudienceSegment,
    deleteAudienceSegment,
    regenerateSEO,
    generateGeoVariantsForSegment,
    listFunnelsForSegment,
    generateBaseFunnelForSegment,
  } = useDreamNet();

  const segment = getSegment(segmentId);
  const funnels = listFunnelsForSegment(segmentId);

  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [isGeoOpen, setIsGeoOpen] = useState<boolean>(false);
  const [isCreateFunnelOpen, setIsCreateFunnelOpen] = useState<boolean>(false);
  const [showGeoVariants, setShowGeoVariants] = useState<boolean>(false);
  
  const [editForm, setEditForm] = useState({
    name: segment?.name || '',
    archetype: segment?.archetype || '',
    description: segment?.description || '',
    priorityLevel: segment?.priorityLevel || 'medium',
    coreMotivations: segment?.coreMotivations?.join('\n') || '',
    painPoints: segment?.painPoints?.join('\n') || '',
    chainAffinity: segment?.chainAffinity?.join(', ') || '',
    preferredChannels: segment?.preferredChannels?.join(', ') || '',
    tags: segment?.tags?.join(', ') || '',
    seoTitle: segment?.seoTitle || '',
    seoDescription: segment?.seoDescription || '',
    seoKeywords: segment?.seoKeywords?.join(', ') || '',
    seoHashtags: segment?.seoHashtags?.join(' ') || '',
    altText: segment?.altText || '',
  });

  if (!segment) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-400">Segment not found</p>
      </div>
    );
  }

  const handleSave = (): void => {
    updateAudienceSegment(segmentId, {
      name: editForm.name,
      archetype: editForm.archetype,
      description: editForm.description,
      priorityLevel: editForm.priorityLevel as PriorityLevel,
      coreMotivations: editForm.coreMotivations.split('\n').filter((x: string) => x.trim()),
      painPoints: editForm.painPoints.split('\n').filter((x: string) => x.trim()),
      chainAffinity: editForm.chainAffinity.split(',').map((x: string) => x.trim()).filter((x: string) => x),
      preferredChannels: editForm.preferredChannels.split(',').map((x: string) => x.trim()).filter((x: string) => x),
      tags: editForm.tags.split(',').map((x: string) => x.trim()).filter((x: string) => x),
      seoTitle: editForm.seoTitle,
      seoDescription: editForm.seoDescription,
      seoKeywords: editForm.seoKeywords.split(',').map((x: string) => x.trim()).filter((x: string) => x),
      seoHashtags: editForm.seoHashtags.split(/[\s,]+/).filter((x: string) => x),
      altText: editForm.altText,
    });
    setIsEditing(false);
  };

  const handleRegenerateSEO = (): void => {
    regenerateSEO(segmentId);
    const updatedSegment = getSegment(segmentId);
    if (updatedSegment) {
      setEditForm({
        ...editForm,
        seoTitle: updatedSegment.seoTitle,
        seoDescription: updatedSegment.seoDescription,
        seoKeywords: updatedSegment.seoKeywords.join(', '),
        seoHashtags: updatedSegment.seoHashtags.join(' '),
        altText: updatedSegment.altText,
      });
    }
  };

  const handleGenerateGeoVariants = (): void => {
    generateGeoVariantsForSegment(segmentId);
    setShowGeoVariants(true);
  };

  const handleGenerateBaseFunnel = (): void => {
    const result = generateBaseFunnelForSegment(segmentId);
    onViewFunnel(result.funnel.id);
  };

  const handleDelete = (): void => {
    if (confirm(`Delete "${segment.name}"? This will also delete all associated funnels.`)) {
      deleteAudienceSegment(segmentId);
    }
  };

  const getPriorityColor = (priority: PriorityLevel): string => {
    switch (priority) {
      case 'critical': return 'bg-red-500/20 text-red-300 border-red-500/50';
      case 'high': return 'bg-orange-500/20 text-orange-300 border-orange-500/50';
      case 'medium': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/50';
      case 'low': return 'bg-blue-500/20 text-blue-300 border-blue-500/50';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h2 className="text-3xl font-bold text-white">{segment.name}</h2>
            <Badge className={getPriorityColor(segment.priorityLevel)}>
              {segment.priorityLevel}
            </Badge>
          </div>
          <p className="text-slate-400 italic">{segment.archetype}</p>
        </div>

        <div className="flex gap-2">
          <Button
            onClick={() => setIsEditing(!isEditing)}
            variant="outline"
            className="border-slate-700"
          >
            <Edit2 className="h-4 w-4 mr-2" />
            {isEditing ? 'Cancel' : 'Edit'}
          </Button>
          <Button
            onClick={handleDelete}
            variant="destructive"
            size="icon"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Tabs defaultValue="identity" className="w-full">
        <TabsList className="bg-slate-800 border border-slate-700">
          <TabsTrigger value="identity">
            <Users className="h-4 w-4 mr-2" />
            Identity
          </TabsTrigger>
          <TabsTrigger value="seo">
            <Sparkles className="h-4 w-4 mr-2" />
            SEO & Geo
          </TabsTrigger>
          <TabsTrigger value="funnels">
            <Target className="h-4 w-4 mr-2" />
            Funnels
          </TabsTrigger>
        </TabsList>

        {/* Identity Tab */}
        <TabsContent value="identity" className="space-y-6">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Segment Identity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {isEditing ? (
                <>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-slate-300">Name</Label>
                      <Input
                        value={editForm.name}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, name: e.target.value })}
                        className="bg-slate-900/50 border-slate-700"
                      />
                    </div>
                    <div>
                      <Label className="text-slate-300">Archetype</Label>
                      <Input
                        value={editForm.archetype}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, archetype: e.target.value })}
                        className="bg-slate-900/50 border-slate-700"
                      />
                    </div>
                  </div>

                  <div>
                    <Label className="text-slate-300">Description</Label>
                    <Textarea
                      value={editForm.description}
                      onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setEditForm({ ...editForm, description: e.target.value })}
                      className="bg-slate-900/50 border-slate-700"
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label className="text-slate-300">Priority Level</Label>
                    <Select
                      value={editForm.priorityLevel}
                      onValueChange={(value: string) => setEditForm({ ...editForm, priorityLevel: value })}
                    >
                      <SelectTrigger className="bg-slate-900/50 border-slate-700">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-slate-300">Core Motivations (one per line)</Label>
                    <Textarea
                      value={editForm.coreMotivations}
                      onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setEditForm({ ...editForm, coreMotivations: e.target.value })}
                      className="bg-slate-900/50 border-slate-700"
                      rows={4}
                    />
                  </div>

                  <div>
                    <Label className="text-slate-300">Pain Points (one per line)</Label>
                    <Textarea
                      value={editForm.painPoints}
                      onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setEditForm({ ...editForm, painPoints: e.target.value })}
                      className="bg-slate-900/50 border-slate-700"
                      rows={4}
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-slate-300">Chain Affinity (comma-separated)</Label>
                      <Input
                        value={editForm.chainAffinity}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, chainAffinity: e.target.value })}
                        className="bg-slate-900/50 border-slate-700"
                        placeholder="Base, Solana, Ethereum"
                      />
                    </div>
                    <div>
                      <Label className="text-slate-300">Tags (comma-separated)</Label>
                      <Input
                        value={editForm.tags}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, tags: e.target.value })}
                        className="bg-slate-900/50 border-slate-700"
                        placeholder="crypto, builders, culture"
                      />
                    </div>
                  </div>

                  <div>
                    <Label className="text-slate-300">Preferred Channels (comma-separated)</Label>
                    <Input
                      value={editForm.preferredChannels}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, preferredChannels: e.target.value })}
                      className="bg-slate-900/50 border-slate-700"
                      placeholder="X, Farcaster, Discord"
                    />
                  </div>

                  <Button onClick={handleSave} className="bg-green-600 hover:bg-green-700">
                    Save Changes
                  </Button>
                </>
              ) : (
                <>
                  <div>
                    <h4 className="text-sm font-semibold text-slate-300 mb-2">Description</h4>
                    <p className="text-slate-400">{segment.description}</p>
                  </div>

                  <Separator className="bg-slate-700" />

                  <div>
                    <h4 className="text-sm font-semibold text-slate-300 mb-2">Core Motivations</h4>
                    <ul className="space-y-1">
                      {segment.coreMotivations.map((m: string, i: number) => (
                        <li key={i} className="text-slate-400 flex items-start gap-2">
                          <span className="text-purple-400 mt-1">•</span>
                          <span>{m}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold text-slate-300 mb-2">Pain Points</h4>
                    <ul className="space-y-1">
                      {segment.painPoints.map((p: string, i: number) => (
                        <li key={i} className="text-slate-400 flex items-start gap-2">
                          <span className="text-red-400 mt-1">•</span>
                          <span>{p}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Separator className="bg-slate-700" />

                  <div className="grid md:grid-cols-2 gap-4">
                    {segment.chainAffinity.length > 0 && (
                      <div>
                        <h4 className="text-sm font-semibold text-slate-300 mb-2 flex items-center gap-2">
                          <TrendingUp className="h-4 w-4" />
                          Chain Affinity
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {segment.chainAffinity.map((c: string) => (
                            <Badge key={c} variant="outline" className="border-blue-500/50 text-blue-300">
                              {c}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    <div>
                      <h4 className="text-sm font-semibold text-slate-300 mb-2">Tags</h4>
                      <div className="flex flex-wrap gap-2">
                        {segment.tags.map((t: string) => (
                          <Badge key={t} variant="secondary">
                            {t}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold text-slate-300 mb-2">Preferred Channels</h4>
                    <p className="text-slate-400">{segment.preferredChannels.join(', ')}</p>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* SEO & Geo Tab */}
        <TabsContent value="seo" className="space-y-6">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white">SEO Metadata</CardTitle>
                <Button
                  onClick={handleRegenerateSEO}
                  variant="outline"
                  size="sm"
                  className="border-slate-700"
                >
                  <Sparkles className="h-4 w-4 mr-2" />
                  Regenerate
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {isEditing ? (
                <>
                  <div>
                    <Label className="text-slate-300">SEO Title</Label>
                    <Input
                      value={editForm.seoTitle}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, seoTitle: e.target.value })}
                      className="bg-slate-900/50 border-slate-700"
                    />
                  </div>
                  <div>
                    <Label className="text-slate-300">SEO Description</Label>
                    <Textarea
                      value={editForm.seoDescription}
                      onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setEditForm({ ...editForm, seoDescription: e.target.value })}
                      className="bg-slate-900/50 border-slate-700"
                      rows={2}
                    />
                  </div>
                  <div>
                    <Label className="text-slate-300">Keywords (comma-separated)</Label>
                    <Input
                      value={editForm.seoKeywords}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, seoKeywords: e.target.value })}
                      className="bg-slate-900/50 border-slate-700"
                    />
                  </div>
                  <div>
                    <Label className="text-slate-300">Hashtags (space-separated)</Label>
                    <Input
                      value={editForm.seoHashtags}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, seoHashtags: e.target.value })}
                      className="bg-slate-900/50 border-slate-700"
                    />
                  </div>
                  <div>
                    <Label className="text-slate-300">Alt Text</Label>
                    <Input
                      value={editForm.altText}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditForm({ ...editForm, altText: e.target.value })}
                      className="bg-slate-900/50 border-slate-700"
                    />
                  </div>
                  <Button onClick={handleSave} className="bg-green-600 hover:bg-green-700">
                    Save Changes
                  </Button>
                </>
              ) : (
                <div className="space-y-3 text-sm">
                  <div>
                    <span className="text-slate-500 font-medium">Title:</span>
                    <p className="text-slate-300 mt-1">{segment.seoTitle}</p>
                  </div>
                  <div>
                    <span className="text-slate-500 font-medium">Description:</span>
                    <p className="text-slate-300 mt-1">{segment.seoDescription}</p>
                  </div>
                  <div>
                    <span className="text-slate-500 font-medium">Keywords:</span>
                    <p className="text-slate-300 mt-1">{segment.seoKeywords.join(', ')}</p>
                  </div>
                  <div>
                    <span className="text-slate-500 font-medium">Hashtags:</span>
                    <p className="text-slate-300 mt-1">{segment.seoHashtags.join(' ')}</p>
                  </div>
                  <div>
                    <span className="text-slate-500 font-medium">Alt Text:</span>
                    <p className="text-slate-300 mt-1">{segment.altText}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white flex items-center gap-2">
                  <Globe className="h-5 w-5" />
                  Geographic Targeting
                </CardTitle>
                <Button
                  onClick={() => setIsGeoOpen(true)}
                  variant="outline"
                  size="sm"
                  className="border-slate-700"
                >
                  <MapPin className="h-4 w-4 mr-2" />
                  Manage Targets
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {segment.primaryGeoTargets.length === 0 ? (
                <p className="text-slate-500 text-sm">No geographic targets set</p>
              ) : (
                <>
                  <div className="space-y-2">
                    {segment.primaryGeoTargets.map((geo: GeoTarget) => (
                      <div key={geo.id} className="bg-slate-900/50 rounded-lg p-3 text-sm">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-semibold text-slate-300">{geo.id}</span>
                          <Badge variant="outline" className="text-xs">
                            {geo.language}
                          </Badge>
                        </div>
                        <div className="text-slate-400 space-y-1">
                          <p>Region: {geo.region}</p>
                          {geo.country && <p>Country: {geo.country}</p>}
                          {geo.cityOrMarket && <p>City/Market: {geo.cityOrMarket}</p>}
                        </div>
                      </div>
                    ))}
                  </div>

                  <Button
                    onClick={handleGenerateGeoVariants}
                    variant="secondary"
                    className="w-full"
                  >
                    <Sparkles className="h-4 w-4 mr-2" />
                    Generate Localized Variants
                  </Button>

                  {showGeoVariants && Object.keys(segment.segmentIntroLocalized).length > 0 && (
                    <div className="mt-4 space-y-3">
                      <h4 className="text-sm font-semibold text-slate-300">Localized Variants</h4>
                      {Object.entries(segment.segmentIntroLocalized).map(([geoKey, intro]: [string, string]) => (
                        <div key={geoKey} className="bg-slate-900/50 rounded-lg p-3 text-sm">
                          <div className="font-semibold text-purple-400 mb-1">{geoKey}</div>
                          <p className="text-slate-400 mb-2">{intro}</p>
                          {segment.tagsLocalized[geoKey] && (
                            <div className="flex flex-wrap gap-1">
                              {segment.tagsLocalized[geoKey].map((tag: string) => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Funnels Tab */}
        <TabsContent value="funnels" className="space-y-6">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white">Funnels for this Segment</CardTitle>
                <div className="flex gap-2">
                  <Button
                    onClick={handleGenerateBaseFunnel}
                    variant="outline"
                    size="sm"
                    className="border-purple-500/50 text-purple-300 hover:bg-purple-500/10"
                  >
                    <Sparkles className="h-4 w-4 mr-2" />
                    Generate Base Funnel
                  </Button>
                  <Button
                    onClick={() => setIsCreateFunnelOpen(true)}
                    size="sm"
                    className="bg-gradient-to-r from-purple-500 to-pink-500"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Create Custom
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {funnels.length === 0 ? (
                <div className="text-center py-8">
                  <Target className="h-12 w-12 text-slate-600 mx-auto mb-3" />
                  <p className="text-slate-500 mb-4">No funnels created yet</p>
                  <Button
                    onClick={handleGenerateBaseFunnel}
                    variant="outline"
                    className="border-slate-700"
                  >
                    Generate Your First Funnel
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  {funnels.map((funnel) => (
                    <div
                      key={funnel.id}
                      className="bg-slate-900/50 rounded-lg p-4 hover:bg-slate-900/70 transition-colors cursor-pointer border border-slate-700 hover:border-purple-500/50"
                      onClick={() => onViewFunnel(funnel.id)}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-semibold text-white">{funnel.name}</h4>
                        <Badge
                          variant="outline"
                          className={
                            funnel.status === 'active'
                              ? 'border-green-500/50 text-green-300'
                              : 'border-slate-600 text-slate-400'
                          }
                        >
                          {funnel.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-400 mb-3">{funnel.description}</p>
                      <div className="flex items-center justify-between text-xs text-slate-500">
                        <span>{funnel.stageIds.length} stages</span>
                        <span className="text-purple-400 hover:text-purple-300">
                          View Details →
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <GeoTargetManager
        open={isGeoOpen}
        onOpenChange={setIsGeoOpen}
        segmentId={segmentId}
      />

      <CreateFunnelDialog
        open={isCreateFunnelOpen}
        onOpenChange={setIsCreateFunnelOpen}
        segmentId={segmentId}
        onCreated={onViewFunnel}
      />
    </div>
  );
}
