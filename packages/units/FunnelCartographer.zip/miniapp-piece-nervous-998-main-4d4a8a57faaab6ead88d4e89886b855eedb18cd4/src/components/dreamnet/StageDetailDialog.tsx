'use client';

import { useState, useEffect } from 'react';
import { useDreamNet } from '@/contexts/DreamNetContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Sparkles, Plus, X, Globe } from 'lucide-react';

interface StageDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  stageId: string;
  segmentId: string;
}

export default function StageDetailDialog({ open, onOpenChange, stageId, segmentId }: StageDetailDialogProps) {
  const {
    getStage,
    getSegment,
    addOrUpdateFunnelStage,
    regenerateStageMessages,
    generateStageGeoVariantsForStage,
    geoVariants,
  } = useDreamNet();

  const stage = getStage(stageId);
  const segment = getSegment(segmentId);

  const [stageName, setStageName] = useState<string>('');
  const [stageOrder, setStageOrder] = useState<number>(1);
  const [objective, setObjective] = useState<string>('');
  const [keyMessages, setKeyMessages] = useState<string[]>([]);
  const [recommendedCTAs, setRecommendedCTAs] = useState<string[]>([]);
  const [recommendedAssets, setRecommendedAssets] = useState<string[]>([]);
  const [notes, setNotes] = useState<string>('');
  const [regenerateInstructions, setRegenerateInstructions] = useState<string>('');
  const [showGeoVariants, setShowGeoVariants] = useState<boolean>(false);

  const stageGeoVariants = geoVariants.filter((gv) => gv.stageId === stageId);

  useEffect(() => {
    if (stage) {
      setStageName(stage.stageName);
      setStageOrder(stage.stageOrder);
      setObjective(stage.objective);
      setKeyMessages([...stage.keyMessages]);
      setRecommendedCTAs([...stage.recommendedCTAs]);
      setRecommendedAssets([...stage.recommendedAssets]);
      setNotes(stage.notes);
    }
  }, [stage]);

  if (!stage || !segment) return null;

  const handleSave = (): void => {
    addOrUpdateFunnelStage({
      id: stageId,
      segmentId,
      stageName,
      stageOrder,
      objective,
      keyMessages: keyMessages.filter((m: string) => m.trim()),
      recommendedCTAs: recommendedCTAs.filter((c: string) => c.trim()),
      recommendedAssets: recommendedAssets.filter((a: string) => a.trim()),
      notes,
    });
    onOpenChange(false);
  };

  const handleRegenerateMessages = (): void => {
    if (!regenerateInstructions.trim()) return;
    regenerateStageMessages(stageId, regenerateInstructions);
    setRegenerateInstructions('');
    
    const updatedStage = getStage(stageId);
    if (updatedStage) {
      setKeyMessages([...updatedStage.keyMessages]);
      setRecommendedCTAs([...updatedStage.recommendedCTAs]);
      setNotes(updatedStage.notes);
    }
  };

  const handleGenerateGeoVariants = (): void => {
    generateStageGeoVariantsForStage(stageId);
    setShowGeoVariants(true);
  };

  const addMessage = (): void => {
    setKeyMessages([...keyMessages, '']);
  };

  const updateMessage = (index: number, value: string): void => {
    const updated = [...keyMessages];
    updated[index] = value;
    setKeyMessages(updated);
  };

  const removeMessage = (index: number): void => {
    setKeyMessages(keyMessages.filter((_, i: number) => i !== index));
  };

  const addCTA = (): void => {
    setRecommendedCTAs([...recommendedCTAs, '']);
  };

  const updateCTA = (index: number, value: string): void => {
    const updated = [...recommendedCTAs];
    updated[index] = value;
    setRecommendedCTAs(updated);
  };

  const removeCTA = (index: number): void => {
    setRecommendedCTAs(recommendedCTAs.filter((_, i: number) => i !== index));
  };

  const addAsset = (): void => {
    setRecommendedAssets([...recommendedAssets, '']);
  };

  const updateAsset = (index: number, value: string): void => {
    const updated = [...recommendedAssets];
    updated[index] = value;
    setRecommendedAssets(updated);
  };

  const removeAsset = (index: number): void => {
    setRecommendedAssets(recommendedAssets.filter((_, i: number) => i !== index));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-900 border-slate-700 max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl text-white">
            Edit Stage: {stage.stageName}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Basic Info */}
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label className="text-slate-300">Stage Name</Label>
              <Input
                value={stageName}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setStageName(e.target.value)}
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>
            <div>
              <Label className="text-slate-300">Stage Order</Label>
              <Input
                type="number"
                value={stageOrder}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setStageOrder(parseInt(e.target.value) || 1)}
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>
          </div>

          <div>
            <Label className="text-slate-300">Objective</Label>
            <Textarea
              value={objective}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setObjective(e.target.value)}
              className="bg-slate-800/50 border-slate-700 text-white"
              rows={2}
            />
          </div>

          <Separator className="bg-slate-700" />

          {/* Key Messages */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <Label className="text-slate-300">Key Messages</Label>
              <Button onClick={addMessage} variant="outline" size="sm" className="border-slate-700">
                <Plus className="h-4 w-4 mr-1" />
                Add
              </Button>
            </div>
            <div className="space-y-2">
              {keyMessages.map((msg: string, index: number) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={msg}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateMessage(index, e.target.value)}
                    className="bg-slate-800/50 border-slate-700 text-white"
                    placeholder="Enter key message..."
                  />
                  <Button
                    onClick={() => removeMessage(index)}
                    variant="ghost"
                    size="icon"
                    className="text-red-400 hover:text-red-300"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>

          {/* CTAs */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <Label className="text-slate-300">Recommended CTAs</Label>
              <Button onClick={addCTA} variant="outline" size="sm" className="border-slate-700">
                <Plus className="h-4 w-4 mr-1" />
                Add
              </Button>
            </div>
            <div className="space-y-2">
              {recommendedCTAs.map((cta: string, index: number) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={cta}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateCTA(index, e.target.value)}
                    className="bg-slate-800/50 border-slate-700 text-white"
                    placeholder="Enter CTA..."
                  />
                  <Button
                    onClick={() => removeCTA(index)}
                    variant="ghost"
                    size="icon"
                    className="text-red-400 hover:text-red-300"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>

          {/* Assets */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <Label className="text-slate-300">Recommended Assets</Label>
              <Button onClick={addAsset} variant="outline" size="sm" className="border-slate-700">
                <Plus className="h-4 w-4 mr-1" />
                Add
              </Button>
            </div>
            <div className="space-y-2">
              {recommendedAssets.map((asset: string, index: number) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={asset}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateAsset(index, e.target.value)}
                    className="bg-slate-800/50 border-slate-700 text-white"
                    placeholder="Enter asset name..."
                  />
                  <Button
                    onClick={() => removeAsset(index)}
                    variant="ghost"
                    size="icon"
                    className="text-red-400 hover:text-red-300"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div>
            <Label className="text-slate-300">Notes</Label>
            <Textarea
              value={notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNotes(e.target.value)}
              className="bg-slate-800/50 border-slate-700 text-white"
              rows={2}
              placeholder="Additional notes..."
            />
          </div>

          <Separator className="bg-slate-700" />

          {/* Regenerate Messaging */}
          <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
            <h4 className="text-sm font-semibold text-purple-300 mb-2 flex items-center gap-2">
              <Sparkles className="h-4 w-4" />
              Regenerate Messaging
            </h4>
            <p className="text-xs text-slate-400 mb-3">
              Provide instructions to adjust the tone or focus of this stage's messaging
            </p>
            <div className="space-y-2">
              <Textarea
                value={regenerateInstructions}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setRegenerateInstructions(e.target.value)}
                className="bg-slate-800/50 border-slate-700 text-white text-sm"
                rows={2}
                placeholder="e.g. make it more aggressive for whales, tone it down for normies..."
              />
              <Button
                onClick={handleRegenerateMessages}
                disabled={!regenerateInstructions.trim()}
                variant="secondary"
                size="sm"
                className="w-full"
              >
                <Sparkles className="h-4 w-4 mr-2" />
                Regenerate
              </Button>
            </div>
          </div>

          {/* Geo Variants */}
          {segment.primaryGeoTargets.length > 0 && (
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
              <h4 className="text-sm font-semibold text-blue-300 mb-2 flex items-center gap-2">
                <Globe className="h-4 w-4" />
                Geographic Variants
              </h4>
              <p className="text-xs text-slate-400 mb-3">
                Generate localized messaging for this stage based on {segment.name}'s geo targets
              </p>
              <Button
                onClick={handleGenerateGeoVariants}
                variant="secondary"
                size="sm"
                className="w-full mb-3"
              >
                Generate Geo Variants
              </Button>

              {showGeoVariants && stageGeoVariants.length > 0 && (
                <div className="space-y-2 mt-3">
                  {stageGeoVariants.map((gv) => (
                    <div key={gv.id} className="bg-slate-900/50 rounded-lg p-3 text-xs">
                      <Badge variant="outline" className="mb-2">
                        {gv.geoKey}
                      </Badge>
                      <div className="space-y-2">
                        <div>
                          <span className="text-slate-500 font-medium">Messages:</span>
                          <ul className="mt-1 space-y-1">
                            {gv.localizedMessages.slice(0, 2).map((msg: string, i: number) => (
                              <li key={i} className="text-slate-400">• {msg}</li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <span className="text-slate-500 font-medium">CTAs:</span>
                          <p className="text-slate-400 mt-1">{gv.localizedCTAs.join(', ')}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex justify-end gap-3">
          <Button
            variant="ghost"
            onClick={() => onOpenChange(false)}
            className="text-slate-400"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
          >
            Save Changes
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
