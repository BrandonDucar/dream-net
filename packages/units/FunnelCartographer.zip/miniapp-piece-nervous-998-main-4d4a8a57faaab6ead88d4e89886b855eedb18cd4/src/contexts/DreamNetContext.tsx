'use client';

import React, { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type {
  AudienceSegment,
  FunnelMap,
  FunnelStage,
  GeoTarget,
  StageGeoVariant,
  CreateSegmentInput,
  UpdateSegmentInput,
  SegmentFilter,
  PriorityLevel,
  FunnelStatus,
} from '@/types/dreamnet';
import {
  generateSegmentDetails,
  generateSEOMetadata,
  generateBaseFunnelStages,
  regenerateStageMessaging,
  generateGeoVariants,
  generateStageGeoVariants,
  exportFunnelBrief,
} from '@/lib/dreamnet-generator';

interface DreamNetContextType {
  segments: AudienceSegment[];
  funnels: FunnelMap[];
  stages: FunnelStage[];
  geoVariants: StageGeoVariant[];
  createAudienceSegment: (input: CreateSegmentInput) => AudienceSegment;
  updateAudienceSegment: (id: string, input: UpdateSegmentInput) => void;
  deleteAudienceSegment: (id: string) => void;
  generateBaseFunnelForSegment: (segmentId: string) => { funnel: FunnelMap; stages: FunnelStage[] };
  createCustomFunnel: (segmentId: string, name: string, description: string) => FunnelMap;
  updateFunnel: (id: string, updates: Partial<FunnelMap>) => void;
  deleteFunnel: (id: string) => void;
  addOrUpdateFunnelStage: (stage: Partial<FunnelStage> & { id?: string; segmentId: string }) => FunnelStage;
  deleteStage: (id: string) => void;
  regenerateStageMessages: (stageId: string, instructions: string) => void;
  assignGeoTargetsToSegment: (segmentId: string, geoTargets: GeoTarget[]) => void;
  generateGeoVariantsForSegment: (segmentId: string) => void;
  generateStageGeoVariantsForStage: (stageId: string) => void;
  regenerateSEO: (segmentId: string) => void;
  listSegments: (filter?: SegmentFilter) => AudienceSegment[];
  listFunnelsForSegment: (segmentId: string) => FunnelMap[];
  getFunnelDetails: (funnelId: string) => { funnel: FunnelMap; stages: FunnelStage[] } | null;
  exportBrief: (funnelId: string) => string;
  getSegment: (id: string) => AudienceSegment | undefined;
  getStage: (id: string) => FunnelStage | undefined;
}

const DreamNetContext = createContext<DreamNetContextType | undefined>(undefined);

export function DreamNetProvider({ children }: { children: ReactNode }) {
  const [segments, setSegments] = useState<AudienceSegment[]>([]);
  const [funnels, setFunnels] = useState<FunnelMap[]>([]);
  const [stages, setStages] = useState<FunnelStage[]>([]);
  const [geoVariants, setGeoVariants] = useState<StageGeoVariant[]>([]);

  const createAudienceSegment = useCallback((input: CreateSegmentInput): AudienceSegment => {
    const generatedDetails = generateSegmentDetails(input);
    
    const newSegment: AudienceSegment = {
      id: `segment-${Date.now()}`,
      name: input.name,
      archetype: input.archetype,
      description: generatedDetails.description || '',
      chainAffinity: generatedDetails.chainAffinity || [],
      priorityLevel: 'medium',
      coreMotivations: generatedDetails.coreMotivations || [],
      painPoints: generatedDetails.painPoints || [],
      preferredChannels: generatedDetails.preferredChannels || [],
      tags: generatedDetails.tags || [],
      seoTitle: '',
      seoDescription: '',
      seoKeywords: [],
      seoHashtags: [],
      altText: '',
      primaryGeoTargets: [],
      segmentIntroLocalized: {},
      tagsLocalized: {},
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    
    const seo = generateSEOMetadata(newSegment);
    newSegment.seoTitle = seo.seoTitle;
    newSegment.seoDescription = seo.seoDescription;
    newSegment.seoKeywords = seo.seoKeywords;
    newSegment.seoHashtags = seo.seoHashtags;
    newSegment.altText = seo.altText;
    
    setSegments((prev: AudienceSegment[]) => [...prev, newSegment]);
    return newSegment;
  }, []);

  const updateAudienceSegment = useCallback((id: string, input: UpdateSegmentInput): void => {
    setSegments((prev: AudienceSegment[]) =>
      prev.map((seg: AudienceSegment) =>
        seg.id === id
          ? { ...seg, ...input, updatedAt: Date.now() }
          : seg
      )
    );
  }, []);

  const deleteAudienceSegment = useCallback((id: string): void => {
    setSegments((prev: AudienceSegment[]) => prev.filter((seg: AudienceSegment) => seg.id !== id));
    setFunnels((prev: FunnelMap[]) => prev.filter((f: FunnelMap) => f.segmentId !== id));
    setStages((prev: FunnelStage[]) => prev.filter((s: FunnelStage) => s.segmentId !== id));
  }, []);

  const generateBaseFunnelForSegment = useCallback(
    (segmentId: string): { funnel: FunnelMap; stages: FunnelStage[] } => {
      const segment = segments.find((s: AudienceSegment) => s.id === segmentId);
      if (!segment) throw new Error('Segment not found');

      const newFunnel: FunnelMap = {
        id: `funnel-${Date.now()}`,
        segmentId,
        name: `${segment.name} Base Funnel`,
        description: `Standard awareness-to-loyalty funnel for ${segment.name}`,
        stageIds: [],
        status: 'draft',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      const newStages = generateBaseFunnelStages(segmentId, segment);
      newFunnel.stageIds = newStages.map((s: FunnelStage) => s.id);

      setFunnels((prev: FunnelMap[]) => [...prev, newFunnel]);
      setStages((prev: FunnelStage[]) => [...prev, ...newStages]);

      return { funnel: newFunnel, stages: newStages };
    },
    [segments]
  );

  const createCustomFunnel = useCallback((segmentId: string, name: string, description: string): FunnelMap => {
    const newFunnel: FunnelMap = {
      id: `funnel-${Date.now()}`,
      segmentId,
      name,
      description,
      stageIds: [],
      status: 'draft',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    setFunnels((prev: FunnelMap[]) => [...prev, newFunnel]);
    return newFunnel;
  }, []);

  const updateFunnel = useCallback((id: string, updates: Partial<FunnelMap>): void => {
    setFunnels((prev: FunnelMap[]) =>
      prev.map((f: FunnelMap) =>
        f.id === id ? { ...f, ...updates, updatedAt: Date.now() } : f
      )
    );
  }, []);

  const deleteFunnel = useCallback((id: string): void => {
    const funnel = funnels.find((f: FunnelMap) => f.id === id);
    if (funnel) {
      setStages((prev: FunnelStage[]) =>
        prev.filter((s: FunnelStage) => !funnel.stageIds.includes(s.id))
      );
    }
    setFunnels((prev: FunnelMap[]) => prev.filter((f: FunnelMap) => f.id !== id));
  }, [funnels]);

  const addOrUpdateFunnelStage = useCallback(
    (stageInput: Partial<FunnelStage> & { id?: string; segmentId: string }): FunnelStage => {
      if (stageInput.id) {
        const updatedStage = { ...stages.find((s: FunnelStage) => s.id === stageInput.id), ...stageInput } as FunnelStage;
        setStages((prev: FunnelStage[]) =>
          prev.map((s: FunnelStage) => (s.id === stageInput.id ? updatedStage : s))
        );
        return updatedStage;
      } else {
        const newStage: FunnelStage = {
          id: `stage-${Date.now()}`,
          segmentId: stageInput.segmentId,
          stageName: stageInput.stageName || 'New Stage',
          stageOrder: stageInput.stageOrder || 1,
          objective: stageInput.objective || '',
          keyMessages: stageInput.keyMessages || [],
          recommendedCTAs: stageInput.recommendedCTAs || [],
          recommendedAssets: stageInput.recommendedAssets || [],
          notes: stageInput.notes || '',
        };
        setStages((prev: FunnelStage[]) => [...prev, newStage]);
        return newStage;
      }
    },
    [stages]
  );

  const deleteStage = useCallback((id: string): void => {
    setStages((prev: FunnelStage[]) => prev.filter((s: FunnelStage) => s.id !== id));
    setFunnels((prev: FunnelMap[]) =>
      prev.map((f: FunnelMap) => ({
        ...f,
        stageIds: f.stageIds.filter((sid: string) => sid !== id),
      }))
    );
  }, []);

  const regenerateStageMessages = useCallback(
    (stageId: string, instructions: string): void => {
      const stage = stages.find((s: FunnelStage) => s.id === stageId);
      if (!stage) return;

      const segment = segments.find((seg: AudienceSegment) => seg.id === stage.segmentId);
      if (!segment) return;

      const { keyMessages, recommendedCTAs } = regenerateStageMessaging(stage, segment, instructions);

      setStages((prev: FunnelStage[]) =>
        prev.map((s: FunnelStage) =>
          s.id === stageId
            ? {
                ...s,
                keyMessages,
                recommendedCTAs,
                notes: s.notes + `\n[Regenerated with: "${instructions}"]`,
              }
            : s
        )
      );
    },
    [stages, segments]
  );

  const assignGeoTargetsToSegment = useCallback((segmentId: string, geoTargets: GeoTarget[]): void => {
    setSegments((prev: AudienceSegment[]) =>
      prev.map((seg: AudienceSegment) =>
        seg.id === segmentId
          ? { ...seg, primaryGeoTargets: geoTargets, updatedAt: Date.now() }
          : seg
      )
    );
  }, []);

  const generateGeoVariantsForSegment = useCallback(
    (segmentId: string): void => {
      const segment = segments.find((s: AudienceSegment) => s.id === segmentId);
      if (!segment) return;

      const { segmentIntroLocalized, tagsLocalized } = generateGeoVariants(segment);

      setSegments((prev: AudienceSegment[]) =>
        prev.map((seg: AudienceSegment) =>
          seg.id === segmentId
            ? { ...seg, segmentIntroLocalized, tagsLocalized, updatedAt: Date.now() }
            : seg
        )
      );
    },
    [segments]
  );

  const generateStageGeoVariantsForStage = useCallback(
    (stageId: string): void => {
      const stage = stages.find((s: FunnelStage) => s.id === stageId);
      if (!stage) return;

      const segment = segments.find((seg: AudienceSegment) => seg.id === stage.segmentId);
      if (!segment || segment.primaryGeoTargets.length === 0) return;

      const variants = generateStageGeoVariants(stage, segment.primaryGeoTargets);

      const newGeoVariants: StageGeoVariant[] = [];
      Object.entries(variants).forEach(([geoKey, data]: [string, { localizedMessages: string[]; localizedCTAs: string[] }]) => {
        newGeoVariants.push({
          id: `geovar-${Date.now()}-${geoKey}`,
          stageId,
          geoKey,
          localizedMessages: data.localizedMessages,
          localizedCTAs: data.localizedCTAs,
        });
      });

      setGeoVariants((prev: StageGeoVariant[]) => [
        ...prev.filter((gv: StageGeoVariant) => gv.stageId !== stageId),
        ...newGeoVariants,
      ]);
    },
    [stages, segments]
  );

  const regenerateSEO = useCallback(
    (segmentId: string): void => {
      const segment = segments.find((s: AudienceSegment) => s.id === segmentId);
      if (!segment) return;

      const seo = generateSEOMetadata(segment);
      updateAudienceSegment(segmentId, seo);
    },
    [segments, updateAudienceSegment]
  );

  const listSegments = useCallback(
    (filter?: SegmentFilter): AudienceSegment[] => {
      let filtered = [...segments];

      if (filter?.priorityLevel) {
        filtered = filtered.filter((s: AudienceSegment) => s.priorityLevel === filter.priorityLevel);
      }

      if (filter?.tag) {
        filtered = filtered.filter((s: AudienceSegment) =>
          s.tags.some((t: string) => t.toLowerCase().includes(filter.tag!.toLowerCase()))
        );
      }

      if (filter?.chainAffinity) {
        filtered = filtered.filter((s: AudienceSegment) =>
          s.chainAffinity.some((c: string) => c.toLowerCase().includes(filter.chainAffinity!.toLowerCase()))
        );
      }

      return filtered;
    },
    [segments]
  );

  const listFunnelsForSegment = useCallback(
    (segmentId: string): FunnelMap[] => {
      return funnels.filter((f: FunnelMap) => f.segmentId === segmentId);
    },
    [funnels]
  );

  const getFunnelDetails = useCallback(
    (funnelId: string): { funnel: FunnelMap; stages: FunnelStage[] } | null => {
      const funnel = funnels.find((f: FunnelMap) => f.id === funnelId);
      if (!funnel) return null;

      const funnelStages = stages
        .filter((s: FunnelStage) => funnel.stageIds.includes(s.id))
        .sort((a: FunnelStage, b: FunnelStage) => a.stageOrder - b.stageOrder);

      return { funnel, stages: funnelStages };
    },
    [funnels, stages]
  );

  const exportBrief = useCallback(
    (funnelId: string): string => {
      const details = getFunnelDetails(funnelId);
      if (!details) return 'Funnel not found';

      const segment = segments.find((s: AudienceSegment) => s.id === details.funnel.segmentId);
      if (!segment) return 'Segment not found';

      return exportFunnelBrief(details.funnel, segment, details.stages);
    },
    [getFunnelDetails, segments]
  );

  const getSegment = useCallback(
    (id: string): AudienceSegment | undefined => {
      return segments.find((s: AudienceSegment) => s.id === id);
    },
    [segments]
  );

  const getStage = useCallback(
    (id: string): FunnelStage | undefined => {
      return stages.find((s: FunnelStage) => s.id === id);
    },
    [stages]
  );

  return (
    <DreamNetContext.Provider
      value={{
        segments,
        funnels,
        stages,
        geoVariants,
        createAudienceSegment,
        updateAudienceSegment,
        deleteAudienceSegment,
        generateBaseFunnelForSegment,
        createCustomFunnel,
        updateFunnel,
        deleteFunnel,
        addOrUpdateFunnelStage,
        deleteStage,
        regenerateStageMessages,
        assignGeoTargetsToSegment,
        generateGeoVariantsForSegment,
        generateStageGeoVariantsForStage,
        regenerateSEO,
        listSegments,
        listFunnelsForSegment,
        getFunnelDetails,
        exportBrief,
        getSegment,
        getStage,
      }}
    >
      {children}
    </DreamNetContext.Provider>
  );
}

export function useDreamNet(): DreamNetContextType {
  const context = useContext(DreamNetContext);
  if (context === undefined) {
    throw new Error('useDreamNet must be used within a DreamNetProvider');
  }
  return context;
}
