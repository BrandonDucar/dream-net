import type { CreateSegmentInput, AudienceSegment, FunnelStage, GeoTarget } from '@/types/dreamnet';

export function generateSegmentDetails(input: CreateSegmentInput): Partial<AudienceSegment> {
  const { prompt, archetype, name } = input;
  const lowerPrompt = prompt.toLowerCase();
  
  // Extract key themes from the prompt
  const hasChain = lowerPrompt.includes('base') || lowerPrompt.includes('solana') || lowerPrompt.includes('eth');
  const hasCrypto = lowerPrompt.includes('degen') || lowerPrompt.includes('whale') || lowerPrompt.includes('trader') || lowerPrompt.includes('token');
  const hasCulture = lowerPrompt.includes('culture') || lowerPrompt.includes('meme') || lowerPrompt.includes('narrative');
  const hasSocial = lowerPrompt.includes('social') || lowerPrompt.includes('community') || lowerPrompt.includes('pickleball');
  const hasBuilder = lowerPrompt.includes('dev') || lowerPrompt.includes('builder') || lowerPrompt.includes('creator') || lowerPrompt.includes('artist');
  
  // Generate description
  const description = `${name} represents ${prompt}. This segment is characterized by their unique position in the DreamNet ecosystem, bringing specific needs, behaviors, and opportunities for engagement.`;
  
  // Generate core motivations based on prompt analysis
  const motivations: string[] = [];
  if (hasCrypto) {
    motivations.push('Financial upside and alpha opportunities');
    motivations.push('Early access to innovative tokens and drops');
    motivations.push('Status and recognition within crypto communities');
  }
  if (hasBuilder) {
    motivations.push('Learning and skill development');
    motivations.push('Building reputation and portfolio');
    motivations.push('Collaboration with like-minded creators');
  }
  if (hasCulture) {
    motivations.push('Cultural influence and trendsetting');
    motivations.push('Community belonging and identity expression');
    motivations.push('Access to exclusive narratives and content');
  }
  if (hasSocial) {
    motivations.push('Social connection and shared experiences');
    motivations.push('Fun, entertainment, and memorable moments');
    motivations.push('Local community engagement');
  }
  
  if (motivations.length === 0) {
    motivations.push('Discovering new opportunities in the ecosystem');
    motivations.push('Meaningful participation and contribution');
    motivations.push('Personal growth and achievement');
  }
  
  // Generate pain points
  const painPoints: string[] = [];
  if (hasCrypto) {
    painPoints.push('Information overload and difficulty finding signal');
    painPoints.push('Missing out on opportunities (FOMO)');
    painPoints.push('Lack of trusted sources and alpha channels');
  }
  if (hasBuilder) {
    painPoints.push('Limited resources and unclear paths forward');
    painPoints.push('Difficulty standing out in crowded markets');
    painPoints.push('Uncertainty about best practices and tools');
  }
  if (hasCulture) {
    painPoints.push('Feeling disconnected from mainstream narratives');
    painPoints.push('Lack of platforms that understand their values');
    painPoints.push('Difficulty finding authentic communities');
  }
  if (hasSocial) {
    painPoints.push('Fragmented social experiences across platforms');
    painPoints.push('Lack of local or niche community hubs');
    painPoints.push('Generic content that doesn\'t resonate');
  }
  
  if (painPoints.length === 0) {
    painPoints.push('Overwhelmed by too many options and platforms');
    painPoints.push('Unclear value propositions and trust signals');
    painPoints.push('Difficulty finding relevant content and connections');
  }
  
  // Detect chain affinity
  const chainAffinity: string[] = [];
  if (lowerPrompt.includes('base')) chainAffinity.push('Base');
  if (lowerPrompt.includes('solana')) chainAffinity.push('Solana');
  if (lowerPrompt.includes('eth') || lowerPrompt.includes('ethereum')) chainAffinity.push('Ethereum');
  if (lowerPrompt.includes('polygon')) chainAffinity.push('Polygon');
  
  // Generate preferred channels
  const preferredChannels: string[] = [];
  if (hasCrypto || hasCulture) {
    preferredChannels.push('X (Twitter)');
    preferredChannels.push('Farcaster');
  }
  if (hasBuilder) {
    preferredChannels.push('Discord');
    preferredChannels.push('GitHub');
    preferredChannels.push('Telegram');
  }
  if (hasSocial) {
    preferredChannels.push('Instagram');
    preferredChannels.push('TikTok');
    preferredChannels.push('Local events');
  }
  if (hasCrypto) {
    preferredChannels.push('Zora');
    preferredChannels.push('Warpcast');
  }
  
  if (preferredChannels.length === 0) {
    preferredChannels.push('X (Twitter)', 'Discord', 'Telegram');
  }
  
  // Generate tags
  const tags: string[] = [];
  if (hasCrypto) tags.push('crypto', 'defi');
  if (hasBuilder) tags.push('builders', 'developers');
  if (hasCulture) tags.push('culture', 'memes');
  if (hasSocial) tags.push('social', 'community');
  if (chainAffinity.length > 0) tags.push('onchain');
  
  // Add archetype as tag
  tags.push(archetype.toLowerCase());
  
  return {
    description,
    coreMotivations: motivations.slice(0, 5),
    painPoints: painPoints.slice(0, 5),
    chainAffinity,
    preferredChannels: [...new Set(preferredChannels)].slice(0, 6),
    tags: [...new Set(tags)],
  };
}

export function generateSEOMetadata(segment: { name: string; description: string; tags: string[]; archetype: string }): {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
} {
  const seoTitle = `${segment.name} | DreamNet Audience Segment`;
  
  const seoDescription = segment.description.length > 160 
    ? segment.description.substring(0, 157) + '...'
    : segment.description;
  
  const seoKeywords = [
    segment.name.toLowerCase(),
    segment.archetype.toLowerCase(),
    ...segment.tags,
    'dreamnet',
    'audience segment',
    'web3 marketing',
  ];
  
  const seoHashtags = segment.tags.map((tag: string) => `#${tag.replace(/\s+/g, '')}`);
  seoHashtags.push('#DreamNet', '#Web3');
  
  const altText = `${segment.name} audience segment visualization - ${segment.archetype} archetype`;
  
  return {
    seoTitle,
    seoDescription,
    seoKeywords: [...new Set(seoKeywords)],
    seoHashtags: [...new Set(seoHashtags)],
    altText,
  };
}

export function generateBaseFunnelStages(segmentId: string, segment: AudienceSegment): FunnelStage[] {
  const stages: FunnelStage[] = [];
  
  // Stage 1: Awareness
  stages.push({
    id: `stage-${Date.now()}-1`,
    segmentId,
    stageName: 'Awareness',
    stageOrder: 1,
    objective: `Introduce ${segment.name} to the DreamNet ecosystem and establish initial recognition`,
    keyMessages: [
      `Welcome to DreamNet - a space built for ${segment.archetype}s like you`,
      `Discover opportunities aligned with your interests: ${segment.tags.slice(0, 3).join(', ')}`,
      `Join a community that understands ${segment.painPoints[0]?.toLowerCase() || 'your needs'}`,
    ],
    recommendedCTAs: [
      'Explore DreamNet',
      'Learn More',
      'See What\'s New',
    ],
    recommendedAssets: [
      'DreamNet landing page',
      'Introductory content piece',
      'Social media posts',
      'Banner ads',
    ],
    notes: 'Auto-generated base funnel stage',
  });
  
  // Stage 2: Interest
  stages.push({
    id: `stage-${Date.now()}-2`,
    segmentId,
    stageName: 'Interest',
    stageOrder: 2,
    objective: `Deepen engagement by showcasing relevant value propositions for ${segment.name}`,
    keyMessages: [
      `Access tools and resources designed for ${segment.archetype}s`,
      `${segment.coreMotivations[0] || 'Achieve your goals'} through DreamNet`,
      `Connect with others who share your passion for ${segment.tags[0] || 'innovation'}`,
    ],
    recommendedCTAs: [
      'Join the Community',
      'Try a Mini-App',
      'Get Started',
    ],
    recommendedAssets: [
      'Feature showcase videos',
      'Case studies',
      'Community highlights',
      'Free trial or demo',
    ],
    notes: 'Auto-generated base funnel stage',
  });
  
  // Stage 3: Action
  stages.push({
    id: `stage-${Date.now()}-3`,
    segmentId,
    stageName: 'Action',
    stageOrder: 3,
    objective: `Convert ${segment.name} into active participants in the DreamNet ecosystem`,
    keyMessages: [
      `Take your first step: ${segment.preferredChannels[0] ? `connect via ${segment.preferredChannels[0]}` : 'join now'}`,
      'Get immediate value with our onboarding experience',
      `Start building, earning, or contributing today`,
    ],
    recommendedCTAs: [
      'Sign Up Now',
      'Connect Wallet',
      'Claim Your Spot',
    ],
    recommendedAssets: [
      'Onboarding flow',
      'Quick start guide',
      'Welcome rewards or incentives',
      segment.chainAffinity.length > 0 ? 'Token claim page' : 'Registration page',
    ],
    notes: 'Auto-generated base funnel stage',
  });
  
  // Stage 4: Loyalty
  stages.push({
    id: `stage-${Date.now()}-4`,
    segmentId,
    stageName: 'Loyalty',
    stageOrder: 4,
    objective: `Retain and deepen commitment from ${segment.name} through ongoing value and recognition`,
    keyMessages: [
      'Your contributions matter - see your impact',
      `Unlock exclusive benefits for ${segment.archetype}s`,
      'Become a leader in the DreamNet community',
    ],
    recommendedCTAs: [
      'Explore Advanced Features',
      'Refer Friends',
      'Join Ambassador Program',
    ],
    recommendedAssets: [
      'Loyalty rewards program',
      'Exclusive community access',
      'Advanced features or tools',
      'Recognition and leaderboards',
    ],
    notes: 'Auto-generated base funnel stage',
  });
  
  return stages;
}

export function regenerateStageMessaging(
  stage: FunnelStage,
  segment: AudienceSegment,
  instructions: string
): { keyMessages: string[]; recommendedCTAs: string[] } {
  const lowerInstructions = instructions.toLowerCase();
  
  let tone = 'balanced';
  if (lowerInstructions.includes('aggressive') || lowerInstructions.includes('bold') || lowerInstructions.includes('strong')) {
    tone = 'aggressive';
  } else if (lowerInstructions.includes('soft') || lowerInstructions.includes('gentle') || lowerInstructions.includes('normie') || lowerInstructions.includes('casual')) {
    tone = 'soft';
  }
  
  const keyMessages: string[] = [];
  const recommendedCTAs: string[] = [];
  
  // Adjust messaging based on stage and tone
  switch (stage.stageName.toLowerCase()) {
    case 'awareness':
      if (tone === 'aggressive') {
        keyMessages.push(`${segment.name}: This is your moment - don't miss out`);
        keyMessages.push(`The future of ${segment.tags[0] || 'innovation'} is here. Are you in?`);
        keyMessages.push(`Join the elite ${segment.archetype}s dominating DreamNet`);
        recommendedCTAs.push('Claim Your Spot Now', 'Get Alpha Access', 'Don\'t Miss This');
      } else if (tone === 'soft') {
        keyMessages.push(`Welcome! We're excited to have ${segment.name} here`);
        keyMessages.push(`Explore at your own pace - there's something for everyone`);
        keyMessages.push(`A friendly community for ${segment.archetype}s`);
        recommendedCTAs.push('Learn More', 'Take a Look', 'See What We\'re About');
      } else {
        keyMessages.push(`Discover DreamNet - built for ${segment.name}`);
        keyMessages.push(`Everything you need as a ${segment.archetype}`);
        keyMessages.push(`Join thousands already benefiting`);
        recommendedCTAs.push('Explore', 'Learn More', 'Get Started');
      }
      break;
      
    case 'interest':
      if (tone === 'aggressive') {
        keyMessages.push(`${segment.coreMotivations[0] || 'Win big'} - but only if you act fast`);
        keyMessages.push(`Your competition is already here. What are you waiting for?`);
        keyMessages.push(`Unlock premium ${segment.tags[0] || 'features'} that give you an edge`);
        recommendedCTAs.push('Join Elite Circle', 'Get Instant Access', 'Activate Now');
      } else if (tone === 'soft') {
        keyMessages.push(`We'd love to help you with ${segment.coreMotivations[0]?.toLowerCase() || 'your goals'}`);
        keyMessages.push(`Take your time exploring what resonates with you`);
        keyMessages.push(`Connect with friendly ${segment.archetype}s in our community`);
        recommendedCTAs.push('Join Us', 'Try It Out', 'Connect');
      } else {
        keyMessages.push(`${segment.coreMotivations[0] || 'Achieve your goals'} with DreamNet`);
        keyMessages.push(`Designed specifically for ${segment.archetype}s`);
        keyMessages.push(`See why ${segment.name} loves our platform`);
        recommendedCTAs.push('Join Community', 'Try Demo', 'Get Started');
      }
      break;
      
    case 'action':
      if (tone === 'aggressive') {
        keyMessages.push('Stop waiting. Start winning. NOW.');
        keyMessages.push(`Claim your ${segment.chainAffinity[0] || 'rewards'} before they're gone`);
        keyMessages.push('First movers get the biggest rewards');
        recommendedCTAs.push('Claim Now', 'Go All In', 'Activate Account');
      } else if (tone === 'soft') {
        keyMessages.push('Ready to give it a try? We are here to help');
        keyMessages.push('Simple signup - no pressure, no hassle');
        keyMessages.push('Join whenever you feel ready');
        recommendedCTAs.push('Sign Up', 'Create Account', 'Get Started');
      } else {
        keyMessages.push('Join DreamNet in under 2 minutes');
        keyMessages.push('Start accessing benefits immediately');
        keyMessages.push('No commitment required - explore freely');
        recommendedCTAs.push('Sign Up', 'Connect', 'Get Started');
      }
      break;
      
    case 'loyalty':
      if (tone === 'aggressive') {
        keyMessages.push('Dominate the leaderboard - prove you\'re the best');
        keyMessages.push('Elite status unlocked - claim your throne');
        keyMessages.push('Maximize your position with advanced features');
        recommendedCTAs.push('Level Up', 'Claim Elite Status', 'Maximize Returns');
      } else if (tone === 'soft') {
        keyMessages.push('Thanks for being part of our community!');
        keyMessages.push('We appreciate your continued support');
        keyMessages.push('Enjoy these special perks as our thanks');
        recommendedCTAs.push('Explore Perks', 'Share With Friends', 'Stay Connected');
      } else {
        keyMessages.push('Welcome to the inner circle');
        keyMessages.push('Unlock exclusive benefits for loyal members');
        keyMessages.push('Help shape the future of DreamNet');
        recommendedCTAs.push('Unlock Rewards', 'Join Ambassador Program', 'Access VIP Features');
      }
      break;
      
    default:
      keyMessages.push('Tailored messaging for your audience');
      keyMessages.push(`Optimized for ${segment.name}`);
      recommendedCTAs.push('Take Action', 'Learn More');
  }
  
  return { keyMessages, recommendedCTAs };
}

export function generateGeoVariants(segment: AudienceSegment): {
  segmentIntroLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
} {
  const segmentIntroLocalized: Record<string, string> = {};
  const tagsLocalized: Record<string, string[]> = {};
  
  for (const geo of segment.primaryGeoTargets) {
    const geoKey = geo.id;
    const language = geo.language;
    
    // Generate localized intro
    if (language === 'es') {
      segmentIntroLocalized[geoKey] = `${segment.name} - ${segment.description} Esta comunidad está diseñada para ${segment.archetype}s que buscan ${segment.coreMotivations[0]?.toLowerCase() || 'oportunidades'}.`;
      tagsLocalized[geoKey] = segment.tags.map((tag: string) => {
        const translations: Record<string, string> = {
          'crypto': 'cripto',
          'builders': 'constructores',
          'culture': 'cultura',
          'community': 'comunidad',
          'social': 'social',
        };
        return translations[tag] || tag;
      });
    } else if (language === 'pt-BR') {
      segmentIntroLocalized[geoKey] = `${segment.name} - ${segment.description} Esta comunidade é projetada para ${segment.archetype}s que buscam ${segment.coreMotivations[0]?.toLowerCase() || 'oportunidades'}.`;
      tagsLocalized[geoKey] = segment.tags.map((tag: string) => {
        const translations: Record<string, string> = {
          'crypto': 'cripto',
          'builders': 'construtores',
          'culture': 'cultura',
          'community': 'comunidade',
          'social': 'social',
        };
        return translations[tag] || tag;
      });
    } else if (language === 'fr') {
      segmentIntroLocalized[geoKey] = `${segment.name} - ${segment.description} Cette communauté est conçue pour les ${segment.archetype}s qui recherchent ${segment.coreMotivations[0]?.toLowerCase() || 'des opportunités'}.`;
      tagsLocalized[geoKey] = segment.tags.map((tag: string) => {
        const translations: Record<string, string> = {
          'crypto': 'crypto',
          'builders': 'constructeurs',
          'culture': 'culture',
          'community': 'communauté',
          'social': 'social',
        };
        return translations[tag] || tag;
      });
    } else {
      // Default to English or region-specific English
      let localizedIntro = `${segment.name} - ${segment.description}`;
      
      if (geo.region === 'LATAM') {
        localizedIntro += ` Popular in ${geo.cityOrMarket || geo.country || 'Latin America'}.`;
      } else if (geo.cityOrMarket) {
        localizedIntro += ` Serving the ${geo.cityOrMarket} community.`;
      }
      
      segmentIntroLocalized[geoKey] = localizedIntro;
      tagsLocalized[geoKey] = [...segment.tags];
    }
  }
  
  return { segmentIntroLocalized, tagsLocalized };
}

export function generateStageGeoVariants(
  stage: FunnelStage,
  geoTargets: GeoTarget[]
): Record<string, { localizedMessages: string[]; localizedCTAs: string[] }> {
  const variants: Record<string, { localizedMessages: string[]; localizedCTAs: string[] }> = {};
  
  for (const geo of geoTargets) {
    const geoKey = geo.id;
    const language = geo.language;
    
    if (language === 'es') {
      variants[geoKey] = {
        localizedMessages: stage.keyMessages.map((msg: string) => `[ES] ${msg}`),
        localizedCTAs: stage.recommendedCTAs.map((cta: string) => {
          const translations: Record<string, string> = {
            'Learn More': 'Saber Más',
            'Get Started': 'Comenzar',
            'Join': 'Únete',
            'Sign Up': 'Regístrate',
            'Explore': 'Explorar',
          };
          return translations[cta] || cta;
        }),
      };
    } else if (language === 'pt-BR') {
      variants[geoKey] = {
        localizedMessages: stage.keyMessages.map((msg: string) => `[PT] ${msg}`),
        localizedCTAs: stage.recommendedCTAs.map((cta: string) => {
          const translations: Record<string, string> = {
            'Learn More': 'Saiba Mais',
            'Get Started': 'Começar',
            'Join': 'Junte-se',
            'Sign Up': 'Inscrever-se',
            'Explore': 'Explorar',
          };
          return translations[cta] || cta;
        }),
      };
    } else {
      // Regional English variants
      const regionalMessages = stage.keyMessages.map((msg: string) => {
        if (geo.cityOrMarket) {
          return msg.replace(/DreamNet/g, `DreamNet ${geo.cityOrMarket}`);
        }
        return msg;
      });
      
      variants[geoKey] = {
        localizedMessages: regionalMessages,
        localizedCTAs: [...stage.recommendedCTAs],
      };
    }
  }
  
  return variants;
}

export function exportFunnelBrief(
  funnel: { name: string; description: string; status: string },
  segment: AudienceSegment,
  stages: FunnelStage[]
): string {
  let brief = `# FUNNEL BRIEF: ${funnel.name}\n\n`;
  brief += `Status: ${funnel.status}\n`;
  brief += `${funnel.description}\n\n`;
  
  brief += `---\n\n`;
  brief += `## AUDIENCE SEGMENT: ${segment.name}\n\n`;
  brief += `**Archetype:** ${segment.archetype}\n`;
  brief += `**Priority:** ${segment.priorityLevel}\n\n`;
  brief += `**Description:**\n${segment.description}\n\n`;
  
  brief += `**Core Motivations:**\n`;
  segment.coreMotivations.forEach((m: string) => {
    brief += `- ${m}\n`;
  });
  
  brief += `\n**Pain Points:**\n`;
  segment.painPoints.forEach((p: string) => {
    brief += `- ${p}\n`;
  });
  
  if (segment.chainAffinity.length > 0) {
    brief += `\n**Chain Affinity:** ${segment.chainAffinity.join(', ')}\n`;
  }
  
  brief += `\n**Preferred Channels:** ${segment.preferredChannels.join(', ')}\n`;
  brief += `**Tags:** ${segment.tags.join(', ')}\n\n`;
  
  brief += `---\n\n`;
  brief += `## FUNNEL STAGES\n\n`;
  
  stages.forEach((stage: FunnelStage) => {
    brief += `### Stage ${stage.stageOrder}: ${stage.stageName}\n\n`;
    brief += `**Objective:**\n${stage.objective}\n\n`;
    
    brief += `**Key Messages:**\n`;
    stage.keyMessages.forEach((msg: string) => {
      brief += `- ${msg}\n`;
    });
    
    brief += `\n**Recommended CTAs:**\n`;
    stage.recommendedCTAs.forEach((cta: string) => {
      brief += `- ${cta}\n`;
    });
    
    if (stage.recommendedAssets.length > 0) {
      brief += `\n**Recommended Assets:**\n`;
      stage.recommendedAssets.forEach((asset: string) => {
        brief += `- ${asset}\n`;
      });
    }
    
    if (stage.notes) {
      brief += `\n**Notes:** ${stage.notes}\n`;
    }
    
    brief += `\n`;
  });
  
  brief += `---\n\n`;
  brief += `## SEO METADATA\n\n`;
  brief += `**Title:** ${segment.seoTitle}\n`;
  brief += `**Description:** ${segment.seoDescription}\n`;
  brief += `**Keywords:** ${segment.seoKeywords.join(', ')}\n`;
  brief += `**Hashtags:** ${segment.seoHashtags.join(' ')}\n`;
  brief += `**Alt Text:** ${segment.altText}\n\n`;
  
  if (segment.primaryGeoTargets.length > 0) {
    brief += `---\n\n`;
    brief += `## GEOGRAPHIC TARGETING\n\n`;
    segment.primaryGeoTargets.forEach((geo: GeoTarget) => {
      brief += `**${geo.id}**\n`;
      brief += `- Region: ${geo.region}\n`;
      if (geo.country) brief += `- Country: ${geo.country}\n`;
      if (geo.cityOrMarket) brief += `- City/Market: ${geo.cityOrMarket}\n`;
      brief += `- Language: ${geo.language}\n`;
      
      if (segment.segmentIntroLocalized[geo.id]) {
        brief += `- Localized Intro: ${segment.segmentIntroLocalized[geo.id]}\n`;
      }
      
      if (segment.tagsLocalized[geo.id]) {
        brief += `- Localized Tags: ${segment.tagsLocalized[geo.id].join(', ')}\n`;
      }
      
      brief += `\n`;
    });
  }
  
  brief += `---\n\n`;
  brief += `Generated by DreamNet Funnel Cartographer\n`;
  brief += `${new Date().toISOString()}\n`;
  
  return brief;
}
