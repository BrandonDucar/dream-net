export type PriorityLevel = "low" | "medium" | "high" | "critical";
export type FunnelStatus = "idea" | "draft" | "active" | "paused" | "retired";

export interface GeoTarget {
  id: string;
  region: string;
  country?: string;
  cityOrMarket?: string;
  language: string;
}

export interface AudienceSegment {
  id: string;
  name: string;
  archetype: string;
  description: string;
  chainAffinity: string[];
  priorityLevel: PriorityLevel;
  coreMotivations: string[];
  painPoints: string[];
  preferredChannels: string[];
  tags: string[];
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
  primaryGeoTargets: GeoTarget[];
  segmentIntroLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
  createdAt: number;
  updatedAt: number;
}

export interface FunnelStage {
  id: string;
  segmentId: string;
  stageName: string;
  stageOrder: number;
  objective: string;
  keyMessages: string[];
  recommendedCTAs: string[];
  recommendedAssets: string[];
  notes: string;
}

export interface FunnelMap {
  id: string;
  segmentId: string;
  name: string;
  description: string;
  stageIds: string[];
  status: FunnelStatus;
  createdAt: number;
  updatedAt: number;
}

export interface StageGeoVariant {
  id: string;
  stageId: string;
  geoKey: string;
  localizedMessages: string[];
  localizedCTAs: string[];
}

export interface CreateSegmentInput {
  name: string;
  archetype: string;
  prompt: string;
}

export interface UpdateSegmentInput {
  name?: string;
  archetype?: string;
  description?: string;
  coreMotivations?: string[];
  painPoints?: string[];
  chainAffinity?: string[];
  preferredChannels?: string[];
  tags?: string[];
  priorityLevel?: PriorityLevel;
  seoTitle?: string;
  seoDescription?: string;
  seoKeywords?: string[];
  seoHashtags?: string[];
  altText?: string;
  primaryGeoTargets?: GeoTarget[];
}

export interface SegmentFilter {
  priorityLevel?: PriorityLevel;
  tag?: string;
  chainAffinity?: string;
}
