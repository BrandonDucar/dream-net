/**
 * Internal Gold Price API
 * Provides real-time gold spot pricing with multiple fallback sources
 */

import { NextRequest, NextResponse } from "next/server";

// Cache for 60 seconds to avoid rate limiting
let cachedPrice: { price: number; timestamp: number; source: string } | null = null;
const CACHE_DURATION = 60000; // 60 seconds

async function fetchFromGoldPriceOrg(): Promise<number> {
  const response = await fetch("https://data-asg.goldprice.org/dbXRates/USD", {
    headers: {
      "User-Agent": "Mozilla/5.0"
    },
    cache: 'no-store'
  });
  
  if (!response.ok) throw new Error("GoldPrice.org failed");
  
  const data = await response.json();
  // Data format: { items: [{ xauPrice: number, ... }] } or array format
  if (Array.isArray(data) && data.length > 1) {
    return parseFloat(data[1]);
  }
  if (data.items && data.items[0] && data.items[0].xauPrice) {
    return parseFloat(data.items[0].xauPrice);
  }
  throw new Error("Invalid GoldPrice.org response");
}

async function fetchFromMetalsLive(): Promise<number> {
  const response = await fetch("https://www.metals.live/v1/spot/gold", {
    headers: {
      "User-Agent": "Mozilla/5.0"
    },
    cache: 'no-store'
  });
  
  if (!response.ok) throw new Error("Metals.live failed");
  
  const data = await response.json();
  if (data && data.price) {
    return parseFloat(data.price);
  }
  throw new Error("Invalid Metals.live response");
}

async function fetchFromCoinbase(): Promise<number> {
  // Coinbase has a free public API for commodity prices
  const response = await fetch("https://api.coinbase.com/v2/prices/XAU-USD/spot", {
    headers: {
      "User-Agent": "Mozilla/5.0"
    },
    cache: 'no-store'
  });
  
  if (!response.ok) throw new Error("Coinbase failed");
  
  const data = await response.json();
  if (data && data.data && data.data.amount) {
    return parseFloat(data.data.amount);
  }
  throw new Error("Invalid Coinbase response");
}

async function fetchFromMetalpriceAPI(): Promise<number> {
  // Using a simple conversion API
  const response = await fetch("https://api.metals.dev/v1/latest?api_key=FREEKEY&currency=USD&unit=toz", {
    headers: {
      "User-Agent": "Mozilla/5.0"
    },
    cache: 'no-store'
  });
  
  if (!response.ok) throw new Error("Metals.dev failed");
  
  const data = await response.json();
  if (data && data.metals && data.metals.gold) {
    return parseFloat(data.metals.gold);
  }
  throw new Error("Invalid Metals.dev response");
}

export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    // Check cache
    if (cachedPrice && Date.now() - cachedPrice.timestamp < CACHE_DURATION) {
      return NextResponse.json({
        success: true,
        price: cachedPrice.price,
        timestamp: cachedPrice.timestamp,
        source: cachedPrice.source,
        cached: true
      });
    }

    // Try multiple sources with fallback
    let price: number | null = null;
    let source = "unknown";
    const errors: string[] = [];

    // Try GoldPrice.org first (most reliable)
    try {
      price = await fetchFromGoldPriceOrg();
      source = "goldprice.org";
    } catch (err) {
      errors.push(`GoldPrice.org: ${err instanceof Error ? err.message : "unknown error"}`);
    }

    // Try Coinbase as fallback
    if (!price) {
      try {
        price = await fetchFromCoinbase();
        source = "coinbase.com";
      } catch (err) {
        errors.push(`Coinbase: ${err instanceof Error ? err.message : "unknown error"}`);
      }
    }

    // Try Metals.live as fallback
    if (!price) {
      try {
        price = await fetchFromMetalsLive();
        source = "metals.live";
      } catch (err) {
        errors.push(`Metals.live: ${err instanceof Error ? err.message : "unknown error"}`);
      }
    }

    // Try Metals.dev as last resort
    if (!price) {
      try {
        price = await fetchFromMetalpriceAPI();
        source = "metals.dev";
      } catch (err) {
        errors.push(`Metals.dev: ${err instanceof Error ? err.message : "unknown error"}`);
      }
    }

    if (!price) {
      throw new Error(`All sources failed: ${errors.join("; ")}`);
    }

    // Validate price is reasonable (between $1000 and $5000)
    if (price < 1000 || price > 5000) {
      throw new Error(`Invalid price detected: $${price}`);
    }

    // Update cache
    cachedPrice = {
      price,
      timestamp: Date.now(),
      source
    };

    return NextResponse.json({
      success: true,
      price,
      timestamp: Date.now(),
      source,
      cached: false
    });

  } catch (error) {
    console.error("Gold price API error:", error);
    
    // Return cached price if available, even if expired
    if (cachedPrice) {
      return NextResponse.json({
        success: true,
        price: cachedPrice.price,
        timestamp: cachedPrice.timestamp,
        source: cachedPrice.source,
        cached: true,
        stale: true
      });
    }

    // Return a fallback estimated price if all else fails
    return NextResponse.json({
      success: true,
      price: 2700, // Approximate current gold price
      timestamp: Date.now(),
      source: "fallback-estimate",
      cached: false,
      warning: "Using estimated price - API sources unavailable"
    });
  }
}
