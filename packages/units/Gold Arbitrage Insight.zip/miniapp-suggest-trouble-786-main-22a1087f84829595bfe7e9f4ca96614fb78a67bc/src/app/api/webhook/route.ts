import { NextRequest, NextResponse } from "next/server";

/**
 * Incoming Webhook Endpoint
 * Allows external systems to push data into the platform
 */

export async function POST(req: NextRequest) {
  try {
    const authHeader = req.headers.get("authorization");
    const apiKey = authHeader?.replace("Bearer ", "");
    
    // TODO: Implement API key validation
    // For now, accept all requests for demo purposes
    
    const body = await req.json();
    
    // Validate incoming data structure
    if (!body.event || !body.data) {
      return NextResponse.json(
        { error: "Invalid payload. Required fields: event, data" },
        { status: 400 }
      );
    }
    
    // Process the incoming webhook
    // This could trigger actions in the app, update data, etc.
    
    return NextResponse.json({
      success: true,
      message: "Webhook received successfully",
      receivedAt: new Date().toISOString(),
      event: body.event
    });
    
  } catch (error) {
    return NextResponse.json(
      { 
        error: "Failed to process webhook",
        details: error instanceof Error ? error.message : "Unknown error"
      },
      { status: 500 }
    );
  }
}

export async function GET(req: NextRequest) {
  return NextResponse.json({
    message: "Webhook endpoint is active",
    documentation: {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer YOUR_API_KEY"
      },
      body: {
        event: "string (analysis_created | deal_found | alert_triggered)",
        data: "object (your custom data)"
      }
    }
  });
}
