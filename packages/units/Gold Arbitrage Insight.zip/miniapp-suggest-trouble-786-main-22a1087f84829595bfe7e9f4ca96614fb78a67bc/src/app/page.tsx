'use client'
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Coins, TrendingUp, Sparkles, Bell, Settings, RefreshCw, DollarSign, Zap, Search } from "lucide-react";
import { AIRecommendations } from "@/components/AIRecommendations";
import IntegrationSettings from "@/components/IntegrationSettings";
import { DealAlerts } from "@/components/DealAlerts";
import { LiveFractionalGoldDashboard } from "@/components/LiveFractionalGoldDashboard";
import { CustomDealAnalyzer } from "@/components/CustomDealAnalyzer";
import { DealerLookup } from "@/components/DealerLookup";
import type { PortfolioRecommendation } from "@/types/gold";
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Page(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [spotPrice, setSpotPrice] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [lastUpdated, setLastUpdated] = useState<string>("");
  const [manualPrice, setManualPrice] = useState<string>("");
  const [aiInsightsLastUpdated, setAiInsightsLastUpdated] = useState<string>("");
  const [aiInsightsLoading, setAiInsightsLoading] = useState<boolean>(false);
  const [insightUpdateTrigger, setInsightUpdateTrigger] = useState<number>(0);

  const fetchGoldPrice = async (): Promise<void> => {
    setLoading(true);
    try {
      const response = await fetch('/api/gold-price');
      const data = await response.json();
      
      if (data.price && data.price > 0) {
        setSpotPrice(data.price);
        setLastUpdated(new Date().toLocaleTimeString());
      }
    } catch (error) {
      console.error('Error fetching gold price:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGoldPrice();
    const interval = setInterval(fetchGoldPrice, 300000); // 5 minutes
    return () => clearInterval(interval);
  }, []);

  // Independent AI Insights refresh
  useEffect(() => {
    if (spotPrice > 0) {
      setAiInsightsLastUpdated(new Date().toLocaleTimeString());
    }
  }, [spotPrice, insightUpdateTrigger]);

  // Auto-refresh AI insights every 3 minutes
  useEffect(() => {
    const aiInterval = setInterval(() => {
      setInsightUpdateTrigger(prev => prev + 1);
      setAiInsightsLastUpdated(new Date().toLocaleTimeString());
    }, 180000); // 3 minutes
    return () => clearInterval(aiInterval);
  }, []);

  const handleManualUpdate = (): void => {
    const price = parseFloat(manualPrice);
    if (price > 0) {
      setSpotPrice(price);
      setLastUpdated(new Date().toLocaleTimeString() + " (Manual)");
      setManualPrice("");
    }
  };

  const handleRefreshAIInsights = async (): Promise<void> => {
    setAiInsightsLoading(true);
    // Simulate insight generation delay
    await new Promise(resolve => setTimeout(resolve, 800));
    setInsightUpdateTrigger(prev => prev + 1);
    setAiInsightsLastUpdated(new Date().toLocaleTimeString());
    setAiInsightsLoading(false);
  };

  // Generate AI recommendations based on current market
  const generateAIRecommendations = (): PortfolioRecommendation[] => {
    if (spotPrice === 0) return [];

    const recommendations: PortfolioRecommendation[] = [];

    // Dynamic recommendations based on spot price trends
    if (spotPrice > 2600) {
      recommendations.push({
        action: "BUY",
        weightType: "1/10 oz",
        reasoning: "Spot price is high but 1/10 oz pieces typically have lower premiums in bulk. Great entry point for fractional accumulation.",
        urgency: "HIGH",
        expectedReturn: 8.5
      });
    }

    if (spotPrice < 2500) {
      recommendations.push({
        action: "BUY",
        weightType: "1/2 oz",
        reasoning: "Lower spot price creates excellent buying opportunity. 1/2 oz pieces offer good balance between premium and liquidity.",
        urgency: "HIGH",
        expectedReturn: 12.3
      });
    }

    if (spotPrice >= 2500 && spotPrice <= 2600) {
      recommendations.push({
        action: "BUY",
        weightType: "1 oz",
        reasoning: "Spot price in optimal range. Full ounce pieces have lowest premiums and best resale value.",
        urgency: "MEDIUM",
        expectedReturn: 9.8
      });
    }

    recommendations.push({
      action: "BUY",
      weightType: "1/4 oz",
      reasoning: "1/4 oz Eagles and Maple Leafs maintain strong secondary market demand with consistent premiums around 10-15%.",
      urgency: "MEDIUM",
      expectedReturn: 6.7
    });

    recommendations.push({
      action: "HOLD",
      weightType: "5g",
      reasoning: "5g bars showing elevated premiums currently. Wait for market correction before accumulating more.",
      urgency: "LOW",
      expectedReturn: 3.2
    });

    return recommendations;
  };

  // Dynamic market sentiment based on spot price
  const getMarketSentiment = (): { sentiment: string; color: string; description: string } => {
    if (spotPrice > 2700) {
      return { sentiment: "Very Bullish", color: "green", description: "Strong upward momentum" };
    } else if (spotPrice > 2600) {
      return { sentiment: "Bullish", color: "green", description: "Strong buying opportunity" };
    } else if (spotPrice > 2400) {
      return { sentiment: "Neutral", color: "blue", description: "Stable market conditions" };
    } else {
      return { sentiment: "Bearish", color: "red", description: "Consider waiting" };
    }
  };

  const aiRecommendations = generateAIRecommendations();
  const marketSentiment = getMarketSentiment();

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50 p-4 pt-16 md:pt-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-3">
            <Coins className="h-10 w-10 text-amber-600" />
            <h1 className="text-4xl font-bold text-amber-900">Fractional Gold Arbitrage Finder</h1>
          </div>
          <p className="text-gray-700 text-lg">
            Live prices • Real-time analysis • Instant insights
          </p>
        </div>

        {/* Live Spot Price Card */}
        <Card className="border-2 border-amber-300 shadow-xl bg-gradient-to-r from-amber-100 to-yellow-100">
          <CardHeader>
            <CardTitle className="text-2xl text-amber-900 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <DollarSign className="h-6 w-6" />
                Live Gold Spot Price
              </span>
              <Button 
                onClick={fetchGoldPrice} 
                variant="outline" 
                size="sm"
                className="bg-white"
                disabled={loading}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <div className="text-5xl font-bold text-amber-900">
                  {loading ? (
                    <span className="text-gray-400">Loading...</span>
                  ) : spotPrice > 0 ? (
                    `$${spotPrice.toFixed(2)}`
                  ) : (
                    <span className="text-red-600">Error</span>
                  )}
                </div>
                <p className="text-sm text-gray-600">
                  Per troy ounce • Last updated: {lastUpdated || "Never"}
                </p>
              </div>
              
              <div className="flex flex-col gap-2">
                <Label htmlFor="manual-price" className="text-xs text-gray-600">Manual Override</Label>
                <div className="flex gap-2">
                  <Input
                    id="manual-price"
                    type="number"
                    placeholder="Enter price"
                    value={manualPrice}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setManualPrice(e.target.value)}
                    className="w-32 bg-white"
                  />
                  <Button onClick={handleManualUpdate} size="sm">Set</Button>
                </div>
              </div>
            </div>

            {spotPrice > 0 && (
              <div className="mt-4 grid grid-cols-3 gap-4 text-center">
                <div className="bg-white p-3 rounded-lg">
                  <p className="text-xs text-gray-600">1/10 oz Melt</p>
                  <p className="text-lg font-bold text-amber-900">${(spotPrice * 0.1).toFixed(2)}</p>
                </div>
                <div className="bg-white p-3 rounded-lg">
                  <p className="text-xs text-gray-600">1/4 oz Melt</p>
                  <p className="text-lg font-bold text-amber-900">${(spotPrice * 0.25).toFixed(2)}</p>
                </div>
                <div className="bg-white p-3 rounded-lg">
                  <p className="text-xs text-gray-600">1/2 oz Melt</p>
                  <p className="text-lg font-bold text-amber-900">${(spotPrice * 0.5).toFixed(2)}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Main Tabs */}
        <Tabs defaultValue="live" className="w-full">
          <TabsList className="grid w-full grid-cols-6 bg-amber-200">
            <TabsTrigger value="live" className="data-[state=active]:bg-white">
              <TrendingUp className="h-4 w-4 mr-2" />
              Live Prices
            </TabsTrigger>
            <TabsTrigger value="ai" className="data-[state=active]:bg-white">
              <Sparkles className="h-4 w-4 mr-2" />
              AI Insights
            </TabsTrigger>
            <TabsTrigger value="lookup" className="data-[state=active]:bg-white">
              <Search className="h-4 w-4 mr-2" />
              Dealer Lookup
            </TabsTrigger>
            <TabsTrigger value="analyze" className="data-[state=active]:bg-white">
              <Coins className="h-4 w-4 mr-2" />
              Analyze Deal
            </TabsTrigger>
            <TabsTrigger value="alerts" className="data-[state=active]:bg-white">
              <Bell className="h-4 w-4 mr-2" />
              Alerts
            </TabsTrigger>
            <TabsTrigger value="integrations" className="data-[state=active]:bg-white">
              <Settings className="h-4 w-4 mr-2" />
              Integrations
            </TabsTrigger>
          </TabsList>

          <TabsContent value="live" className="space-y-4">
            <LiveFractionalGoldDashboard spotPrice={spotPrice} />
          </TabsContent>

          <TabsContent value="lookup" className="space-y-4">
            <DealerLookup />
          </TabsContent>

          <TabsContent value="ai" className="space-y-4">
            <Card className="border-purple-200 bg-gradient-to-r from-purple-50 to-pink-50">
              <CardHeader>
                <CardTitle className="text-purple-900 flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5" />
                    Real-Time Market Intelligence
                    {aiInsightsLoading && <Zap className="h-4 w-4 animate-pulse text-yellow-500" />}
                  </span>
                  <Button 
                    onClick={handleRefreshAIInsights} 
                    variant="outline" 
                    size="sm"
                    className="bg-white"
                    disabled={aiInsightsLoading}
                  >
                    <RefreshCw className={`h-4 w-4 mr-2 ${aiInsightsLoading ? 'animate-spin' : ''}`} />
                    Refresh Insights
                  </Button>
                </CardTitle>
                <CardDescription className="flex items-center justify-between">
                  <span>AI-powered insights updated continuously based on live market data</span>
                  <span className="text-xs text-purple-600">
                    Last updated: {aiInsightsLastUpdated || "Just now"}
                  </span>
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className={`bg-white p-4 rounded-lg border-2 ${
                    marketSentiment.color === 'green' ? 'border-green-200' : 
                    marketSentiment.color === 'blue' ? 'border-blue-200' : 
                    'border-red-200'
                  }`}>
                    <p className="text-xs text-gray-600 mb-1">Market Sentiment</p>
                    <p className={`text-2xl font-bold ${
                      marketSentiment.color === 'green' ? 'text-green-600' : 
                      marketSentiment.color === 'blue' ? 'text-blue-600' : 
                      'text-red-600'
                    }`}>{marketSentiment.sentiment}</p>
                    <p className="text-xs text-gray-500 mt-1">{marketSentiment.description}</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg border-2 border-blue-200">
                    <p className="text-xs text-gray-600 mb-1">Premium Trend</p>
                    <p className="text-2xl font-bold text-blue-600">Stable</p>
                    <p className="text-xs text-gray-500 mt-1">±2% from average</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg border-2 border-amber-200">
                    <p className="text-xs text-gray-600 mb-1">Best Value</p>
                    <p className="text-2xl font-bold text-amber-600">
                      {spotPrice > 2600 ? "1/10 oz" : spotPrice < 2500 ? "1/2 oz" : "1 oz"}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">Lowest premium ratio</p>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg border-2 border-indigo-200">
                  <h3 className="font-bold text-indigo-900 mb-2">Market Analysis</h3>
                  <ul className="space-y-2 text-sm text-gray-700">
                    <li>• Fractional gold premiums averaging 12-18% across major dealers</li>
                    <li>• {spotPrice > 2600 ? "1/10 oz pieces showing strongest demand with quick turnover" : "1/2 oz pieces offering excellent value at current spot levels"}</li>
                    <li>• Secondary market spreads {spotPrice > 2650 ? "widening - increased volatility" : "tightening - good liquidity conditions"}</li>
                    <li>• Spot price at ${spotPrice.toFixed(2)} - {spotPrice > 2700 ? "elevated levels, monitor closely" : spotPrice > 2500 ? "stable accumulation window" : "attractive entry point"}</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <AIRecommendations recommendations={aiRecommendations} />
          </TabsContent>

          <TabsContent value="analyze" className="space-y-4">
            <CustomDealAnalyzer spotPrice={spotPrice} />
          </TabsContent>

          <TabsContent value="alerts" className="space-y-4">
            <DealAlerts spotPrice={spotPrice} />
          </TabsContent>

          <TabsContent value="integrations" className="space-y-4">
            <IntegrationSettings />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
