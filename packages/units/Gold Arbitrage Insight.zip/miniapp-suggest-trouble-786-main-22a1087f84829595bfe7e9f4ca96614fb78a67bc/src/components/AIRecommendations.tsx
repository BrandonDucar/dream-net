'use client'
import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkles, TrendingUp, TrendingDown, Minus } from "lucide-react";
import type { PortfolioRecommendation } from "@/types/gold";

interface AIRecommendationsProps {
  recommendations: PortfolioRecommendation[];
}

export function AIRecommendations({ recommendations }: AIRecommendationsProps): JSX.Element {
  if (recommendations.length === 0) {
    return (
      <Card className="border-amber-200">
        <CardContent className="pt-6 text-center text-gray-500">
          No recommendations available yet. Analyze some items to get AI-powered insights.
        </CardContent>
      </Card>
    );
  }

  const getActionIcon = (action: string): JSX.Element => {
    switch (action) {
      case "BUY": return <TrendingUp className="h-4 w-4" />;
      case "SELL": return <TrendingDown className="h-4 w-4" />;
      default: return <Minus className="h-4 w-4" />;
    }
  };

  const getActionColor = (action: string): string => {
    switch (action) {
      case "BUY": return "bg-green-600";
      case "SELL": return "bg-red-600";
      default: return "bg-gray-600";
    }
  };

  const getUrgencyColor = (urgency: string): string => {
    switch (urgency) {
      case "HIGH": return "border-red-500 bg-red-50";
      case "MEDIUM": return "border-yellow-500 bg-yellow-50";
      default: return "border-blue-500 bg-blue-50";
    }
  };

  return (
    <Card className="border-amber-200 shadow-lg">
      <CardHeader>
        <CardTitle className="text-amber-900 flex items-center gap-2">
          <Sparkles className="h-5 w-5" />
          AI-Powered Recommendations
        </CardTitle>
        <CardDescription>
          Smart insights based on market trends and your portfolio
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {recommendations.map((rec: PortfolioRecommendation, index: number) => (
          <Card key={index} className={`border-2 ${getUrgencyColor(rec.urgency)}`}>
            <CardContent className="pt-4">
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                  <Badge className={getActionColor(rec.action)}>
                    {getActionIcon(rec.action)}
                    <span className="ml-1">{rec.action}</span>
                  </Badge>
                  <span className="font-bold text-gray-900">{rec.weightType} oz</span>
                </div>
                <Badge variant="outline" className="font-semibold">
                  {rec.urgency}
                </Badge>
              </div>
              
              <p className="text-sm text-gray-700 mb-2">{rec.reasoning}</p>
              
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600">Expected Return:</span>
                <span className={`font-semibold ${rec.expectedReturn > 0 ? "text-green-600" : "text-red-600"}`}>
                  {rec.expectedReturn > 0 ? "+" : ""}{rec.expectedReturn.toFixed(2)}%
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </CardContent>
    </Card>
  );
}
