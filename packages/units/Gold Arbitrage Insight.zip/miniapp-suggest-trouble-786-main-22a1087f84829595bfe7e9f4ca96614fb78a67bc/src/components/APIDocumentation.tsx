"use client";

import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

export default function APIDocumentation() {
  return (
    <Card className="bg-gradient-to-br from-amber-950/20 to-yellow-950/20 border-amber-700/30">
      <CardHeader>
        <CardTitle className="text-2xl text-amber-100">📚 API Documentation</CardTitle>
        <CardDescription className="text-amber-100/90 text-base">
          Complete guide for integrating with your Gold Arbitrage platform
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="outgoing" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-black/40">
            <TabsTrigger value="outgoing" className="data-[state=active]:bg-amber-600 data-[state=active]:text-white text-amber-200 font-semibold">Outgoing Webhooks</TabsTrigger>
            <TabsTrigger value="incoming" className="data-[state=active]:bg-amber-600 data-[state=active]:text-white text-amber-200 font-semibold">Incoming API</TabsTrigger>
            <TabsTrigger value="examples" className="data-[state=active]:bg-amber-600 data-[state=active]:text-white text-amber-200 font-semibold">Examples</TabsTrigger>
          </TabsList>

          {/* Outgoing Webhooks */}
          <TabsContent value="outgoing" className="space-y-4 mt-4">
            <Card className="bg-black/40 border-amber-700/20">
              <CardHeader>
                <CardTitle className="text-lg text-amber-100">Webhook Events</CardTitle>
                <CardDescription className="text-amber-100/85 text-base">
                  Your webhooks will receive POST requests for these events
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <EventDoc
                  event="analysis_created"
                  description="Triggered whenever a new arbitrage analysis is completed"
                  payload={{
                    event: "analysis_created",
                    timestamp: 1704067200000,
                    data: {
                      id: "1704067200000",
                      weightType: "1/4",
                      weightOz: 0.25,
                      purchasePrice: 650,
                      meltValue: 625,
                      premiumPct: 4.0,
                      arbitrageScore: 85,
                      recommendation: "BUY"
                    }
                  }}
                />

                <EventDoc
                  event="deal_found"
                  description="Triggered when a high-score opportunity (>70) is identified"
                  payload={{
                    event: "deal_found",
                    timestamp: 1704067200000,
                    data: {
                      weightType: "1/2",
                      arbitrageScore: 92,
                      dealer: "APMEX",
                      savings: 45.50
                    }
                  }}
                />

                <EventDoc
                  event="alert_triggered"
                  description="Triggered when a user's custom deal alert conditions are met"
                  payload={{
                    event: "alert_triggered",
                    timestamp: 1704067200000,
                    data: {
                      alertId: "12345",
                      weightType: "1/10",
                      targetScore: 75,
                      actualScore: 78,
                      message: "Your alert for 1/10 oz was triggered!"
                    }
                  }}
                />

                <EventDoc
                  event="portfolio_updated"
                  description="Triggered when portfolio holdings change"
                  payload={{
                    event: "portfolio_updated",
                    timestamp: 1704067200000,
                    data: {
                      totalValue: 15000,
                      totalGain: 1200,
                      items: 24
                    }
                  }}
                />

                <EventDoc
                  event="price_changed"
                  description="Triggered when gold spot price changes significantly (>1%)"
                  payload={{
                    event: "price_changed",
                    timestamp: 1704067200000,
                    data: {
                      previousPrice: 2500,
                      currentPrice: 2530,
                      changePercent: 1.2,
                      direction: "UP"
                    }
                  }}
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Incoming API */}
          <TabsContent value="incoming" className="space-y-4 mt-4">
            <Card className="bg-black/40 border-amber-700/20">
              <CardHeader>
                <CardTitle className="text-lg text-amber-100">Push Data to Platform</CardTitle>
                <CardDescription className="text-amber-100/85 text-base">
                  Send data from external systems into your platform
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className="bg-green-900/50 text-green-100">POST</Badge>
                    <code className="text-amber-200 bg-black/40 px-2 py-1 rounded text-sm">
                      /api/webhook
                    </code>
                  </div>
                  <p className="text-amber-100/90 text-base">
                    Receive data from external systems like Zapier, Make, or custom apps
                  </p>
                </div>

                <div>
                  <div className="text-amber-200 font-semibold mb-2">Headers</div>
                  <CodeBlock
                    code={`Content-Type: application/json
Authorization: Bearer YOUR_API_KEY`}
                  />
                </div>

                <div>
                  <div className="text-amber-200 font-semibold mb-2">Request Body</div>
                  <CodeBlock
                    code={`{
  "event": "external_deal_found",
  "data": {
    "weightType": "1/4",
    "price": 600,
    "dealer": "Local Coin Shop",
    "location": "New York"
  }
}`}
                  />
                </div>

                <div>
                  <div className="text-amber-200 font-semibold mb-2">Response</div>
                  <CodeBlock
                    code={`{
  "success": true,
  "message": "Webhook received successfully",
  "receivedAt": "2024-01-01T00:00:00.000Z",
  "event": "external_deal_found"
}`}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Examples */}
          <TabsContent value="examples" className="space-y-4 mt-4">
            <Card className="bg-black/40 border-amber-700/20">
              <CardHeader>
                <CardTitle className="text-lg text-amber-100">Integration Examples</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <ExampleIntegration
                  title="Google Sheets"
                  description="Log all analyses to a spreadsheet"
                  code={`// Apps Script in Google Sheets
function doPost(e) {
  const data = JSON.parse(e.postData.contents);
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Analyses");
  
  sheet.appendRow([
    new Date(data.timestamp),
    data.data.weightType,
    data.data.purchasePrice,
    data.data.arbitrageScore,
    data.data.recommendation
  ]);
  
  return ContentService.createTextOutput(JSON.stringify({success: true}));
}`}
                />

                <ExampleIntegration
                  title="Slack Notification"
                  description="Get alerts in Slack when hot deals are found"
                  code={`// Webhook receiver that posts to Slack
const webhook = 'https://hooks.slack.com/services/YOUR/WEBHOOK/URL';

fetch(webhook, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    text: \`🔥 Hot Deal Found!
    Weight: \${data.weightType}
    Score: \${data.arbitrageScore}
    Savings: $\${data.savings}\`
  })
});`}
                />

                <ExampleIntegration
                  title="Discord Bot"
                  description="Post opportunities to Discord channel"
                  code={`// Discord webhook integration
const discordWebhook = 'YOUR_DISCORD_WEBHOOK_URL';

if (data.event === 'deal_found' && data.data.arbitrageScore > 80) {
  fetch(discordWebhook, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      embeds: [{
        title: '💰 High-Score Gold Opportunity',
        color: 15844367,
        fields: [
          { name: 'Weight', value: data.data.weightType },
          { name: 'Score', value: data.data.arbitrageScore.toString() },
          { name: 'Dealer', value: data.data.dealer }
        ]
      }]
    })
  });
}`}
                />

                <ExampleIntegration
                  title="Airtable Database"
                  description="Store all analyses in Airtable"
                  code={`// Airtable API integration
const AIRTABLE_TOKEN = 'YOUR_TOKEN';
const BASE_ID = 'YOUR_BASE_ID';
const TABLE_ID = 'YOUR_TABLE_ID';

fetch(\`https://api.airtable.com/v0/\${BASE_ID}/\${TABLE_ID}\`, {
  method: 'POST',
  headers: {
    'Authorization': \`Bearer \${AIRTABLE_TOKEN}\`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    fields: {
      'Weight': data.data.weightType,
      'Score': data.data.arbitrageScore,
      'Price': data.data.purchasePrice,
      'Recommendation': data.data.recommendation,
      'Date': new Date().toISOString()
    }
  })
});`}
                />

                <ExampleIntegration
                  title="Python Script"
                  description="Process webhook data with Python"
                  code={`import requests
from flask import Flask, request

app = Flask(__name__)

@app.route('/webhook', methods=['POST'])
def handle_webhook():
    data = request.json
    
    if data['event'] == 'analysis_created':
        score = data['data']['arbitrageScore']
        
        if score > 75:
            # Send email notification
            send_email(
                subject=f"Hot Deal: Score {score}",
                body=f"Found {data['data']['weightType']} opportunity"
            )
    
    return {'success': True}

if __name__ == '__main__':
    app.run(port=5000)`}
                />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

function EventDoc({ event, description, payload }: { 
  event: string; 
  description: string; 
  payload: Record<string, unknown>;
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <Badge className="bg-amber-900/50 text-amber-100">{event}</Badge>
      </div>
      <p className="text-amber-100/90 text-base">{description}</p>
      <CodeBlock code={JSON.stringify(payload, null, 2)} />
    </div>
  );
}

function CodeBlock({ code }: { code: string }) {
  return (
    <pre className="bg-black/60 p-4 rounded-lg overflow-x-auto border border-amber-700/30">
      <code className="text-amber-200/90 text-xs font-mono whitespace-pre">
        {code}
      </code>
    </pre>
  );
}

function ExampleIntegration({ title, description, code }: {
  title: string;
  description: string;
  code: string;
}) {
  return (
    <div className="space-y-2">
      <div>
        <h3 className="text-lg font-semibold text-amber-100">{title}</h3>
        <p className="text-amber-100/90 text-base">{description}</p>
      </div>
      <CodeBlock code={code} />
    </div>
  );
}
