'use client'
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Calculator, TrendingUp, TrendingDown } from "lucide-react";
import { calcMelt, calcPremium, calcResaleMargin, calcArbitrageScore, getRecommendation, weightToOz } from "@/lib/calc";

interface CustomDealAnalyzerProps {
  spotPrice: number;
}

interface AnalysisResult {
  weightType: string;
  weightOz: number;
  purchasePrice: number;
  meltValue: number;
  premiumPct: number;
  resaleMargin: number;
  arbitrageScore: number;
  recommendation: "BUY" | "PASS";
}

export function CustomDealAnalyzer({ spotPrice }: CustomDealAnalyzerProps): JSX.Element {
  const [weightType, setWeightType] = useState<string>("1/10");
  const [purchasePrice, setPurchasePrice] = useState<string>("");
  const [marketComp, setMarketComp] = useState<string>("");
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const handleAnalyze = (): void => {
    if (!purchasePrice || spotPrice === 0) return;

    const weightOz = weightToOz(weightType);
    const purchase = parseFloat(purchasePrice);
    const comp = marketComp ? parseFloat(marketComp) : purchase * 1.05;

    const melt = calcMelt(weightOz, spotPrice);
    const premium = calcPremium(purchase, melt);
    const margin = calcResaleMargin(purchase, comp);
    const score = calcArbitrageScore(premium, margin);
    const rec = getRecommendation(score);

    setResult({
      weightType,
      weightOz,
      purchasePrice: purchase,
      meltValue: melt,
      premiumPct: premium,
      resaleMargin: margin,
      arbitrageScore: score,
      recommendation: rec
    });
  };

  return (
    <div className="space-y-4">
      <Card className="border-blue-200 shadow-lg">
        <CardHeader>
          <CardTitle className="text-blue-900 flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Custom Deal Analyzer
          </CardTitle>
          <CardDescription>
            Found a specific deal? Analyze it here to see if it's worth buying
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="weight-type">Gold Piece Weight</Label>
              <Select value={weightType} onValueChange={setWeightType}>
                <SelectTrigger id="weight-type" className="bg-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1/10">1/10 oz</SelectItem>
                  <SelectItem value="1/4">1/4 oz</SelectItem>
                  <SelectItem value="1/2">1/2 oz</SelectItem>
                  <SelectItem value="2g">2g</SelectItem>
                  <SelectItem value="5g">5g</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="purchase-price">Purchase Price ($)</Label>
              <Input
                id="purchase-price"
                type="number"
                placeholder="0.00"
                value={purchasePrice}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPurchasePrice(e.target.value)}
                className="bg-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="market-comp">Market Comp ($) <span className="text-xs text-gray-500">(Optional)</span></Label>
              <Input
                id="market-comp"
                type="number"
                placeholder="0.00"
                value={marketComp}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setMarketComp(e.target.value)}
                className="bg-white"
              />
            </div>
          </div>

          <Button 
            onClick={handleAnalyze} 
            className="w-full bg-blue-600 hover:bg-blue-700"
            disabled={!purchasePrice || spotPrice === 0}
          >
            <Calculator className="h-4 w-4 mr-2" />
            Analyze This Deal
          </Button>
        </CardContent>
      </Card>

      {result && (
        <Card className={`border-2 ${result.recommendation === "BUY" ? "border-green-300 bg-green-50" : "border-red-300 bg-red-50"}`}>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-gray-900">Analysis Result</CardTitle>
              <Badge 
                className={`text-lg px-4 py-2 ${
                  result.recommendation === "BUY" 
                    ? "bg-green-600" 
                    : "bg-red-600"
                }`}
              >
                {result.recommendation === "BUY" ? (
                  <TrendingUp className="h-5 w-5 mr-2" />
                ) : (
                  <TrendingDown className="h-5 w-5 mr-2" />
                )}
                {result.recommendation}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white p-3 rounded-lg border border-gray-200">
                <p className="text-xs text-gray-600 mb-1">Purchase Price</p>
                <p className="text-xl font-bold text-gray-900">${result.purchasePrice.toFixed(2)}</p>
              </div>
              <div className="bg-white p-3 rounded-lg border border-gray-200">
                <p className="text-xs text-gray-600 mb-1">Melt Value</p>
                <p className="text-xl font-bold text-amber-700">${result.meltValue.toFixed(2)}</p>
              </div>
              <div className="bg-white p-3 rounded-lg border border-gray-200">
                <p className="text-xs text-gray-600 mb-1">Premium</p>
                <p className={`text-xl font-bold ${result.premiumPct > 15 ? "text-red-600" : "text-green-600"}`}>
                  {result.premiumPct.toFixed(1)}%
                </p>
              </div>
              <div className="bg-white p-3 rounded-lg border border-gray-200">
                <p className="text-xs text-gray-600 mb-1">Arbitrage Score</p>
                <p className="text-xl font-bold text-blue-600">{result.arbitrageScore}/100</p>
              </div>
            </div>

            <div className="bg-white p-4 rounded-lg border-2 border-gray-200">
              <h3 className="font-bold text-gray-900 mb-2">Deal Breakdown</h3>
              <ul className="text-sm text-gray-700 space-y-1">
                <li>• You're buying {result.weightType} oz of gold for ${result.purchasePrice.toFixed(2)}</li>
                <li>• The actual gold content is worth ${result.meltValue.toFixed(2)} (melt value)</li>
                <li>• You're paying a {result.premiumPct.toFixed(1)}% premium over melt</li>
                <li>• Estimated resale margin: ${result.resaleMargin.toFixed(2)}</li>
                <li className="font-semibold mt-2">
                  {result.recommendation === "BUY" 
                    ? "✅ This is a good deal - the premium is reasonable and arbitrage score is strong"
                    : "⚠️ This deal has a high premium - you may want to wait for a better opportunity"
                  }
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
