'use client'
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Bell, Plus, Trash2 } from "lucide-react";

interface DealAlertsProps {
  spotPrice: number;
}

interface Alert {
  id: string;
  weightType: string;
  targetPremium: number;
  active: boolean;
}

export function DealAlerts({ spotPrice }: DealAlertsProps): JSX.Element {
  const [alerts, setAlerts] = useState<Alert[]>([
    { id: "1", weightType: "1/10 oz", targetPremium: 12, active: true },
    { id: "2", weightType: "1/4 oz", targetPremium: 10, active: true }
  ]);
  const [newWeightType, setNewWeightType] = useState<string>("1/10");
  const [newTargetPremium, setNewTargetPremium] = useState<string>("");

  const handleAddAlert = (): void => {
    if (!newTargetPremium) return;

    const newAlert: Alert = {
      id: Date.now().toString(),
      weightType: newWeightType === "1/10" ? "1/10 oz" : newWeightType === "1/4" ? "1/4 oz" : "1/2 oz",
      targetPremium: parseFloat(newTargetPremium),
      active: true
    };

    setAlerts([...alerts, newAlert]);
    setNewTargetPremium("");
  };

  const handleDeleteAlert = (id: string): void => {
    setAlerts(alerts.filter((alert: Alert) => alert.id !== id));
  };

  const toggleAlert = (id: string): void => {
    setAlerts(alerts.map((alert: Alert) => 
      alert.id === id ? { ...alert, active: !alert.active } : alert
    ));
  };

  return (
    <div className="space-y-4">
      <Card className="border-blue-200 shadow-lg">
        <CardHeader>
          <CardTitle className="text-blue-900 flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Price Alerts
          </CardTitle>
          <CardDescription>
            Get notified when fractional gold pieces hit your target premiums
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-blue-50 border-2 border-blue-200 rounded-lg">
            <h3 className="font-bold text-blue-900 mb-2">📱 Active Monitoring</h3>
            <p className="text-sm text-gray-700">
              Alerts are monitored continuously. When market prices match your targets, you'll be notified via your preferred method.
            </p>
          </div>

          <div className="space-y-3">
            {alerts.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Bell className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                <p>No alerts set up yet</p>
                <p className="text-sm">Create your first alert below</p>
              </div>
            ) : (
              alerts.map((alert: Alert) => (
                <Card key={alert.id} className={`border-2 ${alert.active ? "border-green-200 bg-green-50" : "border-gray-200 bg-gray-50"}`}>
                  <CardContent className="pt-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-bold text-gray-900">{alert.weightType}</span>
                          <Badge variant={alert.active ? "default" : "secondary"}>
                            {alert.active ? "Active" : "Paused"}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600">
                          Alert when premium drops to <span className="font-semibold">{alert.targetPremium}%</span> or below
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => toggleAlert(alert.id)}
                        >
                          {alert.active ? "Pause" : "Resume"}
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDeleteAlert(alert.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="border-amber-200">
        <CardHeader>
          <CardTitle className="text-amber-900">Create New Alert</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="alert-weight">Gold Piece Weight</Label>
              <Select value={newWeightType} onValueChange={setNewWeightType}>
                <SelectTrigger id="alert-weight" className="bg-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1/10">1/10 oz</SelectItem>
                  <SelectItem value="1/4">1/4 oz</SelectItem>
                  <SelectItem value="1/2">1/2 oz</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="alert-premium">Target Premium (%)</Label>
              <Input
                id="alert-premium"
                type="number"
                placeholder="e.g., 10"
                value={newTargetPremium}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewTargetPremium(e.target.value)}
                className="bg-white"
              />
            </div>
          </div>

          <Button onClick={handleAddAlert} className="w-full bg-amber-600 hover:bg-amber-700" disabled={!newTargetPremium}>
            <Plus className="h-4 w-4 mr-2" />
            Create Alert
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
