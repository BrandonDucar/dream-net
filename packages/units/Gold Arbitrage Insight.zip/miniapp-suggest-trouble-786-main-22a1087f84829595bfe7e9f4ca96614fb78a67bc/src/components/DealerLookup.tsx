'use client'
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Search, Copy, Check } from "lucide-react";

interface DealerProduct {
  dealer: string;
  productName: string;
  weight: string;
  searchUrl: string;
  dealerUrl: string;
  dealerLogo?: string;
}

const MAJOR_DEALERS = [
  {
    name: "APMEX",
    baseUrl: "https://www.apmex.com",
    searchUrl: "https://www.apmex.com/search?q=",
    color: "blue"
  },
  {
    name: "JM Bullion",
    baseUrl: "https://www.jmbullion.com",
    searchUrl: "https://www.jmbullion.com/search/?q=",
    color: "green"
  },
  {
    name: "SD Bullion",
    baseUrl: "https://sdbullion.com",
    searchUrl: "https://sdbullion.com/search?type=product&q=",
    color: "orange"
  },
  {
    name: "Money Metals",
    baseUrl: "https://www.moneymetals.com",
    searchUrl: "https://www.moneymetals.com/search?q=",
    color: "purple"
  },
  {
    name: "Golden State Mint",
    baseUrl: "https://www.goldenstatemint.com",
    searchUrl: "https://www.goldenstatemint.com/search.php?search_query=",
    color: "amber"
  }
];

const FRACTIONAL_WEIGHTS = [
  { label: "1/10 oz Gold Eagle", value: "1/10 oz american gold eagle" },
  { label: "1/10 oz Gold Maple Leaf", value: "1/10 oz gold maple leaf" },
  { label: "1/10 oz Gold Buffalo", value: "1/10 oz gold buffalo" },
  { label: "1/4 oz Gold Eagle", value: "1/4 oz american gold eagle" },
  { label: "1/4 oz Gold Maple Leaf", value: "1/4 oz gold maple leaf" },
  { label: "1/2 oz Gold Eagle", value: "1/2 oz american gold eagle" },
  { label: "1/2 oz Gold Maple Leaf", value: "1/2 oz gold maple leaf" },
  { label: "2 gram Gold Bar", value: "2 gram gold bar" },
  { label: "5 gram Gold Bar", value: "5 gram gold bar" },
  { label: "10 gram Gold Bar", value: "10 gram gold bar" },
  { label: "1 oz Gold Bar", value: "1 oz gold bar" },
  { label: "1 oz Gold Eagle", value: "1 oz american gold eagle" },
];

export function DealerLookup(): JSX.Element {
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [customSearch, setCustomSearch] = useState<string>("");
  const [copiedUrl, setCopiedUrl] = useState<string>("");

  const handleQuickSearch = (weight: string): void => {
    setSearchTerm(weight);
  };

  const generateDealerUrls = (query: string): DealerProduct[] => {
    return MAJOR_DEALERS.map(dealer => ({
      dealer: dealer.name,
      productName: query,
      weight: query,
      searchUrl: `${dealer.searchUrl}${encodeURIComponent(query)}`,
      dealerUrl: dealer.baseUrl,
    }));
  };

  const copyToClipboard = async (url: string): Promise<void> => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedUrl(url);
      setTimeout(() => setCopiedUrl(""), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const resultsToShow = searchTerm || customSearch;
  const dealerResults = resultsToShow ? generateDealerUrls(resultsToShow) : [];

  return (
    <Card className="border-indigo-200 bg-gradient-to-r from-indigo-50 to-blue-50">
      <CardHeader>
        <CardTitle className="text-indigo-900 flex items-center gap-2">
          <Search className="h-5 w-5" />
          Dealer URL Lookup
        </CardTitle>
        <CardDescription className="text-gray-700">
          Instantly find fractional gold products across major dealers
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Quick Search Buttons */}
        <div className="space-y-3">
          <Label className="text-sm font-semibold text-gray-700">Quick Search - Common Products</Label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {FRACTIONAL_WEIGHTS.map((weight) => (
              <Button
                key={weight.value}
                onClick={() => handleQuickSearch(weight.value)}
                variant={searchTerm === weight.value ? "default" : "outline"}
                size="sm"
                className="text-xs"
              >
                {weight.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Custom Search */}
        <div className="space-y-2">
          <Label htmlFor="custom-search" className="text-sm font-semibold text-gray-700">
            Or Enter Custom Search
          </Label>
          <div className="flex gap-2">
            <Input
              id="custom-search"
              type="text"
              placeholder="e.g., 1/10 oz gold krugerrand"
              value={customSearch}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                setCustomSearch(e.target.value);
                setSearchTerm("");
              }}
              className="flex-1 bg-white"
            />
            <Button 
              onClick={() => setSearchTerm(customSearch)}
              disabled={!customSearch}
            >
              <Search className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Results */}
        {dealerResults.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-semibold text-gray-700">
                Search Results for: "{resultsToShow}"
              </Label>
              <Badge variant="secondary" className="bg-indigo-100 text-indigo-900">
                {dealerResults.length} Dealers
              </Badge>
            </div>

            <div className="space-y-2">
              {dealerResults.map((product, index) => (
                <Card key={index} className="bg-white border-gray-200">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold text-gray-900">{product.dealer}</h3>
                          <Badge variant="outline" className="text-xs">
                            {product.dealer.toLowerCase().includes('apmex') ? 'Most Popular' : 
                             product.dealer.toLowerCase().includes('jm') ? 'Best Prices' :
                             product.dealer.toLowerCase().includes('sd') ? 'Fast Shipping' :
                             product.dealer.toLowerCase().includes('money') ? 'Low Minimums' :
                             'Trusted Dealer'}
                          </Badge>
                        </div>
                        <p className="text-xs text-gray-600 break-all">{product.searchUrl}</p>
                      </div>
                      <div className="flex gap-2 ml-4">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => copyToClipboard(product.searchUrl)}
                          className="shrink-0"
                        >
                          {copiedUrl === product.searchUrl ? (
                            <Check className="h-4 w-4 text-green-600" />
                          ) : (
                            <Copy className="h-4 w-4" />
                          )}
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => window.open(product.searchUrl, '_blank')}
                          className="shrink-0"
                        >
                          Visit <ExternalLink className="h-4 w-4 ml-1" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-4">
              <p className="text-sm text-blue-900 font-semibold mb-2">💡 Pro Tips:</p>
              <ul className="text-xs text-blue-800 space-y-1">
                <li>• Click "Visit" to open the search results in a new tab</li>
                <li>• Use the copy button to save URLs for later comparison</li>
                <li>• Check multiple dealers to find the best premium</li>
                <li>• Compare prices with the melt values in the Live Prices tab</li>
              </ul>
            </div>
          </div>
        )}

        {/* No Results State */}
        {!dealerResults.length && (
          <div className="text-center py-8 text-gray-500">
            <Search className="h-12 w-12 mx-auto mb-3 text-gray-400" />
            <p className="text-sm">Select a product or enter a custom search to find dealer links</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
