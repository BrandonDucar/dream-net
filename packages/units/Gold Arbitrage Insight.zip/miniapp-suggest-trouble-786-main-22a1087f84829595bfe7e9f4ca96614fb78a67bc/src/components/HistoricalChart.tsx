'use client'
import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart } from "lucide-react";
import type { HistoricalPremium } from "@/types/gold";

interface HistoricalChartProps {
  data: HistoricalPremium[];
  weightType: string;
}

export function HistoricalChart({ data, weightType }: HistoricalChartProps): JSX.Element {
  const filteredData = data.filter(d => d.weightType === weightType).slice(-30);
  
  if (filteredData.length === 0) {
    return (
      <Card className="border-amber-200">
        <CardContent className="pt-6 text-center text-gray-500">
          No historical data available for {weightType} oz yet.
        </CardContent>
      </Card>
    );
  }

  const maxPremium = Math.max(...filteredData.map(d => d.premiumPct));
  const minPremium = Math.min(...filteredData.map(d => d.premiumPct));
  const avgPremium = filteredData.reduce((sum, d) => sum + d.premiumPct, 0) / filteredData.length;
  
  const chartHeight = 200;
  const chartWidth = 800;
  const padding = 40;
  
  // Calculate points for the line chart
  const points = filteredData.map((d, i) => {
    const x = padding + (i / (filteredData.length - 1)) * (chartWidth - 2 * padding);
    const y = chartHeight - padding - ((d.premiumPct - minPremium) / (maxPremium - minPremium)) * (chartHeight - 2 * padding);
    return { x, y, premium: d.premiumPct, date: d.date };
  });
  
  const pathD = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');

  return (
    <Card className="border-amber-200 shadow-lg">
      <CardHeader>
        <CardTitle className="text-amber-900 flex items-center gap-2">
          <LineChart className="h-5 w-5" />
          Premium History - {weightType} oz (Last 30 Days)
        </CardTitle>
        <CardDescription>
          Track premium trends over time
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="mb-4 grid grid-cols-3 gap-4 text-sm">
          <div>
            <p className="text-gray-600">Current</p>
            <p className="text-lg font-semibold text-gray-900">
              {filteredData[filteredData.length - 1].premiumPct.toFixed(2)}%
            </p>
          </div>
          <div>
            <p className="text-gray-600">Average</p>
            <p className="text-lg font-semibold text-gray-900">
              {avgPremium.toFixed(2)}%
            </p>
          </div>
          <div>
            <p className="text-gray-600">Range</p>
            <p className="text-lg font-semibold text-gray-900">
              {minPremium.toFixed(1)}% - {maxPremium.toFixed(1)}%
            </p>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <svg width={chartWidth} height={chartHeight} className="border border-gray-200 rounded">
            {/* Grid lines */}
            {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
              const y = chartHeight - padding - ratio * (chartHeight - 2 * padding);
              const value = minPremium + ratio * (maxPremium - minPremium);
              return (
                <g key={ratio}>
                  <line
                    x1={padding}
                    y1={y}
                    x2={chartWidth - padding}
                    y2={y}
                    stroke="#e5e7eb"
                    strokeWidth="1"
                  />
                  <text x={padding - 5} y={y + 4} textAnchor="end" fontSize="10" fill="#6b7280">
                    {value.toFixed(1)}%
                  </text>
                </g>
              );
            })}
            
            {/* Chart line */}
            <path
              d={pathD}
              fill="none"
              stroke="#d97706"
              strokeWidth="2"
            />
            
            {/* Data points */}
            {points.map((p, i) => (
              <circle
                key={i}
                cx={p.x}
                cy={p.y}
                r="3"
                fill="#d97706"
              >
                <title>{`${new Date(p.date).toLocaleDateString()}: ${p.premium.toFixed(2)}%`}</title>
              </circle>
            ))}
          </svg>
        </div>
        
        <p className="text-xs text-gray-500 mt-2">
          * Premium calculated as (Market Price / Melt Value - 1) × 100
        </p>
      </CardContent>
    </Card>
  );
}
