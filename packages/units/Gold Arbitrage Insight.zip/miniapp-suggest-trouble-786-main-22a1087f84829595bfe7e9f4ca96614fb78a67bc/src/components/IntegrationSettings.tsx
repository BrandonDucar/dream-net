"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  getWebhooks, 
  saveWebhook, 
  deleteWebhook, 
  testWebhook,
  getWebhookLogs,
  INTEGRATION_TEMPLATES,
  type WebhookConfig,
  type IntegrationTemplate
} from "@/lib/integrations";

// Import dedicated setup components
import GoogleSheetsSetup from "./integrations/GoogleSheetsSetup";
import SalesforceSetup from "./integrations/SalesforceSetup";
import HubSpotSetup from "./integrations/HubSpotSetup";
import AirtableSetup from "./integrations/AirtableSetup";
import NotionSetup from "./integrations/NotionSetup";
import ZapierSetup from "./integrations/ZapierSetup";

export default function IntegrationSettings() {
  const [webhooks, setWebhooks] = useState<WebhookConfig[]>([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string | null>(null);
  const [testingWebhook, setTestingWebhook] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<Record<string, boolean>>({});

  useEffect(() => {
    loadWebhooks();
  }, []);

  function loadWebhooks() {
    setWebhooks(getWebhooks());
  }

  function handleTemplateSelect(templateId: string) {
    setSelectedTemplateId(templateId);
  }

  async function handleTestWebhook(webhookId: string) {
    setTestingWebhook(webhookId);
    const webhook = webhooks.find(w => w.id === webhookId);
    
    if (webhook) {
      const success = await testWebhook(webhook);
      setTestResults(prev => ({ ...prev, [webhookId]: success }));
    }
    
    setTestingWebhook(null);
  }

  function handleSaveWebhook(webhook: Omit<WebhookConfig, "id" | "createdAt" | "successCount" | "failureCount">) {
    const newWebhook: WebhookConfig = {
      ...webhook,
      id: Date.now().toString(),
      createdAt: Date.now(),
      successCount: 0,
      failureCount: 0
    };
    
    saveWebhook(newWebhook);
    loadWebhooks();
    setSelectedTemplateId(null);
  }

  function handleToggleWebhook(webhookId: string) {
    const webhook = webhooks.find(w => w.id === webhookId);
    if (webhook) {
      saveWebhook({ ...webhook, enabled: !webhook.enabled });
      loadWebhooks();
    }
  }

  function handleDeleteWebhook(webhookId: string) {
    if (confirm("Are you sure you want to delete this integration?")) {
      deleteWebhook(webhookId);
      loadWebhooks();
    }
  }

  function handleCancelSetup() {
    setSelectedTemplateId(null);
  }

  // Render dedicated setup component based on selected template
  function renderSetupComponent() {
    if (!selectedTemplateId) return null;

    const props = {
      onSave: handleSaveWebhook,
      onCancel: handleCancelSetup
    };

    switch (selectedTemplateId) {
      case "google-sheets":
        return <GoogleSheetsSetup {...props} />;
      case "salesforce":
        return <SalesforceSetup {...props} />;
      case "hubspot":
        return <HubSpotSetup {...props} />;
      case "airtable":
        return <AirtableSetup {...props} />;
      case "notion":
        return <NotionSetup {...props} />;
      case "zapier":
        return <ZapierSetup {...props} />;
      default:
        return null;
    }
  }

  // If a setup component is shown, display only that
  if (selectedTemplateId) {
    return (
      <div className="space-y-6">
        {renderSetupComponent()}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-amber-950/20 to-yellow-950/20 border-amber-700/30">
        <CardHeader>
          <CardTitle className="text-2xl text-amber-50">🔗 API Integrations & Webhooks</CardTitle>
          <CardDescription className="text-amber-100/80 text-base">
            Connect your arbitrage data to Google Sheets, CRM systems, and custom APIs
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="templates" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-black/40">
              <TabsTrigger value="templates" className="data-[state=active]:bg-amber-600 data-[state=active]:text-white text-amber-200">Templates</TabsTrigger>
              <TabsTrigger value="active" className="data-[state=active]:bg-amber-600 data-[state=active]:text-white text-amber-200">Active ({webhooks.length})</TabsTrigger>
              <TabsTrigger value="logs" className="data-[state=active]:bg-amber-600 data-[state=active]:text-white text-amber-200">Logs</TabsTrigger>
            </TabsList>

            {/* Integration Templates */}
            <TabsContent value="templates" className="space-y-4 mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {INTEGRATION_TEMPLATES.map((template) => (
                  <Card 
                    key={template.id}
                    className="bg-black/40 border-amber-700/20 hover:border-amber-600/50 transition-all"
                  >
                    <CardHeader>
                      <CardTitle className="text-lg text-amber-50 flex items-center gap-2">
                        <span className="text-2xl">{template.icon}</span>
                        {template.name}
                      </CardTitle>
                      <CardDescription className="text-amber-100/80 text-base">
                        {template.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button 
                        variant="outline" 
                        className="w-full bg-amber-900/20 border-amber-700/50 text-amber-50 hover:bg-amber-800/30 text-base"
                        onClick={() => handleTemplateSelect(template.id)}
                      >
                        Set Up Integration
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Active Webhooks */}
            <TabsContent value="active" className="space-y-4 mt-4">
              {webhooks.length === 0 ? (
                <Card className="bg-black/40 border-amber-700/20">
                  <CardContent className="pt-6 text-center text-amber-100/70 text-base">
                    No active integrations. Choose a template to get started.
                  </CardContent>
                </Card>
              ) : (
                webhooks.map((webhook) => (
                  <Card 
                    key={webhook.id}
                    className="bg-black/40 border-amber-700/20"
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg text-amber-50 flex items-center gap-2">
                            {webhook.name}
                            {webhook.enabled ? (
                              <Badge className="bg-green-900/50 text-green-100 border-green-700">Active</Badge>
                            ) : (
                              <Badge className="bg-gray-700 text-gray-100 border-gray-600">Paused</Badge>
                            )}
                          </CardTitle>
                          <CardDescription className="text-amber-100/70 text-sm mt-1">
                            {webhook.url}
                          </CardDescription>
                        </div>
                        <Switch
                          checked={webhook.enabled}
                          onCheckedChange={() => handleToggleWebhook(webhook.id)}
                        />
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex gap-4 text-sm text-amber-100/90">
                        <div>
                          <span className="text-green-400 font-semibold">✓ {webhook.successCount}</span> success
                        </div>
                        <div>
                          <span className="text-red-400 font-semibold">✗ {webhook.failureCount}</span> failed
                        </div>
                        {webhook.lastTriggered && (
                          <div>
                            Last: {new Date(webhook.lastTriggered).toLocaleString()}
                          </div>
                        )}
                      </div>
                      
                      <div className="flex flex-wrap gap-2">
                        {webhook.events.map(event => (
                          <Badge key={event} variant="outline" className="bg-amber-900/30 text-amber-100 border-amber-700/50">
                            {event.replace(/_/g, " ")}
                          </Badge>
                        ))}
                      </div>

                      {testResults[webhook.id] !== undefined && (
                        <div className={`text-sm p-2 rounded ${testResults[webhook.id] ? 'bg-green-900/20 text-green-100 border border-green-700/40' : 'bg-red-900/20 text-red-100 border border-red-700/40'}`}>
                          {testResults[webhook.id] ? '✓ Connection successful' : '✗ Connection failed'}
                        </div>
                      )}

                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleTestWebhook(webhook.id)}
                          disabled={testingWebhook === webhook.id}
                          className="bg-amber-900/20 border-amber-700/50 text-amber-100 hover:bg-amber-800/30"
                        >
                          {testingWebhook === webhook.id ? "Testing..." : "Test Connection"}
                        </Button>
                        <Button 
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDeleteWebhook(webhook.id)}
                          className="bg-red-900/50 hover:bg-red-900/70 text-red-100"
                        >
                          Delete
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </TabsContent>

            {/* Integration Logs */}
            <TabsContent value="logs" className="space-y-4 mt-4">
              <LogsViewer webhooks={webhooks} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}

function LogsViewer({ webhooks }: { webhooks: WebhookConfig[] }) {
  const [selectedWebhook, setSelectedWebhook] = useState<string>("all");
  const [logs, setLogs] = useState<ReturnType<typeof getWebhookLogs>>([]);

  useEffect(() => {
    if (selectedWebhook === "all") {
      setLogs(getWebhookLogs("").slice(0, 50)); // Get all logs
    } else {
      setLogs(getWebhookLogs(selectedWebhook));
    }
  }, [selectedWebhook]);

  return (
    <div className="space-y-4">
      <div>
        <Label className="text-amber-50 text-base">Filter by Integration</Label>
        <Select value={selectedWebhook} onValueChange={setSelectedWebhook}>
          <SelectTrigger className="bg-black/40 border-amber-700/30 text-amber-50">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Integrations</SelectItem>
            {webhooks.map(webhook => (
              <SelectItem key={webhook.id} value={webhook.id}>
                {webhook.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {logs.length === 0 ? (
        <Card className="bg-black/40 border-amber-700/20">
          <CardContent className="pt-6 text-center text-amber-100/70 text-base">
            No logs available
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {logs.map(log => (
            <Card 
              key={log.id}
              className={`bg-black/40 border-l-4 ${ 
                log.status === "success" 
                  ? "border-l-green-500 border-amber-700/20" 
                  : "border-l-red-500 border-amber-700/20"
              }`}
            >
              <CardContent className="pt-4 pb-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Badge 
                        className={log.status === "success" ? "bg-green-900/50 text-green-100 border-green-700" : "bg-red-900/50 text-red-100 border-red-700"}
                      >
                        {log.status}
                      </Badge>
                      <span className="text-amber-100/90 text-sm font-medium">{log.event.replace(/_/g, " ")}</span>
                      {log.statusCode && (
                        <span className="text-amber-100/70 text-sm">HTTP {log.statusCode}</span>
                      )}
                    </div>
                    {log.error && (
                      <div className="text-red-200 text-sm font-medium">{log.error}</div>
                    )}
                  </div>
                  <div className="text-right text-sm text-amber-100/70">
                    <div>{new Date(log.timestamp).toLocaleString()}</div>
                    <div className="text-amber-200/80">{log.responseTime}ms</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
