'use client'
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, TrendingDown, AlertCircle } from "lucide-react";
import { calcMelt, calcPremium, calcArbitrageScore, getRecommendation } from "@/lib/calc";

interface FractionalPiece {
  weight: string;
  weightOz: number;
  typicalPremium: number;
  marketPrice: number;
}

interface LiveFractionalGoldDashboardProps {
  spotPrice: number;
}

export function LiveFractionalGoldDashboard({ spotPrice }: LiveFractionalGoldDashboardProps): JSX.Element {
  const [pieces, setPieces] = useState<FractionalPiece[]>([]);

  useEffect(() => {
    if (spotPrice > 0) {
      // Define common fractional pieces with typical market premiums
      const fractionalPieces: FractionalPiece[] = [
        { weight: "1/10 oz American Eagle", weightOz: 0.1, typicalPremium: 15 },
        { weight: "1/10 oz Canadian Maple", weightOz: 0.1, typicalPremium: 14 },
        { weight: "1/4 oz American Eagle", weightOz: 0.25, typicalPremium: 12 },
        { weight: "1/4 oz Canadian Maple", weightOz: 0.25, typicalPremium: 11 },
        { weight: "1/2 oz American Eagle", weightOz: 0.5, typicalPremium: 10 },
        { weight: "1/2 oz Canadian Maple", weightOz: 0.5, typicalPremium: 9 },
        { weight: "2g Gold Bar", weightOz: 0.0643, typicalPremium: 18 },
        { weight: "5g Gold Bar", weightOz: 0.1607, typicalPremium: 16 },
        { weight: "10g Gold Bar", weightOz: 0.3215, typicalPremium: 8 },
        { weight: "20g Gold Bar", weightOz: 0.643, typicalPremium: 6 }
      ];

      // Calculate market prices based on melt + premium
      const calculatedPieces = fractionalPieces.map((piece: FractionalPiece) => {
        const melt = calcMelt(piece.weightOz, spotPrice);
        const marketPrice = melt * (1 + piece.typicalPremium / 100);
        return {
          ...piece,
          marketPrice: parseFloat(marketPrice.toFixed(2))
        };
      });

      setPieces(calculatedPieces);
    }
  }, [spotPrice]);

  if (spotPrice === 0) {
    return (
      <Card className="border-amber-200">
        <CardContent className="pt-6 text-center">
          <AlertCircle className="h-12 w-12 text-amber-600 mx-auto mb-3" />
          <p className="text-gray-700 font-medium">Loading spot price...</p>
          <p className="text-sm text-gray-500 mt-1">Live fractional gold prices will appear here</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-amber-200 shadow-lg">
      <CardHeader>
        <CardTitle className="text-amber-900 text-2xl">Live Fractional Gold Market</CardTitle>
        <CardDescription>
          Real-time pricing for common fractional gold pieces based on current spot price
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {pieces.map((piece: FractionalPiece, index: number) => {
            const melt = calcMelt(piece.weightOz, spotPrice);
            const premium = calcPremium(piece.marketPrice, melt);
            const resaleMargin = piece.marketPrice * 0.03; // Assume 3% resale potential
            const score = calcArbitrageScore(premium, resaleMargin);
            const recommendation = getRecommendation(score);

            return (
              <Card 
                key={index} 
                className={`border-2 ${
                  recommendation === "BUY" 
                    ? "border-green-300 bg-green-50" 
                    : "border-gray-300 bg-gray-50"
                }`}
              >
                <CardContent className="pt-4 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-bold text-gray-900">{piece.weight}</h3>
                      <p className="text-xs text-gray-600">{piece.weightOz} oz</p>
                    </div>
                    <Badge 
                      className={
                        recommendation === "BUY"
                          ? "bg-green-600"
                          : "bg-gray-600"
                      }
                    >
                      {recommendation === "BUY" ? (
                        <TrendingUp className="h-3 w-3 mr-1" />
                      ) : (
                        <TrendingDown className="h-3 w-3 mr-1" />
                      )}
                      {recommendation}
                    </Badge>
                  </div>

                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Market Price:</span>
                      <span className="font-bold text-gray-900">${piece.marketPrice.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Melt Value:</span>
                      <span className="font-semibold text-amber-700">${melt.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Premium:</span>
                      <span className={`font-semibold ${premium > 15 ? "text-red-600" : "text-green-600"}`}>
                        {premium.toFixed(1)}%
                      </span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-gray-200">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-600">Arbitrage Score</span>
                      <Badge variant="outline" className="font-bold">
                        {score}/100
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-6 p-4 bg-blue-50 border-2 border-blue-200 rounded-lg">
          <h3 className="font-bold text-blue-900 mb-2">💡 Understanding the Data</h3>
          <ul className="text-sm text-gray-700 space-y-1">
            <li>• <strong>Market Price:</strong> Typical dealer asking price for this piece</li>
            <li>• <strong>Melt Value:</strong> Intrinsic gold value based on current spot price</li>
            <li>• <strong>Premium:</strong> How much over melt you're paying (lower is better)</li>
            <li>• <strong>Arbitrage Score:</strong> Overall deal quality (70+ = BUY, under 70 = PASS)</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
