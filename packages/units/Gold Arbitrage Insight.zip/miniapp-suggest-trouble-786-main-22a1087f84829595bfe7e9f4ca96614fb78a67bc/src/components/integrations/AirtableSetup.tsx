"use client";

import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { WebhookConfig, WebhookEvent } from "@/lib/integrations";

interface AirtableSetupProps {
  onSave: (webhook: Omit<WebhookConfig, "id" | "createdAt" | "successCount" | "failureCount">) => void;
  onCancel: () => void;
}

export default function AirtableSetup({ onSave, onCancel }: AirtableSetupProps) {
  const [apiKey, setApiKey] = useState("");
  const [baseId, setBaseId] = useState("");
  const [tableName, setTableName] = useState("Arbitrage Opportunities");
  const [selectedEvents, setSelectedEvents] = useState<WebhookEvent[]>(["analysis_created", "deal_found"]);

  const allEvents: WebhookEvent[] = [
    "analysis_created",
    "deal_found",
    "alert_triggered",
    "portfolio_updated",
    "price_changed"
  ];

  function handleSave() {
    const webhook: Omit<WebhookConfig, "id" | "createdAt" | "successCount" | "failureCount"> = {
      name: `Airtable - ${tableName}`,
      url: `https://api.airtable.com/v0/${baseId}/${encodeURIComponent(tableName)}`,
      apiKey: apiKey,
      enabled: true,
      events: selectedEvents,
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      }
    };
    onSave(webhook);
  }

  return (
    <Card className="bg-gradient-to-br from-amber-950/30 to-yellow-950/30 border-amber-700/40">
      <CardHeader>
        <CardTitle className="text-2xl text-amber-50 flex items-center gap-2">
          <span className="text-3xl">🗂️</span>
          Airtable Integration
        </CardTitle>
        <CardDescription className="text-amber-100/80 text-base">
          Send arbitrage data to beautiful, filterable Airtable databases
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Instructions */}
        <div className="bg-black/40 p-4 rounded-lg border border-amber-700/30">
          <h3 className="text-amber-50 font-semibold mb-3 text-lg">📝 Setup Instructions</h3>
          <ol className="space-y-3 text-amber-100/90 text-base">
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">1.</span>
              <span>Create an Airtable base (or use existing)</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">2.</span>
              <span>Create a table with these fields:
                <ul className="ml-4 mt-1 text-sm text-amber-200/80 space-y-1">
                  <li>• Timestamp (Date)</li>
                  <li>• Weight Type (Single line text)</li>
                  <li>• Purchase Price (Currency)</li>
                  <li>• Melt Value (Currency)</li>
                  <li>• Premium % (Number)</li>
                  <li>• Score (Number)</li>
                  <li>• Recommendation (Single select: BUY/PASS)</li>
                  <li>• Dealer (Single line text)</li>
                </ul>
              </span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">3.</span>
              <span>Go to <a href="https://airtable.com/create/tokens" target="_blank" className="text-blue-400 underline">airtable.com/create/tokens</a></span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">4.</span>
              <span>Create token with scopes: <strong className="text-amber-200">data.records:write</strong></span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">5.</span>
              <span>Copy Base ID from your base URL (starts with "app...")</span>
            </li>
          </ol>
        </div>

        {/* Form */}
        <div className="space-y-4">
          <div>
            <Label className="text-amber-50 text-base">Airtable Personal Access Token</Label>
            <Input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="patXXXXXXXXXXXXXX.XXXXXXXXXXXXXXX"
              className="bg-black/50 border-amber-700/40 text-amber-50 placeholder:text-amber-200/40 text-base"
            />
            <p className="text-amber-200/70 text-sm mt-1">Your Airtable personal access token</p>
          </div>

          <div>
            <Label className="text-amber-50 text-base">Base ID</Label>
            <Input
              value={baseId}
              onChange={(e) => setBaseId(e.target.value)}
              placeholder="appXXXXXXXXXXXXXX"
              className="bg-black/50 border-amber-700/40 text-amber-50 placeholder:text-amber-200/40 text-base"
            />
            <p className="text-amber-200/70 text-sm mt-1">Found in your base URL: airtable.com/appXXXX...</p>
          </div>

          <div>
            <Label className="text-amber-50 text-base">Table Name</Label>
            <Input
              value={tableName}
              onChange={(e) => setTableName(e.target.value)}
              placeholder="Arbitrage Opportunities"
              className="bg-black/50 border-amber-700/40 text-amber-50 placeholder:text-amber-200/40 text-base"
            />
            <p className="text-amber-200/70 text-sm mt-1">Exact name of your table (case-sensitive)</p>
          </div>

          <div>
            <Label className="text-amber-50 text-base mb-2 block">What to track</Label>
            <div className="grid grid-cols-2 gap-3">
              {allEvents.map(event => (
                <label key={event} className="flex items-center gap-2 text-amber-100/90 text-base cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedEvents.includes(event)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedEvents([...selectedEvents, event]);
                      } else {
                        setSelectedEvents(selectedEvents.filter(ev => ev !== event));
                      }
                    }}
                    className="rounded w-4 h-4"
                  />
                  <span>{event.replace(/_/g, " ")}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        {/* Example */}
        <div className="bg-black/40 p-4 rounded-lg border border-amber-700/30">
          <h3 className="text-amber-50 font-semibold mb-2 text-base">✨ Airtable Features You Get:</h3>
          <div className="text-amber-100/80 text-sm space-y-1">
            <div>• <strong>Views:</strong> Filter by score, dealer, weight type</div>
            <div>• <strong>Sorting:</strong> Find best deals instantly</div>
            <div>• <strong>Grouping:</strong> Group by recommendation (BUY/PASS)</div>
            <div>• <strong>Charts:</strong> Visualize premium trends over time</div>
            <div>• <strong>Collaboration:</strong> Share with team members</div>
            <div>• <strong>Mobile App:</strong> Access anywhere</div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 pt-2">
          <Button 
            onClick={handleSave}
            disabled={!apiKey || !baseId || !tableName || selectedEvents.length === 0}
            className="bg-green-600 hover:bg-green-700 text-white text-base px-6"
          >
            Save Integration
          </Button>
          <Button 
            variant="outline"
            onClick={onCancel}
            className="bg-black/40 border-amber-700/50 text-amber-100 hover:bg-black/60 text-base"
          >
            Cancel
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
