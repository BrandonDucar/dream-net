"use client";

import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import type { WebhookConfig, WebhookEvent } from "@/lib/integrations";

interface GoogleSheetsSetupProps {
  onSave: (webhook: Omit<WebhookConfig, "id" | "createdAt" | "successCount" | "failureCount">) => void;
  onCancel: () => void;
}

export default function GoogleSheetsSetup({ onSave, onCancel }: GoogleSheetsSetupProps) {
  const [spreadsheetUrl, setSpreadsheetUrl] = useState("");
  const [sheetName, setSheetName] = useState("Arbitrage Data");
  const [webhookUrl, setWebhookUrl] = useState("");
  const [selectedEvents, setSelectedEvents] = useState<WebhookEvent[]>(["analysis_created", "deal_found"]);

  const allEvents: WebhookEvent[] = [
    "analysis_created",
    "deal_found",
    "alert_triggered",
    "portfolio_updated",
    "price_changed"
  ];

  function handleSave() {
    const webhook: Omit<WebhookConfig, "id" | "createdAt" | "successCount" | "failureCount"> = {
      name: `Google Sheets - ${sheetName}`,
      url: webhookUrl,
      enabled: true,
      events: selectedEvents,
      headers: {
        "Content-Type": "application/json"
      }
    };
    onSave(webhook);
  }

  return (
    <Card className="bg-gradient-to-br from-amber-950/30 to-yellow-950/30 border-amber-700/40">
      <CardHeader>
        <CardTitle className="text-2xl text-amber-50 flex items-center gap-2">
          <span className="text-3xl">📊</span>
          Google Sheets Integration
        </CardTitle>
        <CardDescription className="text-amber-100/80 text-base">
          Automatically log every arbitrage analysis to a Google Sheets spreadsheet
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Step-by-step instructions */}
        <div className="bg-black/40 p-4 rounded-lg border border-amber-700/30">
          <h3 className="text-amber-50 font-semibold mb-3 text-lg">📋 Setup Instructions</h3>
          <ol className="space-y-3 text-amber-100/90 text-base">
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">1.</span>
              <span>Open <a href="https://script.google.com" target="_blank" className="text-blue-400 underline">Google Apps Script</a></span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">2.</span>
              <span>Create new project and paste this code:</span>
            </li>
          </ol>
          
          <div className="mt-3 bg-black/60 p-3 rounded font-mono text-sm text-green-300 overflow-x-auto">
{`function doPost(e) {
  var sheet = SpreadsheetApp.openByUrl("YOUR_SHEET_URL").getSheetByName("Arbitrage Data");
  var data = JSON.parse(e.postData.contents);
  sheet.appendRow([
    new Date(data.timestamp),
    data.weightType,
    data.weightOz,
    data.purchasePrice,
    data.meltValue,
    data.premiumPct,
    data.arbitrageScore,
    data.recommendation,
    data.dealer || ""
  ]);
  return ContentService.createTextOutput("Success");
}`}
          </div>

          <ol className="space-y-3 text-amber-100/90 mt-3 text-base">
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">3.</span>
              <span>Deploy as Web App (Execute as: Me, Access: Anyone)</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">4.</span>
              <span>Copy the webhook URL and paste below</span>
            </li>
          </ol>
        </div>

        {/* Form fields */}
        <div className="space-y-4">
          <div>
            <Label className="text-amber-50 text-base">Google Sheets URL</Label>
            <Input
              value={spreadsheetUrl}
              onChange={(e) => setSpreadsheetUrl(e.target.value)}
              placeholder="https://docs.google.com/spreadsheets/d/..."
              className="bg-black/50 border-amber-700/40 text-amber-50 placeholder:text-amber-200/40 text-base"
            />
            <p className="text-amber-200/70 text-sm mt-1">The spreadsheet where data will be logged</p>
          </div>

          <div>
            <Label className="text-amber-50 text-base">Sheet Name</Label>
            <Input
              value={sheetName}
              onChange={(e) => setSheetName(e.target.value)}
              placeholder="Arbitrage Data"
              className="bg-black/50 border-amber-700/40 text-amber-50 placeholder:text-amber-200/40 text-base"
            />
            <p className="text-amber-200/70 text-sm mt-1">Name of the tab in your spreadsheet</p>
          </div>

          <div>
            <Label className="text-amber-50 text-base">Apps Script Webhook URL</Label>
            <Input
              value={webhookUrl}
              onChange={(e) => setWebhookUrl(e.target.value)}
              placeholder="https://script.google.com/macros/s/.../exec"
              className="bg-black/50 border-amber-700/40 text-amber-50 placeholder:text-amber-200/40 text-base"
            />
            <p className="text-amber-200/70 text-sm mt-1">The webhook URL from your deployed Apps Script</p>
          </div>

          <div>
            <Label className="text-amber-50 text-base mb-2 block">What data to send</Label>
            <div className="grid grid-cols-2 gap-3">
              {allEvents.map(event => (
                <label key={event} className="flex items-center gap-2 text-amber-100/90 text-base cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedEvents.includes(event)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedEvents([...selectedEvents, event]);
                      } else {
                        setSelectedEvents(selectedEvents.filter(ev => ev !== event));
                      }
                    }}
                    className="rounded w-4 h-4"
                  />
                  <span>{event.replace(/_/g, " ")}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        {/* Example output */}
        <div className="bg-black/40 p-4 rounded-lg border border-amber-700/30">
          <h3 className="text-amber-50 font-semibold mb-2 text-base">📈 What gets logged:</h3>
          <div className="text-amber-100/80 text-sm space-y-1">
            <div>• Timestamp of analysis</div>
            <div>• Weight type (1/10 oz, 1/4 oz, etc.)</div>
            <div>• Purchase price & melt value</div>
            <div>• Premium percentage</div>
            <div>• Arbitrage score (0-100)</div>
            <div>• BUY/PASS recommendation</div>
            <div>• Dealer name (if applicable)</div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex gap-3 pt-2">
          <Button 
            onClick={handleSave}
            disabled={!webhookUrl || selectedEvents.length === 0}
            className="bg-green-600 hover:bg-green-700 text-white text-base px-6"
          >
            Save Integration
          </Button>
          <Button 
            variant="outline"
            onClick={onCancel}
            className="bg-black/40 border-amber-700/50 text-amber-100 hover:bg-black/60 text-base"
          >
            Cancel
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
