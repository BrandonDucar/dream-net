"use client";

import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { WebhookConfig, WebhookEvent } from "@/lib/integrations";

interface NotionSetupProps {
  onSave: (webhook: Omit<WebhookConfig, "id" | "createdAt" | "successCount" | "failureCount">) => void;
  onCancel: () => void;
}

export default function NotionSetup({ onSave, onCancel }: NotionSetupProps) {
  const [apiKey, setApiKey] = useState("");
  const [databaseId, setDatabaseId] = useState("");
  const [selectedEvents, setSelectedEvents] = useState<WebhookEvent[]>(["analysis_created", "deal_found"]);

  const allEvents: WebhookEvent[] = [
    "analysis_created",
    "deal_found",
    "alert_triggered",
    "portfolio_updated",
    "price_changed"
  ];

  function handleSave() {
    const webhook: Omit<WebhookConfig, "id" | "createdAt" | "successCount" | "failureCount"> = {
      name: "Notion Database",
      url: `https://api.notion.com/v1/pages`,
      apiKey: apiKey,
      enabled: true,
      events: selectedEvents,
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
        "Notion-Version": "2022-06-28"
      }
    };
    onSave(webhook);
  }

  return (
    <Card className="bg-gradient-to-br from-amber-950/30 to-yellow-950/30 border-amber-700/40">
      <CardHeader>
        <CardTitle className="text-2xl text-amber-50 flex items-center gap-2">
          <span className="text-3xl">📝</span>
          Notion Integration
        </CardTitle>
        <CardDescription className="text-amber-100/80 text-base">
          Create rich database pages in Notion for each arbitrage opportunity
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Instructions */}
        <div className="bg-black/40 p-4 rounded-lg border border-amber-700/30">
          <h3 className="text-amber-50 font-semibold mb-3 text-lg">🔗 Setup Instructions</h3>
          <ol className="space-y-3 text-amber-100/90 text-base">
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">1.</span>
              <span>Go to <a href="https://www.notion.so/my-integrations" target="_blank" className="text-blue-400 underline">notion.so/my-integrations</a></span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">2.</span>
              <span>Click "New integration" → Name it "Gold Arbitrage Finder"</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">3.</span>
              <span>Under Capabilities, enable: <strong className="text-amber-200">Insert content</strong></span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">4.</span>
              <span>Copy the "Internal Integration Token"</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">5.</span>
              <span>Create a Notion database with these properties:
                <ul className="ml-4 mt-1 text-sm text-amber-200/80 space-y-1">
                  <li>• Name (Title)</li>
                  <li>• Weight Type (Select)</li>
                  <li>• Purchase Price (Number)</li>
                  <li>• Premium % (Number)</li>
                  <li>• Score (Number)</li>
                  <li>• Recommendation (Select: BUY/PASS)</li>
                  <li>• Dealer (Text)</li>
                  <li>• Timestamp (Date)</li>
                </ul>
              </span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">6.</span>
              <span>Share the database with your integration</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">7.</span>
              <span>Copy the database ID from URL (32-char string)</span>
            </li>
          </ol>
        </div>

        {/* Form */}
        <div className="space-y-4">
          <div>
            <Label className="text-amber-50 text-base">Notion Integration Token</Label>
            <Input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="secret_XXXXXXXXXXXXXXXXXXXXXXXXXXXX"
              className="bg-black/50 border-amber-700/40 text-amber-50 placeholder:text-amber-200/40 text-base"
            />
            <p className="text-amber-200/70 text-sm mt-1">Your internal integration token from Notion</p>
          </div>

          <div>
            <Label className="text-amber-50 text-base">Database ID</Label>
            <Input
              value={databaseId}
              onChange={(e) => setDatabaseId(e.target.value)}
              placeholder="1234567890abcdef1234567890abcdef"
              className="bg-black/50 border-amber-700/40 text-amber-50 placeholder:text-amber-200/40 text-base"
            />
            <p className="text-amber-200/70 text-sm mt-1">
              From your database URL: notion.so/...<strong>1234567890abcdef</strong>?v=...
            </p>
          </div>

          <div>
            <Label className="text-amber-50 text-base mb-2 block">What to sync</Label>
            <div className="grid grid-cols-2 gap-3">
              {allEvents.map(event => (
                <label key={event} className="flex items-center gap-2 text-amber-100/90 text-base cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedEvents.includes(event)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedEvents([...selectedEvents, event]);
                      } else {
                        setSelectedEvents(selectedEvents.filter(ev => ev !== event));
                      }
                    }}
                    className="rounded w-4 h-4"
                  />
                  <span>{event.replace(/_/g, " ")}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        {/* Example */}
        <div className="bg-black/40 p-4 rounded-lg border border-amber-700/30">
          <h3 className="text-amber-50 font-semibold mb-2 text-base">📄 What You Get in Notion:</h3>
          <div className="text-amber-100/80 text-sm space-y-1">
            <div>• <strong>Rich Pages:</strong> Each opportunity becomes a full page</div>
            <div>• <strong>Detailed Analysis:</strong> All calculations and data points</div>
            <div>• <strong>Tagging:</strong> Filter by dealer, weight, recommendation</div>
            <div>• <strong>Comments:</strong> Collaborate with team members</div>
            <div>• <strong>Views:</strong> Table, board, calendar, gallery views</div>
            <div>• <strong>Formulas:</strong> Calculate ROI, profit margins automatically</div>
          </div>
        </div>

        {/* Pro tip */}
        <div className="bg-blue-950/30 p-3 rounded-lg border border-blue-700/40">
          <div className="text-blue-200 text-sm">
            <strong>💡 Pro Tip:</strong> Create a "Dashboard" page with linked databases to visualize all your arbitrage opportunities in one place
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 pt-2">
          <Button 
            onClick={handleSave}
            disabled={!apiKey || !databaseId || selectedEvents.length === 0}
            className="bg-green-600 hover:bg-green-700 text-white text-base px-6"
          >
            Save Integration
          </Button>
          <Button 
            variant="outline"
            onClick={onCancel}
            className="bg-black/40 border-amber-700/50 text-amber-100 hover:bg-black/60 text-base"
          >
            Cancel
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
