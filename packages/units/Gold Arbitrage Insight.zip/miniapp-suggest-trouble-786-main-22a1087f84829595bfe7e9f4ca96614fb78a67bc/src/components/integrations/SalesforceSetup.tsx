"use client";

import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { WebhookConfig, WebhookEvent } from "@/lib/integrations";

interface SalesforceSetupProps {
  onSave: (webhook: Omit<WebhookConfig, "id" | "createdAt" | "successCount" | "failureCount">) => void;
  onCancel: () => void;
}

export default function SalesforceSetup({ onSave, onCancel }: SalesforceSetupProps) {
  const [instanceUrl, setInstanceUrl] = useState("");
  const [apiKey, setApiKey] = useState("");
  const [objectType, setObjectType] = useState("Opportunity");
  const [selectedEvents, setSelectedEvents] = useState<WebhookEvent[]>(["deal_found"]);

  const allEvents: WebhookEvent[] = [
    "analysis_created",
    "deal_found",
    "alert_triggered",
    "portfolio_updated",
    "price_changed"
  ];

  function handleSave() {
    const webhook: Omit<WebhookConfig, "id" | "createdAt" | "successCount" | "failureCount"> = {
      name: `Salesforce - ${objectType}`,
      url: `${instanceUrl}/services/data/v58.0/sobjects/${objectType}`,
      apiKey: apiKey,
      enabled: true,
      events: selectedEvents,
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      }
    };
    onSave(webhook);
  }

  return (
    <Card className="bg-gradient-to-br from-amber-950/30 to-yellow-950/30 border-amber-700/40">
      <CardHeader>
        <CardTitle className="text-2xl text-amber-50 flex items-center gap-2">
          <span className="text-3xl">☁️</span>
          Salesforce Integration
        </CardTitle>
        <CardDescription className="text-amber-100/80 text-base">
          Create Opportunities or custom objects in Salesforce for high-score deals
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Instructions */}
        <div className="bg-black/40 p-4 rounded-lg border border-amber-700/30">
          <h3 className="text-amber-50 font-semibold mb-3 text-lg">🔧 Setup Instructions</h3>
          <ol className="space-y-3 text-amber-100/90 text-base">
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">1.</span>
              <span>Go to Salesforce Setup → Apps → App Manager</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">2.</span>
              <span>Create Connected App with OAuth enabled</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">3.</span>
              <span>Enable: API (Enabled OAuth Settings)</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">4.</span>
              <span>Get your access token using OAuth 2.0 flow</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">5.</span>
              <span>Paste your instance URL and access token below</span>
            </li>
          </ol>
        </div>

        {/* Form */}
        <div className="space-y-4">
          <div>
            <Label className="text-amber-50 text-base">Salesforce Instance URL</Label>
            <Input
              value={instanceUrl}
              onChange={(e) => setInstanceUrl(e.target.value)}
              placeholder="https://yourcompany.my.salesforce.com"
              className="bg-black/50 border-amber-700/40 text-amber-50 placeholder:text-amber-200/40 text-base"
            />
            <p className="text-amber-200/70 text-sm mt-1">Your Salesforce organization URL</p>
          </div>

          <div>
            <Label className="text-amber-50 text-base">Access Token</Label>
            <Input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="00D...!AR..."
              className="bg-black/50 border-amber-700/40 text-amber-50 placeholder:text-amber-200/40 text-base"
            />
            <p className="text-amber-200/70 text-sm mt-1">OAuth 2.0 access token from your connected app</p>
          </div>

          <div>
            <Label className="text-amber-50 text-base">Object Type</Label>
            <Input
              value={objectType}
              onChange={(e) => setObjectType(e.target.value)}
              placeholder="Opportunity"
              className="bg-black/50 border-amber-700/40 text-amber-50 placeholder:text-amber-200/40 text-base"
            />
            <p className="text-amber-200/70 text-sm mt-1">Salesforce object (Opportunity, Lead, Custom_Object__c)</p>
          </div>

          <div>
            <Label className="text-amber-50 text-base mb-2 block">Trigger Events</Label>
            <div className="grid grid-cols-2 gap-3">
              {allEvents.map(event => (
                <label key={event} className="flex items-center gap-2 text-amber-100/90 text-base cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedEvents.includes(event)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedEvents([...selectedEvents, event]);
                      } else {
                        setSelectedEvents(selectedEvents.filter(ev => ev !== event));
                      }
                    }}
                    className="rounded w-4 h-4"
                  />
                  <span>{event.replace(/_/g, " ")}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        {/* Example */}
        <div className="bg-black/40 p-4 rounded-lg border border-amber-700/30">
          <h3 className="text-amber-50 font-semibold mb-2 text-base">📋 What gets created:</h3>
          <div className="text-amber-100/80 text-sm space-y-1">
            <div>• Opportunity Name: "1/4 oz Gold - Score 85"</div>
            <div>• Amount: Purchase price in USD</div>
            <div>• Stage: "Qualified to Buy" (for BUY recommendations)</div>
            <div>• Custom Fields: Premium %, Arbitrage Score, Dealer</div>
            <div>• Description: Full analysis details</div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 pt-2">
          <Button 
            onClick={handleSave}
            disabled={!instanceUrl || !apiKey || selectedEvents.length === 0}
            className="bg-green-600 hover:bg-green-700 text-white text-base px-6"
          >
            Save Integration
          </Button>
          <Button 
            variant="outline"
            onClick={onCancel}
            className="bg-black/40 border-amber-700/50 text-amber-100 hover:bg-black/60 text-base"
          >
            Cancel
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
