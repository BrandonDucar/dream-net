"use client";

import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { WebhookConfig, WebhookEvent } from "@/lib/integrations";

interface ZapierSetupProps {
  onSave: (webhook: Omit<WebhookConfig, "id" | "createdAt" | "successCount" | "failureCount">) => void;
  onCancel: () => void;
}

export default function ZapierSetup({ onSave, onCancel }: ZapierSetupProps) {
  const [webhookUrl, setWebhookUrl] = useState("");
  const [zapName, setZapName] = useState("");
  const [selectedEvents, setSelectedEvents] = useState<WebhookEvent[]>(["deal_found"]);

  const allEvents: WebhookEvent[] = [
    "analysis_created",
    "deal_found",
    "alert_triggered",
    "portfolio_updated",
    "price_changed"
  ];

  function handleSave() {
    const webhook: Omit<WebhookConfig, "id" | "createdAt" | "successCount" | "failureCount"> = {
      name: zapName || "Zapier Webhook",
      url: webhookUrl,
      enabled: true,
      events: selectedEvents,
      headers: {
        "Content-Type": "application/json"
      }
    };
    onSave(webhook);
  }

  return (
    <Card className="bg-gradient-to-br from-amber-950/30 to-yellow-950/30 border-amber-700/40">
      <CardHeader>
        <CardTitle className="text-2xl text-amber-50 flex items-center gap-2">
          <span className="text-3xl">⚡</span>
          Zapier Integration
        </CardTitle>
        <CardDescription className="text-amber-100/80 text-base">
          Connect to 5,000+ apps via Zapier webhooks - Send to Slack, Gmail, Discord, and more
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Instructions */}
        <div className="bg-black/40 p-4 rounded-lg border border-amber-700/30">
          <h3 className="text-amber-50 font-semibold mb-3 text-lg">⚡ Setup Instructions</h3>
          <ol className="space-y-3 text-amber-100/90 text-base">
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">1.</span>
              <span>Go to <a href="https://zapier.com/app/zaps" target="_blank" className="text-blue-400 underline">zapier.com</a> and click "Create Zap"</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">2.</span>
              <span>For the trigger, choose: <strong className="text-amber-200">Webhooks by Zapier</strong></span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">3.</span>
              <span>Select: <strong className="text-amber-200">Catch Hook</strong></span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">4.</span>
              <span>Copy the webhook URL Zapier provides</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">5.</span>
              <span>Paste it below and save</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-amber-300">6.</span>
              <span>Return to Zapier and add actions (send to Slack, email, etc.)</span>
            </li>
          </ol>
        </div>

        {/* Form */}
        <div className="space-y-4">
          <div>
            <Label className="text-amber-50 text-base">Zap Name (Optional)</Label>
            <Input
              value={zapName}
              onChange={(e) => setZapName(e.target.value)}
              placeholder="Deal Alerts to Slack"
              className="bg-black/50 border-amber-700/40 text-amber-50 placeholder:text-amber-200/40 text-base"
            />
            <p className="text-amber-200/70 text-sm mt-1">Give your integration a memorable name</p>
          </div>

          <div>
            <Label className="text-amber-50 text-base">Zapier Webhook URL</Label>
            <Input
              value={webhookUrl}
              onChange={(e) => setWebhookUrl(e.target.value)}
              placeholder="https://hooks.zapier.com/hooks/catch/..."
              className="bg-black/50 border-amber-700/40 text-amber-50 placeholder:text-amber-200/40 text-base"
            />
            <p className="text-amber-200/70 text-sm mt-1">The webhook URL from your Zapier Zap</p>
          </div>

          <div>
            <Label className="text-amber-50 text-base mb-2 block">Trigger Events</Label>
            <div className="grid grid-cols-2 gap-3">
              {allEvents.map(event => (
                <label key={event} className="flex items-center gap-2 text-amber-100/90 text-base cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedEvents.includes(event)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedEvents([...selectedEvents, event]);
                      } else {
                        setSelectedEvents(selectedEvents.filter(ev => ev !== event));
                      }
                    }}
                    className="rounded w-4 h-4"
                  />
                  <span>{event.replace(/_/g, " ")}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        {/* Popular Zap Ideas */}
        <div className="bg-black/40 p-4 rounded-lg border border-amber-700/30">
          <h3 className="text-amber-50 font-semibold mb-2 text-base">🔥 Popular Zap Ideas:</h3>
          <div className="text-amber-100/80 text-sm space-y-2">
            <div>
              <strong className="text-amber-200">💬 Slack:</strong> Post hot deals to #gold-deals channel
            </div>
            <div>
              <strong className="text-amber-200">📧 Gmail:</strong> Email yourself when score &gt; 85
            </div>
            <div>
              <strong className="text-amber-200">🎮 Discord:</strong> Send notifications to Discord server
            </div>
            <div>
              <strong className="text-amber-200">📱 SMS:</strong> Text yourself via Twilio for urgent deals
            </div>
            <div>
              <strong className="text-amber-200">📊 Google Sheets:</strong> Log everything to spreadsheet
            </div>
            <div>
              <strong className="text-amber-200">🗓️ Google Calendar:</strong> Create events for purchasing
            </div>
            <div>
              <strong className="text-amber-200">💰 Stripe:</strong> Track revenue from arbitrage sales
            </div>
          </div>
        </div>

        {/* Data sent */}
        <div className="bg-black/40 p-4 rounded-lg border border-amber-700/30">
          <h3 className="text-amber-50 font-semibold mb-2 text-base">📦 Data You'll Receive:</h3>
          <div className="bg-black/60 p-3 rounded font-mono text-xs text-green-300 overflow-x-auto">
{`{
  "event": "deal_found",
  "timestamp": 1704067200000,
  "data": {
    "weightType": "1/4",
    "weightOz": 0.25,
    "purchasePrice": 650,
    "meltValue": 625,
    "premiumPct": 4.0,
    "arbitrageScore": 85,
    "recommendation": "BUY",
    "dealer": "APMEX",
    "savings": 45.50
  }
}`}
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 pt-2">
          <Button 
            onClick={handleSave}
            disabled={!webhookUrl || selectedEvents.length === 0}
            className="bg-green-600 hover:bg-green-700 text-white text-base px-6"
          >
            Save Integration
          </Button>
          <Button 
            variant="outline"
            onClick={onCancel}
            className="bg-black/40 border-amber-700/50 text-amber-100 hover:bg-black/60 text-base"
          >
            Cancel
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
