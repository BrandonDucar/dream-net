/**
 * Fractional Gold Arbitrage Calculator
 * Core calculation functions for analyzing gold arbitrage opportunities
 */

/**
 * Calculate melt value based on weight and spot price
 */
export function calcMelt(weightOz: number, spot: number): number {
  return weightOz * spot;
}

/**
 * Calculate premium percentage over melt value
 */
export function calcPremium(purchase: number, melt: number): number {
  return ((purchase / melt) - 1) * 100;
}

/**
 * Calculate resale margin (profit potential)
 */
export function calcResaleMargin(purchase: number, comp: number): number {
  return comp - purchase;
}

/**
 * Calculate arbitrage score (0-100)
 * Premium < 12% = good
 * Premium 12-20% = okay
 * Premium 20%+ = bad
 */
export function calcArbitrageScore(premiumPct: number, resaleMargin: number): number {
  let score: number = 100 - premiumPct;
  
  // Add momentum if resale is high
  score += resaleMargin * 0.5;
  
  return Math.max(0, Math.min(100, Math.round(score)));
}

/**
 * Get recommendation based on arbitrage score
 */
export function getRecommendation(score: number): "BUY" | "PASS" {
  if (score >= 70) return "BUY";
  return "PASS";
}

/**
 * Convert weight type to ounces
 */
export function weightToOz(weight: string): number {
  const weightTable: Record<string, number> = {
    "1/10": 0.1,
    "1/4": 0.25,
    "1/2": 0.5,
    "2g": 0.0643,
    "5g": 0.1607,
    "Other": 0
  };
  return weightTable[weight] ?? 0;
}

/**
 * Parse URL to extract potential price and weight information
 */
export function parseProductUrl(url: string): { price?: number; weight?: string } | null {
  try {
    // Extract numbers that look like prices
    const priceMatch = url.match(/[\$]?(\d+\.\d{2})/);
    const price = priceMatch ? parseFloat(priceMatch[1]) : undefined;
    
    // Extract weight information
    const weightPatterns = [
      /1\/10[-\s]?oz/i,
      /1\/4[-\s]?oz/i,
      /1\/2[-\s]?oz/i,
      /2[-\s]?g/i,
      /5[-\s]?g/i
    ];
    
    let weight: string | undefined;
    for (const pattern of weightPatterns) {
      if (pattern.test(url)) {
        const match = url.match(pattern)?.[0];
        if (match) {
          weight = match.toLowerCase().replace(/[-\s]/g, '');
          break;
        }
      }
    }
    
    return { price, weight };
  } catch (error) {
    return null;
  }
}

/**
 * Calculate enhanced arbitrage score with liquidity factor
 */
export function calcEnhancedScore(
  premiumPct: number,
  resaleMargin: number,
  liquidityScore: number
): number {
  let score = 100 - premiumPct;
  score += resaleMargin * 0.5;
  score += (liquidityScore - 50) * 0.2; // Bonus for high liquidity
  
  return Math.max(0, Math.min(100, Math.round(score)));
}
