/**
 * API Integration & Webhook Management System
 * Enables users to connect their own APIs and CRM systems
 */

import type { FractionalGoldItem } from "@/types/gold";

export interface WebhookConfig {
  id: string;
  name: string;
  url: string;
  apiKey?: string;
  enabled: boolean;
  events: WebhookEvent[];
  headers?: Record<string, string>;
  createdAt: number;
  lastTriggered?: number;
  successCount: number;
  failureCount: number;
}

export type WebhookEvent = 
  | "analysis_created"
  | "deal_found"
  | "alert_triggered"
  | "portfolio_updated"
  | "price_changed";

export interface WebhookPayload {
  event: WebhookEvent;
  timestamp: number;
  data: FractionalGoldItem | Record<string, unknown>;
}

export interface IntegrationTemplate {
  id: string;
  name: string;
  provider: "google_sheets" | "hubspot" | "salesforce" | "zapier" | "airtable" | "notion" | "custom";
  description: string;
  icon: string;
  requiredFields: string[];
  setupInstructions: string;
  webhookFormat: string;
}

export interface IntegrationLog {
  id: string;
  webhookId: string;
  event: WebhookEvent;
  status: "success" | "failure";
  statusCode?: number;
  responseTime: number;
  timestamp: number;
  error?: string;
}

const STORAGE_KEYS = {
  WEBHOOKS: "gold_webhooks",
  INTEGRATION_LOGS: "gold_integration_logs",
  API_KEYS: "gold_api_keys"
};

/**
 * CRM Integration Templates
 */
export const INTEGRATION_TEMPLATES: IntegrationTemplate[] = [
  {
    id: "google-sheets",
    name: "Google Sheets",
    provider: "google_sheets",
    description: "Automatically log all analyses to a Google Sheet",
    icon: "📊",
    requiredFields: ["spreadsheetId", "apiKey"],
    setupInstructions: `1. Create a Google Sheet
2. Enable Google Sheets API in Google Cloud Console
3. Create API credentials
4. Copy your Spreadsheet ID from the URL
5. Paste credentials below`,
    webhookFormat: "https://sheets.googleapis.com/v4/spreadsheets/{spreadsheetId}/values:append"
  },
  {
    id: "hubspot",
    name: "HubSpot CRM",
    provider: "hubspot",
    description: "Create deals in HubSpot for high-score opportunities",
    icon: "🎯",
    requiredFields: ["apiKey"],
    setupInstructions: `1. Go to HubSpot Settings → Integrations → API Key
2. Generate a new API key
3. Paste below
4. Deals will auto-create for scores > 70`,
    webhookFormat: "https://api.hubapi.com/crm/v3/objects/deals"
  },
  {
    id: "salesforce",
    name: "Salesforce",
    provider: "salesforce",
    description: "Sync arbitrage opportunities to Salesforce",
    icon: "☁️",
    requiredFields: ["instanceUrl", "accessToken", "objectType"],
    setupInstructions: `1. Login to Salesforce
2. Setup → Apps → Connected Apps
3. Create new Connected App
4. Get OAuth credentials
5. Paste below`,
    webhookFormat: "{instanceUrl}/services/data/v58.0/sobjects/{objectType}"
  },
  {
    id: "zapier",
    name: "Zapier",
    provider: "zapier",
    description: "Connect to 5000+ apps via Zapier webhooks",
    icon: "⚡",
    requiredFields: ["webhookUrl"],
    setupInstructions: `1. Create a new Zap in Zapier
2. Choose "Webhooks by Zapier" as trigger
3. Copy the webhook URL
4. Paste below
5. Connect to any app (Slack, Discord, etc.)`,
    webhookFormat: "Custom webhook URL from Zapier"
  },
  {
    id: "airtable",
    name: "Airtable",
    provider: "airtable",
    description: "Log analyses to Airtable base",
    icon: "🗂️",
    requiredFields: ["baseId", "tableId", "apiKey"],
    setupInstructions: `1. Open your Airtable base
2. Go to Help → API Documentation
3. Copy Base ID and Table ID
4. Generate Personal Access Token
5. Paste below`,
    webhookFormat: "https://api.airtable.com/v0/{baseId}/{tableId}"
  },
  {
    id: "notion",
    name: "Notion",
    provider: "notion",
    description: "Save opportunities to Notion database",
    icon: "📝",
    requiredFields: ["databaseId", "integrationToken"],
    setupInstructions: `1. Create a Notion integration at notion.so/my-integrations
2. Share your database with the integration
3. Copy Database ID from URL
4. Paste credentials below`,
    webhookFormat: "https://api.notion.com/v1/pages"
  },
  {
    id: "custom",
    name: "Custom Webhook",
    provider: "custom",
    description: "Send data to any custom API endpoint",
    icon: "🔗",
    requiredFields: ["url"],
    setupInstructions: `1. Enter your API endpoint URL
2. Optionally add authentication headers
3. Data will be sent as JSON POST
4. Test the connection`,
    webhookFormat: "Custom URL with JSON payload"
  }
];

/**
 * Save webhook configuration
 */
export function saveWebhook(webhook: WebhookConfig): void {
  const webhooks = getWebhooks();
  const existing = webhooks.findIndex(w => w.id === webhook.id);
  
  if (existing !== -1) {
    webhooks[existing] = webhook;
  } else {
    webhooks.push(webhook);
  }
  
  localStorage.setItem(STORAGE_KEYS.WEBHOOKS, JSON.stringify(webhooks));
}

/**
 * Get all webhooks
 */
export function getWebhooks(): WebhookConfig[] {
  const stored = localStorage.getItem(STORAGE_KEYS.WEBHOOKS);
  return stored ? JSON.parse(stored) : [];
}

/**
 * Delete webhook
 */
export function deleteWebhook(id: string): void {
  const webhooks = getWebhooks().filter(w => w.id !== id);
  localStorage.setItem(STORAGE_KEYS.WEBHOOKS, JSON.stringify(webhooks));
}

/**
 * Trigger webhook with payload
 */
export async function triggerWebhook(
  webhookId: string, 
  event: WebhookEvent, 
  data: FractionalGoldItem | Record<string, unknown>
): Promise<void> {
  const webhooks = getWebhooks();
  const webhook = webhooks.find(w => w.id === webhookId);
  
  if (!webhook || !webhook.enabled) {
    return;
  }
  
  if (!webhook.events.includes(event)) {
    return;
  }
  
  const payload: WebhookPayload = {
    event,
    timestamp: Date.now(),
    data
  };
  
  const startTime = Date.now();
  
  try {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      ...(webhook.headers || {})
    };
    
    if (webhook.apiKey) {
      headers["Authorization"] = `Bearer ${webhook.apiKey}`;
    }
    
    const response = await fetch(webhook.url, {
      method: "POST",
      headers,
      body: JSON.stringify(payload)
    });
    
    const responseTime = Date.now() - startTime;
    
    // Log the webhook call
    logIntegration({
      id: Date.now().toString(),
      webhookId: webhook.id,
      event,
      status: response.ok ? "success" : "failure",
      statusCode: response.status,
      responseTime,
      timestamp: Date.now(),
      error: response.ok ? undefined : await response.text()
    });
    
    // Update webhook stats
    webhook.lastTriggered = Date.now();
    if (response.ok) {
      webhook.successCount += 1;
    } else {
      webhook.failureCount += 1;
    }
    saveWebhook(webhook);
    
  } catch (error) {
    const responseTime = Date.now() - startTime;
    
    logIntegration({
      id: Date.now().toString(),
      webhookId: webhook.id,
      event,
      status: "failure",
      responseTime,
      timestamp: Date.now(),
      error: error instanceof Error ? error.message : "Unknown error"
    });
    
    webhook.failureCount += 1;
    saveWebhook(webhook);
  }
}

/**
 * Trigger all webhooks for an event
 */
export async function triggerAllWebhooks(
  event: WebhookEvent,
  data: FractionalGoldItem | Record<string, unknown>
): Promise<void> {
  const webhooks = getWebhooks().filter(w => w.enabled && w.events.includes(event));
  
  await Promise.all(
    webhooks.map(webhook => triggerWebhook(webhook.id, event, data))
  );
}

/**
 * Log integration call
 */
function logIntegration(log: IntegrationLog): void {
  const logs = getIntegrationLogs();
  logs.unshift(log);
  
  // Keep last 500 logs
  const trimmed = logs.slice(0, 500);
  localStorage.setItem(STORAGE_KEYS.INTEGRATION_LOGS, JSON.stringify(trimmed));
}

/**
 * Get integration logs
 */
export function getIntegrationLogs(): IntegrationLog[] {
  const stored = localStorage.getItem(STORAGE_KEYS.INTEGRATION_LOGS);
  return stored ? JSON.parse(stored) : [];
}

/**
 * Get logs for specific webhook
 */
export function getWebhookLogs(webhookId: string): IntegrationLog[] {
  return getIntegrationLogs().filter(log => log.webhookId === webhookId);
}

/**
 * Test webhook connection
 */
export async function testWebhook(webhook: WebhookConfig): Promise<boolean> {
  try {
    const testPayload: WebhookPayload = {
      event: "analysis_created",
      timestamp: Date.now(),
      data: {
        test: true,
        message: "This is a test webhook from Gold Arbitrage Platform"
      }
    };
    
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      ...(webhook.headers || {})
    };
    
    if (webhook.apiKey) {
      headers["Authorization"] = `Bearer ${webhook.apiKey}`;
    }
    
    const response = await fetch(webhook.url, {
      method: "POST",
      headers,
      body: JSON.stringify(testPayload)
    });
    
    return response.ok;
  } catch {
    return false;
  }
}

/**
 * Format data for Google Sheets
 */
export function formatForGoogleSheets(item: FractionalGoldItem): string[][] {
  return [[
    new Date(item.timestamp).toISOString(),
    item.weightType,
    item.weightOz.toString(),
    item.purchasePrice.toString(),
    item.meltValue.toString(),
    item.premiumPct.toString(),
    item.resaleMargin.toString(),
    item.arbitrageScore.toString(),
    item.recommendation,
    item.dealer || ""
  ]];
}

/**
 * Format data for HubSpot Deal
 */
export function formatForHubSpot(item: FractionalGoldItem): Record<string, unknown> {
  return {
    properties: {
      dealname: `${item.weightType} Gold - Score ${item.arbitrageScore}`,
      amount: item.purchasePrice,
      dealstage: item.recommendation === "BUY" ? "qualifiedtobuy" : "appointmentscheduled",
      pipeline: "default",
      closedate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).getTime(), // 7 days from now
      description: `Arbitrage Score: ${item.arbitrageScore}\nPremium: ${item.premiumPct}%\nResale Margin: $${item.resaleMargin}\nDealer: ${item.dealer || "Unknown"}`
    }
  };
}

/**
 * Format data for Salesforce
 */
export function formatForSalesforce(item: FractionalGoldItem): Record<string, unknown> {
  return {
    Name: `${item.weightType} Gold Opportunity`,
    Amount: item.purchasePrice,
    StageName: item.recommendation === "BUY" ? "Qualified" : "Prospecting",
    CloseDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    Description: `Arbitrage Score: ${item.arbitrageScore}\nPremium: ${item.premiumPct}%\nMelt Value: $${item.meltValue}`,
    Type: "New Business"
  };
}

/**
 * Format data for Airtable
 */
export function formatForAirtable(item: FractionalGoldItem): Record<string, unknown> {
  return {
    fields: {
      "Weight Type": item.weightType,
      "Weight (oz)": item.weightOz,
      "Purchase Price": item.purchasePrice,
      "Melt Value": item.meltValue,
      "Premium %": item.premiumPct,
      "Arbitrage Score": item.arbitrageScore,
      "Recommendation": item.recommendation,
      "Dealer": item.dealer || "",
      "Timestamp": new Date(item.timestamp).toISOString()
    }
  };
}

/**
 * Format data for Notion
 */
export function formatForNotion(item: FractionalGoldItem): Record<string, unknown> {
  return {
    parent: { database_id: "" }, // Will be filled by user config
    properties: {
      "Name": {
        title: [{ text: { content: `${item.weightType} - ${item.recommendation}` } }]
      },
      "Score": {
        number: item.arbitrageScore
      },
      "Premium": {
        number: parseFloat(item.premiumPct.toFixed(2))
      },
      "Price": {
        number: item.purchasePrice
      },
      "Recommendation": {
        select: { name: item.recommendation }
      },
      "Date": {
        date: { start: new Date(item.timestamp).toISOString() }
      }
    }
  };
}
