/**
 * Notification System
 * SMS, Email, and Push notifications for deal alerts
 */

export interface NotificationPreferences {
  userId: string;
  email?: string;
  phone?: string;
  pushEnabled: boolean;
  emailEnabled: boolean;
  smsEnabled: boolean;
  minArbitrageScore: number;
  maxPremium: number;
  preferredWeights: string[];
}

export interface Notification {
  id: string;
  type: "deal_alert" | "price_drop" | "portfolio_alert" | "market_update";
  title: string;
  message: string;
  priority: "low" | "medium" | "high";
  data?: Record<string, unknown>;
  createdAt: number;
  sent: boolean;
}

/**
 * Send email notification
 */
export async function sendEmailNotification(
  to: string,
  subject: string,
  body: string
): Promise<boolean> {
  try {
    // In production, integrate with SendGrid, AWS SES, or similar
    console.log(`📧 Email to ${to}: ${subject}`);
    console.log(body);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 100));
    
    return true;
  } catch (error) {
    console.error("Email sending failed:", error);
    return false;
  }
}

/**
 * Send SMS notification
 */
export async function sendSMSNotification(
  phone: string,
  message: string
): Promise<boolean> {
  try {
    // In production, integrate with Twilio, AWS SNS, or similar
    console.log(`📱 SMS to ${phone}: ${message}`);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 100));
    
    return true;
  } catch (error) {
    console.error("SMS sending failed:", error);
    return false;
  }
}

/**
 * Send push notification
 */
export async function sendPushNotification(
  userId: string,
  title: string,
  message: string,
  data?: Record<string, unknown>
): Promise<boolean> {
  try {
    // In production, integrate with Firebase Cloud Messaging, OneSignal, or similar
    console.log(`🔔 Push to ${userId}: ${title} - ${message}`);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 100));
    
    return true;
  } catch (error) {
    console.error("Push notification failed:", error);
    return false;
  }
}

/**
 * Create deal alert notification
 */
export function createDealAlert(
  weightType: string,
  price: number,
  arbitrageScore: number,
  dealer: string
): Notification {
  return {
    id: Date.now().toString(),
    type: "deal_alert",
    title: "🔥 Hot Deal Alert!",
    message: `${weightType} oz gold at $${price} from ${dealer} - Score: ${arbitrageScore}/100`,
    priority: arbitrageScore >= 80 ? "high" : "medium",
    data: {
      weightType,
      price,
      arbitrageScore,
      dealer
    },
    createdAt: Date.now(),
    sent: false
  };
}

/**
 * Create price drop notification
 */
export function createPriceDropAlert(
  productName: string,
  oldPrice: number,
  newPrice: number,
  percentDrop: number
): Notification {
  return {
    id: Date.now().toString(),
    type: "price_drop",
    title: "📉 Price Drop Alert",
    message: `${productName} dropped ${percentDrop.toFixed(1)}% to $${newPrice} (was $${oldPrice})`,
    priority: percentDrop > 5 ? "high" : "medium",
    data: {
      productName,
      oldPrice,
      newPrice,
      percentDrop
    },
    createdAt: Date.now(),
    sent: false
  };
}

/**
 * Send notification based on preferences
 */
export async function sendNotification(
  notification: Notification,
  preferences: NotificationPreferences
): Promise<void> {
  const results: Promise<boolean>[] = [];

  if (preferences.emailEnabled && preferences.email) {
    results.push(
      sendEmailNotification(
        preferences.email,
        notification.title,
        notification.message
      )
    );
  }

  if (preferences.smsEnabled && preferences.phone) {
    results.push(
      sendSMSNotification(
        preferences.phone,
        `${notification.title}: ${notification.message}`
      )
    );
  }

  if (preferences.pushEnabled) {
    results.push(
      sendPushNotification(
        preferences.userId,
        notification.title,
        notification.message,
        notification.data
      )
    );
  }

  await Promise.all(results);
  notification.sent = true;
}

/**
 * Batch send notifications
 */
export async function batchSendNotifications(
  notifications: Notification[],
  preferences: NotificationPreferences
): Promise<void> {
  // Rate limit to avoid spam
  const highPriority = notifications.filter(n => n.priority === "high");
  const otherPriority = notifications.filter(n => n.priority !== "high");

  // Send high priority immediately
  for (const notification of highPriority) {
    await sendNotification(notification, preferences);
  }

  // Send others in batches
  if (otherPriority.length > 0) {
    // Only send digest for non-urgent notifications
    const digest: Notification = {
      id: Date.now().toString(),
      type: "market_update",
      title: `${otherPriority.length} New Market Updates`,
      message: otherPriority.map(n => n.message).join("\n"),
      priority: "low",
      createdAt: Date.now(),
      sent: false
    };

    await sendNotification(digest, preferences);
  }
}

/**
 * Schedule notification for future delivery
 */
export interface ScheduledNotification {
  notification: Notification;
  preferences: NotificationPreferences;
  sendAt: number;
}

const scheduledNotifications: ScheduledNotification[] = [];

export function scheduleNotification(
  notification: Notification,
  preferences: NotificationPreferences,
  sendAt: number
): void {
  scheduledNotifications.push({
    notification,
    preferences,
    sendAt
  });
}

/**
 * Process scheduled notifications
 */
export async function processScheduledNotifications(): Promise<void> {
  const now = Date.now();
  const toSend = scheduledNotifications.filter(sn => sn.sendAt <= now);

  for (const scheduled of toSend) {
    await sendNotification(scheduled.notification, scheduled.preferences);
  }

  // Remove sent notifications
  scheduledNotifications.splice(0, toSend.length);
}

/**
 * Get notification history
 */
export function getNotificationHistory(userId: string): Notification[] {
  // In production, fetch from database
  // For now, return from localStorage
  if (typeof window === "undefined") return [];
  
  const stored = localStorage.getItem(`notifications_${userId}`);
  return stored ? JSON.parse(stored) : [];
}

/**
 * Save notification to history
 */
export function saveNotificationToHistory(userId: string, notification: Notification): void {
  if (typeof window === "undefined") return;
  
  const history = getNotificationHistory(userId);
  history.unshift(notification);
  
  // Keep last 100 notifications
  const trimmed = history.slice(0, 100);
  localStorage.setItem(`notifications_${userId}`, JSON.stringify(trimmed));
}
