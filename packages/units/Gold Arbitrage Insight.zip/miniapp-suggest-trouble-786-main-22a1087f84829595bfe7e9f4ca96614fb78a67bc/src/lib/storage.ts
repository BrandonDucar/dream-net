/**
 * Local Storage Management for Historical Data and User Preferences
 */

import type { 
  FractionalGoldItem, 
  DealAlert, 
  CommunityDeal,
  HistoricalPremium 
} from "@/types/gold";

const STORAGE_KEYS = {
  ANALYSIS_HISTORY: "gold_analysis_history",
  DEAL_ALERTS: "gold_deal_alerts",
  COMMUNITY_DEALS: "gold_community_deals",
  HISTORICAL_PREMIUMS: "gold_historical_premiums",
  USER_PORTFOLIO: "gold_user_portfolio",
  PREFERENCES: "gold_user_preferences"
};

/**
 * Save analysis to history
 */
export async function saveAnalysis(item: FractionalGoldItem): Promise<void> {
  const history = getAnalysisHistory();
  history.unshift(item);
  
  // Keep last 100 analyses
  const trimmed = history.slice(0, 100);
  localStorage.setItem(STORAGE_KEYS.ANALYSIS_HISTORY, JSON.stringify(trimmed));
  
  // Trigger webhooks for analysis_created event
  if (typeof window !== "undefined") {
    const { triggerAllWebhooks } = await import("@/lib/integrations");
    await triggerAllWebhooks("analysis_created", item);
    
    // Also trigger deal_found if score is high
    if (item.arbitrageScore >= 70) {
      await triggerAllWebhooks("deal_found", {
        weightType: item.weightType,
        arbitrageScore: item.arbitrageScore,
        dealer: item.dealer || "Unknown",
        savings: item.resaleMargin,
        timestamp: item.timestamp
      });
    }
  }
}

/**
 * Get analysis history
 */
export function getAnalysisHistory(): FractionalGoldItem[] {
  const stored = localStorage.getItem(STORAGE_KEYS.ANALYSIS_HISTORY);
  return stored ? JSON.parse(stored) : [];
}

/**
 * Save deal alert
 */
export function saveDealAlert(alert: DealAlert): void {
  const alerts = getDealAlerts();
  alerts.push(alert);
  localStorage.setItem(STORAGE_KEYS.DEAL_ALERTS, JSON.stringify(alerts));
}

/**
 * Get deal alerts
 */
export function getDealAlerts(): DealAlert[] {
  const stored = localStorage.getItem(STORAGE_KEYS.DEAL_ALERTS);
  return stored ? JSON.parse(stored) : [];
}

/**
 * Update deal alert
 */
export function updateDealAlert(id: string, updates: Partial<DealAlert>): void {
  const alerts = getDealAlerts();
  const index = alerts.findIndex(a => a.id === id);
  
  if (index !== -1) {
    alerts[index] = { ...alerts[index], ...updates };
    localStorage.setItem(STORAGE_KEYS.DEAL_ALERTS, JSON.stringify(alerts));
  }
}

/**
 * Delete deal alert
 */
export function deleteDealAlert(id: string): void {
  const alerts = getDealAlerts().filter(a => a.id !== id);
  localStorage.setItem(STORAGE_KEYS.DEAL_ALERTS, JSON.stringify(alerts));
}

/**
 * Save community deal
 */
export function saveCommunityDeal(deal: CommunityDeal): void {
  const deals = getCommunityDeals();
  deals.unshift(deal);
  localStorage.setItem(STORAGE_KEYS.COMMUNITY_DEALS, JSON.stringify(deals.slice(0, 50)));
}

/**
 * Get community deals
 */
export function getCommunityDeals(): CommunityDeal[] {
  const stored = localStorage.getItem(STORAGE_KEYS.COMMUNITY_DEALS);
  return stored ? JSON.parse(stored) : [];
}

/**
 * Upvote community deal
 */
export function upvoteDeal(id: string): void {
  const deals = getCommunityDeals();
  const deal = deals.find(d => d.id === id);
  
  if (deal) {
    deal.upvotes += 1;
    localStorage.setItem(STORAGE_KEYS.COMMUNITY_DEALS, JSON.stringify(deals));
  }
}

/**
 * Save historical premium data
 */
export function saveHistoricalPremium(data: HistoricalPremium): void {
  const history = getHistoricalPremiums();
  history.push(data);
  
  // Keep last 1000 data points
  const trimmed = history.slice(-1000);
  localStorage.setItem(STORAGE_KEYS.HISTORICAL_PREMIUMS, JSON.stringify(trimmed));
}

/**
 * Get historical premiums
 */
export function getHistoricalPremiums(): HistoricalPremium[] {
  const stored = localStorage.getItem(STORAGE_KEYS.HISTORICAL_PREMIUMS);
  return stored ? JSON.parse(stored) : [];
}

/**
 * Get user portfolio
 */
export function getUserPortfolio(): string[] {
  const stored = localStorage.getItem(STORAGE_KEYS.USER_PORTFOLIO);
  return stored ? JSON.parse(stored) : [];
}

/**
 * Update user portfolio
 */
export function updateUserPortfolio(weights: string[]): void {
  localStorage.setItem(STORAGE_KEYS.USER_PORTFOLIO, JSON.stringify(weights));
}

/**
 * Get user preferences
 */
export function getUserPreferences(): Record<string, unknown> {
  const stored = localStorage.getItem(STORAGE_KEYS.PREFERENCES);
  return stored ? JSON.parse(stored) : {
    defaultPaymentMethod: "Wire",
    notificationEmail: "",
    autoRefreshInterval: 300000, // 5 minutes
    showDealerComparison: true,
    showHistoricalCharts: true
  };
}

/**
 * Save user preferences
 */
export function saveUserPreferences(prefs: Record<string, unknown>): void {
  localStorage.setItem(STORAGE_KEYS.PREFERENCES, JSON.stringify(prefs));
}
