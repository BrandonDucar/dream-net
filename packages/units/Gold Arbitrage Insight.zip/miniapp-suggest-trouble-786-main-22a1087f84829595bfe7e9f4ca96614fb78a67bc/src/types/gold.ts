/**
 * Comprehensive Type Definitions for Fractional Gold Arbitrage Platform
 */

export interface FractionalGoldItem {
  id: string;
  weightType: string;
  weightOz: number;
  purchasePrice: number;
  marketComp: number;
  meltValue: number;
  premiumPct: number;
  resaleMargin: number;
  arbitrageScore: number;
  recommendation: "BUY" | "PASS";
  timestamp: number;
  dealer?: string;
  liquidityScore?: number;
  trueCost?: number;
  shippingCost?: number;
  paymentFees?: number;
  source?: string;
}

export interface SpotPrice {
  gold: number;
  silver: number;
  platinum: number;
  palladium: number;
  timestamp: number;
  source: string;
}

export interface DealerPrice {
  dealer: string;
  price: number;
  inStock: boolean;
  shippingCost: number;
  paymentMethods: string[];
  url: string;
  reputation: number;
  deliveryDays: number;
}

export interface HistoricalPremium {
  weightType: string;
  date: number;
  premiumPct: number;
  spotPrice: number;
  averagePrice: number;
}

export interface DealAlert {
  id: string;
  weightType: string;
  targetScore: number;
  targetPremium: number;
  active: boolean;
  notificationMethod: "email" | "sms" | "push";
  createdAt: number;
}

export interface CommunityDeal {
  id: string;
  weightType: string;
  price: number;
  dealer: string;
  location: string;
  submittedBy: string;
  timestamp: number;
  upvotes: number;
  verified: boolean;
}

export interface LiquidityMetrics {
  weightType: string;
  avgDaysToSell: number;
  bidAskSpread: number;
  marketDepth: number;
  popularityScore: number;
}

export interface PricePrediction {
  weightType: string;
  currentPremium: number;
  predictedPremium: number;
  confidence: number;
  trend: "UP" | "DOWN" | "STABLE";
  timeframe: string;
}

export interface PortfolioRecommendation {
  action: "BUY" | "SELL" | "HOLD";
  weightType: string;
  reasoning: string;
  urgency: "HIGH" | "MEDIUM" | "LOW";
  expectedReturn: number;
}

export interface DealerReputation {
  dealer: string;
  rating: number;
  totalReviews: number;
  shippingSpeed: number;
  authenticity: number;
  customerService: number;
  lastUpdated: number;
}
