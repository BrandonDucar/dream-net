import { NextResponse } from 'next/server';

// Multi-source gold spot price fetcher with fallbacks
export async function GET(): Promise<NextResponse> {
  console.log('🔍 Starting gold spot price fetch...');
  
  const sources = [
    { name: 'metals.live', fn: fetchFromMetalsLive },
    { name: 'goldapi.io', fn: fetchFromGoldAPI },
    { name: 'metalpriceapi.com', fn: fetchFromMetalpriceAPI }
  ];

  for (const source of sources) {
    try {
      console.log(`⏳ Trying ${source.name}...`);
      const result = await source.fn();
      if (result && result.gold > 0) {
        console.log(`✅ Successfully fetched from ${source.name}: $${result.gold}`);
        return NextResponse.json(result);
      }
    } catch (error) {
      console.error(`❌ ${source.name} failed:`, error);
      continue;
    }
  }

  // All sources failed - return fallback price
  console.warn('⚠️ All sources failed, returning fallback price');
  return NextResponse.json({
    gold: 4193.00,
    currency: 'USD',
    timestamp: Date.now(),
    source: 'fallback (all APIs failed)',
    isFallback: true
  });
}

// Source 1: Metals.live (primary)
async function fetchFromMetalsLive() {
  const response = await fetch('https://api.metals.live/v1/spot', {
    headers: { 'Accept': 'application/json' },
    cache: 'no-store',
    next: { revalidate: 0 }
  });

  if (!response.ok) throw new Error(`metals.live returned ${response.status}`);

  const data = await response.json() as Array<{
    metal: string;
    price: number;
    currency: string;
    timestamp: number;
  }>;

  const goldData = data.find((item: { metal: string }) => item.metal.toLowerCase() === 'gold');
  
  if (!goldData) throw new Error('Gold data not found');

  return {
    gold: goldData.price,
    currency: goldData.currency ?? 'USD',
    timestamp: goldData.timestamp ?? Date.now(),
    source: 'metals.live'
  };
}

// Source 2: GoldAPI.io (FOREX + LBMA)
async function fetchFromGoldAPI() {
  const response = await fetch('https://www.goldapi.io/api/XAU/USD', {
    headers: { 
      'x-access-token': 'goldapi-demo',
      'Content-Type': 'application/json'
    },
    cache: 'no-store',
    next: { revalidate: 0 }
  });

  if (!response.ok) throw new Error(`goldapi.io returned ${response.status}`);

  const data = await response.json() as {
    price: number;
    timestamp: number;
  };

  return {
    gold: data.price,
    currency: 'USD',
    timestamp: data.timestamp ?? Date.now(),
    source: 'goldapi.io'
  };
}

// Source 3: MetalpriceAPI (backup)
async function fetchFromMetalpriceAPI() {
  const response = await fetch('https://api.metalpriceapi.com/v1/latest?api_key=demo&base=USD&currencies=XAU', {
    headers: { 'Accept': 'application/json' },
    cache: 'no-store',
    next: { revalidate: 0 }
  });

  if (!response.ok) throw new Error(`metalpriceapi returned ${response.status}`);

  const data = await response.json() as {
    rates: { XAU: number };
    timestamp: number;
  };

  // MetalpriceAPI returns rate as USD per XAU, need to invert
  const goldPrice = 1 / data.rates.XAU;

  return {
    gold: goldPrice,
    currency: 'USD',
    timestamp: data.timestamp ?? Date.now(),
    source: 'metalpriceapi.com'
  };
}
