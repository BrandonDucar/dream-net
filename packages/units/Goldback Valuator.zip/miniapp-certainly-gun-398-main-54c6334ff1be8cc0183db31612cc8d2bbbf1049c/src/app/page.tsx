'use client'
import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { RefreshCw, TrendingUp, Info, Calculator, Store } from 'lucide-react';
import { 
  GOLDBACK_DENOMINATIONS, 
  GOLDBACK_OZ_PER_NOTE,
  type GoldbackDenomination 
} from '@/lib/goldback';
import { getDealerPrices, type DealerPrice } from '@/lib/dealers';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type SpotData = {
  gold: number;
  currency: string;
  timestamp: number;
  source?: string;
};

export default function GoldbackCalculator(): JSX.Element {
  const { addMiniApp } = useAddMiniApp();
  const isInFarcaster = useIsInFarcaster()
  useQuickAuth(isInFarcaster)
  useEffect(() => {
    const tryAddMiniApp = async () => {
      try {
        await addMiniApp()
      } catch (error) {
        console.error('Failed to add mini app:', error)
      }
    }
    tryAddMiniApp()
  }, [addMiniApp])
  useEffect(() => {
    const initializeFarcaster = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 100))
        
        if (document.readyState !== 'complete') {
          await new Promise<void>(resolve => {
            if (document.readyState === 'complete') {
              resolve()
            } else {
              window.addEventListener('load', () => resolve(), { once: true })
            }
          })
        }
        await sdk.actions.ready()
        console.log('Farcaster SDK initialized successfully - app fully loaded')
      } catch (error) {
        console.error('Failed to initialize Farcaster SDK:', error)
        setTimeout(async () => {
          try {
            await sdk.actions.ready()
            console.log('Farcaster SDK initialized on retry')
          } catch (retryError) {
            console.error('Farcaster SDK retry failed:', retryError)
          }
        }, 1000)
      }
    }
    initializeFarcaster()
  }, [])

  const [goldSpot, setGoldSpot] = useState<number>(4193.00); // Default to current approximate price
  const [source, setSource] = useState<string>('');
  const [lastUpdated, setLastUpdated] = useState<number | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [selectedDenom, setSelectedDenom] = useState<GoldbackDenomination | null>(null);
  const [calcQuantity, setCalcQuantity] = useState<number>(1);

  useEffect(() => {
    fetchSpot();
  }, []);

  const fetchSpot = async (): Promise<void> => {
    console.log('🚀 Client: Starting fetchSpot...');
    setLoading(true);
    try {
      const response = await fetch('/api/spot', {
        cache: 'no-store',
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache'
        }
      });
      
      console.log('📡 Client: Received response:', response.status);
      
      if (!response.ok) {
        console.error('❌ Client: Response not OK:', response.status, response.statusText);
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json() as SpotData;
      console.log('📦 Client: Parsed data:', data);
      
      setGoldSpot(data.gold);
      setLastUpdated(data.timestamp);
      setSource(data.source ?? '');
      console.log(`✅ Client: Gold spot updated to $${data.gold} from ${data.source}`);
    } catch (error) {
      console.error('❌ Client: Failed to fetch spot price:', error);
      // Set fallback price on error
      setGoldSpot(4193.00);
      setLastUpdated(Date.now());
      setSource('fallback (fetch error)');
    } finally {
      setLoading(false);
    }
  };

  const getDenomColor = (denom: GoldbackDenomination): string => {
    if (denom === 0.5) return 'from-gray-600 to-gray-700';
    if (denom === 1) return 'from-amber-600 to-amber-700';
    if (denom === 2) return 'from-orange-600 to-orange-700';
    if (denom === 3) return 'from-rose-600 to-rose-700';
    if (denom === 5) return 'from-purple-600 to-purple-700';
    if (denom === 10) return 'from-cyan-600 to-cyan-700';
    if (denom === 25) return 'from-emerald-600 to-emerald-700';
    if (denom === 50) return 'from-blue-600 to-blue-700';
    return 'from-indigo-600 to-indigo-700';
  };

  const getMeltValue = (denom: GoldbackDenomination): number => {
    return GOLDBACK_OZ_PER_NOTE[denom] * goldSpot;
  };

  const getTypicalPremium = (): number => 35; // Typical 35% premium over melt

  const getTypicalRetailPrice = (denom: GoldbackDenomination): number => {
    const melt = getMeltValue(denom);
    return melt * (1 + getTypicalPremium() / 100);
  };

  const formatDenom = (denom: GoldbackDenomination): string => {
    return denom === 0.5 ? '½' : denom.toString();
  };

  const dealerPrices = selectedDenom 
    ? getDealerPrices('Utah', selectedDenom)
    : [];

  const calcMelt = selectedDenom 
    ? GOLDBACK_OZ_PER_NOTE[selectedDenom] * goldSpot * calcQuantity
    : 0;

  const calcTypicalPrice = selectedDenom 
    ? getTypicalRetailPrice(selectedDenom) * calcQuantity
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#020617] via-[#0a0e1a] to-[#020617] text-gray-100">
      {/* Hero Header */}
      <div className="relative overflow-hidden border-b border-cyan-600/30 bg-gradient-to-r from-cyan-950/30 to-purple-950/30">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyZDNlZSIgc3Ryb2tlLW9wYWNpdHk9IjAuMSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-20"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 py-8 md:py-12">
          <div className="text-center space-y-4">
            <h1 className="text-4xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-400">
              Goldback Calculator
            </h1>
            <p className="text-gray-400 text-lg">Real-time valuations & dealer pricing</p>
          </div>

          {/* MASSIVE Gold Spot Price */}
          <div className="mt-8 flex flex-col items-center gap-6">
            <div className="w-full max-w-3xl">
              <div className="flex flex-col items-center gap-4 p-8 md:p-12 bg-gradient-to-br from-amber-900/40 via-yellow-900/40 to-amber-900/40 border-2 border-amber-500/50 rounded-3xl shadow-2xl shadow-amber-600/30">
                <TrendingUp className="h-12 w-12 md:h-16 md:w-16 text-amber-400 animate-pulse" />
                <div className="text-center space-y-2">
                  <div className="text-base md:text-xl text-amber-300 uppercase tracking-widest font-bold">Live Gold Spot Price</div>
                  <div className="text-7xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-300 tracking-tighter leading-none">
                    ${goldSpot.toFixed(2)}
                  </div>
                  <div className="text-xl md:text-2xl text-amber-400/80 font-semibold">per troy ounce</div>
                </div>
              </div>
            </div>

            <div className="flex flex-col items-center gap-2">
              {lastUpdated && (
                <div className="text-sm text-gray-400">
                  Last updated: {new Date(lastUpdated).toLocaleTimeString()}
                  {source && <span className="text-gray-600 ml-2">• {source}</span>}
                </div>
              )}
              
              <Button 
                onClick={fetchSpot} 
                disabled={loading}
                size="lg"
                className="bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-700 hover:to-yellow-700 text-white shadow-xl shadow-amber-600/40 text-base font-bold"
              >
                <RefreshCw className={`h-5 w-5 mr-2 ${loading ? 'animate-spin' : ''}`} />
                Refresh Gold Price
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        {/* Denomination Grid */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Info className="h-5 w-5 text-cyan-400" />
            <h2 className="text-2xl font-bold text-gray-100">Goldback Denominations</h2>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {GOLDBACK_DENOMINATIONS.map((denom: GoldbackDenomination) => {
              const melt = getMeltValue(denom);
              const retail = getTypicalRetailPrice(denom);
              const oz = GOLDBACK_OZ_PER_NOTE[denom];
              const isSelected = selectedDenom === denom;

              return (
                <Card 
                  key={denom}
                  className={`group cursor-pointer transition-all duration-300 hover:scale-105 ${
                    isSelected 
                      ? 'bg-gradient-to-br from-cyan-900/50 to-purple-900/50 border-cyan-400 shadow-xl shadow-cyan-400/30' 
                      : 'bg-[#0b1120] border-[#1e293b] hover:border-cyan-600/50'
                  }`}
                  onClick={() => setSelectedDenom(denom)}
                >
                  <CardContent className="p-4 space-y-3">
                    {/* Denomination Badge */}
                    <div className={`w-full h-24 rounded-lg bg-gradient-to-br ${getDenomColor(denom)} flex items-center justify-center shadow-lg`}>
                      <div className="text-center">
                        <div className="text-4xl font-black text-white">{formatDenom(denom)}</div>
                        <div className="text-xs text-white/80 uppercase tracking-wider">Goldback</div>
                      </div>
                    </div>

                    {/* Gold Content */}
                    <div className="space-y-1">
                      <div className="text-xs text-gray-500 uppercase">Gold Content</div>
                      <div className="text-sm font-bold text-amber-400">
                        {oz < 0.001 ? oz.toExponential(2) : oz.toFixed(4)} oz
                      </div>
                    </div>

                    {/* Melt Value */}
                    <div className="space-y-1">
                      <div className="text-xs text-gray-500 uppercase">Melt Value</div>
                      <div className="text-lg font-bold text-green-400">
                        ${melt.toFixed(2)}
                      </div>
                    </div>

                    {/* Typical Retail */}
                    <div className="space-y-1">
                      <div className="text-xs text-gray-500 uppercase">Typical Retail</div>
                      <div className="text-lg font-bold text-cyan-400">
                        ${retail.toFixed(2)}
                      </div>
                      <div className="text-xs text-gray-600">
                        (~{getTypicalPremium()}% premium)
                      </div>
                    </div>

                    {isSelected && (
                      <div className="pt-2 border-t border-cyan-600/30">
                        <div className="text-xs text-cyan-400 font-semibold text-center">
                          ✓ Selected
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Calculator & Dealer Comparison */}
        {selectedDenom && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Quick Calculator */}
            <Card className="bg-[#0b1120] border-[#1e293b]">
              <CardContent className="p-6 space-y-6">
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-cyan-400" />
                  <h3 className="text-xl font-bold text-gray-100">
                    Calculator: {formatDenom(selectedDenom)} Goldback
                  </h3>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm text-gray-400 uppercase tracking-wide">Quantity</label>
                    <Input
                      type="number"
                      min="1"
                      value={calcQuantity}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCalcQuantity(parseInt(e.target.value) || 1)}
                      className="bg-[#020617] border-[#1e293b] text-gray-100 text-2xl h-14"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-[#020617] border border-green-600/30 rounded-lg">
                      <div className="text-xs text-gray-500 uppercase mb-1">Melt Value</div>
                      <div className="text-2xl font-bold text-green-400">
                        ${calcMelt.toFixed(2)}
                      </div>
                    </div>
                    
                    <div className="p-4 bg-[#020617] border border-cyan-600/30 rounded-lg">
                      <div className="text-xs text-gray-500 uppercase mb-1">Typical Retail</div>
                      <div className="text-2xl font-bold text-cyan-400">
                        ${calcTypicalPrice.toFixed(2)}
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-gradient-to-r from-amber-900/20 to-yellow-900/20 border border-amber-600/30 rounded-lg">
                    <div className="text-xs text-gray-400 uppercase mb-1">Total Gold Content</div>
                    <div className="text-xl font-bold text-amber-400">
                      {(GOLDBACK_OZ_PER_NOTE[selectedDenom] * calcQuantity).toFixed(6)} oz
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Dealer Prices */}
            <Card className="bg-[#0b1120] border-[#1e293b]">
              <CardContent className="p-6 space-y-6">
                <div className="flex items-center gap-2">
                  <Store className="h-5 w-5 text-cyan-400" />
                  <h3 className="text-xl font-bold text-gray-100">
                    Dealer Prices: {formatDenom(selectedDenom)} GB (Utah)
                  </h3>
                </div>

                <div className="space-y-3">
                  {dealerPrices.length > 0 ? (
                    dealerPrices.map((price: DealerPrice, idx: number) => {
                      const totalPrice = price.pricePerUnit * calcQuantity;
                      const meltValue = getMeltValue(selectedDenom) * calcQuantity;
                      const premium = ((totalPrice / meltValue) - 1) * 100;
                      const isLowest = idx === 0;

                      return (
                        <div 
                          key={`${price.dealer}-${idx}`}
                          className={`p-4 rounded-lg border transition-all ${
                            isLowest 
                              ? 'bg-gradient-to-r from-green-900/30 to-emerald-900/30 border-green-600/50 shadow-lg shadow-green-600/20' 
                              : 'bg-[#020617] border-[#1e293b]'
                          }`}
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <div className="font-bold text-gray-100">{price.dealer}</div>
                              {isLowest && (
                                <div className="text-xs text-green-400 font-semibold">BEST PRICE</div>
                              )}
                            </div>
                            <div className="text-right">
                              <div className="text-2xl font-bold text-cyan-400">
                                ${price.pricePerUnit.toFixed(2)}
                              </div>
                              <div className="text-xs text-gray-500">per unit</div>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-3 mt-3 pt-3 border-t border-gray-800">
                            <div>
                              <div className="text-xs text-gray-500">Total ({calcQuantity}x)</div>
                              <div className="text-lg font-bold text-gray-100">
                                ${totalPrice.toFixed(2)}
                              </div>
                            </div>
                            <div>
                              <div className="text-xs text-gray-500">Premium</div>
                              <div className={`text-lg font-bold ${
                                premium <= 30 ? 'text-green-400' : 
                                premium <= 40 ? 'text-amber-400' : 
                                'text-red-400'
                              }`}>
                                {premium.toFixed(1)}%
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="text-center text-gray-500 py-8">
                      No dealer pricing available for this denomination
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {!selectedDenom && (
          <Card className="bg-gradient-to-br from-cyan-900/20 to-purple-900/20 border-cyan-600/30">
            <CardContent className="p-12 text-center">
              <div className="text-6xl mb-4">👆</div>
              <h3 className="text-2xl font-bold text-gray-100 mb-2">
                Select a Goldback denomination
              </h3>
              <p className="text-gray-400">
                Click any card above to see detailed pricing, calculations, and dealer comparisons
              </p>
            </CardContent>
          </Card>
        )}

        {/* Info Panel */}
        <Card className="bg-gradient-to-r from-amber-900/20 to-yellow-900/20 border-amber-600/30">
          <CardContent className="p-6">
            <div className="flex items-start gap-3">
              <Info className="h-5 w-5 text-amber-400 mt-1 flex-shrink-0" />
              <div className="space-y-2 text-sm text-gray-300">
                <p className="font-semibold text-amber-400">About Goldbacks:</p>
                <p>
                  Goldbacks are physical gold notes containing precise amounts of 24-karat gold. 
                  Each denomination contains a specific fraction of a troy ounce, making them 
                  easily divisible and spendable.
                </p>
                <p>
                  <span className="text-green-400 font-semibold">Melt Value</span> is the pure gold content value at current spot price. 
                  <span className="text-cyan-400 font-semibold ml-2">Retail Price</span> includes premium for manufacturing, design, and dealer markup.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
