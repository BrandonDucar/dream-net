'use client'

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Switch } from '@/components/ui/switch';
import { Bell, Trash2, Plus } from 'lucide-react';
import type { PriceAlert } from '@/lib/storage';
import { loadAlerts, saveAlerts } from '@/lib/storage';
import { GOLDBACK_STATES, GOLDBACK_DENOMINATIONS } from '@/lib/goldback';
import type { GoldbackState, GoldbackDenomination } from '@/lib/goldback';

type AlertsManagerProps = {
  goldSpot: number | null;
};

export function AlertsManager({ goldSpot }: AlertsManagerProps): JSX.Element {
  const [alerts, setAlerts] = useState<PriceAlert[]>([]);
  const [showForm, setShowForm] = useState<boolean>(false);
  
  const [alertType, setAlertType] = useState<'premium' | 'spot'>('premium');
  const [alertState, setAlertState] = useState<GoldbackState>('Utah');
  const [alertDenom, setAlertDenom] = useState<GoldbackDenomination>(1);
  const [alertCondition, setAlertCondition] = useState<'above' | 'below'>('below');
  const [alertThreshold, setAlertThreshold] = useState<string>('');

  useEffect(() => {
    setAlerts(loadAlerts());
  }, []);

  const handleAddAlert = (): void => {
    const threshold = parseFloat(alertThreshold);
    if (isNaN(threshold)) return;

    const newAlert: PriceAlert = {
      id: `${Date.now()}-${Math.random()}`,
      type: alertType,
      state: alertType === 'premium' ? alertState : undefined,
      denomination: alertType === 'premium' ? alertDenom : undefined,
      condition: alertCondition,
      threshold,
      enabled: true,
      createdAt: Date.now()
    };

    const updated = [...alerts, newAlert];
    setAlerts(updated);
    saveAlerts(updated);
    setAlertThreshold('');
    setShowForm(false);
  };

  const handleToggleAlert = (id: string): void => {
    const updated = alerts.map((a: PriceAlert) => 
      a.id === id ? { ...a, enabled: !a.enabled } : a
    );
    setAlerts(updated);
    saveAlerts(updated);
  };

  const handleDeleteAlert = (id: string): void => {
    const updated = alerts.filter((a: PriceAlert) => a.id !== id);
    setAlerts(updated);
    saveAlerts(updated);
  };

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-cyan-400" />
            Price Alerts
          </span>
          <Button
            onClick={() => setShowForm(!showForm)}
            size="sm"
            className="bg-cyan-600 hover:bg-cyan-700 text-white"
          >
            <Plus className="h-4 w-4 mr-2" />
            New Alert
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {showForm && (
          <div className="p-4 bg-[#020617] border border-[#1e293b] rounded-lg space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-300">Alert Type</Label>
                <Select value={alertType} onValueChange={(v: string) => setAlertType(v as 'premium' | 'spot')}>
                  <SelectTrigger className="bg-[#0b1120] border-[#1e293b] text-gray-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="premium">Premium %</SelectItem>
                    <SelectItem value="spot">Gold Spot</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {alertType === 'premium' && (
                <>
                  <div className="space-y-2">
                    <Label className="text-gray-300">State</Label>
                    <Select value={alertState} onValueChange={(v: string) => setAlertState(v as GoldbackState)}>
                      <SelectTrigger className="bg-[#0b1120] border-[#1e293b] text-gray-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {GOLDBACK_STATES.map((state: GoldbackState) => (
                          <SelectItem key={state} value={state}>{state}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-gray-300">Denomination</Label>
                    <Select value={alertDenom.toString()} onValueChange={(v: string) => setAlertDenom(parseFloat(v) as GoldbackDenomination)}>
                      <SelectTrigger className="bg-[#0b1120] border-[#1e293b] text-gray-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {GOLDBACK_DENOMINATIONS.map((denom: GoldbackDenomination) => (
                          <SelectItem key={denom} value={denom.toString()}>
                            {denom === 0.5 ? '½' : denom} GB
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}

              <div className="space-y-2">
                <Label className="text-gray-300">Condition</Label>
                <Select value={alertCondition} onValueChange={(v: string) => setAlertCondition(v as 'above' | 'below')}>
                  <SelectTrigger className="bg-[#0b1120] border-[#1e293b] text-gray-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="below">Falls Below</SelectItem>
                    <SelectItem value="above">Rises Above</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-gray-300">Threshold ({alertType === 'premium' ? '%' : '$'})</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={alertThreshold}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAlertThreshold(e.target.value)}
                  className="bg-[#0b1120] border-[#1e293b] text-gray-100"
                  placeholder={alertType === 'premium' ? '35.00' : '2400.00'}
                />
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleAddAlert} className="bg-cyan-600 hover:bg-cyan-700 text-white">
                Create Alert
              </Button>
              <Button onClick={() => setShowForm(false)} variant="outline" className="border-gray-600 text-gray-300">
                Cancel
              </Button>
            </div>
          </div>
        )}

        {alerts.length > 0 ? (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-[#1e293b] hover:bg-transparent">
                  <TableHead className="text-gray-400">Type</TableHead>
                  <TableHead className="text-gray-400">Condition</TableHead>
                  <TableHead className="text-gray-400">Threshold</TableHead>
                  <TableHead className="text-gray-400">Status</TableHead>
                  <TableHead className="text-gray-400">Enabled</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {alerts.map((alert: PriceAlert) => (
                  <TableRow key={alert.id} className="border-[#1e293b] hover:bg-[#020617]">
                    <TableCell className="text-gray-300">
                      {alert.type === 'premium' ? (
                        <span>{alert.state} {alert.denomination} GB</span>
                      ) : (
                        <span>Gold Spot</span>
                      )}
                    </TableCell>
                    <TableCell className="text-gray-300">
                      {alert.condition === 'below' ? '↓ Below' : '↑ Above'}
                    </TableCell>
                    <TableCell className="text-cyan-400 font-semibold">
                      {alert.type === 'premium' ? `${alert.threshold}%` : `$${alert.threshold}`}
                    </TableCell>
                    <TableCell>
                      <Badge className={alert.enabled ? 'bg-green-600 text-white' : 'bg-gray-600 text-white'}>
                        {alert.enabled ? 'Active' : 'Paused'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={alert.enabled}
                        onCheckedChange={() => handleToggleAlert(alert.id)}
                      />
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteAlert(alert.id)}
                        className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="text-center text-gray-500 py-8">
            No alerts configured
          </div>
        )}
      </CardContent>
    </Card>
  );
}
