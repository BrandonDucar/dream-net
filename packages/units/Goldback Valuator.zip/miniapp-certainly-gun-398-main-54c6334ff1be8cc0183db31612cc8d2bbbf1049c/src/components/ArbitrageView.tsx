'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { TrendingUp, ArrowRight } from 'lucide-react';
import type { GoldbackLine } from '@/lib/goldback';
import { suggestArbitrageTrades, type ArbitrageOpportunity } from '@/lib/arbitrage';

type ArbitrageViewProps = {
  lines: GoldbackLine[];
  goldSpot: number;
};

export function ArbitrageView({ lines, goldSpot }: ArbitrageViewProps): JSX.Element {
  const analysis = suggestArbitrageTrades(lines, goldSpot);

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-cyan-400" />
          Arbitrage Opportunities
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {analysis.opportunities.length > 0 ? (
          <>
            <div className="p-4 bg-[#020617] border border-cyan-600/50 rounded-lg">
              <div className="text-sm text-gray-400 mb-1">AI Recommendation</div>
              <div className="text-gray-100">{analysis.recommendation}</div>
              <div className="text-sm text-cyan-400 mt-2">
                Total Potential Profit: ${analysis.totalPotentialProfit.toFixed(2)}
              </div>
            </div>

            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-[#1e293b] hover:bg-transparent">
                    <TableHead className="text-gray-400">Denomination</TableHead>
                    <TableHead className="text-gray-400">Buy From</TableHead>
                    <TableHead className="text-gray-400">Sell To</TableHead>
                    <TableHead className="text-gray-400">Margin</TableHead>
                    <TableHead className="text-gray-400">Est. Profit</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {analysis.opportunities.map((opp: ArbitrageOpportunity) => (
                    <TableRow key={opp.id} className="border-[#1e293b] hover:bg-[#020617]">
                      <TableCell className="font-semibold text-cyan-400">
                        {opp.denomination === 0.5 ? '½' : opp.denomination} GB
                      </TableCell>
                      <TableCell className="text-gray-300">
                        <div className="flex items-center gap-2">
                          <span>{opp.buyState}</span>
                          <Badge className="bg-green-600 text-white">
                            {opp.buyPremium.toFixed(1)}%
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell className="text-gray-300">
                        <div className="flex items-center gap-2">
                          <ArrowRight className="h-4 w-4 text-cyan-400" />
                          <span>{opp.sellState}</span>
                          <Badge className="bg-amber-600 text-white">
                            {opp.sellPremium.toFixed(1)}%
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={
                          opp.profitMargin >= 15 
                            ? 'bg-green-600 text-white' 
                            : opp.profitMargin >= 10 
                            ? 'bg-cyan-600 text-white' 
                            : 'bg-amber-600 text-white'
                        }>
                          {opp.profitMargin.toFixed(1)}%
                        </Badge>
                      </TableCell>
                      <TableCell className="text-green-400 font-semibold">
                        ${opp.estimatedProfit.toFixed(2)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </>
        ) : (
          <div className="text-center text-gray-500 py-8">
            No arbitrage opportunities detected. Add more lines with different states or premiums.
          </div>
        )}
      </CardContent>
    </Card>
  );
}
