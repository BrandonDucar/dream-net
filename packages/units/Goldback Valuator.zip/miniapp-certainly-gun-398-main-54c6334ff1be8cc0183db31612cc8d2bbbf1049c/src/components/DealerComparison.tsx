'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Store, TrendingDown, TrendingUp } from 'lucide-react';
import type { GoldbackLine } from '@/lib/goldback';
import { getDealerPrices, compareToDealerPrices, type DealerPrice } from '@/lib/dealers';

type DealerComparisonProps = {
  line: GoldbackLine;
};

export function DealerComparison({ line }: DealerComparisonProps): JSX.Element {
  const dealerPrices = getDealerPrices(line.state, line.denomination);
  const comparison = compareToDealerPrices(
    line.state,
    line.denomination,
    line.quantity,
    line.marketPriceTotal
  );

  return (
    <Card className="bg-[#0b1120] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Store className="h-5 w-5 text-cyan-400" />
          Dealer Price Comparison
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <div className="text-sm text-gray-400">Your Price Per Unit</div>
            <div className="text-xl font-bold text-cyan-400">
              ${comparison.pricePerUnit.toFixed(2)}
            </div>
          </div>
          
          <div className="space-y-1">
            <div className="text-sm text-gray-400">Market Average</div>
            <div className="text-xl font-bold text-amber-400">
              ${comparison.avgMarketPrice?.toFixed(2) ?? '—'}
            </div>
          </div>

          {comparison.percentVsAvg !== null && (
            <div className="space-y-1 col-span-2">
              <div className="text-sm text-gray-400">vs Market Average</div>
              <div className={`text-lg font-semibold flex items-center gap-2 ${
                comparison.percentVsAvg < 0 ? 'text-green-400' : 'text-red-400'
              }`}>
                {comparison.percentVsAvg < 0 ? <TrendingDown className="h-5 w-5" /> : <TrendingUp className="h-5 w-5" />}
                {comparison.percentVsAvg > 0 ? '+' : ''}{comparison.percentVsAvg.toFixed(1)}%
                {comparison.savingsVsAvg !== null && (
                  <span className="text-sm text-gray-400">
                    ({comparison.savingsVsAvg < 0 ? 'Paying' : 'Saving'} ${Math.abs(comparison.savingsVsAvg).toFixed(2)})
                  </span>
                )}
              </div>
            </div>
          )}
        </div>

        {dealerPrices.length > 0 && (
          <div className="overflow-x-auto">
            <div className="text-sm font-semibold text-gray-300 mb-2">Current Dealer Prices</div>
            <Table>
              <TableHeader>
                <TableRow className="border-[#1e293b] hover:bg-transparent">
                  <TableHead className="text-gray-400">Dealer</TableHead>
                  <TableHead className="text-gray-400">Price/Unit</TableHead>
                  <TableHead className="text-gray-400">Total ({line.quantity}x)</TableHead>
                  <TableHead className="text-gray-400">vs You</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {dealerPrices.slice(0, 5).map((dealer: DealerPrice) => {
                  const totalPrice = dealer.pricePerUnit * line.quantity;
                  const diff = totalPrice - line.marketPriceTotal;
                  const diffPct = ((comparison.pricePerUnit / dealer.pricePerUnit) - 1) * 100;
                  
                  return (
                    <TableRow key={dealer.dealer} className="border-[#1e293b] hover:bg-[#020617]">
                      <TableCell className="font-medium text-gray-300">{dealer.dealer}</TableCell>
                      <TableCell className="text-cyan-400">${dealer.pricePerUnit.toFixed(2)}</TableCell>
                      <TableCell className="text-gray-300">${totalPrice.toFixed(2)}</TableCell>
                      <TableCell>
                        <Badge className={diff > 0 ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}>
                          {diff > 0 ? '+' : ''}{diffPct.toFixed(1)}%
                        </Badge>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
