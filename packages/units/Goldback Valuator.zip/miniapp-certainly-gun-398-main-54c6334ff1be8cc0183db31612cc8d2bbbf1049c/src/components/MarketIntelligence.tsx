'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { BarChart3, Activity } from 'lucide-react';
import type { GoldbackLine } from '@/lib/goldback';
import { calculateGoldbackIndex, type GoldbackIndex } from '@/lib/index';
import { getRarityData, getRarityLabel, getRarityColor, calculateRarityPremium } from '@/lib/rarity';
import type { GoldbackState } from '@/lib/goldback';

type MarketIntelligenceProps = {
  lines: GoldbackLine[];
  goldSpot: number;
};

export function MarketIntelligence({ lines, goldSpot }: MarketIntelligenceProps): JSX.Element {
  const index = calculateGoldbackIndex(lines, goldSpot);

  const getTrendIcon = (trend: 'rising' | 'falling' | 'stable'): string => {
    if (trend === 'rising') return '📈';
    if (trend === 'falling') return '📉';
    return '➡️';
  };

  const getTrendColor = (trend: 'rising' | 'falling' | 'stable'): string => {
    if (trend === 'rising') return 'text-green-400';
    if (trend === 'falling') return 'text-red-400';
    return 'text-gray-400';
  };

  return (
    <div className="space-y-6">
      <Card className="bg-[#0b1120] border-[#1e293b]">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-cyan-400" />
            Goldback Premium Index
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="space-y-1">
              <div className="text-sm text-gray-400">Overall Index</div>
              <div className="text-3xl font-bold text-cyan-400">
                {index.overallIndex.toFixed(1)}%
              </div>
            </div>
            
            <div className="space-y-1">
              <div className="text-sm text-gray-400">Market Trend</div>
              <div className={`text-2xl font-semibold ${getTrendColor(index.trend)}`}>
                {getTrendIcon(index.trend)} {index.trend}
              </div>
            </div>

            <div className="space-y-1">
              <div className="text-sm text-gray-400">Volatility</div>
              <div className="text-2xl font-semibold text-amber-400">
                {index.volatility.toFixed(1)}%
              </div>
            </div>

            <div className="space-y-1">
              <div className="text-sm text-gray-400">Last Updated</div>
              <div className="text-sm text-gray-300">
                {new Date(index.timestamp).toLocaleTimeString()}
              </div>
            </div>
          </div>

          {Object.keys(index.byState).length > 0 && (
            <div className="overflow-x-auto">
              <div className="text-sm font-semibold text-gray-300 mb-2">Premium by State</div>
              <Table>
                <TableHeader>
                  <TableRow className="border-[#1e293b] hover:bg-transparent">
                    <TableHead className="text-gray-400">State</TableHead>
                    <TableHead className="text-gray-400">Avg Premium</TableHead>
                    <TableHead className="text-gray-400">vs Overall</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.entries(index.byState)
                    .sort(([, a], [, b]) => a - b)
                    .map(([state, premium]) => {
                      const diff = premium - index.overallIndex;
                      return (
                        <TableRow key={state} className="border-[#1e293b] hover:bg-[#020617]">
                          <TableCell className="font-medium text-gray-300">{state}</TableCell>
                          <TableCell className="text-cyan-400 font-semibold">
                            {premium.toFixed(1)}%
                          </TableCell>
                          <TableCell>
                            <Badge className={
                              diff < -5 
                                ? 'bg-green-600 text-white' 
                                : diff > 5 
                                ? 'bg-red-600 text-white' 
                                : 'bg-gray-600 text-white'
                            }>
                              {diff > 0 ? '+' : ''}{diff.toFixed(1)}%
                            </Badge>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-[#0b1120] border-[#1e293b]">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-cyan-400" />
            Rarity Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-[#1e293b] hover:bg-transparent">
                  <TableHead className="text-gray-400">State</TableHead>
                  <TableHead className="text-gray-400">Denom</TableHead>
                  <TableHead className="text-gray-400">Rarity</TableHead>
                  <TableHead className="text-gray-400">Mintage</TableHead>
                  <TableHead className="text-gray-400">Your Premium</TableHead>
                  <TableHead className="text-gray-400">Value</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {lines.map((line: GoldbackLine) => {
                  const rarity = getRarityData(line.state, line.denomination);
                  if (!rarity) return null;
                  
                  const analysis = calculateRarityPremium(line.premiumPct, rarity.rarityScore);
                  
                  return (
                    <TableRow key={line.id} className="border-[#1e293b] hover:bg-[#020617]">
                      <TableCell className="text-gray-300">{line.state}</TableCell>
                      <TableCell className="text-cyan-400 font-semibold">
                        {line.denomination === 0.5 ? '½' : line.denomination} GB
                      </TableCell>
                      <TableCell>
                        <Badge className={
                          rarity.rarityScore >= 75 
                            ? 'bg-purple-600 text-white' 
                            : rarity.rarityScore >= 60 
                            ? 'bg-pink-600 text-white' 
                            : rarity.rarityScore >= 45 
                            ? 'bg-amber-600 text-white' 
                            : 'bg-gray-600 text-white'
                        }>
                          {getRarityLabel(rarity.rarityScore)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-gray-400">{rarity.mintage.toLocaleString()}</TableCell>
                      <TableCell className="text-cyan-400">{line.premiumPct.toFixed(1)}%</TableCell>
                      <TableCell>
                        <Badge className={analysis.isUndervalued ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}>
                          {analysis.isUndervalued ? '💎 Undervalued' : '⚠️ Fair/Rich'}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
