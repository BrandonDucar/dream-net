import type { GoldbackLine, GoldbackDenomination, GoldbackState } from './goldback';
import { premiumPct } from './goldback';

export type ArbitrageOpportunity = {
  id: string;
  buyState: GoldbackState;
  sellState: GoldbackState;
  denomination: GoldbackDenomination;
  buyPremium: number;
  sellPremium: number;
  profitMargin: number;
  estimatedProfit: number;
  buyLine?: GoldbackLine;
  sellLine?: GoldbackLine;
};

export function detectArbitrageOpportunities(
  lines: GoldbackLine[],
  minProfitMargin: number = 10
): ArbitrageOpportunity[] {
  const opportunities: ArbitrageOpportunity[] = [];
  
  // Group lines by denomination
  const byDenom = new Map<GoldbackDenomination, GoldbackLine[]>();
  for (const line of lines) {
    const existing = byDenom.get(line.denomination) ?? [];
    existing.push(line);
    byDenom.set(line.denomination, existing);
  }
  
  // Find arbitrage between different states/lines of same denomination
  for (const [denom, denomLines] of byDenom.entries()) {
    for (let i = 0; i < denomLines.length; i++) {
      for (let j = i + 1; j < denomLines.length; j++) {
        const line1 = denomLines[i];
        const line2 = denomLines[j];
        
        // Buy low, sell high
        const [buyLine, sellLine] = line1.premiumPct < line2.premiumPct 
          ? [line1, line2] 
          : [line2, line1];
        
        const profitMargin = sellLine.premiumPct - buyLine.premiumPct;
        
        if (profitMargin >= minProfitMargin) {
          const pricePerUnit = buyLine.marketPriceTotal / buyLine.quantity;
          const sellPricePerUnit = sellLine.marketPriceTotal / sellLine.quantity;
          const estimatedProfit = (sellPricePerUnit - pricePerUnit) * Math.min(buyLine.quantity, sellLine.quantity);
          
          opportunities.push({
            id: `${buyLine.id}-${sellLine.id}`,
            buyState: buyLine.state,
            sellState: sellLine.state,
            denomination: denom,
            buyPremium: buyLine.premiumPct,
            sellPremium: sellLine.premiumPct,
            profitMargin,
            estimatedProfit,
            buyLine,
            sellLine
          });
        }
      }
    }
  }
  
  return opportunities.sort((a: ArbitrageOpportunity, b: ArbitrageOpportunity) => b.profitMargin - a.profitMargin);
}

export function calculateArbitrageROI(
  buyPrice: number,
  sellPrice: number,
  shippingCost: number = 0,
  fees: number = 0
): {
  grossProfit: number;
  netProfit: number;
  roi: number;
} {
  const grossProfit = sellPrice - buyPrice;
  const netProfit = grossProfit - shippingCost - fees;
  const roi = buyPrice > 0 ? (netProfit / buyPrice) * 100 : 0;
  
  return { grossProfit, netProfit, roi };
}

export function suggestArbitrageTrades(
  lines: GoldbackLine[],
  goldSpot: number
): {
  recommendation: string;
  opportunities: ArbitrageOpportunity[];
  totalPotentialProfit: number;
} {
  const opportunities = detectArbitrageOpportunities(lines, 8); // 8% minimum margin
  
  const totalPotentialProfit = opportunities.reduce(
    (sum: number, opp: ArbitrageOpportunity) => sum + opp.estimatedProfit, 
    0
  );
  
  let recommendation = '';
  
  if (opportunities.length === 0) {
    recommendation = 'No significant arbitrage opportunities detected in your basket.';
  } else if (opportunities.length === 1) {
    const opp = opportunities[0];
    recommendation = `Buy ${opp.denomination} GB from ${opp.buyState} at ${opp.buyPremium.toFixed(1)}% premium, sell in ${opp.sellState} at ${opp.sellPremium.toFixed(1)}% premium. Estimated profit: $${opp.estimatedProfit.toFixed(2)}.`;
  } else {
    const best = opportunities[0];
    recommendation = `${opportunities.length} arbitrage opportunities found! Best: ${best.denomination} GB between ${best.buyState} and ${best.sellState} with ${best.profitMargin.toFixed(1)}% margin ($${best.estimatedProfit.toFixed(2)} profit).`;
  }
  
  return {
    recommendation,
    opportunities,
    totalPotentialProfit
  };
}
