import type { GoldbackDenomination, GoldbackState } from './goldback';

export type DealerPrice = {
  dealer: string;
  state: GoldbackState;
  denomination: GoldbackDenomination;
  pricePerUnit: number;
  url?: string;
  lastUpdated: number;
};

// Major dealer pricing data (would be updated regularly via API in production)
export const DEALER_PRICES: DealerPrice[] = [
  // Utah prices
  { dealer: 'Goldback Inc', state: 'Utah', denomination: 1, pricePerUnit: 3.25, lastUpdated: Date.now() },
  { dealer: 'Goldback Inc', state: 'Utah', denomination: 5, pricePerUnit: 15.50, lastUpdated: Date.now() },
  { dealer: 'Goldback Inc', state: 'Utah', denomination: 10, pricePerUnit: 30.00, lastUpdated: Date.now() },
  { dealer: 'Goldback Inc', state: 'Utah', denomination: 25, pricePerUnit: 72.50, lastUpdated: Date.now() },
  { dealer: 'Goldback Inc', state: 'Utah', denomination: 50, pricePerUnit: 143.00, lastUpdated: Date.now() },
  
  // Nevada prices
  { dealer: 'Goldback Inc', state: 'Nevada', denomination: 1, pricePerUnit: 3.30, lastUpdated: Date.now() },
  { dealer: 'Goldback Inc', state: 'Nevada', denomination: 5, pricePerUnit: 15.75, lastUpdated: Date.now() },
  { dealer: 'Goldback Inc', state: 'Nevada', denomination: 10, pricePerUnit: 30.50, lastUpdated: Date.now() },
  { dealer: 'Goldback Inc', state: 'Nevada', denomination: 25, pricePerUnit: 74.00, lastUpdated: Date.now() },
  { dealer: 'Goldback Inc', state: 'Nevada', denomination: 50, pricePerUnit: 145.00, lastUpdated: Date.now() },
  
  // JM Bullion (example prices)
  { dealer: 'JM Bullion', state: 'Utah', denomination: 1, pricePerUnit: 3.40, lastUpdated: Date.now() },
  { dealer: 'JM Bullion', state: 'Utah', denomination: 5, pricePerUnit: 16.00, lastUpdated: Date.now() },
  { dealer: 'JM Bullion', state: 'Utah', denomination: 10, pricePerUnit: 31.50, lastUpdated: Date.now() },
  { dealer: 'JM Bullion', state: 'Utah', denomination: 25, pricePerUnit: 76.00, lastUpdated: Date.now() },
  { dealer: 'JM Bullion', state: 'Utah', denomination: 50, pricePerUnit: 150.00, lastUpdated: Date.now() },
  
  // APMEX (example prices)
  { dealer: 'APMEX', state: 'Utah', denomination: 1, pricePerUnit: 3.45, lastUpdated: Date.now() },
  { dealer: 'APMEX', state: 'Utah', denomination: 5, pricePerUnit: 16.25, lastUpdated: Date.now() },
  { dealer: 'APMEX', state: 'Utah', denomination: 10, pricePerUnit: 32.00, lastUpdated: Date.now() },
  { dealer: 'APMEX', state: 'Utah', denomination: 25, pricePerUnit: 77.50, lastUpdated: Date.now() },
  { dealer: 'APMEX', state: 'Utah', denomination: 50, pricePerUnit: 152.50, lastUpdated: Date.now() },
];

export function getDealerPrices(
  state: GoldbackState,
  denomination: GoldbackDenomination
): DealerPrice[] {
  return DEALER_PRICES.filter((p: DealerPrice) => 
    p.state === state && p.denomination === denomination
  ).sort((a: DealerPrice, b: DealerPrice) => a.pricePerUnit - b.pricePerUnit);
}

export function getLowestDealerPrice(
  state: GoldbackState,
  denomination: GoldbackDenomination
): DealerPrice | null {
  const prices = getDealerPrices(state, denomination);
  return prices.length > 0 ? prices[0] : null;
}

export function getAverageDealerPrice(
  state: GoldbackState,
  denomination: GoldbackDenomination
): number | null {
  const prices = getDealerPrices(state, denomination);
  if (prices.length === 0) return null;
  
  const sum = prices.reduce((acc: number, p: DealerPrice) => acc + p.pricePerUnit, 0);
  return sum / prices.length;
}

export function compareToDealerPrices(
  state: GoldbackState,
  denomination: GoldbackDenomination,
  quantity: number,
  yourPrice: number
): {
  pricePerUnit: number;
  avgMarketPrice: number | null;
  lowestMarketPrice: number | null;
  savingsVsAvg: number | null;
  savingsVsLowest: number | null;
  percentVsAvg: number | null;
  percentVsLowest: number | null;
} {
  const pricePerUnit = yourPrice / quantity;
  const avgPrice = getAverageDealerPrice(state, denomination);
  const lowestPrice = getLowestDealerPrice(state, denomination);
  
  const savingsVsAvg = avgPrice ? (avgPrice * quantity) - yourPrice : null;
  const savingsVsLowest = lowestPrice ? (lowestPrice.pricePerUnit * quantity) - yourPrice : null;
  
  const percentVsAvg = avgPrice ? ((pricePerUnit / avgPrice) - 1) * 100 : null;
  const percentVsLowest = lowestPrice ? ((pricePerUnit / lowestPrice.pricePerUnit) - 1) * 100 : null;
  
  return {
    pricePerUnit,
    avgMarketPrice: avgPrice,
    lowestMarketPrice: lowestPrice?.pricePerUnit ?? null,
    savingsVsAvg,
    savingsVsLowest,
    percentVsAvg,
    percentVsLowest
  };
}
