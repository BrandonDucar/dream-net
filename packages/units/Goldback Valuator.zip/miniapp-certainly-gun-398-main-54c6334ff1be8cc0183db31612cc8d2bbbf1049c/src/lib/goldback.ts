export type GoldbackDenomination =
  | 0.5   // 1/2 Goldback
  | 1
  | 2
  | 3
  | 5
  | 10
  | 25
  | 50
  | 100;

export type GoldbackState =
  | "Utah"
  | "Nevada"
  | "New Hampshire"
  | "Wyoming"
  | "South Dakota"
  | "Arizona"
  | "Oklahoma"
  | "Florida"
  | "Other";

// denomination → troy ounces of gold
export const GOLDBACK_OZ_PER_NOTE: Record<GoldbackDenomination, number> = {
  0.5: 1 / 2000,   // 1/2000 oz
  1:   1 / 1000,   // 1/1000 oz
  2:   1 / 500,    // 1/500 oz
  3:   3 / 1000,   // 3/1000 oz (limited early release)
  5:   1 / 200,    // 1/200 oz
  10:  1 / 100,    // 1/100 oz
  25:  1 / 40,     // 1/40 oz
  50:  1 / 20,     // 1/20 oz
  100: 1 / 10      // 1/10 oz
};

export const GOLDBACK_DENOMINATIONS: GoldbackDenomination[] = [0.5, 1, 2, 3, 5, 10, 25, 50, 100];

export const GOLDBACK_STATES: GoldbackState[] = [
  "Utah",
  "Nevada",
  "New Hampshire",
  "Wyoming",
  "South Dakota",
  "Arizona",
  "Oklahoma",
  "Florida",
  "Other"
];

export function goldbacksToOz(denomination: GoldbackDenomination, quantity: number): number {
  return GOLDBACK_OZ_PER_NOTE[denomination] * quantity;
}

export function meltValueFromGoldbacks(
  denomination: GoldbackDenomination,
  quantity: number,
  goldSpotPerOz: number
): number {
  const oz = goldbacksToOz(denomination, quantity);
  return oz * goldSpotPerOz;
}

export function premiumPct(marketPrice: number, meltValue: number): number {
  if (meltValue <= 0) return 0;
  return ((marketPrice / meltValue) - 1) * 100;
}

export function classifyGoldbackDeal(premium: number): "deal" | "fair" | "rich" | "insane" {
  if (premium <= 20) return "deal";
  if (premium <= 40) return "fair";
  if (premium <= 70) return "rich";
  return "insane";
}

export type GoldbackLine = {
  id: string;
  denomination: GoldbackDenomination;
  quantity: number;
  state: GoldbackState;
  marketPriceTotal: number;
  meltValueTotal: number;
  premiumPct: number;
  edgeLabel: "deal" | "fair" | "rich" | "insane";
  notes?: string;
  createdAt: number;
  acquisitionCost?: number; // For P/L tracking
};

export type GoldbackBasketSummary = {
  totalNotes: number;
  totalGoldOz: number;
  totalMeltValue: number;
  totalMarketPrice: number;
  blendedPremiumPct: number;
  avgPricePerGoldback: number;
};

export type GoldbackStateBreakdown = {
  state: GoldbackState;
  totalNotes: number;
  totalGoldOz: number;
  totalMarketPrice: number;
  totalMeltValue: number;
  blendedPremiumPct: number;
};

export function summarizeBasket(
  lines: GoldbackLine[],
  goldSpotPerOz: number
): GoldbackBasketSummary {
  let totalNotes = 0;
  let totalGoldOz = 0;
  let totalMeltValue = 0;
  let totalMarketPrice = 0;

  for (const line of lines) {
    totalNotes += line.denomination * line.quantity;
    const ozForLine = goldbacksToOz(line.denomination, line.quantity);
    totalGoldOz += ozForLine;
    const melt = ozForLine * goldSpotPerOz;
    totalMeltValue += melt;
    totalMarketPrice += line.marketPriceTotal;
  }

  const blendedPremiumPct = totalMeltValue > 0
    ? ((totalMarketPrice / totalMeltValue) - 1) * 100
    : 0;

  const avgPricePerGoldback = totalNotes > 0
    ? totalMarketPrice / totalNotes
    : 0;

  return {
    totalNotes,
    totalGoldOz,
    totalMeltValue,
    totalMarketPrice,
    blendedPremiumPct,
    avgPricePerGoldback
  };
}

export function summarizeByState(
  lines: GoldbackLine[],
  goldSpotPerOz: number
): GoldbackStateBreakdown[] {
  const map = new Map<GoldbackState, GoldbackStateBreakdown>();

  for (const line of lines) {
    const existing = map.get(line.state) ?? {
      state: line.state,
      totalNotes: 0,
      totalGoldOz: 0,
      totalMarketPrice: 0,
      totalMeltValue: 0,
      blendedPremiumPct: 0
    };

    const notes = line.denomination * line.quantity;
    const oz = goldbacksToOz(line.denomination, line.quantity);
    const melt = oz * goldSpotPerOz;

    existing.totalNotes += notes;
    existing.totalGoldOz += oz;
    existing.totalMarketPrice += line.marketPriceTotal;
    existing.totalMeltValue += melt;

    map.set(line.state, existing);
  }

  for (const [state, entry] of map.entries()) {
    entry.blendedPremiumPct =
      entry.totalMeltValue > 0
        ? ((entry.totalMarketPrice / entry.totalMeltValue) - 1) * 100
        : 0;
    map.set(state, entry);
  }

  return Array.from(map.values());
}
