import type { GoldbackLine, GoldbackState, GoldbackDenomination } from './goldback';
import { premiumPct } from './goldback';
import { loadHistoricalPremiums, type HistoricalPremiumData } from './storage';
import { GOLDBACK_STATES, GOLDBACK_DENOMINATIONS } from './goldback';

export type GoldbackIndex = {
  overallIndex: number;
  timestamp: number;
  byState: Record<GoldbackState, number>;
  byDenomination: Record<GoldbackDenomination, number>;
  trend: 'rising' | 'falling' | 'stable';
  volatility: number;
};

export function calculateGoldbackIndex(
  lines: GoldbackLine[],
  goldSpot: number
): GoldbackIndex {
  if (lines.length === 0) {
    return {
      overallIndex: 0,
      timestamp: Date.now(),
      byState: {} as Record<GoldbackState, number>,
      byDenomination: {} as Record<GoldbackDenomination, number>,
      trend: 'stable',
      volatility: 0
    };
  }
  
  // Calculate weighted average premium across all lines
  let totalValue = 0;
  let totalWeightedPremium = 0;
  
  const stateMap = new Map<GoldbackState, { premium: number; weight: number }>();
  const denomMap = new Map<GoldbackDenomination, { premium: number; weight: number }>();
  
  for (const line of lines) {
    const weight = line.meltValueTotal;
    totalValue += weight;
    totalWeightedPremium += line.premiumPct * weight;
    
    // By state
    const stateData = stateMap.get(line.state) ?? { premium: 0, weight: 0 };
    stateData.premium += line.premiumPct * weight;
    stateData.weight += weight;
    stateMap.set(line.state, stateData);
    
    // By denomination
    const denomData = denomMap.get(line.denomination) ?? { premium: 0, weight: 0 };
    denomData.premium += line.premiumPct * weight;
    denomData.weight += weight;
    denomMap.set(line.denomination, denomData);
  }
  
  const overallIndex = totalValue > 0 ? totalWeightedPremium / totalValue : 0;
  
  const byState: Record<GoldbackState, number> = {} as Record<GoldbackState, number>;
  for (const [state, data] of stateMap.entries()) {
    byState[state] = data.weight > 0 ? data.premium / data.weight : 0;
  }
  
  const byDenomination: Record<GoldbackDenomination, number> = {} as Record<GoldbackDenomination, number>;
  for (const [denom, data] of denomMap.entries()) {
    byDenomination[denom] = data.weight > 0 ? data.premium / data.weight : 0;
  }
  
  // Calculate trend from historical data
  const history = loadHistoricalPremiums();
  const last7Days = history.filter((h: HistoricalPremiumData) => h.date > Date.now() - (7 * 24 * 60 * 60 * 1000));
  
  let trend: 'rising' | 'falling' | 'stable' = 'stable';
  let volatility = 0;
  
  if (last7Days.length >= 2) {
    const premiums = last7Days.map((h: HistoricalPremiumData) => h.premiumPct);
    const avg = premiums.reduce((sum: number, p: number) => sum + p, 0) / premiums.length;
    const variance = premiums.reduce((sum: number, p: number) => sum + Math.pow(p - avg, 2), 0) / premiums.length;
    volatility = Math.sqrt(variance);
    
    const recent = premiums.slice(-3);
    const earlier = premiums.slice(0, Math.min(3, premiums.length - 3));
    
    if (recent.length > 0 && earlier.length > 0) {
      const recentAvg = recent.reduce((sum: number, p: number) => sum + p, 0) / recent.length;
      const earlierAvg = earlier.reduce((sum: number, p: number) => sum + p, 0) / earlier.length;
      
      if (recentAvg > earlierAvg + 2) trend = 'rising';
      else if (recentAvg < earlierAvg - 2) trend = 'falling';
    }
  }
  
  return {
    overallIndex,
    timestamp: Date.now(),
    byState,
    byDenomination,
    trend,
    volatility
  };
}

export type DealRecommendation = {
  type: 'buy' | 'sell' | 'hold';
  confidence: 'low' | 'medium' | 'high';
  reason: string;
  action?: string;
};

export function getAIDealAdvisor(
  line: GoldbackLine,
  goldSpot: number,
  historicalAvg?: number
): DealRecommendation {
  const premium = line.premiumPct;
  
  // Rule 1: Extreme deals
  if (premium < 15) {
    return {
      type: 'buy',
      confidence: 'high',
      reason: `Exceptional deal at ${premium.toFixed(1)}% premium. Well below typical market rates.`,
      action: 'Strong buy - consider buying more of this denomination/state'
    };
  }
  
  // Rule 2: Historical comparison
  if (historicalAvg && premium < historicalAvg - 5) {
    return {
      type: 'buy',
      confidence: 'high',
      reason: `Premium ${(historicalAvg - premium).toFixed(1)}% below 30-day average (${historicalAvg.toFixed(1)}%).`,
      action: 'Good entry point - below recent market average'
    };
  }
  
  // Rule 3: Fair deals
  if (premium >= 20 && premium <= 40) {
    return {
      type: 'hold',
      confidence: 'medium',
      reason: `Fair market premium at ${premium.toFixed(1)}%. Within normal range.`,
      action: 'Hold - reasonable price but no standout value'
    };
  }
  
  // Rule 4: Rich premiums
  if (premium > 60) {
    return {
      type: 'sell',
      confidence: 'high',
      reason: `High premium at ${premium.toFixed(1)}%. Good opportunity to realize gains.`,
      action: 'Consider selling - premium is elevated'
    };
  }
  
  // Rule 5: Moderate premiums
  if (premium > 40 && premium <= 60) {
    return {
      type: 'hold',
      confidence: 'medium',
      reason: `Moderate premium at ${premium.toFixed(1)}%. Slightly elevated but not extreme.`,
      action: 'Hold or wait for better entry point'
    };
  }
  
  // Default
  return {
    type: 'hold',
    confidence: 'low',
    reason: `Premium at ${premium.toFixed(1)}%. Monitor market conditions.`,
    action: 'Neutral - watch for price movements'
  };
}
