import type { GoldbackDenomination, GoldbackState } from './goldback';

export type RarityData = {
  state: GoldbackState;
  denomination: GoldbackDenomination;
  mintage: number;
  rarityScore: number; // 0-100, higher = more rare
  notes: string;
};

// Mintage data (approximate, would be updated from Goldback Safe API in production)
export const RARITY_DATA: RarityData[] = [
  // Utah (first series, higher mintage)
  { state: 'Utah', denomination: 1, mintage: 500000, rarityScore: 10, notes: 'Common' },
  { state: 'Utah', denomination: 5, mintage: 250000, rarityScore: 20, notes: 'Common' },
  { state: 'Utah', denomination: 10, mintage: 150000, rarityScore: 30, notes: 'Moderate' },
  { state: 'Utah', denomination: 25, mintage: 75000, rarityScore: 50, notes: 'Scarce' },
  { state: 'Utah', denomination: 50, mintage: 40000, rarityScore: 65, notes: 'Rare' },
  
  // Nevada (moderate mintage)
  { state: 'Nevada', denomination: 1, mintage: 300000, rarityScore: 25, notes: 'Common' },
  { state: 'Nevada', denomination: 5, mintage: 150000, rarityScore: 35, notes: 'Moderate' },
  { state: 'Nevada', denomination: 10, mintage: 90000, rarityScore: 45, notes: 'Moderate' },
  { state: 'Nevada', denomination: 25, mintage: 45000, rarityScore: 60, notes: 'Scarce' },
  { state: 'Nevada', denomination: 50, mintage: 25000, rarityScore: 75, notes: 'Rare' },
  
  // New Hampshire (lower mintage)
  { state: 'New Hampshire', denomination: 1, mintage: 200000, rarityScore: 35, notes: 'Moderate' },
  { state: 'New Hampshire', denomination: 5, mintage: 100000, rarityScore: 45, notes: 'Moderate' },
  { state: 'New Hampshire', denomination: 10, mintage: 60000, rarityScore: 55, notes: 'Scarce' },
  { state: 'New Hampshire', denomination: 25, mintage: 30000, rarityScore: 70, notes: 'Rare' },
  { state: 'New Hampshire', denomination: 50, mintage: 18000, rarityScore: 82, notes: 'Very Rare' },
  
  // Wyoming (low mintage)
  { state: 'Wyoming', denomination: 1, mintage: 150000, rarityScore: 40, notes: 'Moderate' },
  { state: 'Wyoming', denomination: 5, mintage: 80000, rarityScore: 50, notes: 'Scarce' },
  { state: 'Wyoming', denomination: 10, mintage: 50000, rarityScore: 60, notes: 'Scarce' },
  { state: 'Wyoming', denomination: 25, mintage: 25000, rarityScore: 75, notes: 'Rare' },
  { state: 'Wyoming', denomination: 50, mintage: 15000, rarityScore: 85, notes: 'Very Rare' },
  
  // South Dakota (newer, limited)
  { state: 'South Dakota', denomination: 1, mintage: 100000, rarityScore: 50, notes: 'Scarce' },
  { state: 'South Dakota', denomination: 5, mintage: 60000, rarityScore: 60, notes: 'Scarce' },
  { state: 'South Dakota', denomination: 10, mintage: 40000, rarityScore: 68, notes: 'Rare' },
  { state: 'South Dakota', denomination: 25, mintage: 20000, rarityScore: 80, notes: 'Very Rare' },
  { state: 'South Dakota', denomination: 50, mintage: 12000, rarityScore: 88, notes: 'Extremely Rare' },
];

export function getRarityData(
  state: GoldbackState,
  denomination: GoldbackDenomination
): RarityData | null {
  return RARITY_DATA.find((r: RarityData) => 
    r.state === state && r.denomination === denomination
  ) ?? null;
}

export function getRarityLabel(rarityScore: number): string {
  if (rarityScore >= 85) return 'Extremely Rare';
  if (rarityScore >= 75) return 'Very Rare';
  if (rarityScore >= 60) return 'Rare';
  if (rarityScore >= 45) return 'Scarce';
  if (rarityScore >= 30) return 'Moderate';
  return 'Common';
}

export function getRarityColor(rarityScore: number): string {
  if (rarityScore >= 85) return 'text-purple-400';
  if (rarityScore >= 75) return 'text-pink-400';
  if (rarityScore >= 60) return 'text-red-400';
  if (rarityScore >= 45) return 'text-amber-400';
  if (rarityScore >= 30) return 'text-yellow-400';
  return 'text-gray-400';
}

export function calculateRarityPremium(
  marketPremium: number,
  rarityScore: number
): {
  expectedPremium: number;
  isUndervalued: boolean;
  rarityAdjustedValue: number;
} {
  // Expected premium should increase with rarity
  // Base: 30% premium + (rarityScore * 0.5)
  const expectedPremium = 30 + (rarityScore * 0.5);
  const isUndervalued = marketPremium < expectedPremium;
  const rarityAdjustedValue = expectedPremium - marketPremium;
  
  return {
    expectedPremium,
    isUndervalued,
    rarityAdjustedValue
  };
}
