import type { GoldbackLine, GoldbackDenomination, GoldbackState } from './goldback';

export type HistoricalPremiumData = {
  date: number;
  state: GoldbackState;
  denomination: GoldbackDenomination;
  premiumPct: number;
  goldSpot: number;
};

export type PriceAlert = {
  id: string;
  type: 'premium' | 'spot';
  state?: GoldbackState;
  denomination?: GoldbackDenomination;
  condition: 'above' | 'below';
  threshold: number;
  enabled: boolean;
  createdAt: number;
  lastTriggered?: number;
};

export type CommunityPrice = {
  id: string;
  state: GoldbackState;
  denomination: GoldbackDenomination;
  quantity: number;
  pricePerUnit: number;
  dealer: string;
  reportedAt: number;
  reportedBy?: string;
};

// LocalStorage keys
const LINES_KEY = 'goldback_lines';
const HISTORY_KEY = 'goldback_premium_history';
const ALERTS_KEY = 'goldback_alerts';
const COMMUNITY_KEY = 'goldback_community_prices';

// Basket/Lines persistence
export function saveLines(lines: GoldbackLine[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(LINES_KEY, JSON.stringify(lines));
}

export function loadLines(): GoldbackLine[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(LINES_KEY);
  if (!data) return [];
  try {
    return JSON.parse(data) as GoldbackLine[];
  } catch {
    return [];
  }
}

// Historical premium tracking
export function saveHistoricalPremium(data: HistoricalPremiumData): void {
  if (typeof window === 'undefined') return;
  const history = loadHistoricalPremiums();
  history.push(data);
  
  // Keep only last 90 days
  const cutoff = Date.now() - (90 * 24 * 60 * 60 * 1000);
  const filtered = history.filter((h: HistoricalPremiumData) => h.date > cutoff);
  
  localStorage.setItem(HISTORY_KEY, JSON.stringify(filtered));
}

export function loadHistoricalPremiums(): HistoricalPremiumData[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(HISTORY_KEY);
  if (!data) return [];
  try {
    return JSON.parse(data) as HistoricalPremiumData[];
  } catch {
    return [];
  }
}

export function getAveragePremium(
  state: GoldbackState,
  denomination: GoldbackDenomination,
  days: number = 30
): number | null {
  const history = loadHistoricalPremiums();
  const cutoff = Date.now() - (days * 24 * 60 * 60 * 1000);
  
  const relevant = history.filter((h: HistoricalPremiumData) => 
    h.state === state && 
    h.denomination === denomination && 
    h.date > cutoff
  );
  
  if (relevant.length === 0) return null;
  
  const sum = relevant.reduce((acc: number, h: HistoricalPremiumData) => acc + h.premiumPct, 0);
  return sum / relevant.length;
}

// Price alerts
export function saveAlerts(alerts: PriceAlert[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(ALERTS_KEY, JSON.stringify(alerts));
}

export function loadAlerts(): PriceAlert[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(ALERTS_KEY);
  if (!data) return [];
  try {
    return JSON.parse(data) as PriceAlert[];
  } catch {
    return [];
  }
}

// Community pricing
export function saveCommunityPrice(price: CommunityPrice): void {
  if (typeof window === 'undefined') return;
  const prices = loadCommunityPrices();
  prices.push(price);
  
  // Keep only last 30 days
  const cutoff = Date.now() - (30 * 24 * 60 * 60 * 1000);
  const filtered = prices.filter((p: CommunityPrice) => p.reportedAt > cutoff);
  
  localStorage.setItem(COMMUNITY_KEY, JSON.stringify(filtered));
}

export function loadCommunityPrices(): CommunityPrice[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(COMMUNITY_KEY);
  if (!data) return [];
  try {
    return JSON.parse(data) as CommunityPrice[];
  } catch {
    return [];
  }
}

export function getRecentCommunityPrices(
  state: GoldbackState,
  denomination: GoldbackDenomination,
  days: number = 7
): CommunityPrice[] {
  const prices = loadCommunityPrices();
  const cutoff = Date.now() - (days * 24 * 60 * 60 * 1000);
  
  return prices.filter((p: CommunityPrice) => 
    p.state === state && 
    p.denomination === denomination && 
    p.reportedAt > cutoff
  );
}

// Export functionality
export function exportBasketToJSON(lines: GoldbackLine[]): string {
  return JSON.stringify(lines, null, 2);
}

export function exportBasketToCSV(lines: GoldbackLine[]): string {
  const headers = ['Denomination', 'Quantity', 'State', 'Market Price', 'Melt Value', 'Premium %', 'Edge', 'Notes', 'Created At'];
  const rows = lines.map((line: GoldbackLine) => [
    line.denomination,
    line.quantity,
    line.state,
    line.marketPriceTotal.toFixed(2),
    line.meltValueTotal.toFixed(2),
    line.premiumPct.toFixed(2),
    line.edgeLabel,
    line.notes || '',
    new Date(line.createdAt).toISOString()
  ]);
  
  const csv = [
    headers.join(','),
    ...rows.map((row: (string | number)[]) => row.join(','))
  ].join('\n');
  
  return csv;
}

export function downloadFile(content: string, filename: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
