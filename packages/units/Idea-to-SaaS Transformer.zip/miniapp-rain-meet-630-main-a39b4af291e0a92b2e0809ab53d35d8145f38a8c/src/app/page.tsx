'use client'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { generateBlueprint } from '@/lib/blueprint-generator'
import type { FormData, Blueprint } from '@/types/blueprint'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function MicroSaaSForgePage(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [formData, setFormData] = useState<FormData>({
    idea: '',
    primaryUser: '',
    currentSolution: '',
    pricePoint: ''
  })

  const [blueprint, setBlueprint] = useState<Blueprint | null>(null)
  const [isGenerating, setIsGenerating] = useState<boolean>(false)

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault()
    setIsGenerating(true)
    
    setTimeout(() => {
      const generatedBlueprint = generateBlueprint(formData)
      setBlueprint(generatedBlueprint)
      setIsGenerating(false)
    }, 800)
  }

  const handleReset = (): void => {
    setFormData({
      idea: '',
      primaryUser: '',
      currentSolution: '',
      pricePoint: ''
    })
    setBlueprint(null)
  }

  const isFormValid = formData.idea.length > 20 && formData.primaryUser.length > 2 && formData.currentSolution.length > 2 && formData.pricePoint.length > 0

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-black mb-3">
            Micro SaaS Forge
          </h1>
          <p className="text-lg text-gray-600">
            Turn your software idea into a lean, testable Micro SaaS concept
          </p>
        </div>

        {!blueprint ? (
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Tell Us About Your Idea</CardTitle>
              <CardDescription>
                Answer these 4 questions to generate your comprehensive Micro SaaS blueprint
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="idea" className="text-base font-semibold">
                    1. Describe your idea in 3–5 sentences
                  </Label>
                  <Textarea
                    id="idea"
                    placeholder="What problem does it solve? What does it do? Be specific..."
                    value={formData.idea}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setFormData({...formData, idea: e.target.value})}
                    className="min-h-32 resize-none"
                    required
                  />
                  <p className="text-sm text-gray-500">
                    {formData.idea.length} characters
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="primaryUser" className="text-base font-semibold">
                    2. Who is the primary user?
                  </Label>
                  <Input
                    id="primaryUser"
                    placeholder="e.g., Freelance designers, SaaS founders, Marketing agencies..."
                    value={formData.primaryUser}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({...formData, primaryUser: e.target.value})}
                    required
                  />
                  <p className="text-sm text-gray-500">
                    Be specific: job title, role, or type of person
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="currentSolution" className="text-base font-semibold">
                    3. What are they using instead right now (if anything)?
                  </Label>
                  <Input
                    id="currentSolution"
                    placeholder="e.g., Excel spreadsheets, Notion, Nothing - doing it manually..."
                    value={formData.currentSolution}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({...formData, currentSolution: e.target.value})}
                    required
                  />
                  <p className="text-sm text-gray-500">
                    Existing tools, manual processes, or workarounds
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="pricePoint" className="text-base font-semibold">
                    4. How much do you imagine they might pay per month?
                  </Label>
                  <Input
                    id="pricePoint"
                    type="text"
                    placeholder="e.g., $10, $29, $99..."
                    value={formData.pricePoint}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({...formData, pricePoint: e.target.value})}
                    required
                  />
                  <p className="text-sm text-gray-500">
                    Just your gut feeling—no wrong answer here!
                  </p>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button 
                    type="submit" 
                    size="lg"
                    className="flex-1"
                    disabled={!isFormValid || isGenerating}
                  >
                    {isGenerating ? 'Generating Blueprint...' : 'Generate Blueprint'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            <Card className="shadow-lg bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-2xl mb-2">Your Micro SaaS Blueprint</CardTitle>
                    <CardDescription className="text-base">
                      Screenshot or copy this comprehensive plan
                    </CardDescription>
                  </div>
                  <Button onClick={handleReset} variant="outline" size="sm">
                    Start Over
                  </Button>
                </div>
              </CardHeader>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl">🎯 Refined Positioning</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg font-semibold text-blue-600 bg-blue-50 p-4 rounded-lg border border-blue-200">
                  {blueprint.positioning}
                </p>
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl">⚡ Feature Breakdown</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-semibold text-base mb-3 flex items-center gap-2">
                    <Badge variant="default">Must-Have</Badge>
                    Core Features (Non-Negotiable)
                  </h3>
                  <ul className="space-y-2">
                    {blueprint.coreFeatures.map((feature: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-green-600 mt-1">✓</span>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <Separator />

                <div>
                  <h3 className="font-semibold text-base mb-3 flex items-center gap-2">
                    <Badge variant="secondary">Nice-to-Have</Badge>
                    Future Features
                  </h3>
                  <ul className="space-y-2">
                    {blueprint.niceToHaveFeatures.map((feature: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-gray-400 mt-1">○</span>
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl">🚀 First Version Scope (2–4 Weeks)</CardTitle>
                <CardDescription>
                  Your minimal viable product to test demand
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {blueprint.firstVersionFeatures.map((feature: string, idx: number) => (
                    <li key={idx} className="flex items-start gap-2 p-2 hover:bg-gray-50 rounded">
                      <Badge variant="outline" className="mt-0.5">
                        {idx + 1}
                      </Badge>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl">💰 Pricing Strategy</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-3">
                  {blueprint.pricingTiers.map((tier, idx: number) => (
                    <div 
                      key={idx} 
                      className={`p-4 rounded-lg border-2 ${
                        idx === 1 ? 'border-blue-500 bg-blue-50' : 'border-gray-200 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-bold text-lg">{tier.name}</h3>
                        {idx === 1 && (
                          <Badge variant="default">Popular</Badge>
                        )}
                      </div>
                      <p className="text-3xl font-bold mb-3">{tier.price}</p>
                      <p className="text-sm text-gray-600 mb-4">{tier.description}</p>
                      <ul className="space-y-2">
                        {tier.features.map((feature: string, fIdx: number) => (
                          <li key={fIdx} className="text-sm flex items-start gap-2">
                            <span className="text-green-600 mt-0.5">✓</span>
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl">🔍 Validation Plan</CardTitle>
                <CardDescription>
                  How to test demand before building everything
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">Finding 10–20 Early Users</h3>
                  <ul className="space-y-2 ml-4">
                    {blueprint.validationPlan.findUsers.map((method: string, idx: number) => (
                      <li key={idx} className="list-disc">{method}</li>
                    ))}
                  </ul>
                </div>

                <Separator />

                <div>
                  <h3 className="font-semibold mb-2">Questions to Ask Them</h3>
                  <ul className="space-y-2 ml-4">
                    {blueprint.validationPlan.questions.map((question: string, idx: number) => (
                      <li key={idx} className="list-disc italic text-gray-700">&quot;{question}&quot;</li>
                    ))}
                  </ul>
                </div>

                <Separator />

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                    <h3 className="font-semibold mb-2 text-green-800">
                      ✅ Keep Building If...
                    </h3>
                    <ul className="space-y-1 text-sm">
                      {blueprint.validationPlan.keepBuildingSignals.map((signal: string, idx: number) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="text-green-600">•</span>
                          <span>{signal}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                    <h3 className="font-semibold mb-2 text-red-800">
                      ⚠️ Pivot or Kill If...
                    </h3>
                    <ul className="space-y-1 text-sm">
                      {blueprint.validationPlan.pivotSignals.map((signal: string, idx: number) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="text-red-600">•</span>
                          <span>{signal}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl">🛠️ Development Plan</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-3">Suggested Stack</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {Object.entries(blueprint.devPlan.stack).map(([key, value]) => (
                      <div key={key} className="p-3 bg-gray-50 rounded border">
                        <p className="text-xs text-gray-600 uppercase font-semibold mb-1">
                          {key}
                        </p>
                        <p className="text-sm font-medium">{value}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="font-semibold mb-3">Implementation Steps</h3>
                  <div className="space-y-2">
                    {blueprint.devPlan.steps.map((step: string, idx: number) => (
                      <div key={idx} className="flex items-start gap-3 p-3 bg-gray-50 rounded hover:bg-gray-100 transition-colors">
                        <Badge variant="outline" className="shrink-0">
                          {idx + 1}
                        </Badge>
                        <span className="text-sm">{step}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-900">
                    <strong>💡 Pro Tip:</strong> {blueprint.devPlan.proTip}
                  </p>
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-center pt-4">
              <Button onClick={handleReset} variant="outline" size="lg">
                Create Another Blueprint
              </Button>
            </div>
          </div>
        )}
      </div>
    </main>
  )
}
