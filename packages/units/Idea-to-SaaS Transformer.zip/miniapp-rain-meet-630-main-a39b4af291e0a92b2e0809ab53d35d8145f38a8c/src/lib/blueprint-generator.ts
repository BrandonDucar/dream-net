import type { FormData, Blueprint, PricingTier } from '@/types/blueprint'

export function generateBlueprint(formData: FormData): Blueprint {
  const { idea, primaryUser, currentSolution, pricePoint } = formData
  
  const priceValue = parsePricePoint(pricePoint)
  const userType = detectUserType(primaryUser)
  const competitorType = detectCompetitorType(currentSolution)
  
  const positioning = generatePositioning(idea, primaryUser)
  const features = generateFeatures(idea, userType, competitorType)
  const pricingTiers = generatePricingTiers(priceValue, userType)
  const validationPlan = generateValidationPlan(primaryUser, competitorType)
  const devPlan = generateDevPlan(idea, priceValue)

  return {
    positioning,
    coreFeatures: features.core,
    niceToHaveFeatures: features.niceToHave,
    firstVersionFeatures: features.firstVersion,
    pricingTiers,
    validationPlan,
    devPlan
  }
}

function parsePricePoint(pricePoint: string): number {
  const numbers = pricePoint.match(/\d+/)
  return numbers ? parseInt(numbers[0]) : 29
}

function detectUserType(primaryUser: string): string {
  const lower = primaryUser.toLowerCase()
  
  if (lower.includes('developer') || lower.includes('engineer') || lower.includes('programmer')) {
    return 'developer'
  }
  if (lower.includes('designer') || lower.includes('creative') || lower.includes('artist')) {
    return 'creative'
  }
  if (lower.includes('founder') || lower.includes('entrepreneur') || lower.includes('startup')) {
    return 'founder'
  }
  if (lower.includes('marketing') || lower.includes('marketer') || lower.includes('growth')) {
    return 'marketer'
  }
  if (lower.includes('freelance') || lower.includes('consultant') || lower.includes('solo')) {
    return 'freelancer'
  }
  if (lower.includes('agency') || lower.includes('team') || lower.includes('company')) {
    return 'agency'
  }
  
  return 'general'
}

function detectCompetitorType(currentSolution: string): string {
  const lower = currentSolution.toLowerCase()
  
  if (lower.includes('nothing') || lower.includes('manual') || lower.includes('doing it themselves')) {
    return 'manual'
  }
  if (lower.includes('excel') || lower.includes('spreadsheet') || lower.includes('google sheets')) {
    return 'spreadsheet'
  }
  if (lower.includes('notion') || lower.includes('airtable') || lower.includes('database')) {
    return 'nocode'
  }
  if (lower.includes('expensive') || lower.includes('enterprise') || lower.includes('complex')) {
    return 'enterprise'
  }
  
  return 'existing'
}

function generatePositioning(idea: string, primaryUser: string): string {
  const keywords = extractKeywords(idea)
  const mainAction = keywords[0] || 'manage'
  
  return `${mainAction} for ${primaryUser} that eliminates manual work and delivers results in minutes.`
}

function extractKeywords(text: string): string[] {
  const actionWords = [
    'automate', 'manage', 'track', 'analyze', 'create', 'generate', 'build', 
    'design', 'optimize', 'monitor', 'organize', 'schedule', 'streamline',
    'simplify', 'accelerate', 'enhance'
  ]
  
  const lower = text.toLowerCase()
  const found = actionWords.filter(word => lower.includes(word))
  
  if (found.length > 0) {
    return found.map(word => capitalizeFirst(word))
  }
  
  return ['Smart tool']
}

function capitalizeFirst(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1)
}

function generateFeatures(idea: string, userType: string, competitorType: string): {
  core: string[]
  niceToHave: string[]
  firstVersion: string[]
} {
  const baseFeatures = {
    core: [
      'User authentication and secure login',
      'Core workflow automation',
      'Dashboard with key metrics',
      'Data export functionality',
      'Basic reporting'
    ],
    niceToHave: [
      'Advanced analytics and insights',
      'Team collaboration features',
      'Third-party integrations',
      'Mobile app',
      'API access for developers',
      'Custom branding options'
    ],
    firstVersion: [
      'Simple onboarding flow',
      'Single core feature that solves the main pain point',
      'Basic dashboard showing results',
      'Manual data input/upload',
      'Email notifications for key events'
    ]
  }

  if (userType === 'developer') {
    baseFeatures.core.push('API documentation and endpoints')
    baseFeatures.niceToHave.push('Webhook support', 'CLI tool')
  }

  if (userType === 'creative' || userType === 'designer') {
    baseFeatures.core.push('Visual preview functionality')
    baseFeatures.niceToHave.push('Template library', 'Asset management')
  }

  if (userType === 'agency') {
    baseFeatures.core.push('Multi-client management')
    baseFeatures.niceToHave.push('White-label options', 'Client portal')
  }

  if (competitorType === 'spreadsheet') {
    baseFeatures.core.push('Spreadsheet import/export')
    baseFeatures.firstVersion.push('One-click import from Excel/Sheets')
  }

  if (competitorType === 'manual') {
    baseFeatures.core.push('Automation of repetitive tasks')
    baseFeatures.firstVersion.push('Time-saving automation for most common task')
  }

  return baseFeatures
}

function generatePricingTiers(targetPrice: number, userType: string): PricingTier[] {
  const basePrice = Math.max(9, Math.round(targetPrice / 2))
  const midPrice = targetPrice
  const highPrice = Math.round(targetPrice * 2.5)

  const tiers: PricingTier[] = [
    {
      name: 'Starter',
      price: `$${basePrice}/mo`,
      description: 'Perfect for trying it out',
      features: [
        'Core features included',
        'Up to 100 operations/month',
        'Email support',
        'Basic analytics'
      ]
    },
    {
      name: 'Professional',
      price: `$${midPrice}/mo`,
      description: 'Best for growing users',
      features: [
        'Everything in Starter',
        'Unlimited operations',
        'Priority support',
        'Advanced analytics',
        'Export to CSV/PDF'
      ]
    },
    {
      name: 'Business',
      price: `$${highPrice}/mo`,
      description: 'For teams and power users',
      features: [
        'Everything in Professional',
        'Team collaboration (up to 5 users)',
        'API access',
        'Custom integrations',
        'Dedicated account manager'
      ]
    }
  ]

  if (userType === 'agency') {
    tiers[2].features.push('White-label options')
    tiers[2].features.push('Client management')
  }

  if (userType === 'developer') {
    tiers[1].features.push('API rate limit: 10k/day')
    tiers[2].features.push('API rate limit: 100k/day')
  }

  return tiers
}

function generateValidationPlan(primaryUser: string, competitorType: string): {
  findUsers: string[]
  questions: string[]
  keepBuildingSignals: string[]
  pivotSignals: string[]
} {
  const findUsers = [
    `Join relevant communities where ${primaryUser} hang out (Reddit, Discord, Slack groups)`,
    'Post on Twitter/LinkedIn describing the problem and asking if anyone faces it',
    'Reach out directly to 20 potential users via cold email or DMs',
    'Create a simple landing page and run $50–100 in ads to test interest',
    'Attend industry meetups or online events and talk to potential users'
  ]

  const questions = [
    'How are you currently solving this problem?',
    `How much time/money does this cost you per month?`,
    'What would make this tool a "must-have" instead of "nice-to-have"?',
    `Would you pay $${50} per month for a solution that saves you X hours/week?`,
    'What\'s the biggest frustration with your current approach?',
    'If I built this, would you be willing to try it in the first month?'
  ]

  const keepBuildingSignals = [
    '5+ people say they would pay for it immediately',
    'Users describe the pain point without prompting',
    '30%+ of conversations end with "when can I try it?"',
    'People offer to pre-pay or join a beta waitlist',
    'Current solutions are clearly inadequate or expensive'
  ]

  const pivotSignals = [
    'No one is willing to pay the proposed price',
    'People say "that\'s interesting but..." and can\'t commit',
    'The pain point exists but isn\'t urgent or frequent',
    'Users have acceptable free alternatives',
    'It takes 10+ conversations to find one interested person'
  ]

  if (competitorType === 'manual') {
    keepBuildingSignals.push('Users spend 5+ hours/week on manual tasks you could automate')
  }

  if (competitorType === 'enterprise') {
    keepBuildingSignals.push('Users complain current tools are too expensive or complex')
  }

  return {
    findUsers,
    questions,
    keepBuildingSignals,
    pivotSignals
  }
}

function generateDevPlan(idea: string, priceValue: number): {
  stack: { [key: string]: string }
  steps: string[]
  proTip: string
} {
  const stack = {
    Frontend: 'Next.js + React',
    Backend: 'Next.js API Routes',
    Database: priceValue > 50 ? 'PostgreSQL (Supabase)' : 'SQLite or Firebase',
    Auth: 'Clerk or NextAuth',
    Hosting: 'Vercel',
    Payments: 'Stripe'
  }

  const steps = [
    'Set up Next.js project with TypeScript and Tailwind CSS',
    'Design database schema for core entities (users, data, settings)',
    'Build authentication flow (signup, login, password reset)',
    'Create main dashboard with placeholder UI',
    'Implement the ONE core feature that solves the main problem',
    'Add data persistence (save/load user data)',
    'Build simple analytics/reporting view',
    'Add basic email notifications for key events',
    'Implement Stripe checkout for payments',
    'Create settings page (profile, billing, preferences)',
    'Add data export functionality (CSV or JSON)',
    'Write basic API documentation (if applicable)',
    'Test end-to-end user flow thoroughly',
    'Deploy to Vercel and set up custom domain',
    'Create simple landing page explaining value prop'
  ]

  const proTip = 'Focus on getting ONE core workflow perfect before adding more features. A tool that does one thing exceptionally well beats a tool that does ten things poorly.'

  return {
    stack,
    steps,
    proTip
  }
}
