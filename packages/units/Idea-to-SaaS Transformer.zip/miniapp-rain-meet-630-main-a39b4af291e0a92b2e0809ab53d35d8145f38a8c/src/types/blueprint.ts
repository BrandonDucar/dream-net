export interface FormData {
  idea: string
  primaryUser: string
  currentSolution: string
  pricePoint: string
}

export interface PricingTier {
  name: string
  price: string
  description: string
  features: string[]
}

export interface ValidationPlan {
  findUsers: string[]
  questions: string[]
  keepBuildingSignals: string[]
  pivotSignals: string[]
}

export interface DevPlan {
  stack: {
    [key: string]: string
  }
  steps: string[]
  proTip: string
}

export interface Blueprint {
  positioning: string
  coreFeatures: string[]
  niceToHaveFeatures: string[]
  firstVersionFeatures: string[]
  pricingTiers: PricingTier[]
  validationPlan: ValidationPlan
  devPlan: DevPlan
}
