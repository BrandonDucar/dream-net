import { NextRequest, NextResponse } from 'next/server'
import type { WalletData } from '@/types/wallet'

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const { address }: { address: string } = await request.json()

    if (!address || !address.startsWith('0x')) {
      return NextResponse.json(
        { error: 'Invalid wallet address' },
        { status: 400 }
      )
    }

    // Fetch transaction data from Basescan API (Base chain)
    const basescanUrl = `https://api.basescan.org/api?module=account&action=txlist&address=${address}&startblock=0&endblock=99999999&sort=desc&apikey=YourApiKeyToken`
    
    const txResponse = await fetch(basescanUrl)
    const txData = await txResponse.json()

    // Fetch balance from Basescan
    const balanceUrl = `https://api.basescan.org/api?module=account&action=balance&address=${address}&tag=latest&apikey=YourApiKeyToken`
    const balanceResponse = await fetch(balanceUrl)
    const balanceData = await balanceResponse.json()

    // Process and analyze the data
    const analysis: WalletData = await analyzeWalletData(address, txData, balanceData)

    return NextResponse.json(analysis)
  } catch (error) {
    console.error('Error analyzing wallet:', error)
    return NextResponse.json(
      { error: 'Failed to analyze wallet' },
      { status: 500 }
    )
  }
}

async function analyzeWalletData(
  address: string,
  txData: any,
  balanceData: any
): Promise<WalletData> {
  const transactions = txData.result || []
  const balance = balanceData.result ? (parseInt(balanceData.result) / 1e18).toFixed(4) : '0.0000'
  
  // Calculate transaction metrics
  const txCount = transactions.length
  const totalValue = transactions.reduce((sum: number, tx: any) => {
    return sum + parseFloat(tx.value) / 1e18
  }, 0)
  
  const avgTxValue = txCount > 0 ? (totalValue / txCount).toFixed(4) : '0.0000'
  
  // Determine wallet personality based on behavior
  const personality = determinePersonality(transactions, parseFloat(balance))
  const archetype = determineArchetype(personality.type)
  const riskProfile = calculateRiskProfile(transactions)
  const holdingStrategy = analyzeHoldingStrategy(transactions)
  const dailyRhythm = analyzeDailyActivity(transactions)
  const networkSignals = analyzeNetworkSignals(transactions)
  const anomalies = detectAnomalies(transactions)
  
  // Get timestamps
  const firstTx = transactions[transactions.length - 1]
  const lastTx = transactions[0]
  const firstSeen = firstTx ? new Date(parseInt(firstTx.timeStamp) * 1000).toLocaleDateString() : 'Unknown'
  const lastActive = lastTx ? new Date(parseInt(lastTx.timeStamp) * 1000).toLocaleDateString() : 'Unknown'

  return {
    address,
    balance,
    transactionCount: txCount,
    firstSeen,
    lastActive,
    personality,
    spendingProfile: {
      avgTransactionValue: `${avgTxValue} ETH`,
      totalSpent: `${totalValue.toFixed(4)} ETH`,
      topCategories: [
        { category: 'DeFi Swaps', percentage: 45, amount: '0.5 ETH' },
        { category: 'NFT Mints', percentage: 30, amount: '0.3 ETH' },
        { category: 'Transfers', percentage: 25, amount: '0.2 ETH' }
      ],
      frequency: txCount > 100 ? 'Very Active' : txCount > 50 ? 'Active' : txCount > 10 ? 'Moderate' : 'Casual'
    },
    favoriteTokens: [
      { symbol: 'ETH', name: 'Ethereum', balance: balance, valueUsd: '2500', holdings: 60 },
      { symbol: 'USDC', name: 'USD Coin', balance: '1000', valueUsd: '1000', holdings: 25 },
      { symbol: 'DEGEN', name: 'Degen', balance: '50000', valueUsd: '500', holdings: 15 }
    ],
    riskFingerprint: riskProfile,
    holdingStrategy,
    archetype,
    dailyRhythm,
    networkSignals,
    anomalies
  }
}

function determinePersonality(transactions: any[], balance: number): {
  type: string
  traits: string[]
  description: string
  emoji: string
} {
  const txCount = transactions.length
  const hasHighBalance = balance > 1
  const isVeryActive = txCount > 100

  if (hasHighBalance && txCount < 50) {
    return {
      type: 'Collector Whale',
      traits: ['Patient', 'Strategic', 'Long-term Holder'],
      description: 'This wallet accumulates and holds — making calculated moves, not chasing hype.',
      emoji: '🐋'
    }
  } else if (isVeryActive && !hasHighBalance) {
    return {
      type: 'Micro-Flow Artist',
      traits: ['Experimental', 'Frequent Trader', 'Gas Optimizer'],
      description: 'High activity, low balance — loves testing protocols and staying in motion.',
      emoji: '🎨'
    }
  } else if (isVeryActive) {
    return {
      type: 'Silent Builder',
      traits: ['Consistent', 'Developer', 'Protocol Explorer'],
      description: 'Active across contracts, likely building or deeply engaged in the ecosystem.',
      emoji: '🔨'
    }
  } else if (txCount > 20) {
    return {
      type: 'Casual Enjoyer',
      traits: ['Balanced', 'Curious', 'Steady'],
      description: 'Not rushing, not stopping — just enjoying the onchain life at their own pace.',
      emoji: '😌'
    }
  } else {
    return {
      type: 'Lurker',
      traits: ['Observer', 'Cautious', 'Selective'],
      description: 'Watching from the sidelines, making rare but intentional moves.',
      emoji: '👀'
    }
  }
}

function determineArchetype(personalityType: string): {
  title: string
  description: string
  color: string
} {
  const archetypes: Record<string, { title: string; description: string; color: string }> = {
    'Collector Whale': {
      title: 'The Accumulator',
      description: 'Diamond hands with deep pockets. This wallet believes in long-term value and rarely sells.',
      color: '#3b82f6'
    },
    'Micro-Flow Artist': {
      title: 'The Experimenter',
      description: 'Always trying something new. Low stakes, high curiosity, endless creativity.',
      color: '#ec4899'
    },
    'Silent Builder': {
      title: 'The Developer',
      description: 'Not here for the show. This wallet is shipping, testing, and pushing code.',
      color: '#8b5cf6'
    },
    'Casual Enjoyer': {
      title: 'The Balanced Explorer',
      description: 'Neither FOMO nor FUD. Just vibing onchain with steady, thoughtful moves.',
      color: '#10b981'
    },
    'Lurker': {
      title: 'The Observer',
      description: 'Watching, learning, waiting for the perfect moment to act.',
      color: '#6b7280'
    }
  }

  return archetypes[personalityType] || archetypes['Lurker']
}

function calculateRiskProfile(transactions: any[]): {
  level: 'Low' | 'Medium' | 'High' | 'Degen'
  score: number
  factors: string[]
} {
  const txCount = transactions.length
  const factors: string[] = []
  let score = 30

  if (txCount > 100) {
    score += 20
    factors.push('High transaction volume')
  }

  if (txCount < 10) {
    factors.push('Low activity')
  } else {
    factors.push('Moderate activity')
    score += 10
  }

  factors.push('On Base L2')
  score += 15

  const level = score < 40 ? 'Low' : score < 60 ? 'Medium' : score < 80 ? 'High' : 'Degen'

  return { level, score, factors }
}

function analyzeHoldingStrategy(transactions: any[]): {
  type: 'Diamond Hands' | 'Paper Hands' | 'Active Trader' | 'Balanced'
  avgHoldTime: string
  turnoverRate: number
} {
  const txCount = transactions.length

  if (txCount < 20) {
    return {
      type: 'Diamond Hands',
      avgHoldTime: '6+ months',
      turnoverRate: 5
    }
  } else if (txCount > 100) {
    return {
      type: 'Active Trader',
      avgHoldTime: '2-7 days',
      turnoverRate: 85
    }
  } else {
    return {
      type: 'Balanced',
      avgHoldTime: '1-2 months',
      turnoverRate: 40
    }
  }
}

function analyzeDailyActivity(transactions: any[]): {
  activeHours: number[]
  peakActivity: string
  timezone: string
  pattern: string
} {
  const hours = transactions.map((tx: any) => {
    const date = new Date(parseInt(tx.timeStamp) * 1000)
    return date.getUTCHours()
  })

  const uniqueHours = [...new Set(hours)].sort((a, b) => a - b)
  const mostCommonHour = hours.sort((a: number, b: number) =>
    hours.filter((v: number) => v === a).length - hours.filter((v: number) => v === b).length
  ).pop()

  return {
    activeHours: uniqueHours.slice(0, 8),
    peakActivity: `${mostCommonHour}:00 - ${(mostCommonHour || 0) + 1}:00 UTC`,
    timezone: 'UTC',
    pattern: transactions.length > 50 ? 'Consistent daily activity' : 'Sporadic activity'
  }
}

function analyzeNetworkSignals(transactions: any[]): {
  connections: number
  clusters: string[]
  influence: number
} {
  const uniqueAddresses = new Set(
    transactions.map((tx: any) => tx.to).filter((addr: string) => addr)
  )

  return {
    connections: uniqueAddresses.size,
    clusters: ['DeFi Traders', 'NFT Collectors', 'Base Early Adopters'],
    influence: Math.min(95, uniqueAddresses.size * 2)
  }
}

function detectAnomalies(transactions: any[]): Array<{
  type: string
  description: string
  severity: 'low' | 'medium' | 'high'
  timestamp: string
}> {
  const anomalies: Array<{
    type: string
    description: string
    severity: 'low' | 'medium' | 'high'
    timestamp: string
  }> = []

  if (transactions.length > 200) {
    anomalies.push({
      type: 'High Activity Spike',
      description: 'Unusually high number of transactions detected',
      severity: 'medium',
      timestamp: new Date().toLocaleDateString()
    })
  }

  if (transactions.length < 5) {
    anomalies.push({
      type: 'Low Activity',
      description: 'Very few transactions — could be a new or dormant wallet',
      severity: 'low',
      timestamp: new Date().toLocaleDateString()
    })
  }

  return anomalies
}
