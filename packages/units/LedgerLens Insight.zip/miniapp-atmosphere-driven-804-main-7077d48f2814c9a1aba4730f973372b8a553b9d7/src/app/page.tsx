'use client'
import { useState, useEffect } from 'react'
import { WalletInput } from '@/components/wallet-input'
import { WalletAnalysis } from '@/components/wallet-analysis'
import { Loader2 } from 'lucide-react'
import type { WalletData } from '@/types/wallet'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function LedgerLensPage(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [loading, setLoading] = useState<boolean>(false)
  const [walletData, setWalletData] = useState<WalletData | null>(null)
  const [error, setError] = useState<string>('')

  const handleAnalyze = async (address: string): Promise<void> => {
    setLoading(true)
    setError('')
    setWalletData(null)

    try {
      const response = await fetch('/api/analyze-wallet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address }),
      })

      if (!response.ok) {
        throw new Error('Failed to analyze wallet')
      }

      const data: WalletData = await response.json()
      setWalletData(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <div className="container mx-auto px-4 py-8 md:py-16">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-4">
            LedgerLens
          </h1>
          <p className="text-lg md:text-xl text-gray-700 max-w-2xl mx-auto">
            The AI that explains any wallet&apos;s life story. 
            <br />
            <span className="font-semibold text-purple-600">Spotify Wrapped for wallets — but real-time.</span>
          </p>
        </div>

        {/* Wallet Input */}
        <WalletInput onAnalyze={handleAnalyze} disabled={loading} />

        {/* Loading State */}
        {loading && (
          <div className="flex flex-col items-center justify-center py-16">
            <Loader2 className="h-12 w-12 animate-spin text-purple-600 mb-4" />
            <p className="text-gray-600 text-lg">Analyzing wallet behavior...</p>
            <p className="text-gray-500 text-sm mt-2">Reading the blockchain, computing patterns...</p>
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="max-w-2xl mx-auto mt-8 p-6 bg-red-50 border border-red-200 rounded-xl">
            <p className="text-red-700 font-semibold">Error: {error}</p>
          </div>
        )}

        {/* Analysis Results */}
        {walletData && !loading && (
          <WalletAnalysis data={walletData} />
        )}
      </div>
    </main>
  )
}
