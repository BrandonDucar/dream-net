'use client'

import type { WalletData } from '@/types/wallet'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  Wallet, 
  TrendingUp, 
  Shield, 
  Clock, 
  Network, 
  AlertTriangle,
  Coins,
  Target
} from 'lucide-react'

interface WalletAnalysisProps {
  data: WalletData
}

export function WalletAnalysis({ data }: WalletAnalysisProps): JSX.Element {
  return (
    <div className="max-w-7xl mx-auto mt-8 space-y-6">
      {/* Archetype Hero Card */}
      <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-3xl font-bold flex items-center gap-3">
              <span className="text-5xl">{data.personality.emoji}</span>
              {data.archetype.title}
            </CardTitle>
            <Badge className="text-lg px-4 py-2" style={{ backgroundColor: data.archetype.color }}>
              {data.personality.type}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-lg text-gray-700 mb-4">{data.archetype.description}</p>
          <div className="flex flex-wrap gap-2">
            {data.personality.traits.map((trait: string) => (
              <Badge key={trait} variant="secondary" className="text-sm">
                {trait}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <Wallet className="h-4 w-4" />
              Balance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-blue-600">{data.balance} ETH</p>
            <p className="text-xs text-gray-500 mt-1">{data.transactionCount} transactions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-600">{data.spendingProfile.frequency}</p>
            <p className="text-xs text-gray-500 mt-1">Last: {data.lastActive}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Risk Level
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-orange-600">{data.riskFingerprint.level}</p>
            <p className="text-xs text-gray-500 mt-1">Score: {data.riskFingerprint.score}/100</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <Target className="h-4 w-4" />
              Strategy
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-purple-600">{data.holdingStrategy.type}</p>
            <p className="text-xs text-gray-500 mt-1">Avg hold: {data.holdingStrategy.avgHoldTime}</p>
          </CardContent>
        </Card>
      </div>

      {/* Spending Profile */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Spending Personality
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600 mb-1">Average Transaction</p>
              <p className="text-xl font-bold text-blue-600">{data.spendingProfile.avgTransactionValue}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Spent</p>
              <p className="text-xl font-bold text-purple-600">{data.spendingProfile.totalSpent}</p>
            </div>
          </div>
          <div className="space-y-3">
            <p className="text-sm font-semibold text-gray-700">Top Categories:</p>
            {data.spendingProfile.topCategories.map((cat) => (
              <div key={cat.category} className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">{cat.category}</span>
                  <span className="text-gray-600">{cat.percentage}% • {cat.amount}</span>
                </div>
                <Progress value={cat.percentage} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Favorite Tokens */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Coins className="h-5 w-5" />
            Favorite Tokens
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {data.favoriteTokens.map((token) => (
              <div key={token.symbol} className="p-4 bg-gray-50 rounded-lg border">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-bold text-lg">{token.symbol}</p>
                    <p className="text-xs text-gray-600">{token.name}</p>
                  </div>
                  <Badge variant="secondary">{token.holdings}%</Badge>
                </div>
                <p className="text-sm text-gray-700">{token.balance}</p>
                <p className="text-xs text-gray-500 mt-1">${token.valueUsd} USD</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Risk Fingerprint */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Risk Fingerprint
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium">Risk Score</span>
              <span className="text-sm font-bold">{data.riskFingerprint.score}/100</span>
            </div>
            <Progress value={data.riskFingerprint.score} className="h-3" />
          </div>
          <div className="space-y-2">
            <p className="text-sm font-semibold text-gray-700">Risk Factors:</p>
            {data.riskFingerprint.factors.map((factor: string, index: number) => (
              <Badge key={index} variant="outline" className="mr-2">
                {factor}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Daily Rhythm */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Daily Rhythm
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-600 mb-2">Peak Activity: <span className="font-bold text-purple-600">{data.dailyRhythm.peakActivity}</span></p>
              <p className="text-sm text-gray-600">Pattern: <span className="font-medium">{data.dailyRhythm.pattern}</span></p>
              <p className="text-sm text-gray-600">Timezone: <span className="font-medium">{data.dailyRhythm.timezone}</span></p>
            </div>
            <div>
              <p className="text-sm font-semibold text-gray-700 mb-2">Active Hours:</p>
              <div className="flex flex-wrap gap-2">
                {data.dailyRhythm.activeHours.map((hour: number) => (
                  <Badge key={hour} variant="secondary">
                    {hour}:00
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Network Signals */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-5 w-5" />
            Network Graph
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Connected Wallets</span>
              <span className="text-xl font-bold text-blue-600">{data.networkSignals.connections}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Network Influence</span>
              <span className="text-xl font-bold text-purple-600">{data.networkSignals.influence}%</span>
            </div>
            <div>
              <p className="text-sm font-semibold text-gray-700 mb-2">Detected Clusters:</p>
              <div className="flex flex-wrap gap-2">
                {data.networkSignals.clusters.map((cluster: string) => (
                  <Badge key={cluster} className="bg-blue-100 text-blue-800">
                    {cluster}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Anomalies */}
      {data.anomalies.length > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-700">
              <AlertTriangle className="h-5 w-5" />
              Behavior Anomalies
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {data.anomalies.map((anomaly, index: number) => (
                <div key={index} className="p-3 bg-white rounded-lg border border-orange-200">
                  <div className="flex justify-between items-start mb-1">
                    <p className="font-semibold text-gray-800">{anomaly.type}</p>
                    <Badge 
                      variant={anomaly.severity === 'high' ? 'destructive' : 'secondary'}
                      className="text-xs"
                    >
                      {anomaly.severity}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600">{anomaly.description}</p>
                  <p className="text-xs text-gray-500 mt-1">{anomaly.timestamp}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
