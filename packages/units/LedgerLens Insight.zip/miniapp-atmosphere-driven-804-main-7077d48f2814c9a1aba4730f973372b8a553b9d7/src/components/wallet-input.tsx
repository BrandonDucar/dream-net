'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Search } from 'lucide-react'

interface WalletInputProps {
  onAnalyze: (address: string) => Promise<void>
  disabled: boolean
}

export function WalletInput({ onAnalyze, disabled }: WalletInputProps): JSX.Element {
  const [address, setAddress] = useState<string>('')

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault()
    if (address.trim()) {
      onAnalyze(address.trim())
    }
  }

  return (
    <div className="max-w-3xl mx-auto mb-12">
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
        <Input
          type="text"
          placeholder="Paste any wallet address (0x...)"
          value={address}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAddress(e.target.value)}
          disabled={disabled}
          className="flex-1 h-14 text-lg px-6 border-2 border-purple-200 focus:border-purple-500 rounded-xl"
        />
        <Button
          type="submit"
          disabled={disabled || !address.trim()}
          className="h-14 px-8 text-lg bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 rounded-xl"
        >
          <Search className="mr-2 h-5 w-5" />
          Analyze Wallet
        </Button>
      </form>
      <p className="text-sm text-gray-500 mt-3 text-center">
        Works with Base, Ethereum, and EVM-compatible chains
      </p>
    </div>
  )
}
