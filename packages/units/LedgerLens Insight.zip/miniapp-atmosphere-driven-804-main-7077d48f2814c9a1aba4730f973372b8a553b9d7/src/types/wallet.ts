export interface WalletData {
  address: string
  balance: string
  transactionCount: number
  firstSeen: string
  lastActive: string
  personality: WalletPersonality
  spendingProfile: SpendingProfile
  favoriteTokens: TokenInfo[]
  riskFingerprint: RiskFingerprint
  holdingStrategy: HoldingStrategy
  archetype: WalletArchetype
  dailyRhythm: DailyRhythm
  networkSignals: NetworkSignals
  anomalies: Anomaly[]
}

export interface WalletPersonality {
  type: string
  traits: string[]
  description: string
  emoji: string
}

export interface SpendingProfile {
  avgTransactionValue: string
  totalSpent: string
  topCategories: CategorySpend[]
  frequency: string
}

export interface CategorySpend {
  category: string
  percentage: number
  amount: string
}

export interface TokenInfo {
  symbol: string
  name: string
  balance: string
  valueUsd: string
  holdings: number
}

export interface RiskFingerprint {
  level: 'Low' | 'Medium' | 'High' | 'Degen'
  score: number
  factors: string[]
}

export interface HoldingStrategy {
  type: 'Diamond Hands' | 'Paper Hands' | 'Active Trader' | 'Balanced'
  avgHoldTime: string
  turnoverRate: number
}

export interface WalletArchetype {
  title: string
  description: string
  color: string
}

export interface DailyRhythm {
  activeHours: number[]
  peakActivity: string
  timezone: string
  pattern: string
}

export interface NetworkSignals {
  connections: number
  clusters: string[]
  influence: number
}

export interface Anomaly {
  type: string
  description: string
  severity: 'low' | 'medium' | 'high'
  timestamp: string
}
