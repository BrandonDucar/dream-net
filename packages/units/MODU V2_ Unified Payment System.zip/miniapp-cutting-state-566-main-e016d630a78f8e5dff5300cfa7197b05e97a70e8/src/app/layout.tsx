import type { Metadata } from 'next';
import '@coinbase/onchainkit/styles.css';
import './globals.css';
import { Providers } from './providers';
import FarcasterWrapper from "@/components/FarcasterWrapper";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
        <html lang="en">
          <body>
            <Providers>
      <FarcasterWrapper>
        {children}
      </FarcasterWrapper>
      </Providers>
          </body>
        </html>
      );
}

export const metadata: Metadata = {
        title: "MODU V2: Unified Payment System",
        description: "Upgrade money movement with MODU V2: a modular system integrating Mod Packs, Streams, and Programmable Actions for automated, efficient financial activities. Explore smart contract architectures and token mechanics.",
        other: { "fc:frame": JSON.stringify({"version":"next","imageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_98a5ab49-f5bb-4872-845d-6a5c790566eb-Q97x05cgz1MZgJz1uJN6XD54CmBR4x","button":{"title":"Open with Ohara","action":{"type":"launch_frame","name":"MODU V2: Unified Payment System","url":"https://cutting-state-566.app.ohara.ai","splashImageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/farcaster/splash_images/splash_image1.svg","splashBackgroundColor":"#ffffff"}}}
        ) }
    };
