'use client'
import { useState, useEffect } from 'react';
import { useAccount } from 'wagmi';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ModPackCard } from '@/components/mod-pack-card';
import { StreamBuilder } from '@/components/stream-builder';
import { ActionBuilder } from '@/components/action-builder';
import { ExampleFlows } from '@/components/example-flows';
import { TokenMetrics } from '@/components/token-metrics';
import { MOD_PACKS } from '@/lib/mod-packs';
import type { ModPack, Stream, ProgrammableAction } from '@/app/types/modu';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Page(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const { address, status } = useAccount();
  const [activeSection, setActiveSection] = useState<string>('overview');

  const handleMintModPack = (modPack: ModPack): void => {
    console.log('Minting Mod Pack:', modPack);
  };

  const handleCreateStream = (stream: Partial<Stream>): void => {
    console.log('Creating Stream:', stream);
  };

  const handleCreateAction = (action: Partial<ProgrammableAction>): void => {
    console.log('Creating Action:', action);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <header className="mb-12 text-center space-y-4">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="text-5xl">🧩</div>
            <h1 className="text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
              MODU V2
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            The unified modular payments layer for Base. One system, three primitives: Mod Packs, Streams, and Programmable Actions.
          </p>
          
          {status === 'connected' && address && (
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-500/10 border border-green-500/20 rounded-full">
              <div className="w-2 h-2 rounded-full bg-green-500"></div>
              <span className="text-sm font-medium">
                Connected: {address.slice(0, 6)}...{address.slice(-4)}
              </span>
            </div>
          )}

          <div className="flex items-center justify-center gap-4 pt-4">
            <Button variant="default" size="lg">
              Get Started
            </Button>
            <Button variant="outline" size="lg">
              View Docs
            </Button>
          </div>
        </header>

        <section className="mb-16">
          <Card className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border-blue-500/20">
            <CardHeader>
              <CardTitle className="text-2xl">What is MODU V2?</CardTitle>
              <CardDescription className="text-base">
                A single unified system that upgrades how money moves on Base
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-6 md:grid-cols-3">
                <div className="space-y-2">
                  <div className="text-3xl">🎴</div>
                  <h3 className="font-bold text-lg">Mod Packs</h3>
                  <p className="text-sm text-muted-foreground">
                    NFT ability cards that upgrade your wallet behavior. Speed, privacy, utility, and social mods that you can mint and attach.
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="text-3xl">💧</div>
                  <h3 className="font-bold text-lg">Streams</h3>
                  <p className="text-sm text-muted-foreground">
                    Continuous money flows. Set up rent, creator income, or subscriptions that drip MODU automatically over time.
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="text-3xl">⚡</div>
                  <h3 className="font-bold text-lg">Programmable Actions</h3>
                  <p className="text-sm text-muted-foreground">
                    If-then automation. When MODU comes in, auto-forward, split, burn, buy, mint, or trigger any action you configure.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="mb-16">
          <Tabs defaultValue="mod-packs" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="mod-packs">🎴 Mod Packs</TabsTrigger>
              <TabsTrigger value="streams">💧 Streams</TabsTrigger>
              <TabsTrigger value="actions">⚡ Actions</TabsTrigger>
            </TabsList>

            <TabsContent value="mod-packs" className="space-y-8">
              <div className="text-center space-y-2 mb-8">
                <h2 className="text-3xl font-bold">Mod Pack Marketplace</h2>
                <p className="text-muted-foreground">
                  Mint NFT ability cards to upgrade your wallet with modular superpowers
                </p>
              </div>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {MOD_PACKS.map((pack) => (
                  <ModPackCard key={pack.id} modPack={pack} onMint={handleMintModPack} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="streams" className="space-y-8">
              <div className="text-center space-y-2 mb-8">
                <h2 className="text-3xl font-bold">MODU Streams</h2>
                <p className="text-muted-foreground">
                  Create continuous payment flows that settle automatically
                </p>
              </div>
              <div className="max-w-2xl mx-auto">
                <StreamBuilder onCreateStream={handleCreateStream} />
              </div>
              <div className="grid gap-6 md:grid-cols-2 mt-8">
                <Card>
                  <CardHeader>
                    <CardTitle>How Streams Work</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-500/10 text-blue-500 flex items-center justify-center text-sm font-medium">
                        1
                      </div>
                      <div className="text-sm">Set recipient, rate, and duration</div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-500/10 text-blue-500 flex items-center justify-center text-sm font-medium">
                        2
                      </div>
                      <div className="text-sm">MODU drips continuously per your schedule</div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-500/10 text-blue-500 flex items-center justify-center text-sm font-medium">
                        3
                      </div>
                      <div className="text-sm">Auto-settles when duration completes</div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Stream Benefits</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-start gap-2">
                      <span className="text-green-500 font-bold">✓</span>
                      <span className="text-sm">No manual recurring payments</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="text-green-500 font-bold">✓</span>
                      <span className="text-sm">Attach Mod Packs for gas savings</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="text-green-500 font-bold">✓</span>
                      <span className="text-sm">Pause, adjust rate, or cancel anytime</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="text-green-500 font-bold">✓</span>
                      <span className="text-sm">Perfect for rent, subscriptions, payroll</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="actions" className="space-y-8">
              <div className="text-center space-y-2 mb-8">
                <h2 className="text-3xl font-bold">Programmable Actions</h2>
                <p className="text-muted-foreground">
                  No-code automation: when MODU arrives, trigger any action automatically
                </p>
              </div>
              <div className="max-w-2xl mx-auto">
                <ActionBuilder onCreateAction={handleCreateAction} />
              </div>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mt-8">
                <Card>
                  <CardHeader>
                    <div className="text-3xl mb-2">➡️</div>
                    <CardTitle className="text-base">Forward</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      Auto-route to another wallet
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <div className="text-3xl mb-2">✂️</div>
                    <CardTitle className="text-base">Split</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      Divide between multiple wallets
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <div className="text-3xl mb-2">🔥</div>
                    <CardTitle className="text-base">Auto-Burn</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      Burn percentage automatically
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <div className="text-3xl mb-2">📈</div>
                    <CardTitle className="text-base">Auto-Buy</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      DCA into other tokens
                    </p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </section>

        <section className="mb-16">
          <ExampleFlows />
        </section>

        <section className="mb-16">
          <TokenMetrics />
        </section>

        <section>
          <Card className="bg-gradient-to-br from-blue-600 to-purple-600 text-white border-0">
            <CardContent className="py-12 text-center space-y-4">
              <h2 className="text-3xl font-bold">Ready to Build with MODU V2?</h2>
              <p className="text-lg opacity-90 max-w-2xl mx-auto">
                Join the modular payments revolution on Base. No pump talk, no speculation — just pure utility and architecture.
              </p>
              <div className="flex items-center justify-center gap-4 pt-4">
                <Button variant="secondary" size="lg">
                  Start Building
                </Button>
                <Button variant="outline" size="lg" className="bg-transparent text-white border-white hover:bg-white/10">
                  Read the Docs
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  );
}
