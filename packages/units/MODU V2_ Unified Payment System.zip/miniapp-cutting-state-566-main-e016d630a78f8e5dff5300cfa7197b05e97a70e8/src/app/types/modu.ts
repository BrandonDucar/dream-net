import type { Address } from 'viem';

export type ModPackType = 'speed' | 'privacy' | 'utility' | 'social';

export interface ModPack {
  id: string;
  name: string;
  type: ModPackType;
  description: string;
  benefit: string;
  icon: string;
  price: string;
  gasReduction?: number;
}

export interface Stream {
  id: string;
  recipient: Address;
  rate: string;
  duration: number;
  startTime: number;
  active: boolean;
  autoSettle: boolean;
  modPackBonus?: string;
}

export type ActionType = 
  | 'forward'
  | 'split'
  | 'burn'
  | 'auto-buy'
  | 'mint-mod'
  | 'trigger-post'
  | 'webhook';

export interface ProgrammableAction {
  id: string;
  name: string;
  trigger: {
    amount: string;
    token: Address;
  };
  action: ActionType;
  params: Record<string, unknown>;
  active: boolean;
}

export interface SplitParams {
  walletA: Address;
  walletB: Address;
  walletC?: Address;
  percentages: number[];
}

export interface ForwardParams {
  destination: Address;
}

export interface BurnParams {
  percentage: number;
}

export interface AutoBuyParams {
  token: Address;
  percentage: number;
}
