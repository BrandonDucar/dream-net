'use client';

import { useState } from 'react';
import type { ActionType, ProgrammableAction } from '@/app/types/modu';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface ActionBuilderProps {
  onCreateAction?: (action: Partial<ProgrammableAction>) => void;
}

export function ActionBuilder({ onCreateAction }: ActionBuilderProps): JSX.Element {
  const [actionName, setActionName] = useState('');
  const [triggerAmount, setTriggerAmount] = useState('');
  const [actionType, setActionType] = useState<ActionType>('forward');
  const [param1, setParam1] = useState('');
  const [param2, setParam2] = useState('');

  const handleCreate = (): void => {
    const action: Partial<ProgrammableAction> = {
      name: actionName,
      trigger: {
        amount: triggerAmount,
        token: '0x0000000000000000000000000000000000000000' as `0x${string}`,
      },
      action: actionType,
      params: buildParams(),
      active: true,
    };
    onCreateAction?.(action);
  };

  const buildParams = (): Record<string, unknown> => {
    switch (actionType) {
      case 'forward':
        return { destination: param1 };
      case 'split':
        return { 
          walletA: param1, 
          walletB: param2, 
          percentages: [70, 30] 
        };
      case 'burn':
        return { percentage: Number(param1) || 5 };
      case 'auto-buy':
        return { token: param1, percentage: Number(param2) || 100 };
      default:
        return {};
    }
  };

  const actionDescriptions: Record<ActionType, string> = {
    forward: 'Send all incoming MODU to another wallet',
    split: 'Divide incoming MODU between multiple wallets',
    burn: 'Automatically burn a percentage of incoming MODU',
    'auto-buy': 'Use incoming MODU to buy another token',
    'mint-mod': 'Automatically mint a Mod Pack when threshold is met',
    'trigger-post': 'Post to Farcaster when you receive MODU',
    webhook: 'Call a custom webhook with transaction data',
  };

  const renderParams = (): JSX.Element => {
    switch (actionType) {
      case 'forward':
        return (
          <div className="space-y-2">
            <Label htmlFor="destination">Destination Wallet</Label>
            <Input
              id="destination"
              placeholder="0x..."
              value={param1}
              onChange={(e) => setParam1(e.target.value)}
            />
          </div>
        );
      case 'split':
        return (
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="walletA">Wallet A (70%)</Label>
              <Input
                id="walletA"
                placeholder="0x..."
                value={param1}
                onChange={(e) => setParam1(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="walletB">Wallet B (30%)</Label>
              <Input
                id="walletB"
                placeholder="0x..."
                value={param2}
                onChange={(e) => setParam2(e.target.value)}
              />
            </div>
          </div>
        );
      case 'burn':
        return (
          <div className="space-y-2">
            <Label htmlFor="percentage">Burn Percentage</Label>
            <Input
              id="percentage"
              type="number"
              placeholder="5"
              value={param1}
              onChange={(e) => setParam1(e.target.value)}
            />
          </div>
        );
      case 'auto-buy':
        return (
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="token">Token Address</Label>
              <Input
                id="token"
                placeholder="0x..."
                value={param1}
                onChange={(e) => setParam1(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="buyPercentage">Use % of MODU</Label>
              <Input
                id="buyPercentage"
                type="number"
                placeholder="100"
                value={param2}
                onChange={(e) => setParam2(e.target.value)}
              />
            </div>
          </div>
        );
      default:
        return (
          <div className="text-sm text-muted-foreground py-4">
            Coming soon: {actionType} configuration
          </div>
        );
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Programmable Actions</CardTitle>
        <CardDescription>
          Set up if-then automation for incoming MODU
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="action-name">Action Name</Label>
          <Input
            id="action-name"
            placeholder="My Auto-Split"
            value={actionName}
            onChange={(e) => setActionName(e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="trigger">Trigger Amount (MODU)</Label>
          <Input
            id="trigger"
            type="number"
            placeholder="100"
            value={triggerAmount}
            onChange={(e) => setTriggerAmount(e.target.value)}
          />
          <p className="text-xs text-muted-foreground">
            Action triggers when you receive this amount
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="action-type">Action Type</Label>
          <Select value={actionType} onValueChange={(value) => setActionType(value as ActionType)}>
            <SelectTrigger id="action-type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="forward">Forward</SelectItem>
              <SelectItem value="split">Split</SelectItem>
              <SelectItem value="burn">Auto-Burn</SelectItem>
              <SelectItem value="auto-buy">Auto-Buy Token</SelectItem>
              <SelectItem value="mint-mod">Mint Mod Pack</SelectItem>
              <SelectItem value="trigger-post">Trigger Post</SelectItem>
              <SelectItem value="webhook">Webhook</SelectItem>
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            {actionDescriptions[actionType]}
          </p>
        </div>

        {renderParams()}

        <div className="pt-4 border-t">
          <Button onClick={handleCreate} className="w-full" disabled={!actionName || !triggerAmount}>
            Create Action
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
