'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface ExampleFlow {
  id: string;
  title: string;
  category: string;
  steps: string[];
  benefit: string;
}

const EXAMPLE_FLOWS: ExampleFlow[] = [
  {
    id: 'creator-income',
    title: 'Creator Income Automation',
    category: 'Creator',
    steps: [
      'Followers stream 1 MODU/day to creator',
      'Creator attaches Speed Mod Pack (12% gas savings)',
      'Auto-split action sends 5% to savings wallet',
      'Remaining 95% available for instant use',
    ],
    benefit: 'Passive income with automated savings',
  },
  {
    id: 'rent-stream',
    title: 'Rent Payment Stream',
    category: 'Payment',
    steps: [
      'Set stream: 500 MODU/month to landlord',
      'Duration: 12 months',
      'Auto-settle: On',
      'Attach Speed Mod for reduced gas fees',
    ],
    benefit: 'Set-and-forget monthly payments',
  },
  {
    id: 'dca-automation',
    title: 'DCA Investment Strategy',
    category: 'Trading',
    steps: [
      'Receive 100 MODU from any source',
      'Programmable action triggers',
      'Auto-buy ETH with 70% of incoming MODU',
      'Forward remaining 30% to savings',
    ],
    benefit: 'Automated dollar-cost averaging',
  },
  {
    id: 'freelance-split',
    title: 'Freelancer Payment Split',
    category: 'Business',
    steps: [
      'Client sends project payment',
      'Action auto-splits: 60% to main wallet',
      '25% to tax savings wallet',
      '15% to business development fund',
    ],
    benefit: 'Automatic financial organization',
  },
];

export function ExampleFlows(): JSX.Element {
  const categoryColors: Record<string, string> = {
    Creator: 'bg-purple-500/10 text-purple-500 border-purple-500/20',
    Payment: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
    Trading: 'bg-green-500/10 text-green-500 border-green-500/20',
    Business: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
  };

  return (
    <div className="space-y-4">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold">Real-World Use Cases</h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          See how MODU V2 transforms payment workflows with modular automation
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {EXAMPLE_FLOWS.map((flow) => (
          <Card key={flow.id} className="hover:border-primary/50 transition-colors">
            <CardHeader>
              <div className="flex items-start justify-between mb-2">
                <CardTitle className="text-xl">{flow.title}</CardTitle>
                <Badge variant="outline" className={categoryColors[flow.category]}>
                  {flow.category}
                </Badge>
              </div>
              <CardDescription className="text-green-600 dark:text-green-400 font-medium">
                {flow.benefit}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ol className="space-y-3">
                {flow.steps.map((step, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-sm font-medium">
                      {idx + 1}
                    </div>
                    <span className="text-sm flex-1 pt-0.5">{step}</span>
                  </li>
                ))}
              </ol>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
