'use client';

import { useState } from 'react';
import type { ModPack } from '@/app/types/modu';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface ModPackCardProps {
  modPack: ModPack;
  onMint?: (modPack: ModPack) => void;
}

export function ModPackCard({ modPack, onMint }: ModPackCardProps): JSX.Element {
  const [isMinting, setIsMinting] = useState(false);

  const handleMint = async (): Promise<void> => {
    setIsMinting(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      onMint?.(modPack);
    } finally {
      setIsMinting(false);
    }
  };

  const typeColors: Record<string, string> = {
    speed: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
    privacy: 'bg-purple-500/10 text-purple-500 border-purple-500/20',
    utility: 'bg-green-500/10 text-green-500 border-green-500/20',
    social: 'bg-pink-500/10 text-pink-500 border-pink-500/20',
  };

  return (
    <Card className="h-full flex flex-col hover:border-primary/50 transition-colors">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="text-4xl mb-2">{modPack.icon}</div>
          <Badge variant="outline" className={typeColors[modPack.type]}>
            {modPack.type}
          </Badge>
        </div>
        <CardTitle className="text-xl">{modPack.name}</CardTitle>
        <CardDescription>{modPack.description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
        <div className="space-y-2">
          <div className="text-sm font-medium text-green-600 dark:text-green-400">
            ✓ {modPack.benefit}
          </div>
          {modPack.gasReduction && (
            <div className="text-xs text-muted-foreground">
              Gas reduction: {modPack.gasReduction}%
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex items-center justify-between">
        <div className="text-2xl font-bold">{modPack.price} MODU</div>
        <Button onClick={handleMint} disabled={isMinting}>
          {isMinting ? 'Minting...' : 'Mint Pack'}
        </Button>
      </CardFooter>
    </Card>
  );
}
