'use client';

import { useState } from 'react';
import type { Stream } from '@/app/types/modu';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';

interface StreamBuilderProps {
  onCreateStream?: (stream: Partial<Stream>) => void;
}

export function StreamBuilder({ onCreateStream }: StreamBuilderProps): JSX.Element {
  const [recipient, setRecipient] = useState('');
  const [rate, setRate] = useState('');
  const [duration, setDuration] = useState('30');
  const [autoSettle, setAutoSettle] = useState(true);
  const [timeUnit, setTimeUnit] = useState('day');

  const handleCreate = (): void => {
    const stream: Partial<Stream> = {
      recipient: recipient as `0x${string}`,
      rate,
      duration: Number(duration),
      autoSettle,
      startTime: Date.now(),
      active: true,
    };
    onCreateStream?.(stream);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create a MODU Stream</CardTitle>
        <CardDescription>
          Set up continuous payments that drip automatically over time
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="recipient">Recipient Address</Label>
          <Input
            id="recipient"
            placeholder="0x..."
            value={recipient}
            onChange={(e) => setRecipient(e.target.value)}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="rate">Rate (MODU)</Label>
            <Input
              id="rate"
              type="number"
              placeholder="0.1"
              value={rate}
              onChange={(e) => setRate(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="timeUnit">Per</Label>
            <Select value={timeUnit} onValueChange={setTimeUnit}>
              <SelectTrigger id="timeUnit">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="minute">Minute</SelectItem>
                <SelectItem value="hour">Hour</SelectItem>
                <SelectItem value="day">Day</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="duration">Duration (days)</Label>
          <Input
            id="duration"
            type="number"
            placeholder="30"
            value={duration}
            onChange={(e) => setDuration(e.target.value)}
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="auto-settle">Auto-settle on completion</Label>
            <p className="text-xs text-muted-foreground">
              Automatically finalize when duration ends
            </p>
          </div>
          <Switch
            id="auto-settle"
            checked={autoSettle}
            onCheckedChange={setAutoSettle}
          />
        </div>

        <div className="pt-4 border-t">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-medium">Total Stream Value:</span>
            <span className="text-2xl font-bold">
              {rate && duration ? (Number(rate) * Number(duration)).toFixed(2) : '0.00'} MODU
            </span>
          </div>
          <Button onClick={handleCreate} className="w-full" disabled={!recipient || !rate || !duration}>
            Create Stream
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
