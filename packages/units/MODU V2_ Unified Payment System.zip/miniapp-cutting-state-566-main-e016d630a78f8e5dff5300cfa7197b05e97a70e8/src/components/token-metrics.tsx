'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface Metric {
  label: string;
  value: string;
  description: string;
  icon: string;
}

const METRICS: Metric[] = [
  {
    label: 'Minting Mod Packs',
    value: '8-50 MODU',
    description: 'Unlock wallet abilities',
    icon: '🎴',
  },
  {
    label: 'Stream Boosting',
    value: '0.5% fee',
    description: 'Faster settlement times',
    icon: '💧',
  },
  {
    label: 'Action Execution',
    value: '0.1 MODU',
    description: 'Per automation trigger',
    icon: '⚡',
  },
  {
    label: 'Gas Reduction',
    value: 'Up to 40%',
    description: 'With Ultra Batch Mod',
    icon: '🚀',
  },
  {
    label: 'Upgrade Tiers',
    value: '3 Levels',
    description: 'Basic → Enhanced → Pro',
    icon: '📊',
  },
  {
    label: 'Network',
    value: 'Base',
    description: 'Low fees, high speed',
    icon: '🔵',
  },
];

export function TokenMetrics(): JSX.Element {
  return (
    <div className="space-y-8">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold">$MODU2 Token Utility</h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Pure utility token powering the entire modular payments ecosystem
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {METRICS.map((metric) => (
          <Card key={metric.label}>
            <CardHeader>
              <div className="text-3xl mb-2">{metric.icon}</div>
              <CardTitle className="text-lg">{metric.label}</CardTitle>
              <CardDescription>{metric.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">
                {metric.value}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border-blue-500/20">
        <CardHeader>
          <CardTitle>No Fake Yield, No Confusing Locks</CardTitle>
          <CardDescription>
            MODU V2 is built on pure utility — every token has a real purpose in the ecosystem
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            <li className="flex items-start gap-2">
              <span className="text-green-500 font-bold">✓</span>
              <span className="text-sm">Transparent pricing for all features</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-500 font-bold">✓</span>
              <span className="text-sm">Direct utility in every transaction</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-500 font-bold">✓</span>
              <span className="text-sm">Base-native for maximum efficiency</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-500 font-bold">✓</span>
              <span className="text-sm">Modular design enables infinite extensions</span>
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
