import type { ModPack } from '@/app/types/modu';

export const MOD_PACKS: ModPack[] = [
  {
    id: 'speed-boost',
    name: 'Speed Boost',
    type: 'speed',
    description: 'Batch transactions and optimize gas routing',
    benefit: 'Reduce gas costs by 12-25%',
    icon: '⚡',
    price: '10',
    gasReduction: 15,
  },
  {
    id: 'stealth-mode',
    name: 'Stealth Mode',
    type: 'privacy',
    description: 'Legal obfuscation between wallet addresses',
    benefit: 'Enhanced privacy for legitimate transactions',
    icon: '🥷',
    price: '25',
  },
  {
    id: 'auto-split',
    name: 'Auto-Split Pro',
    type: 'utility',
    description: 'Automatically split incoming payments',
    benefit: 'Set-and-forget payment distribution',
    icon: '✂️',
    price: '15',
  },
  {
    id: 'social-share',
    name: 'Social Share',
    type: 'social',
    description: 'Auto-post transactions to Farcaster',
    benefit: 'Build your onchain reputation',
    icon: '📱',
    price: '8',
  },
  {
    id: 'trade-trigger',
    name: 'Trade Trigger',
    type: 'utility',
    description: 'Auto-buy tokens when MODU arrives',
    benefit: 'DCA automation built-in',
    icon: '📈',
    price: '20',
  },
  {
    id: 'ultra-batch',
    name: 'Ultra Batch',
    type: 'speed',
    description: 'Advanced batching with MEV protection',
    benefit: 'Reduce gas by up to 40%',
    icon: '🚀',
    price: '50',
    gasReduction: 35,
  },
];

export function getModPacksByType(type: string): ModPack[] {
  return MOD_PACKS.filter((pack) => pack.type === type);
}

export function getModPackById(id: string): ModPack | undefined {
  return MOD_PACKS.find((pack) => pack.id === id);
}
