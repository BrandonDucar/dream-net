'use client'
import { useState, useEffect } from "react";
import type { SportCode, MatchupRequest, MatchupResult, SimulationResult } from "@/lib/types";
import { generateMatchup, simulateMatchup, getTeamsForSport } from "@/lib/matchup";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import GeofencingBanner from "@/components/GeofencingBanner";
import OddsComparison from "@/components/OddsComparison";
import AIAssistant from "@/components/AIAssistant";
import BankrollTracker from "@/components/BankrollTracker";
import AdvancedCalculators from "@/components/AdvancedCalculators";
import EnhancedPredictorTab from "@/components/EnhancedPredictorTab";
import MLPredictionsTab from "@/components/MLPredictionsTab";
import SentimentTab from "@/components/SentimentTab";
import LiveTrackingTab from "@/components/LiveTrackingTab";
import ParlayBuilderTab from "@/components/ParlayBuilderTab";
import AdvancedFeaturesTab from "@/components/AdvancedFeaturesTab";
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

const SPORTS: SportCode[] = ["NFL", "NBA", "NCAAB", "NCAAF", "MLB", "NHL", "SOCCER", "UFC"];

export default function UniversalMatchupPredictor() {
  const { addMiniApp } = useAddMiniApp();
  const isInFarcaster = useIsInFarcaster();
  useQuickAuth(isInFarcaster);

  useEffect(() => {
    const tryAddMiniApp = async () => {
      try {
        await addMiniApp();
      } catch (error) {
        console.error('Failed to add mini app:', error);
      }
    };
    tryAddMiniApp();
  }, [addMiniApp]);

  useEffect(() => {
    const initializeFarcaster = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 100));
        
        if (document.readyState !== 'complete') {
          await new Promise<void>(resolve => {
            if (document.readyState === 'complete') {
              resolve();
            } else {
              window.addEventListener('load', () => resolve(), { once: true });
            }
          });
        }

        await sdk.actions.ready();
        console.log('Farcaster SDK initialized successfully - app fully loaded');
      } catch (error) {
        console.error('Failed to initialize Farcaster SDK:', error);
        
        setTimeout(async () => {
          try {
            await sdk.actions.ready();
            console.log('Farcaster SDK initialized on retry');
          } catch (retryError) {
            console.error('Farcaster SDK retry failed:', retryError);
          }
        }, 1000);
      }
    };

    initializeFarcaster();
  }, []);

  const [activeTab, setActiveTab] = useState<string>("predictor");
  const [activeSubTab, setActiveSubTab] = useState<string>("analytics");
  const [sport, setSport] = useState<SportCode | "">("");
  const [teamAId, setTeamAId] = useState<string>("");
  const [teamBId, setTeamBId] = useState<string>("");
  const [neutralSite, setNeutralSite] = useState<boolean>(false);
  const [marketSpread, setMarketSpread] = useState<string>("");
  const [marketTotal, setMarketTotal] = useState<string>("");

  const [result, setResult] = useState<MatchupResult | null>(null);
  const [simulation, setSimulation] = useState<SimulationResult | null>(null);
  const [simIterations, setSimIterations] = useState<number>(100);

  const teamsForSport = sport ? getTeamsForSport(sport) : [];

  const handleGenerateMatchup = () => {
    if (!sport || !teamAId || !teamBId) return;

    const req: MatchupRequest = {
      sport,
      teamAId,
      teamBId,
      neutralSite,
      marketSpread: marketSpread ? parseFloat(marketSpread) : undefined,
      marketTotal: marketTotal ? parseFloat(marketTotal) : undefined,
    };

    const matchupResult = generateMatchup(req);
    setResult(matchupResult);
    setSimulation(null);
  };

  const handleRunSimulation = () => {
    if (!result || !sport) return;
    const simResult = simulateMatchup(sport, result, simIterations);
    setSimulation(simResult);
  };

  const canGenerate = sport && teamAId && teamBId;

  return (
    <div className="min-h-screen bg-[#020617] text-white pt-8 pb-16 px-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-[#22d3ee] to-[#22c55e] bg-clip-text text-transparent">
            Universal Matchup Predictor
          </h1>
          <p className="text-gray-400 text-lg">
            AI-Powered Sports Betting Analytics Platform • All Sports, All Tools
          </p>
          <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
            <Badge variant="outline" className="bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]">
              Free Forever
            </Badge>
            <Badge variant="outline" className="bg-[#22d3ee]/20 text-[#22d3ee] border-[#22d3ee]">
              Real-Time Odds
            </Badge>
            <Badge variant="outline" className="bg-[#fbbf24]/20 text-[#fbbf24] border-[#fbbf24]">
              AI Assistant
            </Badge>
          </div>
        </div>

        {/* Geofencing Banner */}
        <GeofencingBanner />

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 md:grid-cols-6 bg-[#1e293b] border border-[#334155] h-auto">
            <TabsTrigger 
              value="predictor" 
              className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black py-3"
            >
              <div className="flex flex-col items-center">
                <span className="text-lg">🎯</span>
                <span className="text-xs md:text-sm">Predictor</span>
              </div>
            </TabsTrigger>
            <TabsTrigger 
              value="odds" 
              className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black py-3"
            >
              <div className="flex flex-col items-center">
                <span className="text-lg">📊</span>
                <span className="text-xs md:text-sm">Live Odds</span>
              </div>
            </TabsTrigger>
            <TabsTrigger 
              value="calculators" 
              className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black py-3"
            >
              <div className="flex flex-col items-center">
                <span className="text-lg">🧮</span>
                <span className="text-xs md:text-sm">Calculators</span>
              </div>
            </TabsTrigger>
            <TabsTrigger 
              value="bankroll" 
              className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black py-3"
            >
              <div className="flex flex-col items-center">
                <span className="text-lg">💰</span>
                <span className="text-xs md:text-sm">Bankroll</span>
              </div>
            </TabsTrigger>
            <TabsTrigger 
              value="ai" 
              className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black py-3"
            >
              <div className="flex flex-col items-center">
                <span className="text-lg">🤖</span>
                <span className="text-xs md:text-sm">AI Helper</span>
              </div>
            </TabsTrigger>
            <TabsTrigger 
              value="advanced" 
              className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black py-3"
            >
              <div className="flex flex-col items-center">
                <span className="text-lg">⚡</span>
                <span className="text-xs md:text-sm">Advanced</span>
              </div>
            </TabsTrigger>
          </TabsList>

          {/* Matchup Predictor Tab */}
          <TabsContent value="predictor" className="space-y-6 mt-6">
            {/* Matchup Selector Card */}
            <Card className="bg-[#0f172a] border-[#1e293b]">
              <CardHeader>
                <CardTitle className="text-2xl text-white">Select Matchup</CardTitle>
                <CardDescription className="text-gray-400">
                  Choose sport and teams to generate win probabilities and fair odds
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Sport Selector */}
                <div className="space-y-2">
                  <Label htmlFor="sport" className="text-white">Sport</Label>
                  <Select
                    value={sport}
                    onValueChange={(value: string) => {
                      setSport(value as SportCode);
                      setTeamAId("");
                      setTeamBId("");
                      setResult(null);
                      setSimulation(null);
                    }}
                  >
                    <SelectTrigger id="sport" className="bg-[#1e293b] border-[#334155] text-white">
                      <SelectValue placeholder="Select a sport" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#1e293b] border-[#334155]">
                      {SPORTS.map((s: SportCode) => (
                        <SelectItem key={s} value={s} className="text-white hover:bg-[#334155]">
                          {s}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Team Selectors */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="teamA" className="text-white">Team A</Label>
                    <Select
                      value={teamAId}
                      onValueChange={setTeamAId}
                      disabled={!sport}
                    >
                      <SelectTrigger id="teamA" className="bg-[#1e293b] border-[#334155] text-white">
                        <SelectValue placeholder="Select Team A" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#1e293b] border-[#334155]">
                        {teamsForSport.map((team) => (
                          <SelectItem
                            key={team.id}
                            value={team.id}
                            className="text-white hover:bg-[#334155]"
                          >
                            {team.displayName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="teamB" className="text-white">Team B</Label>
                    <Select
                      value={teamBId}
                      onValueChange={setTeamBId}
                      disabled={!sport}
                    >
                      <SelectTrigger id="teamB" className="bg-[#1e293b] border-[#334155] text-white">
                        <SelectValue placeholder="Select Team B" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#1e293b] border-[#334155]">
                        {teamsForSport.map((team) => (
                          <SelectItem
                            key={team.id}
                            value={team.id}
                            className="text-white hover:bg-[#334155]"
                          >
                            {team.displayName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Neutral Site Toggle */}
                <div className="flex items-center space-x-3 bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                  <Switch
                    id="neutral"
                    checked={neutralSite}
                    onCheckedChange={setNeutralSite}
                    className="data-[state=checked]:bg-[#22d3ee]"
                  />
                  <Label htmlFor="neutral" className="text-white cursor-pointer">
                    Neutral Site (removes home advantage)
                  </Label>
                </div>

                {/* Market Context (Optional) */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <div className="h-px flex-1 bg-[#334155]" />
                    <span className="text-gray-400 text-sm">Optional Market Context</span>
                    <div className="h-px flex-1 bg-[#334155]" />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="spread" className="text-white">
                        Market Spread (Team A)
                      </Label>
                      <Input
                        id="spread"
                        type="number"
                        step="0.5"
                        placeholder="e.g., -3.5"
                        value={marketSpread}
                        onChange={(e) => setMarketSpread(e.target.value)}
                        className="bg-[#1e293b] border-[#334155] text-white placeholder:text-gray-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="total" className="text-white">
                        Market Total
                      </Label>
                      <Input
                        id="total"
                        type="number"
                        step="0.5"
                        placeholder="e.g., 215.5"
                        value={marketTotal}
                        onChange={(e) => setMarketTotal(e.target.value)}
                        className="bg-[#1e293b] border-[#334155] text-white placeholder:text-gray-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Generate Button */}
                <Button
                  onClick={handleGenerateMatchup}
                  disabled={!canGenerate}
                  className="w-full bg-[#22d3ee] hover:bg-[#06b6d4] text-black font-semibold text-lg py-6"
                >
                  Generate Matchup Analysis
                </Button>
              </CardContent>
            </Card>

            {/* Results Card */}
            {result && (
              <>
                <Card className="bg-[#0f172a] border-[#1e293b]">
                  <CardHeader>
                    <CardTitle className="text-3xl text-white">
                      {result.teamAName} vs {result.teamBName}
                    </CardTitle>
                    <CardDescription className="text-gray-400 text-lg">
                      {sport} • {neutralSite ? "Neutral Site" : "Home Advantage to Team A"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Win Probabilities */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155] space-y-2">
                        <div className="text-gray-400 text-sm">Team A Win Probability</div>
                        <div className="text-4xl font-bold text-[#22c55e]">
                          {(result.winProbA * 100).toFixed(1)}%
                        </div>
                        <div className="text-sm text-gray-400">{result.teamAName}</div>
                      </div>

                      <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155] space-y-2">
                        <div className="text-gray-400 text-sm">Team B Win Probability</div>
                        <div className="text-4xl font-bold text-[#22c55e]">
                          {(result.winProbB * 100).toFixed(1)}%
                        </div>
                        <div className="text-sm text-gray-400">{result.teamBName}</div>
                      </div>
                    </div>

                    {/* Projected Score */}
                    {result.projectedScoreA !== null && result.projectedScoreB !== null && (
                      <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
                        <div className="text-gray-400 text-sm mb-2">Projected Final Score</div>
                        <div className="text-3xl font-bold text-white">
                          {result.projectedScoreA} - {result.projectedScoreB}
                        </div>
                        <div className="text-sm text-gray-400 mt-1">
                          Total: {(result.projectedScoreA + result.projectedScoreB).toFixed(1)}
                        </div>
                      </div>
                    )}

                    {/* Fair Odds */}
                    <div className="space-y-3">
                      <div className="text-lg font-semibold text-white">Fair Odds</div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                          <div className="text-gray-400 text-sm mb-2">{result.teamAName}</div>
                          <div className="space-y-1">
                            <div className="text-xl font-bold text-[#22d3ee]">
                              {result.fairAmericanA > 0 ? `+${result.fairAmericanA}` : result.fairAmericanA}
                            </div>
                            <div className="text-sm text-gray-400">
                              Decimal: {result.fairDecimalA.toFixed(2)}
                            </div>
                          </div>
                        </div>

                        <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                          <div className="text-gray-400 text-sm mb-2">{result.teamBName}</div>
                          <div className="space-y-1">
                            <div className="text-xl font-bold text-[#22d3ee]">
                              {result.fairAmericanB > 0 ? `+${result.fairAmericanB}` : result.fairAmericanB}
                            </div>
                            <div className="text-sm text-gray-400">
                              Decimal: {result.fairDecimalB.toFixed(2)}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Upset Probability & Favored Team */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                        <div className="text-gray-400 text-sm">Upset Probability</div>
                        <div className="text-2xl font-bold text-[#f87171] mt-1">
                          {(result.upsetProbability * 100).toFixed(1)}%
                        </div>
                      </div>

                      <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                        <div className="text-gray-400 text-sm">Favored Team</div>
                        <div className="text-xl font-bold text-white mt-1">
                          {result.favoredTeam === "A" ? result.teamAName : 
                           result.favoredTeam === "B" ? result.teamBName : 
                           "Even Matchup"}
                        </div>
                      </div>
                    </div>

                    <Separator className="bg-[#334155]" />

                    {/* Analysis Sections */}
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="text-lg font-semibold text-white">Pace Notes</div>
                        <p className="text-gray-300 text-sm leading-relaxed">{result.paceNotes}</p>
                      </div>

                      <div className="space-y-2">
                        <div className="text-lg font-semibold text-white">Style Notes</div>
                        <ul className="space-y-1">
                          {result.styleNotes.map((note: string, idx: number) => (
                            <li key={idx} className="text-gray-300 text-sm flex items-start">
                              <span className="text-[#22d3ee] mr-2">•</span>
                              <span>{note}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="space-y-2">
                        <div className="text-lg font-semibold text-white">Key Edges</div>
                        <ul className="space-y-1">
                          {result.keyEdges.map((edge: string, idx: number) => (
                            <li key={idx} className="text-gray-300 text-sm flex items-start">
                              <span className="text-[#22d3ee] mr-2">•</span>
                              <span>{edge}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                        <div className="text-lg font-semibold text-white mb-2">Lean Summary</div>
                        <p className="text-gray-300 text-sm leading-relaxed">{result.leanSummary}</p>
                      </div>
                    </div>

                    <div className="bg-[#334155] p-3 rounded-lg">
                      <p className="text-xs text-gray-400 text-center">
                        Analytics for informational purposes only. Not betting advice or guaranteed outcomes.
                      </p>
                    </div>
                  </CardContent>
                </Card>

                {/* Enhanced Features Sub-Tabs */}
                <Tabs value={activeSubTab} onValueChange={setActiveSubTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 bg-[#1e293b] border border-[#334155]">
                    <TabsTrigger value="analytics" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
                      📈 Analytics
                    </TabsTrigger>
                    <TabsTrigger value="ml" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
                      🤖 ML Models
                    </TabsTrigger>
                    <TabsTrigger value="sentiment" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
                      💬 Sentiment
                    </TabsTrigger>
                    <TabsTrigger value="live" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
                      📡 Live
                    </TabsTrigger>
                    <TabsTrigger value="parlays" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
                      🎲 Parlays
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="analytics" className="mt-6">
                    <EnhancedPredictorTab 
                      result={result} 
                      sport={sport as SportCode} 
                      teamAId={teamAId} 
                      teamBId={teamBId}
                      neutralSite={neutralSite}
                    />
                  </TabsContent>

                  <TabsContent value="ml" className="mt-6">
                    <MLPredictionsTab result={result} />
                  </TabsContent>

                  <TabsContent value="sentiment" className="mt-6">
                    <SentimentTab 
                      teamAId={teamAId}
                      teamBId={teamBId}
                      teamAName={result.teamAName}
                      teamBName={result.teamBName}
                      sport={sport as SportCode}
                    />
                  </TabsContent>

                  <TabsContent value="live" className="mt-6">
                    <LiveTrackingTab 
                      teamAId={teamAId}
                      teamBId={teamBId}
                      sport={sport as SportCode}
                    />
                  </TabsContent>

                  <TabsContent value="parlays" className="mt-6">
                    <ParlayBuilderTab result={result} sport={sport as SportCode} />
                  </TabsContent>
                </Tabs>

                {/* Simulation Card */}
                <Card className="bg-[#0f172a] border-[#1e293b]">
                  <CardHeader>
                    <CardTitle className="text-2xl text-white">Monte Carlo Simulation</CardTitle>
                    <CardDescription className="text-gray-400">
                      Run simulations to see outcome distributions and volatility
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Simulation Controls */}
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="iterations" className="text-white">
                          Number of Simulations
                        </Label>
                        <Select
                          value={simIterations.toString()}
                          onValueChange={(value: string) => setSimIterations(parseInt(value))}
                        >
                          <SelectTrigger id="iterations" className="bg-[#1e293b] border-[#334155] text-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-[#1e293b] border-[#334155]">
                            <SelectItem value="100" className="text-white hover:bg-[#334155]">
                              100 Simulations
                            </SelectItem>
                            <SelectItem value="500" className="text-white hover:bg-[#334155]">
                              500 Simulations
                            </SelectItem>
                            <SelectItem value="1000" className="text-white hover:bg-[#334155]">
                              1000 Simulations
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <Button
                        onClick={handleRunSimulation}
                        className="w-full bg-[#22d3ee] hover:bg-[#06b6d4] text-black font-semibold py-6"
                      >
                        Run Simulations
                      </Button>
                    </div>

                    {/* Simulation Results */}
                    {simulation && (
                      <div className="space-y-4">
                        <Separator className="bg-[#334155]" />

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                            <div className="text-gray-400 text-xs mb-1">Team A Wins</div>
                            <div className="text-2xl font-bold text-[#22c55e]">
                              {(simulation.winPctA * 100).toFixed(1)}%
                            </div>
                            <div className="text-xs text-gray-500 mt-1">
                              {simulation.winsA} / {simulation.iterations}
                            </div>
                          </div>

                          <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                            <div className="text-gray-400 text-xs mb-1">Team B Wins</div>
                            <div className="text-2xl font-bold text-[#22c55e]">
                              {(simulation.winPctB * 100).toFixed(1)}%
                            </div>
                            <div className="text-xs text-gray-500 mt-1">
                              {simulation.winsB} / {simulation.iterations}
                            </div>
                          </div>

                          <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                            <div className="text-gray-400 text-xs mb-1">Close Games</div>
                            <div className="text-2xl font-bold text-[#fbbf24]">
                              {(simulation.closeGamePct * 100).toFixed(1)}%
                            </div>
                          </div>

                          <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                            <div className="text-gray-400 text-xs mb-1">Chaos Index</div>
                            <div className="text-2xl font-bold text-[#f87171]">
                              {simulation.chaosIndex.toFixed(2)}
                            </div>
                          </div>
                        </div>

                        {simulation.avgScoreA !== null && simulation.avgScoreB !== null && (
                          <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
                            <div className="text-gray-400 text-sm mb-2">Average Simulated Score</div>
                            <div className="text-3xl font-bold text-white">
                              {simulation.avgScoreA} - {simulation.avgScoreB}
                            </div>
                          </div>
                        )}

                        {/* Blowout Percentages */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                            <div className="text-gray-400 text-sm">Team A Blowout %</div>
                            <div className="text-xl font-bold text-[#22c55e] mt-1">
                              {(simulation.blowoutPctA * 100).toFixed(1)}%
                            </div>
                          </div>

                          <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                            <div className="text-gray-400 text-sm">Team B Blowout %</div>
                            <div className="text-xl font-bold text-[#22c55e] mt-1">
                              {(simulation.blowoutPctB * 100).toFixed(1)}%
                            </div>
                          </div>
                        </div>

                        <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-400">Volatility Assessment</span>
                            <Badge
                              variant="outline"
                              className={
                                simulation.chaosIndex < 2
                                  ? "bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]"
                                  : simulation.chaosIndex < 5
                                  ? "bg-[#fbbf24]/20 text-[#fbbf24] border-[#fbbf24]"
                                  : "bg-[#f87171]/20 text-[#f87171] border-[#f87171]"
                              }
                            >
                              {simulation.chaosIndex < 2
                                ? "Low Volatility"
                                : simulation.chaosIndex < 5
                                ? "Medium Volatility"
                                : "High Volatility"}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </>
            )}
          </TabsContent>

          {/* Live Odds Tab */}
          <TabsContent value="odds" className="space-y-6 mt-6">
            {result ? (
              <OddsComparison teamAName={result.teamAName} teamBName={result.teamBName} />
            ) : (
              <Card className="bg-[#0f172a] border-[#1e293b]">
                <CardContent className="py-12">
                  <div className="text-center text-gray-400">
                    <div className="text-4xl mb-4">📊</div>
                    <p>Generate a matchup first to see live odds comparison</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Calculators Tab */}
          <TabsContent value="calculators" className="space-y-6 mt-6">
            <AdvancedCalculators />
          </TabsContent>

          {/* Bankroll Tab */}
          <TabsContent value="bankroll" className="space-y-6 mt-6">
            <BankrollTracker />
          </TabsContent>

          {/* AI Assistant Tab */}
          <TabsContent value="ai" className="space-y-6 mt-6">
            <AIAssistant />
          </TabsContent>

          {/* Advanced Features Tab */}
          <TabsContent value="advanced" className="space-y-6 mt-6">
            <AdvancedFeaturesTab sport={sport || undefined} />
          </TabsContent>
        </Tabs>

        {/* Footer */}
        <div className="text-center space-y-2 pt-8">
          <Separator className="bg-[#334155] mb-6" />
          <p className="text-xs text-gray-500">
            © 2024 Universal Matchup Predictor • Built on Base • Educational purposes only
          </p>
          <p className="text-xs text-gray-500">
            Must be 21+ to bet. Gambling problem? Call 1-800-GAMBLER
          </p>
        </div>
      </div>
    </div>
  );
}
