'use client'
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

type Message = {
  role: "user" | "assistant";
  content: string;
  timestamp: string;
};

export default function AIAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hey! I'm your AI betting assistant. I can help you analyze matchups, calculate odds, interpret betting trends, and answer questions about sports betting strategy. What would you like to know?",
      timestamp: new Date().toISOString()
    }
  ]);
  const [input, setInput] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage: Message = {
      role: "user",
      content: input,
      timestamp: new Date().toISOString()
    };

    setMessages([...messages, userMessage]);
    setInput("");
    setLoading(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = generateAIResponse(input);
      const assistantMessage: Message = {
        role: "assistant",
        content: aiResponse,
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, assistantMessage]);
      setLoading(false);
    }, 1500);
  };

  const generateAIResponse = (query: string): string => {
    const lowerQuery = query.toLowerCase();

    // Simple keyword-based responses (in production, this would use a real AI API)
    if (lowerQuery.includes("lakers") || lowerQuery.includes("celtics")) {
      return "Based on current power ratings and recent form, this looks like a competitive matchup. I'd suggest looking at the total rather than the spread - both teams have strong offenses but inconsistent defense lately. Check the public betting percentages to see where the sharp money is going.";
    }

    if (lowerQuery.includes("kelly") || lowerQuery.includes("bankroll")) {
      return "For bankroll management, I recommend using fractional Kelly (25-50% of full Kelly) to reduce variance. Never bet more than 2-3% of your bankroll on a single game, even if Kelly suggests more. Preservation of capital is key to long-term success.";
    }

    if (lowerQuery.includes("parlay")) {
      return "Parlays have higher variance and lower expected value than straight bets. The sportsbook edge compounds with each leg. If you do bet parlays, stick to 2-3 legs max and look for correlated outcomes. Single-game parlays can offer better value than traditional parlays.";
    }

    if (lowerQuery.includes("sharp") || lowerQuery.includes("public")) {
      return "Sharp money typically comes in late and moves lines despite lower bet counts. Look for games where the money percentage significantly exceeds the bet percentage - that's often sharp action. Fading the public can be profitable, but make sure you have your own solid reasoning too.";
    }

    if (lowerQuery.includes("value") || lowerQuery.includes("edge")) {
      return "Finding value means identifying spots where your probability assessment differs from the market's implied probability. Use the EV calculator to quantify your edge. I generally look for at least 3-5% edge before placing a bet, accounting for uncertainty in my model.";
    }

    if (lowerQuery.includes("live") || lowerQuery.includes("in-game")) {
      return "Live betting can offer great value if you're watching the game and can spot momentum shifts before the books adjust. Key moments: after turnovers, injuries, or when a team is about to get possession. Move quickly - lines adjust fast.";
    }

    if (lowerQuery.includes("weather")) {
      return "Weather significantly impacts outdoor sports. Wind over 15mph affects passing games and kicking. Rain reduces scoring. Cold weather (under 40°F) tends to favor the run game. Check totals - they often don't adjust enough for extreme weather.";
    }

    // Default response
    return "That's a great question! While I can provide general betting insights, remember that no prediction is guaranteed. I recommend: 1) Using multiple data points for analysis, 2) Managing your bankroll carefully with fractional Kelly, 3) Shopping lines across books, and 4) Tracking your bets to identify strengths and weaknesses. What specific matchup or concept would you like me to explain?";
  };

  const suggestedQuestions = [
    "What's the difference between sharp and public money?",
    "How should I use the Kelly Criterion?",
    "When is the best time to place a bet?",
    "How do I identify value bets?",
    "Should I bet parlays or straight bets?"
  ];

  return (
    <Card className="bg-[#0f172a] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-2xl text-white flex items-center space-x-2">
          <span>🤖</span>
          <span>AI Betting Assistant</span>
        </CardTitle>
        <CardDescription className="text-gray-400">
          Get AI-powered insights, strategy advice, and betting analysis
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Chat Messages */}
        <div className="bg-[#1e293b] rounded-lg border border-[#334155] p-4 space-y-4 max-h-[500px] overflow-y-auto">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-4 ${
                  message.role === "user"
                    ? "bg-[#22d3ee] text-black"
                    : "bg-[#334155] text-white"
                }`}
              >
                <div className="text-sm leading-relaxed">{message.content}</div>
                <div
                  className={`text-xs mt-2 ${
                    message.role === "user" ? "text-black/60" : "text-gray-400"
                  }`}
                >
                  {new Date(message.timestamp).toLocaleTimeString()}
                </div>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex justify-start">
              <div className="bg-[#334155] rounded-lg p-4">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Suggested Questions */}
        {messages.length === 1 && (
          <div className="space-y-2">
            <div className="text-sm text-gray-400">Suggested questions:</div>
            <div className="flex flex-wrap gap-2">
              {suggestedQuestions.map((question, index) => (
                <Badge
                  key={index}
                  variant="outline"
                  className="cursor-pointer hover:bg-[#22d3ee] hover:text-black hover:border-[#22d3ee] text-gray-300 border-[#334155]"
                  onClick={() => setInput(question)}
                >
                  {question}
                </Badge>
              ))}
            </div>
          </div>
        )}

        <Separator className="bg-[#334155]" />

        {/* Input Area */}
        <div className="space-y-3">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Ask me anything about sports betting, strategy, or analysis..."
            className="bg-[#1e293b] border-[#334155] text-white min-h-[100px]"
            disabled={loading}
          />

          <Button
            onClick={handleSend}
            disabled={!input.trim() || loading}
            className="w-full bg-[#22d3ee] hover:bg-[#06b6d4] text-black font-semibold"
          >
            {loading ? "Thinking..." : "Send Message"}
          </Button>
        </div>

        <div className="bg-[#334155] p-3 rounded-lg">
          <p className="text-xs text-gray-400">
            💡 <strong>AI Disclaimer:</strong> This AI assistant provides educational information only. 
            Always do your own research and bet responsibly.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
