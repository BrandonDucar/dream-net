'use client'
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  kellyStake,
  expectedValue,
  calculateParlay,
  calculateHedge,
  riskOfRuin
} from "@/lib/calculators";
import type { ParlayLeg } from "@/lib/extended-types";

export default function AdvancedCalculators() {
  // Kelly Calculator State
  const [kellyBankroll, setKellyBankroll] = useState<string>("1000");
  const [kellyOdds, setKellyOdds] = useState<string>("-110");
  const [kellyWinProb, setKellyWinProb] = useState<string>("55");
  const [kellyFraction, setKellyFraction] = useState<string>("0.25");

  // EV Calculator State
  const [evStake, setEvStake] = useState<string>("100");
  const [evOdds, setEvOdds] = useState<string>("+150");
  const [evWinProb, setEvWinProb] = useState<string>("45");

  // Parlay Calculator State
  const [parlayLegs, setParlayLegs] = useState<ParlayLeg[]>([
    { matchup: "", betType: "", odds: -110, stake: 100 }
  ]);

  // Hedge Calculator State
  const [hedgeOriginalStake, setHedgeOriginalStake] = useState<string>("100");
  const [hedgeOriginalOdds, setHedgeOriginalOdds] = useState<string>("+300");
  const [hedgeCurrentOdds, setHedgeCurrentOdds] = useState<string>("-150");
  const [hedgeGuarantee, setHedgeGuarantee] = useState<boolean>(true);

  // Risk of Ruin State
  const [rorWinRate, setRorWinRate] = useState<string>("52");
  const [rorAvgOdds, setRorAvgOdds] = useState<string>("-110");
  const [rorUnits, setRorUnits] = useState<string>("50");

  const handleAddParlayLeg = () => {
    setParlayLegs([...parlayLegs, { matchup: "", betType: "", odds: -110, stake: 100 }]);
  };

  const handleRemoveParlayLeg = (index: number) => {
    setParlayLegs(parlayLegs.filter((_, i) => i !== index));
  };

  const handleParlayLegChange = (index: number, field: keyof ParlayLeg, value: string | number) => {
    const updated = [...parlayLegs];
    if (field === 'odds' || field === 'stake') {
      updated[index][field] = typeof value === 'string' ? parseFloat(value) : value;
    } else {
      updated[index][field] = value as string;
    }
    setParlayLegs(updated);
  };

  const kellyResult = kellyStake(
    parseFloat(kellyBankroll) || 0,
    parseFloat(kellyOdds) || 0,
    parseFloat(kellyWinProb) || 0,
    parseFloat(kellyFraction) || 1
  );

  const evResult = expectedValue(
    parseFloat(evStake) || 0,
    parseFloat(evOdds) || 0,
    parseFloat(evWinProb) || 0
  );

  const parlayResult = parlayLegs.length > 0 && parlayLegs.every(leg => leg.odds && leg.stake)
    ? calculateParlay(parlayLegs)
    : null;

  const hedgeResult = calculateHedge(
    parseFloat(hedgeOriginalStake) || 0,
    parseFloat(hedgeOriginalOdds) || 0,
    parseFloat(hedgeCurrentOdds) || 0,
    hedgeGuarantee
  );

  const rorResult = riskOfRuin(
    parseFloat(rorWinRate) || 0,
    parseFloat(rorAvgOdds) || 0,
    parseFloat(rorUnits) || 0
  );

  return (
    <Tabs defaultValue="kelly" className="w-full">
      <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 bg-[#1e293b] border border-[#334155]">
        <TabsTrigger value="kelly" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
          Kelly
        </TabsTrigger>
        <TabsTrigger value="ev" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
          EV
        </TabsTrigger>
        <TabsTrigger value="parlay" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
          Parlay
        </TabsTrigger>
        <TabsTrigger value="hedge" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
          Hedge
        </TabsTrigger>
        <TabsTrigger value="ror" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
          Risk
        </TabsTrigger>
      </TabsList>

      {/* Kelly Criterion */}
      <TabsContent value="kelly">
        <Card className="bg-[#0f172a] border-[#1e293b]">
          <CardHeader>
            <CardTitle className="text-xl text-white">Kelly Criterion Calculator</CardTitle>
            <CardDescription className="text-gray-400">
              Calculate optimal bet size based on your edge
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-white">Bankroll ($)</Label>
                <Input
                  type="number"
                  value={kellyBankroll}
                  onChange={(e) => setKellyBankroll(e.target.value)}
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-white">Odds (American)</Label>
                <Input
                  type="number"
                  value={kellyOdds}
                  onChange={(e) => setKellyOdds(e.target.value)}
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-white">Win Probability (%)</Label>
                <Input
                  type="number"
                  value={kellyWinProb}
                  onChange={(e) => setKellyWinProb(e.target.value)}
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-white">Kelly Fraction (0.25 recommended)</Label>
                <Input
                  type="number"
                  step="0.05"
                  value={kellyFraction}
                  onChange={(e) => setKellyFraction(e.target.value)}
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>
            </div>

            <Separator className="bg-[#334155]" />

            <div className="space-y-4">
              <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
                <div className="text-gray-400 text-sm mb-2">Recommended Bet Size</div>
                <div className="text-4xl font-bold text-[#22d3ee]">
                  ${kellyResult.fractionalKelly.toFixed(2)}
                </div>
                <div className="text-sm text-gray-400 mt-1">
                  {kellyResult.percentage.toFixed(2)}% of bankroll
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                  <div className="text-gray-400 text-sm mb-1">Full Kelly</div>
                  <div className="text-2xl font-bold text-white">
                    ${kellyResult.fullKelly.toFixed(2)}
                  </div>
                  <div className="text-xs text-[#f87171] mt-1">
                    ⚠️ High variance
                  </div>
                </div>

                <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                  <div className="text-gray-400 text-sm mb-1">Fractional Kelly</div>
                  <div className="text-2xl font-bold text-[#22c55e]">
                    ${kellyResult.fractionalKelly.toFixed(2)}
                  </div>
                  <div className="text-xs text-[#22c55e] mt-1">
                    ✓ Safer approach
                  </div>
                </div>
              </div>

              <div className="bg-[#334155] p-3 rounded-lg">
                <p className="text-xs text-gray-400">
                  <strong>Note:</strong> Full Kelly maximizes growth but has high variance. 
                  Fractional Kelly (25-50%) is recommended for bankroll preservation.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      {/* Expected Value */}
      <TabsContent value="ev">
        <Card className="bg-[#0f172a] border-[#1e293b]">
          <CardHeader>
            <CardTitle className="text-xl text-white">Expected Value (EV) Calculator</CardTitle>
            <CardDescription className="text-gray-400">
              Calculate if a bet has positive expected value
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="text-white">Stake ($)</Label>
                <Input
                  type="number"
                  value={evStake}
                  onChange={(e) => setEvStake(e.target.value)}
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-white">Odds (American)</Label>
                <Input
                  type="number"
                  value={evOdds}
                  onChange={(e) => setEvOdds(e.target.value)}
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-white">True Win Probability (%)</Label>
                <Input
                  type="number"
                  value={evWinProb}
                  onChange={(e) => setEvWinProb(e.target.value)}
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>
            </div>

            <Separator className="bg-[#334155]" />

            <div className="space-y-4">
              <div className={`p-6 rounded-lg border-2 ${evResult.isPositiveEV ? 'bg-[#22c55e]/10 border-[#22c55e]' : 'bg-[#f87171]/10 border-[#f87171]'}`}>
                <div className="flex items-center justify-between mb-4">
                  <div className="text-gray-400 text-sm">Expected Value</div>
                  <Badge
                    variant="outline"
                    className={evResult.isPositiveEV ? 'bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]' : 'bg-[#f87171]/20 text-[#f87171] border-[#f87171]'}
                  >
                    {evResult.isPositiveEV ? 'Positive EV' : 'Negative EV'}
                  </Badge>
                </div>
                <div className={`text-4xl font-bold ${evResult.isPositiveEV ? 'text-[#22c55e]' : 'text-[#f87171]'}`}>
                  {evResult.ev >= 0 ? '+' : ''}${evResult.ev.toFixed(2)}
                </div>
                <div className="text-sm text-gray-400 mt-1">
                  {evResult.evPercentage >= 0 ? '+' : ''}{evResult.evPercentage.toFixed(2)}% return
                </div>
              </div>

              <div className="bg-[#334155] p-3 rounded-lg">
                <p className="text-xs text-gray-400">
                  <strong>EV Formula:</strong> (Win Probability × Win Amount) - (Loss Probability × Loss Amount)
                  <br />
                  Only bet when EV is positive and you have an edge over the market.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      {/* Parlay Calculator */}
      <TabsContent value="parlay">
        <Card className="bg-[#0f172a] border-[#1e293b]">
          <CardHeader>
            <CardTitle className="text-xl text-white">Parlay Calculator</CardTitle>
            <CardDescription className="text-gray-400">
              Calculate combined odds and potential payout for parlays
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {parlayLegs.map((leg, index) => (
              <div key={index} className="bg-[#1e293b] p-4 rounded-lg border border-[#334155] space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-white font-semibold">Leg {index + 1}</span>
                  {parlayLegs.length > 1 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveParlayLeg(index)}
                      className="text-[#f87171] hover:text-[#dc2626]"
                    >
                      Remove
                    </Button>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-white">Matchup</Label>
                    <Input
                      value={leg.matchup}
                      onChange={(e) => handleParlayLegChange(index, 'matchup', e.target.value)}
                      placeholder="Lakers vs Celtics"
                      className="bg-[#0f172a] border-[#334155] text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-white">Odds</Label>
                    <Input
                      type="number"
                      value={leg.odds}
                      onChange={(e) => handleParlayLegChange(index, 'odds', e.target.value)}
                      className="bg-[#0f172a] border-[#334155] text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-white">Stake ($)</Label>
                    <Input
                      type="number"
                      value={leg.stake}
                      onChange={(e) => handleParlayLegChange(index, 'stake', e.target.value)}
                      className="bg-[#0f172a] border-[#334155] text-white"
                    />
                  </div>
                </div>
              </div>
            ))}

            <Button
              onClick={handleAddParlayLeg}
              variant="outline"
              className="w-full border-[#22d3ee] text-[#22d3ee] hover:bg-[#22d3ee] hover:text-black"
            >
              + Add Another Leg
            </Button>

            {parlayResult && (
              <>
                <Separator className="bg-[#334155]" />

                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
                      <div className="text-gray-400 text-sm mb-2">Total Odds</div>
                      <div className="text-3xl font-bold text-[#22d3ee]">
                        {parlayResult.totalOddsAmerican > 0 ? '+' : ''}{parlayResult.totalOddsAmerican}
                      </div>
                      <div className="text-sm text-gray-400 mt-1">
                        Decimal: {parlayResult.totalOdds.toFixed(2)}
                      </div>
                    </div>

                    <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
                      <div className="text-gray-400 text-sm mb-2">Win Probability</div>
                      <div className="text-3xl font-bold text-[#fbbf24]">
                        {parlayResult.impliedProbability.toFixed(1)}%
                      </div>
                    </div>
                  </div>

                  <div className="bg-[#22c55e]/10 p-6 rounded-lg border-2 border-[#22c55e]">
                    <div className="text-gray-400 text-sm mb-2">Potential Payout</div>
                    <div className="text-4xl font-bold text-[#22c55e]">
                      ${parlayResult.potentialPayout.toFixed(2)}
                    </div>
                    <div className="text-sm text-gray-300 mt-1">
                      Profit: ${parlayResult.potentialProfit.toFixed(2)} on ${parlayResult.totalStake} stake
                    </div>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      {/* Hedge Calculator */}
      <TabsContent value="hedge">
        <Card className="bg-[#0f172a] border-[#1e293b]">
          <CardHeader>
            <CardTitle className="text-xl text-white">Hedge Calculator</CardTitle>
            <CardDescription className="text-gray-400">
              Calculate hedge bet to guarantee profit or minimize loss
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="text-white">Original Stake ($)</Label>
                <Input
                  type="number"
                  value={hedgeOriginalStake}
                  onChange={(e) => setHedgeOriginalStake(e.target.value)}
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-white">Original Odds</Label>
                <Input
                  type="number"
                  value={hedgeOriginalOdds}
                  onChange={(e) => setHedgeOriginalOdds(e.target.value)}
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-white">Current Hedge Odds</Label>
                <Input
                  type="number"
                  value={hedgeCurrentOdds}
                  onChange={(e) => setHedgeCurrentOdds(e.target.value)}
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>
            </div>

            <Separator className="bg-[#334155]" />

            <div className="space-y-4">
              <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
                <div className="text-gray-400 text-sm mb-2">Hedge Bet Size</div>
                <div className="text-4xl font-bold text-[#22d3ee]">
                  ${hedgeResult.hedgeStake.toFixed(2)}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                  <div className="text-gray-400 text-sm mb-2">{hedgeResult.scenarioA.outcome}</div>
                  <div className={`text-2xl font-bold ${hedgeResult.scenarioA.profit >= 0 ? 'text-[#22c55e]' : 'text-[#f87171]'}`}>
                    {hedgeResult.scenarioA.profit >= 0 ? '+' : ''}${hedgeResult.scenarioA.profit.toFixed(2)}
                  </div>
                </div>

                <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                  <div className="text-gray-400 text-sm mb-2">{hedgeResult.scenarioB.outcome}</div>
                  <div className={`text-2xl font-bold ${hedgeResult.scenarioB.profit >= 0 ? 'text-[#22c55e]' : 'text-[#f87171]'}`}>
                    {hedgeResult.scenarioB.profit >= 0 ? '+' : ''}${hedgeResult.scenarioB.profit.toFixed(2)}
                  </div>
                </div>
              </div>

              {hedgeResult.guaranteedProfit !== null && (
                <div className="bg-[#22c55e]/10 p-4 rounded-lg border-2 border-[#22c55e]">
                  <div className="text-gray-400 text-sm mb-1">Guaranteed Profit</div>
                  <div className="text-3xl font-bold text-[#22c55e]">
                    ${hedgeResult.guaranteedProfit.toFixed(2)}
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      {/* Risk of Ruin */}
      <TabsContent value="ror">
        <Card className="bg-[#0f172a] border-[#1e293b]">
          <CardHeader>
            <CardTitle className="text-xl text-white">Risk of Ruin Calculator</CardTitle>
            <CardDescription className="text-gray-400">
              Calculate probability of losing your entire bankroll
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="text-white">Win Rate (%)</Label>
                <Input
                  type="number"
                  value={rorWinRate}
                  onChange={(e) => setRorWinRate(e.target.value)}
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-white">Average Odds</Label>
                <Input
                  type="number"
                  value={rorAvgOdds}
                  onChange={(e) => setRorAvgOdds(e.target.value)}
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-white">Bankroll (units)</Label>
                <Input
                  type="number"
                  value={rorUnits}
                  onChange={(e) => setRorUnits(e.target.value)}
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>
            </div>

            <Separator className="bg-[#334155]" />

            <div className={`p-6 rounded-lg border-2 ${rorResult < 5 ? 'bg-[#22c55e]/10 border-[#22c55e]' : rorResult < 20 ? 'bg-[#fbbf24]/10 border-[#fbbf24]' : 'bg-[#f87171]/10 border-[#f87171]'}`}>
              <div className="text-gray-400 text-sm mb-2">Risk of Ruin</div>
              <div className={`text-5xl font-bold ${rorResult < 5 ? 'text-[#22c55e]' : rorResult < 20 ? 'text-[#fbbf24]' : 'text-[#f87171]'}`}>
                {rorResult.toFixed(2)}%
              </div>
              <div className="mt-4">
                <Badge
                  variant="outline"
                  className={
                    rorResult < 5
                      ? 'bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]'
                      : rorResult < 20
                      ? 'bg-[#fbbf24]/20 text-[#fbbf24] border-[#fbbf24]'
                      : 'bg-[#f87171]/20 text-[#f87171] border-[#f87171]'
                  }
                >
                  {rorResult < 5 ? 'Low Risk' : rorResult < 20 ? 'Moderate Risk' : 'High Risk'}
                </Badge>
              </div>
            </div>

            <div className="bg-[#334155] p-3 rounded-lg">
              <p className="text-xs text-gray-400">
                <strong>Risk of Ruin</strong> is the probability you'll lose your entire bankroll.
                Lower is better. Increase bankroll size or improve win rate to reduce risk.
              </p>
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
}
