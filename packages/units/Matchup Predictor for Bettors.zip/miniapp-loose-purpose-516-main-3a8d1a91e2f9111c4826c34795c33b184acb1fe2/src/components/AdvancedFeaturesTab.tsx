'use client'
import { useState } from "react";
import type { SportCode } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { generateMockAlerts, type Alert } from "@/lib/alerts";
import { scanArbitrageOpportunities, getArbitrageSummary, getArbitrageInstructions } from "@/lib/arbitrage";
import { getLeaderboard } from "@/lib/community";
import { Download, Bell, Target, Trophy } from "lucide-react";
import { exportDataSet } from "@/lib/export";

type Props = {
  sport?: SportCode;
};

export default function AdvancedFeaturesTab({ sport }: Props) {
  const [activeTab, setActiveTab] = useState<string>("alerts");
  const [alerts] = useState<Alert[]>(generateMockAlerts(sport || "NFL"));
  const [arbitrage] = useState(scanArbitrageOpportunities(sport));
  const [leaderboard] = useState(getLeaderboard(10));

  const arbSummary = getArbitrageSummary(arbitrage);
  const unreadAlerts = alerts.filter((a) => !a.isRead);

  const handleExportArbitrage = () => {
    exportDataSet("arbitrage", arbitrage);
  };

  const handleExportLeaderboard = () => {
    exportDataSet("leaderboard", leaderboard);
  };

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3 bg-[#1e293b] border border-[#334155]">
          <TabsTrigger value="alerts" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
            <Bell className="w-4 h-4 mr-2" />
            Alerts
            {unreadAlerts.length > 0 && (
              <Badge className="ml-2 bg-[#f87171]">{unreadAlerts.length}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="arbitrage" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
            <Target className="w-4 h-4 mr-2" />
            Arbitrage
          </TabsTrigger>
          <TabsTrigger value="leaderboard" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
            <Trophy className="w-4 h-4 mr-2" />
            Leaderboard
          </TabsTrigger>
        </TabsList>

        <TabsContent value="alerts" className="space-y-4 mt-4">
          <Card className="bg-[#0f172a] border-[#1e293b]">
            <CardHeader>
              <CardTitle className="text-white">Live Alerts & Notifications</CardTitle>
              <CardDescription className="text-gray-400">
                Real-time updates on line movements, injuries, and opportunities
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {alerts.map((alert) => (
                  <div
                    key={alert.id}
                    className={`bg-[#1e293b] p-4 rounded-lg border ${
                      !alert.isRead ? "border-[#22d3ee]" : "border-[#334155]"
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center">
                        <Badge
                          variant="outline"
                          className={
                            alert.severity === "High"
                              ? "bg-[#f87171]/20 text-[#f87171] border-[#f87171]"
                              : alert.severity === "Medium"
                              ? "bg-[#fbbf24]/20 text-[#fbbf24] border-[#fbbf24]"
                              : "bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]"
                          }
                        >
                          {alert.severity}
                        </Badge>
                        <span className="text-xs text-gray-400 ml-2">
                          {alert.timestamp.toLocaleTimeString()}
                        </span>
                      </div>
                      {!alert.isRead && (
                        <Badge className="bg-[#22d3ee] text-black">New</Badge>
                      )}
                    </div>
                    <p className="text-white text-sm">{alert.message}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="arbitrage" className="space-y-4 mt-4">
          <Card className="bg-[#0f172a] border-[#1e293b]">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-white">Arbitrage Scanner</CardTitle>
                <CardDescription className="text-gray-400">
                  Risk-free betting opportunities across multiple sportsbooks
                </CardDescription>
              </div>
              <Button
                onClick={handleExportArbitrage}
                variant="outline"
                size="sm"
                className="bg-[#1e293b] border-[#334155] text-white hover:bg-[#334155]"
              >
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                  <div className="text-gray-400 text-sm">Total Opportunities</div>
                  <div className="text-2xl font-bold text-white">{arbSummary.totalOpportunities}</div>
                </div>
                <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                  <div className="text-gray-400 text-sm">Avg Profit</div>
                  <div className="text-2xl font-bold text-[#22c55e]">{arbSummary.averageProfit}%</div>
                </div>
                <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                  <div className="text-gray-400 text-sm">Low Risk</div>
                  <div className="text-2xl font-bold text-[#22d3ee]">{arbSummary.lowRiskCount}</div>
                </div>
                <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                  <div className="text-gray-400 text-sm">Best Profit</div>
                  <div className="text-2xl font-bold text-[#22c55e]">
                    {arbSummary.bestOpportunity?.profitMargin.toFixed(2) || "0"}%
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                {arbitrage.map((opp) => (
                  <div key={opp.id} className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-semibold text-white">
                          {opp.teamA} vs {opp.teamB}
                        </h3>
                        <p className="text-sm text-gray-400">
                          {opp.sport} • {opp.betType}
                        </p>
                      </div>
                      <Badge
                        variant="outline"
                        className={
                          opp.riskLevel === "Low"
                            ? "bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]"
                            : opp.riskLevel === "Medium"
                            ? "bg-[#fbbf24]/20 text-[#fbbf24] border-[#fbbf24]"
                            : "bg-[#f87171]/20 text-[#f87171] border-[#f87171]"
                        }
                      >
                        {opp.riskLevel} Risk
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="bg-[#0f172a] p-3 rounded border border-[#334155]">
                        <div className="text-gray-400 text-xs mb-1">{opp.bookA.name}</div>
                        <div className="text-white font-semibold">Odds: {opp.bookA.odds}</div>
                        <div className="text-[#22d3ee] text-sm">Stake: ${opp.stakeA}</div>
                      </div>

                      <div className="bg-[#0f172a] p-3 rounded border border-[#334155]">
                        <div className="text-gray-400 text-xs mb-1">{opp.bookB.name}</div>
                        <div className="text-white font-semibold">Odds: {opp.bookB.odds}</div>
                        <div className="text-[#22d3ee] text-sm">Stake: ${opp.stakeB}</div>
                      </div>
                    </div>

                    <div className="bg-[#22c55e]/10 p-3 rounded-lg border border-[#22c55e] mb-3">
                      <div className="flex justify-between items-center">
                        <span className="text-[#22c55e] font-semibold">Guaranteed Profit:</span>
                        <span className="text-[#22c55e] text-xl font-bold">
                          ${opp.guaranteedProfit.toFixed(2)} ({opp.profitMargin.toFixed(2)}%)
                        </span>
                      </div>
                    </div>

                    <div className="text-xs text-gray-400">
                      Expires in: {opp.expiresIn} minutes
                    </div>
                  </div>
                ))}

                {arbitrage.length === 0 && (
                  <div className="bg-[#1e293b] p-12 rounded-lg border border-[#334155] text-center">
                    <Target className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-400">No arbitrage opportunities found at this time</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="leaderboard" className="space-y-4 mt-4">
          <Card className="bg-[#0f172a] border-[#1e293b]">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-white">Community Leaderboard</CardTitle>
                <CardDescription className="text-gray-400">
                  Top performers ranked by ROI and win rate
                </CardDescription>
              </div>
              <Button
                onClick={handleExportLeaderboard}
                variant="outline"
                size="sm"
                className="bg-[#1e293b] border-[#334155] text-white hover:bg-[#334155]"
              >
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {leaderboard.map((entry, idx) => (
                  <div
                    key={entry.user.userId}
                    className={`bg-[#1e293b] p-4 rounded-lg border ${
                      idx < 3 ? "border-[#22d3ee]" : "border-[#334155]"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="text-2xl font-bold text-[#22d3ee]">#{entry.position}</div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="text-white font-semibold">{entry.user.username}</span>
                            {entry.user.verified && (
                              <Badge variant="outline" className="text-xs bg-[#22d3ee]/20 text-[#22d3ee] border-[#22d3ee]">
                                ✓
                              </Badge>
                            )}
                            {entry.user.isPro && (
                              <Badge variant="outline" className="text-xs bg-[#fbbf24]/20 text-[#fbbf24] border-[#fbbf24]">
                                PRO
                              </Badge>
                            )}
                          </div>
                          <div className="text-sm text-gray-400">
                            {entry.wins}-{entry.losses}-{entry.pushes} • Best: {entry.bestSport}
                          </div>
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-xl font-bold text-[#22c55e]">{entry.roi.toFixed(1)}% ROI</div>
                        <div className="text-sm text-gray-400">
                          {entry.winRate.toFixed(1)}% Win Rate
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
