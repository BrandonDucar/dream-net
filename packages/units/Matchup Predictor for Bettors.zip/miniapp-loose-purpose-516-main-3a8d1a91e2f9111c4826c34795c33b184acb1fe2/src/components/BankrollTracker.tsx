'use client'
import { useState } from "react";
import type { BettingRecord, BankrollStats } from "@/lib/extended-types";
import { calculateBankrollStats } from "@/lib/calculators";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function BankrollTracker() {
  const [startingBalance, setStartingBalance] = useState<number>(1000);
  const [records, setRecords] = useState<BettingRecord[]>([]);
  const [showAddForm, setShowAddForm] = useState<boolean>(false);

  // Form state
  const [formSport, setFormSport] = useState<string>("");
  const [formMatchup, setFormMatchup] = useState<string>("");
  const [formBetType, setFormBetType] = useState<"moneyline" | "spread" | "total" | "parlay">("moneyline");
  const [formStake, setFormStake] = useState<string>("");
  const [formOdds, setFormOdds] = useState<string>("");
  const [formResult, setFormResult] = useState<"win" | "loss" | "push" | "pending">("pending");
  const [formNotes, setFormNotes] = useState<string>("");

  const stats = calculateBankrollStats(records, startingBalance);

  const handleAddRecord = () => {
    if (!formMatchup || !formStake || !formOdds) return;

    const stake = parseFloat(formStake);
    const odds = parseFloat(formOdds);
    
    let profit = 0;
    if (formResult === "win") {
      const decimal = odds > 0 ? (odds / 100) + 1 : (100 / Math.abs(odds)) + 1;
      profit = stake * (decimal - 1);
    } else if (formResult === "loss") {
      profit = -stake;
    }

    const newRecord: BettingRecord = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      sport: formSport,
      matchup: formMatchup,
      betType: formBetType,
      stake,
      odds,
      result: formResult,
      profit,
      notes: formNotes
    };

    setRecords([newRecord, ...records]);
    
    // Reset form
    setFormSport("");
    setFormMatchup("");
    setFormStake("");
    setFormOdds("");
    setFormResult("pending");
    setFormNotes("");
    setShowAddForm(false);
  };

  const handleDeleteRecord = (id: string) => {
    setRecords(records.filter(r => r.id !== id));
  };

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <Card className="bg-[#0f172a] border-[#1e293b]">
        <CardHeader>
          <CardTitle className="text-2xl text-white">Bankroll Statistics</CardTitle>
          <CardDescription className="text-gray-400">
            Track your betting performance and manage your bankroll
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Balance & Starting */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
              <div className="text-gray-400 text-sm mb-1">Current Balance</div>
              <div className={`text-3xl font-bold ${stats.totalProfit >= 0 ? 'text-[#22c55e]' : 'text-[#f87171]'}`}>
                ${stats.currentBalance.toFixed(2)}
              </div>
            </div>

            <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
              <div className="text-gray-400 text-sm mb-1">Total Profit/Loss</div>
              <div className={`text-3xl font-bold ${stats.totalProfit >= 0 ? 'text-[#22c55e]' : 'text-[#f87171]'}`}>
                {stats.totalProfit >= 0 ? '+' : ''}{stats.totalProfit.toFixed(2)}
              </div>
            </div>

            <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
              <div className="text-gray-400 text-sm mb-1">ROI</div>
              <div className={`text-3xl font-bold ${stats.roi >= 0 ? 'text-[#22c55e]' : 'text-[#f87171]'}`}>
                {stats.roi >= 0 ? '+' : ''}{stats.roi.toFixed(1)}%
              </div>
            </div>
          </div>

          {/* Win Rate & Record */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
              <div className="text-gray-400 text-xs mb-1">Win Rate</div>
              <div className="text-xl font-bold text-[#22d3ee]">
                {stats.winRate.toFixed(1)}%
              </div>
            </div>

            <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
              <div className="text-gray-400 text-xs mb-1">Wins</div>
              <div className="text-xl font-bold text-[#22c55e]">{stats.wins}</div>
            </div>

            <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
              <div className="text-gray-400 text-xs mb-1">Losses</div>
              <div className="text-xl font-bold text-[#f87171]">{stats.losses}</div>
            </div>

            <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
              <div className="text-gray-400 text-xs mb-1">Pushes</div>
              <div className="text-xl font-bold text-gray-400">{stats.pushes}</div>
            </div>

            <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
              <div className="text-gray-400 text-xs mb-1">Streak</div>
              <Badge variant="outline" className={stats.streak.type === 'win' ? 'bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]' : 'bg-[#f87171]/20 text-[#f87171] border-[#f87171]'}>
                {stats.streak.type === 'win' ? 'W' : 'L'}{stats.streak.count}
              </Badge>
            </div>
          </div>

          {/* Starting Balance Input */}
          <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
            <Label htmlFor="starting-balance" className="text-white text-sm mb-2 block">
              Starting Bankroll
            </Label>
            <Input
              id="starting-balance"
              type="number"
              value={startingBalance}
              onChange={(e) => setStartingBalance(parseFloat(e.target.value) || 0)}
              className="bg-[#0f172a] border-[#334155] text-white w-48"
            />
          </div>
        </CardContent>
      </Card>

      {/* Add Bet Button */}
      <Button
        onClick={() => setShowAddForm(!showAddForm)}
        className="w-full bg-[#22d3ee] hover:bg-[#06b6d4] text-black font-semibold py-6"
      >
        {showAddForm ? "Cancel" : "Add New Bet"}
      </Button>

      {/* Add Bet Form */}
      {showAddForm && (
        <Card className="bg-[#0f172a] border-[#1e293b]">
          <CardHeader>
            <CardTitle className="text-xl text-white">Add New Bet</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="sport" className="text-white">Sport</Label>
                <Input
                  id="sport"
                  value={formSport}
                  onChange={(e) => setFormSport(e.target.value)}
                  placeholder="NBA, NFL, etc."
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="matchup" className="text-white">Matchup *</Label>
                <Input
                  id="matchup"
                  value={formMatchup}
                  onChange={(e) => setFormMatchup(e.target.value)}
                  placeholder="Lakers vs Celtics"
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bet-type" className="text-white">Bet Type</Label>
                <Select value={formBetType} onValueChange={(v) => setFormBetType(v as typeof formBetType)}>
                  <SelectTrigger className="bg-[#1e293b] border-[#334155] text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1e293b] border-[#334155]">
                    <SelectItem value="moneyline" className="text-white">Moneyline</SelectItem>
                    <SelectItem value="spread" className="text-white">Spread</SelectItem>
                    <SelectItem value="total" className="text-white">Total</SelectItem>
                    <SelectItem value="parlay" className="text-white">Parlay</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="stake" className="text-white">Stake ($) *</Label>
                <Input
                  id="stake"
                  type="number"
                  value={formStake}
                  onChange={(e) => setFormStake(e.target.value)}
                  placeholder="100"
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="odds" className="text-white">Odds (American) *</Label>
                <Input
                  id="odds"
                  type="number"
                  value={formOdds}
                  onChange={(e) => setFormOdds(e.target.value)}
                  placeholder="-110"
                  className="bg-[#1e293b] border-[#334155] text-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="result" className="text-white">Result</Label>
                <Select value={formResult} onValueChange={(v) => setFormResult(v as typeof formResult)}>
                  <SelectTrigger className="bg-[#1e293b] border-[#334155] text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1e293b] border-[#334155]">
                    <SelectItem value="pending" className="text-white">Pending</SelectItem>
                    <SelectItem value="win" className="text-white">Win</SelectItem>
                    <SelectItem value="loss" className="text-white">Loss</SelectItem>
                    <SelectItem value="push" className="text-white">Push</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes" className="text-white">Notes</Label>
              <Textarea
                id="notes"
                value={formNotes}
                onChange={(e) => setFormNotes(e.target.value)}
                placeholder="Optional notes about this bet..."
                className="bg-[#1e293b] border-[#334155] text-white"
              />
            </div>

            <Button
              onClick={handleAddRecord}
              disabled={!formMatchup || !formStake || !formOdds}
              className="w-full bg-[#22c55e] hover:bg-[#16a34a] text-black font-semibold"
            >
              Add Bet
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Betting History */}
      {records.length > 0 && (
        <Card className="bg-[#0f172a] border-[#1e293b]">
          <CardHeader>
            <CardTitle className="text-xl text-white">Betting History</CardTitle>
            <CardDescription className="text-gray-400">
              {records.length} total bet{records.length !== 1 ? 's' : ''}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-[#334155]">
                    <TableHead className="text-gray-400">Date</TableHead>
                    <TableHead className="text-gray-400">Matchup</TableHead>
                    <TableHead className="text-gray-400">Type</TableHead>
                    <TableHead className="text-gray-400">Stake</TableHead>
                    <TableHead className="text-gray-400">Odds</TableHead>
                    <TableHead className="text-gray-400">Result</TableHead>
                    <TableHead className="text-gray-400">Profit</TableHead>
                    <TableHead className="text-gray-400"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {records.map((record) => (
                    <TableRow key={record.id} className="border-[#334155]">
                      <TableCell className="text-gray-300 text-sm">
                        {new Date(record.date).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-white font-medium">{record.matchup}</TableCell>
                      <TableCell className="text-gray-300 text-sm capitalize">{record.betType}</TableCell>
                      <TableCell className="text-gray-300">${record.stake}</TableCell>
                      <TableCell className="text-gray-300">
                        {record.odds > 0 ? `+${record.odds}` : record.odds}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            record.result === "win"
                              ? "bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]"
                              : record.result === "loss"
                              ? "bg-[#f87171]/20 text-[#f87171] border-[#f87171]"
                              : record.result === "push"
                              ? "bg-gray-500/20 text-gray-400 border-gray-500"
                              : "bg-[#fbbf24]/20 text-[#fbbf24] border-[#fbbf24]"
                          }
                        >
                          {record.result}
                        </Badge>
                      </TableCell>
                      <TableCell className={`font-semibold ${record.profit >= 0 ? 'text-[#22c55e]' : 'text-[#f87171]'}`}>
                        {record.profit >= 0 ? '+' : ''}${record.profit.toFixed(2)}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteRecord(record.id)}
                          className="text-[#f87171] hover:text-[#dc2626] hover:bg-[#f87171]/10"
                        >
                          Delete
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
