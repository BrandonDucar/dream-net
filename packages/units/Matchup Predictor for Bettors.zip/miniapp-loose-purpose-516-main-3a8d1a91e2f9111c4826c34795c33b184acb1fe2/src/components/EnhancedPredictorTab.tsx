'use client'
import { useState } from "react";
import type { SportCode, MatchupResult } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getWeatherForGame, locationData } from "@/lib/weather";
import { getInjuryReport, compareTeamHealth, getInjuryImpactSummary } from "@/lib/injuries";
import { getHeadToHeadRecord, getHeadToHeadSummary } from "@/lib/historical";
import { getBettingTrends, getTrendSummary } from "@/lib/betting-trends";
import { AlertCircle, Cloud, Activity, History, TrendingUp } from "lucide-react";

type Props = {
  result: MatchupResult;
  sport: SportCode;
  teamAId: string;
  teamBId: string;
  neutralSite: boolean;
};

export default function EnhancedPredictorTab({ result, sport, teamAId, teamBId, neutralSite }: Props) {
  const [activeSubTab, setActiveSubTab] = useState<string>("weather");

  // Fetch enhanced data
  const weather = getWeatherForGame(sport, locationData[teamAId] || { city: "Unknown", state: "", isDome: false });
  const injuryA = getInjuryReport(teamAId, sport);
  const injuryB = getInjuryReport(teamBId, sport);
  const healthComparison = compareTeamHealth(injuryA, injuryB);
  const historical = getHeadToHeadRecord(teamAId, teamBId, sport);
  const trends = getBettingTrends(teamAId, teamBId, sport);

  return (
    <Card className="bg-[#0f172a] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-xl text-white">Advanced Analytics</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activeSubTab} onValueChange={setActiveSubTab}>
          <TabsList className="grid grid-cols-2 md:grid-cols-4 bg-[#1e293b] border border-[#334155]">
            <TabsTrigger value="weather" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
              <Cloud className="w-4 h-4 mr-2" />
              Weather
            </TabsTrigger>
            <TabsTrigger value="injuries" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
              <Activity className="w-4 h-4 mr-2" />
              Injuries
            </TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
              <History className="w-4 h-4 mr-2" />
              History
            </TabsTrigger>
            <TabsTrigger value="trends" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
              <TrendingUp className="w-4 h-4 mr-2" />
              Trends
            </TabsTrigger>
          </TabsList>

          <TabsContent value="weather" className="space-y-4 mt-4">
            <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white">Weather Conditions</h3>
                <Badge
                  variant="outline"
                  className={
                    weather.impact === "High" ? "bg-[#f87171]/20 text-[#f87171] border-[#f87171]" :
                    weather.impact === "Medium" ? "bg-[#fbbf24]/20 text-[#fbbf24] border-[#fbbf24]" :
                    "bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]"
                  }
                >
                  {weather.impact} Impact
                </Badge>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                <div>
                  <div className="text-gray-400 text-sm">Condition</div>
                  <div className="text-white font-semibold">{weather.condition}</div>
                </div>
                <div>
                  <div className="text-gray-400 text-sm">Temperature</div>
                  <div className="text-white font-semibold">{weather.temperature}°F</div>
                </div>
                <div>
                  <div className="text-gray-400 text-sm">Wind</div>
                  <div className="text-white font-semibold">{weather.windSpeed} mph</div>
                </div>
                <div>
                  <div className="text-gray-400 text-sm">Precipitation</div>
                  <div className="text-white font-semibold">{weather.precipitation}%</div>
                </div>
              </div>

              <div className="bg-[#0f172a] p-4 rounded-lg border border-[#334155]">
                <p className="text-sm text-gray-300 leading-relaxed">{weather.recommendation}</p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="injuries" className="space-y-4 mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-white">{result.teamAName}</h3>
                  <Badge variant="outline" className={
                    injuryA.overallHealthScore >= 85 ? "bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]" :
                    injuryA.overallHealthScore >= 70 ? "bg-[#fbbf24]/20 text-[#fbbf24] border-[#fbbf24]" :
                    "bg-[#f87171]/20 text-[#f87171] border-[#f87171]"
                  }>
                    Health: {injuryA.overallHealthScore}%
                  </Badge>
                </div>

                {injuryA.injuries.length === 0 ? (
                  <p className="text-gray-400 text-sm">No injury concerns</p>
                ) : (
                  <div className="space-y-2">
                    {injuryA.injuries.map((injury, idx) => (
                      <div key={idx} className="bg-[#0f172a] p-3 rounded border border-[#334155]">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-white font-medium">{injury.playerName}</span>
                          <Badge variant="outline" className="text-xs">{injury.status}</Badge>
                        </div>
                        <div className="text-sm text-gray-400">
                          {injury.position} • {injury.injuryType}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-white">{result.teamBName}</h3>
                  <Badge variant="outline" className={
                    injuryB.overallHealthScore >= 85 ? "bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]" :
                    injuryB.overallHealthScore >= 70 ? "bg-[#fbbf24]/20 text-[#fbbf24] border-[#fbbf24]" :
                    "bg-[#f87171]/20 text-[#f87171] border-[#f87171]"
                  }>
                    Health: {injuryB.overallHealthScore}%
                  </Badge>
                </div>

                {injuryB.injuries.length === 0 ? (
                  <p className="text-gray-400 text-sm">No injury concerns</p>
                ) : (
                  <div className="space-y-2">
                    {injuryB.injuries.map((injury, idx) => (
                      <div key={idx} className="bg-[#0f172a] p-3 rounded border border-[#334155]">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-white font-medium">{injury.playerName}</span>
                          <Badge variant="outline" className="text-xs">{injury.status}</Badge>
                        </div>
                        <div className="text-sm text-gray-400">
                          {injury.position} • {injury.injuryType}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
              <div className="flex items-center mb-2">
                <AlertCircle className="w-4 h-4 mr-2 text-[#22d3ee]" />
                <span className="text-white font-semibold">Health Comparison</span>
              </div>
              <p className="text-sm text-gray-300">{healthComparison}</p>
            </div>
          </TabsContent>

          <TabsContent value="history" className="space-y-4 mt-4">
            <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
              <h3 className="text-lg font-semibold text-white mb-4">Head-to-Head Record</h3>

              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-[#22c55e]">{historical.teamAWins}</div>
                  <div className="text-sm text-gray-400">{historical.teamAName} Wins</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-400">{historical.ties}</div>
                  <div className="text-sm text-gray-400">Ties</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-[#22c55e]">{historical.teamBWins}</div>
                  <div className="text-sm text-gray-400">{historical.teamBName} Wins</div>
                </div>
              </div>

              <div className="bg-[#0f172a] p-4 rounded-lg border border-[#334155] mb-4">
                <p className="text-sm text-gray-300">{getHeadToHeadSummary(historical)}</p>
              </div>

              <div>
                <h4 className="text-md font-semibold text-white mb-3">Last 5 Games</h4>
                <div className="space-y-2">
                  {historical.lastFiveGames.map((game, idx) => (
                    <div key={idx} className="bg-[#0f172a] p-3 rounded border border-[#334155] flex items-center justify-between">
                      <div>
                        <div className="text-white font-medium">
                          {game.teamAScore} - {game.teamBScore}
                        </div>
                        <div className="text-xs text-gray-400">{game.date.toLocaleDateString()}</div>
                      </div>
                      <Badge variant="outline" className="text-xs">{game.location}</Badge>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="trends" className="space-y-4 mt-4">
            <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
              <h3 className="text-lg font-semibold text-white mb-4">Betting Trends</h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div className="bg-[#0f172a] p-4 rounded-lg border border-[#334155]">
                  <h4 className="text-md font-semibold text-white mb-3">{trends.teamA.teamName}</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-400 text-sm">Public Betting</span>
                      <span className="text-white font-semibold">{trends.teamA.publicBettingPct}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400 text-sm">Sharp Money</span>
                      <span className="text-white font-semibold">{trends.teamA.sharpMoneyPct}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400 text-sm">Line Movement</span>
                      <span className={trends.teamA.lineMovement > 0 ? "text-[#22c55e] font-semibold" : "text-[#f87171] font-semibold"}>
                        {trends.teamA.lineMovement > 0 ? "+" : ""}{trends.teamA.lineMovement}
                      </span>
                    </div>
                    <Badge variant="outline" className="mt-2">{trends.teamA.consensusRating}</Badge>
                  </div>
                </div>

                <div className="bg-[#0f172a] p-4 rounded-lg border border-[#334155]">
                  <h4 className="text-md font-semibold text-white mb-3">{trends.teamB.teamName}</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-400 text-sm">Public Betting</span>
                      <span className="text-white font-semibold">{trends.teamB.publicBettingPct}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400 text-sm">Sharp Money</span>
                      <span className="text-white font-semibold">{trends.teamB.sharpMoneyPct}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400 text-sm">Line Movement</span>
                      <span className={trends.teamB.lineMovement > 0 ? "text-[#22c55e] font-semibold" : "text-[#f87171] font-semibold"}>
                        {trends.teamB.lineMovement > 0 ? "+" : ""}{trends.teamB.lineMovement}
                      </span>
                    </div>
                    <Badge variant="outline" className="mt-2">{trends.teamB.consensusRating}</Badge>
                  </div>
                </div>
              </div>

              <div className="bg-[#0f172a] p-4 rounded-lg border border-[#334155]">
                <div className="flex items-center mb-2">
                  <TrendingUp className="w-4 h-4 mr-2 text-[#22d3ee]" />
                  <span className="text-white font-semibold">Trend Summary</span>
                </div>
                <p className="text-sm text-gray-300">{getTrendSummary(trends)}</p>
              </div>

              {trends.disagreement && (
                <div className="bg-[#fbbf24]/10 p-4 rounded-lg border border-[#fbbf24]">
                  <div className="flex items-center mb-2">
                    <AlertCircle className="w-4 h-4 mr-2 text-[#fbbf24]" />
                    <span className="text-[#fbbf24] font-semibold">Sharp vs Public Disagreement</span>
                  </div>
                  <p className="text-sm text-gray-300">{trends.recommendation}</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
