'use client'
import { useState, useEffect } from "react";
import type { LocationData, Sportsbook } from "@/lib/extended-types";
import { detectUserLocation, getSportsbooksForState } from "@/lib/geofencing";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export default function GeofencingBanner() {
  const [location, setLocation] = useState<LocationData | null>(null);
  const [sportsbooks, setSportsbooks] = useState<Sportsbook[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [dismissed, setDismissed] = useState<boolean>(false);

  useEffect(() => {
    const fetchLocation = async () => {
      try {
        const loc = await detectUserLocation();
        setLocation(loc);
        
        if (loc.state && loc.isLegalBetting) {
          const books = getSportsbooksForState(loc.state);
          setSportsbooks(books);
        }
      } catch (error) {
        console.error("Failed to detect location:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchLocation();
  }, []);

  if (loading || dismissed || !location) {
    return null;
  }

  return (
    <Card className={`border-2 ${location.isLegalBetting ? 'bg-[#22c55e]/10 border-[#22c55e]' : 'bg-[#fbbf24]/10 border-[#fbbf24]'}`}>
      <CardContent className="py-4">
        <div className="flex items-start justify-between">
          <div className="flex-1 space-y-3">
            <div className="flex items-center space-x-3">
              <span className="text-2xl">{location.isLegalBetting ? "✅" : "⚠️"}</span>
              <div>
                <div className="font-semibold text-white">
                  {location.city}, {location.state}
                </div>
                <div className="text-sm text-gray-400">
                  {location.regulatoryNote}
                </div>
              </div>
            </div>

            {location.isLegalBetting && sportsbooks.length > 0 && (
              <div className="space-y-2">
                <div className="text-sm text-gray-400">Legal sportsbooks in your area:</div>
                <div className="flex flex-wrap gap-2">
                  {sportsbooks.slice(0, 5).map((book) => (
                    <a
                      key={book.id}
                      href={book.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="no-underline"
                    >
                      <Badge
                        variant="outline"
                        className="cursor-pointer hover:bg-[#22d3ee] hover:text-black hover:border-[#22d3ee] text-white border-[#334155]"
                      >
                        {book.logo} {book.name}
                      </Badge>
                    </a>
                  ))}
                </div>
                <div className="text-xs text-gray-400">
                  Click to view sign-up bonuses and promotions
                </div>
              </div>
            )}

            {!location.isLegalBetting && (
              <div className="bg-[#fbbf24]/20 p-3 rounded-lg border border-[#fbbf24]">
                <p className="text-sm text-gray-300">
                  Online sports betting is not currently available in your state. 
                  You can still use our analytics and tools for educational purposes.
                </p>
              </div>
            )}
          </div>

          <Button
            variant="ghost"
            size="sm"
            onClick={() => setDismissed(true)}
            className="text-gray-400 hover:text-white"
          >
            ✕
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
