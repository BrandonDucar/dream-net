'use client'
import { useState, useEffect } from "react";
import type { SportCode } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getLiveGameData, getLiveBettingSummary } from "@/lib/live-tracking";
import { Radio, Zap, Clock } from "lucide-react";

type Props = {
  teamAId: string;
  teamBId: string;
  sport: SportCode;
};

export default function LiveTrackingTab({ teamAId, teamBId, sport }: Props) {
  const [liveData, setLiveData] = useState(getLiveGameData(teamAId, teamBId, sport));
  const [autoRefresh, setAutoRefresh] = useState(true);

  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      setLiveData(getLiveGameData(teamAId, teamBId, sport));
    }, 5000); // Refresh every 5 seconds

    return () => clearInterval(interval);
  }, [autoRefresh, teamAId, teamBId, sport]);

  const handleManualRefresh = () => {
    setLiveData(getLiveGameData(teamAId, teamBId, sport));
  };

  return (
    <div className="space-y-6">
      <Card className="bg-[#0f172a] border-[#1e293b]">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white flex items-center">
                <Radio className="w-5 h-5 mr-2 text-[#f87171] animate-pulse" />
                Live Game Tracking
              </CardTitle>
              <CardDescription className="text-gray-400">
                Real-time scores and in-game betting suggestions
              </CardDescription>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleManualRefresh}
                className="bg-[#1e293b] border-[#334155] text-white hover:bg-[#334155]"
              >
                Refresh
              </Button>
              <Button
                variant={autoRefresh ? "default" : "outline"}
                size="sm"
                onClick={() => setAutoRefresh(!autoRefresh)}
                className={autoRefresh ? "bg-[#22c55e] text-black hover:bg-[#16a34a]" : "bg-[#1e293b] border-[#334155] text-white hover:bg-[#334155]"}
              >
                {autoRefresh ? "Auto: ON" : "Auto: OFF"}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Live Score */}
          <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
            <div className="flex items-center justify-between mb-4">
              <Badge variant="outline" className="bg-[#f87171]/20 text-[#f87171] border-[#f87171] animate-pulse">
                <Radio className="w-3 h-3 mr-1" />
                LIVE
              </Badge>
              <div className="flex items-center text-gray-400 text-sm">
                <Clock className="w-4 h-4 mr-1" />
                Q{liveData.quarter} • {liveData.timeRemaining}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 items-center">
              <div className="text-center">
                <div className="text-white font-semibold mb-1">{liveData.teamA}</div>
                <div className="text-5xl font-bold text-white">{liveData.scoreA}</div>
              </div>

              <div className="text-center">
                <div className="text-gray-400 text-sm mb-2">vs</div>
                {liveData.possession && (
                  <Badge variant="outline" className="bg-[#22d3ee]/20 text-[#22d3ee] border-[#22d3ee]">
                    {liveData.possession === "A" ? liveData.teamA : liveData.teamB} Ball
                  </Badge>
                )}
              </div>

              <div className="text-center">
                <div className="text-white font-semibold mb-1">{liveData.teamB}</div>
                <div className="text-5xl font-bold text-white">{liveData.scoreB}</div>
              </div>
            </div>

            {liveData.lastPlay && (
              <div className="mt-4 bg-[#0f172a] p-3 rounded border border-[#334155]">
                <div className="text-xs text-gray-400 mb-1">Last Play:</div>
                <div className="text-sm text-white">{liveData.lastPlay}</div>
              </div>
            )}

            {/* Momentum Indicator */}
            <div className="mt-4 flex items-center justify-center">
              <Badge
                variant="outline"
                className={
                  liveData.momentum === "A"
                    ? "bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]"
                    : liveData.momentum === "B"
                    ? "bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]"
                    : "bg-gray-600/20 text-gray-400 border-gray-600"
                }
              >
                <Zap className="w-3 h-3 mr-1" />
                {liveData.momentum === "Even" 
                  ? "Momentum: Even" 
                  : `Momentum: ${liveData.momentum === "A" ? liveData.teamA : liveData.teamB}`}
              </Badge>
            </div>
          </div>

          {/* In-Game Betting Suggestions */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Live Betting Opportunities</h3>
            <div className="space-y-3">
              {liveData.liveBettingSuggestions.map((suggestion, idx) => (
                <div key={idx} className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="outline" className="bg-[#22d3ee]/20 text-[#22d3ee] border-[#22d3ee]">
                      {suggestion.betType}
                    </Badge>
                    <div className="flex items-center space-x-2">
                      <Badge
                        variant="outline"
                        className={
                          suggestion.confidence === "High"
                            ? "bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]"
                            : suggestion.confidence === "Medium"
                            ? "bg-[#fbbf24]/20 text-[#fbbf24] border-[#fbbf24]"
                            : "bg-gray-600/20 text-gray-400 border-gray-600"
                        }
                      >
                        {suggestion.confidence}
                      </Badge>
                      <Badge
                        variant="outline"
                        className={
                          suggestion.urgency === "Act Now"
                            ? "bg-[#f87171]/20 text-[#f87171] border-[#f87171]"
                            : suggestion.urgency === "Monitor"
                            ? "bg-[#fbbf24]/20 text-[#fbbf24] border-[#fbbf24]"
                            : "bg-gray-600/20 text-gray-400 border-gray-600"
                        }
                      >
                        {suggestion.urgency}
                      </Badge>
                    </div>
                  </div>

                  <div className="text-white font-semibold mb-2">{suggestion.suggestion}</div>
                  <p className="text-sm text-gray-400">{suggestion.reasoning}</p>

                  {suggestion.liveOdds && (
                    <div className="mt-3 flex items-center space-x-4 text-xs">
                      <div>
                        <span className="text-gray-400">Live Odds:</span>
                        <span className="text-white font-semibold ml-1">{liveData.teamA} {suggestion.liveOdds.teamA}</span>
                      </div>
                      <div>
                        <span className="text-white font-semibold">{liveData.teamB} {suggestion.liveOdds.teamB}</span>
                      </div>
                    </div>
                  )}
                </div>
              ))}

              {liveData.liveBettingSuggestions.length === 0 && (
                <div className="bg-[#1e293b] p-12 rounded-lg border border-[#334155] text-center">
                  <p className="text-gray-400">No live betting opportunities at this moment</p>
                  <p className="text-xs text-gray-500 mt-2">Suggestions will appear as the game progresses</p>
                </div>
              )}
            </div>
          </div>

          {/* Game Summary */}
          <div className="bg-[#0f172a] p-4 rounded-lg border border-[#22d3ee]">
            <div className="text-sm font-semibold text-[#22d3ee] mb-2">Live Summary:</div>
            <p className="text-sm text-gray-300">{getLiveBettingSummary(liveData)}</p>
          </div>

          <div className="text-xs text-center text-gray-500">
            Updates every 5 seconds when auto-refresh is enabled
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
