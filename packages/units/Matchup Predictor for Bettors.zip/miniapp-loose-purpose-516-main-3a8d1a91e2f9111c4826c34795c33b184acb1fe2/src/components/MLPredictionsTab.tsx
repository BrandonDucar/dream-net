'use client'
import { useState } from "react";
import type { MatchupResult } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { generateEnsemblePrediction, type EnsemblePrediction } from "@/lib/ml-predictions";
import { Cpu, TrendingUp, TrendingDown, Minus } from "lucide-react";

type Props = {
  result: MatchupResult;
};

export default function MLPredictionsTab({ result }: Props) {
  const [ensemble] = useState<EnsemblePrediction>(generateEnsemblePrediction(result));

  return (
    <div className="space-y-6">
      <Card className="bg-[#0f172a] border-[#1e293b]">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Cpu className="w-5 h-5 mr-2 text-[#22d3ee]" />
            Machine Learning Predictions
          </CardTitle>
          <CardDescription className="text-gray-400">
            AI models trained on historical data with ensemble consensus
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Ensemble Consensus */}
          <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Ensemble Consensus</h3>
              <Badge
                variant="outline"
                className={
                  ensemble.modelAgreement > 80
                    ? "bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]"
                    : ensemble.modelAgreement > 60
                    ? "bg-[#fbbf24]/20 text-[#fbbf24] border-[#fbbf24]"
                    : "bg-[#f87171]/20 text-[#f87171] border-[#f87171]"
                }
              >
                {ensemble.modelAgreement}% Agreement
              </Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="bg-[#0f172a] p-4 rounded border border-[#334155]">
                <div className="text-gray-400 text-sm mb-2">Consensus Win Probability</div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-white">{result.teamAName}</span>
                    <span className="text-[#22c55e] font-bold">
                      {(ensemble.consensus.winProbA * 100).toFixed(1)}%
                    </span>
                  </div>
                  <Progress
                    value={ensemble.consensus.winProbA * 100}
                    className="h-2 bg-[#1e293b]"
                  />
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-white">{result.teamBName}</span>
                    <span className="text-[#22c55e] font-bold">
                      {(ensemble.consensus.winProbB * 100).toFixed(1)}%
                    </span>
                  </div>
                  <Progress
                    value={ensemble.consensus.winProbB * 100}
                    className="h-2 bg-[#1e293b]"
                  />
                </div>
              </div>

              {ensemble.consensus.projectedScoreA !== null && ensemble.consensus.projectedScoreB !== null && (
                <div className="bg-[#0f172a] p-4 rounded border border-[#334155]">
                  <div className="text-gray-400 text-sm mb-2">Consensus Projected Score</div>
                  <div className="text-4xl font-bold text-white text-center">
                    {ensemble.consensus.projectedScoreA} - {ensemble.consensus.projectedScoreB}
                  </div>
                </div>
              )}
            </div>

            <div className="bg-[#0f172a] p-4 rounded-lg border border-[#334155]">
              <p className="text-sm text-gray-300 leading-relaxed">{ensemble.recommendation}</p>
            </div>
          </div>

          {/* Individual Model Predictions */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Individual Model Predictions</h3>
            <div className="space-y-3">
              {ensemble.models.map((modelPred, idx) => (
                <div key={idx} className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <div className="text-white font-semibold">{modelPred.model.name}</div>
                      <div className="text-xs text-gray-400">
                        {modelPred.model.type} • {modelPred.model.accuracy}% Historical Accuracy
                      </div>
                    </div>
                    <Badge variant="outline" className="bg-[#22d3ee]/20 text-[#22d3ee] border-[#22d3ee]">
                      {modelPred.confidence}% Confidence
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 gap-3 mb-3">
                    <div className="text-center bg-[#0f172a] p-2 rounded border border-[#334155]">
                      <div className="text-xs text-gray-400">{result.teamAName}</div>
                      <div className="text-lg font-bold text-[#22c55e]">
                        {(modelPred.winProbA * 100).toFixed(1)}%
                      </div>
                    </div>
                    <div className="text-center bg-[#0f172a] p-2 rounded border border-[#334155]">
                      <div className="text-xs text-gray-400">{result.teamBName}</div>
                      <div className="text-lg font-bold text-[#22c55e]">
                        {(modelPred.winProbB * 100).toFixed(1)}%
                      </div>
                    </div>
                  </div>

                  {/* Key Factors */}
                  <div className="space-y-1">
                    <div className="text-xs text-gray-400 mb-1">Key Factors:</div>
                    {modelPred.keyFactors.slice(0, 3).map((factor, fidx) => (
                      <div key={fidx} className="flex items-center justify-between text-xs">
                        <span className="text-gray-300">{factor.factor}</span>
                        <div className="flex items-center">
                          {factor.impact > 0.3 ? (
                            <TrendingUp className="w-3 h-3 text-[#22c55e] mr-1" />
                          ) : factor.impact < -0.3 ? (
                            <TrendingDown className="w-3 h-3 text-[#f87171] mr-1" />
                          ) : (
                            <Minus className="w-3 h-3 text-gray-400 mr-1" />
                          )}
                          <span
                            className={
                              factor.impact > 0.3
                                ? "text-[#22c55e]"
                                : factor.impact < -0.3
                                ? "text-[#f87171]"
                                : "text-gray-400"
                            }
                          >
                            {factor.impact > 0 ? "+" : ""}
                            {factor.impact.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
