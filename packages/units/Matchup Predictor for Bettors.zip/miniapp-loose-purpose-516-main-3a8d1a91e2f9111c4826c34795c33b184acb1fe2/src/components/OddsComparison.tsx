'use client'
import { useState, useEffect } from "react";
import type { OddsData, PublicBettingData, LineMovement } from "@/lib/extended-types";
import { generateMockOdds, findBestOdds, generatePublicBettingData, generateLineMovements } from "@/lib/odds-data";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

type OddsComparisonProps = {
  teamAName: string;
  teamBName: string;
};

export default function OddsComparison({ teamAName, teamBName }: OddsComparisonProps) {
  const [oddsData, setOddsData] = useState<OddsData[]>([]);
  const [publicData, setPublicData] = useState<PublicBettingData | null>(null);
  const [lineMovements, setLineMovements] = useState<LineMovement[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    // Simulate fetching odds data
    const fetchData = async () => {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 800)); // Simulate API delay
      
      const odds = generateMockOdds(teamAName, teamBName);
      const publicBetting = generatePublicBettingData();
      const movements = generateLineMovements();
      
      setOddsData(odds);
      setPublicData(publicBetting);
      setLineMovements(movements);
      setLoading(false);
    };

    fetchData();
  }, [teamAName, teamBName]);

  if (loading) {
    return (
      <Card className="bg-[#0f172a] border-[#1e293b]">
        <CardContent className="py-12">
          <div className="text-center text-gray-400">
            <div className="animate-pulse">Loading real-time odds...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const bestOdds = findBestOdds(oddsData);

  return (
    <Tabs defaultValue="odds" className="w-full">
      <TabsList className="grid w-full grid-cols-3 bg-[#1e293b] border border-[#334155]">
        <TabsTrigger value="odds" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
          Odds Comparison
        </TabsTrigger>
        <TabsTrigger value="public" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
          Public Betting
        </TabsTrigger>
        <TabsTrigger value="movements" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-black">
          Line Movements
        </TabsTrigger>
      </TabsList>

      {/* Odds Comparison */}
      <TabsContent value="odds">
        <Card className="bg-[#0f172a] border-[#1e293b]">
          <CardHeader>
            <CardTitle className="text-xl text-white">Real-Time Odds Comparison</CardTitle>
            <CardDescription className="text-gray-400">
              Compare odds across major sportsbooks • Updated live
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Best Odds Summary */}
            <div className="bg-[#22d3ee]/10 p-4 rounded-lg border border-[#22d3ee]">
              <div className="text-sm text-gray-400 mb-3">🏆 Best Available Odds</div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                  <div className="text-xs text-gray-400 mb-1">{teamAName} ML</div>
                  <div className="text-lg font-bold text-white">
                    {bestOdds.bestMoneylineA.moneylineA > 0 ? '+' : ''}{bestOdds.bestMoneylineA.moneylineA}
                  </div>
                  <div className="text-xs text-[#22d3ee]">{bestOdds.bestMoneylineA.sportsbook}</div>
                </div>
                
                <div>
                  <div className="text-xs text-gray-400 mb-1">{teamBName} ML</div>
                  <div className="text-lg font-bold text-white">
                    {bestOdds.bestMoneylineB.moneylineB > 0 ? '+' : ''}{bestOdds.bestMoneylineB.moneylineB}
                  </div>
                  <div className="text-xs text-[#22d3ee]">{bestOdds.bestMoneylineB.sportsbook}</div>
                </div>

                <div>
                  <div className="text-xs text-gray-400 mb-1">Over {bestOdds.bestOver.total}</div>
                  <div className="text-lg font-bold text-white">
                    {bestOdds.bestOver.overOdds > 0 ? '+' : ''}{bestOdds.bestOver.overOdds}
                  </div>
                  <div className="text-xs text-[#22d3ee]">{bestOdds.bestOver.sportsbook}</div>
                </div>
              </div>
            </div>

            <Separator className="bg-[#334155]" />

            {/* Detailed Odds Table */}
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-[#334155]">
                    <TableHead className="text-gray-400">Sportsbook</TableHead>
                    <TableHead className="text-gray-400">{teamAName} ML</TableHead>
                    <TableHead className="text-gray-400">{teamBName} ML</TableHead>
                    <TableHead className="text-gray-400">Spread</TableHead>
                    <TableHead className="text-gray-400">Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {oddsData.map((odds, index) => (
                    <TableRow key={index} className="border-[#334155]">
                      <TableCell className="font-semibold text-white">{odds.sportsbook}</TableCell>
                      <TableCell>
                        <span className={odds.sportsbook === bestOdds.bestMoneylineA.sportsbook ? 'text-[#22c55e] font-bold' : 'text-gray-300'}>
                          {odds.moneylineA > 0 ? '+' : ''}{odds.moneylineA}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className={odds.sportsbook === bestOdds.bestMoneylineB.sportsbook ? 'text-[#22c55e] font-bold' : 'text-gray-300'}>
                          {odds.moneylineB > 0 ? '+' : ''}{odds.moneylineB}
                        </span>
                      </TableCell>
                      <TableCell className="text-gray-300">
                        {odds.spreadA > 0 ? '+' : ''}{odds.spreadA} ({odds.spreadOddsA})
                      </TableCell>
                      <TableCell className="text-gray-300">
                        O{odds.total} ({odds.overOdds}) / U{odds.total} ({odds.underOdds})
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            <div className="bg-[#334155] p-3 rounded-lg">
              <p className="text-xs text-gray-400">
                💡 <strong>Line shopping tip:</strong> Always compare odds across sportsbooks. 
                A few points difference can significantly impact long-term profitability.
              </p>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      {/* Public Betting */}
      <TabsContent value="public">
        <Card className="bg-[#0f172a] border-[#1e293b]">
          <CardHeader>
            <CardTitle className="text-xl text-white">Public Betting Percentages</CardTitle>
            <CardDescription className="text-gray-400">
              See where the public and sharp money is going
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {publicData && (
              <>
                {/* Sharp Action Alert */}
                {publicData.sharpAction !== "none" && (
                  <div className="bg-[#fbbf24]/10 p-4 rounded-lg border-2 border-[#fbbf24]">
                    <div className="flex items-center space-x-2">
                      <span className="text-2xl">⚡</span>
                      <div>
                        <div className="text-sm font-semibold text-[#fbbf24]">Sharp Money Detected</div>
                        <div className="text-xs text-gray-400">
                          Professional bettors favor {publicData.sharpAction === "A" ? teamAName : teamBName}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Team A */}
                  <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
                    <div className="text-lg font-semibold text-white mb-4">{teamAName}</div>
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm text-gray-400">Public Bets</span>
                          <span className="text-xl font-bold text-white">{publicData.teamA.betsPercentage}%</span>
                        </div>
                        <div className="w-full bg-[#334155] rounded-full h-2">
                          <div
                            className="bg-[#22d3ee] h-2 rounded-full"
                            style={{ width: `${publicData.teamA.betsPercentage}%` }}
                          ></div>
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm text-gray-400">Money %</span>
                          <span className="text-xl font-bold text-white">{publicData.teamA.moneyPercentage}%</span>
                        </div>
                        <div className="w-full bg-[#334155] rounded-full h-2">
                          <div
                            className="bg-[#22c55e] h-2 rounded-full"
                            style={{ width: `${publicData.teamA.moneyPercentage}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Team B */}
                  <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
                    <div className="text-lg font-semibold text-white mb-4">{teamBName}</div>
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm text-gray-400">Public Bets</span>
                          <span className="text-xl font-bold text-white">{publicData.teamB.betsPercentage}%</span>
                        </div>
                        <div className="w-full bg-[#334155] rounded-full h-2">
                          <div
                            className="bg-[#22d3ee] h-2 rounded-full"
                            style={{ width: `${publicData.teamB.betsPercentage}%` }}
                          ></div>
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm text-gray-400">Money %</span>
                          <span className="text-xl font-bold text-white">{publicData.teamB.moneyPercentage}%</span>
                        </div>
                        <div className="w-full bg-[#334155] rounded-full h-2">
                          <div
                            className="bg-[#22c55e] h-2 rounded-full"
                            style={{ width: `${publicData.teamB.moneyPercentage}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-[#334155] p-3 rounded-lg">
                  <p className="text-xs text-gray-400">
                    <strong>Sharp money</strong> is identified when the money percentage significantly differs from bet percentage.
                    Large bettors (sharps) often bet opposite the public.
                  </p>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      {/* Line Movements */}
      <TabsContent value="movements">
        <Card className="bg-[#0f172a] border-[#1e293b]">
          <CardHeader>
            <CardTitle className="text-xl text-white">Line Movement History</CardTitle>
            <CardDescription className="text-gray-400">
              Track how odds have moved over the past 24 hours
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {lineMovements.map((movement, index) => (
                <div key={index} className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <Badge variant="outline" className="bg-[#22d3ee]/20 text-[#22d3ee] border-[#22d3ee]">
                          {movement.type}
                        </Badge>
                        <span className="text-xs text-gray-400">{movement.sportsbook}</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className="text-white font-mono">{movement.oldValue}</span>
                        <span className={movement.direction === "up" ? "text-[#22c55e]" : "text-[#f87171]"}>
                          {movement.direction === "up" ? "↑" : "↓"}
                        </span>
                        <span className="text-white font-mono">{movement.newValue}</span>
                      </div>
                    </div>
                    <div className="text-xs text-gray-400">
                      {new Date(movement.timestamp).toLocaleTimeString()}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
}
