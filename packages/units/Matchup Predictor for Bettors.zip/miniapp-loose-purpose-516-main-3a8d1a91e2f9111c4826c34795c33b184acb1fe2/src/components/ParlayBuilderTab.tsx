'use client'
import { useState } from "react";
import type { SportCode, MatchupResult } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { getAvailableParlayLegs, buildCorrelatedParlay, suggestCorrelatedParlays, type ParlayLeg } from "@/lib/correlated-parlays";
import { Layers, Plus, Trash2, AlertTriangle } from "lucide-react";

type Props = {
  result: MatchupResult;
  sport: SportCode;
};

export default function ParlayBuilderTab({ result, sport }: Props) {
  const availableLegs = getAvailableParlayLegs(
    sport,
    result.teamAName,
    result.teamBName,
    result.projectedScoreA || undefined,
    result.projectedScoreB || undefined
  );

  const [selectedLegs, setSelectedLegs] = useState<ParlayLeg[]>([]);
  const suggestions = suggestCorrelatedParlays(sport, result.teamAName, result.teamBName, availableLegs);

  const toggleLeg = (leg: ParlayLeg) => {
    setSelectedLegs((prev) => {
      const exists = prev.find((l) => l.id === leg.id);
      if (exists) {
        return prev.filter((l) => l.id !== leg.id);
      } else {
        return [...prev, leg];
      }
    });
  };

  const clearAll = () => {
    setSelectedLegs([]);
  };

  const customParlay = selectedLegs.length >= 2 
    ? buildCorrelatedParlay(sport, result.teamAName, result.teamBName, selectedLegs)
    : null;

  return (
    <div className="space-y-6">
      <Card className="bg-[#0f172a] border-[#1e293b]">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Layers className="w-5 h-5 mr-2 text-[#22d3ee]" />
            Correlated Parlay Builder
          </CardTitle>
          <CardDescription className="text-gray-400">
            Build same-game parlays with correlation analysis
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Suggested Parlays */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Suggested Parlays</h3>
            <div className="space-y-3">
              {suggestions.map((parlay, idx) => (
                <div key={idx} className="bg-[#1e293b] p-4 rounded-lg border border-[#334155]">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className="bg-[#22d3ee]/20 text-[#22d3ee] border-[#22d3ee]">
                        {parlay.legs.length}-Leg Parlay
                      </Badge>
                      <Badge
                        variant="outline"
                        className={
                          parlay.recommendation === "Strong"
                            ? "bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]"
                            : parlay.recommendation === "Moderate"
                            ? "bg-[#fbbf24]/20 text-[#fbbf24] border-[#fbbf24]"
                            : parlay.recommendation === "Weak"
                            ? "bg-gray-600/20 text-gray-400 border-gray-600"
                            : "bg-[#f87171]/20 text-[#f87171] border-[#f87171]"
                        }
                      >
                        {parlay.recommendation}
                      </Badge>
                    </div>
                    <div className="text-right">
                      <div className="text-[#22c55e] font-bold text-lg">
                        {parlay.americanOdds > 0 ? "+" : ""}{parlay.americanOdds}
                      </div>
                      <div className="text-xs text-gray-400">Decimal: {parlay.totalOdds}</div>
                    </div>
                  </div>

                  <div className="space-y-2 mb-3">
                    {parlay.legs.map((leg, lidx) => (
                      <div key={lidx} className="bg-[#0f172a] p-2 rounded border border-[#334155] flex items-center justify-between">
                        <span className="text-sm text-white">{leg.description}</span>
                        <span className="text-xs text-gray-400">{leg.odds.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>

                  <div className="bg-[#0f172a] p-3 rounded border border-[#334155]">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-gray-400">Correlation Score:</span>
                      <span className="text-sm text-white font-semibold">{parlay.correlationScore}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-400">Edge Estimate:</span>
                      <span className={`text-sm font-semibold ${
                        parlay.edgeEstimate > 0 ? "text-[#22c55e]" : "text-[#f87171]"
                      }`}>
                        {parlay.edgeEstimate > 0 ? "+" : ""}{parlay.edgeEstimate}%
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-gray-400 mt-3">{parlay.reasoning}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Custom Parlay Builder */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Build Custom Parlay</h3>
              {selectedLegs.length > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearAll}
                  className="bg-[#1e293b] border-[#334155] text-white hover:bg-[#334155]"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Clear All
                </Button>
              )}
            </div>

            <div className="bg-[#1e293b] p-4 rounded-lg border border-[#334155] mb-4">
              <div className="space-y-2">
                {availableLegs.map((leg) => {
                  const isSelected = selectedLegs.some((l) => l.id === leg.id);
                  return (
                    <div
                      key={leg.id}
                      onClick={() => toggleLeg(leg)}
                      className={`flex items-center justify-between p-3 rounded cursor-pointer transition-colors ${
                        isSelected 
                          ? "bg-[#22d3ee]/10 border border-[#22d3ee]" 
                          : "bg-[#0f172a] border border-[#334155] hover:border-[#22d3ee]"
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <Checkbox checked={isSelected} className="data-[state=checked]:bg-[#22d3ee]" />
                        <div>
                          <div className="text-white font-medium">{leg.description}</div>
                          <div className="text-xs text-gray-400">{leg.betType}</div>
                        </div>
                      </div>
                      <div className="text-white font-semibold">{leg.odds.toFixed(2)}</div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Custom Parlay Summary */}
            {customParlay && (
              <div className="bg-[#1e293b] p-6 rounded-lg border border-[#22d3ee]">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-lg font-semibold text-white">Your Parlay</h4>
                  <Badge
                    variant="outline"
                    className={
                      customParlay.recommendation === "Strong"
                        ? "bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]"
                        : customParlay.recommendation === "Moderate"
                        ? "bg-[#fbbf24]/20 text-[#fbbf24] border-[#fbbf24]"
                        : customParlay.recommendation === "Weak"
                        ? "bg-gray-600/20 text-gray-400 border-gray-600"
                        : "bg-[#f87171]/20 text-[#f87171] border-[#f87171]"
                    }
                  >
                    {customParlay.recommendation}
                  </Badge>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
                  <div className="bg-[#0f172a] p-3 rounded border border-[#334155]">
                    <div className="text-xs text-gray-400 mb-1">Total Legs</div>
                    <div className="text-2xl font-bold text-white">{customParlay.legs.length}</div>
                  </div>

                  <div className="bg-[#0f172a] p-3 rounded border border-[#334155]">
                    <div className="text-xs text-gray-400 mb-1">Combined Odds</div>
                    <div className="text-2xl font-bold text-[#22c55e]">
                      {customParlay.americanOdds > 0 ? "+" : ""}{customParlay.americanOdds}
                    </div>
                  </div>

                  <div className="bg-[#0f172a] p-3 rounded border border-[#334155]">
                    <div className="text-xs text-gray-400 mb-1">Correlation</div>
                    <div className={`text-2xl font-bold ${
                      customParlay.correlationScore > 0.5 ? "text-[#f87171]" :
                      customParlay.correlationScore > 0.2 ? "text-[#fbbf24]" :
                      "text-[#22c55e]"
                    }`}>
                      {customParlay.correlationScore.toFixed(2)}
                    </div>
                  </div>
                </div>

                {customParlay.correlationScore > 0.5 && (
                  <div className="bg-[#f87171]/10 p-3 rounded-lg border border-[#f87171] mb-4">
                    <div className="flex items-start">
                      <AlertTriangle className="w-4 h-4 text-[#f87171] mr-2 mt-0.5" />
                      <div className="text-sm text-[#f87171]">
                        High correlation detected. Sportsbooks have likely adjusted odds to account for dependency between these outcomes.
                      </div>
                    </div>
                  </div>
                )}

                <div className="bg-[#0f172a] p-4 rounded-lg border border-[#334155]">
                  <p className="text-sm text-gray-300 leading-relaxed">{customParlay.reasoning}</p>
                </div>
              </div>
            )}

            {selectedLegs.length === 1 && (
              <div className="bg-[#1e293b] p-8 rounded-lg border border-[#334155] text-center">
                <Plus className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">Select at least one more leg to create a parlay</p>
              </div>
            )}

            {selectedLegs.length === 0 && (
              <div className="bg-[#1e293b] p-8 rounded-lg border border-[#334155] text-center">
                <Layers className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">Select legs above to build your custom parlay</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
