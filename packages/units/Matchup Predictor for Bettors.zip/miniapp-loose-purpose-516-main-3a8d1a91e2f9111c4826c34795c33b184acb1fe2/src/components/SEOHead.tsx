import Head from "next/head";

type SEOHeadProps = {
  title?: string;
  description?: string;
  matchup?: {
    teamA: string;
    teamB: string;
    sport: string;
    winProbA: number;
    winProbB: number;
  };
};

export default function SEOHead({ title, description, matchup }: SEOHeadProps) {
  const defaultTitle = "Universal Matchup Predictor - Sports Betting Analytics & Odds Calculator";
  const defaultDescription = "Free sports betting analytics platform with AI-powered predictions, odds comparison, bankroll tracking, and advanced calculators for NFL, NBA, MLB, NHL, Soccer, and more.";

  const pageTitle = matchup
    ? `${matchup.teamA} vs ${matchup.teamB} Prediction | ${matchup.sport} Betting Odds & Analysis`
    : title || defaultTitle;

  const pageDescription = matchup
    ? `${matchup.teamA} (${(matchup.winProbA * 100).toFixed(1)}% win probability) vs ${matchup.teamB} (${(matchup.winProbB * 100).toFixed(1)}%). Get AI-powered predictions, fair odds, and betting analysis.`
    : description || defaultDescription;

  const keywords = [
    "sports betting",
    "betting odds calculator",
    "matchup predictor",
    "sports analytics",
    "betting strategy",
    "kelly criterion",
    "expected value",
    "parlay calculator",
    "odds comparison",
    "bankroll management",
    matchup?.sport,
    matchup?.teamA,
    matchup?.teamB
  ].filter(Boolean).join(", ");

  const structuredData = matchup
    ? {
        "@context": "https://schema.org",
        "@type": "SportsEvent",
        "name": `${matchup.teamA} vs ${matchup.teamB}`,
        "sport": matchup.sport,
        "competitor": [
          {
            "@type": "SportsTeam",
            "name": matchup.teamA
          },
          {
            "@type": "SportsTeam",
            "name": matchup.teamB
          }
        ],
        "description": pageDescription
      }
    : {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        "name": "Universal Matchup Predictor",
        "applicationCategory": "Sports Analytics",
        "description": defaultDescription,
        "offers": {
          "@type": "Offer",
          "price": "0",
          "priceCurrency": "USD"
        }
      };

  return (
    <Head>
      <title>{pageTitle}</title>
      <meta name="description" content={pageDescription} />
      <meta name="keywords" content={keywords} />

      {/* Open Graph */}
      <meta property="og:title" content={pageTitle} />
      <meta property="og:description" content={pageDescription} />
      <meta property="og:type" content="website" />
      <meta property="og:site_name" content="Universal Matchup Predictor" />

      {/* Twitter Card */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={pageTitle} />
      <meta name="twitter:description" content={pageDescription} />

      {/* Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />

      {/* Additional SEO */}
      <meta name="robots" content="index, follow" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <link rel="canonical" href={typeof window !== 'undefined' ? window.location.href : ''} />
    </Head>
  );
}
