'use client'
import { useState } from "react";
import type { SportCode } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { getMatchupSentiment, getSentimentSummary } from "@/lib/sentiment";
import { MessageCircle, TrendingUp, Hash } from "lucide-react";

type Props = {
  teamAId: string;
  teamBId: string;
  teamAName: string;
  teamBName: string;
  sport: SportCode;
};

export default function SentimentTab({ teamAId, teamBId, teamAName, teamBName, sport }: Props) {
  const [sentimentData] = useState(getMatchupSentiment(teamAId, teamBId, sport));

  const getMomentumColor = (momentum: string) => {
    if (momentum === "Rising") return "text-[#22c55e]";
    if (momentum === "Falling") return "text-[#f87171]";
    return "text-gray-400";
  };

  const getPerceptionColor = (perception: string) => {
    if (perception === "Underrated") return "bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]";
    if (perception === "Overrated") return "bg-[#f87171]/20 text-[#f87171] border-[#f87171]";
    return "bg-gray-600/20 text-gray-400 border-gray-600";
  };

  return (
    <div className="space-y-6">
      <Card className="bg-[#0f172a] border-[#1e293b]">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <MessageCircle className="w-5 h-5 mr-2 text-[#22d3ee]" />
            Sentiment Analysis
          </CardTitle>
          <CardDescription className="text-gray-400">
            Social media and news sentiment from Twitter, Reddit, and betting forums
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Overall Sentiment Summary */}
          <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
            <h3 className="text-lg font-semibold text-white mb-4">Matchup Sentiment</h3>

            <div className="bg-[#0f172a] p-4 rounded-lg border border-[#334155] mb-4">
              <p className="text-sm text-gray-300 leading-relaxed">{getSentimentSummary(sentimentData)}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center bg-[#0f172a] p-4 rounded border border-[#334155]">
                <div className="text-gray-400 text-sm mb-2">Public Favors</div>
                <div className="text-white font-bold text-lg">
                  {sentimentData.favoredByPublic === "A" ? teamAName :
                   sentimentData.favoredByPublic === "B" ? teamBName :
                   "Even"}
                </div>
              </div>

              <div className="text-center bg-[#0f172a] p-4 rounded border border-[#334155]">
                <div className="text-gray-400 text-sm mb-2">Sentiment Edge</div>
                <div className={`font-bold text-lg ${
                  sentimentData.sentimentEdge > 20 ? "text-[#22c55e]" :
                  sentimentData.sentimentEdge < -20 ? "text-[#f87171]" :
                  "text-gray-400"
                }`}>
                  {sentimentData.sentimentEdge > 0 ? "+" : ""}{sentimentData.sentimentEdge}%
                </div>
              </div>

              <div className="text-center bg-[#0f172a] p-4 rounded border border-[#334155]">
                <div className="text-gray-400 text-sm mb-2">Narratives</div>
                <div className="text-white font-bold text-lg">{sentimentData.narratives.length}</div>
              </div>
            </div>
          </div>

          {/* Team Sentiment Comparison */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Team A */}
            <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white">{teamAName}</h3>
                <div className="flex items-center space-x-2">
                  <Badge variant="outline" className={getPerceptionColor(sentimentData.teamA.publicPerception)}>
                    {sentimentData.teamA.publicPerception}
                  </Badge>
                  <span className={`text-sm font-semibold ${getMomentumColor(sentimentData.teamA.momentum)}`}>
                    <TrendingUp className="w-4 h-4 inline mr-1" />
                    {sentimentData.teamA.momentum}
                  </span>
                </div>
              </div>

              {/* Sentiment Scores */}
              <div className="space-y-3 mb-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-400">Positive</span>
                    <span className="text-[#22c55e]">{sentimentData.teamA.overallSentiment.positive}%</span>
                  </div>
                  <Progress value={sentimentData.teamA.overallSentiment.positive} className="h-2 bg-[#0f172a]" />
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-400">Neutral</span>
                    <span className="text-gray-400">{sentimentData.teamA.overallSentiment.neutral}%</span>
                  </div>
                  <Progress value={sentimentData.teamA.overallSentiment.neutral} className="h-2 bg-[#0f172a]" />
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-400">Negative</span>
                    <span className="text-[#f87171]">{sentimentData.teamA.overallSentiment.negative}%</span>
                  </div>
                  <Progress value={sentimentData.teamA.overallSentiment.negative} className="h-2 bg-[#0f172a]" />
                </div>
              </div>

              {/* Top Sources */}
              <div className="space-y-2">
                <div className="text-sm text-gray-400 mb-2">Top Sources:</div>
                {sentimentData.teamA.sources.slice(0, 3).map((source, idx) => (
                  <div key={idx} className="flex items-center justify-between bg-[#0f172a] p-2 rounded border border-[#334155]">
                    <span className="text-xs text-white">{source.platform}</span>
                    <div className="flex items-center space-x-2">
                      {source.trending && <Badge className="text-xs bg-[#22d3ee]">Trending</Badge>}
                      <span className={`text-xs font-semibold ${
                        source.sentiment.overall > 0.3 ? "text-[#22c55e]" :
                        source.sentiment.overall < -0.3 ? "text-[#f87171]" :
                        "text-gray-400"
                      }`}>
                        {source.sentiment.overall > 0 ? "+" : ""}{(source.sentiment.overall * 100).toFixed(0)}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Team B */}
            <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white">{teamBName}</h3>
                <div className="flex items-center space-x-2">
                  <Badge variant="outline" className={getPerceptionColor(sentimentData.teamB.publicPerception)}>
                    {sentimentData.teamB.publicPerception}
                  </Badge>
                  <span className={`text-sm font-semibold ${getMomentumColor(sentimentData.teamB.momentum)}`}>
                    <TrendingUp className="w-4 h-4 inline mr-1" />
                    {sentimentData.teamB.momentum}
                  </span>
                </div>
              </div>

              {/* Sentiment Scores */}
              <div className="space-y-3 mb-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-400">Positive</span>
                    <span className="text-[#22c55e]">{sentimentData.teamB.overallSentiment.positive}%</span>
                  </div>
                  <Progress value={sentimentData.teamB.overallSentiment.positive} className="h-2 bg-[#0f172a]" />
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-400">Neutral</span>
                    <span className="text-gray-400">{sentimentData.teamB.overallSentiment.neutral}%</span>
                  </div>
                  <Progress value={sentimentData.teamB.overallSentiment.neutral} className="h-2 bg-[#0f172a]" />
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-400">Negative</span>
                    <span className="text-[#f87171]">{sentimentData.teamB.overallSentiment.negative}%</span>
                  </div>
                  <Progress value={sentimentData.teamB.overallSentiment.negative} className="h-2 bg-[#0f172a]" />
                </div>
              </div>

              {/* Top Sources */}
              <div className="space-y-2">
                <div className="text-sm text-gray-400 mb-2">Top Sources:</div>
                {sentimentData.teamB.sources.slice(0, 3).map((source, idx) => (
                  <div key={idx} className="flex items-center justify-between bg-[#0f172a] p-2 rounded border border-[#334155]">
                    <span className="text-xs text-white">{source.platform}</span>
                    <div className="flex items-center space-x-2">
                      {source.trending && <Badge className="text-xs bg-[#22d3ee]">Trending</Badge>}
                      <span className={`text-xs font-semibold ${
                        source.sentiment.overall > 0.3 ? "text-[#22c55e]" :
                        source.sentiment.overall < -0.3 ? "text-[#f87171]" :
                        "text-gray-400"
                      }`}>
                        {source.sentiment.overall > 0 ? "+" : ""}{(source.sentiment.overall * 100).toFixed(0)}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Narratives */}
          <div className="bg-[#1e293b] p-6 rounded-lg border border-[#334155]">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
              <Hash className="w-5 h-5 mr-2 text-[#22d3ee]" />
              Key Narratives
            </h3>
            <ul className="space-y-2">
              {sentimentData.narratives.map((narrative, idx) => (
                <li key={idx} className="flex items-start text-sm text-gray-300">
                  <span className="text-[#22d3ee] mr-2">•</span>
                  <span>{narrative}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Recommendation */}
          <div className="bg-[#0f172a] p-4 rounded-lg border border-[#22d3ee]">
            <div className="text-sm font-semibold text-[#22d3ee] mb-2">Sentiment Recommendation:</div>
            <p className="text-sm text-gray-300 leading-relaxed">{sentimentData.recommendation}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
