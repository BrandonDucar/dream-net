import type { TeamEntry } from "../lib/types";

export const teams: TeamEntry[] = [
  // NBA
  { id: "nba-celtics", sport: "NBA", name: "Celtics", displayName: "Boston Celtics", rating: 1720 },
  { id: "nba-lakers", sport: "NBA", name: "Lakers", displayName: "Los Angeles Lakers", rating: 1650 },
  { id: "nba-warriors", sport: "NBA", name: "Warriors", displayName: "Golden State Warriors", rating: 1680 },
  { id: "nba-bucks", sport: "NBA", name: "Bucks", displayName: "Milwaukee Bucks", rating: 1690 },
  { id: "nba-nuggets", sport: "NBA", name: "Nuggets", displayName: "Denver Nuggets", rating: 1700 },
  { id: "nba-heat", sport: "NBA", name: "Heat", displayName: "Miami Heat", rating: 1640 },
  { id: "nba-76ers", sport: "NBA", name: "76ers", displayName: "Philadelphia 76ers", rating: 1660 },
  { id: "nba-suns", sport: "NBA", name: "Suns", displayName: "Phoenix Suns", rating: 1670 },
  { id: "nba-mavericks", sport: "NBA", name: "Mavericks", displayName: "Dallas Mavericks", rating: 1685 },
  { id: "nba-knicks", sport: "NBA", name: "Knicks", displayName: "New York Knicks", rating: 1655 },

  // NFL
  { id: "nfl-chiefs", sport: "NFL", name: "Chiefs", displayName: "Kansas City Chiefs", rating: 1720 },
  { id: "nfl-eagles", sport: "NFL", name: "Eagles", displayName: "Philadelphia Eagles", rating: 1690 },
  { id: "nfl-49ers", sport: "NFL", name: "49ers", displayName: "San Francisco 49ers", rating: 1710 },
  { id: "nfl-bills", sport: "NFL", name: "Bills", displayName: "Buffalo Bills", rating: 1700 },
  { id: "nfl-bengals", sport: "NFL", name: "Bengals", displayName: "Cincinnati Bengals", rating: 1680 },
  { id: "nfl-cowboys", sport: "NFL", name: "Cowboys", displayName: "Dallas Cowboys", rating: 1670 },
  { id: "nfl-ravens", sport: "NFL", name: "Ravens", displayName: "Baltimore Ravens", rating: 1695 },
  { id: "nfl-dolphins", sport: "NFL", name: "Dolphins", displayName: "Miami Dolphins", rating: 1665 },
  { id: "nfl-lions", sport: "NFL", name: "Lions", displayName: "Detroit Lions", rating: 1685 },
  { id: "nfl-packers", sport: "NFL", name: "Packers", displayName: "Green Bay Packers", rating: 1660 },

  // NCAAB
  { id: "ncaab-duke", sport: "NCAAB", name: "Duke", displayName: "Duke Blue Devils", rating: 1680 },
  { id: "ncaab-unc", sport: "NCAAB", name: "UNC", displayName: "North Carolina Tar Heels", rating: 1650 },
  { id: "ncaab-kansas", sport: "NCAAB", name: "Kansas", displayName: "Kansas Jayhawks", rating: 1690 },
  { id: "ncaab-gonzaga", sport: "NCAAB", name: "Gonzaga", displayName: "Gonzaga Bulldogs", rating: 1670 },
  { id: "ncaab-kentucky", sport: "NCAAB", name: "Kentucky", displayName: "Kentucky Wildcats", rating: 1660 },
  { id: "ncaab-ucla", sport: "NCAAB", name: "UCLA", displayName: "UCLA Bruins", rating: 1655 },
  { id: "ncaab-uconn", sport: "NCAAB", name: "UConn", displayName: "UConn Huskies", rating: 1700 },
  { id: "ncaab-arizona", sport: "NCAAB", name: "Arizona", displayName: "Arizona Wildcats", rating: 1665 },
  { id: "ncaab-purdue", sport: "NCAAB", name: "Purdue", displayName: "Purdue Boilermakers", rating: 1675 },
  { id: "ncaab-houston", sport: "NCAAB", name: "Houston", displayName: "Houston Cougars", rating: 1685 },

  // NCAAF
  { id: "ncaaf-georgia", sport: "NCAAF", name: "Georgia", displayName: "Georgia Bulldogs", rating: 1720 },
  { id: "ncaaf-alabama", sport: "NCAAF", name: "Alabama", displayName: "Alabama Crimson Tide", rating: 1710 },
  { id: "ncaaf-ohio-state", sport: "NCAAF", name: "Ohio State", displayName: "Ohio State Buckeyes", rating: 1700 },
  { id: "ncaaf-michigan", sport: "NCAAF", name: "Michigan", displayName: "Michigan Wolverines", rating: 1690 },
  { id: "ncaaf-texas", sport: "NCAAF", name: "Texas", displayName: "Texas Longhorns", rating: 1685 },
  { id: "ncaaf-oregon", sport: "NCAAF", name: "Oregon", displayName: "Oregon Ducks", rating: 1675 },
  { id: "ncaaf-usc", sport: "NCAAF", name: "USC", displayName: "USC Trojans", rating: 1665 },
  { id: "ncaaf-clemson", sport: "NCAAF", name: "Clemson", displayName: "Clemson Tigers", rating: 1680 },
  { id: "ncaaf-penn-state", sport: "NCAAF", name: "Penn State", displayName: "Penn State Nittany Lions", rating: 1670 },
  { id: "ncaaf-fsu", sport: "NCAAF", name: "FSU", displayName: "Florida State Seminoles", rating: 1660 },

  // MLB
  { id: "mlb-dodgers", sport: "MLB", name: "Dodgers", displayName: "Los Angeles Dodgers", rating: 1700 },
  { id: "mlb-yankees", sport: "MLB", name: "Yankees", displayName: "New York Yankees", rating: 1680 },
  { id: "mlb-astros", sport: "MLB", name: "Astros", displayName: "Houston Astros", rating: 1690 },
  { id: "mlb-braves", sport: "MLB", name: "Braves", displayName: "Atlanta Braves", rating: 1685 },
  { id: "mlb-padres", sport: "MLB", name: "Padres", displayName: "San Diego Padres", rating: 1665 },
  { id: "mlb-mets", sport: "MLB", name: "Mets", displayName: "New York Mets", rating: 1660 },
  { id: "mlb-phillies", sport: "MLB", name: "Phillies", displayName: "Philadelphia Phillies", rating: 1670 },
  { id: "mlb-orioles", sport: "MLB", name: "Orioles", displayName: "Baltimore Orioles", rating: 1675 },

  // NHL
  { id: "nhl-avalanche", sport: "NHL", name: "Avalanche", displayName: "Colorado Avalanche", rating: 1700 },
  { id: "nhl-lightning", sport: "NHL", name: "Lightning", displayName: "Tampa Bay Lightning", rating: 1680 },
  { id: "nhl-hurricanes", sport: "NHL", name: "Hurricanes", displayName: "Carolina Hurricanes", rating: 1690 },
  { id: "nhl-rangers", sport: "NHL", name: "Rangers", displayName: "New York Rangers", rating: 1670 },
  { id: "nhl-bruins", sport: "NHL", name: "Bruins", displayName: "Boston Bruins", rating: 1685 },
  { id: "nhl-oilers", sport: "NHL", name: "Oilers", displayName: "Edmonton Oilers", rating: 1675 },
  { id: "nhl-panthers", sport: "NHL", name: "Panthers", displayName: "Florida Panthers", rating: 1665 },
  { id: "nhl-stars", sport: "NHL", name: "Stars", displayName: "Dallas Stars", rating: 1660 },

  // SOCCER
  { id: "soccer-man-city", sport: "SOCCER", name: "Man City", displayName: "Manchester City", rating: 1780 },
  { id: "soccer-real-madrid", sport: "SOCCER", name: "Real Madrid", displayName: "Real Madrid CF", rating: 1770 },
  { id: "soccer-barcelona", sport: "SOCCER", name: "Barcelona", displayName: "FC Barcelona", rating: 1760 },
  { id: "soccer-bayern", sport: "SOCCER", name: "Bayern", displayName: "Bayern Munich", rating: 1750 },
  { id: "soccer-liverpool", sport: "SOCCER", name: "Liverpool", displayName: "Liverpool FC", rating: 1740 },
  { id: "soccer-psg", sport: "SOCCER", name: "PSG", displayName: "Paris Saint-Germain", rating: 1730 },
  { id: "soccer-arsenal", sport: "SOCCER", name: "Arsenal", displayName: "Arsenal FC", rating: 1720 },
  { id: "soccer-inter", sport: "SOCCER", name: "Inter", displayName: "Inter Milan", rating: 1710 },

  // UFC
  { id: "ufc-jones", sport: "UFC", name: "Jon Jones", displayName: "Jon Jones", rating: 1750 },
  { id: "ufc-pereira", sport: "UFC", name: "Alex Pereira", displayName: "Alex Pereira", rating: 1720 },
  { id: "ufc-adesanya", sport: "UFC", name: "Israel Adesanya", displayName: "Israel Adesanya", rating: 1700 },
  { id: "ufc-islam", sport: "UFC", name: "Islam Makhachev", displayName: "Islam Makhachev", rating: 1740 },
  { id: "ufc-oliveira", sport: "UFC", name: "Charles Oliveira", displayName: "Charles Oliveira", rating: 1710 },
  { id: "ufc-volkanovski", sport: "UFC", name: "Alexander Volkanovski", displayName: "Alexander Volkanovski", rating: 1705 },
];
