// Line Alerts & Notification System
import type { SportCode } from "./types";

export type AlertType = 
  | "line_move" 
  | "odds_value" 
  | "injury" 
  | "weather" 
  | "steam_move" 
  | "arbitrage";

export type Alert = {
  id: string;
  type: AlertType;
  sport: SportCode;
  teamA: string;
  teamB: string;
  message: string;
  severity: "High" | "Medium" | "Low";
  timestamp: Date;
  isRead: boolean;
};

export type LineAlert = {
  userId: string;
  sport: SportCode;
  teamA: string;
  teamB: string;
  targetSpread?: number;
  targetTotal?: number;
  targetMoneyline?: number;
  alertWhen: "Above" | "Below";
  enabled: boolean;
  lastTriggered?: Date;
};

// In-memory alert storage (would be database in production)
let alerts: Alert[] = [];
let lineAlerts: LineAlert[] = [];

export function createLineAlert(alert: Omit<LineAlert, "lastTriggered">): LineAlert {
  const newAlert: LineAlert = {
    ...alert,
  };
  lineAlerts.push(newAlert);
  return newAlert;
}

export function checkLineAlerts(
  sport: SportCode,
  teamA: string,
  teamB: string,
  currentSpread: number,
  currentTotal: number,
  currentMoneyline: number
): Alert[] {
  const triggeredAlerts: Alert[] = [];

  lineAlerts.forEach((lineAlert) => {
    if (
      !lineAlert.enabled ||
      lineAlert.sport !== sport ||
      lineAlert.teamA !== teamA ||
      lineAlert.teamB !== teamB
    ) {
      return;
    }

    let triggered = false;
    let message = "";

    if (lineAlert.targetSpread !== undefined) {
      if (lineAlert.alertWhen === "Above" && currentSpread >= lineAlert.targetSpread) {
        triggered = true;
        message = `Spread reached ${currentSpread} (target: ${lineAlert.targetSpread})`;
      } else if (lineAlert.alertWhen === "Below" && currentSpread <= lineAlert.targetSpread) {
        triggered = true;
        message = `Spread dropped to ${currentSpread} (target: ${lineAlert.targetSpread})`;
      }
    }

    if (lineAlert.targetTotal !== undefined) {
      if (lineAlert.alertWhen === "Above" && currentTotal >= lineAlert.targetTotal) {
        triggered = true;
        message = `Total reached ${currentTotal} (target: ${lineAlert.targetTotal})`;
      } else if (lineAlert.alertWhen === "Below" && currentTotal <= lineAlert.targetTotal) {
        triggered = true;
        message = `Total dropped to ${currentTotal} (target: ${lineAlert.targetTotal})`;
      }
    }

    if (triggered) {
      const alert: Alert = {
        id: Math.random().toString(36).substring(7),
        type: "line_move",
        sport,
        teamA,
        teamB,
        message: `🔔 Line Alert: ${message} for ${teamA} vs ${teamB}`,
        severity: "Medium",
        timestamp: new Date(),
        isRead: false,
      };

      triggeredAlerts.push(alert);
      alerts.push(alert);
      lineAlert.lastTriggered = new Date();
    }
  });

  return triggeredAlerts;
}

export function generateMockAlerts(sport: SportCode): Alert[] {
  const mockAlerts: Alert[] = [
    {
      id: "1",
      type: "steam_move",
      sport,
      teamA: "Lakers",
      teamB: "Celtics",
      message: "🔥 Steam Move: Lakers spread moved from -3 to -5 in 5 minutes. Heavy sharp action detected.",
      severity: "High",
      timestamp: new Date(Date.now() - 1800000), // 30 min ago
      isRead: false,
    },
    {
      id: "2",
      type: "injury",
      sport,
      teamA: "Chiefs",
      teamB: "Eagles",
      message: "⚠️ Injury Update: Starting QB listed as Questionable. Line moved 2 points.",
      severity: "High",
      timestamp: new Date(Date.now() - 3600000), // 1 hour ago
      isRead: false,
    },
    {
      id: "3",
      type: "weather",
      sport: "NFL",
      teamA: "Packers",
      teamB: "Bears",
      message: "🌨️ Weather Alert: Heavy snow expected. Total dropped from 44.5 to 39.5.",
      severity: "Medium",
      timestamp: new Date(Date.now() - 7200000), // 2 hours ago
      isRead: true,
    },
    {
      id: "4",
      type: "odds_value",
      sport,
      teamA: "Duke",
      teamB: "UNC",
      message: "💎 Value Alert: Your model shows 8.2% edge on Duke ML at current odds.",
      severity: "Medium",
      timestamp: new Date(Date.now() - 10800000), // 3 hours ago
      isRead: false,
    },
    {
      id: "5",
      type: "arbitrage",
      sport,
      teamA: "Barcelona",
      teamB: "Real Madrid",
      message: "🎯 Arbitrage: 2.1% risk-free profit across 3 books. Act quickly.",
      severity: "High",
      timestamp: new Date(Date.now() - 14400000), // 4 hours ago
      isRead: true,
    },
  ];

  return mockAlerts;
}

export function getActiveAlerts(sport?: SportCode): Alert[] {
  if (sport) {
    return alerts.filter((a) => a.sport === sport && !a.isRead);
  }
  return alerts.filter((a) => !a.isRead);
}

export function getAllAlerts(): Alert[] {
  return [...alerts];
}

export function markAlertAsRead(alertId: string): void {
  const alert = alerts.find((a) => a.id === alertId);
  if (alert) {
    alert.isRead = true;
  }
}

export function clearAllAlerts(): void {
  alerts = [];
}

export function getAlertIcon(type: AlertType): string {
  const icons: Record<AlertType, string> = {
    line_move: "📊",
    odds_value: "💎",
    injury: "⚠️",
    weather: "🌨️",
    steam_move: "🔥",
    arbitrage: "🎯",
  };
  return icons[type] || "🔔";
}
