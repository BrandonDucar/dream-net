// Arbitrage Opportunity Scanner
import type { SportCode } from "./types";

export type SportsBook = {
  name: string;
  odds: number; // decimal odds
  available: boolean;
};

export type ArbitrageOpportunity = {
  id: string;
  sport: SportCode;
  teamA: string;
  teamB: string;
  betType: "Moneyline" | "Spread" | "Total";
  bookA: SportsBook;
  bookB: SportsBook;
  profitMargin: number; // percentage profit
  stake: number; // total amount to bet
  stakeA: number; // amount on team A
  stakeB: number; // amount on team B
  payoutA: number;
  payoutB: number;
  guaranteedProfit: number;
  expiresIn: number; // minutes until opportunity likely closes
  riskLevel: "Low" | "Medium" | "High";
};

export type ArbitrageSummary = {
  totalOpportunities: number;
  bestOpportunity: ArbitrageOpportunity | null;
  averageProfit: number;
  lowRiskCount: number;
};

// Calculate if arbitrage exists between two odds
export function calculateArbitrage(
  oddsA: number, // decimal
  oddsB: number  // decimal
): { hasArbitrage: boolean; profitMargin: number; impliedTotal: number } {
  const impliedProbA = 1 / oddsA;
  const impliedProbB = 1 / oddsB;
  const impliedTotal = impliedProbA + impliedProbB;

  const hasArbitrage = impliedTotal < 1;
  const profitMargin = hasArbitrage ? ((1 - impliedTotal) / impliedTotal) * 100 : 0;

  return { hasArbitrage, profitMargin, impliedTotal };
}

// Calculate optimal stake distribution for arbitrage
export function calculateOptimalStakes(
  totalStake: number,
  oddsA: number,
  oddsB: number
): { stakeA: number; stakeB: number; payoutA: number; payoutB: number; profit: number } {
  const impliedProbA = 1 / oddsA;
  const impliedProbB = 1 / oddsB;
  const totalImplied = impliedProbA + impliedProbB;

  const stakeA = (totalStake * impliedProbA) / totalImplied;
  const stakeB = (totalStake * impliedProbB) / totalImplied;

  const payoutA = stakeA * oddsA;
  const payoutB = stakeB * oddsB;

  const profit = Math.min(payoutA, payoutB) - totalStake;

  return {
    stakeA: Math.round(stakeA * 100) / 100,
    stakeB: Math.round(stakeB * 100) / 100,
    payoutA: Math.round(payoutA * 100) / 100,
    payoutB: Math.round(payoutB * 100) / 100,
    profit: Math.round(profit * 100) / 100,
  };
}

// Mock arbitrage scanner
export function scanArbitrageOpportunities(sport?: SportCode): ArbitrageOpportunity[] {
  const opportunities: ArbitrageOpportunity[] = [];
  const books = ["DraftKings", "FanDuel", "BetMGM", "Caesars", "PointsBet"];
  const numOpps = Math.floor(Math.random() * 5) + 1; // 1-5 opportunities

  for (let i = 0; i < numOpps; i++) {
    // Generate two odds that create arbitrage
    const baseOdds = 1.8 + Math.random() * 0.5; // 1.8 - 2.3
    const oddsA = baseOdds + Math.random() * 0.3;
    const oddsB = (1 / (1 - (1 / oddsA))) + Math.random() * 0.1;

    const arb = calculateArbitrage(oddsA, oddsB);

    if (arb.hasArbitrage) {
      const totalStake = 1000;
      const stakes = calculateOptimalStakes(totalStake, oddsA, oddsB);

      const bookAName = books[Math.floor(Math.random() * books.length)] || "DraftKings";
      const bookBName = books.filter((b) => b !== bookAName)[Math.floor(Math.random() * (books.length - 1))] || "FanDuel";

      opportunities.push({
        id: Math.random().toString(36).substring(7),
        sport: sport || "NBA",
        teamA: "Team A",
        teamB: "Team B",
        betType: ["Moneyline", "Spread", "Total"][Math.floor(Math.random() * 3)] as "Moneyline" | "Spread" | "Total",
        bookA: { name: bookAName, odds: Math.round(oddsA * 100) / 100, available: true },
        bookB: { name: bookBName, odds: Math.round(oddsB * 100) / 100, available: true },
        profitMargin: Math.round(arb.profitMargin * 100) / 100,
        stake: totalStake,
        stakeA: stakes.stakeA,
        stakeB: stakes.stakeB,
        payoutA: stakes.payoutA,
        payoutB: stakes.payoutB,
        guaranteedProfit: stakes.profit,
        expiresIn: Math.floor(Math.random() * 30) + 5, // 5-35 minutes
        riskLevel: arb.profitMargin > 3 ? "Low" : arb.profitMargin > 1.5 ? "Medium" : "High",
      });
    }
  }

  return opportunities.sort((a, b) => b.profitMargin - a.profitMargin);
}

export function getArbitrageSummary(opportunities: ArbitrageOpportunity[]): ArbitrageSummary {
  if (opportunities.length === 0) {
    return {
      totalOpportunities: 0,
      bestOpportunity: null,
      averageProfit: 0,
      lowRiskCount: 0,
    };
  }

  const bestOpportunity = opportunities[0] || null;
  const averageProfit = opportunities.reduce((sum, opp) => sum + opp.profitMargin, 0) / opportunities.length;
  const lowRiskCount = opportunities.filter((opp) => opp.riskLevel === "Low").length;

  return {
    totalOpportunities: opportunities.length,
    bestOpportunity,
    averageProfit: Math.round(averageProfit * 100) / 100,
    lowRiskCount,
  };
}

export function getArbitrageInstructions(opp: ArbitrageOpportunity): string[] {
  return [
    `1. Place $${opp.stakeA} on ${opp.teamA} at ${opp.bookA.name} (odds: ${opp.bookA.odds})`,
    `2. Place $${opp.stakeB} on ${opp.teamB} at ${opp.bookB.name} (odds: ${opp.bookB.odds})`,
    `3. Total stake: $${opp.stake}`,
    `4. Guaranteed payout: $${Math.max(opp.payoutA, opp.payoutB).toFixed(2)}`,
    `5. Guaranteed profit: $${opp.guaranteedProfit.toFixed(2)} (${opp.profitMargin}%)`,
    `⚠️ Act quickly - odds can change rapidly. Verify odds before placing bets.`,
  ];
}
