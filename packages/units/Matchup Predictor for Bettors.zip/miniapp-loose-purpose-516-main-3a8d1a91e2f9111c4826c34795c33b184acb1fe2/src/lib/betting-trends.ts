// Betting Trends - Sharp vs Public Money Tracking
import type { SportCode } from "./types";

export type BettingTrend = {
  teamId: string;
  teamName: string;
  sport: SportCode;
  publicBettingPct: number; // % of bets on this team
  publicMoneyPct: number; // % of money on this team
  sharpMoneyPct: number; // % of sharp money on this team
  lineMovement: number; // positive = line moving toward team, negative = away
  steamMoves: number; // count of sudden sharp line movements
  reverseLineMovement: boolean; // line moving opposite of public %
  consensusRating: "Strong Sharp" | "Sharp" | "Public" | "Neutral";
};

export type LineMovementHistory = {
  timestamp: Date;
  spread: number;
  total: number;
  moneylineOdds: number;
  volume: "High" | "Medium" | "Low";
  sharpAction: boolean;
};

export type TrendAnalysis = {
  teamA: BettingTrend;
  teamB: BettingTrend;
  sharpSide: "A" | "B" | "Even";
  publicSide: "A" | "B" | "Even";
  disagreement: boolean; // sharp vs public disagree
  confidence: "High" | "Medium" | "Low";
  recommendation: string;
  lineHistory: LineMovementHistory[];
};

// Mock betting trends generator
export function getBettingTrends(
  teamAId: string,
  teamBId: string,
  sport: SportCode
): TrendAnalysis {
  const trendA = generateTeamTrend(teamAId, sport);
  const trendB = generateTeamTrend(teamBId, sport);

  // Normalize so they add up correctly
  const totalPublic = trendA.publicBettingPct + trendB.publicBettingPct;
  trendA.publicBettingPct = (trendA.publicBettingPct / totalPublic) * 100;
  trendB.publicBettingPct = (trendB.publicBettingPct / totalPublic) * 100;

  const sharpSide = determineSharpSide(trendA, trendB);
  const publicSide = trendA.publicBettingPct > trendB.publicBettingPct ? "A" : "B";
  const disagreement = sharpSide !== publicSide && sharpSide !== "Even";

  return {
    teamA: trendA,
    teamB: trendB,
    sharpSide,
    publicSide,
    disagreement,
    confidence: calculateConfidence(trendA, trendB, disagreement),
    recommendation: generateRecommendation(trendA, trendB, sharpSide, publicSide, disagreement),
    lineHistory: generateLineHistory(),
  };
}

function generateTeamTrend(teamId: string, sport: SportCode): BettingTrend {
  const publicPct = Math.random() * 100;
  const moneyPct = publicPct + (Math.random() - 0.5) * 20; // money can differ from bets
  const sharpPct = Math.random() * 100;
  const lineMove = (Math.random() - 0.5) * 3; // -1.5 to +1.5 points

  const reverseLineMovement = 
    (publicPct > 60 && lineMove < -0.3) || 
    (publicPct < 40 && lineMove > 0.3);

  let consensusRating: "Strong Sharp" | "Sharp" | "Public" | "Neutral" = "Neutral";
  if (sharpPct > 70 && reverseLineMovement) consensusRating = "Strong Sharp";
  else if (sharpPct > 60) consensusRating = "Sharp";
  else if (publicPct > 70) consensusRating = "Public";

  return {
    teamId,
    teamName: teamId.split("-")[1] || "Team",
    sport,
    publicBettingPct: Math.round(publicPct),
    publicMoneyPct: Math.round(Math.max(0, Math.min(100, moneyPct))),
    sharpMoneyPct: Math.round(sharpPct),
    lineMovement: Math.round(lineMove * 10) / 10,
    steamMoves: Math.floor(Math.random() * 3),
    reverseLineMovement,
    consensusRating,
  };
}

function determineSharpSide(trendA: BettingTrend, trendB: BettingTrend): "A" | "B" | "Even" {
  const sharpDiff = trendA.sharpMoneyPct - trendB.sharpMoneyPct;

  if (Math.abs(sharpDiff) < 10) return "Even";
  return sharpDiff > 0 ? "A" : "B";
}

function calculateConfidence(
  trendA: BettingTrend,
  trendB: BettingTrend,
  disagreement: boolean
): "High" | "Medium" | "Low" {
  const hasRLM = trendA.reverseLineMovement || trendB.reverseLineMovement;
  const hasSteam = trendA.steamMoves > 1 || trendB.steamMoves > 1;

  if (disagreement && hasRLM && hasSteam) return "High";
  if (disagreement && (hasRLM || hasSteam)) return "Medium";
  return "Low";
}

function generateRecommendation(
  trendA: BettingTrend,
  trendB: BettingTrend,
  sharpSide: "A" | "B" | "Even",
  publicSide: "A" | "B" | "Even",
  disagreement: boolean
): string {
  if (sharpSide === "Even") {
    return "Sharp money is relatively balanced on both sides. No clear betting edge detected.";
  }

  const sharpTeam = sharpSide === "A" ? trendA.teamName : trendB.teamName;
  const sharpTrend = sharpSide === "A" ? trendA : trendB;

  if (disagreement && sharpTrend.reverseLineMovement) {
    return `Strong sharp money signal on ${sharpTeam}. Line moving toward sharps despite public backing the other side - this is a classic reverse line movement scenario worth monitoring.`;
  }

  if (disagreement) {
    return `Sharp money favors ${sharpTeam} while public is on the other side. Consider the sharp side but verify with other factors.`;
  }

  if (sharpSide === publicSide) {
    return `Both sharp and public money agree on ${sharpTeam}. This consensus suggests a strong side, but value may be limited due to line adjustment.`;
  }

  return `Moderate sharp activity on ${sharpTeam} with ${sharpTrend.steamMoves} steam move(s). Monitor for additional sharp action.`;
}

function generateLineHistory(): LineMovementHistory[] {
  const history: LineMovementHistory[] = [];
  const now = Date.now();
  const hoursBack = 24;

  let currentSpread = (Math.random() - 0.5) * 14; // -7 to +7
  let currentTotal = 200 + Math.random() * 40; // 200-240
  let currentML = -110 + Math.random() * 40; // -110 to -70

  for (let i = hoursBack; i >= 0; i -= 2) {
    // Every 2 hours
    const timestamp = new Date(now - i * 3600000);

    // Small random movements
    currentSpread += (Math.random() - 0.5) * 1;
    currentTotal += (Math.random() - 0.5) * 2;
    currentML += (Math.random() - 0.5) * 10;

    history.push({
      timestamp,
      spread: Math.round(currentSpread * 2) / 2, // round to 0.5
      total: Math.round(currentTotal * 2) / 2,
      moneylineOdds: Math.round(currentML),
      volume: ["High", "Medium", "Low"][Math.floor(Math.random() * 3)] as "High" | "Medium" | "Low",
      sharpAction: Math.random() > 0.7, // 30% chance of sharp action
    });
  }

  return history;
}

export function getTrendSummary(analysis: TrendAnalysis): string {
  const { teamA, teamB, sharpSide, publicSide, disagreement } = analysis;

  const parts: string[] = [];

  parts.push(`Public: ${teamA.publicBettingPct}% on ${teamA.teamName}, ${teamB.publicBettingPct}% on ${teamB.teamName}`);

  if (disagreement) {
    const sharpTeam = sharpSide === "A" ? teamA.teamName : teamB.teamName;
    parts.push(`⚠️ Sharp money disagrees - favoring ${sharpTeam}`);
  }

  const rlmTeam = teamA.reverseLineMovement ? teamA.teamName : 
                  teamB.reverseLineMovement ? teamB.teamName : null;

  if (rlmTeam) {
    parts.push(`🔄 Reverse line movement detected on ${rlmTeam}`);
  }

  return parts.join(" • ");
}
