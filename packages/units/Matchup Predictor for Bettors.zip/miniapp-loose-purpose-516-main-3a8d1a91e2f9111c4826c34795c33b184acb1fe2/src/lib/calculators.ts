import type { ParlayLeg, BettingRecord, BankrollStats } from "./extended-types";

// Convert American odds to decimal
export function americanToDecimal(american: number): number {
  if (american > 0) {
    return (american / 100) + 1;
  } else {
    return (100 / Math.abs(american)) + 1;
  }
}

// Convert decimal odds to American
export function decimalToAmerican(decimal: number): number {
  if (decimal >= 2) {
    return Math.round((decimal - 1) * 100);
  } else {
    return Math.round(-100 / (decimal - 1));
  }
}

// Calculate implied probability from odds
export function impliedProbability(american: number): number {
  const decimal = americanToDecimal(american);
  return (1 / decimal) * 100;
}

// Remove vig to get true probability
export function removeVig(oddsA: number, oddsB: number): { probA: number; probB: number } {
  const impliedA = impliedProbability(oddsA) / 100;
  const impliedB = impliedProbability(oddsB) / 100;
  const totalImplied = impliedA + impliedB;
  
  const trueA = impliedA / totalImplied;
  const trueB = impliedB / totalImplied;
  
  return {
    probA: trueA * 100,
    probB: trueB * 100
  };
}

// Calculate parlay odds and payout
export function calculateParlay(legs: ParlayLeg[]): {
  totalOdds: number;
  totalOddsAmerican: number;
  totalStake: number;
  potentialPayout: number;
  potentialProfit: number;
  impliedProbability: number;
} {
  const totalStake = legs.reduce((sum, leg) => sum + leg.stake, 0);
  
  // Convert all odds to decimal and multiply
  const decimalOdds = legs.map(leg => americanToDecimal(leg.odds));
  const totalDecimal = decimalOdds.reduce((product, odds) => product * odds, 1);
  
  const potentialPayout = totalStake * totalDecimal;
  const potentialProfit = potentialPayout - totalStake;
  const totalOddsAmerican = decimalToAmerican(totalDecimal);
  const impliedProb = (1 / totalDecimal) * 100;
  
  return {
    totalOdds: totalDecimal,
    totalOddsAmerican,
    totalStake,
    potentialPayout,
    potentialProfit,
    impliedProbability: impliedProb
  };
}

// Kelly Criterion calculator
export function kellyStake(
  bankroll: number,
  odds: number,
  winProbability: number,
  fraction: number = 1
): {
  fullKelly: number;
  fractionalKelly: number;
  percentage: number;
} {
  const decimal = americanToDecimal(odds);
  const b = decimal - 1; // net odds
  const p = winProbability / 100;
  const q = 1 - p;
  
  // Kelly formula: (bp - q) / b
  const kelly = (b * p - q) / b;
  const kellyPercentage = Math.max(0, kelly * 100); // Don't bet if negative
  
  const fullKellyStake = (kellyPercentage / 100) * bankroll;
  const fractionalKellyStake = fullKellyStake * fraction;
  
  return {
    fullKelly: fullKellyStake,
    fractionalKelly: fractionalKellyStake,
    percentage: kellyPercentage * fraction
  };
}

// Expected Value calculator
export function expectedValue(
  stake: number,
  odds: number,
  winProbability: number
): {
  ev: number;
  evPercentage: number;
  isPositiveEV: boolean;
} {
  const decimal = americanToDecimal(odds);
  const p = winProbability / 100;
  
  const winAmount = stake * (decimal - 1);
  const lossAmount = stake;
  
  const ev = (p * winAmount) - ((1 - p) * lossAmount);
  const evPercentage = (ev / stake) * 100;
  
  return {
    ev,
    evPercentage,
    isPositiveEV: ev > 0
  };
}

// Hedge calculator
export function calculateHedge(
  originalStake: number,
  originalOdds: number,
  currentOdds: number,
  guaranteeProfit: boolean = false
): {
  hedgeStake: number;
  scenarioA: { outcome: string; profit: number };
  scenarioB: { outcome: string; profit: number };
  guaranteedProfit: number | null;
} {
  const originalDecimal = americanToDecimal(originalOdds);
  const currentDecimal = americanToDecimal(currentOdds);
  
  const originalPayout = originalStake * originalDecimal;
  
  let hedgeStake: number;
  if (guaranteeProfit) {
    // Calculate stake to guarantee equal profit on both sides
    hedgeStake = originalPayout / currentDecimal;
  } else {
    // Calculate stake to guarantee return of original stake
    hedgeStake = (originalPayout - originalStake) / currentDecimal;
  }
  
  const hedgePayout = hedgeStake * currentDecimal;
  
  // Scenario A: Original bet wins
  const profitA = originalPayout - originalStake - hedgeStake;
  
  // Scenario B: Hedge wins
  const profitB = hedgePayout - originalStake - hedgeStake;
  
  return {
    hedgeStake,
    scenarioA: { outcome: "Original bet wins", profit: profitA },
    scenarioB: { outcome: "Hedge wins", profit: profitB },
    guaranteedProfit: guaranteeProfit ? Math.min(profitA, profitB) : null
  };
}

// Calculate bankroll statistics
export function calculateBankrollStats(
  records: BettingRecord[],
  startingBalance: number
): BankrollStats {
  const completedBets = records.filter(r => r.result !== "pending");
  
  const wins = completedBets.filter(r => r.result === "win").length;
  const losses = completedBets.filter(r => r.result === "loss").length;
  const pushes = completedBets.filter(r => r.result === "push").length;
  
  const totalProfit = completedBets.reduce((sum, r) => sum + r.profit, 0);
  const currentBalance = startingBalance + totalProfit;
  
  const winRate = completedBets.length > 0 ? (wins / completedBets.length) * 100 : 0;
  const roi = startingBalance > 0 ? (totalProfit / startingBalance) * 100 : 0;
  
  const avgOdds = completedBets.length > 0
    ? completedBets.reduce((sum, r) => sum + r.odds, 0) / completedBets.length
    : 0;
  
  const largestWin = completedBets.length > 0
    ? Math.max(...completedBets.map(r => r.profit))
    : 0;
    
  const largestLoss = completedBets.length > 0
    ? Math.min(...completedBets.map(r => r.profit))
    : 0;
  
  // Calculate current streak
  let streak = { type: "win" as const, count: 0 };
  for (let i = completedBets.length - 1; i >= 0; i--) {
    const result = completedBets[i].result;
    if (result === "push") continue;
    
    if (streak.count === 0) {
      streak.type = result === "win" ? "win" : "loss";
      streak.count = 1;
    } else if ((streak.type === "win" && result === "win") || 
               (streak.type === "loss" && result === "loss")) {
      streak.count++;
    } else {
      break;
    }
  }
  
  return {
    currentBalance,
    startingBalance,
    totalBets: completedBets.length,
    wins,
    losses,
    pushes,
    winRate,
    roi,
    avgOdds,
    totalProfit,
    largestWin,
    largestLoss,
    streak
  };
}

// Risk of Ruin calculator
export function riskOfRuin(
  winRate: number,
  avgOdds: number,
  bankrollUnits: number
): number {
  // Simplified risk of ruin formula
  const p = winRate / 100;
  const q = 1 - p;
  
  if (p >= 0.5) {
    // Positive expectation
    const avgDecimal = americanToDecimal(avgOdds);
    const b = avgDecimal - 1;
    const ratio = q / (p * b);
    return Math.pow(ratio, bankrollUnits) * 100;
  } else {
    // Negative expectation - very high risk
    return 99.9;
  }
}
