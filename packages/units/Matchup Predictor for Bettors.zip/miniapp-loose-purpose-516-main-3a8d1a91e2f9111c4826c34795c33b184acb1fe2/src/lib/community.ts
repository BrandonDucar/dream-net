// Community Features - Leaderboards, Expert Picks, Chat
import type { SportCode } from "./types";

export type UserProfile = {
  userId: string;
  username: string;
  avatar?: string;
  joinDate: Date;
  verified: boolean;
  isPro: boolean;
};

export type BettorStats = {
  user: UserProfile;
  totalBets: number;
  wins: number;
  losses: number;
  pushes: number;
  winRate: number;
  roi: number;
  profit: number;
  streak: number; // positive = win streak, negative = loss streak
  bestSport: SportCode;
  rank: number;
};

export type LeaderboardEntry = BettorStats & {
  position: number;
  change: number; // +3, -2, etc.
};

export type ExpertPick = {
  expert: UserProfile;
  sport: SportCode;
  teamA: string;
  teamB: string;
  pick: "A" | "B";
  betType: "Moneyline" | "Spread" | "Total";
  confidence: number; // 1-10
  reasoning: string;
  odds: number;
  posted: Date;
  result?: "Win" | "Loss" | "Push" | "Pending";
};

export type ChatMessage = {
  id: string;
  user: UserProfile;
  message: string;
  timestamp: Date;
  likes: number;
  replies: ChatMessage[];
  sport?: SportCode;
  tags: string[];
};

export type CommunityConsensus = {
  sport: SportCode;
  teamA: string;
  teamB: string;
  pickA: number; // % picking team A
  pickB: number; // % picking team B
  totalPicks: number;
  expertConsensus: "A" | "B" | "Split";
  publicConsensus: "A" | "B" | "Split";
  sharpConsensus: "A" | "B" | "Split";
};

// Mock leaderboard data
export function getLeaderboard(limit: number = 10): LeaderboardEntry[] {
  const users: BettorStats[] = [];

  for (let i = 0; i < limit; i++) {
    const wins = Math.floor(Math.random() * 100) + 50;
    const losses = Math.floor(Math.random() * 80) + 30;
    const pushes = Math.floor(Math.random() * 10);
    const totalBets = wins + losses + pushes;
    const winRate = (wins / totalBets) * 100;
    const profit = Math.floor((Math.random() - 0.3) * 10000);
    const roi = (profit / (totalBets * 100)) * 100;

    users.push({
      user: {
        userId: `user-${i + 1}`,
        username: `Bettor${i + 1}`,
        joinDate: new Date(Date.now() - Math.random() * 31536000000), // within last year
        verified: Math.random() > 0.7,
        isPro: Math.random() > 0.8,
      },
      totalBets,
      wins,
      losses,
      pushes,
      winRate,
      roi,
      profit,
      streak: Math.floor(Math.random() * 15) - 5,
      bestSport: ["NFL", "NBA", "MLB"][Math.floor(Math.random() * 3)] as SportCode,
      rank: i + 1,
    });
  }

  // Sort by ROI
  users.sort((a, b) => b.roi - a.roi);

  return users.map((stats, index) => ({
    ...stats,
    position: index + 1,
    change: Math.floor(Math.random() * 10) - 5, // -5 to +5
  }));
}

export function getExpertPicks(sport?: SportCode, limit: number = 5): ExpertPick[] {
  const picks: ExpertPick[] = [];
  const sports: SportCode[] = sport ? [sport] : ["NFL", "NBA", "MLB", "NHL", "SOCCER"];

  for (let i = 0; i < limit; i++) {
    const pickSport = sports[Math.floor(Math.random() * sports.length)] || "NFL";
    const confidence = Math.floor(Math.random() * 5) + 6; // 6-10

    picks.push({
      expert: {
        userId: `expert-${i + 1}`,
        username: `SharpBettor${i + 1}`,
        joinDate: new Date(Date.now() - Math.random() * 63072000000), // within 2 years
        verified: true,
        isPro: true,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${i}`,
      },
      sport: pickSport,
      teamA: "Team A",
      teamB: "Team B",
      pick: Math.random() > 0.5 ? "A" : "B",
      betType: ["Moneyline", "Spread", "Total"][Math.floor(Math.random() * 3)] as "Moneyline" | "Spread" | "Total",
      confidence,
      reasoning: generatePickReasoning(confidence),
      odds: -110 + Math.floor(Math.random() * 30),
      posted: new Date(Date.now() - Math.random() * 86400000), // within last day
      result: Math.random() > 0.7 ? ["Win", "Loss", "Push"][Math.floor(Math.random() * 3)] as "Win" | "Loss" | "Push" : "Pending",
    });
  }

  return picks.sort((a, b) => b.confidence - a.confidence);
}

function generatePickReasoning(confidence: number): string {
  const reasons = [
    "Strong matchup advantage in key positions. Defense should dominate.",
    "Recent form suggests value here. Public overreacting to last game.",
    "Sharp money moving the line. Following the professionals on this one.",
    "Historical H2H record heavily favors this side. Trends matter.",
    "Injury news creates opportunity. Market hasn't fully adjusted yet.",
    "Weather conditions favor this style of play. Significant edge here.",
    "Advanced metrics point to value. Model shows 8%+ edge.",
    "Fading the public on this one. Reverse line movement detected.",
  ];

  let reasoning = reasons[Math.floor(Math.random() * reasons.length)] || "Value play based on analysis.";

  if (confidence >= 9) {
    reasoning = `🔥 ${reasoning} High conviction play.`;
  }

  return reasoning;
}

export function getChatMessages(sport?: SportCode, limit: number = 20): ChatMessage[] {
  const messages: ChatMessage[] = [];

  for (let i = 0; i < limit; i++) {
    const minutesAgo = Math.floor(Math.random() * 120);

    messages.push({
      id: `msg-${i + 1}`,
      user: {
        userId: `user-${i + 1}`,
        username: `User${i + 1}`,
        joinDate: new Date(Date.now() - Math.random() * 31536000000),
        verified: Math.random() > 0.8,
        isPro: Math.random() > 0.9,
      },
      message: generateChatMessage(),
      timestamp: new Date(Date.now() - minutesAgo * 60000),
      likes: Math.floor(Math.random() * 50),
      replies: [],
      sport,
      tags: generateTags(),
    });
  }

  return messages.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
}

function generateChatMessage(): string {
  const messages = [
    "Lakers -3 looks like great value tonight",
    "Anyone else on Chiefs ML? Line moved 2 points since open",
    "Stay away from this total - too much uncertainty",
    "Sharp money on the under. Following the pros here",
    "This spread feels like a trap. Public all over the favorite",
    "Just hit a 3-leg parlay! 🔥",
    "Injury report just dropped - monitor the lines",
    "Weather could be a factor. Keep an eye on the forecast",
    "Model shows 7% edge on this one. Max play",
    "Fading the public today. Reverse line movement is clear",
  ];

  return messages[Math.floor(Math.random() * messages.length)] || "Great discussion here!";
}

function generateTags(): string[] {
  const allTags = ["sharp", "value", "fade", "live", "parlay", "injury", "weather", "steam"];
  const numTags = Math.floor(Math.random() * 3);
  return allTags.sort(() => Math.random() - 0.5).slice(0, numTags);
}

export function getCommunityConsensus(
  teamAId: string,
  teamBId: string,
  sport: SportCode
): CommunityConsensus {
  const pickA = Math.random() * 100;
  const pickB = 100 - pickA;

  const expertA = Math.random() * 100;
  const publicA = Math.random() * 100;
  const sharpA = Math.random() * 100;

  return {
    sport,
    teamA: teamAId.split("-")[1] || "Team A",
    teamB: teamBId.split("-")[1] || "Team B",
    pickA: Math.round(pickA),
    pickB: Math.round(pickB),
    totalPicks: Math.floor(Math.random() * 1000) + 200,
    expertConsensus: expertA > 60 ? "A" : expertA < 40 ? "B" : "Split",
    publicConsensus: publicA > 60 ? "A" : publicA < 40 ? "B" : "Split",
    sharpConsensus: sharpA > 60 ? "A" : sharpA < 40 ? "B" : "Split",
  };
}

export function getConsensusSummary(consensus: CommunityConsensus): string {
  const { teamA, teamB, expertConsensus, publicConsensus, sharpConsensus, pickA, pickB } = consensus;

  if (expertConsensus === publicConsensus && publicConsensus === sharpConsensus && expertConsensus !== "Split") {
    const favoredTeam = expertConsensus === "A" ? teamA : teamB;
    return `Strong consensus on ${favoredTeam} across experts, public, and sharps. High agreement play.`;
  }

  if (expertConsensus !== publicConsensus && expertConsensus !== "Split") {
    const expertTeam = expertConsensus === "A" ? teamA : teamB;
    const publicTeam = publicConsensus === "A" ? teamA : teamB;
    return `Experts favor ${expertTeam} while public backs ${publicTeam}. Classic fade opportunity.`;
  }

  return `Community split ${pickA}% on ${teamA}, ${pickB}% on ${teamB}. No clear consensus.`;
}
