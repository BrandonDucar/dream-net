// Correlated Parlay Builder (Same-Game Parlays)
import type { SportCode } from "./types";

export type ParlayLeg = {
  id: string;
  betType: "Spread" | "Total" | "Moneyline" | "Prop";
  selection: string;
  odds: number; // decimal
  description: string;
};

export type CorrelatedParlay = {
  id: string;
  sport: SportCode;
  teamA: string;
  teamB: string;
  legs: ParlayLeg[];
  totalOdds: number; // combined decimal odds
  americanOdds: number;
  correlationScore: number; // -1 to 1, higher = more correlated
  edgeEstimate: number; // estimated edge in %
  recommendation: "Strong" | "Moderate" | "Weak" | "Avoid";
  reasoning: string;
};

export type ParlayBuilder = {
  selectedLegs: ParlayLeg[];
  availableLegs: ParlayLeg[];
  correlationWarnings: string[];
};

// Generate available parlay legs for a matchup
export function getAvailableParlayLegs(
  sport: SportCode,
  teamA: string,
  teamB: string,
  projectedScoreA?: number,
  projectedScoreB?: number
): ParlayLeg[] {
  const legs: ParlayLeg[] = [];

  // Moneyline legs
  legs.push({
    id: "ml-a",
    betType: "Moneyline",
    selection: teamA,
    odds: 1.85 + Math.random() * 0.3,
    description: `${teamA} to win`,
  });

  legs.push({
    id: "ml-b",
    betType: "Moneyline",
    selection: teamB,
    odds: 1.85 + Math.random() * 0.3,
    description: `${teamB} to win`,
  });

  // Spread legs
  const spread = 3.5 + Math.random() * 7;
  legs.push({
    id: "spread-a",
    betType: "Spread",
    selection: `${teamA} -${spread.toFixed(1)}`,
    odds: 1.91,
    description: `${teamA} -${spread.toFixed(1)}`,
  });

  legs.push({
    id: "spread-b",
    betType: "Spread",
    selection: `${teamB} +${spread.toFixed(1)}`,
    odds: 1.91,
    description: `${teamB} +${spread.toFixed(1)}`,
  });

  // Total legs
  if (projectedScoreA && projectedScoreB) {
    const total = projectedScoreA + projectedScoreB;
    legs.push({
      id: "total-over",
      betType: "Total",
      selection: `Over ${total.toFixed(1)}`,
      odds: 1.91,
      description: `Total over ${total.toFixed(1)}`,
    });

    legs.push({
      id: "total-under",
      betType: "Total",
      selection: `Under ${total.toFixed(1)}`,
      odds: 1.91,
      description: `Total under ${total.toFixed(1)}`,
    });
  }

  // Sport-specific props
  if (sport === "NBA" || sport === "NCAAB") {
    legs.push({
      id: "prop-a-pts",
      betType: "Prop",
      selection: `${teamA} over team total`,
      odds: 1.87,
      description: `${teamA} to score over their team total`,
    });

    legs.push({
      id: "prop-lead",
      betType: "Prop",
      selection: "Lead at halftime",
      odds: 2.1,
      description: `${teamA} to lead at halftime`,
    });
  }

  if (sport === "NFL" || sport === "NCAAF") {
    legs.push({
      id: "prop-first-score",
      betType: "Prop",
      selection: "First to score",
      odds: 1.95,
      description: `${teamA} to score first`,
    });

    legs.push({
      id: "prop-rush-yards",
      betType: "Prop",
      selection: "Total rush yards over",
      odds: 1.91,
      description: `${teamA} total rush yards over`,
    });
  }

  return legs;
}

// Calculate correlation between parlay legs
export function calculateCorrelation(legs: ParlayLeg[]): number {
  if (legs.length < 2) return 0;

  // Check for obvious correlations
  let correlationScore = 0;

  const hasML = legs.some((leg) => leg.betType === "Moneyline");
  const hasSpread = legs.some((leg) => leg.betType === "Spread");
  const hasOver = legs.some((leg) => leg.selection.includes("Over"));
  const hasUnder = legs.some((leg) => leg.selection.includes("Under"));

  // Same team ML + spread = highly correlated
  if (hasML && hasSpread) {
    const mlTeam = legs.find((leg) => leg.betType === "Moneyline")?.selection || "";
    const spreadTeam = legs.find((leg) => leg.betType === "Spread")?.selection.split(" ")[0] || "";
    if (mlTeam === spreadTeam) {
      correlationScore += 0.7;
    }
  }

  // ML favorite + Over often correlate
  if (hasML && hasOver) {
    correlationScore += 0.4;
  }

  // Over + Under on same game = contradiction
  if (hasOver && hasUnder) {
    correlationScore = -1; // impossible
  }

  // Multiple same-team props = correlated
  const sameTeamProps = legs.filter((leg) => leg.betType === "Prop");
  if (sameTeamProps.length >= 2) {
    correlationScore += 0.3 * (sameTeamProps.length - 1);
  }

  return Math.max(-1, Math.min(1, correlationScore));
}

// Build a correlated parlay
export function buildCorrelatedParlay(
  sport: SportCode,
  teamA: string,
  teamB: string,
  selectedLegs: ParlayLeg[]
): CorrelatedParlay {
  const correlation = calculateCorrelation(selectedLegs);
  
  // Calculate combined odds
  const totalOdds = selectedLegs.reduce((acc, leg) => acc * leg.odds, 1);
  const americanOdds = decimalToAmerican(totalOdds);

  // Estimate edge based on correlation
  let edgeEstimate = 0;
  if (correlation > 0.5) {
    edgeEstimate = -2 - correlation * 5; // negative edge for high correlation
  } else if (correlation < 0.2 && correlation > 0) {
    edgeEstimate = 1 + Math.random() * 2; // potential small edge
  }

  const recommendation = getRecommendation(correlation, edgeEstimate, selectedLegs.length);
  const reasoning = getReasoning(correlation, selectedLegs);

  return {
    id: Math.random().toString(36).substring(7),
    sport,
    teamA,
    teamB,
    legs: selectedLegs,
    totalOdds: Math.round(totalOdds * 100) / 100,
    americanOdds,
    correlationScore: Math.round(correlation * 100) / 100,
    edgeEstimate: Math.round(edgeEstimate * 100) / 100,
    recommendation,
    reasoning,
  };
}

function decimalToAmerican(decimal: number): number {
  if (decimal >= 2) {
    return Math.round((decimal - 1) * 100);
  } else {
    return Math.round(-100 / (decimal - 1));
  }
}

function getRecommendation(
  correlation: number,
  edge: number,
  numLegs: number
): "Strong" | "Moderate" | "Weak" | "Avoid" {
  if (correlation > 0.7) return "Avoid"; // too correlated, books adjusted
  if (correlation < 0) return "Avoid"; // contradictory legs
  if (numLegs > 4) return "Weak"; // too many legs, low hit rate
  if (edge > 2 && correlation < 0.3) return "Strong";
  if (edge > 0 && correlation < 0.5) return "Moderate";
  return "Weak";
}

function getReasoning(correlation: number, legs: ParlayLeg[]): string {
  if (correlation < 0) {
    return "Warning: Selected legs contain contradictory outcomes. This parlay is impossible to hit.";
  }

  if (correlation > 0.7) {
    return "High correlation detected. Sportsbooks have adjusted odds to reflect dependency between these outcomes. Expected value is likely negative.";
  }

  if (correlation > 0.4) {
    return "Moderate correlation between legs. Books have partially adjusted for this. Consider whether the correlation provides value or removes it.";
  }

  if (legs.length > 4) {
    return `${legs.length}-leg parlay has a low probability of hitting (${(1 / legs.reduce((acc, leg) => acc * leg.odds, 1) * 100).toFixed(1)}%). Only bet if you see significant edge on each individual leg.`;
  }

  return "Legs show low correlation. This is a traditional parlay with independent outcomes. Ensure each leg has positive expected value.";
}

export function suggestCorrelatedParlays(
  sport: SportCode,
  teamA: string,
  teamB: string,
  availableLegs: ParlayLeg[]
): CorrelatedParlay[] {
  const suggestions: CorrelatedParlay[] = [];

  // Suggest 2-3 strong combinations
  // Combo 1: Favorite ML + Over (common positive correlation)
  const mlFavorite = availableLegs.find((leg) => leg.betType === "Moneyline" && leg.odds < 2);
  const over = availableLegs.find((leg) => leg.selection.includes("Over"));
  if (mlFavorite && over) {
    suggestions.push(buildCorrelatedParlay(sport, teamA, teamB, [mlFavorite, over]));
  }

  // Combo 2: Underdog spread + Under (common when dog slows pace)
  const dogSpread = availableLegs.find(
    (leg) => leg.betType === "Spread" && leg.selection.includes("+")
  );
  const under = availableLegs.find((leg) => leg.selection.includes("Under"));
  if (dogSpread && under) {
    suggestions.push(buildCorrelatedParlay(sport, teamA, teamB, [dogSpread, under]));
  }

  // Combo 3: 3-leg with low correlation
  const leg1 = availableLegs[0];
  const leg2 = availableLegs[3];
  const leg3 = availableLegs[5];
  if (leg1 && leg2 && leg3) {
    suggestions.push(buildCorrelatedParlay(sport, teamA, teamB, [leg1, leg2, leg3]));
  }

  return suggestions.sort((a, b) => {
    // Sort by recommendation strength
    const order: Record<string, number> = { Strong: 0, Moderate: 1, Weak: 2, Avoid: 3 };
    return (order[a.recommendation] || 3) - (order[b.recommendation] || 3);
  });
}
