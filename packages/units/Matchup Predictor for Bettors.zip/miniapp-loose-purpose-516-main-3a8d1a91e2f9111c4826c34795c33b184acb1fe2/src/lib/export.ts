// CSV Export Utilities
import type { BetEntry } from "./extended-types";
import type { LeaderboardEntry } from "./community";
import type { ArbitrageOpportunity } from "./arbitrage";

export function exportBetsToCSV(bets: BetEntry[]): string {
  if (bets.length === 0) return "";

  const headers = [
    "ID",
    "Date",
    "Sport",
    "Matchup",
    "Bet Type",
    "Pick",
    "Odds",
    "Stake",
    "Result",
    "Profit/Loss",
    "Notes",
  ];

  const rows = bets.map((bet) => [
    bet.id,
    bet.date.toLocaleDateString(),
    bet.sport,
    bet.matchup,
    bet.betType,
    bet.pick,
    bet.odds,
    bet.stake.toFixed(2),
    bet.result || "Pending",
    bet.profitLoss?.toFixed(2) || "0.00",
    bet.notes || "",
  ]);

  return convertToCSV([headers, ...rows]);
}

export function exportLeaderboardToCSV(entries: LeaderboardEntry[]): string {
  if (entries.length === 0) return "";

  const headers = [
    "Rank",
    "Username",
    "Total Bets",
    "Wins",
    "Losses",
    "Pushes",
    "Win Rate %",
    "ROI %",
    "Profit",
    "Current Streak",
    "Best Sport",
  ];

  const rows = entries.map((entry) => [
    entry.position,
    entry.user.username,
    entry.totalBets,
    entry.wins,
    entry.losses,
    entry.pushes,
    entry.winRate.toFixed(2),
    entry.roi.toFixed(2),
    entry.profit.toFixed(2),
    entry.streak,
    entry.bestSport,
  ]);

  return convertToCSV([headers, ...rows]);
}

export function exportArbitrageToCSV(opportunities: ArbitrageOpportunity[]): string {
  if (opportunities.length === 0) return "";

  const headers = [
    "ID",
    "Sport",
    "Matchup",
    "Bet Type",
    "Book A",
    "Odds A",
    "Book B",
    "Odds B",
    "Profit Margin %",
    "Stake A",
    "Stake B",
    "Total Stake",
    "Guaranteed Profit",
    "Risk Level",
    "Expires In (min)",
  ];

  const rows = opportunities.map((opp) => [
    opp.id,
    opp.sport,
    `${opp.teamA} vs ${opp.teamB}`,
    opp.betType,
    opp.bookA.name,
    opp.bookA.odds,
    opp.bookB.name,
    opp.bookB.odds,
    opp.profitMargin.toFixed(2),
    opp.stakeA.toFixed(2),
    opp.stakeB.toFixed(2),
    opp.stake.toFixed(2),
    opp.guaranteedProfit.toFixed(2),
    opp.riskLevel,
    opp.expiresIn,
  ]);

  return convertToCSV([headers, ...rows]);
}

function convertToCSV(data: (string | number)[][]): string {
  return data
    .map((row) =>
      row
        .map((cell) => {
          const cellStr = String(cell);
          // Escape quotes and wrap in quotes if contains comma, quote, or newline
          if (cellStr.includes(",") || cellStr.includes('"') || cellStr.includes("\n")) {
            return `"${cellStr.replace(/"/g, '""')}"`;
          }
          return cellStr;
        })
        .join(",")
    )
    .join("\n");
}

export function downloadCSV(csvContent: string, filename: string): void {
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  
  if (navigator.msSaveBlob) {
    // IE 10+
    navigator.msSaveBlob(blob, filename);
  } else {
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}

// Export all data types
export function exportDataSet(
  dataType: "bets" | "leaderboard" | "arbitrage",
  data: BetEntry[] | LeaderboardEntry[] | ArbitrageOpportunity[]
): void {
  let csvContent = "";
  let filename = "";

  switch (dataType) {
    case "bets":
      csvContent = exportBetsToCSV(data as BetEntry[]);
      filename = `betting-history-${new Date().toISOString().split("T")[0]}.csv`;
      break;
    case "leaderboard":
      csvContent = exportLeaderboardToCSV(data as LeaderboardEntry[]);
      filename = `leaderboard-${new Date().toISOString().split("T")[0]}.csv`;
      break;
    case "arbitrage":
      csvContent = exportArbitrageToCSV(data as ArbitrageOpportunity[]);
      filename = `arbitrage-opportunities-${new Date().toISOString().split("T")[0]}.csv`;
      break;
  }

  if (csvContent) {
    downloadCSV(csvContent, filename);
  }
}
