// Extended types for premium features

export type USState = 
  | "AL" | "AK" | "AZ" | "AR" | "CA" | "CO" | "CT" | "DE" | "FL" | "GA"
  | "HI" | "ID" | "IL" | "IN" | "IA" | "KS" | "KY" | "LA" | "ME" | "MD"
  | "MA" | "MI" | "MN" | "MS" | "MO" | "MT" | "NE" | "NV" | "NH" | "NJ"
  | "NM" | "NY" | "NC" | "ND" | "OH" | "OK" | "OR" | "PA" | "RI" | "SC"
  | "SD" | "TN" | "TX" | "UT" | "VT" | "VA" | "WA" | "WV" | "WI" | "WY" | "DC";

export type LocationData = {
  state: USState | null;
  city: string | null;
  country: string;
  isLegalBetting: boolean;
  legalSportsbooks: string[];
  regulatoryNote: string;
};

export type Sportsbook = {
  id: string;
  name: string;
  logo: string;
  legalStates: USState[];
  signupBonus: string;
  features: string[];
  rating: number;
  url: string;
};

export type OddsData = {
  sportsbook: string;
  moneylineA: number;
  moneylineB: number;
  spreadA: number;
  spreadOddsA: number;
  spreadB: number;
  spreadOddsB: number;
  total: number;
  overOdds: number;
  underOdds: number;
  lastUpdated: string;
};

export type LineMovement = {
  timestamp: string;
  type: "spread" | "total" | "moneyline";
  oldValue: number;
  newValue: number;
  direction: "up" | "down";
  sportsbook: string;
};

export type PublicBettingData = {
  teamA: {
    betsPercentage: number;
    moneyPercentage: number;
  };
  teamB: {
    betsPercentage: number;
    moneyPercentage: number;
  };
  sharpAction: "A" | "B" | "none";
};

export type BettingRecord = {
  id: string;
  date: string;
  sport: string;
  matchup: string;
  betType: "moneyline" | "spread" | "total" | "parlay";
  stake: number;
  odds: number;
  result: "win" | "loss" | "push" | "pending";
  profit: number;
  notes: string;
};

export type BankrollStats = {
  currentBalance: number;
  startingBalance: number;
  totalBets: number;
  wins: number;
  losses: number;
  pushes: number;
  winRate: number;
  roi: number;
  avgOdds: number;
  totalProfit: number;
  largestWin: number;
  largestLoss: number;
  streak: { type: "win" | "loss"; count: number };
};

export type ParlayLeg = {
  matchup: string;
  betType: string;
  odds: number;
  stake: number;
};

export type ArbitrageOpportunity = {
  matchup: string;
  bookA: string;
  bookB: string;
  oddsA: number;
  oddsB: number;
  stakeA: number;
  stakeB: number;
  guaranteedProfit: number;
  profitPercentage: number;
};

export type AIAnalysis = {
  confidence: number;
  reasoning: string;
  keyFactors: string[];
  riskAssessment: "low" | "medium" | "high";
  recommendation: string;
  alternativePlays: string[];
};

export type WeatherData = {
  condition: string;
  temperature: number;
  windSpeed: number;
  precipitation: number;
  impact: "favorable" | "neutral" | "unfavorable";
  notes: string;
};

export type InjuryReport = {
  player: string;
  team: string;
  position: string;
  status: "out" | "questionable" | "doubtful" | "probable";
  impact: "high" | "medium" | "low";
  details: string;
};

export type TrendData = {
  teamA: {
    ats: string; // Against the spread record
    overUnder: string;
    homeAway: string;
    recent: string;
  };
  teamB: {
    ats: string;
    overUnder: string;
    homeAway: string;
    recent: string;
  };
  headToHead: string;
};

export type AlertConfig = {
  id: string;
  type: "line_movement" | "odds_value" | "injury" | "arbitrage";
  matchup: string;
  condition: string;
  threshold: number;
  enabled: boolean;
};
