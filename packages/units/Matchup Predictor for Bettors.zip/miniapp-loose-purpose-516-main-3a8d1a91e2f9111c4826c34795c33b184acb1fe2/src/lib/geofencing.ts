import type { LocationData, USState, Sportsbook } from "./extended-types";

// Legal betting states as of 2024
const LEGAL_BETTING_STATES: USState[] = [
  "AZ", "AR", "CO", "CT", "DE", "IL", "IN", "IA", "KS", "KY",
  "LA", "ME", "MD", "MA", "MI", "NH", "NJ", "NY", "NC", "OH",
  "OR", "PA", "RI", "TN", "VA", "VT", "WV", "WI", "WY", "DC"
];

// Major sportsbooks with their legal states
export const SPORTSBOOKS: Sportsbook[] = [
  {
    id: "draftkings",
    name: "DraftKings",
    logo: "🎯",
    legalStates: ["AZ", "CO", "CT", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "NH", "NJ", "NY", "NC", "OH", "OR", "PA", "TN", "VA", "VT", "WV", "WI", "WY"],
    signupBonus: "Bet $5, Get $200 in Bonus Bets",
    features: ["Live Betting", "Same Game Parlay", "Quick Withdrawals"],
    rating: 4.8,
    url: "https://www.draftkings.com"
  },
  {
    id: "fanduel",
    name: "FanDuel",
    logo: "💙",
    legalStates: ["AZ", "CO", "CT", "IL", "IN", "IA", "KS", "KY", "LA", "MD", "MA", "MI", "NJ", "NY", "NC", "OH", "PA", "TN", "VA", "VT", "WV", "WI", "WY"],
    signupBonus: "Bet $5, Get $150 in Bonus Bets",
    features: ["No Sweat First Bet", "Best Odds Guarantee", "Fast Payouts"],
    rating: 4.7,
    url: "https://www.fanduel.com"
  },
  {
    id: "betmgm",
    name: "BetMGM",
    logo: "🦁",
    legalStates: ["AZ", "CO", "IL", "IN", "IA", "KS", "KY", "LA", "MD", "MA", "MI", "NJ", "NY", "NC", "OH", "PA", "TN", "VA", "WV", "WY", "DC"],
    signupBonus: "Up to $1,500 First Bet Offer",
    features: ["MGM Rewards", "Live Betting", "Parlay+"],
    rating: 4.6,
    url: "https://www.betmgm.com"
  },
  {
    id: "caesars",
    name: "Caesars Sportsbook",
    logo: "👑",
    legalStates: ["AZ", "CO", "IL", "IN", "IA", "KS", "KY", "LA", "MD", "MA", "MI", "NJ", "NY", "NC", "OH", "PA", "TN", "VA", "WV", "WY"],
    signupBonus: "$1,000 First Bet on Caesars",
    features: ["Caesars Rewards", "Same Game Parlay", "Odds Boosts"],
    rating: 4.5,
    url: "https://www.caesars.com/sportsbook"
  },
  {
    id: "espnbet",
    name: "ESPN BET",
    logo: "🏈",
    legalStates: ["AZ", "CO", "IL", "IN", "IA", "KS", "KY", "LA", "MD", "MA", "MI", "NJ", "NY", "NC", "OH", "PA", "TN", "VA", "WV"],
    signupBonus: "$1,000 First Bet Reset",
    features: ["ESPN Integration", "Fantasy Sync", "Expert Analysis"],
    rating: 4.4,
    url: "https://espnbet.com"
  }
];

export async function detectUserLocation(): Promise<LocationData> {
  try {
    // Use ipapi.co for geolocation (free tier: 1000 requests/day)
    const response = await fetch("https://ipapi.co/json/");
    const data = await response.json();

    const state = data.region_code as USState;
    const isLegal = LEGAL_BETTING_STATES.includes(state);
    const legalBooks = SPORTSBOOKS
      .filter(book => book.legalStates.includes(state))
      .map(book => book.name);

    return {
      state,
      city: data.city,
      country: data.country_code,
      isLegalBetting: isLegal,
      legalSportsbooks: legalBooks,
      regulatoryNote: getRegulatoryNote(state, isLegal)
    };
  } catch (error) {
    // Fallback if location detection fails
    return {
      state: null,
      city: null,
      country: "US",
      isLegalBetting: false,
      legalSportsbooks: [],
      regulatoryNote: "Unable to detect location. Please verify local betting laws."
    };
  }
}

function getRegulatoryNote(state: USState | null, isLegal: boolean): string {
  if (!state) {
    return "Location detection unavailable. Verify local regulations before betting.";
  }

  if (isLegal) {
    return `Online sports betting is legal in ${state}. Must be 21+ and physically located in-state.`;
  }

  // Special cases
  const specialCases: Record<string, string> = {
    "CA": "Sports betting is not yet legal in California. Tribal casinos may offer retail betting.",
    "TX": "Sports betting is not currently legal in Texas. Legislation is pending.",
    "FL": "Sports betting legality in Florida is complex. Check current status before betting.",
    "GA": "Sports betting is not yet legal in Georgia. Legislation is under consideration."
  };

  return specialCases[state] || `Online sports betting is not currently legal in ${state}. Check for future updates.`;
}

export function getSportsbooksForState(state: USState): Sportsbook[] {
  return SPORTSBOOKS.filter(book => book.legalStates.includes(state));
}

export function findArbitrageOpportunities(odds: { bookA: string; oddsA: number; bookB: string; oddsB: number }[]): any[] {
  const opportunities = [];

  for (const pair of odds) {
    const impliedProbA = 1 / convertToDecimal(pair.oddsA);
    const impliedProbB = 1 / convertToDecimal(pair.oddsB);
    const totalImplied = impliedProbA + impliedProbB;

    if (totalImplied < 1) {
      // Arbitrage opportunity exists
      const profitMargin = (1 - totalImplied) * 100;
      const totalStake = 100; // Base stake
      const stakeA = (totalStake * impliedProbA) / totalImplied;
      const stakeB = (totalStake * impliedProbB) / totalImplied;
      const guaranteedProfit = totalStake * (1 / totalImplied - 1);

      opportunities.push({
        bookA: pair.bookA,
        bookB: pair.bookB,
        oddsA: pair.oddsA,
        oddsB: pair.oddsB,
        stakeA: stakeA.toFixed(2),
        stakeB: stakeB.toFixed(2),
        guaranteedProfit: guaranteedProfit.toFixed(2),
        profitPercentage: profitMargin.toFixed(2)
      });
    }
  }

  return opportunities;
}

function convertToDecimal(american: number): number {
  if (american > 0) {
    return (american / 100) + 1;
  } else {
    return (100 / Math.abs(american)) + 1;
  }
}
