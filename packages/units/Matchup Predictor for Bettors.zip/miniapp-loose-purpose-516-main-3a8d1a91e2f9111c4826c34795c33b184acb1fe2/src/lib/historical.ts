// Historical Matchup Database
import type { SportCode } from "./types";

export type HistoricalGame = {
  date: Date;
  teamAScore: number;
  teamBScore: number;
  location: "Home" | "Away" | "Neutral";
  seasonYear: number;
  notes?: string;
};

export type HeadToHeadRecord = {
  teamAId: string;
  teamBId: string;
  teamAName: string;
  teamBName: string;
  sport: SportCode;
  totalGames: number;
  teamAWins: number;
  teamBWins: number;
  ties: number;
  averageScoreA: number;
  averageScoreB: number;
  lastFiveGames: HistoricalGame[];
  longestWinStreakA: number;
  longestWinStreakB: number;
  currentStreak: { team: "A" | "B" | "None"; count: number };
};

// Mock historical data generator
export function getHeadToHeadRecord(
  teamAId: string,
  teamBId: string,
  sport: SportCode
): HeadToHeadRecord {
  const numGames = Math.floor(Math.random() * 20) + 5; // 5-25 games
  const games = generateHistoricalGames(numGames, sport);

  let teamAWins = 0;
  let teamBWins = 0;
  let ties = 0;
  let totalScoreA = 0;
  let totalScoreB = 0;

  games.forEach((game) => {
    totalScoreA += game.teamAScore;
    totalScoreB += game.teamBScore;

    if (game.teamAScore > game.teamBScore) teamAWins++;
    else if (game.teamBScore > game.teamAScore) teamBWins++;
    else ties++;
  });

  return {
    teamAId,
    teamBId,
    teamAName: teamAId.split("-")[1] || "Team A",
    teamBName: teamBId.split("-")[1] || "Team B",
    sport,
    totalGames: numGames,
    teamAWins,
    teamBWins,
    ties,
    averageScoreA: Math.round((totalScoreA / numGames) * 10) / 10,
    averageScoreB: Math.round((totalScoreB / numGames) * 10) / 10,
    lastFiveGames: games.slice(0, 5),
    longestWinStreakA: calculateLongestStreak(games, "A"),
    longestWinStreakB: calculateLongestStreak(games, "B"),
    currentStreak: calculateCurrentStreak(games),
  };
}

function generateHistoricalGames(count: number, sport: SportCode): HistoricalGame[] {
  const games: HistoricalGame[] = [];
  const currentYear = new Date().getFullYear();

  const scoreRanges: Record<SportCode, { min: number; max: number }> = {
    NFL: { min: 10, max: 45 },
    NBA: { min: 85, max: 130 },
    NCAAB: { min: 55, max: 90 },
    NCAAF: { min: 17, max: 52 },
    MLB: { min: 0, max: 12 },
    NHL: { min: 0, max: 7 },
    SOCCER: { min: 0, max: 5 },
    UFC: { min: 0, max: 0 },
    OTHER: { min: 0, max: 100 },
  };

  const range = scoreRanges[sport] || scoreRanges.OTHER;

  for (let i = 0; i < count; i++) {
    const daysAgo = Math.floor(Math.random() * 1095); // up to 3 years ago
    const date = new Date();
    date.setDate(date.getDate() - daysAgo);

    games.push({
      date,
      teamAScore: Math.floor(Math.random() * (range.max - range.min + 1)) + range.min,
      teamBScore: Math.floor(Math.random() * (range.max - range.min + 1)) + range.min,
      location: ["Home", "Away", "Neutral"][Math.floor(Math.random() * 3)] as "Home" | "Away" | "Neutral",
      seasonYear: currentYear - Math.floor(daysAgo / 365),
    });
  }

  // Sort by date descending
  games.sort((a, b) => b.date.getTime() - a.date.getTime());

  return games;
}

function calculateLongestStreak(games: HistoricalGame[], team: "A" | "B"): number {
  let maxStreak = 0;
  let currentStreak = 0;

  // Reverse to go chronologically
  const chronological = [...games].reverse();

  chronological.forEach((game) => {
    const teamWon =
      team === "A" ? game.teamAScore > game.teamBScore : game.teamBScore > game.teamAScore;

    if (teamWon) {
      currentStreak++;
      maxStreak = Math.max(maxStreak, currentStreak);
    } else {
      currentStreak = 0;
    }
  });

  return maxStreak;
}

function calculateCurrentStreak(games: HistoricalGame[]): { team: "A" | "B" | "None"; count: number } {
  if (games.length === 0) return { team: "None", count: 0 };

  const firstGame = games[0];
  let streakTeam: "A" | "B" | "None" = "None";

  if (firstGame.teamAScore > firstGame.teamBScore) streakTeam = "A";
  else if (firstGame.teamBScore > firstGame.teamAScore) streakTeam = "B";
  else return { team: "None", count: 0 };

  let count = 1;

  for (let i = 1; i < games.length; i++) {
    const game = games[i];
    const aWon = game.teamAScore > game.teamBScore;
    const bWon = game.teamBScore > game.teamAScore;

    if ((streakTeam === "A" && aWon) || (streakTeam === "B" && bWon)) {
      count++;
    } else {
      break;
    }
  }

  return { team: streakTeam, count };
}

export function getHeadToHeadSummary(record: HeadToHeadRecord): string {
  const winPctA = (record.teamAWins / record.totalGames) * 100;
  const winPctB = (record.teamBWins / record.totalGames) * 100;

  const dominantTeam = winPctA > winPctB + 10 ? record.teamAName :
                       winPctB > winPctA + 10 ? record.teamBName : null;

  if (dominantTeam) {
    return `${dominantTeam} has dominated this matchup historically, winning ${Math.max(winPctA, winPctB).toFixed(0)}% of ${record.totalGames} games.`;
  }

  if (record.currentStreak.count >= 3) {
    const streakTeam = record.currentStreak.team === "A" ? record.teamAName : record.teamBName;
    return `${streakTeam} has won the last ${record.currentStreak.count} meetings in this matchup.`;
  }

  return `This is a competitive rivalry with ${record.totalGames} games played. Series stands at ${record.teamAWins}-${record.teamBWins}${record.ties > 0 ? `-${record.ties}` : ""}.`;
}
