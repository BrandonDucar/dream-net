// Injury Report Tracking System
import type { SportCode } from "./types";

export type InjuryStatus = "Out" | "Doubtful" | "Questionable" | "Probable" | "Healthy";

export type PlayerInjury = {
  playerName: string;
  position: string;
  injuryType: string;
  status: InjuryStatus;
  lastUpdate: Date;
  impactRating: number; // 1-10, higher = more impactful
};

export type TeamInjuryReport = {
  teamId: string;
  teamName: string;
  sport: SportCode;
  injuries: PlayerInjury[];
  overallHealthScore: number; // 0-100, higher = healthier
  lastUpdated: Date;
};

// Mock injury data generator - in production, integrate with injury API
export function getInjuryReport(teamId: string, sport: SportCode): TeamInjuryReport {
  const mockInjuries = generateMockInjuries(sport);
  const healthScore = calculateHealthScore(mockInjuries);

  return {
    teamId,
    teamName: teamId.split("-")[1] || "Team",
    sport,
    injuries: mockInjuries,
    overallHealthScore: healthScore,
    lastUpdated: new Date(),
  };
}

function generateMockInjuries(sport: SportCode): PlayerInjury[] {
  const positions: Record<SportCode, string[]> = {
    NFL: ["QB", "RB", "WR", "TE", "OL", "DL", "LB", "CB", "S"],
    NBA: ["PG", "SG", "SF", "PF", "C"],
    NCAAB: ["PG", "SG", "SF", "PF", "C"],
    NCAAF: ["QB", "RB", "WR", "OL", "DL", "LB", "DB"],
    MLB: ["SP", "RP", "C", "1B", "2B", "3B", "SS", "OF"],
    NHL: ["C", "LW", "RW", "D", "G"],
    SOCCER: ["GK", "DF", "MF", "FW"],
    UFC: ["Fighter"],
    OTHER: ["Player"],
  };

  const injuryTypes = [
    "Ankle Sprain",
    "Hamstring Strain",
    "Knee Injury",
    "Shoulder",
    "Concussion",
    "Back",
    "Illness",
    "Rest",
  ];

  const statuses: InjuryStatus[] = ["Out", "Doubtful", "Questionable", "Probable"];
  const numInjuries = Math.floor(Math.random() * 4); // 0-3 injuries

  const injuries: PlayerInjury[] = [];
  for (let i = 0; i < numInjuries; i++) {
    const pos = positions[sport] || positions.OTHER;
    injuries.push({
      playerName: `Player ${i + 1}`,
      position: pos[Math.floor(Math.random() * pos.length)] || "Player",
      injuryType: injuryTypes[Math.floor(Math.random() * injuryTypes.length)] || "Injury",
      status: statuses[Math.floor(Math.random() * statuses.length)] || "Questionable",
      lastUpdate: new Date(Date.now() - Math.random() * 86400000 * 3), // last 3 days
      impactRating: Math.floor(Math.random() * 10) + 1,
    });
  }

  return injuries;
}

function calculateHealthScore(injuries: PlayerInjury[]): number {
  if (injuries.length === 0) return 100;

  let totalImpact = 0;
  injuries.forEach((injury) => {
    const statusMultiplier = {
      Out: 1.5,
      Doubtful: 1.2,
      Questionable: 0.8,
      Probable: 0.4,
      Healthy: 0,
    };
    totalImpact += injury.impactRating * (statusMultiplier[injury.status] || 1);
  });

  const score = Math.max(0, 100 - totalImpact * 3);
  return Math.round(score);
}

export function getInjuryImpactSummary(report: TeamInjuryReport): string {
  const criticalInjuries = report.injuries.filter(
    (i) => i.status === "Out" && i.impactRating >= 7
  );

  if (criticalInjuries.length > 0) {
    return `Critical: ${criticalInjuries.length} key player(s) out. Significant impact expected.`;
  }

  if (report.overallHealthScore < 70) {
    return "Multiple injuries affecting rotation depth. Monitor lineup changes.";
  }

  if (report.overallHealthScore < 85) {
    return "Some injury concerns but core lineup largely intact.";
  }

  return "Team is healthy with no major injury concerns.";
}

export function compareTeamHealth(reportA: TeamInjuryReport, reportB: TeamInjuryReport): string {
  const diff = reportA.overallHealthScore - reportB.overallHealthScore;

  if (Math.abs(diff) < 10) {
    return "Both teams relatively equal in health status.";
  }

  const healthierTeam = diff > 0 ? reportA.teamName : reportB.teamName;
  const magnitude = Math.abs(diff) > 20 ? "significant" : "moderate";

  return `${healthierTeam} has a ${magnitude} health advantage in this matchup.`;
}
