// Live Game Tracking & In-Game Betting Suggestions
import type { SportCode } from "./types";

export type GameStatus = "Pre-Game" | "In-Progress" | "Halftime" | "Final";

export type LiveGameData = {
  gameId: string;
  sport: SportCode;
  teamA: string;
  teamB: string;
  status: GameStatus;
  quarter: number | null; // period/quarter/inning
  timeRemaining: string; // "12:34" format
  scoreA: number;
  scoreB: number;
  possession?: "A" | "B" | null;
  lastPlay?: string;
  momentum: "A" | "B" | "Even";
  liveBettingSuggestions: LiveBettingSuggestion[];
};

export type LiveBettingSuggestion = {
  betType: "Spread" | "Total" | "Moneyline" | "Prop";
  suggestion: string;
  reasoning: string;
  confidence: "High" | "Medium" | "Low";
  urgency: "Act Now" | "Monitor" | "Wait";
  liveOdds?: {
    teamA: number;
    teamB: number;
  };
};

export type InGameMetrics = {
  teamAStats: TeamStats;
  teamBStats: TeamStats;
  keyTrends: string[];
  scoringPace: "Fast" | "Normal" | "Slow";
  volatility: "High" | "Medium" | "Low";
};

export type TeamStats = {
  fieldGoalPct?: number;
  threePointPct?: number;
  turnovers?: number;
  rebounds?: number;
  possessionTime?: number;
  yardsPerPlay?: number;
  thirdDownPct?: number;
};

// Mock live game data
export function getLiveGameData(
  teamAId: string,
  teamBId: string,
  sport: SportCode
): LiveGameData {
  const quarter = Math.floor(Math.random() * 4) + 1;
  const timeRemaining = `${Math.floor(Math.random() * 12)}:${String(Math.floor(Math.random() * 60)).padStart(2, "0")}`;
  
  const scoreA = Math.floor(Math.random() * 50) + 20;
  const scoreB = Math.floor(Math.random() * 50) + 20;

  const scoreDiff = Math.abs(scoreA - scoreB);
  const momentum: "A" | "B" | "Even" = 
    scoreDiff > 10 ? (scoreA > scoreB ? "A" : "B") : "Even";

  return {
    gameId: `${teamAId}-${teamBId}-${Date.now()}`,
    sport,
    teamA: teamAId.split("-")[1] || "Team A",
    teamB: teamBId.split("-")[1] || "Team B",
    status: "In-Progress",
    quarter,
    timeRemaining,
    scoreA,
    scoreB,
    possession: Math.random() > 0.5 ? "A" : "B",
    lastPlay: generateLastPlay(sport),
    momentum,
    liveBettingSuggestions: generateLiveSuggestions(sport, scoreA, scoreB, quarter, momentum),
  };
}

function generateLastPlay(sport: SportCode): string {
  const plays: Record<SportCode, string[]> = {
    NBA: ["3-pointer by #23", "Layup scored", "Free throw made", "Turnover", "Defensive rebound"],
    NFL: ["15-yard pass completion", "3-yard rush", "Incomplete pass", "Field goal GOOD", "Touchdown!"],
    MLB: ["Single to left field", "Strikeout swinging", "Home run!", "Ground out", "Walk"],
    NHL: ["Goal scored!", "Shot on net", "Icing call", "Power play begins", "Save by goalie"],
    SOCCER: ["Corner kick", "Goal!", "Yellow card", "Shot wide", "Offside call"],
    NCAAB: ["Jumper made", "Dunk!", "Block", "Steal", "Timeout"],
    NCAAF: ["Touchdown pass!", "Sack for -8 yards", "First down", "Punt", "Interception"],
    UFC: ["Significant strike", "Takedown", "Submission attempt", "Round ends"],
    OTHER: ["Play in progress"],
  };

  const sportPlays = plays[sport] || plays.OTHER;
  return sportPlays[Math.floor(Math.random() * sportPlays.length)] || "Play in progress";
}

function generateLiveSuggestions(
  sport: SportCode,
  scoreA: number,
  scoreB: number,
  quarter: number,
  momentum: "A" | "B" | "Even"
): LiveBettingSuggestion[] {
  const suggestions: LiveBettingSuggestion[] = [];

  const scoreDiff = scoreA - scoreB;
  const leadingTeam = scoreA > scoreB ? "Team A" : "Team B";

  // Momentum play
  if (momentum !== "Even" && quarter <= 3) {
    suggestions.push({
      betType: "Spread",
      suggestion: `Live ${momentum === "A" ? "Team A" : "Team B"} -${Math.abs(scoreDiff) + 2}.5`,
      reasoning: `${momentum === "A" ? "Team A" : "Team B"} has clear momentum and is likely to extend lead.`,
      confidence: "Medium",
      urgency: "Monitor",
      liveOdds: { teamA: -110, teamB: -110 },
    });
  }

  // Comeback potential
  if (Math.abs(scoreDiff) > 10 && quarter >= 3) {
    const trailingTeam = scoreA < scoreB ? "Team A" : "Team B";
    suggestions.push({
      betType: "Spread",
      suggestion: `Live ${trailingTeam} +${Math.abs(scoreDiff) - 3}.5`,
      reasoning: "Large deficit may create value on trailing team to cover as favorite eases up.",
      confidence: "Low",
      urgency: "Wait",
    });
  }

  // High-scoring game total
  const currentTotal = scoreA + scoreB;
  const estimatedFinalTotal = (currentTotal / quarter) * 4;

  if (estimatedFinalTotal > 220 && sport === "NBA") {
    suggestions.push({
      betType: "Total",
      suggestion: `Live Over ${currentTotal + 50}.5`,
      reasoning: "Game pace suggests high-scoring finish. Both teams clicking offensively.",
      confidence: "High",
      urgency: "Act Now",
    });
  }

  // Close game moneyline
  if (Math.abs(scoreDiff) <= 3 && quarter === 4) {
    suggestions.push({
      betType: "Moneyline",
      suggestion: `Live ${leadingTeam} ML`,
      reasoning: "Leading team has slight edge in tight game with time running out.",
      confidence: "Medium",
      urgency: "Monitor",
      liveOdds: { teamA: -125, teamB: +105 },
    });
  }

  return suggestions;
}

export function getInGameMetrics(
  sport: SportCode
): InGameMetrics {
  const teamAStats = generateTeamStats(sport);
  const teamBStats = generateTeamStats(sport);

  const keyTrends = [
    `Team A shooting ${teamAStats.fieldGoalPct?.toFixed(1)}% from the field`,
    `Team B with ${teamBStats.turnovers} turnovers`,
    `Scoring pace is ${Math.random() > 0.5 ? "above" : "below"} season average`,
  ];

  return {
    teamAStats,
    teamBStats,
    keyTrends,
    scoringPace: ["Fast", "Normal", "Slow"][Math.floor(Math.random() * 3)] as "Fast" | "Normal" | "Slow",
    volatility: ["High", "Medium", "Low"][Math.floor(Math.random() * 3)] as "High" | "Medium" | "Low",
  };
}

function generateTeamStats(sport: SportCode): TeamStats {
  if (sport === "NBA" || sport === "NCAAB") {
    return {
      fieldGoalPct: 40 + Math.random() * 20,
      threePointPct: 30 + Math.random() * 15,
      turnovers: Math.floor(Math.random() * 15) + 5,
      rebounds: Math.floor(Math.random() * 20) + 30,
    };
  }

  if (sport === "NFL" || sport === "NCAAF") {
    return {
      yardsPerPlay: 4 + Math.random() * 3,
      thirdDownPct: 30 + Math.random() * 40,
      turnovers: Math.floor(Math.random() * 3),
      possessionTime: 20 + Math.random() * 20,
    };
  }

  return {};
}

export function getLiveBettingSummary(game: LiveGameData): string {
  const { teamA, teamB, scoreA, scoreB, quarter, momentum } = game;
  const leader = scoreA > scoreB ? teamA : teamB;
  const diff = Math.abs(scoreA - scoreB);

  let summary = `${teamA} ${scoreA} - ${teamB} ${scoreB} `;

  if (quarter) {
    summary += `(Q${quarter}) • `;
  }

  if (momentum !== "Even") {
    const momentumTeam = momentum === "A" ? teamA : teamB;
    summary += `${momentumTeam} has momentum • `;
  }

  if (diff <= 3) {
    summary += "Tight game - high volatility";
  } else if (diff > 10) {
    summary += `${leader} controlling`;
  } else {
    summary += "Competitive matchup";
  }

  return summary;
}
