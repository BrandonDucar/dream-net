import type {
  SportCode,
  TeamEntry,
  MatchupRequest,
  MatchupResult,
  SimulationResult
} from "./types";

import { teams } from "../data/teams";

export function getTeamsForSport(sport: SportCode): TeamEntry[] {
  return teams.filter((t: TeamEntry) => t.sport === sport);
}

export function getTeamById(id: string): TeamEntry | undefined {
  return teams.find((t: TeamEntry) => t.id === id);
}

// ELO → win probability
export function winProbFromElo(eloA: number, eloB: number, neutral: boolean): { winProbA: number; winProbB: number } {
  // simple home advantage: +50 ELO to home side if not neutral
  const homeAdv = 50;
  const adjA = neutral ? eloA : eloA + homeAdv;
  const adjB = neutral ? eloB : eloB;
  const winProbA = 1 / (1 + Math.pow(10, (adjB - adjA) / 400));
  const winProbB = 1 - winProbA;
  return { winProbA, winProbB };
}

// Convert probability → decimal/american odds
export function decimalFromProb(p: number): number {
  if (p <= 0) return 0;
  return 1 / p;
}

export function americanFromProb(p: number): number {
  if (p <= 0 || p >= 1) return 0;
  if (p >= 0.5) {
    // favorite
    const odds = - (p / (1 - p)) * 100;
    return Math.round(odds);
  } else {
    const odds = ((1 - p) / p) * 100;
    return Math.round(odds);
  }
}

// Projected score baselines per sport
function scoreBaseline(sport: SportCode): { baseA: number; baseB: number; spreadScale: number; blowoutMargin: number; closeMargin: number } {
  switch (sport) {
    case "NBA":
      return { baseA: 110, baseB: 108, spreadScale: 25, blowoutMargin: 15, closeMargin: 5 };
    case "NCAAB":
      return { baseA: 72, baseB: 70, spreadScale: 15, blowoutMargin: 12, closeMargin: 5 };
    case "NFL":
      return { baseA: 24, baseB: 22, spreadScale: 10, blowoutMargin: 14, closeMargin: 3 };
    case "NCAAF":
      return { baseA: 31, baseB: 28, spreadScale: 14, blowoutMargin: 17, closeMargin: 7 };
    case "MLB":
      return { baseA: 4.5, baseB: 4.2, spreadScale: 3, blowoutMargin: 4, closeMargin: 1 };
    case "NHL":
      return { baseA: 3, baseB: 2.8, spreadScale: 2, blowoutMargin: 3, closeMargin: 1 };
    case "SOCCER":
      return { baseA: 1.4, baseB: 1.2, spreadScale: 1.5, blowoutMargin: 3, closeMargin: 1 };
    case "UFC":
      return { baseA: 0, baseB: 0, spreadScale: 0, blowoutMargin: 0, closeMargin: 0 };
    default:
      return { baseA: 0, baseB: 0, spreadScale: 0, blowoutMargin: 0, closeMargin: 0 };
  }
}

// Simple score projection based on win probability
export function projectScores(
  sport: SportCode,
  winProbA: number,
  winProbB: number
): { projectedScoreA: number | null; projectedScoreB: number | null } {
  const base = scoreBaseline(sport);
  if (sport === "UFC" || sport === "OTHER") {
    return { projectedScoreA: null, projectedScoreB: null };
  }

  // convert winProb difference into a notional spread
  const diff = winProbA - winProbB; // roughly -1 to 1
  const spread = diff * base.spreadScale;

  const avgTotal = base.baseA + base.baseB;
  const scoreA = (avgTotal / 2) + spread / 2;
  const scoreB = (avgTotal / 2) - spread / 2;

  return {
    projectedScoreA: Math.round(scoreA * 10) / 10,
    projectedScoreB: Math.round(scoreB * 10) / 10
  };
}

// Lean text helpers
export function buildLeanSummary(result: MatchupResult, req: MatchupRequest): string {
  const { sport, teamAName, teamBName, winProbA, winProbB, projectedScoreA, projectedScoreB } = result;

  const favorite = result.favoredTeam === "A" ? teamAName :
                   result.favoredTeam === "B" ? teamBName : "no clear favorite";

  const lines: string[] = [];

  lines.push(`${favorite} rates as the stronger side in this matchup.`);

  if (projectedScoreA != null && projectedScoreB != null) {
    const total = projectedScoreA + projectedScoreB;
    lines.push(`Model projects roughly ${projectedScoreA}-${projectedScoreB} (~${total.toFixed(1)} total points).`);
  }

  if (req.marketSpread != null) {
    const impliedSpread = (projectedScoreA ?? 0) - (projectedScoreB ?? 0);
    const diffSpread = impliedSpread - req.marketSpread;
    if (Math.abs(diffSpread) > 1) {
      lines.push(`Spread edge: model spread ${impliedSpread.toFixed(1)} vs market ${req.marketSpread.toFixed(1)} (${diffSpread > 0 ? "leans to favorite" : "leans to dog"}).`);
    }
  }

  if (req.marketTotal != null && projectedScoreA != null && projectedScoreB != null) {
    const modelTotal = projectedScoreA + projectedScoreB;
    const diffTotal = modelTotal - req.marketTotal;
    if (Math.abs(diffTotal) > 3) {
      lines.push(`Total edge: model total ${modelTotal.toFixed(1)} vs market ${req.marketTotal.toFixed(1)} (${diffTotal > 0 ? "leans over" : "leans under"}).`);
    }
  }

  if (winProbA > 0.60 || winProbB > 0.60) {
    const heavyFav = winProbA > 0.60 ? teamAName : teamBName;
    const sideProb = Math.max(winProbA, winProbB) * 100;
    lines.push(`${heavyFav} carries about a ${sideProb.toFixed(1)}% win chance; moneyline is the primary angle here.`);
  } else if (Math.abs(winProbA - winProbB) < 0.1) {
    lines.push(`This projects as a relatively tight game; spreads and live angles may matter more than pregame MLs.`);
  }

  return lines.join(" ");
}

// Main function to generate a matchup result
export function generateMatchup(req: MatchupRequest): MatchupResult {
  const teamA = getTeamById(req.teamAId);
  const teamB = getTeamById(req.teamBId);
  if (!teamA || !teamB) {
    throw new Error("Invalid team IDs");
  }

  const { winProbA, winProbB } = winProbFromElo(teamA.rating, teamB.rating, req.neutralSite);

  const { projectedScoreA, projectedScoreB } = projectScores(req.sport, winProbA, winProbB);

  const fairDecimalA = decimalFromProb(winProbA);
  const fairDecimalB = decimalFromProb(winProbB);
  const fairAmericanA = americanFromProb(winProbA);
  const fairAmericanB = americanFromProb(winProbB);

  let favoredTeam: "A" | "B" | "even" = "even";
  if (winProbA > winProbB + 0.02) favoredTeam = "A";
  else if (winProbB > winProbA + 0.02) favoredTeam = "B";

  const upsetProbability = favoredTeam === "A" ? winProbB : favoredTeam === "B" ? winProbA : Math.min(winProbA, winProbB);

  const paceNotes = buildPaceNotes(req.sport, winProbA, winProbB);
  const styleNotes = buildStyleNotes(req.sport, teamA, teamB, winProbA, winProbB);
  const keyEdges = buildKeyEdges(req, winProbA, winProbB, projectedScoreA, projectedScoreB);

  const resultBase: MatchupResult = {
    sport: req.sport,
    teamAName: teamA.displayName,
    teamBName: teamB.displayName,

    winProbA,
    winProbB,

    projectedScoreA,
    projectedScoreB,

    fairDecimalA,
    fairDecimalB,
    fairAmericanA,
    fairAmericanB,

    upsetProbability,
    favoredTeam,

    paceNotes,
    styleNotes,
    keyEdges,
    leanSummary: ""  // filled below
  };

  const withLean: MatchupResult = {
    ...resultBase,
    leanSummary: buildLeanSummary(resultBase, req)
  };

  return withLean;
}

// Simple, sport-dependent text stubs – can be expanded later
export function buildPaceNotes(sport: SportCode, winProbA: number, winProbB: number): string {
  switch (sport) {
    case "NBA":
    case "NCAAB":
      return "Projected tempo: medium pace with swings driven by shot variance.";
    case "NFL":
    case "NCAAF":
      return "Game script likely dictated by early scoring; favorites may lean run-heavy if ahead.";
    case "SOCCER":
      return "Possession and chance quality matter more than raw volume; expect a few key moments to swing it.";
    default:
      return "Standard pace projection with moderate variance.";
  }
}

export function buildStyleNotes(
  sport: SportCode,
  teamA: TeamEntry,
  teamB: TeamEntry,
  winProbA: number,
  winProbB: number
): string[] {
  const notes: string[] = [];
  if (winProbA > winProbB) {
    notes.push(`${teamA.displayName} grades slightly stronger overall on power rating.`);
  } else if (winProbB > winProbA) {
    notes.push(`${teamB.displayName} grades slightly stronger overall on power rating.`);
  } else {
    notes.push(`Power ratings see these teams as nearly equal.`);
  }
  notes.push(`Expect the market to anchor around the stronger side with modest adjustment for form and injuries.`);
  return notes;
}

// Simple edge messages vs market spread/total
export function buildKeyEdges(
  req: MatchupRequest,
  winProbA: number,
  winProbB: number,
  projectedScoreA: number | null,
  projectedScoreB: number | null
): string[] {
  const edges: string[] = [];
  if (req.marketSpread != null && projectedScoreA != null && projectedScoreB != null) {
    const impliedSpread = projectedScoreA - projectedScoreB;
    const diffSpread = impliedSpread - req.marketSpread;
    if (Math.abs(diffSpread) > 1) {
      edges.push(`Spread edge of about ${diffSpread.toFixed(1)} pts vs market.`);
    }
  }
  if (req.marketTotal != null && projectedScoreA != null && projectedScoreB != null) {
    const modelTotal = projectedScoreA + projectedScoreB;
    const diffTotal = modelTotal - req.marketTotal;
    if (Math.abs(diffTotal) > 3) {
      edges.push(`Total edge of about ${diffTotal.toFixed(1)} pts vs market.`);
    }
  }
  if (edges.length === 0) {
    edges.push("No obvious edges vs the given market numbers at first glance.");
  }
  return edges;
}

// Monte Carlo-like simulation (simple, not true statistical model)
export function simulateMatchup(
  sport: SportCode,
  baseResult: MatchupResult,
  iterations: number
): SimulationResult {
  let winsA = 0;
  let winsB = 0;
  let sumScoreA = 0;
  let sumScoreB = 0;
  let blowoutA = 0;
  let blowoutB = 0;
  let closeGames = 0;

  const base = scoreBaseline(sport);
  const blowoutMargin = base.blowoutMargin;
  const closeMargin = base.closeMargin;

  for (let i = 0; i < iterations; i++) {
    const r = Math.random();
    const aWins = r < baseResult.winProbA;
    if (aWins) winsA++; else winsB++;

    if (baseResult.projectedScoreA != null && baseResult.projectedScoreB != null) {
      // simple noise around the projected scores
      const noiseA = randomNormal(0, base.spreadScale / 4);
      const noiseB = randomNormal(0, base.spreadScale / 4);
      const scoreA = Math.max(0, baseResult.projectedScoreA + noiseA);
      const scoreB = Math.max(0, baseResult.projectedScoreB + noiseB);
      sumScoreA += scoreA;
      sumScoreB += scoreB;

      const diff = Math.abs(scoreA - scoreB);
      if (diff >= blowoutMargin) {
        if (scoreA > scoreB) blowoutA++; else blowoutB++;
      } else if (diff <= closeMargin) {
        closeGames++;
      }
    }
  }

  const winPctA = winsA / iterations;
  const winPctB = winsB / iterations;

  const avgScoreA = baseResult.projectedScoreA != null ? sumScoreA / iterations : null;
  const avgScoreB = baseResult.projectedScoreB != null ? sumScoreB / iterations : null;

  const chaosIndex =
    baseResult.projectedScoreA != null
      ? Math.abs((avgScoreA! - baseResult.projectedScoreA) + (avgScoreB! - baseResult.projectedScoreB))
      : Math.abs(winPctA - baseResult.winProbA) * 100;

  return {
    iterations,
    winsA,
    winsB,
    winPctA,
    winPctB,
    avgScoreA: avgScoreA != null ? Math.round(avgScoreA * 10) / 10 : null,
    avgScoreB: avgScoreB != null ? Math.round(avgScoreB * 10) / 10 : null,
    blowoutPctA: iterations > 0 ? blowoutA / iterations : 0,
    blowoutPctB: iterations > 0 ? blowoutB / iterations : 0,
    closeGamePct: iterations > 0 ? closeGames / iterations : 0,
    chaosIndex
  };
}

// Simple approximate normal RNG
function randomNormal(mean = 0, stdDev = 1): number {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  const z = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return mean + z * stdDev;
}
