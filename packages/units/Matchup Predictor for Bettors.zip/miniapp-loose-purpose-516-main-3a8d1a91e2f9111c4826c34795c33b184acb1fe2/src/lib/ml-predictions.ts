// Machine Learning Predictions (Mock Implementation)
import type { SportCode, MatchupResult } from "./types";

export type MLModel = {
  name: string;
  type: "Neural Network" | "Random Forest" | "XGBoost" | "Ensemble";
  accuracy: number; // historical accuracy %
  lastTrained: Date;
  features: string[];
};

export type MLPrediction = {
  model: MLModel;
  winProbA: number;
  winProbB: number;
  confidence: number; // 0-100
  projectedScoreA: number | null;
  projectedScoreB: number | null;
  keyFactors: { factor: string; impact: number }[]; // impact is -1 to 1
  uncertainty: number; // 0-100, higher = more uncertain
};

export type EnsemblePrediction = {
  models: MLPrediction[];
  consensus: {
    winProbA: number;
    winProbB: number;
    projectedScoreA: number | null;
    projectedScoreB: number | null;
  };
  modelAgreement: number; // 0-100, how much models agree
  recommendation: string;
};

const MODELS: MLModel[] = [
  {
    name: "Deep Neural Network",
    type: "Neural Network",
    accuracy: 64.2,
    lastTrained: new Date("2024-12-01"),
    features: ["ELO", "Recent Form", "Head-to-Head", "Home/Away", "Rest Days"],
  },
  {
    name: "Random Forest Classifier",
    type: "Random Forest",
    accuracy: 61.8,
    lastTrained: new Date("2024-12-01"),
    features: ["ELO", "Offensive Rating", "Defensive Rating", "Pace", "Injuries"],
  },
  {
    name: "XGBoost Predictor",
    type: "XGBoost",
    accuracy: 63.5,
    lastTrained: new Date("2024-12-01"),
    features: ["ELO", "Player Stats", "Team Chemistry", "Matchup History", "Travel Distance"],
  },
  {
    name: "Ensemble Meta-Model",
    type: "Ensemble",
    accuracy: 66.1,
    lastTrained: new Date("2024-12-01"),
    features: ["All Model Outputs", "Betting Market Odds", "Public Sentiment", "Weather", "Injuries"],
  },
];

// Generate ML prediction based on a matchup result
export function generateMLPrediction(
  result: MatchupResult,
  modelName: string
): MLPrediction {
  const model = MODELS.find((m) => m.name === modelName) || MODELS[0];
  
  // Add some variance to the base result
  const variance = (Math.random() - 0.5) * 0.1; // +/- 5%
  const winProbA = Math.max(0, Math.min(1, result.winProbA + variance));
  const winProbB = 1 - winProbA;

  const scoreVariance = (Math.random() - 0.5) * 5;
  const projectedScoreA = result.projectedScoreA !== null ? result.projectedScoreA + scoreVariance : null;
  const projectedScoreB = result.projectedScoreB !== null ? result.projectedScoreB - scoreVariance : null;

  return {
    model,
    winProbA,
    winProbB,
    confidence: Math.floor(50 + Math.random() * 40), // 50-90%
    projectedScoreA: projectedScoreA !== null ? Math.round(projectedScoreA * 10) / 10 : null,
    projectedScoreB: projectedScoreB !== null ? Math.round(projectedScoreB * 10) / 10 : null,
    keyFactors: generateKeyFactors(result.sport),
    uncertainty: Math.floor(Math.random() * 30) + 10, // 10-40%
  };
}

export function generateEnsemblePrediction(result: MatchupResult): EnsemblePrediction {
  const modelPredictions = MODELS.map((model) => generateMLPrediction(result, model.name));

  const avgWinProbA = modelPredictions.reduce((sum, pred) => sum + pred.winProbA, 0) / modelPredictions.length;
  const avgWinProbB = 1 - avgWinProbA;

  let avgScoreA: number | null = null;
  let avgScoreB: number | null = null;

  if (result.projectedScoreA !== null && result.projectedScoreB !== null) {
    const scores = modelPredictions.filter((p) => p.projectedScoreA !== null && p.projectedScoreB !== null);
    if (scores.length > 0) {
      avgScoreA = scores.reduce((sum, p) => sum + (p.projectedScoreA || 0), 0) / scores.length;
      avgScoreB = scores.reduce((sum, p) => sum + (p.projectedScoreB || 0), 0) / scores.length;
      avgScoreA = Math.round(avgScoreA * 10) / 10;
      avgScoreB = Math.round(avgScoreB * 10) / 10;
    }
  }

  // Calculate agreement - standard deviation of predictions
  const stdDev = Math.sqrt(
    modelPredictions.reduce((sum, pred) => sum + Math.pow(pred.winProbA - avgWinProbA, 2), 0) / modelPredictions.length
  );
  const modelAgreement = Math.max(0, 100 - stdDev * 400); // convert to 0-100 scale

  return {
    models: modelPredictions,
    consensus: {
      winProbA: Math.round(avgWinProbA * 1000) / 1000,
      winProbB: Math.round(avgWinProbB * 1000) / 1000,
      projectedScoreA: avgScoreA,
      projectedScoreB: avgScoreB,
    },
    modelAgreement: Math.round(modelAgreement),
    recommendation: getEnsembleRecommendation(modelAgreement, avgWinProbA, modelPredictions),
  };
}

function generateKeyFactors(sport: SportCode): { factor: string; impact: number }[] {
  const allFactors: Record<string, number> = {
    "Recent Form": (Math.random() - 0.5) * 0.8,
    "Head-to-Head History": (Math.random() - 0.5) * 0.6,
    "Home Court Advantage": Math.random() * 0.4,
    "Rest Days": (Math.random() - 0.5) * 0.5,
    "Injury Impact": -(Math.random() * 0.7),
    "Offensive Efficiency": Math.random() * 0.6,
    "Defensive Rating": Math.random() * 0.5,
    "Pace of Play": (Math.random() - 0.5) * 0.4,
    "Matchup Advantage": (Math.random() - 0.5) * 0.7,
  };

  return Object.entries(allFactors)
    .sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]))
    .slice(0, 5)
    .map(([factor, impact]) => ({
      factor,
      impact: Math.round(impact * 100) / 100,
    }));
}

function getEnsembleRecommendation(
  agreement: number,
  winProbA: number,
  models: MLPrediction[]
): string {
  const highConfidence = models.filter((m) => m.confidence > 70).length;
  const totalModels = models.length;

  if (agreement > 80 && highConfidence === totalModels) {
    const favoredSide = winProbA > 0.55 ? "Team A" : winProbA < 0.45 ? "Team B" : "neither side";
    return `High confidence prediction with ${agreement.toFixed(0)}% model agreement. All models favor ${favoredSide}.`;
  }

  if (agreement > 60) {
    return `Models show moderate agreement (${agreement.toFixed(0)}%). ${highConfidence}/${totalModels} models have high confidence.`;
  }

  return `Low model agreement (${agreement.toFixed(0)}%). High uncertainty - consider waiting for more data or avoiding this matchup.`;
}

export function compareModelToMarket(
  mlPrediction: MLPrediction,
  marketOdds: number // decimal odds
): { edge: number; recommendation: string } {
  const marketImpliedProb = 1 / marketOdds;
  const modelProb = mlPrediction.winProbA;
  const edge = (modelProb - marketImpliedProb) * 100;

  let recommendation = "";

  if (edge > 5) {
    recommendation = `Strong edge detected: Model sees ${(modelProb * 100).toFixed(1)}% vs market's ${(marketImpliedProb * 100).toFixed(1)}%. Consider betting.`;
  } else if (edge > 2) {
    recommendation = `Slight edge: Model is ${edge.toFixed(1)}% higher than market. Proceed with caution.`;
  } else if (edge < -5) {
    recommendation = `Negative edge: Market is significantly more favorable to this side than our model suggests. Avoid.`;
  } else {
    recommendation = `No significant edge. Market odds align with model prediction.`;
  }

  return { edge: Math.round(edge * 100) / 100, recommendation };
}
