import type { OddsData, PublicBettingData, LineMovement } from "./extended-types";

// Mock real-time odds data generator
// In production, this would connect to odds APIs like The Odds API, OddsJam, etc.
export function generateMockOdds(teamAName: string, teamBName: string): OddsData[] {
  const baseSpread = Math.random() * 7 - 3.5; // -3.5 to +3.5
  const baseTotal = 210 + Math.random() * 20; // 210-230
  
  return [
    {
      sportsbook: "DraftKings",
      moneylineA: -150 + Math.floor(Math.random() * 30),
      moneylineB: 130 + Math.floor(Math.random() * 30),
      spreadA: Math.round(baseSpread * 2) / 2,
      spreadOddsA: -110,
      spreadB: -Math.round(baseSpread * 2) / 2,
      spreadOddsB: -110,
      total: Math.round(baseTotal * 2) / 2,
      overOdds: -115,
      underOdds: -105,
      lastUpdated: new Date().toISOString()
    },
    {
      sportsbook: "FanDuel",
      moneylineA: -145 + Math.floor(Math.random() * 30),
      moneylineB: 135 + Math.floor(Math.random() * 30),
      spreadA: Math.round(baseSpread * 2) / 2,
      spreadOddsA: -108,
      spreadB: -Math.round(baseSpread * 2) / 2,
      spreadOddsB: -112,
      total: Math.round((baseTotal + 1) * 2) / 2,
      overOdds: -110,
      underOdds: -110,
      lastUpdated: new Date().toISOString()
    },
    {
      sportsbook: "BetMGM",
      moneylineA: -155 + Math.floor(Math.random() * 30),
      moneylineB: 125 + Math.floor(Math.random() * 30),
      spreadA: Math.round((baseSpread - 0.5) * 2) / 2,
      spreadOddsA: -112,
      spreadB: -Math.round((baseSpread - 0.5) * 2) / 2,
      spreadOddsB: -108,
      total: Math.round((baseTotal - 1) * 2) / 2,
      overOdds: -105,
      underOdds: -115,
      lastUpdated: new Date().toISOString()
    },
    {
      sportsbook: "Caesars",
      moneylineA: -148 + Math.floor(Math.random() * 30),
      moneylineB: 128 + Math.floor(Math.random() * 30),
      spreadA: Math.round(baseSpread * 2) / 2,
      spreadOddsA: -110,
      spreadOddsB: -110,
      spreadB: -Math.round(baseSpread * 2) / 2,
      total: Math.round(baseTotal * 2) / 2,
      overOdds: -112,
      underOdds: -108,
      lastUpdated: new Date().toISOString()
    },
    {
      sportsbook: "ESPN BET",
      moneylineA: -152 + Math.floor(Math.random() * 30),
      moneylineB: 132 + Math.floor(Math.random() * 30),
      spreadA: Math.round(baseSpread * 2) / 2,
      spreadOddsA: -110,
      spreadB: -Math.round(baseSpread * 2) / 2,
      spreadOddsB: -110,
      total: Math.round((baseTotal + 0.5) * 2) / 2,
      overOdds: -110,
      underOdds: -110,
      lastUpdated: new Date().toISOString()
    }
  ];
}

export function findBestOdds(oddsArray: OddsData[]): {
  bestMoneylineA: OddsData;
  bestMoneylineB: OddsData;
  bestSpreadA: OddsData;
  bestSpreadB: OddsData;
  bestOver: OddsData;
  bestUnder: OddsData;
} {
  return {
    bestMoneylineA: oddsArray.reduce((best, curr) => 
      curr.moneylineA > best.moneylineA ? curr : best
    ),
    bestMoneylineB: oddsArray.reduce((best, curr) => 
      curr.moneylineB > best.moneylineB ? curr : best
    ),
    bestSpreadA: oddsArray.reduce((best, curr) => 
      curr.spreadOddsA > best.spreadOddsA ? curr : best
    ),
    bestSpreadB: oddsArray.reduce((best, curr) => 
      curr.spreadOddsB > best.spreadOddsB ? curr : best
    ),
    bestOver: oddsArray.reduce((best, curr) => 
      curr.overOdds > best.overOdds ? curr : best
    ),
    bestUnder: oddsArray.reduce((best, curr) => 
      curr.underOdds > best.underOdds ? curr : best
    )
  };
}

export function generatePublicBettingData(): PublicBettingData {
  const betsA = 45 + Math.random() * 20; // 45-65%
  const moneyA = 40 + Math.random() * 25; // 40-65%
  
  // Sharp action when money % differs significantly from bets %
  const diff = Math.abs(moneyA - betsA);
  let sharpAction: "A" | "B" | "none" = "none";
  
  if (diff > 10) {
    sharpAction = moneyA > betsA ? "A" : "B";
  }
  
  return {
    teamA: {
      betsPercentage: Math.round(betsA * 10) / 10,
      moneyPercentage: Math.round(moneyA * 10) / 10
    },
    teamB: {
      betsPercentage: Math.round((100 - betsA) * 10) / 10,
      moneyPercentage: Math.round((100 - moneyA) * 10) / 10
    },
    sharpAction
  };
}

export function generateLineMovements(): LineMovement[] {
  const now = new Date();
  const movements: LineMovement[] = [];
  
  // Generate 5-10 line movements over the past 24 hours
  const count = 5 + Math.floor(Math.random() * 6);
  
  for (let i = 0; i < count; i++) {
    const hoursAgo = Math.random() * 24;
    const timestamp = new Date(now.getTime() - hoursAgo * 60 * 60 * 1000).toISOString();
    
    const types: ("spread" | "total" | "moneyline")[] = ["spread", "total", "moneyline"];
    const type = types[Math.floor(Math.random() * types.length)];
    
    let oldValue: number, newValue: number;
    
    if (type === "spread") {
      oldValue = -3.5;
      newValue = -4.0;
    } else if (type === "total") {
      oldValue = 215.5;
      newValue = 217.0;
    } else {
      oldValue = -150;
      newValue = -165;
    }
    
    movements.push({
      timestamp,
      type,
      oldValue,
      newValue,
      direction: newValue > oldValue ? "up" : "down",
      sportsbook: ["DraftKings", "FanDuel", "BetMGM"][Math.floor(Math.random() * 3)]
    });
  }
  
  return movements.sort((a, b) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
}

// Calculate if there's betting value compared to our model
export function calculateBettingValue(
  modelWinProb: number,
  marketOdds: number
): {
  hasValue: boolean;
  edge: number;
  expectedValue: number;
} {
  // Convert market odds to implied probability
  const decimal = marketOdds > 0 ? (marketOdds / 100) + 1 : (100 / Math.abs(marketOdds)) + 1;
  const marketProb = (1 / decimal) * 100;
  
  // Edge = model probability - market probability
  const edge = modelWinProb - marketProb;
  
  // Positive EV if our model probability is higher than market
  const hasValue = edge > 2; // Require at least 2% edge
  
  // Calculate EV on $100 bet
  const stake = 100;
  const winAmount = stake * (decimal - 1);
  const expectedValue = (modelWinProb / 100) * winAmount - ((100 - modelWinProb) / 100) * stake;
  
  return {
    hasValue,
    edge: Math.round(edge * 10) / 10,
    expectedValue: Math.round(expectedValue * 100) / 100
  };
}
