// Sentiment Analysis from Sports News & Social Media
import type { SportCode } from "./types";

export type SentimentScore = {
  positive: number; // 0-100
  negative: number; // 0-100
  neutral: number; // 0-100
  overall: number; // -1 to 1
};

export type SentimentSource = {
  platform: "Twitter" | "Reddit" | "News" | "Betting Forums" | "Expert Picks";
  sentiment: SentimentScore;
  volume: number; // number of mentions
  trending: boolean;
  topKeywords: string[];
};

export type TeamSentiment = {
  teamId: string;
  teamName: string;
  sport: SportCode;
  overallSentiment: SentimentScore;
  sources: SentimentSource[];
  momentum: "Rising" | "Falling" | "Stable";
  publicPerception: "Overrated" | "Underrated" | "Fairly Rated";
  lastUpdated: Date;
};

export type MatchupSentiment = {
  teamA: TeamSentiment;
  teamB: TeamSentiment;
  favoredByPublic: "A" | "B" | "Even";
  sentimentEdge: number; // -100 to 100, positive favors A
  narratives: string[];
  recommendation: string;
};

// Mock sentiment generator
export function getTeamSentiment(
  teamId: string,
  sport: SportCode
): TeamSentiment {
  const sources: SentimentSource[] = [
    generateSourceSentiment("Twitter"),
    generateSourceSentiment("Reddit"),
    generateSourceSentiment("News"),
    generateSourceSentiment("Betting Forums"),
    generateSourceSentiment("Expert Picks"),
  ];

  const overallSentiment = calculateOverallSentiment(sources);
  const momentum = calculateMomentum(overallSentiment);
  const publicPerception = determinePublicPerception(overallSentiment);

  return {
    teamId,
    teamName: teamId.split("-")[1] || "Team",
    sport,
    overallSentiment,
    sources,
    momentum,
    publicPerception,
    lastUpdated: new Date(),
  };
}

function generateSourceSentiment(
  platform: "Twitter" | "Reddit" | "News" | "Betting Forums" | "Expert Picks"
): SentimentSource {
  const positive = Math.random() * 100;
  const negative = Math.random() * (100 - positive);
  const neutral = 100 - positive - negative;

  const overall = (positive - negative) / 100;

  const keywords = [
    "dominant",
    "momentum",
    "injury concerns",
    "hot streak",
    "struggling",
    "underdog",
    "favorite",
    "value bet",
    "overvalued",
    "sharp play",
  ];

  const topKeywords = keywords
    .sort(() => Math.random() - 0.5)
    .slice(0, 3);

  return {
    platform,
    sentiment: {
      positive: Math.round(positive),
      negative: Math.round(negative),
      neutral: Math.round(neutral),
      overall: Math.round(overall * 100) / 100,
    },
    volume: Math.floor(Math.random() * 10000) + 500,
    trending: Math.random() > 0.7,
    topKeywords,
  };
}

function calculateOverallSentiment(sources: SentimentSource[]): SentimentScore {
  const totalVolume = sources.reduce((sum, s) => sum + s.volume, 0);

  let weightedPositive = 0;
  let weightedNegative = 0;
  let weightedNeutral = 0;

  sources.forEach((source) => {
    const weight = source.volume / totalVolume;
    weightedPositive += source.sentiment.positive * weight;
    weightedNegative += source.sentiment.negative * weight;
    weightedNeutral += source.sentiment.neutral * weight;
  });

  const overall = (weightedPositive - weightedNegative) / 100;

  return {
    positive: Math.round(weightedPositive),
    negative: Math.round(weightedNegative),
    neutral: Math.round(weightedNeutral),
    overall: Math.round(overall * 100) / 100,
  };
}

function calculateMomentum(sentiment: SentimentScore): "Rising" | "Falling" | "Stable" {
  // Simulate momentum based on sentiment
  if (sentiment.overall > 0.3) return "Rising";
  if (sentiment.overall < -0.3) return "Falling";
  return "Stable";
}

function determinePublicPerception(sentiment: SentimentScore): "Overrated" | "Underrated" | "Fairly Rated" {
  // Mock logic - in reality would compare to actual performance metrics
  if (sentiment.overall > 0.5) return "Overrated";
  if (sentiment.overall < -0.2) return "Underrated";
  return "Fairly Rated";
}

export function getMatchupSentiment(
  teamAId: string,
  teamBId: string,
  sport: SportCode
): MatchupSentiment {
  const teamA = getTeamSentiment(teamAId, sport);
  const teamB = getTeamSentiment(teamBId, sport);

  const sentimentEdge = (teamA.overallSentiment.overall - teamB.overallSentiment.overall) * 50;

  const favoredByPublic: "A" | "B" | "Even" = 
    sentimentEdge > 10 ? "A" : 
    sentimentEdge < -10 ? "B" : 
    "Even";

  const narratives = generateNarratives(teamA, teamB);

  return {
    teamA,
    teamB,
    favoredByPublic,
    sentimentEdge: Math.round(sentimentEdge),
    narratives,
    recommendation: getSentimentRecommendation(teamA, teamB, sentimentEdge),
  };
}

function generateNarratives(teamA: TeamSentiment, teamB: TeamSentiment): string[] {
  const narratives: string[] = [];

  if (teamA.momentum === "Rising" && teamB.momentum === "Falling") {
    narratives.push(`${teamA.teamName} riding momentum wave while ${teamB.teamName} trending downward`);
  }

  if (teamA.publicPerception === "Underrated") {
    narratives.push(`Public sleeping on ${teamA.teamName} - potential value play`);
  }

  if (teamB.publicPerception === "Overrated") {
    narratives.push(`${teamB.teamName} may be overvalued by public sentiment`);
  }

  const trendingTeam = teamA.sources.some((s) => s.trending) ? teamA.teamName :
                       teamB.sources.some((s) => s.trending) ? teamB.teamName : null;

  if (trendingTeam) {
    narratives.push(`${trendingTeam} generating significant social media buzz`);
  }

  if (narratives.length === 0) {
    narratives.push("Sentiment relatively balanced between both teams");
  }

  return narratives;
}

function getSentimentRecommendation(
  teamA: TeamSentiment,
  teamB: TeamSentiment,
  edge: number
): string {
  if (Math.abs(edge) < 5) {
    return "Sentiment is neutral. Public has no strong opinion on either side.";
  }

  const favoredTeam = edge > 0 ? teamA.teamName : teamB.teamName;
  const favoredSentiment = edge > 0 ? teamA : teamB;

  if (favoredSentiment.publicPerception === "Overrated") {
    return `Public heavily favors ${favoredTeam}, but sentiment analysis suggests they may be overrated. Consider fading the public.`;
  }

  if (favoredSentiment.momentum === "Rising") {
    return `${favoredTeam} has strong positive momentum in public perception. Narrative aligns with potential performance.`;
  }

  return `Public sentiment leans toward ${favoredTeam}. Monitor if this creates value on the other side.`;
}

export function getSentimentSummary(matchupSentiment: MatchupSentiment): string {
  const { teamA, teamB, favoredByPublic, sentimentEdge } = matchupSentiment;

  if (favoredByPublic === "Even") {
    return "Public sentiment is evenly split between both teams.";
  }

  const favored = favoredByPublic === "A" ? teamA : teamB;
  const edgeMagnitude = Math.abs(sentimentEdge);

  if (edgeMagnitude > 30) {
    return `Strong public sentiment favoring ${favored.teamName} (${edgeMagnitude}% edge). Heavy narrative bias detected.`;
  }

  return `Public leans toward ${favored.teamName} (${edgeMagnitude}% edge). Moderate sentiment advantage.`;
}
