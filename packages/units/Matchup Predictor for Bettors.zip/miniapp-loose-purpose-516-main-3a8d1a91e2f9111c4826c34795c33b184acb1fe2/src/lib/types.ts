export type SportCode =
  | "NFL"
  | "NBA"
  | "NCAAB"
  | "NCAAF"
  | "MLB"
  | "NHL"
  | "SOCCER"
  | "UFC"
  | "OTHER";

export type TeamEntry = {
  id: string;
  sport: SportCode;
  name: string;      // "Lakers", "Patriots", "Duke", etc.
  displayName: string; // "Los Angeles Lakers", "New England Patriots"
  rating: number;   // simple ELO-like rating (e.g. 1300–1800)
};

export type MatchupRequest = {
  sport: SportCode;
  teamAId: string;
  teamBId: string;
  neutralSite: boolean;
  // optional market context
  marketSpread?: number;   // spread for team A (e.g. -3.5 means A favored)
  marketTotal?: number;    // game total (e.g. 215.5)
};

export type MatchupResult = {
  sport: SportCode;
  teamAName: string;
  teamBName: string;

  winProbA: number;       // 0–1
  winProbB: number;       // 0–1 (1 - winProbA)

  projectedScoreA: number | null; // null if not a scoring sport (e.g. UFC)
  projectedScoreB: number | null;

  fairDecimalA: number;   // 1 / winProbA
  fairDecimalB: number;   // 1 / winProbB
  fairAmericanA: number;  // converted from decimal
  fairAmericanB: number;

  upsetProbability: number; // underdog's winProb
  favoredTeam: "A" | "B" | "even";

  paceNotes: string;
  styleNotes: string[];
  keyEdges: string[];
  leanSummary: string;    // textual explanation (ML vs spread vs total)

  // Optional value comparison vs market
  edgeVsSpread?: string;
  edgeVsTotal?: string;
};

export type SimulationResult = {
  iterations: number;
  winsA: number;
  winsB: number;
  winPctA: number;
  winPctB: number;
  avgScoreA: number | null;
  avgScoreB: number | null;
  blowoutPctA: number;
  blowoutPctB: number;
  closeGamePct: number;
  chaosIndex: number;
};
