// Weather Integration for Outdoor Sports
import type { SportCode } from "./types";

export type WeatherCondition = "Clear" | "Cloudy" | "Rain" | "Snow" | "Wind" | "Dome";

export type WeatherData = {
  condition: WeatherCondition;
  temperature: number; // Fahrenheit
  windSpeed: number; // mph
  precipitation: number; // %
  impact: "High" | "Medium" | "Low" | "None";
  recommendation: string;
};

export type GameLocation = {
  city: string;
  state: string;
  isDome: boolean;
};

// Mock weather data generator - in production, integrate with weather API
export function getWeatherForGame(
  sport: SportCode,
  location: GameLocation,
  gameDate?: Date
): WeatherData {
  // Dome/indoor venues
  if (location.isDome || sport === "NBA" || sport === "NHL") {
    return {
      condition: "Dome",
      temperature: 72,
      windSpeed: 0,
      precipitation: 0,
      impact: "None",
      recommendation: "Indoor game - weather has no impact on gameplay.",
    };
  }

  // Outdoor sports - simulate weather
  const conditions: WeatherCondition[] = ["Clear", "Cloudy", "Rain", "Snow", "Wind"];
  const randomCondition = conditions[Math.floor(Math.random() * conditions.length)];
  
  const baseTemp = sport === "NFL" || sport === "NCAAF" ? 55 : 75;
  const temp = baseTemp + (Math.random() * 30 - 15);
  const wind = Math.random() * 25;
  const precip = randomCondition === "Rain" ? 60 + Math.random() * 40 : 
                 randomCondition === "Snow" ? 70 + Math.random() * 30 : 
                 Math.random() * 20;

  return {
    condition: randomCondition,
    temperature: Math.round(temp),
    windSpeed: Math.round(wind),
    precipitation: Math.round(precip),
    impact: calculateWeatherImpact(sport, randomCondition, wind, precip),
    recommendation: getWeatherRecommendation(sport, randomCondition, wind, precip),
  };
}

function calculateWeatherImpact(
  sport: SportCode,
  condition: WeatherCondition,
  wind: number,
  precip: number
): "High" | "Medium" | "Low" | "None" {
  if (sport === "NFL" || sport === "NCAAF") {
    if (condition === "Snow" || (condition === "Rain" && precip > 70)) return "High";
    if (wind > 20 || precip > 40) return "Medium";
    return "Low";
  }

  if (sport === "MLB") {
    if (wind > 15 || (condition === "Rain" && precip > 50)) return "Medium";
    return "Low";
  }

  if (sport === "SOCCER") {
    if (condition === "Rain" && precip > 60) return "Medium";
    return "Low";
  }

  return "None";
}

function getWeatherRecommendation(
  sport: SportCode,
  condition: WeatherCondition,
  wind: number,
  precip: number
): string {
  if (sport === "NFL" || sport === "NCAAF") {
    if (condition === "Snow") {
      return "Heavy snow favors run-heavy offenses and unders. Passing efficiency drops significantly.";
    }
    if (condition === "Rain" && precip > 70) {
      return "Rain reduces passing accuracy and scoring. Lean towards unders and ground game.";
    }
    if (wind > 20) {
      return "High winds affect deep passes and field goals. Consider under and run-focused teams.";
    }
    return "Moderate weather conditions. Minor impact on gameplay expected.";
  }

  if (sport === "MLB") {
    if (wind > 15) {
      return "Strong winds can boost home runs if blowing out, or suppress scoring if blowing in.";
    }
    if (condition === "Rain") {
      return "Rain may delay or postpone game. Check lineups and pitcher adjustments.";
    }
  }

  if (sport === "SOCCER") {
    if (condition === "Rain" && precip > 60) {
      return "Wet conditions favor possession teams and reduce goal scoring slightly.";
    }
  }

  return "Weather conditions are favorable and unlikely to significantly impact gameplay.";
}

export const locationData: Record<string, GameLocation> = {
  // NFL
  "nfl-chiefs": { city: "Kansas City", state: "MO", isDome: false },
  "nfl-eagles": { city: "Philadelphia", state: "PA", isDome: false },
  "nfl-cowboys": { city: "Arlington", state: "TX", isDome: true },
  "nfl-packers": { city: "Green Bay", state: "WI", isDome: false },
  
  // NBA - all indoor
  "nba-lakers": { city: "Los Angeles", state: "CA", isDome: true },
  "nba-celtics": { city: "Boston", state: "MA", isDome: true },
  
  // MLB
  "mlb-yankees": { city: "New York", state: "NY", isDome: false },
  "mlb-dodgers": { city: "Los Angeles", state: "CA", isDome: false },
  
  // Soccer
  "soccer-barca": { city: "Barcelona", state: "Spain", isDome: false },
  "soccer-madrid": { city: "Madrid", state: "Spain", isDome: false },
};
