import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { calculateAnalytics } from '@/lib/analytics-engine';

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const searchParams = request.nextUrl.searchParams;
    const period = searchParams.get('period') as "week" | "month" | "quarter" | "year" | "all" || 'all';

    const analytics = calculateAnalytics(period);

    return NextResponse.json({ analytics });
  } catch (error) {
    console.error('Analytics calculation error:', error);
    return NextResponse.json(
      { error: 'Failed to calculate analytics' },
      { status: 500 }
    );
  }
}
