import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import type { TrendingTopic } from '@/types';

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const searchParams = request.nextUrl.searchParams;
    const source = searchParams.get('source') || 'all';

    const trends = await fetchTrendingTopics(source);

    return NextResponse.json({ trends });
  } catch (error) {
    console.error('Culture pulse error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch trending topics' },
      { status: 500 }
    );
  }
}

async function fetchTrendingTopics(source: string): Promise<TrendingTopic[]> {
  const now = new Date().toISOString();
  
  const mockTrends: TrendingTopic[] = [
    {
      id: '1',
      topic: 'Base Mainnet Launch',
      description: 'Base scaling to millions with new optimizations',
      momentum: 95,
      category: 'Infrastructure',
      relatedKeywords: ['base', 'l2', 'scaling', 'onchain'],
      source: 'x',
      detectedAt: now,
    },
    {
      id: '2',
      topic: 'ZK-Rollup Innovation',
      description: 'New zero-knowledge proof systems improving privacy',
      momentum: 87,
      category: 'Technology',
      relatedKeywords: ['zk', 'privacy', 'zkp', 'rollups'],
      source: 'farcaster',
      detectedAt: now,
    },
    {
      id: '3',
      topic: 'AI Agent Economy',
      description: 'Autonomous agents trading and building onchain',
      momentum: 92,
      category: 'AI',
      relatedKeywords: ['ai', 'agents', 'autonomous', 'bots'],
      source: 'web',
      detectedAt: now,
    },
    {
      id: '4',
      topic: 'Meme Coin Season',
      description: 'New wave of community-driven tokens launching',
      momentum: 78,
      category: 'Culture',
      relatedKeywords: ['memecoin', 'launch', 'community', 'degen'],
      source: 'x',
      detectedAt: now,
    },
    {
      id: '5',
      topic: 'Onchain Gaming',
      description: 'Fully onchain games gaining traction',
      momentum: 72,
      category: 'Gaming',
      relatedKeywords: ['gaming', 'onchain', 'nft', 'play'],
      source: 'farcaster',
      detectedAt: now,
    },
    {
      id: '6',
      topic: 'DeFi 3.0',
      description: 'Next generation of decentralized finance protocols',
      momentum: 85,
      category: 'DeFi',
      relatedKeywords: ['defi', 'yield', 'protocol', 'liquidity'],
      source: 'web',
      detectedAt: now,
    },
  ];

  if (source === 'all') {
    return mockTrends;
  }

  return mockTrends.filter((t: TrendingTopic) => t.source === source);
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.json();
    const { query } = body;

    if (!query || typeof query !== 'string') {
      return NextResponse.json(
        { error: 'Query is required' },
        { status: 400 }
      );
    }

    const trends = await searchTrendingTopics(query);

    return NextResponse.json({ trends });
  } catch (error) {
    console.error('Culture pulse search error:', error);
    return NextResponse.json(
      { error: 'Failed to search trending topics' },
      { status: 500 }
    );
  }
}

async function searchTrendingTopics(query: string): Promise<TrendingTopic[]> {
  const allTrends = await fetchTrendingTopics('all');
  const lowerQuery = query.toLowerCase();

  return allTrends.filter((trend: TrendingTopic) => {
    return (
      trend.topic.toLowerCase().includes(lowerQuery) ||
      trend.description.toLowerCase().includes(lowerQuery) ||
      trend.relatedKeywords.some((kw: string) => kw.toLowerCase().includes(lowerQuery))
    );
  });
}
