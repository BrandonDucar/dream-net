import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.json();
    const { text, embeds, signerUuid, fid } = body;

    if (!text || !signerUuid || !fid) {
      return NextResponse.json(
        { error: 'Missing required parameters' },
        { status: 400 }
      );
    }

    const castData = {
      signerUuid,
      text,
      embeds: embeds || [],
    };

    const response = await fetch('/api/proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        protocol: 'https',
        origin: 'api.neynar.com',
        path: '/v2/farcaster/cast',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: castData,
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      return NextResponse.json(
        { error: `Failed to post to Farcaster: ${error}` },
        { status: response.status }
      );
    }

    const result = await response.json();

    return NextResponse.json({
      success: true,
      castHash: result.cast?.hash,
      castUrl: `https://warpcast.com/${result.cast?.author?.username}/${result.cast?.hash}`,
    });
  } catch (error) {
    console.error('Farcaster post error:', error);
    return NextResponse.json(
      { error: 'Failed to post to Farcaster' },
      { status: 500 }
    );
  }
}
