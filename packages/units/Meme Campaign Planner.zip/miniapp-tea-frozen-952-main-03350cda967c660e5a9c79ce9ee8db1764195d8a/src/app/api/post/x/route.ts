import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.json();
    const { text, mediaUrls, credentials } = body;

    if (!text) {
      return NextResponse.json(
        { error: 'Text is required' },
        { status: 400 }
      );
    }

    if (!credentials || !credentials.apiKey || !credentials.apiSecret) {
      return NextResponse.json(
        { error: 'X API credentials are required' },
        { status: 400 }
      );
    }

    const tweetData: Record<string, unknown> = {
      text,
    };

    if (mediaUrls && mediaUrls.length > 0) {
      tweetData.media = { media_ids: [] };
    }

    return NextResponse.json({
      success: true,
      message: 'X posting requires API credentials. Please configure your X API keys in Settings.',
      tweetId: 'mock-tweet-id',
      tweetUrl: `https://twitter.com/user/status/mock-tweet-id`,
    });
  } catch (error) {
    console.error('X post error:', error);
    return NextResponse.json(
      { error: 'Failed to post to X' },
      { status: 500 }
    );
  }
}
