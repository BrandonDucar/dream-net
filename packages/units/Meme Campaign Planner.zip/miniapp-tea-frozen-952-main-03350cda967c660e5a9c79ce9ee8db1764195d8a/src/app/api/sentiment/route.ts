import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { analyzeSentiment } from '@/lib/sentiment-analyzer';

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.json();
    const { text } = body;

    if (!text || typeof text !== 'string') {
      return NextResponse.json(
        { error: 'Text is required' },
        { status: 400 }
      );
    }

    const sentiment = analyzeSentiment(text);

    return NextResponse.json({ sentiment });
  } catch (error) {
    console.error('Sentiment analysis error:', error);
    return NextResponse.json(
      { error: 'Failed to analyze sentiment' },
      { status: 500 }
    );
  }
}
