'use client'
import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { CampaignDashboard } from '@/components/campaign-dashboard';
import { MemeLibrary } from '@/components/meme-library';
import { CampaignDetail } from '@/components/campaign-detail';
import { AddMemeDialog } from '@/components/add-meme-dialog';
import { CreateCampaignDialog } from '@/components/create-campaign-dialog';
import { AutoPlanDialog } from '@/components/auto-plan-dialog';
import { CulturePulseDashboard } from '@/components/culture-pulse-dashboard';
import { AnalyticsDashboard } from '@/components/analytics-dashboard';
import { CalendarView } from '@/components/calendar-view';
import { SettingsDialog } from '@/components/settings-dialog';
import { Zap, Settings as SettingsIcon } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type View = 'dashboard' | 'library' | 'detail';

export default function MemeCampaignConductor(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [activeTab, setActiveTab] = useState<string>('campaigns');
  const [selectedCampaignId, setSelectedCampaignId] = useState<string | null>(null);
  const [refreshTrigger, setRefreshTrigger] = useState<number>(0);
  
  const [isAddMemeOpen, setIsAddMemeOpen] = useState<boolean>(false);
  const [isCreateCampaignOpen, setIsCreateCampaignOpen] = useState<boolean>(false);
  const [isAutoPlanOpen, setIsAutoPlanOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [selectedMemeIds, setSelectedMemeIds] = useState<string[]>([]);

  const handleViewCampaign = (campaignId: string): void => {
    setSelectedCampaignId(campaignId);
    setCurrentView('detail');
  };

  const handleBackToDashboard = (): void => {
    setCurrentView('dashboard');
    setSelectedCampaignId(null);
    triggerRefresh();
  };

  const handleCreateCampaign = (): void => {
    setIsCreateCampaignOpen(true);
  };

  const handleAutoPlanFromDashboard = (): void => {
    setActiveTab('library');
  };

  const handleAutoPlanFromLibrary = (memeIds: string[]): void => {
    setSelectedMemeIds(memeIds);
    setIsAutoPlanOpen(true);
  };

  const triggerRefresh = (): void => {
    setRefreshTrigger((prev: number) => prev + 1);
  };

  const handleSuccess = (): void => {
    triggerRefresh();
    setActiveTab('campaigns');
  };

  if (currentView === 'detail' && selectedCampaignId) {
    return (
      <main className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-4 sm:p-6 lg:p-8">
        <div className="max-w-7xl mx-auto">
          <CampaignDetail
            campaignId={selectedCampaignId}
            onBack={handleBackToDashboard}
            onRefresh={triggerRefresh}
          />
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        <Card className="border-2">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-2">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
            </div>
            <CardTitle className="text-3xl font-bold">Meme Campaign Conductor</CardTitle>
            <CardDescription className="text-base">
              Plan, organize, and schedule your meme drops with tactical precision
            </CardDescription>
            <div className="mt-4">
              <button
                onClick={() => setIsSettingsOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm border rounded-lg hover:bg-gray-50 transition-colors"
              >
                <SettingsIcon className="w-4 h-4" />
                Settings
              </button>
            </div>
          </CardHeader>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
            <TabsTrigger value="library">Memes</TabsTrigger>
            <TabsTrigger value="pulse">Culture Pulse</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="calendar">Calendar</TabsTrigger>
          </TabsList>

          <TabsContent value="campaigns" className="mt-6">
            <CampaignDashboard
              onViewCampaign={handleViewCampaign}
              onCreateCampaign={handleCreateCampaign}
              onAutoPlan={handleAutoPlanFromDashboard}
              refreshTrigger={refreshTrigger}
            />
          </TabsContent>

          <TabsContent value="library" className="mt-6">
            <MemeLibrary
              onAddMeme={() => setIsAddMemeOpen(true)}
              onAutoPlanFromSelected={handleAutoPlanFromLibrary}
              refreshTrigger={refreshTrigger}
            />
          </TabsContent>

          <TabsContent value="pulse" className="mt-6">
            <CulturePulseDashboard />
          </TabsContent>

          <TabsContent value="analytics" className="mt-6">
            <AnalyticsDashboard />
          </TabsContent>

          <TabsContent value="calendar" className="mt-6">
            <CalendarView />
          </TabsContent>
        </Tabs>

        <AddMemeDialog
          isOpen={isAddMemeOpen}
          onClose={() => setIsAddMemeOpen(false)}
          onSuccess={triggerRefresh}
        />

        <CreateCampaignDialog
          isOpen={isCreateCampaignOpen}
          onClose={() => setIsCreateCampaignOpen(false)}
          onSuccess={handleSuccess}
        />

        <AutoPlanDialog
          isOpen={isAutoPlanOpen}
          onClose={() => setIsAutoPlanOpen(false)}
          onSuccess={handleSuccess}
          selectedMemeIds={selectedMemeIds}
        />

        <SettingsDialog
          isOpen={isSettingsOpen}
          onClose={() => setIsSettingsOpen(false)}
        />
      </div>
    </main>
  );
}
