'use client';

import { useState } from 'react';
import { addMeme } from '@/lib/campaign-logic';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';

interface AddMemeDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function AddMemeDialog({ isOpen, onClose, onSuccess }: AddMemeDialogProps) {
  const [title, setTitle] = useState<string>('');
  const [topic, setTopic] = useState<string>('');
  const [channelHints, setChannelHints] = useState<string>('');
  const [strengthScore, setStrengthScore] = useState<number>(0.7);
  const [notes, setNotes] = useState<string>('');

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    
    addMeme({
      title,
      topic,
      channelHints: channelHints.split(',').map((h: string) => h.trim()).filter((h: string) => h.length > 0),
      strengthScore,
      notes,
    });
    
    resetForm();
    onSuccess();
    onClose();
  };

  const resetForm = (): void => {
    setTitle('');
    setTopic('');
    setChannelHints('');
    setStrengthScore(0.7);
    setNotes('');
  };

  const handleClose = (): void => {
    resetForm();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Add New Meme</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              value={title}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTitle(e.target.value)}
              placeholder="e.g., Base Builder Summer"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="topic">Topic</Label>
            <Input
              id="topic"
              value={topic}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTopic(e.target.value)}
              placeholder="e.g., Base, DeFi, NFTs"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="channelHints">Channel Hints (comma-separated)</Label>
            <Input
              id="channelHints"
              value={channelHints}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setChannelHints(e.target.value)}
              placeholder="e.g., farcaster, x, zora"
            />
            <p className="text-xs text-gray-500">Suggested: x, farcaster, zora, base-feed</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="strengthScore">
              Strength Score: {(strengthScore * 100).toFixed(0)}%
            </Label>
            <Slider
              id="strengthScore"
              value={[strengthScore]}
              onValueChange={(values: number[]) => setStrengthScore(values[0])}
              min={0}
              max={1}
              step={0.05}
              className="py-4"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNotes(e.target.value)}
              placeholder="Internal notes about this meme..."
              rows={3}
            />
          </div>

          <div className="flex gap-2 pt-4">
            <Button type="button" variant="outline" onClick={handleClose} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" className="flex-1">
              Add Meme
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
