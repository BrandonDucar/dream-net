'use client'
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart3, TrendingUp, Users, Target, Activity, RefreshCw } from 'lucide-react';
import type { AnalyticsSummary } from '@/types';

export function AnalyticsDashboard(): JSX.Element {
  const [analytics, setAnalytics] = useState<AnalyticsSummary | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [period, setPeriod] = useState<"week" | "month" | "quarter" | "year" | "all">('month');

  useEffect(() => {
    fetchAnalytics();
  }, [period]);

  const fetchAnalytics = async (): Promise<void> => {
    try {
      setLoading(true);
      const response = await fetch(`/api/analytics/calculate?period=${period}`);
      if (!response.ok) throw new Error('Failed to fetch analytics');
      
      const data = await response.json();
      setAnalytics(data.analytics);
    } catch (error) {
      console.error('Failed to fetch analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading && !analytics) {
    return (
      <Card>
        <CardContent className="p-8 text-center text-gray-500">
          Loading analytics...
        </CardContent>
      </Card>
    );
  }

  if (!analytics) {
    return (
      <Card>
        <CardContent className="p-8 text-center text-gray-500">
          No analytics data available
        </CardContent>
      </Card>
    );
  }

  const statCards = [
    {
      title: 'Total Campaigns',
      value: analytics.totalCampaigns,
      subtitle: `${analytics.activeCampaigns} active`,
      icon: Target,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100',
    },
    {
      title: 'Total Memes',
      value: analytics.totalMemes,
      subtitle: 'In library',
      icon: BarChart3,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100',
    },
    {
      title: 'Total Drops',
      value: analytics.totalDrops,
      subtitle: `${analytics.scheduledDrops} scheduled`,
      icon: Activity,
      color: 'text-green-600',
      bgColor: 'bg-green-100',
    },
    {
      title: 'Avg Engagement',
      value: `${analytics.avgEngagementRate.toFixed(2)}%`,
      subtitle: `${analytics.growthRate >= 0 ? '+' : ''}${analytics.growthRate.toFixed(1)}% growth`,
      icon: TrendingUp,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100',
    },
    {
      title: 'Total Reach',
      value: analytics.totalReach.toLocaleString(),
      subtitle: 'Impressions',
      icon: Users,
      color: 'text-pink-600',
      bgColor: 'bg-pink-100',
    },
    {
      title: 'Total Engagements',
      value: analytics.totalEngagements.toLocaleString(),
      subtitle: 'Likes, shares, comments',
      icon: Activity,
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-100',
    },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Analytics Dashboard
              </CardTitle>
              <CardDescription>
                Performance metrics and insights
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Select value={period} onValueChange={(value: string) => setPeriod(value as typeof period)}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="week">Week</SelectItem>
                  <SelectItem value="month">Month</SelectItem>
                  <SelectItem value="quarter">Quarter</SelectItem>
                  <SelectItem value="year">Year</SelectItem>
                  <SelectItem value="all">All Time</SelectItem>
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                size="sm"
                onClick={fetchAnalytics}
                disabled={loading}
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {statCards.map((stat, idx) => (
          <Card key={idx}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                  <p className="text-xs text-gray-500 mt-1">{stat.subtitle}</p>
                </div>
                <div className={`${stat.bgColor} ${stat.color} p-3 rounded-lg`}>
                  <stat.icon className="w-6 h-6" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {analytics.topPerformingMeme && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Top Performing Meme</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <div className="bg-gradient-to-br from-yellow-400 to-orange-500 p-4 rounded-lg">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="font-semibold">{analytics.topPerformingMeme.title}</p>
                <p className="text-sm text-gray-600">{analytics.topPerformingMeme.topic}</p>
                <p className="text-xs text-gray-500 mt-1">
                  Strength Score: {(analytics.topPerformingMeme.strengthScore * 100).toFixed(0)}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {analytics.topPerformingChannel && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Top Performing Channel</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <div className="bg-gradient-to-br from-blue-400 to-purple-500 p-4 rounded-lg">
                <Target className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="font-semibold capitalize">{analytics.topPerformingChannel}</p>
                <p className="text-sm text-gray-600">Highest total engagement</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
