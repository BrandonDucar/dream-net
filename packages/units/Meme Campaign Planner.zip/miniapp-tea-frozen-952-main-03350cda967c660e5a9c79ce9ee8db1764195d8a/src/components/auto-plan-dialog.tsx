'use client';

import { useState, useEffect } from 'react';
import type { Cadence } from '@/types';
import { autoPlanCampaignFromMemes } from '@/lib/campaign-logic';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface AutoPlanDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  selectedMemeIds: string[];
}

export function AutoPlanDialog({ isOpen, onClose, onSuccess, selectedMemeIds }: AutoPlanDialogProps) {
  const [name, setName] = useState<string>('');
  const [startDate, setStartDate] = useState<string>('');
  const [cadence, setCadence] = useState<Cadence>('daily');

  useEffect(() => {
    if (isOpen) {
      const today = new Date().toISOString().split('T')[0];
      setStartDate(today);
    }
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    
    autoPlanCampaignFromMemes({
      name,
      memes: selectedMemeIds,
      preferredStartDate: new Date(startDate).toISOString(),
      preferredCadence: cadence,
    });
    
    resetForm();
    onSuccess();
    onClose();
  };

  const resetForm = (): void => {
    setName('');
    setStartDate('');
    setCadence('daily');
  };

  const handleClose = (): void => {
    resetForm();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Auto-Plan Campaign from Memes</DialogTitle>
        </DialogHeader>
        <div className="mb-4 p-3 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-900">
            <strong>{selectedMemeIds.length} memes</strong> selected. Theme, narrative hook, and target channels will be automatically inferred.
          </p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Campaign Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
              placeholder="e.g., Q1 Launch Wave"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="startDate">Start Date</Label>
            <Input
              id="startDate"
              type="date"
              value={startDate}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setStartDate(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="cadence">Preferred Cadence</Label>
            <Select value={cadence} onValueChange={(value: string) => setCadence(value as Cadence)}>
              <SelectTrigger id="cadence">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="slow-drip">Slow Drip (every 3 days)</SelectItem>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="burst">Burst (every 4 hours)</SelectItem>
                <SelectItem value="event-timed">Event-Timed (twice daily)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-2 pt-4">
            <Button type="button" variant="outline" onClick={handleClose} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" className="flex-1">
              Auto-Plan Campaign
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
