'use client'
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Calendar, ChevronLeft, ChevronRight } from 'lucide-react';
import { generateCalendarEvents, getEventsForMonth, groupEventsByDate } from '@/lib/calendar-utils';
import type { CalendarEvent } from '@/types';

export function CalendarView(): JSX.Element {
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [groupedEvents, setGroupedEvents] = useState<Record<string, CalendarEvent[]>>({});

  useEffect(() => {
    loadEvents();
  }, [currentDate]);

  const loadEvents = (): void => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const monthEvents = getEventsForMonth(year, month);
    setEvents(monthEvents);
    setGroupedEvents(groupEventsByDate(monthEvents));
  };

  const goToPreviousMonth = (): void => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const goToNextMonth = (): void => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const goToToday = (): void => {
    setCurrentDate(new Date());
  };

  const getDaysInMonth = (): number[] => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    return Array.from({ length: daysInMonth }, (_, i: number) => i + 1);
  };

  const getFirstDayOfMonth = (): number => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    return new Date(year, month, 1).getDay();
  };

  const formatDate = (day: number): string => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    return new Date(year, month, day).toISOString().split('T')[0];
  };

  const getEventsForDay = (day: number): CalendarEvent[] => {
    const dateKey = formatDate(day);
    return groupedEvents[dateKey] || [];
  };

  const isToday = (day: number): boolean => {
    const today = new Date();
    return (
      day === today.getDate() &&
      currentDate.getMonth() === today.getMonth() &&
      currentDate.getFullYear() === today.getFullYear()
    );
  };

  const monthName = currentDate.toLocaleString('default', { month: 'long', year: 'numeric' });
  const days = getDaysInMonth();
  const firstDay = getFirstDayOfMonth();
  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Content Calendar
              </CardTitle>
              <CardDescription>
                Visual timeline of all scheduled drops and campaigns
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={goToPreviousMonth}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={goToToday}>
                Today
              </Button>
              <Button variant="outline" size="sm" onClick={goToNextMonth}>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
          <div className="text-xl font-semibold text-center pt-2">
            {monthName}
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2 mb-2">
            {weekDays.map((day: string) => (
              <div
                key={day}
                className="text-center text-sm font-semibold text-gray-600 py-2"
              >
                {day}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-2">
            {Array.from({ length: firstDay }, (_, i: number) => (
              <div key={`empty-${i}`} className="aspect-square" />
            ))}
            
            {days.map((day: number) => {
              const dayEvents = getEventsForDay(day);
              const isTodayDate = isToday(day);
              
              return (
                <div
                  key={day}
                  className={`
                    border rounded-lg p-2 aspect-square overflow-hidden
                    ${isTodayDate ? 'border-blue-500 bg-blue-50' : 'border-gray-200'}
                    ${dayEvents.length > 0 ? 'hover:shadow-md cursor-pointer' : ''}
                    transition-all
                  `}
                >
                  <div className={`text-sm font-medium mb-1 ${isTodayDate ? 'text-blue-600' : ''}`}>
                    {day}
                  </div>
                  <div className="space-y-1">
                    {dayEvents.slice(0, 2).map((event: CalendarEvent) => (
                      <div
                        key={event.id}
                        className="text-xs p-1 rounded truncate"
                        style={{ backgroundColor: event.color, color: 'white' }}
                        title={event.title}
                      >
                        {event.type === 'drop' ? '📍' : '🎯'} {event.title}
                      </div>
                    ))}
                    {dayEvents.length > 2 && (
                      <div className="text-xs text-gray-500">
                        +{dayEvents.length - 2} more
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Upcoming Events</CardTitle>
          <CardDescription>
            Next scheduled drops and campaign milestones
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[300px]">
            {events.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No events scheduled for this month
              </div>
            ) : (
              <div className="space-y-3">
                {events.map((event: CalendarEvent) => (
                  <div
                    key={event.id}
                    className="flex items-center gap-3 p-3 border rounded-lg hover:shadow-sm transition-shadow"
                  >
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: event.color }}
                    />
                    <div className="flex-1">
                      <div className="font-medium">{event.title}</div>
                      <div className="text-sm text-gray-600">
                        {new Date(event.date).toLocaleDateString('en-US', {
                          weekday: 'short',
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </div>
                    </div>
                    <Badge variant="outline" className="capitalize">
                      {event.type.replace('_', ' ')}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
