'use client';

import { useState, useEffect } from 'react';
import type { Campaign, CampaignStatus } from '@/types';
import { getCampaigns } from '@/lib/campaign-logic';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Eye, Globe } from 'lucide-react';

interface CampaignDashboardProps {
  onViewCampaign: (campaignId: string) => void;
  onCreateCampaign: () => void;
  onAutoPlan: () => void;
  refreshTrigger: number;
}

export function CampaignDashboard({ 
  onViewCampaign, 
  onCreateCampaign, 
  onAutoPlan,
  refreshTrigger 
}: CampaignDashboardProps) {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [filter, setFilter] = useState<CampaignStatus | 'all'>('all');

  useEffect(() => {
    loadCampaigns();
  }, [filter, refreshTrigger]);

  const loadCampaigns = (): void => {
    const allCampaigns = getCampaigns();
    const filtered = filter === 'all' 
      ? allCampaigns 
      : allCampaigns.filter((c: Campaign) => c.status === filter);
    setCampaigns(filtered);
  };

  const getStatusColor = (status: CampaignStatus): string => {
    const colors: Record<CampaignStatus, string> = {
      planned: 'bg-blue-500',
      active: 'bg-green-500',
      cooldown: 'bg-yellow-500',
      archived: 'bg-gray-500',
    };
    return colors[status] || 'bg-gray-500';
  };

  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div className="flex gap-2 flex-wrap">
          <Button onClick={onCreateCampaign} className="gap-2">
            <Plus className="w-4 h-4" />
            Create Campaign
          </Button>
          <Button onClick={onAutoPlan} variant="outline" className="gap-2">
            <Plus className="w-4 h-4" />
            Auto-Plan from Memes
          </Button>
        </div>
        
        <Select value={filter} onValueChange={(value: string) => setFilter(value as CampaignStatus | 'all')}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Campaigns</SelectItem>
            <SelectItem value="planned">Planned</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="cooldown">Cooldown</SelectItem>
            <SelectItem value="archived">Archived</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {campaigns.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-gray-500">
            <p className="mb-4">No campaigns yet. Start by creating your first campaign or auto-planning from your meme library.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {campaigns.map((campaign: Campaign) => (
            <Card key={campaign.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex justify-between items-start gap-2">
                  <CardTitle className="text-lg">{campaign.name}</CardTitle>
                  <Badge className={getStatusColor(campaign.status)}>
                    {campaign.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm font-medium text-gray-600">Theme</p>
                  <p className="text-sm">{campaign.theme}</p>
                </div>
                
                <div>
                  <p className="text-sm font-medium text-gray-600">Dates</p>
                  <p className="text-sm">
                    {formatDate(campaign.startDate)}
                    {campaign.endDate && ` - ${formatDate(campaign.endDate)}`}
                  </p>
                </div>
                
                <div>
                  <p className="text-sm font-medium text-gray-600">Cadence</p>
                  <p className="text-sm capitalize">{campaign.cadence.replace('-', ' ')}</p>
                </div>
                
                <div className="flex flex-wrap gap-1">
                  {campaign.targetChannels.map((channel: string) => (
                    <Badge key={channel} variant="outline" className="text-xs">
                      {channel}
                    </Badge>
                  ))}
                </div>
                
                {campaign.geoTargeting && (
                  <div className="flex items-center gap-1 text-xs text-blue-600 pt-2 border-t">
                    <Globe className="w-3 h-3" />
                    <span>
                      {campaign.geoTargeting.regions.map((r: string) => r.replace('-', ' ')).join(', ')}
                    </span>
                  </div>
                )}
                
                <Button 
                  onClick={() => onViewCampaign(campaign.id)} 
                  className="w-full gap-2 mt-4"
                  variant="outline"
                >
                  <Eye className="w-4 h-4" />
                  View Details
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
