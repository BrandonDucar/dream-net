'use client';

import { useState, useEffect } from 'react';
import type { Campaign, Drop, Meme, CampaignStatus, Cadence } from '@/types';
import { getCampaignDetails, updateCampaignStatus, regenerateDropSchedule } from '@/lib/campaign-logic';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, RefreshCw, Globe, Clock } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { CollaborationPanel } from '@/components/collaboration-panel';
import { PostPreview } from '@/components/post-preview';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';

interface CampaignDetailProps {
  campaignId: string;
  onBack: () => void;
  onRefresh: () => void;
}

export function CampaignDetail({ campaignId, onBack, onRefresh }: CampaignDetailProps) {
  const [campaign, setCampaign] = useState<Campaign | undefined>(undefined);
  const [drops, setDrops] = useState<Drop[]>([]);
  const [memes, setMemes] = useState<Meme[]>([]);
  const [isRegenerateOpen, setIsRegenerateOpen] = useState<boolean>(false);
  const [newCadence, setNewCadence] = useState<Cadence>('daily');
  const [newStartDate, setNewStartDate] = useState<string>('');

  useEffect(() => {
    loadCampaignData();
  }, [campaignId]);

  const loadCampaignData = (): void => {
    const data = getCampaignDetails(campaignId);
    setCampaign(data.campaign);
    setDrops(data.drops);
    setMemes(data.memes);
    
    if (data.campaign) {
      setNewCadence(data.campaign.cadence);
      setNewStartDate(data.campaign.startDate.split('T')[0]);
    }
  };

  const handleStatusChange = (newStatus: string): void => {
    updateCampaignStatus(campaignId, newStatus as CampaignStatus);
    loadCampaignData();
    onRefresh();
  };

  const handleRegenerateSchedule = (): void => {
    regenerateDropSchedule(campaignId, newCadence, new Date(newStartDate).toISOString());
    loadCampaignData();
    setIsRegenerateOpen(false);
    onRefresh();
  };

  const formatDateTime = (dateString: string): string => {
    return new Date(dateString).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getPriorityColor = (priority: string): string => {
    const colors: Record<string, string> = {
      high: 'bg-red-500',
      normal: 'bg-blue-500',
      low: 'bg-gray-500',
    };
    return colors[priority] || 'bg-gray-500';
  };

  if (!campaign) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Campaign not found</p>
        <Button onClick={onBack} className="mt-4">Go Back</Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button onClick={onBack} variant="ghost" className="gap-2">
          <ArrowLeft className="w-4 h-4" />
          Back
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <CardTitle className="text-2xl">{campaign.name}</CardTitle>
            <div className="flex gap-2 flex-wrap">
              <Select value={campaign.status} onValueChange={handleStatusChange}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="planned">Planned</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="cooldown">Cooldown</SelectItem>
                  <SelectItem value="archived">Archived</SelectItem>
                </SelectContent>
              </Select>
              
              <Dialog open={isRegenerateOpen} onOpenChange={setIsRegenerateOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="gap-2">
                    <RefreshCw className="w-4 h-4" />
                    Regenerate Schedule
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Regenerate Drop Schedule</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="cadence">Cadence</Label>
                      <Select value={newCadence} onValueChange={(value: string) => setNewCadence(value as Cadence)}>
                        <SelectTrigger id="cadence">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="slow-drip">Slow Drip</SelectItem>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="burst">Burst</SelectItem>
                          <SelectItem value="event-timed">Event-Timed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="startDate">Start Date</Label>
                      <Input 
                        id="startDate"
                        type="date" 
                        value={newStartDate}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewStartDate(e.target.value)}
                      />
                    </div>
                    <Button onClick={handleRegenerateSchedule} className="w-full">
                      Regenerate
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <p className="text-sm font-medium text-gray-600">Theme</p>
              <p className="text-sm mt-1">{campaign.theme}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Cadence</p>
              <p className="text-sm mt-1 capitalize">{campaign.cadence.replace('-', ' ')}</p>
            </div>
          </div>
          
          <div>
            <p className="text-sm font-medium text-gray-600">Narrative Hook</p>
            <p className="text-sm mt-1">{campaign.narrativeHook}</p>
          </div>
          
          {campaign.seoDescription && (
            <div>
              <p className="text-sm font-medium text-gray-600">SEO Description</p>
              <p className="text-sm mt-1 text-gray-500">{campaign.seoDescription}</p>
            </div>
          )}
          
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <p className="text-sm font-medium text-gray-600">Start Date</p>
              <p className="text-sm mt-1">{formatDateTime(campaign.startDate)}</p>
            </div>
            {campaign.endDate && (
              <div>
                <p className="text-sm font-medium text-gray-600">End Date</p>
                <p className="text-sm mt-1">{formatDateTime(campaign.endDate)}</p>
              </div>
            )}
          </div>
          
          <div>
            <p className="text-sm font-medium text-gray-600 mb-2">Target Channels</p>
            <div className="flex flex-wrap gap-2">
              {campaign.targetChannels.map((channel: string) => (
                <Badge key={channel} variant="outline">
                  {channel}
                </Badge>
              ))}
            </div>
          </div>
          
          {campaign.geoTargeting && (
            <div className="pt-4 border-t">
              <div className="flex items-center gap-2 mb-3">
                <Globe className="w-4 h-4 text-blue-600" />
                <p className="text-sm font-medium text-gray-900">Geographic Targeting</p>
              </div>
              
              <div className="grid gap-3 md:grid-cols-3">
                <div>
                  <p className="text-xs font-medium text-gray-600">Target Regions</p>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {campaign.geoTargeting.regions.map((region: string) => (
                      <Badge key={region} variant="secondary" className="text-xs capitalize">
                        {region.replace('-', ' ')}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div>
                  <p className="text-xs font-medium text-gray-600">Primary Timezone</p>
                  <p className="text-sm mt-1">{campaign.geoTargeting.primaryTimezone}</p>
                </div>
                
                <div>
                  <p className="text-xs font-medium text-gray-600">Optimal Times</p>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {campaign.geoTargeting.optimalPostingTimes.slice(0, 3).map((time: string, idx: number) => (
                      <Badge key={idx} variant="outline" className="text-xs font-mono">
                        {time}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Attached Memes ({memes.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {memes.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No memes attached</p>
          ) : (
            <div className="grid gap-3 md:grid-cols-2">
              {memes.map((meme: Meme) => (
                <div key={meme.id} className="border rounded-lg p-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium">{meme.title}</p>
                      <p className="text-sm text-gray-600">{meme.topic}</p>
                    </div>
                    <Badge variant="outline" className="font-mono text-xs">
                      {(meme.strengthScore * 100).toFixed(0)}%
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Tabs defaultValue="schedule" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="schedule">Drop Schedule</TabsTrigger>
          <TabsTrigger value="collaboration">Collaboration</TabsTrigger>
          <TabsTrigger value="preview">Post Preview</TabsTrigger>
        </TabsList>

        <TabsContent value="schedule">
          <Card>
            <CardHeader>
              <CardTitle>Drop Schedule ({drops.length})</CardTitle>
            </CardHeader>
            <CardContent>
          {drops.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No drops scheduled</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Meme</TableHead>
                    <TableHead>Channel</TableHead>
                    <TableHead>Region</TableHead>
                    <TableHead>Scheduled At</TableHead>
                    <TableHead>Local Time</TableHead>
                    <TableHead>Priority</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {drops.map((drop: Drop) => {
                    const meme = memes.find((m: Meme) => m.id === drop.memeId);
                    return (
                      <TableRow key={drop.id}>
                        <TableCell className="font-medium">
                          {meme?.title || 'Unknown'}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{drop.channel}</Badge>
                        </TableCell>
                        <TableCell>
                          {drop.targetRegion && (
                            <Badge variant="secondary" className="text-xs capitalize">
                              {drop.targetRegion.replace('-', ' ')}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>{formatDateTime(drop.scheduledAt)}</TableCell>
                        <TableCell>
                          {drop.localTime && (
                            <div className="flex items-center gap-1 text-sm font-mono">
                              <Clock className="w-3 h-3" />
                              {drop.localTime}
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge className={getPriorityColor(drop.priority)}>
                            {drop.priority}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="collaboration">
          <CollaborationPanel campaignId={campaignId} />
        </TabsContent>

        <TabsContent value="preview">
          {memes.length > 0 ? (
            <PostPreview
              meme={memes[0]}
              caption={campaign.narrativeHook}
            />
          ) : (
            <Card>
              <CardContent className="p-8 text-center text-gray-500">
                No memes attached to preview
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
