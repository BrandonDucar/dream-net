'use client'
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { MessageSquare, CheckCircle, XCircle, AlertCircle, Send } from 'lucide-react';
import { loadComments, addComment, updateComment, saveComments } from '@/lib/storage';
import type { CollaborationComment, CollaborationAction } from '@/types';

interface CollaborationPanelProps {
  campaignId: string;
  memeId?: string;
  dropId?: string;
}

export function CollaborationPanel({ campaignId, memeId, dropId }: CollaborationPanelProps): JSX.Element {
  const [comments, setComments] = useState<CollaborationComment[]>([]);
  const [newComment, setNewComment] = useState<string>('');
  const [action, setAction] = useState<CollaborationAction>('comment');
  const [userName] = useState<string>('Builder'); // Would come from auth in real app

  useEffect(() => {
    loadCampaignComments();
  }, [campaignId, memeId, dropId]);

  const loadCampaignComments = (): void => {
    const allComments = loadComments();
    let filtered = allComments.filter((c: CollaborationComment) => c.campaignId === campaignId);
    
    if (memeId) {
      filtered = filtered.filter((c: CollaborationComment) => c.memeId === memeId);
    }
    
    if (dropId) {
      filtered = filtered.filter((c: CollaborationComment) => c.dropId === dropId);
    }
    
    filtered.sort((a: CollaborationComment, b: CollaborationComment) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
    
    setComments(filtered);
  };

  const handleSubmit = (): void => {
    if (!newComment.trim()) return;

    const comment: CollaborationComment = {
      id: `comment-${Date.now()}`,
      campaignId,
      memeId,
      dropId,
      userId: 'current-user',
      userName,
      action,
      comment: newComment,
      timestamp: new Date().toISOString(),
      resolved: false,
    };

    addComment(comment);
    setNewComment('');
    setAction('comment');
    loadCampaignComments();
  };

  const toggleResolved = (commentId: string): void => {
    const comment = comments.find((c: CollaborationComment) => c.id === commentId);
    if (comment) {
      updateComment(commentId, { resolved: !comment.resolved });
      loadCampaignComments();
    }
  };

  const getActionIcon = (actionType: CollaborationAction): JSX.Element => {
    switch (actionType) {
      case 'approve':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'reject':
        return <XCircle className="w-4 h-4 text-red-600" />;
      case 'request_changes':
        return <AlertCircle className="w-4 h-4 text-yellow-600" />;
      default:
        return <MessageSquare className="w-4 h-4 text-blue-600" />;
    }
  };

  const getActionBadge = (actionType: CollaborationAction): JSX.Element => {
    const colors: Record<CollaborationAction, string> = {
      comment: 'bg-blue-100 text-blue-800',
      approve: 'bg-green-100 text-green-800',
      reject: 'bg-red-100 text-red-800',
      request_changes: 'bg-yellow-100 text-yellow-800',
    };

    return (
      <Badge className={colors[actionType]}>
        {actionType.replace('_', ' ')}
      </Badge>
    );
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="w-5 h-5" />
          Team Collaboration
        </CardTitle>
        <CardDescription>
          Comments, approvals, and feedback
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <Select value={action} onValueChange={(value: string) => setAction(value as CollaborationAction)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="comment">Comment</SelectItem>
              <SelectItem value="approve">Approve</SelectItem>
              <SelectItem value="reject">Reject</SelectItem>
              <SelectItem value="request_changes">Request Changes</SelectItem>
            </SelectContent>
          </Select>

          <Textarea
            placeholder="Add your comment or feedback..."
            value={newComment}
            onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNewComment(e.target.value)}
            rows={3}
          />

          <Button onClick={handleSubmit} className="w-full">
            <Send className="w-4 h-4 mr-2" />
            Submit
          </Button>
        </div>

        <ScrollArea className="h-[400px]">
          {comments.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No comments yet. Be the first to add feedback!
            </div>
          ) : (
            <div className="space-y-3">
              {comments.map((comment: CollaborationComment) => (
                <Card
                  key={comment.id}
                  className={`p-3 ${comment.resolved ? 'opacity-60 border-green-200' : ''}`}
                >
                  <div className="space-y-2">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        {getActionIcon(comment.action)}
                        <span className="font-semibold">{comment.userName}</span>
                        {getActionBadge(comment.action)}
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleResolved(comment.id)}
                      >
                        {comment.resolved ? (
                          <CheckCircle className="w-4 h-4 text-green-600" />
                        ) : (
                          <div className="w-4 h-4 border-2 border-gray-300 rounded-full" />
                        )}
                      </Button>
                    </div>
                    
                    <p className="text-sm text-gray-700">{comment.comment}</p>
                    
                    <div className="text-xs text-gray-500">
                      {new Date(comment.timestamp).toLocaleString()}
                      {comment.resolved && (
                        <span className="ml-2 text-green-600">· Resolved</span>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
