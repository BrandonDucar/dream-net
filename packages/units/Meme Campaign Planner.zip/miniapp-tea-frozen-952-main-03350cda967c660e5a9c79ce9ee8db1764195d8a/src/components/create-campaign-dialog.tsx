'use client';

import { useState, useEffect } from 'react';
import type { Meme, Cadence, Channel } from '@/types';
import { createCampaign } from '@/lib/campaign-logic';
import { loadMemes } from '@/lib/storage';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';

interface CreateCampaignDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function CreateCampaignDialog({ isOpen, onClose, onSuccess }: CreateCampaignDialogProps) {
  const [name, setName] = useState<string>('');
  const [theme, setTheme] = useState<string>('');
  const [narrativeHook, setNarrativeHook] = useState<string>('');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [cadence, setCadence] = useState<Cadence>('daily');
  const [targetChannels, setTargetChannels] = useState<Set<Channel>>(new Set(['farcaster', 'x']));
  const [selectedMemes, setSelectedMemes] = useState<Set<string>>(new Set());
  const [availableMemes, setAvailableMemes] = useState<Meme[]>([]);

  useEffect(() => {
    if (isOpen) {
      const memes = loadMemes();
      setAvailableMemes(memes);
      
      const today = new Date().toISOString().split('T')[0];
      setStartDate(today);
    }
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    
    createCampaign({
      name,
      theme,
      narrativeHook,
      startDate: new Date(startDate).toISOString(),
      endDate: endDate ? new Date(endDate).toISOString() : null,
      cadence,
      targetChannels: Array.from(targetChannels),
      memeIds: Array.from(selectedMemes),
    });
    
    resetForm();
    onSuccess();
    onClose();
  };

  const resetForm = (): void => {
    setName('');
    setTheme('');
    setNarrativeHook('');
    setStartDate('');
    setEndDate('');
    setCadence('daily');
    setTargetChannels(new Set(['farcaster', 'x']));
    setSelectedMemes(new Set());
  };

  const handleClose = (): void => {
    resetForm();
    onClose();
  };

  const toggleChannel = (channel: Channel): void => {
    const newChannels = new Set(targetChannels);
    if (newChannels.has(channel)) {
      newChannels.delete(channel);
    } else {
      newChannels.add(channel);
    }
    setTargetChannels(newChannels);
  };

  const toggleMeme = (memeId: string): void => {
    const newMemes = new Set(selectedMemes);
    if (newMemes.has(memeId)) {
      newMemes.delete(memeId);
    } else {
      newMemes.add(memeId);
    }
    setSelectedMemes(newMemes);
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New Campaign</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Campaign Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
              placeholder="e.g., Base Summer Launch"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="theme">Theme</Label>
            <Input
              id="theme"
              value={theme}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTheme(e.target.value)}
              placeholder="e.g., Base Ecosystem Growth"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="narrativeHook">Narrative Hook</Label>
            <Textarea
              id="narrativeHook"
              value={narrativeHook}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNarrativeHook(e.target.value)}
              placeholder="e.g., Building momentum on Base with viral content"
              rows={2}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startDate">Start Date</Label>
              <Input
                id="startDate"
                type="date"
                value={startDate}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setStartDate(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="endDate">End Date (optional)</Label>
              <Input
                id="endDate"
                type="date"
                value={endDate}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEndDate(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="cadence">Cadence</Label>
            <Select value={cadence} onValueChange={(value: string) => setCadence(value as Cadence)}>
              <SelectTrigger id="cadence">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="slow-drip">Slow Drip (every 3 days)</SelectItem>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="burst">Burst (every 4 hours)</SelectItem>
                <SelectItem value="event-timed">Event-Timed (twice daily)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Target Channels</Label>
            <div className="grid grid-cols-2 gap-2">
              {(['x', 'farcaster', 'zora', 'base-feed'] as Channel[]).map((channel: Channel) => (
                <div key={channel} className="flex items-center space-x-2">
                  <Checkbox
                    id={`channel-${channel}`}
                    checked={targetChannels.has(channel)}
                    onCheckedChange={() => toggleChannel(channel)}
                  />
                  <label
                    htmlFor={`channel-${channel}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {channel}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Select Memes ({selectedMemes.size} selected)</Label>
            {availableMemes.length === 0 ? (
              <p className="text-sm text-gray-500">No memes available. Add memes first.</p>
            ) : (
              <div className="border rounded-lg max-h-48 overflow-y-auto p-2 space-y-1">
                {availableMemes.map((meme: Meme) => (
                  <div key={meme.id} className="flex items-center space-x-2 p-2 hover:bg-gray-50 rounded">
                    <Checkbox
                      id={`meme-${meme.id}`}
                      checked={selectedMemes.has(meme.id)}
                      onCheckedChange={() => toggleMeme(meme.id)}
                    />
                    <label
                      htmlFor={`meme-${meme.id}`}
                      className="text-sm flex-1 cursor-pointer"
                    >
                      {meme.title} - {meme.topic}
                    </label>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex gap-2 pt-4">
            <Button type="button" variant="outline" onClick={handleClose} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" className="flex-1" disabled={targetChannels.size === 0}>
              Create Campaign
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
