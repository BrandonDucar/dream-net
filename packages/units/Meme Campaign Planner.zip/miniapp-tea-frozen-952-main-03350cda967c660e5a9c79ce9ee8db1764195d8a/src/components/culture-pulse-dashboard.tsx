'use client'
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { TrendingUp, Search, Sparkles, RefreshCw } from 'lucide-react';
import type { TrendingTopic } from '@/types';

export function CulturePulseDashboard(): JSX.Element {
  const [trends, setTrends] = useState<TrendingTopic[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filteredTrends, setFilteredTrends] = useState<TrendingTopic[]>([]);

  useEffect(() => {
    fetchTrends();
  }, []);

  useEffect(() => {
    if (searchQuery) {
      const filtered = trends.filter((trend: TrendingTopic) => 
        trend.topic.toLowerCase().includes(searchQuery.toLowerCase()) ||
        trend.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        trend.relatedKeywords.some((kw: string) => 
          kw.toLowerCase().includes(searchQuery.toLowerCase())
        )
      );
      setFilteredTrends(filtered);
    } else {
      setFilteredTrends(trends);
    }
  }, [searchQuery, trends]);

  const fetchTrends = async (): Promise<void> => {
    try {
      setLoading(true);
      const response = await fetch('/api/culture-pulse');
      if (!response.ok) throw new Error('Failed to fetch trends');
      
      const data = await response.json();
      setTrends(data.trends);
      setFilteredTrends(data.trends);
    } catch (error) {
      console.error('Failed to fetch trends:', error);
    } finally {
      setLoading(false);
    }
  };

  const getMomentumColor = (momentum: number): string => {
    if (momentum >= 90) return 'bg-red-500';
    if (momentum >= 75) return 'bg-orange-500';
    if (momentum >= 60) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getCategoryColor = (category: string): string => {
    const colors: Record<string, string> = {
      'Infrastructure': 'bg-blue-100 text-blue-800',
      'Technology': 'bg-purple-100 text-purple-800',
      'AI': 'bg-pink-100 text-pink-800',
      'Culture': 'bg-green-100 text-green-800',
      'Gaming': 'bg-indigo-100 text-indigo-800',
      'DeFi': 'bg-yellow-100 text-yellow-800',
    };
    return colors[category] || 'bg-gray-100 text-gray-800';
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            <CardTitle>Culture Pulse</CardTitle>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={fetchTrends}
            disabled={loading}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
        <CardDescription>
          Real-time trending topics across crypto culture
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search trends..."
              value={searchQuery}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <ScrollArea className="h-[500px]">
          <div className="space-y-3">
            {loading ? (
              <div className="text-center py-8 text-gray-500">
                Loading trending topics...
              </div>
            ) : filteredTrends.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No trending topics found
              </div>
            ) : (
              filteredTrends.map((trend: TrendingTopic) => (
                <Card key={trend.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold">{trend.topic}</h3>
                            <Badge className={getCategoryColor(trend.category)}>
                              {trend.category}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600">{trend.description}</p>
                        </div>
                        <div className="flex items-center gap-2 ml-4">
                          <Sparkles className="w-4 h-4 text-yellow-500" />
                          <span className="text-sm font-medium">{trend.momentum}</span>
                        </div>
                      </div>

                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className={`${getMomentumColor(trend.momentum)} h-2 rounded-full transition-all`}
                          style={{ width: `${trend.momentum}%` }}
                        />
                      </div>

                      <div className="flex flex-wrap gap-1">
                        {trend.relatedKeywords.map((keyword: string, idx: number) => (
                          <Badge
                            key={idx}
                            variant="outline"
                            className="text-xs"
                          >
                            #{keyword}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>Source: {trend.source}</span>
                        <span>{new Date(trend.detectedAt).toLocaleString()}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
