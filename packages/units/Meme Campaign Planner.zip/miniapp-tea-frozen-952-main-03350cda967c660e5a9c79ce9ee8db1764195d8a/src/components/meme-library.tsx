'use client';

import { useState, useEffect } from 'react';
import type { Meme } from '@/types';
import { loadMemes } from '@/lib/storage';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, Zap, Sparkles, TrendingUp } from 'lucide-react';

interface MemeLibraryProps {
  onAddMeme: () => void;
  onAutoPlanFromSelected: (memeIds: string[]) => void;
  refreshTrigger: number;
}

export function MemeLibrary({ onAddMeme, onAutoPlanFromSelected, refreshTrigger }: MemeLibraryProps) {
  const [memes, setMemes] = useState<Meme[]>([]);
  const [selectedMemes, setSelectedMemes] = useState<Set<string>>(new Set());

  useEffect(() => {
    loadMemesData();
  }, [refreshTrigger]);

  const loadMemesData = (): void => {
    const allMemes = loadMemes();
    setMemes(allMemes.sort((a: Meme, b: Meme) => b.strengthScore - a.strengthScore));
  };

  const toggleMemeSelection = (memeId: string): void => {
    const newSelection = new Set(selectedMemes);
    if (newSelection.has(memeId)) {
      newSelection.delete(memeId);
    } else {
      newSelection.add(memeId);
    }
    setSelectedMemes(newSelection);
  };

  const handleAutoPlan = (): void => {
    if (selectedMemes.size > 0) {
      onAutoPlanFromSelected(Array.from(selectedMemes));
      setSelectedMemes(new Set());
    }
  };

  const getStrengthColor = (score: number): string => {
    if (score >= 0.8) return 'text-green-600 bg-green-50';
    if (score >= 0.6) return 'text-blue-600 bg-blue-50';
    if (score >= 0.4) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <Button onClick={onAddMeme} className="gap-2">
          <Plus className="w-4 h-4" />
          Add Meme
        </Button>
        
        {selectedMemes.size > 0 && (
          <div className="flex gap-2 items-center">
            <span className="text-sm text-gray-600">
              {selectedMemes.size} selected
            </span>
            <Button onClick={handleAutoPlan} className="gap-2">
              <Zap className="w-4 h-4" />
              Auto-Plan Campaign
            </Button>
          </div>
        )}
      </div>

      {memes.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-gray-500">
            <p className="mb-4">No memes in your library yet. Add your first meme to start planning campaigns.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {memes.map((meme: Meme) => (
            <Card 
              key={meme.id} 
              className={`hover:shadow-lg transition-all cursor-pointer ${
                selectedMemes.has(meme.id) ? 'ring-2 ring-blue-500' : ''
              }`}
              onClick={() => toggleMemeSelection(meme.id)}
            >
              <CardHeader>
                <div className="flex justify-between items-start gap-2">
                  <div className="flex-1">
                    <CardTitle className="text-lg">{meme.title}</CardTitle>
                  </div>
                  <Checkbox 
                    checked={selectedMemes.has(meme.id)}
                    onCheckedChange={() => toggleMemeSelection(meme.id)}
                    onClick={(e: React.MouseEvent) => e.stopPropagation()}
                  />
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm font-medium text-gray-600">Topic</p>
                  <p className="text-sm">{meme.topic}</p>
                </div>
                
                <div>
                  <p className="text-sm font-medium text-gray-600">Strength Score</p>
                  <Badge className={`${getStrengthColor(meme.strengthScore)} font-mono`}>
                    {(meme.strengthScore * 100).toFixed(0)}%
                  </Badge>
                </div>
                
                {meme.channelHints.length > 0 && (
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">Channel Hints</p>
                    <div className="flex flex-wrap gap-1">
                      {meme.channelHints.map((channel: string, idx: number) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {channel}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
                
                {meme.notes && (
                  <div>
                    <p className="text-sm font-medium text-gray-600">Notes</p>
                    <p className="text-sm text-gray-500 line-clamp-2">{meme.notes}</p>
                  </div>
                )}
                
                {meme.aiMetadata && (
                  <div className="space-y-2 pt-2 border-t">
                    <div className="flex items-center gap-1 text-xs font-medium text-purple-600">
                      <Sparkles className="w-3 h-3" />
                      AI Optimizations
                    </div>
                    
                    {meme.aiMetadata.hashtags.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-gray-600 mb-1">Hashtags</p>
                        <div className="flex flex-wrap gap-1">
                          {meme.aiMetadata.hashtags.slice(0, 4).map((tag: string, idx: number) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {meme.aiMetadata.trendingScore > 0.7 && (
                      <div className="flex items-center gap-1 text-xs text-orange-600">
                        <TrendingUp className="w-3 h-3" />
                        High trending potential
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
