'use client'
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Eye } from 'lucide-react';
import type { Channel, Meme } from '@/types';

interface PostPreviewProps {
  meme: Meme;
  caption?: string;
  hashtags?: string[];
}

export function PostPreview({ meme, caption, hashtags }: PostPreviewProps): JSX.Element {
  const [selectedChannel, setSelectedChannel] = useState<Channel>('farcaster');

  const defaultCaption = caption || meme.aiMetadata?.suggestedCaption || meme.title;
  const defaultHashtags = hashtags || meme.aiMetadata?.hashtags || [];

  const renderPreview = (): JSX.Element => {
    switch (selectedChannel) {
      case 'farcaster':
        return (
          <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
            <div className="flex items-start gap-3 mb-3">
              <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold">
                U
              </div>
              <div className="flex-1">
                <div className="font-semibold">Your Profile</div>
                <div className="text-sm text-gray-500">@username · now</div>
              </div>
            </div>
            <div className="mb-3">
              <p className="text-gray-900 whitespace-pre-wrap">{defaultCaption}</p>
              <div className="flex flex-wrap gap-1 mt-2">
                {defaultHashtags.map((tag: string, idx: number) => (
                  <span key={idx} className="text-purple-600">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
            {meme.imageUrl && (
              <div className="rounded-lg overflow-hidden border border-gray-200">
                <div className="bg-gray-100 aspect-video flex items-center justify-center">
                  <span className="text-gray-500">Meme Image</span>
                </div>
              </div>
            )}
            <div className="flex items-center gap-6 mt-3 text-gray-500 text-sm">
              <span>💬 Reply</span>
              <span>🔄 Recast</span>
              <span>❤️ Like</span>
            </div>
          </div>
        );

      case 'x':
        return (
          <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
            <div className="flex items-start gap-3 mb-3">
              <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                U
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold">Your Name</span>
                  <span className="text-gray-500">@username</span>
                  <span className="text-gray-500">· now</span>
                </div>
                <div className="mt-1">
                  <p className="text-gray-900 whitespace-pre-wrap">{defaultCaption}</p>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {defaultHashtags.map((tag: string, idx: number) => (
                      <span key={idx} className="text-blue-600">
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
                {meme.imageUrl && (
                  <div className="mt-3 rounded-2xl overflow-hidden border border-gray-200">
                    <div className="bg-gray-100 aspect-video flex items-center justify-center">
                      <span className="text-gray-500">Meme Image</span>
                    </div>
                  </div>
                )}
                <div className="flex items-center justify-between mt-3 text-gray-500 max-w-md">
                  <span className="hover:text-blue-500 cursor-pointer">💬</span>
                  <span className="hover:text-green-500 cursor-pointer">🔄</span>
                  <span className="hover:text-red-500 cursor-pointer">❤️</span>
                  <span className="hover:text-blue-500 cursor-pointer">📊</span>
                  <span className="hover:text-blue-500 cursor-pointer">🔖</span>
                  <span className="hover:text-blue-500 cursor-pointer">⬆️</span>
                </div>
              </div>
            </div>
          </div>
        );

      case 'zora':
        return (
          <div className="bg-black text-white border border-gray-800 rounded-lg p-4 shadow-sm">
            <div className="mb-3">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full" />
                <span className="font-semibold">your.eth</span>
              </div>
              <p className="text-gray-300 whitespace-pre-wrap">{defaultCaption}</p>
              <div className="flex flex-wrap gap-1 mt-2">
                {defaultHashtags.map((tag: string, idx: number) => (
                  <span key={idx} className="text-purple-400">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
            {meme.imageUrl && (
              <div className="rounded-lg overflow-hidden border border-gray-800">
                <div className="bg-gray-900 aspect-square flex items-center justify-center">
                  <span className="text-gray-600">NFT Artwork</span>
                </div>
              </div>
            )}
            <div className="flex items-center justify-between mt-3 text-sm">
              <span className="text-gray-400">Floor: 0.1 ETH</span>
              <button className="bg-white text-black px-4 py-1 rounded-full font-semibold">
                Collect
              </button>
            </div>
          </div>
        );

      case 'base-feed':
        return (
          <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
            <div className="flex items-start gap-3 mb-3">
              <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                B
              </div>
              <div className="flex-1">
                <div className="font-semibold">Base Builder</div>
                <div className="text-sm text-gray-500">Building onchain</div>
              </div>
              <Badge className="bg-blue-600">Base</Badge>
            </div>
            <div className="mb-3">
              <p className="text-gray-900 whitespace-pre-wrap">{defaultCaption}</p>
              <div className="flex flex-wrap gap-1 mt-2">
                {defaultHashtags.map((tag: string, idx: number) => (
                  <span key={idx} className="text-blue-600">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
            {meme.imageUrl && (
              <div className="rounded-lg overflow-hidden border border-gray-200">
                <div className="bg-gradient-to-br from-blue-100 to-blue-200 aspect-video flex items-center justify-center">
                  <span className="text-blue-600">Onchain Content</span>
                </div>
              </div>
            )}
            <div className="flex items-center gap-4 mt-3 text-gray-500 text-sm">
              <span>🔷 Like</span>
              <span>💬 Comment</span>
              <span>↗️ Share</span>
            </div>
          </div>
        );

      default:
        return <div>Unknown channel</div>;
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5" />
              Post Preview
            </CardTitle>
            <CardDescription>
              See how your meme will look on each platform
            </CardDescription>
          </div>
          <Select value={selectedChannel} onValueChange={(value: string) => setSelectedChannel(value as Channel)}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="farcaster">Farcaster</SelectItem>
              <SelectItem value="x">X (Twitter)</SelectItem>
              <SelectItem value="zora">Zora</SelectItem>
              <SelectItem value="base-feed">Base Feed</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        {renderPreview()}
      </CardContent>
    </Card>
  );
}
