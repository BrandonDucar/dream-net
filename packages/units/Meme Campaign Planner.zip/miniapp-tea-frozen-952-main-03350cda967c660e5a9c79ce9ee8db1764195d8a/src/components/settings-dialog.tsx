'use client'
import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Settings } from 'lucide-react';
import { loadSocialCredentials, saveSocialCredentials } from '@/lib/storage';
import type { SocialCredentials } from '@/types';
import { toast } from 'sonner';

interface SettingsDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SettingsDialog({ isOpen, onClose }: SettingsDialogProps): JSX.Element {
  const [credentials, setCredentials] = useState<SocialCredentials>({});

  useEffect(() => {
    if (isOpen) {
      const saved = loadSocialCredentials();
      setCredentials(saved);
    }
  }, [isOpen]);

  const handleSave = (): void => {
    saveSocialCredentials(credentials);
    toast.success('Settings saved successfully');
    onClose();
  };

  const updateXCredentials = (field: string, value: string): void => {
    setCredentials({
      ...credentials,
      x: {
        ...credentials.x,
        [field]: value,
      } as SocialCredentials['x'],
    });
  };

  const updateFarcasterCredentials = (field: string, value: string): void => {
    setCredentials({
      ...credentials,
      farcaster: {
        ...credentials.farcaster,
        [field]: value,
      } as SocialCredentials['farcaster'],
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Settings
          </DialogTitle>
          <DialogDescription>
            Configure your social media API credentials for posting
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="x" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="x">X (Twitter)</TabsTrigger>
            <TabsTrigger value="farcaster">Farcaster</TabsTrigger>
          </TabsList>

          <TabsContent value="x" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="x-api-key">API Key</Label>
              <Input
                id="x-api-key"
                type="password"
                value={credentials.x?.apiKey || ''}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                  updateXCredentials('apiKey', e.target.value)
                }
                placeholder="Enter your X API key"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="x-api-secret">API Secret</Label>
              <Input
                id="x-api-secret"
                type="password"
                value={credentials.x?.apiSecret || ''}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                  updateXCredentials('apiSecret', e.target.value)
                }
                placeholder="Enter your X API secret"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="x-access-token">Access Token</Label>
              <Input
                id="x-access-token"
                type="password"
                value={credentials.x?.accessToken || ''}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                  updateXCredentials('accessToken', e.target.value)
                }
                placeholder="Enter your X access token"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="x-access-secret">Access Token Secret</Label>
              <Input
                id="x-access-secret"
                type="password"
                value={credentials.x?.accessSecret || ''}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                  updateXCredentials('accessSecret', e.target.value)
                }
                placeholder="Enter your X access token secret"
              />
            </div>

            <div className="bg-blue-50 p-3 rounded-lg text-sm">
              <p className="font-semibold mb-1">How to get X API credentials:</p>
              <ol className="list-decimal list-inside space-y-1 text-gray-700">
                <li>Go to developer.twitter.com</li>
                <li>Create a new app or select existing</li>
                <li>Generate API keys and access tokens</li>
                <li>Paste them here to enable posting</li>
              </ol>
            </div>
          </TabsContent>

          <TabsContent value="farcaster" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fc-signer-uuid">Signer UUID</Label>
              <Input
                id="fc-signer-uuid"
                value={credentials.farcaster?.signerUuid || ''}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                  updateFarcasterCredentials('signerUuid', e.target.value)
                }
                placeholder="Enter your Farcaster signer UUID"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="fc-fid">FID (Farcaster ID)</Label>
              <Input
                id="fc-fid"
                value={credentials.farcaster?.fid || ''}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                  updateFarcasterCredentials('fid', e.target.value)
                }
                placeholder="Enter your Farcaster ID"
              />
            </div>

            <div className="bg-purple-50 p-3 rounded-lg text-sm">
              <p className="font-semibold mb-1">How to get Farcaster credentials:</p>
              <ol className="list-decimal list-inside space-y-1 text-gray-700">
                <li>Go to neynar.com and create an account</li>
                <li>Create a new signer for your app</li>
                <li>Copy the signer UUID</li>
                <li>Your FID is your Farcaster user ID</li>
              </ol>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            Save Settings
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
