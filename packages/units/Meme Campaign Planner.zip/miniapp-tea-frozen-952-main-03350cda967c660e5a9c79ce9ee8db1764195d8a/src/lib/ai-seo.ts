import type { Meme, Campaign, AIMetadata } from '@/types';

// AI-powered hashtag generation based on topic and title
export function generateHashtags(meme: Meme): string[] {
  const hashtags: string[] = [];
  const topic = meme.topic.toLowerCase();
  const title = meme.title.toLowerCase();
  
  // Base hashtags from topic
  const topicWords = topic.split(/\s+/).filter((w: string) => w.length > 3);
  topicWords.forEach((word: string) => {
    hashtags.push(`#${word.replace(/[^a-z0-9]/g, '')}`);
  });
  
  // Crypto-native hashtags
  if (topic.includes('base') || title.includes('base')) {
    hashtags.push('#Base', '#BasedAndBuilding', '#OnBase');
  }
  if (topic.includes('crypto') || topic.includes('web3')) {
    hashtags.push('#Crypto', '#Web3', '#CryptoTwitter');
  }
  if (topic.includes('nft')) {
    hashtags.push('#NFT', '#NFTs', '#NFTCommunity');
  }
  if (topic.includes('meme')) {
    hashtags.push('#MemeCoin', '#MemeEconomy', '#CryptoMemes');
  }
  if (topic.includes('defi')) {
    hashtags.push('#DeFi', '#DeFiSummer', '#YieldFarming');
  }
  
  // Engagement hashtags
  hashtags.push('#BuildingInPublic', '#GrowthMindset');
  
  // Remove duplicates and limit to 8
  return [...new Set(hashtags)].slice(0, 8);
}

// Generate SEO-optimized caption
export function generateCaption(meme: Meme, hashtags: string[]): string {
  const topic = meme.topic;
  const title = meme.title;
  
  const templates = [
    `${title} 🚀\n\nWhen you're building on ${topic}, you know the vibes are immaculate.\n\n${hashtags.slice(0, 5).join(' ')}`,
    `POV: You're shipping ${topic} features and the community goes wild 👀\n\n${title}\n\n${hashtags.slice(0, 5).join(' ')}`,
    `${title}\n\nThis is the energy we bring to ${topic}. No cap. 💎\n\n${hashtags.slice(0, 5).join(' ')}`,
    `The ${topic} narrative hitting different today:\n\n${title} ⚡️\n\n${hashtags.slice(0, 5).join(' ')}`,
  ];
  
  const randomIndex = Math.floor(Math.random() * templates.length);
  return templates[randomIndex] as string;
}

// Extract keywords for SEO
export function extractKeywords(meme: Meme): string[] {
  const keywords: string[] = [];
  const text = `${meme.title} ${meme.topic} ${meme.notes}`.toLowerCase();
  
  const cryptoKeywords = ['crypto', 'blockchain', 'web3', 'defi', 'nft', 'base', 'ethereum', 'token', 'smart contract', 'dapp'];
  const cultureKeywords = ['meme', 'viral', 'trending', 'culture', 'community', 'narrative', 'momentum'];
  
  cryptoKeywords.forEach((kw: string) => {
    if (text.includes(kw)) keywords.push(kw);
  });
  
  cultureKeywords.forEach((kw: string) => {
    if (text.includes(kw)) keywords.push(kw);
  });
  
  return [...new Set(keywords)];
}

// Calculate trending score based on various factors
export function calculateTrendingScore(meme: Meme): number {
  let score = meme.strengthScore;
  
  const topic = meme.topic.toLowerCase();
  
  // Boost for hot topics
  if (topic.includes('base')) score += 0.15;
  if (topic.includes('zk') || topic.includes('zero-knowledge')) score += 0.1;
  if (topic.includes('ai')) score += 0.1;
  if (topic.includes('meme')) score += 0.05;
  
  // Cap at 1.0
  return Math.min(score, 1.0);
}

// Generate complete AI metadata for a meme
export function generateAIMetadata(meme: Meme): AIMetadata {
  const hashtags = generateHashtags(meme);
  const suggestedCaption = generateCaption(meme, hashtags);
  const keywords = extractKeywords(meme);
  const trendingScore = calculateTrendingScore(meme);
  
  return {
    hashtags,
    suggestedCaption,
    keywords,
    trendingScore,
  };
}

// Generate SEO description for campaign
export function generateCampaignSEO(campaign: Campaign, memeTopics: string[]): string {
  const theme = campaign.theme;
  const uniqueTopics = [...new Set(memeTopics)];
  
  const descriptions = [
    `A coordinated ${campaign.cadence} campaign focused on ${theme}. Deploying ${memeTopics.length} high-impact memes across ${campaign.targetChannels.join(', ')} to maximize viral reach and community engagement.`,
    `${campaign.name}: Strategic meme deployment targeting ${uniqueTopics.slice(0, 3).join(', ')}. ${campaign.narrativeHook} Scheduled for optimal engagement and cultural momentum.`,
    `Multi-channel campaign amplifying ${theme}. ${memeTopics.length} carefully curated memes scheduled for ${campaign.cadence} distribution across the cryptoverse. ${campaign.narrativeHook}`,
  ];
  
  const randomIndex = Math.floor(Math.random() * descriptions.length);
  return descriptions[randomIndex] as string;
}
