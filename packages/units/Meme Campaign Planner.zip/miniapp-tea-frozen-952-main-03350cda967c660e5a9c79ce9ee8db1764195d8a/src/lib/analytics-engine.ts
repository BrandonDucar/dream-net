import type { 
  AnalyticsSummary, 
  Campaign, 
  Meme, 
  Drop, 
  PostedContent,
  Channel,
  PerformanceMetrics
} from '@/types';
import { loadCampaigns, loadMemes, loadDrops, loadPostedContent } from './storage';

export function calculateAnalytics(period: "week" | "month" | "quarter" | "year" | "all" = "all"): AnalyticsSummary {
  const campaigns = loadCampaigns();
  const memes = loadMemes();
  const drops = loadDrops();
  const posted = loadPostedContent();

  const now = new Date();
  const periodStart = getPeriodStart(period, now);

  const filteredPosted = posted.filter((p: PostedContent) => {
    const postedDate = new Date(p.postedAt);
    return postedDate >= periodStart;
  });

  const activeCampaigns = campaigns.filter((c: Campaign) => c.status === 'active');
  const scheduledDrops = drops.filter((d: Drop) => d.status === 'scheduled');
  const postedDrops = drops.filter((d: Drop) => d.status === 'posted');

  let totalReach = 0;
  let totalEngagements = 0;
  let totalEngagementRate = 0;
  let engagementCount = 0;

  filteredPosted.forEach((post: PostedContent) => {
    totalReach += post.performance.reach || 0;
    totalEngagements += 
      (post.performance.likes || 0) + 
      (post.performance.shares || 0) + 
      (post.performance.comments || 0);
    if (post.performance.engagement_rate) {
      totalEngagementRate += post.performance.engagement_rate;
      engagementCount++;
    }
  });

  const avgEngagementRate = engagementCount > 0 
    ? totalEngagementRate / engagementCount 
    : 0;

  const topPerformingPost = findTopPerformingPost(filteredPosted);
  const topPerformingMeme = topPerformingPost 
    ? memes.find((m: Meme) => m.id === topPerformingPost.memeId)
    : undefined;

  const topPerformingChannel = findTopPerformingChannel(filteredPosted);

  const previousPeriodStart = getPeriodStart(period, periodStart);
  const previousPosted = posted.filter((p: PostedContent) => {
    const postedDate = new Date(p.postedAt);
    return postedDate >= previousPeriodStart && postedDate < periodStart;
  });

  const previousEngagements = previousPosted.reduce((sum: number, post: PostedContent) => {
    return sum + 
      (post.performance.likes || 0) + 
      (post.performance.shares || 0) + 
      (post.performance.comments || 0);
  }, 0);

  const growthRate = previousEngagements > 0
    ? ((totalEngagements - previousEngagements) / previousEngagements) * 100
    : 0;

  return {
    totalCampaigns: campaigns.length,
    activeCampaigns: activeCampaigns.length,
    totalMemes: memes.length,
    totalDrops: drops.length,
    scheduledDrops: scheduledDrops.length,
    postedDrops: postedDrops.length,
    avgEngagementRate,
    topPerformingMeme,
    topPerformingChannel,
    totalReach,
    totalEngagements,
    growthRate,
    period,
  };
}

function getPeriodStart(period: "week" | "month" | "quarter" | "year" | "all", from: Date): Date {
  const start = new Date(from);
  
  switch (period) {
    case 'week':
      start.setDate(start.getDate() - 7);
      break;
    case 'month':
      start.setMonth(start.getMonth() - 1);
      break;
    case 'quarter':
      start.setMonth(start.getMonth() - 3);
      break;
    case 'year':
      start.setFullYear(start.getFullYear() - 1);
      break;
    case 'all':
      return new Date(0);
  }
  
  return start;
}

function findTopPerformingPost(posted: PostedContent[]): PostedContent | undefined {
  if (posted.length === 0) return undefined;
  
  return posted.reduce((best: PostedContent, current: PostedContent) => {
    const bestScore = calculatePerformanceScore(best.performance);
    const currentScore = calculatePerformanceScore(current.performance);
    return currentScore > bestScore ? current : best;
  });
}

function calculatePerformanceScore(metrics: PerformanceMetrics): number {
  return (
    (metrics.likes || 0) * 1 +
    (metrics.shares || 0) * 3 +
    (metrics.comments || 0) * 2 +
    (metrics.saves || 0) * 2
  );
}

function findTopPerformingChannel(posted: PostedContent[]): Channel | undefined {
  if (posted.length === 0) return undefined;

  const channelScores: Record<string, number> = {};

  posted.forEach((post: PostedContent) => {
    const score = calculatePerformanceScore(post.performance);
    channelScores[post.channel] = (channelScores[post.channel] || 0) + score;
  });

  const topChannel = Object.entries(channelScores).reduce((best, current) => {
    return current[1] > best[1] ? current : best;
  });

  return topChannel[0] as Channel;
}

export function getMemePerformance(memeId: string): PerformanceMetrics {
  const posted = loadPostedContent();
  const memePosts = posted.filter((p: PostedContent) => p.memeId === memeId);

  if (memePosts.length === 0) {
    return {
      views: 0,
      likes: 0,
      shares: 0,
      comments: 0,
      engagement_rate: 0,
      reach: 0,
      impressions: 0,
      updatedAt: new Date().toISOString(),
    };
  }

  const aggregated = memePosts.reduce((acc: PerformanceMetrics, post: PostedContent) => {
    return {
      views: acc.views + (post.performance.views || 0),
      likes: acc.likes + (post.performance.likes || 0),
      shares: acc.shares + (post.performance.shares || 0),
      comments: acc.comments + (post.performance.comments || 0),
      engagement_rate: 0,
      reach: acc.reach + (post.performance.reach || 0),
      impressions: acc.impressions + (post.performance.impressions || 0),
      clicks: (acc.clicks || 0) + (post.performance.clicks || 0),
      saves: (acc.saves || 0) + (post.performance.saves || 0),
      updatedAt: new Date().toISOString(),
    };
  }, {
    views: 0,
    likes: 0,
    shares: 0,
    comments: 0,
    engagement_rate: 0,
    reach: 0,
    impressions: 0,
    updatedAt: new Date().toISOString(),
  });

  const totalEngagements = aggregated.likes + aggregated.shares + aggregated.comments + (aggregated.saves || 0);
  aggregated.engagement_rate = aggregated.reach > 0 
    ? (totalEngagements / aggregated.reach) * 100 
    : 0;

  return aggregated;
}

export function getCampaignPerformance(campaignId: string): PerformanceMetrics {
  const posted = loadPostedContent();
  const campaign = loadCampaigns().find((c: Campaign) => c.id === campaignId);
  
  if (!campaign) {
    return {
      views: 0,
      likes: 0,
      shares: 0,
      comments: 0,
      engagement_rate: 0,
      reach: 0,
      impressions: 0,
      updatedAt: new Date().toISOString(),
    };
  }

  const campaignPosts = posted.filter((p: PostedContent) => p.campaignId === campaignId);

  if (campaignPosts.length === 0) {
    return {
      views: 0,
      likes: 0,
      shares: 0,
      comments: 0,
      engagement_rate: 0,
      reach: 0,
      impressions: 0,
      updatedAt: new Date().toISOString(),
    };
  }

  const aggregated = campaignPosts.reduce((acc: PerformanceMetrics, post: PostedContent) => {
    return {
      views: acc.views + (post.performance.views || 0),
      likes: acc.likes + (post.performance.likes || 0),
      shares: acc.shares + (post.performance.shares || 0),
      comments: acc.comments + (post.performance.comments || 0),
      engagement_rate: 0,
      reach: acc.reach + (post.performance.reach || 0),
      impressions: acc.impressions + (post.performance.impressions || 0),
      clicks: (acc.clicks || 0) + (post.performance.clicks || 0),
      saves: (acc.saves || 0) + (post.performance.saves || 0),
      updatedAt: new Date().toISOString(),
    };
  }, {
    views: 0,
    likes: 0,
    shares: 0,
    comments: 0,
    engagement_rate: 0,
    reach: 0,
    impressions: 0,
    updatedAt: new Date().toISOString(),
  });

  const totalEngagements = aggregated.likes + aggregated.shares + aggregated.comments + (aggregated.saves || 0);
  aggregated.engagement_rate = aggregated.reach > 0 
    ? (totalEngagements / aggregated.reach) * 100 
    : 0;

  return aggregated;
}
