import type { CalendarEvent, Drop, Campaign, PostStatus, CampaignStatus } from '@/types';
import { loadDrops, loadCampaigns } from './storage';

export function generateCalendarEvents(): CalendarEvent[] {
  const drops = loadDrops();
  const campaigns = loadCampaigns();
  const events: CalendarEvent[] = [];

  drops.forEach((drop: Drop) => {
    events.push({
      id: `drop-${drop.id}`,
      title: `Drop: ${drop.channel}`,
      type: 'drop',
      date: drop.scheduledAt,
      campaignId: drop.campaignId,
      dropId: drop.id,
      color: getDropColor(drop.status),
      status: drop.status,
    });
  });

  campaigns.forEach((campaign: Campaign) => {
    events.push({
      id: `campaign-start-${campaign.id}`,
      title: `${campaign.name} (Start)`,
      type: 'campaign_start',
      date: campaign.startDate,
      campaignId: campaign.id,
      color: getCampaignColor(campaign.status),
      status: campaign.status,
    });

    if (campaign.endDate) {
      events.push({
        id: `campaign-end-${campaign.id}`,
        title: `${campaign.name} (End)`,
        type: 'campaign_end',
        date: campaign.endDate,
        campaignId: campaign.id,
        color: getCampaignColor(campaign.status),
        status: campaign.status,
      });
    }
  });

  return events.sort((a: CalendarEvent, b: CalendarEvent) => {
    return new Date(a.date).getTime() - new Date(b.date).getTime();
  });
}

function getDropColor(status: PostStatus): string {
  switch (status) {
    case 'scheduled': return '#3b82f6';
    case 'posted': return '#10b981';
    case 'failed': return '#ef4444';
    case 'draft': return '#6b7280';
    default: return '#6b7280';
  }
}

function getCampaignColor(status: CampaignStatus): string {
  switch (status) {
    case 'planned': return '#8b5cf6';
    case 'active': return '#10b981';
    case 'cooldown': return '#f59e0b';
    case 'archived': return '#6b7280';
    default: return '#6b7280';
  }
}

export function getEventsForDateRange(startDate: Date, endDate: Date): CalendarEvent[] {
  const allEvents = generateCalendarEvents();
  
  return allEvents.filter((event: CalendarEvent) => {
    const eventDate = new Date(event.date);
    return eventDate >= startDate && eventDate <= endDate;
  });
}

export function getEventsForMonth(year: number, month: number): CalendarEvent[] {
  const startDate = new Date(year, month, 1);
  const endDate = new Date(year, month + 1, 0);
  
  return getEventsForDateRange(startDate, endDate);
}

export function groupEventsByDate(events: CalendarEvent[]): Record<string, CalendarEvent[]> {
  const grouped: Record<string, CalendarEvent[]> = {};
  
  events.forEach((event: CalendarEvent) => {
    const dateKey = new Date(event.date).toISOString().split('T')[0];
    if (!grouped[dateKey]) {
      grouped[dateKey] = [];
    }
    grouped[dateKey].push(event);
  });
  
  return grouped;
}
