import type { Meme, Campaign, Drop, Cadence, Channel, CampaignStatus, Priority, GeoRegion } from '@/types';
import { addMeme as storeMeme, addCampaign as storeCampaign, addDrop, loadMemes, loadCampaigns, loadDrops, saveCampaigns, saveDrops, getDropsByCampaign, updateCampaign as storeUpdateCampaign } from './storage';
import { generateAIMetadata, generateCampaignSEO } from './ai-seo';
import { inferGeoTargeting, getOptimalPostingTime, getLocalTimeString } from './geofencing';

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

export function addMeme(data: {
  title: string;
  topic: string;
  channelHints?: string[];
  strengthScore: number;
  notes: string;
}): Meme {
  const now = new Date().toISOString();
  const meme: Meme = {
    id: generateId(),
    title: data.title,
    topic: data.topic,
    channelHints: data.channelHints || [],
    strengthScore: data.strengthScore,
    notes: data.notes,
    createdAt: now,
    updatedAt: now,
  };
  
  // Auto-generate AI metadata
  meme.aiMetadata = generateAIMetadata(meme);
  
  storeMeme(meme);
  return meme;
}

export function createCampaign(data: {
  name: string;
  theme: string;
  narrativeHook: string;
  startDate: string;
  endDate: string | null;
  cadence: Cadence;
  targetChannels: Channel[];
  memeIds: string[];
}): Campaign {
  const campaign: Campaign = {
    id: generateId(),
    name: data.name,
    theme: data.theme,
    narrativeHook: data.narrativeHook,
    startDate: data.startDate,
    endDate: data.endDate,
    cadence: data.cadence,
    targetChannels: data.targetChannels,
    memeIds: data.memeIds,
    status: 'planned',
  };
  
  storeCampaign(campaign);
  return campaign;
}

function inferThemeFromMemes(memes: Meme[]): string {
  const topics = memes.map((m: Meme) => m.topic);
  const uniqueTopics = [...new Set(topics)];
  
  if (uniqueTopics.length === 1) {
    return uniqueTopics[0];
  } else if (uniqueTopics.length === 2) {
    return `${uniqueTopics[0]} & ${uniqueTopics[1]}`;
  } else if (uniqueTopics.length > 2) {
    return `${uniqueTopics[0]}, ${uniqueTopics[1]} & More`;
  }
  
  return 'Mixed Topics';
}

function inferNarrativeHook(memes: Meme[]): string {
  const topics = memes.map((m: Meme) => m.topic.toLowerCase());
  const hasBase = topics.some((t: string) => t.includes('base'));
  const hasCrypto = topics.some((t: string) => t.includes('crypto') || t.includes('web3') || t.includes('blockchain'));
  const hasMeme = topics.some((t: string) => t.includes('meme'));
  
  if (hasBase) return 'Building momentum on Base with viral content';
  if (hasCrypto && hasMeme) return 'Cryptonative humor meets culture';
  if (hasCrypto) return 'Riding the crypto narrative wave';
  
  return `Amplifying ${memes[0]?.topic || 'cultural moments'} through coordinated drops`;
}

function inferTargetChannels(memes: Meme[]): Channel[] {
  const channelSet = new Set<Channel>();
  
  memes.forEach((meme: Meme) => {
    meme.channelHints.forEach((hint: string) => {
      const normalized = hint.toLowerCase();
      if (normalized === 'x' || normalized === 'twitter') channelSet.add('x');
      if (normalized === 'farcaster' || normalized === 'fc') channelSet.add('farcaster');
      if (normalized === 'zora') channelSet.add('zora');
      if (normalized === 'base-feed' || normalized === 'base') channelSet.add('base-feed');
    });
  });
  
  if (channelSet.size === 0) {
    return ['farcaster', 'x'];
  }
  
  return Array.from(channelSet);
}

function generateDropSchedule(
  campaignId: string,
  memeIds: string[],
  targetChannels: Channel[],
  cadence: Cadence,
  startDate: string,
  geoTargeting?: { regions: GeoRegion[]; primaryTimezone: string; optimalPostingTimes: string[] }
): Drop[] {
  const drops: Drop[] = [];
  const start = new Date(startDate);
  
  let intervalHours: number;
  let priority: Priority = 'normal';
  
  switch (cadence) {
    case 'slow-drip':
      intervalHours = 72; // Every 3 days
      break;
    case 'daily':
      intervalHours = 24;
      break;
    case 'burst':
      intervalHours = 4; // Every 4 hours
      priority = 'high';
      break;
    case 'event-timed':
      intervalHours = 12; // Twice daily
      priority = 'high';
      break;
    default:
      intervalHours = 24;
  }
  
  const memes = loadMemes();
  const sortedMemeIds = [...memeIds].sort((a: string, b: string) => {
    const memeA = memes.find((m: Meme) => m.id === a);
    const memeB = memes.find((m: Meme) => m.id === b);
    return (memeB?.strengthScore || 0) - (memeA?.strengthScore || 0);
  });
  
  sortedMemeIds.forEach((memeId: string, index: number) => {
    const regions = geoTargeting?.regions || ['global'];
    
    regions.forEach((region: GeoRegion) => {
      targetChannels.forEach((channel: Channel) => {
        const scheduledTime = new Date(start);
        scheduledTime.setHours(scheduledTime.getHours() + (index * intervalHours));
        
        // Apply optimal timing if available
        if (geoTargeting?.optimalPostingTimes && geoTargeting.optimalPostingTimes.length > 0) {
          const optimalTime = geoTargeting.optimalPostingTimes[index % geoTargeting.optimalPostingTimes.length] as string;
          const [hours, minutes] = optimalTime.split(':');
          scheduledTime.setHours(parseInt(hours), parseInt(minutes));
        }
        
        const scheduledISO = scheduledTime.toISOString();
        const localTime = geoTargeting?.primaryTimezone 
          ? getLocalTimeString(scheduledISO, geoTargeting.primaryTimezone as any)
          : undefined;
        
        drops.push({
          id: generateId(),
          campaignId,
          memeId,
          channel,
          scheduledAt: scheduledISO,
          priority,
          targetRegion: region,
          localTime,
          status: 'scheduled' as const,
        });
      });
    });
  });
  
  return drops;
}

export function autoPlanCampaignFromMemes(data: {
  name: string;
  memes: string[];
  preferredStartDate: string;
  preferredCadence: Cadence;
}): { campaign: Campaign; drops: Drop[] } {
  const memes = loadMemes();
  const selectedMemes = memes.filter((m: Meme) => data.memes.includes(m.id));
  
  if (selectedMemes.length === 0) {
    throw new Error('No memes selected');
  }
  
  const theme = inferThemeFromMemes(selectedMemes);
  const narrativeHook = inferNarrativeHook(selectedMemes);
  const targetChannels = inferTargetChannels(selectedMemes);
  
  // Infer geo targeting from memes
  const allChannelHints = selectedMemes.flatMap((m: Meme) => m.channelHints);
  const geoTargeting = inferGeoTargeting(allChannelHints);
  
  // Generate SEO description
  const memeTopics = selectedMemes.map((m: Meme) => m.topic);
  const seoDescription = generateCampaignSEO(
    {
      name: data.name,
      theme,
      narrativeHook,
      cadence: data.preferredCadence,
      targetChannels,
    } as Campaign,
    memeTopics
  );
  
  const campaign = createCampaign({
    name: data.name,
    theme,
    narrativeHook,
    startDate: data.preferredStartDate,
    endDate: null,
    cadence: data.preferredCadence,
    targetChannels,
    memeIds: data.memes,
  });
  
  // Update with geo targeting and SEO
  storeUpdateCampaign(campaign.id, { geoTargeting, seoDescription });
  
  const drops = generateDropSchedule(
    campaign.id,
    data.memes,
    targetChannels,
    data.preferredCadence,
    data.preferredStartDate,
    geoTargeting
  );
  
  drops.forEach((drop: Drop) => addDrop(drop));
  
  return { campaign, drops };
}

export function getCampaigns(filter?: CampaignStatus): Campaign[] {
  const campaigns = loadCampaigns();
  
  if (filter) {
    return campaigns.filter((c: Campaign) => c.status === filter);
  }
  
  return campaigns;
}

export function getCampaignDetails(campaignId: string): {
  campaign: Campaign | undefined;
  drops: Drop[];
  memes: Meme[];
} {
  const campaigns = loadCampaigns();
  const campaign = campaigns.find((c: Campaign) => c.id === campaignId);
  const drops = getDropsByCampaign(campaignId);
  
  const memes = loadMemes();
  const campaignMemes = campaign 
    ? memes.filter((m: Meme) => campaign.memeIds.includes(m.id))
    : [];
  
  return { campaign, drops, memes: campaignMemes };
}

export function updateCampaignStatus(campaignId: string, status: CampaignStatus): void {
  storeUpdateCampaign(campaignId, { status });
}

export function regenerateDropSchedule(
  campaignId: string,
  newCadence: Cadence,
  newStartDate: string
): Drop[] {
  const allDrops = loadDrops();
  const campaigns = loadCampaigns();
  const campaign = campaigns.find((c: Campaign) => c.id === campaignId);
  
  if (!campaign) {
    throw new Error('Campaign not found');
  }
  
  const filteredDrops = allDrops.filter((d: Drop) => d.campaignId !== campaignId);
  saveDrops(filteredDrops);
  
  storeUpdateCampaign(campaignId, {
    cadence: newCadence,
    startDate: newStartDate,
  });
  
  const newDrops = generateDropSchedule(
    campaignId,
    campaign.memeIds,
    campaign.targetChannels,
    newCadence,
    newStartDate,
    campaign.geoTargeting
  );
  
  newDrops.forEach((drop: Drop) => addDrop(drop));
  
  return newDrops;
}
