import type { GeoRegion, Timezone, GeoTargeting } from '@/types';

export const TIMEZONE_LABELS: Record<Timezone, string> = {
  'UTC-8': 'Pacific (LA, SF)',
  'UTC-5': 'Eastern (NY, Miami)',
  'UTC+0': 'GMT (London)',
  'UTC+1': 'CET (Paris, Berlin)',
  'UTC+8': 'SGT (Singapore, HK)',
  'UTC+9': 'JST (Tokyo)',
};

export const REGION_TIMEZONES: Record<GeoRegion, Timezone[]> = {
  'americas': ['UTC-8', 'UTC-5'],
  'europe': ['UTC+0', 'UTC+1'],
  'asia-pacific': ['UTC+8', 'UTC+9'],
  'global': ['UTC-8', 'UTC-5', 'UTC+0', 'UTC+1', 'UTC+8', 'UTC+9'],
};

// Optimal posting times by region (hours in local time)
export const OPTIMAL_POSTING_TIMES: Record<GeoRegion, string[]> = {
  'americas': ['09:00', '12:00', '15:00', '18:00', '21:00'],
  'europe': ['08:00', '12:00', '17:00', '20:00'],
  'asia-pacific': ['09:00', '12:00', '19:00', '22:00'],
  'global': ['09:00', '15:00', '21:00'], // Compromise times
};

// Convert time from one timezone to another
export function convertTimezone(
  dateTime: string,
  fromTz: Timezone,
  toTz: Timezone
): string {
  const date = new Date(dateTime);
  
  // Get offset in hours
  const fromOffset = parseInt(fromTz.replace('UTC', ''));
  const toOffset = parseInt(toTz.replace('UTC', ''));
  const offsetDiff = toOffset - fromOffset;
  
  // Apply offset
  date.setHours(date.getHours() + offsetDiff);
  
  return date.toISOString();
}

// Get local time string for a timezone
export function getLocalTimeString(dateTime: string, timezone: Timezone): string {
  const date = new Date(dateTime);
  
  // Get the time in the target timezone
  const offset = parseInt(timezone.replace('UTC', ''));
  const utcDate = new Date(date.getTime() + date.getTimezoneOffset() * 60000);
  const targetDate = new Date(utcDate.getTime() + offset * 3600000);
  
  const hours = targetDate.getHours().toString().padStart(2, '0');
  const minutes = targetDate.getMinutes().toString().padStart(2, '0');
  
  return `${hours}:${minutes}`;
}

// Find the best posting time for a region
export function getOptimalPostingTime(
  startDate: string,
  region: GeoRegion,
  timezone: Timezone
): string {
  const date = new Date(startDate);
  const optimalTimes = OPTIMAL_POSTING_TIMES[region];
  
  if (!optimalTimes || optimalTimes.length === 0) {
    return startDate;
  }
  
  // Use the first optimal time
  const [hours, minutes] = (optimalTimes[0] as string).split(':');
  date.setHours(parseInt(hours), parseInt(minutes), 0, 0);
  
  return date.toISOString();
}

// Generate default geo targeting
export function generateDefaultGeoTargeting(): GeoTargeting {
  return {
    regions: ['global'],
    primaryTimezone: 'UTC-5',
    optimalPostingTimes: OPTIMAL_POSTING_TIMES['global'],
  };
}

// Infer geo targeting from channel hints
export function inferGeoTargeting(channelHints: string[]): GeoTargeting {
  const hints = channelHints.join(' ').toLowerCase();
  
  let regions: GeoRegion[] = ['global'];
  let primaryTimezone: Timezone = 'UTC-5';
  
  // Infer from hints
  if (hints.includes('asia') || hints.includes('japan') || hints.includes('singapore')) {
    regions = ['asia-pacific'];
    primaryTimezone = 'UTC+8';
  } else if (hints.includes('europe') || hints.includes('uk') || hints.includes('germany')) {
    regions = ['europe'];
    primaryTimezone = 'UTC+1';
  } else if (hints.includes('us') || hints.includes('america')) {
    regions = ['americas'];
    primaryTimezone = 'UTC-5';
  }
  
  return {
    regions,
    primaryTimezone,
    optimalPostingTimes: OPTIMAL_POSTING_TIMES[regions[0] as GeoRegion] || OPTIMAL_POSTING_TIMES['global'],
  };
}

// Format timezone for display
export function formatTimezone(timezone: Timezone): string {
  return TIMEZONE_LABELS[timezone] || timezone;
}

// Calculate all timezone equivalents for a drop
export function getMultiTimezoneSchedule(
  scheduledAt: string,
  primaryTimezone: Timezone
): Record<Timezone, string> {
  const schedule: Record<Timezone, string> = {} as Record<Timezone, string>;
  
  const allTimezones: Timezone[] = ['UTC-8', 'UTC-5', 'UTC+0', 'UTC+1', 'UTC+8', 'UTC+9'];
  
  allTimezones.forEach((tz: Timezone) => {
    schedule[tz] = getLocalTimeString(scheduledAt, tz);
  });
  
  return schedule;
}
