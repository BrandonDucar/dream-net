import type { SentimentAnalysis, SentimentType } from '@/types';

const CRYPTO_KEYWORDS = [
  'based', 'onchain', 'gm', 'wagmi', 'ngmi', 'bullish', 'bearish',
  'degen', 'ser', 'fren', 'moon', 'diamond hands', 'paper hands',
  'lfg', 'hodl', 'rekt', 'pumping', 'dumping', 'alpha', 'beta',
  'bag holder', 'ape', 'whale', 'shrimp', 'gas', 'mint', 'burn',
  'stake', 'yield', 'farm', 'liquidity', 'protocol', 'dao', 'nft',
  'memecoin', 'shitcoin', 'altcoin', 'mainnet', 'testnet', 'airdrop',
  'tokenomics', 'rugpull', 'fud', 'fomo', 'probably nothing',
  'few understand', 'anon', 'ser', 'builders', 'shipping', 'deploy'
];

const POSITIVE_WORDS = [
  'amazing', 'awesome', 'great', 'excellent', 'love', 'best', 'perfect',
  'bullish', 'moon', 'pumping', 'gains', 'winning', 'success', 'excited',
  'happy', 'good', 'nice', 'wonderful', 'fantastic', 'incredible',
  'based', 'wagmi', 'lfg', 'gm', 'bullish', 'alpha'
];

const NEGATIVE_WORDS = [
  'bad', 'terrible', 'awful', 'worst', 'hate', 'horrible', 'poor',
  'bearish', 'rekt', 'dumping', 'losses', 'failing', 'scam', 'rugpull',
  'sad', 'disappointed', 'angry', 'frustrated', 'annoyed', 'upset',
  'ngmi', 'fud', 'bearish', 'paper hands'
];

export function analyzeSentiment(text: string): SentimentAnalysis {
  const lowerText = text.toLowerCase();
  const words = lowerText.split(/\s+/);

  let positiveCount = 0;
  let negativeCount = 0;
  let cryptoKeywordCount = 0;

  const foundKeywords: string[] = [];
  const emotions: Record<string, number> = {
    joy: 0,
    excitement: 0,
    confidence: 0,
    fear: 0,
    anger: 0,
    sadness: 0,
  };

  words.forEach((word: string) => {
    if (POSITIVE_WORDS.includes(word)) positiveCount++;
    if (NEGATIVE_WORDS.includes(word)) negativeCount++;
    
    CRYPTO_KEYWORDS.forEach((keyword: string) => {
      if (lowerText.includes(keyword)) {
        cryptoKeywordCount++;
        if (!foundKeywords.includes(keyword)) {
          foundKeywords.push(keyword);
        }
      }
    });
  });

  if (lowerText.match(/\b(lol|lmao|haha|😂|🤣|😄|😊)/)) emotions.joy += 0.3;
  if (lowerText.match(/\b(lfg|let's go|moon|🚀|💪|🔥)/)) emotions.excitement += 0.3;
  if (lowerText.match(/\b(based|bullish|wagmi|💎|🙌)/)) emotions.confidence += 0.3;
  if (lowerText.match(/\b(scared|worried|concern|😰|😨)/)) emotions.fear += 0.3;
  if (lowerText.match(/\b(angry|mad|pissed|😠|😡)/)) emotions.anger += 0.3;
  if (lowerText.match(/\b(sad|disappointed|😢|😭)/)) emotions.sadness += 0.3;

  const totalSentimentWords = positiveCount + negativeCount;
  const score = totalSentimentWords > 0
    ? (positiveCount - negativeCount) / totalSentimentWords
    : 0;

  let overall: SentimentType;
  if (score > 0.2) overall = 'positive';
  else if (score < -0.2) overall = 'negative';
  else if (positiveCount > 0 && negativeCount > 0) overall = 'mixed';
  else overall = 'neutral';

  const culturalResonance = Math.min(cryptoKeywordCount / 5, 1);

  const viralIndicators = [
    lowerText.includes('🚀'),
    lowerText.includes('lfg'),
    lowerText.includes('moon'),
    lowerText.includes('based'),
    cryptoKeywordCount >= 3,
    positiveCount >= 2,
    text.length < 200,
  ].filter(Boolean).length;

  const viralPotential = Math.min(viralIndicators / 7, 1);

  return {
    overall,
    score,
    emotions,
    keywords: foundKeywords,
    culturalResonance,
    viralPotential,
    analyzedAt: new Date().toISOString(),
  };
}

export async function analyzeSentimentWithAI(text: string): Promise<SentimentAnalysis> {
  try {
    const response = await fetch('/api/sentiment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
    });

    if (!response.ok) {
      return analyzeSentiment(text);
    }

    const data = await response.json();
    return data.sentiment;
  } catch (error) {
    console.error('AI sentiment analysis failed, using local:', error);
    return analyzeSentiment(text);
  }
}
