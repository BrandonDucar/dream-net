import type { 
  Meme, 
  Campaign, 
  Drop, 
  PostedContent, 
  TrendingTopic, 
  CollaborationComment, 
  ABTest,
  SocialCredentials,
  AnalyticsSummary
} from '@/types';

const STORAGE_KEYS = {
  MEMES: 'meme-campaign-conductor:memes',
  CAMPAIGNS: 'meme-campaign-conductor:campaigns',
  DROPS: 'meme-campaign-conductor:drops',
  POSTED: 'meme-campaign-conductor:posted',
  TRENDS: 'meme-campaign-conductor:trends',
  COMMENTS: 'meme-campaign-conductor:comments',
  AB_TESTS: 'meme-campaign-conductor:ab-tests',
  CREDENTIALS: 'meme-campaign-conductor:credentials',
  ANALYTICS: 'meme-campaign-conductor:analytics',
} as const;

// Meme storage
export function saveMemes(memes: Meme[]): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEYS.MEMES, JSON.stringify(memes));
  }
}

export function loadMemes(): Meme[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(STORAGE_KEYS.MEMES);
  return data ? JSON.parse(data) : [];
}

export function addMeme(meme: Meme): void {
  const memes = loadMemes();
  memes.push(meme);
  saveMemes(memes);
}

export function updateMeme(id: string, updates: Partial<Meme>): void {
  const memes = loadMemes();
  const index = memes.findIndex((m: Meme) => m.id === id);
  if (index !== -1) {
    memes[index] = { ...memes[index], ...updates };
    saveMemes(memes);
  }
}

export function deleteMeme(id: string): void {
  const memes = loadMemes();
  saveMemes(memes.filter((m: Meme) => m.id !== id));
}

// Campaign storage
export function saveCampaigns(campaigns: Campaign[]): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEYS.CAMPAIGNS, JSON.stringify(campaigns));
  }
}

export function loadCampaigns(): Campaign[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(STORAGE_KEYS.CAMPAIGNS);
  return data ? JSON.parse(data) : [];
}

export function addCampaign(campaign: Campaign): void {
  const campaigns = loadCampaigns();
  campaigns.push(campaign);
  saveCampaigns(campaigns);
}

export function updateCampaign(id: string, updates: Partial<Campaign>): void {
  const campaigns = loadCampaigns();
  const index = campaigns.findIndex((c: Campaign) => c.id === id);
  if (index !== -1) {
    campaigns[index] = { ...campaigns[index], ...updates };
    saveCampaigns(campaigns);
  }
}

export function deleteCampaign(id: string): void {
  const campaigns = loadCampaigns();
  saveCampaigns(campaigns.filter((c: Campaign) => c.id !== id));
  
  const drops = loadDrops();
  saveDrops(drops.filter((d: Drop) => d.campaignId !== id));
}

// Drop storage
export function saveDrops(drops: Drop[]): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEYS.DROPS, JSON.stringify(drops));
  }
}

export function loadDrops(): Drop[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(STORAGE_KEYS.DROPS);
  return data ? JSON.parse(data) : [];
}

export function addDrop(drop: Drop): void {
  const drops = loadDrops();
  drops.push(drop);
  saveDrops(drops);
}

export function updateDrop(id: string, updates: Partial<Drop>): void {
  const drops = loadDrops();
  const index = drops.findIndex((d: Drop) => d.id === id);
  if (index !== -1) {
    drops[index] = { ...drops[index], ...updates };
    saveDrops(drops);
  }
}

export function deleteDrop(id: string): void {
  const drops = loadDrops();
  saveDrops(drops.filter((d: Drop) => d.id !== id));
}

export function getDropsByCampaign(campaignId: string): Drop[] {
  const drops = loadDrops();
  return drops.filter((d: Drop) => d.campaignId === campaignId);
}

// Posted content storage
export function savePostedContent(posted: PostedContent[]): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEYS.POSTED, JSON.stringify(posted));
  }
}

export function loadPostedContent(): PostedContent[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(STORAGE_KEYS.POSTED);
  return data ? JSON.parse(data) : [];
}

export function addPostedContent(post: PostedContent): void {
  const posted = loadPostedContent();
  posted.push(post);
  savePostedContent(posted);
}

export function updatePostedContent(id: string, updates: Partial<PostedContent>): void {
  const posted = loadPostedContent();
  const index = posted.findIndex((p: PostedContent) => p.id === id);
  if (index !== -1) {
    posted[index] = { ...posted[index], ...updates };
    savePostedContent(posted);
  }
}

// Trending topics storage
export function saveTrendingTopics(trends: TrendingTopic[]): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEYS.TRENDS, JSON.stringify(trends));
  }
}

export function loadTrendingTopics(): TrendingTopic[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(STORAGE_KEYS.TRENDS);
  return data ? JSON.parse(data) : [];
}

export function addTrendingTopic(trend: TrendingTopic): void {
  const trends = loadTrendingTopics();
  const exists = trends.findIndex((t: TrendingTopic) => t.topic === trend.topic);
  if (exists !== -1) {
    trends[exists] = trend;
  } else {
    trends.push(trend);
  }
  saveTrendingTopics(trends);
}

// Collaboration comments storage
export function saveComments(comments: CollaborationComment[]): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEYS.COMMENTS, JSON.stringify(comments));
  }
}

export function loadComments(): CollaborationComment[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(STORAGE_KEYS.COMMENTS);
  return data ? JSON.parse(data) : [];
}

export function addComment(comment: CollaborationComment): void {
  const comments = loadComments();
  comments.push(comment);
  saveComments(comments);
}

export function getCommentsByCampaign(campaignId: string): CollaborationComment[] {
  const comments = loadComments();
  return comments.filter((c: CollaborationComment) => c.campaignId === campaignId);
}

export function updateComment(id: string, updates: Partial<CollaborationComment>): void {
  const comments = loadComments();
  const index = comments.findIndex((c: CollaborationComment) => c.id === id);
  if (index !== -1) {
    comments[index] = { ...comments[index], ...updates };
    saveComments(comments);
  }
}

// A/B test storage
export function saveABTests(tests: ABTest[]): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEYS.AB_TESTS, JSON.stringify(tests));
  }
}

export function loadABTests(): ABTest[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(STORAGE_KEYS.AB_TESTS);
  return data ? JSON.parse(data) : [];
}

export function addABTest(test: ABTest): void {
  const tests = loadABTests();
  tests.push(test);
  saveABTests(tests);
}

export function updateABTest(id: string, updates: Partial<ABTest>): void {
  const tests = loadABTests();
  const index = tests.findIndex((t: ABTest) => t.id === id);
  if (index !== -1) {
    tests[index] = { ...tests[index], ...updates };
    saveABTests(tests);
  }
}

// Social credentials storage
export function saveSocialCredentials(credentials: SocialCredentials): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEYS.CREDENTIALS, JSON.stringify(credentials));
  }
}

export function loadSocialCredentials(): SocialCredentials {
  if (typeof window === 'undefined') return {};
  const data = localStorage.getItem(STORAGE_KEYS.CREDENTIALS);
  return data ? JSON.parse(data) : {};
}

// Analytics storage
export function saveAnalytics(analytics: AnalyticsSummary): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEYS.ANALYTICS, JSON.stringify(analytics));
  }
}

export function loadAnalytics(): AnalyticsSummary | null {
  if (typeof window === 'undefined') return null;
  const data = localStorage.getItem(STORAGE_KEYS.ANALYTICS);
  return data ? JSON.parse(data) : null;
}
