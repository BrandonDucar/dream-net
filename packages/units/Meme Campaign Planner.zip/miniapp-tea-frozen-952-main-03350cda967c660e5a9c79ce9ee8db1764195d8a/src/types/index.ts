export type Channel = "x" | "farcaster" | "zora" | "base-feed";

export type Cadence = "slow-drip" | "daily" | "burst" | "event-timed";

export type CampaignStatus = "planned" | "active" | "cooldown" | "archived";

export type Priority = "high" | "normal" | "low";

export type GeoRegion = "americas" | "europe" | "asia-pacific" | "global";

export type Timezone = "UTC-8" | "UTC-5" | "UTC+0" | "UTC+1" | "UTC+8" | "UTC+9";

export type PostStatus = "scheduled" | "posted" | "failed" | "draft";

export type CollaborationAction = "comment" | "approve" | "reject" | "request_changes";

export type SentimentType = "positive" | "neutral" | "negative" | "mixed";

export interface AIMetadata {
  hashtags: string[];
  suggestedCaption: string;
  keywords: string[];
  trendingScore: number;
}

export interface GeoTargeting {
  regions: GeoRegion[];
  primaryTimezone: Timezone;
  optimalPostingTimes: string[];
}

export interface Meme {
  id: string;
  title: string;
  topic: string;
  channelHints: string[];
  strengthScore: number;
  notes: string;
  aiMetadata?: AIMetadata;
  imageUrl?: string; // URL to meme image
  createdAt: string;
  updatedAt: string;
}

export interface Campaign {
  id: string;
  name: string;
  theme: string;
  narrativeHook: string;
  startDate: string;
  endDate: string | null;
  cadence: Cadence;
  targetChannels: Channel[];
  memeIds: string[];
  status: CampaignStatus;
  geoTargeting?: GeoTargeting;
  seoDescription?: string;
  createdBy?: string;
  teamMembers?: string[];
}

export interface Drop {
  id: string;
  campaignId: string;
  memeId: string;
  channel: Channel;
  scheduledAt: string;
  priority: Priority;
  targetRegion?: GeoRegion;
  localTime?: string;
  status: PostStatus;
  postId?: string; // ID from social platform after posting
  variants?: DropVariant[]; // For A/B testing
}

export interface DropVariant {
  id: string;
  caption: string;
  hashtags: string[];
  scheduledAt?: string;
  performance?: PerformanceMetrics;
}

export interface PostedContent {
  id: string;
  dropId: string;
  campaignId: string;
  memeId: string;
  channel: Channel;
  postedAt: string;
  postUrl?: string;
  platformPostId?: string;
  caption: string;
  performance: PerformanceMetrics;
  sentiment: SentimentAnalysis;
}

export interface PerformanceMetrics {
  views: number;
  likes: number;
  shares: number;
  comments: number;
  engagement_rate: number;
  reach: number;
  impressions: number;
  clicks?: number;
  saves?: number;
  updatedAt: string;
}

export interface SentimentAnalysis {
  overall: SentimentType;
  score: number; // -1 to 1
  emotions: Record<string, number>; // joy, anger, surprise, etc.
  keywords: string[];
  culturalResonance: number; // 0-1 how well it resonates with crypto culture
  viralPotential: number; // 0-1 predicted virality
  analyzedAt: string;
}

export interface TrendingTopic {
  id: string;
  topic: string;
  description: string;
  momentum: number; // 0-100
  category: string;
  relatedKeywords: string[];
  suggestedMemes?: string[];
  source: string; // "x", "farcaster", "web"
  detectedAt: string;
  peakTime?: string;
}

export interface CollaborationComment {
  id: string;
  campaignId: string;
  memeId?: string;
  dropId?: string;
  userId: string;
  userName: string;
  action: CollaborationAction;
  comment: string;
  timestamp: string;
  resolved: boolean;
}

export interface ABTest {
  id: string;
  campaignId: string;
  memeId: string;
  variants: DropVariant[];
  winner?: string; // variant id
  status: "running" | "completed" | "paused";
  startDate: string;
  endDate?: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  type: "drop" | "campaign_start" | "campaign_end" | "review";
  date: string;
  campaignId?: string;
  dropId?: string;
  color: string;
  status: PostStatus | CampaignStatus;
}

export interface SocialCredentials {
  x?: {
    apiKey: string;
    apiSecret: string;
    accessToken: string;
    accessSecret: string;
  };
  farcaster?: {
    signerUuid: string;
    fid: string;
  };
}

export interface AnalyticsSummary {
  totalCampaigns: number;
  activeCampaigns: number;
  totalMemes: number;
  totalDrops: number;
  scheduledDrops: number;
  postedDrops: number;
  avgEngagementRate: number;
  topPerformingMeme?: Meme;
  topPerformingChannel?: Channel;
  totalReach: number;
  totalEngagements: number;
  growthRate: number; // percentage
  period: "week" | "month" | "quarter" | "year" | "all";
}
