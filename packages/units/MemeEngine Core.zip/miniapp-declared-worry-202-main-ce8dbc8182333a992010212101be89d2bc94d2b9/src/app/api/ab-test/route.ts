import { openaiChatCompletion } from '@/openai-api';
import type { NextRequest } from 'next/server';

interface ABTestRequest {
  text: string;
}

export async function POST(req: NextRequest): Promise<Response> {
  try {
    const body: ABTestRequest = await req.json();

    if (!body.text || body.text.trim().length === 0) {
      return Response.json(
        { error: 'Text field is required' },
        { status: 400 }
      );
    }

    const systemPrompt = `You are an A/B testing expert for viral content. Generate 3 optimized variants of the input text, each targeting different viral strategies.

CURRENT TRENDING CONTEXT (December 2024):
- Top hashtags: #dankmemes, #funnymemes, #memesdaily
- Viral patterns: "chill guy" movement, short-form dominance, crypto culture
- Platform dynamics: X favors punchy text, TikTok needs hooks, Farcaster loves builder culture

Your task:
1. Create 3 distinct variants (A, B, C)
2. Each variant should optimize for different platforms/styles
3. Predict performance score (0-100) for each
4. Explain key strengths
5. Provide testing strategy recommendation

Return ONLY valid JSON:
{
  "variants": [
    {
      "version": "Variant A",
      "text": "optimized text variant",
      "predicted_score": number (0-100),
      "strengths": ["strength 1", "strength 2", "strength 3"],
      "platform_focus": "X / Farcaster / TikTok / Instagram"
    },
    {
      "version": "Variant B",
      "text": "different optimization",
      "predicted_score": number,
      "strengths": ["strength 1", "strength 2", "strength 3"],
      "platform_focus": "platform name"
    },
    {
      "version": "Variant C",
      "text": "third variant",
      "predicted_score": number,
      "strengths": ["strength 1", "strength 2", "strength 3"],
      "platform_focus": "platform name"
    }
  ],
  "recommendation": "which variant to use and why",
  "testing_strategy": "how to run the A/B test across platforms"
}

Variant Strategies:
- Variant A: Maximize humor and relatability (broad appeal)
- Variant B: Optimize for specific platform format (TikTok hook / X punchline / etc)
- Variant C: Trending hashtag integration + cultural moment timing

CRITICAL: Return ONLY JSON, no markdown, no explanation.`;

    const userPrompt = `Generate 3 A/B test variants for this content:

"${body.text}"

Create variants that test different viral strategies. Include trending December 2024 hashtags where appropriate (#dankmemes, #funnymemes, etc).`;

    const response = await openaiChatCompletion({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
    });

    const aiContent: string = response.choices[0]?.message?.content || '';

    let result: any;
    try {
      const jsonMatch: RegExpMatchArray | null = aiContent.match(/\{[\s\S]*\}/);
      const jsonStr: string = jsonMatch ? jsonMatch[0] : aiContent;
      result = JSON.parse(jsonStr);
    } catch {
      result = {
        variants: [
          {
            version: 'Variant A',
            text: body.text,
            predicted_score: 60,
            strengths: ['Original content', 'Baseline performance', 'Control group'],
            platform_focus: 'All Platforms',
          },
          {
            version: 'Variant B',
            text: `${body.text} 🔥`,
            predicted_score: 65,
            strengths: ['Emoji boost', 'Visual appeal', 'Engagement trigger'],
            platform_focus: 'Instagram',
          },
          {
            version: 'Variant C',
            text: `${body.text} #memes #dankmemes`,
            predicted_score: 70,
            strengths: ['Hashtag discovery', 'Trend alignment', 'Reach boost'],
            platform_focus: 'X',
          },
        ],
        recommendation: 'Test all three variants simultaneously with equal traffic distribution',
        testing_strategy: 'Run for 48 hours, measure engagement rate, reach, and remix probability',
      };
    }

    return Response.json(result);
  } catch (error: unknown) {
    console.error('A/B test error:', error);
    const errorMessage: string = error instanceof Error ? error.message : 'Unknown error';
    return Response.json(
      { error: 'Failed to generate A/B test variants', details: errorMessage },
      { status: 500 }
    );
  }
}
