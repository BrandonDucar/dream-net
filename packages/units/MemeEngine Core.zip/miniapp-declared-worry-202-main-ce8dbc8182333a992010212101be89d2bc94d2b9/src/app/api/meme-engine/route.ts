import { openaiChatCompletion } from '@/openai-api';
import type { NextRequest } from 'next/server';

interface MemeEngineRequest {
  text: string;
  platforms?: string[];
  audience_region?: string;
  post_type?: string;
  aggression_level?: string;
  image?: string;
}

export async function POST(req: NextRequest): Promise<Response> {
  try {
    const formData: FormData = await req.formData();
    
    const text: string = formData.get('text') as string;
    const platformsStr: string = formData.get('platforms') as string;
    const platforms: string[] = platformsStr ? JSON.parse(platformsStr) : ['X', 'Farcaster', 'Instagram', 'TikTok', 'Base'];
    const audience_region: string = formData.get('audience_region') as string || 'Global';
    const post_type: string = formData.get('post_type') as string || 'meme';
    const aggression_level: string = formData.get('aggression_level') as string || 'standard';
    const imageFile: File | null = formData.get('image') as File | null;

    // Validate required field
    if (!text || text.trim().length === 0) {
      return Response.json(
        { error: 'Text field is required' },
        { status: 400 }
      );
    }

    let imageBase64: string = '';
    let imageAnalysis: string = '';
    
    if (imageFile) {
      const bytes: ArrayBuffer = await imageFile.arrayBuffer();
      const buffer: Buffer = Buffer.from(bytes);
      imageBase64 = `data:${imageFile.type};base64,${buffer.toString('base64')}`;
      
      // Get image analysis from GPT-4o
      const imagePrompt = `Analyze this image for viral potential. Focus on:
- Visual composition and aesthetic appeal
- Emoji/text overlay effectiveness
- Color palette and contrast
- Meme format recognition
- Emotional impact
- Shareability factors

Provide a brief analysis in 2-3 sentences.`;

      const imageResponse = await openaiChatCompletion({
        model: 'gpt-4o',
        messages: [
          {
            role: 'user',
            content: [
              { type: 'text', text: imagePrompt },
              { type: 'image_url', image_url: { url: imageBase64 } }
            ]
          }
        ],
      });

      imageAnalysis = imageResponse.choices[0]?.message?.content || 'Image analysis unavailable';
    }

    // Enhanced system prompt with all competitive features
    const systemPrompt = `You are MemeEngineCore, the most advanced virality simulation engine in existence. You combine every competitor's best feature and exceed them all.

Your capabilities:
- Multi-modal analysis (text + visual patterns)
- Real-time trending data integration
- Professional rating system (humor, relatability, creativity, timing, visual appeal)
- Historical pattern matching against December 2024 viral successes
- Best time to post predictions
- Audience demographic targeting
- Crypto culture analysis (Base/Farcaster ecosystem)
- A/B testing recommendations

CURRENT TRENDING CONTEXT (December 2024):
Top Hashtags: #memes (136M posts), #dankmemes (66M), #funnymemes (49M), #memesdaily (43M)
Viral Patterns: "chill guy" meme movement, short-form video dominance, crypto culture integration
Memecoin Surge: 150% market recovery, DOGE/PEPE/BONK trending, Base blockchain seeing $2.4B inflows
Social Dynamics: KOL-driven narratives, whale wallet rotations, social sentiment as price catalyst

Core Analysis Factors:
1. Hook strength and emotional punch
2. Cultural density and relatability
3. Clarity and rhythm
4. Viral pattern matching (open loops, punchlines, hyper-relatable angles)
5. Visual composition (if image provided)
6. Trending hashtag alignment
7. Platform-specific formatting
8. Timing and cultural moment relevance
9. Remix/adaptation potential
10. Crypto-native cultural fit

You must return ONLY valid JSON in this exact format:
{
  "prediction": {
    "expected_reach": "string (e.g., '50-100K impressions', 'viral potential 500K+')",
    "time_to_peak_hours": number,
    "decay_curve": "string (e.g., 'explosive rise, medium tail', 'slow build, evergreen')",
    "spread_score": number (0-100),
    "remix_probability": number (0-100),
    "platform_breakdown": {
      "X": "one-sentence prediction",
      "Farcaster": "one-sentence prediction",
      "Instagram": "one-sentence prediction",
      "TikTok": "one-sentence prediction",
      "Base": "one-sentence prediction"
    }
  },
  "professional_ratings": {
    "humor_quality": number (0-10),
    "relatability": number (0-10),
    "creativity": number (0-10),
    "timing_score": number (0-10),
    "visual_appeal": number (0-10)
  },
  "best_time_to_post": {
    "optimal_hour": number (0-23),
    "timezone": "EST/PST/UTC",
    "reasoning": "brief explanation",
    "engagement_curve": "description of expected hourly engagement pattern"
  },
  "audience_demographics": {
    "primary_age_group": "Gen Z / Millennials / Gen X",
    "interests": ["interest1", "interest2", "interest3"],
    "communities": ["community1", "community2"]
  },
  "crypto_analysis": {
    "memecoin_correlation": "analysis of potential memecoin tie-in",
    "base_ecosystem_fit": number (0-10),
    "farcaster_resonance": number (0-10)
  },
  "historical_comparison": {
    "similar_viral_content": ["example 1", "example 2"],
    "pattern_match_score": number (0-100),
    "cultural_moment": "description of timing relevance"
  },
  "strength_factors": ["factor1", "factor2", "factor3"],
  "risk_factors": ["risk1", "risk2"],
  "optimized_version": "improved version with trending hashtags and better clarity",
  "lore_variant": "DreamNet-style mystical version referencing Signal Vines, Culture Engines, etc."
}

Platform Analysis Guidelines:
- X: Short, punchy, scroll-halt potential. Best for text-first, reply-bait formats.
- Farcaster: Aesthetic communal uplift, crypto-native humor, builder culture vibes.
- Instagram: Visual-first, emoji-heavy, story/reel format optimization.
- TikTok: Hook-first video potential, sound-sync opportunities, trend jumping.
- Base: Onchain meme culture, DeFi humor, builder/developer community appeal.

Geo-style Tuning for "${audience_region}":
- US: Casual internet slang, Gen Z TikTok language
- EU: Cleaner tone, international English
- LATAM: Warmer, expressive, community-focused
- Asia: Avoid Western-centric references
- Global: Broad, universally accessible

Aggression Level "${aggression_level}":
- conservative: Safe predictions, proven formats
- standard: Balanced risk assessment
- aggressive: High upside potential, bold estimates

${imageAnalysis ? `IMAGE ANALYSIS PROVIDED:\n${imageAnalysis}\n\nFactor this visual analysis into all ratings and predictions.` : ''}

CRITICAL: Respond with ONLY the JSON object. No markdown, no explanation, no code blocks.`;

    const userPrompt = `Analyze this ${post_type} for virality across ${platforms.join(', ')}:

"${text}"

Audience Region: ${audience_region}
Post Type: ${post_type}
Aggression Level: ${aggression_level}
${imageAnalysis ? `Visual Context: ${imageAnalysis}` : ''}

Consider current December 2024 trends: #dankmemes, #funnymemes, memecoin surge, Base ecosystem growth, "chill guy" viral movement.

Return complete JSON prediction with all professional ratings, crypto analysis, and optimization recommendations.`;

    // Call OpenAI
    const response = await openaiChatCompletion({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
    });

    const aiContent: string = response.choices[0]?.message?.content || '';

    // Parse the JSON response
    let prediction: any;
    try {
      const jsonMatch: RegExpMatchArray | null = aiContent.match(/\{[\s\S]*\}/);
      const jsonStr: string = jsonMatch ? jsonMatch[0] : aiContent;
      prediction = JSON.parse(jsonStr);
    } catch {
      // Fallback structure with all new fields
      prediction = {
        prediction: {
          expected_reach: '10-50K impressions',
          time_to_peak_hours: 24,
          decay_curve: 'standard curve',
          spread_score: 50,
          remix_probability: 30,
          platform_breakdown: {
            X: 'Moderate scroll-stop potential',
            Farcaster: 'Good community resonance',
            Instagram: 'Visual optimization needed',
            TikTok: 'Hook strength could improve',
            Base: 'Builder culture appeal moderate',
          },
        },
        professional_ratings: {
          humor_quality: 5,
          relatability: 5,
          creativity: 5,
          timing_score: 5,
          visual_appeal: imageAnalysis ? 6 : 5,
        },
        best_time_to_post: {
          optimal_hour: 18,
          timezone: 'EST',
          reasoning: 'Evening engagement peak',
          engagement_curve: 'Steady rise from 5PM to 8PM',
        },
        audience_demographics: {
          primary_age_group: 'Millennials',
          interests: ['humor', 'culture', 'trends'],
          communities: ['general internet', 'meme enthusiasts'],
        },
        crypto_analysis: {
          memecoin_correlation: 'Low direct correlation',
          base_ecosystem_fit: 5,
          farcaster_resonance: 5,
        },
        historical_comparison: {
          similar_viral_content: ['Classic meme formats'],
          pattern_match_score: 50,
          cultural_moment: 'Standard timing',
        },
        strength_factors: ['Content received'],
        risk_factors: ['Analysis needs refinement'],
        optimized_version: text,
        lore_variant: `The Signal Vines whisper: "${text}"`,
      };
    }

    return Response.json(prediction);
  } catch (error: unknown) {
    console.error('MemeEngine error:', error);
    const errorMessage: string = error instanceof Error ? error.message : 'Unknown error';
    return Response.json(
      { error: 'Failed to analyze meme', details: errorMessage },
      { status: 500 }
    );
  }
}
