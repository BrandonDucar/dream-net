'use client'
import { useState, useEffect } from 'react';
import type { FormEvent, ChangeEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MemeResults } from '@/components/meme-results';
import { TrendingDataPanel } from '@/components/trending-data-panel';
import { ABTestingPanel } from '@/components/ab-testing-panel';
import { Sparkles, Loader2, Upload, TrendingUp, FlaskConical } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

interface PlatformBreakdown {
  X: string;
  Farcaster: string;
  Instagram: string;
  TikTok: string;
  Base: string;
}

interface Prediction {
  expected_reach: string;
  time_to_peak_hours: number;
  decay_curve: string;
  spread_score: number;
  remix_probability: number;
  platform_breakdown: PlatformBreakdown;
}

interface ProfessionalRatings {
  humor_quality: number;
  relatability: number;
  creativity: number;
  timing_score: number;
  visual_appeal: number;
}

interface BestTimeToPost {
  optimal_hour: number;
  timezone: string;
  reasoning: string;
  engagement_curve: string;
}

interface AudienceDemographics {
  primary_age_group: string;
  interests: string[];
  communities: string[];
}

interface CryptoAnalysis {
  memecoin_correlation: string;
  base_ecosystem_fit: number;
  farcaster_resonance: number;
}

interface HistoricalComparison {
  similar_viral_content: string[];
  pattern_match_score: number;
  cultural_moment: string;
}

interface AnalysisResult {
  prediction: Prediction;
  strength_factors: string[];
  risk_factors: string[];
  optimized_version: string;
  lore_variant: string;
  professional_ratings: ProfessionalRatings;
  best_time_to_post: BestTimeToPost;
  audience_demographics: AudienceDemographics;
  crypto_analysis: CryptoAnalysis;
  historical_comparison: HistoricalComparison;
}

const ALL_PLATFORMS: string[] = ['X', 'Farcaster', 'Instagram', 'TikTok', 'Base'];

export default function Page(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [text, setText] = useState<string>('');
  const [platforms, setPlatforms] = useState<string[]>(ALL_PLATFORMS);
  const [audienceRegion, setAudienceRegion] = useState<string>('Global');
  const [postType, setPostType] = useState<string>('meme');
  const [aggressionLevel, setAggressionLevel] = useState<string>('standard');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string>('');

  const handlePlatformToggle = (platform: string): void => {
    setPlatforms((prev: string[]) =>
      prev.includes(platform)
        ? prev.filter((p: string) => p !== platform)
        : [...prev, platform]
    );
  };

  const handleImageUpload = (e: ChangeEvent<HTMLInputElement>): void => {
    const file: File | null = e.target.files?.[0] || null;
    if (file) {
      setImageFile(file);
      const reader: FileReader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    setError('');
    setResult(null);

    if (!text.trim()) {
      setError('Please enter some text to analyze');
      return;
    }

    if (platforms.length === 0) {
      setError('Please select at least one platform');
      return;
    }

    setLoading(true);

    try {
      const formData: FormData = new FormData();
      formData.append('text', text);
      formData.append('platforms', JSON.stringify(platforms));
      formData.append('audience_region', audienceRegion);
      formData.append('post_type', postType);
      formData.append('aggression_level', aggressionLevel);
      
      if (imageFile) {
        formData.append('image', imageFile);
      }

      const response: Response = await fetch('/api/meme-engine', {
        method: 'POST',
        body: formData,
      });

      const data: AnalysisResult | { error: string } = await response.json();

      if (!response.ok) {
        const errorData = data as { error: string };
        throw new Error(errorData.error || 'Analysis failed');
      }

      setResult(data as AnalysisResult);
    } catch (err: unknown) {
      const errorMessage: string = err instanceof Error ? err.message : 'Failed to analyze meme';
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-purple-950/20 to-indigo-950/30 text-white pt-16 pb-24 px-4">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4 animate-in fade-in duration-1000">
          <div className="flex items-center justify-center gap-3">
            <Sparkles className="w-10 h-10 text-purple-400 animate-pulse" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-indigo-400 bg-clip-text text-transparent">
              MemeEngineCore
            </h1>
            <Sparkles className="w-10 h-10 text-purple-400 animate-pulse" />
          </div>
          <p className="text-xl text-gray-400">
            DreamNet&apos;s Ultimate Culture Forecasting Platform
          </p>
          <p className="text-gray-500 max-w-3xl mx-auto">
            Multi-modal AI analysis • Real-time trending data • Professional ratings • A/B testing • Historical patterns • Crypto culture integration
          </p>
        </div>

        <Tabs defaultValue="analyze" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-purple-950/30">
            <TabsTrigger value="analyze" className="data-[state=active]:bg-purple-600">
              <Sparkles className="w-4 h-4 mr-2" />
              Analyze
            </TabsTrigger>
            <TabsTrigger value="trending" className="data-[state=active]:bg-purple-600">
              <TrendingUp className="w-4 h-4 mr-2" />
              Live Trends
            </TabsTrigger>
            <TabsTrigger value="abtest" className="data-[state=active]:bg-purple-600">
              <FlaskConical className="w-4 h-4 mr-2" />
              A/B Testing
            </TabsTrigger>
          </TabsList>

          <TabsContent value="analyze" className="space-y-8 mt-8">
            {/* Input Form */}
            <Card className="border-2 border-purple-500/30 bg-gradient-to-br from-purple-950/20 via-black to-indigo-950/20 shadow-2xl">
              <CardHeader>
                <CardTitle className="text-white">Input Your Meme or Idea</CardTitle>
                <CardDescription className="text-gray-400">
                  Enter text and optionally upload an image for multi-modal analysis
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Text Input */}
                  <div className="space-y-2">
                    <Label htmlFor="text" className="text-white">
                      Text / Meme / Caption <span className="text-red-400">*</span>
                    </Label>
                    <Textarea
                      id="text"
                      value={text}
                      onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setText(e.target.value)}
                      placeholder="Enter your meme, caption, or idea..."
                      className="min-h-32 bg-black/40 border-purple-500/30 text-white placeholder:text-gray-600"
                      required
                    />
                  </div>

                  {/* Image Upload */}
                  <div className="space-y-2">
                    <Label htmlFor="image" className="text-white">
                      Upload Image (Optional)
                    </Label>
                    <div className="flex items-center gap-4">
                      <Button
                        type="button"
                        onClick={() => document.getElementById('image')?.click()}
                        variant="outline"
                        className="bg-black/40 border-purple-500/30 text-white"
                      >
                        <Upload className="w-4 h-4 mr-2" />
                        Choose Image
                      </Button>
                      <input
                        id="image"
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                      {imageFile && (
                        <span className="text-sm text-gray-400">{imageFile.name}</span>
                      )}
                    </div>
                    {imagePreview && (
                      <div className="mt-3">
                        <img
                          src={imagePreview}
                          alt="Preview"
                          className="max-w-xs rounded-lg border border-purple-500/30"
                        />
                      </div>
                    )}
                  </div>

                  {/* Platform Selection */}
                  <div className="space-y-3">
                    <Label className="text-white">Platforms</Label>
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                      {ALL_PLATFORMS.map((platform: string) => (
                        <div key={platform} className="flex items-center space-x-2">
                          <Checkbox
                            id={platform}
                            checked={platforms.includes(platform)}
                            onCheckedChange={() => handlePlatformToggle(platform)}
                            className="border-purple-500/50"
                          />
                          <Label
                            htmlFor={platform}
                            className="text-sm text-gray-300 cursor-pointer"
                          >
                            {platform}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Audience Region */}
                    <div className="space-y-2">
                      <Label htmlFor="region" className="text-white">
                        Audience Region
                      </Label>
                      <Select value={audienceRegion} onValueChange={setAudienceRegion}>
                        <SelectTrigger className="bg-black/40 border-purple-500/30 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Global">Global</SelectItem>
                          <SelectItem value="US">US</SelectItem>
                          <SelectItem value="EU">EU</SelectItem>
                          <SelectItem value="LATAM">LATAM</SelectItem>
                          <SelectItem value="Asia">Asia</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Post Type */}
                    <div className="space-y-2">
                      <Label htmlFor="postType" className="text-white">
                        Post Type
                      </Label>
                      <Select value={postType} onValueChange={setPostType}>
                        <SelectTrigger className="bg-black/40 border-purple-500/30 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="meme">Meme</SelectItem>
                          <SelectItem value="caption">Caption</SelectItem>
                          <SelectItem value="announcement">Announcement</SelectItem>
                          <SelectItem value="shitpost">Shitpost</SelectItem>
                          <SelectItem value="lore_drop">Lore Drop</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Aggression Level */}
                    <div className="space-y-2">
                      <Label htmlFor="aggression" className="text-white">
                        Aggression Level
                      </Label>
                      <Select value={aggressionLevel} onValueChange={setAggressionLevel}>
                        <SelectTrigger className="bg-black/40 border-purple-500/30 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="conservative">Conservative</SelectItem>
                          <SelectItem value="standard">Standard</SelectItem>
                          <SelectItem value="aggressive">Aggressive</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-semibold py-6 text-lg"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Running Advanced Analysis...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Simulate Virality
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Error Display */}
            {error && (
              <Card className="border-2 border-red-500/50 bg-red-950/20">
                <CardContent className="pt-6">
                  <p className="text-red-400">{error}</p>
                </CardContent>
              </Card>
            )}

            {/* Results */}
            {result && <MemeResults {...result} />}
          </TabsContent>

          <TabsContent value="trending" className="mt-8">
            <TrendingDataPanel />
          </TabsContent>

          <TabsContent value="abtest" className="mt-8">
            <ABTestingPanel />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
