'use client';

import { useState } from 'react';
import type { FC, FormEvent, ChangeEvent } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { FlaskConical, Loader2, TrendingUp, Sparkles } from 'lucide-react';

interface Variant {
  version: string;
  text: string;
  predicted_score: number;
  strengths: string[];
  platform_focus: string;
}

interface ABTestResult {
  variants: Variant[];
  recommendation: string;
  testing_strategy: string;
}

export const ABTestingPanel: FC = () => {
  const [inputText, setInputText] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<ABTestResult | null>(null);
  const [error, setError] = useState<string>('');

  const handleSubmit = async (e: FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    setError('');
    setResult(null);

    if (!inputText.trim()) {
      setError('Please enter text to generate variants');
      return;
    }

    setLoading(true);

    try {
      const response: Response = await fetch('/api/ab-test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: inputText }),
      });

      const data: ABTestResult | { error: string } = await response.json();

      if (!response.ok) {
        const errorData = data as { error: string };
        throw new Error(errorData.error || 'A/B test generation failed');
      }

      setResult(data as ABTestResult);
    } catch (err: unknown) {
      const errorMessage: string = err instanceof Error ? err.message : 'Failed to generate A/B test variants';
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score: number): string => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    return 'text-orange-400';
  };

  return (
    <div className="space-y-6">
      {/* Input Form */}
      <Card className="border-2 border-purple-500/30 bg-gradient-to-br from-purple-950/20 via-black to-indigo-950/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <FlaskConical className="w-5 h-5 text-purple-400" />
            A/B Testing Simulator
          </CardTitle>
          <CardDescription className="text-gray-400">
            Generate 3 optimized variants and compare predicted performance
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="abtest-text" className="text-white">
                Original Text <span className="text-red-400">*</span>
              </Label>
              <Textarea
                id="abtest-text"
                value={inputText}
                onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setInputText(e.target.value)}
                placeholder="Enter your meme or caption to generate optimized variants..."
                className="min-h-32 bg-black/40 border-purple-500/30 text-white placeholder:text-gray-600"
                required
              />
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-semibold py-6"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Generating Variants...
                </>
              ) : (
                <>
                  <FlaskConical className="w-5 h-5 mr-2" />
                  Generate A/B Test Variants
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Error Display */}
      {error && (
        <Card className="border-2 border-red-500/50 bg-red-950/20">
          <CardContent className="pt-6">
            <p className="text-red-400">{error}</p>
          </CardContent>
        </Card>
      )}

      {/* Results */}
      {result && (
        <div className="space-y-6">
          {/* Variants Comparison */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {result.variants.map((variant: Variant, idx: number) => (
              <Card
                key={idx}
                className={`border-2 ${
                  idx === 0
                    ? 'border-green-500/40 bg-gradient-to-br from-green-950/20 to-black'
                    : idx === 1
                    ? 'border-yellow-500/40 bg-gradient-to-br from-yellow-950/20 to-black'
                    : 'border-blue-500/40 bg-gradient-to-br from-blue-950/20 to-black'
                }`}
              >
                <CardHeader>
                  <CardTitle className="flex items-center justify-between text-white">
                    <span>{variant.version}</span>
                    <Badge
                      className={
                        idx === 0
                          ? 'bg-green-500/20 text-green-400 border-green-500/30'
                          : idx === 1
                          ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
                          : 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                      }
                    >
                      {variant.platform_focus}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-black/40 p-4 rounded-lg border border-gray-700">
                    <p className="text-white leading-relaxed">{variant.text}</p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Predicted Score</span>
                      <span className={`text-2xl font-bold ${getScoreColor(variant.predicted_score)}`}>
                        {variant.predicted_score}
                      </span>
                    </div>
                    <Progress value={variant.predicted_score} className="h-2" />
                  </div>

                  <div>
                    <div className="text-sm text-gray-400 mb-2">Key Strengths:</div>
                    <ul className="space-y-1">
                      {variant.strengths.map((strength: string, sIdx: number) => (
                        <li key={sIdx} className="text-sm text-gray-300 flex items-start gap-2">
                          <Sparkles className="w-3 h-3 mt-1 text-purple-400" />
                          {strength}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Recommendation */}
          <Card className="border-2 border-purple-500/30 bg-gradient-to-br from-purple-950/20 to-black">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-purple-400">
                <TrendingUp className="w-5 h-5" />
                Expert Recommendation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-black/40 p-4 rounded-lg border border-purple-500/20">
                <p className="text-white leading-relaxed">{result.recommendation}</p>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-cyan-400 mb-2">Testing Strategy</h3>
                <div className="bg-black/40 p-4 rounded-lg border border-cyan-500/20">
                  <p className="text-gray-300">{result.testing_strategy}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};
