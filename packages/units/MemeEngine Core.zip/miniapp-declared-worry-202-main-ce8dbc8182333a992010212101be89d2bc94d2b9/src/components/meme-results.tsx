'use client';

import type { FC } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Sparkles, TrendingUp, Clock, Zap, AlertTriangle, Lightbulb, Star, Users, Target, Coins, History } from 'lucide-react';

interface PlatformBreakdown {
  X: string;
  Farcaster: string;
  Instagram: string;
  TikTok: string;
  Base: string;
}

interface Prediction {
  expected_reach: string;
  time_to_peak_hours: number;
  decay_curve: string;
  spread_score: number;
  remix_probability: number;
  platform_breakdown: PlatformBreakdown;
}

interface ProfessionalRatings {
  humor_quality: number;
  relatability: number;
  creativity: number;
  timing_score: number;
  visual_appeal: number;
}

interface BestTimeToPost {
  optimal_hour: number;
  timezone: string;
  reasoning: string;
  engagement_curve: string;
}

interface AudienceDemographics {
  primary_age_group: string;
  interests: string[];
  communities: string[];
}

interface CryptoAnalysis {
  memecoin_correlation: string;
  base_ecosystem_fit: number;
  farcaster_resonance: number;
}

interface HistoricalComparison {
  similar_viral_content: string[];
  pattern_match_score: number;
  cultural_moment: string;
}

interface MemeResultsProps {
  prediction: Prediction;
  strength_factors: string[];
  risk_factors: string[];
  optimized_version: string;
  lore_variant: string;
  professional_ratings: ProfessionalRatings;
  best_time_to_post: BestTimeToPost;
  audience_demographics: AudienceDemographics;
  crypto_analysis: CryptoAnalysis;
  historical_comparison: HistoricalComparison;
}

export const MemeResults: FC<MemeResultsProps> = ({
  prediction,
  strength_factors,
  risk_factors,
  optimized_version,
  lore_variant,
  professional_ratings,
  best_time_to_post,
  audience_demographics,
  crypto_analysis,
  historical_comparison,
}) => {
  const platformColors: Record<keyof PlatformBreakdown, string> = {
    X: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
    Farcaster: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
    Instagram: 'bg-pink-500/20 text-pink-300 border-pink-500/30',
    TikTok: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
    Base: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
  };

  const getRatingColor = (score: number): string => {
    if (score >= 8) return 'text-green-400';
    if (score >= 6) return 'text-yellow-400';
    return 'text-orange-400';
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-700">
      {/* Main Prediction Card */}
      <Card className="border-2 border-purple-500/30 bg-gradient-to-br from-purple-950/30 via-black to-indigo-950/30 shadow-2xl shadow-purple-500/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-2xl text-white">
            <Sparkles className="w-6 h-6 text-purple-400" />
            Virality Prediction
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-gray-400 text-sm">
                <TrendingUp className="w-4 h-4" />
                Spread Score
              </div>
              <div className="text-3xl font-bold text-white">{prediction.spread_score}</div>
              <Progress value={prediction.spread_score} className="h-2" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-gray-400 text-sm">
                <Zap className="w-4 h-4" />
                Remix Probability
              </div>
              <div className="text-3xl font-bold text-white">{prediction.remix_probability}%</div>
              <Progress value={prediction.remix_probability} className="h-2" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-gray-400 text-sm">
                <Clock className="w-4 h-4" />
                Time to Peak
              </div>
              <div className="text-3xl font-bold text-white">{prediction.time_to_peak_hours}h</div>
              <div className="text-sm text-gray-500">{prediction.decay_curve}</div>
            </div>
          </div>

          <Separator className="bg-purple-500/20" />

          {/* Expected Reach */}
          <div>
            <div className="text-sm text-gray-400 mb-2">Expected Reach</div>
            <div className="text-xl text-white font-medium">{prediction.expected_reach}</div>
          </div>
        </CardContent>
      </Card>

      {/* Professional Ratings */}
      <Card className="border-2 border-yellow-500/30 bg-gradient-to-br from-yellow-950/20 via-black to-orange-950/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-yellow-400">
            <Star className="w-5 h-5" />
            Professional Ratings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {[
              { label: 'Humor', value: professional_ratings.humor_quality },
              { label: 'Relatability', value: professional_ratings.relatability },
              { label: 'Creativity', value: professional_ratings.creativity },
              { label: 'Timing', value: professional_ratings.timing_score },
              { label: 'Visual', value: professional_ratings.visual_appeal },
            ].map(({ label, value }) => (
              <div key={label} className="text-center space-y-2">
                <div className="text-sm text-gray-400">{label}</div>
                <div className={`text-3xl font-bold ${getRatingColor(value)}`}>
                  {value.toFixed(1)}
                </div>
                <Progress value={value * 10} className="h-1" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Best Time to Post */}
        <Card className="border-2 border-cyan-500/30 bg-gradient-to-br from-cyan-950/20 to-black">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-cyan-400">
              <Clock className="w-5 h-5" />
              Best Time to Post
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Optimal Hour</span>
              <span className="text-2xl font-bold text-white">
                {best_time_to_post.optimal_hour}:00 {best_time_to_post.timezone}
              </span>
            </div>
            <div className="text-sm text-gray-300">
              <strong>Why:</strong> {best_time_to_post.reasoning}
            </div>
            <div className="text-sm text-gray-400">
              <strong>Pattern:</strong> {best_time_to_post.engagement_curve}
            </div>
          </CardContent>
        </Card>

        {/* Audience Demographics */}
        <Card className="border-2 border-pink-500/30 bg-gradient-to-br from-pink-950/20 to-black">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-pink-400">
              <Users className="w-5 h-5" />
              Target Audience
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <span className="text-sm text-gray-400">Age Group:</span>
              <Badge className="ml-2 bg-pink-500/20 text-pink-300 border-pink-500/30">
                {audience_demographics.primary_age_group}
              </Badge>
            </div>
            <div>
              <div className="text-sm text-gray-400 mb-2">Interests:</div>
              <div className="flex flex-wrap gap-2">
                {audience_demographics.interests.map((interest: string, idx: number) => (
                  <Badge key={idx} variant="outline" className="text-gray-300">
                    {interest}
                  </Badge>
                ))}
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-400 mb-2">Communities:</div>
              <div className="flex flex-wrap gap-2">
                {audience_demographics.communities.map((community: string, idx: number) => (
                  <Badge key={idx} variant="outline" className="text-gray-300">
                    {community}
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Crypto Analysis */}
      <Card className="border-2 border-indigo-500/30 bg-gradient-to-br from-indigo-950/20 to-black">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-indigo-400">
            <Coins className="w-5 h-5" />
            Crypto Culture Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">Base Ecosystem Fit</span>
                <span className="text-xl font-bold text-white">{crypto_analysis.base_ecosystem_fit}/10</span>
              </div>
              <Progress value={crypto_analysis.base_ecosystem_fit * 10} className="h-2" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">Farcaster Resonance</span>
                <span className="text-xl font-bold text-white">{crypto_analysis.farcaster_resonance}/10</span>
              </div>
              <Progress value={crypto_analysis.farcaster_resonance * 10} className="h-2" />
            </div>
          </div>
          <div className="bg-black/40 p-3 rounded-lg border border-indigo-500/20">
            <div className="text-sm text-gray-400 mb-1">Memecoin Correlation</div>
            <div className="text-gray-300">{crypto_analysis.memecoin_correlation}</div>
          </div>
        </CardContent>
      </Card>

      {/* Historical Comparison */}
      <Card className="border-2 border-orange-500/30 bg-gradient-to-br from-orange-950/20 to-black">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-orange-400">
            <History className="w-5 h-5" />
            Historical Pattern Match
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-gray-400">Pattern Match Score</span>
            <div className="flex items-center gap-3">
              <span className="text-2xl font-bold text-white">{historical_comparison.pattern_match_score}%</span>
              <Progress value={historical_comparison.pattern_match_score} className="h-2 w-24" />
            </div>
          </div>
          <div>
            <div className="text-sm text-gray-400 mb-2">Similar Viral Content:</div>
            <ul className="space-y-1">
              {historical_comparison.similar_viral_content.map((content: string, idx: number) => (
                <li key={idx} className="text-sm text-gray-300 flex items-start gap-2">
                  <span className="text-orange-400">•</span>
                  {content}
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-black/40 p-3 rounded-lg border border-orange-500/20">
            <div className="text-sm text-gray-400 mb-1">Cultural Moment</div>
            <div className="text-gray-300">{historical_comparison.cultural_moment}</div>
          </div>
        </CardContent>
      </Card>

      {/* Platform Breakdown */}
      <Card className="border-2 border-indigo-500/30 bg-gradient-to-br from-indigo-950/30 via-black to-purple-950/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <Target className="w-5 h-5" />
            Platform Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {(Object.keys(prediction.platform_breakdown) as Array<keyof PlatformBreakdown>).map((platform: keyof PlatformBreakdown) => (
            <div key={platform} className="flex items-start gap-3">
              <Badge className={`${platformColors[platform]} border px-3 py-1 font-semibold`}>
                {platform}
              </Badge>
              <div className="text-gray-300 text-sm flex-1">
                {prediction.platform_breakdown[platform]}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Strength and Risk Factors */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="border-2 border-green-500/30 bg-gradient-to-br from-green-950/20 to-black">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-400">
              <Lightbulb className="w-5 h-5" />
              Strength Factors
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {strength_factors.map((factor: string, idx: number) => (
                <li key={idx} className="flex items-start gap-2 text-gray-300 text-sm">
                  <span className="text-green-400 mt-1">•</span>
                  <span>{factor}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card className="border-2 border-yellow-500/30 bg-gradient-to-br from-yellow-950/20 to-black">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-yellow-400">
              <AlertTriangle className="w-5 h-5" />
              Risk Factors
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {risk_factors.map((risk: string, idx: number) => (
                <li key={idx} className="flex items-start gap-2 text-gray-300 text-sm">
                  <span className="text-yellow-400 mt-1">•</span>
                  <span>{risk}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Optimized Version */}
      <Card className="border-2 border-cyan-500/30 bg-gradient-to-br from-cyan-950/20 to-black">
        <CardHeader>
          <CardTitle className="text-cyan-400">Optimized Version</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-black/40 p-4 rounded-lg border border-cyan-500/20">
            <p className="text-white text-lg leading-relaxed">{optimized_version}</p>
          </div>
        </CardContent>
      </Card>

      {/* Lore Variant */}
      <Card className="border-2 border-purple-500/30 bg-gradient-to-br from-purple-950/20 via-black to-indigo-950/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-purple-400">
            <Sparkles className="w-5 h-5" />
            DreamNet Lore Variant
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-black/40 p-4 rounded-lg border border-purple-500/20">
            <p className="text-purple-200 text-lg leading-relaxed italic">{lore_variant}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
