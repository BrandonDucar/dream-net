'use client';

import type { FC } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Hash, Coins, Flame } from 'lucide-react';

export const TrendingDataPanel: FC = () => {
  const trendingHashtags = [
    { tag: '#memes', posts: '136M', growth: '+12%' },
    { tag: '#dankmemes', posts: '66M', growth: '+8%' },
    { tag: '#funnymemes', posts: '49M', growth: '+15%' },
    { tag: '#memesdaily', posts: '43M', growth: '+10%' },
    { tag: '#edgymemes', posts: '28M', growth: '+6%' },
    { tag: '#offensivememes', posts: '23M', growth: '+5%' },
  ];

  const viralPatterns = [
    {
      name: 'Chill Guy Movement',
      description: 'Relatable character-based memes with laid-back vibes',
      platforms: ['X', 'TikTok', 'Instagram'],
      strength: 95,
    },
    {
      name: 'Short-form Dominance',
      description: 'Sub-30 second videos with instant hook and punchline',
      platforms: ['TikTok', 'Instagram', 'X'],
      strength: 92,
    },
    {
      name: 'Crypto Culture Integration',
      description: 'Memes referencing Base, memecoins, gas fees, and builder culture',
      platforms: ['X', 'Farcaster', 'Base'],
      strength: 88,
    },
  ];

  const memecoinTrends = [
    { token: 'DOGE', change: '+7%', reason: 'US ETF launch' },
    { token: 'PEPE', change: '+45%', reason: 'Whale accumulation' },
    { token: 'BONK', change: '+32%', reason: 'Community momentum' },
    { token: 'TURBO', change: '+30%', reason: 'Exchange withdrawals' },
    { token: 'FARTCOIN', change: '+100%', reason: 'Viral narrative' },
  ];

  const baseEcosystem = [
    { metric: 'Net Capital Inflow', value: '$2.4B', period: '30 days' },
    { metric: 'DEX Volume Share', value: '45%', period: 'Solana+BNB+Base' },
    { metric: 'Meme Market Recovery', value: '+150%', period: 'Since Nov' },
    { metric: 'Gas Fees', value: 'Multi-month lows', period: 'Current' },
  ];

  return (
    <div className="space-y-6">
      {/* Trending Hashtags */}
      <Card className="border-2 border-purple-500/30 bg-gradient-to-br from-purple-950/20 via-black to-indigo-950/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <Hash className="w-5 h-5 text-purple-400" />
            Live Trending Hashtags
          </CardTitle>
          <CardDescription className="text-gray-400">
            Real-time data from across platforms (December 2024)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {trendingHashtags.map(({ tag, posts, growth }) => (
              <div
                key={tag}
                className="bg-black/40 p-4 rounded-lg border border-purple-500/20 hover:border-purple-500/40 transition-colors"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-lg font-semibold text-purple-300">{tag}</span>
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                    {growth}
                  </Badge>
                </div>
                <div className="text-2xl font-bold text-white">{posts}</div>
                <div className="text-xs text-gray-500">Total Posts</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Viral Patterns */}
      <Card className="border-2 border-pink-500/30 bg-gradient-to-br from-pink-950/20 to-black">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-pink-400">
            <Flame className="w-5 h-5" />
            Current Viral Patterns
          </CardTitle>
          <CardDescription className="text-gray-400">
            What&apos;s working right now across platforms
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {viralPatterns.map(({ name, description, platforms, strength }) => (
            <div
              key={name}
              className="bg-black/40 p-4 rounded-lg border border-pink-500/20"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-white mb-1">{name}</h3>
                  <p className="text-sm text-gray-400 mb-3">{description}</p>
                  <div className="flex flex-wrap gap-2">
                    {platforms.map((platform: string) => (
                      <Badge key={platform} variant="outline" className="text-gray-300">
                        {platform}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="ml-4 text-center">
                  <div className="text-3xl font-bold text-pink-400">{strength}</div>
                  <div className="text-xs text-gray-500">Strength</div>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Memecoin Trends */}
      <Card className="border-2 border-indigo-500/30 bg-gradient-to-br from-indigo-950/20 to-black">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-indigo-400">
            <Coins className="w-5 h-5" />
            Memecoin Market Trends
          </CardTitle>
          <CardDescription className="text-gray-400">
            Live sentiment and price action correlation
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            {memecoinTrends.map(({ token, change, reason }) => (
              <div
                key={token}
                className="bg-black/40 p-4 rounded-lg border border-indigo-500/20 flex items-center justify-between"
              >
                <div>
                  <div className="text-xl font-bold text-white mb-1">{token}</div>
                  <div className="text-sm text-gray-400">{reason}</div>
                </div>
                <Badge
                  className={`text-lg font-semibold ${
                    change.startsWith('+')
                      ? 'bg-green-500/20 text-green-400 border-green-500/30'
                      : 'bg-red-500/20 text-red-400 border-red-500/30'
                  }`}
                >
                  {change}
                </Badge>
              </div>
            ))}
          </div>

          <div className="bg-indigo-950/30 p-4 rounded-lg border border-indigo-500/20">
            <h3 className="text-lg font-semibold text-indigo-300 mb-3">Base Ecosystem Metrics</h3>
            <div className="grid grid-cols-2 gap-4">
              {baseEcosystem.map(({ metric, value, period }) => (
                <div key={metric}>
                  <div className="text-sm text-gray-400">{metric}</div>
                  <div className="text-2xl font-bold text-white">{value}</div>
                  <div className="text-xs text-gray-500">{period}</div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Market Insights */}
      <Card className="border-2 border-cyan-500/30 bg-gradient-to-br from-cyan-950/20 to-black">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-cyan-400">
            <TrendingUp className="w-5 h-5" />
            Key Market Insights
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="bg-black/40 p-4 rounded-lg border border-cyan-500/20">
            <p className="text-gray-300">
              <strong className="text-cyan-400">Meme Supercycle Alert:</strong> December 2024 showing strongest setup since 2021. Year-end portfolio rebalancing + reduced macro fear (VIX &lt; 15) + whale rotations creating explosive conditions.
            </p>
          </div>
          <div className="bg-black/40 p-4 rounded-lg border border-cyan-500/20">
            <p className="text-gray-300">
              <strong className="text-cyan-400">Social Dynamics:</strong> KOL-driven narratives now primary price catalyst. Major influencers rotating capital into memecoins, with social sentiment metrics outperforming traditional TA.
            </p>
          </div>
          <div className="bg-black/40 p-4 rounded-lg border border-cyan-500/20">
            <p className="text-gray-300">
              <strong className="text-cyan-400">Platform Shift:</strong> Farcaster seeing increased crypto-native meme adoption. Base memes correlating 0.7+ with memecoin price action. TikTok format adaptations showing 3x Instagram engagement.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
