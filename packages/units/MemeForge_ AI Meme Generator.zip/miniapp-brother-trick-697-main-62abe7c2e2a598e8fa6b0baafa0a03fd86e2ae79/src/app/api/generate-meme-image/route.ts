import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.json() as {
      topPanel: string;
      bottomPanel: string;
      style?: string;
      branding?: string;
    };

    if (!body.topPanel || !body.bottomPanel) {
      return NextResponse.json(
        { error: 'Both text panels are required' },
        { status: 400 }
      );
    }

    // Build image generation prompt
    let imagePrompt = `Create a meme background image with a ${body.style || 'modern'} aesthetic. `;
    
    // Style-specific prompts
    const stylePrompts: Record<string, string> = {
      clean: 'minimalist, clean design with solid colors or subtle gradients',
      chaotic: 'vibrant, energetic, with bold colors and dynamic elements',
      surreal: 'dreamlike, abstract, with surreal and artistic elements',
      spicy: 'bold, edgy, with dramatic lighting and intense colors',
      wholesome: 'warm, friendly, with soft pastel colors and cozy vibes',
      'dreamnet-lore': 'futuristic, tech-inspired, with neon accents and digital elements'
    };

    if (body.style && stylePrompts[body.style as keyof typeof stylePrompts]) {
      imagePrompt += stylePrompts[body.style as keyof typeof stylePrompts];
    } else {
      imagePrompt += 'suitable for a meme template with clear space for text overlay';
    }

    imagePrompt += '. The image should work well as a background for text overlay. No text in the image itself.';

    // Call OpenAI DALL-E via proxy
    const response = await fetch(`${request.nextUrl.origin}/api/proxy`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        protocol: 'https',
        origin: 'api.openai.com',
        path: '/v1/images/generations',
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'dall-e-3',
          prompt: imagePrompt,
          n: 1,
          size: '1024x1024',
          quality: 'standard'
        })
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Image generation error:', errorText);
      throw new Error('Failed to generate image');
    }

    const data = await response.json() as { data: Array<{ url: string }> };
    const imageUrl = data.data[0]?.url;

    if (!imageUrl) {
      throw new Error('No image URL in response');
    }

    return NextResponse.json({ imageUrl });
  } catch (error) {
    console.error('Error generating meme image:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to generate image' },
      { status: 500 }
    );
  }
}
