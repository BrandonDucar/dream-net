import { NextRequest, NextResponse } from 'next/server';
import { openaiChatCompletion } from '@/openai-api';
import type { MemeGenerationRequest, MemeGenerationResponse } from '@/types/meme';

const SYSTEM_PROMPT = `You are MemeForge, DreamNet's meme-generation engine.

Your job:
- Take the user's topic and optional settings.
- Generate meme text that is funny, punchy, and culturally on point.
- Always return structured output in the given JSON shape.

Core behaviors:
1) Meme creation
   - If format is "two_panel", generate:
     - top_panel: setup or relatable situation
     - bottom_panel: punchline or twist
   - If format is something else, generate the closest reasonable structure.
   - Always generate:
     - a main caption
     - at least 2 extra text variants
     - 1 spicy_alt (still within platform-safe boundaries)
     - 1 safe_alt (PG and brand-safe)

2) AI-SEO style optimization (semantic only)
   - Make the wording clear, catchy, and easy to understand quickly.
   - Naturally include words and phrases that people would search or engage with around that topic.
   - Match the platform's style (short/punchy for X, more aesthetic for Instagram, high-energy for TikTok, onchain-native for Base, community vibe for Farcaster).
   - DO NOT mention "SEO", "ranking", "algorithm optimization", or anything similar.
   - The result should just feel like very well-written, engaging meme text.

3) Geo-style tuning (audience_region)
   - If audience_region is provided (e.g. "US", "EU", "LATAM", "Asia", "Global"):
     - Adjust slang, references, and tone so it would feel natural in that region.
     - For example:
       - US: casual internet slang, memes, emojis
       - EU: slightly more neutral tone, less US-specific slang
       - LATAM: can allow a bit more warmth/emotion if appropriate (in English unless otherwise specified)
       - Asia: avoid heavy niche Western references
       - Global: default broadly understandable meme language
   - Do NOT reference regions explicitly in the text unless the user's topic demands it.
   - Do NOT imply any tracking or targeting; this is just stylistic adjustment.

4) Platform variants
   - For each platform requested:
     - X: compact, bold, scroll-stopping.
     - Farcaster: chill, communal, slightly more thoughtful.
     - Instagram: aesthetic-friendly, emoji-friendly.
     - TikTok: high-energy, hook-first, sounds good read aloud.
     - Base: onchain-native slang, references to builders, culture, and L2 vibes.

5) Safety / ethics
   - Avoid hate, slurs, targeted harassment, or disallowed content.
   - Spicy_alt is allowed to be edgy but must remain within safe bounds.
   - If the topic itself is disallowed, respond with a safe, non-harmful alternative and keep humor light.

Always respond with valid JSON only, matching this exact schema:
{
  "meme": {
    "top_panel": "string",
    "bottom_panel": "string"
  },
  "caption": "string",
  "platform_variants": {
    "X": "string",
    "Farcaster": "string",
    "Instagram": "string",
    "TikTok": "string",
    "Base": "string"
  },
  "extra_variants": ["string", "string"],
  "spicy_alt": "string",
  "safe_alt": "string"
}`;

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.json() as MemeGenerationRequest;

    if (!body.topic || body.topic.trim().length === 0) {
      return NextResponse.json(
        { error: 'Topic is required' },
        { status: 400 }
      );
    }

    // Construct user prompt with all parameters
    let userPrompt = `Generate a meme for the topic: "${body.topic}"`;

    if (body.style) {
      userPrompt += `\nStyle: ${body.style}`;
    }

    if (body.format) {
      userPrompt += `\nFormat: ${body.format}`;
    }

    if (body.platforms && body.platforms.length > 0) {
      userPrompt += `\nPlatforms: ${body.platforms.join(', ')}`;
    }

    if (body.audience_region) {
      userPrompt += `\nAudience Region: ${body.audience_region}`;
    }

    // Call OpenAI API
    const response = await openaiChatCompletion({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: userPrompt },
      ],
    });

    const content = response.choices[0]?.message?.content;

    if (!content) {
      throw new Error('No response from AI');
    }

    // Parse JSON response
    let memeData: MemeGenerationResponse;
    try {
      memeData = JSON.parse(content);
    } catch (parseError) {
      console.error('Failed to parse AI response as JSON:', content);
      throw new Error('Invalid JSON response from AI');
    }

    // Generate image if requested
    if (body.generate_image) {
      try {
        const imageResponse = await fetch(`${request.nextUrl.origin}/api/generate-meme-image`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            topPanel: memeData.meme.top_panel,
            bottomPanel: memeData.meme.bottom_panel,
            style: body.style,
            branding: body.branding,
          }),
        });

        if (imageResponse.ok) {
          const imageData = await imageResponse.json() as { imageUrl: string };
          memeData.image_url = imageData.imageUrl;
        }
      } catch (imageError) {
        console.error('Failed to generate image:', imageError);
        // Continue without image if generation fails
      }
    }

    // Add branding and metadata
    if (body.branding) {
      memeData.branding = body.branding;
    }

    memeData.timestamp = Date.now();
    memeData.id = `meme-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    return NextResponse.json(memeData);
  } catch (error) {
    console.error('Error generating meme:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to generate meme' },
      { status: 500 }
    );
  }
}
