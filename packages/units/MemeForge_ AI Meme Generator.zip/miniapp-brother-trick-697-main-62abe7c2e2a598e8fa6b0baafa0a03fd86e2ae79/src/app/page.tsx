'use client'
import { useState, useEffect } from 'react';
import { MemeGeneratorForm } from '@/components/meme-generator-form';
import { MemeResultDisplay } from '@/components/meme-result-display';
import { MemeHistory } from '@/components/meme-history';
import { useMemeHistory } from '@/hooks/useMemeHistory';
import type { MemeGenerationResponse } from '@/types/meme';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Home(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [result, setResult] = useState<MemeGenerationResponse | null>(null);
  const { saveMeme } = useMemeHistory();

  const handleGenerate = (newResult: MemeGenerationResponse): void => {
    setResult(newResult);
    saveMeme(newResult);
  };

  const handleSelectFromHistory = (meme: MemeGenerationResponse): void => {
    setResult(meme);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <div className="container mx-auto px-4 py-12 space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent">
            MemeForge
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            DreamNet&apos;s AI-powered meme generation engine. Create platform-optimized memes with smart cultural tuning.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <MemeGeneratorForm onGenerate={handleGenerate} />

            {result && <MemeResultDisplay result={result} />}
          </div>

          <div className="lg:col-span-1">
            <MemeHistory 
              onSelect={handleSelectFromHistory}
              currentMemeId={result?.id}
            />
          </div>
        </div>

        <footer className="text-center text-sm text-gray-500 pt-8">
          <p>Powered by DreamNet × OpenAI</p>
        </footer>
      </div>
    </div>
  );
}
