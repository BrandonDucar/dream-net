'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import type { MemeGenerationRequest, MemeGenerationResponse } from '@/types/meme';
import { Loader2, Image as ImageIcon } from 'lucide-react';

interface MemeGeneratorFormProps {
  onGenerate: (result: MemeGenerationResponse) => void;
}

const STYLES = ['clean', 'chaotic', 'surreal', 'spicy', 'wholesome', 'dreamnet-lore'] as const;
const FORMATS = ['two_panel', 'one_liner', 'copypasta', 'shitpost', 'lore_moment', 'platform_caption'] as const;
const PLATFORMS = ['X', 'Farcaster', 'Instagram', 'TikTok', 'Base'] as const;
const REGIONS = ['US', 'EU', 'LATAM', 'Asia', 'Global'] as const;

export function MemeGeneratorForm({ onGenerate }: MemeGeneratorFormProps): JSX.Element {
  const [topic, setTopic] = useState<string>('');
  const [style, setStyle] = useState<string>('');
  const [format, setFormat] = useState<string>('');
  const [platforms, setPlatforms] = useState<string[]>([]);
  const [region, setRegion] = useState<string>('');
  const [branding, setBranding] = useState<string>('');
  const [generateImage, setGenerateImage] = useState<boolean>(true);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const handlePlatformToggle = (platform: string): void => {
    setPlatforms((prev: string[]) =>
      prev.includes(platform)
        ? prev.filter((p: string) => p !== platform)
        : [...prev, platform]
    );
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    setError('');

    if (!topic.trim()) {
      setError('Please enter a topic');
      return;
    }

    setIsLoading(true);

    try {
      const requestBody: MemeGenerationRequest = {
        topic: topic.trim(),
        generate_image: generateImage,
      };

      if (style) requestBody.style = style as MemeGenerationRequest['style'];
      if (format) requestBody.format = format as MemeGenerationRequest['format'];
      if (platforms.length > 0) requestBody.platforms = platforms as MemeGenerationRequest['platforms'];
      if (region) requestBody.audience_region = region as MemeGenerationRequest['audience_region'];
      if (branding.trim()) requestBody.branding = branding.trim();

      const response = await fetch('/api/generate-meme', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to generate meme');
      }

      const result = await response.json() as MemeGenerationResponse;
      onGenerate(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle className="text-2xl font-bold">MemeForge</CardTitle>
        <CardDescription>DreamNet&apos;s Meme Generation Engine</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="topic" className="text-sm font-medium">
              Topic <span className="text-red-500">*</span>
            </Label>
            <Input
              id="topic"
              type="text"
              placeholder="e.g., Base season, algorithm raw-dogging engagement"
              value={topic}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTopic(e.target.value)}
              disabled={isLoading}
              className="w-full"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="style" className="text-sm font-medium">
                Style
              </Label>
              <Select value={style} onValueChange={setStyle} disabled={isLoading}>
                <SelectTrigger id="style">
                  <SelectValue placeholder="Select style" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {STYLES.map((s: string) => (
                    <SelectItem key={s} value={s}>
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="format" className="text-sm font-medium">
                Format
              </Label>
              <Select value={format} onValueChange={setFormat} disabled={isLoading}>
                <SelectTrigger id="format">
                  <SelectValue placeholder="Select format" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {FORMATS.map((f: string) => (
                    <SelectItem key={f} value={f}>
                      {f}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium">Platforms</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {PLATFORMS.map((platform: string) => (
                <div key={platform} className="flex items-center space-x-2">
                  <Checkbox
                    id={platform}
                    checked={platforms.includes(platform)}
                    onCheckedChange={() => handlePlatformToggle(platform)}
                    disabled={isLoading}
                  />
                  <Label
                    htmlFor={platform}
                    className="text-sm font-normal cursor-pointer"
                  >
                    {platform}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="region" className="text-sm font-medium">
              Audience Region
            </Label>
            <Select value={region} onValueChange={setRegion} disabled={isLoading}>
              <SelectTrigger id="region">
                <SelectValue placeholder="Select region" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                {REGIONS.map((r: string) => (
                  <SelectItem key={r} value={r}>
                    {r}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="branding" className="text-sm font-medium">
              Custom Branding / Watermark
            </Label>
            <Input
              id="branding"
              type="text"
              placeholder="e.g., @YourHandle or YourBrand.com"
              value={branding}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setBranding(e.target.value)}
              disabled={isLoading}
              className="w-full"
            />
          </div>

          <div className="flex items-center space-x-2 p-4 bg-purple-50 rounded-md border border-purple-200">
            <Checkbox
              id="generate-image"
              checked={generateImage}
              onCheckedChange={(checked: boolean) => setGenerateImage(checked)}
              disabled={isLoading}
            />
            <Label
              htmlFor="generate-image"
              className="text-sm font-medium cursor-pointer flex items-center gap-2"
            >
              <ImageIcon className="h-4 w-4" />
              Generate AI Image Background
            </Label>
          </div>

          {error && (
            <div className="p-3 text-sm text-red-600 bg-red-50 border border-red-200 rounded-md">
              {error}
            </div>
          )}

          <Button
            type="submit"
            className="w-full"
            disabled={isLoading || !topic.trim()}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Forging Meme...
              </>
            ) : (
              'Generate Meme'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
