'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { MemeGenerationResponse } from '@/types/meme';
import { Clock, Trash2, Eye } from 'lucide-react';

interface MemeHistoryProps {
  onSelect: (meme: MemeGenerationResponse) => void;
  currentMemeId?: string;
}

export function MemeHistory({ onSelect, currentMemeId }: MemeHistoryProps): JSX.Element {
  const [history, setHistory] = useState<MemeGenerationResponse[]>([]);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = (): void => {
    try {
      const saved = localStorage.getItem('memeforge-history');
      if (saved) {
        const parsed = JSON.parse(saved) as MemeGenerationResponse[];
        setHistory(parsed.sort((a: MemeGenerationResponse, b: MemeGenerationResponse) => 
          (b.timestamp || 0) - (a.timestamp || 0)
        ));
      }
    } catch (error) {
      console.error('Failed to load history:', error);
    }
  };

  const clearHistory = (): void => {
    if (confirm('Are you sure you want to clear all meme history?')) {
      localStorage.removeItem('memeforge-history');
      setHistory([]);
    }
  };

  const deleteMeme = (id: string): void => {
    const updated = history.filter((m: MemeGenerationResponse) => m.id !== id);
    localStorage.setItem('memeforge-history', JSON.stringify(updated));
    setHistory(updated);
  };

  const formatTimestamp = (timestamp: number): string => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString();
  };

  if (history.length === 0) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Meme History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-500 text-center py-8">
            No memes generated yet. Create your first meme to see it here!
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Meme History
            <Badge variant="secondary">{history.length}</Badge>
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={clearHistory}
            className="text-red-600 hover:text-red-700"
          >
            <Trash2 className="h-4 w-4 mr-1" />
            Clear All
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-3">
            {history.map((meme: MemeGenerationResponse) => (
              <div
                key={meme.id}
                className={`p-4 border rounded-lg transition-colors cursor-pointer hover:bg-gray-50 ${
                  meme.id === currentMemeId ? 'border-purple-500 bg-purple-50' : 'border-gray-200'
                }`}
                onClick={() => onSelect(meme)}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <Eye className="h-4 w-4 text-gray-400" />
                      <span className="text-xs text-gray-500">
                        {meme.timestamp ? formatTimestamp(meme.timestamp) : 'Unknown time'}
                      </span>
                    </div>
                    <p className="text-sm font-medium text-gray-900 line-clamp-2 mb-1">
                      {meme.meme.top_panel}
                    </p>
                    <p className="text-xs text-gray-600 line-clamp-1">
                      {meme.meme.bottom_panel}
                    </p>
                    {meme.branding && (
                      <Badge variant="outline" className="mt-2 text-xs">
                        {meme.branding}
                      </Badge>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e: React.MouseEvent<HTMLButtonElement>) => {
                      e.stopPropagation();
                      deleteMeme(meme.id || '');
                    }}
                    className="text-red-600 hover:text-red-700 flex-shrink-0"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
