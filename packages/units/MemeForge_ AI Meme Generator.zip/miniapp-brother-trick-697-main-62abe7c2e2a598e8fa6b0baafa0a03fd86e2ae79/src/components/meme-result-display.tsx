'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import type { MemeGenerationResponse } from '@/types/meme';
import { Copy, Check, Share2, Download } from 'lucide-react';

interface MemeResultDisplayProps {
  result: MemeGenerationResponse;
}

export function MemeResultDisplay({ result }: MemeResultDisplayProps): JSX.Element {
  const [copiedText, setCopiedText] = useState<string>('');

  const copyToClipboard = async (text: string, label: string): Promise<void> => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedText(label);
      setTimeout(() => setCopiedText(''), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const shareToSocial = (platform: string, text: string): void => {
    const encodedText = encodeURIComponent(text);
    const urls: Record<string, string> = {
      X: `https://twitter.com/intent/tweet?text=${encodedText}`,
      Farcaster: `https://warpcast.com/~/compose?text=${encodedText}`,
      Instagram: `https://www.instagram.com/`, // Instagram doesn't support direct sharing via URL
      TikTok: `https://www.tiktok.com/`,
    };

    const url = urls[platform];
    if (url) {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  };

  const downloadImage = async (): Promise<void> => {
    if (!result.image_url) return;

    try {
      const response = await fetch(result.image_url);
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `memeforge-${Date.now()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to download image:', error);
    }
  };

  return (
    <div className="w-full max-w-4xl space-y-6">
      {result.image_url && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl">Generated Meme Image</CardTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={downloadImage}
              >
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="relative rounded-lg overflow-hidden">
              <img
                src={result.image_url}
                alt="Generated meme background"
                className="w-full h-auto"
              />
              <div className="absolute inset-0 flex flex-col justify-between p-8 bg-black/30">
                <div className="text-white text-2xl md:text-3xl font-bold text-center drop-shadow-lg">
                  {result.meme.top_panel}
                </div>
                <div className="text-white text-2xl md:text-3xl font-bold text-center drop-shadow-lg">
                  {result.meme.bottom_panel}
                </div>
              </div>
              {result.branding && (
                <div className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded">
                  {result.branding}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">Two-Panel Meme</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-gradient-to-b from-gray-800 to-gray-900 text-white p-8 rounded-lg space-y-4 text-center">
            <div className="text-2xl font-bold leading-tight">
              {result.meme.top_panel}
            </div>
            <Separator className="bg-gray-600" />
            <div className="text-2xl font-bold leading-tight">
              {result.meme.bottom_panel}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm font-semibold">Main Caption:</h4>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => copyToClipboard(result.caption, 'caption')}
              >
                {copiedText === 'caption' ? (
                  <Check className="h-4 w-4 text-green-600" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
              </Button>
            </div>
            <p className="text-base bg-gray-100 p-3 rounded-md">{result.caption}</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">Platform Variants</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="X" className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="X">X</TabsTrigger>
              <TabsTrigger value="Farcaster">Farcaster</TabsTrigger>
              <TabsTrigger value="Instagram">Instagram</TabsTrigger>
              <TabsTrigger value="TikTok">TikTok</TabsTrigger>
              <TabsTrigger value="Base">Base</TabsTrigger>
            </TabsList>

            {Object.entries(result.platform_variants).map(([platform, text]: [string, string]) => (
              <TabsContent key={platform} value={platform} className="space-y-2">
                <div className="p-4 bg-gray-50 rounded-md border">
                  <p className="text-base">{text}</p>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => copyToClipboard(text, platform)}
                    className="flex-1"
                  >
                    {copiedText === platform ? (
                      <>
                        <Check className="h-4 w-4 mr-2 text-green-600" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="h-4 w-4 mr-2" />
                        Copy
                      </>
                    )}
                  </Button>
                  {(platform === 'X' || platform === 'Farcaster') && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => shareToSocial(platform, text)}
                      className="flex-1"
                    >
                      <Share2 className="h-4 w-4 mr-2" />
                      Share
                    </Button>
                  )}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              Extra Variants
              <Badge variant="outline">{result.extra_variants.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {result.extra_variants.map((variant: string, idx: number) => (
              <div key={idx} className="space-y-2">
                <div className="p-3 bg-blue-50 rounded-md border border-blue-200">
                  <p className="text-sm">{variant}</p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(variant, `extra-${idx}`)}
                  className="w-full"
                >
                  {copiedText === `extra-${idx}` ? (
                    <>
                      <Check className="h-4 w-4 mr-2 text-green-600" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Alternative Versions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="destructive">Spicy</Badge>
              </div>
              <div className="p-3 bg-red-50 rounded-md border border-red-200">
                <p className="text-sm">{result.spicy_alt}</p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => copyToClipboard(result.spicy_alt, 'spicy')}
                className="w-full mt-2"
              >
                {copiedText === 'spicy' ? (
                  <>
                    <Check className="h-4 w-4 mr-2 text-green-600" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4 mr-2" />
                    Copy
                  </>
                )}
              </Button>
            </div>

            <Separator />

            <div>
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="secondary">Safe</Badge>
              </div>
              <div className="p-3 bg-green-50 rounded-md border border-green-200">
                <p className="text-sm">{result.safe_alt}</p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => copyToClipboard(result.safe_alt, 'safe')}
                className="w-full mt-2"
              >
                {copiedText === 'safe' ? (
                  <>
                    <Check className="h-4 w-4 mr-2 text-green-600" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4 mr-2" />
                    Copy
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
