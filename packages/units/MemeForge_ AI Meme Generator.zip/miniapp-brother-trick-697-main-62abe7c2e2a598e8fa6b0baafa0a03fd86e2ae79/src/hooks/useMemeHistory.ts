import { useEffect, useState } from 'react';
import type { MemeGenerationResponse } from '@/types/meme';

export function useMemeHistory() {
  const [history, setHistory] = useState<MemeGenerationResponse[]>([]);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = (): void => {
    try {
      const saved = localStorage.getItem('memeforge-history');
      if (saved) {
        const parsed = JSON.parse(saved) as MemeGenerationResponse[];
        setHistory(parsed);
      }
    } catch (error) {
      console.error('Failed to load history:', error);
    }
  };

  const saveMeme = (meme: MemeGenerationResponse): void => {
    try {
      const memeWithMetadata: MemeGenerationResponse = {
        ...meme,
        id: meme.id || `meme-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        timestamp: meme.timestamp || Date.now(),
      };

      const saved = localStorage.getItem('memeforge-history');
      const existing = saved ? (JSON.parse(saved) as MemeGenerationResponse[]) : [];
      
      // Keep only last 50 memes
      const updated = [memeWithMetadata, ...existing].slice(0, 50);
      
      localStorage.setItem('memeforge-history', JSON.stringify(updated));
      setHistory(updated);
    } catch (error) {
      console.error('Failed to save meme:', error);
    }
  };

  return {
    history,
    saveMeme,
    loadHistory,
  };
}
