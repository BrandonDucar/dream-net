export interface MemeGenerationRequest {
  topic: string;
  style?: 'clean' | 'chaotic' | 'surreal' | 'spicy' | 'wholesome' | 'dreamnet-lore';
  format?: 'two_panel' | 'one_liner' | 'copypasta' | 'shitpost' | 'lore_moment' | 'platform_caption';
  platforms?: Array<'X' | 'Farcaster' | 'Instagram' | 'TikTok' | 'Base'>;
  audience_region?: 'US' | 'EU' | 'LATAM' | 'Asia' | 'Global';
  branding?: string;
  generate_image?: boolean;
}

export interface MemeGenerationResponse {
  meme: {
    top_panel: string;
    bottom_panel: string;
  };
  caption: string;
  platform_variants: {
    X: string;
    Farcaster: string;
    Instagram: string;
    TikTok: string;
    Base: string;
  };
  extra_variants: string[];
  spicy_alt: string;
  safe_alt: string;
  image_url?: string;
  branding?: string;
  timestamp?: number;
  id?: string;
}
