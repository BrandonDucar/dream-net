import { NextResponse } from "next/server";

// Multi-source metals pricing with automatic fallback
// Tries multiple free APIs in sequence until one succeeds

interface MetalPrices {
  gold: number;
  silver: number;
  platinum: number;
  palladium: number;
  rhodium: number;
  currency: string;
  timestamp: number;
  dailyHigh: {
    gold: number;
    silver: number;
    platinum: number;
    palladium: number;
    rhodium: number;
  };
  dailyLow: {
    gold: number;
    silver: number;
    platinum: number;
    palladium: number;
    rhodium: number;
  };
}

// Source 1: Try Metals-API format (popular free tier)
async function fetchFromMetalsAPI(): Promise<MetalPrices | null> {
  try {
    const apiKey = process.env.METALS_API_KEY;
    if (!apiKey) return null;

    const response = await fetch(
      `https://metals-api.com/api/latest?access_key=${apiKey}&base=USD&symbols=XAU,XAG,XPT,XPD`,
      {
        next: { revalidate: 300 },
      }
    );

    if (response.ok) {
      const data = await response.json();
      if (!data.success || !data.rates) return null;

      const rates = data.rates;
      
      const gold = rates.XAU ? (1 / rates.XAU) : 2667.45;
      const silver = rates.XAG ? (1 / rates.XAG) : 30.82;
      const platinum = rates.XPT ? (1 / rates.XPT) : 962.10;
      const palladium = rates.XPD ? (1 / rates.XPD) : 978.25;
      const rhodium = 4825.00;

      return {
        gold,
        silver,
        platinum,
        palladium,
        rhodium,
        currency: "USD",
        timestamp: data.timestamp || Math.floor(Date.now() / 1000),
        dailyHigh: {
          gold: gold * 1.015,
          silver: silver * 1.02,
          platinum: platinum * 1.018,
          palladium: palladium * 1.025,
          rhodium: rhodium * 1.03,
        },
        dailyLow: {
          gold: gold * 0.985,
          silver: silver * 0.98,
          platinum: platinum * 0.982,
          palladium: palladium * 0.975,
          rhodium: rhodium * 0.97,
        },
      };
    }
  } catch (error) {
    console.log("Metals-API failed, trying next source...");
  }
  return null;
}

// Source 2: Try MetalpriceAPI format
async function fetchFromMetalpriceAPI(): Promise<MetalPrices | null> {
  try {
    const apiKey = process.env.METALPRICEAPI_KEY;
    if (!apiKey) return null;

    const response = await fetch(
      `https://api.metalpriceapi.com/v1/latest?api_key=${apiKey}&base=USD&currencies=XAU,XAG,XPT,XPD,XRH`,
      {
        next: { revalidate: 300 },
      }
    );

    if (response.ok) {
      const data = await response.json();
      if (!data.success || !data.rates) return null;

      const rates = data.rates;
      
      const gold = rates.XAU ? (1 / rates.XAU) : 2667.45;
      const silver = rates.XAG ? (1 / rates.XAG) : 30.82;
      const platinum = rates.XPT ? (1 / rates.XPT) : 962.10;
      const palladium = rates.XPD ? (1 / rates.XPD) : 978.25;
      const rhodium = rates.XRH ? (1 / rates.XRH) : 4825.00;

      return {
        gold,
        silver,
        platinum,
        palladium,
        rhodium,
        currency: "USD",
        timestamp: data.timestamp || Math.floor(Date.now() / 1000),
        dailyHigh: {
          gold: gold * 1.015,
          silver: silver * 1.02,
          platinum: platinum * 1.018,
          palladium: palladium * 1.025,
          rhodium: rhodium * 1.03,
        },
        dailyLow: {
          gold: gold * 0.985,
          silver: silver * 0.98,
          platinum: platinum * 0.982,
          palladium: palladium * 0.975,
          rhodium: rhodium * 0.97,
        },
      };
    }
  } catch (error) {
    console.log("MetalpriceAPI failed, trying next source...");
  }
  return null;
}

// Source 3: Try GoldAPI format
async function fetchFromGoldAPI(): Promise<MetalPrices | null> {
  try {
    const apiKey = process.env.GOLDAPI_KEY;
    if (!apiKey) return null;

    const response = await fetch(
      "https://www.goldapi.io/api/XAU/USD",
      {
        headers: {
          "x-access-token": apiKey,
        },
        next: { revalidate: 300 },
      }
    );

    if (response.ok) {
      const data = await response.json();
      
      const gold = data.price || data.price_gram_24k * 31.1035;
      const silver = 30.82; // GoldAPI is gold-only
      const platinum = 962.10;
      const palladium = 978.25;
      const rhodium = 4825.00;

      return {
        gold,
        silver,
        platinum,
        palladium,
        rhodium,
        currency: "USD",
        timestamp: Math.floor(Date.now() / 1000),
        dailyHigh: {
          gold: gold * 1.015,
          silver: silver * 1.02,
          platinum: platinum * 1.018,
          palladium: palladium * 1.025,
          rhodium: rhodium * 1.03,
        },
        dailyLow: {
          gold: gold * 0.985,
          silver: silver * 0.98,
          platinum: platinum * 0.982,
          palladium: palladium * 0.975,
          rhodium: rhodium * 0.97,
        },
      };
    }
  } catch (error) {
    console.log("GoldAPI failed, trying next source...");
  }
  return null;
}

// Fallback to realistic mock data
function getFallbackPrices(): MetalPrices {
  const gold = 2667.45;
  const silver = 30.82;
  const platinum = 962.10;
  const palladium = 978.25;
  const rhodium = 4825.00;

  return {
    gold,
    silver,
    platinum,
    palladium,
    rhodium,
    currency: "USD",
    timestamp: Math.floor(Date.now() / 1000),
    dailyHigh: {
      gold: gold * 1.015,
      silver: silver * 1.02,
      platinum: platinum * 1.018,
      palladium: palladium * 1.025,
      rhodium: rhodium * 1.03,
    },
    dailyLow: {
      gold: gold * 0.985,
      silver: silver * 0.98,
      platinum: platinum * 0.982,
      palladium: palladium * 0.975,
      rhodium: rhodium * 0.97,
    },
  };
}

export async function GET(): Promise<NextResponse> {
  try {
    // Try sources in sequence - add your API keys to .env to enable
    const sources = [
      fetchFromMetalsAPI,        // Set METALS_API_KEY
      fetchFromMetalpriceAPI,    // Set METALPRICEAPI_KEY
      fetchFromGoldAPI,          // Set GOLDAPI_KEY
    ];

    for (const source of sources) {
      const result = await source();
      if (result) {
        return NextResponse.json(result);
      }
    }

    // All sources failed or no API keys provided - use fallback
    console.log("All API sources unavailable, using fallback data");
    return NextResponse.json(getFallbackPrices());
  } catch (error: unknown) {
    console.error("Error in spot price handler:", error);
    return NextResponse.json(getFallbackPrices());
  }
}
