'use client'
import { useState, useEffect, useMemo, useCallback } from "react";
import type {
  BuyCategory,
  BuyCategoryComputed,
  SpotData,
  SpotMap,
  MetalCode,
  DailyHighLow,
} from "@/types";
import { defaultCategories } from "@/data/buyCategories";
import {
  meltPerOz,
  meltPerGram,
  computeBuyFromPct,
  computeSellFromPct,
  computeProfit,
} from "@/lib/buysheet";
import { SpotBar } from "@/components/SpotBar";
import { BuySheetTable } from "@/components/BuySheetTable";
import { CategorySettings } from "@/components/CategorySettings";
import { QuickQuoteCalculator } from "@/components/QuickQuoteCalculator";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Printer, Download, Settings2, Calculator } from "lucide-react";
import { toast } from "sonner";
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

const STORAGE_KEY = "dealer-buysheet-categories";
const AUTO_REFRESH_KEY = "dealer-buysheet-autorefresh";

export default function Page(): JSX.Element {
  const { addMiniApp } = useAddMiniApp();
  const isInFarcaster = useIsInFarcaster();
  useQuickAuth(isInFarcaster);

  useEffect(() => {
    const tryAddMiniApp = async () => {
      try {
        await addMiniApp();
      } catch (error) {
        console.error("Failed to add mini app:", error);
      }
    };

    tryAddMiniApp();
  }, [addMiniApp]);

  useEffect(() => {
    const initializeFarcaster = async () => {
      try {
        await new Promise((resolve) => setTimeout(resolve, 100));

        if (document.readyState !== "complete") {
          await new Promise<void>((resolve) => {
            if (document.readyState === "complete") {
              resolve();
            } else {
              window.addEventListener("load", () => resolve(), { once: true });
            }
          });
        }

        await sdk.actions.ready();
        console.log("Farcaster SDK initialized successfully - app fully loaded");
      } catch (error) {
        console.error("Failed to initialize Farcaster SDK:", error);

        setTimeout(async () => {
          try {
            await sdk.actions.ready();
            console.log("Farcaster SDK initialized on retry");
          } catch (retryError) {
            console.error("Farcaster SDK retry failed:", retryError);
          }
        }, 1000);
      }
    };

    initializeFarcaster();
  }, []);

  const [spotData, setSpotData] = useState<SpotData | null>(null);
  const [categories, setCategories] = useState<BuyCategory[]>(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        try {
          return JSON.parse(stored);
        } catch {
          return defaultCategories;
        }
      }
    }
    return defaultCategories;
  });
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [showQuickQuote, setShowQuickQuote] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<string>("metal");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  const [filterMetal, setFilterMetal] = useState<MetalCode | "ALL">("ALL");
  const [autoRefresh, setAutoRefresh] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(AUTO_REFRESH_KEY);
      return stored === "true";
    }
    return false;
  });
  const [dailyHighLow, setDailyHighLow] = useState<DailyHighLow | null>(null);

  // Save categories to localStorage
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(categories));
    }
  }, [categories]);

  // Save auto-refresh preference
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem(AUTO_REFRESH_KEY, autoRefresh.toString());
    }
  }, [autoRefresh]);

  // Generate mock daily high/low based on current spot
  const generateDailyHighLow = useCallback((spot: SpotData): DailyHighLow => {
    return {
      gold: {
        high: spot.gold * 1.015,
        low: spot.gold * 0.985,
      },
      silver: {
        high: spot.silver * 1.02,
        low: spot.silver * 0.98,
      },
      platinum: {
        high: spot.platinum * 1.018,
        low: spot.platinum * 0.982,
      },
      palladium: {
        high: spot.palladium * 1.025,
        low: spot.palladium * 0.975,
      },
      rhodium: {
        high: spot.rhodium * 1.03,
        low: spot.rhodium * 0.97,
      },
    };
  }, []);

  // Fetch spot prices
  const fetchSpotPrices = async (): Promise<void> => {
    setIsRefreshing(true);
    try {
      const response = await fetch("/api/spot");
      if (!response.ok) {
        throw new Error("Failed to fetch spot prices");
      }
      const data: SpotData = await response.json();
      setSpotData(data);
      setDailyHighLow(generateDailyHighLow(data));
      toast.success("Spot prices updated");
    } catch (error: unknown) {
      console.error("Error fetching spot prices:", error);
      toast.error("Failed to fetch spot prices");
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchSpotPrices();
  }, []);

  // Auto-refresh every 5 minutes
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(
      () => {
        fetchSpotPrices();
      },
      5 * 60 * 1000
    ); // 5 minutes

    return () => clearInterval(interval);
  }, [autoRefresh]);

  // Compute categories with melt, buy, sell, and profit values
  const computedCategories = useMemo<BuyCategoryComputed[]>(() => {
    if (!spotData) return [];

    const spots: SpotMap = {
      gold: spotData.gold,
      silver: spotData.silver,
      platinum: spotData.platinum,
      palladium: spotData.palladium,
      rhodium: spotData.rhodium,
    };

    return categories.map((cat: BuyCategory) => {
      const meltOz = meltPerOz(cat.metal, cat.purity, spots);
      const meltGram = meltPerGram(cat.metal, cat.purity, spots);
      const { buyPerOz, buyPerGram } = computeBuyFromPct(
        meltOz,
        meltGram,
        cat.bidPctOfMelt
      );
      const { sellPerOz, sellPerGram } = computeSellFromPct(
        meltOz,
        meltGram,
        cat.sellPctOfMelt
      );
      const { profitPerOz, profitPerGram } = computeProfit(
        sellPerOz,
        sellPerGram,
        buyPerOz,
        buyPerGram
      );

      return {
        ...cat,
        meltPerOz: meltOz,
        meltPerGram: meltGram,
        buyPerOz,
        buyPerGram,
        sellPerOz,
        sellPerGram,
        profitPerOz,
        profitPerGram,
      };
    });
  }, [spotData, categories]);

  const handleUpdateBidPct = (id: string, newPct: number): void => {
    setCategories((prev: BuyCategory[]) =>
      prev.map((cat: BuyCategory) =>
        cat.id === id ? { ...cat, bidPctOfMelt: newPct } : cat
      )
    );
  };

  const handleUpdateSellPct = (id: string, newPct: number): void => {
    setCategories((prev: BuyCategory[]) =>
      prev.map((cat: BuyCategory) =>
        cat.id === id ? { ...cat, sellPctOfMelt: newPct } : cat
      )
    );
  };

  const handleUpdateNotes = (id: string, notes: string): void => {
    setCategories((prev: BuyCategory[]) =>
      prev.map((cat: BuyCategory) => (cat.id === id ? { ...cat, notes } : cat))
    );
  };

  const handleDeleteCategory = (id: string): void => {
    setCategories((prev: BuyCategory[]) =>
      prev.filter((cat: BuyCategory) => cat.id !== id)
    );
    toast.success("Category removed");
  };

  const handleAddCategory = (
    newCat: Omit<BuyCategory, "id" | "isDefault">
  ): void => {
    const id = `custom-${Date.now()}`;
    setCategories((prev: BuyCategory[]) => [
      ...prev,
      { ...newCat, id, isDefault: false },
    ]);
    toast.success("Category added");
  };

  const handleResetCategories = (): void => {
    setCategories(defaultCategories);
    localStorage.removeItem(STORAGE_KEY);
    toast.success("Categories reset to defaults");
  };

  const handlePrint = (): void => {
    window.print();
  };

  const handleExportCSV = (): void => {
    const headers = [
      "Category",
      "Metal",
      "Purity",
      "Basis",
      "Bid % of Melt",
      "Sell % of Melt",
      "Melt / oz",
      "Melt / g",
      "Buy / oz",
      "Buy / g",
      "Sell / oz",
      "Sell / g",
      "Profit / oz",
      "Profit / g",
      "Notes",
    ];

    const rows = computedCategories.map((cat: BuyCategoryComputed) => [
      cat.name,
      cat.metal,
      (cat.purity * 100).toFixed(2) + "%",
      cat.basis,
      cat.bidPctOfMelt.toString(),
      cat.sellPctOfMelt.toString(),
      cat.meltPerOz.toFixed(2),
      cat.meltPerGram.toFixed(2),
      cat.buyPerOz.toFixed(2),
      cat.buyPerGram.toFixed(2),
      cat.sellPerOz.toFixed(2),
      cat.sellPerGram.toFixed(2),
      cat.profitPerOz.toFixed(2),
      cat.profitPerGram.toFixed(2),
      cat.notes,
    ]);

    const csv = [headers, ...rows]
      .map((row: string[]) => row.join(","))
      .join("\n");

    navigator.clipboard
      .writeText(csv)
      .then(() => {
        toast.success("CSV copied to clipboard");
      })
      .catch(() => {
        toast.error("Failed to copy CSV");
      });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      {/* Print Styles */}
      <style jsx global>{`
        @media print {
          body {
            background: white;
            color: black;
          }
          .print\\:hidden {
            display: none !important;
          }
          table {
            border: 1px solid #000;
          }
          th,
          td {
            border: 1px solid #000;
            color: black;
          }
        }
      `}</style>

      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-900 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-cyan-400">
              Dealer Buy Sheet
            </h1>
            <p className="text-sm text-slate-400">
              Live metals pricing with adjustable bid levels
            </p>
          </div>
          <div className="flex gap-3 print:hidden">
            <Button
              onClick={(): void => setShowQuickQuote(!showQuickQuote)}
              size="sm"
              className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600"
            >
              <Calculator className="mr-2 h-4 w-4" />
              {showQuickQuote ? "Hide" : "Show"} Quote
            </Button>
            <Button
              onClick={(): void => setShowSettings(!showSettings)}
              size="sm"
              className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600"
            >
              <Settings2 className="mr-2 h-4 w-4" />
              {showSettings ? "Hide" : "Show"} Settings
            </Button>
            <Button
              onClick={handleExportCSV}
              size="sm"
              className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600"
            >
              <Download className="mr-2 h-4 w-4" />
              Copy CSV
            </Button>
            <Button
              onClick={handlePrint}
              size="sm"
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <Printer className="mr-2 h-4 w-4" />
              Print Sheet
            </Button>
          </div>
        </div>
      </header>

      {/* Spot Bar */}
      <SpotBar
        spotData={spotData}
        dailyHighLow={dailyHighLow}
        onRefresh={fetchSpotPrices}
        isRefreshing={isRefreshing}
        onResetCategories={handleResetCategories}
      />

      {/* Controls Bar */}
      <div className="border-b border-slate-700 bg-slate-900/50 px-6 py-3 print:hidden">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <Label htmlFor="sortBy" className="text-sm text-slate-300">
              Sort by:
            </Label>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger
                id="sortBy"
                className="h-8 w-32 border-slate-600 bg-slate-800 text-slate-200"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="border-slate-600 bg-slate-800">
                <SelectItem value="metal" className="text-slate-200">
                  Metal
                </SelectItem>
                <SelectItem value="name" className="text-slate-200">
                  Name
                </SelectItem>
                <SelectItem value="purity" className="text-slate-200">
                  Purity
                </SelectItem>
                <SelectItem value="bidPct" className="text-slate-200">
                  Bid %
                </SelectItem>
                <SelectItem value="buyPerOz" className="text-slate-200">
                  Buy/oz
                </SelectItem>
              </SelectContent>
            </Select>
            <Button
              onClick={(): void =>
                setSortOrder((prev: "asc" | "desc") =>
                  prev === "asc" ? "desc" : "asc"
                )
              }
              size="sm"
              variant="outline"
              className="h-8 border-slate-600 text-slate-200 hover:bg-slate-800"
            >
              {sortOrder === "asc" ? "↑" : "↓"}
            </Button>
          </div>

          <div className="flex items-center gap-2">
            <Label htmlFor="filterMetal" className="text-sm text-slate-300">
              Filter:
            </Label>
            <Select
              value={filterMetal}
              onValueChange={(val: string): void => setFilterMetal(val as MetalCode | "ALL")}
            >
              <SelectTrigger
                id="filterMetal"
                className="h-8 w-32 border-slate-600 bg-slate-800 text-slate-200"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="border-slate-600 bg-slate-800">
                <SelectItem value="ALL" className="text-slate-200">
                  All Metals
                </SelectItem>
                <SelectItem value="AU" className="text-slate-200">
                  Gold
                </SelectItem>
                <SelectItem value="AG" className="text-slate-200">
                  Silver
                </SelectItem>
                <SelectItem value="PT" className="text-slate-200">
                  Platinum
                </SelectItem>
                <SelectItem value="PD" className="text-slate-200">
                  Palladium
                </SelectItem>
                <SelectItem value="RH" className="text-slate-200">
                  Rhodium
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="ml-auto flex items-center gap-2">
            <Label htmlFor="autoRefresh" className="text-sm text-slate-300">
              Auto-refresh (5 min)
            </Label>
            <Switch
              id="autoRefresh"
              checked={autoRefresh}
              onCheckedChange={setAutoRefresh}
            />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 gap-6 p-6 lg:grid-cols-4">
        {/* Buy Sheet Table */}
        <div
          className={`${
            showSettings || showQuickQuote
              ? "lg:col-span-3"
              : "lg:col-span-4"
          }`}
        >
          <Card className="border-slate-700 bg-slate-900/50">
            <CardContent className="p-0">
              <div className="px-6 py-4">
                <p className="text-xs text-slate-400">
                  All prices are dealer buy/sell prices based on live melt
                  values. Adjust percentages to reflect current market
                  conditions.
                </p>
              </div>
              <BuySheetTable
                categories={computedCategories}
                onUpdateBidPct={handleUpdateBidPct}
                onUpdateSellPct={handleUpdateSellPct}
                onUpdateNotes={handleUpdateNotes}
                onDeleteCategory={handleDeleteCategory}
                sortBy={sortBy}
                sortOrder={sortOrder}
                filterMetal={filterMetal}
              />
            </CardContent>
          </Card>
        </div>

        {/* Side Panels */}
        {(showSettings || showQuickQuote) && (
          <div className="space-y-6 lg:col-span-1">
            {showQuickQuote && (
              <QuickQuoteCalculator categories={computedCategories} />
            )}
            {showSettings && (
              <CategorySettings onAddCategory={handleAddCategory} />
            )}
          </div>
        )}
      </div>
    </div>
  );
}
