'use client'
import { useState } from "react";
import type { BuyCategoryComputed, MetalCode } from "@/types";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Trash2, ChevronDown, ChevronRight } from "lucide-react";

interface BuySheetTableProps {
  categories: BuyCategoryComputed[];
  onUpdateBidPct: (id: string, newPct: number) => void;
  onUpdateSellPct: (id: string, newPct: number) => void;
  onUpdateNotes: (id: string, notes: string) => void;
  onDeleteCategory: (id: string) => void;
  sortBy: string;
  sortOrder: "asc" | "desc";
  filterMetal: MetalCode | "ALL";
}

const metalNames: Record<MetalCode, string> = {
  AU: "Gold",
  AG: "Silver",
  PT: "Platinum",
  PD: "Palladium",
  RH: "Rhodium",
};

const metalColors: Record<MetalCode, string> = {
  AU: "text-yellow-400",
  AG: "text-slate-300",
  PT: "text-slate-400",
  PD: "text-slate-500",
  RH: "text-purple-400",
};

export function BuySheetTable({
  categories,
  onUpdateBidPct,
  onUpdateSellPct,
  onUpdateNotes,
  onDeleteCategory,
  sortBy,
  sortOrder,
  filterMetal,
}: BuySheetTableProps): JSX.Element {
  const [collapsedGroups, setCollapsedGroups] = useState<Set<MetalCode>>(
    new Set()
  );
  const [editingNotes, setEditingNotes] = useState<string | null>(null);

  const toggleGroup = (metal: MetalCode): void => {
    setCollapsedGroups((prev: Set<MetalCode>) => {
      const newSet = new Set(prev);
      if (newSet.has(metal)) {
        newSet.delete(metal);
      } else {
        newSet.add(metal);
      }
      return newSet;
    });
  };

  // Filter by metal
  const filteredCategories =
    filterMetal === "ALL"
      ? categories
      : categories.filter(
          (cat: BuyCategoryComputed) => cat.metal === filterMetal
        );

  // Sort categories
  const sortedCategories = [...filteredCategories].sort(
    (a: BuyCategoryComputed, b: BuyCategoryComputed) => {
      let aVal: number | string = 0;
      let bVal: number | string = 0;

      switch (sortBy) {
        case "name":
          aVal = a.name;
          bVal = b.name;
          break;
        case "metal":
          aVal = a.metal;
          bVal = b.metal;
          break;
        case "purity":
          aVal = a.purity;
          bVal = b.purity;
          break;
        case "bidPct":
          aVal = a.bidPctOfMelt;
          bVal = b.bidPctOfMelt;
          break;
        case "buyPerOz":
          aVal = a.buyPerOz;
          bVal = b.buyPerOz;
          break;
        default:
          return 0;
      }

      if (typeof aVal === "string" && typeof bVal === "string") {
        return sortOrder === "asc"
          ? aVal.localeCompare(bVal)
          : bVal.localeCompare(aVal);
      }

      return sortOrder === "asc"
        ? (aVal as number) - (bVal as number)
        : (bVal as number) - (aVal as number);
    }
  );

  // Group by metal
  const groupedCategories = sortedCategories.reduce(
    (acc: Record<MetalCode, BuyCategoryComputed[]>, cat: BuyCategoryComputed) => {
      if (!acc[cat.metal]) {
        acc[cat.metal] = [];
      }
      acc[cat.metal].push(cat);
      return acc;
    },
    {} as Record<MetalCode, BuyCategoryComputed[]>
  );

  const metals = Object.keys(groupedCategories) as MetalCode[];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs">
        <thead>
          <tr className="border-b border-slate-700 bg-slate-800">
            <th className="px-3 py-2 text-left font-semibold text-cyan-400">
              Category
            </th>
            <th className="px-3 py-2 text-center font-semibold text-cyan-400">
              Purity
            </th>
            <th className="px-3 py-2 text-center font-semibold text-cyan-400">
              Bid %
            </th>
            <th className="px-3 py-2 text-center font-semibold text-cyan-400">
              Sell %
            </th>
            <th className="px-3 py-2 text-right font-semibold text-slate-400">
              Melt/oz
            </th>
            <th className="px-3 py-2 text-right font-semibold text-slate-400">
              Melt/g
            </th>
            <th className="px-3 py-2 text-right font-semibold text-green-400">
              Buy/oz
            </th>
            <th className="px-3 py-2 text-right font-semibold text-green-400">
              Buy/g
            </th>
            <th className="px-3 py-2 text-right font-semibold text-cyan-400">
              Sell/oz
            </th>
            <th className="px-3 py-2 text-right font-semibold text-cyan-400">
              Sell/g
            </th>
            <th className="px-3 py-2 text-right font-semibold text-purple-400">
              Profit/oz
            </th>
            <th className="px-3 py-2 text-left font-semibold text-slate-400">
              Notes
            </th>
            <th className="px-3 py-2 print:hidden"></th>
          </tr>
        </thead>
        <tbody>
          {metals.map((metal: MetalCode) => {
            const isCollapsed = collapsedGroups.has(metal);
            const metalCategories = groupedCategories[metal];

            return (
              <>
                {/* Group Header */}
                <tr
                  key={`header-${metal}`}
                  className="cursor-pointer border-b border-slate-700 bg-slate-800/70 hover:bg-slate-800"
                  onClick={(): void => toggleGroup(metal)}
                >
                  <td
                    colSpan={13}
                    className="px-3 py-2 font-semibold"
                  >
                    <div className="flex items-center gap-2">
                      {isCollapsed ? (
                        <ChevronRight className="h-4 w-4 text-slate-400" />
                      ) : (
                        <ChevronDown className="h-4 w-4 text-slate-400" />
                      )}
                      <span className={metalColors[metal]}>
                        {metalNames[metal]} ({metalCategories.length})
                      </span>
                    </div>
                  </td>
                </tr>

                {/* Category Rows */}
                {!isCollapsed &&
                  metalCategories.map((cat: BuyCategoryComputed) => (
                    <tr
                      key={cat.id}
                      className="border-b border-slate-800 hover:bg-slate-800/30"
                    >
                      <td className="px-3 py-2 text-slate-200">{cat.name}</td>
                      <td className="px-3 py-2 text-center text-slate-300">
                        {(cat.purity * 100).toFixed(2)}%
                      </td>
                      <td className="px-3 py-2 text-center">
                        <Input
                          type="number"
                          value={cat.bidPctOfMelt}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                            onUpdateBidPct(cat.id, parseFloat(e.target.value))
                          }
                          className="h-7 w-16 border-slate-600 bg-slate-800 text-center text-xs text-slate-200"
                        />
                      </td>
                      <td className="px-3 py-2 text-center">
                        <Input
                          type="number"
                          value={cat.sellPctOfMelt}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                            onUpdateSellPct(cat.id, parseFloat(e.target.value))
                          }
                          className="h-7 w-16 border-slate-600 bg-slate-800 text-center text-xs text-slate-200"
                        />
                      </td>
                      <td className="px-3 py-2 text-right text-slate-400">
                        ${cat.meltPerOz.toFixed(2)}
                      </td>
                      <td className="px-3 py-2 text-right text-slate-400">
                        ${cat.meltPerGram.toFixed(2)}
                      </td>
                      <td className="px-3 py-2 text-right font-semibold text-green-400">
                        ${cat.buyPerOz.toFixed(2)}
                      </td>
                      <td className="px-3 py-2 text-right font-semibold text-green-400">
                        ${cat.buyPerGram.toFixed(2)}
                      </td>
                      <td className="px-3 py-2 text-right font-semibold text-cyan-400">
                        ${cat.sellPerOz.toFixed(2)}
                      </td>
                      <td className="px-3 py-2 text-right font-semibold text-cyan-400">
                        ${cat.sellPerGram.toFixed(2)}
                      </td>
                      <td className="px-3 py-2 text-right font-semibold text-purple-400">
                        ${cat.profitPerOz.toFixed(2)}
                      </td>
                      <td className="px-3 py-2">
                        {editingNotes === cat.id ? (
                          <Input
                            type="text"
                            value={cat.notes}
                            onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                              onUpdateNotes(cat.id, e.target.value)
                            }
                            onBlur={(): void => setEditingNotes(null)}
                            autoFocus
                            className="h-7 border-slate-600 bg-slate-800 text-xs text-slate-200"
                          />
                        ) : (
                          <div
                            onClick={(): void => setEditingNotes(cat.id)}
                            className="cursor-pointer text-slate-400 hover:text-slate-300"
                          >
                            {cat.notes || <span className="italic">Add note...</span>}
                          </div>
                        )}
                      </td>
                      <td className="px-3 py-2 text-center print:hidden">
                        {!cat.isDefault && (
                          <Button
                            onClick={(): void => onDeleteCategory(cat.id)}
                            variant="ghost"
                            size="sm"
                            className="h-7 w-7 p-0 text-red-400 hover:bg-red-900/20 hover:text-red-300"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
              </>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
