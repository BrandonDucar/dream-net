'use client'
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { BuyCategory, MetalCode } from "@/types";
import { Plus } from "lucide-react";
import { toast } from "sonner";

interface CategorySettingsProps {
  onAddCategory: (newCat: Omit<BuyCategory, "id" | "isDefault">) => void;
}

export function CategorySettings({
  onAddCategory,
}: CategorySettingsProps): JSX.Element {
  const [name, setName] = useState<string>("");
  const [metal, setMetal] = useState<MetalCode>("AU");
  const [purity, setPurity] = useState<string>("0.999");
  const [basis, setBasis] = useState<"oz" | "g">("oz");
  const [bidPct, setBidPct] = useState<string>("95");
  const [sellPct, setSellPct] = useState<string>("105");
  const [notes, setNotes] = useState<string>("");

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();

    if (!name.trim()) {
      toast.error("Category name is required");
      return;
    }

    const purityNum = parseFloat(purity);
    if (isNaN(purityNum) || purityNum <= 0 || purityNum > 1) {
      toast.error("Purity must be between 0 and 1");
      return;
    }

    const bidPctNum = parseFloat(bidPct);
    if (isNaN(bidPctNum) || bidPctNum <= 0) {
      toast.error("Bid % must be a positive number");
      return;
    }

    const sellPctNum = parseFloat(sellPct);
    if (isNaN(sellPctNum) || sellPctNum <= 0) {
      toast.error("Sell % must be a positive number");
      return;
    }

    onAddCategory({
      name: name.trim(),
      metal,
      purity: purityNum,
      basis,
      bidPctOfMelt: bidPctNum,
      sellPctOfMelt: sellPctNum,
      notes: notes.trim(),
    });

    // Reset form
    setName("");
    setPurity("0.999");
    setBidPct("95");
    setSellPct("105");
    setNotes("");
  };

  return (
    <Card className="border-slate-700 bg-slate-900/50">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg text-cyan-400">
          Add Custom Category
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name" className="text-slate-300">
              Category Name
            </Label>
            <Input
              id="name"
              value={name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                setName(e.target.value)
              }
              placeholder="e.g. Gold Chains 10k"
              className="mt-1 border-slate-600 bg-slate-800 text-slate-200"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="metal" className="text-slate-300">
                Metal
              </Label>
              <Select value={metal} onValueChange={(val: string): void => setMetal(val as MetalCode)}>
                <SelectTrigger
                  id="metal"
                  className="mt-1 border-slate-600 bg-slate-800 text-slate-200"
                >
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="border-slate-600 bg-slate-800">
                  <SelectItem value="AU" className="text-slate-200">
                    Gold (AU)
                  </SelectItem>
                  <SelectItem value="AG" className="text-slate-200">
                    Silver (AG)
                  </SelectItem>
                  <SelectItem value="PT" className="text-slate-200">
                    Platinum (PT)
                  </SelectItem>
                  <SelectItem value="PD" className="text-slate-200">
                    Palladium (PD)
                  </SelectItem>
                  <SelectItem value="RH" className="text-slate-200">
                    Rhodium (RH)
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="purity" className="text-slate-300">
                Purity (0-1)
              </Label>
              <Input
                id="purity"
                type="number"
                step="0.001"
                value={purity}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                  setPurity(e.target.value)
                }
                className="mt-1 border-slate-600 bg-slate-800 text-slate-200"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="basis" className="text-slate-300">
              Basis
            </Label>
            <Select value={basis} onValueChange={(val: string): void => setBasis(val as "oz" | "g")}>
              <SelectTrigger
                id="basis"
                className="mt-1 border-slate-600 bg-slate-800 text-slate-200"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="border-slate-600 bg-slate-800">
                <SelectItem value="oz" className="text-slate-200">
                  Per Ounce (oz)
                </SelectItem>
                <SelectItem value="g" className="text-slate-200">
                  Per Gram (g)
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="bidPct" className="text-slate-300">
                Bid % of Melt
              </Label>
              <Input
                id="bidPct"
                type="number"
                step="0.1"
                value={bidPct}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                  setBidPct(e.target.value)
                }
                className="mt-1 border-slate-600 bg-slate-800 text-slate-200"
              />
            </div>

            <div>
              <Label htmlFor="sellPct" className="text-slate-300">
                Sell % of Melt
              </Label>
              <Input
                id="sellPct"
                type="number"
                step="0.1"
                value={sellPct}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                  setSellPct(e.target.value)
                }
                className="mt-1 border-slate-600 bg-slate-800 text-slate-200"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="notes" className="text-slate-300">
              Notes (Optional)
            </Label>
            <Input
              id="notes"
              value={notes}
              onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                setNotes(e.target.value)
              }
              placeholder="e.g. Hot item this week"
              className="mt-1 border-slate-600 bg-slate-800 text-slate-200"
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-green-600 hover:bg-green-700"
          >
            <Plus className="mr-2 h-4 w-4" />
            Add Category
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
