'use client'
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { BuyCategoryComputed } from "@/types";
import { Calculator } from "lucide-react";

interface QuickQuoteCalculatorProps {
  categories: BuyCategoryComputed[];
}

export function QuickQuoteCalculator({
  categories,
}: QuickQuoteCalculatorProps): JSX.Element {
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>("");
  const [weight, setWeight] = useState<string>("");
  const [unit, setUnit] = useState<"oz" | "g">("oz");

  const selectedCategory = categories.find(
    (cat: BuyCategoryComputed) => cat.id === selectedCategoryId
  );

  const calculateOffer = (): { buy: number; sell: number } | null => {
    if (!selectedCategory || !weight || parseFloat(weight) <= 0) {
      return null;
    }

    const weightNum = parseFloat(weight);
    const buyPrice =
      unit === "oz"
        ? selectedCategory.buyPerOz * weightNum
        : selectedCategory.buyPerGram * weightNum;
    const sellPrice =
      unit === "oz"
        ? selectedCategory.sellPerOz * weightNum
        : selectedCategory.sellPerGram * weightNum;

    return { buy: buyPrice, sell: sellPrice };
  };

  const offer = calculateOffer();

  return (
    <Card className="border-slate-700 bg-slate-900/50">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg text-cyan-400">
          <Calculator className="h-5 w-5" />
          Quick Quote
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="category" className="text-slate-300">
            Category
          </Label>
          <Select value={selectedCategoryId} onValueChange={setSelectedCategoryId}>
            <SelectTrigger
              id="category"
              className="mt-1 border-slate-600 bg-slate-800 text-slate-200"
            >
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent className="border-slate-600 bg-slate-800">
              {categories.map((cat: BuyCategoryComputed) => (
                <SelectItem
                  key={cat.id}
                  value={cat.id}
                  className="text-slate-200"
                >
                  {cat.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="weight" className="text-slate-300">
              Weight
            </Label>
            <Input
              id="weight"
              type="number"
              step="0.01"
              min="0"
              value={weight}
              onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                setWeight(e.target.value)
              }
              placeholder="0.00"
              className="mt-1 border-slate-600 bg-slate-800 text-slate-200"
            />
          </div>
          <div>
            <Label htmlFor="unit" className="text-slate-300">
              Unit
            </Label>
            <Select value={unit} onValueChange={(val: string): void => setUnit(val as "oz" | "g")}>
              <SelectTrigger
                id="unit"
                className="mt-1 border-slate-600 bg-slate-800 text-slate-200"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="border-slate-600 bg-slate-800">
                <SelectItem value="oz" className="text-slate-200">
                  oz
                </SelectItem>
                <SelectItem value="g" className="text-slate-200">
                  g
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {offer && (
          <div className="mt-4 space-y-2 rounded-lg border border-slate-700 bg-slate-800/50 p-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-slate-300">
                Our Buy Offer:
              </span>
              <span className="text-xl font-bold text-green-400">
                ${offer.buy.toFixed(2)}
              </span>
            </div>
            <div className="flex items-center justify-between border-t border-slate-700 pt-2">
              <span className="text-sm font-medium text-slate-300">
                Our Sell Price:
              </span>
              <span className="text-xl font-bold text-cyan-400">
                ${offer.sell.toFixed(2)}
              </span>
            </div>
          </div>
        )}

        {!offer && selectedCategory && weight && parseFloat(weight) > 0 && (
          <div className="rounded-lg border border-slate-700 bg-slate-800/50 p-3">
            <p className="text-center text-sm text-slate-400">
              Enter weight to calculate offer
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
