'use client'
import type { SpotData, MetalCode, DailyHighLow } from "@/types";
import { Button } from "@/components/ui/button";
import { RefreshCw, RotateCcw, TrendingUp, TrendingDown } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface SpotBarProps {
  spotData: SpotData | null;
  dailyHighLow: DailyHighLow | null;
  onRefresh: () => void;
  isRefreshing: boolean;
  onResetCategories: () => void;
}

interface MetalSpotProps {
  symbol: string;
  price: number;
  color: string;
  high?: number;
  low?: number;
}

function MetalSpot({
  symbol,
  price,
  color,
  high,
  low,
}: MetalSpotProps): JSX.Element {
  const isNearHigh = high && price >= high * 0.98;
  const isNearLow = low && price <= low * 1.02;

  return (
    <div className="flex flex-col gap-1 rounded-lg border border-slate-700 bg-slate-800 px-4 py-2">
      <div className="flex items-center gap-2">
        <span className={`text-sm font-bold ${color}`}>{symbol}:</span>
        <span className="text-lg font-bold text-slate-200">
          ${price.toFixed(2)}
        </span>
        {isNearHigh && (
          <Badge
            variant="outline"
            className="border-green-500 text-green-400"
          >
            <TrendingUp className="mr-1 h-3 w-3" />
            High
          </Badge>
        )}
        {isNearLow && (
          <Badge variant="outline" className="border-red-500 text-red-400">
            <TrendingDown className="mr-1 h-3 w-3" />
            Low
          </Badge>
        )}
      </div>
      {high && low && (
        <div className="text-xs text-slate-400">
          H: ${high.toFixed(2)} | L: ${low.toFixed(2)}
        </div>
      )}
    </div>
  );
}

export function SpotBar({
  spotData,
  dailyHighLow,
  onRefresh,
  isRefreshing,
  onResetCategories,
}: SpotBarProps): JSX.Element {
  const formatTimestamp = (timestamp: number): string => {
    const date = new Date(timestamp * 1000);
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  };

  return (
    <div className="border-b border-slate-700 bg-slate-900/80 px-6 py-4 print:hidden">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        {/* Spot Prices */}
        <div className="flex flex-wrap gap-3">
          {spotData ? (
            <>
              <MetalSpot
                symbol="AU"
                price={spotData.gold}
                color="text-yellow-400"
                high={dailyHighLow?.gold.high}
                low={dailyHighLow?.gold.low}
              />
              <MetalSpot
                symbol="AG"
                price={spotData.silver}
                color="text-slate-300"
                high={dailyHighLow?.silver.high}
                low={dailyHighLow?.silver.low}
              />
              <MetalSpot
                symbol="PT"
                price={spotData.platinum}
                color="text-slate-400"
                high={dailyHighLow?.platinum.high}
                low={dailyHighLow?.platinum.low}
              />
              <MetalSpot
                symbol="PD"
                price={spotData.palladium}
                color="text-slate-500"
                high={dailyHighLow?.palladium.high}
                low={dailyHighLow?.palladium.low}
              />
              <MetalSpot
                symbol="RH"
                price={spotData.rhodium}
                color="text-purple-400"
                high={dailyHighLow?.rhodium.high}
                low={dailyHighLow?.rhodium.low}
              />
            </>
          ) : (
            <p className="text-sm text-slate-400">Loading spot prices...</p>
          )}
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center gap-3">
          {spotData && (
            <p className="text-xs text-slate-400">
              Updated: {formatTimestamp(spotData.timestamp)}
            </p>
          )}
          <Button
            onClick={onRefresh}
            disabled={isRefreshing}
            size="sm"
            className="bg-cyan-600 hover:bg-cyan-700 text-white"
          >
            <RefreshCw
              className={`mr-2 h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`}
            />
            Refresh Spot
          </Button>
          <Button
            onClick={onResetCategories}
            size="sm"
            className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600"
          >
            <RotateCcw className="mr-2 h-4 w-4" />
            Reset Defaults
          </Button>
        </div>
      </div>
    </div>
  );
}
