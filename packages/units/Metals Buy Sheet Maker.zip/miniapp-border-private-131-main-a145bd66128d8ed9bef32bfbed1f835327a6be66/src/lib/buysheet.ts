import type { MetalCode, SpotMap } from "@/types";

export function getSpotForMetal(metal: MetalCode, spots: SpotMap): number {
  switch (metal) {
    case "AU":
      return spots.gold;
    case "AG":
      return spots.silver;
    case "PT":
      return spots.platinum;
    case "PD":
      return spots.palladium;
    case "RH":
      return spots.rhodium;
    default:
      return 0;
  }
}

// Melt per oz for a given category (per troy ounce)
export function meltPerOz(
  metal: MetalCode,
  purity: number,
  spots: SpotMap
): number {
  const spot = getSpotForMetal(metal, spots);
  return spot * purity;
}

// Melt per gram
export function meltPerGram(
  metal: MetalCode,
  purity: number,
  spots: SpotMap
): number {
  const perOz = meltPerOz(metal, purity, spots);
  return perOz / 31.1034768;
}

// Compute final buy numbers
export function computeBuyFromPct(
  meltPerOzValue: number,
  meltPerGramValue: number,
  bidPctOfMelt: number
): { buyPerOz: number; buyPerGram: number } {
  const factor = bidPctOfMelt / 100;
  const buyPerOz = meltPerOzValue * factor;
  const buyPerGram = meltPerGramValue * factor;
  return { buyPerOz, buyPerGram };
}

// Compute sell prices
export function computeSellFromPct(
  meltPerOzValue: number,
  meltPerGramValue: number,
  sellPctOfMelt: number
): { sellPerOz: number; sellPerGram: number } {
  const factor = sellPctOfMelt / 100;
  const sellPerOz = meltPerOzValue * factor;
  const sellPerGram = meltPerGramValue * factor;
  return { sellPerOz, sellPerGram };
}

// Compute profit margin
export function computeProfit(
  sellPerOz: number,
  sellPerGram: number,
  buyPerOz: number,
  buyPerGram: number
): { profitPerOz: number; profitPerGram: number } {
  return {
    profitPerOz: sellPerOz - buyPerOz,
    profitPerGram: sellPerGram - buyPerGram,
  };
}
