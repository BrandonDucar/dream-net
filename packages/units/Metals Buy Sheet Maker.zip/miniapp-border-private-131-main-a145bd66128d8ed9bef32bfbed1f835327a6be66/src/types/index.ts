export type MetalCode = "AU" | "AG" | "PT" | "PD" | "RH";

export interface BuyCategory {
  id: string;
  name: string;
  metal: MetalCode;
  purity: number;
  basis: "oz" | "g";
  bidPctOfMelt: number;
  sellPctOfMelt: number;
  notes: string;
  isDefault: boolean;
}

export interface BuyCategoryComputed extends BuyCategory {
  meltPerOz: number;
  meltPerGram: number;
  buyPerOz: number;
  buyPerGram: number;
  sellPerOz: number;
  sellPerGram: number;
  profitPerOz: number;
  profitPerGram: number;
}

export interface SpotMap {
  gold: number;
  silver: number;
  platinum: number;
  palladium: number;
  rhodium: number;
}

export interface SpotData extends SpotMap {
  currency: string;
  timestamp: number;
}

export interface DailyHighLow {
  gold: { high: number; low: number };
  silver: { high: number; low: number };
  platinum: { high: number; low: number };
  palladium: { high: number; low: number };
  rhodium: { high: number; low: number };
}

export interface QuickQuote {
  categoryId: string;
  weight: number;
  unit: "oz" | "g";
}
