import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'
export const revalidate = 0

interface MarketDataResponse {
  btc: {
    price: number
    change24h: number
    timestamp: string
  }
  fxRates: {
    usdIndex: number
    eurUsd: number
    timestamp: string
  }
  stock: {
    spx: number
    spxChange: number
    timestamp: string
  }
  vix: {
    value: number
    timestamp: string
  }
  timestamp: string
}

const CACHE_DURATION = 60000 // 60 seconds
let cachedData: MarketDataResponse | null = null
let lastFetch = 0

async function fetchBitcoinPrice(): Promise<{ price: number; change24h: number }> {
  try {
    const response = await fetch(
      'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd&include_24hr_change=true',
      { cache: 'no-store' }
    )
    
    if (!response.ok) {
      throw new Error('CoinGecko API error')
    }
    
    const data = await response.json()
    return {
      price: data.bitcoin.usd,
      change24h: data.bitcoin.usd_24h_change || 0
    }
  } catch (error) {
    console.error('Error fetching Bitcoin price:', error)
    return { price: 43000, change24h: 2.5 } // Fallback
  }
}

async function fetchFXRates(): Promise<{ usdIndex: number; eurUsd: number }> {
  try {
    const response = await fetch(
      'https://api.frankfurter.app/latest?from=USD&to=EUR',
      { cache: 'no-store' }
    )
    
    if (!response.ok) {
      throw new Error('Frankfurter API error')
    }
    
    const data = await response.json()
    const eurUsd = data.rates.EUR
    
    // Calculate USD index (inverted EUR/USD as proxy)
    const usdIndex = 100 / eurUsd
    
    return {
      usdIndex: parseFloat(usdIndex.toFixed(2)),
      eurUsd: parseFloat(eurUsd.toFixed(4))
    }
  } catch (error) {
    console.error('Error fetching FX rates:', error)
    return { usdIndex: 104.5, eurUsd: 0.92 } // Fallback
  }
}

async function fetchStockData(): Promise<{ spx: number; spxChange: number }> {
  try {
    // Alpha Vantage free API key (demo key - replace with your own for production)
    const apiKey = 'demo'
    const response = await fetch(
      `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=SPY&apikey=${apiKey}`,
      { cache: 'no-store' }
    )
    
    if (!response.ok) {
      throw new Error('Alpha Vantage API error')
    }
    
    const data = await response.json()
    
    if (data['Global Quote']) {
      const quote = data['Global Quote']
      const price = parseFloat(quote['05. price'])
      const changePercent = parseFloat(quote['10. change percent'].replace('%', ''))
      
      // SPY tracks SPX at about 1/10 the value, multiply by 10 for SPX approximation
      return {
        spx: parseFloat((price * 10).toFixed(2)),
        spxChange: parseFloat(changePercent.toFixed(2))
      }
    }
    
    throw new Error('Invalid response from Alpha Vantage')
  } catch (error) {
    console.error('Error fetching stock data:', error)
    return { spx: 5000, spxChange: 0.5 } // Fallback
  }
}

async function fetchVIX(): Promise<number> {
  try {
    // Alpha Vantage for VIX
    const apiKey = 'demo'
    const response = await fetch(
      `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=VIX&apikey=${apiKey}`,
      { cache: 'no-store' }
    )
    
    if (!response.ok) {
      throw new Error('Alpha Vantage VIX API error')
    }
    
    const data = await response.json()
    
    if (data['Global Quote']) {
      const quote = data['Global Quote']
      return parseFloat(quote['05. price'])
    }
    
    throw new Error('Invalid VIX response')
  } catch (error) {
    console.error('Error fetching VIX:', error)
    return 18.5 // Fallback
  }
}

export async function GET(): Promise<NextResponse<MarketDataResponse>> {
  const now = Date.now()
  
  // Return cached data if fresh
  if (cachedData && (now - lastFetch) < CACHE_DURATION) {
    return NextResponse.json(cachedData)
  }
  
  // Fetch all data in parallel
  const [btcData, fxData, stockData, vixValue] = await Promise.all([
    fetchBitcoinPrice(),
    fetchFXRates(),
    fetchStockData(),
    fetchVIX()
  ])
  
  const timestamp = new Date().toISOString()
  
  const marketData: MarketDataResponse = {
    btc: {
      price: btcData.price,
      change24h: btcData.change24h,
      timestamp
    },
    fxRates: {
      usdIndex: fxData.usdIndex,
      eurUsd: fxData.eurUsd,
      timestamp
    },
    stock: {
      spx: stockData.spx,
      spxChange: stockData.spxChange,
      timestamp
    },
    vix: {
      value: vixValue,
      timestamp
    },
    timestamp
  }
  
  cachedData = marketData
  lastFetch = now
  
  return NextResponse.json(marketData)
}
