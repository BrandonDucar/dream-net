import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'
export const revalidate = 0

interface VolatilityResponse {
  metal: string
  volatility1m: number
  volatility5m: number
  volatility1h: number
  volatility24h: number
  timestamp: string
}

const CACHE_DURATION = 60000 // 60 seconds
const cache = new Map<string, { data: VolatilityResponse; timestamp: number }>()

// Simulated historical price fetching - in production, you'd use real historical data
async function calculateVolatility(
  metal: string,
  currentPrice: number,
  timeframe: '1m' | '5m' | '1h' | '24h'
): Promise<number> {
  try {
    // For real implementation, fetch historical prices from Metals-API or similar
    // This is a simplified calculation using current price variance
    
    const timeframeMinutes: Record<typeof timeframe, number> = {
      '1m': 1,
      '5m': 5,
      '1h': 60,
      '24h': 1440
    }
    
    const minutes = timeframeMinutes[timeframe]
    
    // Simulate price variance based on timeframe
    // Longer timeframes typically show higher volatility
    const baseVolatility = 0.3 // Base volatility percentage
    const timeMultiplier = Math.sqrt(minutes / 60) // Volatility scales with sqrt of time
    const randomFactor = Math.random() * 0.5 + 0.75 // 0.75 to 1.25
    
    const volatility = baseVolatility * timeMultiplier * randomFactor
    
    return parseFloat(volatility.toFixed(2))
  } catch (error) {
    console.error(`Error calculating ${timeframe} volatility:`, error)
    return 1.0 // Fallback
  }
}

export async function GET(request: Request): Promise<NextResponse<VolatilityResponse>> {
  const { searchParams } = new URL(request.url)
  const metal = searchParams.get('metal') || 'gold'
  const priceParam = searchParams.get('price')
  const currentPrice = priceParam ? parseFloat(priceParam) : 2050
  
  const now = Date.now()
  const cacheKey = `${metal}-${currentPrice}`
  const cached = cache.get(cacheKey)
  
  // Return cached data if fresh
  if (cached && (now - cached.timestamp) < CACHE_DURATION) {
    return NextResponse.json(cached.data)
  }
  
  // Calculate volatility for all timeframes in parallel
  const [vol1m, vol5m, vol1h, vol24h] = await Promise.all([
    calculateVolatility(metal, currentPrice, '1m'),
    calculateVolatility(metal, currentPrice, '5m'),
    calculateVolatility(metal, currentPrice, '1h'),
    calculateVolatility(metal, currentPrice, '24h')
  ])
  
  const volatilityData: VolatilityResponse = {
    metal,
    volatility1m: vol1m,
    volatility5m: vol5m,
    volatility1h: vol1h,
    volatility24h: vol24h,
    timestamp: new Date().toISOString()
  }
  
  cache.set(cacheKey, { data: volatilityData, timestamp: now })
  
  return NextResponse.json(volatilityData)
}
