'use client'
import { useState, useEffect } from 'react'
import { Dashboard } from '@/components/dashboard'
import type { UserPreferences } from '@/types/metals'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Home(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  
  const [preferences, setPreferences] = useState<UserPreferences>({
    metals: ['gold', 'silver'],
    features: ['all'],
    region: 'United States',
    city: 'New York'
  })
  const [isLoading, setIsLoading] = useState<boolean>(true)

  useEffect(() => {
    const stored = localStorage.getItem('metalsmind_preferences')
    if (stored) {
      try {
        const parsed = JSON.parse(stored) as UserPreferences
        setPreferences(parsed)
      } catch (e) {
        console.error('Failed to parse stored preferences:', e)
      }
    }
    setIsLoading(false)
  }, [])

  const handlePreferencesUpdate = (prefs: UserPreferences): void => {
    setPreferences(prefs)
    localStorage.setItem('metalsmind_preferences', JSON.stringify(prefs))
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="text-2xl font-bold text-black mb-2">MetalsMind Pro</div>
          <div className="text-sm text-black">Loading...</div>
        </div>
      </div>
    )
  }

  return <Dashboard preferences={preferences} onPreferencesUpdate={handlePreferencesUpdate} />
}
