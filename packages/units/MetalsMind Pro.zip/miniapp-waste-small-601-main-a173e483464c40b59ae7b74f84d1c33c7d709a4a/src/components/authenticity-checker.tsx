'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Shield, AlertTriangle, CheckCircle } from 'lucide-react'

interface AuthenticityResult {
  itemName: string
  authenticityScore: number
  riskLevel: 'low' | 'medium' | 'high' | 'critical'
  designMarkers: string[]
  warnings: string[]
  corrections: string[]
  confidence: string
}

export function AuthenticityChecker(): JSX.Element {
  const [itemName, setItemName] = useState<string>('')
  const [description, setDescription] = useState<string>('')
  const [weight, setWeight] = useState<string>('')
  const [dimensions, setDimensions] = useState<string>('')
  const [result, setResult] = useState<AuthenticityResult | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false)

  const handleAnalyze = (): void => {
    if (!itemName.trim() || !description.trim()) {
      alert('Please provide item name and description')
      return
    }

    setIsAnalyzing(true)

    setTimeout(() => {
      const score = Math.floor(Math.random() * 40) + 60
      const riskLevel: AuthenticityResult['riskLevel'] = 
        score >= 85 ? 'low' : score >= 70 ? 'medium' : score >= 50 ? 'high' : 'critical'

      const designMarkers = [
        'Edge reeding pattern consistent with authentic examples',
        'Mint mark positioning and depth within tolerance',
        'Relief details match known die variations',
        'Surface luster appropriate for stated grade'
      ]

      const warnings = []
      const corrections = []

      if (score < 85) {
        warnings.push('Weight variance detected - verify on calibrated scale')
        corrections.push('Confirm weight within ±0.1g of specification')
      }

      if (score < 70) {
        warnings.push('Surface texture inconsistent with genuine items')
        corrections.push('Recommend professional authentication service review')
      }

      if (score < 60) {
        warnings.push('HIGH RISK: Multiple counterfeit indicators present')
        corrections.push('Do not purchase - seek certified dealer verification')
      }

      const mockResult: AuthenticityResult = {
        itemName: itemName.trim(),
        authenticityScore: score,
        riskLevel,
        designMarkers,
        warnings,
        corrections,
        confidence: score >= 85 ? 'High confidence - likely authentic' : 
                   score >= 70 ? 'Moderate confidence - additional verification recommended' :
                   score >= 50 ? 'Low confidence - significant concerns identified' :
                   'Very low confidence - high probability of counterfeit'
      }

      setResult(mockResult)
      setIsAnalyzing(false)
    }, 1500)
  }

  const getRiskColor = (risk: AuthenticityResult['riskLevel']): string => {
    if (risk === 'low') return 'bg-green-100 border-green-500 text-black'
    if (risk === 'medium') return 'bg-yellow-100 border-yellow-500 text-black'
    if (risk === 'high') return 'bg-orange-100 border-orange-500 text-black'
    return 'bg-red-100 border-red-500 text-black'
  }

  const getRiskIcon = (risk: AuthenticityResult['riskLevel']): JSX.Element => {
    if (risk === 'low') return <CheckCircle className="h-5 w-5 text-black" />
    if (risk === 'medium') return <Shield className="h-5 w-5 text-black" />
    return <AlertTriangle className="h-5 w-5 text-black" />
  }

  return (
    <Card className="border-2 border-black">
      <CardHeader className="border-b border-black">
        <CardTitle className="text-xl text-black">Authenticity & Counterfeit Detection</CardTitle>
        <CardDescription className="text-black">
          AI-simulated analysis of design markers, weight, dimensions, and known counterfeit indicators
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="itemName" className="text-black">Item Name</Label>
              <Input
                id="itemName"
                value={itemName}
                onChange={(e) => setItemName(e.target.value)}
                placeholder="e.g., 2024 American Gold Eagle 1oz"
                className="border-black text-black"
              />
            </div>

            <div>
              <Label htmlFor="description" className="text-black">Description & Observations</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe visual details, markings, color, luster, edge characteristics..."
                rows={4}
                className="border-black text-black"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="weight" className="text-black">Weight (g)</Label>
                <Input
                  id="weight"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  placeholder="31.103"
                  className="border-black text-black"
                />
              </div>
              <div>
                <Label htmlFor="dimensions" className="text-black">Dimensions (mm)</Label>
                <Input
                  id="dimensions"
                  value={dimensions}
                  onChange={(e) => setDimensions(e.target.value)}
                  placeholder="32.7 x 2.87"
                  className="border-black text-black"
                />
              </div>
            </div>

            <Button
              onClick={handleAnalyze}
              disabled={isAnalyzing}
              className="w-full bg-black text-white hover:bg-gray-800"
            >
              {isAnalyzing ? 'Analyzing...' : 'Analyze Authenticity'}
            </Button>
          </div>

          {result && (
            <div className="border-2 border-black rounded p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-black">{result.itemName}</h3>
                <Badge className={getRiskColor(result.riskLevel)}>
                  {getRiskIcon(result.riskLevel)}
                  <span className="ml-2">{result.riskLevel.toUpperCase()} RISK</span>
                </Badge>
              </div>

              <div className="border border-black p-4 rounded bg-gray-50">
                <div className="text-center">
                  <div className="text-4xl font-bold text-black mb-2">{result.authenticityScore}/100</div>
                  <div className="text-sm text-black">Authenticity Confidence Score</div>
                  <div className="text-xs text-black mt-1">{result.confidence}</div>
                </div>
              </div>

              {result.designMarkers.length > 0 && (
                <div>
                  <h4 className="font-semibold text-black mb-2">Design Markers Analysis:</h4>
                  <ul className="space-y-1">
                    {result.designMarkers.map((marker, idx) => (
                      <li key={idx} className="text-sm text-black flex items-start">
                        <span className="mr-2">✓</span>
                        <span>{marker}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {result.warnings.length > 0 && (
                <div className="border-l-4 border-orange-500 bg-orange-50 p-3">
                  <h4 className="font-semibold text-black mb-2">⚠️ Warnings:</h4>
                  <ul className="space-y-1">
                    {result.warnings.map((warning, idx) => (
                      <li key={idx} className="text-sm text-black">• {warning}</li>
                    ))}
                  </ul>
                </div>
              )}

              {result.corrections.length > 0 && (
                <div className="border-l-4 border-blue-500 bg-blue-50 p-3">
                  <h4 className="font-semibold text-black mb-2">📋 Recommendations:</h4>
                  <ul className="space-y-1">
                    {result.corrections.map((correction, idx) => (
                      <li key={idx} className="text-sm text-black">• {correction}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
