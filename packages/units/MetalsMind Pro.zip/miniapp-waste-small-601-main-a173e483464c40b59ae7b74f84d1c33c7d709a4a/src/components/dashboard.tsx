'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { PriceTriangulation } from '@/components/price-triangulation'
import { LocalMarketIndex } from '@/components/local-market-index'
import { InventoryManager } from '@/components/inventory-manager'
import { PatternAlerts } from '@/components/pattern-alerts'
import { AuthenticityChecker } from '@/components/authenticity-checker'
import { DealerReliability } from '@/components/dealer-reliability'
import { DCAStrategy } from '@/components/dca-strategy'
import { WeeklyReportView } from '@/components/weekly-report'
import { LivePriceTicker } from '@/components/live-price-ticker'
import { SettingsDialog } from '@/components/settings-dialog'
import type { UserPreferences } from '@/types/metals'
import { RefreshCw, Settings } from 'lucide-react'

interface DashboardProps {
  preferences: UserPreferences
  onPreferencesUpdate: (preferences: UserPreferences) => void
}

export function Dashboard({ preferences, onPreferencesUpdate }: DashboardProps): JSX.Element {
  const [lastUpdate, setLastUpdate] = useState<string>(new Date().toLocaleTimeString())
  const [activeTab, setActiveTab] = useState<string>('overview')
  const [settingsOpen, setSettingsOpen] = useState<boolean>(false)

  const handleRefresh = (): void => {
    setLastUpdate(new Date().toLocaleTimeString())
  }

  const showPortfolio = preferences.features.includes('portfolio') || preferences.features.includes('all')
  const showPricing = preferences.features.includes('pricing') || preferences.features.includes('all')
  const showSignals = preferences.features.includes('signals') || preferences.features.includes('all')
  const showAuthenticity = preferences.features.includes('authenticity') || preferences.features.includes('all')

  return (
    <div className="min-h-screen bg-white text-black">
      <header className="border-b border-black sticky top-0 bg-white z-50 pt-12">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-black">MetalsMind Pro</h1>
              <p className="text-sm text-black">
                {preferences.city}, {preferences.region} • Last update: {lastUpdate}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                onClick={handleRefresh}
                variant="outline"
                size="sm"
                className="border-black text-black"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Button
                onClick={() => setSettingsOpen(true)}
                variant="outline"
                size="sm"
                className="border-black text-black"
              >
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <LivePriceTicker />
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full mt-6">
          <TabsList className="grid grid-cols-4 lg:grid-cols-8 w-full mb-6 bg-gray-100 border border-black">
            <TabsTrigger value="overview" className="text-black">Overview</TabsTrigger>
            {showPricing && <TabsTrigger value="pricing" className="text-black">Pricing</TabsTrigger>}
            {showPricing && <TabsTrigger value="local" className="text-black">Local Market</TabsTrigger>}
            {showPortfolio && <TabsTrigger value="inventory" className="text-black">Inventory</TabsTrigger>}
            {showSignals && <TabsTrigger value="signals" className="text-black">Signals</TabsTrigger>}
            {showAuthenticity && <TabsTrigger value="authenticity" className="text-black">Authenticity</TabsTrigger>}
            <TabsTrigger value="dealers" className="text-black">Dealers</TabsTrigger>
            <TabsTrigger value="dca" className="text-black">Strategy</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {showPricing && <PriceTriangulation metals={preferences.metals} />}
            {showPricing && <LocalMarketIndex region={preferences.region} city={preferences.city} metals={preferences.metals} />}
            {showSignals && <PatternAlerts metals={preferences.metals} />}
            <WeeklyReportView metals={preferences.metals} />
          </TabsContent>

          {showPricing && (
            <TabsContent value="pricing">
              <PriceTriangulation metals={preferences.metals} />
            </TabsContent>
          )}

          {showPricing && (
            <TabsContent value="local">
              <LocalMarketIndex region={preferences.region} city={preferences.city} metals={preferences.metals} />
            </TabsContent>
          )}

          {showPortfolio && (
            <TabsContent value="inventory">
              <InventoryManager metals={preferences.metals} />
            </TabsContent>
          )}

          {showSignals && (
            <TabsContent value="signals">
              <PatternAlerts metals={preferences.metals} />
            </TabsContent>
          )}

          {showAuthenticity && (
            <TabsContent value="authenticity">
              <AuthenticityChecker />
            </TabsContent>
          )}

          <TabsContent value="dealers">
            <DealerReliability />
          </TabsContent>

          <TabsContent value="dca">
            <DCAStrategy metals={preferences.metals} />
          </TabsContent>
        </Tabs>
      </main>

      <SettingsDialog
        open={settingsOpen}
        onOpenChange={setSettingsOpen}
        preferences={preferences}
        onSave={onPreferencesUpdate}
      />
    </div>
  )
}
