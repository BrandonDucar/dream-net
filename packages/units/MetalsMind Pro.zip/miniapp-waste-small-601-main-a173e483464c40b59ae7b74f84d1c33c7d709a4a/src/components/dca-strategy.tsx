'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import type { MetalType, DCARecommendation } from '@/types/metals'
import { generatePriceData, generateDCARecommendation } from '@/lib/metals-engine'
import { TrendingUp, DollarSign, Calendar } from 'lucide-react'

interface DCAStrategyProps {
  metals: MetalType[]
}

export function DCAStrategy({ metals }: DCAStrategyProps): JSX.Element {
  const [recommendations, setRecommendations] = useState<DCARecommendation[]>([])

  useEffect(() => {
    const fetchRecommendations = async (): Promise<void> => {
      const data = await Promise.all(
        metals.map(async metal => {
          const priceData = await generatePriceData(metal)
          return generateDCARecommendation(metal, priceData)
        })
      )
      setRecommendations(data)
    }
    fetchRecommendations()
  }, [metals])

  const getOpportunityColor = (opportunity: DCARecommendation['currentOpportunity']): string => {
    if (opportunity === 'excellent') return 'bg-green-100 border-green-500 text-black'
    if (opportunity === 'good') return 'bg-blue-100 border-blue-500 text-black'
    if (opportunity === 'fair') return 'bg-yellow-100 border-yellow-500 text-black'
    return 'bg-red-100 border-red-500 text-black'
  }

  return (
    <Card className="border-2 border-black">
      <CardHeader className="border-b border-black">
        <CardTitle className="text-xl text-black">Smart DCA & Strategy Engine</CardTitle>
        <CardDescription className="text-black">
          Optimal purchase timing, premium dip detection, and cost-efficient allocation recommendations
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="space-y-6">
          {recommendations.map(rec => (
            <div key={rec.metal} className="border-2 border-black p-6 rounded space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-black capitalize">{rec.metal}</h3>
                <Badge className={getOpportunityColor(rec.currentOpportunity)}>
                  {rec.currentOpportunity.toUpperCase()} OPPORTUNITY
                </Badge>
              </div>

              {rec.premiumDipWindow && (
                <div className="bg-green-50 border-2 border-green-500 p-3 rounded flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-black flex-shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-black">Premium Dip Window Detected!</p>
                    <p className="text-xs text-black">Below-average premiums create short-term value entry</p>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="border border-black p-4 rounded bg-gray-50">
                  <div className="flex items-center gap-2 mb-2">
                    <DollarSign className="h-4 w-4 text-black" />
                    <span className="text-sm text-black">Recommended Amount</span>
                  </div>
                  <div className="text-2xl font-bold text-black">${rec.recommendedAmount}</div>
                </div>
                <div className="border border-black p-4 rounded bg-gray-50">
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="h-4 w-4 text-black" />
                    <span className="text-sm text-black">Frequency</span>
                  </div>
                  <div className="text-2xl font-bold text-black capitalize">{rec.frequency}</div>
                </div>
              </div>

              <div className="pt-3 border-t border-black">
                <p className="text-sm font-semibold text-black mb-2">Strategy Analysis:</p>
                <p className="text-sm text-black">{rec.reasoning}</p>
              </div>

              {rec.alternativeSuggestions.length > 0 && (
                <div className="border-l-4 border-blue-500 bg-blue-50 p-3">
                  <p className="text-sm font-semibold text-black mb-2">💡 Alternative Strategies:</p>
                  <ul className="space-y-1">
                    {rec.alternativeSuggestions.map((suggestion, idx) => (
                      <li key={idx} className="text-sm text-black">• {suggestion}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="bg-black text-white p-4 rounded">
                <p className="text-sm font-semibold mb-2">📊 Best Allocation Move Today:</p>
                <p className="text-sm">
                  {rec.currentOpportunity === 'excellent' || rec.currentOpportunity === 'good'
                    ? `Consider ${rec.frequency} purchases of $${rec.recommendedAmount} to maximize value at current levels.`
                    : rec.currentOpportunity === 'fair'
                    ? `Maintain regular ${rec.frequency} schedule at $${rec.recommendedAmount} for steady accumulation.`
                    : `Reduce ${rec.frequency} allocation or wait for better entry. Consider reallocating to stronger value metals.`}
                </p>
              </div>
            </div>
          ))}

          <div className="border border-black p-4 rounded bg-gray-50">
            <h4 className="font-semibold text-black mb-3">DCA Strategy Best Practices:</h4>
            <ul className="space-y-2 text-sm text-black">
              <li>✓ Maintain consistent schedule regardless of short-term price moves</li>
              <li>✓ Increase allocation during premium compression windows</li>
              <li>✓ Diversify across multiple metals for risk management</li>
              <li>✓ Track cost basis and efficiency over time</li>
              <li>✓ Adjust allocation based on opportunity ratings</li>
              <li>✓ Consider switching to lower-premium alternatives when spreads widen</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
