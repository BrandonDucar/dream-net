'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import type { DealerInfo } from '@/types/metals'
import { generateDealerInfo } from '@/lib/metals-engine'
import { Search, Store } from 'lucide-react'

export function DealerReliability(): JSX.Element {
  const [dealerName, setDealerName] = useState<string>('')
  const [dealerInfo, setDealerInfo] = useState<DealerInfo | null>(null)
  const [isSearching, setIsSearching] = useState<boolean>(false)

  const handleSearch = (): void => {
    if (!dealerName.trim()) {
      alert('Please enter a dealer name')
      return
    }

    setIsSearching(true)

    setTimeout(() => {
      const info = generateDealerInfo(dealerName.trim())
      setDealerInfo(info)
      setIsSearching(false)
    }, 1000)
  }

  const getScoreColor = (score: number): string => {
    if (score >= 85) return 'text-green-600'
    if (score >= 70) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getScoreBadge = (score: number): string => {
    if (score >= 85) return 'bg-green-100 border-green-500 text-black'
    if (score >= 70) return 'bg-yellow-100 border-yellow-500 text-black'
    return 'bg-red-100 border-red-500 text-black'
  }

  return (
    <Card className="border-2 border-black">
      <CardHeader className="border-b border-black">
        <CardTitle className="text-xl text-black">Dealer Reliability Intelligence (DRI)</CardTitle>
        <CardDescription className="text-black">
          Evaluate spread fairness, shipping speed, buyback consistency, and trustworthiness
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="space-y-6">
          <div className="flex gap-3">
            <div className="flex-1">
              <Label htmlFor="dealerName" className="text-black">Dealer Name</Label>
              <Input
                id="dealerName"
                value={dealerName}
                onChange={(e) => setDealerName(e.target.value)}
                placeholder="e.g., APMEX, JM Bullion, SD Bullion"
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                className="border-black text-black"
              />
            </div>
            <div className="flex items-end">
              <Button
                onClick={handleSearch}
                disabled={isSearching}
                className="bg-black text-white hover:bg-gray-800"
              >
                <Search className="h-4 w-4 mr-2" />
                {isSearching ? 'Searching...' : 'Search'}
              </Button>
            </div>
          </div>

          {!dealerInfo && !isSearching && (
            <div className="text-center py-12 border border-black rounded">
              <Store className="h-12 w-12 text-black mx-auto mb-4" />
              <p className="text-black mb-2">Enter a dealer name to view reliability analysis</p>
              <p className="text-sm text-black">
                Simulated intelligence based on market patterns and typical dealer behaviors
              </p>
            </div>
          )}

          {dealerInfo && (
            <div className="space-y-6">
              <div className="border-2 border-black rounded p-6 bg-gray-50">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-2xl font-bold text-black">{dealerInfo.name}</h3>
                  <Badge className={getScoreBadge(dealerInfo.reliabilityScore)}>
                    <span className="text-lg font-bold">{dealerInfo.reliabilityScore}/100</span>
                  </Badge>
                </div>

                <p className="text-sm text-black mb-4">{dealerInfo.summary}</p>

                <div className="bg-blue-50 border border-blue-500 p-3 rounded">
                  <p className="text-sm font-semibold text-black mb-1">Best Use Case:</p>
                  <p className="text-sm text-black">{dealerInfo.bestUseCase}</p>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold text-black">Detailed Metrics:</h4>

                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-black">Reliability Score</span>
                    <span className={`text-sm font-semibold ${getScoreColor(dealerInfo.reliabilityScore)}`}>
                      {dealerInfo.reliabilityScore}/100
                    </span>
                  </div>
                  <Progress value={dealerInfo.reliabilityScore} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-black">Spread Fairness</span>
                    <span className={`text-sm font-semibold ${getScoreColor(dealerInfo.spreadFairness)}`}>
                      {dealerInfo.spreadFairness}/100
                    </span>
                  </div>
                  <Progress value={dealerInfo.spreadFairness} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-black">Shipping Speed</span>
                    <span className={`text-sm font-semibold ${getScoreColor(dealerInfo.shippingSpeed)}`}>
                      {dealerInfo.shippingSpeed}/100
                    </span>
                  </div>
                  <Progress value={dealerInfo.shippingSpeed} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-black">Buyback Consistency</span>
                    <span className={`text-sm font-semibold ${getScoreColor(dealerInfo.buybackConsistency)}`}>
                      {dealerInfo.buybackConsistency}/100
                    </span>
                  </div>
                  <Progress value={dealerInfo.buybackConsistency} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-black">Trustworthiness</span>
                    <span className={`text-sm font-semibold ${getScoreColor(dealerInfo.trustworthiness)}`}>
                      {dealerInfo.trustworthiness}/100
                    </span>
                  </div>
                  <Progress value={dealerInfo.trustworthiness} className="h-2" />
                </div>
              </div>

              {dealerInfo.knownIssues.length > 0 && (
                <div className="border-l-4 border-orange-500 bg-orange-50 p-4">
                  <h4 className="font-semibold text-black mb-2">⚠️ Known Issues:</h4>
                  <ul className="space-y-1">
                    {dealerInfo.knownIssues.map((issue, idx) => (
                      <li key={idx} className="text-sm text-black">• {issue}</li>
                    ))}
                  </ul>
                </div>
              )}

              {dealerInfo.knownIssues.length === 0 && (
                <div className="border-l-4 border-green-500 bg-green-50 p-4">
                  <p className="text-sm text-black">✅ No major issues reported - solid track record</p>
                </div>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
