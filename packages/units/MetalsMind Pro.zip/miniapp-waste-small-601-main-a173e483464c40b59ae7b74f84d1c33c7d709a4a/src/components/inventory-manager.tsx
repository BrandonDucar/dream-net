'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import type { MetalType, InventoryItem, InventoryAnalysis } from '@/types/metals'
import { generatePriceData, analyzeInventoryItem } from '@/lib/metals-engine'
import { Plus, Trash2, Package } from 'lucide-react'

interface InventoryManagerProps {
  metals: MetalType[]
}

export function InventoryManager({ metals }: InventoryManagerProps): JSX.Element {
  const [inventory, setInventory] = useState<InventoryItem[]>([])
  const [analyses, setAnalyses] = useState<InventoryAnalysis[]>([])
  const [showAddForm, setShowAddForm] = useState<boolean>(false)

  const [formData, setFormData] = useState<Partial<InventoryItem>>({
    name: '',
    metal: metals[0],
    weight: 0,
    weightUnit: 'oz',
    purity: 99.9,
    purchasePrice: 0,
    purchaseDate: new Date().toISOString().split('T')[0],
    type: 'bullion'
  })

  useEffect(() => {
    const stored = localStorage.getItem('metalsmind_inventory')
    if (stored) {
      try {
        const parsed = JSON.parse(stored) as InventoryItem[]
        setInventory(parsed)
      } catch (e) {
        console.error('Failed to parse inventory:', e)
      }
    }
  }, [])

  useEffect(() => {
    const analyzeInventory = async (): Promise<void> => {
      if (inventory.length > 0) {
        const newAnalyses = await Promise.all(
          inventory.map(async item => {
            const priceData = await generatePriceData(item.metal)
            return analyzeInventoryItem(item, priceData.spotPrice)
          })
        )
        setAnalyses(newAnalyses)
      }
    }
    analyzeInventory()
  }, [inventory])

  const handleAddItem = (): void => {
    if (!formData.name || !formData.weight || !formData.purchasePrice) {
      alert('Please fill in all required fields')
      return
    }

    const newItem: InventoryItem = {
      id: `item-${Date.now()}`,
      name: formData.name,
      metal: formData.metal || metals[0],
      weight: formData.weight,
      weightUnit: formData.weightUnit || 'oz',
      purity: formData.purity || 99.9,
      purchasePrice: formData.purchasePrice,
      purchaseDate: formData.purchaseDate || new Date().toISOString().split('T')[0],
      type: formData.type || 'bullion',
      notes: formData.notes
    }

    const updated = [...inventory, newItem]
    setInventory(updated)
    localStorage.setItem('metalsmind_inventory', JSON.stringify(updated))

    setFormData({
      name: '',
      metal: metals[0],
      weight: 0,
      weightUnit: 'oz',
      purity: 99.9,
      purchasePrice: 0,
      purchaseDate: new Date().toISOString().split('T')[0],
      type: 'bullion'
    })
    setShowAddForm(false)
  }

  const handleDeleteItem = (id: string): void => {
    const updated = inventory.filter(item => item.id !== id)
    setInventory(updated)
    localStorage.setItem('metalsmind_inventory', JSON.stringify(updated))
  }

  const totalValue = analyses.reduce((sum, a) => sum + a.totalValue, 0)
  const totalGainLoss = analyses.reduce((sum, a) => sum + a.gainLoss, 0)

  const getLiquidityColor = (rank: InventoryAnalysis['liquidityRank']): string => {
    if (rank === 'fast') return 'bg-green-100 border-green-500 text-black'
    if (rank === 'medium') return 'bg-yellow-100 border-yellow-500 text-black'
    return 'bg-red-100 border-red-500 text-black'
  }

  return (
    <Card className="border-2 border-black">
      <CardHeader className="border-b border-black">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-xl text-black">Smart Inventory & Melt/Premium Engine</CardTitle>
            <CardDescription className="text-black">
              Track melt value, premium decomposition, gains/losses, and liquidity rankings
            </CardDescription>
          </div>
          <Button
            onClick={() => setShowAddForm(!showAddForm)}
            className="bg-black text-white hover:bg-gray-800"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Item
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        {inventory.length === 0 && !showAddForm && (
          <div className="text-center py-12 border border-black rounded">
            <Package className="h-12 w-12 text-black mx-auto mb-4" />
            <p className="text-black mb-4">No inventory items yet</p>
            <Button onClick={() => setShowAddForm(true)} className="bg-black text-white hover:bg-gray-800">
              Add Your First Item
            </Button>
          </div>
        )}

        {showAddForm && (
          <div className="border border-black p-4 rounded mb-6 space-y-4">
            <h3 className="font-semibold text-black mb-4">Add New Item</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name" className="text-black">Item Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., 1oz American Eagle"
                  className="border-black text-black"
                />
              </div>
              <div>
                <Label htmlFor="metal" className="text-black">Metal Type</Label>
                <Select value={formData.metal} onValueChange={(value) => setFormData({ ...formData, metal: value as MetalType })}>
                  <SelectTrigger className="border-black text-black">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {metals.map(metal => (
                      <SelectItem key={metal} value={metal} className="capitalize">{metal}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="weight" className="text-black">Weight</Label>
                <Input
                  id="weight"
                  type="number"
                  step="0.01"
                  value={formData.weight}
                  onChange={(e) => setFormData({ ...formData, weight: parseFloat(e.target.value) })}
                  className="border-black text-black"
                />
              </div>
              <div>
                <Label htmlFor="weightUnit" className="text-black">Weight Unit</Label>
                <Select value={formData.weightUnit} onValueChange={(value) => setFormData({ ...formData, weightUnit: value as 'oz' | 'g' | 'kg' })}>
                  <SelectTrigger className="border-black text-black">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="oz">Ounces (oz)</SelectItem>
                    <SelectItem value="g">Grams (g)</SelectItem>
                    <SelectItem value="kg">Kilograms (kg)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="purity" className="text-black">Purity (%)</Label>
                <Input
                  id="purity"
                  type="number"
                  step="0.1"
                  value={formData.purity}
                  onChange={(e) => setFormData({ ...formData, purity: parseFloat(e.target.value) })}
                  className="border-black text-black"
                />
              </div>
              <div>
                <Label htmlFor="type" className="text-black">Type</Label>
                <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value as InventoryItem['type'] })}>
                  <SelectTrigger className="border-black text-black">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bullion">Bullion</SelectItem>
                    <SelectItem value="coin">Coin</SelectItem>
                    <SelectItem value="numismatic">Numismatic</SelectItem>
                    <SelectItem value="scrap">Scrap</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="purchasePrice" className="text-black">Purchase Price ($)</Label>
                <Input
                  id="purchasePrice"
                  type="number"
                  step="0.01"
                  value={formData.purchasePrice}
                  onChange={(e) => setFormData({ ...formData, purchasePrice: parseFloat(e.target.value) })}
                  className="border-black text-black"
                />
              </div>
              <div>
                <Label htmlFor="purchaseDate" className="text-black">Purchase Date</Label>
                <Input
                  id="purchaseDate"
                  type="date"
                  value={formData.purchaseDate}
                  onChange={(e) => setFormData({ ...formData, purchaseDate: e.target.value })}
                  className="border-black text-black"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleAddItem} className="bg-black text-white hover:bg-gray-800">
                Save Item
              </Button>
              <Button onClick={() => setShowAddForm(false)} variant="outline" className="border-black text-black">
                Cancel
              </Button>
            </div>
          </div>
        )}

        {analyses.length > 0 && (
          <>
            <div className="grid grid-cols-3 gap-4 mb-6 p-4 border border-black rounded bg-gray-50">
              <div>
                <div className="text-sm text-black">Total Portfolio Value</div>
                <div className="text-2xl font-bold text-black">${totalValue.toFixed(2)}</div>
              </div>
              <div>
                <div className="text-sm text-black">Total Gain/Loss</div>
                <div className={`text-2xl font-bold ${totalGainLoss >= 0 ? 'text-black' : 'text-black'}`}>
                  ${totalGainLoss.toFixed(2)}
                </div>
              </div>
              <div>
                <div className="text-sm text-black">Items Tracked</div>
                <div className="text-2xl font-bold text-black">{inventory.length}</div>
              </div>
            </div>

            <div className="space-y-4">
              {analyses.map((analysis, idx) => (
                <div key={analysis.item.id} className="border border-black p-4 rounded space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold text-black">{analysis.item.name}</h3>
                      <p className="text-sm text-black capitalize">
                        {analysis.item.weight} {analysis.item.weightUnit} • {analysis.item.purity}% pure {analysis.item.metal}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getLiquidityColor(analysis.liquidityRank)}>
                        {analysis.liquidityRank} liquidity
                      </Badge>
                      <Button
                        onClick={() => handleDeleteItem(analysis.item.id)}
                        variant="outline"
                        size="sm"
                        className="border-black text-black"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <div className="text-black">Current Value</div>
                      <div className="font-semibold text-black">${analysis.totalValue.toFixed(2)}</div>
                    </div>
                    <div>
                      <div className="text-black">Melt Value</div>
                      <div className="font-semibold text-black">${analysis.currentMeltValue.toFixed(2)}</div>
                    </div>
                    <div>
                      <div className="text-black">Total Premiums</div>
                      <div className="font-semibold text-black">
                        ${(analysis.meltPremium + analysis.numismaticPremium + analysis.dealerPremium + analysis.temporaryMarketPremium).toFixed(2)}
                      </div>
                    </div>
                    <div>
                      <div className="text-black">Gain/Loss</div>
                      <div className={`font-semibold ${analysis.gainLoss >= 0 ? 'text-black' : 'text-black'}`}>
                        ${analysis.gainLoss.toFixed(2)} ({analysis.gainLossPercent.toFixed(2)}%)
                      </div>
                    </div>
                  </div>

                  {analysis.recommendations.length > 0 && (
                    <div className="pt-2 border-t border-black">
                      <p className="text-xs font-semibold text-black mb-2">Recommendations:</p>
                      <ul className="text-xs text-black space-y-1">
                        {analysis.recommendations.map((rec, idx) => (
                          <li key={idx}>• {rec}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
