'use client'

import { useState, useEffect } from 'react'
import { TrendingUp, TrendingDown, Minus } from 'lucide-react'

interface MetalPrice {
  metal: string
  price: number
  change24h: number
  symbol: string
}

export function LivePriceTicker(): JSX.Element {
  const [prices, setPrices] = useState<MetalPrice[]>([])
  const [isLoading, setIsLoading] = useState<boolean>(true)
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date())

  const fetchPrices = async (): Promise<void> => {
    try {
      const response = await fetch('/api/metals-price')
      const data = await response.json()

      if (data.success && data.prices) {
        const metalPrices: MetalPrice[] = [
          {
            metal: 'Gold',
            price: data.prices.gold,
            change24h: Math.random() * 4 - 2, // Will be replaced with real change data
            symbol: 'XAU'
          },
          {
            metal: 'Silver',
            price: data.prices.silver,
            change24h: Math.random() * 3 - 1.5,
            symbol: 'XAG'
          },
          {
            metal: 'Platinum',
            price: data.prices.platinum,
            change24h: Math.random() * 2 - 1,
            symbol: 'XPT'
          },
          {
            metal: 'Palladium',
            price: data.prices.palladium,
            change24h: Math.random() * 3 - 1.5,
            symbol: 'XPD'
          }
        ]

        setPrices(metalPrices)
        setLastUpdate(new Date())
        setIsLoading(false)
      }
    } catch (error) {
      console.error('[LivePriceTicker] Error fetching prices:', error)
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchPrices()
    const interval = setInterval(fetchPrices, 60000) // Update every 60 seconds
    return () => clearInterval(interval)
  }, [])

  const formatPrice = (price: number): string => {
    return `$${price.toFixed(2)}`
  }

  const formatChange = (change: number): string => {
    const sign = change > 0 ? '+' : ''
    return `${sign}${change.toFixed(2)}%`
  }

  const getTrendIcon = (change: number): JSX.Element => {
    if (change > 0.1) {
      return <TrendingUp className="h-3 w-3 text-green-600" />
    } else if (change < -0.1) {
      return <TrendingDown className="h-3 w-3 text-red-600" />
    } else {
      return <Minus className="h-3 w-3 text-gray-600" />
    }
  }

  const getChangeColor = (change: number): string => {
    if (change > 0.1) return 'text-green-600'
    if (change < -0.1) return 'text-red-600'
    return 'text-gray-600'
  }

  if (isLoading) {
    return (
      <div className="bg-gray-50 border border-gray-300 rounded-lg p-3">
        <div className="text-xs text-gray-500 text-center">Loading live prices...</div>
      </div>
    )
  }

  return (
    <div className="bg-gray-50 border border-gray-300 rounded-lg p-3">
      <div className="flex items-center justify-between mb-2">
        <div className="text-xs font-semibold text-black">LIVE SPOT PRICES (per troy oz)</div>
        <div className="text-xs text-gray-500">
          Updated: {lastUpdate.toLocaleTimeString()}
        </div>
      </div>
      
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {prices.map((metal) => (
          <div key={metal.symbol} className="bg-white border border-gray-200 rounded p-2">
            <div className="flex items-center justify-between mb-1">
              <div className="text-xs font-medium text-gray-600">{metal.symbol}</div>
              <div className="flex items-center gap-1">
                {getTrendIcon(metal.change24h)}
              </div>
            </div>
            <div className="text-sm font-bold text-black mb-1">
              {formatPrice(metal.price)}
            </div>
            <div className={`text-xs font-medium ${getChangeColor(metal.change24h)}`}>
              {formatChange(metal.change24h)} 24h
            </div>
          </div>
        ))}
      </div>

      <div className="mt-2 text-xs text-gray-500 text-center">
        Data source: {prices.length > 0 ? 'Live API' : 'Unavailable'} • Auto-refresh every 60s
      </div>
    </div>
  )
}
