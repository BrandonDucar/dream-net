'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import type { MetalType, LocalMarketData } from '@/types/metals'
import { generateLocalMarketData } from '@/lib/metals-engine'
import { Star } from 'lucide-react'

interface LocalMarketIndexProps {
  region: string
  city: string
  metals: MetalType[]
}

export function LocalMarketIndex({ region, city, metals }: LocalMarketIndexProps): JSX.Element {
  const [marketData, setMarketData] = useState<LocalMarketData[]>([])

  useEffect(() => {
    const data = metals.map(metal => generateLocalMarketData(region, city, metal))
    setMarketData(data)
  }, [region, city, metals])

  const getRatingColor = (rating: LocalMarketData['rating']): string => {
    if (rating === 'buy') return 'bg-green-100 border-green-500 text-black'
    if (rating === 'sell') return 'bg-blue-100 border-blue-500 text-black'
    return 'bg-gray-100 border-gray-500 text-black'
  }

  return (
    <Card className="border-2 border-black">
      <CardHeader className="border-b border-black">
        <CardTitle className="text-xl text-black">Local Market Spread Index (LMSI)</CardTitle>
        <CardDescription className="text-black">
          {city}, {region} - Local dealer behavior, pawn/jewelry melt values, marketplace averages, and liquidity patterns
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="space-y-4">
          {marketData.map((data, idx) => (
            <div key={idx} className="border border-black p-4 rounded space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-black capitalize">
                  {metals[idx]} Market
                </h3>
                <Badge className={getRatingColor(data.rating)}>
                  <span className="uppercase font-bold">{data.rating}</span>
                </Badge>
              </div>

              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <div className="text-black">Buy Premium</div>
                  <div className="font-semibold text-black">{data.buyPremium}%</div>
                </div>
                <div>
                  <div className="text-black">Sell Discount</div>
                  <div className="font-semibold text-black">{data.sellDiscount}%</div>
                </div>
                <div>
                  <div className="text-black">Liquidity Index</div>
                  <div className="font-semibold text-black">{data.liquidityIndex}/100</div>
                </div>
              </div>

              <div className="pt-2 border-t border-black">
                <p className="text-sm text-black mb-2">{data.summary}</p>
              </div>

              <div className="bg-gray-50 border border-black p-3 rounded flex items-start gap-2">
                <Star className="h-4 w-4 text-black mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-xs font-semibold text-black mb-1">Today&apos;s Local Sweet Spot:</p>
                  <p className="text-xs text-black">{data.sweetSpot}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
