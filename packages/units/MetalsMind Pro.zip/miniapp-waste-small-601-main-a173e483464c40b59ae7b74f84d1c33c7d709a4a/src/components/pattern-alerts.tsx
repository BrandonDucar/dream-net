'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import type { MetalType, PatternAlert } from '@/types/metals'
import { generatePatternAlerts } from '@/lib/metals-engine'
import { AlertTriangle, TrendingUp, Activity } from 'lucide-react'

interface PatternAlertsProps {
  metals: MetalType[]
}

export function PatternAlerts({ metals }: PatternAlertsProps): JSX.Element {
  const [alerts, setAlerts] = useState<PatternAlert[]>([])

  useEffect(() => {
    const fetchAlerts = async (): Promise<void> => {
      const data = await generatePatternAlerts(metals)
      setAlerts(data)
    }
    fetchAlerts()
  }, [metals])

  const getSeverityColor = (severity: PatternAlert['severity']): string => {
    if (severity === 'critical') return 'bg-red-100 border-red-500 text-black'
    if (severity === 'high') return 'bg-orange-100 border-orange-500 text-black'
    if (severity === 'medium') return 'bg-yellow-100 border-yellow-500 text-black'
    return 'bg-blue-100 border-blue-500 text-black'
  }

  const getTypeIcon = (type: PatternAlert['type']): JSX.Element => {
    if (type === 'spread' || type === 'futures' || type === 'correlation') {
      return <Activity className="h-5 w-5 text-black" />
    }
    if (type === 'whale' || type === 'supply') {
      return <TrendingUp className="h-5 w-5 text-black" />
    }
    return <AlertTriangle className="h-5 w-5 text-black" />
  }

  return (
    <Card className="border-2 border-black">
      <CardHeader className="border-b border-black">
        <CardTitle className="text-xl text-black">Pattern Alerts & Intelligence Signals</CardTitle>
        <CardDescription className="text-black">
          Spread anomalies, futures disconnects, whale moves, supply shifts, seasonal patterns, and macro correlations
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        {alerts.length === 0 && (
          <div className="text-center py-8 border border-black rounded">
            <p className="text-black">No active alerts at this time</p>
          </div>
        )}

        <div className="space-y-4">
          {alerts.map(alert => (
            <div
              key={alert.id}
              className={`border-2 p-4 rounded space-y-3 ${
                alert.actionable ? 'border-black bg-gray-50' : 'border-gray-300'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  {getTypeIcon(alert.type)}
                  <div className="flex-1">
                    <h3 className="text-base font-semibold text-black">{alert.title}</h3>
                    <p className="text-sm text-black mt-1 capitalize">
                      {alert.metal} • {alert.type} pattern
                    </p>
                  </div>
                </div>
                <Badge className={getSeverityColor(alert.severity)}>
                  {alert.severity.toUpperCase()}
                </Badge>
              </div>

              <p className="text-sm text-black pl-8">{alert.description}</p>

              {alert.actionable && (
                <div className="bg-black text-white p-2 rounded text-xs font-semibold ml-8">
                  ⚡ Actionable Signal - Consider Position Adjustment
                </div>
              )}

              <div className="text-xs text-black pl-8">
                {new Date(alert.timestamp).toLocaleString()}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
