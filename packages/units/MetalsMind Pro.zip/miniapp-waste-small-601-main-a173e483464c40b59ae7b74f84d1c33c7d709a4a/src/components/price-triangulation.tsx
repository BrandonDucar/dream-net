'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import type { MetalType, PriceData } from '@/types/metals'
import { generatePriceData } from '@/lib/metals-engine'
import { TrendingUp, TrendingDown, Minus } from 'lucide-react'

interface PriceTriangulationProps {
  metals: MetalType[]
}

export function PriceTriangulation({ metals }: PriceTriangulationProps): JSX.Element {
  const [priceData, setPriceData] = useState<PriceData[]>([])

  useEffect(() => {
    const fetchPrices = async (): Promise<void> => {
      const data = await Promise.all(metals.map(metal => generatePriceData(metal)))
      setPriceData(data)
    }
    fetchPrices()
  }, [metals])

  const getTrendIcon = (trend: PriceData['trend']): JSX.Element => {
    if (trend === 'bullish') return <TrendingUp className="h-4 w-4 text-black" />
    if (trend === 'bearish') return <TrendingDown className="h-4 w-4 text-black" />
    return <Minus className="h-4 w-4 text-black" />
  }

  const getTrendColor = (trend: PriceData['trend']): string => {
    if (trend === 'bullish') return 'bg-green-100 border-green-500 text-black'
    if (trend === 'bearish') return 'bg-red-100 border-red-500 text-black'
    return 'bg-gray-100 border-gray-500 text-black'
  }

  return (
    <Card className="border-2 border-black">
      <CardHeader className="border-b border-black">
        <CardTitle className="text-xl text-black">Real Spot Price Triangulation</CardTitle>
        <CardDescription className="text-black">
          Multi-source synthetic pricing combining global spots, futures, domestic dealer averages, and supply/demand indicators
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {priceData.map(data => (
            <div key={data.metal} className="border border-black p-4 rounded space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-black capitalize">{data.metal}</h3>
                <Badge className={getTrendColor(data.trend)}>
                  {getTrendIcon(data.trend)}
                  <span className="ml-1 capitalize">{data.trend}</span>
                </Badge>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-black">True Median Price:</span>
                  <span className="font-semibold text-black">${data.trueMedianPrice}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-black">Dealer Spread Index:</span>
                  <span className="font-semibold text-black">{data.dealerSpreadIndex}%</span>
                </div>
              </div>

              <div className="pt-2 border-t border-black">
                <p className="text-xs font-semibold text-black mb-2">Volatility Windows:</p>
                <div className="grid grid-cols-4 gap-2 text-xs">
                  <div className="text-center">
                    <div className="text-black">1m</div>
                    <div className="font-semibold text-black">{data.volatility1m}%</div>
                  </div>
                  <div className="text-center">
                    <div className="text-black">5m</div>
                    <div className="font-semibold text-black">{data.volatility5m}%</div>
                  </div>
                  <div className="text-center">
                    <div className="text-black">1h</div>
                    <div className="font-semibold text-black">{data.volatility1h}%</div>
                  </div>
                  <div className="text-center">
                    <div className="text-black">24h</div>
                    <div className="font-semibold text-black">{data.volatility24h}%</div>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-black">
                <p className="text-xs text-black">{data.strength}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
