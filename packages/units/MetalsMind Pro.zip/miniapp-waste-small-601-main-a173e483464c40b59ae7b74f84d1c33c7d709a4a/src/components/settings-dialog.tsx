'use client'

import { useState, useEffect } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import type { UserPreferences, MetalType, FeatureType } from '@/types/metals'

interface SettingsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  preferences: UserPreferences
  onSave: (preferences: UserPreferences) => void
}

export function SettingsDialog({ open, onOpenChange, preferences, onSave }: SettingsDialogProps): JSX.Element {
  const [selectedMetals, setSelectedMetals] = useState<MetalType[]>(preferences.metals)
  const [selectedFeatures, setSelectedFeatures] = useState<FeatureType[]>(preferences.features)
  const [region, setRegion] = useState<string>(preferences.region)
  const [city, setCity] = useState<string>(preferences.city)

  useEffect(() => {
    setSelectedMetals(preferences.metals)
    setSelectedFeatures(preferences.features)
    setRegion(preferences.region)
    setCity(preferences.city)
  }, [preferences])

  const metalOptions: { value: MetalType; label: string }[] = [
    { value: 'gold', label: 'Gold' },
    { value: 'silver', label: 'Silver' },
    { value: 'platinum', label: 'Platinum' },
    { value: 'palladium', label: 'Palladium' },
    { value: 'scrap', label: 'Scrap' },
    { value: 'numismatics', label: 'Numismatics/Collectibles' }
  ]

  const featureOptions: { value: FeatureType; label: string; description: string }[] = [
    { value: 'portfolio', label: 'Portfolio Tracking', description: 'Track your metals inventory and value' },
    { value: 'pricing', label: 'Pricing Intelligence', description: 'Real-time spot prices and spreads' },
    { value: 'signals', label: 'Market Signals', description: 'Pattern detection and alerts' },
    { value: 'authenticity', label: 'Authenticity Help', description: 'Counterfeit detection assistance' },
    { value: 'all', label: 'All Features', description: 'Complete metals intelligence suite' }
  ]

  const toggleMetal = (metal: MetalType): void => {
    setSelectedMetals(prev =>
      prev.includes(metal) ? prev.filter(m => m !== metal) : [...prev, metal]
    )
  }

  const toggleFeature = (feature: FeatureType): void => {
    if (feature === 'all') {
      setSelectedFeatures(['all'])
    } else {
      setSelectedFeatures(prev => {
        const filtered = prev.filter(f => f !== 'all')
        return filtered.includes(feature) ? filtered.filter(f => f !== feature) : [...filtered, feature]
      })
    }
  }

  const handleSave = (): void => {
    if (selectedMetals.length === 0) {
      alert('Please select at least one metal type')
      return
    }
    if (selectedFeatures.length === 0) {
      alert('Please select at least one feature')
      return
    }
    if (!region.trim() || !city.trim()) {
      alert('Please enter your region and city')
      return
    }

    const updatedPreferences: UserPreferences = {
      metals: selectedMetals,
      features: selectedFeatures,
      region: region.trim(),
      city: city.trim()
    }

    onSave(updatedPreferences)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-white border-2 border-black">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-black">Settings</DialogTitle>
          <DialogDescription className="text-black">
            Configure your MetalsMind Pro preferences
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="metals" className="w-full">
          <TabsList className="grid grid-cols-3 w-full bg-gray-100 border border-black">
            <TabsTrigger value="metals" className="text-black">Metals</TabsTrigger>
            <TabsTrigger value="features" className="text-black">Features</TabsTrigger>
            <TabsTrigger value="location" className="text-black">Location</TabsTrigger>
          </TabsList>

          <TabsContent value="metals" className="space-y-4 pt-4">
            <div>
              <h3 className="text-lg font-semibold text-black mb-4">
                What metals do you stack or collect?
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {metalOptions.map(option => (
                  <div
                    key={option.value}
                    className="flex items-center space-x-2 p-3 border border-black rounded cursor-pointer hover:bg-gray-50"
                    onClick={() => toggleMetal(option.value)}
                  >
                    <Checkbox
                      id={`metal-${option.value}`}
                      checked={selectedMetals.includes(option.value)}
                      onCheckedChange={() => toggleMetal(option.value)}
                    />
                    <Label
                      htmlFor={`metal-${option.value}`}
                      className="cursor-pointer text-black"
                    >
                      {option.label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="features" className="space-y-4 pt-4">
            <div>
              <h3 className="text-lg font-semibold text-black mb-4">
                What features do you want?
              </h3>
              <div className="space-y-3">
                {featureOptions.map(option => (
                  <div
                    key={option.value}
                    className="flex items-start space-x-2 p-3 border border-black rounded cursor-pointer hover:bg-gray-50"
                    onClick={() => toggleFeature(option.value)}
                  >
                    <Checkbox
                      id={`feature-${option.value}`}
                      checked={selectedFeatures.includes(option.value)}
                      onCheckedChange={() => toggleFeature(option.value)}
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <Label
                        htmlFor={`feature-${option.value}`}
                        className="cursor-pointer font-semibold text-black"
                      >
                        {option.label}
                      </Label>
                      <p className="text-sm text-black mt-1">{option.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="location" className="space-y-4 pt-4">
            <div>
              <h3 className="text-lg font-semibold text-black mb-4">
                What region and city are you in?
              </h3>
              <p className="text-sm text-black mb-4">
                This helps provide accurate local market spread data and dealer intelligence.
              </p>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="region" className="text-black">
                    Region/State/Province
                  </Label>
                  <Input
                    id="region"
                    type="text"
                    placeholder="e.g., California, Ontario, New South Wales"
                    value={region}
                    onChange={(e) => setRegion(e.target.value)}
                    className="border-black text-black"
                  />
                </div>
                <div>
                  <Label htmlFor="city" className="text-black">
                    City
                  </Label>
                  <Input
                    id="city"
                    type="text"
                    placeholder="e.g., Los Angeles, Toronto, Sydney"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="border-black text-black"
                  />
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex gap-3 pt-4 border-t border-black">
          <Button
            onClick={() => onOpenChange(false)}
            variant="outline"
            className="flex-1 border-black text-black"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            className="flex-1 bg-black text-white hover:bg-gray-800"
          >
            Save Changes
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
