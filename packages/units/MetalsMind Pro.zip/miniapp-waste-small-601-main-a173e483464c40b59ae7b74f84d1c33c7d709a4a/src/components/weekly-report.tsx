'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import type { MetalType, WeeklyReport } from '@/types/metals'
import { generateWeeklyReport } from '@/lib/metals-engine'
import { Calendar, TrendingUp, TrendingDown, AlertCircle } from 'lucide-react'

interface WeeklyReportViewProps {
  metals: MetalType[]
}

export function WeeklyReportView({ metals }: WeeklyReportViewProps): JSX.Element {
  const [report, setReport] = useState<WeeklyReport | null>(null)

  useEffect(() => {
    const fetchReport = async (): Promise<void> => {
      const data = await generateWeeklyReport(metals)
      setReport(data)
    }
    fetchReport()
  }, [metals])

  const handleRegenerate = async (): Promise<void> => {
    const data = await generateWeeklyReport(metals)
    setReport(data)
  }

  if (!report) {
    return (
      <Card className="border-2 border-black">
        <CardContent className="pt-6">
          <p className="text-center text-black">Loading weekly report...</p>
        </CardContent>
      </Card>
    )
  }

  const formatDate = (dateStr: string): string => {
    return new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
  }

  const getTrendIcon = (direction: 'up' | 'down' | 'flat'): JSX.Element => {
    if (direction === 'up') return <TrendingUp className="h-4 w-4 text-black" />
    if (direction === 'down') return <TrendingDown className="h-4 w-4 text-black" />
    return <span className="text-black">→</span>
  }

  return (
    <Card className="border-2 border-black">
      <CardHeader className="border-b border-black">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-xl text-black">Weekly Regeneration Report</CardTitle>
            <CardDescription className="text-black">
              {formatDate(report.startDate)} - {formatDate(report.endDate)}
            </CardDescription>
          </div>
          <Button onClick={handleRegenerate} variant="outline" size="sm" className="border-black text-black">
            <Calendar className="h-4 w-4 mr-2" />
            Regenerate
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="border border-black p-4 rounded bg-gray-50">
              <div className="text-sm text-black mb-1">Portfolio Change</div>
              <div className={`text-2xl font-bold ${report.portfolioChange >= 0 ? 'text-black' : 'text-black'}`}>
                {report.portfolioChange >= 0 ? '+' : ''}${report.portfolioChange.toFixed(2)}
              </div>
              <div className="text-xs text-black">
                {report.portfolioChangePercent >= 0 ? '+' : ''}{report.portfolioChangePercent.toFixed(2)}%
              </div>
            </div>

            <div className="border border-black p-4 rounded bg-gray-50">
              <div className="text-sm text-black mb-1">Premium Efficiency</div>
              <div className={`text-2xl font-bold ${report.premiumEfficiencyChange >= 0 ? 'text-black' : 'text-black'}`}>
                {report.premiumEfficiencyChange >= 0 ? '+' : ''}{report.premiumEfficiencyChange.toFixed(2)}%
              </div>
              <div className="text-xs text-black">
                {report.premiumEfficiencyChange >= 0 ? 'Improved' : 'Declined'}
              </div>
            </div>

            <div className="border border-black p-4 rounded bg-gray-50">
              <div className="text-sm text-black mb-1">Major Alerts</div>
              <div className="text-2xl font-bold text-black">{report.majorAlerts.length}</div>
              <div className="text-xs text-black">High priority signals</div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-black mb-3">Price Trend Direction:</h4>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {Object.entries(report.priceTrendDirection).map(([metal, direction]) => (
                <div key={metal} className="flex items-center justify-between border border-black p-2 rounded">
                  <span className="text-sm text-black capitalize">{metal}</span>
                  <div className="flex items-center gap-1">
                    {getTrendIcon(direction)}
                    <span className="text-xs text-black capitalize">{direction}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {report.localSpreadShifts.length > 0 && (
            <div>
              <h4 className="font-semibold text-black mb-3">Local Spread Shifts:</h4>
              <div className="space-y-2">
                {report.localSpreadShifts.map((shift, idx) => (
                  <div key={idx} className="border-l-4 border-blue-500 bg-blue-50 p-3">
                    <p className="text-sm text-black">{shift}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {report.majorAlerts.length > 0 && (
            <div>
              <h4 className="font-semibold text-black mb-3 flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-black" />
                Major Alerts This Week:
              </h4>
              <div className="space-y-3">
                {report.majorAlerts.map(alert => (
                  <div key={alert.id} className="border-2 border-black p-4 rounded">
                    <div className="flex items-start justify-between mb-2">
                      <h5 className="font-semibold text-black">{alert.title}</h5>
                      <Badge className="bg-orange-100 border-orange-500 text-black">
                        {alert.severity.toUpperCase()}
                      </Badge>
                    </div>
                    <p className="text-sm text-black">{alert.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="bg-black text-white p-4 rounded">
            <h4 className="font-semibold mb-3">💎 Real-World Recommendations:</h4>
            <ul className="space-y-2">
              {report.recommendations.map((rec, idx) => (
                <li key={idx} className="text-sm">• {rec}</li>
              ))}
            </ul>
          </div>

          <div className="border border-black p-4 rounded bg-gray-50">
            <h4 className="font-semibold text-black mb-2">Weekly Summary:</h4>
            <p className="text-sm text-black">
              Portfolio {report.portfolioChange >= 0 ? 'increased' : 'decreased'} by{' '}
              {Math.abs(report.portfolioChangePercent).toFixed(2)}% this week.{' '}
              {report.majorAlerts.length > 0
                ? `${report.majorAlerts.length} high-priority alerts detected requiring attention.`
                : 'No critical alerts detected - market conditions stable.'}{' '}
              Premium efficiency {report.premiumEfficiencyChange >= 0 ? 'improved' : 'declined'} by{' '}
              {Math.abs(report.premiumEfficiencyChange).toFixed(2)}%.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
