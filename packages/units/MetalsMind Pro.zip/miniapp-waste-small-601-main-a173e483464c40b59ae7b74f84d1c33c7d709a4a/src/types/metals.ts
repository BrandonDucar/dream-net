export type MetalType = 'gold' | 'silver' | 'platinum' | 'palladium' | 'scrap' | 'numismatics'

export type FeatureType = 'portfolio' | 'pricing' | 'signals' | 'authenticity' | 'all'

export interface UserPreferences {
  metals: MetalType[]
  features: FeatureType[]
  region: string
  city: string
}

export interface InventoryItem {
  id: string
  name: string
  metal: MetalType
  weight: number
  weightUnit: 'oz' | 'g' | 'kg'
  purity: number
  purchasePrice: number
  purchaseDate: string
  type: 'bullion' | 'coin' | 'numismatic' | 'scrap'
  notes?: string
}

export interface PriceData {
  metal: MetalType
  spotPrice: number
  trueMedianPrice: number
  dealerSpreadIndex: number
  volatility1m: number
  volatility5m: number
  volatility1h: number
  volatility24h: number
  trend: 'bullish' | 'bearish' | 'neutral'
  strength: string
  lastUpdated: string
}

export interface LocalMarketData {
  region: string
  city: string
  rating: 'buy' | 'sell' | 'hold'
  buyPremium: number
  sellDiscount: number
  liquidityIndex: number
  sweetSpot: string
  summary: string
}

export interface InventoryAnalysis {
  item: InventoryItem
  currentMeltValue: number
  meltPremium: number
  numismaticPremium: number
  dealerPremium: number
  temporaryMarketPremium: number
  totalValue: number
  gainLoss: number
  gainLossPercent: number
  liquidityRank: 'fast' | 'medium' | 'slow'
  recommendations: string[]
}

export interface PatternAlert {
  id: string
  type: 'spread' | 'futures' | 'whale' | 'supply' | 'seasonal' | 'correlation'
  severity: 'low' | 'medium' | 'high' | 'critical'
  metal: MetalType | 'all'
  title: string
  description: string
  timestamp: string
  actionable: boolean
}

export interface DealerInfo {
  name: string
  reliabilityScore: number
  spreadFairness: number
  shippingSpeed: number
  buybackConsistency: number
  trustworthiness: number
  knownIssues: string[]
  bestUseCase: string
  summary: string
}

export interface DCARecommendation {
  metal: MetalType
  recommendedAmount: number
  frequency: 'daily' | 'weekly' | 'monthly'
  reasoning: string
  currentOpportunity: 'excellent' | 'good' | 'fair' | 'poor'
  alternativeSuggestions: string[]
  premiumDipWindow: boolean
}

export interface WeeklyReport {
  startDate: string
  endDate: string
  portfolioChange: number
  portfolioChangePercent: number
  premiumEfficiencyChange: number
  localSpreadShifts: string[]
  priceTrendDirection: Record<MetalType, 'up' | 'down' | 'flat'>
  majorAlerts: PatternAlert[]
  recommendations: string[]
}

export interface AuthenticityCheck {
  itemName: string
  authenticityScore: number
  riskLevel: 'low' | 'medium' | 'high' | 'critical'
  designMarkers: string[]
  warnings: string[]
  corrections: string[]
  confidence: string
}
