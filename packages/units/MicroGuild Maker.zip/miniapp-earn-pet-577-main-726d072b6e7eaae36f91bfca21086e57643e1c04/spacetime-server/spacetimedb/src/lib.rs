use spacetimedb::{table, reducer, ReducerContext, Identity, Table, Timestamp, SpacetimeType};
use std::cmp::Ordering;

// ----- Custom Types -----

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum MemberRole {
    Creator,
    Member,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum ProposalStatus {
    Active,
    Passed,
    Rejected,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum VoteType {
    Yes,
    No,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum ActivityType {
    Created,
    Joined,
    Voted,
    Funded,
    Withdrew,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum GoalStatus {
    Active,
    Completed,
    Cancelled,
}

// ----- Tables -----

#[table(name = guild, public)]
#[derive(Clone)]
pub struct Guild {
    #[primary_key]
    #[auto_inc]
    id: u64,
    name: String,
    description: String,
    member_count: u32,
    treasury_balance: String, // ETH string (e.g., "0", "1.2345")
    max_members: u32,
    created_at: Timestamp,
    creator_identity: Identity,
}

#[table(name = guild_member, public)]
#[derive(Clone)]
pub struct GuildMember {
    #[primary_key]
    member_identity: Identity,
    #[index(btree)]
    guild_id: u64,
    username: String,
    role: MemberRole,
    joined_at: Timestamp,
}

#[table(name = proposal, public)]
#[derive(Clone)]
pub struct Proposal {
    #[primary_key]
    #[auto_inc]
    id: u64,
    #[index(btree)]
    guild_id: u64,
    title: String,
    description: String,
    proposer_identity: Identity,
    yes_votes: u32,
    no_votes: u32,
    status: ProposalStatus,
    created_at: Timestamp,
}

#[table(name = vote, public)]
#[derive(Clone)]
pub struct Vote {
    #[primary_key]
    #[auto_inc]
    id: u64,
    #[index(btree)]
    proposal_id: u64,
    #[index(btree)]
    voter_identity: Identity,
    vote_type: VoteType,
    voted_at: Timestamp,
}

#[table(name = activity, public)]
#[derive(Clone)]
pub struct Activity {
    #[primary_key]
    #[auto_inc]
    id: u64,
    #[index(btree)]
    guild_id: u64,
    action_type: ActivityType,
    description: String,
    actor_identity: Identity,
    created_at: Timestamp,
}

#[table(name = goal, public)]
#[derive(Clone)]
pub struct Goal {
    #[primary_key]
    #[auto_inc]
    id: u64,
    #[index(btree)]
    guild_id: u64,
    title: String,
    description: String,
    target_amount: String,
    current_amount: String,
    status: GoalStatus,
    created_at: Timestamp,
}

// ----- Helpers -----

fn is_member_of_guild(ctx: &ReducerContext, guild_id: u64, identity: Identity) -> bool {
    if let Some(member) = ctx.db.guild_member().member_identity().find(&identity) {
        member.guild_id == guild_id
    } else {
        false
    }
}

fn get_member(ctx: &ReducerContext, identity: Identity) -> Option<GuildMember> {
    ctx.db.guild_member().member_identity().find(&identity)
}

fn normalize_action(s: &str) -> Option<ActivityType> {
    match s.to_ascii_lowercase().as_str() {
        "created" => Some(ActivityType::Created),
        "joined" => Some(ActivityType::Joined),
        "voted" => Some(ActivityType::Voted),
        "funded" => Some(ActivityType::Funded),
        "withdrew" | "withdraw" => Some(ActivityType::Withdrew),
        _ => None,
    }
}

// Convert decimal string (up to 18 fractional digits) to wei (i128)
fn parse_eth_to_wei(amount: &str) -> Result<i128, String> {
    let s = amount.trim();
    if s.is_empty() {
        return Err("Amount cannot be empty".into());
    }
    let mut neg = false;
    let mut s = s;
    if let Some(rest) = s.strip_prefix('-') {
        neg = true;
        s = rest;
    } else if let Some(rest) = s.strip_prefix('+') {
        s = rest;
    }

    let parts: Vec<&str> = s.split('.').collect();
    if parts.len() > 2 {
        return Err("Invalid amount format".into());
    }
    let whole = parts[0];
    if !whole.chars().all(|c| c.is_ascii_digit()) || (whole.is_empty()) {
        return Err("Invalid whole part".into());
    }
    let mut frac = if parts.len() == 2 { parts[1] } else { "" };
    if !frac.chars().all(|c| c.is_ascii_digit()) {
        return Err("Invalid fractional part".into());
    }
    if frac.len() > 18 {
        return Err("Too many fractional digits (max 18)".into());
    }
    // Pad fractional to 18
    let mut frac_owned = frac.to_string();
    while frac_owned.len() < 18 {
        frac_owned.push('0');
    }
    frac = &frac_owned;

    let whole_val: i128 = whole.parse::<i128>().map_err(|_| "Invalid whole number")?;
    let frac_val: i128 = if frac.is_empty() { 0 } else { frac.parse::<i128>().map_err(|_| "Invalid fractional number")? };

    let wei = whole_val
        .checked_mul(1_000_000_000_000_000_000i128)
        .and_then(|v| v.checked_add(frac_val))
        .ok_or_else(|| "Amount overflow".to_string())?;

    Ok(if neg { -wei } else { wei })
}

fn format_wei_to_eth(wei: i128) -> String {
    let neg = wei.is_negative();
    let abs = wei.abs();
    let whole = abs / 1_000_000_000_000_000_000i128;
    let frac = (abs % 1_000_000_000_000_000_000i128) as i128;
    if frac == 0 {
        if neg { format!("-{}", whole) } else { format!("{}", whole) }
    } else {
        let mut frac_str = format!("{:018}", frac);
        // Trim trailing zeros
        while frac_str.ends_with('0') {
            frac_str.pop();
        }
        if neg {
            format!("-{}.{}", whole, frac_str)
        } else {
            format!("{}.{}", whole, frac_str)
        }
    }
}

fn add_eth_strings(a: &str, b: &str) -> Result<String, String> {
    let wa = parse_eth_to_wei(a)?;
    let wb = parse_eth_to_wei(b)?;
    Ok(format_wei_to_eth(wa + wb))
}

// ----- Reducers -----

#[reducer]
pub fn create_guild(ctx: &ReducerContext, name: String, description: String, username: String) -> Result<(), String> {
    if name.trim().is_empty() {
        return Err("Guild name cannot be empty".into());
    }
    if username.trim().is_empty() {
        return Err("Username cannot be empty".into());
    }
    if get_member(ctx, ctx.sender).is_some() {
        return Err("You are already a member of a guild".into());
    }

    let guild_row = Guild {
        id: 0,
        name: name.clone(),
        description: description.clone(),
        member_count: 1,
        treasury_balance: "0".to_string(),
        max_members: 5,
        created_at: ctx.timestamp,
        creator_identity: ctx.sender,
    };

    match ctx.db.guild().try_insert(guild_row) {
        Ok(inserted) => {
            let new_guild_id = inserted.id;

            let member = GuildMember {
                member_identity: ctx.sender,
                guild_id: new_guild_id,
                username: username.clone(),
                role: MemberRole::Creator,
                joined_at: ctx.timestamp,
            };
            if ctx.db.guild_member().try_insert(member).is_err() {
                return Err("Failed to add creator as guild member".into());
            }

            let activity = Activity {
                id: 0,
                guild_id: new_guild_id,
                action_type: ActivityType::Created,
                description: format!("Guild '{}' created", name),
                actor_identity: ctx.sender,
                created_at: ctx.timestamp,
            };
            let _ = ctx.db.activity().try_insert(activity);

            Ok(())
        }
        Err(e) => Err(format!("Failed to create guild: {}", e)),
    }
}

#[reducer]
pub fn join_guild(ctx: &ReducerContext, guild_id: u64, username: String) -> Result<(), String> {
    if username.trim().is_empty() {
        return Err("Username cannot be empty".into());
    }
    let mut guild = match ctx.db.guild().id().find(guild_id) {
        Some(g) => g,
        None => return Err("Guild not found".into()),
    };

    if let Some(existing) = get_member(ctx, ctx.sender) {
        if existing.guild_id == guild_id {
            return Err("You are already a member of this guild".into());
        } else {
            return Err("You are already a member of a different guild".into());
        }
    }

    if guild.member_count >= guild.max_members {
        return Err("Guild is at maximum capacity".into());
    }

    let gm = GuildMember {
        member_identity: ctx.sender,
        guild_id,
        username: username.clone(),
        role: MemberRole::Member,
        joined_at: ctx.timestamp,
    };
    ctx.db.guild_member().insert(gm);

    guild.member_count += 1;
    ctx.db.guild().id().update(guild);

    let activity = Activity {
        id: 0,
        guild_id,
        action_type: ActivityType::Joined,
        description: format!("{} joined the guild", username),
        actor_identity: ctx.sender,
        created_at: ctx.timestamp,
    };
    let _ = ctx.db.activity().try_insert(activity);

    Ok(())
}

#[reducer]
pub fn leave_guild(ctx: &ReducerContext, guild_id: u64) -> Result<(), String> {
    let mut guild = match ctx.db.guild().id().find(guild_id) {
        Some(g) => g,
        None => return Err("Guild not found".into()),
    };

    let member = match get_member(ctx, ctx.sender) {
        Some(m) => {
            if m.guild_id != guild_id {
                return Err("You are not a member of this guild".into());
            }
            m
        }
        None => return Err("You are not a member of any guild".into()),
    };

    if matches!(member.role, MemberRole::Creator) && guild.member_count > 1 {
        return Err("Creator cannot leave while other members remain".into());
    }

    ctx.db.guild_member().member_identity().delete(&ctx.sender);

    if guild.member_count > 0 {
        guild.member_count -= 1;
        ctx.db.guild().id().update(guild);
    }

    Ok(())
}

#[reducer]
pub fn create_proposal(ctx: &ReducerContext, guild_id: u64, title: String, description: String) -> Result<(), String> {
    if title.trim().is_empty() {
        return Err("Title cannot be empty".into());
    }

    if ctx.db.guild().id().find(guild_id).is_none() {
        return Err("Guild not found".into());
    }

    if !is_member_of_guild(ctx, guild_id, ctx.sender) {
        return Err("Only guild members can create proposals".into());
    }

    let proposal = Proposal {
        id: 0,
        guild_id,
        title: title.clone(),
        description: description.clone(),
        proposer_identity: ctx.sender,
        yes_votes: 0,
        no_votes: 0,
        status: ProposalStatus::Active,
        created_at: ctx.timestamp,
    };

    match ctx.db.proposal().try_insert(proposal) {
        Ok(p) => {
            let activity = Activity {
                id: 0,
                guild_id,
                action_type: ActivityType::Created,
                description: format!("Proposal created: {}", title),
                actor_identity: ctx.sender,
                created_at: ctx.timestamp,
            };
            let _ = ctx.db.activity().try_insert(activity);
            let _ = p; // silence unused
            Ok(())
        }
        Err(e) => Err(format!("Failed to create proposal: {}", e)),
    }
}

#[reducer]
pub fn cast_vote(ctx: &ReducerContext, proposal_id: u64, vote_yes: bool) -> Result<(), String> {
    let mut proposal = match ctx.db.proposal().id().find(proposal_id) {
        Some(p) => p,
        None => return Err("Proposal not found".into()),
    };

    if !is_member_of_guild(ctx, proposal.guild_id, ctx.sender) {
        return Err("Only guild members can vote on proposals".into());
    }

    if !matches!(proposal.status, ProposalStatus::Active) {
        return Err("Proposal is not active".into());
    }

    // Ensure voter hasn't already voted on this proposal
    for v in ctx.db.vote().iter() {
        if v.proposal_id == proposal_id && v.voter_identity == ctx.sender {
            return Err("You have already voted on this proposal".into());
        }
    }

    let vt = if vote_yes { VoteType::Yes } else { VoteType::No };
    let vote_row = Vote {
        id: 0,
        proposal_id,
        voter_identity: ctx.sender,
        vote_type: vt.clone(),
        voted_at: ctx.timestamp,
    };
    ctx.db.vote().insert(vote_row);

    // Update counts
    match vt {
        VoteType::Yes => proposal.yes_votes += 1,
        VoteType::No => proposal.no_votes += 1,
    }
    ctx.db.proposal().id().update(proposal);

    // Log activity
    let activity = Activity {
        id: 0,
        guild_id: ctx.db.proposal().id().find(proposal_id).map(|p| p.guild_id).unwrap_or(0),
        action_type: ActivityType::Voted,
        description: format!(
            "Voted {} on proposal {}",
            if vote_yes { "YES" } else { "NO" },
            proposal_id
        ),
        actor_identity: ctx.sender,
        created_at: ctx.timestamp,
    };
    let _ = ctx.db.activity().try_insert(activity);

    Ok(())
}

#[reducer]
pub fn update_treasury(ctx: &ReducerContext, guild_id: u64, amount_change: String, action: String) -> Result<(), String> {
    let mut guild = match ctx.db.guild().id().find(guild_id) {
        Some(g) => g,
        None => return Err("Guild not found".into()),
    };

    if !is_member_of_guild(ctx, guild_id, ctx.sender) {
        return Err("Only guild members can update the treasury".into());
    }

    let action_type = normalize_action(&action).ok_or_else(|| "Invalid action. Use 'funded' or 'withdrew'".to_string())?;
    if !matches!(action_type, ActivityType::Funded | ActivityType::Withdrew) {
        return Err("Action must be 'funded' or 'withdrew'".into());
    }

    // Normalize delta sign based on action
    let delta_abs = {
        let s = amount_change.trim();
        if s.starts_with('-') { s.trim_start_matches('-').to_string() } else { s.to_string() }
    };
    let signed_delta = if matches!(action_type, ActivityType::Withdrew) {
        format!("-{}", delta_abs)
    } else {
        delta_abs.clone()
    };

    let new_balance = add_eth_strings(&guild.treasury_balance, &signed_delta)?;
    let activity_desc = match action_type {
        ActivityType::Funded => format!("Funded {} ETH", amount_change),
        ActivityType::Withdrew => format!("Withdrew {} ETH", amount_change),
        _ => action.to_string(),
    };

    guild.treasury_balance = new_balance.clone();
    // Store for logging if needed later
    let updated_balance_str = guild.treasury_balance.clone();
    ctx.db.guild().id().update(guild);

    let activity = Activity {
        id: 0,
        guild_id,
        action_type,
        description: format!("{} | New treasury balance: {}", activity_desc, updated_balance_str),
        actor_identity: ctx.sender,
        created_at: ctx.timestamp,
    };
    let _ = ctx.db.activity().try_insert(activity);

    Ok(())
}

#[reducer]
pub fn create_goal(ctx: &ReducerContext, guild_id: u64, title: String, description: String, target_amount: String) -> Result<(), String> {
    if title.trim().is_empty() {
        return Err("Title cannot be empty".into());
    }
    if ctx.db.guild().id().find(guild_id).is_none() {
        return Err("Guild not found".into());
    }
    if !is_member_of_guild(ctx, guild_id, ctx.sender) {
        return Err("Only guild members can create goals".into());
    }

    // Validate target amount parses
    let _ = parse_eth_to_wei(&target_amount).map_err(|e| format!("Invalid target_amount: {}", e))?;

    let goal = Goal {
        id: 0,
        guild_id,
        title: title.clone(),
        description: description.clone(),
        target_amount: target_amount.clone(),
        current_amount: "0".to_string(),
        status: GoalStatus::Active,
        created_at: ctx.timestamp,
    };

    match ctx.db.goal().try_insert(goal) {
        Ok(g) => {
            let activity = Activity {
                id: 0,
                guild_id,
                action_type: ActivityType::Created,
                description: format!("Goal created: {}", title),
                actor_identity: ctx.sender,
                created_at: ctx.timestamp,
            };
            let _ = ctx.db.activity().try_insert(activity);
            let _ = g;
            Ok(())
        }
        Err(e) => Err(format!("Failed to create goal: {}", e)),
    }
}

#[reducer]
pub fn update_goal_progress(ctx: &ReducerContext, goal_id: u64, new_amount: String) -> Result<(), String> {
    let mut goal = match ctx.db.goal().id().find(goal_id) {
        Some(g) => g,
        None => return Err("Goal not found".into()),
    };

    if !is_member_of_guild(ctx, goal.guild_id, ctx.sender) {
        return Err("Only guild members can update goals".into());
    }

    // Validate new amount
    let _ = parse_eth_to_wei(&new_amount).map_err(|e| format!("Invalid amount: {}", e))?;
    goal.current_amount = new_amount;
    ctx.db.goal().id().update(goal);

    Ok(())
}

#[reducer]
pub fn complete_goal(ctx: &ReducerContext, goal_id: u64) -> Result<(), String> {
    let mut goal = match ctx.db.goal().id().find(goal_id) {
        Some(g) => g,
        None => return Err("Goal not found".into()),
    };

    if !is_member_of_guild(ctx, goal.guild_id, ctx.sender) {
        return Err("Only guild members can complete goals".into());
    }

    if !matches!(goal.status, GoalStatus::Active) {
        return Err("Goal is not active".into());
    }

    goal.status = GoalStatus::Completed;
    ctx.db.goal().id().update(goal);

    Ok(())
}