import type { Metadata } from 'next';
import '@coinbase/onchainkit/styles.css';
import './globals.css';
import { Providers } from './providers';
import FarcasterWrapper from "@/components/FarcasterWrapper";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
        <html lang="en">
          <body className="antialiased">
            <Providers>
      <FarcasterWrapper>
        {children}
      </FarcasterWrapper>
      </Providers>
          </body>
        </html>
      );
}

export const metadata: Metadata = {
        title: "MicroGuild Maker",
        description: "Instantly create tiny DAOs with ease. One click, no fuss. Enjoy shared vaults, votes, goals, and perks. Perfect for micro-teams on Base. Try MicroGuild Maker today!",
        other: { "fc:frame": JSON.stringify({"version":"next","imageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_a8384446-14be-40f0-9c9a-2824ce7410c5-SgWNi4QiKeecdcg4Ej13O2QT6rfwPw","button":{"title":"Open with Ohara","action":{"type":"launch_frame","name":"MicroGuild Maker","url":"https://earn-pet-577.app.ohara.ai","splashImageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/farcaster/splash_images/splash_image1.svg","splashBackgroundColor":"#ffffff"}}}
        ) }
    };
