'use client'
import { useState, useEffect } from 'react';
import { useAccount } from 'wagmi';
import { useSpacetimeDB } from '@/hooks/use-spacetimedb';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Users, TrendingUp, Target, Activity as ActivityIcon, Coins, Plus, Vote, CheckCircle } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function HomePage() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const { address, status } = useAccount();
  const {
    connected,
    statusMessage,
    guilds,
    members,
    proposals,
    activities,
    goals,
    votes,
    myMembership,
    createGuild,
    joinGuild,
    createProposal,
    castVote,
    updateTreasury,
    createGoal,
    completeGoal,
  } = useSpacetimeDB();

  const [newGuildName, setNewGuildName] = useState('');
  const [newGuildDesc, setNewGuildDesc] = useState('');
  const [username, setUsername] = useState('');
  const [proposalTitle, setProposalTitle] = useState('');
  const [proposalDesc, setProposalDesc] = useState('');
  const [fundAmount, setFundAmount] = useState('');
  const [goalTitle, setGoalTitle] = useState('');
  const [goalDesc, setGoalDesc] = useState('');
  const [goalTarget, setGoalTarget] = useState('');
  const [selectedGuildId, setSelectedGuildId] = useState<bigint | null>(null);

  const myGuild = myMembership ? Array.from(guilds.values()).find(g => g.id === myMembership.guildId) : null;
  const myGuildMembers = myGuild ? Array.from(members.values()).filter(m => m.guildId === myGuild.id) : [];
  const myGuildProposals = myGuild ? Array.from(proposals.values()).filter(p => p.guildId === myGuild.id) : [];
  const myGuildActivities = myGuild ? Array.from(activities.values()).filter(a => a.guildId === myGuild.id).sort((a, b) => Number(b.id - a.id)).slice(0, 20) : [];
  const myGuildGoals = myGuild ? Array.from(goals.values()).filter(g => g.guildId === myGuild.id) : [];

  const handleCreateGuild = () => {
    if (!newGuildName || !username) return;
    createGuild(newGuildName, newGuildDesc, username);
    setNewGuildName('');
    setNewGuildDesc('');
    setUsername('');
  };

  const handleJoinGuild = (guildId: bigint) => {
    if (!username) return;
    joinGuild(guildId, username);
    setUsername('');
  };

  const handleCreateProposal = () => {
    if (!myGuild || !proposalTitle) return;
    createProposal(myGuild.id, proposalTitle, proposalDesc);
    setProposalTitle('');
    setProposalDesc('');
  };

  const handleCastVote = (proposalId: bigint, voteYes: boolean) => {
    castVote(proposalId, voteYes);
  };

  const handleFundGuild = () => {
    if (!myGuild || !fundAmount) return;
    updateTreasury(myGuild.id, fundAmount, 'funded');
    setFundAmount('');
  };

  const handleCreateGoal = () => {
    if (!myGuild || !goalTitle || !goalTarget) return;
    createGoal(myGuild.id, goalTitle, goalDesc, goalTarget);
    setGoalTitle('');
    setGoalDesc('');
    setGoalTarget('');
  };

  if (!connected) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl">MicroGuilds</CardTitle>
            <CardDescription>{statusMessage}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full"></div>
              </div>
              <p className="text-sm text-center text-gray-600">
                Tiny DAOs on Base. No overhead. Just vibes.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (status !== 'connected' || !address) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl">MicroGuilds</CardTitle>
            <CardDescription>Connect your wallet to continue</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-center text-gray-600">
              Open this app in Warpcast to access your Base wallet
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!myMembership) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-4 sm:p-6 pt-16">
        <div className="max-w-6xl mx-auto space-y-6">
          <div className="text-center space-y-2">
            <h1 className="text-4xl sm:text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              MicroGuilds
            </h1>
            <p className="text-lg text-gray-600">Tiny 2-5 member DAOs on Base. Group chats with a bank account.</p>
          </div>

          <Tabs defaultValue="browse" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="browse">Browse Guilds</TabsTrigger>
              <TabsTrigger value="create">Create Guild</TabsTrigger>
            </TabsList>

            <TabsContent value="browse" className="space-y-4 mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {Array.from(guilds.values()).map((guild) => (
                  <Card key={guild.id.toString()} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span className="truncate">{guild.name}</span>
                        <Badge variant="secondary">{guild.memberCount}/{guild.maxMembers}</Badge>
                      </CardTitle>
                      <CardDescription className="line-clamp-2">{guild.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-600">Treasury</span>
                          <span className="font-semibold">{guild.treasuryBalance} ETH</span>
                        </div>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              className="w-full" 
                              disabled={guild.memberCount >= guild.maxMembers}
                              onClick={() => setSelectedGuildId(guild.id)}
                            >
                              {guild.memberCount >= guild.maxMembers ? 'Full' : 'Join Guild'}
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Join {guild.name}</DialogTitle>
                              <DialogDescription>Enter your username to join this guild</DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div>
                                <Label htmlFor="join-username">Username</Label>
                                <Input
                                  id="join-username"
                                  placeholder="Your username"
                                  value={username}
                                  onChange={(e) => setUsername(e.target.value)}
                                />
                              </div>
                              <Button className="w-full" onClick={() => handleJoinGuild(guild.id)}>
                                Join Now
                              </Button>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {guilds.size === 0 && (
                <Card>
                  <CardContent className="py-12 text-center">
                    <p className="text-gray-600">No guilds yet. Be the first to create one!</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="create" className="space-y-4 mt-6">
              <Card className="max-w-2xl mx-auto">
                <CardHeader>
                  <CardTitle>Create a MicroGuild</CardTitle>
                  <CardDescription>Start your tiny DAO in seconds. Max 5 members, zero complexity.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="guild-name">Guild Name *</Label>
                    <Input
                      id="guild-name"
                      placeholder="The Degen Collective"
                      value={newGuildName}
                      onChange={(e) => setNewGuildName(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="guild-desc">Description</Label>
                    <Textarea
                      id="guild-desc"
                      placeholder="What's your guild about?"
                      value={newGuildDesc}
                      onChange={(e) => setNewGuildDesc(e.target.value)}
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label htmlFor="creator-username">Your Username *</Label>
                    <Input
                      id="creator-username"
                      placeholder="creator.eth"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                    />
                  </div>
                  <Button className="w-full" size="lg" onClick={handleCreateGuild}>
                    <Plus className="mr-2 h-5 w-5" />
                    Create MicroGuild
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-4 sm:p-6 pt-16">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold">{myGuild?.name || 'My Guild'}</h1>
            <p className="text-gray-600">{myGuild?.description}</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm text-gray-600">Treasury</p>
              <p className="text-2xl font-bold text-green-600">{myGuild?.treasuryBalance || '0'} ETH</p>
            </div>
            <Dialog>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Coins className="mr-2 h-4 w-4" />
                  Fund
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Fund Guild Treasury</DialogTitle>
                  <DialogDescription>Add ETH to the shared treasury</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="fund-amount">Amount (ETH)</Label>
                    <Input
                      id="fund-amount"
                      type="number"
                      step="0.001"
                      placeholder="0.1"
                      value={fundAmount}
                      onChange={(e) => setFundAmount(e.target.value)}
                    />
                  </div>
                  <Button className="w-full" onClick={handleFundGuild}>
                    Add Funds
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Tabs defaultValue="proposals" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="proposals">
              <Vote className="mr-2 h-4 w-4" />
              Proposals
            </TabsTrigger>
            <TabsTrigger value="goals">
              <Target className="mr-2 h-4 w-4" />
              Goals
            </TabsTrigger>
            <TabsTrigger value="members">
              <Users className="mr-2 h-4 w-4" />
              Members
            </TabsTrigger>
            <TabsTrigger value="activity">
              <ActivityIcon className="mr-2 h-4 w-4" />
              Activity
            </TabsTrigger>
          </TabsList>

          <TabsContent value="proposals" className="space-y-4 mt-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Active Proposals</h2>
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="mr-2 h-4 w-4" />
                    New Proposal
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create Proposal</DialogTitle>
                    <DialogDescription>Start a vote on something important</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="proposal-title">Title</Label>
                      <Input
                        id="proposal-title"
                        placeholder="Proposal title"
                        value={proposalTitle}
                        onChange={(e) => setProposalTitle(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="proposal-desc">Description</Label>
                      <Textarea
                        id="proposal-desc"
                        placeholder="What are you proposing?"
                        value={proposalDesc}
                        onChange={(e) => setProposalDesc(e.target.value)}
                        rows={3}
                      />
                    </div>
                    <Button className="w-full" onClick={handleCreateProposal}>
                      Create Proposal
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid gap-4">
              {myGuildProposals.map((prop) => {
                const userVote = Array.from(votes.values()).find(
                  v => v.proposalId === prop.id && v.voterIdentity.toHexString() === myMembership?.memberIdentity.toHexString()
                );
                const hasVoted = !!userVote;

                return (
                  <Card key={prop.id.toString()}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle>{prop.title}</CardTitle>
                          <CardDescription>{prop.description}</CardDescription>
                        </div>
                        <Badge variant={prop.status.tag === 'Active' ? 'default' : 'secondary'}>
                          {prop.status.tag}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex gap-4 text-sm">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-600" />
                          <span className="font-semibold">{prop.yesVotes}</span>
                          <span className="text-gray-600">Yes</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-red-600" />
                          <span className="font-semibold">{prop.noVotes}</span>
                          <span className="text-gray-600">No</span>
                        </div>
                      </div>
                      {prop.status.tag === 'Active' && !hasVoted && (
                        <div className="flex gap-2">
                          <Button
                            className="flex-1 bg-green-600 hover:bg-green-700"
                            onClick={() => handleCastVote(prop.id, true)}
                          >
                            Vote Yes
                          </Button>
                          <Button
                            variant="destructive"
                            className="flex-1"
                            onClick={() => handleCastVote(prop.id, false)}
                          >
                            Vote No
                          </Button>
                        </div>
                      )}
                      {hasVoted && (
                        <Badge variant="secondary">
                          You voted {userVote?.voteType.tag === 'Yes' ? 'Yes' : 'No'}
                        </Badge>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {myGuildProposals.length === 0 && (
              <Card>
                <CardContent className="py-12 text-center">
                  <p className="text-gray-600">No proposals yet. Create one to get started!</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="goals" className="space-y-4 mt-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Guild Goals</h2>
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="mr-2 h-4 w-4" />
                    New Goal
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create Goal</DialogTitle>
                    <DialogDescription>Set a shared objective for your guild</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="goal-title">Title</Label>
                      <Input
                        id="goal-title"
                        placeholder="Goal title"
                        value={goalTitle}
                        onChange={(e) => setGoalTitle(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="goal-desc">Description</Label>
                      <Textarea
                        id="goal-desc"
                        placeholder="What's the goal?"
                        value={goalDesc}
                        onChange={(e) => setGoalDesc(e.target.value)}
                        rows={2}
                      />
                    </div>
                    <div>
                      <Label htmlFor="goal-target">Target Amount (ETH)</Label>
                      <Input
                        id="goal-target"
                        type="number"
                        step="0.01"
                        placeholder="1.0"
                        value={goalTarget}
                        onChange={(e) => setGoalTarget(e.target.value)}
                      />
                    </div>
                    <Button className="w-full" onClick={handleCreateGoal}>
                      Create Goal
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid gap-4">
              {myGuildGoals.map((goal) => {
                const progress = parseFloat(goal.currentAmount || '0') / parseFloat(goal.targetAmount || '1') * 100;
                return (
                  <Card key={goal.id.toString()}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle>{goal.title}</CardTitle>
                          <CardDescription>{goal.description}</CardDescription>
                        </div>
                        <Badge variant={goal.status.tag === 'Active' ? 'default' : 'secondary'}>
                          {goal.status.tag}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Progress</span>
                          <span className="font-semibold">{goal.currentAmount} / {goal.targetAmount} ETH</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full transition-all"
                            style={{ width: `${Math.min(progress, 100)}%` }}
                          />
                        </div>
                      </div>
                      {goal.status.tag === 'Active' && progress >= 100 && (
                        <Button
                          size="sm"
                          className="w-full"
                          onClick={() => completeGoal(goal.id)}
                        >
                          <CheckCircle className="mr-2 h-4 w-4" />
                          Mark Complete
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {myGuildGoals.length === 0 && (
              <Card>
                <CardContent className="py-12 text-center">
                  <p className="text-gray-600">No goals yet. Set one to rally your guild!</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="members" className="space-y-4 mt-6">
            <h2 className="text-xl font-semibold">Guild Members ({myGuildMembers.length}/{myGuild?.maxMembers})</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {myGuildMembers.map((member) => (
                <Card key={member.memberIdentity.toHexString()}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>{member.username}</span>
                      {member.role.tag === 'Creator' && (
                        <Badge variant="default">Creator</Badge>
                      )}
                    </CardTitle>
                    <CardDescription className="text-xs truncate">
                      {member.memberIdentity.toHexString().substring(0, 16)}...
                    </CardDescription>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="activity" className="space-y-4 mt-6">
            <h2 className="text-xl font-semibold">Recent Activity</h2>
            <Card>
              <ScrollArea className="h-[500px]">
                <div className="p-6 space-y-4">
                  {myGuildActivities.map((activity, index) => {
                    const member = Array.from(members.values()).find(
                      m => m.memberIdentity.toHexString() === activity.actorIdentity.toHexString()
                    );
                    return (
                      <div key={activity.id.toString()}>
                        <div className="flex gap-3">
                          <div className="flex-shrink-0">
                            {activity.actionType.tag === 'Created' && <TrendingUp className="h-5 w-5 text-blue-600" />}
                            {activity.actionType.tag === 'Joined' && <Users className="h-5 w-5 text-green-600" />}
                            {activity.actionType.tag === 'Voted' && <Vote className="h-5 w-5 text-purple-600" />}
                            {activity.actionType.tag === 'Funded' && <Coins className="h-5 w-5 text-yellow-600" />}
                            {activity.actionType.tag === 'Withdrew' && <Coins className="h-5 w-5 text-red-600" />}
                          </div>
                          <div className="flex-1 space-y-1">
                            <p className="text-sm">
                              <span className="font-semibold">{member?.username || 'Unknown'}</span>
                              <span className="text-gray-600"> {activity.description}</span>
                            </p>
                            <p className="text-xs text-gray-500">
                              {new Date(Number(activity.createdAt.toDate())).toLocaleString()}
                            </p>
                          </div>
                        </div>
                        {index < myGuildActivities.length - 1 && <Separator className="my-4" />}
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            </Card>
            {myGuildActivities.length === 0 && (
              <Card>
                <CardContent className="py-12 text-center">
                  <p className="text-gray-600">No activity yet. Get started!</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
