'use client';

import { useEffect, useState, useCallback, useRef } from 'react';
import { Identity } from 'spacetimedb';
import type { DbConnection as BaseDbConnection, EventContext, Guild, GuildMember, Proposal, Activity, Goal, Vote, RemoteTables, RemoteReducers } from '../spacetime_module_bindings';

// Extend DbConnection to include db and reducers properties
type DbConnection = BaseDbConnection & {
  db: RemoteTables;
  reducers: RemoteReducers;
};
import * as moduleBindings from '../spacetime_module_bindings';

export function useSpacetimeDB() {
  const [connected, setConnected] = useState(false);
  const [identity, setIdentity] = useState<Identity | null>(null);
  const [statusMessage, setStatusMessage] = useState('Connecting to real-time network...');
  const [guilds, setGuilds] = useState<ReadonlyMap<bigint, Guild>>(new Map());
  const [members, setMembers] = useState<ReadonlyMap<string, GuildMember>>(new Map());
  const [proposals, setProposals] = useState<ReadonlyMap<bigint, Proposal>>(new Map());
  const [activities, setActivities] = useState<ReadonlyMap<bigint, Activity>>(new Map());
  const [goals, setGoals] = useState<ReadonlyMap<bigint, Goal>>(new Map());
  const [votes, setVotes] = useState<ReadonlyMap<bigint, Vote>>(new Map());
  const [myMembership, setMyMembership] = useState<GuildMember | null>(null);
  const connectionRef = useRef<DbConnection | null>(null);

  const registerTableCallbacks = useCallback((currentIdentity: Identity) => {
    if (!connectionRef.current) return;

    connectionRef.current.db.guild.onInsert((_ctx: EventContext | undefined, guild: Guild) => {
      setGuilds((prev: ReadonlyMap<bigint, Guild>) => new Map(prev).set(guild.id, guild));
    });

    connectionRef.current.db.guild.onUpdate((_ctx: EventContext | undefined, _old: Guild, newGuild: Guild) => {
      setGuilds((prev: ReadonlyMap<bigint, Guild>) => {
        const newMap = new Map(prev);
        newMap.set(newGuild.id, newGuild);
        return newMap;
      });
    });

    connectionRef.current.db.guild.onDelete((_ctx: EventContext, guild: Guild) => {
      setGuilds((prev: ReadonlyMap<bigint, Guild>) => {
        const newMap = new Map(prev);
        newMap.delete(guild.id);
        return newMap;
      });
    });

    connectionRef.current.db.guildMember.onInsert((_ctx: EventContext | undefined, member: GuildMember) => {
      setMembers((prev: ReadonlyMap<string, GuildMember>) => new Map(prev).set(member.memberIdentity.toHexString(), member));
      
      if (currentIdentity && member.memberIdentity.toHexString() === currentIdentity.toHexString()) {
        setMyMembership(member);
      }
    });

    connectionRef.current.db.guildMember.onUpdate((_ctx: EventContext | undefined, _old: GuildMember, newMember: GuildMember) => {
      setMembers((prev: ReadonlyMap<string, GuildMember>) => {
        const newMap = new Map(prev);
        newMap.set(newMember.memberIdentity.toHexString(), newMember);
        return newMap;
      });
      
      if (currentIdentity && newMember.memberIdentity.toHexString() === currentIdentity.toHexString()) {
        setMyMembership(newMember);
      }
    });

    connectionRef.current.db.guildMember.onDelete((_ctx: EventContext, member: GuildMember) => {
      setMembers((prev: ReadonlyMap<string, GuildMember>) => {
        const newMap = new Map(prev);
        newMap.delete(member.memberIdentity.toHexString());
        return newMap;
      });
      
      if (currentIdentity && member.memberIdentity.toHexString() === currentIdentity.toHexString()) {
        setMyMembership(null);
      }
    });

    connectionRef.current.db.proposal.onInsert((_ctx: EventContext | undefined, proposal: Proposal) => {
      setProposals((prev: ReadonlyMap<bigint, Proposal>) => new Map(prev).set(proposal.id, proposal));
    });

    connectionRef.current.db.proposal.onUpdate((_ctx: EventContext | undefined, _old: Proposal, newProposal: Proposal) => {
      setProposals((prev: ReadonlyMap<bigint, Proposal>) => {
        const newMap = new Map(prev);
        newMap.set(newProposal.id, newProposal);
        return newMap;
      });
    });

    connectionRef.current.db.activity.onInsert((_ctx: EventContext | undefined, activity: Activity) => {
      setActivities((prev: ReadonlyMap<bigint, Activity>) => new Map(prev).set(activity.id, activity));
    });

    connectionRef.current.db.goal.onInsert((_ctx: EventContext | undefined, goal: Goal) => {
      setGoals((prev: ReadonlyMap<bigint, Goal>) => new Map(prev).set(goal.id, goal));
    });

    connectionRef.current.db.goal.onUpdate((_ctx: EventContext | undefined, _old: Goal, newGoal: Goal) => {
      setGoals((prev: ReadonlyMap<bigint, Goal>) => {
        const newMap = new Map(prev);
        newMap.set(newGoal.id, newGoal);
        return newMap;
      });
    });

    connectionRef.current.db.vote.onInsert((_ctx: EventContext | undefined, vote: Vote) => {
      setVotes((prev: ReadonlyMap<bigint, Vote>) => new Map(prev).set(vote.id, vote));
    });
  }, []);

  const subscribeToTables = useCallback(() => {
    if (!connectionRef.current) return;
    
    const queries = [
      'SELECT * FROM guild',
      'SELECT * FROM guild_member',
      'SELECT * FROM proposal',
      'SELECT * FROM activity',
      'SELECT * FROM goal',
      'SELECT * FROM vote'
    ];
    
    const builder = connectionRef.current.subscriptionBuilder() as any;
    builder
      .onApplied(() => {
        setStatusMessage('Connected! Ready to build.');
        processInitialCache();
      })
      .onError((error: Error) => {
        console.error('Subscription error:', error);
        setStatusMessage(`Error: ${error.message}`);
      })
      .subscribe(queries);
  }, []);

  const processInitialCache = useCallback(() => {
    if (!connectionRef.current) return;

    const guildMap = new Map<bigint, Guild>();
    for (const guild of connectionRef.current.db.guild.iter()) {
      guildMap.set(guild.id, guild);
    }
    setGuilds(guildMap);

    const memberMap = new Map<string, GuildMember>();
    for (const member of connectionRef.current.db.guildMember.iter()) {
      memberMap.set(member.memberIdentity.toHexString(), member);
      if (identity && member.memberIdentity.toHexString() === identity.toHexString()) {
        setMyMembership(member);
      }
    }
    setMembers(memberMap);

    const proposalMap = new Map<bigint, Proposal>();
    for (const proposal of connectionRef.current.db.proposal.iter()) {
      proposalMap.set(proposal.id, proposal);
    }
    setProposals(proposalMap);

    const activityMap = new Map<bigint, Activity>();
    for (const activity of connectionRef.current.db.activity.iter()) {
      activityMap.set(activity.id, activity);
    }
    setActivities(activityMap);

    const goalMap = new Map<bigint, Goal>();
    for (const goal of connectionRef.current.db.goal.iter()) {
      goalMap.set(goal.id, goal);
    }
    setGoals(goalMap);

    const voteMap = new Map<bigint, Vote>();
    for (const vote of connectionRef.current.db.vote.iter()) {
      voteMap.set(vote.id, vote);
    }
    setVotes(voteMap);
  }, [identity]);

  useEffect(() => {
    // Only run on client side
    if (typeof window === 'undefined') {
      return;
    }
    
    if (connectionRef.current) {
      return;
    }

    const dbHost = 'wss://maincloud.spacetimedb.com';
    const dbName = process.env.NEXT_PUBLIC_SPACETIME_MODULE_NAME || 'default_module';

    const onConnect = (connection: DbConnection, id: Identity, _token: string) => {
      connectionRef.current = connection;
      setIdentity(id);
      setConnected(true);
      setStatusMessage('Syncing guilds...');
      
      subscribeToTables();
      registerTableCallbacks(id);
    };

    const onDisconnect = (_ctx: unknown, reason?: Error | null) => {
      const reasonStr = reason ? reason.message : 'Connection lost';
      setStatusMessage(`Disconnected: ${reasonStr}`);
      connectionRef.current = null;
      setIdentity(null);
      setConnected(false);
    };

    moduleBindings.DbConnection.builder()
      .withUri(dbHost)
      .withModuleName(dbName)
      .onConnect(onConnect)
      .onDisconnect(onDisconnect)
      .build();
  }, [subscribeToTables, registerTableCallbacks]);

  const createGuild = useCallback((name: string, description: string, username: string) => {
    if (!connectionRef.current || !identity || !connected) return;
    connectionRef.current.reducers.createGuild(name, description, username);
  }, [connected, identity]);

  const joinGuild = useCallback((guildId: bigint, username: string) => {
    if (!connectionRef.current || !identity || !connected) return;
    connectionRef.current.reducers.joinGuild(guildId, username);
  }, [connected, identity]);

  const leaveGuild = useCallback((guildId: bigint) => {
    if (!connectionRef.current || !identity || !connected) return;
    connectionRef.current.reducers.leaveGuild(guildId);
  }, [connected, identity]);

  const createProposal = useCallback((guildId: bigint, title: string, description: string) => {
    if (!connectionRef.current || !identity || !connected) return;
    connectionRef.current.reducers.createProposal(guildId, title, description);
  }, [connected, identity]);

  const castVote = useCallback((proposalId: bigint, voteYes: boolean) => {
    if (!connectionRef.current || !identity || !connected) return;
    connectionRef.current.reducers.castVote(proposalId, voteYes);
  }, [connected, identity]);

  const updateTreasury = useCallback((guildId: bigint, amount: string, action: string) => {
    if (!connectionRef.current || !identity || !connected) return;
    connectionRef.current.reducers.updateTreasury(guildId, amount, action);
  }, [connected, identity]);

  const createGoal = useCallback((guildId: bigint, title: string, description: string, targetAmount: string) => {
    if (!connectionRef.current || !identity || !connected) return;
    connectionRef.current.reducers.createGoal(guildId, title, description, targetAmount);
  }, [connected, identity]);

  const updateGoalProgress = useCallback((goalId: bigint, newAmount: string) => {
    if (!connectionRef.current || !identity || !connected) return;
    connectionRef.current.reducers.updateGoalProgress(goalId, newAmount);
  }, [connected, identity]);

  const completeGoal = useCallback((goalId: bigint) => {
    if (!connectionRef.current || !identity || !connected) return;
    connectionRef.current.reducers.completeGoal(goalId);
  }, [connected, identity]);

  return {
    connected,
    identity,
    statusMessage,
    guilds,
    members,
    proposals,
    activities,
    goals,
    votes,
    myMembership,
    createGuild,
    joinGuild,
    leaveGuild,
    createProposal,
    castVote,
    updateTreasury,
    createGoal,
    updateGoalProgress,
    completeGoal,
  };
}
