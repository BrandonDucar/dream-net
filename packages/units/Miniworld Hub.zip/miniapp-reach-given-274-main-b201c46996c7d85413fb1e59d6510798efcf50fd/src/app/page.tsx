'use client'
import { useState, useEffect } from 'react';
import type { MiniApp, ObjectType, Relationship, DreamNetData } from '@/types/dreamnet';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Plus, Map, Network, Download, Activity, Lightbulb, Search } from 'lucide-react';
import {
  loadData,
  saveMiniApp,
  deleteMiniApp,
  saveObjectType,
  deleteObjectType,
  saveRelationship,
  deleteRelationship,
  generateId,
} from '@/lib/dreamnet-storage';
import { generateMiniAppSEO, generateObjectTypeSEO } from '@/lib/seo-generator';
import { generateMiniworldMapSummary, exportMiniworldBrief } from '@/lib/miniworld-map-generator';
import { MiniAppList } from '@/components/dreamnet/miniapp-list';
import { MiniAppForm } from '@/components/dreamnet/miniapp-form';
import { ObjectTypeList } from '@/components/dreamnet/objecttype-list';
import { ObjectTypeForm } from '@/components/dreamnet/objecttype-form';
import { RelationshipBrowser } from '@/components/dreamnet/relationship-browser';
import { RelationshipForm } from '@/components/dreamnet/relationship-form';
import { MapSummary } from '@/components/dreamnet/map-summary';
import { GraphVisualizer } from '@/components/dreamnet/graph-visualizer';
import { HealthDashboard } from '@/components/dreamnet/health-dashboard';
import { AIInsights } from '@/components/dreamnet/ai-insights';
import { ImpactAnalyzer } from '@/components/dreamnet/impact-analyzer';
import { exportAsJSON, exportAsMarkdown, exportAsMiroCSV, downloadFile } from '@/lib/export-generator';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type DialogMode = 'none' | 'miniapp' | 'objecttype' | 'relationship' | 'map';

export default function DreamNetRegistry() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [data, setData] = useState<DreamNetData>({
    miniApps: [],
    objectTypes: [],
    relationships: [],
    geoTargets: [],
  });

  const [dialogMode, setDialogMode] = useState<DialogMode>('none');
  const [editingMiniApp, setEditingMiniApp] = useState<MiniApp | undefined>(undefined);
  const [editingObjectType, setEditingObjectType] = useState<ObjectType | undefined>(undefined);
  const [editingRelationship, setEditingRelationship] = useState<Relationship | undefined>(undefined);
  const [prefillFromType, setPrefillFromType] = useState<string>('');

  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const [filterRelationKind, setFilterRelationKind] = useState<string>('all');

  const [mapSummary, setMapSummary] = useState<string>('');
  const [briefSummary, setBriefSummary] = useState<string>('');

  useEffect(() => {
    const loaded = loadData();
    setData(loaded);
  }, []);

  const refreshData = () => {
    const loaded = loadData();
    setData(loaded);
  };

  const handleSaveMiniApp = (miniApp: MiniApp) => {
    const appToSave: MiniApp = {
      ...miniApp,
      id: miniApp.id || generateId(),
    };

    if (!appToSave.seoTitle) {
      const seoData = generateMiniAppSEO(appToSave);
      Object.assign(appToSave, seoData);
    }

    saveMiniApp(appToSave);
    refreshData();
    setDialogMode('none');
    setEditingMiniApp(undefined);
  };

  const handleDeleteMiniApp = (id: string) => {
    deleteMiniApp(id);
    refreshData();
  };

  const handleEditMiniApp = (miniApp: MiniApp) => {
    setEditingMiniApp(miniApp);
    setDialogMode('miniapp');
  };

  const handleSaveObjectType = (objectType: ObjectType) => {
    const objToSave: ObjectType = {
      ...objectType,
      id: objectType.id || generateId(),
    };

    if (!objToSave.seoTitle) {
      const seoData = generateObjectTypeSEO(objToSave);
      Object.assign(objToSave, seoData);
    }

    saveObjectType(objToSave);
    refreshData();
    setDialogMode('none');
    setEditingObjectType(undefined);
  };

  const handleDeleteObjectType = (id: string) => {
    deleteObjectType(id);
    refreshData();
  };

  const handleEditObjectType = (objectType: ObjectType) => {
    setEditingObjectType(objectType);
    setDialogMode('objecttype');
  };

  const handleSaveRelationship = (relationship: Relationship) => {
    const relToSave: Relationship = {
      ...relationship,
      id: relationship.id || generateId(),
    };

    saveRelationship(relToSave);
    refreshData();
    setDialogMode('none');
    setEditingRelationship(undefined);
    setPrefillFromType('');
  };

  const handleDeleteRelationship = (id: string) => {
    deleteRelationship(id);
    refreshData();
  };

  const handleGenerateMap = () => {
    const map = generateMiniworldMapSummary(data);
    const brief = exportMiniworldBrief(data);
    setMapSummary(map);
    setBriefSummary(brief);
    setDialogMode('map');
  };

  const closeDialog = () => {
    setDialogMode('none');
    setEditingMiniApp(undefined);
    setEditingObjectType(undefined);
    setEditingRelationship(undefined);
    setPrefillFromType('');
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-8 px-4 max-w-7xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">DreamNet Miniworld Registry</h1>
          <p className="text-muted-foreground">
            Your ecosystem map for tracking mini-apps, objects, and relationships
          </p>
        </div>

        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-6 mb-6">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="graph">Graph</TabsTrigger>
            <TabsTrigger value="health">Health</TabsTrigger>
            <TabsTrigger value="insights">Insights</TabsTrigger>
            <TabsTrigger value="impact">Impact</TabsTrigger>
            <TabsTrigger value="relationships">Relationships</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            <div className="flex gap-4 mb-6 flex-wrap">
              <Button onClick={handleGenerateMap} size="lg">
                <Map className="w-4 h-4 mr-2" />
                Generate Miniworld Map
              </Button>
              <Button 
                onClick={() => {
                  const json = exportAsJSON(data, { includeMetadata: true, includeSEO: true, includeGeo: true });
                  downloadFile(json, 'dreamnet-registry.json', 'application/json');
                }} 
                variant="outline"
              >
                <Download className="w-4 h-4 mr-2" />
                Export JSON
              </Button>
              <Button 
                onClick={() => {
                  const markdown = exportAsMarkdown(data, { includeSEO: true });
                  downloadFile(markdown, 'dreamnet-registry.md', 'text/markdown');
                }} 
                variant="outline"
              >
                <Download className="w-4 h-4 mr-2" />
                Export Markdown
              </Button>
              <Button 
                onClick={() => {
                  const csv = exportAsMiroCSV(data);
                  downloadFile(csv, 'dreamnet-miro-board.csv', 'text/csv');
                }} 
                variant="outline"
              >
                <Download className="w-4 h-4 mr-2" />
                Export to Miro
              </Button>
            </div>

            <Tabs defaultValue="miniapps" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="miniapps">Mini-Apps ({data.miniApps.length})</TabsTrigger>
                <TabsTrigger value="objecttypes">Object Types ({data.objectTypes.length})</TabsTrigger>
              </TabsList>

              <TabsContent value="miniapps" className="space-y-4 mt-4">
                <div className="flex justify-end">
                  <Button
                    onClick={() => {
                      setEditingMiniApp(undefined);
                      setDialogMode('miniapp');
                    }}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    New Mini-App
                  </Button>
                </div>

                <MiniAppList
                  miniApps={data.miniApps}
                  onEdit={handleEditMiniApp}
                  onDelete={handleDeleteMiniApp}
                  filterCategory={filterCategory}
                  filterStatus={filterStatus}
                  filterPriority={filterPriority}
                  onFilterCategoryChange={setFilterCategory}
                  onFilterStatusChange={setFilterStatus}
                  onFilterPriorityChange={setFilterPriority}
                />
              </TabsContent>

              <TabsContent value="objecttypes" className="space-y-4 mt-4">
                <div className="flex justify-end">
                  <Button
                    onClick={() => {
                      setEditingObjectType(undefined);
                      setDialogMode('objecttype');
                    }}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    New Object Type
                  </Button>
                </div>

                <ObjectTypeList
                  objectTypes={data.objectTypes}
                  miniApps={data.miniApps}
                  onEdit={handleEditObjectType}
                  onDelete={handleDeleteObjectType}
                />
              </TabsContent>
            </Tabs>
          </TabsContent>

          <TabsContent value="graph" className="space-y-6">
            <GraphVisualizer
              miniApps={data.miniApps}
              objectTypes={data.objectTypes}
              relationships={data.relationships}
            />
          </TabsContent>

          <TabsContent value="health" className="space-y-6">
            <HealthDashboard
              miniApps={data.miniApps}
              objectTypes={data.objectTypes}
              relationships={data.relationships}
            />
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            <AIInsights
              miniApps={data.miniApps}
              objectTypes={data.objectTypes}
              relationships={data.relationships}
            />
          </TabsContent>

          <TabsContent value="impact" className="space-y-6">
            <ImpactAnalyzer
              miniApps={data.miniApps}
              objectTypes={data.objectTypes}
              relationships={data.relationships}
            />
          </TabsContent>

          <TabsContent value="relationships" className="space-y-6">
            <div className="flex justify-end">
              <Button
                onClick={() => {
                  setEditingRelationship(undefined);
                  setPrefillFromType('');
                  setDialogMode('relationship');
                }}
              >
                <Network className="w-4 h-4 mr-2" />
                Define Relationship
              </Button>
            </div>

            <RelationshipBrowser
              relationships={data.relationships}
              onDelete={handleDeleteRelationship}
              filterKind={filterRelationKind}
              onFilterKindChange={setFilterRelationKind}
            />
          </TabsContent>
        </Tabs>

        <Dialog open={dialogMode === 'miniapp'} onOpenChange={(open: boolean) => !open && closeDialog()}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingMiniApp ? 'Edit Mini-App' : 'Create Mini-App'}</DialogTitle>
            </DialogHeader>
            <MiniAppForm
              miniApp={editingMiniApp}
              allMiniApps={data.miniApps}
              geoTargets={data.geoTargets}
              onSave={handleSaveMiniApp}
              onCancel={closeDialog}
            />
          </DialogContent>
        </Dialog>

        <Dialog open={dialogMode === 'objecttype'} onOpenChange={(open: boolean) => !open && closeDialog()}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingObjectType ? 'Edit Object Type' : 'Create Object Type'}</DialogTitle>
            </DialogHeader>
            <ObjectTypeForm
              objectType={editingObjectType}
              allMiniApps={data.miniApps}
              onSave={handleSaveObjectType}
              onCancel={closeDialog}
            />
          </DialogContent>
        </Dialog>

        <Dialog open={dialogMode === 'relationship'} onOpenChange={(open: boolean) => !open && closeDialog()}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Define Relationship</DialogTitle>
            </DialogHeader>
            <RelationshipForm
              relationship={editingRelationship}
              miniApps={data.miniApps}
              objectTypes={data.objectTypes}
              onSave={handleSaveRelationship}
              onCancel={closeDialog}
              prefillFromType={prefillFromType}
            />
          </DialogContent>
        </Dialog>

        <Dialog open={dialogMode === 'map'} onOpenChange={(open: boolean) => !open && closeDialog()}>
          <DialogContent className="max-w-5xl max-h-[90vh]">
            <DialogHeader>
              <DialogTitle>Miniworld Map & Brief</DialogTitle>
            </DialogHeader>
            <MapSummary mapSummary={mapSummary} briefSummary={briefSummary} />
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
