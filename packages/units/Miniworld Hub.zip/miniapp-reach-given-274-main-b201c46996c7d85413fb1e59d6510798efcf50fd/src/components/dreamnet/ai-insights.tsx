'use client';

import React, { useMemo } from 'react';
import type { MiniApp, ObjectType, Relationship } from '@/types/dreamnet';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Lightbulb, Zap, Target, Network, Brain } from 'lucide-react';

interface AIInsightsProps {
  miniApps: MiniApp[];
  objectTypes: ObjectType[];
  relationships: Relationship[];
  onSuggestionClick?: (suggestion: Insight) => void;
}

interface Insight {
  id: string;
  type: 'connection' | 'gap' | 'optimization' | 'expansion' | 'consolidation';
  priority: 'high' | 'medium' | 'low';
  title: string;
  description: string;
  actionable: string;
  entities: string[];
}

export function AIInsights({ miniApps, objectTypes, relationships, onSuggestionClick }: AIInsightsProps) {
  const insights = useMemo(() => {
    const allInsights: Insight[] = [];

    // Analyze missing connections
    const connectionInsights = analyzeMissingConnections(miniApps, objectTypes, relationships);
    allInsights.push(...connectionInsights);

    // Identify ecosystem gaps
    const gapInsights = identifyGaps(miniApps, objectTypes);
    allInsights.push(...gapInsights);

    // Suggest optimizations
    const optimizationInsights = suggestOptimizations(miniApps, relationships);
    allInsights.push(...optimizationInsights);

    // Recommend expansions
    const expansionInsights = recommendExpansions(miniApps, objectTypes);
    allInsights.push(...expansionInsights);

    // Identify consolidation opportunities
    const consolidationInsights = identifyConsolidations(miniApps, objectTypes);
    allInsights.push(...consolidationInsights);

    // Sort by priority
    return allInsights.sort((a: Insight, b: Insight) => {
      const priorityOrder: Record<string, number> = { high: 0, medium: 1, low: 2 };
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    });
  }, [miniApps, objectTypes, relationships]);

  const getInsightIcon = (type: string) => {
    const icons: Record<string, JSX.Element> = {
      connection: <Network className="h-5 w-5" />,
      gap: <Target className="h-5 w-5" />,
      optimization: <Zap className="h-5 w-5" />,
      expansion: <Lightbulb className="h-5 w-5" />,
      consolidation: <Brain className="h-5 w-5" />,
    };
    return icons[type] || <Lightbulb className="h-5 w-5" />;
  };

  const getInsightColor = (type: string): string => {
    const colors: Record<string, string> = {
      connection: 'border-blue-300 bg-blue-50',
      gap: 'border-yellow-300 bg-yellow-50',
      optimization: 'border-green-300 bg-green-50',
      expansion: 'border-purple-300 bg-purple-50',
      consolidation: 'border-orange-300 bg-orange-50',
    };
    return colors[type] || 'border-gray-300 bg-gray-50';
  };

  const getPriorityBadge = (priority: string) => {
    const variants: Record<string, 'destructive' | 'default' | 'secondary'> = {
      high: 'destructive',
      medium: 'default',
      low: 'secondary',
    };
    return <Badge variant={variants[priority]}>{priority.toUpperCase()}</Badge>;
  };

  if (insights.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            AI Insights
          </CardTitle>
          <CardDescription>Smart recommendations for your ecosystem</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            <Brain className="h-12 w-12 mx-auto mb-4 text-gray-300" />
            <p>Your ecosystem is well-organized! Add more mini-apps and object types for AI insights.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5" />
          AI Insights
        </CardTitle>
        <CardDescription>
          {insights.length} smart recommendation{insights.length !== 1 ? 's' : ''} for your ecosystem
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {insights.map((insight: Insight) => (
            <Card key={insight.id} className={`${getInsightColor(insight.type)} border-2`}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    {getInsightIcon(insight.type)}
                    <div>
                      <CardTitle className="text-base">{insight.title}</CardTitle>
                      <div className="flex gap-2 mt-1">
                        {getPriorityBadge(insight.priority)}
                        <Badge variant="outline">{insight.type}</Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-gray-700">{insight.description}</p>
                <div className="bg-white rounded p-3 border">
                  <div className="text-xs font-semibold text-gray-500 mb-1">RECOMMENDED ACTION</div>
                  <div className="text-sm font-medium">{insight.actionable}</div>
                </div>
                {insight.entities.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {insight.entities.map((entity: string, idx: number) => (
                      <Badge key={idx} variant="secondary">{entity}</Badge>
                    ))}
                  </div>
                )}
                {onSuggestionClick && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onSuggestionClick(insight)}
                    className="w-full"
                  >
                    Implement Suggestion
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// Analysis functions
function analyzeMissingConnections(
  miniApps: MiniApp[],
  objectTypes: ObjectType[],
  relationships: Relationship[]
): Insight[] {
  const insights: Insight[] = [];

  miniApps.forEach((app: MiniApp) => {
    // Check if app outputs are used by other apps
    app.outputTypes.forEach((outputType: string) => {
      const consumers = miniApps.filter((otherApp: MiniApp) =>
        otherApp.id !== app.id && otherApp.inputTypes.includes(outputType)
      );

      consumers.forEach((consumer: MiniApp) => {
        const hasRelationship = relationships.some(
          (rel: Relationship) =>
            (rel.fromType === app.name || rel.fromType === app.id) &&
            (rel.toType === consumer.name || rel.toType === consumer.id)
        );

        if (!hasRelationship) {
          insights.push({
            id: `connection-${app.id}-${consumer.id}`,
            type: 'connection',
            priority: 'high',
            title: `Missing Connection: ${app.name} → ${consumer.name}`,
            description: `${app.name} outputs ${outputType}, which ${consumer.name} consumes. Consider defining their relationship.`,
            actionable: `Create a relationship from ${app.name} to ${consumer.name} with relation type "feeds" or "provides".`,
            entities: [app.name, consumer.name, outputType],
          });
        }
      });
    });
  });

  return insights.slice(0, 3); // Limit to top 3
}

function identifyGaps(miniApps: MiniApp[], objectTypes: ObjectType[]): Insight[] {
  const insights: Insight[] = [];

  // Find categories with only one app
  const categoryCount: Record<string, MiniApp[]> = {};
  miniApps.forEach((app: MiniApp) => {
    if (!categoryCount[app.category]) {
      categoryCount[app.category] = [];
    }
    categoryCount[app.category].push(app);
  });

  Object.entries(categoryCount).forEach(([category, apps]) => {
    if (apps.length === 1 && apps[0].status === 'active') {
      insights.push({
        id: `gap-category-${category}`,
        type: 'gap',
        priority: 'medium',
        title: `Single Point of Dependency: ${category}`,
        description: `Only ${apps[0].name} exists in the ${category} category. Consider adding a backup or complementary app.`,
        actionable: `Create another ${category} mini-app to reduce ecosystem fragility and add redundancy.`,
        entities: [category, apps[0].name],
      });
    }
  });

  // Find object types with no primary apps
  objectTypes.forEach((obj: ObjectType) => {
    if (obj.primaryMiniApps.length === 0) {
      insights.push({
        id: `gap-object-${obj.id}`,
        type: 'gap',
        priority: 'low',
        title: `Orphaned Object Type: ${obj.name}`,
        description: `${obj.name} has no primary mini-apps assigned. This object type may not be actively managed.`,
        actionable: `Assign a primary mini-app to ${obj.name} or consider if this object type is still needed.`,
        entities: [obj.name],
      });
    }
  });

  return insights.slice(0, 2);
}

function suggestOptimizations(miniApps: MiniApp[], relationships: Relationship[]): Insight[] {
  const insights: Insight[] = [];

  // Find apps with many inputs but few relationships
  miniApps.forEach((app: MiniApp) => {
    if (app.inputTypes.length >= 3) {
      const incomingRels = relationships.filter(
        (rel: Relationship) => rel.toType === app.name || rel.toType === app.id
      );

      if (incomingRels.length === 0) {
        insights.push({
          id: `optimize-inputs-${app.id}`,
          type: 'optimization',
          priority: 'medium',
          title: `Clarify Data Sources for ${app.name}`,
          description: `${app.name} expects ${app.inputTypes.length} input types but has no defined source relationships.`,
          actionable: `Define relationships showing where ${app.name} gets its inputs from.`,
          entities: [app.name, ...app.inputTypes],
        });
      }
    }
  });

  // Find paused high-priority apps
  miniApps.forEach((app: MiniApp) => {
    if (app.status === 'paused' && app.priorityLevel === 'high') {
      insights.push({
        id: `optimize-paused-${app.id}`,
        type: 'optimization',
        priority: 'high',
        title: `Reactivate High-Priority App: ${app.name}`,
        description: `${app.name} is marked as high priority but currently paused. Consider reactivating or lowering priority.`,
        actionable: `Change ${app.name} status to "active" or adjust its priority level to match current focus.`,
        entities: [app.name],
      });
    }
  });

  return insights.slice(0, 2);
}

function recommendExpansions(miniApps: MiniApp[], objectTypes: ObjectType[]): Insight[] {
  const insights: Insight[] = [];

  // Suggest analytics apps if none exist
  const hasAnalytics = miniApps.some((app: MiniApp) => app.category === 'analytics');
  if (!hasAnalytics && miniApps.length > 3) {
    insights.push({
      id: 'expand-analytics',
      type: 'expansion',
      priority: 'medium',
      title: 'Add Analytics Capability',
      description: 'Your ecosystem lacks an analytics mini-app to track performance and usage across your tools.',
      actionable: 'Create an analytics mini-app that tracks metrics from your active apps and provides insights.',
      entities: ['analytics'],
    });
  }

  // Suggest distribution apps if many content objects exist
  const contentTypes = objectTypes.filter((obj: ObjectType) =>
    ['ScriptVariant', 'Drop', 'Campaign', 'Meme'].some((keyword: string) =>
      obj.name.toLowerCase().includes(keyword.toLowerCase())
    )
  );
  const hasDistribution = miniApps.some((app: MiniApp) => app.category === 'distribution');
  if (contentTypes.length >= 2 && !hasDistribution) {
    insights.push({
      id: 'expand-distribution',
      type: 'expansion',
      priority: 'high',
      title: 'Add Distribution Layer',
      description: `You have ${contentTypes.length} content types but no distribution mini-app to manage publishing.`,
      actionable: 'Create a distribution mini-app to coordinate publishing across channels and platforms.',
      entities: ['distribution', ...contentTypes.map((t: ObjectType) => t.name)],
    });
  }

  return insights.slice(0, 2);
}

function identifyConsolidations(miniApps: MiniApp[], objectTypes: ObjectType[]): Insight[] {
  const insights: Insight[] = [];

  // Find similar object types
  const objectNames = objectTypes.map((obj: ObjectType) => obj.name.toLowerCase());
  objectTypes.forEach((obj: ObjectType, i: number) => {
    objectTypes.slice(i + 1).forEach((otherObj: ObjectType) => {
      const similarity = calculateSimilarity(obj.name, otherObj.name);
      if (similarity > 0.6) {
        insights.push({
          id: `consolidate-${obj.id}-${otherObj.id}`,
          type: 'consolidation',
          priority: 'low',
          title: `Similar Object Types: ${obj.name} & ${otherObj.name}`,
          description: 'These object types appear similar and might represent the same concept.',
          actionable: `Review ${obj.name} and ${otherObj.name} to determine if they should be merged or more clearly differentiated.`,
          entities: [obj.name, otherObj.name],
        });
      }
    });
  });

  // Find retired apps that still have relationships
  miniApps.forEach((app: MiniApp) => {
    if (app.status === 'retired' && app.relatedApps.length > 0) {
      insights.push({
        id: `consolidate-retired-${app.id}`,
        type: 'consolidation',
        priority: 'low',
        title: `Clean Up Retired App: ${app.name}`,
        description: `${app.name} is retired but still has ${app.relatedApps.length} related apps defined.`,
        actionable: `Remove relationships for ${app.name} or reassign its responsibilities to active apps.`,
        entities: [app.name],
      });
    }
  });

  return insights.slice(0, 2);
}

function calculateSimilarity(str1: string, str2: string): number {
  const longer = str1.length > str2.length ? str1 : str2;
  const shorter = str1.length > str2.length ? str2 : str1;
  
  if (longer.length === 0) return 1.0;
  
  const editDistance = levenshteinDistance(longer.toLowerCase(), shorter.toLowerCase());
  return (longer.length - editDistance) / longer.length;
}

function levenshteinDistance(str1: string, str2: string): number {
  const matrix: number[][] = [];

  for (let i = 0; i <= str2.length; i++) {
    matrix[i] = [i];
  }

  for (let j = 0; j <= str1.length; j++) {
    matrix[0][j] = j;
  }

  for (let i = 1; i <= str2.length; i++) {
    for (let j = 1; j <= str1.length; j++) {
      if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }

  return matrix[str2.length][str1.length];
}
