'use client';

import React, { useEffect, useRef, useState } from 'react';
import type { MiniApp, ObjectType, Relationship } from '@/types/dreamnet';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ZoomIn, ZoomOut, Maximize2, RefreshCw } from 'lucide-react';

interface GraphNode {
  id: string;
  name: string;
  type: 'miniapp' | 'object';
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  data: MiniApp | ObjectType;
}

interface GraphEdge {
  from: string;
  to: string;
  label: string;
  color: string;
}

interface GraphVisualizerProps {
  miniApps: MiniApp[];
  objectTypes: ObjectType[];
  relationships: Relationship[];
  onNodeClick?: (node: GraphNode) => void;
}

export function GraphVisualizer({ miniApps, objectTypes, relationships, onNodeClick }: GraphVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [nodes, setNodes] = useState<GraphNode[]>([]);
  const [edges, setEdges] = useState<GraphEdge[]>([]);
  const [zoom, setZoom] = useState<number>(1);
  const [offset, setOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const animationRef = useRef<number>();

  // Initialize graph
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const width = canvas.width;
    const height = canvas.height;

    // Create nodes
    const newNodes: GraphNode[] = [];

    // Add mini-app nodes
    miniApps.forEach((app: MiniApp) => {
      newNodes.push({
        id: app.id,
        name: app.name,
        type: 'miniapp',
        x: Math.random() * width,
        y: Math.random() * height,
        vx: 0,
        vy: 0,
        radius: 30,
        color: getStatusColor(app.status),
        data: app,
      });
    });

    // Add object type nodes
    objectTypes.forEach((obj: ObjectType) => {
      newNodes.push({
        id: obj.id,
        name: obj.name,
        type: 'object',
        x: Math.random() * width,
        y: Math.random() * height,
        vx: 0,
        vy: 0,
        radius: 20,
        color: '#8b5cf6',
        data: obj,
      });
    });

    // Create edges from relationships
    const newEdges: GraphEdge[] = relationships.map((rel: Relationship) => ({
      from: rel.fromType,
      to: rel.toType,
      label: rel.relationKind,
      color: getRelationColor(rel.relationKind),
    }));

    setNodes(newNodes);
    setEdges(newEdges);
  }, [miniApps, objectTypes, relationships]);

  // Physics simulation
  useEffect(() => {
    if (nodes.length === 0) return;

    const simulate = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;

      const width = canvas.width;
      const height = canvas.height;

      setNodes((prevNodes: GraphNode[]) => {
        const newNodes = [...prevNodes];

        // Apply forces
        newNodes.forEach((node: GraphNode, i: number) => {
          let fx = 0;
          let fy = 0;

          // Center attraction
          const centerX = width / 2;
          const centerY = height / 2;
          fx += (centerX - node.x) * 0.001;
          fy += (centerY - node.y) * 0.001;

          // Repulsion between nodes
          newNodes.forEach((other: GraphNode, j: number) => {
            if (i !== j) {
              const dx = node.x - other.x;
              const dy = node.y - other.y;
              const dist = Math.sqrt(dx * dx + dy * dy);
              if (dist < 200 && dist > 0) {
                const force = 100 / (dist * dist);
                fx += (dx / dist) * force;
                fy += (dy / dist) * force;
              }
            }
          });

          // Edge attraction
          edges.forEach((edge: GraphEdge) => {
            let otherNode: GraphNode | null = null;
            if (edge.from === node.id || edge.from === node.name) {
              otherNode = newNodes.find((n: GraphNode) => n.id === edge.to || n.name === edge.to) || null;
            } else if (edge.to === node.id || edge.to === node.name) {
              otherNode = newNodes.find((n: GraphNode) => n.id === edge.from || n.name === edge.from) || null;
            }

            if (otherNode) {
              const dx = otherNode.x - node.x;
              const dy = otherNode.y - node.y;
              const dist = Math.sqrt(dx * dx + dy * dy);
              if (dist > 0) {
                const force = dist * 0.01;
                fx += (dx / dist) * force;
                fy += (dy / dist) * force;
              }
            }
          });

          // Update velocity
          node.vx = (node.vx + fx) * 0.8;
          node.vy = (node.vy + fy) * 0.8;

          // Update position
          node.x += node.vx;
          node.y += node.vy;

          // Boundary constraints
          node.x = Math.max(node.radius, Math.min(width - node.radius, node.x));
          node.y = Math.max(node.radius, Math.min(height - node.radius, node.y));
        });

        return newNodes;
      });

      animationRef.current = requestAnimationFrame(simulate);
    };

    simulate();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [nodes.length, edges]);

  // Render
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Apply transformations
    ctx.save();
    ctx.translate(offset.x, offset.y);
    ctx.scale(zoom, zoom);

    // Draw edges
    edges.forEach((edge: GraphEdge) => {
      const fromNode = nodes.find((n: GraphNode) => n.id === edge.from || n.name === edge.from);
      const toNode = nodes.find((n: GraphNode) => n.id === edge.to || n.name === edge.to);

      if (fromNode && toNode) {
        ctx.beginPath();
        ctx.moveTo(fromNode.x, fromNode.y);
        ctx.lineTo(toNode.x, toNode.y);
        ctx.strokeStyle = edge.color;
        ctx.lineWidth = 2;
        ctx.stroke();

        // Draw arrow
        const angle = Math.atan2(toNode.y - fromNode.y, toNode.x - fromNode.x);
        const arrowX = toNode.x - Math.cos(angle) * (toNode.radius + 5);
        const arrowY = toNode.y - Math.sin(angle) * (toNode.radius + 5);
        ctx.beginPath();
        ctx.moveTo(arrowX, arrowY);
        ctx.lineTo(
          arrowX - 10 * Math.cos(angle - Math.PI / 6),
          arrowY - 10 * Math.sin(angle - Math.PI / 6)
        );
        ctx.lineTo(
          arrowX - 10 * Math.cos(angle + Math.PI / 6),
          arrowY - 10 * Math.sin(angle + Math.PI / 6)
        );
        ctx.fillStyle = edge.color;
        ctx.fill();
      }
    });

    // Draw nodes
    nodes.forEach((node: GraphNode) => {
      // Node circle
      ctx.beginPath();
      ctx.arc(node.x, node.y, node.radius, 0, 2 * Math.PI);
      ctx.fillStyle = node.color;
      ctx.fill();
      ctx.strokeStyle = selectedNode?.id === node.id ? '#fff' : '#000';
      ctx.lineWidth = selectedNode?.id === node.id ? 4 : 2;
      ctx.stroke();

      // Node label
      ctx.fillStyle = '#000';
      ctx.font = 'bold 12px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(node.name, node.x, node.y);

      // Node type badge
      ctx.font = '10px sans-serif';
      ctx.fillText(node.type === 'miniapp' ? 'APP' : 'OBJ', node.x, node.y + node.radius + 12);
    });

    ctx.restore();
  }, [nodes, edges, zoom, offset, selectedNode]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left - offset.x) / zoom;
    const y = (e.clientY - rect.top - offset.y) / zoom;

    // Find clicked node
    const clickedNode = nodes.find((node: GraphNode) => {
      const dx = x - node.x;
      const dy = y - node.y;
      return Math.sqrt(dx * dx + dy * dy) <= node.radius;
    });

    if (clickedNode) {
      setSelectedNode(clickedNode);
      if (onNodeClick) {
        onNodeClick(clickedNode);
      }
    } else {
      setSelectedNode(null);
    }
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - offset.x, y: e.clientY - offset.y });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDragging) {
      setOffset({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const resetView = () => {
    setZoom(1);
    setOffset({ x: 0, y: 0 });
    setSelectedNode(null);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Ecosystem Graph</CardTitle>
            <CardDescription>Interactive visualization of your miniworld</CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setZoom((z: number) => Math.min(z + 0.2, 3))}>
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={() => setZoom((z: number) => Math.max(z - 0.2, 0.5))}>
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={resetView}>
              <Maximize2 className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setNodes([]);
                setTimeout(() => {
                  const canvas = canvasRef.current;
                  if (!canvas) return;
                  const width = canvas.width;
                  const height = canvas.height;
                  const newNodes: GraphNode[] = [];
                  miniApps.forEach((app: MiniApp) => {
                    newNodes.push({
                      id: app.id,
                      name: app.name,
                      type: 'miniapp',
                      x: Math.random() * width,
                      y: Math.random() * height,
                      vx: 0,
                      vy: 0,
                      radius: 30,
                      color: getStatusColor(app.status),
                      data: app,
                    });
                  });
                  objectTypes.forEach((obj: ObjectType) => {
                    newNodes.push({
                      id: obj.id,
                      name: obj.name,
                      type: 'object',
                      x: Math.random() * width,
                      y: Math.random() * height,
                      vx: 0,
                      vy: 0,
                      radius: 20,
                      color: '#8b5cf6',
                      data: obj,
                    });
                  });
                  setNodes(newNodes);
                }, 100);
              }}
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <canvas
            ref={canvasRef}
            width={1000}
            height={600}
            className="w-full border rounded-lg bg-gray-50 cursor-move"
            onClick={handleCanvasClick}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
          />

          {selectedNode && (
            <Card className="bg-blue-50">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  {selectedNode.name}
                  <Badge>{selectedNode.type === 'miniapp' ? 'Mini-App' : 'Object Type'}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-700">
                  {selectedNode.type === 'miniapp'
                    ? (selectedNode.data as MiniApp).description
                    : (selectedNode.data as ObjectType).description}
                </p>
                {selectedNode.type === 'miniapp' && (
                  <div className="mt-4 space-y-2">
                    <div className="flex gap-2">
                      <Badge variant="outline">{(selectedNode.data as MiniApp).category}</Badge>
                      <Badge>{(selectedNode.data as MiniApp).status}</Badge>
                      <Badge variant="secondary">{(selectedNode.data as MiniApp).priorityLevel}</Badge>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          <div className="flex gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-green-500"></div>
              <span>Active Apps</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-blue-500"></div>
              <span>Idea Apps</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-purple-500"></div>
              <span>Object Types</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    active: '#22c55e',
    idea: '#3b82f6',
    paused: '#f59e0b',
    retired: '#6b7280',
  };
  return colors[status] || '#6b7280';
}

function getRelationColor(relationKind: string): string {
  const colors: Record<string, string> = {
    creates: '#10b981',
    uses: '#3b82f6',
    tracks: '#8b5cf6',
    feeds: '#f59e0b',
    visualizes: '#ec4899',
    posts: '#06b6d4',
  };
  return colors[relationKind] || '#6b7280';
}
