'use client';

import React, { useMemo } from 'react';
import type { MiniApp, ObjectType, Relationship } from '@/types/dreamnet';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { AlertCircle, CheckCircle2, Clock, TrendingUp, AlertTriangle } from 'lucide-react';

interface HealthDashboardProps {
  miniApps: MiniApp[];
  objectTypes: ObjectType[];
  relationships: Relationship[];
}

export function HealthDashboard({ miniApps, objectTypes, relationships }: HealthDashboardProps) {
  const health = useMemo(() => {
    const activeApps = miniApps.filter((app: MiniApp) => app.status === 'active').length;
    const totalApps = miniApps.length;
    const criticalApps = miniApps.filter((app: MiniApp) => app.priorityLevel === 'critical').length;
    const ideaApps = miniApps.filter((app: MiniApp) => app.status === 'idea').length;
    const pausedApps = miniApps.filter((app: MiniApp) => app.status === 'paused').length;
    
    // Calculate connectivity score (apps with relationships / total apps)
    const appsWithRelationships = new Set<string>();
    relationships.forEach((rel: Relationship) => {
      const fromApp = miniApps.find((app: MiniApp) => app.name === rel.fromType || app.id === rel.fromType);
      const toApp = miniApps.find((app: MiniApp) => app.name === rel.toType || app.id === rel.toType);
      if (fromApp) appsWithRelationships.add(fromApp.id);
      if (toApp) appsWithRelationships.add(toApp.id);
    });
    const connectivityScore = totalApps > 0 ? (appsWithRelationships.size / totalApps) * 100 : 0;

    // Calculate documentation score (apps with SEO / total apps)
    const appsWithSEO = miniApps.filter((app: MiniApp) => app.seoTitle && app.seoDescription).length;
    const documentationScore = totalApps > 0 ? (appsWithSEO / totalApps) * 100 : 0;

    // Find orphaned apps (no relationships)
    const orphanedApps = miniApps.filter((app: MiniApp) => {
      return !relationships.some((rel: Relationship) => 
        rel.fromType === app.name || rel.fromType === app.id ||
        rel.toType === app.name || rel.toType === app.id
      );
    });

    // Find unused object types
    const usedObjectTypes = new Set<string>();
    miniApps.forEach((app: MiniApp) => {
      app.inputTypes.forEach((type: string) => usedObjectTypes.add(type));
      app.outputTypes.forEach((type: string) => usedObjectTypes.add(type));
    });
    const unusedObjectTypes = objectTypes.filter((obj: ObjectType) => !usedObjectTypes.has(obj.name));

    // Calculate overall health score
    const healthScore = Math.round(
      (activeApps / totalApps) * 40 +
      (connectivityScore / 100) * 30 +
      (documentationScore / 100) * 20 +
      (1 - (orphanedApps.length / totalApps)) * 10
    );

    return {
      healthScore,
      activeApps,
      totalApps,
      criticalApps,
      ideaApps,
      pausedApps,
      connectivityScore,
      documentationScore,
      orphanedApps,
      unusedObjectTypes,
      totalRelationships: relationships.length,
      totalObjectTypes: objectTypes.length,
    };
  }, [miniApps, objectTypes, relationships]);

  const getHealthColor = (score: number): string => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getHealthIcon = (score: number) => {
    if (score >= 80) return <CheckCircle2 className="h-8 w-8 text-green-600" />;
    if (score >= 60) return <Clock className="h-8 w-8 text-yellow-600" />;
    return <AlertCircle className="h-8 w-8 text-red-600" />;
  };

  const getHealthLabel = (score: number): string => {
    if (score >= 80) return 'Healthy';
    if (score >= 60) return 'Fair';
    return 'Needs Attention';
  };

  return (
    <div className="space-y-6">
      {/* Overall Health Score */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            {getHealthIcon(health.healthScore)}
            <div>
              <div className="text-3xl font-bold">{health.healthScore}/100</div>
              <div className="text-sm text-gray-500">{getHealthLabel(health.healthScore)}</div>
            </div>
          </CardTitle>
          <CardDescription>Overall ecosystem health score</CardDescription>
        </CardHeader>
        <CardContent>
          <Progress value={health.healthScore} className="h-3" />
        </CardContent>
      </Card>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Mini-Apps Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm">Active</span>
                <Badge variant="default" className="bg-green-500">{health.activeApps}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Critical Priority</span>
                <Badge variant="destructive">{health.criticalApps}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Ideas</span>
                <Badge variant="secondary">{health.ideaApps}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Paused</span>
                <Badge variant="outline">{health.pausedApps}</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Connectivity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm">Relationship Density</span>
                  <span className={`text-sm font-bold ${getHealthColor(health.connectivityScore)}`}>
                    {Math.round(health.connectivityScore)}%
                  </span>
                </div>
                <Progress value={health.connectivityScore} className="h-2" />
              </div>
              <div className="pt-2 border-t">
                <div className="text-2xl font-bold">{health.totalRelationships}</div>
                <div className="text-sm text-gray-500">Total relationships</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Documentation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm">SEO Coverage</span>
                  <span className={`text-sm font-bold ${getHealthColor(health.documentationScore)}`}>
                    {Math.round(health.documentationScore)}%
                  </span>
                </div>
                <Progress value={health.documentationScore} className="h-2" />
              </div>
              <div className="pt-2 border-t">
                <div className="text-2xl font-bold">{health.totalObjectTypes}</div>
                <div className="text-sm text-gray-500">Object types defined</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Warnings & Recommendations */}
      {(health.orphanedApps.length > 0 || health.unusedObjectTypes.length > 0) && (
        <Card className="border-yellow-300 bg-yellow-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-yellow-800">
              <AlertTriangle className="h-5 w-5" />
              Recommendations
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {health.orphanedApps.length > 0 && (
              <div>
                <div className="font-semibold text-sm text-yellow-800 mb-2">
                  {health.orphanedApps.length} orphaned mini-app{health.orphanedApps.length !== 1 ? 's' : ''}
                </div>
                <div className="space-y-1">
                  {health.orphanedApps.map((app: MiniApp) => (
                    <div key={app.id} className="text-sm text-yellow-700">
                      • <strong>{app.name}</strong> has no relationships. Consider defining how it connects to your ecosystem.
                    </div>
                  ))}
                </div>
              </div>
            )}

            {health.unusedObjectTypes.length > 0 && (
              <div>
                <div className="font-semibold text-sm text-yellow-800 mb-2">
                  {health.unusedObjectTypes.length} unused object type{health.unusedObjectTypes.length !== 1 ? 's' : ''}
                </div>
                <div className="space-y-1">
                  {health.unusedObjectTypes.slice(0, 3).map((obj: ObjectType) => (
                    <div key={obj.id} className="text-sm text-yellow-700">
                      • <strong>{obj.name}</strong> is not used by any mini-app. Consider assigning it or removing it.
                    </div>
                  ))}
                  {health.unusedObjectTypes.length > 3 && (
                    <div className="text-sm text-yellow-700">
                      • ...and {health.unusedObjectTypes.length - 3} more
                    </div>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Growth Trends */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Ecosystem Growth
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-3xl font-bold text-blue-600">{health.totalApps}</div>
              <div className="text-sm text-gray-500">Mini-Apps</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-purple-600">{health.totalObjectTypes}</div>
              <div className="text-sm text-gray-500">Object Types</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-green-600">{health.totalRelationships}</div>
              <div className="text-sm text-gray-500">Relationships</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
