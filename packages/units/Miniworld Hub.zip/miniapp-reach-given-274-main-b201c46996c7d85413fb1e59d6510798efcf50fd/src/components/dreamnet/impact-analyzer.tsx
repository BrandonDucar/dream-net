'use client';

import React, { useState, useMemo } from 'react';
import type { MiniApp, ObjectType, Relationship } from '@/types/dreamnet';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertTriangle, ArrowDown, ArrowRight, Search } from 'lucide-react';

interface ImpactAnalyzerProps {
  miniApps: MiniApp[];
  objectTypes: ObjectType[];
  relationships: Relationship[];
}

interface ImpactResult {
  directlyAffected: Array<{ id: string; name: string; type: 'app' | 'object' }>;
  indirectlyAffected: Array<{ id: string; name: string; type: 'app' | 'object' }>;
  brokenRelationships: Relationship[];
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
}

export function ImpactAnalyzer({ miniApps, objectTypes, relationships }: ImpactAnalyzerProps) {
  const [selectedEntity, setSelectedEntity] = useState<string>('');
  const [selectedType, setSelectedType] = useState<'app' | 'object'>('app');
  const [impactResult, setImpactResult] = useState<ImpactResult | null>(null);

  const allEntities = useMemo(() => {
    return [
      ...miniApps.map((app: MiniApp) => ({ id: app.id, name: app.name, type: 'app' as const })),
      ...objectTypes.map((obj: ObjectType) => ({ id: obj.id, name: obj.name, type: 'object' as const })),
    ];
  }, [miniApps, objectTypes]);

  const analyzeImpact = () => {
    if (!selectedEntity) return;

    const entity = allEntities.find((e) => e.id === selectedEntity);
    if (!entity) return;

    // Find direct relationships
    const directRelationships = relationships.filter(
      (rel: Relationship) =>
        rel.fromType === entity.name ||
        rel.fromType === entity.id ||
        rel.toType === entity.name ||
        rel.toType === entity.id
    );

    // Find directly affected entities
    const directlyAffectedIds = new Set<string>();
    directRelationships.forEach((rel: Relationship) => {
      if (rel.fromType === entity.name || rel.fromType === entity.id) {
        const affected = allEntities.find((e) => e.name === rel.toType || e.id === rel.toType);
        if (affected) directlyAffectedIds.add(affected.id);
      }
      if (rel.toType === entity.name || rel.toType === entity.id) {
        const affected = allEntities.find((e) => e.name === rel.fromType || e.id === rel.fromType);
        if (affected) directlyAffectedIds.add(affected.id);
      }
    });

    const directlyAffected = Array.from(directlyAffectedIds)
      .map((id: string) => allEntities.find((e) => e.id === id))
      .filter((e): e is { id: string; name: string; type: 'app' | 'object' } => e !== undefined);

    // Find indirectly affected (2nd degree)
    const indirectlyAffectedIds = new Set<string>();
    directlyAffected.forEach((affected) => {
      const secondaryRels = relationships.filter(
        (rel: Relationship) =>
          (rel.fromType === affected.name || rel.fromType === affected.id) &&
          rel.toType !== entity.name &&
          rel.toType !== entity.id
      );

      secondaryRels.forEach((rel: Relationship) => {
        const secondaryAffected = allEntities.find((e) => e.name === rel.toType || e.id === rel.toType);
        if (secondaryAffected && !directlyAffectedIds.has(secondaryAffected.id)) {
          indirectlyAffectedIds.add(secondaryAffected.id);
        }
      });
    });

    const indirectlyAffected = Array.from(indirectlyAffectedIds)
      .map((id: string) => allEntities.find((e) => e.id === id))
      .filter((e): e is { id: string; name: string; type: 'app' | 'object' } => e !== undefined);

    // Determine severity
    let severity: 'low' | 'medium' | 'high' | 'critical' = 'low';
    const totalAffected = directlyAffected.length + indirectlyAffected.length;
    
    if (entity.type === 'app') {
      const app = miniApps.find((a: MiniApp) => a.id === entity.id);
      if (app?.priorityLevel === 'critical') severity = 'critical';
      else if (totalAffected > 5) severity = 'high';
      else if (totalAffected > 2) severity = 'medium';
    } else {
      if (totalAffected > 8) severity = 'critical';
      else if (totalAffected > 5) severity = 'high';
      else if (totalAffected > 2) severity = 'medium';
    }

    // Generate description
    let description = '';
    if (entity.type === 'app') {
      description = `Removing or modifying ${entity.name} would directly affect ${directlyAffected.length} ${
        directlyAffected.length === 1 ? 'entity' : 'entities'
      }`;
      if (indirectlyAffected.length > 0) {
        description += ` and indirectly impact ${indirectlyAffected.length} more through the dependency chain`;
      }
      description += '.';
    } else {
      description = `Changing the ${entity.name} object type would break ${directRelationships.length} ${
        directRelationships.length === 1 ? 'relationship' : 'relationships'
      }`;
      if (directlyAffected.length > 0) {
        description += ` and require updates to ${directlyAffected.length} mini-app${
          directlyAffected.length === 1 ? '' : 's'
        }`;
      }
      description += '.';
    }

    setImpactResult({
      directlyAffected,
      indirectlyAffected,
      brokenRelationships: directRelationships,
      severity,
      description,
    });
  };

  const getSeverityColor = (severity: string): string => {
    const colors: Record<string, string> = {
      low: 'bg-green-100 text-green-800 border-green-300',
      medium: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      high: 'bg-orange-100 text-orange-800 border-orange-300',
      critical: 'bg-red-100 text-red-800 border-red-300',
    };
    return colors[severity] || colors.low;
  };

  const getSeverityBadge = (severity: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      low: 'secondary',
      medium: 'default',
      high: 'default',
      critical: 'destructive',
    };
    return <Badge variant={variants[severity]}>{severity.toUpperCase()}</Badge>;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="h-5 w-5" />
          Impact Analyzer
        </CardTitle>
        <CardDescription>Analyze what would break if you change or remove an entity</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Entity Type</label>
            <Select value={selectedType} onValueChange={(value: string) => setSelectedType(value as 'app' | 'object')}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="app">Mini-App</SelectItem>
                <SelectItem value="object">Object Type</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="md:col-span-2">
            <label className="text-sm font-medium mb-2 block">Select Entity</label>
            <Select value={selectedEntity} onValueChange={setSelectedEntity}>
              <SelectTrigger>
                <SelectValue placeholder="Choose an entity to analyze..." />
              </SelectTrigger>
              <SelectContent>
                {allEntities
                  .filter((e) => e.type === selectedType)
                  .map((entity) => (
                    <SelectItem key={entity.id} value={entity.id}>
                      {entity.name}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button onClick={analyzeImpact} disabled={!selectedEntity} className="w-full">
          <Search className="h-4 w-4 mr-2" />
          Analyze Impact
        </Button>

        {impactResult && (
          <div className="space-y-6">
            {/* Severity Summary */}
            <Card className={`border-2 ${getSeverityColor(impactResult.severity)}`}>
              <CardHeader className="pb-3">
                <div className="flex items-center gap-3">
                  <AlertTriangle className="h-6 w-6" />
                  <div>
                    <CardTitle className="text-lg">Impact Assessment</CardTitle>
                    {getSeverityBadge(impactResult.severity)}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm font-medium">{impactResult.description}</p>
              </CardContent>
            </Card>

            {/* Directly Affected */}
            {impactResult.directlyAffected.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <ArrowRight className="h-4 w-4" />
                    Directly Affected ({impactResult.directlyAffected.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {impactResult.directlyAffected.map((entity) => (
                      <div key={entity.id} className="flex items-center justify-between p-3 bg-gray-50 rounded border">
                        <div className="flex items-center gap-3">
                          <Badge variant={entity.type === 'app' ? 'default' : 'secondary'}>
                            {entity.type === 'app' ? 'APP' : 'OBJECT'}
                          </Badge>
                          <span className="font-medium">{entity.name}</span>
                        </div>
                        <Badge variant="destructive">Direct Impact</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Indirectly Affected */}
            {impactResult.indirectlyAffected.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <ArrowDown className="h-4 w-4" />
                    Indirectly Affected ({impactResult.indirectlyAffected.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {impactResult.indirectlyAffected.map((entity) => (
                      <div key={entity.id} className="flex items-center justify-between p-3 bg-gray-50 rounded border">
                        <div className="flex items-center gap-3">
                          <Badge variant={entity.type === 'app' ? 'default' : 'secondary'}>
                            {entity.type === 'app' ? 'APP' : 'OBJECT'}
                          </Badge>
                          <span className="font-medium">{entity.name}</span>
                        </div>
                        <Badge variant="outline">Ripple Effect</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Broken Relationships */}
            {impactResult.brokenRelationships.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">
                    Broken Relationships ({impactResult.brokenRelationships.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {impactResult.brokenRelationships.map((rel: Relationship) => (
                      <div key={rel.id} className="p-3 bg-red-50 rounded border border-red-200">
                        <div className="flex items-center gap-2 text-sm">
                          <span className="font-medium">{rel.fromType}</span>
                          <Badge variant="outline">{rel.relationKind}</Badge>
                          <ArrowRight className="h-3 w-3" />
                          <span className="font-medium">{rel.toType}</span>
                        </div>
                        {rel.description && <p className="text-xs text-gray-600 mt-1">{rel.description}</p>}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* No Impact */}
            {impactResult.directlyAffected.length === 0 && impactResult.indirectlyAffected.length === 0 && (
              <Card className="bg-green-50 border-green-200">
                <CardContent className="pt-6">
                  <div className="text-center text-green-800">
                    <div className="text-2xl mb-2">✓</div>
                    <p className="font-medium">No Impact Detected</p>
                    <p className="text-sm mt-1">This entity can be safely modified or removed.</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
