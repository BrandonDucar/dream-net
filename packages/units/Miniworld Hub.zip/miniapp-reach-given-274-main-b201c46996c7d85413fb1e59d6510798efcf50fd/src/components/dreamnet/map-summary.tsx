'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Copy, Check } from 'lucide-react';
import { useState } from 'react';

interface MapSummaryProps {
  mapSummary: string;
  briefSummary: string;
}

export function MapSummary({ mapSummary, briefSummary }: MapSummaryProps) {
  const [copiedMap, setCopiedMap] = useState<boolean>(false);
  const [copiedBrief, setCopiedBrief] = useState<boolean>(false);

  const copyMapToClipboard = () => {
    navigator.clipboard.writeText(mapSummary);
    setCopiedMap(true);
    setTimeout(() => setCopiedMap(false), 2000);
  };

  const copyBriefToClipboard = () => {
    navigator.clipboard.writeText(briefSummary);
    setCopiedBrief(true);
    setTimeout(() => setCopiedBrief(false), 2000);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Miniworld Map</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="map">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="map">Map View</TabsTrigger>
            <TabsTrigger value="brief">Export Brief</TabsTrigger>
          </TabsList>

          <TabsContent value="map" className="space-y-4">
            <div className="flex justify-end">
              <Button onClick={copyMapToClipboard} size="sm" variant="outline">
                {copiedMap ? (
                  <>
                    <Check className="w-4 h-4 mr-2" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 mr-2" />
                    Copy Map
                  </>
                )}
              </Button>
            </div>
            <ScrollArea className="h-[600px] w-full rounded border bg-muted p-4">
              <pre className="text-sm font-mono whitespace-pre-wrap">
                {mapSummary}
              </pre>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="brief" className="space-y-4">
            <div className="flex justify-end">
              <Button onClick={copyBriefToClipboard} size="sm" variant="outline">
                {copiedBrief ? (
                  <>
                    <Check className="w-4 h-4 mr-2" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 mr-2" />
                    Copy Brief
                  </>
                )}
              </Button>
            </div>
            <ScrollArea className="h-[600px] w-full rounded border bg-muted p-4">
              <pre className="text-sm font-mono whitespace-pre-wrap">
                {briefSummary}
              </pre>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
