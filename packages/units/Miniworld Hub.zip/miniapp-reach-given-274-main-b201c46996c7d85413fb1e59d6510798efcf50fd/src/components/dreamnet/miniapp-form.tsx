'use client';

import { useState } from 'react';
import type { MiniApp, MiniAppStatus, PriorityLevel, GeoTarget } from '@/types/dreamnet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { X, Plus, Sparkles, Globe } from 'lucide-react';
import { generateMiniAppSEO, generateGeoVariants } from '@/lib/seo-generator';

interface MiniAppFormProps {
  miniApp?: MiniApp;
  allMiniApps: MiniApp[];
  geoTargets: GeoTarget[];
  onSave: (miniApp: MiniApp) => void;
  onCancel: () => void;
}

export function MiniAppForm({ miniApp, allMiniApps, geoTargets, onSave, onCancel }: MiniAppFormProps) {
  const [formData, setFormData] = useState<MiniApp>(
    miniApp || {
      id: '',
      name: '',
      category: '',
      description: '',
      role: '',
      inputTypes: [],
      outputTypes: [],
      status: 'active',
      priorityLevel: 'medium',
      relatedApps: [],
      notes: '',
      seoTitle: '',
      seoDescription: '',
      seoKeywords: [],
      seoHashtags: [],
      altText: '',
      primaryGeoTargets: [],
      appIntroLocalized: {},
      tagsLocalized: {},
    }
  );

  const [newInputType, setNewInputType] = useState<string>('');
  const [newOutputType, setNewOutputType] = useState<string>('');
  const [newKeyword, setNewKeyword] = useState<string>('');
  const [newHashtag, setNewHashtag] = useState<string>('');

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSave(formData);
  };

  const addInputType = () => {
    if (newInputType.trim()) {
      setFormData({
        ...formData,
        inputTypes: [...formData.inputTypes, newInputType.trim()],
      });
      setNewInputType('');
    }
  };

  const removeInputType = (index: number) => {
    setFormData({
      ...formData,
      inputTypes: formData.inputTypes.filter((_: string, i: number) => i !== index),
    });
  };

  const addOutputType = () => {
    if (newOutputType.trim()) {
      setFormData({
        ...formData,
        outputTypes: [...formData.outputTypes, newOutputType.trim()],
      });
      setNewOutputType('');
    }
  };

  const removeOutputType = (index: number) => {
    setFormData({
      ...formData,
      outputTypes: formData.outputTypes.filter((_: string, i: number) => i !== index),
    });
  };

  const regenerateSEO = () => {
    const seoData = generateMiniAppSEO(formData);
    setFormData({
      ...formData,
      ...seoData,
    });
  };

  const addKeyword = () => {
    if (newKeyword.trim()) {
      setFormData({
        ...formData,
        seoKeywords: [...formData.seoKeywords, newKeyword.trim()],
      });
      setNewKeyword('');
    }
  };

  const removeKeyword = (index: number) => {
    setFormData({
      ...formData,
      seoKeywords: formData.seoKeywords.filter((_: string, i: number) => i !== index),
    });
  };

  const addHashtag = () => {
    if (newHashtag.trim()) {
      const hashtag = newHashtag.trim().startsWith('#') ? newHashtag.trim() : `#${newHashtag.trim()}`;
      setFormData({
        ...formData,
        seoHashtags: [...formData.seoHashtags, hashtag],
      });
      setNewHashtag('');
    }
  };

  const removeHashtag = (index: number) => {
    setFormData({
      ...formData,
      seoHashtags: formData.seoHashtags.filter((_: string, i: number) => i !== index),
    });
  };

  const toggleRelatedApp = (appId: string) => {
    if (formData.relatedApps.includes(appId)) {
      setFormData({
        ...formData,
        relatedApps: formData.relatedApps.filter((id: string) => id !== appId),
      });
    } else {
      setFormData({
        ...formData,
        relatedApps: [...formData.relatedApps, appId],
      });
    }
  };

  const toggleGeoTarget = (geoId: string) => {
    const existing = formData.primaryGeoTargets.find((g: GeoTarget) => g.id === geoId);
    if (existing) {
      setFormData({
        ...formData,
        primaryGeoTargets: formData.primaryGeoTargets.filter((g: GeoTarget) => g.id !== geoId),
      });
    } else {
      const geoTarget = geoTargets.find((g: GeoTarget) => g.id === geoId);
      if (geoTarget) {
        setFormData({
          ...formData,
          primaryGeoTargets: [...formData.primaryGeoTargets, geoTarget],
        });
      }
    }
  };

  const generateGeoVariantsForApp = () => {
    if (formData.primaryGeoTargets.length === 0) {
      alert('Please select at least one geo target first.');
      return;
    }

    const variants = generateGeoVariants(formData);
    setFormData({
      ...formData,
      appIntroLocalized: variants.appIntroLocalized,
      tagsLocalized: variants.tagsLocalized,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Tabs defaultValue="identity" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="identity">Identity</TabsTrigger>
          <TabsTrigger value="seo">SEO & Geo</TabsTrigger>
          <TabsTrigger value="relationships">Relationships</TabsTrigger>
        </TabsList>

        <TabsContent value="identity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name">Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">Category *</Label>
                  <Input
                    id="category"
                    value={formData.category}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      setFormData({ ...formData, category: e.target.value })
                    }
                    placeholder="e.g., culture, distribution, analytics"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="role">Role *</Label>
                  <Input
                    id="role"
                    value={formData.role}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      setFormData({ ...formData, role: e.target.value })
                    }
                    placeholder="e.g., generator, planner, analyzer"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                  rows={4}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value: MiniAppStatus) =>
                      setFormData({ ...formData, status: value })
                    }
                  >
                    <SelectTrigger id="status">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="idea">Idea</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="paused">Paused</SelectItem>
                      <SelectItem value="retired">Retired</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="priority">Priority Level</Label>
                  <Select
                    value={formData.priorityLevel}
                    onValueChange={(value: PriorityLevel) =>
                      setFormData({ ...formData, priorityLevel: value })
                    }
                  >
                    <SelectTrigger id="priority">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Input & Output Types</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Input Types</Label>
                <div className="flex gap-2 mb-2">
                  <Input
                    value={newInputType}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewInputType(e.target.value)}
                    placeholder="e.g., CultureCoin, Drop"
                    onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addInputType();
                      }
                    }}
                  />
                  <Button type="button" onClick={addInputType} size="sm">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {formData.inputTypes.map((type: string, index: number) => (
                    <Badge key={index} variant="secondary">
                      {type}
                      <button
                        type="button"
                        onClick={() => removeInputType(index)}
                        className="ml-2"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <Label>Output Types</Label>
                <div className="flex gap-2 mb-2">
                  <Input
                    value={newOutputType}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewOutputType(e.target.value)}
                    placeholder="e.g., CultureCoin, DropBrief"
                    onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addOutputType();
                      }
                    }}
                  />
                  <Button type="button" onClick={addOutputType} size="sm">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {formData.outputTypes.map((type: string, index: number) => (
                    <Badge key={index} variant="secondary">
                      {type}
                      <button
                        type="button"
                        onClick={() => removeOutputType(index)}
                        className="ml-2"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Notes</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={formData.notes}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                  setFormData({ ...formData, notes: e.target.value })
                }
                rows={3}
                placeholder="Additional notes..."
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="seo" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>SEO Metadata</CardTitle>
              <Button type="button" onClick={regenerateSEO} size="sm" variant="outline">
                <Sparkles className="w-4 h-4 mr-2" />
                Regenerate SEO
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="seoTitle">SEO Title</Label>
                <Input
                  id="seoTitle"
                  value={formData.seoTitle}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setFormData({ ...formData, seoTitle: e.target.value })
                  }
                />
              </div>

              <div>
                <Label htmlFor="seoDescription">SEO Description</Label>
                <Textarea
                  id="seoDescription"
                  value={formData.seoDescription}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                    setFormData({ ...formData, seoDescription: e.target.value })
                  }
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="altText">Alt Text</Label>
                <Input
                  id="altText"
                  value={formData.altText}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setFormData({ ...formData, altText: e.target.value })
                  }
                />
              </div>

              <div>
                <Label>SEO Keywords</Label>
                <div className="flex gap-2 mb-2">
                  <Input
                    value={newKeyword}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewKeyword(e.target.value)}
                    placeholder="Add keyword"
                    onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addKeyword();
                      }
                    }}
                  />
                  <Button type="button" onClick={addKeyword} size="sm">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {formData.seoKeywords.map((keyword: string, index: number) => (
                    <Badge key={index} variant="outline">
                      {keyword}
                      <button
                        type="button"
                        onClick={() => removeKeyword(index)}
                        className="ml-2"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <Label>SEO Hashtags</Label>
                <div className="flex gap-2 mb-2">
                  <Input
                    value={newHashtag}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewHashtag(e.target.value)}
                    placeholder="Add hashtag"
                    onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addHashtag();
                      }
                    }}
                  />
                  <Button type="button" onClick={addHashtag} size="sm">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {formData.seoHashtags.map((hashtag: string, index: number) => (
                    <Badge key={index} variant="outline">
                      {hashtag}
                      <button
                        type="button"
                        onClick={() => removeHashtag(index)}
                        className="ml-2"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Geo Targeting</CardTitle>
              <Button type="button" onClick={generateGeoVariantsForApp} size="sm" variant="outline">
                <Globe className="w-4 h-4 mr-2" />
                Generate Geo Variants
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Primary Geo Targets</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {geoTargets.map((geo: GeoTarget) => {
                    const isSelected = formData.primaryGeoTargets.some((g: GeoTarget) => g.id === geo.id);
                    return (
                      <div
                        key={geo.id}
                        className={`p-3 border rounded cursor-pointer transition-colors ${
                          isSelected ? 'bg-primary text-primary-foreground' : 'bg-background hover:bg-muted'
                        }`}
                        onClick={() => toggleGeoTarget(geo.id)}
                      >
                        <div className="font-medium">{geo.region} - {geo.language}</div>
                        <div className="text-sm opacity-80">{geo.cityOrMarket}</div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {Object.keys(formData.appIntroLocalized).length > 0 && (
                <div>
                  <Label>Localized Intros</Label>
                  <div className="space-y-2 mt-2">
                    {Object.entries(formData.appIntroLocalized).map(([geoKey, intro]) => (
                      <div key={geoKey} className="p-3 bg-muted rounded">
                        <div className="font-medium text-sm mb-1">{geoKey}</div>
                        <div className="text-sm">{intro}</div>
                        {formData.tagsLocalized[geoKey] && (
                          <div className="flex flex-wrap gap-1 mt-2">
                            {formData.tagsLocalized[geoKey].map((tag: string, idx: number) => (
                              <Badge key={idx} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="relationships" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Related Mini-Apps</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-2">
                {allMiniApps
                  .filter((app: MiniApp) => app.id !== formData.id)
                  .map((app: MiniApp) => {
                    const isSelected = formData.relatedApps.includes(app.id);
                    return (
                      <div
                        key={app.id}
                        className={`p-3 border rounded cursor-pointer transition-colors ${
                          isSelected ? 'bg-primary text-primary-foreground' : 'bg-background hover:bg-muted'
                        }`}
                        onClick={() => toggleRelatedApp(app.id)}
                      >
                        <div className="font-medium">{app.name}</div>
                        <div className="text-sm opacity-80">{app.category}</div>
                      </div>
                    );
                  })}
              </div>
              {allMiniApps.filter((app: MiniApp) => app.id !== formData.id).length === 0 && (
                <p className="text-muted-foreground text-sm">No other apps available yet.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex gap-2 justify-end">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {miniApp ? 'Update Mini-App' : 'Create Mini-App'}
        </Button>
      </div>
    </form>
  );
}
