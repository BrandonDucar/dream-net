'use client';

import type { MiniApp } from '@/types/dreamnet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Edit, Trash2 } from 'lucide-react';

interface MiniAppListProps {
  miniApps: MiniApp[];
  onEdit: (miniApp: MiniApp) => void;
  onDelete: (id: string) => void;
  filterCategory: string;
  filterStatus: string;
  filterPriority: string;
  onFilterCategoryChange: (value: string) => void;
  onFilterStatusChange: (value: string) => void;
  onFilterPriorityChange: (value: string) => void;
}

export function MiniAppList({
  miniApps,
  onEdit,
  onDelete,
  filterCategory,
  filterStatus,
  filterPriority,
  onFilterCategoryChange,
  onFilterStatusChange,
  onFilterPriorityChange,
}: MiniAppListProps) {
  const categories = Array.from(new Set(miniApps.map((app: MiniApp) => app.category).filter(Boolean)));

  const filteredApps = miniApps.filter((app: MiniApp) => {
    if (filterCategory !== 'all' && app.category !== filterCategory) return false;
    if (filterStatus !== 'all' && app.status !== filterStatus) return false;
    if (filterPriority !== 'all' && app.priorityLevel !== filterPriority) return false;
    return true;
  });

  const getStatusColor = (status: string): string => {
    const colors: Record<string, string> = {
      idea: 'bg-yellow-500/10 text-yellow-700 dark:text-yellow-400',
      active: 'bg-green-500/10 text-green-700 dark:text-green-400',
      paused: 'bg-orange-500/10 text-orange-700 dark:text-orange-400',
      retired: 'bg-gray-500/10 text-gray-700 dark:text-gray-400',
    };
    return colors[status] || '';
  };

  const getPriorityColor = (priority: string): string => {
    const colors: Record<string, string> = {
      low: 'bg-blue-500/10 text-blue-700 dark:text-blue-400',
      medium: 'bg-purple-500/10 text-purple-700 dark:text-purple-400',
      high: 'bg-orange-500/10 text-orange-700 dark:text-orange-400',
      critical: 'bg-red-500/10 text-red-700 dark:text-red-400',
    };
    return colors[priority] || '';
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2 flex-wrap">
        <Select value={filterCategory} onValueChange={onFilterCategoryChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map((cat: string) => (
              <SelectItem key={cat} value={cat}>
                {cat}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filterStatus} onValueChange={onFilterStatusChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="All Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="idea">Idea</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="paused">Paused</SelectItem>
            <SelectItem value="retired">Retired</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filterPriority} onValueChange={onFilterPriorityChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="All Priorities" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Priorities</SelectItem>
            <SelectItem value="low">Low</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="high">High</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-4">
        {filteredApps.length === 0 && (
          <Card>
            <CardContent className="pt-6">
              <p className="text-center text-muted-foreground">No mini-apps found. Create your first one!</p>
            </CardContent>
          </Card>
        )}

        {filteredApps.map((app: MiniApp) => (
          <Card key={app.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="space-y-1 flex-1">
                  <CardTitle className="text-xl">{app.name}</CardTitle>
                  <div className="flex gap-2 flex-wrap">
                    <Badge variant="outline">{app.category}</Badge>
                    <Badge className={getStatusColor(app.status)}>
                      {app.status}
                    </Badge>
                    <Badge className={getPriorityColor(app.priorityLevel)}>
                      {app.priorityLevel}
                    </Badge>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onEdit(app)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      if (confirm(`Delete ${app.name}?`)) {
                        onDelete(app.id);
                      }
                    }}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">{app.description}</p>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium">Role:</span> {app.role}
                </div>
                <div>
                  <span className="font-medium">Related Apps:</span> {app.relatedApps.length}
                </div>
              </div>

              {(app.inputTypes.length > 0 || app.outputTypes.length > 0) && (
                <div className="mt-4 space-y-2">
                  {app.inputTypes.length > 0 && (
                    <div>
                      <span className="text-xs font-medium text-muted-foreground">INPUTS:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {app.inputTypes.map((type: string, idx: number) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {type}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  {app.outputTypes.length > 0 && (
                    <div>
                      <span className="text-xs font-medium text-muted-foreground">OUTPUTS:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {app.outputTypes.map((type: string, idx: number) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {type}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
