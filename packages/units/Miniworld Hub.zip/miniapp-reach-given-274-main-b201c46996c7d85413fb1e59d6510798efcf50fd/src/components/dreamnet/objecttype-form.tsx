'use client';

import { useState } from 'react';
import type { ObjectType, MiniApp } from '@/types/dreamnet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { X, Plus, Sparkles } from 'lucide-react';
import { generateObjectTypeSEO } from '@/lib/seo-generator';

interface ObjectTypeFormProps {
  objectType?: ObjectType;
  allMiniApps: MiniApp[];
  onSave: (objectType: ObjectType) => void;
  onCancel: () => void;
}

export function ObjectTypeForm({ objectType, allMiniApps, onSave, onCancel }: ObjectTypeFormProps) {
  const [formData, setFormData] = useState<ObjectType>(
    objectType || {
      id: '',
      name: '',
      description: '',
      examples: [],
      primaryMiniApps: [],
      notes: '',
      seoTitle: '',
      seoDescription: '',
      seoKeywords: [],
      seoHashtags: [],
      altText: '',
    }
  );

  const [newExample, setNewExample] = useState<string>('');
  const [newKeyword, setNewKeyword] = useState<string>('');
  const [newHashtag, setNewHashtag] = useState<string>('');

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSave(formData);
  };

  const addExample = () => {
    if (newExample.trim()) {
      setFormData({
        ...formData,
        examples: [...formData.examples, newExample.trim()],
      });
      setNewExample('');
    }
  };

  const removeExample = (index: number) => {
    setFormData({
      ...formData,
      examples: formData.examples.filter((_: string, i: number) => i !== index),
    });
  };

  const regenerateSEO = () => {
    const seoData = generateObjectTypeSEO(formData);
    setFormData({
      ...formData,
      ...seoData,
    });
  };

  const addKeyword = () => {
    if (newKeyword.trim()) {
      setFormData({
        ...formData,
        seoKeywords: [...formData.seoKeywords, newKeyword.trim()],
      });
      setNewKeyword('');
    }
  };

  const removeKeyword = (index: number) => {
    setFormData({
      ...formData,
      seoKeywords: formData.seoKeywords.filter((_: string, i: number) => i !== index),
    });
  };

  const addHashtag = () => {
    if (newHashtag.trim()) {
      const hashtag = newHashtag.trim().startsWith('#') ? newHashtag.trim() : `#${newHashtag.trim()}`;
      setFormData({
        ...formData,
        seoHashtags: [...formData.seoHashtags, hashtag],
      });
      setNewHashtag('');
    }
  };

  const removeHashtag = (index: number) => {
    setFormData({
      ...formData,
      seoHashtags: formData.seoHashtags.filter((_: string, i: number) => i !== index),
    });
  };

  const togglePrimaryMiniApp = (appId: string) => {
    if (formData.primaryMiniApps.includes(appId)) {
      setFormData({
        ...formData,
        primaryMiniApps: formData.primaryMiniApps.filter((id: string) => id !== appId),
      });
    } else {
      setFormData({
        ...formData,
        primaryMiniApps: [...formData.primaryMiniApps, appId],
      });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Tabs defaultValue="identity" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="identity">Identity</TabsTrigger>
          <TabsTrigger value="seo">SEO</TabsTrigger>
        </TabsList>

        <TabsContent value="identity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name">Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  required
                />
              </div>

              <div>
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                  rows={4}
                  required
                />
              </div>

              <div>
                <Label>Examples</Label>
                <div className="flex gap-2 mb-2">
                  <Input
                    value={newExample}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewExample(e.target.value)}
                    placeholder="e.g., CultureCoin #1, UserSegment Alpha"
                    onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addExample();
                      }
                    }}
                  />
                  <Button type="button" onClick={addExample} size="sm">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {formData.examples.map((example: string, index: number) => (
                    <Badge key={index} variant="secondary">
                      {example}
                      <button
                        type="button"
                        onClick={() => removeExample(index)}
                        className="ml-2"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                    setFormData({ ...formData, notes: e.target.value })
                  }
                  rows={3}
                  placeholder="Additional notes..."
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Primary Mini-Apps</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-2">
                {allMiniApps.map((app: MiniApp) => {
                  const isSelected = formData.primaryMiniApps.includes(app.id);
                  return (
                    <div
                      key={app.id}
                      className={`p-3 border rounded cursor-pointer transition-colors ${
                        isSelected ? 'bg-primary text-primary-foreground' : 'bg-background hover:bg-muted'
                      }`}
                      onClick={() => togglePrimaryMiniApp(app.id)}
                    >
                      <div className="font-medium">{app.name}</div>
                      <div className="text-sm opacity-80">{app.category}</div>
                    </div>
                  );
                })}
              </div>
              {allMiniApps.length === 0 && (
                <p className="text-muted-foreground text-sm">No apps available yet.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="seo" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>SEO Metadata</CardTitle>
              <Button type="button" onClick={regenerateSEO} size="sm" variant="outline">
                <Sparkles className="w-4 h-4 mr-2" />
                Regenerate SEO
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="seoTitle">SEO Title</Label>
                <Input
                  id="seoTitle"
                  value={formData.seoTitle}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setFormData({ ...formData, seoTitle: e.target.value })
                  }
                />
              </div>

              <div>
                <Label htmlFor="seoDescription">SEO Description</Label>
                <Textarea
                  id="seoDescription"
                  value={formData.seoDescription}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                    setFormData({ ...formData, seoDescription: e.target.value })
                  }
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="altText">Alt Text</Label>
                <Input
                  id="altText"
                  value={formData.altText}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setFormData({ ...formData, altText: e.target.value })
                  }
                />
              </div>

              <div>
                <Label>SEO Keywords</Label>
                <div className="flex gap-2 mb-2">
                  <Input
                    value={newKeyword}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewKeyword(e.target.value)}
                    placeholder="Add keyword"
                    onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addKeyword();
                      }
                    }}
                  />
                  <Button type="button" onClick={addKeyword} size="sm">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {formData.seoKeywords.map((keyword: string, index: number) => (
                    <Badge key={index} variant="outline">
                      {keyword}
                      <button
                        type="button"
                        onClick={() => removeKeyword(index)}
                        className="ml-2"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <Label>SEO Hashtags</Label>
                <div className="flex gap-2 mb-2">
                  <Input
                    value={newHashtag}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewHashtag(e.target.value)}
                    placeholder="Add hashtag"
                    onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addHashtag();
                      }
                    }}
                  />
                  <Button type="button" onClick={addHashtag} size="sm">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {formData.seoHashtags.map((hashtag: string, index: number) => (
                    <Badge key={index} variant="outline">
                      {hashtag}
                      <button
                        type="button"
                        onClick={() => removeHashtag(index)}
                        className="ml-2"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex gap-2 justify-end">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {objectType ? 'Update Object Type' : 'Create Object Type'}
        </Button>
      </div>
    </form>
  );
}
