'use client';

import type { ObjectType, MiniApp } from '@/types/dreamnet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Edit, Trash2 } from 'lucide-react';

interface ObjectTypeListProps {
  objectTypes: ObjectType[];
  miniApps: MiniApp[];
  onEdit: (objectType: ObjectType) => void;
  onDelete: (id: string) => void;
}

export function ObjectTypeList({ objectTypes, miniApps, onEdit, onDelete }: ObjectTypeListProps) {
  const getAppName = (appId: string): string => {
    const app = miniApps.find((a: MiniApp) => a.id === appId);
    return app ? app.name : appId;
  };

  return (
    <div className="grid gap-4">
      {objectTypes.length === 0 && (
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">No object types found. Create your first one!</p>
          </CardContent>
        </Card>
      )}

      {objectTypes.map((objType: ObjectType) => (
        <Card key={objType.id} className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="space-y-1 flex-1">
                <CardTitle className="text-xl">{objType.name}</CardTitle>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => onEdit(objType)}
                >
                  <Edit className="w-4 h-4" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    if (confirm(`Delete ${objType.name}?`)) {
                      onDelete(objType.id);
                    }
                  }}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">{objType.description}</p>

            {objType.examples.length > 0 && (
              <div className="mb-4">
                <span className="text-xs font-medium text-muted-foreground">EXAMPLES:</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {objType.examples.map((example: string, idx: number) => (
                    <Badge key={idx} variant="secondary" className="text-xs">
                      {example}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {objType.primaryMiniApps.length > 0 && (
              <div>
                <span className="text-xs font-medium text-muted-foreground">PRIMARY MINI-APPS:</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {objType.primaryMiniApps.map((appId: string, idx: number) => (
                    <Badge key={idx} variant="outline" className="text-xs">
                      {getAppName(appId)}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
