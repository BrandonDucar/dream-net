'use client';

import type { Relationship } from '@/types/dreamnet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Trash2, ArrowRight } from 'lucide-react';

interface RelationshipBrowserProps {
  relationships: Relationship[];
  onDelete: (id: string) => void;
  filterKind: string;
  onFilterKindChange: (value: string) => void;
}

export function RelationshipBrowser({
  relationships,
  onDelete,
  filterKind,
  onFilterKindChange,
}: RelationshipBrowserProps) {
  const relationKinds = Array.from(
    new Set(relationships.map((rel: Relationship) => rel.relationKind).filter(Boolean))
  );

  const filteredRelationships = relationships.filter((rel: Relationship) => {
    if (filterKind !== 'all' && rel.relationKind !== filterKind) return false;
    return true;
  });

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Relationships</CardTitle>
          <Select value={filterKind} onValueChange={onFilterKindChange}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="All Kinds" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Kinds</SelectItem>
              {relationKinds.map((kind: string) => (
                <SelectItem key={kind} value={kind}>
                  {kind}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        {filteredRelationships.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">
            No relationships found. Define connections between your mini-apps and object types!
          </p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>From</TableHead>
                <TableHead>Relation</TableHead>
                <TableHead>To</TableHead>
                <TableHead>Description</TableHead>
                <TableHead className="w-[80px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRelationships.map((rel: Relationship) => (
                <TableRow key={rel.id}>
                  <TableCell>
                    <Badge variant="outline">{rel.fromType}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Badge>{rel.relationKind}</Badge>
                      <ArrowRight className="w-4 h-4 text-muted-foreground" />
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{rel.toType}</Badge>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {rel.description || '-'}
                  </TableCell>
                  <TableCell>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        if (confirm('Delete this relationship?')) {
                          onDelete(rel.id);
                        }
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
