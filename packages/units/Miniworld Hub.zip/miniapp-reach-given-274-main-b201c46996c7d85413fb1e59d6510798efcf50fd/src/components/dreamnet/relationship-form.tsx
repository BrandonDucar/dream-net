'use client';

import { useState } from 'react';
import type { Relationship, MiniApp, ObjectType } from '@/types/dreamnet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface RelationshipFormProps {
  relationship?: Relationship;
  miniApps: MiniApp[];
  objectTypes: ObjectType[];
  onSave: (relationship: Relationship) => void;
  onCancel: () => void;
  prefillFromType?: string;
}

export function RelationshipForm({
  relationship,
  miniApps,
  objectTypes,
  onSave,
  onCancel,
  prefillFromType,
}: RelationshipFormProps) {
  const allTypes = [
    ...miniApps.map((app: MiniApp) => ({ name: app.name, type: 'MiniApp' })),
    ...objectTypes.map((obj: ObjectType) => ({ name: obj.name, type: 'ObjectType' })),
  ];

  const [formData, setFormData] = useState<Relationship>(
    relationship || {
      id: '',
      fromType: prefillFromType || '',
      toType: '',
      relationKind: '',
      description: '',
    }
  );

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Define Relationship</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="fromType">From *</Label>
            <Select
              value={formData.fromType}
              onValueChange={(value: string) =>
                setFormData({ ...formData, fromType: value })
              }
            >
              <SelectTrigger id="fromType">
                <SelectValue placeholder="Select source..." />
              </SelectTrigger>
              <SelectContent>
                {allTypes.map((item: { name: string; type: string }) => (
                  <SelectItem key={item.name} value={item.name}>
                    {item.name} ({item.type})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="relationKind">Relation Kind *</Label>
            <Input
              id="relationKind"
              value={formData.relationKind}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setFormData({ ...formData, relationKind: e.target.value })
              }
              placeholder="e.g., creates, uses, tracks, feeds, visualizes"
              required
            />
          </div>

          <div>
            <Label htmlFor="toType">To *</Label>
            <Select
              value={formData.toType}
              onValueChange={(value: string) =>
                setFormData({ ...formData, toType: value })
              }
            >
              <SelectTrigger id="toType">
                <SelectValue placeholder="Select target..." />
              </SelectTrigger>
              <SelectContent>
                {allTypes.map((item: { name: string; type: string }) => (
                  <SelectItem key={item.name} value={item.name}>
                    {item.name} ({item.type})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                setFormData({ ...formData, description: e.target.value })
              }
              rows={3}
              placeholder="Describe this relationship..."
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-2 justify-end">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {relationship ? 'Update Relationship' : 'Create Relationship'}
        </Button>
      </div>
    </form>
  );
}
