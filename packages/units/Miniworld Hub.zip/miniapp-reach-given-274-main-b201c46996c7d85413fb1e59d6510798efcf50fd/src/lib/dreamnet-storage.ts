import type { DreamNetData, MiniApp, ObjectType, Relationship, GeoTarget } from '@/types/dreamnet';

const STORAGE_KEY = 'dreamnet-registry';

const defaultData: DreamNetData = {
  miniApps: [],
  objectTypes: [],
  relationships: [],
  geoTargets: [
    {
      id: 'us-en',
      region: 'US',
      country: 'US',
      cityOrMarket: 'National',
      language: 'en',
    },
    {
      id: 'latam-es',
      region: 'LATAM',
      country: 'MX',
      cityOrMarket: 'Regional',
      language: 'es',
    },
    {
      id: 'latam-pt',
      region: 'LATAM',
      country: 'BR',
      cityOrMarket: 'Brazil',
      language: 'pt-BR',
    },
    {
      id: 'eu-en',
      region: 'EU',
      country: 'GB',
      cityOrMarket: 'London',
      language: 'en',
    },
  ],
};

export function loadData(): DreamNetData {
  if (typeof window === 'undefined') {
    return defaultData;
  }

  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored) as DreamNetData;
      return {
        ...defaultData,
        ...parsed,
        geoTargets: parsed.geoTargets && parsed.geoTargets.length > 0 ? parsed.geoTargets : defaultData.geoTargets,
      };
    }
  } catch (error) {
    console.error('Error loading data:', error);
  }

  return defaultData;
}

export function saveData(data: DreamNetData): void {
  if (typeof window === 'undefined') {
    return;
  }

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Error saving data:', error);
  }
}

export function saveMiniApp(miniApp: MiniApp): void {
  const data = loadData();
  const index = data.miniApps.findIndex((app: MiniApp) => app.id === miniApp.id);

  if (index >= 0) {
    data.miniApps[index] = miniApp;
  } else {
    data.miniApps.push(miniApp);
  }

  saveData(data);
}

export function deleteMiniApp(id: string): void {
  const data = loadData();
  data.miniApps = data.miniApps.filter((app: MiniApp) => app.id !== id);
  saveData(data);
}

export function saveObjectType(objectType: ObjectType): void {
  const data = loadData();
  const index = data.objectTypes.findIndex((obj: ObjectType) => obj.id === objectType.id);

  if (index >= 0) {
    data.objectTypes[index] = objectType;
  } else {
    data.objectTypes.push(objectType);
  }

  saveData(data);
}

export function deleteObjectType(id: string): void {
  const data = loadData();
  data.objectTypes = data.objectTypes.filter((obj: ObjectType) => obj.id !== id);
  saveData(data);
}

export function saveRelationship(relationship: Relationship): void {
  const data = loadData();
  const index = data.relationships.findIndex((rel: Relationship) => rel.id === relationship.id);

  if (index >= 0) {
    data.relationships[index] = relationship;
  } else {
    data.relationships.push(relationship);
  }

  saveData(data);
}

export function deleteRelationship(id: string): void {
  const data = loadData();
  data.relationships = data.relationships.filter((rel: Relationship) => rel.id !== id);
  saveData(data);
}

export function saveGeoTarget(geoTarget: GeoTarget): void {
  const data = loadData();
  const index = data.geoTargets.findIndex((geo: GeoTarget) => geo.id === geoTarget.id);

  if (index >= 0) {
    data.geoTargets[index] = geoTarget;
  } else {
    data.geoTargets.push(geoTarget);
  }

  saveData(data);
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}
