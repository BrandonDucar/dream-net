import type { DreamNetData, MiniApp, ObjectType, Relationship } from '@/types/dreamnet';

export function generateMiniworldMapSummary(data: DreamNetData): string {
  const { miniApps, objectTypes, relationships } = data;

  const sections: string[] = [];

  sections.push('═══════════════════════════════════════════════════════');
  sections.push('         DREAMNET MINIWORLD REGISTRY MAP');
  sections.push('═══════════════════════════════════════════════════════\n');

  const appsByCategory = miniApps.reduce((acc: Record<string, MiniApp[]>, app: MiniApp) => {
    const category = app.category || 'uncategorized';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(app);
    return acc;
  }, {});

  sections.push('┌─────────────────────────────────────────────────────┐');
  sections.push('│ MINI-APPS BY CATEGORY                               │');
  sections.push('└─────────────────────────────────────────────────────┘\n');

  Object.keys(appsByCategory).sort().forEach((category: string) => {
    sections.push(`▸ ${category.toUpperCase()}`);
    appsByCategory[category].forEach((app: MiniApp) => {
      sections.push(`  • ${app.name} [${app.status}] [${app.priorityLevel}]`);
      sections.push(`    Role: ${app.role}`);
      if (app.inputTypes.length > 0) {
        sections.push(`    Inputs: ${app.inputTypes.join(', ')}`);
      }
      if (app.outputTypes.length > 0) {
        sections.push(`    Outputs: ${app.outputTypes.join(', ')}`);
      }
      sections.push('');
    });
  });

  sections.push('\n┌─────────────────────────────────────────────────────┐');
  sections.push('│ OBJECT TYPES                                        │');
  sections.push('└─────────────────────────────────────────────────────┘\n');

  objectTypes.forEach((objType: ObjectType) => {
    sections.push(`▸ ${objType.name}`);
    sections.push(`  Description: ${objType.description}`);
    if (objType.primaryMiniApps.length > 0) {
      const appNames = objType.primaryMiniApps
        .map((appId: string) => {
          const app = miniApps.find((a: MiniApp) => a.id === appId);
          return app ? app.name : appId;
        })
        .join(', ');
      sections.push(`  Primary Apps: ${appNames}`);
    }
    if (objType.examples.length > 0) {
      sections.push(`  Examples: ${objType.examples.join(', ')}`);
    }
    sections.push('');
  });

  sections.push('\n┌─────────────────────────────────────────────────────┐');
  sections.push('│ KEY RELATIONSHIPS                                   │');
  sections.push('└─────────────────────────────────────────────────────┘\n');

  const relationsByKind = relationships.reduce((acc: Record<string, Relationship[]>, rel: Relationship) => {
    const kind = rel.relationKind || 'unknown';
    if (!acc[kind]) {
      acc[kind] = [];
    }
    acc[kind].push(rel);
    return acc;
  }, {});

  Object.keys(relationsByKind).sort().forEach((kind: string) => {
    sections.push(`▸ ${kind.toUpperCase()}`);
    relationsByKind[kind].forEach((rel: Relationship) => {
      sections.push(`  ${rel.fromType} → ${rel.toType}`);
      if (rel.description) {
        sections.push(`    ${rel.description}`);
      }
    });
    sections.push('');
  });

  sections.push('\n┌─────────────────────────────────────────────────────┐');
  sections.push('│ STATISTICS                                          │');
  sections.push('└─────────────────────────────────────────────────────┘\n');

  const activeApps = miniApps.filter((app: MiniApp) => app.status === 'active').length;
  const ideaApps = miniApps.filter((app: MiniApp) => app.status === 'idea').length;
  const criticalApps = miniApps.filter((app: MiniApp) => app.priorityLevel === 'critical').length;

  sections.push(`  Total Mini-Apps: ${miniApps.length}`);
  sections.push(`  Active Apps: ${activeApps}`);
  sections.push(`  Idea Stage Apps: ${ideaApps}`);
  sections.push(`  Critical Priority Apps: ${criticalApps}`);
  sections.push(`  Object Types: ${objectTypes.length}`);
  sections.push(`  Relationships: ${relationships.length}`);

  sections.push('\n═══════════════════════════════════════════════════════');

  return sections.join('\n');
}

export function exportMiniworldBrief(data: DreamNetData): string {
  const { miniApps, objectTypes, relationships } = data;

  const sections: string[] = [];

  sections.push('═══════════════════════════════════════════════════════');
  sections.push('      DREAMNET MINIWORLD ECOSYSTEM BRIEF');
  sections.push('═══════════════════════════════════════════════════════\n');

  sections.push('MINI-APP REGISTRY\n');
  sections.push('This ecosystem consists of interconnected mini-apps that create,');
  sections.push('manage, and analyze various digital objects and experiences.\n');

  miniApps.forEach((app: MiniApp) => {
    sections.push(`• ${app.name}`);
    sections.push(`  ${app.description}`);
    sections.push(`  Status: ${app.status} | Priority: ${app.priorityLevel}`);
    sections.push('');
  });

  sections.push('\nOBJECT TYPES\n');
  sections.push('These are the core data structures and entities managed across the ecosystem:\n');

  objectTypes.forEach((objType: ObjectType) => {
    sections.push(`• ${objType.name}: ${objType.description}`);
  });

  sections.push('\n\nDATA FLOW\n');
  sections.push('Key relationships and interactions:\n');

  relationships.forEach((rel: Relationship) => {
    sections.push(`  ${rel.fromType} --[${rel.relationKind}]--> ${rel.toType}`);
    if (rel.description) {
      sections.push(`    └─ ${rel.description}`);
    }
  });

  sections.push('\n\nPOTENTIAL FUTURE INTEGRATIONS\n');
  sections.push('- Cross-app analytics dashboard');
  sections.push('- Unified object search across all apps');
  sections.push('- Automated workflow orchestration between apps');
  sections.push('- Real-time collaboration features');
  sections.push('- Shared authentication and permissions layer');

  sections.push('\n═══════════════════════════════════════════════════════');

  return sections.join('\n');
}
