import type { SEOMetadata, MiniApp, ObjectType } from '@/types/dreamnet';

export function generateMiniAppSEO(app: Partial<MiniApp>): SEOMetadata {
  const name = app.name || 'Untitled App';
  const description = app.description || 'A mini-app in the DreamNet ecosystem';
  const category = app.category || 'general';
  const role = app.role || 'tool';

  const seoTitle = `${name} | ${category.charAt(0).toUpperCase() + category.slice(1)} ${role.charAt(0).toUpperCase() + role.slice(1)}`;
  
  const seoDescription = description.length > 160 
    ? description.substring(0, 157) + '...' 
    : description;

  const seoKeywords = [
    name.toLowerCase(),
    category.toLowerCase(),
    role.toLowerCase(),
    'mini-app',
    'dreamnet',
    'registry',
    ...(app.inputTypes || []).map((t: string) => t.toLowerCase()),
    ...(app.outputTypes || []).map((t: string) => t.toLowerCase()),
  ];

  const seoHashtags = [
    '#DreamNet',
    `#${category.replace(/\s+/g, '')}`,
    `#${name.replace(/\s+/g, '')}`,
    '#MiniApp',
    '#Web3',
  ];

  const altText = `${name}: ${role} for ${category} in the DreamNet ecosystem`;

  return {
    seoTitle,
    seoDescription,
    seoKeywords: Array.from(new Set(seoKeywords)),
    seoHashtags: Array.from(new Set(seoHashtags)),
    altText,
  };
}

export function generateObjectTypeSEO(objectType: Partial<ObjectType>): SEOMetadata {
  const name = objectType.name || 'Untitled Object';
  const description = objectType.description || 'An object type in the DreamNet ecosystem';

  const seoTitle = `${name} | DreamNet Object Type`;
  
  const seoDescription = description.length > 160 
    ? description.substring(0, 157) + '...' 
    : description;

  const seoKeywords = [
    name.toLowerCase(),
    'object-type',
    'data-model',
    'dreamnet',
    'registry',
    ...(objectType.examples || []).map((ex: string) => ex.toLowerCase()),
  ];

  const seoHashtags = [
    '#DreamNet',
    `#${name.replace(/\s+/g, '')}`,
    '#DataModel',
    '#ObjectType',
  ];

  const altText = `${name}: A data object type in the DreamNet ecosystem`;

  return {
    seoTitle,
    seoDescription,
    seoKeywords: Array.from(new Set(seoKeywords)),
    seoHashtags: Array.from(new Set(seoHashtags)),
    altText,
  };
}

export function generateGeoVariants(app: MiniApp): {
  appIntroLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
} {
  const appIntroLocalized: Record<string, string> = {};
  const tagsLocalized: Record<string, string[]> = {};

  app.primaryGeoTargets.forEach((geo) => {
    const geoKey = geo.id;

    if (geo.language === 'es') {
      appIntroLocalized[geoKey] = `${app.name}: ${app.description} (Categoría: ${app.category})`;
      tagsLocalized[geoKey] = [
        '#DreamNet',
        `#${app.category.replace(/\s+/g, '')}`,
        '#AplicaciónMini',
        '#Web3',
      ];
    } else if (geo.language === 'pt-BR') {
      appIntroLocalized[geoKey] = `${app.name}: ${app.description} (Categoria: ${app.category})`;
      tagsLocalized[geoKey] = [
        '#DreamNet',
        `#${app.category.replace(/\s+/g, '')}`,
        '#MiniApp',
        '#Web3',
      ];
    } else {
      appIntroLocalized[geoKey] = `${app.name}: ${app.description} (Category: ${app.category})`;
      tagsLocalized[geoKey] = app.seoHashtags || [
        '#DreamNet',
        `#${app.category.replace(/\s+/g, '')}`,
        '#MiniApp',
      ];
    }
  });

  return { appIntroLocalized, tagsLocalized };
}
