export interface GeoTarget {
  id: string;
  region: string;
  country: string;
  cityOrMarket: string;
  language: string;
}

export interface SEOMetadata {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export interface MiniApp extends SEOMetadata {
  id: string;
  name: string;
  category: string;
  description: string;
  role: string;
  inputTypes: string[];
  outputTypes: string[];
  status: 'idea' | 'active' | 'paused' | 'retired';
  priorityLevel: 'low' | 'medium' | 'high' | 'critical';
  relatedApps: string[];
  notes: string;
  primaryGeoTargets: GeoTarget[];
  appIntroLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
}

export interface ObjectType extends SEOMetadata {
  id: string;
  name: string;
  description: string;
  examples: string[];
  primaryMiniApps: string[];
  notes: string;
}

export interface Relationship {
  id: string;
  fromType: string;
  toType: string;
  relationKind: string;
  description: string;
}

export interface DreamNetData {
  miniApps: MiniApp[];
  objectTypes: ObjectType[];
  relationships: Relationship[];
  geoTargets: GeoTarget[];
}

export type MiniAppStatus = 'idea' | 'active' | 'paused' | 'retired';
export type PriorityLevel = 'low' | 'medium' | 'high' | 'critical';
