'use client'
import { useState, useEffect } from 'react';
import type { BusinessInfo, OfferResults } from '@/types/offer';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { OfferResults as OfferResultsComponent } from '@/components/offer-results';
import { Loader2, Sparkles } from 'lucide-react';
import { openaiChatCompletion } from '@/openai-api';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function LocalOfferLab(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [formData, setFormData] = useState<BusinessInfo>({
    product: '',
    customer: '',
    channel: '',
    currentOffer: '',
  });
  const [results, setResults] = useState<OfferResults | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const handleInputChange = (field: keyof BusinessInfo, value: string): void => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const generateOffers = async (): Promise<void> => {
    if (!formData.product || !formData.customer || !formData.channel) {
      setError('Please fill out the first three questions at minimum.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const prompt = `You are an expert offer designer for small businesses. Analyze this business and create compelling offers.

Business Details:
- What they sell: ${formData.product}
- Ideal customer: ${formData.customer}
- Where customers find them: ${formData.channel}
- Current offer (if any): ${formData.currentOffer || 'None'}

Please provide a response in EXACTLY this JSON format (no extra text, no markdown, just valid JSON):

{
  "diagnosis": {
    "summary": "A 1-2 sentence diagnosis of their current situation",
    "missing": ["element1", "element2", "element3"]
  },
  "offers": [
    {
      "title": "Try-Me Offer",
      "type": "Low-risk trial offer",
      "wording": "The exact offer wording they should use",
      "bestFor": "Who this offer works best for",
      "howToPresent": {
        "signage": "How to display on signage",
        "socialPost": "How to post on social media",
        "dm": "How to present in direct messages",
        "landingPage": "How to present on a landing page"
      }
    },
    {
      "title": "Bundle Offer",
      "type": "Value-packed bundle",
      "wording": "The exact offer wording",
      "bestFor": "Who this works for",
      "howToPresent": {
        "signage": "Signage copy",
        "socialPost": "Social media copy",
        "dm": "DM copy",
        "landingPage": "Landing page copy"
      }
    },
    {
      "title": "Membership/Subscription Offer",
      "type": "Recurring value",
      "wording": "The exact offer wording",
      "bestFor": "Who this works for",
      "howToPresent": {
        "signage": "Signage copy",
        "socialPost": "Social media copy",
        "dm": "DM copy",
        "landingPage": "Landing page copy"
      }
    },
    {
      "title": "Seasonal/Event Offer",
      "type": "Timely special",
      "wording": "The exact offer wording",
      "bestFor": "Who this works for",
      "howToPresent": {
        "signage": "Signage copy",
        "socialPost": "Social media copy",
        "dm": "DM copy",
        "landingPage": "Landing page copy"
      }
    }
  ],
  "launchPlan": [
    {
      "day": 1,
      "task": "Day 1 task name",
      "action": "Specific action to take"
    },
    {
      "day": 2,
      "task": "Day 2 task name",
      "action": "Specific action to take"
    },
    {
      "day": 3,
      "task": "Day 3 task name",
      "action": "Specific action to take"
    },
    {
      "day": 4,
      "task": "Day 4 task name",
      "action": "Specific action to take"
    },
    {
      "day": 5,
      "task": "Day 5 task name",
      "action": "Specific action to take"
    },
    {
      "day": 6,
      "task": "Day 6 task name",
      "action": "Specific action to take"
    },
    {
      "day": 7,
      "task": "Day 7 task name",
      "action": "Specific action to take"
    }
  ],
  "bestOffer": 0
}

Guidelines:
- Keep language simple and actionable
- Be specific about urgency, clarity, bonuses, guarantees
- Make the wording sound natural and compelling
- Ensure the 7-day plan is realistic for a small business owner
- Set "bestOffer" to the index (0-3) of the most recommended offer for this business
- Keep "missing" to 3-5 key elements like "urgency", "clear value", "guarantee", "bonus", "scarcity", etc.`;

      const response = await openaiChatCompletion({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: 'You are an expert offer designer. Always respond with valid JSON only, no markdown formatting.',
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
      });

      const content = response.choices[0]?.message?.content;
      if (!content) {
        throw new Error('No response from AI');
      }

      const cleanedContent = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      const parsedResults: OfferResults = JSON.parse(cleanedContent);

      setResults(parsedResults);
    } catch (err) {
      console.error('Error generating offers:', err);
      setError('Failed to generate offers. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4 pt-8">
          <div className="flex items-center justify-center gap-3">
            <Sparkles className="h-10 w-10 text-purple-600" />
            <h1 className="text-4xl sm:text-5xl font-bold text-black">Local Offer Lab</h1>
          </div>
          <p className="text-lg text-black max-w-2xl mx-auto">
            Design clear, compelling offers for your small business or solo operation.
            Answer a few questions and get ready-to-use offer strategies tonight.
          </p>
        </div>

        {/* Form Card */}
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl text-black">Tell Us About Your Business</CardTitle>
            <CardDescription className="text-black">
              Answer these questions to get personalized offer recommendations
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Question 1 */}
            <div className="space-y-2">
              <Label htmlFor="product" className="text-base font-semibold text-black">
                1. What do you sell?
              </Label>
              <Input
                id="product"
                placeholder="e.g., Handmade candles, consulting services, home cleaning..."
                value={formData.product}
                onChange={(e) => handleInputChange('product', e.target.value)}
                className="text-black"
              />
            </div>

            {/* Question 2 */}
            <div className="space-y-2">
              <Label htmlFor="customer" className="text-base font-semibold text-black">
                2. Who is your ideal customer?
              </Label>
              <Textarea
                id="customer"
                placeholder="e.g., Busy moms in their 30s-40s who value wellness, small business owners looking to grow..."
                value={formData.customer}
                onChange={(e) => handleInputChange('customer', e.target.value)}
                rows={3}
                className="text-black"
              />
            </div>

            {/* Question 3 */}
            <div className="space-y-2">
              <Label htmlFor="channel" className="text-base font-semibold text-black">
                3. Where do they usually find you?
              </Label>
              <Input
                id="channel"
                placeholder="e.g., Walk-in, Instagram, referrals, Facebook groups, local events..."
                value={formData.channel}
                onChange={(e) => handleInputChange('channel', e.target.value)}
                className="text-black"
              />
            </div>

            {/* Question 4 */}
            <div className="space-y-2">
              <Label htmlFor="currentOffer" className="text-base font-semibold text-black">
                4. What's your current best offer, if any?
              </Label>
              <Textarea
                id="currentOffer"
                placeholder="e.g., 10% off first purchase, free consultation, or leave blank if you don't have one yet..."
                value={formData.currentOffer}
                onChange={(e) => handleInputChange('currentOffer', e.target.value)}
                rows={3}
                className="text-black"
              />
              <p className="text-xs text-black">Optional - leave blank if you don't have one</p>
            </div>

            {/* Error Message */}
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-900">{error}</p>
              </div>
            )}

            {/* Submit Button */}
            <Button
              onClick={generateOffers}
              disabled={loading}
              className="w-full bg-purple-600 hover:bg-purple-700 text-white text-lg py-6"
              size="lg"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Generating Your Offers...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-5 w-5" />
                  Generate My Offers
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results */}
        {results && <OfferResultsComponent results={results} />}

        {/* Footer */}
        <div className="text-center text-sm text-black py-8">
          <p>Built for real-world business owners who want clarity, not confusion.</p>
        </div>
      </div>
    </div>
  );
}
