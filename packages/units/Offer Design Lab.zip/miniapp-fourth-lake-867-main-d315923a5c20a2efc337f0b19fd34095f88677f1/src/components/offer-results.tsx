'use client';

import type { OfferResults } from '@/types/offer';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle2, AlertCircle, Lightbulb, Calendar } from 'lucide-react';

interface OfferResultsProps {
  results: OfferResults;
}

export function OfferResults({ results }: OfferResultsProps): JSX.Element {
  const { diagnosis, offers, launchPlan, bestOffer } = results;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Diagnosis Section */}
      <Card className="border-orange-200 bg-orange-50">
        <CardHeader>
          <div className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-orange-600" />
            <CardTitle className="text-black">Quick Diagnosis</CardTitle>
          </div>
          <CardDescription className="text-black">{diagnosis.summary}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <p className="text-sm font-medium text-black">What's missing:</p>
            <div className="flex flex-wrap gap-2">
              {diagnosis.missing.map((item: string, index: number) => (
                <Badge key={index} variant="outline" className="bg-white text-black border-orange-300">
                  {item}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Offers Section */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Lightbulb className="h-5 w-5 text-yellow-600" />
          <h2 className="text-2xl font-bold text-black">Your Alternative Offers</h2>
        </div>

        {offers.map((offer, index: number) => (
          <Card
            key={index}
            className={`transition-all hover:shadow-lg ${
              index === bestOffer ? 'border-green-500 border-2 bg-green-50' : ''
            }`}
          >
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2">
                    <CardTitle className="text-black">{offer.title}</CardTitle>
                    {index === bestOffer && (
                      <Badge className="bg-green-600 text-white">
                        <CheckCircle2 className="h-3 w-3 mr-1" />
                        Recommended
                      </Badge>
                    )}
                  </div>
                  <CardDescription className="text-black">{offer.type}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Exact Wording */}
              <div className="space-y-2">
                <p className="text-sm font-semibold text-black">Exact Wording:</p>
                <Alert className="bg-blue-50 border-blue-200">
                  <AlertDescription className="text-base font-medium text-black">
                    "{offer.wording}"
                  </AlertDescription>
                </Alert>
              </div>

              {/* Best For */}
              <div className="space-y-2">
                <p className="text-sm font-semibold text-black">Best For:</p>
                <p className="text-sm text-black">{offer.bestFor}</p>
              </div>

              <Separator />

              {/* How to Present */}
              <div className="space-y-3">
                <p className="text-sm font-semibold text-black">How to Present:</p>
                <div className="grid gap-3">
                  {offer.howToPresent.signage && (
                    <div className="rounded-lg bg-purple-50 p-3 border border-purple-200">
                      <p className="text-xs font-semibold text-purple-900 mb-1">📋 Signage</p>
                      <p className="text-sm text-black">{offer.howToPresent.signage}</p>
                    </div>
                  )}
                  {offer.howToPresent.socialPost && (
                    <div className="rounded-lg bg-blue-50 p-3 border border-blue-200">
                      <p className="text-xs font-semibold text-blue-900 mb-1">📱 Social Post</p>
                      <p className="text-sm text-black">{offer.howToPresent.socialPost}</p>
                    </div>
                  )}
                  {offer.howToPresent.dm && (
                    <div className="rounded-lg bg-green-50 p-3 border border-green-200">
                      <p className="text-xs font-semibold text-green-900 mb-1">💬 Direct Message</p>
                      <p className="text-sm text-black">{offer.howToPresent.dm}</p>
                    </div>
                  )}
                  {offer.howToPresent.landingPage && (
                    <div className="rounded-lg bg-orange-50 p-3 border border-orange-200">
                      <p className="text-xs font-semibold text-orange-900 mb-1">🌐 Landing Page</p>
                      <p className="text-sm text-black">{offer.howToPresent.landingPage}</p>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Launch Plan Section */}
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-green-600" />
            <CardTitle className="text-black">7-Day Micro-Launch Plan</CardTitle>
          </div>
          <CardDescription className="text-black">
            For your best offer: {offers[bestOffer]?.title}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {launchPlan.map((day, index: number) => (
              <div
                key={index}
                className="flex gap-4 p-3 rounded-lg bg-white border border-green-200"
              >
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-green-600 text-white font-bold">
                    {day.day}
                  </div>
                </div>
                <div className="flex-1 space-y-1">
                  <p className="font-semibold text-black">{day.task}</p>
                  <p className="text-sm text-black">{day.action}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
