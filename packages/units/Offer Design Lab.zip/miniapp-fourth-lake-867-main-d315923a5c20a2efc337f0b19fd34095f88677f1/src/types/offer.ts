export interface BusinessInfo {
  product: string;
  customer: string;
  channel: string;
  currentOffer: string;
}

export interface Diagnosis {
  summary: string;
  missing: string[];
}

export interface OfferOption {
  title: string;
  type: string;
  wording: string;
  bestFor: string;
  howToPresent: {
    signage?: string;
    socialPost?: string;
    dm?: string;
    landingPage?: string;
  };
}

export interface LaunchPlan {
  day: number;
  task: string;
  action: string;
}

export interface OfferResults {
  diagnosis: Diagnosis;
  offers: OfferOption[];
  launchPlan: LaunchPlan[];
  bestOffer: number;
}
