/**
 * Contract Addresses Route for Ohara SDK
 * 
 * Handles contract address retrieval and on-demand deployment for miniapps.
 * 
 * Key features:
 * - Uses assureContractsDeployed() to deploy missing contracts automatically
 * - Uses NEXT_PUBLIC_SDK_CHAIN_ID from environment (chainId parameter optional)
 * - Returns deployment status for debugging
 * 
 * The OharaAiWagmiProvider automatically calls:
 * GET /api/sdk/addresses
 */

import {
  getContracts,
  getControllerAddress,
  assureContractsDeployed,
} from '@ohara-ai/sdk/server'
import { NextResponse } from 'next/server'

// Mark this route as dynamic
export const dynamic = 'force-dynamic'

/**
 * GET /api/sdk/addresses
 * Returns contract addresses for the configured chain
 * 
 * Uses NEXT_PUBLIC_SDK_CHAIN_ID from environment configuration.
 * This route ensures that required contracts (Score, Match) are deployed
 * before returning addresses. If contracts don't exist, they will be
 * deployed automatically.
 */
export async function GET() {
  try {
    // Ensure contracts are deployed before returning addresses
    const deployResult = await assureContractsDeployed()
    
    if (!deployResult.success) {
      console.error(
        '[addresses route] Contract deployment had failures:',
        deployResult.message,
      )
    }

    const controllerAddress = await getControllerAddress()
    
    // Get contract addresses from storage or api (will include newly deployed contracts)
    const addresses = await getContracts()
    
    // Merge controller address into app context
    const responseData = {
      addresses: {
        ...addresses,
        app: {
          ...addresses.app,
          controller: controllerAddress,
        },
      },
    }

    return NextResponse.json(responseData)
  } catch (error) {
    console.error('Error fetching contract addresses:', error)
    return NextResponse.json(
      {
        error: 'Failed to fetch contract addresses',
        details: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 },
    )
  }
}