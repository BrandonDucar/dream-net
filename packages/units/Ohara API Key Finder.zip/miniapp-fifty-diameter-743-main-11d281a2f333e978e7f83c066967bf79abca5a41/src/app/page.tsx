import Image from "next/image";

export default function Page() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-4 sm:p-8 bg-black relative">
      <div className="relative z-10 flex flex-col items-center">
        <div className="mb-2">
          <Image
            src="https://ohara-assets.s3.us-east-2.amazonaws.com/modu-standing.png"
            alt=""
            width={200}
            height={200}
            className="sm:w-[300px] sm:h-[300px]"
          />
        </div>
        <h1 className="text-2xl sm:text-4xl font-bold text-white mb-4 text-center">
          Your mini-app will appear here once you start building!
        </h1>
        <p className="text-base sm:text-lg text-gray-300 mb-6 sm:mb-8 text-center max-w-sm sm:max-w-md">
          Continue chatting with Modu to flesh out your idea — then when you’re ready, flip the toggle below to build mode and ask Modu to build!
        </p>
      </div>
    </main>
  );
}
