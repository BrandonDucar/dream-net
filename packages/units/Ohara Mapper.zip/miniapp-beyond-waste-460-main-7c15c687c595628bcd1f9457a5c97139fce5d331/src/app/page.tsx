'use client'
import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { TerritoryService } from '@/services/territoryService';
import { WorldMap } from '@/components/territory/WorldMap';
import { TerritoryNodeForm } from '@/components/territory/TerritoryNodeForm';
import { RegionForm } from '@/components/territory/RegionForm';
import { ZoneForm } from '@/components/territory/ZoneForm';
import { CorridorForm } from '@/components/territory/CorridorForm';
import { ExpansionZoneForm } from '@/components/territory/ExpansionZoneForm';
import { PopulationForm } from '@/components/territory/PopulationForm';
import { FlowTrafficForm } from '@/components/territory/FlowTrafficForm';
import type {
  TerritoryNode,
  Region,
  Zone,
  Corridor,
  ExpansionZone,
  PopulationMarker,
  FlowTraffic,
  ImportanceLevel,
  CorridorType,
  CorridorStrength,
  FlowType,
  FlowMagnitude,
  PopulationRole
} from '@/types/territory';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DreamNetTerritoryManager(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [service] = useState<TerritoryService>(() => new TerritoryService());
  const [nodes, setNodes] = useState<TerritoryNode[]>([]);
  const [regions, setRegions] = useState<Region[]>([]);
  const [zones, setZones] = useState<Zone[]>([]);
  const [corridors, setCorridors] = useState<Corridor[]>([]);
  const [expansionZones, setExpansionZones] = useState<ExpansionZone[]>([]);
  const [populationMarkers, setPopulationMarkers] = useState<PopulationMarker[]>([]);
  const [flowTraffic, setFlowTraffic] = useState<FlowTraffic[]>([]);
  
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [showNodeForm, setShowNodeForm] = useState<boolean>(false);
  const [showRegionForm, setShowRegionForm] = useState<boolean>(false);
  const [showZoneForm, setShowZoneForm] = useState<boolean>(false);
  const [showCorridorForm, setShowCorridorForm] = useState<boolean>(false);
  const [showExpansionZoneForm, setShowExpansionZoneForm] = useState<boolean>(false);
  const [showPopulationForm, setShowPopulationForm] = useState<boolean>(false);
  const [showFlowTrafficForm, setShowFlowTrafficForm] = useState<boolean>(false);
  
  const [editingNode, setEditingNode] = useState<TerritoryNode | null>(null);
  const [editingRegion, setEditingRegion] = useState<Region | null>(null);
  const [editingZone, setEditingZone] = useState<Zone | null>(null);
  const [editingCorridor, setEditingCorridor] = useState<Corridor | null>(null);
  const [editingExpansionZone, setEditingExpansionZone] = useState<ExpansionZone | null>(null);
  const [editingPopulation, setEditingPopulation] = useState<PopulationMarker | null>(null);
  const [editingFlowTraffic, setEditingFlowTraffic] = useState<FlowTraffic | null>(null);

  const [territoryMapText, setTerritoryMapText] = useState<string>('');
  const [showTerritoryMap, setShowTerritoryMap] = useState<boolean>(false);

  const loadData = (): void => {
    const data = service.getAllData();
    setNodes(data.nodes);
    setRegions(data.regions);
    setZones(data.zones);
    setCorridors(data.corridors);
    setExpansionZones(data.expansionZones);
    setPopulationMarkers(data.populationMarkers);
    setFlowTraffic(data.flowTraffic);
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleNodeSubmit = (data: {
    name: string;
    category: string;
    miniAppId?: string;
    description: string;
    importanceLevel: ImportanceLevel;
    regionId?: string;
    zoneId?: string;
    x: number;
    y: number;
    tags: string[];
    notes: string;
  }): void => {
    if (editingNode) {
      service.updateTerritoryNode(editingNode.id, data);
    } else {
      service.registerTerritoryNode(data);
    }
    loadData();
    setShowNodeForm(false);
    setEditingNode(null);
  };

  const handleRegionSubmit = (data: {
    name: string;
    description: string;
    colorHex: string;
    importanceLevel: ImportanceLevel;
    tags: string[];
    notes: string;
  }): void => {
    if (editingRegion) {
      service.updateRegion(editingRegion.id, data);
    } else {
      service.createRegion(data);
    }
    loadData();
    setShowRegionForm(false);
    setEditingRegion(null);
  };

  const handleZoneSubmit = (data: {
    name: string;
    description: string;
    colorHex: string;
    parentRegionId?: string;
    tags: string[];
    notes: string;
  }): void => {
    if (editingZone) {
      service.updateZone(editingZone.id, data);
    } else {
      service.createZone(data);
    }
    loadData();
    setShowZoneForm(false);
    setEditingZone(null);
  };

  const handleCorridorSubmit = (data: {
    name: string;
    fromNodeId: string;
    toNodeId: string;
    corridorType: CorridorType;
    strength: CorridorStrength;
    description: string;
    tags: string[];
    notes: string;
  }): void => {
    if (editingCorridor) {
      service.updateCorridor(editingCorridor.id, data);
    } else {
      service.createCorridor(data);
    }
    loadData();
    setShowCorridorForm(false);
    setEditingCorridor(null);
  };

  const handleExpansionZoneSubmit = (data: {
    name: string;
    description: string;
    suggestedMiniAppTypes: string[];
    coordinates: number[];
    tags: string[];
    notes: string;
  }): void => {
    if (editingExpansionZone) {
      service.updateExpansionZone(editingExpansionZone.id, data);
    } else {
      service.createExpansionZone(data);
    }
    loadData();
    setShowExpansionZoneForm(false);
    setEditingExpansionZone(null);
  };

  const handlePopulationSubmit = (data: {
    identityId: string;
    identityName: string;
    locatedInNodeId: string;
    role: PopulationRole;
    notes: string;
  }): void => {
    if (editingPopulation) {
      service.updatePopulationMarker(editingPopulation.id, data);
    } else {
      service.placePopulation(data);
    }
    loadData();
    setShowPopulationForm(false);
    setEditingPopulation(null);
  };

  const handleFlowTrafficSubmit = (data: {
    fromNodeId: string;
    toNodeId: string;
    flowType: FlowType;
    magnitude: FlowMagnitude;
    notes: string;
  }): void => {
    if (editingFlowTraffic) {
      service.updateFlowTraffic(editingFlowTraffic.id, data);
    } else {
      service.recordFlowTraffic(data);
    }
    loadData();
    setShowFlowTrafficForm(false);
    setEditingFlowTraffic(null);
  };

  const handleNodeDrag = (nodeId: string, x: number, y: number): void => {
    service.setNodeCoordinates(nodeId, x, y);
    loadData();
  };

  const handleDeleteNode = (nodeId: string): void => {
    if (confirm('Delete this territory node?')) {
      service.deleteTerritoryNode(nodeId);
      loadData();
      setSelectedNodeId(null);
    }
  };

  const handleDeleteRegion = (regionId: string): void => {
    if (confirm('Delete this region?')) {
      service.deleteRegion(regionId);
      loadData();
    }
  };

  const handleDeleteZone = (zoneId: string): void => {
    if (confirm('Delete this zone?')) {
      service.deleteZone(zoneId);
      loadData();
    }
  };

  const handleDeleteCorridor = (corridorId: string): void => {
    if (confirm('Delete this corridor?')) {
      service.deleteCorridor(corridorId);
      loadData();
    }
  };

  const handleDeleteExpansionZone = (expansionZoneId: string): void => {
    if (confirm('Delete this expansion zone?')) {
      service.deleteExpansionZone(expansionZoneId);
      loadData();
    }
  };

  const handleDeletePopulation = (populationId: string): void => {
    if (confirm('Delete this population marker?')) {
      service.deletePopulationMarker(populationId);
      loadData();
    }
  };

  const handleDeleteFlowTraffic = (flowTrafficId: string): void => {
    if (confirm('Delete this flow traffic record?')) {
      service.deleteFlowTraffic(flowTrafficId);
      loadData();
    }
  };

  const generateTerritoryMap = (): void => {
    const mapText = service.generateTerritoryMap();
    setTerritoryMapText(mapText);
    setShowTerritoryMap(true);
  };

  const exportTerritoryBrief = (): void => {
    const brief = service.exportTerritoryBrief();
    const blob = new Blob([brief], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dreamnet-territory-brief-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getNodeName = (nodeId: string): string => {
    const node = nodes.find((n: TerritoryNode) => n.id === nodeId);
    return node ? node.name : 'Unknown';
  };

  const getRegionName = (regionId: string | null): string => {
    if (!regionId) return 'None';
    const region = regions.find((r: Region) => r.id === regionId);
    return region ? region.name : 'Unknown';
  };

  const getZoneName = (zoneId: string | null): string => {
    if (!zoneId) return 'None';
    const zone = zones.find((z: Zone) => z.id === zoneId);
    return zone ? zone.name : 'Unknown';
  };

  const selectedNode = selectedNodeId ? nodes.find((n: TerritoryNode) => n.id === selectedNodeId) : null;
  const selectedNodeDetail = selectedNodeId ? service.getTerritoryDetail(selectedNodeId) : null;

  return (
    <div className="min-h-screen bg-black text-white p-4 md:p-8">
      <div className="max-w-[1600px] mx-auto space-y-6">
        <div className="text-center space-y-2 mb-8">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
            DreamNet Territory Manager
          </h1>
          <p className="text-gray-400 text-lg">Ohara Megastructure Mapper</p>
          <p className="text-gray-500 text-sm">Transforming mini-apps into sovereign territory</p>
        </div>

        <Tabs defaultValue="map" className="w-full">
          <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8 bg-gray-900">
            <TabsTrigger value="map">Map</TabsTrigger>
            <TabsTrigger value="territories">Territories</TabsTrigger>
            <TabsTrigger value="regions">Regions</TabsTrigger>
            <TabsTrigger value="zones">Zones</TabsTrigger>
            <TabsTrigger value="corridors">Corridors</TabsTrigger>
            <TabsTrigger value="expansion">Expansion</TabsTrigger>
            <TabsTrigger value="population">Population</TabsTrigger>
            <TabsTrigger value="traffic">Traffic</TabsTrigger>
          </TabsList>

          <TabsContent value="map" className="mt-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>Ohara World Map</CardTitle>
                <CardDescription>Visual representation of your DreamNet territory</CardDescription>
                <div className="flex flex-wrap gap-2 pt-4">
                  <Button onClick={() => { setEditingNode(null); setShowNodeForm(true); }}>
                    Add Territory
                  </Button>
                  <Button onClick={() => { setEditingRegion(null); setShowRegionForm(true); }} variant="outline">
                    Add Region
                  </Button>
                  <Button onClick={() => { setEditingZone(null); setShowZoneForm(true); }} variant="outline">
                    Add Zone
                  </Button>
                  <Button onClick={() => { setEditingCorridor(null); setShowCorridorForm(true); }} variant="outline">
                    Add Corridor
                  </Button>
                  <Button onClick={generateTerritoryMap} variant="outline">
                    Generate Map Text
                  </Button>
                  <Button onClick={exportTerritoryBrief} variant="outline">
                    Export Brief
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-950 rounded-lg p-4">
                  <WorldMap
                    nodes={nodes}
                    regions={regions}
                    zones={zones}
                    corridors={corridors}
                    selectedNodeId={selectedNodeId}
                    onNodeClick={setSelectedNodeId}
                    onNodeDrag={handleNodeDrag}
                  />
                </div>

                {selectedNode && selectedNodeDetail && (
                  <Card className="mt-4 bg-gray-800 border-gray-700">
                    <CardHeader>
                      <CardTitle>{selectedNode.name}</CardTitle>
                      <CardDescription>{selectedNode.category}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-gray-400">Importance</p>
                          <Badge>{selectedNode.importanceLevel}</Badge>
                        </div>
                        <div>
                          <p className="text-gray-400">Region</p>
                          <p>{getRegionName(selectedNode.regionId)}</p>
                        </div>
                        <div>
                          <p className="text-gray-400">Zone</p>
                          <p>{getZoneName(selectedNode.zoneId)}</p>
                        </div>
                        <div>
                          <p className="text-gray-400">Coordinates</p>
                          <p>({selectedNode.x.toFixed(0)}, {selectedNode.y.toFixed(0)})</p>
                        </div>
                      </div>

                      {selectedNode.description && (
                        <div>
                          <p className="text-gray-400 text-sm">Description</p>
                          <p className="text-sm">{selectedNode.description}</p>
                        </div>
                      )}

                      {selectedNode.tags.length > 0 && (
                        <div>
                          <p className="text-gray-400 text-sm mb-2">Tags</p>
                          <div className="flex flex-wrap gap-1">
                            {selectedNode.tags.map((tag: string, i: number) => (
                              <Badge key={i} variant="outline">{tag}</Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {selectedNodeDetail.neighbors.length > 0 && (
                        <div>
                          <p className="text-gray-400 text-sm mb-2">Neighbors</p>
                          <div className="flex flex-wrap gap-1">
                            {selectedNodeDetail.neighbors.map((neighbor: TerritoryNode) => (
                              <Badge key={neighbor.id} variant="secondary">{neighbor.name}</Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {selectedNodeDetail.corridors.length > 0 && (
                        <div>
                          <p className="text-gray-400 text-sm mb-2">Corridors</p>
                          <div className="space-y-1 text-sm">
                            {selectedNodeDetail.corridors.map((corridor: Corridor) => (
                              <div key={corridor.id}>
                                {corridor.fromNodeId === selectedNodeId ? '→' : '←'} {corridor.name}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {selectedNodeDetail.populationMarkers.length > 0 && (
                        <div>
                          <p className="text-gray-400 text-sm mb-2">Population ({selectedNodeDetail.populationMarkers.length})</p>
                          <div className="space-y-1 text-sm">
                            {selectedNodeDetail.populationMarkers.map((marker: PopulationMarker) => (
                              <div key={marker.id}>
                                {marker.identityName} ({marker.role})
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="flex gap-2 pt-2">
                        <Button size="sm" onClick={() => { setEditingNode(selectedNode); setShowNodeForm(true); }}>
                          Edit
                        </Button>
                        <Button size="sm" variant="destructive" onClick={() => handleDeleteNode(selectedNode.id)}>
                          Delete
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="territories" className="mt-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>Territory Nodes ({nodes.length})</CardTitle>
                <CardDescription>All registered territories in the megastructure</CardDescription>
                <Button onClick={() => { setEditingNode(null); setShowNodeForm(true); }}>
                  Add Territory Node
                </Button>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px]">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Importance</TableHead>
                        <TableHead>Region</TableHead>
                        <TableHead>Zone</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {nodes.map((node: TerritoryNode) => (
                        <TableRow key={node.id}>
                          <TableCell className="font-medium">{node.name}</TableCell>
                          <TableCell>{node.category}</TableCell>
                          <TableCell>
                            <Badge>{node.importanceLevel}</Badge>
                          </TableCell>
                          <TableCell>{getRegionName(node.regionId)}</TableCell>
                          <TableCell>{getZoneName(node.zoneId)}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button size="sm" variant="outline" onClick={() => { setEditingNode(node); setShowNodeForm(true); }}>
                                Edit
                              </Button>
                              <Button size="sm" variant="destructive" onClick={() => handleDeleteNode(node.id)}>
                                Delete
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="regions" className="mt-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>Regions ({regions.length})</CardTitle>
                <CardDescription>Large-scale territorial divisions</CardDescription>
                <Button onClick={() => { setEditingRegion(null); setShowRegionForm(true); }}>
                  Add Region
                </Button>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px]">
                  <div className="space-y-4">
                    {regions.map((region: Region) => (
                      <Card key={region.id} className="bg-gray-800 border-gray-700">
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-3">
                              <div 
                                className="w-6 h-6 rounded-md border-2 border-white"
                                style={{ backgroundColor: region.colorHex }}
                              />
                              <div>
                                <CardTitle className="text-lg">{region.name}</CardTitle>
                                <CardDescription>{region.description}</CardDescription>
                              </div>
                            </div>
                            <Badge>{region.importanceLevel}</Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <p className="text-sm text-gray-400">
                              Territories: {region.territoryNodeIds.length}
                            </p>
                            {region.tags.length > 0 && (
                              <div className="flex flex-wrap gap-1">
                                {region.tags.map((tag: string, i: number) => (
                                  <Badge key={i} variant="outline">{tag}</Badge>
                                ))}
                              </div>
                            )}
                            <div className="flex gap-2 pt-2">
                              <Button size="sm" variant="outline" onClick={() => { setEditingRegion(region); setShowRegionForm(true); }}>
                                Edit
                              </Button>
                              <Button size="sm" variant="destructive" onClick={() => handleDeleteRegion(region.id)}>
                                Delete
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="zones" className="mt-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>Zones ({zones.length})</CardTitle>
                <CardDescription>Specialized districts and corridors</CardDescription>
                <Button onClick={() => { setEditingZone(null); setShowZoneForm(true); }}>
                  Add Zone
                </Button>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px]">
                  <div className="space-y-4">
                    {zones.map((zone: Zone) => (
                      <Card key={zone.id} className="bg-gray-800 border-gray-700">
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-3">
                              <div 
                                className="w-6 h-6 rounded-md border-2 border-white"
                                style={{ backgroundColor: zone.colorHex }}
                              />
                              <div>
                                <CardTitle className="text-lg">{zone.name}</CardTitle>
                                <CardDescription>{zone.description}</CardDescription>
                              </div>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            {zone.parentRegionId && (
                              <p className="text-sm text-gray-400">
                                Parent Region: {getRegionName(zone.parentRegionId)}
                              </p>
                            )}
                            <p className="text-sm text-gray-400">
                              Territories: {zone.territoryNodeIds.length}
                            </p>
                            {zone.tags.length > 0 && (
                              <div className="flex flex-wrap gap-1">
                                {zone.tags.map((tag: string, i: number) => (
                                  <Badge key={i} variant="outline">{tag}</Badge>
                                ))}
                              </div>
                            )}
                            <div className="flex gap-2 pt-2">
                              <Button size="sm" variant="outline" onClick={() => { setEditingZone(zone); setShowZoneForm(true); }}>
                                Edit
                              </Button>
                              <Button size="sm" variant="destructive" onClick={() => handleDeleteZone(zone.id)}>
                                Delete
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="corridors" className="mt-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>Corridors ({corridors.length})</CardTitle>
                <CardDescription>Connections and pathways between territories</CardDescription>
                <Button onClick={() => { setEditingCorridor(null); setShowCorridorForm(true); }}>
                  Add Corridor
                </Button>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px]">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>From</TableHead>
                        <TableHead>To</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Strength</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {corridors.map((corridor: Corridor) => (
                        <TableRow key={corridor.id}>
                          <TableCell className="font-medium">{corridor.name}</TableCell>
                          <TableCell>{getNodeName(corridor.fromNodeId)}</TableCell>
                          <TableCell>{getNodeName(corridor.toNodeId)}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{corridor.corridorType}</Badge>
                          </TableCell>
                          <TableCell>
                            <Badge>{corridor.strength}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button size="sm" variant="outline" onClick={() => { setEditingCorridor(corridor); setShowCorridorForm(true); }}>
                                Edit
                              </Button>
                              <Button size="sm" variant="destructive" onClick={() => handleDeleteCorridor(corridor.id)}>
                                Delete
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="expansion" className="mt-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>Expansion Zones ({expansionZones.length})</CardTitle>
                <CardDescription>Future territories and strategic opportunities</CardDescription>
                <Button onClick={() => { setEditingExpansionZone(null); setShowExpansionZoneForm(true); }}>
                  Add Expansion Zone
                </Button>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px]">
                  <div className="space-y-4">
                    {expansionZones.map((zone: ExpansionZone) => (
                      <Card key={zone.id} className="bg-gray-800 border-gray-700">
                        <CardHeader>
                          <CardTitle className="text-lg">{zone.name}</CardTitle>
                          <CardDescription>{zone.description}</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            {zone.suggestedMiniAppTypes.length > 0 && (
                              <div>
                                <p className="text-sm text-gray-400 mb-2">Suggested Types:</p>
                                <div className="flex flex-wrap gap-1">
                                  {zone.suggestedMiniAppTypes.map((type: string, i: number) => (
                                    <Badge key={i} variant="secondary">{type}</Badge>
                                  ))}
                                </div>
                              </div>
                            )}
                            {zone.tags.length > 0 && (
                              <div className="flex flex-wrap gap-1">
                                {zone.tags.map((tag: string, i: number) => (
                                  <Badge key={i} variant="outline">{tag}</Badge>
                                ))}
                              </div>
                            )}
                            <div className="flex gap-2 pt-2">
                              <Button size="sm" variant="outline" onClick={() => { setEditingExpansionZone(zone); setShowExpansionZoneForm(true); }}>
                                Edit
                              </Button>
                              <Button size="sm" variant="destructive" onClick={() => handleDeleteExpansionZone(zone.id)}>
                                Delete
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="population" className="mt-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>Population ({populationMarkers.length})</CardTitle>
                <CardDescription>Identities residing in territories</CardDescription>
                <Button onClick={() => { setEditingPopulation(null); setShowPopulationForm(true); }}>
                  Place Identity
                </Button>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px]">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Identity</TableHead>
                        <TableHead>Located In</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {populationMarkers.map((marker: PopulationMarker) => (
                        <TableRow key={marker.id}>
                          <TableCell className="font-medium">{marker.identityName}</TableCell>
                          <TableCell>{getNodeName(marker.locatedInNodeId)}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{marker.role}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button size="sm" variant="outline" onClick={() => { setEditingPopulation(marker); setShowPopulationForm(true); }}>
                                Edit
                              </Button>
                              <Button size="sm" variant="destructive" onClick={() => handleDeletePopulation(marker.id)}>
                                Delete
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="traffic" className="mt-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>Flow Traffic ({flowTraffic.length})</CardTitle>
                <CardDescription>Data and content flows between territories</CardDescription>
                <Button onClick={() => { setEditingFlowTraffic(null); setShowFlowTrafficForm(true); }}>
                  Record Flow Traffic
                </Button>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px]">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>From</TableHead>
                        <TableHead>To</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Magnitude</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {flowTraffic.map((flow: FlowTraffic) => (
                        <TableRow key={flow.id}>
                          <TableCell>{getNodeName(flow.fromNodeId)}</TableCell>
                          <TableCell>{getNodeName(flow.toNodeId)}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{flow.flowType}</Badge>
                          </TableCell>
                          <TableCell>
                            <Badge>{flow.magnitude}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button size="sm" variant="outline" onClick={() => { setEditingFlowTraffic(flow); setShowFlowTrafficForm(true); }}>
                                Edit
                              </Button>
                              <Button size="sm" variant="destructive" onClick={() => handleDeleteFlowTraffic(flow.id)}>
                                Delete
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={showNodeForm} onOpenChange={setShowNodeForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-gray-900 text-white">
          <DialogHeader>
            <DialogTitle>{editingNode ? 'Edit Territory Node' : 'Add Territory Node'}</DialogTitle>
          </DialogHeader>
          <TerritoryNodeForm
            node={editingNode}
            regions={regions}
            zones={zones}
            onSubmit={handleNodeSubmit}
            onCancel={() => { setShowNodeForm(false); setEditingNode(null); }}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={showRegionForm} onOpenChange={setShowRegionForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-gray-900 text-white">
          <DialogHeader>
            <DialogTitle>{editingRegion ? 'Edit Region' : 'Add Region'}</DialogTitle>
          </DialogHeader>
          <RegionForm
            region={editingRegion}
            onSubmit={handleRegionSubmit}
            onCancel={() => { setShowRegionForm(false); setEditingRegion(null); }}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={showZoneForm} onOpenChange={setShowZoneForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-gray-900 text-white">
          <DialogHeader>
            <DialogTitle>{editingZone ? 'Edit Zone' : 'Add Zone'}</DialogTitle>
          </DialogHeader>
          <ZoneForm
            zone={editingZone}
            regions={regions}
            onSubmit={handleZoneSubmit}
            onCancel={() => { setShowZoneForm(false); setEditingZone(null); }}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={showCorridorForm} onOpenChange={setShowCorridorForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-gray-900 text-white">
          <DialogHeader>
            <DialogTitle>{editingCorridor ? 'Edit Corridor' : 'Add Corridor'}</DialogTitle>
          </DialogHeader>
          <CorridorForm
            corridor={editingCorridor}
            nodes={nodes}
            onSubmit={handleCorridorSubmit}
            onCancel={() => { setShowCorridorForm(false); setEditingCorridor(null); }}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={showExpansionZoneForm} onOpenChange={setShowExpansionZoneForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-gray-900 text-white">
          <DialogHeader>
            <DialogTitle>{editingExpansionZone ? 'Edit Expansion Zone' : 'Add Expansion Zone'}</DialogTitle>
          </DialogHeader>
          <ExpansionZoneForm
            expansionZone={editingExpansionZone}
            onSubmit={handleExpansionZoneSubmit}
            onCancel={() => { setShowExpansionZoneForm(false); setEditingExpansionZone(null); }}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={showPopulationForm} onOpenChange={setShowPopulationForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-gray-900 text-white">
          <DialogHeader>
            <DialogTitle>{editingPopulation ? 'Edit Population Marker' : 'Place Identity'}</DialogTitle>
          </DialogHeader>
          <PopulationForm
            populationMarker={editingPopulation}
            nodes={nodes}
            onSubmit={handlePopulationSubmit}
            onCancel={() => { setShowPopulationForm(false); setEditingPopulation(null); }}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={showFlowTrafficForm} onOpenChange={setShowFlowTrafficForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-gray-900 text-white">
          <DialogHeader>
            <DialogTitle>{editingFlowTraffic ? 'Edit Flow Traffic' : 'Record Flow Traffic'}</DialogTitle>
          </DialogHeader>
          <FlowTrafficForm
            flowTraffic={editingFlowTraffic}
            nodes={nodes}
            onSubmit={handleFlowTrafficSubmit}
            onCancel={() => { setShowFlowTrafficForm(false); setEditingFlowTraffic(null); }}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={showTerritoryMap} onOpenChange={setShowTerritoryMap}>
        <DialogContent className="max-w-4xl max-h-[90vh] bg-gray-900 text-white">
          <DialogHeader>
            <DialogTitle>Territory Map</DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[70vh] w-full">
            <pre className="text-xs whitespace-pre-wrap font-mono bg-gray-950 p-4 rounded">
              {territoryMapText}
            </pre>
          </ScrollArea>
          <div className="flex gap-2">
            <Button 
              onClick={() => {
                navigator.clipboard.writeText(territoryMapText);
                alert('Map copied to clipboard!');
              }}
            >
              Copy to Clipboard
            </Button>
            <Button variant="outline" onClick={() => setShowTerritoryMap(false)}>
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
