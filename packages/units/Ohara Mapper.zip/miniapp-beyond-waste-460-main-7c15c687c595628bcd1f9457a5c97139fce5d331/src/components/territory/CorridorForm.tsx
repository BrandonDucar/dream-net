'use client';

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { Corridor, TerritoryNode, CorridorType, CorridorStrength } from '@/types/territory';

interface CorridorFormProps {
  corridor?: Corridor | null;
  nodes: TerritoryNode[];
  onSubmit: (data: {
    name: string;
    fromNodeId: string;
    toNodeId: string;
    corridorType: CorridorType;
    strength: CorridorStrength;
    description: string;
    tags: string[];
    notes: string;
  }) => void;
  onCancel: () => void;
}

export function CorridorForm({ corridor, nodes, onSubmit, onCancel }: CorridorFormProps): JSX.Element {
  const [name, setName] = useState<string>(corridor?.name || '');
  const [fromNodeId, setFromNodeId] = useState<string>(corridor?.fromNodeId || '');
  const [toNodeId, setToNodeId] = useState<string>(corridor?.toNodeId || '');
  const [corridorType, setCorridorType] = useState<CorridorType>(corridor?.corridorType || 'mixed');
  const [strength, setStrength] = useState<CorridorStrength>(corridor?.strength || 'normal');
  const [description, setDescription] = useState<string>(corridor?.description || '');
  const [tags, setTags] = useState<string>(corridor?.tags.join(', ') || '');
  const [notes, setNotes] = useState<string>(corridor?.notes || '');

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    if (!fromNodeId || !toNodeId) return;
    
    onSubmit({
      name,
      fromNodeId,
      toNodeId,
      corridorType,
      strength,
      description,
      tags: tags.split(',').map((t: string) => t.trim()).filter((t: string) => t),
      notes
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-6">
      <div className="space-y-2">
        <Label htmlFor="name">Corridor Name *</Label>
        <Input
          id="name"
          value={name}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
          placeholder="e.g. Culture-to-Drop Corridor"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="fromNode">From Node *</Label>
        <Select value={fromNodeId} onValueChange={setFromNodeId} required>
          <SelectTrigger id="fromNode">
            <SelectValue placeholder="Select source node..." />
          </SelectTrigger>
          <SelectContent>
            {nodes.map((node: TerritoryNode) => (
              <SelectItem key={node.id} value={node.id}>
                {node.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="toNode">To Node *</Label>
        <Select value={toNodeId} onValueChange={setToNodeId} required>
          <SelectTrigger id="toNode">
            <SelectValue placeholder="Select destination node..." />
          </SelectTrigger>
          <SelectContent>
            {nodes.map((node: TerritoryNode) => (
              <SelectItem key={node.id} value={node.id}>
                {node.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="type">Corridor Type</Label>
        <Select value={corridorType} onValueChange={(value: string) => setCorridorType(value as CorridorType)}>
          <SelectTrigger id="type">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="data-flow">Data Flow</SelectItem>
            <SelectItem value="creative-flow">Creative Flow</SelectItem>
            <SelectItem value="ops-flow">Ops Flow</SelectItem>
            <SelectItem value="social-flow">Social Flow</SelectItem>
            <SelectItem value="narrative-flow">Narrative Flow</SelectItem>
            <SelectItem value="pickleball-flow">Pickleball Flow</SelectItem>
            <SelectItem value="mixed">Mixed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="strength">Strength</Label>
        <Select value={strength} onValueChange={(value: string) => setStrength(value as CorridorStrength)}>
          <SelectTrigger id="strength">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="weak">Weak</SelectItem>
            <SelectItem value="normal">Normal</SelectItem>
            <SelectItem value="strong">Strong</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={description}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
          placeholder="Describe this corridor..."
          rows={3}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="tags">Tags (comma-separated)</Label>
        <Input
          id="tags"
          value={tags}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTags(e.target.value)}
          placeholder="transit, critical, high-traffic"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          value={notes}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNotes(e.target.value)}
          placeholder="Additional notes..."
          rows={3}
        />
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" className="flex-1">
          {corridor ? 'Update Corridor' : 'Create Corridor'}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
