'use client';

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import type { ExpansionZone } from '@/types/territory';

interface ExpansionZoneFormProps {
  expansionZone?: ExpansionZone | null;
  onSubmit: (data: {
    name: string;
    description: string;
    suggestedMiniAppTypes: string[];
    coordinates: number[];
    tags: string[];
    notes: string;
  }) => void;
  onCancel: () => void;
}

export function ExpansionZoneForm({ expansionZone, onSubmit, onCancel }: ExpansionZoneFormProps): JSX.Element {
  const [name, setName] = useState<string>(expansionZone?.name || '');
  const [description, setDescription] = useState<string>(expansionZone?.description || '');
  const [suggestedTypes, setSuggestedTypes] = useState<string>(
    expansionZone?.suggestedMiniAppTypes.join(', ') || ''
  );
  const [coordinates, setCoordinates] = useState<string>(
    expansionZone?.coordinates.join(', ') || ''
  );
  const [tags, setTags] = useState<string>(expansionZone?.tags.join(', ') || '');
  const [notes, setNotes] = useState<string>(expansionZone?.notes || '');

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    onSubmit({
      name,
      description,
      suggestedMiniAppTypes: suggestedTypes.split(',').map((t: string) => t.trim()).filter((t: string) => t),
      coordinates: coordinates.split(',').map((c: string) => parseFloat(c.trim())).filter((c: number) => !isNaN(c)),
      tags: tags.split(',').map((t: string) => t.trim()).filter((t: string) => t),
      notes
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-6">
      <div className="space-y-2">
        <Label htmlFor="name">Expansion Zone Name *</Label>
        <Input
          id="name"
          value={name}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
          placeholder="e.g. Unclaimed East"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description *</Label>
        <Textarea
          id="description"
          value={description}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
          placeholder="Describe this expansion zone..."
          rows={3}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="suggestedTypes">Suggested Mini-App Types (comma-separated)</Label>
        <Input
          id="suggestedTypes"
          value={suggestedTypes}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSuggestedTypes(e.target.value)}
          placeholder="e.g. culture, pickleball, social"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="coordinates">Coordinates (comma-separated numbers)</Label>
        <Input
          id="coordinates"
          value={coordinates}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCoordinates(e.target.value)}
          placeholder="e.g. 100, 200, 300, 400"
        />
        <p className="text-xs text-gray-500">Optional: rough bounding box or polygon coordinates</p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="tags">Tags (comma-separated)</Label>
        <Input
          id="tags"
          value={tags}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTags(e.target.value)}
          placeholder="future, expansion, strategic"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          value={notes}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNotes(e.target.value)}
          placeholder="Additional notes..."
          rows={3}
        />
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" className="flex-1">
          {expansionZone ? 'Update Expansion Zone' : 'Create Expansion Zone'}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
