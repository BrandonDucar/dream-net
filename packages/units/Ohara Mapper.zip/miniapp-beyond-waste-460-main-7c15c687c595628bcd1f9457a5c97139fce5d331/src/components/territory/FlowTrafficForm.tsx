'use client';

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { FlowTraffic, TerritoryNode, FlowType, FlowMagnitude } from '@/types/territory';

interface FlowTrafficFormProps {
  flowTraffic?: FlowTraffic | null;
  nodes: TerritoryNode[];
  onSubmit: (data: {
    fromNodeId: string;
    toNodeId: string;
    flowType: FlowType;
    magnitude: FlowMagnitude;
    notes: string;
  }) => void;
  onCancel: () => void;
}

export function FlowTrafficForm({ flowTraffic, nodes, onSubmit, onCancel }: FlowTrafficFormProps): JSX.Element {
  const [fromNodeId, setFromNodeId] = useState<string>(flowTraffic?.fromNodeId || '');
  const [toNodeId, setToNodeId] = useState<string>(flowTraffic?.toNodeId || '');
  const [flowType, setFlowType] = useState<FlowType>(flowTraffic?.flowType || 'content');
  const [magnitude, setMagnitude] = useState<FlowMagnitude>(flowTraffic?.magnitude || 'medium');
  const [notes, setNotes] = useState<string>(flowTraffic?.notes || '');

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    if (!fromNodeId || !toNodeId) return;
    
    onSubmit({
      fromNodeId,
      toNodeId,
      flowType,
      magnitude,
      notes
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-6">
      <div className="space-y-2">
        <Label htmlFor="fromNode">From Node *</Label>
        <Select value={fromNodeId} onValueChange={setFromNodeId} required>
          <SelectTrigger id="fromNode">
            <SelectValue placeholder="Select source node..." />
          </SelectTrigger>
          <SelectContent>
            {nodes.map((node: TerritoryNode) => (
              <SelectItem key={node.id} value={node.id}>
                {node.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="toNode">To Node *</Label>
        <Select value={toNodeId} onValueChange={setToNodeId} required>
          <SelectTrigger id="toNode">
            <SelectValue placeholder="Select destination node..." />
          </SelectTrigger>
          <SelectContent>
            {nodes.map((node: TerritoryNode) => (
              <SelectItem key={node.id} value={node.id}>
                {node.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="flowType">Flow Type</Label>
        <Select value={flowType} onValueChange={(value: string) => setFlowType(value as FlowType)}>
          <SelectTrigger id="flowType">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="content">Content</SelectItem>
            <SelectItem value="drops">Drops</SelectItem>
            <SelectItem value="scripts">Scripts</SelectItem>
            <SelectItem value="ops">Ops</SelectItem>
            <SelectItem value="pickleball">Pickleball</SelectItem>
            <SelectItem value="culture">Culture</SelectItem>
            <SelectItem value="other">Other</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="magnitude">Magnitude</Label>
        <Select value={magnitude} onValueChange={(value: string) => setMagnitude(value as FlowMagnitude)}>
          <SelectTrigger id="magnitude">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="low">Low</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="high">High</SelectItem>
            <SelectItem value="extreme">Extreme</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          value={notes}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNotes(e.target.value)}
          placeholder="Additional notes..."
          rows={3}
        />
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" className="flex-1">
          {flowTraffic ? 'Update Flow Traffic' : 'Record Flow Traffic'}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
