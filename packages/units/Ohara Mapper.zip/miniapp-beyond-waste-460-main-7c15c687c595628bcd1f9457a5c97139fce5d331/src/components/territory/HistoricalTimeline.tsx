'use client'
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { HistoricalEvent, TerritoryNode, Region, Zone, Corridor } from '@/types/territory';

interface HistoricalTimelineProps {
  events: HistoricalEvent[];
  nodes: TerritoryNode[];
  regions: Region[];
  zones: Zone[];
  corridors: Corridor[];
  onCreateEvent: (params: {
    eventType: string;
    title: string;
    description: string;
    relatedEntityType: "node" | "region" | "zone" | "corridor" | "general";
    relatedEntityId: string | null;
    eventDate: string;
    tags: string[];
  }) => void;
  onDeleteEvent: (id: string) => void;
}

export function HistoricalTimeline({
  events,
  nodes,
  regions,
  zones,
  corridors,
  onCreateEvent,
  onDeleteEvent
}: HistoricalTimelineProps): JSX.Element {
  const [formData, setFormData] = useState({
    eventType: 'territory-founded',
    title: '',
    description: '',
    relatedEntityType: 'general' as "node" | "region" | "zone" | "corridor" | "general",
    relatedEntityId: '',
    eventDate: new Date().toISOString().split('T')[0],
    tags: ''
  });

  const handleSubmit = (): void => {
    if (!formData.title || !formData.description) {
      alert('Please fill in title and description');
      return;
    }

    onCreateEvent({
      ...formData,
      relatedEntityId: formData.relatedEntityId || null,
      tags: formData.tags.split(',').map(t => t.trim()).filter(Boolean)
    });

    setFormData({
      eventType: 'territory-founded',
      title: '',
      description: '',
      relatedEntityType: 'general',
      relatedEntityId: '',
      eventDate: new Date().toISOString().split('T')[0],
      tags: ''
    });
  };

  const sortedEvents = [...events].sort((a, b) => 
    new Date(b.eventDate).getTime() - new Date(a.eventDate).getTime()
  );

  const getEntityName = (event: HistoricalEvent): string => {
    if (!event.relatedEntityId) return 'General Event';
    
    switch (event.relatedEntityType) {
      case 'node':
        return nodes.find(n => n.id === event.relatedEntityId)?.name || 'Unknown Node';
      case 'region':
        return regions.find(r => r.id === event.relatedEntityId)?.name || 'Unknown Region';
      case 'zone':
        return zones.find(z => z.id === event.relatedEntityId)?.name || 'Unknown Zone';
      case 'corridor':
        return corridors.find(c => c.id === event.relatedEntityId)?.name || 'Unknown Corridor';
      default:
        return 'General';
    }
  };

  const getEventTypeEmoji = (eventType: string): string => {
    const emojis: Record<string, string> = {
      'territory-founded': '🏗️',
      'territory-upgraded': '⬆️',
      'corridor-opened': '🛤️',
      'alliance-formed': '🤝',
      'conflict': '⚔️',
      'milestone': '🏆',
      'expansion': '📈',
      'population-growth': '👥',
      'resource-discovered': '💎',
      'crisis': '🚨'
    };
    return emojis[eventType] || '📌';
  };

  const getEntityOptions = (): React.ReactElement[] => {
    switch (formData.relatedEntityType) {
      case 'node':
        return nodes.map(n => (
          <SelectItem key={n.id} value={n.id}>{n.name}</SelectItem>
        ));
      case 'region':
        return regions.map(r => (
          <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>
        ));
      case 'zone':
        return zones.map(z => (
          <SelectItem key={z.id} value={z.id}>{z.name}</SelectItem>
        ));
      case 'corridor':
        return corridors.map(c => (
          <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
        ));
      default:
        return [<SelectItem key="none" value="">None</SelectItem>];
    }
  };

  return (
    <div className="space-y-6">
      {/* Form */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle>Record Historical Event</CardTitle>
          <CardDescription>Document key moments in DreamNet history</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Event Type</Label>
              <Select
                value={formData.eventType}
                onValueChange={(value: string) => setFormData({ ...formData, eventType: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="territory-founded">🏗️ Territory Founded</SelectItem>
                  <SelectItem value="territory-upgraded">⬆️ Territory Upgraded</SelectItem>
                  <SelectItem value="corridor-opened">🛤️ Corridor Opened</SelectItem>
                  <SelectItem value="alliance-formed">🤝 Alliance Formed</SelectItem>
                  <SelectItem value="conflict">⚔️ Conflict</SelectItem>
                  <SelectItem value="milestone">🏆 Milestone</SelectItem>
                  <SelectItem value="expansion">📈 Expansion</SelectItem>
                  <SelectItem value="population-growth">👥 Population Growth</SelectItem>
                  <SelectItem value="resource-discovered">💎 Resource Discovered</SelectItem>
                  <SelectItem value="crisis">🚨 Crisis</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Event Date</Label>
              <Input
                type="date"
                value={formData.eventDate}
                onChange={(e) => setFormData({ ...formData, eventDate: e.target.value })}
              />
            </div>

            <div>
              <Label>Related To</Label>
              <Select
                value={formData.relatedEntityType}
                onValueChange={(value: "node" | "region" | "zone" | "corridor" | "general") => 
                  setFormData({ ...formData, relatedEntityType: value, relatedEntityId: '' })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="general">General Event</SelectItem>
                  <SelectItem value="node">Territory Node</SelectItem>
                  <SelectItem value="region">Region</SelectItem>
                  <SelectItem value="zone">Zone</SelectItem>
                  <SelectItem value="corridor">Corridor</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.relatedEntityType !== 'general' && (
              <div>
                <Label>Select Entity</Label>
                <Select
                  value={formData.relatedEntityId}
                  onValueChange={(value: string) => setFormData({ ...formData, relatedEntityId: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select entity" />
                  </SelectTrigger>
                  <SelectContent>
                    {getEntityOptions()}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <div>
            <Label>Event Title</Label>
            <Input
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="e.g., CultureCoin Foundry Established"
            />
          </div>

          <div>
            <Label>Description</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe what happened..."
              rows={3}
            />
          </div>

          <div>
            <Label>Tags (comma-separated)</Label>
            <Input
              value={formData.tags}
              onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
              placeholder="founding, culture, expansion"
            />
          </div>

          <Button onClick={handleSubmit}>Record Event</Button>
        </CardContent>
      </Card>

      {/* Timeline */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle>DreamNet Timeline ({events.length} events)</CardTitle>
          <CardDescription>Historical record of your empire</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[600px] pr-4">
            {sortedEvents.length === 0 ? (
              <p className="text-center text-gray-400 py-8">No events recorded yet</p>
            ) : (
              <div className="space-y-4">
                {sortedEvents.map((event, index) => (
                  <div key={event.id} className="relative">
                    {/* Timeline line */}
                    {index !== sortedEvents.length - 1 && (
                      <div className="absolute left-6 top-12 bottom-0 w-0.5 bg-gray-700" />
                    )}

                    <Card className="bg-gray-900 border-gray-700">
                      <CardContent className="p-4">
                        <div className="flex gap-4">
                          {/* Emoji indicator */}
                          <div className="text-3xl flex-shrink-0">
                            {getEventTypeEmoji(event.eventType)}
                          </div>

                          <div className="flex-1 space-y-2">
                            {/* Header */}
                            <div className="flex items-start justify-between gap-2">
                              <div>
                                <h4 className="font-semibold text-lg">{event.title}</h4>
                                <p className="text-sm text-gray-400">
                                  {new Date(event.eventDate).toLocaleDateString('en-US', {
                                    year: 'numeric',
                                    month: 'long',
                                    day: 'numeric'
                                  })}
                                </p>
                              </div>
                              <Badge variant="outline">{event.eventType}</Badge>
                            </div>

                            {/* Description */}
                            <p className="text-sm text-gray-300">{event.description}</p>

                            {/* Entity link */}
                            {event.relatedEntityId && (
                              <div className="text-sm text-blue-400">
                                Related to: {getEntityName(event)}
                              </div>
                            )}

                            {/* Tags */}
                            {event.tags.length > 0 && (
                              <div className="flex flex-wrap gap-1">
                                {event.tags.map((tag, i) => (
                                  <Badge key={i} variant="secondary" className="text-xs">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>
                            )}

                            {/* Actions */}
                            <div className="pt-2">
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => onDeleteEvent(event.id)}
                              >
                                Delete
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
