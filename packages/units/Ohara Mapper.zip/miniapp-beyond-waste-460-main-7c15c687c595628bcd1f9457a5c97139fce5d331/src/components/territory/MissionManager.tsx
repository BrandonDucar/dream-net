'use client'
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import type { Mission, MissionStatus } from '@/types/territory';

interface MissionManagerProps {
  missions: Mission[];
  onCreateMission: (params: {
    title: string;
    description: string;
    missionType: string;
    targetMetric: string;
    targetValue: number;
    currentValue: number;
    status: MissionStatus;
    reward: string;
    startDate: string;
    notes: string;
  }) => void;
  onUpdateMission: (id: string, updates: Partial<Mission>) => void;
  onDeleteMission: (id: string) => void;
}

export function MissionManager({
  missions,
  onCreateMission,
  onUpdateMission,
  onDeleteMission
}: MissionManagerProps): JSX.Element {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    missionType: 'expansion',
    targetMetric: 'territory-count',
    targetValue: 10,
    currentValue: 0,
    status: 'active' as MissionStatus,
    reward: '',
    startDate: new Date().toISOString().split('T')[0],
    notes: ''
  });

  const handleSubmit = (): void => {
    if (!formData.title || !formData.description) {
      alert('Please fill in title and description');
      return;
    }

    if (editingId) {
      onUpdateMission(editingId, formData);
      setEditingId(null);
    } else {
      onCreateMission(formData);
    }

    setFormData({
      title: '',
      description: '',
      missionType: 'expansion',
      targetMetric: 'territory-count',
      targetValue: 10,
      currentValue: 0,
      status: 'active',
      reward: '',
      startDate: new Date().toISOString().split('T')[0],
      notes: ''
    });
  };

  const handleEdit = (mission: Mission): void => {
    setEditingId(mission.id);
    setFormData({
      title: mission.title,
      description: mission.description,
      missionType: mission.missionType,
      targetMetric: mission.targetMetric,
      targetValue: mission.targetValue,
      currentValue: mission.currentValue,
      status: mission.status,
      reward: mission.reward,
      startDate: mission.startDate.split('T')[0],
      notes: mission.notes
    });
  };

  const getStatusColor = (status: MissionStatus): string => {
    const colors: Record<MissionStatus, string> = {
      'active': 'bg-yellow-600',
      'completed': 'bg-green-600',
      'failed': 'bg-red-600'
    };
    return colors[status];
  };

  const activeMissions = missions.filter(m => m.status === 'active');
  const completedMissions = missions.filter(m => m.status === 'completed');
  const failedMissions = missions.filter(m => m.status === 'failed');

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-yellow-900/30 border-yellow-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-2xl">{activeMissions.length}</CardTitle>
            <CardDescription>Active Missions</CardDescription>
          </CardHeader>
        </Card>
        <Card className="bg-green-900/30 border-green-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-2xl">{completedMissions.length}</CardTitle>
            <CardDescription>Completed</CardDescription>
          </CardHeader>
        </Card>
        <Card className="bg-red-900/30 border-red-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-2xl">{failedMissions.length}</CardTitle>
            <CardDescription>Failed</CardDescription>
          </CardHeader>
        </Card>
      </div>

      {/* Form */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle>{editingId ? 'Edit' : 'Create'} Mission</CardTitle>
          <CardDescription>Define quests and achievements for your empire</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Mission Title</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="e.g., Establish 10 Territories"
              />
            </div>

            <div>
              <Label>Mission Type</Label>
              <Select
                value={formData.missionType}
                onValueChange={(value: string) => setFormData({ ...formData, missionType: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="expansion">Expansion</SelectItem>
                  <SelectItem value="connection">Connection</SelectItem>
                  <SelectItem value="population">Population</SelectItem>
                  <SelectItem value="alliance">Alliance</SelectItem>
                  <SelectItem value="infrastructure">Infrastructure</SelectItem>
                  <SelectItem value="milestone">Milestone</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Target Metric</Label>
              <Select
                value={formData.targetMetric}
                onValueChange={(value: string) => setFormData({ ...formData, targetMetric: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="territory-count">Territory Count</SelectItem>
                  <SelectItem value="corridor-count">Corridor Count</SelectItem>
                  <SelectItem value="population-count">Population Count</SelectItem>
                  <SelectItem value="alliance-count">Alliance Count</SelectItem>
                  <SelectItem value="vitality-score">Vitality Score</SelectItem>
                  <SelectItem value="dominance-score">Dominance Score</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: MissionStatus) => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="failed">Failed</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Target Value</Label>
              <Input
                type="number"
                value={formData.targetValue}
                onChange={(e) => setFormData({ ...formData, targetValue: parseInt(e.target.value) || 0 })}
              />
            </div>

            <div>
              <Label>Current Value</Label>
              <Input
                type="number"
                value={formData.currentValue}
                onChange={(e) => setFormData({ ...formData, currentValue: parseInt(e.target.value) || 0 })}
              />
            </div>

            <div>
              <Label>Reward</Label>
              <Input
                value={formData.reward}
                onChange={(e) => setFormData({ ...formData, reward: e.target.value })}
                placeholder="Badge, unlock, bonus..."
              />
            </div>

            <div>
              <Label>Start Date</Label>
              <Input
                type="date"
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
              />
            </div>
          </div>

          <div>
            <Label>Description</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Mission details..."
              rows={3}
            />
          </div>

          <div>
            <Label>Notes</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Additional notes..."
              rows={2}
            />
          </div>

          <div className="flex gap-2">
            <Button onClick={handleSubmit}>
              {editingId ? 'Update' : 'Create'} Mission
            </Button>
            {editingId && (
              <Button variant="outline" onClick={() => {
                setEditingId(null);
                setFormData({
                  title: '',
                  description: '',
                  missionType: 'expansion',
                  targetMetric: 'territory-count',
                  targetValue: 10,
                  currentValue: 0,
                  status: 'active',
                  reward: '',
                  startDate: new Date().toISOString().split('T')[0],
                  notes: ''
                });
              }}>
                Cancel
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Mission List */}
      <div className="space-y-4">
        {missions.map((mission) => {
          const progress = mission.targetValue > 0 
            ? Math.min((mission.currentValue / mission.targetValue) * 100, 100) 
            : 0;

          return (
            <Card key={mission.id} className="bg-gray-800 border-gray-700">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg">{mission.title}</CardTitle>
                    <CardDescription>{mission.description}</CardDescription>
                  </div>
                  <Badge className={getStatusColor(mission.status)}>
                    {mission.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>{mission.targetMetric}</span>
                    <span className="font-medium">
                      {mission.currentValue} / {mission.targetValue}
                    </span>
                  </div>
                  <Progress value={progress} className="h-2" />
                  <p className="text-sm text-gray-400 mt-1">{progress.toFixed(0)}% Complete</p>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">Type:</span>
                    <Badge variant="outline" className="ml-2">{mission.missionType}</Badge>
                  </div>
                  <div>
                    <span className="text-gray-400">Reward:</span>
                    <span className="ml-2">{mission.reward}</span>
                  </div>
                </div>

                {mission.notes && (
                  <p className="text-sm text-gray-300">{mission.notes}</p>
                )}

                <div className="flex gap-2 pt-2">
                  <Button size="sm" variant="outline" onClick={() => handleEdit(mission)}>
                    Edit
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => onDeleteMission(mission.id)}>
                    Delete
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {missions.length === 0 && (
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="text-center py-8 text-gray-400">
            No missions yet. Create your first quest to start tracking achievements.
          </CardContent>
        </Card>
      )}
    </div>
  );
}
