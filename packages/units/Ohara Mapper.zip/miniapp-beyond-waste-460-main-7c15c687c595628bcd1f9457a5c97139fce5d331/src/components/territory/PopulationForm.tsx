'use client';

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { PopulationMarker, TerritoryNode, PopulationRole } from '@/types/territory';

interface PopulationFormProps {
  populationMarker?: PopulationMarker | null;
  nodes: TerritoryNode[];
  onSubmit: (data: {
    identityId: string;
    identityName: string;
    locatedInNodeId: string;
    role: PopulationRole;
    notes: string;
  }) => void;
  onCancel: () => void;
}

export function PopulationForm({ populationMarker, nodes, onSubmit, onCancel }: PopulationFormProps): JSX.Element {
  const [identityId, setIdentityId] = useState<string>(populationMarker?.identityId || '');
  const [identityName, setIdentityName] = useState<string>(populationMarker?.identityName || '');
  const [locatedInNodeId, setLocatedInNodeId] = useState<string>(populationMarker?.locatedInNodeId || '');
  const [role, setRole] = useState<PopulationRole>(populationMarker?.role || 'worker');
  const [notes, setNotes] = useState<string>(populationMarker?.notes || '');

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    if (!locatedInNodeId) return;
    
    onSubmit({
      identityId: identityId || `identity-${Date.now()}`,
      identityName,
      locatedInNodeId,
      role,
      notes
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-6">
      <div className="space-y-2">
        <Label htmlFor="identityName">Identity Name *</Label>
        <Input
          id="identityName"
          value={identityName}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setIdentityName(e.target.value)}
          placeholder="e.g. Alice Builder"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="identityId">Identity ID (optional)</Label>
        <Input
          id="identityId"
          value={identityId}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setIdentityId(e.target.value)}
          placeholder="Auto-generated if left empty"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="location">Located In Node *</Label>
        <Select value={locatedInNodeId} onValueChange={setLocatedInNodeId} required>
          <SelectTrigger id="location">
            <SelectValue placeholder="Select territory node..." />
          </SelectTrigger>
          <SelectContent>
            {nodes.map((node: TerritoryNode) => (
              <SelectItem key={node.id} value={node.id}>
                {node.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="role">Role</Label>
        <Select value={role} onValueChange={(value: string) => setRole(value as PopulationRole)}>
          <SelectTrigger id="role">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="worker">Worker</SelectItem>
            <SelectItem value="guardian">Guardian</SelectItem>
            <SelectItem value="scout">Scout</SelectItem>
            <SelectItem value="operator">Operator</SelectItem>
            <SelectItem value="builder">Builder</SelectItem>
            <SelectItem value="other">Other</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          value={notes}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNotes(e.target.value)}
          placeholder="Additional notes..."
          rows={3}
        />
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" className="flex-1">
          {populationMarker ? 'Update Population Marker' : 'Place Identity'}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
