'use client';

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { Region, ImportanceLevel } from '@/types/territory';

interface RegionFormProps {
  region?: Region | null;
  onSubmit: (data: {
    name: string;
    description: string;
    colorHex: string;
    importanceLevel: ImportanceLevel;
    tags: string[];
    notes: string;
  }) => void;
  onCancel: () => void;
}

const presetColors = [
  { name: 'Red', hex: '#ef4444' },
  { name: 'Orange', hex: '#f97316' },
  { name: 'Amber', hex: '#f59e0b' },
  { name: 'Yellow', hex: '#eab308' },
  { name: 'Lime', hex: '#84cc16' },
  { name: 'Green', hex: '#22c55e' },
  { name: 'Emerald', hex: '#10b981' },
  { name: 'Teal', hex: '#14b8a6' },
  { name: 'Cyan', hex: '#06b6d4' },
  { name: 'Sky', hex: '#0ea5e9' },
  { name: 'Blue', hex: '#3b82f6' },
  { name: 'Indigo', hex: '#6366f1' },
  { name: 'Violet', hex: '#8b5cf6' },
  { name: 'Purple', hex: '#a855f7' },
  { name: 'Fuchsia', hex: '#d946ef' },
  { name: 'Pink', hex: '#ec4899' },
  { name: 'Rose', hex: '#f43f5e' }
];

export function RegionForm({ region, onSubmit, onCancel }: RegionFormProps): JSX.Element {
  const [name, setName] = useState<string>(region?.name || '');
  const [description, setDescription] = useState<string>(region?.description || '');
  const [colorHex, setColorHex] = useState<string>(region?.colorHex || '#3b82f6');
  const [importanceLevel, setImportanceLevel] = useState<ImportanceLevel>(region?.importanceLevel || 'medium');
  const [tags, setTags] = useState<string>(region?.tags.join(', ') || '');
  const [notes, setNotes] = useState<string>(region?.notes || '');

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    onSubmit({
      name,
      description,
      colorHex,
      importanceLevel,
      tags: tags.split(',').map((t: string) => t.trim()).filter((t: string) => t),
      notes
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-6">
      <div className="space-y-2">
        <Label htmlFor="name">Region Name *</Label>
        <Input
          id="name"
          value={name}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
          placeholder="e.g. Cultural North"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description *</Label>
        <Textarea
          id="description"
          value={description}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
          placeholder="Describe this region..."
          rows={3}
          required
        />
      </div>

      <div className="space-y-2">
        <Label>Region Color</Label>
        <div className="grid grid-cols-9 gap-2">
          {presetColors.map((color: { name: string; hex: string }) => (
            <button
              key={color.hex}
              type="button"
              className={`w-8 h-8 rounded-md border-2 ${colorHex === color.hex ? 'border-white' : 'border-gray-600'}`}
              style={{ backgroundColor: color.hex }}
              onClick={() => setColorHex(color.hex)}
              title={color.name}
            />
          ))}
        </div>
        <Input
          type="text"
          value={colorHex}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setColorHex(e.target.value)}
          placeholder="#3b82f6"
          className="mt-2"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="importance">Importance Level</Label>
        <Select value={importanceLevel} onValueChange={(value: string) => setImportanceLevel(value as ImportanceLevel)}>
          <SelectTrigger id="importance">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="low">Low</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="high">High</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="tags">Tags (comma-separated)</Label>
        <Input
          id="tags"
          value={tags}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTags(e.target.value)}
          placeholder="strategic, cultural, foundational"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          value={notes}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNotes(e.target.value)}
          placeholder="Additional notes..."
          rows={3}
        />
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" className="flex-1">
          {region ? 'Update Region' : 'Create Region'}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
