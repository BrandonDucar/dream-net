'use client'
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import type { TerritoryData, TerritoryNode, TerritoryHealth, Mission } from '@/types/territory';

interface SovereigntyDashboardProps {
  data: TerritoryData;
}

export function SovereigntyDashboard({ data }: SovereigntyDashboardProps): JSX.Element {
  // Calculate sovereignty metrics
  const totalTerritory = data.nodes.length;
  const totalInfluence = data.influenceRadii.reduce((sum, inf) => sum + inf.influenceStrength, 0);
  const totalProduction = data.resourceProduction.reduce((sum, res) => sum + res.surplus, 0);
  const totalPopulation = data.populationMarkers.length;
  const corridorDensity = totalTerritory > 0 ? (data.corridors.length / totalTerritory).toFixed(2) : '0';
  const expansionRate = data.expansionZones.length;
  const dominanceScore = Math.round(totalTerritory * 10 + totalInfluence + totalPopulation * 5 + (parseFloat(corridorDensity) * 100));

  // Territory health stats
  const healthyTerritories = data.territoryHealth.filter(h => h.status === 'thriving' || h.status === 'stable').length;
  const criticalTerritories = data.territoryHealth.filter(h => h.status === 'under-siege' || h.status === 'abandoned').length;

  // Mission progress
  const activeMissions = data.missions.filter(m => m.status === 'active');
  const completedMissions = data.missions.filter(m => m.status === 'completed');
  const missionCompletionRate = data.missions.length > 0 
    ? Math.round((completedMissions.length / data.missions.length) * 100) 
    : 0;

  // Alliance stats
  const activeAlliances = data.alliances.filter(a => a.status === 'active').length;

  // Recent events
  const recentEvents = [...data.historicalEvents]
    .sort((a, b) => new Date(b.eventDate).getTime() - new Date(a.eventDate).getTime())
    .slice(0, 5);

  // Projects in progress
  const activeProjects = data.infrastructureProjects.filter(p => p.status === 'in-progress').length;

  return (
    <div className="space-y-6">
      {/* Main Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-900/50 to-blue-800/30 border-blue-700">
          <CardHeader className="pb-2">
            <CardDescription className="text-blue-200">Total Territory</CardDescription>
            <CardTitle className="text-4xl text-white">{totalTerritory}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-blue-300">nodes controlled</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-900/50 to-purple-800/30 border-purple-700">
          <CardHeader className="pb-2">
            <CardDescription className="text-purple-200">Total Influence</CardDescription>
            <CardTitle className="text-4xl text-white">{totalInfluence}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-purple-300">sphere of power</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-900/50 to-green-800/30 border-green-700">
          <CardHeader className="pb-2">
            <CardDescription className="text-green-200">Population</CardDescription>
            <CardTitle className="text-4xl text-white">{totalPopulation}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-green-300">identities across DreamNet</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-900/50 to-orange-800/30 border-orange-700">
          <CardHeader className="pb-2">
            <CardDescription className="text-orange-200">Dominance Score</CardDescription>
            <CardTitle className="text-4xl text-white">{dominanceScore}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-orange-300">overall power rating</p>
          </CardContent>
        </Card>
      </div>

      {/* Secondary Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-lg">Corridor Density</CardTitle>
            <CardDescription>{corridorDensity} corridors per territory</CardDescription>
          </CardHeader>
          <CardContent>
            <Progress value={parseFloat(corridorDensity) * 20} className="h-2" />
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-lg">Resource Production</CardTitle>
            <CardDescription>{totalProduction > 0 ? '+' : ''}{totalProduction} surplus</CardDescription>
          </CardHeader>
          <CardContent>
            <Badge variant={totalProduction > 0 ? 'default' : 'destructive'}>
              {totalProduction > 0 ? 'Surplus' : 'Deficit'}
            </Badge>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-lg">Expansion Zones</CardTitle>
            <CardDescription>{expansionRate} future territories</CardDescription>
          </CardHeader>
          <CardContent>
            <Badge variant="outline">{expansionRate} opportunities</Badge>
          </CardContent>
        </Card>
      </div>

      {/* Territory Health & Missions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>Territory Health</CardTitle>
            <CardDescription>Status across your empire</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm">Healthy Territories</span>
                <Badge className="bg-green-600">{healthyTerritories}</Badge>
              </div>
              <Progress value={(healthyTerritories / Math.max(totalTerritory, 1)) * 100} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm">Critical Territories</span>
                <Badge className="bg-red-600">{criticalTerritories}</Badge>
              </div>
              <Progress value={(criticalTerritories / Math.max(totalTerritory, 1)) * 100} className="h-2 bg-gray-700" />
            </div>
            <div className="pt-2 border-t border-gray-700">
              <p className="text-sm text-gray-400">
                {data.landmarks.length} landmarks, {data.districts.length} districts
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>Mission Progress</CardTitle>
            <CardDescription>Active quests and achievements</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm">Completion Rate</span>
                <Badge>{missionCompletionRate}%</Badge>
              </div>
              <Progress value={missionCompletionRate} className="h-2" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-2xl font-bold text-yellow-500">{activeMissions.length}</p>
                <p className="text-sm text-gray-400">Active</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-green-500">{completedMissions.length}</p>
                <p className="text-sm text-gray-400">Completed</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alliances & Projects */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>Strategic Overview</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm">Active Alliances</span>
              <Badge variant="outline">{activeAlliances}</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Infrastructure Projects</span>
              <Badge variant="outline">{activeProjects}</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Border Dynamics</span>
              <Badge variant="outline">{data.borderDynamics.length}</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Migration Events</span>
              <Badge variant="outline">{data.migrations.length}</Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>Recent Events</CardTitle>
            <CardDescription>Timeline activity</CardDescription>
          </CardHeader>
          <CardContent>
            {recentEvents.length === 0 ? (
              <p className="text-sm text-gray-500">No events recorded</p>
            ) : (
              <div className="space-y-2">
                {recentEvents.map((event) => (
                  <div key={event.id} className="text-sm border-l-2 border-blue-500 pl-3 py-1">
                    <p className="font-medium">{event.title}</p>
                    <p className="text-xs text-gray-400">
                      {new Date(event.eventDate).toLocaleDateString()}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
