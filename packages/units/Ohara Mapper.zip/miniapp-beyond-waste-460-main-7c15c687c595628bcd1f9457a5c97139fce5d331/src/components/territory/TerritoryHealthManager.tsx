'use client'
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import type { TerritoryNode, TerritoryHealth, TerritoryStatus } from '@/types/territory';

interface TerritoryHealthManagerProps {
  nodes: TerritoryNode[];
  territoryHealth: TerritoryHealth[];
  onCreateHealth: (params: {
    territoryNodeId: string;
    status: TerritoryStatus;
    vitalityScore: number;
    lastActivityDate: string;
    technicalDebt: number;
    notes: string;
  }) => void;
  onUpdateHealth: (id: string, updates: Partial<TerritoryHealth>) => void;
  onDeleteHealth: (id: string) => void;
}

export function TerritoryHealthManager({
  nodes,
  territoryHealth,
  onCreateHealth,
  onUpdateHealth,
  onDeleteHealth
}: TerritoryHealthManagerProps): JSX.Element {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    territoryNodeId: '',
    status: 'stable' as TerritoryStatus,
    vitalityScore: 75,
    lastActivityDate: new Date().toISOString().split('T')[0],
    technicalDebt: 20,
    notes: ''
  });

  const handleSubmit = (): void => {
    if (!formData.territoryNodeId) {
      alert('Please select a territory');
      return;
    }

    if (editingId) {
      onUpdateHealth(editingId, formData);
      setEditingId(null);
    } else {
      onCreateHealth(formData);
    }

    setFormData({
      territoryNodeId: '',
      status: 'stable',
      vitalityScore: 75,
      lastActivityDate: new Date().toISOString().split('T')[0],
      technicalDebt: 20,
      notes: ''
    });
  };

  const handleEdit = (health: TerritoryHealth): void => {
    setEditingId(health.id);
    setFormData({
      territoryNodeId: health.territoryNodeId,
      status: health.status,
      vitalityScore: health.vitalityScore,
      lastActivityDate: health.lastActivityDate.split('T')[0],
      technicalDebt: health.technicalDebt,
      notes: health.notes
    });
  };

  const getStatusColor = (status: TerritoryStatus): string => {
    const colors: Record<TerritoryStatus, string> = {
      'thriving': 'bg-green-600',
      'stable': 'bg-blue-600',
      'dormant': 'bg-yellow-600',
      'under-siege': 'bg-orange-600',
      'abandoned': 'bg-red-600'
    };
    return colors[status];
  };

  const getStatusEmoji = (status: TerritoryStatus): string => {
    const emojis: Record<TerritoryStatus, string> = {
      'thriving': '🟢',
      'stable': '🟡',
      'dormant': '🟠',
      'under-siege': '🔴',
      'abandoned': '⚫'
    };
    return emojis[status];
  };

  return (
    <div className="space-y-6">
      {/* Form */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle>{editingId ? 'Edit' : 'Add'} Territory Health</CardTitle>
          <CardDescription>Track vitality, status, and technical debt</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Territory</Label>
              <Select
                value={formData.territoryNodeId}
                onValueChange={(value: string) => setFormData({ ...formData, territoryNodeId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select territory" />
                </SelectTrigger>
                <SelectContent>
                  {nodes.map((node) => (
                    <SelectItem key={node.id} value={node.id}>
                      {node.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: TerritoryStatus) => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="thriving">🟢 Thriving</SelectItem>
                  <SelectItem value="stable">🟡 Stable</SelectItem>
                  <SelectItem value="dormant">🟠 Dormant</SelectItem>
                  <SelectItem value="under-siege">🔴 Under Siege</SelectItem>
                  <SelectItem value="abandoned">⚫ Abandoned</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Vitality Score (0-100): {formData.vitalityScore}</Label>
              <Input
                type="range"
                min="0"
                max="100"
                value={formData.vitalityScore}
                onChange={(e) => setFormData({ ...formData, vitalityScore: parseInt(e.target.value) })}
                className="mt-2"
              />
              <Progress value={formData.vitalityScore} className="mt-2 h-2" />
            </div>

            <div>
              <Label>Technical Debt (0-100): {formData.technicalDebt}</Label>
              <Input
                type="range"
                min="0"
                max="100"
                value={formData.technicalDebt}
                onChange={(e) => setFormData({ ...formData, technicalDebt: parseInt(e.target.value) })}
                className="mt-2"
              />
              <Progress value={formData.technicalDebt} className="mt-2 h-2 bg-gray-700" />
            </div>

            <div>
              <Label>Last Activity Date</Label>
              <Input
                type="date"
                value={formData.lastActivityDate}
                onChange={(e) => setFormData({ ...formData, lastActivityDate: e.target.value })}
              />
            </div>
          </div>

          <div>
            <Label>Notes</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Health status notes..."
            />
          </div>

          <div className="flex gap-2">
            <Button onClick={handleSubmit}>
              {editingId ? 'Update' : 'Create'} Health Record
            </Button>
            {editingId && (
              <Button variant="outline" onClick={() => {
                setEditingId(null);
                setFormData({
                  territoryNodeId: '',
                  status: 'stable',
                  vitalityScore: 75,
                  lastActivityDate: new Date().toISOString().split('T')[0],
                  technicalDebt: 20,
                  notes: ''
                });
              }}>
                Cancel
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Health List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {territoryHealth.map((health) => {
          const node = nodes.find(n => n.id === health.territoryNodeId);
          if (!node) return null;

          return (
            <Card key={health.id} className="bg-gray-800 border-gray-700">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{node.name}</CardTitle>
                    <Badge className={getStatusColor(health.status)}>
                      {getStatusEmoji(health.status)} {health.status}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Vitality</span>
                    <span className="font-medium">{health.vitalityScore}/100</span>
                  </div>
                  <Progress value={health.vitalityScore} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Technical Debt</span>
                    <span className="font-medium">{health.technicalDebt}/100</span>
                  </div>
                  <Progress value={health.technicalDebt} className="h-2 bg-gray-700" />
                </div>

                <div className="text-sm text-gray-400">
                  Last Activity: {new Date(health.lastActivityDate).toLocaleDateString()}
                </div>

                {health.notes && (
                  <p className="text-sm text-gray-300">{health.notes}</p>
                )}

                <div className="flex gap-2 pt-2">
                  <Button size="sm" variant="outline" onClick={() => handleEdit(health)}>
                    Edit
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => onDeleteHealth(health.id)}>
                    Delete
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {territoryHealth.length === 0 && (
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="text-center py-8 text-gray-400">
            No health records yet. Create one to start tracking territory vitality.
          </CardContent>
        </Card>
      )}
    </div>
  );
}
