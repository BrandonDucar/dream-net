'use client';

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { TerritoryNode, Region, Zone, ImportanceLevel } from '@/types/territory';

interface TerritoryNodeFormProps {
  node?: TerritoryNode | null;
  regions: Region[];
  zones: Zone[];
  onSubmit: (data: {
    name: string;
    category: string;
    miniAppId?: string;
    description: string;
    importanceLevel: ImportanceLevel;
    regionId?: string;
    zoneId?: string;
    x: number;
    y: number;
    tags: string[];
    notes: string;
  }) => void;
  onCancel: () => void;
}

export function TerritoryNodeForm({ node, regions, zones, onSubmit, onCancel }: TerritoryNodeFormProps): JSX.Element {
  const [name, setName] = useState<string>(node?.name || '');
  const [category, setCategory] = useState<string>(node?.category || '');
  const [miniAppId, setMiniAppId] = useState<string>(node?.miniAppId || '');
  const [description, setDescription] = useState<string>(node?.description || '');
  const [importanceLevel, setImportanceLevel] = useState<ImportanceLevel>(node?.importanceLevel || 'medium');
  const [regionId, setRegionId] = useState<string>(node?.regionId || '');
  const [zoneId, setZoneId] = useState<string>(node?.zoneId || '');
  const [x, setX] = useState<string>(node?.x.toString() || '400');
  const [y, setY] = useState<string>(node?.y.toString() || '300');
  const [tags, setTags] = useState<string>(node?.tags.join(', ') || '');
  const [notes, setNotes] = useState<string>(node?.notes || '');

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    onSubmit({
      name,
      category,
      miniAppId: miniAppId || undefined,
      description,
      importanceLevel,
      regionId: regionId || undefined,
      zoneId: zoneId || undefined,
      x: parseFloat(x) || 400,
      y: parseFloat(y) || 300,
      tags: tags.split(',').map((t: string) => t.trim()).filter((t: string) => t),
      notes
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-6">
      <div className="space-y-2">
        <Label htmlFor="name">Territory Name *</Label>
        <Input
          id="name"
          value={name}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
          placeholder="e.g. CultureCoin Foundry"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="category">Category *</Label>
        <Input
          id="category"
          value={category}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCategory(e.target.value)}
          placeholder="e.g. culture, ops, distribution"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="miniAppId">Mini App ID (optional)</Label>
        <Input
          id="miniAppId"
          value={miniAppId}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setMiniAppId(e.target.value)}
          placeholder="Link to existing mini-app"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={description}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
          placeholder="Describe this territory..."
          rows={3}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="importance">Importance Level</Label>
        <Select value={importanceLevel} onValueChange={(value: string) => setImportanceLevel(value as ImportanceLevel)}>
          <SelectTrigger id="importance">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="low">Low</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="high">High</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="region">Region (optional)</Label>
        <Select value={regionId} onValueChange={setRegionId}>
          <SelectTrigger id="region">
            <SelectValue placeholder="Select region..." />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">None</SelectItem>
            {regions.map((region: Region) => (
              <SelectItem key={region.id} value={region.id}>
                {region.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="zone">Zone (optional)</Label>
        <Select value={zoneId} onValueChange={setZoneId}>
          <SelectTrigger id="zone">
            <SelectValue placeholder="Select zone..." />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">None</SelectItem>
            {zones.map((zone: Zone) => (
              <SelectItem key={zone.id} value={zone.id}>
                {zone.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="x">X Coordinate</Label>
          <Input
            id="x"
            type="number"
            value={x}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setX(e.target.value)}
            placeholder="400"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="y">Y Coordinate</Label>
          <Input
            id="y"
            type="number"
            value={y}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setY(e.target.value)}
            placeholder="300"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="tags">Tags (comma-separated)</Label>
        <Input
          id="tags"
          value={tags}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTags(e.target.value)}
          placeholder="culture, creative, social"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          value={notes}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNotes(e.target.value)}
          placeholder="Additional notes..."
          rows={3}
        />
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" className="flex-1">
          {node ? 'Update Territory' : 'Create Territory'}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
