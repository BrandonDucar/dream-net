'use client';

import React, { useRef, useEffect, useState } from 'react';
import type { TerritoryNode, Region, Zone, Corridor } from '@/types/territory';

interface WorldMapProps {
  nodes: TerritoryNode[];
  regions: Region[];
  zones: Zone[];
  corridors: Corridor[];
  selectedNodeId: string | null;
  onNodeClick: (nodeId: string) => void;
  onNodeDrag: (nodeId: string, x: number, y: number) => void;
}

export function WorldMap({
  nodes,
  regions,
  zones,
  corridors,
  selectedNodeId,
  onNodeClick,
  onNodeDrag
}: WorldMapProps): JSX.Element {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  const getNodeColor = (node: TerritoryNode): string => {
    if (node.zoneId) {
      const zone = zones.find((z: Zone) => z.id === node.zoneId);
      if (zone) return zone.colorHex;
    }
    if (node.regionId) {
      const region = regions.find((r: Region) => r.id === node.regionId);
      if (region) return region.colorHex;
    }
    return '#6b7280';
  };

  const drawMap = (): void => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw background grid
    ctx.strokeStyle = '#1f2937';
    ctx.lineWidth = 1;
    for (let x = 0; x < canvas.width; x += 50) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += 50) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Draw corridors
    corridors.forEach((corridor: Corridor) => {
      const fromNode = nodes.find((n: TerritoryNode) => n.id === corridor.fromNodeId);
      const toNode = nodes.find((n: TerritoryNode) => n.id === corridor.toNodeId);

      if (fromNode && toNode) {
        ctx.strokeStyle = corridor.strength === 'critical' ? '#ef4444' : 
                         corridor.strength === 'strong' ? '#f59e0b' : 
                         corridor.strength === 'normal' ? '#10b981' : '#6b7280';
        ctx.lineWidth = corridor.strength === 'critical' ? 4 : 
                       corridor.strength === 'strong' ? 3 : 
                       corridor.strength === 'normal' ? 2 : 1;
        ctx.setLineDash(corridor.corridorType === 'mixed' ? [5, 5] : []);

        ctx.beginPath();
        ctx.moveTo(fromNode.x, fromNode.y);
        ctx.lineTo(toNode.x, toNode.y);
        ctx.stroke();
        ctx.setLineDash([]);

        // Draw arrow
        const angle = Math.atan2(toNode.y - fromNode.y, toNode.x - fromNode.x);
        const arrowLength = 10;
        const arrowX = toNode.x - Math.cos(angle) * 20;
        const arrowY = toNode.y - Math.sin(angle) * 20;

        ctx.beginPath();
        ctx.moveTo(arrowX, arrowY);
        ctx.lineTo(
          arrowX - arrowLength * Math.cos(angle - Math.PI / 6),
          arrowY - arrowLength * Math.sin(angle - Math.PI / 6)
        );
        ctx.moveTo(arrowX, arrowY);
        ctx.lineTo(
          arrowX - arrowLength * Math.cos(angle + Math.PI / 6),
          arrowY - arrowLength * Math.sin(angle + Math.PI / 6)
        );
        ctx.stroke();
      }
    });

    // Draw neighbor connections
    nodes.forEach((node: TerritoryNode) => {
      node.neighbors.forEach((neighborId: string) => {
        const neighbor = nodes.find((n: TerritoryNode) => n.id === neighborId);
        if (neighbor && node.id < neighborId) {
          ctx.strokeStyle = '#374151';
          ctx.lineWidth = 1;
          ctx.setLineDash([2, 2]);

          ctx.beginPath();
          ctx.moveTo(node.x, node.y);
          ctx.lineTo(neighbor.x, neighbor.y);
          ctx.stroke();
          ctx.setLineDash([]);
        }
      });
    });

    // Draw nodes
    nodes.forEach((node: TerritoryNode) => {
      const color = getNodeColor(node);
      const isSelected = node.id === selectedNodeId;
      const radius = node.importanceLevel === 'critical' ? 16 : 
                    node.importanceLevel === 'high' ? 12 : 
                    node.importanceLevel === 'medium' ? 10 : 8;

      // Draw glow for selected node
      if (isSelected) {
        ctx.shadowColor = color;
        ctx.shadowBlur = 20;
      }

      // Draw node circle
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(node.x, node.y, radius, 0, Math.PI * 2);
      ctx.fill();

      // Draw border
      ctx.strokeStyle = isSelected ? '#fff' : '#000';
      ctx.lineWidth = isSelected ? 3 : 2;
      ctx.stroke();

      ctx.shadowBlur = 0;

      // Draw label
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      
      // Draw text background
      const textMetrics = ctx.measureText(node.name);
      const textWidth = textMetrics.width;
      const textHeight = 14;
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(node.x - textWidth / 2 - 4, node.y + radius + 4, textWidth + 8, textHeight + 4);
      
      // Draw text
      ctx.fillStyle = '#fff';
      ctx.fillText(node.name, node.x, node.y + radius + 6);
    });
  };

  useEffect(() => {
    drawMap();
  }, [nodes, regions, zones, corridors, selectedNodeId]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>): void => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Find clicked node
    for (let i = nodes.length - 1; i >= 0; i--) {
      const node = nodes[i];
      if (!node) continue;
      
      const radius = node.importanceLevel === 'critical' ? 16 : 
                    node.importanceLevel === 'high' ? 12 : 
                    node.importanceLevel === 'medium' ? 10 : 8;

      const distance = Math.sqrt(Math.pow(x - node.x, 2) + Math.pow(y - node.y, 2));
      if (distance <= radius) {
        onNodeClick(node.id);
        return;
      }
    }

    // If no node clicked, deselect
    onNodeClick('');
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>): void => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Find clicked node
    for (let i = nodes.length - 1; i >= 0; i--) {
      const node = nodes[i];
      if (!node) continue;
      
      const radius = node.importanceLevel === 'critical' ? 16 : 
                    node.importanceLevel === 'high' ? 12 : 
                    node.importanceLevel === 'medium' ? 10 : 8;

      const distance = Math.sqrt(Math.pow(x - node.x, 2) + Math.pow(y - node.y, 2));
      if (distance <= radius) {
        setDraggingNodeId(node.id);
        setDragOffset({ x: x - node.x, y: y - node.y });
        return;
      }
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>): void => {
    if (!draggingNodeId) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left - dragOffset.x;
    const y = e.clientY - rect.top - dragOffset.y;

    onNodeDrag(draggingNodeId, x, y);
  };

  const handleMouseUp = (): void => {
    setDraggingNodeId(null);
  };

  return (
    <div className="relative w-full h-full bg-gray-900 rounded-lg overflow-hidden">
      <canvas
        ref={canvasRef}
        width={1200}
        height={800}
        className="cursor-pointer"
        onClick={handleCanvasClick}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      />
      
      <div className="absolute top-4 left-4 bg-black/80 p-4 rounded-lg text-white text-xs space-y-1">
        <div className="font-bold text-sm mb-2">LEGEND</div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-red-500"></div>
          <span>Critical Importance</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-orange-500"></div>
          <span>High Importance</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-blue-500"></div>
          <span>Medium Importance</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-gray-500"></div>
          <span>Low Importance</span>
        </div>
        <div className="border-t border-gray-700 my-2"></div>
        <div className="flex items-center gap-2">
          <div className="w-8 h-0.5 bg-red-500"></div>
          <span>Critical Corridor</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-8 h-0.5 bg-orange-500"></div>
          <span>Strong Corridor</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-8 h-0.5 bg-green-500"></div>
          <span>Normal Corridor</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-8 h-0.5 bg-gray-500"></div>
          <span>Weak Corridor</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-8 h-0.5 bg-gray-400" style={{ borderTop: '2px dashed #9ca3af' }}></div>
          <span>Mixed Flow</span>
        </div>
        <div className="border-t border-gray-700 my-2"></div>
        <div className="text-gray-400">
          Click nodes to select<br />
          Drag nodes to reposition
        </div>
      </div>

      <div className="absolute bottom-4 left-4 bg-black/80 p-3 rounded-lg text-white text-xs">
        <div className="font-bold">STATS</div>
        <div>Territories: {nodes.length}</div>
        <div>Corridors: {corridors.length}</div>
        <div>Regions: {regions.length}</div>
        <div>Zones: {zones.length}</div>
      </div>
    </div>
  );
}
