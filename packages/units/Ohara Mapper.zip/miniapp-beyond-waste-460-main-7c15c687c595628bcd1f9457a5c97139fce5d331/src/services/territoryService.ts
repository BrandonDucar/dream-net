import type {
  TerritoryNode,
  Region,
  Zone,
  Corridor,
  ExpansionZone,
  PopulationMarker,
  FlowTraffic,
  TerritoryData,
  TerritoryFilters,
  ImportanceLevel,
  CorridorType,
  CorridorStrength,
  FlowType,
  FlowMagnitude,
  PopulationRole,
  SEOMeta,
  TerritoryHealth,
  TerritoryStatus,
  ResourceProduction,
  ResourceType,
  InfluenceRadius,
  HistoricalEvent,
  Alliance,
  AllianceType,
  AllianceStatus,
  Landmark,
  LandmarkType,
  Migration,
  BorderDynamic,
  BorderType,
  InfrastructureProject,
  ProjectStatus,
  District,
  Mission,
  MissionStatus,
  TerrainType
} from '@/types/territory';

const STORAGE_KEY = 'dreamnet-territory-data';

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

function generateSEOMeta(name: string, description: string, tags: string[]): SEOMeta {
  return {
    seoTitle: `${name} | DreamNet Territory`,
    seoDescription: description.substring(0, 160),
    seoKeywords: tags,
    seoHashtags: tags.map((tag: string) => `#${tag.replace(/\s+/g, '')}`),
    altText: `Territory map marker for ${name}`
  };
}

export class TerritoryService {
  private data: TerritoryData;

  constructor() {
    this.data = this.loadData();
  }

  private loadData(): TerritoryData {
    if (typeof window === 'undefined') {
      return this.getEmptyData();
    }
    
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored) as TerritoryData;
      }
    } catch (error) {
      console.error('Error loading territory data:', error);
    }
    
    return this.getEmptyData();
  }

  private getEmptyData(): TerritoryData {
    return {
      nodes: [],
      regions: [],
      zones: [],
      corridors: [],
      expansionZones: [],
      populationMarkers: [],
      flowTraffic: [],
      territoryHealth: [],
      resourceProduction: [],
      influenceRadii: [],
      historicalEvents: [],
      alliances: [],
      landmarks: [],
      migrations: [],
      borderDynamics: [],
      infrastructureProjects: [],
      districts: [],
      missions: []
    };
  }

  private saveData(): void {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
      } catch (error) {
        console.error('Error saving territory data:', error);
      }
    }
  }

  // TERRITORY NODE OPERATIONS
  registerTerritoryNode(params: {
    name: string;
    category: string;
    miniAppId?: string | null;
    description?: string;
    importanceLevel?: ImportanceLevel;
    regionId?: string | null;
    zoneId?: string | null;
    x?: number;
    y?: number;
    tags?: string[];
    notes?: string;
    terrainType?: TerrainType | null;
  }): TerritoryNode {
    const now = new Date().toISOString();
    const node: TerritoryNode = {
      id: generateId(),
      miniAppId: params.miniAppId || null,
      name: params.name,
      category: params.category,
      description: params.description || '',
      importanceLevel: params.importanceLevel || 'medium',
      regionId: params.regionId || null,
      zoneId: params.zoneId || null,
      x: params.x || Math.random() * 800,
      y: params.y || Math.random() * 600,
      neighbors: [],
      tags: params.tags || [],
      notes: params.notes || '',
      terrainType: params.terrainType || null,
      seo: generateSEOMeta(params.name, params.description || '', params.tags || []),
      createdAt: now,
      updatedAt: now
    };

    this.data.nodes.push(node);
    this.saveData();
    return node;
  }

  updateTerritoryNode(id: string, updates: Partial<Omit<TerritoryNode, 'id' | 'createdAt'>>): TerritoryNode | null {
    const index = this.data.nodes.findIndex((n: TerritoryNode) => n.id === id);
    if (index === -1) return null;

    const node = this.data.nodes[index];
    if (!node) return null;

    this.data.nodes[index] = {
      ...node,
      ...updates,
      updatedAt: new Date().toISOString()
    };

    this.saveData();
    return this.data.nodes[index] || null;
  }

  setNodeCoordinates(id: string, x: number, y: number): TerritoryNode | null {
    return this.updateTerritoryNode(id, { x, y });
  }

  addNeighbor(nodeId: string, neighborId: string): boolean {
    const node = this.data.nodes.find((n: TerritoryNode) => n.id === nodeId);
    const neighbor = this.data.nodes.find((n: TerritoryNode) => n.id === neighborId);

    if (!node || !neighbor || nodeId === neighborId) return false;

    if (!node.neighbors.includes(neighborId)) {
      node.neighbors.push(neighborId);
    }
    if (!neighbor.neighbors.includes(nodeId)) {
      neighbor.neighbors.push(nodeId);
    }

    this.saveData();
    return true;
  }

  removeNeighbor(nodeId: string, neighborId: string): boolean {
    const node = this.data.nodes.find((n: TerritoryNode) => n.id === nodeId);
    const neighbor = this.data.nodes.find((n: TerritoryNode) => n.id === neighborId);

    if (!node || !neighbor) return false;

    node.neighbors = node.neighbors.filter((id: string) => id !== neighborId);
    neighbor.neighbors = neighbor.neighbors.filter((id: string) => id !== nodeId);

    this.saveData();
    return true;
  }

  deleteTerritoryNode(id: string): boolean {
    const index = this.data.nodes.findIndex((n: TerritoryNode) => n.id === id);
    if (index === -1) return false;

    // Remove from neighbors
    this.data.nodes.forEach((node: TerritoryNode) => {
      node.neighbors = node.neighbors.filter((nId: string) => nId !== id);
    });

    // Remove from regions and zones
    this.data.regions.forEach((region: Region) => {
      region.territoryNodeIds = region.territoryNodeIds.filter((nId: string) => nId !== id);
    });
    this.data.zones.forEach((zone: Zone) => {
      zone.territoryNodeIds = zone.territoryNodeIds.filter((nId: string) => nId !== id);
    });

    // Remove corridors
    this.data.corridors = this.data.corridors.filter(
      (c: Corridor) => c.fromNodeId !== id && c.toNodeId !== id
    );

    // Remove flow traffic
    this.data.flowTraffic = this.data.flowTraffic.filter(
      (f: FlowTraffic) => f.fromNodeId !== id && f.toNodeId !== id
    );

    // Remove population markers
    this.data.populationMarkers = this.data.populationMarkers.filter(
      (p: PopulationMarker) => p.locatedInNodeId !== id
    );

    this.data.nodes.splice(index, 1);
    this.saveData();
    return true;
  }

  // REGION OPERATIONS
  createRegion(params: {
    name: string;
    description: string;
    colorHex: string;
    importanceLevel?: ImportanceLevel;
    tags?: string[];
    notes?: string;
  }): Region {
    const now = new Date().toISOString();
    const region: Region = {
      id: generateId(),
      name: params.name,
      description: params.description,
      colorHex: params.colorHex,
      importanceLevel: params.importanceLevel || 'medium',
      territoryNodeIds: [],
      tags: params.tags || [],
      notes: params.notes || '',
      seo: generateSEOMeta(params.name, params.description, params.tags || []),
      createdAt: now,
      updatedAt: now
    };

    this.data.regions.push(region);
    this.saveData();
    return region;
  }

  updateRegion(id: string, updates: Partial<Omit<Region, 'id' | 'createdAt'>>): Region | null {
    const index = this.data.regions.findIndex((r: Region) => r.id === id);
    if (index === -1) return null;

    const region = this.data.regions[index];
    if (!region) return null;

    this.data.regions[index] = {
      ...region,
      ...updates,
      updatedAt: new Date().toISOString()
    };

    this.saveData();
    return this.data.regions[index] || null;
  }

  assignNodeToRegion(nodeId: string, regionId: string): boolean {
    const node = this.data.nodes.find((n: TerritoryNode) => n.id === nodeId);
    const region = this.data.regions.find((r: Region) => r.id === regionId);

    if (!node || !region) return false;

    // Remove from old region
    if (node.regionId) {
      const oldRegion = this.data.regions.find((r: Region) => r.id === node.regionId);
      if (oldRegion) {
        oldRegion.territoryNodeIds = oldRegion.territoryNodeIds.filter((id: string) => id !== nodeId);
      }
    }

    // Add to new region
    node.regionId = regionId;
    if (!region.territoryNodeIds.includes(nodeId)) {
      region.territoryNodeIds.push(nodeId);
    }

    this.saveData();
    return true;
  }

  removeNodeFromRegion(nodeId: string): boolean {
    const node = this.data.nodes.find((n: TerritoryNode) => n.id === nodeId);
    if (!node || !node.regionId) return false;

    const region = this.data.regions.find((r: Region) => r.id === node.regionId);
    if (region) {
      region.territoryNodeIds = region.territoryNodeIds.filter((id: string) => id !== nodeId);
    }

    node.regionId = null;
    this.saveData();
    return true;
  }

  deleteRegion(id: string): boolean {
    const index = this.data.regions.findIndex((r: Region) => r.id === id);
    if (index === -1) return false;

    // Remove region reference from nodes
    this.data.nodes.forEach((node: TerritoryNode) => {
      if (node.regionId === id) {
        node.regionId = null;
      }
    });

    // Remove region reference from zones
    this.data.zones.forEach((zone: Zone) => {
      if (zone.parentRegionId === id) {
        zone.parentRegionId = null;
      }
    });

    this.data.regions.splice(index, 1);
    this.saveData();
    return true;
  }

  // ZONE OPERATIONS
  createZone(params: {
    name: string;
    description: string;
    colorHex: string;
    parentRegionId?: string | null;
    tags?: string[];
    notes?: string;
  }): Zone {
    const now = new Date().toISOString();
    const zone: Zone = {
      id: generateId(),
      name: params.name,
      description: params.description,
      parentRegionId: params.parentRegionId || null,
      colorHex: params.colorHex,
      territoryNodeIds: [],
      tags: params.tags || [],
      notes: params.notes || '',
      seo: generateSEOMeta(params.name, params.description, params.tags || []),
      createdAt: now,
      updatedAt: now
    };

    this.data.zones.push(zone);
    this.saveData();
    return zone;
  }

  updateZone(id: string, updates: Partial<Omit<Zone, 'id' | 'createdAt'>>): Zone | null {
    const index = this.data.zones.findIndex((z: Zone) => z.id === id);
    if (index === -1) return null;

    const zone = this.data.zones[index];
    if (!zone) return null;

    this.data.zones[index] = {
      ...zone,
      ...updates,
      updatedAt: new Date().toISOString()
    };

    this.saveData();
    return this.data.zones[index] || null;
  }

  assignNodeToZone(nodeId: string, zoneId: string): boolean {
    const node = this.data.nodes.find((n: TerritoryNode) => n.id === nodeId);
    const zone = this.data.zones.find((z: Zone) => z.id === zoneId);

    if (!node || !zone) return false;

    // Remove from old zone
    if (node.zoneId) {
      const oldZone = this.data.zones.find((z: Zone) => z.id === node.zoneId);
      if (oldZone) {
        oldZone.territoryNodeIds = oldZone.territoryNodeIds.filter((id: string) => id !== nodeId);
      }
    }

    // Add to new zone
    node.zoneId = zoneId;
    if (!zone.territoryNodeIds.includes(nodeId)) {
      zone.territoryNodeIds.push(nodeId);
    }

    this.saveData();
    return true;
  }

  removeNodeFromZone(nodeId: string): boolean {
    const node = this.data.nodes.find((n: TerritoryNode) => n.id === nodeId);
    if (!node || !node.zoneId) return false;

    const zone = this.data.zones.find((z: Zone) => z.id === node.zoneId);
    if (zone) {
      zone.territoryNodeIds = zone.territoryNodeIds.filter((id: string) => id !== nodeId);
    }

    node.zoneId = null;
    this.saveData();
    return true;
  }

  deleteZone(id: string): boolean {
    const index = this.data.zones.findIndex((z: Zone) => z.id === id);
    if (index === -1) return false;

    // Remove zone reference from nodes
    this.data.nodes.forEach((node: TerritoryNode) => {
      if (node.zoneId === id) {
        node.zoneId = null;
      }
    });

    this.data.zones.splice(index, 1);
    this.saveData();
    return true;
  }

  // CORRIDOR OPERATIONS
  createCorridor(params: {
    name: string;
    fromNodeId: string;
    toNodeId: string;
    corridorType: CorridorType;
    strength: CorridorStrength;
    description?: string;
    tags?: string[];
    notes?: string;
  }): Corridor | null {
    const fromNode = this.data.nodes.find((n: TerritoryNode) => n.id === params.fromNodeId);
    const toNode = this.data.nodes.find((n: TerritoryNode) => n.id === params.toNodeId);

    if (!fromNode || !toNode) return null;

    const now = new Date().toISOString();
    const corridor: Corridor = {
      id: generateId(),
      name: params.name,
      description: params.description || '',
      fromNodeId: params.fromNodeId,
      toNodeId: params.toNodeId,
      corridorType: params.corridorType,
      strength: params.strength,
      tags: params.tags || [],
      notes: params.notes || '',
      createdAt: now,
      updatedAt: now
    };

    this.data.corridors.push(corridor);
    this.saveData();
    return corridor;
  }

  updateCorridor(id: string, updates: Partial<Omit<Corridor, 'id' | 'createdAt'>>): Corridor | null {
    const index = this.data.corridors.findIndex((c: Corridor) => c.id === id);
    if (index === -1) return null;

    const corridor = this.data.corridors[index];
    if (!corridor) return null;

    this.data.corridors[index] = {
      ...corridor,
      ...updates,
      updatedAt: new Date().toISOString()
    };

    this.saveData();
    return this.data.corridors[index] || null;
  }

  deleteCorridor(id: string): boolean {
    const index = this.data.corridors.findIndex((c: Corridor) => c.id === id);
    if (index === -1) return false;

    this.data.corridors.splice(index, 1);
    this.saveData();
    return true;
  }

  // EXPANSION ZONE OPERATIONS
  createExpansionZone(params: {
    name: string;
    description: string;
    suggestedMiniAppTypes?: string[];
    coordinates?: number[];
    tags?: string[];
    notes?: string;
  }): ExpansionZone {
    const now = new Date().toISOString();
    const expansionZone: ExpansionZone = {
      id: generateId(),
      name: params.name,
      description: params.description,
      suggestedMiniAppTypes: params.suggestedMiniAppTypes || [],
      coordinates: params.coordinates || [],
      tags: params.tags || [],
      notes: params.notes || '',
      createdAt: now,
      updatedAt: now
    };

    this.data.expansionZones.push(expansionZone);
    this.saveData();
    return expansionZone;
  }

  updateExpansionZone(id: string, updates: Partial<Omit<ExpansionZone, 'id' | 'createdAt'>>): ExpansionZone | null {
    const index = this.data.expansionZones.findIndex((e: ExpansionZone) => e.id === id);
    if (index === -1) return null;

    const expansionZone = this.data.expansionZones[index];
    if (!expansionZone) return null;

    this.data.expansionZones[index] = {
      ...expansionZone,
      ...updates,
      updatedAt: new Date().toISOString()
    };

    this.saveData();
    return this.data.expansionZones[index] || null;
  }

  deleteExpansionZone(id: string): boolean {
    const index = this.data.expansionZones.findIndex((e: ExpansionZone) => e.id === id);
    if (index === -1) return false;

    this.data.expansionZones.splice(index, 1);
    this.saveData();
    return true;
  }

  // POPULATION MARKER OPERATIONS
  placePopulation(params: {
    identityId: string;
    identityName: string;
    locatedInNodeId: string;
    role: PopulationRole;
    notes?: string;
  }): PopulationMarker | null {
    const node = this.data.nodes.find((n: TerritoryNode) => n.id === params.locatedInNodeId);
    if (!node) return null;

    const now = new Date().toISOString();
    const marker: PopulationMarker = {
      id: generateId(),
      identityId: params.identityId,
      identityName: params.identityName,
      locatedInNodeId: params.locatedInNodeId,
      role: params.role,
      notes: params.notes || '',
      createdAt: now,
      updatedAt: now
    };

    this.data.populationMarkers.push(marker);
    this.saveData();
    return marker;
  }

  updatePopulationMarker(id: string, updates: Partial<Omit<PopulationMarker, 'id' | 'createdAt'>>): PopulationMarker | null {
    const index = this.data.populationMarkers.findIndex((p: PopulationMarker) => p.id === id);
    if (index === -1) return null;

    const marker = this.data.populationMarkers[index];
    if (!marker) return null;

    this.data.populationMarkers[index] = {
      ...marker,
      ...updates,
      updatedAt: new Date().toISOString()
    };

    this.saveData();
    return this.data.populationMarkers[index] || null;
  }

  deletePopulationMarker(id: string): boolean {
    const index = this.data.populationMarkers.findIndex((p: PopulationMarker) => p.id === id);
    if (index === -1) return false;

    this.data.populationMarkers.splice(index, 1);
    this.saveData();
    return true;
  }

  // FLOW TRAFFIC OPERATIONS
  recordFlowTraffic(params: {
    fromNodeId: string;
    toNodeId: string;
    flowType: FlowType;
    magnitude: FlowMagnitude;
    notes?: string;
  }): FlowTraffic | null {
    const fromNode = this.data.nodes.find((n: TerritoryNode) => n.id === params.fromNodeId);
    const toNode = this.data.nodes.find((n: TerritoryNode) => n.id === params.toNodeId);

    if (!fromNode || !toNode) return null;

    const now = new Date().toISOString();
    const traffic: FlowTraffic = {
      id: generateId(),
      fromNodeId: params.fromNodeId,
      toNodeId: params.toNodeId,
      flowType: params.flowType,
      magnitude: params.magnitude,
      notes: params.notes || '',
      createdAt: now,
      updatedAt: now
    };

    this.data.flowTraffic.push(traffic);
    this.saveData();
    return traffic;
  }

  updateFlowTraffic(id: string, updates: Partial<Omit<FlowTraffic, 'id' | 'createdAt'>>): FlowTraffic | null {
    const index = this.data.flowTraffic.findIndex((f: FlowTraffic) => f.id === id);
    if (index === -1) return null;

    const traffic = this.data.flowTraffic[index];
    if (!traffic) return null;

    this.data.flowTraffic[index] = {
      ...traffic,
      ...updates,
      updatedAt: new Date().toISOString()
    };

    this.saveData();
    return this.data.flowTraffic[index] || null;
  }

  deleteFlowTraffic(id: string): boolean {
    const index = this.data.flowTraffic.findIndex((f: FlowTraffic) => f.id === id);
    if (index === -1) return false;

    this.data.flowTraffic.splice(index, 1);
    this.saveData();
    return true;
  }

  // QUERY OPERATIONS
  listTerritoryNodes(filters?: TerritoryFilters): TerritoryNode[] {
    let nodes = [...this.data.nodes];

    if (filters) {
      if (filters.category) {
        nodes = nodes.filter((n: TerritoryNode) => n.category === filters.category);
      }
      if (filters.regionId) {
        nodes = nodes.filter((n: TerritoryNode) => n.regionId === filters.regionId);
      }
      if (filters.zoneId) {
        nodes = nodes.filter((n: TerritoryNode) => n.zoneId === filters.zoneId);
      }
      if (filters.tag) {
        nodes = nodes.filter((n: TerritoryNode) => n.tags.includes(filters.tag || ''));
      }
      if (filters.importanceLevel) {
        nodes = nodes.filter((n: TerritoryNode) => n.importanceLevel === filters.importanceLevel);
      }
    }

    return nodes;
  }

  getTerritoryDetail(nodeId: string): {
    node: TerritoryNode;
    neighbors: TerritoryNode[];
    corridors: Corridor[];
    flowTraffic: FlowTraffic[];
    populationMarkers: PopulationMarker[];
    region: Region | null;
    zone: Zone | null;
  } | null {
    const node = this.data.nodes.find((n: TerritoryNode) => n.id === nodeId);
    if (!node) return null;

    const neighbors = this.data.nodes.filter((n: TerritoryNode) => node.neighbors.includes(n.id));
    const corridors = this.data.corridors.filter(
      (c: Corridor) => c.fromNodeId === nodeId || c.toNodeId === nodeId
    );
    const flowTraffic = this.data.flowTraffic.filter(
      (f: FlowTraffic) => f.fromNodeId === nodeId || f.toNodeId === nodeId
    );
    const populationMarkers = this.data.populationMarkers.filter(
      (p: PopulationMarker) => p.locatedInNodeId === nodeId
    );
    const region = node.regionId ? this.data.regions.find((r: Region) => r.id === node.regionId) || null : null;
    const zone = node.zoneId ? this.data.zones.find((z: Zone) => z.id === node.zoneId) || null : null;

    return {
      node,
      neighbors,
      corridors,
      flowTraffic,
      populationMarkers,
      region,
      zone
    };
  }

  getAllData(): TerritoryData {
    return { ...this.data };
  }

  getRegions(): Region[] {
    return [...this.data.regions];
  }

  getZones(): Zone[] {
    return [...this.data.zones];
  }

  getCorridors(): Corridor[] {
    return [...this.data.corridors];
  }

  getExpansionZones(): ExpansionZone[] {
    return [...this.data.expansionZones];
  }

  getPopulationMarkers(): PopulationMarker[] {
    return [...this.data.populationMarkers];
  }

  getFlowTraffic(): FlowTraffic[] {
    return [...this.data.flowTraffic];
  }

  // GENERATE OPERATIONS
  generateTerritoryMap(): string {
    let output = '═══════════════════════════════════════════════════\n';
    output += '  DREAMNET TERRITORY MAP - OHARA MEGASTRUCTURE\n';
    output += '═══════════════════════════════════════════════════\n\n';

    // Regions
    output += '▓▓▓ REGIONS ▓▓▓\n';
    this.data.regions.forEach((region: Region) => {
      output += `\n[${region.name}] (${region.colorHex})\n`;
      output += `  ${region.description}\n`;
      output += `  Importance: ${region.importanceLevel.toUpperCase()}\n`;
      output += `  Territories: ${region.territoryNodeIds.length}\n`;
      if (region.tags.length > 0) {
        output += `  Tags: ${region.tags.join(', ')}\n`;
      }
    });

    // Zones
    output += '\n\n▓▓▓ ZONES ▓▓▓\n';
    this.data.zones.forEach((zone: Zone) => {
      output += `\n[${zone.name}] (${zone.colorHex})\n`;
      output += `  ${zone.description}\n`;
      if (zone.parentRegionId) {
        const region = this.data.regions.find((r: Region) => r.id === zone.parentRegionId);
        output += `  Parent Region: ${region ? region.name : 'Unknown'}\n`;
      }
      output += `  Territories: ${zone.territoryNodeIds.length}\n`;
    });

    // Territory Nodes
    output += '\n\n▓▓▓ TERRITORY NODES ▓▓▓\n';
    this.data.nodes.forEach((node: TerritoryNode) => {
      output += `\n[${node.name}]\n`;
      output += `  Category: ${node.category}\n`;
      output += `  Coordinates: (${node.x.toFixed(0)}, ${node.y.toFixed(0)})\n`;
      output += `  Importance: ${node.importanceLevel.toUpperCase()}\n`;
      if (node.regionId) {
        const region = this.data.regions.find((r: Region) => r.id === node.regionId);
        output += `  Region: ${region ? region.name : 'Unknown'}\n`;
      }
      if (node.zoneId) {
        const zone = this.data.zones.find((z: Zone) => z.id === node.zoneId);
        output += `  Zone: ${zone ? zone.name : 'Unknown'}\n`;
      }
      if (node.neighbors.length > 0) {
        const neighborNames = node.neighbors.map((nId: string) => {
          const n = this.data.nodes.find((node: TerritoryNode) => node.id === nId);
          return n ? n.name : 'Unknown';
        });
        output += `  Neighbors: ${neighborNames.join(', ')}\n`;
      }
      if (node.description) {
        output += `  Description: ${node.description}\n`;
      }
    });

    // Corridors
    output += '\n\n▓▓▓ CORRIDORS ▓▓▓\n';
    this.data.corridors.forEach((corridor: Corridor) => {
      const fromNode = this.data.nodes.find((n: TerritoryNode) => n.id === corridor.fromNodeId);
      const toNode = this.data.nodes.find((n: TerritoryNode) => n.id === corridor.toNodeId);
      output += `\n[${corridor.name}]\n`;
      output += `  ${fromNode ? fromNode.name : 'Unknown'} ──→ ${toNode ? toNode.name : 'Unknown'}\n`;
      output += `  Type: ${corridor.corridorType}\n`;
      output += `  Strength: ${corridor.strength.toUpperCase()}\n`;
      if (corridor.description) {
        output += `  ${corridor.description}\n`;
      }
    });

    // Expansion Zones
    output += '\n\n▓▓▓ EXPANSION ZONES ▓▓▓\n';
    this.data.expansionZones.forEach((zone: ExpansionZone) => {
      output += `\n[${zone.name}]\n`;
      output += `  ${zone.description}\n`;
      if (zone.suggestedMiniAppTypes.length > 0) {
        output += `  Suggested Types: ${zone.suggestedMiniAppTypes.join(', ')}\n`;
      }
    });

    // Population
    output += '\n\n▓▓▓ POPULATION ▓▓▓\n';
    output += `Total Identities: ${this.data.populationMarkers.length}\n`;
    const populationByNode: Record<string, number> = {};
    this.data.populationMarkers.forEach((marker: PopulationMarker) => {
      populationByNode[marker.locatedInNodeId] = (populationByNode[marker.locatedInNodeId] || 0) + 1;
    });
    Object.keys(populationByNode).forEach((nodeId: string) => {
      const node = this.data.nodes.find((n: TerritoryNode) => n.id === nodeId);
      const count = populationByNode[nodeId];
      if (node && typeof count === 'number') {
        output += `  ${node.name}: ${count} identities\n`;
      }
    });

    // Flow Traffic
    output += '\n\n▓▓▓ FLOW TRAFFIC ▓▓▓\n';
    output += `Total Flows: ${this.data.flowTraffic.length}\n`;
    const flowsByType: Record<string, number> = {};
    this.data.flowTraffic.forEach((flow: FlowTraffic) => {
      flowsByType[flow.flowType] = (flowsByType[flow.flowType] || 0) + 1;
    });
    Object.keys(flowsByType).forEach((type: string) => {
      const count = flowsByType[type];
      if (typeof count === 'number') {
        output += `  ${type}: ${count} flows\n`;
      }
    });

    output += '\n═══════════════════════════════════════════════════\n';
    output += '  END OF TERRITORY MAP\n';
    output += '═══════════════════════════════════════════════════\n';

    return output;
  }

  generateRegionSummary(regionId: string): string {
    const region = this.data.regions.find((r: Region) => r.id === regionId);
    if (!region) return 'Region not found';

    let output = `═══════════════════════════════════════\n`;
    output += `  REGION: ${region.name}\n`;
    output += `═══════════════════════════════════════\n\n`;
    output += `${region.description}\n\n`;
    output += `Color: ${region.colorHex}\n`;
    output += `Importance: ${region.importanceLevel.toUpperCase()}\n`;
    output += `Tags: ${region.tags.join(', ') || 'None'}\n\n`;

    output += `▓▓▓ TERRITORIES (${region.territoryNodeIds.length}) ▓▓▓\n`;
    region.territoryNodeIds.forEach((nodeId: string) => {
      const node = this.data.nodes.find((n: TerritoryNode) => n.id === nodeId);
      if (node) {
        output += `  • ${node.name} (${node.category})\n`;
      }
    });

    if (region.notes) {
      output += `\n▓▓▓ NOTES ▓▓▓\n${region.notes}\n`;
    }

    return output;
  }

  generateZoneSummary(zoneId: string): string {
    const zone = this.data.zones.find((z: Zone) => z.id === zoneId);
    if (!zone) return 'Zone not found';

    let output = `═══════════════════════════════════════\n`;
    output += `  ZONE: ${zone.name}\n`;
    output += `═══════════════════════════════════════\n\n`;
    output += `${zone.description}\n\n`;
    output += `Color: ${zone.colorHex}\n`;

    if (zone.parentRegionId) {
      const region = this.data.regions.find((r: Region) => r.id === zone.parentRegionId);
      output += `Parent Region: ${region ? region.name : 'Unknown'}\n`;
    }

    output += `Tags: ${zone.tags.join(', ') || 'None'}\n\n`;

    output += `▓▓▓ TERRITORIES (${zone.territoryNodeIds.length}) ▓▓▓\n`;
    zone.territoryNodeIds.forEach((nodeId: string) => {
      const node = this.data.nodes.find((n: TerritoryNode) => n.id === nodeId);
      if (node) {
        output += `  • ${node.name} (${node.category})\n`;
      }
    });

    if (zone.notes) {
      output += `\n▓▓▓ NOTES ▓▓▓\n${zone.notes}\n`;
    }

    return output;
  }

  exportTerritoryBrief(): string {
    let output = '╔═══════════════════════════════════════════════════════╗\n';
    output += '║       DREAMNET TERRITORY BRIEF v1.0                   ║\n';
    output += '║       OHARA MEGASTRUCTURE MAPPER                      ║\n';
    output += '╚═══════════════════════════════════════════════════════╝\n\n';

    output += `Generated: ${new Date().toISOString()}\n\n`;

    output += '▓▓▓ EXECUTIVE SUMMARY ▓▓▓\n';
    output += `Total Regions: ${this.data.regions.length}\n`;
    output += `Total Zones: ${this.data.zones.length}\n`;
    output += `Total Territory Nodes: ${this.data.nodes.length}\n`;
    output += `Total Corridors: ${this.data.corridors.length}\n`;
    output += `Total Expansion Zones: ${this.data.expansionZones.length}\n`;
    output += `Total Population: ${this.data.populationMarkers.length}\n`;
    output += `Total Flow Traffic Events: ${this.data.flowTraffic.length}\n\n`;

    output += '▓▓▓ TERRITORY BREAKDOWN ▓▓▓\n';
    const categoryCounts: Record<string, number> = {};
    this.data.nodes.forEach((node: TerritoryNode) => {
      categoryCounts[node.category] = (categoryCounts[node.category] || 0) + 1;
    });
    Object.keys(categoryCounts).forEach((cat: string) => {
      const count = categoryCounts[cat];
      if (typeof count === 'number') {
        output += `  ${cat}: ${count} nodes\n`;
      }
    });

    output += '\n▓▓▓ REGIONAL STRUCTURE ▓▓▓\n';
    this.data.regions.forEach((region: Region) => {
      output += `\n[${region.name}]\n`;
      output += `  Territories: ${region.territoryNodeIds.length}\n`;
      output += `  Importance: ${region.importanceLevel}\n`;
    });

    output += '\n▓▓▓ STRATEGIC CORRIDORS ▓▓▓\n';
    const corridorsByStrength: Record<string, number> = {};
    this.data.corridors.forEach((corridor: Corridor) => {
      corridorsByStrength[corridor.strength] = (corridorsByStrength[corridor.strength] || 0) + 1;
    });
    Object.keys(corridorsByStrength).forEach((strength: string) => {
      const count = corridorsByStrength[strength];
      if (typeof count === 'number') {
        output += `  ${strength}: ${count} corridors\n`;
      }
    });

    output += '\n▓▓▓ EXPANSION OPPORTUNITIES ▓▓▓\n';
    this.data.expansionZones.forEach((zone: ExpansionZone) => {
      output += `\n[${zone.name}]\n`;
      output += `  ${zone.description}\n`;
      if (zone.suggestedMiniAppTypes.length > 0) {
        output += `  Suggested: ${zone.suggestedMiniAppTypes.join(', ')}\n`;
      }
    });

    output += '\n═══════════════════════════════════════════════════════\n';
    output += '  DreamNet Territory Brief - End of Document\n';
    output += '═══════════════════════════════════════════════════════\n';

    return output;
  }

  clearAllData(): void {
    this.data = this.getEmptyData();
    this.saveData();
  }
}
