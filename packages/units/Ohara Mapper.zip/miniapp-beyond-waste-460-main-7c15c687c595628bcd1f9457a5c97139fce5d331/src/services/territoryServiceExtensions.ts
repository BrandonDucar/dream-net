// This file contains all the new CRUD operations for the 15 advanced features
// These methods should be added to the TerritoryService class

import type {
  TerritoryHealth,
  TerritoryStatus,
  ResourceProduction,
  ResourceType,
  InfluenceRadius,
  HistoricalEvent,
  Alliance,
  AllianceType,
  AllianceStatus,
  Landmark,
  LandmarkType,
  Migration,
  BorderDynamic,
  BorderType,
  InfrastructureProject,
  ProjectStatus,
  District,
  Mission,
  MissionStatus
} from '@/types/territory';

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

// ======================
// TERRITORY HEALTH OPERATIONS
// ======================

export function createTerritoryHealth(data: any, params: {
  territoryNodeId: string;
  status: TerritoryStatus;
  vitalityScore: number;
  lastActivityDate: string;
  technicalDebt: number;
  notes?: string;
}): TerritoryHealth {
  const now = new Date().toISOString();
  const health: TerritoryHealth = {
    id: generateId(),
    territoryNodeId: params.territoryNodeId,
    status: params.status,
    vitalityScore: params.vitalityScore,
    lastActivityDate: params.lastActivityDate,
    technicalDebt: params.technicalDebt,
    notes: params.notes || '',
    createdAt: now,
    updatedAt: now
  };
  
  data.territoryHealth.push(health);
  return health;
}

export function updateTerritoryHealth(data: any, id: string, updates: Partial<Omit<TerritoryHealth, 'id' | 'createdAt'>>): TerritoryHealth | null {
  const index = data.territoryHealth.findIndex((h: TerritoryHealth) => h.id === id);
  if (index === -1) return null;
  
  data.territoryHealth[index] = {
    ...data.territoryHealth[index],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  
  return data.territoryHealth[index];
}

export function getTerritoryHealthByNodeId(data: any, nodeId: string): TerritoryHealth | null {
  return data.territoryHealth.find((h: TerritoryHealth) => h.territoryNodeId === nodeId) || null;
}

export function deleteTerritoryHealth(data: any, id: string): boolean {
  const index = data.territoryHealth.findIndex((h: TerritoryHealth) => h.id === id);
  if (index === -1) return false;
  data.territoryHealth.splice(index, 1);
  return true;
}

// ======================
// RESOURCE PRODUCTION OPERATIONS
// ======================

export function createResourceProduction(data: any, params: {
  territoryNodeId: string;
  resourceType: ResourceType;
  productionRate: number;
  consumptionRate: number;
  notes?: string;
}): ResourceProduction {
  const now = new Date().toISOString();
  const resource: ResourceProduction = {
    id: generateId(),
    territoryNodeId: params.territoryNodeId,
    resourceType: params.resourceType,
    productionRate: params.productionRate,
    consumptionRate: params.consumptionRate,
    surplus: params.productionRate - params.consumptionRate,
    notes: params.notes || '',
    createdAt: now,
    updatedAt: now
  };
  
  data.resourceProduction.push(resource);
  return resource;
}

export function updateResourceProduction(data: any, id: string, updates: Partial<Omit<ResourceProduction, 'id' | 'createdAt'>>): ResourceProduction | null {
  const index = data.resourceProduction.findIndex((r: ResourceProduction) => r.id === id);
  if (index === -1) return null;
  
  const updated = {
    ...data.resourceProduction[index],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  
  if (updated.productionRate !== undefined && updated.consumptionRate !== undefined) {
    updated.surplus = updated.productionRate - updated.consumptionRate;
  }
  
  data.resourceProduction[index] = updated;
  return data.resourceProduction[index];
}

export function getResourceProductionByNodeId(data: any, nodeId: string): ResourceProduction[] {
  return data.resourceProduction.filter((r: ResourceProduction) => r.territoryNodeId === nodeId);
}

export function deleteResourceProduction(data: any, id: string): boolean {
  const index = data.resourceProduction.findIndex((r: ResourceProduction) => r.id === id);
  if (index === -1) return false;
  data.resourceProduction.splice(index, 1);
  return true;
}

// ======================
// INFLUENCE RADIUS OPERATIONS
// ======================

export function createInfluenceRadius(data: any, params: {
  territoryNodeId: string;
  influenceStrength: number;
  radius: number;
  influenceType: string;
  decayRate: number;
  notes?: string;
}): InfluenceRadius {
  const now = new Date().toISOString();
  const influence: InfluenceRadius = {
    id: generateId(),
    territoryNodeId: params.territoryNodeId,
    influenceStrength: params.influenceStrength,
    radius: params.radius,
    influenceType: params.influenceType,
    decayRate: params.decayRate,
    notes: params.notes || '',
    createdAt: now,
    updatedAt: now
  };
  
  data.influenceRadii.push(influence);
  return influence;
}

export function updateInfluenceRadius(data: any, id: string, updates: Partial<Omit<InfluenceRadius, 'id' | 'createdAt'>>): InfluenceRadius | null {
  const index = data.influenceRadii.findIndex((i: InfluenceRadius) => i.id === id);
  if (index === -1) return null;
  
  data.influenceRadii[index] = {
    ...data.influenceRadii[index],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  
  return data.influenceRadii[index];
}

export function getInfluenceRadiusByNodeId(data: any, nodeId: string): InfluenceRadius | null {
  return data.influenceRadii.find((i: InfluenceRadius) => i.territoryNodeId === nodeId) || null;
}

export function deleteInfluenceRadius(data: any, id: string): boolean {
  const index = data.influenceRadii.findIndex((i: InfluenceRadius) => i.id === id);
  if (index === -1) return false;
  data.influenceRadii.splice(index, 1);
  return true;
}

// ======================
// HISTORICAL EVENT OPERATIONS
// ======================

export function createHistoricalEvent(data: any, params: {
  eventType: string;
  title: string;
  description: string;
  relatedEntityType: "node" | "region" | "zone" | "corridor" | "general";
  relatedEntityId?: string | null;
  eventDate?: string;
  tags?: string[];
}): HistoricalEvent {
  const now = new Date().toISOString();
  const event: HistoricalEvent = {
    id: generateId(),
    eventType: params.eventType,
    title: params.title,
    description: params.description,
    relatedEntityType: params.relatedEntityType,
    relatedEntityId: params.relatedEntityId || null,
    eventDate: params.eventDate || now,
    tags: params.tags || [],
    createdAt: now
  };
  
  data.historicalEvents.push(event);
  return event;
}

export function getHistoricalEventsByEntityId(data: any, entityId: string): HistoricalEvent[] {
  return data.historicalEvents.filter((e: HistoricalEvent) => e.relatedEntityId === entityId);
}

export function getHistoricalEventsByType(data: any, eventType: string): HistoricalEvent[] {
  return data.historicalEvents.filter((e: HistoricalEvent) => e.eventType === eventType);
}

export function getAllHistoricalEvents(data: any): HistoricalEvent[] {
  return [...data.historicalEvents].sort((a: HistoricalEvent, b: HistoricalEvent) => 
    new Date(b.eventDate).getTime() - new Date(a.eventDate).getTime()
  );
}

export function deleteHistoricalEvent(data: any, id: string): boolean {
  const index = data.historicalEvents.findIndex((e: HistoricalEvent) => e.id === id);
  if (index === -1) return false;
  data.historicalEvents.splice(index, 1);
  return true;
}

// ======================
// ALLIANCE OPERATIONS
// ======================

export function createAlliance(data: any, params: {
  name: string;
  allianceType: AllianceType;
  territoryNodeIds: string[];
  status: AllianceStatus;
  terms: string;
  benefits: string;
  startDate: string;
  endDate?: string | null;
  notes?: string;
}): Alliance {
  const now = new Date().toISOString();
  const alliance: Alliance = {
    id: generateId(),
    name: params.name,
    allianceType: params.allianceType,
    territoryNodeIds: params.territoryNodeIds,
    status: params.status,
    terms: params.terms,
    benefits: params.benefits,
    startDate: params.startDate,
    endDate: params.endDate || null,
    notes: params.notes || '',
    createdAt: now,
    updatedAt: now
  };
  
  data.alliances.push(alliance);
  return alliance;
}

export function updateAlliance(data: any, id: string, updates: Partial<Omit<Alliance, 'id' | 'createdAt'>>): Alliance | null {
  const index = data.alliances.findIndex((a: Alliance) => a.id === id);
  if (index === -1) return null;
  
  data.alliances[index] = {
    ...data.alliances[index],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  
  return data.alliances[index];
}

export function getAlliancesByNodeId(data: any, nodeId: string): Alliance[] {
  return data.alliances.filter((a: Alliance) => a.territoryNodeIds.includes(nodeId));
}

export function deleteAlliance(data: any, id: string): boolean {
  const index = data.alliances.findIndex((a: Alliance) => a.id === id);
  if (index === -1) return false;
  data.alliances.splice(index, 1);
  return true;
}

// ======================
// LANDMARK OPERATIONS
// ======================

export function createLandmark(data: any, params: {
  territoryNodeId: string;
  name: string;
  landmarkType: LandmarkType;
  description: string;
  effectBonus: string;
  iconEmoji: string;
  notes?: string;
}): Landmark {
  const now = new Date().toISOString();
  const landmark: Landmark = {
    id: generateId(),
    territoryNodeId: params.territoryNodeId,
    name: params.name,
    landmarkType: params.landmarkType,
    description: params.description,
    effectBonus: params.effectBonus,
    iconEmoji: params.iconEmoji,
    notes: params.notes || '',
    createdAt: now,
    updatedAt: now
  };
  
  data.landmarks.push(landmark);
  return landmark;
}

export function updateLandmark(data: any, id: string, updates: Partial<Omit<Landmark, 'id' | 'createdAt'>>): Landmark | null {
  const index = data.landmarks.findIndex((l: Landmark) => l.id === id);
  if (index === -1) return null;
  
  data.landmarks[index] = {
    ...data.landmarks[index],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  
  return data.landmarks[index];
}

export function getLandmarksByNodeId(data: any, nodeId: string): Landmark[] {
  return data.landmarks.filter((l: Landmark) => l.territoryNodeId === nodeId);
}

export function deleteLandmark(data: any, id: string): boolean {
  const index = data.landmarks.findIndex((l: Landmark) => l.id === id);
  if (index === -1) return false;
  data.landmarks.splice(index, 1);
  return true;
}

// ======================
// MIGRATION OPERATIONS
// ======================

export function createMigration(data: any, params: {
  populationMarkerId: string;
  fromNodeId: string;
  toNodeId: string;
  migrationDate: string;
  reason: string;
  pushFactors: string[];
  pullFactors: string[];
  notes?: string;
}): Migration {
  const now = new Date().toISOString();
  const migration: Migration = {
    id: generateId(),
    populationMarkerId: params.populationMarkerId,
    fromNodeId: params.fromNodeId,
    toNodeId: params.toNodeId,
    migrationDate: params.migrationDate,
    reason: params.reason,
    pushFactors: params.pushFactors,
    pullFactors: params.pullFactors,
    notes: params.notes || '',
    createdAt: now
  };
  
  data.migrations.push(migration);
  return migration;
}

export function getMigrationsByNodeId(data: any, nodeId: string): Migration[] {
  return data.migrations.filter((m: Migration) => m.fromNodeId === nodeId || m.toNodeId === nodeId);
}

export function getMigrationsByPopulationId(data: any, populationId: string): Migration[] {
  return data.migrations.filter((m: Migration) => m.populationMarkerId === populationId);
}

export function deleteMigration(data: any, id: string): boolean {
  const index = data.migrations.findIndex((m: Migration) => m.id === id);
  if (index === -1) return false;
  data.migrations.splice(index, 1);
  return true;
}

// ======================
// BORDER DYNAMIC OPERATIONS
// ======================

export function createBorderDynamic(data: any, params: {
  nodeAId: string;
  nodeBId: string;
  borderType: BorderType;
  contestedArea: boolean;
  incidentCount: number;
  notes?: string;
}): BorderDynamic {
  const now = new Date().toISOString();
  const border: BorderDynamic = {
    id: generateId(),
    nodeAId: params.nodeAId,
    nodeBId: params.nodeBId,
    borderType: params.borderType,
    contestedArea: params.contestedArea,
    incidentCount: params.incidentCount,
    notes: params.notes || '',
    createdAt: now,
    updatedAt: now
  };
  
  data.borderDynamics.push(border);
  return border;
}

export function updateBorderDynamic(data: any, id: string, updates: Partial<Omit<BorderDynamic, 'id' | 'createdAt'>>): BorderDynamic | null {
  const index = data.borderDynamics.findIndex((b: BorderDynamic) => b.id === id);
  if (index === -1) return null;
  
  data.borderDynamics[index] = {
    ...data.borderDynamics[index],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  
  return data.borderDynamics[index];
}

export function getBorderDynamicsByNodeId(data: any, nodeId: string): BorderDynamic[] {
  return data.borderDynamics.filter((b: BorderDynamic) => b.nodeAId === nodeId || b.nodeBId === nodeId);
}

export function deleteBorderDynamic(data: any, id: string): boolean {
  const index = data.borderDynamics.findIndex((b: BorderDynamic) => b.id === id);
  if (index === -1) return false;
  data.borderDynamics.splice(index, 1);
  return true;
}

// ======================
// INFRASTRUCTURE PROJECT OPERATIONS
// ======================

export function createInfrastructureProject(data: any, params: {
  name: string;
  projectType: string;
  targetEntityType: "node" | "region" | "zone" | "corridor";
  targetEntityId: string;
  status: ProjectStatus;
  resourceRequirements: string;
  completionBenefits: string;
  startDate: string;
  expectedCompletionDate?: string | null;
  notes?: string;
}): InfrastructureProject {
  const now = new Date().toISOString();
  const project: InfrastructureProject = {
    id: generateId(),
    name: params.name,
    projectType: params.projectType,
    targetEntityType: params.targetEntityType,
    targetEntityId: params.targetEntityId,
    status: params.status,
    resourceRequirements: params.resourceRequirements,
    completionBenefits: params.completionBenefits,
    startDate: params.startDate,
    expectedCompletionDate: params.expectedCompletionDate || null,
    actualCompletionDate: null,
    notes: params.notes || '',
    createdAt: now,
    updatedAt: now
  };
  
  data.infrastructureProjects.push(project);
  return project;
}

export function updateInfrastructureProject(data: any, id: string, updates: Partial<Omit<InfrastructureProject, 'id' | 'createdAt'>>): InfrastructureProject | null {
  const index = data.infrastructureProjects.findIndex((p: InfrastructureProject) => p.id === id);
  if (index === -1) return null;
  
  data.infrastructureProjects[index] = {
    ...data.infrastructureProjects[index],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  
  return data.infrastructureProjects[index];
}

export function getInfrastructureProjectsByEntityId(data: any, entityId: string): InfrastructureProject[] {
  return data.infrastructureProjects.filter((p: InfrastructureProject) => p.targetEntityId === entityId);
}

export function deleteInfrastructureProject(data: any, id: string): boolean {
  const index = data.infrastructureProjects.findIndex((p: InfrastructureProject) => p.id === id);
  if (index === -1) return false;
  data.infrastructureProjects.splice(index, 1);
  return true;
}

// ======================
// DISTRICT OPERATIONS
// ======================

export function createDistrict(data: any, params: {
  parentNodeId: string;
  name: string;
  specialization: string;
  description: string;
  x: number;
  y: number;
  notes?: string;
}): District {
  const now = new Date().toISOString();
  const district: District = {
    id: generateId(),
    parentNodeId: params.parentNodeId,
    name: params.name,
    specialization: params.specialization,
    description: params.description,
    x: params.x,
    y: params.y,
    notes: params.notes || '',
    createdAt: now,
    updatedAt: now
  };
  
  data.districts.push(district);
  return district;
}

export function updateDistrict(data: any, id: string, updates: Partial<Omit<District, 'id' | 'createdAt'>>): District | null {
  const index = data.districts.findIndex((d: District) => d.id === id);
  if (index === -1) return null;
  
  data.districts[index] = {
    ...data.districts[index],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  
  return data.districts[index];
}

export function getDistrictsByParentNodeId(data: any, parentNodeId: string): District[] {
  return data.districts.filter((d: District) => d.parentNodeId === parentNodeId);
}

export function deleteDistrict(data: any, id: string): boolean {
  const index = data.districts.findIndex((d: District) => d.id === id);
  if (index === -1) return false;
  data.districts.splice(index, 1);
  return true;
}

// ======================
// MISSION OPERATIONS
// ======================

export function createMission(data: any, params: {
  title: string;
  description: string;
  missionType: string;
  targetMetric: string;
  targetValue: number;
  currentValue: number;
  status: MissionStatus;
  reward: string;
  startDate: string;
  notes?: string;
}): Mission {
  const now = new Date().toISOString();
  const mission: Mission = {
    id: generateId(),
    title: params.title,
    description: params.description,
    missionType: params.missionType,
    targetMetric: params.targetMetric,
    targetValue: params.targetValue,
    currentValue: params.currentValue,
    status: params.status,
    reward: params.reward,
    startDate: params.startDate,
    completionDate: null,
    notes: params.notes || '',
    createdAt: now,
    updatedAt: now
  };
  
  data.missions.push(mission);
  return mission;
}

export function updateMission(data: any, id: string, updates: Partial<Omit<Mission, 'id' | 'createdAt'>>): Mission | null {
  const index = data.missions.findIndex((m: Mission) => m.id === id);
  if (index === -1) return null;
  
  data.missions[index] = {
    ...data.missions[index],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  
  return data.missions[index];
}

export function getActiveMissions(data: any): Mission[] {
  return data.missions.filter((m: Mission) => m.status === 'active');
}

export function deleteMission(data: any, id: string): boolean {
  const index = data.missions.findIndex((m: Mission) => m.id === id);
  if (index === -1) return false;
  data.missions.splice(index, 1);
  return true;
}

// ======================
// ANALYTICS FUNCTIONS
// ======================

export function calculateSovereigntyMetrics(data: any): {
  totalTerritory: number;
  totalInfluence: number;
  totalProduction: number;
  totalPopulation: number;
  corridorDensity: number;
  expansionRate: number;
  dominanceScore: number;
} {
  const totalTerritory = data.nodes.length;
  const totalInfluence = data.influenceRadii.reduce((sum: number, inf: InfluenceRadius) => sum + inf.influenceStrength, 0);
  const totalProduction = data.resourceProduction.reduce((sum: number, res: ResourceProduction) => sum + res.surplus, 0);
  const totalPopulation = data.populationMarkers.length;
  const corridorDensity = totalTerritory > 0 ? data.corridors.length / totalTerritory : 0;
  const expansionRate = data.expansionZones.length;
  const dominanceScore = totalTerritory * 10 + totalInfluence + totalPopulation * 5 + (corridorDensity * 100);
  
  return {
    totalTerritory,
    totalInfluence,
    totalProduction,
    totalPopulation,
    corridorDensity,
    expansionRate,
    dominanceScore
  };
}

export function getTerrainTypeLabel(terrainType: string | null): string {
  const labels: Record<string, string> = {
    'mountains': '🏔️ Mountains',
    'coastal': '🏖️ Coastal',
    'forests': '🌳 Forests',
    'desert': '🏜️ Desert',
    'urban-core': '🏙️ Urban Core'
  };
  return terrainType ? labels[terrainType] || terrainType : 'Unspecified';
}
