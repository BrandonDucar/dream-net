export type ImportanceLevel = "low" | "medium" | "high" | "critical";
export type CorridorType = 
  | "data-flow"
  | "creative-flow"
  | "ops-flow"
  | "social-flow"
  | "narrative-flow"
  | "pickleball-flow"
  | "mixed";
export type CorridorStrength = "weak" | "normal" | "strong" | "critical";
export type FlowType = "content" | "drops" | "scripts" | "ops" | "pickleball" | "culture" | "other";
export type FlowMagnitude = "low" | "medium" | "high" | "extreme";
export type PopulationRole = "worker" | "guardian" | "scout" | "operator" | "builder" | "other";
export type TerritoryStatus = "thriving" | "stable" | "dormant" | "under-siege" | "abandoned";
export type ResourceType = "content" | "scripts" | "drops" | "culture" | "infrastructure" | "social-capital";
export type AllianceType = "trade-agreement" | "defense-pact" | "cultural-exchange" | "joint-venture";
export type AllianceStatus = "active" | "expired" | "violated" | "under-negotiation";
export type LandmarkType = "cultural-hub" | "innovation-center" | "social-nexus" | "infrastructure-masterwork";
export type BorderType = "clear" | "disputed" | "porous" | "fortified";
export type ProjectStatus = "planned" | "in-progress" | "completed" | "abandoned";
export type TerrainType = "mountains" | "coastal" | "forests" | "desert" | "urban-core";
export type MissionStatus = "active" | "completed" | "failed";

export interface SEOMeta {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export interface TerritoryNode {
  id: string;
  miniAppId: string | null;
  name: string;
  category: string;
  description: string;
  importanceLevel: ImportanceLevel;
  regionId: string | null;
  zoneId: string | null;
  x: number;
  y: number;
  neighbors: string[];
  tags: string[];
  notes: string;
  terrainType: TerrainType | null;
  seo: SEOMeta;
  createdAt: string;
  updatedAt: string;
}

export interface Region {
  id: string;
  name: string;
  description: string;
  colorHex: string;
  importanceLevel: ImportanceLevel;
  territoryNodeIds: string[];
  tags: string[];
  notes: string;
  seo: SEOMeta;
  createdAt: string;
  updatedAt: string;
}

export interface Zone {
  id: string;
  name: string;
  description: string;
  parentRegionId: string | null;
  colorHex: string;
  territoryNodeIds: string[];
  tags: string[];
  notes: string;
  seo: SEOMeta;
  createdAt: string;
  updatedAt: string;
}

export interface Corridor {
  id: string;
  name: string;
  description: string;
  fromNodeId: string;
  toNodeId: string;
  corridorType: CorridorType;
  strength: CorridorStrength;
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface ExpansionZone {
  id: string;
  name: string;
  description: string;
  suggestedMiniAppTypes: string[];
  coordinates: number[];
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface PopulationMarker {
  id: string;
  identityId: string;
  identityName: string;
  locatedInNodeId: string;
  role: PopulationRole;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface FlowTraffic {
  id: string;
  fromNodeId: string;
  toNodeId: string;
  flowType: FlowType;
  magnitude: FlowMagnitude;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

// NEW FEATURE INTERFACES

export interface TerritoryHealth {
  id: string;
  territoryNodeId: string;
  status: TerritoryStatus;
  vitalityScore: number; // 0-100
  lastActivityDate: string;
  technicalDebt: number; // 0-100
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface ResourceProduction {
  id: string;
  territoryNodeId: string;
  resourceType: ResourceType;
  productionRate: number;
  consumptionRate: number;
  surplus: number;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface InfluenceRadius {
  id: string;
  territoryNodeId: string;
  influenceStrength: number; // 0-100
  radius: number;
  influenceType: string;
  decayRate: number;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface HistoricalEvent {
  id: string;
  eventType: string;
  title: string;
  description: string;
  relatedEntityType: "node" | "region" | "zone" | "corridor" | "general";
  relatedEntityId: string | null;
  eventDate: string;
  tags: string[];
  createdAt: string;
}

export interface Alliance {
  id: string;
  name: string;
  allianceType: AllianceType;
  territoryNodeIds: string[];
  status: AllianceStatus;
  terms: string;
  benefits: string;
  startDate: string;
  endDate: string | null;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface Landmark {
  id: string;
  territoryNodeId: string;
  name: string;
  landmarkType: LandmarkType;
  description: string;
  effectBonus: string;
  iconEmoji: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface Migration {
  id: string;
  populationMarkerId: string;
  fromNodeId: string;
  toNodeId: string;
  migrationDate: string;
  reason: string;
  pushFactors: string[];
  pullFactors: string[];
  notes: string;
  createdAt: string;
}

export interface BorderDynamic {
  id: string;
  nodeAId: string;
  nodeBId: string;
  borderType: BorderType;
  contestedArea: boolean;
  incidentCount: number;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface InfrastructureProject {
  id: string;
  name: string;
  projectType: string;
  targetEntityType: "node" | "region" | "zone" | "corridor";
  targetEntityId: string;
  status: ProjectStatus;
  resourceRequirements: string;
  completionBenefits: string;
  startDate: string;
  expectedCompletionDate: string | null;
  actualCompletionDate: string | null;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface District {
  id: string;
  parentNodeId: string;
  name: string;
  specialization: string;
  description: string;
  x: number; // relative to parent
  y: number; // relative to parent
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  missionType: string;
  targetMetric: string;
  targetValue: number;
  currentValue: number;
  status: MissionStatus;
  reward: string;
  startDate: string;
  completionDate: string | null;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface TerritoryData {
  nodes: TerritoryNode[];
  regions: Region[];
  zones: Zone[];
  corridors: Corridor[];
  expansionZones: ExpansionZone[];
  populationMarkers: PopulationMarker[];
  flowTraffic: FlowTraffic[];
  territoryHealth: TerritoryHealth[];
  resourceProduction: ResourceProduction[];
  influenceRadii: InfluenceRadius[];
  historicalEvents: HistoricalEvent[];
  alliances: Alliance[];
  landmarks: Landmark[];
  migrations: Migration[];
  borderDynamics: BorderDynamic[];
  infrastructureProjects: InfrastructureProject[];
  districts: District[];
  missions: Mission[];
}

export interface TerritoryFilters {
  category?: string;
  regionId?: string;
  zoneId?: string;
  tag?: string;
  importanceLevel?: ImportanceLevel;
}
