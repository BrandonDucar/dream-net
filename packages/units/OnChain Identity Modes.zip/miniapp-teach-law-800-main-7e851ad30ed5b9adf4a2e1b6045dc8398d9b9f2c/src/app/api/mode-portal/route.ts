import { NextRequest, NextResponse } from 'next/server';

// Cross-app portal API for reading user modes
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const address = searchParams.get('address');

  if (!address) {
    return NextResponse.json(
      { error: 'Wallet address required' },
      { status: 400 }
    );
  }

  try {
    // In production, this would read from the smart contract
    // For now, we'll simulate the response
    const mockModeData = {
      address,
      mode: {
        id: 'builder',
        name: 'Builder Mode',
        emoji: '🛠️',
        theme: {
          primaryColor: '#0052FF',
          accentColor: '#00D4FF',
        },
        socialPresence: {
          visibility: 'public',
        },
      },
      timestamp: Date.now(),
    };

    return NextResponse.json(
      {
        success: true,
        data: mockModeData,
      },
      {
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET',
          'Access-Control-Allow-Headers': 'Content-Type',
        },
      }
    );
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch mode data' },
      { status: 500 }
    );
  }
}

// Handle CORS preflight
export async function OPTIONS() {
  return NextResponse.json(
    {},
    {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
    }
  );
}
