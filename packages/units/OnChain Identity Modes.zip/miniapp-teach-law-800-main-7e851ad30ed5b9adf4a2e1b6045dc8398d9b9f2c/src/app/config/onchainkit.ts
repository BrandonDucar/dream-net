export const ONCHAINKIT_PROJECT_ID = 'cm5yjbh8z01lv6heoze3v3ep5';
export const ONCHAINKIT_API_KEY = 'client-WY5fRbUUsnYnSBnU7hp47apYGAdUgABi38uhK4PxBYLpx';
