import type { Metadata } from 'next';
import '@coinbase/onchainkit/styles.css';
import './globals.css';
import { Providers } from './providers';
import FarcasterWrapper from "@/components/FarcasterWrapper";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
        <html lang="en">
          <body>
            <Providers>
      <FarcasterWrapper>
        {children}
      </FarcasterWrapper>
      </Providers>
          </body>
        </html>
      );
}

export const metadata: Metadata = {
        title: "OnChain Identity Modes",
        description: "Attach unique modes to each wallet. Customize transaction settings, UI themes, and social presence with Builder, Collector, Stealth, and more modes for personalized identity.",
        other: { "fc:frame": JSON.stringify({"version":"next","imageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_bfe42114-8679-4821-8754-38442759410d-kME3w2n0DibcmgwEOh3xUrdoE5SuSr","button":{"title":"Open with Ohara","action":{"type":"launch_frame","name":"OnChain Identity Modes","url":"https://teach-law-800.app.ohara.ai","splashImageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/farcaster/splash_images/splash_image1.svg","splashBackgroundColor":"#ffffff"}}}
        ) }
    };
