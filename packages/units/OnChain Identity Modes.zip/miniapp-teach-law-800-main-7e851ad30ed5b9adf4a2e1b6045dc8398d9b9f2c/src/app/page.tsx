'use client'
import { useState, useEffect } from 'react';
import { usePrivy } from '@privy-io/react-auth';
import { useAccount } from 'wagmi';
import { MODE_PRESETS, type ModeId, type ModeConfig } from '@/types/modes';
import { ModeCard } from '@/components/mode-card';
import { ModeConfigPanel } from '@/components/mode-config-panel';
import { ModeAnalyticsPanel } from '@/components/mode-analytics-panel';
import { SocialModesPanel } from '@/components/social-modes-panel';
import { AutomationPanel } from '@/components/automation-panel';
import { ModePortalEmbed } from '@/components/mode-portal-embed';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Wallet, Settings, Save, LogOut, BarChart3, Users, Zap, Code, Cloud } from 'lucide-react';
import { toast } from 'sonner';
import { useModeAnalytics } from '@/hooks/use-mode-analytics';
import { useModeContract } from '@/hooks/use-mode-contract';
import { getAutomationEngine } from '@/lib/automation-engine';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function HumanModePage() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const { ready, authenticated, login, logout, user } = usePrivy();
  const { address, status } = useAccount();
  const [selectedMode, setSelectedMode] = useState<ModeId>('builder');
  const [activeMode, setActiveMode] = useState<ModeConfig>(MODE_PRESETS.builder);
  const [customConfig, setCustomConfig] = useState<ModeConfig>(MODE_PRESETS.builder);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  
  const { startSession, endSession } = useModeAnalytics();
  const { saveModeOnchain } = useModeContract();

  useEffect(() => {
    if (address) {
      const saved = localStorage.getItem(`human-mode-${address}`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved) as { modeId: ModeId; config: ModeConfig };
          setSelectedMode(parsed.modeId);
          setActiveMode(parsed.config);
          setCustomConfig(parsed.config);
        } catch (error) {
          console.error('Failed to load saved mode:', error);
        }
      }
    }
  }, [address]);

  const handleModeSelect = (modeId: ModeId) => {
    setSelectedMode(modeId);
    setCustomConfig(MODE_PRESETS[modeId]);
    setHasUnsavedChanges(false);
  };

  const handleConfigChange = (config: ModeConfig) => {
    setCustomConfig(config);
    setHasUnsavedChanges(true);
  };

  const handleSave = () => {
    if (!address) {
      toast.error('Please connect your wallet first');
      return;
    }

    try {
      const saveData = {
        modeId: selectedMode,
        config: customConfig,
      };
      localStorage.setItem(`human-mode-${address}`, JSON.stringify(saveData));
      setActiveMode(customConfig);
      setHasUnsavedChanges(false);
      toast.success(`${customConfig.name} saved successfully!`);
    } catch (error) {
      console.error('Failed to save mode:', error);
      toast.error('Failed to save mode settings');
    }
  };

  const handleReset = () => {
    setCustomConfig(MODE_PRESETS[selectedMode]);
    setHasUnsavedChanges(false);
    toast.info('Configuration reset to defaults');
  };

  if (!ready) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading HUMAN MODE...</p>
        </div>
      </div>
    );
  }

  if (!authenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-4">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 text-6xl">🧬</div>
            <CardTitle className="text-3xl">HUMAN MODE</CardTitle>
            <CardDescription>Your onchain personality layer on Base</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                Connect your wallet to set your mode and customize your Base identity.
              </p>
              <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                <li>Choose from 7 unique personality modes</li>
                <li>Configure transaction settings</li>
                <li>Customize your social presence</li>
                <li>Set risk limits and auto-behaviors</li>
              </ul>
            </div>
            <Button onClick={login} className="w-full" size="lg">
              <Wallet className="mr-2 h-4 w-4" />
              Connect Wallet
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-bold mb-2">HUMAN MODE 🧬</h1>
            <p className="text-muted-foreground">Your onchain personality layer on Base</p>
          </div>
          <Card className="w-full md:w-auto">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground mb-1">Connected Wallet</p>
                  <p className="font-mono text-sm">
                    {address ? `${address.slice(0, 6)}...${address.slice(-4)}` : 'Not connected'}
                  </p>
                  {user?.email && (
                    <p className="text-xs text-muted-foreground mt-1">{user.email.address}</p>
                  )}
                </div>
                <Button variant="outline" size="icon" onClick={() => logout()}>
                  <LogOut className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="text-2xl">{activeMode.emoji}</span>
              Active Mode: {activeMode.name}
            </CardTitle>
            <CardDescription>{activeMode.tagline}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary">Gas: {activeMode.txSettings.gasPriority}</Badge>
              <Badge variant="secondary">
                Slippage: {activeMode.txSettings.slippageTolerance}%
              </Badge>
              <Badge variant="secondary">{activeMode.socialPresence.visibility}</Badge>
              <Badge variant="secondary">Max TX: {activeMode.riskLimits.maxSingleTx} ETH</Badge>
              <Badge variant="secondary">
                Daily Limit: {activeMode.riskLimits.dailyLimit} ETH
              </Badge>
              {activeMode.txSettings.autoApprove && (
                <Badge variant="default">Auto-approve ON</Badge>
              )}
              {activeMode.autoTagging.enabled && (
                <Badge variant="default">Auto-tag: {activeMode.autoTagging.tagPattern}</Badge>
              )}
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="select" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6">
            <TabsTrigger value="select">
              <Wallet className="mr-2 h-4 w-4" />
              Modes
            </TabsTrigger>
            <TabsTrigger value="configure">
              <Settings className="mr-2 h-4 w-4" />
              Config
              {hasUnsavedChanges && <Badge className="ml-2 hidden lg:inline">*</Badge>}
            </TabsTrigger>
            <TabsTrigger value="automation">
              <Zap className="mr-2 h-4 w-4" />
              Auto
            </TabsTrigger>
            <TabsTrigger value="analytics">
              <BarChart3 className="mr-2 h-4 w-4" />
              Stats
            </TabsTrigger>
            <TabsTrigger value="social">
              <Users className="mr-2 h-4 w-4" />
              Social
            </TabsTrigger>
            <TabsTrigger value="portal">
              <Code className="mr-2 h-4 w-4" />
              Portal
            </TabsTrigger>
          </TabsList>

          <TabsContent value="select" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Object.entries(MODE_PRESETS).map(([id, mode]) => (
                <ModeCard
                  key={id}
                  mode={mode}
                  isSelected={selectedMode === id}
                  onSelect={() => handleModeSelect(id as ModeId)}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="configure" className="space-y-4">
            <ModeConfigPanel mode={customConfig} onChange={handleConfigChange} />
            <div className="flex gap-4">
              <Button onClick={handleSave} size="lg" className="flex-1" disabled={!hasUnsavedChanges}>
                <Save className="mr-2 h-4 w-4" />
                Save Configuration
              </Button>
              <Button
                onClick={() => {
                  handleSave();
                  saveModeOnchain(customConfig);
                }}
                size="lg"
                className="flex-1"
                disabled={!hasUnsavedChanges}
              >
                <Cloud className="mr-2 h-4 w-4" />
                Save Onchain
              </Button>
              <Button
                onClick={handleReset}
                size="lg"
                variant="outline"
                disabled={!hasUnsavedChanges}
              >
                Reset
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="automation" className="space-y-4">
            <AutomationPanel activeMode={activeMode} />
          </TabsContent>

          <TabsContent value="analytics" className="space-y-4">
            <ModeAnalyticsPanel />
          </TabsContent>

          <TabsContent value="social" className="space-y-4">
            <SocialModesPanel onImportMode={(config) => {
              setCustomConfig(config);
              setSelectedMode(config.id);
              setHasUnsavedChanges(true);
            }} />
          </TabsContent>

          <TabsContent value="portal" className="space-y-4">
            <ModePortalEmbed />
          </TabsContent>
        </Tabs>

        <Card className="bg-muted/50">
          <CardHeader>
            <CardTitle className="text-lg">About HUMAN MODE</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-2">
            <p>
              HUMAN MODE is a Base-native onchain personality layer. Your mode settings define how
              your wallet behaves, from transaction defaults to social presence.
            </p>
            <p>
              Each mode comes with pre-configured settings optimized for different use cases, but
              you can customize everything to match your personal style.
            </p>
            <p className="font-medium text-foreground">
              New features: Store your mode onchain, track analytics, discover community modes,
              automate behaviors, and embed your mode in other apps.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
