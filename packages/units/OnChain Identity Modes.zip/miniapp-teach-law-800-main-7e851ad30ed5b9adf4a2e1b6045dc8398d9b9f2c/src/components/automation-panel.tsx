'use client'
import type { FC } from 'react';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Zap, Shield, MessageSquare, Tag, Activity } from 'lucide-react';
import { toast } from 'sonner';
import { getAutomationEngine } from '@/lib/automation-engine';
import type { ModeConfig } from '@/types/modes';

type AutomationPanelProps = {
  activeMode: ModeConfig;
};

export const AutomationPanel: FC<AutomationPanelProps> = ({ activeMode }) => {
  const [isEnabled, setIsEnabled] = useState(true);
  const [dailySpent, setDailySpent] = useState(0);
  const [testTxValue, setTestTxValue] = useState(0.5);

  useEffect(() => {
    const engine = getAutomationEngine(activeMode);
    engine.setEnabled(isEnabled);
  }, [isEnabled, activeMode]);

  const handleTestRiskCheck = () => {
    const engine = getAutomationEngine(activeMode);
    const result = engine.checkRiskLimits(testTxValue, dailySpent);

    if (result.allowed) {
      if (result.message) {
        toast.warning(result.message);
      } else {
        toast.success('Transaction allowed!');
      }
    } else {
      toast.error(result.message || 'Transaction blocked');
    }
  };

  const handleTestAutoApprove = () => {
    const engine = getAutomationEngine(activeMode);
    const shouldApprove = engine.shouldAutoApprove(testTxValue);

    if (shouldApprove) {
      toast.success('Transaction would be auto-approved');
    } else {
      toast.info('Manual confirmation required');
    }
  };

  const handleShowGreeting = () => {
    const engine = getAutomationEngine(activeMode);
    const greeting = engine.getGreeting();
    if (greeting) {
      toast.info(greeting, {
        description: 'Mode greeting message',
      });
    }
  };

  const engine = getAutomationEngine(activeMode);
  const autoTags = engine.getAutoTags();
  const gasSettings = engine.getGasSettings();
  const socialSettings = engine.getSocialSettings();

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Automation Engine
              </CardTitle>
              <CardDescription>Mode-based behaviors and auto-execution</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Label htmlFor="automation-toggle">Enabled</Label>
              <Switch
                id="automation-toggle"
                checked={isEnabled}
                onCheckedChange={setIsEnabled}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium text-sm">Status</h4>
              <Badge variant={isEnabled ? 'default' : 'secondary'}>
                {isEnabled ? 'Active' : 'Disabled'}
              </Badge>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium text-sm">Current Mode</h4>
              <div className="flex items-center gap-2">
                <span className="text-2xl">{activeMode.emoji}</span>
                <span className="font-medium">{activeMode.name}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Shield className="h-4 w-4" />
            Risk Management
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs">Max Single TX</Label>
              <p className="text-2xl font-bold">{activeMode.riskLimits.maxSingleTx} ETH</p>
            </div>
            <div>
              <Label className="text-xs">Daily Limit</Label>
              <p className="text-2xl font-bold">{activeMode.riskLimits.dailyLimit} ETH</p>
            </div>
            <div>
              <Label className="text-xs">Warning At</Label>
              <p className="text-2xl font-bold">{activeMode.riskLimits.warningThreshold} ETH</p>
            </div>
            <div>
              <Label className="text-xs">Confirmation</Label>
              <Badge variant={activeMode.riskLimits.requireConfirmation ? 'default' : 'secondary'}>
                {activeMode.riskLimits.requireConfirmation ? 'Required' : 'Optional'}
              </Badge>
            </div>
          </div>

          <div className="border-t pt-4 space-y-2">
            <Label>Test Transaction (ETH)</Label>
            <div className="flex gap-2">
              <input
                type="number"
                step="0.1"
                value={testTxValue}
                onChange={(e) => setTestTxValue(parseFloat(e.target.value) || 0)}
                className="flex-1 px-3 py-2 border rounded-md"
              />
              <Button onClick={handleTestRiskCheck} variant="outline">
                Check Risk
              </Button>
              <Button onClick={handleTestAutoApprove} variant="outline">
                Check Auto-approve
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <MessageSquare className="h-4 w-4" />
              Auto-responses
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="text-xs">Greeting Message</Label>
              <p className="text-sm text-muted-foreground italic">
                {activeMode.autoResponse.greeting || 'None'}
              </p>
            </div>
            <div className="space-y-2">
              <Label className="text-xs">Transaction Message</Label>
              <p className="text-sm text-muted-foreground italic">
                {activeMode.autoResponse.transactionMessage || 'None'}
              </p>
            </div>
            <Button onClick={handleShowGreeting} variant="outline" size="sm" className="w-full">
              Test Greeting
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Tag className="h-4 w-4" />
              Auto-tagging
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="text-xs">Active Tags</Label>
              <div className="flex flex-wrap gap-2">
                {autoTags.length > 0 ? (
                  autoTags.map((tag, index) => (
                    <Badge key={index} variant="secondary">
                      {tag}
                    </Badge>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground">No tags enabled</p>
                )}
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-xs">Include Emoji</Label>
              <Badge variant={activeMode.autoTagging.includeEmoji ? 'default' : 'secondary'}>
                {activeMode.autoTagging.includeEmoji ? 'Yes' : 'No'}
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Activity className="h-4 w-4" />
            Auto-logging
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <p className="text-xs text-muted-foreground mb-2">Transactions</p>
              <Badge variant={activeMode.autoLog.logTransactions ? 'default' : 'secondary'}>
                {activeMode.autoLog.logTransactions ? 'Enabled' : 'Disabled'}
              </Badge>
            </div>
            <div className="text-center">
              <p className="text-xs text-muted-foreground mb-2">Interactions</p>
              <Badge variant={activeMode.autoLog.logInteractions ? 'default' : 'secondary'}>
                {activeMode.autoLog.logInteractions ? 'Enabled' : 'Disabled'}
              </Badge>
            </div>
            <div className="text-center">
              <p className="text-xs text-muted-foreground mb-2">Balance Changes</p>
              <Badge variant={activeMode.autoLog.logBalanceChanges ? 'default' : 'secondary'}>
                {activeMode.autoLog.logBalanceChanges ? 'Enabled' : 'Disabled'}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-muted/50">
        <CardHeader>
          <CardTitle className="text-lg">Gas & Social Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-xs">Gas Priority</Label>
            <p className="text-sm font-medium">{gasSettings.priority.toUpperCase()}</p>
            {gasSettings.maxGasPrice && (
              <p className="text-xs text-muted-foreground">Max: {gasSettings.maxGasPrice} gwei</p>
            )}
          </div>
          <div>
            <Label className="text-xs">Social Visibility</Label>
            <div className="flex flex-wrap gap-2 mt-1">
              <Badge variant="outline">{socialSettings.visibility}</Badge>
              {socialSettings.shouldShare && <Badge>Auto-share</Badge>}
              {socialSettings.shareTransactions && <Badge variant="secondary">Share TXs</Badge>}
              {socialSettings.shareBalance && <Badge variant="secondary">Share Balance</Badge>}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
