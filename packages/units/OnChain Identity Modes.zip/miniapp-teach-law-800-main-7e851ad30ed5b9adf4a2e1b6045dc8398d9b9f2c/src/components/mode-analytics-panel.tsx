'use client'
import type { FC } from 'react';
import { useModeAnalytics } from '@/hooks/use-mode-analytics';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { BarChart3, Clock, TrendingUp, Zap } from 'lucide-react';
import { MODE_PRESETS, type ModeId } from '@/types/modes';

export const ModeAnalyticsPanel: FC = () => {
  const { analytics, formatDuration, getModeStats } = useModeAnalytics();

  const sortedModes = (Object.keys(MODE_PRESETS) as ModeId[]).sort((a, b) => {
    return getModeStats(b).totalTime - getModeStats(a).totalTime;
  });

  const totalTime = Object.values(analytics.modeStats).reduce(
    (sum, stats) => sum + stats.totalTime,
    0
  );

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Global Stats
          </CardTitle>
          <CardDescription>Your overall HUMAN MODE activity</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Mode Switches</p>
              <p className="text-2xl font-bold">{analytics.globalStats.totalModeSwitches}</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Total Transactions</p>
              <p className="text-2xl font-bold">{analytics.globalStats.totalTransactions}</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Gas Spent</p>
              <p className="text-2xl font-bold">{analytics.globalStats.totalGasSpent.toFixed(4)}</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Most Used</p>
              <p className="text-2xl font-bold">
                {MODE_PRESETS[analytics.globalStats.mostUsedMode].emoji}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Time Breakdown by Mode
          </CardTitle>
          <CardDescription>How you spend your onchain time</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {sortedModes.map((modeId) => {
            const mode = MODE_PRESETS[modeId];
            const stats = getModeStats(modeId);
            const percentage = totalTime > 0 ? (stats.totalTime / totalTime) * 100 : 0;

            return (
              <div key={modeId} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{mode.emoji}</span>
                    <span className="font-medium">{mode.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{stats.totalSessions} sessions</Badge>
                    <span className="text-sm text-muted-foreground">
                      {formatDuration(stats.totalTime)}
                    </span>
                  </div>
                </div>
                <Progress value={percentage} className="h-2" />
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{percentage.toFixed(1)}% of total time</span>
                  <span>{stats.transactionCount} txs</span>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <TrendingUp className="h-4 w-4" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            {analytics.transactions.slice(-5).reverse().map((tx) => (
              <div key={tx.hash} className="flex items-center justify-between py-2 border-b last:border-0">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{MODE_PRESETS[tx.modeId].emoji}</span>
                  <div>
                    <p className="text-sm font-medium">
                      {tx.value.toFixed(4)} ETH
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(tx.timestamp).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <Badge variant={tx.status === 'success' ? 'default' : 'destructive'}>
                  {tx.status}
                </Badge>
              </div>
            ))}
            {analytics.transactions.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">
                No transactions yet
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Zap className="h-4 w-4" />
              Mode Performance
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {sortedModes.slice(0, 5).map((modeId) => {
              const mode = MODE_PRESETS[modeId];
              const stats = getModeStats(modeId);
              const avgGasPerTx = stats.transactionCount > 0
                ? stats.totalGasSpent / stats.transactionCount
                : 0;

              return (
                <div key={modeId} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{mode.emoji}</span>
                    <span className="text-sm">{mode.name}</span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{avgGasPerTx.toFixed(4)} gas/tx</p>
                    <p className="text-xs text-muted-foreground">
                      {stats.totalValueTransacted.toFixed(2)} ETH total
                    </p>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
