'use client';

import type { ModeConfig } from '@/types/modes';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle2 } from 'lucide-react';

type ModeCardProps = {
  mode: ModeConfig;
  isSelected: boolean;
  onSelect: () => void;
};

export function ModeCard({ mode, isSelected, onSelect }: ModeCardProps) {
  return (
    <Card
      className={`relative cursor-pointer transition-all hover:shadow-lg ${
        isSelected ? 'ring-2 ring-primary' : ''
      }`}
      onClick={onSelect}
      style={{
        borderColor: isSelected ? mode.theme.primaryColor : undefined,
      }}
    >
      {isSelected && (
        <div className="absolute -top-2 -right-2 z-10">
          <CheckCircle2 className="w-8 h-8 text-white bg-primary rounded-full" />
        </div>
      )}
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <CardTitle className="flex items-center gap-2">
              <span className="text-4xl">{mode.emoji}</span>
              <span>{mode.name}</span>
            </CardTitle>
            <CardDescription className="text-sm">{mode.description}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm font-medium italic" style={{ color: mode.theme.primaryColor }}>
          "{mode.tagline}"
        </p>
        <div className="flex flex-wrap gap-2">
          <Badge variant="secondary" className="text-xs">
            Gas: {mode.txSettings.gasPriority}
          </Badge>
          <Badge variant="secondary" className="text-xs">
            Slip: {mode.txSettings.slippageTolerance}%
          </Badge>
          <Badge variant="secondary" className="text-xs">
            {mode.socialPresence.visibility}
          </Badge>
          <Badge variant="secondary" className="text-xs">
            Max: {mode.riskLimits.maxSingleTx} ETH
          </Badge>
        </div>
        <Button
          className="w-full mt-4"
          variant={isSelected ? 'default' : 'outline'}
          style={
            isSelected
              ? {
                  backgroundColor: mode.theme.primaryColor,
                  color: 'white',
                }
              : undefined
          }
        >
          {isSelected ? 'Selected' : 'Select Mode'}
        </Button>
      </CardContent>
    </Card>
  );
}
