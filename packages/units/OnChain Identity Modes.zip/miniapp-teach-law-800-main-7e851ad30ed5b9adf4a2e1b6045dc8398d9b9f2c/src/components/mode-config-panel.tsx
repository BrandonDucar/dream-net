'use client';

import type { ModeConfig } from '@/types/modes';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';

type ModeConfigPanelProps = {
  mode: ModeConfig;
  onChange: (mode: ModeConfig) => void;
};

export function ModeConfigPanel({ mode, onChange }: ModeConfigPanelProps) {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <span className="text-3xl">{mode.emoji}</span>
            {mode.name} Configuration
          </CardTitle>
          <CardDescription>{mode.description}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Transaction Settings</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="gasPriority">Gas Priority</Label>
                <Select
                  value={mode.txSettings.gasPriority}
                  onValueChange={(value) =>
                    onChange({
                      ...mode,
                      txSettings: {
                        ...mode.txSettings,
                        gasPriority: value as 'low' | 'medium' | 'high' | 'max',
                      },
                    })
                  }
                >
                  <SelectTrigger id="gasPriority">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="max">Max</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="slippage">Slippage Tolerance (%)</Label>
                <Input
                  id="slippage"
                  type="number"
                  step="0.1"
                  value={mode.txSettings.slippageTolerance}
                  onChange={(e) =>
                    onChange({
                      ...mode,
                      txSettings: {
                        ...mode.txSettings,
                        slippageTolerance: parseFloat(e.target.value),
                      },
                    })
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="autoApprove">Auto-approve transactions</Label>
                <Switch
                  id="autoApprove"
                  checked={mode.txSettings.autoApprove}
                  onCheckedChange={(checked) =>
                    onChange({
                      ...mode,
                      txSettings: { ...mode.txSettings, autoApprove: checked },
                    })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="maxGasPrice">Max Gas Price (gwei)</Label>
                <Input
                  id="maxGasPrice"
                  type="number"
                  value={mode.txSettings.maxGasPrice || 50}
                  onChange={(e) =>
                    onChange({
                      ...mode,
                      txSettings: {
                        ...mode.txSettings,
                        maxGasPrice: parseInt(e.target.value),
                      },
                    })
                  }
                />
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Theme</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="primaryColor">Primary Color</Label>
                <Input
                  id="primaryColor"
                  type="color"
                  value={mode.theme.primaryColor}
                  onChange={(e) =>
                    onChange({
                      ...mode,
                      theme: { ...mode.theme, primaryColor: e.target.value },
                    })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="accentColor">Accent Color</Label>
                <Input
                  id="accentColor"
                  type="color"
                  value={mode.theme.accentColor}
                  onChange={(e) =>
                    onChange({
                      ...mode,
                      theme: { ...mode.theme, accentColor: e.target.value },
                    })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="textStyle">Text Style</Label>
                <Select
                  value={mode.theme.textStyle}
                  onValueChange={(value) =>
                    onChange({
                      ...mode,
                      theme: {
                        ...mode.theme,
                        textStyle: value as 'minimal' | 'bold' | 'playful' | 'professional',
                      },
                    })
                  }
                >
                  <SelectTrigger id="textStyle">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="minimal">Minimal</SelectItem>
                    <SelectItem value="bold">Bold</SelectItem>
                    <SelectItem value="playful">Playful</SelectItem>
                    <SelectItem value="professional">Professional</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Social Presence</h3>
            <div className="space-y-3">
              <div className="space-y-2">
                <Label htmlFor="visibility">Visibility</Label>
                <Select
                  value={mode.socialPresence.visibility}
                  onValueChange={(value) =>
                    onChange({
                      ...mode,
                      socialPresence: {
                        ...mode.socialPresence,
                        visibility: value as 'public' | 'friends' | 'private',
                      },
                    })
                  }
                >
                  <SelectTrigger id="visibility">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="public">Public</SelectItem>
                    <SelectItem value="friends">Friends</SelectItem>
                    <SelectItem value="private">Private</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="autoShare">Auto-share activity</Label>
                <Switch
                  id="autoShare"
                  checked={mode.socialPresence.autoShare}
                  onCheckedChange={(checked) =>
                    onChange({
                      ...mode,
                      socialPresence: { ...mode.socialPresence, autoShare: checked },
                    })
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="shareTransactions">Share transactions</Label>
                <Switch
                  id="shareTransactions"
                  checked={mode.socialPresence.shareTransactions}
                  onCheckedChange={(checked) =>
                    onChange({
                      ...mode,
                      socialPresence: { ...mode.socialPresence, shareTransactions: checked },
                    })
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="shareBalance">Share balance</Label>
                <Switch
                  id="shareBalance"
                  checked={mode.socialPresence.shareBalance}
                  onCheckedChange={(checked) =>
                    onChange({
                      ...mode,
                      socialPresence: { ...mode.socialPresence, shareBalance: checked },
                    })
                  }
                />
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Auto-response</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label htmlFor="autoResponseEnabled">Enable auto-response</Label>
                <Switch
                  id="autoResponseEnabled"
                  checked={mode.autoResponse.enabled}
                  onCheckedChange={(checked) =>
                    onChange({
                      ...mode,
                      autoResponse: { ...mode.autoResponse, enabled: checked },
                    })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="greeting">Greeting message</Label>
                <Input
                  id="greeting"
                  value={mode.autoResponse.greeting}
                  onChange={(e) =>
                    onChange({
                      ...mode,
                      autoResponse: { ...mode.autoResponse, greeting: e.target.value },
                    })
                  }
                  disabled={!mode.autoResponse.enabled}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="transactionMessage">Transaction message</Label>
                <Input
                  id="transactionMessage"
                  value={mode.autoResponse.transactionMessage}
                  onChange={(e) =>
                    onChange({
                      ...mode,
                      autoResponse: { ...mode.autoResponse, transactionMessage: e.target.value },
                    })
                  }
                  disabled={!mode.autoResponse.enabled}
                />
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Auto-tagging</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label htmlFor="autoTaggingEnabled">Enable auto-tagging</Label>
                <Switch
                  id="autoTaggingEnabled"
                  checked={mode.autoTagging.enabled}
                  onCheckedChange={(checked) =>
                    onChange({
                      ...mode,
                      autoTagging: { ...mode.autoTagging, enabled: checked },
                    })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="tagPattern">Tag pattern</Label>
                <Input
                  id="tagPattern"
                  value={mode.autoTagging.tagPattern}
                  onChange={(e) =>
                    onChange({
                      ...mode,
                      autoTagging: { ...mode.autoTagging, tagPattern: e.target.value },
                    })
                  }
                  disabled={!mode.autoTagging.enabled}
                  placeholder="#tag1 #tag2"
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="includeEmoji">Include emoji</Label>
                <Switch
                  id="includeEmoji"
                  checked={mode.autoTagging.includeEmoji}
                  onCheckedChange={(checked) =>
                    onChange({
                      ...mode,
                      autoTagging: { ...mode.autoTagging, includeEmoji: checked },
                    })
                  }
                  disabled={!mode.autoTagging.enabled}
                />
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Auto-log Behaviors</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label htmlFor="logTransactions">Log transactions</Label>
                <Switch
                  id="logTransactions"
                  checked={mode.autoLog.logTransactions}
                  onCheckedChange={(checked) =>
                    onChange({
                      ...mode,
                      autoLog: { ...mode.autoLog, logTransactions: checked },
                    })
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="logInteractions">Log interactions</Label>
                <Switch
                  id="logInteractions"
                  checked={mode.autoLog.logInteractions}
                  onCheckedChange={(checked) =>
                    onChange({
                      ...mode,
                      autoLog: { ...mode.autoLog, logInteractions: checked },
                    })
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="logBalanceChanges">Log balance changes</Label>
                <Switch
                  id="logBalanceChanges"
                  checked={mode.autoLog.logBalanceChanges}
                  onCheckedChange={(checked) =>
                    onChange({
                      ...mode,
                      autoLog: { ...mode.autoLog, logBalanceChanges: checked },
                    })
                  }
                />
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Risk Limits</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="maxSingleTx">Max single transaction (ETH)</Label>
                <Input
                  id="maxSingleTx"
                  type="number"
                  step="0.1"
                  value={mode.riskLimits.maxSingleTx}
                  onChange={(e) =>
                    onChange({
                      ...mode,
                      riskLimits: {
                        ...mode.riskLimits,
                        maxSingleTx: parseFloat(e.target.value),
                      },
                    })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dailyLimit">Daily limit (ETH)</Label>
                <Input
                  id="dailyLimit"
                  type="number"
                  step="1"
                  value={mode.riskLimits.dailyLimit}
                  onChange={(e) =>
                    onChange({
                      ...mode,
                      riskLimits: {
                        ...mode.riskLimits,
                        dailyLimit: parseFloat(e.target.value),
                      },
                    })
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="requireConfirmation">Require confirmation</Label>
                <Switch
                  id="requireConfirmation"
                  checked={mode.riskLimits.requireConfirmation}
                  onCheckedChange={(checked) =>
                    onChange({
                      ...mode,
                      riskLimits: { ...mode.riskLimits, requireConfirmation: checked },
                    })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="warningThreshold">Warning threshold (ETH)</Label>
                <Input
                  id="warningThreshold"
                  type="number"
                  step="0.1"
                  value={mode.riskLimits.warningThreshold}
                  onChange={(e) =>
                    onChange({
                      ...mode,
                      riskLimits: {
                        ...mode.riskLimits,
                        warningThreshold: parseFloat(e.target.value),
                      },
                    })
                  }
                />
              </div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-muted rounded-lg">
            <h4 className="font-semibold mb-2">Current Mode Summary</h4>
            <div className="flex flex-wrap gap-2">
              <Badge>Gas: {mode.txSettings.gasPriority}</Badge>
              <Badge>Slip: {mode.txSettings.slippageTolerance}%</Badge>
              <Badge>{mode.socialPresence.visibility}</Badge>
              <Badge>Max TX: {mode.riskLimits.maxSingleTx} ETH</Badge>
              <Badge>Daily: {mode.riskLimits.dailyLimit} ETH</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
