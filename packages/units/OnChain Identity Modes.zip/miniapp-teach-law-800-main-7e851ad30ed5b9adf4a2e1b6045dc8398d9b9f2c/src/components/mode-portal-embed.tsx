'use client'
import type { FC } from 'react';
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Code, Copy, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';

export const ModePortalEmbed: FC = () => {
  const [widgetType, setWidgetType] = useState<'badge' | 'card'>('badge');

  const getBadgeCode = () => {
    return `<!-- HUMAN MODE Badge -->
<div id="human-mode-badge"></div>
<script>
  (function() {
    const address = 'YOUR_WALLET_ADDRESS';
    fetch(\`${window.location.origin}/api/mode-portal?address=\${address}\`)
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          const badge = document.getElementById('human-mode-badge');
          badge.innerHTML = \`
            <a href="${window.location.origin}?mode=\${address}" 
               target="_blank"
               style="display: inline-flex; align-items: center; gap: 8px; 
                      padding: 8px 16px; background: \${data.data.mode.theme.primaryColor}; 
                      color: white; border-radius: 8px; text-decoration: none; 
                      font-family: system-ui, sans-serif; font-size: 14px;">
              <span style="font-size: 20px;">\${data.data.mode.emoji}</span>
              <span>\${data.data.mode.name}</span>
            </a>
          \`;
        }
      });
  })();
</script>`;
  };

  const getCardCode = () => {
    return `<!-- HUMAN MODE Card -->
<div id="human-mode-card"></div>
<script>
  (function() {
    const address = 'YOUR_WALLET_ADDRESS';
    fetch(\`${window.location.origin}/api/mode-portal?address=\${address}\`)
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          const card = document.getElementById('human-mode-card');
          card.innerHTML = \`
            <div style="border: 1px solid #e5e7eb; border-radius: 12px; 
                        padding: 16px; max-width: 300px; 
                        font-family: system-ui, sans-serif;">
              <div style="display: flex; align-items: center; gap: 12px; 
                          margin-bottom: 12px;">
                <span style="font-size: 32px;">\${data.data.mode.emoji}</span>
                <div>
                  <h3 style="margin: 0; font-size: 16px; font-weight: 600;">
                    \${data.data.mode.name}
                  </h3>
                  <p style="margin: 0; font-size: 12px; color: #6b7280;">
                    HUMAN MODE
                  </p>
                </div>
              </div>
              <div style="display: flex; gap: 8px;">
                <span style="padding: 4px 8px; background: #f3f4f6; 
                             border-radius: 4px; font-size: 12px;">
                  \${data.data.mode.socialPresence.visibility}
                </span>
              </div>
              <a href="${window.location.origin}?mode=\${address}" 
                 target="_blank"
                 style="display: block; margin-top: 12px; text-align: center; 
                        padding: 8px; background: \${data.data.mode.theme.primaryColor}; 
                        color: white; border-radius: 6px; text-decoration: none; 
                        font-size: 14px;">
                View Full Profile
              </a>
            </div>
          \`;
        }
      });
  })();
</script>`;
  };

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    toast.success('Code copied to clipboard!');
  };

  const embedCode = widgetType === 'badge' ? getBadgeCode() : getCardCode();

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Code className="h-5 w-5" />
            Cross-App Portal
          </CardTitle>
          <CardDescription>
            Embed your HUMAN MODE in other apps and websites
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <Label>Widget Type</Label>
            <div className="grid grid-cols-2 gap-4">
              <Button
                variant={widgetType === 'badge' ? 'default' : 'outline'}
                onClick={() => setWidgetType('badge')}
              >
                Badge
              </Button>
              <Button
                variant={widgetType === 'card' ? 'default' : 'outline'}
                onClick={() => setWidgetType('card')}
              >
                Card
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Embed Code</Label>
              <Button
                onClick={() => handleCopy(embedCode)}
                variant="ghost"
                size="sm"
              >
                <Copy className="h-4 w-4 mr-2" />
                Copy
              </Button>
            </div>
            <Textarea
              value={embedCode}
              readOnly
              className="font-mono text-xs h-64"
            />
          </div>

          <div className="space-y-2">
            <Label>API Endpoint</Label>
            <div className="flex gap-2">
              <Input
                value={`${typeof window !== 'undefined' ? window.location.origin : ''}/api/mode-portal?address=YOUR_ADDRESS`}
                readOnly
                className="font-mono text-sm"
              />
              <Button
                onClick={() =>
                  handleCopy(
                    `${typeof window !== 'undefined' ? window.location.origin : ''}/api/mode-portal?address=YOUR_ADDRESS`
                  )
                }
                variant="outline"
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Other apps can call this endpoint to read your mode configuration
            </p>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-muted/50">
        <CardHeader>
          <CardTitle className="text-lg">Integration Examples</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-medium mb-2">DeFi Protocols</h4>
            <p className="text-sm text-muted-foreground">
              Auto-set slippage, gas settings, and risk parameters based on user's mode
            </p>
          </div>
          <div>
            <h4 className="font-medium mb-2">NFT Marketplaces</h4>
            <p className="text-sm text-muted-foreground">
              Display collector mode badges and auto-configure bidding settings
            </p>
          </div>
          <div>
            <h4 className="font-medium mb-2">Social Platforms</h4>
            <p className="text-sm text-muted-foreground">
              Show user's current mode on their profile, customize interaction styles
            </p>
          </div>
          <div>
            <h4 className="font-medium mb-2">Wallets</h4>
            <p className="text-sm text-muted-foreground">
              Import mode preferences directly into wallet settings
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Preview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg p-6 bg-white">
            <div className="flex items-center gap-3">
              <span className="text-4xl">🛠️</span>
              <div>
                <h3 className="font-semibold">Builder Mode</h3>
                <p className="text-sm text-muted-foreground">HUMAN MODE</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
