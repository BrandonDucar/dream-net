'use client'
import type { FC } from 'react';
import { useState } from 'react';
import { useAccount } from 'wagmi';
import { usePublicModes } from '@/hooks/use-mode-contract';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Users, Search, Download, Share2, Copy } from 'lucide-react';
import { toast } from 'sonner';
import type { ModeConfig } from '@/types/modes';
import { MODE_PRESETS } from '@/types/modes';

type SocialModesPanelProps = {
  onImportMode: (config: ModeConfig) => void;
};

export const SocialModesPanel: FC<SocialModesPanelProps> = ({ onImportMode }) => {
  const { address } = useAccount();
  const { publicModes, isLoading } = usePublicModes();
  const [searchQuery, setSearchQuery] = useState('');

  const handleCopyShareLink = () => {
    if (!address) return;
    const shareUrl = `${window.location.origin}?mode=${address}`;
    navigator.clipboard.writeText(shareUrl);
    toast.success('Share link copied to clipboard!');
  };

  const handleImport = (modeData: string) => {
    try {
      const config = JSON.parse(modeData) as ModeConfig;
      onImportMode(config);
      toast.success(`Imported ${config.name}!`);
    } catch (error) {
      console.error('Failed to import mode:', error);
      toast.error('Failed to import mode');
    }
  };

  const filteredModes = publicModes.filter((entry: any) => {
    if (!searchQuery) return true;
    const address = entry.user.toLowerCase();
    return address.includes(searchQuery.toLowerCase());
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Share2 className="h-5 w-5" />
            Share Your Mode
          </CardTitle>
          <CardDescription>Let others discover and copy your configuration</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              value={address ? `${window.location.origin}?mode=${address}` : ''}
              readOnly
              className="font-mono text-sm"
            />
            <Button onClick={handleCopyShareLink} variant="outline">
              <Copy className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">
            Share this link with others so they can import your mode configuration
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Discover Modes
          </CardTitle>
          <CardDescription>
            Browse and import mode configurations from the community
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by wallet address..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
              <p className="text-sm text-muted-foreground">Loading public modes...</p>
            </div>
          ) : filteredModes.length === 0 ? (
            <div className="text-center py-8">
              <Users className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">
                No public modes found. Be the first to share yours!
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredModes.slice(0, 10).map((entry: any, index: number) => {
                try {
                  const config = JSON.parse(entry.modeData) as ModeConfig;
                  const preset = MODE_PRESETS[config.id];

                  return (
                    <Card key={`${entry.user}-${index}`} className="bg-muted/50">
                      <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3 flex-1">
                            <Avatar>
                              <AvatarFallback className="text-2xl">
                                {preset.emoji}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <p className="font-medium">{config.name}</p>
                              <p className="text-xs text-muted-foreground font-mono truncate">
                                {entry.user}
                              </p>
                              <div className="flex flex-wrap gap-1 mt-2">
                                <Badge variant="secondary" className="text-xs">
                                  Gas: {config.txSettings.gasPriority}
                                </Badge>
                                <Badge variant="secondary" className="text-xs">
                                  {config.socialPresence.visibility}
                                </Badge>
                                {config.txSettings.autoApprove && (
                                  <Badge className="text-xs">Auto-approve</Badge>
                                )}
                              </div>
                            </div>
                          </div>
                          <Button
                            onClick={() => handleImport(entry.modeData)}
                            size="sm"
                            variant="outline"
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Import
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                } catch {
                  return null;
                }
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
