import { useState, useEffect, useCallback } from 'react';
import { useAccount } from 'wagmi';
import type { ModeId } from '@/types/modes';
import type { AnalyticsData, ModeSession, TransactionLog, ModeAnalytics } from '@/types/analytics';

const INITIAL_ANALYTICS: AnalyticsData = {
  sessions: [],
  transactions: [],
  modeStats: {
    builder: { totalSessions: 0, totalTime: 0, transactionCount: 0, totalGasSpent: 0, totalValueTransacted: 0, lastUsed: 0 },
    collector: { totalSessions: 0, totalTime: 0, transactionCount: 0, totalGasSpent: 0, totalValueTransacted: 0, lastUsed: 0 },
    stealth: { totalSessions: 0, totalTime: 0, transactionCount: 0, totalGasSpent: 0, totalValueTransacted: 0, lastUsed: 0 },
    sniper: { totalSessions: 0, totalTime: 0, transactionCount: 0, totalGasSpent: 0, totalValueTransacted: 0, lastUsed: 0 },
    creator: { totalSessions: 0, totalTime: 0, transactionCount: 0, totalGasSpent: 0, totalValueTransacted: 0, lastUsed: 0 },
    degen: { totalSessions: 0, totalTime: 0, transactionCount: 0, totalGasSpent: 0, totalValueTransacted: 0, lastUsed: 0 },
    merchant: { totalSessions: 0, totalTime: 0, transactionCount: 0, totalGasSpent: 0, totalValueTransacted: 0, lastUsed: 0 },
  },
  globalStats: {
    totalModeSwitches: 0,
    mostUsedMode: 'builder',
    totalTransactions: 0,
    totalGasSpent: 0,
  },
};

export function useModeAnalytics() {
  const { address } = useAccount();
  const [analytics, setAnalytics] = useState<AnalyticsData>(INITIAL_ANALYTICS);
  const [currentSession, setCurrentSession] = useState<ModeSession | null>(null);

  // Load analytics from localStorage
  useEffect(() => {
    if (address) {
      const stored = localStorage.getItem(`analytics-${address}`);
      if (stored) {
        try {
          setAnalytics(JSON.parse(stored));
        } catch (error) {
          console.error('Failed to load analytics:', error);
        }
      }
    }
  }, [address]);

  // Save analytics to localStorage
  const saveAnalytics = useCallback((data: AnalyticsData) => {
    if (address) {
      localStorage.setItem(`analytics-${address}`, JSON.stringify(data));
      setAnalytics(data);
    }
  }, [address]);

  // Start a new mode session
  const startSession = useCallback((modeId: ModeId) => {
    const session: ModeSession = {
      modeId,
      startTime: Date.now(),
    };
    setCurrentSession(session);
  }, []);

  // End current session
  const endSession = useCallback(() => {
    if (!currentSession) return;

    const endTime = Date.now();
    const duration = Math.floor((endTime - currentSession.startTime) / 1000);

    const completedSession: ModeSession = {
      ...currentSession,
      endTime,
      duration,
    };

    const updatedAnalytics = { ...analytics };
    updatedAnalytics.sessions.push(completedSession);

    const modeStats = updatedAnalytics.modeStats[currentSession.modeId];
    modeStats.totalSessions += 1;
    modeStats.totalTime += duration;
    modeStats.lastUsed = endTime;

    updatedAnalytics.globalStats.totalModeSwitches += 1;

    // Calculate most used mode
    let maxTime = 0;
    let mostUsed: ModeId = 'builder';
    Object.entries(updatedAnalytics.modeStats).forEach(([modeId, stats]) => {
      if (stats.totalTime > maxTime) {
        maxTime = stats.totalTime;
        mostUsed = modeId as ModeId;
      }
    });
    updatedAnalytics.globalStats.mostUsedMode = mostUsed;

    saveAnalytics(updatedAnalytics);
    setCurrentSession(null);
  }, [currentSession, analytics, saveAnalytics]);

  // Log a transaction
  const logTransaction = useCallback((
    hash: string,
    modeId: ModeId,
    value: number,
    gasUsed: number,
    status: 'success' | 'failed'
  ) => {
    const transaction: TransactionLog = {
      hash,
      modeId,
      timestamp: Date.now(),
      value,
      gasUsed,
      status,
    };

    const updatedAnalytics = { ...analytics };
    updatedAnalytics.transactions.push(transaction);

    const modeStats = updatedAnalytics.modeStats[modeId];
    if (status === 'success') {
      modeStats.transactionCount += 1;
      modeStats.totalGasSpent += gasUsed;
      modeStats.totalValueTransacted += value;
    }

    updatedAnalytics.globalStats.totalTransactions += 1;
    updatedAnalytics.globalStats.totalGasSpent += gasUsed;

    saveAnalytics(updatedAnalytics);
  }, [analytics, saveAnalytics]);

  // Get stats for a specific mode
  const getModeStats = useCallback((modeId: ModeId): ModeAnalytics => {
    return analytics.modeStats[modeId];
  }, [analytics]);

  // Calculate session time for display
  const formatDuration = (seconds: number): string => {
    if (seconds < 60) return `${seconds}s`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
    return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`;
  };

  return {
    analytics,
    currentSession,
    startSession,
    endSession,
    logTransaction,
    getModeStats,
    formatDuration,
  };
}
