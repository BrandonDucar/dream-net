import { useAccount, useWriteContract, useReadContract } from 'wagmi';
import { MODE_REGISTRY_ABI, MODE_REGISTRY_ADDRESS } from '@/lib/contracts/mode-registry-abi';
import type { ModeConfig } from '@/types/modes';
import { toast } from 'sonner';

export function useModeContract() {
  const { address } = useAccount();
  const { writeContractAsync } = useWriteContract();

  // Save mode onchain
  const saveModeOnchain = async (modeConfig: ModeConfig): Promise<boolean> => {
    if (!address) {
      toast.error('No wallet connected');
      return false;
    }

    try {
      const modeData = JSON.stringify(modeConfig);
      
      const hash = await writeContractAsync({
        address: MODE_REGISTRY_ADDRESS,
        abi: MODE_REGISTRY_ABI,
        functionName: 'setMode',
        args: [modeData],
      });

      toast.success('Mode saved onchain!', {
        description: `Transaction: ${hash.slice(0, 10)}...`,
      });

      return true;
    } catch (error) {
      console.error('Failed to save mode onchain:', error);
      toast.error('Failed to save mode onchain');
      return false;
    }
  };

  return {
    saveModeOnchain,
  };
}

// Hook to read mode from contract
export function useReadModeContract(userAddress?: string) {
  const { data: modeData, isLoading } = useReadContract({
    address: MODE_REGISTRY_ADDRESS,
    abi: MODE_REGISTRY_ABI,
    functionName: 'getMode',
    args: userAddress ? [userAddress as `0x${string}`] : undefined,
  });

  const parsedMode = modeData
    ? (() => {
        try {
          return JSON.parse(modeData as string) as ModeConfig;
        } catch {
          return null;
        }
      })()
    : null;

  return {
    modeData: parsedMode,
    isLoading,
  };
}

// Hook to fetch public modes (social discovery)
export function usePublicModes() {
  const { data: publicModes, isLoading } = useReadContract({
    address: MODE_REGISTRY_ADDRESS,
    abi: MODE_REGISTRY_ABI,
    functionName: 'getPublicModes',
  });

  return {
    publicModes: publicModes || [],
    isLoading,
  };
}
