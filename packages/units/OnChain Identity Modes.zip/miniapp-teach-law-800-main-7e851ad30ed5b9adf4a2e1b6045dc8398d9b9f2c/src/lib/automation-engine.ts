import type { ModeConfig } from '@/types/modes';
import { toast } from 'sonner';

export type AutomationEvent = {
  type: 'transaction' | 'balance_change' | 'interaction';
  data: any;
};

export class AutomationEngine {
  private currentMode: ModeConfig;
  private isEnabled: boolean = true;

  constructor(mode: ModeConfig) {
    this.currentMode = mode;
  }

  updateMode(mode: ModeConfig): void {
    this.currentMode = mode;
  }

  setEnabled(enabled: boolean): void {
    this.isEnabled = enabled;
  }

  // Auto-respond based on mode settings
  async handleAutoResponse(event: AutomationEvent): Promise<void> {
    if (!this.isEnabled || !this.currentMode.autoResponse.enabled) return;

    const { type } = event;
    const { autoResponse } = this.currentMode;

    if (type === 'transaction' && autoResponse.transactionMessage) {
      toast.info(autoResponse.transactionMessage);
    }
  }

  // Auto-tag transactions
  getAutoTags(): string[] {
    if (!this.currentMode.autoTagging.enabled) return [];

    const tags = this.currentMode.autoTagging.tagPattern
      .split(' ')
      .filter((tag) => tag.startsWith('#'));

    if (this.currentMode.autoTagging.includeEmoji) {
      return [this.currentMode.emoji, ...tags];
    }

    return tags;
  }

  // Check risk limits before transaction
  checkRiskLimits(txValue: number, dailyTotal: number): {
    allowed: boolean;
    message?: string;
  } {
    const { riskLimits } = this.currentMode;

    // Check single transaction limit
    if (txValue > riskLimits.maxSingleTx) {
      return {
        allowed: false,
        message: `Transaction exceeds max single transaction limit of ${riskLimits.maxSingleTx} ETH`,
      };
    }

    // Check daily limit
    if (dailyTotal + txValue > riskLimits.dailyLimit) {
      return {
        allowed: false,
        message: `Transaction would exceed daily limit of ${riskLimits.dailyLimit} ETH`,
      };
    }

    // Check warning threshold
    if (txValue > riskLimits.warningThreshold) {
      if (riskLimits.requireConfirmation) {
        return {
          allowed: true,
          message: `Large transaction (${txValue} ETH). Please confirm.`,
        };
      }
    }

    return { allowed: true };
  }

  // Auto-approve check
  shouldAutoApprove(txValue: number): boolean {
    if (!this.currentMode.txSettings.autoApprove) return false;

    // Don't auto-approve if it exceeds warning threshold
    return txValue <= this.currentMode.riskLimits.warningThreshold;
  }

  // Get recommended gas settings
  getGasSettings(): {
    priority: 'low' | 'medium' | 'high' | 'max';
    maxGasPrice?: number;
  } {
    return {
      priority: this.currentMode.txSettings.gasPriority,
      maxGasPrice: this.currentMode.txSettings.maxGasPrice,
    };
  }

  // Auto-log decision
  shouldLog(eventType: 'transaction' | 'interaction' | 'balance'): boolean {
    const { autoLog } = this.currentMode;

    switch (eventType) {
      case 'transaction':
        return autoLog.logTransactions;
      case 'interaction':
        return autoLog.logInteractions;
      case 'balance':
        return autoLog.logBalanceChanges;
      default:
        return false;
    }
  }

  // Get social sharing settings
  getSocialSettings(): {
    shouldShare: boolean;
    visibility: 'public' | 'friends' | 'private';
    shareTransactions: boolean;
    shareBalance: boolean;
  } {
    const { socialPresence } = this.currentMode;
    return {
      shouldShare: socialPresence.autoShare,
      visibility: socialPresence.visibility,
      shareTransactions: socialPresence.shareTransactions,
      shareBalance: socialPresence.shareBalance,
    };
  }

  // Get greeting message
  getGreeting(): string {
    return this.currentMode.autoResponse.greeting;
  }
}

// Singleton instance
let automationEngineInstance: AutomationEngine | null = null;

export function getAutomationEngine(mode?: ModeConfig): AutomationEngine {
  if (!automationEngineInstance && mode) {
    automationEngineInstance = new AutomationEngine(mode);
  } else if (automationEngineInstance && mode) {
    automationEngineInstance.updateMode(mode);
  }

  if (!automationEngineInstance) {
    throw new Error('AutomationEngine not initialized');
  }

  return automationEngineInstance;
}
