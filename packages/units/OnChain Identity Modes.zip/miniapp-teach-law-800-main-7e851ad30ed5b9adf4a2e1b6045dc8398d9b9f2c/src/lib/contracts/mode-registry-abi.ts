// ABI for ModeRegistry contract on Base
export const MODE_REGISTRY_ABI = [
  {
    inputs: [
      { internalType: 'string', name: '_modeData', type: 'string' },
    ],
    name: 'setMode',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      { internalType: 'address', name: '_user', type: 'address' },
    ],
    name: 'getMode',
    outputs: [{ internalType: 'string', name: '', type: 'string' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      { internalType: 'address', name: '_user', type: 'address' },
    ],
    name: 'getModeTimestamp',
    outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'getPublicModes',
    outputs: [
      { 
        components: [
          { internalType: 'address', name: 'user', type: 'address' },
          { internalType: 'string', name: 'modeData', type: 'string' },
          { internalType: 'uint256', name: 'timestamp', type: 'uint256' },
        ],
        internalType: 'struct ModeRegistry.ModeEntry[]',
        name: '',
        type: 'tuple[]',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    anonymous: false,
    inputs: [
      { indexed: true, internalType: 'address', name: 'user', type: 'address' },
      { indexed: false, internalType: 'string', name: 'modeData', type: 'string' },
    ],
    name: 'ModeUpdated',
    type: 'event',
  },
] as const;

// Deployed contract address on Base
export const MODE_REGISTRY_ADDRESS = '0x1234567890123456789012345678901234567890' as const;
