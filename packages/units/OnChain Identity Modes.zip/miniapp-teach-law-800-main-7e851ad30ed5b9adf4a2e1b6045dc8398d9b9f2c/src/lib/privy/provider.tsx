'use client';

import { PrivyProvider, type PrivyProviderProps } from '@privy-io/react-auth';

const PRIVY_APP_ID = 'cm5yjbh8z01lv6heoze3v3ep5';
const CLIENT_ID = 'client-WY5fRbUUsnYnSBnU7hp47apYGAdUgABi38uhK4PxBYLpx';

export const PrivyWrapper: React.FC<PrivyProviderProps> = ({
  children,
  ...props
}) => {
  return (
    <PrivyProvider
      appId={PRIVY_APP_ID}
      clientId={CLIENT_ID}
      config={{
        loginMethods: ['wallet', 'email'],
        appearance: {
          theme: 'light',
          accentColor: '#0052FF',
          showWalletLoginFirst: true,
        },
        embeddedWallets: {
          createOnLogin: 'users-without-wallets',
        },
        defaultChain: {
          id: 8453,
          name: 'Base',
          nativeCurrency: {
            name: 'Ethereum',
            symbol: 'ETH',
            decimals: 18,
          },
          rpcUrls: {
            default: {
              http: ['https://mainnet.base.org'],
            },
          },
          blockExplorers: {
            default: {
              name: 'BaseScan',
              url: 'https://basescan.org',
            },
          },
        },
        supportedChains: [
          {
            id: 8453,
            name: 'Base',
            nativeCurrency: {
              name: 'Ethereum',
              symbol: 'ETH',
              decimals: 18,
            },
            rpcUrls: {
              default: {
                http: ['https://mainnet.base.org'],
              },
            },
            blockExplorers: {
              default: {
                name: 'BaseScan',
                url: 'https://basescan.org',
              },
            },
          },
        ],
      }}
      {...props}
    >
      {children}
    </PrivyProvider>
  );
};
