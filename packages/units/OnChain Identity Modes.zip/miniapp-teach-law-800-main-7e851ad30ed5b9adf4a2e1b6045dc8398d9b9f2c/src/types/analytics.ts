import type { ModeId } from './modes';

export type ModeSession = {
  modeId: ModeId;
  startTime: number;
  endTime?: number;
  duration?: number;
};

export type TransactionLog = {
  hash: string;
  modeId: ModeId;
  timestamp: number;
  value: number;
  gasUsed: number;
  status: 'success' | 'failed';
};

export type ModeAnalytics = {
  totalSessions: number;
  totalTime: number; // in seconds
  transactionCount: number;
  totalGasSpent: number;
  totalValueTransacted: number;
  lastUsed: number;
  favoriteMode?: ModeId;
};

export type AnalyticsData = {
  sessions: ModeSession[];
  transactions: TransactionLog[];
  modeStats: Record<ModeId, ModeAnalytics>;
  globalStats: {
    totalModeSwitches: number;
    mostUsedMode: ModeId;
    totalTransactions: number;
    totalGasSpent: number;
  };
};
