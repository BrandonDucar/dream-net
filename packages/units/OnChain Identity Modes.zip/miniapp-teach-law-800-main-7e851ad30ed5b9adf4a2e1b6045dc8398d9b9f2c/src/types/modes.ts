export type ModeId =
  | 'builder'
  | 'collector'
  | 'stealth'
  | 'sniper'
  | 'creator'
  | 'degen'
  | 'merchant';

export type TxSettings = {
  gasPriority: 'low' | 'medium' | 'high' | 'max';
  slippageTolerance: number;
  autoApprove: boolean;
  maxGasPrice?: number;
};

export type ThemeSettings = {
  primaryColor: string;
  accentColor: string;
  textStyle: 'minimal' | 'bold' | 'playful' | 'professional';
};

export type SocialPresence = {
  visibility: 'public' | 'friends' | 'private';
  autoShare: boolean;
  shareTransactions: boolean;
  shareBalance: boolean;
};

export type AutoResponse = {
  enabled: boolean;
  greeting: string;
  transactionMessage: string;
};

export type AutoTagging = {
  enabled: boolean;
  tagPattern: string;
  includeEmoji: boolean;
};

export type AutoLog = {
  logTransactions: boolean;
  logInteractions: boolean;
  logBalanceChanges: boolean;
};

export type RiskLimits = {
  maxSingleTx: number;
  dailyLimit: number;
  requireConfirmation: boolean;
  warningThreshold: number;
};

export type ModeConfig = {
  id: ModeId;
  name: string;
  emoji: string;
  description: string;
  tagline: string;
  txSettings: TxSettings;
  theme: ThemeSettings;
  socialPresence: SocialPresence;
  autoResponse: AutoResponse;
  autoTagging: AutoTagging;
  autoLog: AutoLog;
  riskLimits: RiskLimits;
};

export const MODE_PRESETS: Record<ModeId, ModeConfig> = {
  builder: {
    id: 'builder',
    name: 'Builder Mode',
    emoji: '🛠️',
    description: 'Optimized for developers and protocol builders',
    tagline: 'Ship fast, break nothing',
    txSettings: {
      gasPriority: 'medium',
      slippageTolerance: 1.0,
      autoApprove: false,
      maxGasPrice: 50,
    },
    theme: {
      primaryColor: '#0052FF',
      accentColor: '#00D4FF',
      textStyle: 'minimal',
    },
    socialPresence: {
      visibility: 'public',
      autoShare: true,
      shareTransactions: true,
      shareBalance: false,
    },
    autoResponse: {
      enabled: true,
      greeting: 'gm, building something cool?',
      transactionMessage: 'Transaction executed - check the logs',
    },
    autoTagging: {
      enabled: true,
      tagPattern: '#buidl #onbase',
      includeEmoji: true,
    },
    autoLog: {
      logTransactions: true,
      logInteractions: true,
      logBalanceChanges: true,
    },
    riskLimits: {
      maxSingleTx: 1,
      dailyLimit: 5,
      requireConfirmation: true,
      warningThreshold: 0.5,
    },
  },
  collector: {
    id: 'collector',
    name: 'Collector Mode',
    emoji: '🎨',
    description: 'For NFT collectors and art enthusiasts',
    tagline: 'Curate your collection',
    txSettings: {
      gasPriority: 'high',
      slippageTolerance: 2.0,
      autoApprove: false,
      maxGasPrice: 100,
    },
    theme: {
      primaryColor: '#9333EA',
      accentColor: '#F59E0B',
      textStyle: 'playful',
    },
    socialPresence: {
      visibility: 'public',
      autoShare: true,
      shareTransactions: true,
      shareBalance: true,
    },
    autoResponse: {
      enabled: true,
      greeting: 'Welcome to my collection 🎭',
      transactionMessage: 'New piece acquired!',
    },
    autoTagging: {
      enabled: true,
      tagPattern: '#NFT #collector #onbase',
      includeEmoji: true,
    },
    autoLog: {
      logTransactions: true,
      logInteractions: false,
      logBalanceChanges: true,
    },
    riskLimits: {
      maxSingleTx: 5,
      dailyLimit: 20,
      requireConfirmation: true,
      warningThreshold: 2,
    },
  },
  stealth: {
    id: 'stealth',
    name: 'Stealth Mode',
    emoji: '🥷',
    description: 'Maximum privacy and minimal footprint',
    tagline: 'Move in silence',
    txSettings: {
      gasPriority: 'low',
      slippageTolerance: 0.5,
      autoApprove: false,
      maxGasPrice: 30,
    },
    theme: {
      primaryColor: '#1F2937',
      accentColor: '#374151',
      textStyle: 'minimal',
    },
    socialPresence: {
      visibility: 'private',
      autoShare: false,
      shareTransactions: false,
      shareBalance: false,
    },
    autoResponse: {
      enabled: false,
      greeting: '',
      transactionMessage: '',
    },
    autoTagging: {
      enabled: false,
      tagPattern: '',
      includeEmoji: false,
    },
    autoLog: {
      logTransactions: false,
      logInteractions: false,
      logBalanceChanges: false,
    },
    riskLimits: {
      maxSingleTx: 0.5,
      dailyLimit: 2,
      requireConfirmation: true,
      warningThreshold: 0.2,
    },
  },
  sniper: {
    id: 'sniper',
    name: 'Sniper Mode',
    emoji: '🎯',
    description: 'Lightning-fast execution for trading',
    tagline: 'Speed is alpha',
    txSettings: {
      gasPriority: 'max',
      slippageTolerance: 5.0,
      autoApprove: true,
      maxGasPrice: 200,
    },
    theme: {
      primaryColor: '#DC2626',
      accentColor: '#F59E0B',
      textStyle: 'bold',
    },
    socialPresence: {
      visibility: 'friends',
      autoShare: false,
      shareTransactions: false,
      shareBalance: false,
    },
    autoResponse: {
      enabled: true,
      greeting: 'Ready to execute',
      transactionMessage: 'Position opened ⚡',
    },
    autoTagging: {
      enabled: true,
      tagPattern: '#sniper #trading',
      includeEmoji: true,
    },
    autoLog: {
      logTransactions: true,
      logInteractions: false,
      logBalanceChanges: true,
    },
    riskLimits: {
      maxSingleTx: 10,
      dailyLimit: 50,
      requireConfirmation: false,
      warningThreshold: 5,
    },
  },
  creator: {
    id: 'creator',
    name: 'Creator Mode',
    emoji: '✨',
    description: 'For artists and content creators',
    tagline: 'Create and share',
    txSettings: {
      gasPriority: 'medium',
      slippageTolerance: 1.5,
      autoApprove: false,
      maxGasPrice: 60,
    },
    theme: {
      primaryColor: '#EC4899',
      accentColor: '#8B5CF6',
      textStyle: 'playful',
    },
    socialPresence: {
      visibility: 'public',
      autoShare: true,
      shareTransactions: true,
      shareBalance: false,
    },
    autoResponse: {
      enabled: true,
      greeting: 'Creating magic ✨',
      transactionMessage: 'New creation minted!',
    },
    autoTagging: {
      enabled: true,
      tagPattern: '#creator #art #onbase',
      includeEmoji: true,
    },
    autoLog: {
      logTransactions: true,
      logInteractions: true,
      logBalanceChanges: false,
    },
    riskLimits: {
      maxSingleTx: 2,
      dailyLimit: 10,
      requireConfirmation: true,
      warningThreshold: 1,
    },
  },
  degen: {
    id: 'degen',
    name: 'Degen Mode',
    emoji: '🎲',
    description: 'Full send, no regrets',
    tagline: 'Risk it for the biscuit',
    txSettings: {
      gasPriority: 'max',
      slippageTolerance: 10.0,
      autoApprove: true,
      maxGasPrice: 500,
    },
    theme: {
      primaryColor: '#EAB308',
      accentColor: '#F97316',
      textStyle: 'bold',
    },
    socialPresence: {
      visibility: 'public',
      autoShare: true,
      shareTransactions: true,
      shareBalance: true,
    },
    autoResponse: {
      enabled: true,
      greeting: 'LFG 🚀',
      transactionMessage: 'YOLO trade executed',
    },
    autoTagging: {
      enabled: true,
      tagPattern: '#degen #yolo #onbase',
      includeEmoji: true,
    },
    autoLog: {
      logTransactions: true,
      logInteractions: true,
      logBalanceChanges: true,
    },
    riskLimits: {
      maxSingleTx: 100,
      dailyLimit: 500,
      requireConfirmation: false,
      warningThreshold: 50,
    },
  },
  merchant: {
    id: 'merchant',
    name: 'Merchant Mode',
    emoji: '🏪',
    description: 'Optimized for commerce and payments',
    tagline: 'Accept payments seamlessly',
    txSettings: {
      gasPriority: 'medium',
      slippageTolerance: 0.5,
      autoApprove: true,
      maxGasPrice: 40,
    },
    theme: {
      primaryColor: '#059669',
      accentColor: '#10B981',
      textStyle: 'professional',
    },
    socialPresence: {
      visibility: 'public',
      autoShare: true,
      shareTransactions: false,
      shareBalance: false,
    },
    autoResponse: {
      enabled: true,
      greeting: 'Payment received, thank you!',
      transactionMessage: 'Transaction confirmed ✓',
    },
    autoTagging: {
      enabled: true,
      tagPattern: '#merchant #commerce #onbase',
      includeEmoji: false,
    },
    autoLog: {
      logTransactions: true,
      logInteractions: true,
      logBalanceChanges: true,
    },
    riskLimits: {
      maxSingleTx: 5,
      dailyLimit: 50,
      requireConfirmation: false,
      warningThreshold: 10,
    },
  },
};
