import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

interface RouteParams {
  params: Promise<{
    slug: string;
  }>;
}

// API endpoint to get a funnel by slug
export async function GET(
  request: NextRequest,
  { params }: RouteParams
): Promise<NextResponse> {
  try {
    const { slug } = await params;

    return NextResponse.json({
      message: 'Use client-side storage to fetch funnel by slug',
      note: 'This API endpoint is for external agents. Data is stored client-side.',
      slug,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json(
      { error: 'Failed to fetch funnel', details: errorMessage },
      { status: 500 }
    );
  }
}
