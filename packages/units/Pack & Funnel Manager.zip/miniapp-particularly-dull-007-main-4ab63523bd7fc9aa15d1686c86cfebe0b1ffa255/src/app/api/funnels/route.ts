import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// API endpoint to get all active funnels
export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') || 'active';

    return NextResponse.json({
      message: 'Use client-side storage to fetch funnels',
      note: 'This API endpoint is for external agents. Data is stored client-side.',
      filter: { status },
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json(
      { error: 'Failed to fetch funnels', details: errorMessage },
      { status: 500 }
    );
  }
}
