import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// API endpoint to get all active packs
export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    // This endpoint returns active packs from localStorage
    // Note: We need to return empty array since this runs server-side
    // The actual data fetching happens client-side
    
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') || 'active';

    return NextResponse.json({
      message: 'Use client-side storage to fetch packs',
      note: 'This API endpoint is for external agents. Data is stored client-side.',
      filter: { status },
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json(
      { error: 'Failed to fetch packs', details: errorMessage },
      { status: 500 }
    );
  }
}
