'use client';

import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { funnelStorage, packStorage, generateId, generateSlug } from '@/lib/storage';
import { ArrowLeft, Save, Plus, Edit, Trash2, ArrowUp, ArrowDown, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import type { FunnelDefinition, FunnelStep, FunnelStepType, Status, PackDefinition } from '@/types';

export default function FunnelEditorPage(): JSX.Element {
  const router = useRouter();
  const params = useParams();
  const funnelId = params.id as string;

  const [funnel, setFunnel] = useState<FunnelDefinition | null>(null);
  const [packs, setPacks] = useState<PackDefinition[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState<boolean>(true);
  const [stepDialogOpen, setStepDialogOpen] = useState<boolean>(false);
  const [editingStep, setEditingStep] = useState<FunnelStep | null>(null);
  const [stepForm, setStepForm] = useState<Partial<FunnelStep>>({});

  useEffect(() => {
    loadFunnel();
    loadPacks();
  }, [funnelId]);

  const loadFunnel = (): void => {
    try {
      const loadedFunnel = funnelStorage.getById(funnelId);
      if (!loadedFunnel) {
        toast.error('Funnel not found');
        router.push('/funnels');
        return;
      }
      setFunnel(loadedFunnel);
    } catch (error) {
      toast.error('Failed to load funnel');
      router.push('/funnels');
    } finally {
      setLoading(false);
    }
  };

  const loadPacks = (): void => {
    const allPacks = packStorage.getAll();
    setPacks(allPacks.filter((p: PackDefinition) => p.status === 'active'));
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!funnel) return false;

    if (!funnel.name.trim()) {
      newErrors['name'] = 'Name is required';
    }

    if (!funnel.slug.trim()) {
      newErrors['slug'] = 'Slug is required';
    }

    if (funnel.steps.length === 0) {
      newErrors['steps'] = 'At least one step is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async (exitAfter: boolean = false): Promise<void> => {
    if (!funnel || !validateForm()) {
      toast.error('Please fix validation errors');
      return;
    }

    try {
      funnelStorage.update(funnelId, funnel);
      toast.success('Funnel saved successfully!');
      
      if (exitAfter) {
        router.push('/funnels');
      } else {
        loadFunnel();
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to save funnel: ${errorMessage}`);
    }
  };

  const updateField = <K extends keyof FunnelDefinition>(
    field: K,
    value: FunnelDefinition[K]
  ): void => {
    if (!funnel) return;
    setFunnel({ ...funnel, [field]: value });
    
    // Clear error for this field
    if (errors[field]) {
      const newErrors = { ...errors };
      delete newErrors[field];
      setErrors(newErrors);
    }
  };

  const handleNameChange = (name: string): void => {
    updateField('name', name);
    // Auto-generate slug from name if it hasn't been manually changed
    if (funnel && (funnel.slug === '' || funnel.slug.startsWith('new-funnel-'))) {
      updateField('slug', generateSlug(name));
    }
  };

  const handleAddStep = (): void => {
    setEditingStep(null);
    setStepForm({
      label: '',
      step_type: 'pack_join',
      required: false,
    });
    setStepDialogOpen(true);
  };

  const handleEditStep = (step: FunnelStep): void => {
    setEditingStep(step);
    setStepForm(step);
    setStepDialogOpen(true);
  };

  const handleSaveStep = (): void => {
    if (!funnel || !stepForm.label || !stepForm.step_type) {
      toast.error('Please fill in required fields');
      return;
    }

    const newStep: FunnelStep = {
      id: editingStep?.id || generateId(),
      label: stepForm.label,
      step_type: stepForm.step_type,
      pack_id: stepForm.pack_id,
      required: stepForm.required || false,
      notes: stepForm.notes,
    };

    let updatedSteps: FunnelStep[];
    if (editingStep) {
      // Update existing step
      updatedSteps = funnel.steps.map((s: FunnelStep) => 
        s.id === editingStep.id ? newStep : s
      );
    } else {
      // Add new step
      updatedSteps = [...funnel.steps, newStep];
    }

    updateField('steps', updatedSteps);
    setStepDialogOpen(false);
    setStepForm({});
    setEditingStep(null);
    
    // Clear steps error
    if (errors['steps']) {
      const newErrors = { ...errors };
      delete newErrors['steps'];
      setErrors(newErrors);
    }
  };

  const handleDeleteStep = (stepId: string): void => {
    if (!funnel) return;
    const updatedSteps = funnel.steps.filter((s: FunnelStep) => s.id !== stepId);
    updateField('steps', updatedSteps);
    toast.success('Step deleted');
  };

  const handleMoveStep = (index: number, direction: 'up' | 'down'): void => {
    if (!funnel) return;
    const newSteps = [...funnel.steps];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    
    if (targetIndex < 0 || targetIndex >= newSteps.length) return;
    
    [newSteps[index], newSteps[targetIndex]] = [newSteps[targetIndex], newSteps[index]];
    updateField('steps', newSteps);
  };

  const getStepTypeLabel = (type: FunnelStepType): string => {
    const labels: Record<FunnelStepType, string> = {
      pack_join: 'Pack Join',
      pack_exit: 'Pack Exit',
      score_checkpoint: 'Score Checkpoint',
      ritual_trigger: 'Ritual Trigger',
      custom: 'Custom',
    };
    return labels[type];
  };

  const getStatusColor = (status: Status): string => {
    const colors: Record<Status, string> = {
      active: 'bg-green-500/10 text-green-500 border-green-500/20',
      draft: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
      archived: 'bg-zinc-500/10 text-zinc-500 border-zinc-500/20',
    };
    return colors[status];
  };

  const getPackName = (packId?: string): string => {
    if (!packId) return '-';
    const pack = packs.find((p: PackDefinition) => p.id === packId);
    return pack ? pack.name : 'Unknown Pack';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-zinc-400">Loading...</div>
      </div>
    );
  }

  if (!funnel) {
    return null;
  }

  return (
    <div className="space-y-6 max-w-7xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => router.push('/funnels')}
            className="text-zinc-400 hover:text-white"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-white">{funnel.name}</h1>
            <p className="text-zinc-400 mt-1">
              Created {new Date(funnel.created_at).toLocaleDateString()}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <Badge className={getStatusColor(funnel.status)}>
            {funnel.status}
          </Badge>
          <Button
            onClick={() => handleSave(false)}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Save className="w-4 h-4 mr-2" />
            Save
          </Button>
          <Button
            onClick={() => handleSave(true)}
            variant="outline"
            className="border-zinc-700 text-white hover:bg-zinc-800"
          >
            Save & Exit
          </Button>
        </div>
      </div>

      {/* Error Summary */}
      {Object.keys(errors).length > 0 && (
        <Card className="bg-red-500/10 border-red-500/20">
          <CardContent className="pt-6">
            <div className="flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-red-500 mt-0.5" />
              <div>
                <h3 className="font-medium text-red-500 mb-2">Validation Errors</h3>
                <ul className="space-y-1">
                  {Object.entries(errors).map(([field, message]: [string, string]) => (
                    <li key={field} className="text-sm text-red-400">
                      {message}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Panel - Basic Info */}
        <div className="lg:col-span-1">
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader>
              <CardTitle className="text-white">Basic Information</CardTitle>
              <CardDescription className="text-zinc-400">
                Core funnel configuration
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-zinc-300">Name *</Label>
                <Input
                  id="name"
                  value={funnel.name}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleNameChange(e.target.value)}
                  className="bg-zinc-800 border-zinc-700 text-white"
                  placeholder="e.g., Onboarding Funnel"
                />
                {errors['name'] && (
                  <p className="text-sm text-red-400">{errors['name']}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="slug" className="text-zinc-300">Slug *</Label>
                <Input
                  id="slug"
                  value={funnel.slug}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('slug', e.target.value)}
                  className="bg-zinc-800 border-zinc-700 text-white font-mono"
                  placeholder="e.g., onboarding-funnel"
                />
                {errors['slug'] && (
                  <p className="text-sm text-red-400">{errors['slug']}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="status" className="text-zinc-300">Status</Label>
                <Select
                  value={funnel.status}
                  onValueChange={(value: string) => updateField('status', value as Status)}
                >
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="archived">Archived</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description" className="text-zinc-300">Description</Label>
                <Textarea
                  id="description"
                  value={funnel.description || ''}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => updateField('description', e.target.value)}
                  className="bg-zinc-800 border-zinc-700 text-white min-h-24"
                  placeholder="Brief description of this funnel..."
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Panel - Steps */}
        <div className="lg:col-span-2">
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-white">Funnel Steps</CardTitle>
                  <CardDescription className="text-zinc-400">
                    Define the sequence of steps
                  </CardDescription>
                </div>
                <Button
                  onClick={handleAddStep}
                  size="sm"
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Step
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {errors['steps'] && (
                <p className="text-sm text-red-400 mb-4">{errors['steps']}</p>
              )}

              {funnel.steps.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-zinc-500 mb-4">No steps added yet</p>
                  <Button
                    onClick={handleAddStep}
                    size="sm"
                    variant="outline"
                    className="border-zinc-700 text-white hover:bg-zinc-800"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add First Step
                  </Button>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow className="border-zinc-800">
                      <TableHead className="text-zinc-400 w-12">#</TableHead>
                      <TableHead className="text-zinc-400">Label</TableHead>
                      <TableHead className="text-zinc-400">Type</TableHead>
                      <TableHead className="text-zinc-400">Pack</TableHead>
                      <TableHead className="text-zinc-400 w-24">Required</TableHead>
                      <TableHead className="text-zinc-400 text-right w-32">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {funnel.steps.map((step: FunnelStep, index: number) => (
                      <TableRow key={step.id} className="border-zinc-800">
                        <TableCell className="text-zinc-400">{index + 1}</TableCell>
                        <TableCell className="font-medium text-white">{step.label}</TableCell>
                        <TableCell className="text-zinc-300">
                          {getStepTypeLabel(step.step_type)}
                        </TableCell>
                        <TableCell className="text-zinc-300 text-sm">
                          {getPackName(step.pack_id)}
                        </TableCell>
                        <TableCell>
                          {step.required && (
                            <Badge className="bg-blue-500/10 text-blue-500 border-blue-500/20">
                              Required
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end space-x-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleMoveStep(index, 'up')}
                              disabled={index === 0}
                              className="text-zinc-400 hover:text-white disabled:opacity-30"
                            >
                              <ArrowUp className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleMoveStep(index, 'down')}
                              disabled={index === funnel.steps.length - 1}
                              className="text-zinc-400 hover:text-white disabled:opacity-30"
                            >
                              <ArrowDown className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditStep(step)}
                              className="text-zinc-400 hover:text-white"
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteStep(step.id)}
                              className="text-zinc-400 hover:text-red-400"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Metadata */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader>
          <CardTitle className="text-white text-sm">Metadata</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-zinc-500">ID:</span>
              <span className="text-zinc-300 ml-2 font-mono">{funnel.id}</span>
            </div>
            <div>
              <span className="text-zinc-500">Created:</span>
              <span className="text-zinc-300 ml-2">
                {new Date(funnel.created_at).toLocaleString()}
              </span>
            </div>
            <div>
              <span className="text-zinc-500">Last Updated:</span>
              <span className="text-zinc-300 ml-2">
                {new Date(funnel.updated_at).toLocaleString()}
              </span>
            </div>
            <div>
              <span className="text-zinc-500">Total Steps:</span>
              <span className="text-zinc-300 ml-2">{funnel.steps.length}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Step Editor Dialog */}
      <Dialog open={stepDialogOpen} onOpenChange={setStepDialogOpen}>
        <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">
              {editingStep ? 'Edit Step' : 'Add Step'}
            </DialogTitle>
            <DialogDescription className="text-zinc-400">
              Configure the step properties
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="step_label" className="text-zinc-300">Label *</Label>
              <Input
                id="step_label"
                value={stepForm.label || ''}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                  setStepForm({ ...stepForm, label: e.target.value })
                }
                className="bg-zinc-800 border-zinc-700 text-white"
                placeholder="e.g., Join Wolf Pack"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="step_type" className="text-zinc-300">Step Type *</Label>
              <Select
                value={stepForm.step_type}
                onValueChange={(value: string) => 
                  setStepForm({ ...stepForm, step_type: value as FunnelStepType })
                }
              >
                <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pack_join">Pack Join</SelectItem>
                  <SelectItem value="pack_exit">Pack Exit</SelectItem>
                  <SelectItem value="score_checkpoint">Score Checkpoint</SelectItem>
                  <SelectItem value="ritual_trigger">Ritual Trigger</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {(stepForm.step_type === 'pack_join' || stepForm.step_type === 'pack_exit') && (
              <div className="space-y-2">
                <Label htmlFor="pack_id" className="text-zinc-300">Linked Pack</Label>
                <Select
                  value={stepForm.pack_id || 'none'}
                  onValueChange={(value: string) => 
                    setStepForm({ ...stepForm, pack_id: value === 'none' ? undefined : value })
                  }
                >
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No pack selected</SelectItem>
                    {packs.map((pack: PackDefinition) => (
                      <SelectItem key={pack.id} value={pack.id}>
                        {pack.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="flex items-center justify-between p-3 bg-zinc-800 rounded-lg">
              <div className="space-y-0.5">
                <Label htmlFor="step_required" className="text-zinc-300 text-sm">
                  Required Step
                </Label>
                <p className="text-xs text-zinc-500">
                  Must this step be completed?
                </p>
              </div>
              <Switch
                id="step_required"
                checked={stepForm.required || false}
                onCheckedChange={(checked: boolean) => 
                  setStepForm({ ...stepForm, required: checked })
                }
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="step_notes" className="text-zinc-300">Notes</Label>
              <Textarea
                id="step_notes"
                value={stepForm.notes || ''}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => 
                  setStepForm({ ...stepForm, notes: e.target.value })
                }
                className="bg-zinc-800 border-zinc-700 text-white min-h-20"
                placeholder="Additional notes or instructions..."
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setStepDialogOpen(false)}
              className="border-zinc-700 text-white hover:bg-zinc-800"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSaveStep}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {editingStep ? 'Update Step' : 'Add Step'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
