'use client';

import { useEffect, useState, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { funnelStorage, generateSlug } from '@/lib/storage';
import { Plus, Search, Edit, Copy, Trash2, CheckCircle, Archive } from 'lucide-react';
import { toast } from 'sonner';
import type { FunnelDefinition, Status } from '@/types';

function FunnelsPageContent(): JSX.Element {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [funnels, setFunnels] = useState<FunnelDefinition[]>([]);
  const [filteredFunnels, setFilteredFunnels] = useState<FunnelDefinition[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState<boolean>(false);
  const [funnelToDelete, setFunnelToDelete] = useState<string | null>(null);

  useEffect(() => {
    loadFunnels();

    // Check if we should open the new funnel dialog
    const action = searchParams.get('action');
    if (action === 'new') {
      handleNewFunnel();
    }
  }, [searchParams]);

  useEffect(() => {
    filterFunnels();
  }, [funnels, searchQuery, statusFilter]);

  const loadFunnels = (): void => {
    const allFunnels = funnelStorage.getAll();
    setFunnels(allFunnels);
  };

  const filterFunnels = (): void => {
    let filtered = [...funnels];

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter((funnel: FunnelDefinition) =>
        funnel.name.toLowerCase().includes(query) ||
        funnel.slug.toLowerCase().includes(query) ||
        funnel.description?.toLowerCase().includes(query)
      );
    }

    // Status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter((funnel: FunnelDefinition) => funnel.status === statusFilter);
    }

    setFilteredFunnels(filtered);
  };

  const handleNewFunnel = (): void => {
    try {
      const newFunnel = funnelStorage.create({
        name: 'New Funnel',
        slug: generateSlug(`new-funnel-${Date.now()}`),
        status: 'draft',
        steps: [],
      });

      toast.success('Funnel created!');
      router.push(`/funnels/${newFunnel.id}`);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to create funnel: ${errorMessage}`);
    }
  };

  const handleDuplicate = (funnel: FunnelDefinition): void => {
    try {
      const duplicated = funnelStorage.duplicate(funnel.id, `${funnel.name} (Copy)`);
      toast.success('Funnel duplicated!');
      loadFunnels();
      router.push(`/funnels/${duplicated.id}`);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to duplicate funnel: ${errorMessage}`);
    }
  };

  const handleSetActive = (funnelId: string): void => {
    try {
      funnelStorage.update(funnelId, { status: 'active' });
      toast.success('Funnel activated!');
      loadFunnels();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to activate funnel: ${errorMessage}`);
    }
  };

  const handleArchive = (funnelId: string): void => {
    try {
      funnelStorage.update(funnelId, { status: 'archived' });
      toast.success('Funnel archived!');
      loadFunnels();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to archive funnel: ${errorMessage}`);
    }
  };

  const handleDeleteClick = (funnelId: string): void => {
    setFunnelToDelete(funnelId);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = (): void => {
    if (funnelToDelete) {
      try {
        funnelStorage.delete(funnelToDelete);
        toast.success('Funnel deleted!');
        loadFunnels();
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        toast.error(`Failed to delete funnel: ${errorMessage}`);
      }
    }
    setDeleteDialogOpen(false);
    setFunnelToDelete(null);
  };

  const getStatusColor = (status: Status): string => {
    const colors: Record<Status, string> = {
      active: 'bg-green-500/10 text-green-500 border-green-500/20',
      draft: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
      archived: 'bg-zinc-500/10 text-zinc-500 border-zinc-500/20',
    };
    return colors[status];
  };

  const formatDate = (isoDate: string): string => {
    return new Date(isoDate).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Funnels</h1>
          <p className="text-zinc-400 mt-1">Manage funnel definitions and steps</p>
        </div>
        <Button onClick={handleNewFunnel} className="bg-purple-600 hover:bg-purple-700">
          <Plus className="w-4 h-4 mr-2" />
          New Funnel
        </Button>
      </div>

      {/* Filters */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-zinc-500" />
              <Input
                placeholder="Search funnels..."
                value={searchQuery}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
                className="pl-10 bg-zinc-800 border-zinc-700 text-white"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48 bg-zinc-800 border-zinc-700 text-white">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="archived">Archived</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader>
          <CardTitle className="text-white">
            {filteredFunnels.length} {filteredFunnels.length === 1 ? 'Funnel' : 'Funnels'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-zinc-800 hover:bg-zinc-800/50">
                <TableHead className="text-zinc-400">Name</TableHead>
                <TableHead className="text-zinc-400">Slug</TableHead>
                <TableHead className="text-zinc-400">Status</TableHead>
                <TableHead className="text-zinc-400">Steps</TableHead>
                <TableHead className="text-zinc-400">Updated</TableHead>
                <TableHead className="text-zinc-400 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredFunnels.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-zinc-500 py-8">
                    No funnels found
                  </TableCell>
                </TableRow>
              ) : (
                filteredFunnels.map((funnel: FunnelDefinition) => (
                  <TableRow key={funnel.id} className="border-zinc-800 hover:bg-zinc-800/50">
                    <TableCell className="font-medium text-white">
                      <Link href={`/funnels/${funnel.id}`} className="hover:text-purple-400">
                        {funnel.name}
                      </Link>
                    </TableCell>
                    <TableCell className="font-mono text-sm text-zinc-400">
                      {funnel.slug}
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(funnel.status)}>
                        {funnel.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-zinc-300">
                      {funnel.steps.length}
                    </TableCell>
                    <TableCell className="text-zinc-400 text-sm">
                      {formatDate(funnel.updated_at)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => router.push(`/funnels/${funnel.id}`)}
                          className="text-zinc-400 hover:text-white"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDuplicate(funnel)}
                          className="text-zinc-400 hover:text-white"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        {funnel.status !== 'active' && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleSetActive(funnel.id)}
                            className="text-zinc-400 hover:text-green-400"
                          >
                            <CheckCircle className="w-4 h-4" />
                          </Button>
                        )}
                        {funnel.status !== 'archived' && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleArchive(funnel.id)}
                            className="text-zinc-400 hover:text-yellow-400"
                          >
                            <Archive className="w-4 h-4" />
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteClick(funnel.id)}
                          className="text-zinc-400 hover:text-red-400"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent className="bg-zinc-900 border-zinc-800">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Delete Funnel</AlertDialogTitle>
            <AlertDialogDescription className="text-zinc-400">
              Are you sure you want to delete this funnel? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-zinc-800 border-zinc-700 text-white hover:bg-zinc-700">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default function FunnelsPage(): JSX.Element {
  return (
    <Suspense fallback={<div className="flex items-center justify-center h-96"><div className="text-zinc-400">Loading...</div></div>}>
      <FunnelsPageContent />
    </Suspense>
  );
}
