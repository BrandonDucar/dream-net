import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Navigation } from "@/components/navigation";
import { Toaster } from "@/components/ui/sonner";
import FarcasterWrapper from "@/components/FarcasterWrapper";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>): JSX.Element {
  return (
        <html lang="en" className="dark">
          <body
            className={`${geistSans.variable} ${geistMono.variable} antialiased bg-zinc-950 text-white min-h-screen`}
          >
            <Navigation />
            <main className="container mx-auto px-4 py-8">
              
      <FarcasterWrapper>
        {children}
      </FarcasterWrapper>
      
            </main>
            <Toaster />
          </body>
        </html>
      );
}

export const metadata: Metadata = {
        title: "Pack & Funnel Manager",
        description: "Manage and configure pack and funnel definitions for DreamNet. Easily create, edit, and export active definitions with rules for wallet assignment and integration.",
        other: { "fc:frame": JSON.stringify({"version":"next","imageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_4fc81c7a-1534-4d4e-8d16-31db29e3021c-dPWFwaq4eA4r5FGbv0f9iBP0BCEOjp","button":{"title":"Open with Ohara","action":{"type":"launch_frame","name":"Pack & Funnel Manager","url":"https://particularly-dull-007.app.ohara.ai","splashImageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/farcaster/splash_images/splash_image1.svg","splashBackgroundColor":"#ffffff"}}}
        ) }
    };
