'use client';

import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { packStorage, generateSlug } from '@/lib/storage';
import { ArrowLeft, Save, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import type { PackDefinition, PackType, Status, PackRules } from '@/types';

export default function PackEditorPage(): JSX.Element {
  const router = useRouter();
  const params = useParams();
  const packId = params.id as string;

  const [pack, setPack] = useState<PackDefinition | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    loadPack();
  }, [packId]);

  const loadPack = (): void => {
    try {
      const loadedPack = packStorage.getById(packId);
      if (!loadedPack) {
        toast.error('Pack not found');
        router.push('/packs');
        return;
      }
      setPack(loadedPack);
    } catch (error) {
      toast.error('Failed to load pack');
      router.push('/packs');
    } finally {
      setLoading(false);
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!pack) return false;

    if (!pack.name.trim()) {
      newErrors['name'] = 'Name is required';
    }

    if (!pack.slug.trim()) {
      newErrors['slug'] = 'Slug is required';
    }

    // Check if at least one rule is set
    const hasRules = Object.values(pack.rules).some((value: unknown) => {
      if (typeof value === 'string') {
        return value.trim() !== '';
      }
      if (typeof value === 'number') {
        return value > 0;
      }
      if (typeof value === 'boolean') {
        return true;
      }
      return false;
    });

    if (!hasRules) {
      newErrors['rules'] = 'At least one rule must be set';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async (exitAfter: boolean = false): Promise<void> => {
    if (!pack || !validateForm()) {
      toast.error('Please fix validation errors');
      return;
    }

    try {
      packStorage.update(packId, pack);
      toast.success('Pack saved successfully!');
      
      if (exitAfter) {
        router.push('/packs');
      } else {
        loadPack();
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to save pack: ${errorMessage}`);
    }
  };

  const updateField = <K extends keyof PackDefinition>(
    field: K,
    value: PackDefinition[K]
  ): void => {
    if (!pack) return;
    setPack({ ...pack, [field]: value });
    
    // Clear error for this field
    if (errors[field]) {
      const newErrors = { ...errors };
      delete newErrors[field];
      setErrors(newErrors);
    }
  };

  const updateRule = <K extends keyof PackRules>(
    rule: K,
    value: PackRules[K]
  ): void => {
    if (!pack) return;
    setPack({
      ...pack,
      rules: { ...pack.rules, [rule]: value },
    });
    
    // Clear rules error
    if (errors['rules']) {
      const newErrors = { ...errors };
      delete newErrors['rules'];
      setErrors(newErrors);
    }
  };

  const handleNameChange = (name: string): void => {
    updateField('name', name);
    // Auto-generate slug from name if it hasn't been manually changed
    if (pack && (pack.slug === '' || pack.slug.startsWith('new-pack-'))) {
      updateField('slug', generateSlug(name));
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-zinc-400">Loading...</div>
      </div>
    );
  }

  if (!pack) {
    return null;
  }

  const getRulesSummary = (): string[] => {
    const summary: string[] = [];
    if (pack.rules.min_balance) summary.push(`Min Balance: ${pack.rules.min_balance}`);
    if (pack.rules.max_balance) summary.push(`Max Balance: ${pack.rules.max_balance}`);
    if (pack.rules.min_hold_time_days) summary.push(`Min Hold: ${pack.rules.min_hold_time_days} days`);
    if (pack.rules.min_tvl) summary.push(`Min TVL: ${pack.rules.min_tvl}`);
    if (pack.rules.min_trades_last_30d) summary.push(`Min Trades: ${pack.rules.min_trades_last_30d}/30d`);
    if (pack.rules.min_lp_amount) summary.push(`Min LP: ${pack.rules.min_lp_amount}`);
    if (pack.rules.allow_multiple_packs !== undefined) {
      summary.push(`Multiple Packs: ${pack.rules.allow_multiple_packs ? 'Yes' : 'No'}`);
    }
    return summary;
  };

  const getStatusColor = (status: Status): string => {
    const colors: Record<Status, string> = {
      active: 'bg-green-500/10 text-green-500 border-green-500/20',
      draft: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
      archived: 'bg-zinc-500/10 text-zinc-500 border-zinc-500/20',
    };
    return colors[status];
  };

  return (
    <div className="space-y-6 max-w-7xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => router.push('/packs')}
            className="text-zinc-400 hover:text-white"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-white">{pack.name}</h1>
            <p className="text-zinc-400 mt-1">
              Created {new Date(pack.created_at).toLocaleDateString()}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <Badge className={getStatusColor(pack.status)}>
            {pack.status}
          </Badge>
          <Button
            onClick={() => handleSave(false)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Save className="w-4 h-4 mr-2" />
            Save
          </Button>
          <Button
            onClick={() => handleSave(true)}
            variant="outline"
            className="border-zinc-700 text-white hover:bg-zinc-800"
          >
            Save & Exit
          </Button>
        </div>
      </div>

      {/* Error Summary */}
      {Object.keys(errors).length > 0 && (
        <Card className="bg-red-500/10 border-red-500/20">
          <CardContent className="pt-6">
            <div className="flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-red-500 mt-0.5" />
              <div>
                <h3 className="font-medium text-red-500 mb-2">Validation Errors</h3>
                <ul className="space-y-1">
                  {Object.entries(errors).map(([field, message]: [string, string]) => (
                    <li key={field} className="text-sm text-red-400">
                      {message}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Panel - Basic Info */}
        <div className="space-y-6">
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader>
              <CardTitle className="text-white">Basic Information</CardTitle>
              <CardDescription className="text-zinc-400">
                Core pack configuration
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-zinc-300">Name *</Label>
                <Input
                  id="name"
                  value={pack.name}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleNameChange(e.target.value)}
                  className="bg-zinc-800 border-zinc-700 text-white"
                  placeholder="e.g., Wolf Pack Tier 1"
                />
                {errors['name'] && (
                  <p className="text-sm text-red-400">{errors['name']}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="slug" className="text-zinc-300">Slug *</Label>
                <Input
                  id="slug"
                  value={pack.slug}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('slug', e.target.value)}
                  className="bg-zinc-800 border-zinc-700 text-white font-mono"
                  placeholder="e.g., wolf-pack-tier-1"
                />
                {errors['slug'] && (
                  <p className="text-sm text-red-400">{errors['slug']}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="type" className="text-zinc-300">Type</Label>
                <Select
                  value={pack.type}
                  onValueChange={(value: string) => updateField('type', value as PackType)}
                >
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="wolf_pack">Wolf Pack</SelectItem>
                    <SelectItem value="whale_pod">Whale Pod</SelectItem>
                    <SelectItem value="orca_ring">Orca Ring</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="status" className="text-zinc-300">Status</Label>
                <Select
                  value={pack.status}
                  onValueChange={(value: string) => updateField('status', value as Status)}
                >
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="archived">Archived</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description" className="text-zinc-300">Description</Label>
                <Textarea
                  id="description"
                  value={pack.description || ''}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => updateField('description', e.target.value)}
                  className="bg-zinc-800 border-zinc-700 text-white min-h-20"
                  placeholder="Brief description of this pack..."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="chain" className="text-zinc-300">Chain</Label>
                  <Input
                    id="chain"
                    value={pack.chain || ''}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('chain', e.target.value)}
                    className="bg-zinc-800 border-zinc-700 text-white"
                    placeholder="e.g., base"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="primary_token" className="text-zinc-300">Primary Token</Label>
                  <Input
                    id="primary_token"
                    value={pack.primary_token || ''}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateField('primary_token', e.target.value)}
                    className="bg-zinc-800 border-zinc-700 text-white"
                    placeholder="e.g., DREAM"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Panel - Rules */}
        <div className="space-y-6">
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader>
              <CardTitle className="text-white">Pack Rules</CardTitle>
              <CardDescription className="text-zinc-400">
                Define membership criteria
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Rules Summary */}
              {getRulesSummary().length > 0 && (
                <div className="p-3 bg-zinc-800 rounded-lg">
                  <h4 className="text-sm font-medium text-zinc-300 mb-2">Active Rules:</h4>
                  <ul className="space-y-1">
                    {getRulesSummary().map((rule: string, index: number) => (
                      <li key={index} className="text-xs text-zinc-400">
                        • {rule}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {errors['rules'] && (
                <p className="text-sm text-red-400">{errors['rules']}</p>
              )}

              <Separator className="bg-zinc-800" />

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="min_balance" className="text-zinc-300 text-sm">Min Balance</Label>
                  <Input
                    id="min_balance"
                    value={pack.rules.min_balance || ''}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateRule('min_balance', e.target.value)}
                    className="bg-zinc-800 border-zinc-700 text-white"
                    placeholder="e.g., 1000"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="max_balance" className="text-zinc-300 text-sm">Max Balance</Label>
                  <Input
                    id="max_balance"
                    value={pack.rules.max_balance || ''}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateRule('max_balance', e.target.value)}
                    className="bg-zinc-800 border-zinc-700 text-white"
                    placeholder="e.g., 10000"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="min_hold_time_days" className="text-zinc-300 text-sm">
                  Min Hold Time (days)
                </Label>
                <Input
                  id="min_hold_time_days"
                  type="number"
                  value={pack.rules.min_hold_time_days || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    updateRule('min_hold_time_days', e.target.value ? parseInt(e.target.value) : undefined)
                  }
                  className="bg-zinc-800 border-zinc-700 text-white"
                  placeholder="e.g., 30"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="min_tvl" className="text-zinc-300 text-sm">Min TVL</Label>
                <Input
                  id="min_tvl"
                  value={pack.rules.min_tvl || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateRule('min_tvl', e.target.value)}
                  className="bg-zinc-800 border-zinc-700 text-white"
                  placeholder="e.g., 50000"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="min_trades_last_30d" className="text-zinc-300 text-sm">
                  Min Trades (Last 30 Days)
                </Label>
                <Input
                  id="min_trades_last_30d"
                  type="number"
                  value={pack.rules.min_trades_last_30d || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    updateRule('min_trades_last_30d', e.target.value ? parseInt(e.target.value) : undefined)
                  }
                  className="bg-zinc-800 border-zinc-700 text-white"
                  placeholder="e.g., 5"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="min_lp_amount" className="text-zinc-300 text-sm">Min LP Amount</Label>
                <Input
                  id="min_lp_amount"
                  value={pack.rules.min_lp_amount || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateRule('min_lp_amount', e.target.value)}
                  className="bg-zinc-800 border-zinc-700 text-white"
                  placeholder="e.g., 1000"
                />
              </div>

              <div className="flex items-center justify-between p-3 bg-zinc-800 rounded-lg">
                <div className="space-y-0.5">
                  <Label htmlFor="allow_multiple_packs" className="text-zinc-300 text-sm">
                    Allow Multiple Packs
                  </Label>
                  <p className="text-xs text-zinc-500">
                    Can wallets be in other packs?
                  </p>
                </div>
                <Switch
                  id="allow_multiple_packs"
                  checked={pack.rules.allow_multiple_packs || false}
                  onCheckedChange={(checked: boolean) => updateRule('allow_multiple_packs', checked)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="custom_logic" className="text-zinc-300 text-sm">Custom Logic</Label>
                <Textarea
                  id="custom_logic"
                  value={pack.rules.custom_logic || ''}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => updateRule('custom_logic', e.target.value)}
                  className="bg-zinc-800 border-zinc-700 text-white min-h-24"
                  placeholder="Describe any custom membership logic..."
                />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Metadata */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader>
          <CardTitle className="text-white text-sm">Metadata</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-zinc-500">ID:</span>
              <span className="text-zinc-300 ml-2 font-mono">{pack.id}</span>
            </div>
            <div>
              <span className="text-zinc-500">Created:</span>
              <span className="text-zinc-300 ml-2">
                {new Date(pack.created_at).toLocaleString()}
              </span>
            </div>
            <div>
              <span className="text-zinc-500">Last Updated:</span>
              <span className="text-zinc-300 ml-2">
                {new Date(pack.updated_at).toLocaleString()}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
