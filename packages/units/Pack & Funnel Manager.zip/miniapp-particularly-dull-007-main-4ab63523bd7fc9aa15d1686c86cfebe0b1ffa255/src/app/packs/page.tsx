'use client';

import { useEffect, useState, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { packStorage, generateSlug } from '@/lib/storage';
import { Plus, Search, Edit, Copy, Trash2, CheckCircle, Archive } from 'lucide-react';
import { toast } from 'sonner';
import type { PackDefinition, PackType, Status } from '@/types';

function PacksPageContent(): JSX.Element {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [packs, setPacks] = useState<PackDefinition[]>([]);
  const [filteredPacks, setFilteredPacks] = useState<PackDefinition[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState<boolean>(false);
  const [packToDelete, setPackToDelete] = useState<string | null>(null);

  useEffect(() => {
    loadPacks();

    // Check if we should open the new pack dialog
    const action = searchParams.get('action');
    if (action === 'new') {
      handleNewPack();
    }
  }, [searchParams]);

  useEffect(() => {
    filterPacks();
  }, [packs, searchQuery, typeFilter, statusFilter]);

  const loadPacks = (): void => {
    const allPacks = packStorage.getAll();
    setPacks(allPacks);
  };

  const filterPacks = (): void => {
    let filtered = [...packs];

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter((pack: PackDefinition) =>
        pack.name.toLowerCase().includes(query) ||
        pack.slug.toLowerCase().includes(query) ||
        pack.description?.toLowerCase().includes(query)
      );
    }

    // Type filter
    if (typeFilter !== 'all') {
      filtered = filtered.filter((pack: PackDefinition) => pack.type === typeFilter);
    }

    // Status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter((pack: PackDefinition) => pack.status === statusFilter);
    }

    setFilteredPacks(filtered);
  };

  const handleNewPack = (): void => {
    try {
      const newPack = packStorage.create({
        name: 'New Pack',
        slug: generateSlug(`new-pack-${Date.now()}`),
        type: 'wolf_pack',
        status: 'draft',
        rules: {},
      });

      toast.success('Pack created!');
      router.push(`/packs/${newPack.id}`);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to create pack: ${errorMessage}`);
    }
  };

  const handleDuplicate = (pack: PackDefinition): void => {
    try {
      const duplicated = packStorage.duplicate(pack.id, `${pack.name} (Copy)`);
      toast.success('Pack duplicated!');
      loadPacks();
      router.push(`/packs/${duplicated.id}`);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to duplicate pack: ${errorMessage}`);
    }
  };

  const handleSetActive = (packId: string): void => {
    try {
      packStorage.update(packId, { status: 'active' });
      toast.success('Pack activated!');
      loadPacks();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to activate pack: ${errorMessage}`);
    }
  };

  const handleArchive = (packId: string): void => {
    try {
      packStorage.update(packId, { status: 'archived' });
      toast.success('Pack archived!');
      loadPacks();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to archive pack: ${errorMessage}`);
    }
  };

  const handleDeleteClick = (packId: string): void => {
    setPackToDelete(packId);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = (): void => {
    if (packToDelete) {
      try {
        packStorage.delete(packToDelete);
        toast.success('Pack deleted!');
        loadPacks();
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        toast.error(`Failed to delete pack: ${errorMessage}`);
      }
    }
    setDeleteDialogOpen(false);
    setPackToDelete(null);
  };

  const getPackTypeLabel = (type: PackType): string => {
    const labels: Record<PackType, string> = {
      wolf_pack: 'Wolf Pack',
      whale_pod: 'Whale Pod',
      orca_ring: 'Orca Ring',
      custom: 'Custom',
    };
    return labels[type];
  };

  const getStatusColor = (status: Status): string => {
    const colors: Record<Status, string> = {
      active: 'bg-green-500/10 text-green-500 border-green-500/20',
      draft: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
      archived: 'bg-zinc-500/10 text-zinc-500 border-zinc-500/20',
    };
    return colors[status];
  };

  const formatDate = (isoDate: string): string => {
    return new Date(isoDate).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Packs</h1>
          <p className="text-zinc-400 mt-1">Manage pack definitions and rules</p>
        </div>
        <Button onClick={handleNewPack} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          New Pack
        </Button>
      </div>

      {/* Filters */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-zinc-500" />
              <Input
                placeholder="Search packs..."
                value={searchQuery}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
                className="pl-10 bg-zinc-800 border-zinc-700 text-white"
              />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-full md:w-48 bg-zinc-800 border-zinc-700 text-white">
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="wolf_pack">Wolf Pack</SelectItem>
                <SelectItem value="whale_pod">Whale Pod</SelectItem>
                <SelectItem value="orca_ring">Orca Ring</SelectItem>
                <SelectItem value="custom">Custom</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48 bg-zinc-800 border-zinc-700 text-white">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="archived">Archived</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader>
          <CardTitle className="text-white">
            {filteredPacks.length} {filteredPacks.length === 1 ? 'Pack' : 'Packs'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-zinc-800 hover:bg-zinc-800/50">
                <TableHead className="text-zinc-400">Name</TableHead>
                <TableHead className="text-zinc-400">Type</TableHead>
                <TableHead className="text-zinc-400">Slug</TableHead>
                <TableHead className="text-zinc-400">Status</TableHead>
                <TableHead className="text-zinc-400">Token</TableHead>
                <TableHead className="text-zinc-400">Updated</TableHead>
                <TableHead className="text-zinc-400 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredPacks.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-zinc-500 py-8">
                    No packs found
                  </TableCell>
                </TableRow>
              ) : (
                filteredPacks.map((pack: PackDefinition) => (
                  <TableRow key={pack.id} className="border-zinc-800 hover:bg-zinc-800/50">
                    <TableCell className="font-medium text-white">
                      <Link href={`/packs/${pack.id}`} className="hover:text-blue-400">
                        {pack.name}
                      </Link>
                    </TableCell>
                    <TableCell className="text-zinc-300">
                      {getPackTypeLabel(pack.type)}
                    </TableCell>
                    <TableCell className="font-mono text-sm text-zinc-400">
                      {pack.slug}
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(pack.status)}>
                        {pack.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-zinc-300">
                      {pack.primary_token || '-'}
                    </TableCell>
                    <TableCell className="text-zinc-400 text-sm">
                      {formatDate(pack.updated_at)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => router.push(`/packs/${pack.id}`)}
                          className="text-zinc-400 hover:text-white"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDuplicate(pack)}
                          className="text-zinc-400 hover:text-white"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        {pack.status !== 'active' && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleSetActive(pack.id)}
                            className="text-zinc-400 hover:text-green-400"
                          >
                            <CheckCircle className="w-4 h-4" />
                          </Button>
                        )}
                        {pack.status !== 'archived' && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleArchive(pack.id)}
                            className="text-zinc-400 hover:text-yellow-400"
                          >
                            <Archive className="w-4 h-4" />
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteClick(pack.id)}
                          className="text-zinc-400 hover:text-red-400"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent className="bg-zinc-900 border-zinc-800">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Delete Pack</AlertDialogTitle>
            <AlertDialogDescription className="text-zinc-400">
              Are you sure you want to delete this pack? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-zinc-800 border-zinc-700 text-white hover:bg-zinc-700">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default function PacksPage(): JSX.Element {
  return (
    <Suspense fallback={<div className="flex items-center justify-center h-96"><div className="text-zinc-400">Loading...</div></div>}>
      <PacksPageContent />
    </Suspense>
  );
}
