'use client'
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { packStorage, funnelStorage, walletStorage } from '@/lib/storage';
import { Package, GitBranch, Wallet, Plus, Activity, ArrowRight } from 'lucide-react';
import type { PackDefinition, FunnelDefinition } from '@/types';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DashboardPage(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [stats, setStats] = useState({
    totalPacks: 0,
    activePacks: 0,
    draftPacks: 0,
    totalFunnels: 0,
    activeFunnels: 0,
    totalWallets: 0,
  });
  const [recentPacks, setRecentPacks] = useState<PackDefinition[]>([]);
  const [recentFunnels, setRecentFunnels] = useState<FunnelDefinition[]>([]);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = (): void => {
    const packs = packStorage.getAll();
    const funnels = funnelStorage.getAll();
    const wallets = walletStorage.getAll();

    setStats({
      totalPacks: packs.length,
      activePacks: packs.filter((p: PackDefinition) => p.status === 'active').length,
      draftPacks: packs.filter((p: PackDefinition) => p.status === 'draft').length,
      totalFunnels: funnels.length,
      activeFunnels: funnels.filter((f: FunnelDefinition) => f.status === 'active').length,
      totalWallets: wallets.length,
    });

    // Get 3 most recent packs
    const sortedPacks = [...packs].sort(
      (a: PackDefinition, b: PackDefinition) => 
        new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
    );
    setRecentPacks(sortedPacks.slice(0, 3));

    // Get 3 most recent funnels
    const sortedFunnels = [...funnels].sort(
      (a: FunnelDefinition, b: FunnelDefinition) => 
        new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
    );
    setRecentFunnels(sortedFunnels.slice(0, 3));
  };

  const getPackTypeLabel = (type: string): string => {
    const labels: Record<string, string> = {
      wolf_pack: 'Wolf Pack',
      whale_pod: 'Whale Pod',
      orca_ring: 'Orca Ring',
      custom: 'Custom',
    };
    return labels[type] || type;
  };

  const getStatusColor = (status: string): string => {
    const colors: Record<string, string> = {
      active: 'bg-green-500/10 text-green-500 border-green-500/20',
      draft: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
      archived: 'bg-zinc-500/10 text-zinc-500 border-zinc-500/20',
    };
    return colors[status] || colors['draft'];
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-4xl font-bold text-white">Pack & Funnel Manager</h1>
        <p className="text-zinc-400 text-lg">
          DreamNet ecosystem configuration registry
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-zinc-400">Total Packs</CardTitle>
            <Package className="w-4 h-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-white">{stats.totalPacks}</div>
            <p className="text-xs text-zinc-500 mt-1">
              {stats.activePacks} active, {stats.draftPacks} draft
            </p>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-zinc-400">Total Funnels</CardTitle>
            <GitBranch className="w-4 h-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-white">{stats.totalFunnels}</div>
            <p className="text-xs text-zinc-500 mt-1">
              {stats.activeFunnels} active
            </p>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-zinc-400">Wallet Assignments</CardTitle>
            <Wallet className="w-4 h-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-white">{stats.totalWallets}</div>
            <p className="text-xs text-zinc-500 mt-1">
              Total assignments
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Activity className="w-5 h-5" />
            <span>Quick Actions</span>
          </CardTitle>
          <CardDescription className="text-zinc-400">
            Create new configurations
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3">
          <Link href="/packs?action=new">
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              New Pack
            </Button>
          </Link>
          <Link href="/funnels?action=new">
            <Button className="bg-purple-600 hover:bg-purple-700">
              <Plus className="w-4 h-4 mr-2" />
              New Funnel
            </Button>
          </Link>
          <Link href="/wallet-assignments?action=new">
            <Button className="bg-green-600 hover:bg-green-700">
              <Plus className="w-4 h-4 mr-2" />
              Assign Wallet
            </Button>
          </Link>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Packs */}
        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-white">Recent Packs</CardTitle>
              <Link href="/packs">
                <Button variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
                  View all
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
            <CardDescription className="text-zinc-400">
              Latest pack updates
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentPacks.length === 0 ? (
              <p className="text-zinc-500 text-sm py-4 text-center">No packs yet</p>
            ) : (
              recentPacks.map((pack: PackDefinition) => (
                <Link
                  key={pack.id}
                  href={`/packs/${pack.id}`}
                  className="block p-3 rounded-lg bg-zinc-800 hover:bg-zinc-700 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="space-y-1 flex-1">
                      <h4 className="font-medium text-white">{pack.name}</h4>
                      <p className="text-xs text-zinc-400">{getPackTypeLabel(pack.type)}</p>
                    </div>
                    <Badge className={getStatusColor(pack.status)}>
                      {pack.status}
                    </Badge>
                  </div>
                </Link>
              ))
            )}
          </CardContent>
        </Card>

        {/* Recent Funnels */}
        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-white">Recent Funnels</CardTitle>
              <Link href="/funnels">
                <Button variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
                  View all
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
            <CardDescription className="text-zinc-400">
              Latest funnel updates
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentFunnels.length === 0 ? (
              <p className="text-zinc-500 text-sm py-4 text-center">No funnels yet</p>
            ) : (
              recentFunnels.map((funnel: FunnelDefinition) => (
                <Link
                  key={funnel.id}
                  href={`/funnels/${funnel.id}`}
                  className="block p-3 rounded-lg bg-zinc-800 hover:bg-zinc-700 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="space-y-1 flex-1">
                      <h4 className="font-medium text-white">{funnel.name}</h4>
                      <p className="text-xs text-zinc-400">{funnel.steps.length} steps</p>
                    </div>
                    <Badge className={getStatusColor(funnel.status)}>
                      {funnel.status}
                    </Badge>
                  </div>
                </Link>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* API Documentation */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader>
          <CardTitle className="text-white">API Endpoints</CardTitle>
          <CardDescription className="text-zinc-400">
            External agents can read configuration data from these endpoints
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="font-mono text-sm">
            <div className="flex items-center space-x-3 p-2 bg-zinc-800 rounded">
              <Badge className="bg-green-500/10 text-green-500 border-green-500/20">GET</Badge>
              <code className="text-blue-400">/api/packs</code>
              <span className="text-zinc-500">List active packs</span>
            </div>
          </div>
          <div className="font-mono text-sm">
            <div className="flex items-center space-x-3 p-2 bg-zinc-800 rounded">
              <Badge className="bg-green-500/10 text-green-500 border-green-500/20">GET</Badge>
              <code className="text-blue-400">/api/packs/[slug]</code>
              <span className="text-zinc-500">Get pack by slug</span>
            </div>
          </div>
          <div className="font-mono text-sm">
            <div className="flex items-center space-x-3 p-2 bg-zinc-800 rounded">
              <Badge className="bg-green-500/10 text-green-500 border-green-500/20">GET</Badge>
              <code className="text-blue-400">/api/funnels</code>
              <span className="text-zinc-500">List active funnels</span>
            </div>
          </div>
          <div className="font-mono text-sm">
            <div className="flex items-center space-x-3 p-2 bg-zinc-800 rounded">
              <Badge className="bg-green-500/10 text-green-500 border-green-500/20">GET</Badge>
              <code className="text-blue-400">/api/funnels/[slug]</code>
              <span className="text-zinc-500">Get funnel by slug</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
