'use client';

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { walletStorage, packStorage } from '@/lib/storage';
import { Plus, Search, Trash2, Wallet } from 'lucide-react';
import { toast } from 'sonner';
import type { WalletAssignment, AssignmentSource, PackDefinition } from '@/types';

function WalletAssignmentsPageContent(): JSX.Element {
  const searchParams = useSearchParams();
  const [assignments, setAssignments] = useState<WalletAssignment[]>([]);
  const [filteredAssignments, setFilteredAssignments] = useState<WalletAssignment[]>([]);
  const [packs, setPacks] = useState<PackDefinition[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState<boolean>(false);
  const [assignmentToDelete, setAssignmentToDelete] = useState<{ wallet: string; pack: string } | null>(null);
  
  const [formData, setFormData] = useState<{
    wallet_address: string;
    pack_id: string;
    source: AssignmentSource;
    notes: string;
  }>({
    wallet_address: '',
    pack_id: '',
    source: 'manual',
    notes: '',
  });

  useEffect(() => {
    loadAssignments();
    loadPacks();

    // Check if we should open the new assignment dialog
    const action = searchParams.get('action');
    if (action === 'new') {
      handleNewAssignment();
    }
  }, [searchParams]);

  useEffect(() => {
    filterAssignments();
  }, [assignments, searchQuery]);

  const loadAssignments = (): void => {
    const allAssignments = walletStorage.getAll();
    setAssignments(allAssignments);
  };

  const loadPacks = (): void => {
    const allPacks = packStorage.getAll();
    setPacks(allPacks);
  };

  const filterAssignments = (): void => {
    let filtered = [...assignments];

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter((assignment: WalletAssignment) =>
        assignment.wallet_address.toLowerCase().includes(query) ||
        assignment.pack_id.toLowerCase().includes(query) ||
        assignment.notes?.toLowerCase().includes(query)
      );
    }

    setFilteredAssignments(filtered);
  };

  const handleNewAssignment = (): void => {
    setFormData({
      wallet_address: '',
      pack_id: '',
      source: 'manual',
      notes: '',
    });
    setDialogOpen(true);
  };

  const handleSaveAssignment = (): void => {
    if (!formData.wallet_address.trim() || !formData.pack_id) {
      toast.error('Please fill in wallet address and select a pack');
      return;
    }

    try {
      walletStorage.create({
        wallet_address: formData.wallet_address.trim(),
        pack_id: formData.pack_id,
        source: formData.source,
        notes: formData.notes.trim() || undefined,
      });

      toast.success('Wallet assigned to pack!');
      loadAssignments();
      setDialogOpen(false);
      setFormData({
        wallet_address: '',
        pack_id: '',
        source: 'manual',
        notes: '',
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to assign wallet: ${errorMessage}`);
    }
  };

  const handleDeleteClick = (walletAddress: string, packId: string): void => {
    setAssignmentToDelete({ wallet: walletAddress, pack: packId });
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = (): void => {
    if (assignmentToDelete) {
      try {
        walletStorage.delete(assignmentToDelete.wallet, assignmentToDelete.pack);
        toast.success('Assignment removed!');
        loadAssignments();
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        toast.error(`Failed to remove assignment: ${errorMessage}`);
      }
    }
    setDeleteDialogOpen(false);
    setAssignmentToDelete(null);
  };

  const getPackName = (packId: string): string => {
    const pack = packs.find((p: PackDefinition) => p.id === packId);
    return pack ? pack.name : packId;
  };

  const getSourceColor = (source: AssignmentSource): string => {
    const colors: Record<AssignmentSource, string> = {
      manual: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
      import: 'bg-purple-500/10 text-purple-500 border-purple-500/20',
      agent: 'bg-green-500/10 text-green-500 border-green-500/20',
    };
    return colors[source];
  };

  const formatDate = (isoDate: string): string => {
    return new Date(isoDate).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const shortenAddress = (address: string): string => {
    if (address.length <= 16) return address;
    return `${address.slice(0, 8)}...${address.slice(-6)}`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Wallet Assignments</h1>
          <p className="text-zinc-400 mt-1">Manage wallet-to-pack assignments</p>
        </div>
        <Button onClick={handleNewAssignment} className="bg-green-600 hover:bg-green-700">
          <Plus className="w-4 h-4 mr-2" />
          New Assignment
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-zinc-400">Total Assignments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-white">{assignments.length}</div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-zinc-400">Manual Assignments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-white">
              {assignments.filter((a: WalletAssignment) => a.source === 'manual').length}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-zinc-400">Agent Assignments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-white">
              {assignments.filter((a: WalletAssignment) => a.source === 'agent').length}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-zinc-500" />
            <Input
              placeholder="Search by wallet address, pack, or notes..."
              value={searchQuery}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
              className="pl-10 bg-zinc-800 border-zinc-700 text-white"
            />
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader>
          <CardTitle className="text-white">
            {filteredAssignments.length} {filteredAssignments.length === 1 ? 'Assignment' : 'Assignments'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-zinc-800 hover:bg-zinc-800/50">
                <TableHead className="text-zinc-400">Wallet Address</TableHead>
                <TableHead className="text-zinc-400">Pack</TableHead>
                <TableHead className="text-zinc-400">Source</TableHead>
                <TableHead className="text-zinc-400">Assigned</TableHead>
                <TableHead className="text-zinc-400">Notes</TableHead>
                <TableHead className="text-zinc-400 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAssignments.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-zinc-500 py-8">
                    No assignments found
                  </TableCell>
                </TableRow>
              ) : (
                filteredAssignments.map((assignment: WalletAssignment, index: number) => (
                  <TableRow key={`${assignment.wallet_address}-${assignment.pack_id}-${index}`} className="border-zinc-800 hover:bg-zinc-800/50">
                    <TableCell className="font-mono text-sm text-white">
                      <div className="flex items-center space-x-2">
                        <Wallet className="w-4 h-4 text-zinc-500" />
                        <span title={assignment.wallet_address}>
                          {shortenAddress(assignment.wallet_address)}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-zinc-300">
                      {getPackName(assignment.pack_id)}
                    </TableCell>
                    <TableCell>
                      <Badge className={getSourceColor(assignment.source)}>
                        {assignment.source}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-zinc-400 text-sm">
                      {formatDate(assignment.assigned_at)}
                    </TableCell>
                    <TableCell className="text-zinc-400 text-sm max-w-xs truncate">
                      {assignment.notes || '-'}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteClick(assignment.wallet_address, assignment.pack_id)}
                        className="text-zinc-400 hover:text-red-400"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Add Assignment Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-zinc-900 border-zinc-800 text-white">
          <DialogHeader>
            <DialogTitle className="text-white">New Wallet Assignment</DialogTitle>
            <DialogDescription className="text-zinc-400">
              Assign a wallet address to a pack
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="wallet_address" className="text-zinc-300">Wallet Address *</Label>
              <Input
                id="wallet_address"
                value={formData.wallet_address}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                  setFormData({ ...formData, wallet_address: e.target.value })
                }
                className="bg-zinc-800 border-zinc-700 text-white font-mono"
                placeholder="0x..."
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="pack_id" className="text-zinc-300">Pack *</Label>
              <Select
                value={formData.pack_id}
                onValueChange={(value: string) => setFormData({ ...formData, pack_id: value })}
              >
                <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white">
                  <SelectValue placeholder="Select a pack" />
                </SelectTrigger>
                <SelectContent>
                  {packs.map((pack: PackDefinition) => (
                    <SelectItem key={pack.id} value={pack.id}>
                      {pack.name} ({pack.type})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="source" className="text-zinc-300">Source</Label>
              <Select
                value={formData.source}
                onValueChange={(value: string) => 
                  setFormData({ ...formData, source: value as AssignmentSource })
                }
              >
                <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="manual">Manual</SelectItem>
                  <SelectItem value="import">Import</SelectItem>
                  <SelectItem value="agent">Agent</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes" className="text-zinc-300">Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => 
                  setFormData({ ...formData, notes: e.target.value })
                }
                className="bg-zinc-800 border-zinc-700 text-white min-h-20"
                placeholder="Optional notes..."
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDialogOpen(false)}
              className="border-zinc-700 text-white hover:bg-zinc-800"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSaveAssignment}
              className="bg-green-600 hover:bg-green-700"
            >
              Assign Wallet
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent className="bg-zinc-900 border-zinc-800">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Remove Assignment</AlertDialogTitle>
            <AlertDialogDescription className="text-zinc-400">
              Are you sure you want to remove this wallet assignment?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-zinc-800 border-zinc-700 text-white hover:bg-zinc-700">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-red-600 hover:bg-red-700"
            >
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default function WalletAssignmentsPage(): JSX.Element {
  return (
    <Suspense fallback={<div className="flex items-center justify-center h-96"><div className="text-zinc-400">Loading...</div></div>}>
      <WalletAssignmentsPageContent />
    </Suspense>
  );
}
