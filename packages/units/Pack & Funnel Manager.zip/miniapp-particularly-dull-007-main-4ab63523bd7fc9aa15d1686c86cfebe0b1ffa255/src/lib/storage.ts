// Storage layer for Pack & Funnel Manager using localStorage

import type { PackDefinition, FunnelDefinition, WalletAssignment } from '@/types';

const STORAGE_KEYS = {
  PACKS: 'dreamnet_packs',
  FUNNELS: 'dreamnet_funnels',
  WALLET_ASSIGNMENTS: 'dreamnet_wallet_assignments',
} as const;

// Helper to generate slug from name
export function generateSlug(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

// Helper to generate unique ID
export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

// Pack CRUD operations
export const packStorage = {
  getAll: (): PackDefinition[] => {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.PACKS);
    return data ? JSON.parse(data) : [];
  },

  getById: (id: string): PackDefinition | null => {
    const packs = packStorage.getAll();
    return packs.find((p: PackDefinition) => p.id === id) || null;
  },

  getBySlug: (slug: string): PackDefinition | null => {
    const packs = packStorage.getAll();
    return packs.find((p: PackDefinition) => p.slug === slug) || null;
  },

  create: (pack: Omit<PackDefinition, 'id' | 'created_at' | 'updated_at'>): PackDefinition => {
    const packs = packStorage.getAll();
    
    // Check for duplicate slug
    if (packs.some((p: PackDefinition) => p.slug === pack.slug)) {
      throw new Error(`Pack with slug "${pack.slug}" already exists`);
    }

    const newPack: PackDefinition = {
      ...pack,
      id: generateId(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    packs.push(newPack);
    localStorage.setItem(STORAGE_KEYS.PACKS, JSON.stringify(packs));
    return newPack;
  },

  update: (id: string, updates: Partial<PackDefinition>): PackDefinition => {
    const packs = packStorage.getAll();
    const index = packs.findIndex((p: PackDefinition) => p.id === id);
    
    if (index === -1) {
      throw new Error(`Pack with id "${id}" not found`);
    }

    // Check for duplicate slug if slug is being updated
    if (updates.slug && updates.slug !== packs[index].slug) {
      if (packs.some((p: PackDefinition) => p.slug === updates.slug)) {
        throw new Error(`Pack with slug "${updates.slug}" already exists`);
      }
    }

    const updatedPack: PackDefinition = {
      ...packs[index],
      ...updates,
      updated_at: new Date().toISOString(),
    };

    packs[index] = updatedPack;
    localStorage.setItem(STORAGE_KEYS.PACKS, JSON.stringify(packs));
    return updatedPack;
  },

  delete: (id: string): void => {
    const packs = packStorage.getAll();
    const filtered = packs.filter((p: PackDefinition) => p.id !== id);
    localStorage.setItem(STORAGE_KEYS.PACKS, JSON.stringify(filtered));
  },

  duplicate: (id: string, newName: string): PackDefinition => {
    const original = packStorage.getById(id);
    if (!original) {
      throw new Error(`Pack with id "${id}" not found`);
    }

    const newSlug = generateSlug(newName);
    return packStorage.create({
      ...original,
      name: newName,
      slug: newSlug,
      status: 'draft',
    });
  },
};

// Funnel CRUD operations
export const funnelStorage = {
  getAll: (): FunnelDefinition[] => {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.FUNNELS);
    return data ? JSON.parse(data) : [];
  },

  getById: (id: string): FunnelDefinition | null => {
    const funnels = funnelStorage.getAll();
    return funnels.find((f: FunnelDefinition) => f.id === id) || null;
  },

  getBySlug: (slug: string): FunnelDefinition | null => {
    const funnels = funnelStorage.getAll();
    return funnels.find((f: FunnelDefinition) => f.slug === slug) || null;
  },

  create: (funnel: Omit<FunnelDefinition, 'id' | 'created_at' | 'updated_at'>): FunnelDefinition => {
    const funnels = funnelStorage.getAll();
    
    // Check for duplicate slug
    if (funnels.some((f: FunnelDefinition) => f.slug === funnel.slug)) {
      throw new Error(`Funnel with slug "${funnel.slug}" already exists`);
    }

    const newFunnel: FunnelDefinition = {
      ...funnel,
      id: generateId(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    funnels.push(newFunnel);
    localStorage.setItem(STORAGE_KEYS.FUNNELS, JSON.stringify(funnels));
    return newFunnel;
  },

  update: (id: string, updates: Partial<FunnelDefinition>): FunnelDefinition => {
    const funnels = funnelStorage.getAll();
    const index = funnels.findIndex((f: FunnelDefinition) => f.id === id);
    
    if (index === -1) {
      throw new Error(`Funnel with id "${id}" not found`);
    }

    // Check for duplicate slug if slug is being updated
    if (updates.slug && updates.slug !== funnels[index].slug) {
      if (funnels.some((f: FunnelDefinition) => f.slug === updates.slug)) {
        throw new Error(`Funnel with slug "${updates.slug}" already exists`);
      }
    }

    const updatedFunnel: FunnelDefinition = {
      ...funnels[index],
      ...updates,
      updated_at: new Date().toISOString(),
    };

    funnels[index] = updatedFunnel;
    localStorage.setItem(STORAGE_KEYS.FUNNELS, JSON.stringify(funnels));
    return updatedFunnel;
  },

  delete: (id: string): void => {
    const funnels = funnelStorage.getAll();
    const filtered = funnels.filter((f: FunnelDefinition) => f.id !== id);
    localStorage.setItem(STORAGE_KEYS.FUNNELS, JSON.stringify(filtered));
  },

  duplicate: (id: string, newName: string): FunnelDefinition => {
    const original = funnelStorage.getById(id);
    if (!original) {
      throw new Error(`Funnel with id "${id}" not found`);
    }

    const newSlug = generateSlug(newName);
    return funnelStorage.create({
      ...original,
      name: newName,
      slug: newSlug,
      status: 'draft',
    });
  },
};

// Wallet Assignment CRUD operations
export const walletStorage = {
  getAll: (): WalletAssignment[] => {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.WALLET_ASSIGNMENTS);
    return data ? JSON.parse(data) : [];
  },

  create: (assignment: Omit<WalletAssignment, 'assigned_at'>): WalletAssignment => {
    const assignments = walletStorage.getAll();

    const newAssignment: WalletAssignment = {
      ...assignment,
      assigned_at: new Date().toISOString(),
    };

    assignments.push(newAssignment);
    localStorage.setItem(STORAGE_KEYS.WALLET_ASSIGNMENTS, JSON.stringify(assignments));
    return newAssignment;
  },

  delete: (walletAddress: string, packId: string): void => {
    const assignments = walletStorage.getAll();
    const filtered = assignments.filter(
      (a: WalletAssignment) => !(a.wallet_address === walletAddress && a.pack_id === packId)
    );
    localStorage.setItem(STORAGE_KEYS.WALLET_ASSIGNMENTS, JSON.stringify(filtered));
  },
};
