// Pack & Funnel Manager Type Definitions

export type PackType = "wolf_pack" | "whale_pod" | "orca_ring" | "custom";
export type Status = "draft" | "active" | "archived";
export type FunnelStepType = "pack_join" | "pack_exit" | "score_checkpoint" | "ritual_trigger" | "custom";
export type AssignmentSource = "manual" | "import" | "agent";

export interface PackRules {
  min_balance?: string;
  max_balance?: string;
  min_hold_time_days?: number;
  min_tvl?: string;
  min_trades_last_30d?: number;
  min_lp_amount?: string;
  allow_multiple_packs?: boolean;
  custom_logic?: string;
}

export interface PackDefinition {
  id: string;
  name: string;
  slug: string;
  type: PackType;
  description?: string;
  chain?: string;
  primary_token?: string;
  status: Status;
  created_at: string;
  updated_at: string;
  rules: PackRules;
  tags?: string[];
}

export interface FunnelStep {
  id: string;
  label: string;
  step_type: FunnelStepType;
  pack_id?: string;
  required?: boolean;
  notes?: string;
}

export interface FunnelDefinition {
  id: string;
  name: string;
  slug: string;
  description?: string;
  status: Status;
  created_at: string;
  updated_at: string;
  steps: FunnelStep[];
  tags?: string[];
}

export interface WalletAssignment {
  wallet_address: string;
  pack_id: string;
  assigned_at: string;
  source: AssignmentSource;
  notes?: string;
}
