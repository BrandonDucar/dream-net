import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { ResponseLogger } from "@/components/response-logger";
import { cookies } from "next/headers";
import { ReadyNotifier } from "@/components/ready-notifier";
import FarcasterWrapper from "@/components/FarcasterWrapper";

const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const requestId = cookies().get("x-request-id")?.value;

  return (
        <html lang="en">
          <head>
            {requestId && <meta name="x-request-id" content={requestId} />}
          </head>
          <body
            className={`${geistSans.variable} ${geistMono.variable} antialiased`}
          >
            {/* Do not remove this component, we use it to notify the parent that the mini-app is ready */}
            <ReadyNotifier />
            
      <FarcasterWrapper>
        {children}
      </FarcasterWrapper>
      
            <ResponseLogger />
          </body>
        </html>
      );
}

export const metadata: Metadata = {
  title: "Parlay Lab - Sports Betting EV Calculator & Edge Analyzer",
  description: "Build any parlay or same-game parlay with real-time analytics. Calculate expected value, find edges, analyze risk, and identify which legs add or destroy value. Free betting calculator for smart bettors.",
  keywords: [
    "parlay calculator",
    "SGP calculator",
    "expected value betting",
    "sports betting EV",
    "parlay analyzer",
    "betting edge calculator",
    "same game parlay",
    "parlay odds calculator",
    "betting risk analyzer",
    "sharp betting tool"
  ],
  authors: [{ name: "Parlay Lab" }],
  creator: "Parlay Lab",
  publisher: "Parlay Lab",
  robots: "index, follow",
  openGraph: {
    type: "website",
    title: "Parlay Lab - Sports Betting EV Calculator & Risk Analyzer",
    description: "Free parlay analyzer with expected value calculations, edge detection, and risk metrics. Build multi-leg and same-game parlays with confidence.",
    siteName: "Parlay Lab",
    locale: "en_US"
  },
  twitter: {
    card: "summary_large_image",
    title: "Parlay Lab - Parlay EV Calculator",
    description: "Analyze parlays & SGPs with real-time EV, edge detection, and risk metrics. Make smarter bets."
  },
  other: {
    "fc:frame": JSON.stringify({
      version: "next",
      imageUrl: "https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_e56b5e9d-6487-4afe-8e9a-d7220aa91df2-xBPNugWBJYTkLrLaPgAG1TefpaydtK",
      button: {
        title: "Open with Ohara",
        action: {
          type: "launch_frame",
          name: "Parlay Lab",
          url: "https://put-desk-854.app.ohara.ai",
          splashImageUrl: "https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/farcaster/splash_images/splash_image1.svg",
          splashBackgroundColor: "#ffffff"
        }
      }
    })
  }
};
