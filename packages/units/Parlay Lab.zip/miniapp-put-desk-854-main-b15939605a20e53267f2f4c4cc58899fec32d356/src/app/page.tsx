'use client'
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Trash2, TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react';
import { Toaster } from '@/components/ui/toaster';
import { LocationBanner } from '@/components/location-banner';
import { AIInsightsPanel } from '@/components/ai-insights-panel';
import { SaveLoadPanel } from '@/components/save-load-panel';
import { PresetSelector } from '@/components/preset-selector';
import type { OddsFormat, ParlayLeg, ParlayResult } from '@/lib/parlay';
import {
  decimalFromLegOdds,
  impliedProbabilityFromDecimal,
  buildParlayResult
} from '@/lib/parlay';
import { parseParlayFromURL } from '@/lib/storage';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function ParlayAnalyzer(): JSX.Element {
  const { addMiniApp } = useAddMiniApp();
  const isInFarcaster = useIsInFarcaster()
  useQuickAuth(isInFarcaster)
  useEffect(() => {
    const tryAddMiniApp = async () => {
      try {
        await addMiniApp()
      } catch (error) {
        console.error('Failed to add mini app:', error)
      }
    }

    tryAddMiniApp()
  }, [addMiniApp])
  
  useEffect(() => {
    const initializeFarcaster = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 100))
        
        if (document.readyState !== 'complete') {
          await new Promise<void>(resolve => {
            if (document.readyState === 'complete') {
              resolve()
            } else {
              window.addEventListener('load', () => resolve(), { once: true })
            }
          })
        }

        await sdk.actions.ready()
        console.log('Farcaster SDK initialized successfully - app fully loaded')
      } catch (error) {
        console.error('Failed to initialize Farcaster SDK:', error)
        
        setTimeout(async () => {
          try {
            await sdk.actions.ready()
            console.log('Farcaster SDK initialized on retry')
          } catch (retryError) {
            console.error('Farcaster SDK retry failed:', retryError)
          }
        }, 1000)
      }
    }

    initializeFarcaster()
  }, [])

  const [label, setLabel] = useState<string>('');
  const [oddsFormat, setOddsFormat] = useState<OddsFormat>('american');
  const [oddsInput, setOddsInput] = useState<string>('');
  const [userProbInput, setUserProbInput] = useState<string>('');
  const [correlationGroup, setCorrelationGroup] = useState<string>('');
  const [legs, setLegs] = useState<ParlayLeg[]>([]);
  const [result, setResult] = useState<ParlayResult | null>(null);

  // Load parlay from URL if shared
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const encoded = params.get('parlay');
    if (encoded) {
      const parsedLegs = parseParlayFromURL(encoded);
      if (parsedLegs) {
        setLegs(parsedLegs);
        setResult(buildParlayResult(parsedLegs));
      }
    }
  }, []);

  const addLeg = (): void => {
    if (!label.trim() || !oddsInput || !userProbInput) return;

    const oddsValue = parseFloat(oddsInput);
    const userProbValue = parseFloat(userProbInput) / 100;

    if (isNaN(oddsValue) || isNaN(userProbValue) || userProbValue <= 0 || userProbValue > 1) return;

    const decimalOdds = decimalFromLegOdds(oddsFormat, oddsValue);
    const impliedProb = impliedProbabilityFromDecimal(decimalOdds);
    const edgePct = (userProbValue - impliedProb) * 100;

    const newLeg: ParlayLeg = {
      id: Date.now().toString(),
      label: label.trim(),
      oddsFormat,
      oddsInput: oddsValue,
      decimalOdds,
      impliedProb,
      userProb: userProbValue,
      edgePct,
      correlationGroup: correlationGroup.trim() || undefined
    };

    const updatedLegs = [newLeg, ...legs];
    setLegs(updatedLegs);
    setResult(buildParlayResult(updatedLegs));

    setLabel('');
    setOddsInput('');
    setUserProbInput('');
    setCorrelationGroup('');
  };

  const deleteLeg = (id: string): void => {
    const updatedLegs = legs.filter((leg: ParlayLeg) => leg.id !== id);
    setLegs(updatedLegs);
    setResult(updatedLegs.length >= 2 ? buildParlayResult(updatedLegs) : null);
  };

  const clearAll = (): void => {
    setLegs([]);
    setResult(null);
  };

  const loadParlay = (newLegs: ParlayLeg[]): void => {
    setLegs(newLegs);
    setResult(newLegs.length >= 2 ? buildParlayResult(newLegs) : null);
  };

  const formatOdds = (american: number): string => {
    return american > 0 ? `+${american}` : `${american}`;
  };

  const getRiskColor = (risk: string): string => {
    const riskColors: Record<string, string> = {
      'LOW': 'bg-green-500/20 text-green-400 border-green-500/50',
      'MEDIUM': 'bg-amber-500/20 text-amber-400 border-amber-500/50',
      'HIGH': 'bg-red-500/20 text-red-400 border-red-500/50',
      'INSANE': 'bg-pink-500/20 text-pink-400 border-pink-500/50'
    };
    return riskColors[risk] || '';
  };

  const hasCorrelatedLegs = legs.some((leg: ParlayLeg) => leg.correlationGroup);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white p-4 md:p-8 pt-16">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-3 py-6">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-500 bg-clip-text text-transparent">
            Parlay Lab
          </h1>
          <p className="text-slate-200 text-lg font-medium">
            EV Calculator · Edge Finder · Risk Meter · AI Analysis
          </p>
          <p className="text-slate-400 text-sm max-w-2xl mx-auto">
            Build any parlay or same-game parlay with real-time expected value calculations, edge detection, and risk analysis. Make smarter betting decisions.
          </p>
        </div>

        {/* Location Banner */}
        <LocationBanner />

        {/* Quick Presets */}
        <PresetSelector onLoadPreset={loadParlay} />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Add Leg Panel */}
          <Card className="lg:col-span-1 bg-slate-900/50 border-slate-800">
            <CardHeader>
              <CardTitle className="text-cyan-400">Add Leg</CardTitle>
              <CardDescription className="text-slate-300">
                Build your parlay or SGP
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="label" className="text-slate-200 font-medium">Bet Label</Label>
                <Input
                  id="label"
                  placeholder="Lakers -3.5, Over 221.5"
                  value={label}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setLabel(e.target.value)}
                  className="bg-slate-950 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="oddsFormat" className="text-slate-200 font-medium">Odds Format</Label>
                <Select value={oddsFormat} onValueChange={(value: string) => setOddsFormat(value as OddsFormat)}>
                  <SelectTrigger id="oddsFormat" className="bg-slate-950 border-slate-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-900 border-slate-700">
                    <SelectItem value="american" className="text-white">American</SelectItem>
                    <SelectItem value="decimal" className="text-white">Decimal</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="odds" className="text-slate-200 font-medium">
                  Odds {oddsFormat === 'american' ? '(-110, +150)' : '(1.91, 2.50)'}
                </Label>
                <Input
                  id="odds"
                  type="number"
                  step="any"
                  placeholder={oddsFormat === 'american' ? '-110' : '1.91'}
                  value={oddsInput}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setOddsInput(e.target.value)}
                  className="bg-slate-950 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="userProb" className="text-slate-200 font-medium">Your Win Probability (%)</Label>
                <Input
                  id="userProb"
                  type="number"
                  step="0.1"
                  min="0"
                  max="100"
                  placeholder="55.5"
                  value={userProbInput}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setUserProbInput(e.target.value)}
                  className="bg-slate-950 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="correlation" className="text-slate-200 font-medium">
                  Correlation Group <span className="text-slate-400">(optional)</span>
                </Label>
                <Input
                  id="correlation"
                  placeholder="Lakers-Suns, Game1"
                  value={correlationGroup}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCorrelationGroup(e.target.value)}
                  className="bg-slate-950 border-slate-700 text-white placeholder:text-slate-500"
                />
                <p className="text-xs text-slate-400">
                  Same-game legs with matching groups get correlation adjustment
                </p>
              </div>

              <Button
                onClick={addLeg}
                className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-semibold"
              >
                Add Leg to Parlay
              </Button>

              {/* Save/Load/Share */}
              <div className="pt-2">
                <SaveLoadPanel legs={legs} onLoadParlay={loadParlay} />
              </div>
            </CardContent>
          </Card>

          <div className="lg:col-span-2 space-y-6">
            {/* Parlay Summary */}
            {result && legs.length >= 2 && (
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-cyan-400 flex items-center justify-between">
                    <span>Parlay Summary</span>
                    <Badge className={`${getRiskColor(result.riskHeat)} text-lg px-3 py-1 font-bold`}>
                      {result.riskHeat} RISK
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {hasCorrelatedLegs && (
                    <Alert className="bg-cyan-950/30 border-cyan-800/50">
                      <AlertTriangle className="h-4 w-4 text-cyan-300" />
                      <AlertDescription className="text-cyan-200 font-medium">
                        SGP mode active – correlated legs detected (+ probability adjustment)
                      </AlertDescription>
                    </Alert>
                  )}

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="space-y-1">
                      <p className="text-xs text-slate-400 uppercase font-semibold">Parlay Probability</p>
                      <p className="text-2xl font-bold text-white">
                        {(result.combinedProb * 100).toFixed(2)}%
                      </p>
                    </div>

                    <div className="space-y-1">
                      <p className="text-xs text-slate-400 uppercase font-semibold">Fair Odds</p>
                      <p className="text-2xl font-bold text-white">
                        {formatOdds(result.combinedAmerican)}
                      </p>
                      <p className="text-xs text-slate-300 font-medium">{result.combinedDecimal.toFixed(2)}</p>
                    </div>

                    <div className="space-y-1">
                      <p className="text-xs text-slate-400 uppercase font-semibold">Expected Payout</p>
                      <p className="text-2xl font-bold text-white">
                        {result.expectedPayout.toFixed(2)}x
                      </p>
                    </div>

                    <div className="space-y-1">
                      <p className="text-xs text-slate-400 uppercase font-semibold">EV per Unit</p>
                      <p className={`text-2xl font-bold ${result.evPerUnit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {result.evPerUnit >= 0 ? '+' : ''}{result.evPerUnit.toFixed(3)}
                      </p>
                    </div>
                  </div>

                  <Separator className="bg-slate-800" />

                  <div className="space-y-3">
                    <h3 className="text-sm font-semibold text-slate-200 uppercase">Value Analysis</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {result.bestLegId && (
                        <div className="flex items-center gap-2 p-3 rounded-lg bg-green-950/30 border border-green-800/50">
                          <TrendingUp className="h-5 w-5 text-green-400 flex-shrink-0" />
                          <div className="min-w-0">
                            <p className="text-xs text-green-400 font-semibold">BEST LEG</p>
                            <p className="text-sm text-white font-medium truncate">
                              {legs.find((l: ParlayLeg) => l.id === result.bestLegId)?.label}
                            </p>
                          </div>
                        </div>
                      )}

                      {result.worstLegId && (
                        <div className="flex items-center gap-2 p-3 rounded-lg bg-red-950/30 border border-red-800/50">
                          <TrendingDown className="h-5 w-5 text-red-400 flex-shrink-0" />
                          <div className="min-w-0">
                            <p className="text-xs text-red-400 font-semibold">WORST LEG</p>
                            <p className="text-sm text-white font-medium truncate">
                              {legs.find((l: ParlayLeg) => l.id === result.worstLegId)?.label}
                            </p>
                          </div>
                        </div>
                      )}
                    </div>

                    {result.worstLegId && legs.find((l: ParlayLeg) => l.id === result.worstLegId)?.edgePct < -2 && (
                      <Alert className="bg-red-950/30 border-red-800/50">
                        <AlertTriangle className="h-4 w-4 text-red-300" />
                        <AlertDescription className="text-red-200 font-medium">
                          Warning: {legs.find((l: ParlayLeg) => l.id === result.worstLegId)?.label} is dragging down your EV
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* AI Insights */}
            <AIInsightsPanel result={result} legs={legs} />

            {/* Legs Table */}
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-cyan-400">
                    Legs ({legs.length})
                  </CardTitle>
                  {legs.length > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={clearAll}
                      className="text-red-400 hover:text-red-300 hover:bg-red-950/30 font-semibold"
                    >
                      Clear All
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {legs.length === 0 ? (
                  <div className="text-center py-12 text-slate-400">
                    <p className="text-lg font-medium">No legs added yet</p>
                    <p className="text-sm mt-2">Add at least 2 legs to build a parlay</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-slate-800 hover:bg-transparent">
                          <TableHead className="text-slate-300 font-semibold">Leg</TableHead>
                          <TableHead className="text-slate-300 font-semibold">Odds</TableHead>
                          <TableHead className="text-slate-300 font-semibold">Implied</TableHead>
                          <TableHead className="text-slate-300 font-semibold">Your Prob</TableHead>
                          <TableHead className="text-slate-300 font-semibold">Edge</TableHead>
                          <TableHead className="text-slate-300 font-semibold">SGP Group</TableHead>
                          <TableHead className="text-slate-300 font-semibold"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {legs.map((leg: ParlayLeg) => {
                          const isBest = result?.bestLegId === leg.id;
                          const isWorst = result?.worstLegId === leg.id;
                          const rowClass = isBest
                            ? 'bg-green-950/20 border-l-2 border-green-500'
                            : isWorst
                            ? 'bg-red-950/20 border-l-2 border-red-500'
                            : '';

                          return (
                            <TableRow key={leg.id} className={`border-slate-800 ${rowClass}`}>
                              <TableCell className="font-medium text-white">{leg.label}</TableCell>
                              <TableCell className="text-slate-200 font-medium">{leg.decimalOdds.toFixed(2)}</TableCell>
                              <TableCell className="text-slate-200 font-medium">
                                {(leg.impliedProb * 100).toFixed(1)}%
                              </TableCell>
                              <TableCell className="text-slate-200 font-medium">
                                {(leg.userProb * 100).toFixed(1)}%
                              </TableCell>
                              <TableCell>
                                <Badge
                                  className={
                                    leg.edgePct >= 0
                                      ? 'bg-green-500/20 text-green-400 border-green-500/50 font-bold'
                                      : 'bg-red-500/20 text-red-400 border-red-500/50 font-bold'
                                  }
                                >
                                  {leg.edgePct >= 0 ? '+' : ''}{leg.edgePct.toFixed(2)}%
                                </Badge>
                              </TableCell>
                              <TableCell className="text-slate-300 text-sm font-medium">
                                {leg.correlationGroup || '-'}
                              </TableCell>
                              <TableCell>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => deleteLeg(leg.id)}
                                  className="text-red-400 hover:text-red-300 hover:bg-red-950/30"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      <Toaster />
    </div>
  );
}
