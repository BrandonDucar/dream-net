'use client'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Lightbulb, AlertTriangle, TrendingUp } from 'lucide-react';
import { generateAIInsights, getBettingTip, type AIInsight } from '@/lib/ai-analysis';
import type { ParlayResult, ParlayLeg } from '@/lib/parlay';

type AIInsightsPanelProps = {
  result: ParlayResult | null;
  legs: ParlayLeg[];
};

export function AIInsightsPanel({ result, legs }: AIInsightsPanelProps): JSX.Element {
  const insights = generateAIInsights(result, legs);
  const tip = getBettingTip(legs.length);

  const getIcon = (type: string): JSX.Element => {
    switch (type) {
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-amber-400" />;
      case 'positive':
        return <TrendingUp className="h-4 w-4 text-green-400" />;
      default:
        return <Lightbulb className="h-4 w-4 text-cyan-400" />;
    }
  };

  const getColors = (type: string): string => {
    switch (type) {
      case 'warning':
        return 'bg-amber-950/30 border-amber-800/50 text-amber-300';
      case 'positive':
        return 'bg-green-950/30 border-green-800/50 text-green-300';
      default:
        return 'bg-cyan-950/30 border-cyan-800/50 text-cyan-300';
    }
  };

  return (
    <Card className="bg-slate-900/50 border-slate-800">
      <CardHeader>
        <CardTitle className="text-cyan-400 flex items-center gap-2">
          <Lightbulb className="h-5 w-5" />
          AI Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* General betting tip */}
        <Alert className="bg-slate-800/50 border-slate-700">
          <Lightbulb className="h-4 w-4 text-slate-400" />
          <AlertDescription className="text-slate-300">
            {tip}
          </AlertDescription>
        </Alert>

        {/* AI-generated insights */}
        {insights.length > 0 && (
          <div className="space-y-2">
            {insights.map((insight: AIInsight, idx: number) => (
              <Alert key={idx} className={getColors(insight.type)}>
                {getIcon(insight.type)}
                <div>
                  <AlertTitle className="font-semibold text-white">{insight.title}</AlertTitle>
                  <AlertDescription className="mt-1 text-sm">
                    {insight.message}
                  </AlertDescription>
                </div>
              </Alert>
            ))}
          </div>
        )}

        {insights.length === 0 && legs.length >= 2 && (
          <p className="text-sm text-slate-400 text-center py-4">
            No specific insights for this parlay yet. Keep refining your edges!
          </p>
        )}
      </CardContent>
    </Card>
  );
}
