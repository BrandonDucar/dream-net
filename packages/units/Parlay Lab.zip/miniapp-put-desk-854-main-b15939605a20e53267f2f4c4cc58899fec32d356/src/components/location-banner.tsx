'use client'
import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { MapPin, CheckCircle, XCircle } from 'lucide-react';
import { getUserLocation, type LocationData } from '@/lib/geolocation';

export function LocationBanner(): JSX.Element {
  const [location, setLocation] = useState<LocationData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const loadLocation = async (): Promise<void> => {
      const data = await getUserLocation();
      setLocation(data);
      setLoading(false);
    };

    loadLocation();
  }, []);

  if (loading) {
    return (
      <Card className="bg-slate-900/50 border-slate-800">
        <CardContent className="py-3">
          <div className="flex items-center gap-2 text-slate-400">
            <MapPin className="h-4 w-4" />
            <span className="text-sm">Detecting your location...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!location) return <></>;

  return (
    <Card className="bg-slate-900/50 border-slate-800">
      <CardContent className="py-3">
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-cyan-400" />
            <span className="text-white font-medium">
              {location.city ? `${location.city}, ` : ''}{location.region || location.country || 'Unknown'}
            </span>
          </div>

          {location.isLegalBetting ? (
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-400" />
              <span className="text-green-400 text-sm font-medium">Legal Betting Available</span>
              {location.legalSportsbooks.length > 0 && (
                <span className="text-slate-400 text-sm">
                  ({location.legalSportsbooks.slice(0, 3).join(', ')})
                </span>
              )}
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <XCircle className="h-4 w-4 text-amber-400" />
              <span className="text-amber-400 text-sm font-medium">No Legal Sportsbooks</span>
              {location.offshoreOptions.length > 0 && (
                <span className="text-slate-400 text-sm">
                  Offshore: {location.offshoreOptions.slice(0, 2).join(', ')}
                </span>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
