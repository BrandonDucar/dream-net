'use client'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Zap } from 'lucide-react';
import { PARLAY_PRESETS, type BetPreset } from '@/lib/presets';
import type { ParlayLeg } from '@/lib/parlay';
import { decimalFromLegOdds, impliedProbabilityFromDecimal } from '@/lib/parlay';
import { useToast } from '@/hooks/use-toast';

type PresetSelectorProps = {
  onLoadPreset: (legs: ParlayLeg[]) => void;
};

export function PresetSelector({ onLoadPreset }: PresetSelectorProps): JSX.Element {
  const { toast } = useToast();

  const handleLoadPreset = (preset: BetPreset): void => {
    const legs: ParlayLeg[] = preset.legs.map((leg, idx) => {
      const decimalOdds = decimalFromLegOdds(leg.oddsFormat, leg.oddsInput);
      const impliedProb = impliedProbabilityFromDecimal(decimalOdds);
      const edgePct = (leg.userProb - impliedProb) * 100;

      return {
        id: `preset-${Date.now()}-${idx}`,
        label: leg.label,
        oddsFormat: leg.oddsFormat,
        oddsInput: leg.oddsInput,
        decimalOdds,
        impliedProb,
        userProb: leg.userProb,
        edgePct,
        correlationGroup: leg.correlationGroup
      };
    });

    onLoadPreset(legs);

    toast({
      title: "Preset Loaded!",
      description: `Loaded "${preset.name}" with ${legs.length} legs.`
    });
  };

  return (
    <Card className="bg-slate-900/50 border-slate-800">
      <CardHeader>
        <CardTitle className="text-cyan-400 flex items-center gap-2">
          <Zap className="h-5 w-5" />
          Quick Presets
        </CardTitle>
        <CardDescription className="text-slate-400">
          Load sample parlays to test the analyzer
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {PARLAY_PRESETS.map((preset: BetPreset) => (
            <Button
              key={preset.id}
              variant="outline"
              className="h-auto flex-col items-start gap-1 p-3 bg-slate-800 border-slate-700 text-left hover:bg-slate-700 hover:border-cyan-600"
              onClick={() => handleLoadPreset(preset)}
            >
              <span className="font-semibold text-white">{preset.name}</span>
              <span className="text-xs text-slate-400">{preset.description}</span>
              <span className="text-xs text-cyan-400">{preset.legs.length} legs</span>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
