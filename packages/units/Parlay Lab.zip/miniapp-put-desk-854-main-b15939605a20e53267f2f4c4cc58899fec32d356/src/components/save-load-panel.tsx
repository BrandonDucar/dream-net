'use client'
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Save, FolderOpen, Trash2, Share2, Copy } from 'lucide-react';
import { saveParlay, getSavedParlays, deleteParlay, generateShareableLink, type SavedParlay } from '@/lib/storage';
import type { ParlayLeg } from '@/lib/parlay';
import { useToast } from '@/hooks/use-toast';

type SaveLoadPanelProps = {
  legs: ParlayLeg[];
  onLoadParlay: (legs: ParlayLeg[]) => void;
};

export function SaveLoadPanel({ legs, onLoadParlay }: SaveLoadPanelProps): JSX.Element {
  const [savedParlays, setSavedParlays] = useState<SavedParlay[]>([]);
  const [parlayName, setParlayName] = useState<string>('');
  const [saveDialogOpen, setSaveDialogOpen] = useState<boolean>(false);
  const [loadDialogOpen, setLoadDialogOpen] = useState<boolean>(false);
  const { toast } = useToast();

  useEffect(() => {
    loadSavedParlays();
  }, []);

  const loadSavedParlays = (): void => {
    setSavedParlays(getSavedParlays());
  };

  const handleSave = (): void => {
    if (!parlayName.trim() || legs.length < 2) {
      toast({
        title: "Cannot Save",
        description: "Please name your parlay and add at least 2 legs.",
        variant: "destructive"
      });
      return;
    }

    saveParlay(parlayName.trim(), legs);
    setParlayName('');
    setSaveDialogOpen(false);
    loadSavedParlays();

    toast({
      title: "Parlay Saved!",
      description: `"${parlayName}" has been saved successfully.`
    });
  };

  const handleLoad = (parlay: SavedParlay): void => {
    onLoadParlay(parlay.legs);
    setLoadDialogOpen(false);

    toast({
      title: "Parlay Loaded",
      description: `Loaded "${parlay.name}" with ${parlay.legs.length} legs.`
    });
  };

  const handleDelete = (id: string, name: string): void => {
    deleteParlay(id);
    loadSavedParlays();

    toast({
      title: "Parlay Deleted",
      description: `"${name}" has been removed.`,
      variant: "destructive"
    });
  };

  const handleShare = (): void => {
    if (legs.length < 2) {
      toast({
        title: "Cannot Share",
        description: "Add at least 2 legs to share your parlay.",
        variant: "destructive"
      });
      return;
    }

    const link = generateShareableLink(legs);
    navigator.clipboard.writeText(link);

    toast({
      title: "Link Copied!",
      description: "Shareable parlay link copied to clipboard."
    });
  };

  return (
    <div className="flex flex-wrap gap-2">
      {/* Save Button */}
      <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
        <DialogTrigger asChild>
          <Button
            variant="outline"
            size="sm"
            disabled={legs.length < 2}
            className="bg-slate-800 border-slate-700 text-white hover:bg-slate-700 hover:text-white"
          >
            <Save className="h-4 w-4 mr-2" />
            Save Parlay
          </Button>
        </DialogTrigger>
        <DialogContent className="bg-slate-900 border-slate-800">
          <DialogHeader>
            <DialogTitle className="text-white">Save Your Parlay</DialogTitle>
            <DialogDescription className="text-slate-400">
              Give your parlay a name to save it for later.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="parlay-name" className="text-slate-300">Parlay Name</Label>
              <Input
                id="parlay-name"
                placeholder="My 3-Leg NBA Parlay"
                value={parlayName}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setParlayName(e.target.value)}
                className="bg-slate-950 border-slate-700 text-white"
              />
            </div>
            <Button onClick={handleSave} className="w-full bg-cyan-600 hover:bg-cyan-700 text-white">
              Save
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Load Button */}
      <Dialog open={loadDialogOpen} onOpenChange={setLoadDialogOpen}>
        <DialogTrigger asChild>
          <Button
            variant="outline"
            size="sm"
            className="bg-slate-800 border-slate-700 text-white hover:bg-slate-700 hover:text-white"
          >
            <FolderOpen className="h-4 w-4 mr-2" />
            Load Parlay
          </Button>
        </DialogTrigger>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">Load Saved Parlay</DialogTitle>
            <DialogDescription className="text-slate-400">
              Choose a previously saved parlay to load.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {savedParlays.length === 0 ? (
              <p className="text-center text-slate-500 py-8">No saved parlays yet</p>
            ) : (
              savedParlays.map((parlay: SavedParlay) => (
                <Card key={parlay.id} className="bg-slate-800/50 border-slate-700">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h4 className="font-semibold text-white">{parlay.name}</h4>
                        <p className="text-sm text-slate-400">
                          {parlay.legs.length} legs · {new Date(parlay.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleLoad(parlay)}
                          className="bg-cyan-600 hover:bg-cyan-700 text-white"
                        >
                          Load
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDelete(parlay.id, parlay.name)}
                          className="text-red-400 hover:text-red-300 hover:bg-red-950/30"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Share Button */}
      <Button
        variant="outline"
        size="sm"
        onClick={handleShare}
        disabled={legs.length < 2}
        className="bg-slate-800 border-slate-700 text-white hover:bg-slate-700 hover:text-white"
      >
        <Share2 className="h-4 w-4 mr-2" />
        Share
      </Button>
    </div>
  );
}
