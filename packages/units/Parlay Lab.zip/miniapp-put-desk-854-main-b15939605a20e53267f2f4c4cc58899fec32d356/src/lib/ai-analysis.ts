import type { ParlayLeg, ParlayResult } from './parlay';

export type AIInsight = {
  type: 'warning' | 'tip' | 'positive';
  title: string;
  message: string;
};

export function generateAIInsights(result: ParlayResult | null, legs: ParlayLeg[]): AIInsight[] {
  if (!result || legs.length < 2) return [];

  const insights: AIInsight[] = [];

  // Check for too many legs
  if (legs.length >= 5) {
    insights.push({
      type: 'warning',
      title: 'High Leg Count',
      message: `${legs.length}-leg parlays have exponentially lower hit rates. Consider breaking into smaller parlays for better variance control.`
    });
  }

  // Check if all legs have negative edge
  const allNegativeEdge = legs.every((leg: ParlayLeg) => leg.edgePct < 0);
  if (allNegativeEdge) {
    insights.push({
      type: 'warning',
      title: 'No Positive Edge',
      message: 'Every leg in your parlay has negative expected value. This parlay is -EV overall. Consider finding better lines or removing legs.'
    });
  }

  // Check if EV is positive
  if (result.evPerUnit > 0.05) {
    insights.push({
      type: 'positive',
      title: 'Positive EV Detected',
      message: `This parlay shows +${(result.evPerUnit * 100).toFixed(2)}% edge! Your probability assessments suggest long-term profitability.`
    });
  }

  // Check for extreme risk
  if (result.riskHeat === 'INSANE' && result.combinedProb < 0.05) {
    insights.push({
      type: 'warning',
      title: 'Lottery Ticket Territory',
      message: `${(result.combinedProb * 100).toFixed(2)}% hit probability. This is a high-variance lotto play. Size your stake accordingly.`
    });
  }

  // Check for heavy favorite parlays
  const allHeavyFavorites = legs.every((leg: ParlayLeg) => leg.impliedProb > 0.70);
  if (allHeavyFavorites && legs.length >= 3) {
    insights.push({
      type: 'tip',
      title: 'Heavy Favorite Parlay',
      message: 'Parlaying heavy favorites compounds small edges. One upset ruins the ticket. Consider straight bets or smaller parlays.'
    });
  }

  // Check for correlated legs without correlation tag
  const hasCorrelationTags = legs.some((leg: ParlayLeg) => leg.correlationGroup);
  if (!hasCorrelationTags && legs.length >= 2) {
    const labels = legs.map((leg: ParlayLeg) => leg.label.toLowerCase());
    const possibleCorrelation = labels.some((label: string, idx: number) => 
      labels.slice(idx + 1).some((other: string) => 
        label.split(' ')[0] === other.split(' ')[0] // same team/game
      )
    );

    if (possibleCorrelation) {
      insights.push({
        type: 'tip',
        title: 'Potential Correlation',
        message: 'Your legs might be from the same game. Tag them with a correlation group for more accurate SGP probability modeling.'
      });
    }
  }

  // Check for single bad leg dragging down parlay
  if (result.worstLegId) {
    const worstLeg = legs.find((leg: ParlayLeg) => leg.id === result.worstLegId);
    if (worstLeg && worstLeg.edgePct < -5) {
      insights.push({
        type: 'warning',
        title: 'Value Destroyer Detected',
        message: `"${worstLeg.label}" has ${worstLeg.edgePct.toFixed(1)}% edge. Removing this leg would significantly improve your parlay's EV.`
      });
    }
  }

  // Positive reinforcement for smart plays
  if (result.evPerUnit > 0 && legs.length === 2 && result.riskHeat === 'LOW') {
    insights.push({
      type: 'positive',
      title: 'Smart 2-Leg Construction',
      message: '2-leg parlays with positive edges offer great risk/reward balance. This is a sharp play.'
    });
  }

  return insights;
}

export function getBettingTip(legsCount: number): string {
  const tips: Record<number, string> = {
    0: "Pro tip: The house edge compounds in parlays. Find lines with positive expected value for each leg.",
    1: "Remember: You need at least 2 legs to build a parlay. Keep adding!",
    2: "2-leg parlays are the sharpest — they balance risk and variance better than longer parlays.",
    3: "3-leg parlays start getting risky. Make sure each leg has strong edge to justify the variance.",
    4: "4+ leg parlays are high variance. One loss kills the ticket. Size your stakes accordingly.",
    5: "With 5+ legs, you're building a lottery ticket. These are entertainment plays, not profit engines."
  };

  if (legsCount > 5) return tips[5];
  return tips[legsCount] || tips[0];
}
