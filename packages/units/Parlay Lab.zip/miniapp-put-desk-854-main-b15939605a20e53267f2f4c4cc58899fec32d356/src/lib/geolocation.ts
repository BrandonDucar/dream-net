export type LocationData = {
  country: string | null;
  region: string | null;
  city: string | null;
  isLegalBetting: boolean;
  legalSportsbooks: string[];
  offshoreOptions: string[];
};

// US states where sports betting is legal
const LEGAL_US_STATES = [
  'Arizona', 'Arkansas', 'Colorado', 'Connecticut', 'Delaware', 'Illinois',
  'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland',
  'Massachusetts', 'Michigan', 'Mississippi', 'Montana', 'Nebraska', 'Nevada',
  'New Hampshire', 'New Jersey', 'New Mexico', 'New York', 'North Carolina',
  'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island',
  'South Dakota', 'Tennessee', 'Vermont', 'Virginia', 'Washington', 'West Virginia',
  'Wisconsin', 'Wyoming', 'District of Columbia'
];

// Legal sportsbooks by state (top ones)
const STATE_SPORTSBOOKS: Record<string, string[]> = {
  'default': ['DraftKings', 'FanDuel', 'BetMGM', 'Caesars', 'BetRivers']
};

// Offshore options for non-legal jurisdictions
const OFFSHORE_OPTIONS = [
  'Bovada', 'BetOnline', 'MyBookie', 'Heritage Sports', 'SportsBetting.ag'
];

export async function getUserLocation(): Promise<LocationData> {
  try {
    // Use ipapi.co for geolocation (free tier, no API key needed)
    const response = await fetch('https://ipapi.co/json/');
    if (!response.ok) {
      throw new Error('Geolocation failed');
    }

    const data = await response.json() as {
      country_name?: string;
      region?: string;
      city?: string;
    };

    const country = data.country_name || null;
    const region = data.region || null;
    const city = data.city || null;

    // Check if betting is legal
    const isLegalBetting = country === 'United States' && region
      ? LEGAL_US_STATES.includes(region)
      : false;

    const legalSportsbooks = isLegalBetting ? STATE_SPORTSBOOKS['default'] : [];
    const offshoreOptions = !isLegalBetting ? OFFSHORE_OPTIONS : [];

    return {
      country,
      region,
      city,
      isLegalBetting,
      legalSportsbooks,
      offshoreOptions
    };
  } catch (error) {
    console.error('Geolocation error:', error);
    return {
      country: null,
      region: null,
      city: null,
      isLegalBetting: false,
      legalSportsbooks: [],
      offshoreOptions: OFFSHORE_OPTIONS
    };
  }
}
