export type OddsFormat = "american" | "decimal";

export type ParlayLeg = {
  id: string;
  label: string;
  oddsFormat: OddsFormat;
  oddsInput: number;
  decimalOdds: number;
  impliedProb: number;
  userProb: number;
  edgePct: number;
  correlationGroup?: string;
};

export type ParlayResult = {
  legs: ParlayLeg[];
  combinedProb: number;
  combinedDecimal: number;
  combinedAmerican: number;
  expectedPayout: number;
  evPerUnit: number;
  worstLegId: string | null;
  bestLegId: string | null;
  riskHeat: "LOW" | "MEDIUM" | "HIGH" | "INSANE";
};

export function americanToDecimal(american: number): number {
  if (american > 0) return 1 + american / 100;
  return 1 + 100 / Math.abs(american);
}

export function impliedProbabilityFromDecimal(decimal: number): number {
  return 1 / decimal;
}

export function impliedProbabilityFromAmerican(american: number): number {
  return impliedProbabilityFromDecimal(americanToDecimal(american));
}

export function decimalFromLegOdds(format: OddsFormat, oddsInput: number): number {
  return format === "american" ? americanToDecimal(oddsInput) : oddsInput;
}

export function decimalToAmerican(decimal: number): number {
  if (decimal <= 1) return 0;
  const p = 1 / decimal;
  if (p > 0.5) {
    const num = -(p / (1 - p)) * 100;
    return Math.round(num);
  }
  const num = ((1 - p) / p) * 100;
  return Math.round(num);
}

export function combinedProbability(legs: ParlayLeg[]): number {
  return legs.reduce((acc: number, leg: ParlayLeg) => acc * leg.userProb, 1);
}

export function applyCorrelation(legs: ParlayLeg[], baseProb: number): number {
  const groups = new Map<string, number>();
  for (const leg of legs) {
    if (leg.correlationGroup) {
      const prev = groups.get(leg.correlationGroup) || 0;
      groups.set(leg.correlationGroup, prev + 1);
    }
  }

  let adj = baseProb;

  for (const [group, count] of groups.entries()) {
    if (count >= 2) {
      const boost = 1 + count * 0.05;
      adj = adj * boost;
    }
  }

  return Math.min(adj, 0.9999);
}

export function combinedDecimalOdds(legs: ParlayLeg[]): number {
  return legs.reduce((acc: number, leg: ParlayLeg) => acc * leg.decimalOdds, 1);
}

export function expectedValue(combinedProb: number, combinedDecimal: number): number {
  const winPayout = combinedDecimal - 1;
  const loseProb = 1 - combinedProb;
  return combinedProb * winPayout - loseProb;
}

export function findValueLegs(legs: ParlayLeg[]): { best: string | null; worst: string | null } {
  if (legs.length === 0) return { best: null, worst: null };
  let best = legs[0];
  let worst = legs[0];
  for (const leg of legs) {
    if (leg.edgePct > best.edgePct) best = leg;
    if (leg.edgePct < worst.edgePct) worst = leg;
  }
  return { best: best.id, worst: worst.id };
}

export function classifyRisk(combinedProb: number, legsCount: number): "LOW" | "MEDIUM" | "HIGH" | "INSANE" {
  if (combinedProb > 0.35) return "LOW";
  if (combinedProb > 0.20) return "MEDIUM";
  if (combinedProb > 0.10) return "HIGH";
  return "INSANE";
}

export function buildParlayResult(legs: ParlayLeg[]): ParlayResult | null {
  if (legs.length === 0) return null;

  const baseProb = combinedProbability(legs);
  const adjProb = applyCorrelation(legs, baseProb);
  const dec = combinedDecimalOdds(legs);
  const american = decimalToAmerican(dec);

  const ev = expectedValue(adjProb, dec);
  const { best, worst } = findValueLegs(legs);
  const risk = classifyRisk(adjProb, legs.length);

  return {
    legs,
    combinedProb: adjProb,
    combinedDecimal: dec,
    combinedAmerican: american,
    expectedPayout: dec - 1,
    evPerUnit: ev,
    bestLegId: best,
    worstLegId: worst,
    riskHeat: risk
  };
}
