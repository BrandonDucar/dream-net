export type BetPreset = {
  id: string;
  name: string;
  description: string;
  legs: Array<{
    label: string;
    oddsFormat: 'american' | 'decimal';
    oddsInput: number;
    userProb: number;
    correlationGroup?: string;
  }>;
};

export const PARLAY_PRESETS: BetPreset[] = [
  {
    id: 'nfl-2leg-favorites',
    name: 'NFL 2-Leg Favorites',
    description: 'Two home favorites on the moneyline',
    legs: [
      { label: 'Chiefs ML', oddsFormat: 'american', oddsInput: -180, userProb: 0.68 },
      { label: 'Bills ML', oddsFormat: 'american', oddsInput: -200, userProb: 0.70 }
    ]
  },
  {
    id: 'nba-3leg-totals',
    name: 'NBA 3-Leg Totals',
    description: 'Three over bets in high-scoring games',
    legs: [
      { label: 'Warriors @ Suns Over 230.5', oddsFormat: 'american', oddsInput: -110, userProb: 0.55 },
      { label: 'Nets @ Hawks Over 225.5', oddsFormat: 'american', oddsInput: -110, userProb: 0.53 },
      { label: 'Mavs @ Kings Over 233.5', oddsFormat: 'american', oddsInput: -115, userProb: 0.56 }
    ]
  },
  {
    id: 'sgp-nfl',
    name: 'NFL Same-Game Parlay',
    description: 'Correlated legs from one game',
    legs: [
      { label: 'Mahomes Over 270.5 Pass Yards', oddsFormat: 'american', oddsInput: -115, userProb: 0.58, correlationGroup: 'KC-LAC' },
      { label: 'Chiefs -3.5', oddsFormat: 'american', oddsInput: -110, userProb: 0.54, correlationGroup: 'KC-LAC' },
      { label: 'Kelce Over 65.5 Rec Yards', oddsFormat: 'american', oddsInput: -110, userProb: 0.52, correlationGroup: 'KC-LAC' }
    ]
  },
  {
    id: 'underdog-parlay',
    name: 'Underdog 3-Leg Parlay',
    description: 'High-risk, high-reward underdog plays',
    legs: [
      { label: 'Dolphins +7.5', oddsFormat: 'american', oddsInput: +180, userProb: 0.40 },
      { label: 'Texans ML', oddsFormat: 'american', oddsInput: +220, userProb: 0.35 },
      { label: 'Panthers +10.5', oddsFormat: 'american', oddsInput: +150, userProb: 0.45 }
    ]
  },
  {
    id: 'player-props-sgp',
    name: 'NBA Player Props SGP',
    description: 'Same-game player prop parlay',
    legs: [
      { label: 'LeBron Over 25.5 Points', oddsFormat: 'american', oddsInput: -115, userProb: 0.60, correlationGroup: 'LAL-DEN' },
      { label: 'AD Over 11.5 Rebounds', oddsFormat: 'american', oddsInput: -110, userProb: 0.57, correlationGroup: 'LAL-DEN' },
      { label: 'Lakers ML', oddsFormat: 'american', oddsInput: -150, userProb: 0.62, correlationGroup: 'LAL-DEN' }
    ]
  },
  {
    id: 'safe-2leg',
    name: 'Conservative 2-Leg',
    description: 'Low-risk favorites with small edges',
    legs: [
      { label: 'Celtics -5.5', oddsFormat: 'american', oddsInput: -110, userProb: 0.57 },
      { label: '76ers ML', oddsFormat: 'american', oddsInput: -170, userProb: 0.66 }
    ]
  }
];

export function getPresetById(id: string): BetPreset | null {
  return PARLAY_PRESETS.find((preset: BetPreset) => preset.id === id) || null;
}
