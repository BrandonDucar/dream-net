import type { ParlayLeg } from './parlay';

const STORAGE_KEY = 'parlay-analyzer-saved';

export type SavedParlay = {
  id: string;
  name: string;
  legs: ParlayLeg[];
  createdAt: number;
};

export function saveParlay(name: string, legs: ParlayLeg[]): SavedParlay {
  const savedParlay: SavedParlay = {
    id: Date.now().toString(),
    name,
    legs,
    createdAt: Date.now()
  };

  const existing = getSavedParlays();
  const updated = [savedParlay, ...existing].slice(0, 10); // Keep last 10
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));

  return savedParlay;
}

export function getSavedParlays(): SavedParlay[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (!data) return [];
    return JSON.parse(data) as SavedParlay[];
  } catch (error) {
    console.error('Error loading saved parlays:', error);
    return [];
  }
}

export function deleteParlay(id: string): void {
  const existing = getSavedParlays();
  const updated = existing.filter((p: SavedParlay) => p.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
}

export function generateShareableLink(legs: ParlayLeg[]): string {
  const compressed = legs.map((leg: ParlayLeg) => ({
    l: leg.label,
    o: leg.oddsInput,
    f: leg.oddsFormat === 'american' ? 'a' : 'd',
    p: leg.userProb,
    c: leg.correlationGroup || ''
  }));

  const encoded = btoa(JSON.stringify(compressed));
  return `${window.location.origin}?parlay=${encoded}`;
}

export function parseParlayFromURL(encoded: string): ParlayLeg[] | null {
  try {
    const decoded = atob(encoded);
    const compressed = JSON.parse(decoded) as Array<{
      l: string;
      o: number;
      f: string;
      p: number;
      c?: string;
    }>;

    return compressed.map((item, idx) => {
      const oddsFormat = item.f === 'a' ? 'american' : 'decimal';
      const decimalOdds = oddsFormat === 'american' 
        ? (item.o > 0 ? 1 + item.o / 100 : 1 + 100 / Math.abs(item.o))
        : item.o;
      const impliedProb = 1 / decimalOdds;
      const edgePct = (item.p - impliedProb) * 100;

      return {
        id: `shared-${Date.now()}-${idx}`,
        label: item.l,
        oddsFormat,
        oddsInput: item.o,
        decimalOdds,
        impliedProb,
        userProb: item.p,
        edgePct,
        correlationGroup: item.c || undefined
      };
    });
  } catch (error) {
    console.error('Error parsing parlay from URL:', error);
    return null;
  }
}
