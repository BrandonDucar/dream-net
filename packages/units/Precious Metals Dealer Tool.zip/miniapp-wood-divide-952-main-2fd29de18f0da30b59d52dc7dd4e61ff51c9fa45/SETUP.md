# Melt & Spread Engine - Setup Guide

## 🚀 Live Spot Pricing Setup

Your Melt & Spread Engine is now equipped with **real live precious metals pricing** powered by metals-api.com!

### Quick Setup (Free Tier)

1. **Get Your Free API Key**
   - Visit [metals-api.com](https://metals-api.com)
   - Sign up for a free account
   - No credit card required!
   - Free tier includes:
     - ✅ 100 requests per month
     - ✅ Live spot prices updated every 60 seconds
     - ✅ Gold, Silver, Platinum, Palladium
     - ✅ 150+ currencies supported

2. **Set Environment Variable**
   
   Add your API key to the environment variables:
   ```
   METALS_API_KEY=your_api_key_here
   ```

3. **That's it!** 🎉
   
   Your app will now pull live spot prices automatically.

---

## 🎯 Features Included

### ⚡ Live Pricing
- **Auto-refresh toggle** - Updates prices every 60 seconds automatically
- **Manual refresh** - One-click update anytime
- **Real-time calculations** - Melt values update instantly with spot prices

### 📊 Price Charts
- **24-hour trend visualization** for all metals
- **Price change indicators** - See gains/losses at a glance
- **Color-coded performance** - Green for up, red for down

### 🎨 Quick Presets
Pre-configured templates for common items:
- 🦅 Gold Eagles (1oz, .9167 purity)
- 🍁 Gold/Silver Maples (1oz, .9999 purity)
- 🦬 Gold Buffalo (1oz, .9999 purity)
- 💰 Junk Silver ($1 face, 90%)
- 📊 Silver/Gold Bars (10oz, 100oz, 1kg)
- And more!

### 📋 Quote Management
- **Duplicate quotes** - Click clipboard icon to reprice existing items
- **CSV export** - Download all quotes for records
- **Color-coded spreads**:
  - 🔴 <1% - Too Tight (risky)
  - 🟡 1-3% - Thin Margin
  - 🟢 3-10% - Good Deal
  - 🔵 >10% - Wide Spread
- **Premium alerts** - High premiums over melt highlighted

### 💰 Calculations
For every quote, see:
- **Melt Value** - Pure metal content value
- **Buy/Sell Prices** - Your dealer pricing
- **Spread %** - Profit margin percentage
- **Margin** - Dollar profit per unit
- **Buy/Sell over Melt %** - Premium/discount vs spot

---

## 🔧 Alternative API Setup

If you have your own metals pricing API:

```env
SPOT_API_URL=https://your-api.com/endpoint
SPOT_API_KEY=your_custom_key
```

The app will use your custom API and fall back to metals-api.com if needed.

---

## 📱 Usage Tips

1. **Enable Auto-Refresh** during active trading sessions
2. **Use Quick Presets** to speed up common quotes
3. **Duplicate & Reprice** when market moves - click the clipboard icon
4. **Watch the Spread Colors** for instant deal quality feedback
5. **Export to CSV** at end of day for record-keeping
6. **Toggle Charts** to see price momentum before quoting

---

## 🎓 Spread Guide

| Spread % | Status | Meaning |
|----------|--------|---------|
| <1% 🔴 | Too Tight | Low margin, high risk |
| 1-3% 🟡 | Thin | Acceptable but watch costs |
| 3-10% 🟢 | Good | Healthy dealer margin |
| >10% 🔵 | Wide | High premium (specialty items) |

---

## 💎 Supported Metals

- **🥇 Gold (AU)** - Live spot pricing
- **🥈 Silver (AG)** - Live spot pricing
- **⚪ Platinum (PT)** - Live spot pricing
- **🔵 Palladium (PD)** - Live spot pricing
- **🟣 Rhodium (RH)** - Estimated (check provider)

---

## 🆘 Troubleshooting

**"METALS_API_KEY not configured"**
- You need to set the environment variable with your API key

**"Failed to fetch spot prices"**
- Check your API key is correct
- Verify you haven't exceeded free tier limit (100/month)
- Try manual refresh

**Rhodium price seems off**
- Free tier may use estimated rhodium prices
- Upgrade to premium API tier for rhodium spot data

---

## 🚀 Going Live

1. Set `METALS_API_KEY` in your hosting environment
2. Test the refresh button
3. Enable auto-refresh for live trading
4. You're ready to quote! 🎯

---

**Built for speed. Optimized for the counter. Ready for the show floor.** ⚡💰
