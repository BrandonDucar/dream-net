import { NextRequest, NextResponse } from "next/server";

export async function GET(_req: NextRequest) {
  // Use metals-api.com as the primary spot price source
  // Free tier: 100 requests/month, updated every 60 seconds
  const apiKey = process.env.METALS_API_KEY || process.env.SPOT_API_KEY;
  const customApiUrl = process.env.SPOT_API_URL;

  // If custom API URL is provided, use that instead
  if (customApiUrl) {
    try {
      const headers: Record<string, string> = {};
      if (apiKey) {
        headers["Authorization"] = `Bearer ${apiKey}`;
      }

      const res = await fetch(customApiUrl, { headers });

      if (!res.ok) {
        throw new Error("Custom API failed");
      }

      const raw = await res.json();

      const data = {
        gold: raw.gold_oz ?? raw.XAU ?? raw.data?.XAU ?? raw.gold ?? 0,
        silver: raw.silver_oz ?? raw.XAG ?? raw.data?.XAG ?? raw.silver ?? 0,
        platinum: raw.platinum_oz ?? raw.XPT ?? raw.data?.XPT ?? raw.platinum ?? 0,
        palladium: raw.palladium_oz ?? raw.XPD ?? raw.data?.XPD ?? raw.palladium ?? 0,
        rhodium: raw.rhodium_oz ?? raw.RH ?? raw.data?.RH ?? raw.rhodium ?? 0,
        currency: raw.currency ?? "USD",
        timestamp: raw.timestamp ?? Date.now()
      };

      return NextResponse.json(data);
    } catch (error) {
      console.error("Custom API error, falling back to default:", error);
    }
  }

  // Use metals-api.com as default
  try {
    if (!apiKey) {
      return NextResponse.json(
        { 
          error: "Please set METALS_API_KEY environment variable. Get free API key at https://metals-api.com",
          hint: "Free tier: 100 requests/month with live spot prices for gold, silver, platinum, palladium"
        },
        { status: 500 }
      );
    }

    // Metals-API.com format: https://metals-api.com/api/latest?access_key=YOUR_KEY&base=USD&symbols=XAU,XAG,XPT,XPD
    const metalsApiUrl = `https://metals-api.com/api/latest?access_key=${apiKey}&base=USD&symbols=XAU,XAG,XPT,XPD`;
    
    const res = await fetch(metalsApiUrl);

    if (!res.ok) {
      throw new Error(`Metals API returned ${res.status}`);
    }

    const raw = await res.json();

    if (!raw.success) {
      throw new Error(raw.error?.info || "API request failed");
    }

    // Metals-API returns rates as grams per USD, we need USD per troy oz
    // 1 troy oz = 31.1034768 grams
    // Price per oz = (1 / rate_per_gram) * 31.1034768
    const rates = raw.rates;
    const toOzPrice = (ratePerGram: number) => ratePerGram ? (1 / ratePerGram) * 31.1034768 : 0;

    // For rhodium, use a fallback or estimate if not available
    // Metals-API free tier may not include rhodium
    const rhodiumEstimate = 14800; // Approximate fallback

    const data = {
      gold: toOzPrice(rates.XAU),
      silver: toOzPrice(rates.XAG),
      platinum: toOzPrice(rates.XPT),
      palladium: toOzPrice(rates.XPD),
      rhodium: rates.RH ? toOzPrice(rates.RH) : rhodiumEstimate,
      currency: raw.base || "USD",
      timestamp: raw.timestamp ? raw.timestamp * 1000 : Date.now()
    };

    return NextResponse.json(data);
  } catch (error) {
    console.error("Error fetching spot prices:", error);
    return NextResponse.json(
      { 
        error: "Failed to fetch live spot prices",
        message: error instanceof Error ? error.message : "Unknown error",
        hint: "Set METALS_API_KEY environment variable with your API key from https://metals-api.com"
      },
      { status: 500 }
    );
  }
}
